#include <stdio.h>
#include "IPCS.h"

LONG32	iRcvQid;
LONG32	iWriteQid;

LONG32	iMsgType = 1;
LONG32  iOrdRtrToCatalystNSEDRV;
LONG32 iOrdRtrToCatalystBSEEQ;
LONG32 iOrdRtrToOrdSrvBSEEQ;
LONG32 iOrdRtrToOrdSrvBSECD;
LONG32 iOrdRtrToBComOrderSvr;
LONG32 iOrdRtrToCatalystNSEEQ;
LONG32 iOrdRtrToCatalystDRV;
LONG32 iOrdRtrToOrdSrvNSECR;
LONG32 iOrdRtrToOrdSrvMCX;
LONG32 iOrdRtrToOrdSrvICEX;
LONG32 iOrdRtrToCatalystNseCM;
LONG32 iOrdRtrToOffOrd;
LONG32 iOrdRtrToCon2Del;
LONG32 iRDaemonToSqoff;
LONG32 iOrdRtrToDeaNotify;
LONG32 iOrdRtrToOrdSrvSIP;
LONG32 iOrderRtrToCalMrg;
LONG32 iOrdRtrToGTTOrd;

LONG32 iOrdRtrToOrdSrvBSEDRV; 
LONG32 iOrdRtrToCatalystBSEDRV;

LONG32 fGetQueueIdOption(CHAR sExchId[EXCHANGE_LEN] , CHAR cSegment,LONG32 iMsgCode);

main()
{
	setbuf(stdout,NULL);
	setbuf(stderr,NULL);
	fOpenMsgQueues();

	fRouteOrders();

}

BOOL fRouteOrders()
{
	LONG32	iPacketCount=0;
	SHORT	iMsgCode;
	CHAR	sExcgId[EXCHANGE_LEN];
	CHAR	cSegment;
	LONG32	iExchOption=0;	
	LONG64   iEntryTime,iEndTime;


	CHAR	RecvBuf[ RUPEE_MAX_PACKET_SIZE ] ;
	CHAR	SendBuf[ RUPEE_MAX_PACKET_SIZE ] ;
	struct	INT_COMMON_REQUEST_HDR *pReqHeader;
	struct	ORDER_REQUEST    *pOrdReq;
	//``:w	struct  CO_BO_ORDERS_REQUEST	*IntReq;

	while(TRUE)
	{

		memset(RecvBuf,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(SendBuf,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(sExcgId,'\0',EXCHANGE_LEN);
		cSegment = '\0';
		iMsgCode=0;
		iExchOption=0;

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d %d==============---------",iPacketCount++,iMsgType);
		logInfo("---------==================|||||||||||||||||||||||=================---------");


		if((ReadMsgQ(iRcvQid,&RecvBuf,RUPEE_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("\nError ReadMesgQ ");
			logFatal("RelToOrdRtr id = %d",iRcvQid);
			exit(1);

		}
		logTimestamp("Entry : [OrderRouter] :%d:",++iPacketCount);
		iMsgType = 1;
		iEntryTime = logGetTime();

		memcpy(&SendBuf,&RecvBuf,RUPEE_MAX_PACKET_SIZE);

		pReqHeader 	= (struct INT_COMMON_REQUEST_HDR *) &RecvBuf;
		//		pOrdReq  	= (struct ORDER_REQUEST *) &RecvBuf;

		logTimestamp("------------------Printing Header--------------------");
		/****Changes are user id data types ***/
		logInfo("pReqHeader->iUserId		:%llu:",pReqHeader->iUserId);
		logInfo("pReqHeader->iMsgLength 	:%d:",pReqHeader->iMsgLength);
		logInfo("pReqHeader->iMsgCode 	:%d:",pReqHeader->iMsgCode);
		logInfo("pReqHeader->sExcgId 		:%s:",pReqHeader->sExcgId);
		logInfo("pReqHeader->cSource		:%c:",pReqHeader->cSource );
		logInfo("pReqHeader->cSegment 	:%c:",pReqHeader->cSegment);
		logInfo("-------------------------------------------------------");

		//		logDebug2("pOrdReq->fOrderNum		:%lf:",pOrdReq->fOrderNum);
		//IntReq		= (struct CO_BO_ORDERS_REQUEST *) &RecvBuf;
		/*	
			logDebug2("IntReq->CoBoArray[0].cBuySellInd [%c]",IntReq->CoBoArray[0].cBuySellInd);
			logDebug2("IntReq->CoBoArray[1].cBuySellInd [%c]",IntReq->CoBoArray[1].cBuySellInd);
			logDebug2("IntReq->fOrderNum [%lf]",IntReq->fOrderNum);
		 */
		iMsgCode 	= pReqHeader->iMsgCode;

		switch (iMsgCode)
		{
			case TC_INT_ORDER_ENTRY_REQ :
			case TC_INT_ORDER_CANCEL    :

				pOrdReq         = (struct ORDER_REQUEST *) &RecvBuf;
				
				logDebug2("Market Type = %d",pOrdReq->iMktType); 
				logDebug2("pOrdReq->fOrderNum :%lf:",pOrdReq->fOrderNum);
				logDebug2("pOrdReq->sClientId	:%s:",pOrdReq->sClientId);
				logDebug2("pOrdReq->sEntityId   :%s:",pOrdReq->sEntityId);

				break;
			default :
				logDebug2("This is Default case");
				break;
		}
		logDebug2("pReqHeader->sExcgId = %s",pReqHeader->sExcgId);
		memcpy(sExcgId,pReqHeader->sExcgId,EXCHANGE_LEN);
		logDebug2("sExcgId = %s",sExcgId);
		cSegment 	= pReqHeader->cSegment ;

		iExchOption = fGetQueueIdOption(sExcgId,cSegment,iMsgCode);

		logDebug2("##### iExchOption = %d: #####",iExchOption);

		switch(iExchOption)
		{
			case NSE_EQU :
				logDebug2("Writting to the Queue :%d:",iOrdRtrToCatalystNSEEQ);
				iWriteQid = iOrdRtrToCatalystNSEEQ;
				iMsgType = 1;
				break ;
			case BSE_EQU :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToCatalystBSEEQ);
			  iWriteQid = iOrdRtrToOrdSrvBSEEQ;
				iMsgType = 1;
				break;
			case NSE_DRV :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToCatalystNSEDRV);
				iWriteQid = iOrdRtrToCatalystDRV;/* BSE derivative Having its own catalyst process*/
				iMsgType = -2;
				break;

			case BSE_DRV :
				logDebug2("Writting to the Queue--------QQQQQQQQQQQQQ---------------------- :%d:",iOrdRtrToCatalystBSEDRV);
                                iWriteQid = iOrdRtrToCatalystBSEDRV;/* BSE derivative Having its own catalyst process*/
                                iMsgType = 1;
                                break;


			case NSE_CUR :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToCatalystBSEEQ);
				iWriteQid = iOrdRtrToOrdSrvNSECR;
				iMsgType = 1;
				break; 

			case MCX_COM :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToCatalystBSEEQ);
				iWriteQid = iOrdRtrToOrdSrvMCX;
				iMsgType = 1;
				break;

                        case NSE_CM :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToCatalystNseCM);
                                iWriteQid = iOrdRtrToCatalystNseCM;
				iMsgType = 1;
                                break;

			case ICEX_COM :
				logDebug2("ICEX MSG QUEUE");
                                iWriteQid = iOrdRtrToOrdSrvICEX;			
				break;

			case OFF_ORD :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToOffOrd);
				iWriteQid = iOrdRtrToOffOrd;
				break;
			case CTD_ORD :
				iWriteQid = iOrdRtrToCon2Del;	
				break; 
			case SQR_ORD :
			  logDebug2("Writting to the Queue :%d:",iRDaemonToSqoff);
				iWriteQid = iRDaemonToSqoff;	
				break; 
			case DE_NOTI :
				logInfo("Creation ");
				iWriteQid = iOrdRtrToDeaNotify;
				break;
			case SIP_ORD : 
				iWriteQid = iOrdRtrToOrdSrvSIP; 
				break;

			case MTM_SQROFF	:
				//iWriteQid =  
				break;
			case BSE_CUR :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToOrdSrvBSECD);
				iWriteQid = iOrdRtrToOrdSrvBSECD;	
				break;
			case BSE_COMM :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToBComOrderSvr);
                                iWriteQid = iOrdRtrToBComOrderSvr;
                                break;
			case MRG_CAL: 
				iWriteQid = iOrderRtrToCalMrg;
				iMsgType = 1; 
				break;
			case GTT_ORD :
			  logDebug2("Writting to the Queue :%d:",iOrdRtrToGTTOrd);
                                iWriteQid = iOrdRtrToGTTOrd;
                                break;
			default      :
				logFatal("Invalid ExchangeId :%s:",sExcgId);
				continue ;
		}
		logInfo("iMsgType :%d:",iMsgType);

		if( WriteMsgQ(iWriteQid, &SendBuf, pReqHeader->iMsgLength,iMsgType) ==ERROR)
		{
			perror("\n WriteMsgQ Failed......");
			logFatal("WriteMsgQ to iWriteQid :%d: Failed ...",iWriteQid);
			exit(1);
		}
		logTimestamp("Exit : [OrderRouter]");
		iEndTime = logGetTime();
		logInfo("Time_Elapse -> %ld", iEndTime - iEntryTime);



		//iPacketCount++;

	}
	free(&SendBuf);
	free(RecvBuf);

}
fOpenMsgQueues()
{
	if ((iRcvQid = OpenMsgQ(RelToOrdRtr)) < 0 )
	{
		perror("\n Error Opening Mesg Q ");
		logFatal(" RelToOrdRtr key = %d iRcvQid :%d:",RelToOrdRtr,iRcvQid);
		exit(1);
	}
	logDebug2(" SucessFully Created RelToOrdRtr key = %d iRcvQid :%d:",RelToOrdRtr,iRcvQid);

	/**/	if ((iOrdRtrToOrdSrvBSEEQ = OpenMsgQ(OrdRtrToCatalystBSEEQ)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		printf("\n OrdRtrToOrdSrvBSEEQ key = %d iOrdRtrToCatalystBSEEQ:%d:",OrdRtrToCatalystBSEEQ,iOrdRtrToOrdSrvBSEEQ);
		exit(1);
	}
	logDebug2("\n SucessFully Created OrdRtrToOrdSrvBSEEQ key = %d iOrdRtrToOrdSrvBSEEQ:%d:",OrdRtrToOrdSrvBSEEQ,iOrdRtrToOrdSrvBSEEQ);
	/**/


	if ((iOrdRtrToCatalystBSEDRV = OpenMsgQ(OrdRtrToCatalystBSEDRV)) < 0 )
        {
                perror("\nError Opening Mesg Q ");
                logFatal(" OrdRtrToCatalystBSEDRV key = %d iOrdRtrToCatalystBSEDRV:%d:",OrdRtrToCatalystBSEDRV,iOrdRtrToCatalystBSEDRV);
                exit(1);
        }

        logDebug2(" SucessFully Created OrdRtrToCatalystBSEDRV key = %d iOrdRtrToCatalystBSEDRV:%d:",OrdRtrToCatalystBSEDRV,iOrdRtrToCatalystBSEDRV);

	if ((iOrdRtrToOrdSrvBSEDRV = OpenMsgQ(OrdRtrToOrdSrvBSEDRV)) < 0 )
        {
                perror("\nError Opening Mesg Q ");
                printf("\n OrdRtrToOrdSrvBSEDRV key = %d iOrdRtrToOrdSrvBSEDRV:%d:",OrdRtrToOrdSrvBSEDRV,iOrdRtrToOrdSrvBSEDRV);
                exit(1);
        }
        logDebug2("\n SucessFully Created OrdRtrToOrdSrvBSEDRV key = %d iOrdRtrToOrdSrvBSEDRV:%d:",OrdRtrToOrdSrvBSEDRV,iOrdRtrToOrdSrvBSEDRV);




	

        /**/    if ((iOrdRtrToOrdSrvBSECD = OpenMsgQ(OrdRtrToOrdSrvBSECD)) < 0 )
        {
                perror("\nError Opening Mesg Q ");
                printf("\n OrdRtrToOrdSrvBSECD key = %d iOrdRtrToOrdSrvBSECD:%d:",OrdRtrToOrdSrvBSECD,iOrdRtrToOrdSrvBSECD);
                exit(1);
        }
        logDebug2(" SucessFully Created OrdRtrToOrdSrvBSECD key = %d iOrdRtrToOrdSrvBSECD:%d:",OrdRtrToOrdSrvBSECD,iOrdRtrToOrdSrvBSECD);


	 if ((iOrdRtrToBComOrderSvr = OpenMsgQ(OrdRtrToBComOrderSvr)) < 0 )
        {
                perror("\nError Opening Mesg Q ");
                printf("\n OrdRtrToBComOrderSvr key = %d iOrdRtrToBComOrderSvr:%d:",OrdRtrToBComOrderSvr,iOrdRtrToBComOrderSvr);
                exit(1);
        }
        logDebug2(" SucessFully Created OrdRtrToBComOrderSvr key = %d iOrdRtrToBComOrderSvr:%d:",OrdRtrToBComOrderSvr,iOrdRtrToBComOrderSvr);



	if ((iOrdRtrToCatalystNSEEQ = OpenMsgQ(OrdRtrToCatalystNSEEQ)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal(" OrdRtrToCatalystNSEEQ key = %d iOrdRtrToCatalystNSEEQ:%d:",OrdRtrToCatalystNSEEQ,iOrdRtrToCatalystNSEEQ);
		exit(1);
	}

	logDebug2(" SucessFully Created OrdRtrToCatalystNSEEQ key = %d iOrdRtrToCatalystNSEEQ:%d:",OrdRtrToCatalystNSEEQ,iOrdRtrToCatalystNSEEQ);

	if ((iOrdRtrToCatalystDRV = OpenMsgQ(OrdRtrToCatalystDR)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToCatalystDR key = %d iOrdRtrToCatalystDRV:%d:",OrdRtrToOrdSrvBSEEQ,iOrdRtrToCatalystDRV);
		exit(1);
	}
	logFatal(" SucessFully Created OrdRtrToCatalystDR key = %d iOrdRtrToCatalystDRV:%d:",OrdRtrToOrdSrvBSEEQ,iOrdRtrToCatalystDRV);

	if ((iOrdRtrToOrdSrvNSECR = OpenMsgQ(OrdRtrToOrdSrvNSECR)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		printf("\nOrdRtrToCatalystNSEEQ key = %d iOrdRtrToCatalystNSEEQ:%d:n",OrdRtrToCatalystNSEEQ,iOrdRtrToCatalystNSEEQ);
		exit(1);
	}
	printf("\n SucessFully Created OrdRtrToCatalystNSEEQ key = %d iOrdRtrToCatalystNSEEQ:%d:n",OrdRtrToCatalystNSEEQ,iOrdRtrToCatalystNSEEQ);

	if ((iOrdRtrToOrdSrvMCX = OpenMsgQ(OrdRtrToOrdSrvMCX)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToOrdSrvMCX key = %d iOrdRtrToOrdSrvMCX:%d:",OrdRtrToOrdSrvMCX,iOrdRtrToOrdSrvMCX);
		exit(1);
	}
	printf("\n SucessFully Created OrdRtrToOrdSrvMCX key = %d iOrdRtrToOrdSrvMCX:%d:",OrdRtrToOrdSrvMCX,iOrdRtrToOrdSrvMCX);
        
	if((iOrdRtrToCatalystNseCM = OpenMsgQ(OrdRtrToCatalystNseCM)) == ERROR)
        {
                perror("OpenMsgQ ...OrdRtrToCatalystNSECM");
                exit(ERROR);
        }
        printf("\n SucessFully Created OrdRtrToCatalystNseCM  key = %d iOrdRtrToCatalystNseCM:%d:",OrdRtrToCatalystNseCM,iOrdRtrToCatalystNseCM);

	if ((iOrdRtrToOrdSrvICEX = OpenMsgQ(OrdRtrToOrdSrvICEX)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToOrdSrvICEX key = %d iOrdRtrToOrdSrvICEX :%d:",OrdRtrToOrdSrvICEX,iOrdRtrToOrdSrvICEX);
		exit(1);
	}
	printf("\n SucessFully Created OrdRtrToOrdSrvICEX key = %d iOrdRtrToOrdSrvICEX:%d:",OrdRtrToOrdSrvICEX,iOrdRtrToOrdSrvICEX);

	if ((iOrdRtrToOffOrd = OpenMsgQ(OrdRtrToOffOrd)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToOffOrd key = %d iOrdRtrToOffOrd:%d:",OrdRtrToOffOrd,iOrdRtrToOffOrd);
		exit(1);
	}
	printf("\n SucessFully Created OrdRtrToOffOrd key = %d iOrdRtrToOffOrd:%d:",OrdRtrToOffOrd,iOrdRtrToOffOrd);

	if ((iOrdRtrToCon2Del = OpenMsgQ(OrdRtrToCon2Del)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToCon2Del key = %d iOrdRtrToCon2Del :%d:",OrdRtrToCon2Del,iOrdRtrToCon2Del);
		exit(1);
	}
	logDebug2(" SucessFully Created OrdRtrToCon2Del key = %d iOrdRtrToCon2Del:%d:",OrdRtrToCon2Del,iOrdRtrToCon2Del);

	if ((iRDaemonToSqoff= OpenMsgQ(RDaemonToSqoff)) < 0 )
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToCon2Del key = %d iRDaemonToSqoff:%d:",OrdRtrToCon2Del,iRDaemonToSqoff);
		exit(1);
	}

	printf("\n SucessFully Created OrdRtrToCon2Del key = %d iRDaemonToSqoff:%d:",OrdRtrToCon2Del,iRDaemonToSqoff);
	if((iOrdRtrToDeaNotify = OpenMsgQ(OrdRtrToDeaNotify)) < 0)
	{
		perror("\nError Opening Mesg Q ");
		logFatal("OrdRtrToCon2Del key = %d iOrdRtrToDeaNotify = %d ",OrdRtrToCon2Del,iOrdRtrToDeaNotify);
		exit(1);
	}
	printf("\n SucessFully Created OrdRtrToDeaNotify key = %d iOrdRtrToDeaNotify:%d:",OrdRtrToDeaNotify,iOrdRtrToDeaNotify);

	if((iOrdRtrToOrdSrvSIP = OpenMsgQ (OrdRtrToOrdSrvSIP)) < 0)
	{
		perror("Error in Open Msg Que.");
		logFatal("OrdRtrToCon2Del key = %d iOrdRtrToOrdSrvSIP = %d ",OrdRtrToCon2Del,iOrdRtrToOrdSrvSIP);
		exit(1);
	}
	logDebug2("SucessFully Created OrdRtrToOrdSrvSIP key = %d iOrdRtrToOrdSrvSIP = %d ",OrdRtrToOrdSrvSIP,iOrdRtrToOrdSrvSIP);

	if((iOrderRtrToCalMrg = OpenMsgQ (OrderRtrToCalMrg)) < 0)
	{
		perror("Error in Open Msg Que.");
		logFatal("OrderRtrToCalMrg key = %d iOrderRtrToCalMrg = %d ",OrderRtrToCalMrg,iOrderRtrToCalMrg);
		exit(1);
	}
	logDebug2("SucessFully Created OrderRtrToCalMrg key = %d iOrderRtrToCalMrg = %d ",OrderRtrToCalMrg,iOrderRtrToCalMrg);

	if ((iOrdRtrToGTTOrd = OpenMsgQ(OrdRtrToGTTOrd)) < 0 )
        {
                perror("\nError Opening Mesg Q ");
                logFatal("OrdRtrToOffOrd key = %d iOrdRtrToGTTOrd:%d:",OrdRtrToGTTOrd,iOrdRtrToGTTOrd);
                exit(1);
        }
        logDebug2("SucessFully Created OrdRtrToGTTOrd key = %d iOrdRtrToGTTOrd= %d ",OrdRtrToGTTOrd,iOrdRtrToGTTOrd);
}

LONG32 fGetQueueIdOption(CHAR sExchId[EXCHANGE_LEN] , CHAR cSegment,LONG32 iMsgCode)
{
	logDebug2("sExchId :%s: cSegment :%c: iMsgCode :%d:",sExchId,cSegment,iMsgCode);
	if(iMsgCode == TC_INT_ORDER_ENTRY_REQ || iMsgCode == TC_INT_ORDER_MODIFY || iMsgCode == TC_INT_ORDER_CANCEL || iMsgCode == TC_INT_CO_ORDER_REQ || iMsgCode == TC_INT_CO_ORDER_MODIFY || iMsgCode == TC_INT_CO_ORDER_EXIT ||  iMsgCode == TC_INT_BO_ORDER_REQ || iMsgCode == TC_INT_BO_ORDER_MODIFY || iMsgCode == TC_INT_BO_LEG_MODIFY || iMsgCode == TC_INT_BO_ORDER_EXIT || iMsgCode == TC_BO_PUMP_REQ ||  iMsgCode == TC_INT_SPREAD_OE_REQ || iMsgCode == TC_INT_SPREAD_OM_REQ || iMsgCode == TC_INT_SPREAD_OC_REQ || iMsgCode == TC_INT_BO_ORDER_CANCEL || iMsgCode == TC_INT_2L_OE_REQ || iMsgCode == TC_INT_3L_OE_REQ)
	{
		if ((strncmp(sExchId,NSE_EXCH,3)==0) && ( cSegment == EQUITY_SEGMENT) )
		{
			return NSE_EQU;
		}
		else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == EQUITY_SEGMENT))
		{
			return BSE_EQU;
		}
		else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment ==CURRENCY_SEGMENT))
		{
			return BSE_CUR;
		}

		else if ((strncmp(sExchId,NSE_EXCH,3)==0 )&& ( cSegment == DERIVATIVE_SEGMENT))
		{
			return NSE_DRV;
		}
		else if ((strncmp(sExchId,NSE_EXCH,3)==0 )&& ( cSegment == CURRENCY_SEGMENT))
		{
			return NSE_CUR;
		}
		else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == DERIVATIVE_SEGMENT))
		{
			return BSE_DRV;
		}
		else if ((strncmp(sExchId,MCX_EXCH,3)==0 )&& ( cSegment == COMMODITY_SEGMENT))
		{
			return MCX_COM;
		}
                else if ((strncmp(sExchId,NSE_EXCH,3)==0 )&& ( cSegment == COMMODITY_SEGMENT))
                {
                        return NSE_CM;
                }
                else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == COMMODITY_SEGMENT))
                {
                        return BSE_COMM;
                }
		else if ((strncmp(sExchId,ICEX_EXCH,4)==0 )&& ( cSegment == COMMODITY_SEGMENT))
                {
                        return ICEX_COM;
                }
		else return INVALID_SEGMENT;
	}
	else if(iMsgCode == TC_INT_OFF_ORDER_ENTRY|| iMsgCode == TC_INT_OFF_ORDER_MODIFY|| iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		return OFF_ORD;		
	}
	else if(iMsgCode == TC_INT_CON_DEL_REQ || iMsgCode == TC_INT_ADMIN_EXPIRY_REQ)	
	{
		return CTD_ORD;
	}
	else if(iMsgCode == TC_INT_GTT_ORDER_ENTRY || iMsgCode == TC_INT_GTT_ORDER_MODIFY || iMsgCode == TC_INT_GTT_ORDER_CANCEL)
        {
                return GTT_ORD;
        }
	else if(iMsgCode ==  TC_INT_SQUAREOFF_INTRADAY_REQ || iMsgCode ==  TC_INT_SQUAREOFF_COVER_ORD_REQ || iMsgCode == TC_INT_SQUAREOFF_BRACKET_ORD_REQ || iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ || iMsgCode == TC_INT_PUMPOFFLINE_REQ || iMsgCode == TC_INT_PUMPSIPORDER_REQ )	
	{
		if ((strncmp(sExchId,NSE_EXCH,3)==0) && ( cSegment == EQUITY_SEGMENT) )
		{
			iMsgType = 2 ;
		}
		else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == EQUITY_SEGMENT))
		{
			iMsgType = 1 ;
		}
		else if ((strncmp(sExchId,NSE_EXCH,3)==0 )&& ( cSegment == DERIVATIVE_SEGMENT))
		{
			iMsgType = 3 ;
		}
		else if ((strncmp(sExchId,NSE_EXCH,3)==0 )&& ( cSegment == CURRENCY_SEGMENT))
		{
			iMsgType = 3 ;
		}
		else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == DERIVATIVE_SEGMENT))
		{
			iMsgType = 19 ;
		}
		else if ((strncmp(sExchId,MCX_EXCH,3)==0 )&& ( cSegment == COMMODITY_SEGMENT))
		{
			iMsgType = 4 ;
		}
                else if ((strncmp(sExchId,NSE_EXCH,3)==0 )&& ( cSegment == COMMODITY_SEGMENT))
                {
                        iMsgType = 4 ;
                }
		 else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == COMMODITY_SEGMENT))
                {
                        iMsgType = 4 ;
                }
		else if ((strncmp(sExchId,ICEX_EXCH,4)==0 )&& ( cSegment == COMMODITY_SEGMENT))
                {
                        iMsgType = 16 ;
                }
		else if ((strncmp(sExchId,BSE_EXCH,3)==0 )&& ( cSegment == CURRENCY_SEGMENT))
                {
                        iMsgType = 15 ;
                }

		else 
		{
			return INVALID_SEGMENT;	
		}
		return SQR_ORD;
	}
	else if(iMsgCode == TC_BULK_CANCEL_ADMIN_REQ || iMsgCode == TC_BULK_SQUAREOFF_ADMIN_REQ || iMsgCode == TC_BULK_CO_EXIT_ADMIN_REQ || iMsgCode == TC_BULK_BO_EXIT_ADMIN_REQ) 
	{
			iMsgType = 15 ;
			return SQR_ORD;
	}
	else if((iMsgCode ==  TC_INT_SIP_ORD_REQ) || (iMsgCode == TC_INT_SIP_ORD_CANCEL) || (iMsgCode == TC_INT_SIP_ORD_PAUSE_REQ) || (iMsgCode == TC_INT_SIP_ORD_CONTINUE_REQ  || (iMsgCode == TC_INT_SIP_ORD_MODIFY_REQ)))	
	{
		return SIP_ORD ;
	}
	else if((iMsgCode == TC_INT_NOTIFICATION_REQ) || (iMsgCode == TC_INT_CREATE_ALL_FILE_REQ) || (iMsgCode ==TC_INT_DEALER_CLIENT_SUSPENSION_REQ))
	{	
		return DE_NOTI;
	}
	else if(iMsgCode ==  TC_INT_MTM_AUTO_SQR_OFF )
	{
		return  MTM_SQROFF ;
	}
	else if(iMsgCode ==  TC_INT_CO_MRG_CAL_REQ || iMsgCode == TC_INT_BO_MRG_CAL_REQ || iMsgCode == TC_INT_MRG_CAL_REQ)
	{
		return  MRG_CAL;
	}


}

