#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include "IPCS.h"

main(int argc, char *argv[])
{
	logTimestamp("ENTRY [main]");

	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);


	LONG32 		iMmapToDWSTrdRtr = 0 ;
	LONG32 		iDWSTrdRtrToDWSAdp= 0 ;
	if(( iMmapToDWSTrdRtr = OpenMsgQ(MmapToDWSTrdRtr)) == ERROR)
	{
		printf("\nOpenMsgQ : Error in opening MmapToDWSTrdRtr");
		exit(ERROR);
	}

	//      if(( SndQ = OpenMsgQ(MmapToAdminAdap)) == ERROR)
	if(( iDWSTrdRtrToDWSAdp= OpenMsgQ(DWSTrdRtrToDWSAdp)) == ERROR)
	{
		printf("\nOpenMsgQ : Error in opening DWSTrdRtrToDWSAdp");
		exit(ERROR);
	}

	logDebug2("Successfully Opened Queue iMmapToDWSTrdRtr:%d:",iMmapToDWSTrdRtr);
	logDebug2("Successfully Opened Queue iDWSTrdRtrToAdmqAdap :%d:",iDWSTrdRtrToDWSAdp);
	ProcessOrder(iMmapToDWSTrdRtr,iDWSTrdRtrToDWSAdp);
	logTimestamp("Exit : [main]");

}


void ProcessOrder (LONG32 rcvQ,LONG32 respQ)
{
	logTimestamp("Entry : [ProcessOrder]");	

	CHAR            sRecvBuf[RUPEE_MAX_PACKET_SIZE];
	LONG32 		iCount = 0 ,iMsglen  = 0 , iRetVal = 0;
	LONG32	 	iMsgType;
	DOUBLE64 iOrderNo;

	while(TRUE)
	{
		logInfo("---------==================|||||||||||||||||||||||=================--------");
		logInfo("---------==================WHILE LOOP -> Count : %d ==============---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		LONG32          iUserId = 0;
		LONG32          iDWSRelayID = 0;
		memset(sRecvBuf,'\0',RUPEE_MAX_PACKET_SIZE);

		if( ReadMsgQ(rcvQ,sRecvBuf,RUPEE_MAX_PACKET_SIZE,0) ==  ERROR)
		{
			logFatal(" Error has occured while reading from Queue = %d ",rcvQ);
			exit(ERROR);
		}

		logDebug2(" ---------------------------------Printing Header resp -------------------------------");
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId :%s:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment);

		logDebug2(" ---------------------------------Printing Header -------------------------------");
		logDebug2(" Client ID :%s:",((struct ORDER_RESPONSE *)sRecvBuf)->sClientId);
		logDebug2("ORDER NO :%lf:",((struct ORDER_RESPONSE *)sRecvBuf)->fOrderNum);
		
		iOrderNo = ((struct ORDER_RESPONSE *)sRecvBuf)->fOrderNum;
		
		iUserId = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId;
		iMsglen = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength;
		logDebug2("call find_user_adapter for User Id :%d:",iUserId);
		iMsgType = GetMsgType(iOrderNo);	
	//	iDWSRelayID = find_user_adapter(iUserId);
		logDebug2("iMsgType:%d:",iMsgType);
		if( iDWSRelayID != ERROR)
		{
			logDebug2("*********** write Msg Q iDWSTrdRtrToDWSAdap **************");
			iRetVal = WriteMsgQ(respQ,sRecvBuf,iMsglen,iMsgType);
			if(iRetVal == ERROR)
			{
				perror("Error In WriteQ ");
				exit(ERROR);
			}

		}
		else
		{
			logDebug2("AdminRelay Id Not Found :%d:",iDWSRelayID);
		}
	}
	logTimestamp("EXIT [ProcessOrder]");
}




int GetMsgType(DOUBLE64 fOrderNum)
{

	LONG32 iModReturn,iTest;
	double fOrd ;
	int mod =0;
	fOrd = fOrderNum;
	iTest = fOrd/1000000;
	iTest = fOrd - iTest*1000000.0;
	//iModReturn = iTest % MOD_VALUE;  /*MOD_VALUE = 10 */
	mod = (iTest % 10);  /*MOD_VALUE = 10 */
	logDebug2(" GetModValue [%d][%d][%lf]",iTest,iModReturn,fOrd);

	/*	int mod =0;
	//	int Order = (int)OrderNo;
	printf("%f\n",OrderNo);
	//	mod = OrderNo % 10;
	int Mod= 0;
	Mod	 = (int) OrderNo;
	Mod = OrderNo/1.0;
	logDebug2("%d",Mod);

	mod = Mod % 10;
	logDebug2("%d",mod);
	 */	switch(mod)

	{
		case 0 : 
			return 1;
			break ;
		case 1 :
			return 1;
			break ;
		case 2 :
			return 2;
			break ;
		case 3 :
			return 2;
			break ;
		case 4 :
			return 3;
			break ;
		case 5 :
			return 3;
			break ;
		case 6:
			return 4;
			break ;
		case 7 :
			return 4;
			break ;
		case 8 :
			return 5;
			break ;
		case 9 :
			return 5;
			break ;
		default :
			return ERROR;
			break ;

	}


}

