#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include "IPCS.h"


struct THREAD_PARAMS
{
	LONG32 queue_id;
};

void *fProcess_Request(void* );

LONG32	iOrdSrvToTrdRtr;
LONG32	iTrdSrvToTrdRtr;
LONG32	iTrdRtrToDWSMMap;
LONG32	iTrdRtrToAdminMMap;
LONG32	iTrdRtrToWebAdap;
LONG32	iTrdRtrToRms;
LONG32	iTrdRtrToD2C1MMap;	
LONG32	iTrdRtrToSysMsg;	
LONG32	iTrdRtrToTradeMobMMap;	
void signal_handler(LONG32 Sig);
CHAR flag[1];


main()
{
	struct THREAD_PARAMS params[Max_Num_Threads];
	pthread_t thread_id[Max_Num_Threads];

	LONG32	i=0;
	if(getenv("NOTIFY_FE")==NULL)
	{
		logFatal("Error : Environment variables missing : NOTIFY_FE");
		exit(ERROR);
	}
	else
	{
		strcpy(flag,getenv("NOTIFY_FE"));
		logDebug2("flag   :%s:",flag);
	}

	setbuf(stdout , NULL);
	setbuf(stderr , NULL);
	signal(SIGINT,signal_handler);
	signal(SIGHUP,SIG_IGN);
	signal(SIGTERM,signal_handler);

	fOpenMsgQue();

	for(i=0;i<Max_Num_Threads;i++)
	{
		if ( i == 0 )
		{
			params[i].queue_id = iOrdSrvToTrdRtr;
		}
		else if(i == 1)
		{
			params[i].queue_id = iTrdSrvToTrdRtr;
		}
		else
		{
			params[i].queue_id = iTrdSrvToTrdRtr;
		}	


		if ((pthread_create(&thread_id[i],NULL,fProcess_Request,(void *)&params[i]))!=0)
		{
			logFatal(" Cant create thread %d",i);
		}
		else
		{
			logInfo(" Created");
		}	
	}

	for(i=0;i<Max_Num_Threads;i++)
	{

		logFatal(" Thread %d ....",i);

		if (pthread_join(thread_id[i],NULL))
		{
			logFatal(" Error when waiting for thread % to terminate", i);
		}
		else
		{
			logFatal(" Stopped");
		}

		logInfo("Detach thread...");

		if (pthread_detach(&thread_id[i]))
		{
			logFatal(" Error detaching thread!");
		}
		else
		{
			logInfo("Detached!");
		}

		logFatal("Stop Session %d....",i);

		logInfo("Logged Off");
	}

}

void* fProcess_Request(void *parameter)
{
	CHAR		sRecvBuf[RUPEE_MAX_PACKET_SIZE];
	LONG32		Thread_ID_Log = 0;
	LONG32		iCount;
	CHAR            cSource;
	CHAR		cProductId ;
	LONG32		iLegValue = 0;
	LONG32		iRelayID;
	ULONG64		iUserId;
	LONG32		iRetVal;
	LONG32		iMsglen=0;
	LONG32		iMsgcode =0;
	LONG32		iMsgType =0;
	LONG32		iAdmnRelayID = 0;
	CHAR    sTempIPCS[7];
	CHAR    sTempShm[7];

	LONG64          iEntryTime;
	LONG64          iEndTime;

	struct THREAD_PARAMS *l_parameter = parameter;

	Thread_ID_Log = pthread_self();


	while(TRUE)
	{
		memset(sRecvBuf,'\0',RUPEE_MAX_PACKET_SIZE);
		iCount++;
		cSource =0;
		iRelayID= ERROR;
		iAdmnRelayID=ERROR;
		logInfo(" ===================== No Of Pkts : %d For Thread [%d] =================",iCount,Thread_ID_Log);	
		logInfo(" ===================== Waiting for packet===============================");

		if( l_parameter->queue_id == iOrdSrvToTrdRtr )
		{
			logInfo("===========================reading from OrderServer ========================================");

			if(ReadMsgQ(iOrdSrvToTrdRtr,sRecvBuf,RUPEE_MAX_PACKET_SIZE,0) ==  ERROR)
			{
				logFatal(" Error has occured while reading from Queue = %d ",iOrdSrvToTrdRtr);
				perror("\n Error in reading the Packet ");
				pthread_exit(NULL);
			}
			logDebug2(" Successfully Read From %d Q,",iOrdSrvToTrdRtr);
			logDebug2("iMsgCode = %d",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);
		}
		else
		{
			logInfo("===========================reading from TradeServer ========================================");
			if( ReadMsgQ(iTrdSrvToTrdRtr,sRecvBuf,RUPEE_MAX_PACKET_SIZE,0) ==  ERROR)
			{
				logFatal(" Error has occured while reading from Queue = %d ",iTrdSrvToTrdRtr);
				perror("\n Error in reading the Packet ");
				pthread_exit(NULL);
			}
			logDebug2(" Successfully Read From %d Q,",iTrdSrvToTrdRtr);
                        logDebug2("iMsgCode = %d",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);	

		}

		logTimestamp(" Traderouter [ENTRY]");
		logDebug2(" ---------------------------------Printing Header resp -------------------------------");
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId :%s:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId :%llu:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment);

		logDebug2(" ---------------------------------Printing Header -------------------------------");
		logDebug2(" Client ID :%s:",((struct ORDER_RESPONSE *)sRecvBuf)->sClientId);
		logDebug2("ORDER NO :%lf:",((struct ORDER_RESPONSE *)sRecvBuf)->fOrderNum);
		iUserId = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId;
		iMsglen = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength;


		logDebug2(" SRC_MOB :%s: SRC_WEB :%s: SRC_ADM :%s: ",SRC_MOB,SRC_WEB,SRC_ADM);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource);
		logDebug2("((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);

		switch(((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode)
		{
			case TC_INT_ADMIN_EXPIRY_RESP :
			case TC_INT_AUTOBATCH_MSG_RESP:
			case TC_INT_CREATE_ALL_FILE_RES :
			case TC_INT_CLIENT_ADDED_NOTIFICATION:
				logDebug2("call find_admin_adapter");
                                iRetVal = WriteMsgQ(iTrdRtrToAdminMMap,sRecvBuf,iMsglen,1);
                                if(iRetVal == ERROR)
                                {
                                        perror("Error In WriteQ ");
                                        //exit(ERROR);
                                }
				
				if(((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode == TC_INT_ADMIN_EXPIRY_RESP)
				{
					if((WriteMsgQ(iTrdRtrToRms,sRecvBuf,iMsglen,1)) != TRUE)
					{
						logFatal("Error : Basic error sent failed while sending For RMS");
						//exit(ERROR);
					}
	
				}
				break;
			
			case TC_INT_OE_ERROR_RESP:
			case TC_INT_OM_ERROR_RESP:
//			case TC_INT_OC_ERROR_RESP:
			case TC_INT_TRADE_RESP:
			case TC_INT_MKT_LMT_CONVT_RESP:
			case TC_INT_OC_CONF_RESP:
			//case TC_INT_OFF_ORDER_CANCEL_RSP:
			case TC_INT_SPREAD_OC_CONF_RESP:
			case TC_INT_SPREAD_OE_ERR_RESP:
			case TC_INT_SPREAD_OM_ERR_RESP:
			case TC_INT_SPREAD_OC_ERR_RESP:

			case TC_BO_OE_ERROR_RESP :
			case TC_BO_OM_ERROR_RESP :
			case TC_BO_OC_ERROR_RESP :
			case TC_BO_OC_CONF_RESP :
			case TC_BO_MKT_LMT_CONVT_RESP :
			case TC_BO_TRADE_RESP   :

				logDebug2("Writing to RMSRevValidate");

				if((WriteMsgQ(iTrdRtrToRms,sRecvBuf,iMsglen,1)) != TRUE)
				{
					logFatal("Error : Basic error sent failed while sending For RMS");
					//exit(ERROR);
				}
				
				break;
			default :
				logInfo(" No RMS Call");
				break;


		}
		if((strchr(SRC_MOB,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL) || (strchr(SRC_WEB,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL) )
		{
			//			logDebug2(" Assinging WEB_RELAY_ID (222)");
			//			iRelayID = WEB_RELAY_ID;
			iMsgcode = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode;
			logDebug2("iMsgcode :%d:",iMsgcode);
			switch (iMsgcode)
			{
				case TC_INT_TRADE_RESP          :
				case TC_INT_SL_ORDER_TRIG_RESP  :
				case TC_INT_OE_FREEZE_RESP      :
				case TC_INT_OE_CONF_RESP        :
				case TC_INT_OE_ERROR_RESP       :
				case TC_INT_OM_ERROR_RESP       :
				case TC_INT_OM_CONF_RESP        :
				case TC_INT_OC_ERROR_RESP       :
				case TC_INT_OC_CONF_RESP        :
				case TC_INT_MKT_LMT_CONVT_RESP  :
				case TC_INT_RMS_ORD_REJECTION 	:

					logDebug2("Not writting to iTrdRtrToWebAdap");

					break ;
				default :

					logDebug2("cProductId :%c:",((struct ORDER_RESPONSE *)sRecvBuf)->cProductId);
					logDebug2("iLegValue   :%d:",((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue);

					cProductId = ((struct ORDER_RESPONSE *)sRecvBuf)->cProductId ;
					iLegValue  =  ((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue ;

					if (iLegValue == LEG_1 && cProductId  == PROD_COVER && iMsgcode == TC_INT_ORDER_ENTRY_RSP)
					{
						logDebug2("Dropping Leg 1 Internal Confirmation Packet in Case of Cover Order");
						break;
					}
					else
					{
						logDebug2("Writing to  TrdRtrToWebAdap iMsgType = 1");
						iRetVal = WriteMsgQ(iTrdRtrToWebAdap,sRecvBuf,iMsglen,1);
						if(iRetVal == ERROR)
						{
							perror("Error In WriteQ iTrdRtrToWebAdap");
							exit(ERROR);
						}
						logTimestamp(" Traderouter [EXIT]");
						break ;
					}

			}


		}
/*		if((strchr(SRC_MOB,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL)|| (strchr(SRC_WEB,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) && ((struct INT_COMMON_RESP_HDR *)sRecvBuf )->iMsgCode ==  TC_INT_TRADE_RESP))
		{
			if(!strcmp(flag,STR_YES))
			{
				logDebug2("Writing To The Memory Mapping for Source Mobile ");
				iRetVal = WriteMsgQ(iTrdRtrToTradeMobMMap,sRecvBuf,iMsglen,1);
				if(iRetVal == ERROR)
				{
					perror("Error In WriteQ ");
					exit(ERROR);
				}
			}
			else
			{
				logDebug2("Write Flag is Not For Source Mobile");
			}

		}
*/		if((strchr(SRC_ADM,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL) || (strchr(SRC_SYS,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL))
		{
			/*			logDebug2("call find_admin_adapter");
						iAdmnRelayID = find_admin_adapter(iUserId);
						logDebug2("In SRC_ADM iAdmnRelayID :%d:",iAdmnRelayID);
						if( iAdmnRelayID != FIND_USER_RELAY_ERROR)
						{*/
			logDebug2("*********** write Msg Q iTradeRtrToAdminMemMap **************");
			//				iRetVal = WriteMsgQ(iAdminQueriesToAdaptor,sRecvBuf,iMsglen,iAdmnRelayID);
			//
			switch (iMsgcode)
                        {
                                case TC_INT_TRADE_RESP          :
                                case TC_INT_SL_ORDER_TRIG_RESP  :
                                case TC_INT_OE_FREEZE_RESP      :
                                case TC_INT_OE_CONF_RESP        :
                                case TC_INT_OE_ERROR_RESP       :
                                case TC_INT_OM_ERROR_RESP       :
                                case TC_INT_OM_CONF_RESP        :
                                case TC_INT_OC_ERROR_RESP       :
                                case TC_INT_OC_CONF_RESP        :
                                case TC_INT_MKT_LMT_CONVT_RESP  :
                                //case TC_INT_RMS_ORD_REJECTION   :

                                        logDebug2("Not writting to iTrdRtrToAdmimAdap");

                                        break ;
				
		/**		case TC_INT_ADMIN_EXPIRY_RESP :
                                        
					logDebug2("call find_admin_adapter");
					iRetVal = WriteMsgQ(iTrdRtrToAdminMMap,sRecvBuf,iMsglen,1);
		                        if(iRetVal == ERROR)
        		                {
                		                perror("Error In WriteQ ");
                        		        exit(ERROR);
	                        	}

					break;**/
					
					
                                default :

                                        logDebug2("cProductId :%c:",((struct ORDER_RESPONSE *)sRecvBuf)->cProductId);
                                        logDebug2("iLegValue   :%d:",((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue);

                                        cProductId = ((struct ORDER_RESPONSE *)sRecvBuf)->cProductId ;
                                        iLegValue  =  ((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue ;
					

                                        //``if (iLegValue == LEG_1 && cProductId  == PROD_COVER && iMsgcode == TC_INT_ORDER_ENTRY_RSP)
                                        if (iLegValue == LEG_1 && cProductId  == PROD_COVER && ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode == TC_INT_ORDER_ENTRY_RSP)
                                        {
                                                logDebug2("Dropping Leg 1 Internal Confirmation Packet in Case of Cover Order");
                                                logDebug2("Msgcode :%d",iMsgcode);
                                                break;
                                        }
                                        else
					{
                                                logDebug2("Writing to  TrdRtrToWebAdap iMsgType = 1");
                                                iRetVal = WriteMsgQ(iTrdRtrToWebAdap,sRecvBuf,iMsglen,1);
                                                if(iRetVal == ERROR)
                                                {
                                                        perror("Error In WriteQ iTrdRtrToWebAdap");
                                                        exit(ERROR);
                                                }
                                                logTimestamp(" Traderouter [EXIT]");
                                                break ;
                                        }

                        }


			//iRetVal = WriteMsgQ(iTrdRtrToAdminMMap,sRecvBuf,iMsglen,1);
			//if(iRetVal == ERROR)
			//{
			//	perror("Error In WriteQ ");
			//	exit(ERROR);
			//}

			/*			}
						else
						{
						logDebug2("AdminRelay Id Not Found :%d:",iAdmnRelayID);
						}*/


		}
		if ((strchr(SRC_EXE,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL) || (strchr(SRC_SYS,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL))
		{
			/*			logDebug2(" Before find_user_adapter");
						iRelayID = find_user_adapter(iUserId);
						logDebug2(" in SRC_EXE iRelayID :%d:",iRelayID);
						if ( iRelayID != FIND_USER_RELAY_ERROR)
						{*/
			logDebug2("#########WriteMsgQ iTrdRtrToDwsMemoryMap #################");
			//				iRetVal = WriteMsgQ(iTrdRtrToRel,sRecvBuf,iMsglen,iRelayID);
			switch (iMsgcode)
                        {
                                case TC_INT_TRADE_RESP          :
                                case TC_INT_SL_ORDER_TRIG_RESP  :
                                case TC_INT_OE_FREEZE_RESP      :
                                case TC_INT_OE_CONF_RESP        :
                                case TC_INT_OE_ERROR_RESP       :
                                case TC_INT_OM_ERROR_RESP       :
                                case TC_INT_OM_CONF_RESP        :
                                case TC_INT_OC_ERROR_RESP       :
                                case TC_INT_OC_CONF_RESP        :
                                case TC_INT_MKT_LMT_CONVT_RESP  :
                                //case TC_INT_RMS_ORD_REJECTION   :

                                        logDebug2("Not writting to iTrdRtrToWebAdap");

                                        break ;
                                default :

                                        logDebug2("cProductId :%c:",((struct ORDER_RESPONSE *)sRecvBuf)->cProductId);
                                        logDebug2("iLegValue   :%d:",((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue);

                                        cProductId = ((struct ORDER_RESPONSE *)sRecvBuf)->cProductId ;
                                        iLegValue  =  ((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue ;

                                        if (iLegValue == LEG_1 && cProductId  == PROD_COVER && iMsgcode == TC_INT_ORDER_ENTRY_RSP)
                                        {
                                                logDebug2("Dropping Leg 1 Internal Confirmation Packet in Case of Cover Order");
                                                break;
                                        }
                                        else
                                        {
                                                logDebug2("Writing to  TrdRtrToWebAdap iMsgType = 1");
                                                iRetVal = WriteMsgQ(iTrdRtrToWebAdap,sRecvBuf,iMsglen,1);
                                                if(iRetVal == ERROR)
                                                {
                                                        perror("Error In WriteQ iTrdRtrToWebAdap");
                                                        exit(ERROR);
                                                }
                                                logTimestamp(" Traderouter [EXIT]");
                                                break ;
                                        }
			}
			//iRetVal = WriteMsgQ(iTrdRtrToDWSMMap,sRecvBuf,iMsglen,1);
			//if(iRetVal == ERROR)
			//{
			//	perror("Error In WriteQ iTrdRtrToDwsMemoryMap");
			//	exit(ERROR);
			//}

			/*			}
						else
						{
						logDebug2("Relay Id Not Found :%d:",iRelayID);
						}*/

			/*			if(((struct INT_COMMON_RESP_HDR *)sRecvBuf )->iMsgCode == TC_INT_RMS_ORD_REJECTION)
						{
						logDebug2("*********** write Msg Q iAdminQueriesToAdaptor **************");
						logDebug2("call find_admin_adapter..");

						iAdmnRelayID = find_admin_adapter(iUserId);
						logDebug2("In SRC_EXE  iAdmnRelayID :%d:",iAdmnRelayID);	
						if (iAdmnRelayID != FIND_USER_RELAY_ERROR)
						{

						iRetVal = WriteMsgQ(iAdminQueriesToAdaptor,sRecvBuf,iMsglen,iAdmnRelayID);
						}
						else
						{
						logDebug2("AdminRelay Id Not Found :%d:",iAdmnRelayID);
						}

						logTimestamp(" Traderouter [EXIT]");
						}*/



		}
		logDebug2("Writing to  TrdRtrToMMap ");
		logDebug2(" Client ID :%s:",((struct ORDER_RESPONSE *)sRecvBuf)->sClientId);
		logDebug2("before writing to D2C1 (struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);
		iRetVal = WriteMsgQ(iTrdRtrToD2C1MMap,sRecvBuf,iMsglen,1);
		if(iRetVal == ERROR)
		{
			perror("Error In WriteQ iTrdRtrToD2C1MMap");
			exit(ERROR);
		}

		//logDebug2(" iMktType :%d:",((struct ORDER_RESPONSE *)sRecvBuf)->iMktType);

		/*		switch(((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode)
				{
				case TC_INT_OE_ERROR_RESP:
				case TC_INT_OM_ERROR_RESP:
				case TC_INT_OC_ERROR_RESP:
				case TC_INT_TRADE_RESP:
				case TC_INT_MKT_LMT_CONVT_RESP:
				case TC_INT_OC_CONF_RESP:
				case TC_INT_OFF_ORDER_CANCEL_RSP:	
				case TC_INT_SPREAD_OC_CONF_RESP:	
				case TC_INT_SPREAD_OE_ERR_RESP:	
				case TC_INT_SPREAD_OM_ERR_RESP:	
				case TC_INT_SPREAD_OC_ERR_RESP:	
				case TC_INT_ADMIN_EXPIRY_RESP :

				case TC_BO_OE_ERROR_RESP :
				case TC_BO_OM_ERROR_RESP :
				case TC_BO_OC_ERROR_RESP :
				case TC_BO_OC_CONF_RESP :
				case TC_BO_MKT_LMT_CONVT_RESP :
				case TC_BO_TRADE_RESP	:

				logDebug2("Writing to RMSRevValidate");

				if((WriteMsgQ(iTrdRtrToRms,sRecvBuf,iMsglen,1)) != TRUE)
				{
				logFatal("Error : Basic error sent failed while sending For RMS");
		//exit(ERROR);
		}
		logTimestamp(" Traderouter [EXIT]");
		break;
		default :
		logInfo(" No RMS Call");
		break;


		}*/



		/*		if (iRelayID == FIND_USER_RELAY_ERROR)
				{
				logFatal(" [%d]  Relay No for this particular userid [%d] is not found ",Thread_ID_Log,iUserId);
				iEndTime = logGetTime();
				logInfo("Time_Elapse TradeRouter -> %ld",iEndTime - iEntryTime);
				continue;
				}*/


		/****		if((WriteMsgQ(iTrdRtrToRms,sRecvBuf,iMsglen,1)) != TRUE)
		  {
		  logFatal("Error : Basic error sent failed while sending For RMS");
		//exit(ERROR);
		}****/

		/*		if ( iRelayID != WEB_RELAY_ID)
				{	
				logDebug2("Source :%c:",((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource);

				if( strchr(SRC_ADM,((struct INT_COMMON_RESP_HDR *)sRecvBuf )->cSource) != NULL )
				{
				logDebug2("*********** write Msg Q iAdminQueriesToAdaptor **************");
				iRetVal = WriteMsgQ(iAdminQueriesToAdaptor,sRecvBuf,iMsglen,iAdmnRelayID);
				logTimestamp(" Traderouter [EXIT]");
				}
				else
				{
				if(((struct INT_COMMON_RESP_HDR *)sRecvBuf )->iMsgCode == TC_INT_RMS_ORD_REJECTION)
				{
				logDebug2("*********** write Msg Q iAdminQueriesToAdaptor **************");
				iRetVal = WriteMsgQ(iAdminQueriesToAdaptor,sRecvBuf,iMsglen,iAdmnRelayID);
				logTimestamp(" Traderouter [EXIT]");
				}
				else
				{
				logDebug2("#########WriteMsgQ iTrdRtrToDWSAdapter #################");
				iRetVal = WriteMsgQ(iTrdRtrToRel,sRecvBuf,iMsglen,iRelayID);
				logTimestamp(" Traderouter [EXIT]");
				}
				}
				if(iRetVal == ERROR)
				{
				perror("Error In WriteQ ");
				exit(ERROR);
				}	

				}
				else
				{
				iMsgcode = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode ;
				logDebug2("iMsgcode before Switch = %d:",iMsgcode);
				switch (iMsgcode)
				{
				case TC_INT_TRADE_RESP          :
				case TC_INT_SL_ORDER_TRIG_RESP  :
				case TC_INT_OE_FREEZE_RESP      :
				case TC_INT_OE_CONF_RESP        :
				case TC_INT_OE_ERROR_RESP       :
				case TC_INT_OM_ERROR_RESP       :
				case TC_INT_OM_CONF_RESP        :
				case TC_INT_OC_ERROR_RESP       :
				case TC_INT_OC_CONF_RESP        :
				case TC_INT_MKT_LMT_CONVT_RESP  :

				logDebug2("Not writting to iTrdRtrToWebAdap");

				break ;
				default :

				logDebug2("cProductId :%c:",((struct ORDER_RESPONSE *)sRecvBuf)->cProductId);
				logDebug2("iLegValue   :%d:",((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue);

				cProductId = ((struct ORDER_RESPONSE *)sRecvBuf)->cProductId ;
				iLegValue  =  ((struct ORDER_RESPONSE *)sRecvBuf)->iLegValue ;

				if (iLegValue == LEG_1 && cProductId  == PROD_COVER && iMsgcode == TC_INT_ORDER_ENTRY_RSP)
				{
				logDebug2("Dropping Leg 1 Internal Confirmation Packet in Case of Cover Order");
				break;
				}
				else
				{
				logDebug2("Writing to  TrdRtrToWebAdap iMsgType = 1");
		//					iRetVal = WriteMsgQ(iTrdRtrToWebAdap,sRecvBuf,iMsglen,iMsgType);
		iRetVal = WriteMsgQ(iTrdRtrToWebAdap,sRecvBuf,iMsglen,1);
		if(iRetVal == ERROR)
		{
			perror("Error In WriteQ iTrdRtrToWebAdap");
			exit(ERROR);
		}
		logTimestamp(" Traderouter [EXIT]");
		break ;
	}	
	}

	logDebug2(" iUserId In WebPart :%d:",iUserId);	
	iRelayID = find_user_adapter(iUserId);
	if(iRelayID != ERROR)
	{	
		iRetVal = WriteMsgQ(iTrdRtrToRel,sRecvBuf,iMsglen,iRelayID);
		if(iRetVal == ERROR)
		{
			perror("Error In WriteQ iTrdRtrToRel");
			exit(ERROR);
		}
		logTimestamp(" Traderouter [EXIT]");
	}

	}*/

	//		iRetVal = ERROR;

	/*		logDebug2("Writing to  TrdRtrToD2C1Router");	
			iRetVal = WriteMsgQ(iTrdRtrToD2C,sRecvBuf,iMsglen,1);
			if(iRetVal == ERROR)
			{
			perror("Error In WriteQ iTrdRtrToD2C");
			exit(ERROR);
			}	*/

	/***		iRetVal = ERROR;

	  logDebug2("Writing to  TrdRtrToSysMsg");	
	  iRetVal = WriteMsgQ(iTrdRtrToSysMsg,sRecvBuf,iMsglen,1);
	  if(iRetVal == ERROR)
	  {
	  logDebug2("plzz chck the error");
	  perror("Error In WriteQ iTrdRtrToSysMsg");
	  exit(ERROR);
	  }
	 ***/
	logTimestamp(" EXIT [TradeRouter]");
	}/*** END of while ****/

}/*** END of fProcess_Request *****/
void signal_handler(LONG32 Sig)
{
	logDebug2("signal_handler: Signal caught is::%d ",Sig);
	exit_handler();
	return;
}
BOOL exit_handler()
{
}

void fOpenMsgQue()
{

	logTimestamp("Entry : [fOpenMsgQue]");

	if((iOrdSrvToTrdRtr =  OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal(" Error in Opening OrdSrvToTrdRtr ");
		exit(ERROR);
	}
	logInfo("iOrdSrvToTrdRtr opened successfully with id = %d", iOrdSrvToTrdRtr);

	if((iTrdSrvToTrdRtr =  OpenMsgQ(TrdSrvToTrdRtr)) == ERROR)
	{
		logFatal(" Error in Opening TrdSrvToTrdRtr ");
		exit(ERROR);
	}
	logInfo("iTrdSrvToTrdRtr opened successfully with id = %d", iTrdSrvToTrdRtr);
	/***/   if((iTrdRtrToDWSMMap=  OpenMsgQ(TrdRtrToDWSMMap)) == ERROR)
	{
		logFatal(" Error in Opening TrdRtrToDWSMMap");
		exit(ERROR);
	}
	/*****/
	if((iTrdRtrToWebAdap =  OpenMsgQ(TrdRtrToWebAdap)) == ERROR)
	{
		logFatal(" Error in Opening TrdRtrToWebAdap ");
		exit(ERROR);
	}
	logInfo("iTrdRtrToWebAdap opened successfully with id = %d",iTrdRtrToWebAdap);

	if((iTrdRtrToRms = OpenMsgQ(TrdRtrToRevRmsVal)) == ERROR)
	{
		logFatal(" Error in Opening TrdRtrToRevRmsVal");
		exit(ERROR);
	}
	logInfo("iTrdRtrToRms opened successfully with id = %d", iTrdRtrToRms );

	if((iTrdRtrToD2C1MMap=  OpenMsgQ(TrdRtrToD2C1MMap)) == ERROR)
	{
		logFatal(" Error in Opening TrdRtrToD2C1MMap");
		exit(ERROR);
	}
	logInfo(" iTrdRtrToD2C1MMap opened successfully with id = %d", iTrdRtrToD2C1MMap);

	if((iTrdRtrToSysMsg =  OpenMsgQ(TrdRtrToSysMsg)) == ERROR)
	{
		logFatal(" Error in Opening TrdRtrToSysMsg");
		exit(ERROR);
	}
	logInfo(" iTrdRtrToSysMsg opened successfully with id = %d", iTrdRtrToSysMsg);

	if((iTrdRtrToAdminMMap= OpenMsgQ(TrdRtrToAdminMMap)) == ERROR)
	{
		logFatal("error in Open TrdRtrToAdminMMap Que :");
		exit(ERROR);
	}

	logInfo("iTrdRtrToAdminMMap opened successfully with id = %d",iTrdRtrToAdminMMap);

	if((iTrdRtrToTradeMobMMap= OpenMsgQ(TrdRtrToTradeMobMMap)) == ERROR)
	{
		logFatal("error in Open iTrdRtrToTradeMobMMap Que :");
		exit(ERROR);
	}

	logInfo("iTrdRtrToTradeMobMMap opened successfully with id = %d",iTrdRtrToTradeMobMMap);

	logTimestamp("Exit : [fOpenMsgQue]");

}
