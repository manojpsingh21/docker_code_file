#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include "IPCS.h"

main(int argc, char *argv[])
{
	logTimestamp("ENTRY [main]");

	setbuf(stdout  ,NULL);
        setbuf(stderr  ,NULL);


	LONG32 		iMmapToAdmnTrdRtr= 0 ;
	LONG32 		iTrdRtrToRel= 0 ;
	if(( iMmapToAdmnTrdRtr= OpenMsgQ(MmapToAdmnTrdRtr)) == ERROR)
	{
		logFatal("OpenMsgQ : Error in opening MmapToAdmnTrdRtr ");
		exit(ERROR);
	}

	//      if(( SndQ = OpenMsgQ(MmapToAdminAdap)) == ERROR)
	/*        if(( iAdmTrdRtrToAdmAdap = OpenMsgQ(AdmTrdRtrToAdmAdap)) == ERROR)
		  {
		  logFatal("OpenMsgQ : Error in opening MmapToAdminAdap");
		  exit(ERROR);
		  }
	 */

	if((iTrdRtrToRel= OpenMsgQ(AdminQueriesToAdaptor)) == ERROR)
	{
		perror("Open TrdRtrToRel");
		exit(ERROR);
	}

	logDebug2("Successfully Opened Queue iMmapToAdmnTrdRtr:%d:",iMmapToAdmnTrdRtr);
	logDebug2("Successfully Opened Queue iAdmTrdRtrToAdmAdap :%d:",iTrdRtrToRel);
	ProcessOrder(iMmapToAdmnTrdRtr,iTrdRtrToRel);
	logTimestamp("Exit : [main]");

}


void ProcessOrder (LONG32 rcvQ,LONG32 respQ)
{
	logTimestamp("Entry : [ProcessOrder]");	

	CHAR            sRecvBuf[RUPEE_MAX_PACKET_SIZE];
	LONG32 		iCount = 0 ,iMsglen  = 0 , iRetVal = 0;

	while(TRUE)
	{
		logInfo("---------==================|||||||||||||||||||||||=================--------");
		logInfo("---------==================WHILE LOOP -> Count : %d ==============---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		LONG32          iUserId = 0;
		LONG32          iAdmnRelayID = 0;
		memset(sRecvBuf,'\0',RUPEE_MAX_PACKET_SIZE);

		if( ReadMsgQ(rcvQ,sRecvBuf,RUPEE_MAX_PACKET_SIZE,0) ==  ERROR)
		{
			logFatal(" Error has occured while reading from Queue = %d ",rcvQ);
			exit(ERROR);
		}

	//	((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId = 123;
		logDebug2(" ---------------------------------Printing Header resp -------------------------------");
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId :%s:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource);
		logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment);

		logDebug2(" ---------------------------------Printing Header -------------------------------");
		logDebug2(" Client ID :%s:",((struct ORDER_RESPONSE *)sRecvBuf)->sClientId);
		logDebug2("ORDER NO :%lf:",((struct ORDER_RESPONSE *)sRecvBuf)->fOrderNum);

		iUserId = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId;
		iMsglen = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength;
		logDebug2("call find_admin_adapter for User Id :%d:",iUserId);
		iAdmnRelayID = find_admin_adapter(iUserId);
		logDebug2("iAdmnRelayID :%d:",iAdmnRelayID);
		if( iAdmnRelayID != FIND_USER_RELAY_ERROR)
		{
			logDebug2("*********** write Msg Q iAdminQueriesToAdaptor **************");
			iRetVal = WriteMsgQ(respQ,sRecvBuf,iMsglen,iAdmnRelayID);
			if(iRetVal == ERROR)
			{
				perror("Error In WriteQ ");
				exit(ERROR);
			}

		}
		else
		{
			logDebug2("AdminRelay Id Not Found :%d:",iAdmnRelayID);
		}
	}
	logTimestamp("EXIT [ProcessOrder]");
}

