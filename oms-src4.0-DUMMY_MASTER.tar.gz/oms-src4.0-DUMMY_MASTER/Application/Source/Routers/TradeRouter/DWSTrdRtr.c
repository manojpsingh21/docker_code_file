#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include "IPCS.h"

main(int argc, char *argv[])
{
	logTimestamp("ENTRY [main]");

	setbuf(stdout  ,NULL);
        setbuf(stderr  ,NULL);


	LONG32 		iMmapToDWSTrdRtr = 0 ;
	LONG32 		iDWSTrdRtrToDWSAdp= 0 ;
	if(( iMmapToDWSTrdRtr = OpenMsgQ(MmapToDWSTrdRtr)) == ERROR)
        {
                printf("\nOpenMsgQ : Error in opening MmapToDWSTrdRtr");
                exit(ERROR);
        }

//      if(( SndQ = OpenMsgQ(MmapToAdminAdap)) == ERROR)
        if(( iDWSTrdRtrToDWSAdp= OpenMsgQ(DWSTrdRtrToDWSAdp)) == ERROR)
        {
                printf("\nOpenMsgQ : Error in opening DWSTrdRtrToDWSAdp");
                exit(ERROR);
        }
	
	logDebug2("Successfully Opened Queue iMmapToDWSTrdRtr:%d:",iMmapToDWSTrdRtr);
	logDebug2("Successfully Opened Queue iDWSTrdRtrToAdmqAdap :%d:",iDWSTrdRtrToDWSAdp);
	ProcessOrder(iMmapToDWSTrdRtr,iDWSTrdRtrToDWSAdp);
	logTimestamp("Exit : [main]");

}


void ProcessOrder (LONG32 rcvQ,LONG32 respQ)
{
	logTimestamp("Entry : [ProcessOrder]");	

	CHAR            sRecvBuf[RUPEE_MAX_PACKET_SIZE];
	LONG32 		iCount = 0 ,iMsglen  = 0 , iRetVal = 0;

	while(TRUE)
	{
		logInfo("---------==================|||||||||||||||||||||||=================--------");
                logInfo("---------==================WHILE LOOP -> Count : %d ==============---------",iCount++);
                logInfo("---------==================|||||||||||||||||||||||=================---------");
		ULONG64          iUserId = 0;
		LONG32          iDWSRelayID = 0;
	 	memset(sRecvBuf,'\0',RUPEE_MAX_PACKET_SIZE);

		if( ReadMsgQ(rcvQ,sRecvBuf,RUPEE_MAX_PACKET_SIZE,0) ==  ERROR)
	      	{
	        	logFatal(" Error has occured while reading from Queue = %d ",rcvQ);
			exit(ERROR);
	     	}
		
		logDebug2(" ---------------------------------Printing Header resp -------------------------------");
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iSeqNo);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgCode);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId :%s:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->sExcgId);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId :%d:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iErrorId);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId :%llu:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSource);
                logDebug2(" ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment :%c:",((struct INT_COMMON_RESP_HDR *) sRecvBuf )->cSegment);

                logDebug2(" ---------------------------------Printing Header -------------------------------");
                logDebug2(" Client ID :%s:",((struct ORDER_RESPONSE *)sRecvBuf)->sClientId);
                logDebug2("ORDER NO :%lf:",((struct ORDER_RESPONSE *)sRecvBuf)->fOrderNum);

		iUserId = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iUserId;
	        iMsglen = ((struct INT_COMMON_RESP_HDR *) sRecvBuf )->iMsgLength;
		logDebug2("call find_user_adapter for User Id :%llu:",iUserId);
              	iDWSRelayID = find_user_adapter(iUserId);
                logDebug2("iDWSRelayID :%d:",iDWSRelayID);
                if( iDWSRelayID != FIND_USER_RELAY_ERROR)
                {
                	logDebug2("*********** write Msg Q iDWSTrdRtrToDWSAdap **************");
                        iRetVal = WriteMsgQ(respQ,sRecvBuf,iMsglen,iDWSRelayID);
                        if(iRetVal == ERROR)
                        {
                                perror("Error In WriteQ ");
                        	exit(ERROR);
                    	}

         	}
                else
                {
                	logDebug2("AdminRelay Id Not Found :%d:",iDWSRelayID);
           	}
	}
	logTimestamp("EXIT [ProcessOrder]");
}

