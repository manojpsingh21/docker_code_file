#include "IPCS.h"
#include "DrvNseStruct.h"


BOOL  TwiddleNseBroad(CHAR * pMem)
{
	INT16   TranscodeLocal,i;
	struct NNF_HEADER 		*pForRecTransCode;
	LONG32 count;
	BOOL  iReturn;
	struct TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] =
	{ 
		TC_GENERAL_MSG_BCAST,                  dTC_GENERAL_MSG_BCAST,			/*6501_done*/
	//	TC_MBP_BCAST,                          dTC_MBP_BCAST,				/*7208*/
		TC_SYSTEM_INFORMATION_BCAST,           dTC_SYSTEM_INFORMATION_BCAST,		/*7206_done*/
		TC_STOCK_STATUS_CHANGE_BCAST,		dTC_STOCK_STATUS_CHANGE_BCAST,		/*7320_done*/
		TC_STOCK_STATUS_CHANGE_PREOPEN_BCAST,  dTC_STOCK_STATUS_CHANGE_BCAST,		/*7322_done*/
		TC_BROKER_TURNOVER_EXCEEDED_BCAST,     dTC_BROKER_TURNOVER_EXCEEDED_BCAST,	/*9010_done*/	
		TC_BROKER_TURNOVER_REACTIVATED_BCAST,  dTC_BROKER_TURNOVER_EXCEEDED_BCAST,	/*9011_done*/
		TC_MARKET_OPEN_MSG_BCAST,              dTC_MARKET_STATUS_CHANGE_BCAST , 	/*6511_done*/
		TC_MARKET_CLOSE_MSG_BCAST,             dTC_MARKET_STATUS_CHANGE_BCAST ,		/*6521_done*/
		TC_MARKET_PREOPEN_MSG_BCAST,           dTC_MARKET_STATUS_CHANGE_BCAST ,		/*6531_done*/	
		TC_MARKET_PREOPEN_END_MSG_BCAST,       dTC_MARKET_STATUS_CHANGE_BCAST ,		/*6571_done*/
		TC_MARKET_POSTCLOSE_MSG_BCAST,         dTC_MARKET_STATUS_CHANGE_BCAST ,		/*6522_done*/
		TC_POST_CLOSING_START_BCAST,		dTC_MARKET_STATUS_CHANGE_BCAST ,	/*6583_done*/	
		TC_POST_CLOSING_END_BCAST,		dTC_MARKET_STATUS_CHANGE_BCAST ,	/*6584_done*/	
		TC_SECURITY_OPEN_MSG_BCAST,            dTC_SECURITY_OPEN_MSG_BCAST,		/*6013_done*/
		TC_PARTICIPANT_INFO_RESP,              dTC_PARTICIPANT_INFO_RESP ,		/*7306_done*/	
//		TC_MKT_STATS_RPT_BCAST,                dTC_MKT_STATS_RPT_BCAST,			/*1833_done*/
		TC_INSTRUMENT_UPDATE_BCAST,              dTC_INSTRUMENT_UPDATE_BCAST,		/*7324_done*/
//		TC_BCAST_SPREAD_MBP,			dBCAST_SPREAD_MBP,		
//		TC_TICKER_INDEX_BCAST,			dTC_TICKER_INDEX_BCAST,			/*7202_done*/
		TC_STOCK_DETAILS_CHANGE_BCAST,	     	dTC_STOCK_DETAILS_CHANGE_BCAST,		/*7305_done*/
		TC_BCAST_TRADE_EXECUTION_RANGE,		dTC_TRADE_EXECUTION_RANGE,

	};
	pForRecTransCode  = (struct NNF_HEADER *) pMem;
	TWIDDLE( pForRecTransCode->iMsgCode );  
	TranscodeLocal = pForRecTransCode->iMsgCode;
	logDebug2("The Transcode recieved is %d", TranscodeLocal);	

	for (count=0;count<(MAX_NO_OF_TRANSCODE_TWIDDLE);count++)
	{
		if (TransFunPair[count].Transcode == TranscodeLocal)
		{ 
			iReturn = (*(TransFunPair[count].pToFun))(pMem);
			return TRUE;
		}
	}

	return(NOT_TWIDDLE);
}



/************************** NNF Version 9.4.3 14-08-2002*************************/
BOOL dBCAST_SPREAD_MBP(char *NNFData )
{
	int iRecords;
	struct 	NNF_SPRD_MBP 	*pMbpBcast = (struct NNF_SPRD_MBP *) NNFData;
	TWIDDLE ( pMbpBcast->pHeader.iMsgLength);
	TWIDDLE ( pMbpBcast->pHeader.iErrorCode);
	TWIDDLE ( pMbpBcast->pHeader.iLogTimeStamp);
	TWIDDLE ( pMbpBcast->iToken1);
	TWIDDLE ( pMbpBcast->iToken2);
	TWIDDLE ( pMbpBcast->iMbpBuy);
	TWIDDLE ( pMbpBcast->iMbpSell);
	TWIDDLE ( pMbpBcast->iLastActTime);
	TWIDDLE ( pMbpBcast->iTradedVol);
	TWIDDLE ( pMbpBcast->fTotTradeValue);
	/***
	  for(iRecords=0;iRecords<NO_OF_SPD_RECS;iRecords++)
	  {
	  TWIDDLE ( pMbpBcast->sSpreadMbpBuy[iRecords].BuyNoOfOrders);
	  TWIDDLE ( pMbpBcast->sSpreadMbpBuy[iRecords].BuyQty);
	  TWIDDLE ( pMbpBcast->sSpreadMbpBuy[iRecords].BuyPrice);
	  TWIDDLE ( pMbpBcast->sSpreadMbpSell[iRecords].SellNoOfOrders);
	  TWIDDLE ( pMbpBcast->sSpreadMbpSell[iRecords].SellQty);
	  TWIDDLE ( pMbpBcast->sSpreadMbpSell[iRecords].SellPrice);
	  }
	 ***/
	//	TWIDDLE ( pMbpBcast->sSpreadTotalOrderVol.TotalBuyVol);
	//	TWIDDLE ( pMbpBcast->sSpreadTotalOrderVol.TotalSellVol);
	TWIDDLE ( pMbpBcast->iOpenPriceDiff);
	TWIDDLE ( pMbpBcast->iDayHighPriceDiff);
	TWIDDLE ( pMbpBcast->iDayLowPriceDiff);
	TWIDDLE ( pMbpBcast->iLastTrdPriceDiff);
	TWIDDLE ( pMbpBcast->iLastTrdTime);

	logDebug2("iToken1 :%d:",pMbpBcast->iToken1);
	logDebug2("iToken2 :%d:",pMbpBcast->iToken2);
	logDebug2("iLastTrdPriceDiff :%d:",pMbpBcast->iLastTrdPriceDiff);

	return TRUE;
}

BOOL  dTC_MBP_BCAST(char *NNFData )
{
	logTimestamp("ENTRY[TC_MBP_BCAST]");

	LONG32 nRecord,nTotalRecord;

	NNF_MBP_BCAST  *pMbpBcast = ( NNF_MBP_BCAST *) NNFData;
	logDebug2("sizeof( struct NNF_MBP_BCAST :%d:",sizeof(struct NNF_MBP_BCAST));
			logDebug2("7208 Market_By_price");

			TWIDDLE ( pMbpBcast->sHeader.iMsgLength      );
			logDebug2("pMbpBcast->pHeader.iMsgLength :%d:",pMbpBcast->sHeader.iMsgLength);
			TWIDDLE ( pMbpBcast->sHeader.iErrorCode);
			TWIDDLE ( pMbpBcast->sHeader.iLogTimeStamp       );
			TWIDDLE ( pMbpBcast->iNoOfRecords               );


			for(nTotalRecord=0;nTotalRecord<pMbpBcast->iNoOfRecords;nTotalRecord++)
			{
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iToken            );
			logDebug2(" pMbpBcast->MBPInfo[nTotalRecord].iToken :%d:",pMbpBcast->MBPInfo[nTotalRecord].iToken);
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iBookType         );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iTradingStatus    );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iVolTradedToday   );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iLastTradedPrice  );
			logDebug2(" pMbpBcast->MBPInfo[nTotalRecord].iLastTradedPrice :%d:",pMbpBcast->MBPInfo[nTotalRecord].iLastTradedPrice);
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iNetPriceChange   );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iLastTradeQty     );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iLastTradeTime    );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iAverageTradePrice);
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iAuctionNumber    );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iAuctionStatus    );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iInitiatorType    );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iInitiatorPrice   );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iInitiatorQty     );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iAuctionPrice     );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iAuctionQty       );

			for (nRecord = 0;nRecord<MBP_NO_OF_RECS;nRecord++)
			{
				TWIDDLE (pMbpBcast->MBPInfo[nTotalRecord].MBPRecords[nRecord].iQty     );
				TWIDDLE (pMbpBcast->MBPInfo[nTotalRecord].MBPRecords[nRecord].iPrice   );
				TWIDDLE (pMbpBcast->MBPInfo[nTotalRecord].MBPRecords[nRecord].iNoOfOrders);
				TWIDDLE (pMbpBcast->MBPInfo[nTotalRecord].MBPRecords[nRecord].iBbBuySellFlg);
			}

			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iBbTotalBuyFlg    );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iBbTotalSellFlg   );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].fTotalBuyQty      );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].fTotalSellQty     );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iClosePrice       );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iOpenPrice        );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iHighPrice        );
			TWIDDLE ( pMbpBcast->MBPInfo[nTotalRecord].iLowPrice         );
			}
	logTimestamp("EXIT [TC_MBP_BCAST]");
	return TRUE;
}


BOOL dTC_STOCK_STATUS_CHANGE_BCAST(CHAR *NNFData )
{
	logTimestamp("ENTRY [dTC_STOCK_STATUS_CHANGE_BCAST]");
	LONG32		NoOfRecords,WhichMarket;
	NNF_SECURITY_STATUS_UPDATE_BCAST  *pSecStatusUpdateBcast = (  NNF_SECURITY_STATUS_UPDATE_BCAST *) NNFData;
	TWIDDLE ( pSecStatusUpdateBcast->sHeader.iMsgLength     );
	TWIDDLE ( pSecStatusUpdateBcast->sHeader.iLogTimeStamp  );
	TWIDDLE ( pSecStatusUpdateBcast->NoOfRecords           );
	logDebug2("THIS IS STOCK STATUS CHANGE BCAST 7320");
	for (NoOfRecords = 0;NoOfRecords<pSecStatusUpdateBcast->NoOfRecords;NoOfRecords++)
	{
		TWIDDLE ( pSecStatusUpdateBcast->SecTokenAndEligibility[NoOfRecords].iToken);
		for(WhichMarket = 0;WhichMarket <MARKET_TYPES;WhichMarket++)
		{

			TWIDDLE ( pSecStatusUpdateBcast->SecTokenAndEligibility[NoOfRecords].SecEligibilityPerMkt[WhichMarket].Status);

		}
	}
	logTimestamp("EXIT [dTC_STOCK_STATUS_CHANGE_BCAST]");
	return TRUE;
}

BOOL dTC_BROKER_TURNOVER_EXCEEDED_BCAST(CHAR *NNFData )
{
	logTimestamp("ENTRY [dTC_BROKER_TURNOVER_EXCEEDED_BCAST]");	
	struct  NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST  *pTlimitExcdBcast = (struct  NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST *) NNFData;

	TWIDDLE ( pTlimitExcdBcast->sHeader.iMsgLength     );
	TWIDDLE ( pTlimitExcdBcast->sHeader.iLogTimeStamp  );
	TWIDDLE ( pTlimitExcdBcast->WarningType           );
	TWIDDLE ( pTlimitExcdBcast->TradeNum              );
	TWIDDLE ( pTlimitExcdBcast->TradePrice            );
	TWIDDLE ( pTlimitExcdBcast->TradeVol              );
	logDebug2("THIS IS BROKER ACTIVATION DEACTIVATION BCAST");
	logTimestamp("EXIT [dTC_BROKER_TURNOVER_EXCEEDED_BCAST]");
	return TRUE;
}

BOOL dTC_MARKET_STATUS_CHANGE_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [tTC_MARKET_OPEN_MSG_BCAST]");
	NNF_MARKET_STATUS_CHANGE_BCAST  *pMktStatusChangeBcast = (  NNF_MARKET_STATUS_CHANGE_BCAST *) NNFData;

	TWIDDLE ( pMktStatusChangeBcast->sBcastHeader.iMsgLength     );
	TWIDDLE ( pMktStatusChangeBcast->sBcastHeader.iLogTimeStamp  );
	TWIDDLE ( pMktStatusChangeBcast->iMarketType            );
	TWIDDLE ( pMktStatusChangeBcast->iToken                 );
	TWIDDLE ( pMktStatusChangeBcast->iBcastMsgLength        );
	TWIDDLE ( pMktStatusChangeBcast->SecInfo.iExpiryDate    );
	TWIDDLE ( pMktStatusChangeBcast->SecInfo.iStrikePrice   );
	TWIDDLE ( pMktStatusChangeBcast->SecInfo.iCALevel       );

	logDebug2("Checking Bcast for mktWatch iMsgCode:%d: iMarketType:%d:",pMktStatusChangeBcast->sBcastHeader.iMsgCode,pMktStatusChangeBcast->iMarketType);
	logTimestamp ("EXIT [tTC_MARKET_OPEN_MSG_BCAST]");

	return TRUE;


}

BOOL dTC_SECURITY_OPEN_MSG_BCAST(CHAR * NNFData )
{
	logTimestamp("ENTRY [dTC_SECURITY_OPEN_MSG_BCAST]");
	NNF_SEC_OPEN_BCAST  *pSecOpenBcast = (  NNF_SEC_OPEN_BCAST *) NNFData;

	TWIDDLE (pSecOpenBcast->sHeader.iMsgCode);
	TWIDDLE ( pSecOpenBcast->sHeader.iMsgLength     );
	TWIDDLE ( pSecOpenBcast->sHeader.iLogTimeStamp  );
	TWIDDLE ( pSecOpenBcast->iToken                 );
	TWIDDLE ( pSecOpenBcast->iOpeningPrice          );
	logDebug2("THIS IS OPEN PRICE  BCAST 6013");
	logTimestamp(" EXIT [dTC_SECURITY_OPEN_MSG_BCAST]");
	return TRUE;
}


BOOL dTC_PARTICIPANT_INFO_RESP(CHAR *NNFData )
{
	logTimestamp("ENTRY [dTC_PARTICIPANT_INFO_RESP]");

	NNF_PARTICIPANT_INFO_RESP *pParticipantInfoResp = (NNF_PARTICIPANT_INFO_RESP *) NNFData;

	TWIDDLE( pParticipantInfoResp->sHeader.iMsgLength                );
	TWIDDLE( pParticipantInfoResp->sHeader.iLogTimeStamp             );
	TWIDDLE( pParticipantInfoResp->sHeader.iErrorCode                );
	TWIDDLE( pParticipantInfoResp->LastUpdateTime           );
	logDebug2("THIS IS PARTICIPANT INFORAMATION BCAST ");
	logTimestamp ("EXIT [dTC_PARTICIPANT_INFO_RESP]");
	return TRUE;
}

BOOL dTC_MKT_STATS_RPT_BCAST ( CHAR * NNFData )
{

	INT16     nRecordNumber = 0;
	NNF_MKT_STATS_RPT_DATA_BCAST    *pMktStatsRptData;
	pMktStatsRptData = (NNF_MKT_STATS_RPT_DATA_BCAST *) NNFData;
	logDebug2(" 1833 BHAV COPY DATA RECEIVED ");

	TWIDDLE (pMktStatsRptData->sHeader.iErrorCode);
	TWIDDLE (pMktStatsRptData->sHeader.iLogTimeStamp);
	TWIDDLE (pMktStatsRptData->sHeader.iMsgLength);
	TWIDDLE (pMktStatsRptData->iNumberOfRecords);

	if (pMktStatsRptData->iMsgType == FO_FINAL_BHAVCOPY_RPT)/*M*/
	{

		for(nRecordNumber = 0;nRecordNumber < pMktStatsRptData->iNumberOfRecords; nRecordNumber++)
		{
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iMktType);
			TWIDDLE ((pMktStatsRptData->MktStatsData[nRecordNumber].SecInfo).iExpiryDate);
			TWIDDLE ((pMktStatsRptData->MktStatsData[nRecordNumber].SecInfo).iStrikePrice);
			TWIDDLE ((pMktStatsRptData->MktStatsData[nRecordNumber].SecInfo).iCALevel);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iOpenPrice);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iHighPrice);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iLowPrice);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iClosingPrice);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iTotalQtyTraded);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].fTotalValueTraded);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iPreviousClosePrice);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iOpenIntersest);
			TWIDDLE (pMktStatsRptData->MktStatsData[nRecordNumber].iChgOpenInterest);
			logDebug2(" pMktStatsRptData->MktStatsData[nRecordNumber].ClosingPrice [%f]",pMktStatsRptData->MktStatsData[nRecordNumber].iClosingPrice);
			logDebug2("pMktStatsRptData->MktStatsData[nRecordNumber].PreviousClosePrice [%f]",pMktStatsRptData->MktStatsData[nRecordNumber].iPreviousClosePrice);


		}
	}

	return(TRUE);
}

BOOL tTC_MKT_STATS_RPT_BCAST_HEADER(CHAR *NNFData)
{
	NNF_MKT_STATS_RPT_HEADER_BCAST  *pMktStatsRptHdr;
	pMktStatsRptHdr = (NNF_MKT_STATS_RPT_HEADER_BCAST *) NNFData;
	logDebug2("BHAV COPY HEADER RECEIVED");

	TWIDDLE (pMktStatsRptHdr->sHeader.iLogTimeStamp);
	TWIDDLE (pMktStatsRptHdr->sHeader.iMsgLength);
	TWIDDLE (pMktStatsRptHdr->RptDate);
	TWIDDLE (pMktStatsRptHdr->UserType);
	TWIDDLE (pMktStatsRptHdr->TraderNumber);
	return TRUE;
}


BOOL tTC_MKT_STATS_RPT_BCAST_TRAILER(CHAR *NNFData)
{

	NNF_MKT_STATS_RPT_TRLR_BCAST    *pMktStatsRptTrlr;
	pMktStatsRptTrlr = (NNF_MKT_STATS_RPT_TRLR_BCAST *) NNFData;
	logDebug2("BHAV COPY TAILA");
	TWIDDLE (pMktStatsRptTrlr->sHeader.iLogTimeStamp);
	TWIDDLE (pMktStatsRptTrlr->sHeader.iMsgLength);
	TWIDDLE (pMktStatsRptTrlr->nNumberOfRecords);
	return TRUE;
}

BOOL    dTC_INSTRUMENT_UPDATE_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_INSTRUMENT_UPDATE_BCAST]");
	NNF_INSTRUMENT_UPDATE_INFO_BCAST    *pInstUpdateInfo;
	pInstUpdateInfo = (NNF_INSTRUMENT_UPDATE_INFO_BCAST *) NNFData;
	TWIDDLE ( pInstUpdateInfo->sHeader.iErrorCode    );
	TWIDDLE ( pInstUpdateInfo->sHeader.iLogTimeStamp );
	TWIDDLE ( pInstUpdateInfo->sHeader.iMsgLength    );
	TWIDDLE ( pInstUpdateInfo->InstrumentId);
	TWIDDLE ( pInstUpdateInfo->InstUpdateTime);
	logDebug2("THIS IS INSTRUMENT UPDATE BCAST ");
	logTimestamp("EXIT [dTC_INSTRUMENT_UPDATE_BCAST]");
	return TRUE;
}

BOOL dTC_GENERAL_MSG_BCAST (CHAR * NNFData )
{
	logTimestamp("ENTRY [dTC_GENERAL_MSG_BCAST]");
	NNF_GEN_MESSAGE_BCAST  *pGenMsgBcast = (  NNF_GEN_MESSAGE_BCAST *) NNFData;
	TWIDDLE ( pGenMsgBcast->sHeader.iLogTimeStamp  );
	TWIDDLE ( pGenMsgBcast->sHeader.iMsgLength         );
	TWIDDLE ( pGenMsgBcast->iBranchNumber              );
	TWIDDLE ( pGenMsgBcast->iBcastMsgLength            );
	logDebug2("THIS IS SYSTEM GENERAL MESSAGE BCAST");
	logTimestamp ("EXIT [dTC_GENERAL_MSG_BCAST]");
	return (TRUE);
}

BOOL dTC_SYSTEM_INFORMATION_BCAST(CHAR *NNFData )
{
	logTimestamp ("ENTRY [dTC_SYSTEM_INFORMATION_BCAST]");
	NNF_SYSTEM_INFO_BCAST  *pSysInfoBcast = (NNF_SYSTEM_INFO_BCAST *) NNFData;
	TWIDDLE ( pSysInfoBcast->sHeader.iMsgLength            );
	TWIDDLE ( pSysInfoBcast->sHeader.iLogTimeStamp     );
	TWIDDLE ( pSysInfoBcast->MarketStatus.iNormal      );
	TWIDDLE ( pSysInfoBcast->sExStatus.iNormal         );
	TWIDDLE ( pSysInfoBcast->sPlStatus.iNormal         );
	TWIDDLE ( pSysInfoBcast->MarketStatus.iOddlot      );
	TWIDDLE ( pSysInfoBcast->MarketStatus.iSpot        );
	TWIDDLE ( pSysInfoBcast->MarketStatus.iAuction     );
	TWIDDLE ( pSysInfoBcast->sExStatus.iOddlot         );
	TWIDDLE ( pSysInfoBcast->sExStatus.iSpot           );
	TWIDDLE ( pSysInfoBcast->sExStatus.iAuction        );
	TWIDDLE ( pSysInfoBcast->sPlStatus.iOddlot         );
	TWIDDLE ( pSysInfoBcast->sPlStatus.iSpot           );
	TWIDDLE ( pSysInfoBcast->sPlStatus.iAuction        );
	TWIDDLE ( pSysInfoBcast->iMktIndex                 );
	TWIDDLE ( pSysInfoBcast->iDefaultSettNormal        );
	TWIDDLE ( pSysInfoBcast->iDefaultSettSpot          );
	TWIDDLE ( pSysInfoBcast->iDefaultSettAuction       );
	TWIDDLE ( pSysInfoBcast->iCompetitorPeriod         );
	TWIDDLE ( pSysInfoBcast->iSolicitorPeriod          );
	TWIDDLE ( pSysInfoBcast->iWarnigPercent            );
	TWIDDLE ( pSysInfoBcast->iVolFreezePercent         );
	TWIDDLE ( pSysInfoBcast->iBoardLotQty              );
	TWIDDLE ( pSysInfoBcast->iTickSize                 );
	TWIDDLE ( pSysInfoBcast->iMaxGtcDays               );
	TWIDDLE ( pSysInfoBcast->iDiscQty                  );
	TWIDDLE ( pSysInfoBcast->iRiskFreeInterestRate     );
	logDebug2("THIS IS SYSTEM INFORMATION BCAST");
	logTimestamp("EXIT [dTC_SYSTEM_INFORMATION_BCAST]");
	return TRUE;
}




BOOL dTC_TICKER_INDEX_BCAST(char *NNFData)
{
	logTimestamp(" ENTRY [dTC_TICKER_INDEX_BCAST]");

	int     iRecordNumber = 0;
	struct NNF_TICKER_TRADE_BCAST         *pTickerData;
	pTickerData = (struct NNF_TICKER_TRADE_BCAST *) NNFData;

	TWIDDLE (pTickerData->sHeader.iErrorCode);
	TWIDDLE (pTickerData->sHeader.iLogTimeStamp);
	TWIDDLE (pTickerData->sHeader.iMsgLength);
	TWIDDLE (pTickerData->iNoOfRecords);

	logDebug2("pTickerData->iNoOfRecords :%d:",pTickerData->iNoOfRecords);
	for(iRecordNumber = 0;iRecordNumber < pTickerData->iNoOfRecords; iRecordNumber++)
	{
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iToken);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iMarketType);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iTradeVolume);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iOpenInterest);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iDayHiOpenInt);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iDayLowOpenInt);
		logDebug2("iToken :%d:",pTickerData->TickerIndexInfo[iRecordNumber].iToken);
		logDebug2("iTradePrice :%d:",pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice);
		logDebug2("iDayHiOpenInte :%d:",pTickerData->TickerIndexInfo[iRecordNumber].iDayHiOpenInt);
		logDebug2("iDayLowOpenInt :%d:",pTickerData->TickerIndexInfo[iRecordNumber].iDayLowOpenInt);
		logDebug2("----------Reading Next Record--------------------------------------------");
	}

	logTimestamp("EXIT [dTC_TICKER_INDEX_BCAST]");
	return TRUE;
}


BOOL dTC_STOCK_DETAILS_CHANGE_BCAST (char *NNFData)
{

	logTimestamp("ENTRY [dTC_STOCK_DETAILS_CHANGE_BCAST]");
	logDebug2(" Stock Details Changed Bcast 7305");
	struct NNF_SECURITY_UPDATE_BCAST *pSecData;
	pSecData = (struct NNF_SECURITY_UPDATE_BCAST *)NNFData;
	int i , Msgcode;
	DOUBLE64 	templowpricernge;
	DOUBLE64	temphighpricernge;
	DOUBLE64	tempfreezePecentage;


	TWIDDLE (pSecData->sHeader.iErrorCode);
	TWIDDLE (pSecData->sHeader.iMsgLength);
	TWIDDLE (pSecData->iToken);
	TWIDDLE (pSecData->SecInfo.iStrikePrice);
	TWIDDLE (pSecData->iFreezePercent);
	TWIDDLE (pSecData->iLowPriceRange);
	TWIDDLE (pSecData->iHighPriceRange);


	templowpricernge   = ((DOUBLE64)pSecData->iLowPriceRange)/DRV_CONST_PRICE_FACTOR;
	temphighpricernge  = ((DOUBLE64)pSecData->iHighPriceRange)/DRV_CONST_PRICE_FACTOR;
	tempfreezePecentage = ((DOUBLE64)pSecData->iFreezePercent)/DRV_CONST_PRICE_FACTOR;
	Msgcode = pSecData->sHeader.iMsgCode;
	logDebug2("  MSgcode [%d] pSecData->sHeader.iMsgCode [%d]",Msgcode ,pSecData->sHeader.iMsgCode);
	logDebug2("pSecData->iToken:%d:",pSecData->iToken);
	logDebug2("iToken:%d: LowPriceRange:%.2f: HighPriceRange :%.2f: FreezePecentage :%.2f",pSecData->iToken,templowpricernge,temphighpricernge,tempfreezePecentage);
	logTimestamp("EXIT [dTC_STOCK_DETAILS_CHANGE_BCAST]");
	return TRUE;

}
/***change for Trade Execution Range Update in DB ****/

BOOL dTC_TRADE_EXECUTION_RANGE (char *NNFData)
{
	logTimestamp("ENTRY [TWIDDLE TRADE_EXECUTION_RANGE]");
	logDebug2("TC_BCAST_TRADE_EXECUTION_RANGE     7220");	
	struct NNF_MS_BCAST_TRADE_EXECUTION_RANGE *TrRange;
	TrRange = (struct NNF_MS_BCAST_TRADE_EXECUTION_RANGE *)NNFData;
	LONG32 iNoRec=0;
        int i;
	
	TWIDDLE(TrRange->sTradeRange.iMsgCount);
	logDebug2("TrRange.sTradeRange.iMsgCount:%d:",TrRange->sTradeRange.iMsgCount);
	iNoRec = TrRange->sTradeRange.iMsgCount;
	
	for(i=0;i<=iNoRec;i++)
        {
		TWIDDLE(TrRange->sTradeRange.sTrExcuRange[i].iTokenNumber);
		TWIDDLE(TrRange->sTradeRange.sTrExcuRange[i].iHighExecBand);
		TWIDDLE(TrRange->sTradeRange.sTrExcuRange[i].iLowExecBand);
		logDebug2("TrRange->sTradeRange.sTrExcuRange[%d].iTokenNumber  :%d: ",i,TrRange->sTradeRange.sTrExcuRange[i].iTokenNumber);
                logDebug2("TrRange->sTradeRange.sTrExcuRange[%d].iHighExecBand :%d: ",i,TrRange->sTradeRange.sTrExcuRange[i].iHighExecBand);
                logDebug2("TrRange->sTradeRange.sTrExcuRange[%d].iLowExecBand  :%d: ",i,TrRange->sTradeRange.sTrExcuRange[i].iLowExecBand);
	}
        logTimestamp("EXIT : [TWIDDLE TRADE_EXECUTION_RANGE]");
	return TRUE;
}

