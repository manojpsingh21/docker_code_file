#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/msg.h>
#include <sys/errno.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/msg.h>

/*****#include "Sys_header.h"
#include "Comm_def.h"
#include "Common.h"
#include "DrvNseStruct.h"
#include "IntBcastStructs.h"
#include "Queue.h"
#include "NseTCodes.h"*****/
#include "IPCS.h"
//#include "EQNSEBcastStruct.h"
#include "DrvNseStruct.h"

//#define TWIDDLE(A)      Twiddle ((char *) &A, sizeof(A)) 
char    link_name[X25_LINK_NAME_LEN];

//EXEC SQL INCLUDE SQLCA.H;


/*extern BOOL  MapNseBroad(CHAR * pMem , LONG32 *pRet);*/
extern BOOL  MapNseBroad(CHAR * pMem , CHAR * pMem1,LONG32 *pRet,LONG32 *pRet1);
extern BOOL  TwiddleNseBroad(CHAR * pMem);
extern void Encode(CHAR *buff,LONG32 sizeofbuff,CHAR *outbuff, LONG32 *sizeofoutbuff);
extern void Sigdec2(CHAR *ip, USHORT  *ipL,CHAR *op,USHORT *opL,USHORT *errorcode);

BOOL OpenSocket(CHAR ServiceType,LONG32 *sockfd);
LONG32 sockfd1,sockfdBroad , sockfdMulti;
BOOL  OpenBcastSocket();
BOOL 	SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 portno);
BOOL OpenMultiSocket(LONG32 *sockfd, LONG32 port, CHAR *IPaddr,CHAR *sRecvIP);
void   ReceiveReplyPacketsBcast( LONG32 sockfd1);
void   Twiddle(void *,SHORT);
//int GetQStatus( int MsgQuery);
struct sockaddr_in serv_addr;

/****** Start - LZO Changes *****/
#pragma pack(1)
struct BcastMultiPkts
{
	char    cNetId[2];
	short   iNoPackets;
	char    cPacketData[508];
};
#pragma pack

#pragma pack(1)
struct  BcastRecord
{
	short   iCompLen;
	char    cCompData[512];
};
#pragma pack

/****** End - LZO Changes *****/


CHAR bcastaddress[CALLING_LENS];
CHAR bcastanalytic[CALLING_LENS];
CHAR bcastRupeeNext[CALLING_LENS];
CHAR bcastMDS [CALLING_LENS];

LONG32 portno;
LONG32 MbpBcastPort;
LONG32	iRRNxtDNport;
LONG32 	iITSDNport;
LONG32	iAnlyDNport;
FILE *fpReadFile,*fpWriteFile;
CHAR   dumpFileName[20];
CHAR   dumpFileName1[20];
CHAR readflg, WriteFlag;

LONG32  iMDSENport;
CHAR    sStartFlag[2] ;
CHAR    sBckOffFlag[2];	

CHAR sBackOffIP[CALLING_LENS];
CHAR sBackOffPort[CALLING_LENS];
LONG32  iBackOffPort = 0;


main(LONG32 argc,CHAR **argv)
{  
	/***
	  EXEC SQL BEGIN DECLARE SECTION;  
	  varchar lvar_uid[ORACLE_CONNECT_STR_LEN];
	  EXEC SQL END DECLARE SECTION;  
	 ****/
	struct sockaddr_in cli_addr;
	LONG32  val;
        CHAR    temp;
	CHAR  service;
	CHAR mcastaddress[CALLING_LENS];
	LONG32 mportno;
	char work_station_address   [WS_ADDRESS_LEN ];
	CHAR sBcastRecvIP[CALLING_LENS];
	LONG32 iBcastRecvPort, RecvVal;
	CHAR sRecvIP[CALLING_LENS];

	CHAR sMDSTempPort [10];
	memset(sMDSTempPort,'\0',10);
	CHAR sTempPort[10];
	setbuf(stdout,NULL);
	setbuf(stdin,NULL);




	if(getenv("ANALYTIC_SERVER_IP")==NULL)
	{
		logFatal("Error : Environment variables missing : ANALYTIC_SERVER_IP");
		exit(ERROR);
	}
	else
	{
		strcpy( bcastMDS ,getenv("ANALYTIC_SERVER_IP"));
		logDebug2("bcastMDS :%s:",bcastMDS);
	}
	if(getenv("SEND_FO_BCAST_TO_ANALYTIC_SERVER")==NULL)
	{
		logFatal("Error : Environment variables missing : SEND_FO_BCAST_TO_ANALYTIC_SERVER");
		exit(ERROR);
	}
	else
	{
		strcpy(sStartFlag,getenv("SEND_FO_BCAST_TO_ANALYTIC_SERVER"));
		logDebug2("sStartFlag :%s:",sStartFlag);
	}
	
	if(getenv("ANALY_NSE_FO_PORT")==NULL)
	{
		logFatal("Error : Environment variables missing : ANALY_NSE_FO_PORT");
		exit(ERROR);
	}
	else
	{	
		strcpy(sMDSTempPort,getenv("ANALY_NSE_FO_PORT"));
		iMDSENport = atoi(sMDSTempPort);
		logDebug2("sMDSTempPort[%s] iMDSENport [%d]",sMDSTempPort,iMDSENport);
	}
	if(getenv("BACKOFF_SERVER_IP")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_SERVER_IP");
		exit(ERROR);
	}
	else
	{
		strcpy ( sBackOffIP , getenv("BACKOFF_SERVER_IP"));
		logDebug2("sBackOffIP :%s:",sBackOffIP);
	}
	if(getenv("BACKOFF_NFO_PORT")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_NFO_PORT");
		exit(ERROR);
	}
	else
	{
		strcpy ( sBackOffPort, getenv("BACKOFF_NFO_PORT"));	
		logDebug2("sBackOffPort :%s:",sBackOffPort);
		iBackOffPort = atoi(sBackOffPort);
	}
	if(getenv("BACKOFF_BCAST_FLAG")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_BCAST_FLAG");
		exit(ERROR);
	}
	else
	{
		strcpy(sBckOffFlag,getenv("BACKOFF_BCAST_FLAG"));
		logDebug2("sBckOffFlag  :%s:",sBckOffFlag);
	}
	
	if ( argc != 8 )	// two argument added one for type of broadcast and second for receiving IP
	{
		logDebug2("Argument Mismstch ");
		logDebug2("USAGE : <DNBcastAdap>   <TAP IP> <TAP PORT> <L/D> <Y/N> <Service {M Multicast/U Broadcast}> <Rcv IP> <DNBcastAdap>");
		exit(0);
	}


	logDebug2("ALOKK here 1");
	memset(sBcastRecvIP,'\0',CALLING_LENS);		///some variables name changed for better understanding
        memset(sRecvIP,'\0',CALLING_LENS);
	
	strcpy(sBcastRecvIP,argv[1]);
	readflg= argv[3][0];
	WriteFlag= argv[4][0];
	iBcastRecvPort = atoi(argv[2]);
	service = argv[5][0];		//M for Milticast and U for Broadcast
        strcpy(sRecvIP,argv[6]);	//if broadcast receiving from diffrent IP [not primary ip]
	
	logDebug2("_____________________________P A R A M E T E R E S____________________________");

	logDebug2("McastRecvAddress      	is  : %d ",iBcastRecvPort );
	logDebug2("McastRecvPort        	is  : %s ",sBcastRecvIP );
	logDebug2("sBackOffIP           is  : %s ",sBackOffIP);
	logDebug2("iBackOffPort         is  : %d ",iBackOffPort);

	logDebug2("sStartFlag           is  : %s ",sStartFlag);
	logDebug2("sBckOffFlag          is  : %s ",sBckOffFlag);

	logDebug2("readflg              is  : %c ",readflg );
	logDebug2("WriteFlag            is  : %c ",WriteFlag );
	logDebug2("Service              is  : %c ",service );
        logDebug2("sRecvIP              is  : %s ",sRecvIP);
	logDebug2("_________________________________________________________________________________");

	strcpy ( dumpFileName , "DNBcastdumplive.dmp");
	strcpy ( dumpFileName1 , "DNBcastdumplive.dmp");
	if ( readflg =='D')
	{
		fpReadFile = fopen(dumpFileName,"rb+");
		if( fpReadFile == NULL)
		{
			logFatal("Unable to Open the  Read File ");
			exit(1);
		}
	}
	if ( WriteFlag =='Y')
	{
		fpWriteFile = fopen(dumpFileName1,"wb+");
		if( fpWriteFile == NULL)
		{
			logFatal("Unable to Open the  Write File ");
			exit(1);
		}
	}


	for ( ; ; )
	{

		/*-------------------------------------ADDED FOR BCAST THROUGH TAP -------------------------------------*/

		/*-------------------------------------------------------------------------------------------------------
		  TAP IP IS THE MULTICAST GROUP IP
		  TAP PORT IS THE MULTICAST RECV PORT
		  SOCKFD1 IS THE SOCKET FILE DISCRIPTOR
		  ---------------------------------------------------------------------------------------------------------*/
		switch(service)//Switch case added for type of broadcast .if service = M then its Multicast and if U then broadcast
		{
			case MULTICAST_TYPE :
				RecvVal=OpenMultiSocket(&sockfd1, iBcastRecvPort, sBcastRecvIP, sRecvIP);
				if (RecvVal==FALSE)
				{
					logDebug2("Error in fuction OpenSocket ....Exiting");
					exit(1);
				}
				logDebug2("sockfd1 = [%d]",sockfd1);
				break;
			case BROADCAST_TYPE :
			        cli_addr.sin_family     = AF_INET;
                                if(strcmp(sRecvIP,"0") != 0 )
                                {
                                        cli_addr.sin_addr.s_addr= sRecvIP;
                                }
                                else
                                {
                                        cli_addr.sin_addr.s_addr= INADDR_ANY;
                                }
                                //cli_addr.sin_addr.s_addr= INADDR_ANY;
                                cli_addr.sin_port       = htons(iBcastRecvPort);
                                if(OpenUDPSocket(&sockfd1))
                                {
                                        if (val = (bind(sockfd1,(struct sockaddr *)&cli_addr,sizeof(struct sockaddr))) <0)
                                        {
                                                logDebug2("Client : Error in Binding...is:%d",errno);
                                                memcpy(temp,strerror(errno),100);
                                                exit(1);
                                        }
                                }
                                break;	
		/*------------------------------------------TAP ADDITION ENDS ------------------------------------------*/
		}

		logDebug2("Connection to NSE Broadcast Circuit successful\n");

		ReceiveReplyPacketsBcast(sockfd1);
	}		
}

void ReceiveReplyPacketsBcast( LONG32 sockfd1 )
{
	CHAR        curr_time[200];
	CHAR		*recvgen;
	CHAR 		*lpPostBuffer;
	CHAR		actualMsg[NSE_MAX_PACKET_SIZE],Messagemap[NSE_MAX_PACKET_SIZE];
	CHAR		first_send_this[NSE_MAX_PACKET_SIZE];
	CHAR 		tempdata[MAX_PACKET_SIZE_COMPRESS];
	LONG32      qidnormal, Itsqid=0 ,  recv_bytes, write_status,flag=0,Len,complen,iMsgLen=0 , iMsgLen1= 0;
	CHAR        actualmsg1[NSE_MAX_PACKET_SIZE];	
	/*LONG32      qidnormal, recv_bytes, write_status,flag=0,Len,complen,iMsgLen;*/
	USHORT      iCompDataLgh;
	USHORT      iDcompDataLgh = NSE_MAX_PACKET_RECV_SIZE; 
	USHORT      iErrCode =0;
	DOUBLE64    szUncompressed,szCompressed,szPercentCompression;
	LONG64		PacketCounter;
	LONG32      clilen , sTcode = 0 ;
	LONG32	ret;
	clilen = sizeof(struct sockaddr);

	struct BCAST_HEADER  *bcastheader;
	struct NNF_HEADER                *nnfheader;
	COMPRESSION_BRDCST_DATA   *pCmpBcastData;

	/****** Start - LZO Addition ****/
	char *templpPostBuff;
	struct  BcastMultiPkts * pMultiBcast ;
	struct  BcastRecord *   pSingleBcast ;
	char    *pPacketCol;
	int     tempMsgLen=0,iForLoop=0;
	int PktCnt = 0;
	struct BcastRecord SendForDecompress;
	int LengthOfData;
	char sDecompData[NSE_MAX_PACKET_RECV_SIZE];

	/****** End  - LZO Addition ****/
	LONG32  ExchCompressed;
	LONG32  ExchUncompressed;
	LONG32  InternalMapped;
	LONG32  InternalCompressed;
	LONG32  PTranscode;

	LONG32  status = TRUE   ;
	CHAR    tempflag= FALSE ;
	LONG32  counter = 0     ;




	recvgen = (char *)malloc(sizeof(char)*NSE_MAX_PACKET_RECV_SIZE);



//	qidnormal = OpenMsgQ(DNBAdapToSpltr);
	qidnormal = OpenMsgQ(DNBcasttoMktStatus);
	if ( qidnormal < 0 )
	{
		logFatal("Error in  Opening  Queue ");
		exit(0);
	}
	else
	{
		logDebug2("Normal Queue opened and ready ");
	}
	/******

	  Itsqid = OpenMsgQ(BCASTToItsQ) ;
	  printf("\n\t Itsqid : %d", Itsqid ) ;
	  if ( Itsqid < 0 )
	  {
	  printf("\n Error in  Opening  Its Queue ");
	  exit(0);
	  }
	  else
	  {
	  printf("\nIts Normal Queue opened and ready \n");
	  }

	 **********/
	if((flag=OpenBcastSocket())==FALSE)
	{
		logFatal("Error creating UDP Broadcast socket");
		exit(0);
	}

	if(!OpenMulticastSocket())
	{
		logFatal("Error while creating NSE UDP Multicast Socket");
		free(tempdata);
		free(Messagemap);
		exit(0);
	}



	PacketCounter  = 1;
	szUncompressed = 0;
	szCompressed   = 0;

	while(TRUE)
	{       
		memset(&actualMsg,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(recvgen,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(&Messagemap,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(&first_send_this,SPACE,NSE_MAX_PACKET_RECV_SIZE);

		if (readflg == 'L')
		{
			logDebug2("############################### Calling Socket Receive through TAP ###############################");

			/** gettimeofday(&Start_time,NULL); **/ /** veera added on 01042009 to reduce system calls **/

			/*----------------------------------------------------------- TAP -----------------------------------------------------------*/

			logDebug2("Receving from socket >>>> [%d]",sockfd1);
			//usleep(5000);

			if ((recv_bytes = recvfrom(sockfd1,recvgen,NSE_MAX_PACKET_RECV_SIZE,0,(struct sockaddr *)&serv_addr,&clilen)) < 0 )
			{
				logDebug2("Unable to receive the data from sockfd1, id:%d",sockfd1);
				break;
			}

		}
		else
		{
			ret = fread(recvgen,NSE_MAX_PACKET_RECV_SIZE,1,fpReadFile);

			//                        usleep(50000);


			if ( ret == 0 )
			{
				fclose(fpReadFile) ;
				logDebug2("----FILE CLOSED REOPENING THE FILE " );
				fpReadFile = fopen(dumpFileName,"rb+");

				if (fpReadFile == NULL)
				{
					logFatal("Error In Opening The File ");
					exit(0);
				}
				continue ;
			}
		}

		if(!strcmp(sStartFlag,STR_YES))
		{
			//usleep(5000);
			logDebug2("Sending Broadcast To Analytical Server Ip :%s: Port :%d:",bcastMDS,iMDSENport);
			SendBroadcast(recvgen,NSE_MAX_PACKET_RECV_SIZE,bcastMDS,iMDSENport);
		}

		if(!strcmp(sBckOffFlag,STR_YES))
		{
			logDebug2("Sending Broadcast To BackOff Server Ip :%s: Port :%d:",sBackOffIP,iBackOffPort);
			SendBroadcast(recvgen,NSE_MAX_PACKET_RECV_SIZE,sBackOffIP,iBackOffPort);
		}
		if ( WriteFlag =='Y')
		{
			fwrite ( recvgen, NSE_MAX_PACKET_RECV_SIZE,1,fpWriteFile );
		}

		/*----------------------------------------------------------- TAP -----------------------------------------------------------*/


		lpPostBuffer  = recvgen;

		pMultiBcast = (struct BcastMultiPkts *)lpPostBuffer;

		logDebug2("-------------- NEW PACKET -----------------");

		TWIDDLE(pMultiBcast->iNoPackets);

		logDebug2("iNoPackets   = %d",pMultiBcast->iNoPackets);
		logDebug2("cNetId recvd = %s",pMultiBcast->cNetId);

		pPacketCol= (char *)(pMultiBcast->cPacketData);

		if ( pMultiBcast->iNoPackets > 1 )
			logDebug2("No of packets ae more than 1");


		PktCnt = pMultiBcast->iNoPackets;


		for (iForLoop=1; iForLoop <= PktCnt ; iForLoop++ )
		{
			pSingleBcast = (struct BcastRecord *)pPacketCol;
			logDebug2("------ SUB PACKET NO -------%d",iForLoop);
			TWIDDLE(pSingleBcast->iCompLen);
			logDebug2("pSingleBcast->iCompLen == %d", pSingleBcast->iCompLen );
			if (pSingleBcast->iCompLen > 0 )
			{

				char *lpCompData;
				unsigned short  iCompdataLgh;
				unsigned short  iDcompDataLgh;
				unsigned short  iErrCode =0;
				unsigned short  *pErrCode;
				logDebug2("COMPRESSED SUB PACKET");
				ExchCompressed = pSingleBcast->iCompLen; /*** DELETE THIS ***/
				memset(&SendForDecompress,' ', sizeof(struct BcastRecord));
				memcpy(&SendForDecompress,pSingleBcast->cCompData,pSingleBcast->iCompLen);
				lzo1z_decompress(&SendForDecompress,iCompdataLgh,sDecompData,&iDcompDataLgh,NULL);
				pPacketCol = pPacketCol + pSingleBcast->iCompLen + sizeof(short);
				templpPostBuff = sDecompData;
				templpPostBuff = templpPostBuff + 8;
			}
			else
			{
				logDebug2("UNCOMPRESSED SUB PACKET");
				memset(sDecompData,' ',NSE_MAX_PACKET_RECV_SIZE);
				memcpy(sDecompData,pSingleBcast->cCompData,NSE_PACKET_SIZE);
				templpPostBuff = sDecompData;
				templpPostBuff = templpPostBuff + 8;
				nnfheader = (struct NNF_HEADER *)templpPostBuff;
				TWIDDLE(nnfheader->iMsgLength) ;
				tempMsgLen = nnfheader->iMsgLength;
				ExchCompressed = nnfheader->iMsgLength; /*** DELETE THIS ***/
				TWIDDLE(nnfheader->iMsgLength);
				pPacketCol = pPacketCol + tempMsgLen + sizeof(short) + 8;
			}

			nnfheader = (struct NNF_HEADER *) templpPostBuff;

			TWIDDLE(nnfheader->iMsgCode);
			TWIDDLE(nnfheader->iMsgLength);

			LengthOfData = nnfheader->iMsgLength;
			ExchUncompressed = nnfheader->iMsgLength; /** DELETE THIS ***/
			PTranscode = nnfheader->iMsgCode;

			if ((LengthOfData > 2000) || (LengthOfData < 0))
			{
				logFatal("Wrong Data length len = %d",LengthOfData);
				continue;
			}


			logDebug2("Transcode 	recvd is = %d ", nnfheader->iMsgCode);
			logDebug2("iMsgLen 	recvd is = %d ", nnfheader->iMsgLength);
			sTcode = nnfheader->iMsgCode;
			iMsgLen = nnfheader->iMsgLength;
			TWIDDLE(nnfheader->iMsgCode);
			TWIDDLE(nnfheader->iMsgLength);

			memcpy(&actualMsg,templpPostBuff,NSE_MAX_PACKET_RECV_SIZE);



			flag=0;

			flag=TwiddleNseBroad(&actualMsg);
			if (flag==NOT_TWIDDLE)     
			{
				continue;
			} 

			memcpy(&first_send_this,&actualMsg,NSE_MAX_PACKET_RECV_SIZE);

			logDebug2("before sending to Q :%d:",qidnormal);

		/*	status = GetQStatus (qidnormal );
			if ( status == FALSE)
			{
				tempflag = TRUE;
				counter++;
				logDebug2("QUEUE IS FULL");
			}*/
			write_status = WriteMsgQ(qidnormal,&first_send_this,iMsgLen,1);
			if ( write_status == ERROR)
			{
				logFatal("Error in writing to Q");
				return;
			}
			
			flag=0;

			iMsgLen = 0;
			/*****
			  if ((flag=MapNseBroad(actualMsg,actualmsg1,&iMsgLen,&iMsgLen1))==TRUE)
			  {	
			  printf("\nIn true case");
			  continue;
			  }
			  else
			  {
			  printf("\nMAPPING FAILED");
			  continue;
			  }	
			 ***********/
		} 
	}	
	close(sockfdBroad);
	close(sockfdMulti);
}

BOOL  OpenBcastSocket()
{
	LONG32 optval=1;
	LONG32  val;
	if ( (sockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}
	val = setsockopt(sockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval));
	if ( val < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	return TRUE;
}

BOOL  SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 portno)
{
	struct     sockaddr_in cli_addr ;
	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(bcastaddress);
	cli_addr.sin_port           = htons(portno);


	if(sendto(sockfdBroad,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr))< 0)
	{
		perror("Server : Error in Sending");
		return FALSE;
	}

	logDebug2("BROADCAST Send to IP = %s and Port= %d MsgLength :%d:",bcastaddress, portno,MsgLen);

	return TRUE;
}

BOOL  SendMulticast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 mportno)
{
	struct     	sockaddr_in cli_addr ;
	CHAR		multicastIP[CALLING_LENS] ;
	LONG32     	sentbytes;

	strcpy (multicastIP,getenv("EQU_NSE_MCAST_IP"));

	logDebug2("Kedar::multicastIP :[%s]\n",multicastIP);

	logDebug2("Kedar::mportno:[%d]\n",mportno);

	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(multicastIP);
	/* cli_addr.sin_port           = htons(8104); */

	cli_addr.sin_port           = htons(mportno);

	sentbytes = sendto(sockfdMulti,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr));
	if ( sentbytes < 0 )
	{
		perror("Server : Error in Sending");
		return FALSE;
	}


	logDebug2("Kedar::Multicast:: SentBytes : %d",sentbytes);

	return TRUE;
}

/***********************************************************************************************
  Function Name      :    OpenBcastRecvSocket
Arguments          :
Return Values      :    BOOL
Dependencies       :
Functions Called By:    RecieveReplyPackets In the same File.
Comments           :    This Function Opens a Socket and sets the option for the Socket.
 ************************************************************************************************/
BOOL  OpenBcastRecvSocket(LONG32 * OrgSockId,LONG32 Recvport)
{

	LONG32 sockfd;
	struct  sockaddr_in servaddr,cliaddr;
	LONG32 flag=1,clen,connfd;
	fd_set  ActiveSocket ;

	if( (sockfd = socket( AF_INET, SOCK_DGRAM, 0 )) < 0 )
	{
		perror("Trying to open Socket Failed :\n");
		return FALSE;
	}

	if ( sockfd  > 0 )
	{
		memset(&servaddr,0,sizeof(servaddr));

		servaddr.sin_family = AF_INET;
		servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
		servaddr.sin_port=htons(Recvport);

		FD_CLR(sockfd,&ActiveSocket);
		FD_ZERO(&ActiveSocket );
		FD_SET(sockfd,&ActiveSocket );

		if(setsockopt(sockfd,SOL_SOCKET,SO_BROADCAST,(CHAR *)&flag,sizeof(flag))<0)
		{
			perror("Failed in setting Protocol\n");
			close(sockfd);
			return FALSE;
		}

		if(bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0)
		{
			perror("Failed to bind the port\n");
			close(sockfd);
			return FALSE;
		}

		*OrgSockId = sockfd;
		return TRUE;
	}

	return FALSE;
}
BOOL   OpenMulticastSocket()
{
	LONG32  val;
	struct sockaddr_in   ServerAddr;
	u_char ttl = 254;
	if ( (sockfdMulti = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("server : can't open udp socket");
		return FALSE;
	}
	val = setsockopt(sockfdMulti,IPPROTO_IP,IP_MULTICAST_TTL,(void *)&ttl,sizeof(ttl));
	if ( val < 0 )
	{
		perror(" Multicast Socket Error ");
		return FALSE;
	}
	return TRUE;
}

BOOL OpenSocket(CHAR ServiceType,LONG32 *sockfd)
{
	LONG32 sfd;
	LONG32 optval=1;
	LONG32 val=1;
	CHAR ttl=1;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket");
		exit(0);
	}

	*sockfd = sfd;
	if (val < 0)
		return FALSE;
	else
		return TRUE;
}


/*int GetQStatus( int MsgQuery)
{
	struct msqid_ds sStatQ;
	DOUBLE64        checkbytes = 0.0;

	if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
	{
		checkbytes      =       (sStatQ.msg_qbytes * 0.066);

		logDebug2("From MsgQueryQ TotalBytes            = %d, CurrentBytes=%d ", sStatQ.msg_qbytes,sStatQ.msg_cbytes);
		logDebug2("From MsgQueryQ Availablebytes        = %d", (sStatQ.msg_qbytes - sStatQ.msg_cbytes));
		logDebug2("From MsgQueryQ CheckPointBytes       = %lf", checkbytes );


		if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
		{
			logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
			return FALSE ;
		}
		else
		{
			logDebug2("Queue Check : Passed");
			return TRUE ;
		}
	}
}*/
BOOL OpenMultiSocket(LONG32 *sockfd, LONG32 port, char *IPaddr,CHAR *sRecvIP)
{
	/*--------------------------------------------------------------------------------------------------------------------
	  THIS IS THE CODE TO RECEIVE MULTICAST FROM THE EXCHANGE THROUGH
	  UDP UTILITY PROVIDED BY THE EXCHANGE AND PROVIDE BROADCAST OR
	  THE MULTICAST TO THE FRONT END
	  --------------------------------------------------------------------------------------------------------------------*/

	LONG32 sfd;
	LONG32 optval=1;
	LONG32 val=1;
	u_char ttl = 1;
	struct ip_mreq mreq;
	logDebug2("IPaddr = [%s]",IPaddr);
	logDebug2("port   = [%d]",port);
	logDebug2("RecvIP = [%s],",sRecvIP);
	u_int yes=1;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket");
		exit(0);
	}

	if (setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes)) < 0)
	{
		perror("Reusing ADDR failed");
		exit(1);
	}

	logDebug2("Socket Id is %d",sfd);

	serv_addr.sin_family     = AF_INET;
/***
 * 	Commenting this as it is not working
	if(strcmp(sRecvIP,"0") != 0 )	//if receiving IP is not specified then it take any ip [Primary IP]
        {
	         serv_addr.sin_addr.s_addr= inet_addr(sRecvIP);
        }
        else
        {
        	serv_addr.sin_addr.s_addr= INADDR_ANY;
        }
***/
	serv_addr.sin_addr.s_addr= htonl(INADDR_ANY);
	serv_addr.sin_port       = htons(port);

	if(bind(sfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
	{
		perror("Failed to bind the port\n");
		close(sockfd);
		return FALSE;
	}

	/*----------------------- PASSING MULTICAST GROUP IP -----------------------*/

	mreq.imr_multiaddr.s_addr=inet_addr(IPaddr);
	if(strcmp(sRecvIP,"0") != 0 )    //if receiving IP is not specified then it take any ip [Primary IP] @Nitish-8Jul2019
        {
		mreq.imr_interface.s_addr= inet_addr(sRecvIP);
	}
	else
	{
		mreq.imr_interface.s_addr=htonl(INADDR_ANY);
	}
	

	if (setsockopt(sfd,IPPROTO_IP,IP_ADD_MEMBERSHIP,&mreq,sizeof(mreq)) < 0)
	{
		perror("setsockopt");
		exit(1);
	}
	/*----------------------- SETTING MULTICAST TIME TO LIVE -----------------------*/

	if (( val = setsockopt(sfd,IPPROTO_IP,IP_MULTICAST_TTL,&ttl,sizeof(ttl) ) ) < 0 )
	{
		perror("OpenSocket: Error in setsockopt for Multicast socket");
	}

	*sockfd = sfd;
	logDebug2("$$$$$$$$ Socket Id is %d $$$$$$$$",*sockfd);

	if (val < 0)
		return FALSE;
	else
		return TRUE;
}



BOOL OpenUDPSocket(LONG32 *sockfd)
{
        LONG32 sfd;
        LONG32 optval=1;
        LONG32 val=1;
        CHAR ttl=1;

        if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
        {
                perror("OpenSocket:Error in opening the socket");
                exit(0);
        }

        if((val =setsockopt(sfd,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval)))< 0)
        perror("OpenSocket: Error in setsockopt for Bcast Socket ");

        *sockfd = sfd;
        if (val < 0)
                return FALSE;
        else
                return TRUE;
}

