#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

redisContext *c;
redisContext *c1;
redisReply *reply;
redisReply *reply1;
MYSQL   *DNMbp_con;
INT16   iSubInstance;

main(int argc,char **argv)
{
        setbuf(stdout,0);
        logTimestamp("ENTRY [Main]");
	c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	c1 = RDConnect(REDIS_TYPE_PRICE_BCAST);
        DNMbp_con=DB_Connect();
	iSubInstance = atoi(argv[1]);
        logInfo("iSubInstance :%d:",iSubInstance);
        ReceiveReplyPacketsBcast();
        return 0;
        logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
        logTimestamp("ENTRY [UPDATE LTP IN DB]");
        CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];
        BOOL flag;
        int count=0;
        int iCount ;
        CHAR sKeyValue[RADIS_KEY_LEN];
        DOUBLE64   fTempLtp=0.00,TempDayHiOpenInt,TempDayLowOpenInt;
        LONG32          iTempScripCode =0 ,iMsgCode;
        CHAR    NormlMkt [MKT_TYPE_LEN];
        CHAR    sExch [10];
        CHAR    cSegment;
        CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR    sUpdateQry[MAX_QUERY_SIZE];
        CHAR    supdate [MAX_QUERY_SIZE];


	while(TRUE)
        {

		sprintf(sCommand,"SUBSCRIBE OMSNSEFO-%d ",iSubInstance);
		logDebug2("sCommand -> %s",sCommand);
		//reply = redisCommand(c,sCommand);
		reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
		logDebug2("INCR counter: %lld", reply->integer);
		while(redisGetReply(c,(void**)&reply) == REDIS_OK)
		{
			logTimestamp("Recive Publish Key");
			memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
			memset(&supdate,'\0',MAX_QUERY_SIZE);
			memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
			if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3)
			{
				logDebug2("Error:  Malformed subscribe response!");
				//exit(-1);
				freeReplyObject(reply);
				continue;
			}

			logDebug2("Channel: %s", reply->element[1]->str);
			logDebug2("Received message: %s", reply->element[2]->str);
			sprintf(sKeyValue,"%s",reply->element[2]->str);
			freeReplyObject(reply);
			
			memset(sCommand1,'\0',COMMAND_LEN);
			sprintf(sCommand1,"TTL %s",sKeyValue);
			logDebug2("sCommand1 -> %s",sCommand1);
			reply = fRedisCommand(c1,sCommand1,REDIS_TYPE_PRICE_BCAST);
			logDebug2("INCR counter: %lld", reply->integer);
			
			if(reply->integer != 0 && reply->integer != -2)
			{
				memset(sCommand,'\0',COMMAND_LEN);
				sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT DRVOILOW DRVOIHIGH ",sKeyValue);
				logTimestamp("sCommand -> %s",sCommand);
				reply1 = fRedisCommand(c1,sCommand,REDIS_TYPE_PRICE_BCAST);
				iCount = reply1->elements;
				logDebug2("ELEMENT COUNT =%d ",iCount);
				if(iCount == 0){
					freeReplyObject(reply1);
                                	continue;
				}
				logDebug2("Received message LTP : %s", reply1->element[0]->str);
				logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
				logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
				logDebug2("Received message EXCH: %s", reply1->element[3]->str);
				logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
				logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
				if(reply1->element[0]->str != NULL)
				{
					fTempLtp = atof(reply1->element[0]->str);
					iTempScripCode = atoi(reply1->element[1]->str);
					iMsgCode = atoi(reply1->element[4]->str);
					sprintf(NormlMkt,"%s",reply1->element[2]->str);
			
					if(iMsgCode == TC_TICKER_INDEX_BCAST )
					{
						logDebug2("Received message OILOW: %s", reply1->element[6]->str);
						logDebug2("Received message OIHIGH: %s", reply1->element[7]->str);
						TempDayHiOpenInt = atof(reply1->element[7]->str);
						TempDayLowOpenInt = atof(reply1->element[6]->str);
						
						sprintf(sUpdateQry,"UPDATE DRV_L1_WATCH SET DL1_LTP =%lf ,DL1_LUT = NOW(),DL1_OPEN_INTEREST = %lf ,DL1_OI_HIGH = %lf ,DL1_OI_LOW = %lf WHERE DL1_EXCHANGE = \"%s\" AND DL1_SEGMENT = \'%c\' AND DL1_SCRIP_CODE = \"%d\"  AND DL1_MARKET_TYPE = \"%s\" ; ",fTempLtp,TempDayHiOpenInt,TempDayHiOpenInt,TempDayLowOpenInt,NSE_EXCH,SEGMENT_FNO,iTempScripCode,NormlMkt);	
						
						logTimestamp("sUpdateQry :%s:",sUpdateQry);
						
						if(mysql_query(DNMbp_con,sUpdateQry) != SUCCESS)
						{
							logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table DRV_L1_WATCH");
							sql_Error(DNMbp_con);
						}
						else
						{
							logInfo("Update Query fired successfully ");
						}

						
						if(mysql_affected_rows(DNMbp_con) == 0)
						{			
							sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
							(DL1_EXCHANGE ,\
							DL1_SEGMENT,\
							DL1_SCRIP_CODE,\
							DL1_EXCH_SCRIP_CODE,\
							DL1_MARKET_TYPE,\
							DL1_ENTRY_TIME,\
							DL1_LTP,\
							DL1_OPEN_INTEREST,\
							DL1_OI_HIGH ,\
							DL1_OI_LOW)\
							VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf,%lf,%lf,%lf)\
							on duplicate key \
                                                	UPDATE \
                                                	DL1_EXCHANGE = VALUES(DL1_EXCHANGE),\
                                                	DL1_SEGMENT  = VALUES(DL1_SEGMENT),\
                                                	DL1_SCRIP_CODE = VALUES(DL1_SCRIP_CODE),\
                                                	DL1_EXCH_SCRIP_CODE = VALUES(DL1_EXCH_SCRIP_CODE),\
                                                	DL1_MARKET_TYPE = VALUES(DL1_MARKET_TYPE),\
                                                	DL1_ENTRY_TIME = VALUES(DL1_ENTRY_TIME),\
                                                	DL1_LTP = VALUES(DL1_LTP),\
                                                	DL1_OPEN_INTEREST = VALUES(DL1_OPEN_INTEREST),\
                                                	DL1_OI_HIGH = VALUES(DL1_OI_HIGH),\
                                                	DL1_OI_LOW = VALUES(DL1_OI_LOW);",NSE_EXCH,SEGMENT_FNO,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp,TempDayHiOpenInt,TempDayHiOpenInt,TempDayLowOpenInt);


							logDebug2("Insert Query[%s]",sInsertQry);
							if(mysql_query(DNMbp_con,sInsertQry) != SUCCESS)
							{
								logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table DRV_L1_WATCH");
								sql_Error(DNMbp_con);
							}
							else
							{
								mysql_commit(DNMbp_con);
								logDebug2("------SUCCESS IN INSERT QUERY-----");
							}	
						}
						else
						{
							mysql_commit(DNMbp_con);
							logDebug2("------SUCCESS IN INSERT QUERY-----");
						}

						sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f , L1_LUT = NOW() WHERE L1_EXCHANGE =\'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",fTempLtp,NSE_EXCH,SEGMENT_FNO,iTempScripCode);

						logDebug2("Query[%s]",supdate);

						if(mysql_query(DNMbp_con,supdate) != SUCCESS)
						{
							logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
							sql_Error(DNMbp_con);
						}
						else
						{
							mysql_commit(DNMbp_con);
							logDebug2("------SUCCESS IN LTP UPDATE-----");
						}

					}
					else if (iMsgCode == TC_BCAST_SPREAD_MBP)
					{
						sprintf(sUpdateQry,"UPDATE DRV_L1_WATCH SET DL1_LTP =%lf,DL1_LUT = NOW() WHERE DL1_EXCHANGE = \"%s\" AND DL1_SEGMENT = \'%c\' AND DL1_SCRIP_CODE = \"%s\"  AND DL1_MARKET_TYPE = \"SP\" ; ",fTempLtp,NSE_EXCH,SEGMENT_FNO,reply1->element[1]->str);

						logTimestamp("sUpdateQry :%s:",sUpdateQry);

						if(mysql_query(DNMbp_con,sUpdateQry) != SUCCESS)
						{
							logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table DRV_L1_WATCH");
							sql_Error(DNMbp_con);
						}
						else
						{
							logInfo("Update Query fired successfully ");
						}


						if(mysql_affected_rows(DNMbp_con) == 0)
						{	
						
							sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
							(DL1_EXCHANGE ,\
							DL1_SEGMENT,\
							DL1_SCRIP_CODE,\
							DL1_EXCH_SCRIP_CODE,\
							DL1_ENTRY_TIME,\
							DL1_LTP,\
							DL1_MARKET_TYPE)\
							VALUES(\"%s\",\'%c\',\"%s\",\"%s\",NOW(),%lf,'SP')\
							;",NSE_EXCH,SEGMENT_FNO,reply1->element[1]->str,reply1->element[1]->str,fTempLtp);


							logDebug2("Insert Query[%s]",sInsertQry);
							if(mysql_query(DNMbp_con,sInsertQry) != SUCCESS)
							{
								logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table DRV_L1_WATCH");
								sql_Error(DNMbp_con);
							}
							else
							{
								mysql_commit(DNMbp_con);
								logDebug2("------SUCCESS IN INSERT QUERY-----");
							}
						
						}
						else
						{
							mysql_commit(DNMbp_con);
							logDebug2("------SUCCESS IN INSERT QUERY-----");
						}

						sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f L1_LUT = NOW() WHERE L1_EXCHANGE =\'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =\"%s\" ;",fTempLtp,NSE_EXCH,SEGMENT_FNO,reply1->element[1]->str);

						logDebug2("Query[%s]",supdate);

						if(mysql_query(DNMbp_con,supdate) != SUCCESS)
						{
							logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
							sql_Error(DNMbp_con);
						}
						else
						{
							mysql_commit(DNMbp_con);
							logDebug2("------SUCCESS IN LTP UPDATE-----");
						}
					}
				}
				freeReplyObject(reply1);
			}	
			freeReplyObject(reply);
			logTimestamp("#####EXIT#####");
		}
		logError("Redis connection dropped, trying to reconnnect again");
		sleep(5);
		c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	}
        logTimestamp("EXIT [UPDATE LTP IN DB]");

}
