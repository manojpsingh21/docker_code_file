#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

//redisContext *c;
redisContext *c1;
redisReply *reply;
redisReply *reply1;
redisReply *reply2;
redisReply *repRem;
MYSQL   *ENMbp_con;
INT16	iSubInstance;
LONG32  iSleepTime;

main(int argc,char **argv)
{
	setbuf(stdout,0);
	logTimestamp("ENTRY [Main]");
	//	c = RDConnect();
	c1 = RDConnect(REDIS_TYPE_PRICE_BCAST);
	ENMbp_con=DB_Connect();
	iSubInstance = atoi(argv[1]);
	iSleepTime = atoi(argv[2]);
	if ( argc != 4 )     
        {
                logDebug2("Argument Mismstch ");
                logDebug2("USAGE : NseCMSMemMbpUpd iSubInstance iSleepTime NseCMSMemMbpUpd ");
		iSleepTime = 3 ;
        }

	logInfo("iSubInstance :%d:",iSubInstance);	
	logInfo("iSleepTime:%d:",iSleepTime);	
	ReceiveReplyPacketsBcast();
	return 0;
	logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
	logTimestamp("ENTRY [UPDATE LTP IN DB]");
	CHAR sCommand[COMMAND_LEN],sRSRem[COMMAND_LEN]; 
	BOOL flag;
	int count=0;
	int iCount ;
	int i=0 ;
	CHAR sKeyValue[RADIS_KEY_LEN];
	DOUBLE64   fTempLtp=0.00;
	LONG32          iTempScripCode =0 ,iMsgCode;
	CHAR	sExch [10];
	CHAR	cSegment;
	CHAR    sUpdateQry[MAX_QUERY_SIZE];
	CHAR    sgetMembers[MAX_QUERY_SIZE];
	DOUBLE64 fLowerCktlmt = 0.00 ;
        DOUBLE64 fupperCktlmt = 0.00 ;


	while(TRUE) 
	{
		memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
		memset(&sgetMembers,'\0',MAX_QUERY_SIZE);
		sprintf(sgetMembers,"SMEMBERS NSE:D:DPR");
		//reply = redisCommand(c1,sgetMembers);
		reply = fRedisCommand(c1,sgetMembers,REDIS_TYPE_PRICE_BCAST);	

		iCount = reply->elements;
		for (i=0;i<iCount;i++)
		{
			memset(&sCommand,'\0',COMMAND_LEN);
			sprintf(sCommand,"HMGET %s SCRIPT EXCH SEGMENT UPPERCKT LOWERCKT",reply->element[i]->str);
			logTimestamp("sCommand -> %s",sCommand);
			//reply1 = redisCommand(c1,sCommand);
			reply1 = fRedisCommand(c1,sCommand,REDIS_TYPE_PRICE_BCAST);	
			if(reply1->element[0]->str != NULL)
			{
				iTempScripCode = atoi(reply1->element[0]->str);
				fupperCktlmt = atof(reply1->element[3]->str);
				fLowerCktlmt = atof(reply1->element[4]->str);
				sprintf(sUpdateQry,"CALL PR_CKT_LMT_UPDATE(\"%d\", \"%s\",\'%c\', %.2f, %.2f,@ZSTATUS)",iTempScripCode,NSE_EXCH,DERIVATIVE_SEGMENT,fupperCktlmt,fLowerCktlmt);                		     
				logDebug2("Query[%s]",sUpdateQry);
	                	if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
                		{
                        		logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
                        		sql_Error (ENMbp_con);
                		}
                		else
                		{
                        		mysql_commit(ENMbp_con);
                        		logDebug2("------SUCCESS IN SM_FREEZE_PERCNT UPDATE-----");
                		}


			}
			freeReplyObject(reply1);
			memset(&sRSRem,'\0',COMMAND_LEN);
			sprintf(sRSRem,"SREM NSE:D:DPR %s",reply->element[i]->str);

			logDebug2("sRSRem :%s:",sRSRem);
			//repRem = redisCommand(c1,sRSRem);
			repRem = fRedisCommand(c1,sRSRem,REDIS_TYPE_PRICE_BCAST);	

			if(repRem->type == REDIS_REPLY_INTEGER)
			{
				logInfo("Added Success");
			}
			else
			{
				logFatal("Error in adding values to CLIENT HASH. :%s:",repRem->str);
			}


			freeReplyObject(repRem);



		}


		freeReplyObject(reply);
		sleep(iSleepTime);/* Info :- Sleep time taken because
				     its effect on CPU
				     Utilization after update on every SMEM count*/

	}
	logTimestamp("EXIT [UPDATE LTP IN DB]");
}
