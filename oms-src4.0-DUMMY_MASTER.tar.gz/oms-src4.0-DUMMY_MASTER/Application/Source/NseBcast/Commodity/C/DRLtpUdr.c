#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include "RedisStruct.h"
#include <my_global.h>
#include <mysql.h>

INT16 iMbpCount = 0 ;
BOOL  fBcastUpdt(void *parameter);

MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32  iRcvQ;
MYSQL   *DNMbp_con;

redisContext    *RdConSt;

main(int argv,char *argc[])
{
	logTimestamp("ENTRY [Main]");

	setbuf(stdout,0);

	RdConSt =RDConnect();
	if((iRcvQ=OpenMsgQ(DNMbpToLTPUpd))==ERROR)
	{
		perror("\n Error in Opening DNMbpToLTPUpd....");
		exit(ERROR);
	}
	logDebug2("Message Queue opened DNMbpToLTPUpd : %d:",DNMbpToLTPUpd);

	logTimestamp("EXIT [MAin]");
}

BOOL fRedisLTPUpdate()
{
	logTimestamp("ENTRY [fBcastUpdt]");
	INT16   iTranscodeLocal,i;
	CHAR    sRcvMsg[LOCAL_MAX_PACKET_SIZE];
	LONG32  iCount;
	DOUBLE64 fPrvLTP,fOrdGap,fCalGap;
	BOOL    iRetVal = FALSE;
	redisReply *reply;
	redisReply *repdata;
	redisReply *repUpdate;
	CHAR    sSMemQry [MAX_QUERY_SIZE];
	CHAR    sGetQry [MAX_QUERY_SIZE];
	CHAR    sSetQry [MAX_QUERY_SIZE];
	CHAR    cTmpFlag;

	struct  REDIS_LTP_UPD *pRcvLTP;

	while(TRUE)
	{
		memset(&sRcvMsg,'\0',LOCAL_MAX_PACKET_SIZE);
		memset(pRcvLTP,'\0',sizeof(struct  REDIS_LTP_UPD));
		memset(sSMemQry,'\0',MAX_QUERY_SIZE);
		fPrvLTP = 0.00;
		fOrdGap = 0.00;
		fCalGap = 0.00;
		cTmpFlag = 'N';

		if((ReadMsgQ(iRcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		logDebug2(" pRcvLTP->iToken :%d:",pRcvLTP->iToken);
		logDebug2(" pRcvLTP->fLtp :%lf:",pRcvLTP->fLtp);

		sprintf(sSMemQry,"SMEMBERS %s:%s:%c:%d",SET_BO_ORD,NSE_EXCH,DERIVATIVE_SEGMENT,pRcvLTP->iToken);

		reply = redisCommand(RdConSt,sSMemQry);

		iCount = reply->elements;

		for(i = 0 ;i < iCount;i++)
		{
			memset(sGetQry,'\0',MAX_QUERY_SIZE);
			memset(sSetQry,'\0',MAX_QUERY_SIZE);

			sprintf(sGetQry,"HMGET %s %s %s %s %s %s %s %s %s %s %s %s %s",reply->element[i]->str,ORD_ORDER_NO,ORD_LEG_NO,ORD_SCRIP_CODE,ORD_EXCH_ID,ORD_SEGMENT,ORD_CLIENT_ID,ORD_BUY_SELL_IND,ORD_BO_FLAG,ORD_LTP,ORD_PRE_LTP,ORD_GAP);

			logDebug2("sGetQry :%s:",sGetQry);
			repdata = redisCommand(RdConSt,sGetQry);

			fPrvLTP = atof(repdata->element[9]->str);
			fOrdGap = atof(repdata->element[11]->str);

			if(repdata->type != REDIS_REPLY_NIL && repdata->type != REDIS_REPLY_ERROR)
			{

				if(repdata->element[6]->str[0] == INT_BUY )
				{
					if((pRcvLTP->fLtp - fPrvLTP) >= fOrdGap)
					{
						fCalGap =  pRcvLTP->fLtp - fPrvLTP;
						cTmpFlag = 'Y';
					}
				}
				else if(repdata->element[6]->str[0] == INT_SELL )
				{
					if((fPrvLTP - pRcvLTP->fLtp) >= fOrdGap)
					{
						fCalGap = fPrvLTP -  pRcvLTP->fLtp;
						cTmpFlag = 'Y';
					}
				}
				else
				{
					logInfo("Nothing to Change ");
					continue;
				}

				sprintf(sSetQry,"HMSET %s %s %lf %s %lf %s %c",reply->element[i]->str,ORD_LTP,pRcvLTP->fLtp,ORD_PRE_LTP,pRcvLTP->fLtp,ORD_BO_FLAG,cTmpFlag);
				repUpdate = redisCommand(RdConSt,sSetQry);

				if(!strcasecmp(repUpdate->str,C_REDIS_OK))
				{
					logFatal("Error ");
				}
			}
		}
	}
	logTimestamp("EXIT [fBcastUpdt]");
}


