



BOOL CircuitLmtUpdate (void *parameter)
{
	INT16   TranscodeLocal,i;
	CHAR   RcvMsg[LOCAL_MAX_PACKET_SIZE];

	struct NNF_HEADER *pTransCode; 
	LONG32 count;
	BOOL ReturnValue;
	while(TRUE)
	{
		memset(&RcvMsg,SPACE,LOCAL_MAX_PACKET_SIZE);
		if((ReadMsgQ(rcvQ,&RcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			logDebug2("id %d",rcvQ);
			exit(ERROR);
		}
		pTransCode  = (struct NNF_HEADER *) RcvMsg;
		TranscodeLocal = pTransCode->MsgCode;
