#include "IPCS.h"
//#include "Defination.h"
//#include "EQNSEBcastStruct.h"
#include "EquNseDBUpdMulti.h"
#include <my_global.h>
#include <mysql.h>

INT16 iMbpCount = 0 ;
MYSQL_RES *result;
MYSQL_ROW rowdata;

main()
{
	LONG32 	iFlag;
	LONG32 	i;
	LONG32	iNseRecordCount;

	pthread_t thread_id[MAX_NO_OF_THREADS];

	MYSQL *ENMbp_con[MAX_NO_OF_THREADS];    
	MYSQL *ENMbp_con1=DB_Connect();


	logDebug2("Connecting to database.......");

	if(mysql_autocommit(ENMbp_con1,1))
	{
		sql_Error(ENMbp_con1);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}


	if(mysql_query(ENMbp_con1,"SELECT COUNT(*) FROM NSE_SECURITY_MASTER"))
	{
		sql_Error(ENMbp_con1);
	}

	result = mysql_store_result(ENMbp_con1);

	if(result==NULL)
	{
		sql_Error(ENMbp_con1);

	}

	rowdata = mysql_fetch_row(result);	
	iNseRecordCount = atoi(rowdata[0]);

	if((rcvQ=OpenMsgQ(ENBSpltrToIndxUpld))==ERROR)
	{
		perror("\n Error in Opening ENBSpltrToIndxUpld....");
		exit(ERROR);
	}

	logDebug2("Message Queue opened BcasttoMbpMbo : %d:",ENBSpltrToIndxUpld);

	mysql_free_result(result);
	close(ENMbp_con1);

	for(i=0;i<MAX_NO_OF_THREADS;i++)
	{
		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,(void *)&ENMbp_con[i]))!=0)
			logDebug2("Cant create thread %d",i);
		else
			logDebug2("Created");

	}

	for(i=0;i<MAX_NO_OF_THREADS;i++)
	{
		/*Wait for thread to end */
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logDebug2("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logDebug2("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}
	mysql_free_result(result);

}



BOOL fBcastUpdt(MYSQL *ENMbp_con)
{
	INT16 	iTransCodeLocal,i;
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];

	struct	NNF_HEADER *pForRectTransCode;

	LONG32	iCount;
	BOOL	iRetVal = FALSE;

	ENMbp_con=DB_Connect();		

	struct	TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] =
	{
		TC_MULTIPLE_INDEX_BCAST		,dTC_MULTIPLE_INDEX_BCAST
	};



	while(TRUE)
	{
		memset(&sRcvMsg, ' ',LOCAL_MAX_PACKET_SIZE);

		if(ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE,1) != TRUE)
		{
			perror("Error Read Q");
			exit(ERROR);
		}

		mysql_commit(ENMbp_con);

		pForRectTransCode = (struct NNF_HEADER *)sRcvMsg;

		iTransCodeLocal = pForRectTransCode->iMsgCode;

		for(iCount=0;iCount < MAX_NO_OF_TRANSCODE_RECV;iCount++)
		{
			if(TransFunPair[iCount].Transcode == iTransCodeLocal)
			{
				if((iRetVal = (*(TransFunPair[iCount].pToFun))(&sRcvMsg,ENMbp_con)==TRUE))
				{
					mysql_commit(ENMbp_con);

				}
				else
				{
					logDebug2("DATABASE NOT UDPATED...,BroadDataUpd returned FALSE %d",iTransCodeLocal);
				}
				break;

			}

		}

	}	


}


BOOL	dTC_MULTIPLE_INDEX_BCAST(CHAR *NNFData,MYSQL *ENMbp_con)
{
	BOOL	iRetVal;
	struct NNF_MULTIPLE_INDEX_BCAST *pPacket = (struct NNF_MULTIPLE_INDEX_BCAST *) NNFData;
	CHAR	sExchId[5];
	strcpy(sExchId,"NSE");

	iRetVal = fUpdateMktmvmtBcast(pPacket,sExchId,ENMbp_con);

	return iRetVal;

}


BOOL  	fUpdateMktmvmtBcast(struct NNF_MULTIPLE_INDEX_BCAST *pMktMvmt,CHAR *sExchId,MYSQL *ENMbp_con)
{
	INT16 iLoopVar;
	CHAR	sLogTime[DATE_STRING_LENGTH];

	FLOAT32	iIndexVal;
	FLOAT32	iHighIndex;
	FLOAT32	iLowIndex;
	FLOAT32	iOpenIndex;
	FLOAT32	iCloseIndex;
	FLOAT32	iPctcChange;
	FLOAT32	iYearlyHigh;
	FLOAT32	iYearlyLow;

	INT16	iIndexChange;
	INT16	iIndexChangePos;
	INT16	iIndexChangeNeg;

	LONG32	iNoOfUpmoves;
	LONG32	iNoOfDownmoves;

	CHAR	cNetChangeIndictr;

	CHAR	sTempExchId[EXCHANGE_LEN];
	CHAR	sIndexName[INDEX_NAME_LEN];	

	LONG32	iRecCount;
	CHAR	statement[200];

	strcpy(sTempExchId,sExchId);

	convert_seconds_to_date(pMktMvmt->pHeader.iLogTimeStamp,sLogTime);

	iRecCount = pMktMvmt->iNumberOfRecords;

	for(iLoopVar = 0;iLoopVar < pMktMvmt->iNumberOfRecords;iLoopVar++)
	{

		strcpy(sIndexName,pMktMvmt->pIndicesData[iLoopVar].sIndexName);
		iIndexVal= (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iIndexVal / CONST_PRICE_FACTOR;

		iHighIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iHighIndexVal /CONST_PRICE_FACTOR;
		iLowIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iLowIndexVal /CONST_PRICE_FACTOR;
		iOpenIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iOpeningIndex /CONST_PRICE_FACTOR;
		iCloseIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iClosingIndex /CONST_PRICE_FACTOR;
		iPctcChange=(FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iPercentChange /CONST_PRICE_FACTOR;
		iYearlyHigh = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iYearlyHigh /CONST_PRICE_FACTOR;
		iYearlyLow = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iYearlyLow /CONST_PRICE_FACTOR;
		iNoOfUpmoves= pMktMvmt->pIndicesData[iLoopVar].iNoOfUpMoves;
		iNoOfDownmoves= pMktMvmt->pIndicesData[iLoopVar].iNoOfDownMoves;

		cNetChangeIndictr= pMktMvmt->pIndicesData[iLoopVar].cNetChangeIndicator;
		iIndexChange = (int)(iIndexVal-iCloseIndex);

		if(iIndexChange == 0)
		{
			iCloseIndex = 0;
		}

		if(iIndexChange < 0)
		{
			iIndexChangeNeg = abs(iIndexChange);
			iIndexChangePos = NULL;	
		}		
		else
		{
			iIndexChangePos = iIndexChange;
			iIndexChangePos = NULL;
		}

		logDebug2("Record Count :%d:",iRecCount);
		//		printf("\n host_tempNetChangeIndicator :%s: len:%d:",cNetChangeIndictr,strlen());

		memset(statement,'\0',sizeof(statement));

		sprintf(statement,"UPDATE MULTIPLE_INDEX_INQUIRY SET MII_INDEX_VAL = %i ,MII_HIGH_INDEX_VAL = %i,MII_LOW_INDEX_VAL=%i,MII_OPENING_INDEX=%i,MII_CLOSING_INDEX=DECODE(%i,0,MII_CLOSING_INDEX,%i),MII_PCT_CHANGE=%i,MII_YEARLY_HIGH=%i,MII_YEARLY_LOW=%i,MII_NO_UPS=%i,MII_NO_DOWNS=%i,MII_TIME=STR_TO_DATE(\"%s\",'%%d%%m%%Y %%h%%i%%s') WHERE MII_INDEX_NAME = DECODE(LTRIM(RTRIM(\"%s\")),'CNX Nifty','S&P CNX Nifty',LTRIM(RTRIM(\"%S\"))) AND MII_EXCH_ID = \"%s\"",iIndexVal,iHighIndex,iLowIndex,iOpenIndex,iCloseIndex,iCloseIndex,iPctcChange,iYearlyHigh,iYearlyLow,iNoOfUpmoves,iNoOfDownmoves,sLogTime,sIndexName,sIndexName,sTempExchId);

		if(mysql_query(ENMbp_con,statement))
		{
			sql_Error(ENMbp_con);
		}

		if(mysql_errno(ENMbp_con)==1403)	
		{
			memset(statement,'\0',sizeof(statement));

			sprintf(statement,"INSERT INTO MULTIPLE_INDEX_INQUIRY(MII_INDEX_NAME ,  MII_EXCH_ID ,MII_INDEX_VAL ,MII_HIGH_INDEX_VAL,MII_LOW_INDEX_VAL ,MII_OPENING_INDEX ,MII_CLOSING_INDEX ,MII_PCT_CHANGE,MII_YEARLY_HIGH ,MII_YEARLY_LOW,MII_NO_UPS,MII_NO_DOWNS,MII_TIME)VALUES(\"%s\",%i,%i,%i,%i,%i,%i,%i,%i,%i,%i)",sIndexName,sTempExchId,iIndexVal,iHighIndex,iLowIndex,iOpenIndex,iCloseIndex,iPctcChange,iYearlyHigh,iYearlyLow,iIndexChangePos,iIndexChangeNeg);


			if(mysql_query(ENMbp_con,statement))
			{
				sql_Error(ENMbp_con);
			}
			else
			{
				mysql_commit(ENMbp_con);
			}	
		}
		else
		{
			mysql_commit(ENMbp_con);
		}	

	}	


	return TRUE;
}



