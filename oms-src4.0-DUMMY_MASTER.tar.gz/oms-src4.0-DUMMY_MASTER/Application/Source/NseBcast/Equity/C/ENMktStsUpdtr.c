#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"
#include "RedisStruct.h"

INT16 iMbpCount = 0 ;
SHORT fTrim( CHAR * Str_In ,SHORT MaxLen);
BOOL  fBcastUpdt();
MYSQL_RES *result;
MYSQL_ROW rowdata;
SHORT fConvertBookToMkt(SHORT iBookType);
LONG32  rcvQ;

CHAR  sNCmBrokerId[5];
MYSQL 	*ENMbp_con;
static long iSeqNo = 0;
redisContext *RdConn;
LONG64 iPostCloseMKTStatus = 0;

main(int argv,char *argc[])
{
	logTimestamp ("ENTRY [main]");
	LONG32 	iFlag;
	LONG32 	i;
	LONG32	iNseRecordCount;


	setbuf(stdout,0);
	LoadNseEnv();

	//pthread_t thread_id[MAX_NO_OF_THREADS];
	//pthread_t thread_id[5];


	logInfo("Connecting to Database.......");
	ENMbp_con=DB_Connect();
	fLoadDBNseEnv ();
	logInfo("Connecting to Redis.......");
	RdConn = RDConnect(REDIS_TYPE_PRICE_BCAST);
	LONG32	iSegment;



	if(mysql_autocommit(ENMbp_con,1))
	{
		sql_Error(ENMbp_con);
	}
	else
	{
		logInfo("AutoCommit Enable");
	}

	/*********
	  if(mysql_query(ENMbp_con,"SELECT COUNT(*) FROM NSE_SECURITY_MASTER"))
	  {
	  sql_Error(ENMbp_con);
	  }

	  result = mysql_store_result(ENMbp_con);

	  if(result==NULL)
	  {
	  sql_Error(ENMbp_con);

	  }

	  rowdata = mysql_fetch_row(result);	
	  iNseRecordCount = atoi(rowdata[0]);
	 ******/
	/*****

	  if((ENrcvQ=OpenMsgQ(ENBSpltrToMbpUpld))==ERROR)
	  {
	  perror("\n Error in Opening BcasttoMbpMbo....");
	  exit(ERROR);
	  }

	  if((DNrcvQ=OpenMsgQ(DNBSpltrToMbpUpld))==ERROR)
	  {
	  perror("\n Error in Opening BcasttoMbpMbo....");
	  exit(ERROR);
	  }

	  if((CDrcvQ=OpenMsgQ(CNBSpltrToMbpUpld))==ERROR)
	  {
	  perror("\n Error in Opening BcasttoMbpMbo....");
	  exit(ERROR);
	  }
	 *******/
	/****	switch(iSegment)
	  {
	  case 1: 
	  if((rcvQ=OpenMsgQ(ENBSpltrToMbpUpld))==ERROR)
	  {
	  perror("\n Error in Opening BcasttoMbpMbo....");
	  exit(ERROR);
	  }
	  break;
	  case 2 :
	  if((rcvQ=OpenMsgQ(DRBSpltrToMbpUpld))==ERROR)
	  {
	  perror("\n Error in Opening BcasttoMbpMbo....");
	  exit(ERROR);
	  }
	  break;
	  case 3:
	  if((rcvQ=OpenMsgQ(CDBSpltrToMbpUpld))==ERROR)
	  {
	  perror("\n Error in Opening BcasttoMbpMbo....");
	  exit(ERROR);
	  }
	  break;
	  default :
	  printf("\n Invalide Segment");
	  }	
	 ***********/
	if((rcvQ=OpenMsgQ(ENBSpltrToMStatUpld))==ERROR)
	{
		perror("\n Error in Opening ENBSpltrToMStatUpld....");
		exit(ERROR);
	}

	logDebug1(" Message Queue opened ENBSpltrToMStatUpld : %d:",ENBSpltrToMStatUpld);

	mysql_free_result(result);

	fBcastUpdt();
	/*
	//for(i=0;i<MAX_NO_OF_THREADS;i++)
	for(i=0;i<1;i++)
	{


		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,NULL))!=0)
			logDebug1("Cant create thread %d",i);
		else
			logDebug1("Created");

	}


	//for(i=0;i<MAX_NO_OF_THREADS;i++)
	for(i=0;i<1;i++)
	{
		/*Wait for thread to end * /
		logDebug1("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logInfo("Error when waiting for thread %d to terminate",i);
		else
			logInfo("Stopped");

		logInfo("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logInfo("Error Detaching Thread! ");
		else
			logInfo("Detached! ");

		logInfo("Stop Session %d....",i);

		logInfo("Logged Off");

	}
	*/
	logTimestamp("EXIT [main]");
}

BOOL fBcastUpdt()
{
	INT16	iTranscodeLocal,i;
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];


	struct	NNF_HEADER *pForRecTransCode;
	LONG32	iCount;
	BOOL	iRetVal = FALSE;


	struct TRANS_FUN_PAIR pTransFunPair[MAX_NO_OF_TRANSCODE] =
	{	
		TC_GENERAL_MSG_BCAST                  ,dTC_GENERAL_MSG_BCAST
			,TC_SYSTEM_INFORMATION_BCAST           ,dTC_SYSTEM_INFORMATION_BCAST
			,TC_STOCK_STATUS_CHANGE_BCAST          ,dTC_STOCK_STATUS_CHANGE_BCAST
			,TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST  ,dTC_STOCK_STATUS_CHANGE_BCAST
			,TC_MARKET_OPEN_MSG_BCAST              ,dTC_MARKET_OPEN_MSG_BCAST
			,TC_MARKET_CLOSE_MSG_BCAST             ,dTC_MARKET_CLOSE_MSG_BCAST
			,TC_PREOPEN_SHUTDOWN_BCAST             ,dTC_PREOPEN_SHUTDOWN_BCAST
			,TC_PRE_OPEN_ENDED_MSG_BCAST           ,dTC_PRE_OPEN_ENDED_MSG_BCAST
			//        	,TC_PARTICIPANT_INFO_RESP              ,dTC_PARTICIPANT_INFO_RESP
			//        	,TC_MKT_STATS_RPT_BCAST                ,dTC_MKT_STATS_RPT_BCAST
			,TC_POST_CLOSING_START_BCAST           ,dTC_POSTCLOSE_BCAST
			,TC_SECURITY_OPEN_MSG_BCAST		,dTC_SECURITY_OPEN_MSG_BCAST
			,TC_POST_CLOSING_END_BCAST             	,dTC_POSTCLOSE_BCAST
			,TC_STOCK_DETAILS_CHANGE_BCAST		,dTC_STOCK_DETAILS_CHANGE_BCAST
			,TC_STOCK_DETAILS_CHANGE_BCAST_TNDTC    ,dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC
                        ,TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST_TNDTC  ,dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC
                        ,TC_STOCK_STATUS_CHANGE_BCAST_TNDTC          ,dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC
	};

	while(TRUE)
	{
		memset(&sRcvMsg,' ',LOCAL_MAX_PACKET_SIZE);



		if((ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		//		mysql_commit(ENMbp_con);

		pForRecTransCode = (struct NNF_HEADER *) sRcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgCode;

		/***/	for(iCount = 0;iCount < MAX_NO_OF_TRANSCODE; iCount++)
		{
			if (pTransFunPair[iCount].Transcode == iTranscodeLocal)
			{
				if((iRetVal = (*(pTransFunPair[iCount].pToFun))(sRcvMsg)) == TRUE)
				{
					mysql_commit(ENMbp_con);

				}
				else
				{
					logDebug2("DATABASE NOT UDPATED...,BroadDataUpd returned FALSE %d",iTranscodeLocal);
				}
				break;

			}
		}/****
		   if(iTranscodeLocal == TC_MBP_BCAST)
		   {
		   printf("\n Printf in If");
		   dTC_MBP_BCAST(sRcvMsg);	
		   }
		   else
		   {
		   printf("\n This is in else ");
		   }
		  ****/
	}
}


BOOL dTC_GENERAL_MSG_BCAST(CHAR *NNFData)
{
	BOOL iRetVal;
	struct NNF_GEN_MESSAGE_BCAST 	*pPacket = (struct NNF_GEN_MESSAGE_BCAST *) NNFData;
	iRetVal = fGenMsgBcast(pPacket);


	return iRetVal;
}

BOOL dTC_STOCK_DETAILS_CHANGE_BCAST (CHAR *NNFData)
{
	logTimestamp ("ENTRY [fTC_STOCK_DETAILS_CHANGE]");
	struct NNF_SECURITY_UPDATE_BCAST *pSecData;
	pSecData = (struct NNF_SECURITY_UPDATE_BCAST *)NNFData;
	DOUBLE64 fFreezeprcnt = 0.00;
	DOUBLE64 fLowerCktlmt = 0.00 ;
	DOUBLE64 fupperCktlmt = 0.00 ;
	CHAR    *sToken;
	redisReply *reply;
	CHAR    sCreditRating [CREDIT_RATING_SIZE];
	memset(sCreditRating,'\0',CREDIT_RATING_SIZE);
	CHAR    supdate[MAX_QUERY_SIZE];
        memset(supdate,'\0',MAX_QUERY_SIZE);

	CHAR sCommand[COMMAND_LEN];	
	fFreezeprcnt = ((DOUBLE64)pSecData->FreezePercent)/CONST_PRICE_FACTOR;
	logDebug2(" 7305 Stock Details Changed Bcast");
	logDebug2("pSecData->Token:%d:",pSecData->Token);
	logDebug2(" Credit_rating pSecData->CreditRating [%s]",pSecData->CreditRating);
	/*  fTrim(pSecData->CreditRating,strlen(pSecData->CreditRating)); */
	strncpy(sCreditRating,pSecData->CreditRating,CREDIT_RATING_SIZE);
	fTrim(sCreditRating,strlen(sCreditRating));
	/* strcpy(sCreditRating,pSecData->CreditRating); */
	logDebug2("sCreditRating:%s:",sCreditRating);

	if(!(strcmp(sCreditRating,"-") == 0 || strcmp(sCreditRating,"--") == 0))
	{
		sToken = strtok(sCreditRating, "-");
		fLowerCktlmt    =  atof(sToken);
		sToken = strtok(NULL, "-");
		fupperCktlmt    = atof(sToken);
		logDebug2("fLowerCktlmt = :%f: fupperCktlmt :%f:",fLowerCktlmt,fupperCktlmt);
		sprintf(supdate,"CALL PR_CKT_LMT_UPDATE(\"%d\", \"%s\",\'%c\', %.2f, %.2f,@ZSTATUS)",pSecData->Token,NSE_EXCH,SEGMENT_EQUITY,fupperCktlmt,fLowerCktlmt);		logDebug2("Query[%s]",supdate);
		if(mysql_query(ENMbp_con,supdate) != SUCCESS)
		{
			logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
			sql_Error (ENMbp_con);
		}
		else
		{
			mysql_commit(ENMbp_con);
			logDebug2("------SUCCESS IN SM_FREEZE_PERCNT UPDATE-----");
		}
	
		memset(sCommand,'\0',COMMAND_LEN);
                sprintf(sCommand,"HMSET %s:%s%c%d %s %.2f %s %.2f ",SET_L1_WATCH,NSE_EXCH,SEGMENT_EQUITY,pSecData->Token,SM_LOWER_LIMIT,fLowerCktlmt,SM_UPPER_LIMIT,fupperCktlmt);
                logTimestamp("sCommand -> %s",sCommand);
                reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_PRICE_BCAST);
                freeReplyObject(reply);

		logTimestamp ("EXIT [fTC_STOCK_DETAILS_CHANGE]");
		return TRUE;
	}
	else
	{
		logDebug2("sCreditRating received Null");
		return TRUE;
	}
}

BOOL dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC (CHAR *NNFData)
{
        logTimestamp ("ENTRY [fTC_STOCK_DETAILS_CHANGE_TNDTC]");
        struct NNF_SECURITY_UPDATE_BCAST_TNDTC *pSecData;
        pSecData = (struct NNF_SECURITY_UPDATE_BCAST_TNDTC *)NNFData;
        DOUBLE64 fFreezeprcnt = 0.00;
        DOUBLE64 fLowerCktlmt = 0.00 ;
        DOUBLE64 fupperCktlmt = 0.00 ;
        CHAR    *sToken;
        redisReply *reply;
        CHAR    sCreditRating [CREDIT_RATING_SIZE];
        memset(sCreditRating,'\0',CREDIT_RATING_SIZE);
        CHAR    supdate[MAX_QUERY_SIZE];
        memset(supdate,'\0',MAX_QUERY_SIZE);

        CHAR sCommand[COMMAND_LEN];
        fFreezeprcnt = ((DOUBLE64)pSecData->FreezePercent)/CONST_PRICE_FACTOR;
        logDebug2("18720 Stock Details Changed Bcast");
        logDebug2("pSecData->Token:%d:",pSecData->Token);
        logDebug2(" Credit_rating pSecData->CreditRating [%s]",pSecData->CreditRating);
        /*  fTrim(pSecData->CreditRating,strlen(pSecData->CreditRating)); */
        strncpy(sCreditRating,pSecData->CreditRating,CREDIT_RATING_SIZE);
        fTrim(sCreditRating,strlen(sCreditRating));
        /* strcpy(sCreditRating,pSecData->CreditRating); */
        logDebug2("sCreditRating:%s:",sCreditRating);

        if(!(strcmp(sCreditRating,"-") == 0 || strcmp(sCreditRating,"--") == 0))
        {
                sToken = strtok(sCreditRating, "-");
                fLowerCktlmt    =  atof(sToken);
                sToken = strtok(NULL, "-");
                fupperCktlmt    = atof(sToken);
                logDebug2("fLowerCktlmt = :%f: fupperCktlmt :%f:",fLowerCktlmt,fupperCktlmt);
                sprintf(supdate,"CALL PR_CKT_LMT_UPDATE(\"%d\", \"%s\",\'%c\', %.2f, %.2f,@ZSTATUS)",pSecData->Token,NSE_EXCH,SEGMENT_EQUITY,fupperCktlmt,fLowerCktlmt);                logDebug2("Query[%s]",supdate);
                if(mysql_query(ENMbp_con,supdate) != SUCCESS)
                {
                        logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
                        sql_Error (ENMbp_con);
                }
                else
                {
                        mysql_commit(ENMbp_con);
                        logDebug2("------SUCCESS IN SM_FREEZE_PERCNT UPDATE-----");
                }

                memset(sCommand,'\0',COMMAND_LEN);
                sprintf(sCommand,"HMSET %s:%s%c%d %s %.2f %s %.2f ",SET_L1_WATCH,NSE_EXCH,SEGMENT_EQUITY,pSecData->Token,SM_LOWER_LIMIT,fLowerCktlmt,SM_UPPER_LIMIT,fupperCktlmt);
                logTimestamp("sCommand -> %s",sCommand);
                reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_PRICE_BCAST);
                freeReplyObject(reply);

                logTimestamp ("EXIT [fTC_STOCK_DETAILS_CHANGE]");
                return TRUE;
        }
        else
        {
                logDebug2("sCreditRating received Null");
                return TRUE;
        }
}


BOOL dTC_MKT_STATS_RPT_BCAST (CHAR *NNFData)
{
	LONG32     iRecordNumber = 0 ,iScripId = 0;

	struct NNF_MKT_STATS_RPT_DATA_BCAST   *pRptDataBcast = (NNF_MKT_STATS_RPT_DATA_BCAST *)NNFData;
	//CHAR    *sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//CHAR 	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sInsQry[MAX_QUERY_SIZE];
        memset(sInsQry,'\0',MAX_QUERY_SIZE);
	CHAR   sSelQry[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
	CHAR 	tempSymbol[SYMBOL_LEN];
	CHAR 	tempSeries[SERIES_LEN];
	CHAR 	NormlMkt[MKT_TYPE_LEN];
	memset(tempSymbol,'\0',SYMBOL_LEN);
	memset(tempSeries,'\0',SERIES_LEN);
	memset(NormlMkt,'\0',MKT_TYPE_LEN);
	MYSQL_RES      *Res;
	MYSQL_ROW       Row;
	DOUBLE64 	TempOpnPrice;
	DOUBLE64	TempHighPrice;
	DOUBLE64	TempClosePrice;
	DOUBLE64	TempLowPrice;
	DOUBLE64	TempPrvClose;
	DOUBLE64	TempTotlTrdVal;
	DOUBLE64	TempFifToWekHigh;
	DOUBLE64	TempFifToWekLow;
	LONG32		TemptotlQtyTraded;
	LONG32		TempMktType;

	logDebug2("1833 Bhavcopy Mkt Status Rpt  MsgCode[%d]",pRptDataBcast->sHeader.iMsgCode);
	if (pRptDataBcast->MsgType == EQ_BCPY_REPORT_DATA_BCAST); /*IF MsgType = R */
	{

		logDebug2("pRptDataBcast->MsgType :%c:",pRptDataBcast->MsgType);
		for(iRecordNumber = 0; iRecordNumber < pRptDataBcast->nNumberOfRecords ;iRecordNumber++)
		{
			strncpy(tempSymbol,(pRptDataBcast->MktStatsData[iRecordNumber].SecInfo).sSymbol,SYMBOL_LEN);
			strncpy(tempSeries,(pRptDataBcast->MktStatsData[iRecordNumber].SecInfo).sSeries,SERIES_LEN);
			logDebug2("tempSymbol:%s: tempSeries :%s:",tempSymbol,tempSeries);

			sprintf(sSelQry ,"SELECT s.SM_SCRIP_CODE FROM SECURITY_MASTER s WHERE s.SM_EXCHANGE = \"%s\" AND s.SM_SEGMENT = \'%c\' AND s.SM_EXCH_SYMBOL = \"%s\" AND SM_SERIES = \"%s\" ;",NSE_EXCH,EQUITY_SEGMENT,tempSymbol,tempSeries);

			logDebug2("Query[%s]",sSelQry);	
			if(mysql_query(ENMbp_con,sSelQry) != SUCCESS)
			{
				logSqlFatal("Error in Select Query[SECURITY_MASTER]  In Function dTC_MKT_STATS_RPT_BCAST");
				sql_Error(ENMbp_con);


			}
			else
			{

				logDebug2("Success  in Select Query");
				Res = mysql_store_result(ENMbp_con);


				if(Row = mysql_fetch_row(Res))
				{
					iScripId = atoi(Row[0]);
					logDebug2("Scrip Id[%d]",iScripId);
				}
				mysql_free_result(Res);

				TempHighPrice = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].HighPrice)/CONST_PRICE_FACTOR;	
				TempClosePrice = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].ClosingPrice)/CONST_PRICE_FACTOR;
				TempLowPrice = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].LowPrice)/CONST_PRICE_FACTOR;
				TempOpnPrice = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].OpenPrice)/CONST_PRICE_FACTOR;
				TempPrvClose = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].PreviousClosePrice)/CONST_PRICE_FACTOR;
				TempTotlTrdVal = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].TotalValueTraded)/CONST_PRICE_FACTOR;
				TempFifToWekHigh = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].FiftyTwoWeekHigh)/CONST_PRICE_FACTOR;
				TempFifToWekLow = ((DOUBLE64)pRptDataBcast->MktStatsData[iRecordNumber].FiftyTwoWeekLow)/CONST_PRICE_FACTOR;
				TemptotlQtyTraded = pRptDataBcast->MktStatsData[iRecordNumber].TotalQtyTraded;
				TempMktType= pRptDataBcast->MktStatsData[iRecordNumber].MktType;

				switch(TempMktType)
				{
					case NORMAL_MARKET:
						strncpy(NormlMkt,MKT_TYPE_NL,MKT_TYPE_LEN);
						break;
					case ODDLOT_MARKET:
						strncpy(NormlMkt,MKT_TYPE_OL,MKT_TYPE_LEN);
						break;
					case SPOT_MARKET:
						strncpy(NormlMkt,MKT_TYPE_SP,MKT_TYPE_LEN);
						break;
					case AUCTION_MARKET:
						strncpy(NormlMkt,MKT_TYPE_AU,MKT_TYPE_LEN);
						break;
					case CALL_AUCTION_MARKET1:
						strncpy(NormlMkt,MKT_TYPE_CAU_1,MKT_TYPE_LEN);
						break;
					case CALL_AUCTION_MARKET2:
						strncpy(NormlMkt,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
						break;
					default :
						logDebug2("MktType received in Junk");
						break;	

				}

				logDebug2("iScripId [%d]",iScripId);
				logDebug2("TempOpnPrice[%.2f]",TempOpnPrice);
				logDebug2("TempHighPrice[%.2f]",TempHighPrice);
				logDebug2("TempLowPrice[%.2f]",TempLowPrice);
				logDebug2("TempClosePrice[%.2f]",TempClosePrice);
				logDebug2("TotalQtyTraded [%d]",TemptotlQtyTraded);
				logDebug2("TempTotlTrdVal[%.2f]",TempTotlTrdVal);		
				logDebug2("TempPrvClose[%.2f]",TempPrvClose);
				logDebug2("TempFifToWekHigh[%.2f]",TempFifToWekHigh);
				logDebug2("TempFifToWekLow[%.2f]",TempFifToWekLow);

				sprintf(sInsQry,"INSERT INTO BHAV_COPY \
						( 	BC_EXCHANGE,BC_SEGMENT,\
							BC_SCRIP_CODE,BC_MARKET_TYPE,\
							BC_DATE,BC_OPEN_PRICE,\
							BC_HIGH_PRICE,BC_LOW_PRICE,\
							BC_CLOSE_PRICE,BC_VOLUME,\
							BC_TOTAL_TRADE_VALUE,BC_PERVIOUS_CLOSE,\
							BC_FIFTY_TWO_WEEK_HIGH,BC_FIFTY_TWO_WEEK_LOW )\
						VALUES( \"%s\",\'%c\' ,\
							%d   ,\"%s\" ,\
							Now(),%.2lf  ,\
							%.2lf ,%.2lf  ,\
							%.2lf ,%d     ,\
							%.2lf ,%.2lf  ,\
							%.2lf ,%.2lf  )\
						on duplicate key \
						UPDATE \
						BC_EXCHANGE = VALUES(BC_EXCHANGE) ,\
						BC_SEGMENT  = VALUES(BC_SEGMENT) ,\
						BC_SCRIP_CODE	=  VALUES(BC_SCRIP_CODE) ,\
						BC_MARKET_TYPE = VALUES(BC_MARKET_TYPE) ,\
						BC_DATE = NOW() ,\
						BC_OPEN_PRICE = VALUES(BC_OPEN_PRICE) ,\
						BC_HIGH_PRICE = VALUES(BC_HIGH_PRICE) ,\
						BC_LOW_PRICE = VALUES(BC_LOW_PRICE) ,\
						BC_CLOSE_PRICE = VALUES(BC_CLOSE_PRICE) ,\
						BC_VOLUME = VALUES(BC_VOLUME) ,\
						BC_TOTAL_TRADE_VALUE = VALUES(BC_TOTAL_TRADE_VALUE) ,\
						BC_PERVIOUS_CLOSE = VALUES(BC_PERVIOUS_CLOSE) ,\
						BC_FIFTY_TWO_WEEK_HIGH = VALUES(BC_FIFTY_TWO_WEEK_HIGH) ,\
						BC_FIFTY_TWO_WEEK_LOW = VALUES(BC_FIFTY_TWO_WEEK_LOW);",NSE_EXCH,EQUITY_SEGMENT,iScripId,NormlMkt,TempOpnPrice,TempHighPrice,TempLowPrice,TempClosePrice,TemptotlQtyTraded,TempTotlTrdVal,TempPrvClose,TempFifToWekHigh,TempFifToWekLow);

				logDebug2("Query[%s]",sInsQry);
				if(mysql_query(ENMbp_con,sInsQry) != SUCCESS)
				{
					sql_Error(ENMbp_con);
					logSqlFatal("Error in  Insert Query [BHAV_COPY] in Function dTC_MKT_STATS_RPT_BCAST");
				}
				logDebug2("Success in Insert Query");


			}
		}
	}


	return TRUE;
}	

BOOL fGenMsgBcast(struct NNF_GEN_MESSAGE_BCAST *pGenMsg)
{
	logTimestamp (" ENTRY [fGenMsgBcast]");
//	CHAR	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR	*sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sInsQry[MAX_QUERY_SIZE];
        memset(sInsQry,'\0',MAX_QUERY_SIZE);
        CHAR    sSelQry[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	logDebug2("6501 Gnral Msg Bcast");
	/*	if(pGenMsg->Dest.uiTraderWs)
		{*/

	/*	if(mysql_query(ENMbp_con,"SELECT NextVal('GEN_MSG'); ") != SUCCESS)
		{
		logSqlFatal("Error in selecting [SELECT NextVal('GEN_MSG')]");
		sql_Error(ENMbp_con);
		}

		Res = mysql_store_result(ENMbp_con);
		if(Row = mysql_fetch_row(Res))
		{
		iExchSeqNo = atoi(Row[0]);
		}*/
	iSeqNo ++ ;
	logDebug2("iSeqNo :%d: pGenMsg->BrokerNumber[%s]",iSeqNo,pGenMsg->BrokerNumber);		
	logDebug2("pGenMsg->ActionCode [%s]",pGenMsg->ActionCode);		
	logDebug2("pGenMsg->BcastMsg 	[%s]",pGenMsg->BcastMsg);		

	sprintf(sInsQry,"INSERT INTO EXCH_MESGS \
			(	EXMS_TIME,\
				EXMS_ACTION_CODE,\
				EXMS_GENERAL_MESG,\
				EXMS_EXM_EXCH_ID,\
				EXMS_EXM_SEGMENT,\
				EXMS_MSG_SEQ_NO)\
			VALUES	(\
				NOW(),\
				\"%s\",\
				\"%s\",\
				\"%s\" , \'%c\',%d);",pGenMsg->ActionCode,pGenMsg->BcastMsg,NSE_EXCH,EQUITY_SEGMENT,iSeqNo);

	logDebug2("sInsQry :%s:",sInsQry);

	if(mysql_query(ENMbp_con,sInsQry) != SUCCESS)
	{	
		logSqlFatal("Error in General Msg Bcast Inserting EXCH_MESGS ");
		sql_Error(ENMbp_con);
	}

	logTimestamp("EXIT [fGenMsgBcast]");	
	return TRUE;	
}


BOOL dTC_SYSTEM_INFORMATION_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_SYSTEM_INFORMATION_BCAST]");
	BOOL  ReturnValue;
	struct NNF_SYSTEM_INFO_BCAST *pPacket = (struct NNF_SYSTEM_INFO_BCAST *) NNFData;
	ReturnValue = UpdateSysInfo(pPacket);
	logTimestamp("EXIT [dTC_SYSTEM_INFORMATION_BCAST]");
	return ReturnValue;
}

BOOL UpdateSysInfo(struct NNF_SYSTEM_INFO_BCAST       *spSysInfo)
{
//	CHAR *sUpdtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
        CHAR   sUpdtQry[MAX_QUERY_SIZE];
        memset(sUpdtQry,'\0',MAX_QUERY_SIZE);

	INT16 i,iTempStatus;
	logDebug2("7206 System InfoBcast");
	for(i=1;i<=4;i++)
	{
		switch(i)
		{
			case NORMAL_MARKET :
				iTempStatus = spSysInfo->MarketStatus.Normal;

			case ODDLOT_MARKET :
				iTempStatus = spSysInfo->MarketStatus.Oddlot;

			case SPOT_MARKET:
				iTempStatus = spSysInfo->MarketStatus.Spot;

			case AUCTION_MARKET :
				iTempStatus = spSysInfo->MarketStatus.Auction;

			default :
				logDebug1(" Done with SYSTEM_INFO_BCAST ");
		}		

		sprintf(sUpdtQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d ,EMM_LUT = NOW() WHERE EMM_EXM_EXCH_ID = \"%s\"  \ 
				AND EMM_EXCH_SEG = \'%c\' AND EMM_MKT_TYPE_NO = %d",iTempStatus,NSE_EXCH,EQUITY_SEGMENT,i);

		logDebug2("sUpdtQry :%s:",sUpdtQry);

		if(mysql_query(ENMbp_con,sUpdtQry) != SUCCESS)
		{
			sql_Error(ENMbp_con);
			logSqlFatal("Error in Update Query [EXCH_MKT_MASTER] in Function UpdateSysInfo");
		}
		else
		{
			mysql_commit(ENMbp_con);
		}
		
		fUpdateMktStatus_InRedis(iTempStatus, EQUITY_SEGMENT, NSE_EXCH, i);
	}

}	


BOOL dTC_STOCK_STATUS_CHANGE_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_STOCK_STATUS_CHANGE_BCAST]");
	BOOL  ReturnValue;
	struct NNF_SECURITY_STATUS_UPDATE_BCAST *pPacket = (struct NNF_SECURITY_STATUS_UPDATE_BCAST *) NNFData;
	ReturnValue = UpdateSecStatChangeBcast(pPacket);
	logTimestamp("EXIT [dTC_STOCK_STATUS_CHANGE_BCAST]");
	return ReturnValue;
}

BOOL dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC(CHAR *NNFData)
{
        logTimestamp("ENTRY [dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC]");
        BOOL  ReturnValue;
        struct NNF_SECURITY_STATUS_UPDATE_BCAST_TNDTC *pPacket = (struct NNF_SECURITY_STATUS_UPDATE_BCAST_TNDTC *) NNFData;
        ReturnValue = UpdateSecStatChangeBcastTndtc(pPacket);
        logTimestamp("EXIT [dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC]");
        return ReturnValue;
}



BOOL UpdateSecStatChangeBcast(struct NNF_SECURITY_STATUS_UPDATE_BCAST *spSecstatchngBcast)
{
	INT16	iNoOfRec;
	LONG32	iTempToken;
	INT16	iMktType;
	CHAR	cTempStatus;
	INT16	iTempStat;
	//CHAR	*sUpdtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//CHAR	*sUptSemQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdtQry[MAX_QUERY_SIZE];
        memset(sUpdtQry,'\0',MAX_QUERY_SIZE);
        CHAR   sUptSemQ[MAX_QUERY_SIZE];
        memset(sUptSemQ,'\0',MAX_QUERY_SIZE);

	logDebug2("7320 Security Status Changed");
	for(iNoOfRec = 0;iNoOfRec < spSecstatchngBcast->NoOfRecords;iNoOfRec++)
	{
		iTempToken = spSecstatchngBcast->SecTokenAndEligibility[iNoOfRec].Token;	
		logDebug2("iTempToken [%d]",iTempToken);	
		for(iMktType = 1; iMktType <= 4;iMktType++)
		{
			iTempStat = (spSecstatchngBcast->SecTokenAndEligibility[iNoOfRec].SecEligibilityPerMkt[iMktType]).Status ;
			logDebug2(" MktType Status[%d]",iTempStat);
			if(iTempStat == 3)
			{
				cTempStatus = SEM_SECURITY_SUSPENDED;
			}
			else
			{
				cTempStatus = SEM_SECURITY_STATUS;
			}	

			sprintf(sUpdtQry,"UPDATE SECURITY_MASTER \
					SET SM_STATUS = \'%c\', \
					SM_EXCH_STATUS = \'%c\' \
					WHERE SM_SCRIP_CODE= \"%d\" \ 
					AND   SM_EXCHANGE  = \"%s\" \
					AND   SM_SEGMENT = \'%c\' ;",\
					cTempStatus,cTempStatus,iTempToken,NSE_EXCH,EQUITY_SEGMENT);
			logDebug2("sUpdtQry :%s:",sUpdtQry);

			if(mysql_query(ENMbp_con,sUpdtQry) != SUCCESS)
			{
				sql_Error(ENMbp_con);	
				logSqlFatal("ERROR IN UPDATING [SECURITY_MASTER] In Function UpdateSecStatChangeBcast");
				return FALSE;
			}	
			else
			{
				logDebug2("SUCCESS IN UPDATING SECURITY_MASTER");
				mysql_commit(ENMbp_con);
			}

			sprintf(sUptSemQ,"UPDATE SEM_ACTIVE \
					SET SM_STATUS = \'%c\',SM_EXCH_STATUS=\'%c\' \
					WHERE	SM_SCRIP_CODE = \"%d\" \
					AND SM_EXCHANGE = \"%s\" \
					AND SM_SEGMENT = \'%c\';",\
					cTempStatus,cTempStatus,iTempToken,NSE_EXCH,EQUITY_SEGMENT);	

			logDebug2("sUptSemQ :%s:",sUptSemQ);

			if(mysql_query(ENMbp_con,sUptSemQ) != SUCCESS)
			{
				sql_Error(ENMbp_con);
				logSqlFatal("ERROR IN UPDATING [SEM_ACTIVE] in function UpdateSecStatChangeBcast");
				return FALSE;
			}
			else
			{
				logDebug2("SUCCESS IN UPDATING SEM_ACTIVE");
				mysql_commit(ENMbp_con);
			}

		}
	}
	return TRUE;	

}

BOOL UpdateSecStatChangeBcastTndtc(struct NNF_SECURITY_STATUS_UPDATE_BCAST_TNDTC *spSecstatchngBcast)
{
        INT16   iNoOfRec;
        LONG32  iTempToken;
        INT16   iMktType;
        CHAR    cTempStatus;
        INT16   iTempStat;
        CHAR    sUpdtQry[MAX_QUERY_SIZE];
        CHAR    sUptSemQ[MAX_QUERY_SIZE];

        memset(sUpdtQry,'\0',MAX_QUERY_SIZE);
        memset(sUptSemQ,'\0',MAX_QUERY_SIZE);

        logDebug2("7320 Security Status Changed");
        for(iNoOfRec = 0;iNoOfRec < spSecstatchngBcast->NoOfRecords;iNoOfRec++)
        {
                iTempToken = spSecstatchngBcast->SecTokenAndEligibility[iNoOfRec].Token;
                logDebug2("iTempToken [%d]",iTempToken);
                for(iMktType = 1; iMktType <= 4;iMktType++)
                {
                        iTempStat = (spSecstatchngBcast->SecTokenAndEligibility[iNoOfRec].SecEligibilityPerMkt[iMktType]).Status ;
                        logDebug2(" MktType Status[%d]",iTempStat);
                        if(iTempStat == 3)
                        {
                                cTempStatus = SEM_SECURITY_SUSPENDED;
                        }
                        else
                        {
                                cTempStatus = SEM_SECURITY_STATUS;
                        }

                        sprintf(sUpdtQry,"UPDATE SECURITY_MASTER \
                                        SET SM_STATUS = \'%c\', \
                                        SM_EXCH_STATUS = \'%c\' \
                                        WHERE SM_SCRIP_CODE= \"%d\" \
                                        AND   SM_EXCHANGE  = \"%s\" \
                                        AND   SM_SEGMENT = \'%c\' ;",\
                                        cTempStatus,cTempStatus,iTempToken,NSE_EXCH,EQUITY_SEGMENT);
                        logDebug2("sUpdtQry :%s:",sUpdtQry);

                        if(mysql_query(ENMbp_con,sUpdtQry) != SUCCESS)
                        {
                                sql_Error(ENMbp_con);
                                logSqlFatal("ERROR IN UPDATING [SECURITY_MASTER] In Function UpdateSecStatChangeBcast");
                                return FALSE;
                        }
                        else
                        {
                                logDebug2("SUCCESS IN UPDATING SECURITY_MASTER");
                                mysql_commit(ENMbp_con);
                        }

                        sprintf(sUptSemQ,"UPDATE SEM_ACTIVE \
                                        SET SM_STATUS = \'%c\',SM_EXCH_STATUS=\'%c\' \
                                        WHERE   SM_SCRIP_CODE = \"%d\" \
                                        AND SM_EXCHANGE = \"%s\" \
                                        AND SM_SEGMENT = \'%c\';",\
                                        cTempStatus,cTempStatus,iTempToken,NSE_EXCH,EQUITY_SEGMENT);

                        logDebug2("sUptSemQ :%s:",sUptSemQ);

                        if(mysql_query(ENMbp_con,sUptSemQ) != SUCCESS)
                        {
                                sql_Error(ENMbp_con);
                                logSqlFatal("ERROR IN UPDATING [SEM_ACTIVE] in function UpdateSecStatChangeBcast");
                                return FALSE;
                        }
                        else
                        {
                                logDebug2("SUCCESS IN UPDATING SEM_ACTIVE");
                                mysql_commit(ENMbp_con);
                        }

                }
        }
        return TRUE;

}



BOOL dTC_MARKET_OPEN_MSG_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_MARKET_OPEN_MSG_BCAST]");
	BOOL  ReturnValue;
	struct NNF_MARKET_STATUS_CHANGE_BCAST *pPacket =(struct NNF_MARKET_STATUS_CHANGE_BCAST *)NNFData;
	logDebug1("_________________ MARKET OPENED __________________");

	ReturnValue = UpdateMktOpenSts(pPacket);
	logTimestamp("EXIT [dTC_MARKET_OPEN_MSG_BCAST]");

	return ReturnValue;
}

BOOL UpdateMktOpenSts(struct NNF_MARKET_STATUS_CHANGE_BCAST *spMktStsChgInfo,CHAR *cpExchId)
{
	//CHAR	*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);

	logTimestamp("6511 Mrkt Open Msg Bcast  Mkt Type :%d: ",spMktStsChgInfo->MarketType);	
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\"  WHERE EMM_MKT_TYPE_NO = %d AND EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'E\' ;",MKT_OPEN,spMktStsChgInfo->MarketType,NSE_EXCH);	

	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error in Update Query [EXCH_MKT_MASTER] in Function UpdateMktOpenSts");
	}
	else
	{
		fUpdateMktStatus_InRedis(MKT_OPEN, EQUITY_SEGMENT, NSE_EXCH, spMktStsChgInfo->MarketType);
		return TRUE;
	}
	
	
}

BOOL dTC_SECURITY_OPEN_MSG_BCAST(CHAR *NNFData)
{

	logTimestamp("ENTRY [dTC_SECURITY_OPEN_MSG_BCAST]");
	BOOL ReturnValue;
	struct  NNF_SEC_OPEN_BCAST  *pPacket = (struct  NNF_SEC_OPEN_BCAST *) NNFData;	

	ReturnValue = UpdateSecOpnMsgBcst(pPacket);
	logTimestamp("EXIT [dTC_SECURITY_OPEN_MSG_BCAST]");
	return ReturnValue;
}
BOOL UpdateSecOpnMsgBcst(struct NNF_SEC_OPEN_BCAST *pSecOpenBcast)
{
	logDebug2("6013 New security opn");
	//CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//CHAR 	*sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);
        CHAR   sInsQry[MAX_QUERY_SIZE];
        memset(sInsQry,'\0',MAX_QUERY_SIZE);
	LONG32	temptoken =0; 
	DOUBLE64 tempOpeningPrice =0;
	LONG32   MsgCode= 0;
	logDebug2("pSecOpenBcast->sHeader.iMsgCode[%d]",pSecOpenBcast->sHeader.iMsgLen);
	logDebug2("pSecOpenBcast->sHeader.iErrorCode[%d]",pSecOpenBcast->sHeader.iErrorCode);
	temptoken = pSecOpenBcast->Token;
	tempOpeningPrice  = ((DOUBLE64)pSecOpenBcast->OpeningPrice);
	MsgCode = pSecOpenBcast->sHeader.iMsgCode;
	logDebug2("New Security MsgCode [%d]",MsgCode);
	logDebug2("Token[%d]---OpeningPrice[%f]",temptoken,tempOpeningPrice );

	sprintf(sUpdQry,"UPDATE SECURITY_MASTER SET SM_STATUS = \'%c\' , SM_EXCH_STATUS  = \'%c\' WHERE SM_EXCHANGE = \"%s\" AND SM_SEGMENT = \'%c\' AND  SM_SCRIP_CODE = %d AND SM_EXCH_SCRIP_CODE = %d);",SEM_SECURITY_STATUS,SEM_SECURITY_STATUS,NSE_EXCH,EQUITY_SEGMENT,temptoken,temptoken);

	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error IN UPDATING SECURITY_MASTER in Function UpdateSecOpnMsgBcst");
		return FALSE;
	}
	logDebug2("SUCCESS IN UPDATING SECURITY_MASTER");

	sprintf(sInsQry,"INSERT INTO EQ_L1_WATCH \
			(L1_EXCHANGE ,\
			 L1_SEGMENT,\
			 L1_SCRIP_CODE ,\
			 L1_EXCH_SCRIP_CODE ,\
			 L1_MARKET_TYPE ,\
			 L1_ENTRY_TIME,\
			 L1_BID_QTY ,\
			 L1_BID_PRICE,\
			 L1_ASK_QTY,\
			 L1_ASK_PRICE,\
			 L1_TRADE_TIME,\
			 L1_LTP,\
			 L1_LTQ,\
			 L1_DAY_VOLUME,\
			 L1_NET_CHANGE,\
			 L1_ATP,\
			 L1_OPEN,\
			 L1_HIGH,\
			 L1_LOW,\
			 L1_CLOSE,\
			 L1_TOTAL_BID_QTY,\
			 L1_TOTAL_ASK_QTY,\
			 L1_UPPER_CKT,\
			 L1_LOWER_CKT)\
			 VALUES(\
					 \"%s\", \
					 \'%c\', \
					 %d,\
					 %d,\
					 \"%s\", \
					 NOW(),\
					 %d,\
					 %f,\
					 %d,\
					 %f,\
					 NOW(),\
					 round(%f,2)\
					 %f,\
					 %d,\
					 %d,\
					 %f,\
					 %f,\
					 %f,\
					 %f,\
					 %f,\
					 %d,\
					 %d,\
					 %f,\
					 %f);",NSE_EXCH,EQUITY_SEGMENT,temptoken,temptoken,MKT_TYPE_NL,0,0.00000,0,0.00000,tempOpeningPrice,0,0,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000,0,0,0.00000,0.00000);

	logDebug2("sInsQry :%s:",sInsQry);

	if(mysql_query(ENMbp_con,sInsQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("ERROR IN INSERTING [L1_WATCH] In Function  UpdateSecOpnMsgBcst");
		return FALSE;
	}
	logDebug2("SUCCESS IN INSERTING L1_WATCH");
	logTimestamp("Exit : [UpdateSecOpenBcast]");

	return TRUE;

}

BOOL dTC_MARKET_CLOSE_MSG_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_MARKET_CLOSE_MSG_BCAST]");
	BOOL  ReturnValue;
	struct NNF_MARKET_STATUS_CHANGE_BCAST *pPacket =(struct NNF_MARKET_STATUS_CHANGE_BCAST *)NNFData;
	logDebug2("_________________ MARKET CLOSED __________________");

	ReturnValue = UpdateMktCloseSts(pPacket);
	logTimestamp("EXIT [dTC_MARKET_CLOSE_MSG_BCAST]");
	return ReturnValue;
}

BOOL UpdateMktCloseSts(struct NNF_MARKET_STATUS_CHANGE_BCAST *spMktStsChgInfo)
{
	//CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdQry[MAX_QUERY_SIZE];
        CHAR   sUpdtQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);
        memset(sUpdtQry,'\0',MAX_QUERY_SIZE);
	logDebug2("6521 Mrktclose");

	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" WHERE EMM_MKT_TYPE_NO = %d AND EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'E\' ;",MKT_CLOSE,spMktStsChgInfo->MarketType,NSE_EXCH);
	//        sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' WHERE  EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'E\' ;",MKT_CLOSE,NSE_EXCH);

	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error in Update Query [EXCH_MKT_MASTER] Function UpdateMktCloseSts");
	}
	else
	{
		if (iPostCloseMKTStatus == 1)
                {
			sprintf(sUpdtQry,"UPDATE BATCH_PROCESS SET BP_OFF_MKT_STATUS = \'%c\' ,BP_UPDATED_BY = \"SYSTEM\" WHERE BP_EXCH_ID = \"%s\" \
                        	AND BP_BATCH_NAME = \"OFFMKT_PUMP\" AND BP_SEGMENT = \'%c\' ;",NO,NSE_EXCH,EQUITY_SEGMENT);

		        	logDebug2("sUpdtQry :%s:",sUpdtQry);

       			if(mysql_query(ENMbp_con,sUpdtQry) != SUCCESS)
        		{
           			sql_Error(ENMbp_con);
        		}
        		else
        		{
                		mysql_commit(ENMbp_con);
        		}
		}
			fUpdateMktStatus_InRedis(MKT_CLOSE, EQUITY_SEGMENT, NSE_EXCH, spMktStsChgInfo->MarketType);
			return TRUE;
	}
}

BOOL dTC_PREOPEN_SHUTDOWN_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_PREOPEN_SHUTDOWN_BCAST]");
	BOOL  ReturnValue;
	struct NNF_MARKET_STATUS_CHANGE_BCAST *pPacket = (struct NNF_MARKET_STATUS_CHANGE_BCAST *) NNFData;

	logInfo(" _________________ PREOPENSHUTDOWNRECEIVED _____________");
	ReturnValue = UpdatePrePostSts(pPacket);
	logTimestamp("EXIT [dTC_PREOPEN_SHUTDOWN_BCAST]");
	return ReturnValue;
}

BOOL UpdatePrePostSts(struct  NNF_MARKET_STATUS_CHANGE_BCAST   *spMktStsChgInfo, CHAR *cpExchId)
{
	//CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	logDebug2("6531 PreOpen ShutDown");
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" WHERE EMM_MKT_TYPE_NO = %d AND EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'E\' ;",MKT_PREOPEN,spMktStsChgInfo->MarketType,NSE_EXCH);

	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error in [UPDATE EXCH_MKT_MASTER] In function UpdatePrePostSts");	
		return FALSE;	
	}
	else
	{
		
		fUpdateMktStatus_InRedis(MKT_PREOPEN, EQUITY_SEGMENT, NSE_EXCH, spMktStsChgInfo->MarketType);
		return TRUE;
	}
	
}

BOOL dTC_PRE_OPEN_ENDED_MSG_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_PRE_OPEN_ENDED_MSG_BCAST]");
	BOOL  ReturnValue;
	struct NNF_MARKET_STATUS_CHANGE_BCAST *pPacket =(struct NNF_MARKET_STATUS_CHANGE_BCAST *)NNFData;

	logInfo(" __________________ PREOPENeNDEDRECEIVED _______________");
	ReturnValue = UpdatePreOpenEndSts(pPacket);
	logTimestamp("EXIT [dTC_PRE_OPEN_ENDED_MSG_BCAST]");
	return ReturnValue;
}

BOOL UpdatePreOpenEndSts(struct  NNF_MARKET_STATUS_CHANGE_BCAST   *spMktStsChgInfo)
{
//	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	logDebug2("6571 Preopen Ended MsgBcast");
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" WHERE EMM_MKT_TYPE_NO = %d AND EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'E\' ;",MKT_CLOSE,spMktStsChgInfo->MarketType,NSE_EXCH);

	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error in UPDATE [EXCH_MKT_MASTER] In Function UpdatePreOpenEndSts");
	}
	else
	{
		fUpdateMktStatus_InRedis(MKT_CLOSE, EQUITY_SEGMENT, NSE_EXCH, spMktStsChgInfo->MarketType);
		return TRUE;
	}
}


BOOL dTC_POSTCLOSE_BCAST(CHAR *NNFData)
{
	logTimestamp ("ENTRY [dTC_POSTCLOSE_BCAST]");
	BOOL  	ReturnValue;
	LONG32  Tcode = 0;
	struct NNF_MARKET_STATUS_CHANGE_BCAST *pPacket =(struct NNF_MARKET_STATUS_CHANGE_BCAST *)NNFData;
	logInfo(" _________________ POSTCLOSE BCAST RECEIVED _________________");
	logInfo(" ~~~~~~~~~~~~~~~~~ TRANSCODE IS:       %4d ~~~~~~~~~~~~~~~~~",pPacket->sHeader.iMsgCode);
	Tcode = pPacket->sHeader.iMsgCode;

	ReturnValue = UpdatePostCloseSts(pPacket);
	logTimestamp("EXIT [dTC_POSTCLOSE_BCAST]");
	return ReturnValue;
}

BOOL UpdatePostCloseSts(struct NNF_MARKET_STATUS_CHANGE_BCAST *spMktStsChgInfo)
{
	LONG32	iTransCode ;
	//CHAR 	*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR   sUpdQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);
        CHAR   sUpdtQry[MAX_QUERY_SIZE];
        memset(sUpdtQry,'\0',MAX_QUERY_SIZE);
	iTransCode = spMktStsChgInfo->sHeader.iMsgCode;
	LONG32	iOpenCloseSts ;

	switch(iTransCode)
	{
		case TC_POST_CLOSING_START_BCAST:
			iOpenCloseSts = MKT_POSTCLOSE;	

			break;
		case TC_POST_CLOSING_END_BCAST:
			iOpenCloseSts = MKT_CLOSE;	

			break;
		default:
			logFatal(" Invalid TransCode Received in PostClose Bcast");
			return FALSE;
	}

	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" WHERE EMM_MKT_TYPE_NO = %d AND EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'E\' ;",iOpenCloseSts,spMktStsChgInfo->MarketType,NSE_EXCH);

	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error in UPDATE EXCH_MKT_MASTER in Function UpdatePostCloseSts");
		return FALSE;	
	}
	else
	{
		logDebug2("Row Updated :%d:",mysql_affected_rows(ENMbp_con));
		mysql_commit(ENMbp_con);
	
			if(iTransCode == TC_POST_CLOSING_END_BCAST)	
			{
				sprintf(sUpdtQry,"UPDATE BATCH_PROCESS SET BP_OFF_MKT_STATUS = \'%c\' ,BP_UPDATED_BY = \"SYSTEM\" WHERE BP_EXCH_ID = \"%s\" \
                        		AND BP_BATCH_NAME = \"OFFMKT_PUMP\" AND BP_SEGMENT = \'%c\' ;",YES,NSE_EXCH,EQUITY_SEGMENT);

                        		logDebug2("sUpdtQry :%s:",sUpdtQry);

                		if(mysql_query(ENMbp_con,sUpdtQry) != SUCCESS)
                		{
                        		sql_Error(ENMbp_con);
                		}
                		else
                		{
                        		mysql_commit(ENMbp_con);
                		}
			}
		
		fUpdateMktStatus_InRedis(iOpenCloseSts, EQUITY_SEGMENT, NSE_EXCH, spMktStsChgInfo->MarketType);
		return TRUE;

	}

}


/*******************************************************
  Function Name : fConvertBookToMkt

Parameters    : SHORT BookType

Functionality : Converts book type passed to into a mkt type

Return Values : True/False
 *******************************************************/

SHORT fConvertBookToMkt(SHORT iBookType)
{
	INT16 iMkt;

	switch (iBookType)
	{
		case REGULAR_LOT_BOOK:

		case SPECIAL_TERMS_BOOK:

		case STOP_LOSS_BOOK:

			iMkt = NORMAL_MARKET;
			break;

		case ODD_LOT_BOOK:

			iMkt = ODDLOT_MARKET;
			break;

		case SPOT_LOT_BOOK:

			iMkt = SPOT_MARKET;
			break;

		case AUCTION_BOOK:

			iMkt = AUCTION_MARKET;
			break;

		default:
			iMkt = 0;
	}
	return iMkt;
}



/*******************************************************
  Function Name   : fCheckSpaces
Parameters              : CHAR          *ChkStr,
LONG32        Len
Functionality   : Checks if any spaces are there in a given string
Return Values   : If space, then True else False
 *******************************************************/

BOOL fCheckSpaces( CHAR *cChkStr,LONG32 iLen)
{
	BOOL	 iAllSpace = TRUE	;
	LONG32   i			;

	for(i=0; i < iLen ;i++)
	{
		if (cChkStr[i] != SPACE)
		{
			iAllSpace = FALSE ;
			return iAllSpace  ;
		}

	}
	return iAllSpace;
}

fChkNOpenEquNseMkt ( struct NNF_MBP_BCAST *pMBP_Info)
{

	INT16 iCurSessnId		;
	SHORT iMktSessnId		;

	CHAR  statement[200];
	CHAR  cMktType[MARKET_LEN]	;

	logInfo(" Checking for Market Open ....");

	memset(cMktType,' ',MARKET_LEN);
	//CHAR	*sMktUpdate = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
        CHAR   sMktUpdate[MAX_QUERY_SIZE];
        memset(sMktUpdate,'\0',MAX_QUERY_SIZE);

	//	strncpy ( cMktType,MKT_TYPE_NL,MKT_TYPE_LEN);

	sprintf(sMktUpdate,"SELECT EMM_STATUS FROM EXCH_MKT_MASTER WHERE EMM_EXM_EXCH_ID = 'NSE' AND EMM_MKT_TYPE = \"%s\" AND EMM_EXCH_SEG = 'E'",MKT_TYPE_NL);

	if(mysql_query(ENMbp_con,sMktUpdate) != SUCCESS)
	{
		sql_Error(ENMbp_con);
		logSqlFatal("Error in SELECT EMM_STATUS in Function fChkNOpenEquNseMkt");
	}

	MYSQL_RES *result = mysql_store_result(ENMbp_con);

	MYSQL_ROW row = mysql_fetch_row(result);

	iCurSessnId = atoi(row[0]);

	mysql_free_result(result);

	printf("\n Market Status in the DB :%d: CURRENT Mkt Status :%d:\n",iCurSessnId,pMBP_Info->pMBPInfo[1].iTradingStatus);

	if( iCurSessnId != 1 )
	{
		iCurSessnId = 1;


		sprintf(sMktUpdate,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d , EMM_UPDATE_BY= \"SYSTEM\", EMM_UPDATE_DATE=NOW() WHERE EMM_EXM_EXCH_ID = 'NSE'",iCurSessnId);	


		if(mysql_query(ENMbp_con,sMktUpdate) != SUCCESS)
		{
			sql_Error(ENMbp_con);
			logSqlFatal("Error in UPDATE EXCH_MKT_MASTER In Function fChkNOpenEquNseMkt");
		}
		else
		{
			mysql_commit(ENMbp_con);
		}

	}	
	free(sMktUpdate);
	fUpdateMktStatus_InRedis(iCurSessnId, EQUITY_SEGMENT, NSE_EXCH, NORMAL_MARKET);	
}

SHORT   fTrim( CHAR * cStr_In ,SHORT iMaxLen )
{
	SHORT iStrlen=0;

	if ( iMaxLen <= 0 )
	{
		return FALSE ;
	}

	for( ; cStr_In[iStrlen] != ' ' && iStrlen < iMaxLen ; iStrlen++ )
	{
		continue;
	}
	cStr_In[iStrlen]='\0';
	return iStrlen  ;
}


BOOL fLoadDBNseEnv ()
{
	logTimestamp("Entry : [fLoadDBNseEnv}");
	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;
	CHAR sQry [MAX_QUERY_SIZE];

	memset(sNCmBrokerId,'\0',5);	
	memset(sQry,'\0',MAX_QUERY_SIZE);
	sprintf(sQry,"select EAM_BROKER_ID from EXCH_ADMINISTRATION_MASTER\
			where EAM_EXM_EXCH_ID = \"%s\" and EAM_SEGMENT = \'%c\';",NSE_EXCH,EQUITY_SEGMENT);
	logDebug2("Qry = %s",sQry);

	if (mysql_query(ENMbp_con, sQry) != SUCCESS)
	{
		logDebug2("here 1");
		logSqlFatal("Error in select Qry");
		sql_Error(ENMbp_con);
	}

	logDebug2("here 2");
	Res = mysql_store_result(ENMbp_con);
	logDebug2("here 3");

	if((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] :%s:",Row[0]);
		strncpy(sNCmBrokerId,Row[0],5);
		logDebug2("sNCmBrokerId  :%s:",sNCmBrokerId);

	}
	mysql_free_result(Res);
	logTimestamp("EXIT  : [fLoadDBNseEnv}");

}


BOOL LoadNseEnv()
{
	logTimestamp("Entry : [LoadNseEnv]");
	
	CHAR    sPostCloseMKTStatus     [ENV_VARIABLE_LEN];
        memset(sPostCloseMKTStatus,'\0',ENV_VARIABLE_LEN);

	/*
	if(getenv("NSE_CM_BROKER")== NULL)
	{
		logFatal("Error : Environment variables missing : NSE_CM_BROKER");
	}
	else
	{
		//                sNCmBrokerId = atoi(getenv("NSE_CM_BROKER"));
		strncpy(sNCmBrokerId,(getenv("NSE_CM_BROKER")),5);
		logDebug2("sNCmBrokerId  :%s:",sNCmBrokerId);

	}
	*/

	if (getenv("POST_CLOSE_MKT_STATUS")== NULL){
		
		logFatal("Error : Environment variables missing : POST_CLOSE_MKT_STATUS");
		iPostCloseMKTStatus = 1;	
	
	}
	else{
		strncpy(sPostCloseMKTStatus,getenv("POST_CLOSE_MKT_STATUS"),ENV_VARIABLE_LEN);
		iPostCloseMKTStatus = atoi (sPostCloseMKTStatus);
	}
	logTimestamp("Exit : [LoadNseEnv]");
}
