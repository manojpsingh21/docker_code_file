#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/msg.h>


#define	CALLING_LENS 20
#define	TRUE	1
#define	FALSE	0
#define    NSE_MAX_PACKET_RECV_SIZE     1050


char sMultiCastIp[CALLING_LENS];
char sSendIp[CALLING_LENS];
int  iMulticastPort,iSendPort;
int	iSocketFD;
int	sockfdBroad;

struct sockaddr_in serv_addr;

void ReceiveReplyPacketsBcast( int iSocketFD , char *bcastaddress , int portno)
{

	char            *recvgen;
	int             recv_bytes = 0;
	int             clilen= 0;

	recvgen = (char *)malloc(sizeof(char)*NSE_MAX_PACKET_RECV_SIZE);
	clilen = sizeof(struct sockaddr);

	while(1)
	{
		recv_bytes = 0;
		memset(recvgen,' ',NSE_MAX_PACKET_RECV_SIZE);

		if ((recv_bytes = recvfrom(iSocketFD,recvgen,NSE_MAX_PACKET_RECV_SIZE,0,(struct sockaddr *)&serv_addr,&clilen)) < 0 )
		{
			printf("Unable to receive the data from iSocketFD, id:%d\n",iSocketFD);
			break;
		}
		else
		{
			SendBroadcast(recvgen,NSE_MAX_PACKET_RECV_SIZE,sSendIp,iSendPort);
		}
	}

}



int main(int argc,char **argv)
{

	int iRecvVal = 0;
	setbuf(stdout,0);



	if ( argc != 5 )
	{
		printf("Argument Mismstch \n");
		printf("BcastFrwd <MulticastIP> <MulticastPortNo> <SendIP> <SendPort>\n");
		exit(0);
	}


	memset(sMultiCastIp,'\0',CALLING_LENS);
	strncpy(sMultiCastIp,argv[1],CALLING_LENS);

	memset(sSendIp,'\0',CALLING_LENS);
	strncpy(sSendIp,argv[3],CALLING_LENS);

	iMulticastPort= 0 ;
	iSendPort = 0;	

	iMulticastPort= atoi(argv[2]) ;
	iSendPort = atoi(argv[4]);	


	printf("_____________________________P A R A M E T E R E S____________________________\n");

	printf("sMultiCastIp		is  : %s \n",sMultiCastIp);
	printf("iMulticastPort	is  : %d \n",iMulticastPort);
	printf("sSendIp		is  : %s \n",sSendIp);
	printf("iSendPort		is  : %d \n",iSendPort);

	printf("_________________________________________________________________________________ \n");	


	for ( ; ; )
	{

		iRecvVal=OpenRecvSocket(&iSocketFD, iMulticastPort, sMultiCastIp);

		if (iRecvVal == 0)
		{
			printf("Error in fuction OpenSocket ....Exiting\n");
			exit(1);
		}

		printf("iSocketFD = [%d]\n",iSocketFD);



		printf("Connection to NSE Broadcast Circuit successful\n");
		ReceiveReplyPacketsBcast(iSocketFD,sSendIp,iSendPort);
	}	


}


int  OpenRecvSocket(int *sockfd, int port, char *IPaddr)
{
	int sfd;
	int optval=1;
	int val=1;
	u_char ttl = 1;
	struct ip_mreq mreq;
	printf("IPaddr = [%s]\n",IPaddr);
	printf("port   = [%d]\n",port);
	u_int yes=1;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket\n");
		exit(0);
	}

	if (setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes)) < 0)
	{
		perror("Reusing ADDR failed\n");
		exit(1);
	}

	printf("Socket Id is %d\n",sfd);

	serv_addr.sin_family     = AF_INET;
	serv_addr.sin_addr.s_addr= htonl(INADDR_ANY);
	serv_addr.sin_port       = htons(port);

	if(bind(sfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
	{
		perror("Failed to bind the port\n");
		close(sockfd);
		return FALSE;
	}


	mreq.imr_multiaddr.s_addr=inet_addr(IPaddr);
	mreq.imr_interface.s_addr=htonl(INADDR_ANY);

	if (setsockopt(sfd,IPPROTO_IP,IP_ADD_MEMBERSHIP,&mreq,sizeof(mreq)) < 0)
	{
		perror("setsockopt\n");
		exit(1);
	}

	if (( val = setsockopt(sfd,IPPROTO_IP,IP_MULTICAST_TTL,&ttl,sizeof(ttl) ) ) < 0 )
	{
		perror("OpenSocket: Error in setsockopt for Multicast socket\n");
	}

	*sockfd = sfd;
	printf("Socket Id is %d\n",*sockfd);

	if (val < 0)
		return FALSE;
	else
		return TRUE;
}


int  SendBroadcast(char *cpMsgBuf,int MsgLen,char *bcastaddress,int portno)
{
	struct     sockaddr_in cli_addr ;
	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(bcastaddress);
	cli_addr.sin_port           = htons(portno);

	printf("SENDING BROADCAST IP [%s] PORT [%d]\n",bcastaddress,portno);

	if(sendto(sockfdBroad,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr))< 0)
	{
		perror("Server : Error in Sending\n");
		return FALSE;
	}

	return TRUE;
}
