#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

redisContext *c;
redisContext *c1;
redisReply *reply;
redisReply *reply1;
MYSQL   *ENMbp_con;

main(int argc,char **argv)
{
	setbuf(stdout,0);
	logTimestamp("ENTRY [Main]");
	c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	c1 = RDConnect(REDIS_TYPE_PRICE_BCAST);
	ENMbp_con=DB_Connect();
	ReceiveReplyPacketsBcast();
	return 0;
	logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
	logTimestamp("ENTRY [UPDATE LTP IN DB]");
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN]; 
	BOOL flag;
	int count=0;
	int iCount ;
	CHAR sKeyValue[RADIS_KEY_LEN];
	DOUBLE64   fTempLtp=0.00;
	LONG32          iTempScripCode =0 ,iMsgCode;
	CHAR    NormlMkt [MKT_TYPE_LEN];
	CHAR	sExch [10];
	CHAR	cSegment;
	CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sUpdateQry[MAX_QUERY_SIZE];
	CHAR    supdate [MAX_QUERY_SIZE];

	while(TRUE)
	{
		memset(sCommand,'\0',COMMAND_LEN);
		sprintf(sCommand,"SUBSCRIBE OMSNSECM");
		logDebug2("sCommand -> %s",sCommand);
		reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
		logDebug2("INCR counter: %lld", reply->integer);
		while(redisGetReply(c,(void**)&reply) == REDIS_OK) 
		{
			logTimestamp("Recive Publish Key");		
			memset(sInsertQry,'\0',MAX_QUERY_SIZE);
			memset(supdate,'\0',MAX_QUERY_SIZE);
			memset(sUpdateQry,'\0',MAX_QUERY_SIZE);
			if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3) 
			{
				logDebug2("Error:  Malformed subscribe response!");
				//exit(-1);
				continue;
			}

			logDebug2("Channel: %s", reply->element[1]->str);
			logDebug2("Received message: %s", reply->element[2]->str);
			sprintf(sKeyValue,"%s",reply->element[2]->str);
			freeReplyObject(reply);

			memset(sCommand1,'\0',COMMAND_LEN);				
			sprintf(sCommand1,"TTL %s",sKeyValue);
			logTimestamp("sCommand1 -> %s",sCommand1);
			reply = fRedisCommand(c1,sCommand1,REDIS_TYPE_PRICE_BCAST);		
			logDebug2("INCR counter: %lld", reply->integer);

			if(reply->integer != 0 && reply->integer != -2)
			{
				memset(sCommand,'\0',COMMAND_LEN);
				sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT ",sKeyValue);
				logTimestamp("sCommand -> %s",sCommand);
				reply1 = fRedisCommand(c1,sCommand,REDIS_TYPE_PRICE_BCAST);
				iCount = reply1->elements;
				logDebug2("ELEMENT COUNT =%d ",iCount);
				logDebug2("Received message LTP : %s", reply1->element[0]->str);
				logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
				logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
				logDebug2("Received message EXCH: %s", reply1->element[3]->str);
				logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
				logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
				if(reply1->element[0]->str != NULL)
				{
					fTempLtp = atof(reply1->element[0]->str);
					iTempScripCode = atoi(reply1->element[1]->str);
					iMsgCode = atoi(reply1->element[4]->str);
					sprintf(NormlMkt,"%s",reply1->element[2]->str);	

					sprintf(sUpdateQry,"UPDATE EQ_L1_WATCH SET L1_LTP = %lf,L1_MARKET_TYPE = \"%s\" ,L1_LUT = NOW() WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \"%d\";",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);


					logTimestamp("sUpdateQry Query[%s]",sUpdateQry);
					if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
					{
						logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
						sql_Error(ENMbp_con);
					}
					else
					{
						logDebug2("------SUCCESS IN INSERT QUERY-----");
						if(mysql_affected_rows(ENMbp_con) == 0)
						{
							sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
									(L1_EXCHANGE ,\
									 L1_SEGMENT,\
									 L1_SCRIP_CODE,\
									 L1_EXCH_SCRIP_CODE,\
									 L1_MARKET_TYPE,\
									 L1_ENTRY_TIME,\
									 L1_LTP )\
									VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf)",NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);
							logTimestamp("sInsertQry :%s:",sInsertQry);
							if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
							{
								logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
								sql_Error(ENMbp_con);
							}
						}
						mysql_commit(ENMbp_con);


					}

					sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f ,L1_MARKET_TYPE = \"%s\" ,L1_LUT = NOW() WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =\"%d\" ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);

					logTimestamp(" Update Query[%s]",supdate);

					if(mysql_query(ENMbp_con,supdate) != SUCCESS)
					{
						logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
						sql_Error(ENMbp_con);
					}
					else
					{
						mysql_commit(ENMbp_con);

						logDebug2("------SUCCESS IN LTP UPDATE-----");
						logDebug2("TempScripCode :%d:",iTempScripCode);
						logDebug2(" LTP [%lf]",fTempLtp);
					}
				}
				freeReplyObject(reply1);
			}
			freeReplyObject(reply);


		}
		logError("Redis connection dropped, trying to reconnnect again");
		sleep(5);
		c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	}
	logTimestamp("EXIT [UPDATE LTP IN DB]");
}
