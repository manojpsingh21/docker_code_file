#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <time.h>
#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include "IntTCodes.h"
#include <sys/types.h>
#include <sys/stat.h>
//nclude "hiredis/async.h"


BOOL 	fOpenMessageQ()		;
BOOL 	fSplitter()		;


LONG32  iBcastToSplterQ 	;
LONG32  iSplitterToMbpQ 	;
LONG32  iBcastToIndexQ 		;
LONG32  iBcastToMStatQ 		;
LONG32  iBOTradeSvrToPumper 	;

int GetQStatus( int MsgQuery);

int GetQStatus( int MsgQuery);


main(int argc,char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin,NULL);
	
	fOpenMessageQ();
	fSplitter();
}

BOOL fSplitter()
{
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR	sSbdMsg[LOCAL_MAX_PACKET_SIZE]	;
	struct  NNF_HEADER *pRespHeader		;
	INT16	iMsgCode			;
	INT16	iMsgLen				;
	CHAR    tempflag= FALSE 		;	
	LONG32  counter = 0             	;
	LONG32  status = TRUE   		;
	
	while(TRUE)
	{
		memset( &sRcvMsg,'\0',LOCAL_MAX_PACKET_SIZE);
		memset( &sSbdMsg,'\0',LOCAL_MAX_PACKET_SIZE);
		iMsgCode = 0;

		logDebug2("#########Waiting in while loop to get the data ################# %d",iBcastToSplterQ);
		// changes by @pratik reading from msgtyp 1
		if((ReadMsgQ( iBcastToSplterQ, &sRcvMsg, LOCAL_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			logDebug2("ENBcastSplitteespHeaderead Q :Qid %d", iBcastToSplterQ);
			exit(ERROR);
		}
		logDebug2("This is core ");	

		pRespHeader =(struct NNF_HEADER *) &sRcvMsg ;

		logTimestamp("iMsgCode:%d: iMsgLen:%d:",pRespHeader->iMsgCode,pRespHeader->iMsgLen);
		iMsgCode = pRespHeader->iMsgCode;
		iMsgLen = pRespHeader->iMsgLen;

		logDebug2("iMsgCode :%d: iMsgLength :%d:",iMsgCode,iMsgLen);

		switch (iMsgCode)
		{
			case TC_MBP_BCAST	:
			case TC_MBP_BCAST_TNDTC	:
/***			case TC_AUCTION_INQUIRY_MSG :				
			case TC_CALL_AUCTION_MBP :
			case TC_AUCTION_STATUS_CHNG :				
			case TC_MBO_MBP_UPDATE_BCAST :***/
/****/
				status = GetQStatus (iSplitterToMbpQ);
//				if(WriteMsgQ( iSplitterToMbpQ, &sRcvMsg, iMsgLen ,1) != TRUE)
/****
 * 	This was commented bcoz of the A2 broadcast as A2 bcast comes in 7241
				if ( status == FALSE)
				{
					logInfo("iSplitterToMbpQ Queue is Full with 90%  MsgType 2");
				}
				else
				{
					if(WriteMsgQ( iSplitterToMbpQ, &sRcvMsg, iMsgLen ,1) != TRUE)
					{
						perror("Error WriteQ: ");
						logDebug2("Write Q id %d", iSplitterToMbpQ);
						exit(ERROR);
					}
				}
****/
				break; 	

			case TC_TICKER_INDEX_BCAST:
			case TC_TICKER_INDEX_BCAST_TNDTC:
			case TC_CALL_AUCTION_MBP :
			case TC_CALL_AUCTION_MBP_TNDTC :
				status = GetQStatus (iSplitterToMbpQ);//queue status check ,if queue is 90% it stop sending packets to NseCMMBPUdr @Abhishek-13Jun2019
		                if ( status == FALSE)
        		        {
                			tempflag = TRUE;
                			counter++;
                			logDebug2("QUEUE IS 90% FULL");                          
                		}
				else
				{
					if(WriteMsgQ( iSplitterToMbpQ, &sRcvMsg, iMsgLen ,1) != TRUE)
					{	
						perror("Error WriteQ: ");
						logDebug2("Write Q id %d", iSplitterToMbpQ);
						exit(ERROR);
					}
				}
				/*				
								if(WriteMsgQ( iBOTradeSvrToPumper, &sRcvMsg, iMsgLen ,1) != TRUE)
								{
								perror("Error WriteQ: ");
								logDebug2("Write Q id %d", iBOTradeSvrToPumper );
								exit(ERROR);
								}
				 */

				break;

			case TC_MULTIPLE_INDEX_BCAST:

				if(( WriteMsgQ( iBcastToIndexQ ,&sRcvMsg,iMsgLen ,1 ) != TRUE ))
				{
					perror("Error WriteQ: ");
					logDebug2("Write Q id %d",iBcastToIndexQ);
					exit(ERROR);
				}

				break;

			case TC_GENERAL_MSG_BCAST:
			case TC_SYSTEM_INFORMATION_BCAST:
			case TC_STOCK_STATUS_CHANGE_BCAST:
			case TC_STOCK_STATUS_CHANGE_BCAST_TNDTC:
			case TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST:
			case TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST_TNDTC:
			case TC_MARKET_OPEN_MSG_BCAST:
			case TC_MARKET_CLOSE_MSG_BCAST:
			case TC_PREOPEN_SHUTDOWN_BCAST:
			case TC_PRE_OPEN_ENDED_MSG_BCAST:
				//                      case TC_MKT_STATS_RPT_BCAST:
			case TC_POST_CLOSING_START_BCAST:
			case TC_POST_CLOSING_END_BCAST:
			case TC_SECURITY_OPEN_MSG_BCAST:		
			case TC_STOCK_DETAILS_CHANGE_BCAST:
			case TC_STOCK_DETAILS_CHANGE_BCAST_TNDTC:
				if(iMsgLen > 0)
				{
					if(( WriteMsgQ( iBcastToMStatQ ,&sRcvMsg,iMsgLen ,1 ) != TRUE ))
					{
						perror("Error WriteQ: ");
						logDebug2("Write Q id %d", iBcastToMStatQ);
						exit(ERROR);
					}
					logDebug2("WRITTEN ON QUEUE iMsgCode :%d: iMsgLength :%d:",iMsgCode,iMsgLen);
				}
				break;
			default:

				logDebug2("INVALID  iMsgCode :%d:",iMsgCode);
				break;

		}

	}
}


BOOL fOpenMessageQ()
{
	// Opening And Reading from  MemMap Queue @Nitish
	// change by @pratik from removing MemoryMap
	if( ( iBcastToSplterQ = OpenMsgQ( (ENBAdapToSpltr))) == ERROR )
	{
		perror("Open EQU_NSE_BCAST_QUEUE :");
		exit( 1 );
	}
	if( ( iSplitterToMbpQ = OpenMsgQ( (ENBSpltrToMbpUpld ))) == ERROR )
	{
		perror("Open BcasttoMbpMbo :");
		exit( 1 );
	}
	if( ( iBcastToIndexQ = OpenMsgQ( (ENBSpltrToIndxUpld ))) == ERROR )
	{
		perror("Open iBcasttoIndex :");
		exit( 1 );
	}
 	if( ( iBcastToMStatQ = OpenMsgQ( (ENBSpltrToMStatUpld ))) == ERROR )
	{
		perror("Open iBcasttoIndex :");
		exit( 1 );
	}
	if( ( iBOTradeSvrToPumper = OpenMsgQ( (BOTradeSvrToPumper))) == ERROR )
	{
		perror("Open iBOTradeSvrToPumper :");
		exit( 1 );
	}

	//logDebug2("Queue Openend iBcasttoSplitterQ :%d: iSplittertoMbpQ:%d: iBcasttoIndex:%d:  iBcasttoMktStatus:%d: iBOTradeSvrToPumper :%d: ",iBcastToSplterQ,iSplitterToMbpQ,iBcastToIndexQ,iBcastToMStatQ,iBOTradeSvrToPumper );
	logDebug2("Queue Openend iBcasttoSplitterQ :%d: iSplittertoMbpQ:%d: iBcasttoIndex:%d: iBOTradeSvrToPumper :%d: ",iBcastToSplterQ,iSplitterToMbpQ,iBcastToIndexQ,iBOTradeSvrToPumper );
	return TRUE;

}/**** End of OpenMsgQ****/
//function for checking queue status @abhishek-13Jun2019
int GetQStatus( int MsgQuery)
{
        struct msqid_ds sStatQ;
        DOUBLE64        checkbytes = 0.0;

        if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
        {
                checkbytes      =       (sStatQ.msg_qbytes * 0.066);



                if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
                {
                        logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
                        return FALSE ;
                }
                else
                {
                        return TRUE ;
                }
        }

}


	
