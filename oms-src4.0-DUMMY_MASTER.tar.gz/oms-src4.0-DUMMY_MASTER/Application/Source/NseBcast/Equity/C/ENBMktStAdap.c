#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/msg.h>
/**#define TWIDDLE(A)      			Twiddle ((char *) &A, sizeof(A))*****/
/*
#define RECV(SOCKFD,MSG)                       	tcpRecv(SOCKFD,MSG )
#define CONNECT( CALLADDRESS , CALLDATA)       	tcpConnect(CALLDATA,(CALLADDRESS))
 */


extern BOOL  TwiddleNseBroad(CHAR * pMem);

LONG32 sockfd1,sockfdBroad,sockfdMulti; 

LONG32 iStartupTime;

BOOL  OpenBcastSocket();
BOOL 	SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *calladdress,LONG32 portno);
BOOL 	SendMulticast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *calladdress,LONG32 portno);
BOOL OpenMultiSocket(LONG32 *sockfd, LONG32 port, CHAR *IPaddr,CHAR *sRecvIP);
void   ReceiveReplyPacketsBcast( LONG32 sockfd1);//, CHAR *bcastaddress, LONG32 portno,CHAR *,LONG32);
/**void   Twiddle(void *,SHORT);****/
BOOL OpenMulticastSocket();
BOOL OpenSocket(CHAR ServiceType,LONG32 *sockfd);
//int GetQStatus( int MsgQuery);
struct sockaddr_in serv_addr;

#pragma pack(1)
struct BcastMultiPkts
{
	char    cNetId[2];
	short   iNoPackets;
	char    cPacketData[508];
};
#pragma pack

#pragma pack(1)
struct  BcastRecord
{
	short   iCompLen;
	char    cCompData[512];
};
#pragma pack
CHAR bcastaddress[CALLING_LENS];
CHAR sBackOffIP[CALLING_LENS];
CHAR sBackOffPort[CALLING_LENS];
CHAR sMultitInterfIP[CALLING_LENS];
LONG32	iBackOffPort = 0;
CHAR bcastMDS [CALLING_LENS];
LONG32 portno,mportno,iBcastRecvPort;
FILE *fpReadFile,*fpWriteFile;	
CHAR   dumpFileName[20];
CHAR   dumpFileName1[20];
CHAR readflg, WriteFlag;


LONG32	iITSENport,iITSIDXport;
LONG32	iAnlyENport,iAnlyIDXport;
LONG32 	iMDSENport;
CHAR 	sStartFlag[2] ;
CHAR 	sBckOffFlag[2];


main(LONG32 argc,CHAR **argv)
{ 
	struct sockaddr_in cli_addr; 
	LONG32	val;
	CHAR    temp;
 	CHAR  service;
	CHAR sBcastRecvIP[CALLING_LENS];
	LONG32 RecvPort;
	LONG32 flag	;
	LONG32 RecvVal	;	
	CHAR sRecvIP[CALLING_LENS];
	char mport[10];
	char mbpport[10];
	CHAR mcastaddress[CALLING_LENS];
	CHAR sTempPort[10];	
	CHAR sMDSTempPort [10];	
	memset(sMDSTempPort,'\0',10);
	setbuf(stdout,0);
	
	if(getenv("BACKOFF_SERVER_IP")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_SERVER_IP");
		exit(ERROR);
	}
	else
	{
		strcpy ( sBackOffIP , getenv("BACKOFF_SERVER_IP"));
		logDebug2("sBackOffIP :%s:",sBackOffIP);
	}
	if(getenv("BACKOFF_NEQ_PORT")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_NEQ_PORT");
		exit(ERROR);
	}
	else
	{
		strcpy ( sBackOffPort, getenv("BACKOFF_NEQ_PORT"));
		logDebug2("sBackOffPort :%s:",sBackOffPort);
		iBackOffPort = atoi(sBackOffPort);
	}
	if(getenv("SEND_EQ_BCAST_TO_ANALYTIC_SERVER")==NULL)
	{
		logFatal("Error : Environment variables missing : SEND_EQ_BCAST_TO_ANALYTIC_SERVER");
		exit(ERROR);
	}
	else
	{
		strcpy(sStartFlag,getenv("SEND_EQ_BCAST_TO_ANALYTIC_SERVER"));
		logDebug2("sStartFlag	:%s:",sStartFlag);
	}
	if(getenv("ANALYTIC_SERVER_IP")==NULL)
	{
		logFatal("Error : Environment variables missing : ANALYTIC_SERVER_IP");
		exit(ERROR);
	}
	else
	{
		strcpy( bcastMDS ,getenv("ANALYTIC_SERVER_IP"));
		logDebug2("bcastMDS :%s:",bcastMDS);
	}
	if(getenv("BACKOFF_BCAST_FLAG")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_BCAST_FLAG");
		exit(ERROR);
	}
	else
	{
		strcpy(sBckOffFlag,getenv("BACKOFF_BCAST_FLAG"));
		logDebug2("sBckOffFlag	:%s:",sBckOffFlag);
	}
	if(getenv("ANALY_NSE_EQ_PORT")==NULL)
	{
		logFatal("Error : Environment variables missing : ANALY_NSE_EQ_PORT");
		exit(ERROR);
	}
	else
	{	
		strcpy(sMDSTempPort,getenv("ANALY_NSE_EQ_PORT"));
		iMDSENport = atoi(sMDSTempPort);
		logDebug2("sMDSTempPort[%s] iMDSENport [%d]",sMDSTempPort,iMDSENport);
	}

	if(getenv("EQU_NSE_BCAST_IP")==NULL)
	{
		logFatal("Error : Environment variables missing : EQU_NSE_BCAST_IP");
		//exit(ERROR);
		logInfo("Setting env as default value and reading from INADDR_ANY");
		strcpy ( sMultitInterfIP, "ANY");
	}
	else
	{
		strcpy ( sMultitInterfIP, getenv("EQU_NSE_BCAST_IP"));
		logDebug2("sMultitInterfIP :%s:",sMultitInterfIP);
	}
		if ( argc != 8 )     // two argument added one for type of broadcast and second for receiving IP @Abhishek-13Jun2019
	{
		logDebug2("Argument Mismstch ");
		logDebug2("USAGE : NseCMBcastAdap   <BCAST RECV IP> <TAP PORT> <L/D> <Y/N> <Service {M Multicast/U Broadcast}> <Rcv IP> NseCMBcastAdap");
		exit(0);
	}

	memset(sBcastRecvIP,'\0',CALLING_LENS);  ///some variables name changed for better understanding @Abhishek-13Jun2019
	memset(sRecvIP,'\0',CALLING_LENS);
	//portno  = atoi(argv[1]);
	strcpy(sBcastRecvIP,argv[1]);
	iBcastRecvPort	= atoi(argv[2]);
	readflg= argv[3][0]; 
	WriteFlag= argv[4][0];
	service = argv[5][0];		//M for Milticast and U for Broadcast @Abhishek-13Jun2019
	strcpy(sRecvIP,argv[6]);	//if broadcast receiving from diffrent IP [not primary ip] @Abhishek-13Jun2019

	logDebug2("_____________________________P A R A M E T E R E S____________________________");

	logDebug2("sBcastRecvIP		is  : %s ",sBcastRecvIP);
	logDebug2("iBcastRecvPort	is  : %d ",iBcastRecvPort);

	logDebug2("sBackOffIP		is  : %s ",sBackOffIP);
	logDebug2("iBackOffPort		is  : %d ",iBackOffPort);

	logDebug2("sStartFlag		is  : %s ",sStartFlag);
	logDebug2("sBckOffFlag		is  : %s ",sBckOffFlag);
	logDebug2("Readflg	    	is  : %c ",readflg );
	logDebug2("WriteFlag	    	is  : %c ",WriteFlag );
	logDebug2("Service              is  : %c ",service );
	logDebug2("sRecvIP 	        is  : %s ",sRecvIP);
	
	logDebug2("_________________________________________________________________________________ ");

	strcpy ( dumpFileName , "ENBcastdumplive.dmp");
	strcpy ( dumpFileName1 , "ENBcastdumplive.dmp");
	if ( readflg =='D')
	{
		fpReadFile = fopen(dumpFileName,"rb+");
		if( fpReadFile == NULL)
		{
			logFatal("Unable to Open the  Read File ");
			exit(1);
		}
	}
	if ( WriteFlag =='Y')
	{
		fpWriteFile = fopen(dumpFileName1,"wb+");
		if( fpWriteFile == NULL)
		{
			logFatal("Unable to Open the  Write File ");
			exit(1);
		}
	}


	for ( ; ; )
	{

		/*-------------------------------------ADDED FOR BCAST THROUGH TAP -------------------------------------*/
		switch(service)//Switch case added for type of broadcast .if service = M then its Multicast and if U then broadcast
		{
			case	MULTICAST_TYPE :
				RecvVal=OpenMultiSocket(&sockfd1, iBcastRecvPort, sBcastRecvIP, sRecvIP);

				if (RecvVal==FALSE)
				{
					logFatal("Error in fuction OpenSocket ....Exiting");
					exit(1);
				}
				logDebug2("sockfd1 = [%d]",sockfd1); 
				break;
			case	BROADCAST_TYPE :
				cli_addr.sin_family     = AF_INET;
				if(strcmp(sRecvIP,"0") != 0 )
				{
					cli_addr.sin_addr.s_addr= sRecvIP;
				}
        			else
				{
					cli_addr.sin_addr.s_addr= INADDR_ANY;
        			}
				//cli_addr.sin_addr.s_addr= INADDR_ANY;
				cli_addr.sin_port       = htons(iBcastRecvPort);
				if(OpenUDPSocket(&sockfd1))
                        	{
                               		if (val = (bind(sockfd1,(struct sockaddr *)&cli_addr,sizeof(struct sockaddr))) <0)
                               		{
                                       		logDebug2("Client : Error in Binding...is:%d",errno);
                                       		memcpy(temp,strerror(errno),100);
                                       		exit(1);
                               		}
                       		}
				break;
		}			
	
		/*------------------------------------------TAP ADDITION ENDS ------------------------------------------*/

			logDebug2("Connection to NSE Broadcast Circuit successful");
		//ReceiveReplyPacketsBcast(sockfd1,bcastaddress,portno,mcastaddress,mportno);
			ReceiveReplyPacketsBcast(sockfd1);//,bcastaddress,portno,mcastaddress,mportno);
	}		
}

//void ReceiveReplyPacketsBcast( LONG32 sockfd1 , CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
void ReceiveReplyPacketsBcast( LONG32 sockfd1)//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
	CHAR		*recvgen;
	CHAR 		*lpPostBuffer;
	CHAR		actualMsg[NSE_MAX_PACKET_SIZE],Messagemap[NSE_MAX_PACKET_SIZE];
	CHAR		actualmsg1[NSE_MAX_PACKET_SIZE];
	CHAR		first_send_this[NSE_MAX_PACKET_SIZE];
	CHAR 		tempdata[MAX_PACKET_SIZE_COMPRESS];
	CHAR	    	cSendBuff [ MAX_PACKET_SIZE_COMPRESS ] ;
	LONG32      	qidnormal,Itsqid ,  recv_bytes, write_status,flag=0,Len,complen,iMsgLen=0,iMsgLen1=0,qidnormal1;
	USHORT      	iCompDataLgh;
	USHORT      	iDcompDataLgh = NSE_MAX_PACKET_RECV_SIZE; 
	USHORT      	iErrCode =0;
	DOUBLE64    	szUncompressed,szCompressed,szPercentCompression;
	LONG64 		PacketCounter, MBP_counter=0, MBP_SatyamComp= 0;
	LONG32		Counter=0;
	LONG32		clilen,ret,TempTcode;
	LONG32		iItsPktCount = 1 ;
	LONG32		iOffset = 0 , iItsNoOfRecs = 0 ;
	int8_t		iItsNoRec ;
	clilen = sizeof(struct sockaddr);

	/****** Start - LZO Addition ****/
	CHAR *templpPostBuff;
	struct  BcastMultiPkts * pMultiBcast ;
	struct  BcastRecord *   pSingleBcast ;
	CHAR    *pPacketCol;
	int     tempMsgLen=0,iForLoop=0;
	int PktCnt = 0;
	struct BcastRecord SendForDecompress;
	int LengthOfData;
	CHAR sDecompData[NSE_MAX_PACKET_RECV_SIZE];

	/****** End  - LZO Addition ****/

	struct BCAST_HEADER  *bcastheader;
	struct NNF_HEADER                *nnfheader;
	COMPRESSION_BRDCST_DATA   *pCmpBcastData;
	struct INT_MULTIPLE_INDEX_BCAST *mulindexbcast;
	struct BCAST_HEADER_ITS *pintBcastHeader;
	struct SUB_MKT_WATCH_ITS_1 *pintMktWatch_1;
	struct ITS_MBP_DATA_1  *newbcast ;
	int TCode,iNoRec;
	SHORT sTcode;
	LONG32  ExchCompressed;
	LONG32  ExchUncompressed;
	LONG32  InternalMapped;
	LONG32  InternalCompressed;
	LONG32  PTranscode;

	LONG32	status = TRUE	;
	CHAR	tempflag= FALSE	;
	LONG32	counter = 0		;

	recvgen = (char *)malloc(sizeof(char)*NSE_MAX_PACKET_RECV_SIZE);

	qidnormal = OpenMsgQ(ENBSpltrToMStatUpld);
	if ( qidnormal < 0 )
	{
		logFatal("Error in  Opening  Queue ");
		exit(0);
	}
	else
	{
		logDebug2("Normal Queue opened and ready");
	}
	if((flag=OpenBcastSocket())==FALSE)
	{
		logFatal("Error creating UDP Broadcast socket");
		exit(0);
	}
	logDebug2("ReceiveReplyPacketsBcast:: After succesfull OpenBcastSocket() function call....");
        
        qidnormal1 = OpenMsgQ(ENBSpltrToSAddMStatUpld);
        if ( qidnormal1 < 0 )
        {
                logFatal("Error in  Opening  Queue ");
                exit(0);
        }
        else
        {
                logDebug2("Normal Queue opened and ready");
        }


	PacketCounter  = 1;
	szUncompressed = 0;
	szCompressed   = 0;

	if(!OpenMulticastSocket())
	{
		logFatal("Error while creating NSE UDP Multicast Socket");
		free(tempdata);
		free(Messagemap);
		exit(0);
	}

	logDebug2("After succesfull OpenMulticastSocket() function call....");


	while(TRUE)
	{       
		memset(&actualMsg,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(&actualmsg1,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(recvgen,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(&Messagemap,SPACE,NSE_MAX_PACKET_RECV_SIZE);
		memset(&first_send_this,SPACE,NSE_MAX_PACKET_RECV_SIZE);


		if (readflg == 'L')
		{
			/*----------------------------------------------------------- TAP -----------------------------------------------------------*/
			//usleep(5000);

			if ((recv_bytes = recvfrom(sockfd1,recvgen,NSE_MAX_PACKET_RECV_SIZE,0,(struct sockaddr *)&serv_addr,&clilen)) < 0 )
			{
				logFatal("Unable to receive the data from sockfd1, id:%d",sockfd1);
				break;
			}

			/*----------------------------------------------------------- TAP -----------------------------------------------------------*/	
		}
		else
		{
			ret = fread(recvgen,NSE_MAX_PACKET_RECV_SIZE,1,fpReadFile);

			usleep(2000);


			if ( ret == 0 )
			{
				fclose(fpReadFile) ;
				logDebug2("----FILE CLOSED REOPENING THE FILE " );
				fpReadFile = fopen(dumpFileName,"rb+");

				if (fpReadFile == NULL)
				{
					logFatal("Error In Opening The File ");
					exit(0);
				}
				continue ;
			}
		}

		if(!strcmp(sStartFlag,STR_YES))
		{
			logDebug2("Sending Broadcast To Analytical Server Ip :%s: Port :%d:",bcastMDS,iMDSENport);
			SendBroadcast(recvgen,NSE_MAX_PACKET_RECV_SIZE,bcastMDS,iMDSENport);
		}

		if(!strcmp(sBckOffFlag,STR_YES))
		{
			logDebug2("Sending Broadcast To BackOff Server Ip :%s: Port :%d:",sBackOffIP,iBackOffPort);
			SendBroadcast(recvgen,NSE_MAX_PACKET_RECV_SIZE,sBackOffIP,iBackOffPort);
		}

		if ( WriteFlag =='Y')
		{
			fwrite ( recvgen, NSE_MAX_PACKET_RECV_SIZE,1,fpWriteFile );
		}

		lpPostBuffer  = recvgen;

		pMultiBcast = (struct BcastMultiPkts *)lpPostBuffer;


		TWIDDLE(pMultiBcast->iNoPackets);


		pPacketCol= (char *)(pMultiBcast->cPacketData);

		if ( pMultiBcast->iNoPackets > 1 )
			logDebug2("No of packets are more than 1");

		PktCnt = pMultiBcast->iNoPackets;

		for (iForLoop=1; iForLoop <= PktCnt ; iForLoop++ )
		{
			pSingleBcast = (struct BcastRecord *)pPacketCol;

			TWIDDLE(pSingleBcast->iCompLen);
			if (pSingleBcast->iCompLen > 0 )
			{
				char *lpCompData;
				unsigned short  iCompdataLgh;
				unsigned short  iDcompDataLgh;
				unsigned short  iErrCode =0;
				unsigned short  *pErrCode;

				ExchCompressed = pSingleBcast->iCompLen;
				memset(&SendForDecompress,' ', sizeof(struct BcastRecord));
				memcpy(&SendForDecompress,pSingleBcast->cCompData,pSingleBcast->iCompLen);
				lzo1z_decompress(&SendForDecompress,iCompdataLgh,sDecompData,&iDcompDataLgh,NULL);
				pPacketCol = pPacketCol + pSingleBcast->iCompLen + sizeof(short);
				templpPostBuff = sDecompData;
				templpPostBuff = templpPostBuff + 8;

			}
			else
			{
				memset(sDecompData,' ',NSE_MAX_PACKET_RECV_SIZE);
				memcpy(sDecompData,pSingleBcast->cCompData,NSE_PACKET_SIZE);
				templpPostBuff = sDecompData;
				templpPostBuff = templpPostBuff + 8;
				nnfheader = (struct NNF_HEADER *)templpPostBuff;
				TWIDDLE(nnfheader->iMsgLen) ;
				tempMsgLen = nnfheader->iMsgLen;
				ExchCompressed = nnfheader->iMsgLen; 
				TWIDDLE(nnfheader->iMsgLen);
				pPacketCol = pPacketCol + tempMsgLen + sizeof(short) + 8;
			}

			nnfheader = (struct NNF_HEADER *) templpPostBuff;

			logDebug2("Before Twidling nnfheader->iMsgLen :%d: nnfheader->iMsgCode :%d:",nnfheader->iMsgLen,nnfheader->iMsgCode);

			TWIDDLE(nnfheader->iMsgCode);
			TWIDDLE(nnfheader->iMsgLen);
			LengthOfData = nnfheader->iMsgLen;
			ExchUncompressed = nnfheader->iMsgLen; 
			PTranscode = nnfheader->iMsgCode;


			if ((LengthOfData > 2000) || (LengthOfData < 0))
			{
				logDebug2("Wrong Data length len = %d",LengthOfData);
				continue;
			}

			sTcode = nnfheader->iMsgCode;
			iMsgLen = nnfheader->iMsgLen;

			logDebug2("after Twiddling  nnfheader->iMsgCode [%d] sTcode [%d] iMsgLen :%d: nnfheader->iMsgLen:%d:",nnfheader->iMsgCode,sTcode,iMsgLen,nnfheader->iMsgLen);

			TWIDDLE(nnfheader->iMsgCode);
			TWIDDLE(nnfheader->iMsgLen);

			memcpy(&actualMsg,templpPostBuff,NSE_MAX_PACKET_RECV_SIZE);
			flag=0;

			flag=TwiddleNseBroad(&actualMsg);
			if (flag==NOT_TWIDDLE)     
			{
				logDebug2("TWIIDLE FAILED");
				continue;
			} 
			memcpy(&first_send_this,&actualMsg,NSE_MAX_PACKET_RECV_SIZE);

			/*status = GetQStatus (qidnormal );
			if ( status == FALSE)
			{
				tempflag = TRUE;
				counter++;
				logDebug2("QUEUE IS FULL");
				
			}*/
                        if(sTcode == TC_STOCK_DETAILS_CHANGE_BCAST || sTcode == TC_STOCK_DETAILS_CHANGE_BCAST_TNDTC) /* -- -- -- --*/
                        {
                                logDebug2("TC_STOCK_DETAILS_CHANGE_BCAST");
                                write_status = WriteMsgQ(qidnormal1,&first_send_this,iMsgLen,1);
                        }
                        else
                        {
                                logDebug2("OTHER THEN TC_STOCK_DETAILS_CHANGE_BCAST");
                                write_status = WriteMsgQ(qidnormal,&first_send_this,iMsgLen,1);
                        }
               

			if ( write_status == ERROR)
			{
				logDebug2("Error in writing to Q");
				return;
			}


			if ( tempflag == TRUE )
			{
				logDebug2("Counter is %d",counter);
			}   

			flag=0;
			iMsgLen = 0;
			iMsgLen1 = 0;
		}     /*** End of for ***/
	} /*** End of while ***/
	free(recvgen);
	free(lpPostBuffer);
	free(actualMsg);
	free(Messagemap);
	free(actualmsg1);
	free(first_send_this);
	free(tempdata);
	free(cSendBuff);
	free(templpPostBuff);
	free(pPacketCol);
	free(sDecompData);
	close(sockfdBroad);
	close(sockfdMulti);
}

BOOL  OpenBcastSocket()
{
	LONG32 optval=1;
	LONG32  val;
	if ( (sockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}
	val = setsockopt(sockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval));
	if ( val < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	return TRUE;
}

BOOL  SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 portno)
{
	struct     sockaddr_in cli_addr ;
	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(bcastaddress);
	cli_addr.sin_port           = htons(portno);

	logDebug2("SENDING BROADCAST IP [%s] PORT [%d] :%d: :%d:",bcastaddress,portno,MsgLen,strlen(cpMsgBuf));

	if(sendto(sockfdBroad,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr))< 0)
	{
		perror("Server : Error in Sending");
		return FALSE;
	}

	return TRUE;
}

BOOL  SendMulticast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 mportno)
{
	struct     	sockaddr_in cli_addr ;
	CHAR       	multicastIP[CALLING_LENS] ;
	LONG32      sentbytes;

	strcpy (multicastIP,getenv("EQU_NSE_MCAST_IP"));

	logDebug2("multicastIP :[%s]",multicastIP);

	logDebug2("::mportno :[%d]",mportno);

	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(multicastIP);
	cli_addr.sin_port           = htons(mportno);

	sentbytes = sendto(sockfdMulti,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr));
	if ( sentbytes < 0 )
	{
		perror("Server : Error in Sending");
		return FALSE;
	}

	logDebug2("::Multicast:: SentBytes : %d",sentbytes);

	return TRUE;
}

BOOL  OpenBcastRecvSocket(LONG32 * OrgSockId,LONG32 Recvport)
{

	LONG32 sockfd;
	struct  sockaddr_in servaddr,cliaddr;
	LONG32 flag=1,clen,connfd;
	fd_set  ActiveSocket ;

	if( (sockfd = socket( AF_INET, SOCK_DGRAM, 0 )) < 0 )
	{
		perror("Trying to open Socket Failed :\n");
		return FALSE;
	}

	if ( sockfd  > 0 )
	{
		memset(&servaddr,0,sizeof(servaddr));

		servaddr.sin_family = AF_INET;
		servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
		servaddr.sin_port=htons(Recvport);

		FD_CLR(sockfd,&ActiveSocket);
		FD_ZERO(&ActiveSocket );
		FD_SET(sockfd,&ActiveSocket );

		if(setsockopt(sockfd,SOL_SOCKET,SO_BROADCAST,(CHAR *)&flag,sizeof(flag))<0)
		{
			perror("Failed in setting Protocol\n");
			close(sockfd);
			return FALSE;
		}
		if(bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0)
		{
			perror("Failed to bind the port\n");
			close(sockfd);
			return FALSE;
		}

		*OrgSockId = sockfd;
		return TRUE;
	}

	return FALSE;
}

BOOL   OpenMulticastSocket()
{
	LONG32  val;
	struct sockaddr_in   ServerAddr;
	u_char ttl = 254;
	if ( (sockfdMulti = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("server : can't open udp socket");
		return FALSE;
	}
	val = setsockopt(sockfdMulti,IPPROTO_IP,IP_MULTICAST_TTL,(void *)&ttl,sizeof(ttl));
	if ( val < 0 )
	{
		perror(" Multicast Socket Error ");
		return FALSE;
	}
	return TRUE;
}

BOOL OpenUDPSocket(LONG32 *sockfd)
{
	LONG32 sfd;
	LONG32 optval=1;
	LONG32 val=1;
	CHAR ttl=1;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket");
		exit(0);
	}
	
	if((val =setsockopt(sfd,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval)))< 0)
        perror("OpenSocket: Error in setsockopt for Bcast Socket ");

	*sockfd = sfd;
	if (val < 0)
		return FALSE;
	else
		return TRUE;
}
//function commented because we are using this function in next two process where we put check on only LTP updation
/*int GetQStatus( int MsgQuery)
{
/***
	struct msqid_ds sStatQ;
	DOUBLE64        checkbytes = 0.0;

	if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
	{
		checkbytes      =       (sStatQ.msg_qbytes * 0.066);



		if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
		{
			logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
			return FALSE ;
		}
		else
		{
			return TRUE ;
		}
	}


}*/
BOOL OpenMultiSocket(LONG32 *sockfd, LONG32 port, CHAR *IPaddr,CHAR *sRecvIP)
{
	LONG32 sfd;
	LONG32 optval=1;
	LONG32 val=1;
	u_char ttl = 1;
	struct ip_mreq mreq;
	logDebug2("IPaddr = [%s]",IPaddr);
	logDebug2("port   = [%d]",port);
	logDebug2("RecvIP = [%s],",sRecvIP);
	u_int yes=1;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket");
		exit(0);
	}

	if (setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes)) < 0)
	{
		perror("Reusing ADDR failed");
		exit(1);
	}

	logDebug2("Socket Id is %d",sfd);
	logDebug2("sMultitInterfIP Id is :%s:",sMultitInterfIP);

	serv_addr.sin_family     = AF_INET;
/***
	if(strcmp(sRecvIP,"0") != 0 )		//if receiving IP is not specified then it take any ip [Primary IP] @Abhishek-13Jun2019
        {
        	serv_addr.sin_addr.s_addr= sRecvIP;
        }
        else
        {
        	serv_addr.sin_addr.s_addr= INADDR_ANY;
        }
****/	
	serv_addr.sin_addr.s_addr= htonl(INADDR_ANY);
	serv_addr.sin_port       = htons(port);

	if(bind(sfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
	{
		perror("Failed to bind the port\n");
		close(sockfd);
		return FALSE;
	}


	mreq.imr_multiaddr.s_addr=inet_addr(IPaddr);
	
	if(strcmp(sRecvIP,"0") != 0 )    //if receiving IP is not specified then it take any ip [Primary IP] @Nitish-8Jul2019
        {
                mreq.imr_interface.s_addr=inet_addr(sRecvIP);
        }
        else
        {
                mreq.imr_interface.s_addr=htonl(INADDR_ANY);
        }


	if (setsockopt(sfd,IPPROTO_IP,IP_ADD_MEMBERSHIP,&mreq,sizeof(mreq)) < 0) 
	{
		perror("setsockopt");
	//	exit(1);
	}

	if (( val = setsockopt(sfd,IPPROTO_IP,IP_MULTICAST_TTL,&ttl,sizeof(ttl) ) ) < 0 )
	{
		perror("OpenSocket: Error in setsockopt for Multicast socket");
	}

	*sockfd = sfd;
	logDebug2("Socket Id is %d",*sockfd);

	if (val < 0)
		return FALSE;
	else
		return TRUE;
}
BOOL GetStartupTimeofDay()
{
	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
	gettimeofday(&StartPoint1, &tzp);

	iStartupTime = StartPoint1.tv_sec - OFFSET;	
	logDebug2("Time of entry is :%d: iStartupTime:%d:",StartPoint1.tv_sec,iStartupTime);

}


