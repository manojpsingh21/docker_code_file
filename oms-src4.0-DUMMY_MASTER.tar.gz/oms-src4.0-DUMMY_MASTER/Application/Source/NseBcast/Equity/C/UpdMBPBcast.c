#include "HashTable.h"
#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include <my_global.h>
#include <mysql.h>

MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32  rcvQ;
LONG32  iSendQ;
MYSQL   *ENMbp_con;
CHAR cMsgType ;
LONG32 iMsgType = 0;

main(LONG32 argc, CHAR **argv)
{
	logTimestamp("ENTRY [Main]");
	LONG32  iFlag;
	LONG32  i;
	LONG32  iNseRecordCount;
	LONG32 iRecordNumber,iTotalRecord;

	CHAR            supdate [MAX_QUERY_SIZE];
	CHAR            sUpdQry [MAX_QUERY_SIZE];
	CHAR            sInsertQry [MAX_QUERY_SIZE];
	CHAR		sSymbol[SYMBOL_LEN];
	CHAR		sSeries[SERIES_LEN];
	CHAR		sBroadcastMessage[BCAST_MSG_LEN];
	CHAR		sActionCode [3];

	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);

	CHAR    cMaxNoThread;
	LONG32  iMaxNoThread;
	LONG32  iTranscodeLocal , iCount;
	CHAR    sRcvMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR sMktType[2];
	ENMbp_con=DB_Connect();

	LONG32  iSegment;


	logDebug2("Connecting to database.......");

	struct NNF_HEADER *pForRecTransCode ;
	struct NNF_MBP_BCAST *pMbpBcast ;
	struct MS_AUCTION_INQ_DATA *pAucInq;
	struct BC_AUCTION_STATUS_CHANGE *pAucStatusChg;
	struct NNF_CALL_AUCTION_MBP *pCallAuc;
	struct BCAST_MBO_MBP_UPDATE *pMboMbpUpd;

	rcvQ=OpenMsgQ(ENBSpltrToMbpUpld);
	logDebug2("rcvQ :%d:",rcvQ);


	if(mysql_autocommit(ENMbp_con,1))
	{
		sql_Error(ENMbp_con);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}




	while( TRUE )
	{


		CHAR            cNetChangeIndicator = '0';
		CHAR            cAuctionStatus = '0';
		LONG32          iTempScripCode =0 , iRecord = 0, iTrdadeid = 0 , iMinFillQty = 0 , iMbpQty = 0 ,iTotalSellQty = 0;
		DOUBLE64        fTempLtp=0.00 , fTotalBuyQty =0.00 , fTotalSellQty  =0.00 ,fClosePrice = 0.00,fOpenPrice = 0.00 , fHighPrice = 0.00 , fLowPrice = 0.00;
		DOUBLE64        fPrice = 0.00  ,fNetPriceChange = 0.00 ,fAvgTradePrice = 0.00  , fInitiatorPrice = 0.00 ,fAuctionPrice = 0.00 ,fBestBuyPrice = 0.00  ;
		DOUBLE64	fBestSellPrice = 0.00 ,fFirstOpenPrice = 0.00 , fMbpPrice = 0.00 ;
		LONG32          iVolTradedToday  =0 ,  iNetPriceChange =0 ,iLastTradedQty  =0 , iLastTradeTime  =0 ,iAvgTradePrice  =0 ,iBookType = 0;
		LONG32           iAuctionNumber  =0 , iAuctionStatus  =0 ,iInitiatorType = 0 ,iTradingStatus = 0 , iTempLtp = 0;
		LONG32          iInitiatorPrice  =0 , iInitiatorQty  =0 ,iAuctionPrice  =0 , iAuctionQty  =0 ,iBbTotalBuyFlg = 0 ,iBbTotalSellFlg  =0 ,iNoRecords = 0 ;
		LONG32          iQty = 0,iBbBuySellFlg = 0 ,iRowsAffcted = 0 , iNoOfOrders = 0 , iTotalBuyQty = 0 , iSettlementPeriod = 0, iBcastMsgLen = 0,indicativeTradedQty= 0;

		memset(&supdate,'\0',MAX_QUERY_SIZE);
		memset(&sInsertQry ,'\0',MAX_QUERY_SIZE);
		memset(&sUpdQry,'\0',MAX_QUERY_SIZE);
		memset(&sRcvMsg,'\0',LOCAL_MAX_PACKET_SIZE);
		memset(&pForRecTransCode,'\0' ,sizeof(struct NNF_HEADER));
		memset(&pMbpBcast,'\0' ,sizeof(struct NNF_MBP_BCAST));
		memset(&pAucInq,'\0' ,sizeof(struct MS_AUCTION_INQ_DATA));
		memset(&pAucStatusChg,'\0' ,sizeof(struct BC_AUCTION_STATUS_CHANGE));
		memset(&pCallAuc,'\0' ,sizeof(struct NNF_CALL_AUCTION_MBP));
		memset(&pMboMbpUpd ,'\0' ,sizeof(struct BCAST_MBO_MBP_UPDATE));
		memset(sMktType,'\0',2); 
		memset(sSymbol,'\0',SYMBOL_LEN);
		memset(sSeries,'\0',SERIES_LEN);
		memset(sBroadcastMessage,'\0',BCAST_MSG_LEN);
		memset(sActionCode,'\0',3);
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count :%d: ==============---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if((ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 2)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}
		pForRecTransCode = (struct NNF_HEADER *) sRcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgCode;
		logTimestamp("Received iTranscodeLocal :%d:",iTranscodeLocal);
		switch (iTranscodeLocal)
		{
			/*			case TC_MBP_BCAST :

						logDebug2("7208 TC_MBP_BCAST :%d:",TC_MBP_BCAST);
						pMbpBcast = (NNF_MBP_BCAST *)sRcvMsg;

			//			logDebug2("pMbpBcast->iNoOfRecs :%d:",pMbpBcast->iNoOfRecs);
			for(iTotalRecord = 0;iTotalRecord <pMbpBcast->iNoOfRecs; iTotalRecord++)
			{

			iTempScripCode  =       pMbpBcast->pMBPInfo[iTotalRecord].iToken ;
			iBookType       =       pMbpBcast->pMBPInfo[iTotalRecord].iBookType;
			iTradingStatus  =       pMbpBcast->pMBPInfo[iTotalRecord].iTradingStatus;
			iVolTradedToday =        pMbpBcast->pMBPInfo[iTotalRecord].iVolTradedToday;
			//              iTempLtp        =       pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice ;
			fTempLtp        = ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice)/CONST_PRICE_FACTOR;
			fNetPriceChange = ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iNetPriceChange)/CONST_PRICE_FACTOR ;
			iLastTradedQty  =       pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedQty;
			iLastTradeTime  =        pMbpBcast->pMBPInfo[iTotalRecord].iLastTradeTime;
			fAvgTradePrice  =     ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iAvgTradePrice)/CONST_PRICE_FACTOR;
			iAuctionNumber  =       pMbpBcast->pMBPInfo[iTotalRecord].iAuctionNumber;
			iAuctionStatus  =       pMbpBcast->pMBPInfo[iTotalRecord].iAuctionStatus;
			iInitiatorType  =        pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorType;
			fInitiatorPrice =        ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorPrice)/CONST_PRICE_FACTOR;
			iInitiatorQty   =        pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorQty;
			fAuctionPrice   = ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iAuctionPrice)/CONST_PRICE_FACTOR;
			iAuctionQty     =       pMbpBcast->pMBPInfo[iTotalRecord].iAuctionQty;
			 *		 for(iNoRecords = 0 ; iNoRecords < MBP_NO_OF_RECS ; iNoRecords++)
			 {
			 iQty =  pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iTotalRecord].iQty ;
			 fPrice = ((DOUBLE64) pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iTotalRecord].iPrice)/CONST_PRICE_FACTOR ;
			 iNoOfOrders =    pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iTotalRecord].iNoOfOrders;
			 iBbBuySellFlg =  pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iTotalRecord].iBbBuySellFlg;
			 }*
			 iBbTotalBuyFlg  =        pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalBuyFlg;
			 iBbTotalSellFlg =        pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalSellFlg;
			 fTotalBuyQty    =        pMbpBcast->pMBPInfo[iTotalRecord].fTotalBuyQty;
			 fTotalSellQty   =        pMbpBcast->pMBPInfo[iTotalRecord].fTotalSellQty;

			 fClosePrice     =        ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iClosePrice)/CONST_PRICE_FACTOR;
			 fOpenPrice      =       ((DOUBLE64) pMbpBcast->pMBPInfo[iTotalRecord].iOpenPrice)/CONST_PRICE_FACTOR;
			 fHighPrice      =       ((DOUBLE64) pMbpBcast->pMBPInfo[iTotalRecord].iHighPrice)/CONST_PRICE_FACTOR;
			 fLowPrice       =        ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iLowPrice)/CONST_PRICE_FACTOR;

			//				logDebug2("iBookType :%d:",iBookType);
			 *				switch(iBookType)
			 {
			 case 1:
			 case 2:
			 case 3:
			 case 4:
			 strncpy(sMktType,MKT_TYPE_NL,2);
			 break;
			 case 5:
			 strncpy(sMktType,MKT_TYPE_OL,2);
			 break;
			 case 6:
			 strncpy(sMktType,MKT_TYPE_SP,2);
			 break;
			 case 7:
			 strncpy(sMktType,MKT_TYPE_AU,2);
			 break;
			 case 11:
			 strncpy(sMktType,MKT_TYPE_CAU_1,2);
			 break;
			 case 12:
			 strncpy(sMktType,MKT_TYPE_CAU_2,2);
			 break;
			 default :
			 strncpy(sMktType,MKT_TYPE_NL,2);
			 break;
			 }*

			sprintf(supdate,"UPDATE EQ_AU_L1_WATCH SET\
					L1_UPDATE_TIME= NOW() ,\
					L1_LTP  = %lf,\
					L1_BOOK_TYPE = %d,\
					L1_TRADING_STATUS = %d,\
					L1_VOL_TRD_TODAY = %d,\
					L1_SCRIP_CODE= %d,\
					L1_EXCH_SCRIP_CODE= %d,\
					L1_NET_PRICE_CHG = %d,\
					L1_LAST_TRD_QTY  = %d,\
					L1_LAST_TRADE_TIME = %d,\
					L1_AVG_TRADE_PRICE =  %f,\
					L1_AUCT_NUM = %d,\
					L1_AUCT_STAT =%d,\
					L1_IND_PRICE =%f,\
					L1_IND_QTY =%d,\
					L1_AUCT_PRICE=%f, \
					L1_AUCT_QTY =%d,\
					L1_BUY_BCK_TOTAL_BUY_FLG =%d,\
					L1_BUY_BCK_TOTAL_SELL_FLG =%d,\
					L1_TOTAL_BUY_QTY  =%f,\
					L1_TOTAL_SELL_QTY  =%f,\
					L1_CLOSE_PRICE  =%f,\
					L1_OPEN_PRICE  =%f,\
					L1_HIGH_PRICE  =%f,\
					L1_LOW_PRICE   =%f ,\
					L1_MARKET_TYPE = \"%s\" \
					WHERE L1_EXCHANGE =\"%s\" AND L1_SEGMENT =\'%c\' AND L1_SCRIP_CODE = \'%d\' AND L1_MARKET_TYPE = \"%s\"",\
					fTempLtp,iBookType,iTradingStatus,iVolTradedToday,iTempScripCode,iTempScripCode,fNetPriceChange,\
					iLastTradedQty,iLastTradeTime,fAvgTradePrice,iAuctionNumber,iAuctionStatus,iInitiatorPrice,\
					iInitiatorQty,fAuctionPrice,iAuctionQty,iBbTotalBuyFlg,iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,fClosePrice,\
					fOpenPrice,fHighPrice,fLowPrice,sMktType,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,sMktType);
			//						 logDebug2("Query :%s:",supdate);

			if(mysql_query(ENMbp_con,supdate) != SUCCESS)
			{

				logSqlFatal(" In Function [TC_MBP_BCAST]-->ERROR IN INSERT QUERY->EQ_AU_L1_WATCH");
				sql_Error(ENMbp_con);
			}
			else
			{
				mysql_commit(ENMbp_con);
				iRowsAffcted = mysql_affected_rows(ENMbp_con);
				//			                logDebug2("%d rows updated!!",iRowsAffcted);
				if(iRowsAffcted == 0)
				{

					sprintf(sInsertQry,"INSERT INTO EQ_AU_L1_WATCH (L1_LTP,L1_BOOK_TYPE ,L1_TRADING_STATUS ,\
						L1_VOL_TRD_TODAY  ,L1_SCRIP_CODE,L1_EXCH_SCRIP_CODE,L1_NET_PRICE_CHG ,\
						L1_LAST_TRD_QTY ,L1_LAST_TRADE_TIME ,L1_AVG_TRADE_PRICE ,L1_AUCT_NUM  , L1_AUCT_STAT ,\
						L1_IND_PRICE ,L1_IND_QTY ,L1_AUCT_PRICE, L1_AUCT_QTY ,\
						L1_BUY_BCK_TOTAL_BUY_FLG ,L1_BUY_BCK_TOTAL_SELL_FLG ,L1_TOTAL_BUY_QTY  ,\
						L1_TOTAL_SELL_QTY  ,L1_CLOSE_PRICE  ,L1_OPEN_PRICE  ,L1_HIGH_PRICE  , L1_LOW_PRICE ,\
						L1_EXCHANGE ,L1_SEGMENT,L1_ENTRY_TIME,L1_MARKET_TYPE)\
							VALUES(%f,%d,%d,%d,%d,%d,%f,%d,%d,%f,%d,%d,%f,%d,%f,%d,%d,%d,%f,\
								%f,%f,%f,%f,%f,\"%s\",\'%c\',NOW(),\"%s\")",\
							fTempLtp,iBookType,iTradingStatus,iVolTradedToday,iTempScripCode,iTempScripCode,\
							fNetPriceChange,iLastTradedQty,iLastTradeTime,fAvgTradePrice,\
							iAuctionNumber,iAuctionStatus,fInitiatorPrice,iInitiatorQty,\
							fAuctionPrice,iAuctionQty,iBbTotalBuyFlg,iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,\
							fClosePrice,fOpenPrice,fHighPrice,fLowPrice,NSE_EXCH,EQUITY_SEGMENT,sMktType);
					//			                          logDebug2("%s",sInsertQry);
					if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
					{
						logSqlFatal("###### SQL Failed  ######");
						sql_Error(ENMbp_con);
					}
					else
					{
						mysql_commit(ENMbp_con);
						//			                                logInfo(" Trade Commit sucessful");

					}
				}
				else
				{
					logDebug2("------SUCCESS UPDATE QUERY-----");			                                
				}
			}


		}
		break ;*/

			case TC_AUCTION_INQUIRY_MSG:

			logDebug2(" 6582 TC_AUCTION_INQUIRY_MSG :%d:",TC_AUCTION_INQUIRY_MSG);
			pAucInq = (MS_AUCTION_INQ_DATA *)sRcvMsg;

			iTempScripCode 		= pAucInq->pAucInqInfo.iToken;
			iAuctionNumber 		= pAucInq->pAucInqInfo.iAuctionNumber;
			iAuctionStatus 		= pAucInq->pAucInqInfo.iAuctionStatus;
			iInitiatorType 		= pAucInq->pAucInqInfo.iInitiatorType;
			iTotalBuyQty 		= pAucInq->pAucInqInfo.iTotalBuyQty;
			fBestBuyPrice 		= ((DOUBLE64) pAucInq->pAucInqInfo.iBestBuyPrice)/CONST_PRICE_FACTOR;;
			iTotalSellQty 		= pAucInq->pAucInqInfo.iTotalSellQty;
			fBestSellPrice 		= ((DOUBLE64) pAucInq->pAucInqInfo.iBestSellPrice)/CONST_PRICE_FACTOR;;
			fAuctionPrice 		= (DOUBLE64)(pAucInq->pAucInqInfo.iAuctionPrice)/CONST_PRICE_FACTOR;;
			iAuctionQty 		= pAucInq->pAucInqInfo.iAuctionQty;
			iSettlementPeriod 	= pAucInq->pAucInqInfo.iSettlementPeriod;

			/*				sprintf(supdate,"UPDATE AUC_INQ_WATCH SET\
							L1_UPDATE_TIME= NOW() ,\
							L1_SCRIP_CODE= %d,\
							L1_EXCH_SCRIP_CODE= %d,\
							L1_AUCT_NUM = %d,\
							L1_AUCT_STAT =%d,\
							L1_AUCT_PRICE=%f, \
							L1_AUCT_QTY =%d,\
							L1_TOTAL_BUY_QTY =%d,\
							L1_TOTAL_SELL_QTY =%d,\
							L1_BEST_BUY_PRICE =%f, \
							L1_BEST_SELL_PRICE =%f, \
							L1_SETTLEMENT_PERIOD = %d \
							WHERE L1_EXCHANGE =\"%s\" AND L1_SEGMENT =\'%c\' AND L1_SCRIP_CODE = \'%d\'",\
							iTempScripCode,iTempScripCode,iAuctionNumber,iAuctionStatus,fAuctionPrice,iAuctionQty,iTotalBuyQty,iTotalSellQty,fBestBuyPrice,fBestSellPrice,iSettlementPeriod,NSE_EXCH,EQUITY_SEGMENT,iTempScripCode);
							logDebug2("Query :%s:",supdate);


							if(mysql_query(ENMbp_con,supdate) != SUCCESS)
							{

							logSqlFatal(" In Function [TC_AUCTION_INQUIRY_MSG]-->ERROR IN INSERT QUERY->AUC_INQ_WATCH");
							sql_Error(ENMbp_con);
							}
							else
							{
							mysql_commit(ENMbp_con);
							iRowsAffcted = mysql_affected_rows(ENMbp_con);
							logDebug2("%d rows updated!!",iRowsAffcted);
							if(iRowsAffcted == 0)
							{*/

			sprintf(sInsertQry,"INSERT INTO AUC_INQ_WATCH (L1_SCRIP_CODE,L1_EXCH_SCRIP_CODE,L1_AUCT_NUM,L1_AUCT_STAT ,\
				L1_AUCT_PRICE,L1_AUCT_QTY,L1_ENTRY_TIME,L1_TOTAL_BUY_QTY,L1_TOTAL_SELL_QTY,\
				L1_BEST_BUY_PRICE,L1_BEST_SELL_PRICE,L1_SETTLEMENT_PERIOD,L1_EXCHANGE,L1_SEGMENT)\
					VALUES(%d,%d,%d,%d,%f,%d,NOW(),%d,%d,%f,%f,%d,\"%s\",\'%c\')",\
					iTempScripCode,iTempScripCode,iAuctionNumber,iAuctionStatus,fAuctionPrice,iAuctionQty,\
					iTotalBuyQty,iTotalSellQty,fBestBuyPrice,fBestSellPrice,iSettlementPeriod,\
					NSE_EXCH,EQUITY_SEGMENT);
			logDebug2("%s",sInsertQry);
			if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
			{
				logSqlFatal("###### SQL Failed  ######");
				sql_Error(ENMbp_con);
			}
			else
			{
				mysql_commit(ENMbp_con);
				logInfo(" Trade Commit sucessful");

			}
			/*                                	}
								else
								{
								logDebug2("------SUCCESS UPDATE QUERY-----");                                                   
								}
								}*/

			break ;

			case TC_AUCTION_INQUIRY_MSG_TNDTC:

                        logDebug2("18700 : TC_AUCTION_INQUIRY_MSG_TNDTC :%d:",TC_AUCTION_INQUIRY_MSG_TNDTC);
                        pAucInq = (MS_AUCTION_INQ_DATA_TNDTC *)sRcvMsg;

                        iTempScripCode          = pAucInq->pAucInqInfo.iToken;
                        iAuctionNumber          = pAucInq->pAucInqInfo.iAuctionNumber;
                        iAuctionStatus          = pAucInq->pAucInqInfo.iAuctionStatus;
                        iInitiatorType          = pAucInq->pAucInqInfo.iInitiatorType;
                        iTotalBuyQty            = pAucInq->pAucInqInfo.iTotalBuyQty;
                        fBestBuyPrice           = ((DOUBLE64) pAucInq->pAucInqInfo.iBestBuyPrice)/CONST_PRICE_FACTOR;;
                        iTotalSellQty           = pAucInq->pAucInqInfo.iTotalSellQty;
                        fBestSellPrice          = ((DOUBLE64) pAucInq->pAucInqInfo.iBestSellPrice)/CONST_PRICE_FACTOR;;
                        fAuctionPrice           = (DOUBLE64)(pAucInq->pAucInqInfo.iAuctionPrice)/CONST_PRICE_FACTOR;;
                        iAuctionQty             = pAucInq->pAucInqInfo.iAuctionQty;
                        iSettlementPeriod       = pAucInq->pAucInqInfo.iSettlementPeriod;

                        sprintf(sInsertQry,"INSERT INTO AUC_INQ_WATCH (L1_SCRIP_CODE,L1_EXCH_SCRIP_CODE,L1_AUCT_NUM,L1_AUCT_STAT ,\
                                        L1_AUCT_PRICE,L1_AUCT_QTY,L1_ENTRY_TIME,L1_TOTAL_BUY_QTY,L1_TOTAL_SELL_QTY,\
                                        L1_BEST_BUY_PRICE,L1_BEST_SELL_PRICE,L1_SETTLEMENT_PERIOD,L1_EXCHANGE,L1_SEGMENT)\
                                        VALUES(%d,%d,%d,%d,%f,%d,NOW(),%d,%d,%f,%f,%d,\"%s\",\'%c\')",\
                                        iTempScripCode,iTempScripCode,iAuctionNumber,iAuctionStatus,fAuctionPrice,iAuctionQty,\
                                        iTotalBuyQty,iTotalSellQty,fBestBuyPrice,fBestSellPrice,iSettlementPeriod,\
                                        NSE_EXCH,EQUITY_SEGMENT);
                        logDebug2("sInsertQry -> %s",sInsertQry);
                        if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
                        {
                                logSqlFatal("## SQL Failed in case TC_AUCTION_INQUIRY_MSG_TNDTC  ##");
                                sql_Error(ENMbp_con);
                        }
                        else
                        {
                                mysql_commit(ENMbp_con);
                                logInfo(" Trade Commit sucessful");

                        }

                        break ;
                        /* -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --  */

			case TC_CALL_AUCTION_MBP :

			logDebug2(" 7214 TC_CALL_AUCTION_MBP :%d:",TC_CALL_AUCTION_MBP);
			pCallAuc = (struct NNF_CALL_AUCTION_MBP *)sRcvMsg;

			logDebug2("pCallAuc->iNoOfRecs :%d:",pCallAuc->iNoOfRecs);
			for(iTotalRecord = 0;iTotalRecord <pCallAuc->iNoOfRecs; iTotalRecord++)
			{

				iTempScripCode  	=       pCallAuc->pCallAucMbp[iTotalRecord].iToken ;
				iBookType       	=       pCallAuc->pCallAucMbp[iTotalRecord].iBookType;
				iTradingStatus  	=       pCallAuc->pCallAucMbp[iTotalRecord].iTradingStatus;
				iVolTradedToday 	=    	pCallAuc->pCallAucMbp[iTotalRecord].iVolTradedToday;
				indicativeTradedQty 	=       pCallAuc->pCallAucMbp[iTotalRecord].indicativeTradedQty;
				fTempLtp 		= 	((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iLastTradedPrice)/CONST_PRICE_FACTOR;
				fNetPriceChange 	= 	((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iNetPriceChange)/CONST_PRICE_FACTOR ;
				iLastTradedQty  	=       pCallAuc->pCallAucMbp[iTotalRecord].iLastTradedQty;
				iLastTradeTime  	=       pCallAuc->pCallAucMbp[iTotalRecord].iLastTradeTime;
				fAvgTradePrice  	=     	((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iAvgTradePrice)/CONST_PRICE_FACTOR;
				fFirstOpenPrice		= 	((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iFirstOpenPrice)/CONST_PRICE_FACTOR;
				iBbTotalBuyFlg  	=       pCallAuc->pCallAucMbp[iTotalRecord].iBbTotalBuyFlg;
				iBbTotalSellFlg 	=       pCallAuc->pCallAucMbp[iTotalRecord].iBbTotalSellFlg;
				fTotalBuyQty    	=       pCallAuc->pCallAucMbp[iTotalRecord].fTotalBuyQty;
				fTotalSellQty   	=       pCallAuc->pCallAucMbp[iTotalRecord].fTotalSellQty;

				fClosePrice     	=       ((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iClosePrice)/CONST_PRICE_FACTOR;
				fOpenPrice      	=       ((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iOpenPrice)/CONST_PRICE_FACTOR;
				fHighPrice      	=       ((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iHighPrice)/CONST_PRICE_FACTOR;
				fLowPrice       	=       ((DOUBLE64)pCallAuc->pCallAucMbp[iTotalRecord].iLowPrice)/CONST_PRICE_FACTOR;

				for(iNoRecords = 0 ; iNoRecords < MBP_NO_OF_RECS ; iNoRecords++)
				{
					iQty 		=   	pCallAuc->pCallAucMbp[iTotalRecord].pMBPRecords[iNoRecords].iQty ;
					fPrice 		= ((DOUBLE64) pCallAuc->pCallAucMbp[iTotalRecord].pMBPRecords[iNoRecords].iPrice)/CONST_PRICE_FACTOR ;
					iNoOfOrders 	= 	pCallAuc->pCallAucMbp[iTotalRecord].pMBPRecords[iNoRecords].iNoOfOrders;
					iBbBuySellFlg 	=	pCallAuc->pCallAucMbp[iTotalRecord].pMBPRecords[iNoRecords].iBbBuySellFlg;

					sprintf(sInsertQry,"INSERT INTO EQ_AU_L1_WATCH (L1_LTP,L1_BOOK_TYPE ,L1_TRADING_STATUS ,\
						L1_VOL_TRD_TODAY  ,L1_SCRIP_CODE,L1_EXCH_SCRIP_CODE,L1_NET_PRICE_CHG ,\
						L1_LAST_TRD_QTY ,L1_LAST_TRADE_TIME ,L1_AVG_TRADE_PRICE ,\
						L1_FIRST_OPN_PRICE ,L1_BUY_BCK_TOTAL_BUY_FLG ,L1_BUY_BCK_TOTAL_SELL_FLG ,L1_TOTAL_BUY_QTY  ,\
						L1_TOTAL_SELL_QTY  ,L1_CLOSE_PRICE  ,L1_OPEN_PRICE  ,L1_HIGH_PRICE  , L1_LOW_PRICE ,\
						L1_EXCHANGE ,L1_SEGMENT,L1_ENTRY_TIME,L1_MBP_QTY,L1_MBP_PRICE,L1_MBP_NO_OF_ORDERS,L1_BUY_SELL_IND,L1_SEQ)\
							VALUES(%f,%d,%d,%d,%d,%d,\
								%f,%d,%d,%f,\
								%f,%d,%d,%f,%f ,\
								%f,%f,%f,%f,\"%s\",\'%c\',NOW(),%d,%f,%d,%d,%d)",\
							fTempLtp,iBookType,iTradingStatus,iVolTradedToday,iTempScripCode,iTempScripCode,\
							fNetPriceChange,iLastTradedQty,iLastTradeTime,fAvgTradePrice,\
							fFirstOpenPrice,iBbTotalBuyFlg,iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,\
							fClosePrice,fOpenPrice,fHighPrice,fLowPrice,NSE_EXCH,EQUITY_SEGMENT,iQty,fPrice,iNoOfOrders,iBbBuySellFlg,iNoRecords);

					logDebug2("%s",sInsertQry);
					if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
					{
						logSqlFatal("###### SQL Failed  ######");
						sql_Error(ENMbp_con);
					}
					else
					{
						mysql_commit(ENMbp_con);
						logInfo(" Trade Commit sucessful");

					}
				}
			}
			break ;

			case TC_AUCTION_STATUS_CHNG :

			logDebug2(" 6581 TC_AUCTION_STATUS_CHNG :%d:",TC_AUCTION_STATUS_CHNG);

			pAucStatusChg = (struct BC_AUCTION_STATUS_CHANGE *)sRcvMsg;

			logDebug2("pAucStatusChg->pHeader.iMsgLength :%d;",pAucStatusChg->pHeader.iMsgLen);
			strncpy(sSymbol,pAucStatusChg->SecInfo.sSymbol,SYMBOL_LEN) ;
			strncpy(sSeries,pAucStatusChg->SecInfo.sSeries,SERIES_LEN) ;

			iAuctionNumber 	= pAucStatusChg->iAuctionNumber ;
			cAuctionStatus 	= pAucStatusChg->cAuctionStatus ;
			strncpy(sActionCode,pAucStatusChg->sActionCode,3); ;
			iBcastMsgLen 	= pAucStatusChg->iBroadcastMessageLength ;
			strncpy(sBroadcastMessage,pAucStatusChg->sBroadcastMessage,BCAST_MSG_LEN) ;

			sprintf(sInsertQry,"INSERT INTO AUCTION_MKT_INDICATOR (SYMBOL,SERIES,AUCTION_NUMBER,AUCTION_STATUS,\
				ACTION_CODE,MSG_LEN,MESSAGE,ENTRY_TIME,EXCH,SEGMENT)\
					VALUES(\"%s\",\"%s\",%d,\'%c\',\"%s\",%d,\"%s\",NOW(),\"%s\",\'%c\')",\
					sSymbol,sSeries,iAuctionNumber,cAuctionStatus,sActionCode,iBcastMsgLen,sBroadcastMessage,NSE_EXCH,EQUITY_SEGMENT);

			logDebug2("%s",sInsertQry);

			if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
			{
				logSqlFatal("###### SQL Failed  ######");
				sql_Error(ENMbp_con);
			}
			else
			{
				mysql_commit(ENMbp_con);

			}


			break ;

			case TC_MBO_MBP_UPDATE_BCAST :

			logDebug2(" 7200 TC_MBO_MBP_UPDATE_BCAST :%d:",TC_MBO_MBP_UPDATE_BCAST);
			pMboMbpUpd = (struct BCAST_MBO_MBP_UPDATE*)sRcvMsg;


			iTempScripCode    	=  	pMboMbpUpd->pMboData.iToken ;
			iBookType 		=       pMboMbpUpd->pMboData.iBookType ;
			iTradingStatus 		=       pMboMbpUpd->pMboData.iTradingStatus ;
			iVolTradedToday 	= 	pMboMbpUpd->pMboData.iVolumeTradedToday;
			fTempLtp 		=       ((DOUBLE64)pMboMbpUpd->pMboData.iLastTradedPrice)/CONST_PRICE_FACTOR ;
			fNetPriceChange 	= 	((DOUBLE64)pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice)/CONST_PRICE_FACTOR ;
			iLastTradedQty 		=	pMboMbpUpd->pMboData.iLastTradeQuantity ;
			iLastTradeTime 		= 	pMboMbpUpd->pMboData.iLastTradeTime ;
			fAvgTradePrice 		= 	((DOUBLE64)pMboMbpUpd->pMboData.iAverageTradePrice)/CONST_PRICE_FACTOR ;
			iAuctionNumber 		=	pMboMbpUpd->pMboData.iAuctionNumber ;
			iAuctionStatus 		=	pMboMbpUpd->pMboData.iAuctionStatus ;
			iInitiatorType 		= 	pMboMbpUpd->pMboData.iInitiatorType ;
			fInitiatorPrice 	=	((DOUBLE64)pMboMbpUpd->pMboData.iInitiatorPrice)/CONST_PRICE_FACTOR ;
			iInitiatorQty 		= 	pMboMbpUpd->pMboData.iInitiatorQuantity ;
			fAuctionPrice 		=	((DOUBLE64)pMboMbpUpd->pMboData.iAuctionPrice)/CONST_PRICE_FACTOR ;
			iAuctionQty		= 	pMboMbpUpd->pMboData.iAuctionQuantity ;
			iBbTotalBuyFlg  	=	pMboMbpUpd->iBbTotalBuyFlag;
			iBbTotalSellFlg		=	pMboMbpUpd->iBbTotalSellFlag;
			fTotalBuyQty		=	pMboMbpUpd->fTotalBuyQuantity;
			fTotalSellQty		=	pMboMbpUpd->fTotalSellQuantity;
			fClosePrice		=	((DOUBLE64)pMboMbpUpd->iClosingPrice)/CONST_PRICE_FACTOR;
			fOpenPrice		=	((DOUBLE64)pMboMbpUpd->iOpenPrice)/CONST_PRICE_FACTOR;
			fHighPrice		=	((DOUBLE64)pMboMbpUpd->iHighPrice)/CONST_PRICE_FACTOR;
			fLowPrice		=	((DOUBLE64)pMboMbpUpd->iLowPrice)/CONST_PRICE_FACTOR;

			printf("\n pMboMbpUpd->pMboData.iToken 			:%d:",pMboMbpUpd->pMboData.iToken);
			printf("\n pMboMbpUpd->pMboData.iBookType 		:%d:",pMboMbpUpd->pMboData.iBookType);
			printf("\n pMboMbpUpd->pMboData.iTradingStatus 		:%d:",pMboMbpUpd->pMboData.iTradingStatus);
			printf("\n pMboMbpUpd->pMboData.iVolumeTradedToday 	:%d:",pMboMbpUpd->pMboData.iVolumeTradedToday);
			printf("\n pMboMbpUpd->pMboData.iLastTradedPrice 	:%d:",pMboMbpUpd->pMboData.iLastTradedPrice);
			printf("\n pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice :%d:",pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice);
			printf("\n pMboMbpUpd->pMboData.iLastTradeQuantity 	:%d:",pMboMbpUpd->pMboData.iLastTradeQuantity);
			printf("\n pMboMbpUpd->pMboData.iLastTradeTime 		:%d:",pMboMbpUpd->pMboData.iLastTradeTime);
			printf("\n pMboMbpUpd->pMboData.iAverageTradePrice 	:%d:",pMboMbpUpd->pMboData.iAverageTradePrice);
			printf("\n pMboMbpUpd->pMboData.iAuctionNumber 		:%d:",pMboMbpUpd->pMboData.iAuctionNumber);
			printf("\n pMboMbpUpd->pMboData.iAuctionStatus 		:%d:",pMboMbpUpd->pMboData.iAuctionStatus);
			printf("\n pMboMbpUpd->pMboData.iInitiatorType 		:%d:",pMboMbpUpd->pMboData.iInitiatorType);
			printf("\n pMboMbpUpd->pMboData.iInitiatorPrice 	:%d:",pMboMbpUpd->pMboData.iInitiatorPrice);
			printf("\n pMboMbpUpd->pMboData.iInitiatorQuantity 	:%d:",pMboMbpUpd->pMboData.iInitiatorQuantity);
			printf("\n pMboMbpUpd->pMboData.iAuctionPrice 		:%d:",pMboMbpUpd->pMboData.iAuctionPrice);
			printf("\n pMboMbpUpd->pMboData.iAuctionQuantit 	:%d:",pMboMbpUpd->pMboData.iAuctionQuantity);
			printf("\n pMboMbpUpd->fTotalBuyQuantity 		:%d:",pMboMbpUpd->fTotalBuyQuantity);
			printf("\n pMboMbpUpd->fTotalSellQuantity  		:%d:",pMboMbpUpd->fTotalSellQuantity);
			printf("\n pMboMbpUpd->iClosingPrice  			:%d:",pMboMbpUpd->iClosingPrice);
			printf("\n pMboMbpUpd->iOpenPrice  			:%d:",pMboMbpUpd->iOpenPrice);
			printf("\n pMboMbpUpd->iHighPrice  			:%d:",pMboMbpUpd->iHighPrice);
			printf("\n pMboMbpUpd->iLowPrice  			:%d:",pMboMbpUpd->iLowPrice);
		

			for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
			{
				iTrdadeid  	=	(pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid);
				iQty 		= 	(pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
				fPrice 		=  	((DOUBLE64)pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice)/CONST_PRICE_FACTOR;
				iMinFillQty 	= 	(pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty);

				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid);
				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice);
				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty :%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty);

				iMbpQty 	= 	(pMboMbpUpd->pMBPRecords[iRecord].iQty);
				fMbpPrice	= 	((DOUBLE64)pMboMbpUpd->pMBPRecords[iRecord].iPrice)/CONST_PRICE_FACTOR;
				iNoOfOrders 	= 	(pMboMbpUpd->pMBPRecords[iRecord].iNoOfOrders);
				iBbBuySellFlg 	= 	(pMboMbpUpd->pMBPRecords[iRecord].iBbBuySellFlg);

				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice);
				printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iNoOfOrders :%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iNoOfOrders);

				sprintf(sInsertQry,"INSERT INTO MBO_MBP_L1_WATCH (L1_LTP,L1_BOOK_TYPE ,L1_TRADING_STATUS ,\
					L1_VOL_TRD_TODAY  ,L1_SCRIP_CODE,L1_EXCH_SCRIP_CODE,L1_NET_PRICE_CHG ,\
					L1_LAST_TRD_QTY ,L1_LAST_TRADE_TIME ,L1_AVG_TRADE_PRICE ,L1_AUCT_NUM  , L1_AUCT_STAT ,\
					L1_IND_PRICE ,L1_IND_QTY ,L1_AUCT_PRICE, L1_AUCT_QTY ,\
					L1_BUY_BCK_TOTAL_BUY_FLG ,L1_BUY_BCK_TOTAL_SELL_FLG ,L1_TOTAL_BUY_QTY  ,\
					L1_TOTAL_SELL_QTY  ,L1_CLOSE_PRICE  ,L1_OPEN_PRICE  ,L1_HIGH_PRICE  , L1_LOW_PRICE ,\
					L1_EXCHANGE ,L1_SEGMENT,L1_ENTRY_TIME,L1_MBP_QTY,L1_MBP_PRICE,\
					L1_MBP_NO_OF_ORDERS,L1_BUY_SELL_IND,L1_MBO_TRD_ID,L1_MBO_QTY,L1_MBO_PRICE,L1_MIN_FILL_QTY,L1_SEQ)\
						VALUES(%f,%d,%d,%d,%d,%d,%f,%d,%d,%f,%d,%d,%f,%d,%f,%d,%d,%d,%f,\
							%f,%f,%f,%f,%f,\"%s\",\'%c\',NOW(),%d,%f,%d,%d,%d,%d,%f,%d,%d)",\
						fTempLtp,iBookType,iTradingStatus,iVolTradedToday,iTempScripCode,iTempScripCode,\
						fNetPriceChange,iLastTradedQty,iLastTradeTime,fAvgTradePrice,\
						iAuctionNumber,iAuctionStatus,fInitiatorPrice,iInitiatorQty,\
						fAuctionPrice,iAuctionQty,iBbTotalBuyFlg,iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,\
						fClosePrice,fOpenPrice,fHighPrice,fLowPrice,NSE_EXCH,EQUITY_SEGMENT,iMbpQty,fMbpPrice,iNoOfOrders,\
						iBbBuySellFlg,iTrdadeid,iQty,fPrice,iMinFillQty,iRecord);
				logDebug2("%s",sInsertQry);

				if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
				{
					logSqlFatal("###### SQL Failed  ######");
					sql_Error(ENMbp_con);
				}
				else
				{
					mysql_commit(ENMbp_con);
					//                                              logInfo(" Trade Commit sucessful");

				}

			}
			break; 


			case TC_MBO_MBP_UPDATE_BCAST_TNDTC :

                        logDebug2("18701 :  TC_MBO_MBP_UPDATE_BCAST_TNDTC :%d:",TC_MBO_MBP_UPDATE_BCAST_TNDTC);
                        pMboMbpUpd = (struct BCAST_MBO_MBP_UPDATE_TNDTC*)sRcvMsg;


                        iTempScripCode          =       pMboMbpUpd->pMboData.iToken ;
                        iBookType               =       pMboMbpUpd->pMboData.iBookType ;
                        iTradingStatus          =       pMboMbpUpd->pMboData.iTradingStatus ;
                        iVolTradedToday         =       pMboMbpUpd->pMboData.iVolumeTradedToday;
                        fTempLtp                =       ((DOUBLE64)pMboMbpUpd->pMboData.iLastTradedPrice)/CONST_PRICE_FACTOR ;
                        fNetPriceChange         =       ((DOUBLE64)pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice)/CONST_PRICE_FACTOR ;
                        iLastTradedQty          =       pMboMbpUpd->pMboData.iLastTradeQuantity ;
                        iLastTradeTime          =       pMboMbpUpd->pMboData.iLastTradeTime ;
                        fAvgTradePrice          =       ((DOUBLE64)pMboMbpUpd->pMboData.iAverageTradePrice)/CONST_PRICE_FACTOR ;
                        iAuctionNumber          =       pMboMbpUpd->pMboData.iAuctionNumber ;
                        iAuctionStatus          =       pMboMbpUpd->pMboData.iAuctionStatus ;
                        iInitiatorType          =       pMboMbpUpd->pMboData.iInitiatorType ;
                        fInitiatorPrice         =       ((DOUBLE64)pMboMbpUpd->pMboData.iInitiatorPrice)/CONST_PRICE_FACTOR ;
                        iInitiatorQty           =       pMboMbpUpd->pMboData.iInitiatorQuantity ;
                        fAuctionPrice           =       ((DOUBLE64)pMboMbpUpd->pMboData.iAuctionPrice)/CONST_PRICE_FACTOR ;
                        iAuctionQty             =       pMboMbpUpd->pMboData.iAuctionQuantity ;
                        iBbTotalBuyFlg          =       pMboMbpUpd->iBbTotalBuyFlag;
                        iBbTotalSellFlg         =       pMboMbpUpd->iBbTotalSellFlag;
                        fTotalBuyQty            =       pMboMbpUpd->fTotalBuyQuantity;
                        fTotalSellQty           =       pMboMbpUpd->fTotalSellQuantity;
                        fClosePrice             =       ((DOUBLE64)pMboMbpUpd->iClosingPrice)/CONST_PRICE_FACTOR;
                        fOpenPrice              =       ((DOUBLE64)pMboMbpUpd->iOpenPrice)/CONST_PRICE_FACTOR;
                        fHighPrice              =       ((DOUBLE64)pMboMbpUpd->iHighPrice)/CONST_PRICE_FACTOR;
                        fLowPrice               =       ((DOUBLE64)pMboMbpUpd->iLowPrice)/CONST_PRICE_FACTOR;

                        printf("\n pMboMbpUpd->pMboData.iToken 			:%d:",pMboMbpUpd->pMboData.iToken);
                        printf("\n pMboMbpUpd->pMboData.iBookType 		:%d:",pMboMbpUpd->pMboData.iBookType);
                        printf("\n pMboMbpUpd->pMboData.iTradingStatus 		:%d:",pMboMbpUpd->pMboData.iTradingStatus);
                        printf("\n pMboMbpUpd->pMboData.iVolumeTradedToday 	:%d:",pMboMbpUpd->pMboData.iVolumeTradedToday);
                        printf("\n pMboMbpUpd->pMboData.iLastTradedPrice 	:%d:",pMboMbpUpd->pMboData.iLastTradedPrice);
                        printf("\n pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice :%d:",pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice);
                        printf("\n pMboMbpUpd->pMboData.iLastTradeQuantity 	:%d:",pMboMbpUpd->pMboData.iLastTradeQuantity);
                        printf("\n pMboMbpUpd->pMboData.iLastTradeTime 		:%d:",pMboMbpUpd->pMboData.iLastTradeTime);
                        printf("\n pMboMbpUpd->pMboData.iAverageTradePrice 	:%d:",pMboMbpUpd->pMboData.iAverageTradePrice);
                        printf("\n pMboMbpUpd->pMboData.iAuctionNumber 		:%d:",pMboMbpUpd->pMboData.iAuctionNumber);
                        printf("\n pMboMbpUpd->pMboData.iAuctionStatus 		:%d:",pMboMbpUpd->pMboData.iAuctionStatus);
                        printf("\n pMboMbpUpd->pMboData.iInitiatorType 		:%d:",pMboMbpUpd->pMboData.iInitiatorType);
                        printf("\n pMboMbpUpd->pMboData.iInitiatorPrice 	:%d:",pMboMbpUpd->pMboData.iInitiatorPrice);
                        printf("\n pMboMbpUpd->pMboData.iInitiatorQuantity 	:%d:",pMboMbpUpd->pMboData.iInitiatorQuantity);
                        printf("\n pMboMbpUpd->pMboData.iAuctionPrice 		:%d:",pMboMbpUpd->pMboData.iAuctionPrice);
                        printf("\n pMboMbpUpd->pMboData.iAuctionQuantit 	:%d:",pMboMbpUpd->pMboData.iAuctionQuantity);
                        printf("\n pMboMbpUpd->fTotalBuyQuantity 		:%d:",pMboMbpUpd->fTotalBuyQuantity);
                        printf("\n pMboMbpUpd->fTotalSellQuantity  		:%d:",pMboMbpUpd->fTotalSellQuantity);
                        printf("\n pMboMbpUpd->iClosingPrice  			:%d:",pMboMbpUpd->iClosingPrice);
                        printf("\n pMboMbpUpd->iOpenPrice  			:%d:",pMboMbpUpd->iOpenPrice);
                        printf("\n pMboMbpUpd->iHighPrice  			:%d:",pMboMbpUpd->iHighPrice);
                        printf("\n pMboMbpUpd->iLowPrice  			:%d:",pMboMbpUpd->iLowPrice);

			for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
                        {
                                iTrdadeid       =       (pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid);
                                iQty            =       (pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
                                fPrice          =       ((DOUBLE64)pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice)/CONST_PRICE_FACTOR;
                                iMinFillQty     =       (pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty);

                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid);
                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice);
                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty :%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty);

                                iMbpQty         =       (pMboMbpUpd->pMBPRecords[iRecord].iQty);
                                fMbpPrice       =       ((DOUBLE64)pMboMbpUpd->pMBPRecords[iRecord].iPrice)/CONST_PRICE_FACTOR;
                                iNoOfOrders     =       (pMboMbpUpd->pMBPRecords[iRecord].iNoOfOrders);
                                iBbBuySellFlg   =       (pMboMbpUpd->pMBPRecords[iRecord].iBbBuySellFlg);

                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice 	:%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice);
                                printf("\n pMboMbpUpd->pMboData.pMBORecords[iRecord].iNoOfOrders :%d:",pMboMbpUpd->pMboData.pMBORecords[iRecord].iNoOfOrders);

                                sprintf(sInsertQry,"INSERT INTO MBO_MBP_L1_WATCH (L1_LTP,L1_BOOK_TYPE ,L1_TRADING_STATUS ,\
                                        L1_VOL_TRD_TODAY  ,L1_SCRIP_CODE,L1_EXCH_SCRIP_CODE,L1_NET_PRICE_CHG ,\
                                        L1_LAST_TRD_QTY ,L1_LAST_TRADE_TIME ,L1_AVG_TRADE_PRICE ,L1_AUCT_NUM  , L1_AUCT_STAT ,\
                                        L1_IND_PRICE ,L1_IND_QTY ,L1_AUCT_PRICE, L1_AUCT_QTY ,\
                                        L1_BUY_BCK_TOTAL_BUY_FLG ,L1_BUY_BCK_TOTAL_SELL_FLG ,L1_TOTAL_BUY_QTY  ,\
                                        L1_TOTAL_SELL_QTY  ,L1_CLOSE_PRICE  ,L1_OPEN_PRICE  ,L1_HIGH_PRICE  , L1_LOW_PRICE ,\
                                        L1_EXCHANGE ,L1_SEGMENT,L1_ENTRY_TIME,L1_MBP_QTY,L1_MBP_PRICE,\
                                        L1_MBP_NO_OF_ORDERS,L1_BUY_SELL_IND,L1_MBO_TRD_ID,L1_MBO_QTY,L1_MBO_PRICE,L1_MIN_FILL_QTY,L1_SEQ)\
                                                VALUES(%f,%d,%d,%d,%d,%d,%f,%d,%d,%f,%d,%d,%f,%d,%f,%d,%d,%d,%f,\
                                                        %f,%f,%f,%f,%f,\"%s\",\'%c\',NOW(),%d,%f,%d,%d,%d,%d,%f,%d,%d)",\
                                                fTempLtp,iBookType,iTradingStatus,iVolTradedToday,iTempScripCode,iTempScripCode,\
                                                fNetPriceChange,iLastTradedQty,iLastTradeTime,fAvgTradePrice,\
                                                iAuctionNumber,iAuctionStatus,fInitiatorPrice,iInitiatorQty,\
                                                fAuctionPrice,iAuctionQty,iBbTotalBuyFlg,iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,\
                                                fClosePrice,fOpenPrice,fHighPrice,fLowPrice,NSE_EXCH,EQUITY_SEGMENT,iMbpQty,fMbpPrice,iNoOfOrders,\
                                                iBbBuySellFlg,iTrdadeid,iQty,fPrice,iMinFillQty,iRecord);
                                logDebug2("sInsertQry -> %s",sInsertQry);

                                if(mysql_query(ENMbp_con, sInsertQry) != SUCCESS)
                                {
                                        logSqlFatal("###### SQL Failed  ######");
                                        sql_Error(ENMbp_con);
                                }
                                else
                                {
                                        mysql_commit(ENMbp_con);
                                        logInfo(" Trade Commit sucessful");                 
                                }
                   
                            }
                             break;

			default :
			logDebug2("Received Wrong MsgCode %d ",iTranscodeLocal);	
			break ;
		}
		/**
		 ***/
	}
	logTimestamp("EXIT [fBcastUpdt]");
}

