#include "HashTable.h"
#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include <my_global.h>
#include <mysql.h>

//inserted by @pratik 
#include "RedisStruct.h"
#include "hiredis.h"

struct THREAD_PARAMS
{
	MYSQL *DB_Con;
	LONG32 thread_id;
};
INT16 iMbpCount = 0 ;
//BOOL  fBcastUpdt(void *parameter);
BOOL  fBcastUpdt();
/* function to check Message queue status*/
int GetQStatus( int MsgQuery);
MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32  rcvQ;
LONG32  iSendQ;
MYSQL 	*ENMbp_con;
int GetQStatus( int MsgQuery);


// inserted by @pratik for radis
redisContext *c;
redisReply *reply;
INT16   iTranscodeLocal;
INT16   iExpSec;


main(int argv,char *argc[])
{
	logTimestamp("ENTRY [Main]");
	LONG32 	iFlag;
	LONG32 	i;
	LONG32	iNseRecordCount;
	CHAR	cMaxNoThread;
	LONG32	iMaxNoThread;


	cMaxNoThread  = argc[1][0];	

	iMaxNoThread = cMaxNoThread - '0';

	logDebug3("iMaxNoThread :%d: cMaxNoThread :%c:",iMaxNoThread,cMaxNoThread);

	//struct THREAD_PARAMS params[iMaxNoThread];


	setbuf(stdout,0);
	//pthread_t thread_id[iMaxNoThread];


	logDebug2("Connecting to Database.......");
	ENMbp_con=DB_Connect();
	logDebug2("Connecting to Redis.......");
	c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	// inserted by @pratik for fatching sec value from env 	
	if(getenv("REDIS_KEY_EXP_SEC")== NULL)
        {
                iExpSec = 10;
                logFatal("Error : Environment variables missing : REDIS_KEY_EXP_SEC ");
        }
        else
        {

                iExpSec = atoi(getenv("REDIS_KEY_EXP_SEC"));
        }
			
	LONG32	iSegment;



	if(mysql_autocommit(ENMbp_con,1))
	{
		sql_Error(ENMbp_con);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}
	// Opening and Reading from MemMap Queue @nitish
	// Direct reading from Spltr to mbp for Radis Set & get @pratik
	if((rcvQ=OpenMsgQ(ENBSpltrToMbpUpld))==ERROR)
	{
		perror("\n Error in Opening BcasttoMbpMbo....");
		exit(ERROR);
	}

	logDebug2("Message Queue opened BcasttoMbpMbo : %d:",ENBSpltrToMbpUpld);
	if((iSendQ=OpenMsgQ(ENMbpToLTPUpd))==ERROR)
	{
		perror("\n Error in Opening ENMbpToLTPUpd....");
		exit(ERROR);
	}
	logDebug2("Message Queue opened ENMbpToLTPUpd : %d:",ENMbpToLTPUpd);

	mysql_free_result(result);

	fBcastUpdt();
	/*	
	for(i=0;i<iMaxNoThread;i++)
	{
		params[i].thread_id=i;
		params[i].DB_Con = DB_Connect();	

		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,(void *)&params[i]))!=0)
			logDebug2("Cant create thread %d",i);
		else
			logDebug2("Created");

	}

	logDebug2("ALOK HERE 1 ");

	for(i=0;i<iMaxNoThread;i++)
	{
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logDebug2("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logDebug2("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}
	*/
	logTimestamp("EXIT [MAin]");
}

//BOOL fBcastUpdt(void *parameter)
BOOL fBcastUpdt()
{
	logTimestamp("ENTRY [fBcastUpdt]");
	INT16	i;
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];
	//struct THREAD_PARAMS *l_parameter = parameter;
	struct	NNF_HEADER *pForRecTransCode;
	LONG32	iCount;
	BOOL	iRetVal = FALSE;

	while(TRUE)
	{
		memset(&sRcvMsg,' ',LOCAL_MAX_PACKET_SIZE);


		if((ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		pForRecTransCode = (struct NNF_HEADER *) sRcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgCode;
		logDebug2("iTranscodeLocal[%d]",iTranscodeLocal);
		if(iTranscodeLocal == TC_TICKER_INDEX_BCAST)
		{
			fTC_TICKER_INDEX_BCAST(sRcvMsg);	
		}
		else if (iTranscodeLocal == TC_TICKER_INDEX_BCAST_TNDTC)
                {
                        fTC_TICKER_INDEX_BCAST_TNDTC(sRcvMsg);
                }
		else if (iTranscodeLocal == TC_CALL_AUCTION_MBP)
		{
			//	Adding CA2 Broadcast in NSE CM for New Listing Orer Entry @Nitish
			fTC_CALL_AUCTION_MBP(sRcvMsg);
		}
		else if (iTranscodeLocal == TC_CALL_AUCTION_MBP_TNDTC)
                {
                        fTC_CALL_AUCTION_MBP_TNDTC(sRcvMsg);
                }

	}
	logTimestamp("EXIT [fBcastUpdt]");
}



BOOL fTC_TICKER_INDEX_BCAST(char *NNFData)
{
	logTimestamp("ENTRY [fTC_TICKER_INDEX_BCAST]");

	CHAR 		supdate [MAX_QUERY_SIZE];	
	LONG32		iRecordNumber = 0;
	LONG32 		TempScripCode;
	DOUBLE64 	TempLtp,fLtpRedis = 0.00;
	LONG32 		TempTradeVolume;
	LONG32          TempMktType;
	// insert by @pratik 
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];  
        CHAR sKeyValue[RADIS_KEY_LEN];
	LONG32 iCount;
	struct          REDIS_LTP_UPD	*pRedLTP;
	struct NNF_TICKER_TRADE_BCAST         *pTickerData;
	pTickerData = (struct  NNF_TICKER_TRADE_BCAST *) NNFData;

	CHAR	NormlMkt [MKT_TYPE_LEN];
	memset (&NormlMkt ,'\0',MKT_TYPE_LEN);

	CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR 	sUpdateQry[MAX_QUERY_SIZE];
	logDebug2("7202 LTP");

	logDebug2("pTickerData->iNoOfRecords :%d",pTickerData->iNoOfRecords);

	for(iRecordNumber = 0;iRecordNumber < pTickerData->iNoOfRecords; iRecordNumber++)
	{
		logTimestamp(">>>>>>>>>>>>>>>>>>>>>>>> Loop Time stamp <<<<<<<<<<<<<<<<<<<<<<<<<<<<< ");
		memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
		memset(&supdate,'\0',MAX_QUERY_SIZE);
		memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
		TempScripCode 	= pTickerData->TickerIndexInfo[iRecordNumber].iToken;
		TempMktType 	= pTickerData->TickerIndexInfo[iRecordNumber].iMarketType ;
		TempLtp 	= ((DOUBLE64)pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice)/CONST_PRICE_FACTOR;

		logDebug2("TempScripCode :%d:",TempScripCode);
		logDebug2("TempMktType :%i:",TempMktType);
		logDebug2(" LTP [%lf]",TempLtp);


			switch(TempMktType)
			{
				case NORMAL_MARKET:
					strncpy(NormlMkt,MKT_TYPE_NL,MKT_TYPE_LEN);
					break;

				case ODDLOT_MARKET:
					strncpy(NormlMkt,MKT_TYPE_OL,MKT_TYPE_LEN);
					break;

				case SPOT_MARKET:
					strncpy(NormlMkt,MKT_TYPE_SP,MKT_TYPE_LEN);
					break;

				case AUCTION_MARKET:
					strncpy(NormlMkt,MKT_TYPE_AU,MKT_TYPE_LEN);
					break;

				case CALL_AUCTION_MARKET1:
					strncpy(NormlMkt,MKT_TYPE_CAU_1,MKT_TYPE_LEN);
					break;

				case CALL_AUCTION_MARKET2:
					strncpy(NormlMkt,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
					break;

				default :

					logDebug2("MktType received in Junk");
					break;

			}	
			/***/
			//if (TRUE)//(TempMktType == NORMAL_MARKET)
			// Comment by @pratik for redis
//			if (TempMktType == NORMAL_MARKET)
//			{
/***
			 	sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
			  	(L1_EXCHANGE ,\
			  	L1_SEGMENT,\
			  	L1_SCRIP_CODE,\
			  	L1_EXCH_SCRIP_CODE,\
			  	L1_MARKET_TYPE,\
			  	L1_ENTRY_TIME,\
			  	L1_LTP )\
			  	VALUES(\"%s\",\'%c\',%d,%d,\"%s\",NOW(),%lf)\
			  	on duplicate key \
			  	UPDATE \
			  	L1_EXCHANGE = VALUES(L1_EXCHANGE) ,\
			  	L1_SEGMENT = VALUES(L1_SEGMENT) ,\
			  	L1_SCRIP_CODE = VALUES(L1_SCRIP_CODE) ,\
			  	L1_EXCH_SCRIP_CODE = VALUES(L1_EXCH_SCRIP_CODE) ,\
			  	L1_MARKET_TYPE = VALUES(L1_MARKET_TYPE) ,\
			  	L1_ENTRY_TIME = NOW() ,\
			  	L1_LTP  = VALUES(L1_LTP); ",NSE_EXCH,SEGMENT_EQUITY,TempScripCode,TempScripCode,NormlMkt,TempLtp);
****/
//comment by @pratik for redis
		/*		sprintf(sUpdateQry,"UPDATE EQ_L1_WATCH SET L1_LTP = %lf,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \'%d\' AND L1_LTP <> %lf ;",TempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,TempScripCode,TempLtp);


				logDebug2("sUpdateQry Query[%s]",sUpdateQry);
				if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
				{
					logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
					sql_Error(ENMbp_con);
				}
				else
				{
					logDebug2("------SUCCESS IN INSERT QUERY-----");
					if(mysql_affected_rows(ENMbp_con) == 0)
					{
						sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
                                			(L1_EXCHANGE ,\
                                			L1_SEGMENT,\
                                			L1_SCRIP_CODE,\
                                			L1_EXCH_SCRIP_CODE,\
                                			L1_MARKET_TYPE,\
                                			L1_ENTRY_TIME,\
                                			L1_LTP )\
                                			VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf)",NSE_EXCH,SEGMENT_EQUITY,TempScripCode,TempScripCode,NormlMkt,TempLtp);
						logDebug2("sInsertQry :%s:",sInsertQry);	
						if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
                                		{
                                        		logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
                                        		sql_Error(ENMbp_con);
                                		}
					}
					mysql_commit(ENMbp_con);

					
				}
			 	

				sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f ,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",TempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,TempScripCode);

				logDebug2(" Update Query[%s]",supdate);	

				if(mysql_query(ENMbp_con,supdate) != SUCCESS)
				{
					logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
					sql_Error(ENMbp_con);
				}
				else
				{
					mysql_commit(ENMbp_con);

					logDebug2("------SUCCESS IN LTP UPDATE-----");
					logDebug2("TempScripCode :%d:",TempScripCode);
					logDebug2(" LTP [%lf]",TempLtp);
					fSendLTPtoRed(TempScripCode,TempLtp);
				}
			}*/


		// inserted by @pratik for radis get & set 
	 if (TempMktType == NORMAL_MARKET)
         {		
	
		memset(sKeyValue,'\0',RADIS_KEY_LEN);
		sprintf(sKeyValue,"%s:%c:%d",NSE_EXCH,SEGMENT_EQUITY,TempScripCode);
		memset(sCommand,'\0',COMMAND_LEN);
		memset(sCommand1,'\0',COMMAND_LEN);
		sprintf(sCommand,"HMGET %s LTP",sKeyValue);
		logDebug2("KEY VALUE %s",sKeyValue);
		reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
		logDebug2("reply->len %d",reply->len);
		logDebug2("Received message LTP : %s",reply->element[0]->str);
		if(reply->element[0]->str != NULL)
		{
	        	iCount = reply->elements;
	        	logDebug2("ELEMENT COUNT =%d ",iCount);
	        	logDebug2("Received message LTP : %s",reply->element[0]->str);
			fLtpRedis = atof(reply->element[0]->str);
			freeReplyObject(reply);
		
			if(fLtpRedis == TempLtp)
			{
				logDebug2("No Need To Update LTP in DB");
			}else{
			
				memset(sCommand,'\0',COMMAND_LEN);
				sprintf(sCommand,"HMSET %s LTP %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c ",sKeyValue,TempLtp,TempScripCode,NormlMkt,NSE_EXCH,iTranscodeLocal,SEGMENT_EQUITY);
				logTimestamp("sCommand -> %s",sCommand);
	                	reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
				freeReplyObject(reply);

				sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
				logTimestamp("sCommand1 -> %s",sCommand1);
                                reply = fRedisCommand(c,sCommand1,REDIS_TYPE_PRICE_BCAST);
                                freeReplyObject(reply);

				memset(sCommand,'\0',COMMAND_LEN);
				sprintf(sCommand,"PUBLISH OMSNSECM %s",sKeyValue);
				logTimestamp("sCommand -> %s",sCommand);
	                	reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
	                	logDebug2("INCR counter: %lld", reply->integer);
	                	freeReplyObject(reply);	

				memset(sCommand,'\0',COMMAND_LEN);
                                sprintf(sCommand,"HMSET %s:%s%c%d %s %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c ",SET_L1_WATCH,NSE_EXCH,SEGMENT_EQUITY,TempScripCode,SM_LTP,TempLtp,TempScripCode,NormlMkt,NSE_EXCH,iTranscodeLocal,SEGMENT_EQUITY);
                                logTimestamp("sCommand -> %s",sCommand);
                                reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                                freeReplyObject(reply);
			}
		}else{
			freeReplyObject(reply);	
			memset(sCommand,'\0',COMMAND_LEN);
			memset(sCommand1,'\0',COMMAND_LEN);
	                sprintf(sCommand,"HMSET %s LTP %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c ",sKeyValue,TempLtp,TempScripCode,NormlMkt,NSE_EXCH,iTranscodeLocal,SEGMENT_EQUITY);
	                logTimestamp("sCommand -> %s",sCommand);
	                reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
	                freeReplyObject(reply);

			sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                        logTimestamp("sCommand1 -> %s",sCommand1);
                        reply = fRedisCommand(c,sCommand1,REDIS_TYPE_PRICE_BCAST);
                        freeReplyObject(reply);			

	                memset(sCommand,'\0',COMMAND_LEN);
	                sprintf(sCommand,"PUBLISH OMSNSECM %s",sKeyValue);
	                logTimestamp("sCommand -> %s",sCommand);
	                reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
	                logDebug2("INCR counter: %lld", reply->integer);
                        freeReplyObject(reply);			
			
			memset(sCommand,'\0',COMMAND_LEN);
                        sprintf(sCommand,"HMSET %s:%s%c%d %s %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c ",SET_L1_WATCH,NSE_EXCH,SEGMENT_EQUITY,TempScripCode,SM_LTP,TempLtp,TempScripCode,NormlMkt,NSE_EXCH,iTranscodeLocal,SEGMENT_EQUITY);
                        logTimestamp("sCommand -> %s",sCommand);
                        reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                        freeReplyObject(reply);
		}
		
	}
	
	}
	logTimestamp("EXIT [fTC_TICKER_INDEX_BCAST]");
	return TRUE;
}


/*BOOL fTC_MBP_BCAST (char *NNFData)
{

	logTimestamp("ENTRY [7208 fTC_MBP_BCAST]");

	LONG32 iRecordNumber,iTotalRecord;
	NNF_MBP_BCAST  *pMbpBcast = ( NNF_MBP_BCAST *) NNFData;

	CHAR            supdate [MAX_QUERY_SIZE];
	CHAR            sUpdQry [MAX_QUERY_SIZE];
	CHAR		sInsertQry [MAX_QUERY_SIZE];
	memset(&supdate,'\0',MAX_QUERY_SIZE);
	memset(&sInsertQry ,'\0',MAX_QUERY_SIZE);
	memset(&sUpdQry,'\0',MAX_QUERY_SIZE);

	LONG32          iTempScripCode =0 ;
	DOUBLE64        fTempLtp=0.00 , fTotalBuyQty =0.00 , fTotalSellQty  =0.00 ,fClosePrice = 0.00,fOpenPrice = 0.00 , fHighPrice = 0.00 , fLowPrice = 0.00 , fLtpRedis = 0.00;
	DOUBLE64	fPrice = 0.00  ,fNetPriceChange = 0.00 ,fAvgTradePrice = 0.00  , fInitiatorPrice = 0.00 ,fAuctionPrice = 0.00 ;
	LONG32		iVolTradedToday  =0 ,  iNetPriceChange =0 ,iLastTradedQty  =0 , iLastTradeTime  =0 ,iAvgTradePrice  =0 ,iBookType = 0;
	LONG32		 iAuctionNumber	 =0 , iAuctionStatus  =0 ,iInitiatorType = 0 ,iTradingStatus = 0 , iTempLtp = 0;
	LONG32		iInitiatorPrice  =0 , iInitiatorQty  =0 ,iAuctionPrice  =0 , iAuctionQty  =0 ,iBbTotalBuyFlg = 0 ,iBbTotalSellFlg  =0 ,iNoRecords = 0 ;
	LONG32		iQty = 0,iBbBuySellFlg = 0 ,iRowsAffcted = 0 , iNoOfOrders = 0;
	CHAR		cNetChangeIndicator = '0';
	// Was Uncommented bcoz of A2 bcast in system. Now will recv with 7214 
	CHAR	NormlMkt [MKT_TYPE_LEN];
	memset (&NormlMkt ,'\0',MKT_TYPE_LEN);


	logDebug2("pMbpBcast->iNoOfRecs :%d:",pMbpBcast->iNoOfRecs);
	for(iTotalRecord = 0;iTotalRecord <pMbpBcast->iNoOfRecs; iTotalRecord++)
	{
		memset (&NormlMkt ,'\0',MKT_TYPE_LEN);

		iTempScripCode 	= 	pMbpBcast->pMBPInfo[iTotalRecord].iToken ;
		iBookType 	=	pMbpBcast->pMBPInfo[iTotalRecord].iBookType;
		iTradingStatus	=	pMbpBcast->pMBPInfo[iTotalRecord].iTradingStatus;
		iVolTradedToday =        pMbpBcast->pMBPInfo[iTotalRecord].iVolTradedToday;
		fTempLtp 	= ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice)/CONST_PRICE_FACTOR;
		fNetPriceChange	= ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iNetPriceChange)/CONST_PRICE_FACTOR ;
		iLastTradedQty 	= 	pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedQty;
		iLastTradeTime	=        pMbpBcast->pMBPInfo[iTotalRecord].iLastTradeTime;
		fAvgTradePrice	=     ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iAvgTradePrice)/CONST_PRICE_FACTOR;
		iAuctionNumber	=	pMbpBcast->pMBPInfo[iTotalRecord].iAuctionNumber;
		iAuctionStatus  =	pMbpBcast->pMBPInfo[iTotalRecord].iAuctionStatus;
		iInitiatorType	=        pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorType;
		fInitiatorPrice	=        ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorPrice)/CONST_PRICE_FACTOR;
		iInitiatorQty	=        pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorQty;
		fAuctionPrice	= ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iAuctionPrice)/CONST_PRICE_FACTOR;
		iAuctionQty 	=	pMbpBcast->pMBPInfo[iTotalRecord].iAuctionQty;
		iBbTotalBuyFlg	=        pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalBuyFlg;
		iBbTotalSellFlg	=        pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalSellFlg;
		fTotalBuyQty	=        pMbpBcast->pMBPInfo[iTotalRecord].fTotalBuyQty;
		fTotalSellQty	=        pMbpBcast->pMBPInfo[iTotalRecord].fTotalSellQty;

		fClosePrice	=        ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iClosePrice)/CONST_PRICE_FACTOR;
		fOpenPrice	=       ((DOUBLE64) pMbpBcast->pMBPInfo[iTotalRecord].iOpenPrice)/CONST_PRICE_FACTOR;
		fHighPrice	=       ((DOUBLE64) pMbpBcast->pMBPInfo[iTotalRecord].iHighPrice)/CONST_PRICE_FACTOR;
		fLowPrice	=        ((DOUBLE64)pMbpBcast->pMBPInfo[iTotalRecord].iLowPrice)/CONST_PRICE_FACTOR;


		logDebug2("------------Printing MBP Packet-----------------");
		logDebug2("iTempScripCode 	:%d:",iTempScripCode);
		logDebug2("iBookType		:%d:",iBookType);
		logDebug2("iTradingStatus	:%d:",iTradingStatus);
		logDebug2("iVolTradedToday	:%d:",iVolTradedToday);
		logDebug2("fTempLtp 		:%lf:",fTempLtp);
		logDebug2("cNetChangeIndicator	:%c:",cNetChangeIndicator);
		logDebug2("iNetPriceChange	:%d:",iNetPriceChange);
		logDebug2("iLastTradedQty	:%d:",iLastTradedQty);
		logDebug2("iLastTradeTime	:%d:",iLastTradeTime);
		logDebug2("iAvgTradePrice	:%d:",iAvgTradePrice);
		logDebug2("iAuctionNumber	:%d:",iAuctionNumber);	
		logDebug2("iAuctionStatus	:%d:",iAuctionStatus);
		logDebug2("iInitiatorType	:%d:",iInitiatorType);
		logDebug2("iInitiatorPrice	:%d:",iInitiatorPrice);	
		logDebug2("iInitiatorQty	:%d:",iInitiatorQty);
		logDebug2("iAuctionPrice	:%d:",iAuctionPrice);
		logDebug2("iAuctionQty		:%d:",iAuctionQty);

		logDebug2("iBbTotalBuyFlg	:%d:",iBbTotalBuyFlg);
		logDebug2("iBbTotalSellFlg	:%d:",iBbTotalSellFlg);
		logDebug2("iBbTotalBuyFlg	:%d:",iBbTotalBuyFlg);	
		logDebug2("fTotalBuyQty		:%f:",fTotalBuyQty);
		logDebug2("fTotalSellQty	:%f:",fTotalSellQty);
		logDebug2("fClosePrice		:%f:",fClosePrice);
		logDebug2("fOpenPrice		:%f:",fOpenPrice);
		logDebug2("fHighPrice		:%lf:",fHighPrice);
		logDebug2("fLowPrice		:%lf:",fLowPrice);
		logDebug2("------------------------END----------------------");
		// Was Uncommented bcoz of A2 bcast in system. Now will recv with 7214 
		if(iTradingStatus == 2 || iTradingStatus == 1)
		{
			strncpy(NormlMkt,MKT_TYPE_NL,MKT_TYPE_LEN);
		}
		else if(iBookType == 6)
		{
			strncpy(NormlMkt,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
				
		}
		else
		{
			logInfo("Invalid MKT Type :%d:",iBookType);
			continue;
		}

		sprintf(supdate,"UPDATE EQ_L1_WATCH SET L1_LTP = %lf ,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \'%d\'  AND L1_LTP <> %lf ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,NormlMkt,fTempLtp);

		logDebug2("Query :%s:",supdate);

		if(mysql_query(ENMbp_con,supdate) != SUCCESS)
		{

			logSqlFatal(" In Function [TC_MBP_BCAST]-->ERROR IN INSERT QUERY->EQ_L1_WATCH  ");
			sql_Error(ENMbp_con);
		}
		else
		{
			mysql_commit(ENMbp_con);
			logDebug2("------SUCCESS IN INSERT QUERY-----");
                        if(mysql_affected_rows(ENMbp_con) == 0)
                        {
                        	sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
                        	(L1_EXCHANGE ,\
                        	L1_SEGMENT,\
                        	L1_SCRIP_CODE,\
                        	L1_EXCH_SCRIP_CODE,\
                        	L1_MARKET_TYPE,\
                        	L1_ENTRY_TIME,\
                        	L1_LTP )\
                       	 	VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf)",NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);
                        	logDebug2("sInsertQry :%s:",sInsertQry);
                        	if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
                        	{
                        		logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
                        		sql_Error(ENMbp_con);
                        	}
                        }
                        mysql_commit(ENMbp_con);
		}

		sprintf(sUpdQry,"UPDATE L1_WATCH_ACTIVE SET L1_LTP = %f ,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);

		logDebug2("sUpdQry :%s:",sUpdQry);


		if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
		{

			logDebug2(" Update Query[%s]",sUpdQry);
			logSqlFatal("In Function [TC_MBP_BCAST]-->ERROR IN LTP UPDATE-->L1_WATCH_ACTIVE");
			sql_Error(ENMbp_con);
		}
		else
		{
			mysql_commit(ENMbp_con);
			logDebug2("------SUCCESS IN LTP UPDATE-----");
		}
	}
	logTimestamp("EXIT [fTC_MBP_BCAST]");
	return TRUE;
}*/

//	Adding CA2 Broadcast in NSE CM for New Listing Orer Entry @Nitish
BOOL fTC_CALL_AUCTION_MBP(char *NNFData)
{

        logTimestamp("ENTRY [7214 fTC_CALL_AUCTION_MBP]");

        LONG32 iRecordNumber,iTotalRecord;
        struct NNF_CALL_AUCTION_MBP 	*pMbpBcast = ( struct NNF_CALL_AUCTION_MBP *) NNFData;

        CHAR            supdate [MAX_QUERY_SIZE];
        CHAR            sUpdQry [MAX_QUERY_SIZE];
        CHAR            sInsertQry [MAX_QUERY_SIZE];
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN]; 
        CHAR sKeyValue[RADIS_KEY_LEN];
        LONG32 iCount;
        memset(&supdate,'\0',MAX_QUERY_SIZE);
        memset(&sInsertQry ,'\0',MAX_QUERY_SIZE);
        memset(&sUpdQry,'\0',MAX_QUERY_SIZE);

        LONG32          iTempScripCode =0 ;
        DOUBLE64        fTempLtp=0.00 , fTotalBuyQty =0.00 , fTotalSellQty  =0.00 ,fClosePrice = 0.00,fOpenPrice = 0.00 , fHighPrice = 0.00 , fLowPrice = 0.00,fLtpRedis = 0.00;
        DOUBLE64        fPrice = 0.00  ,fNetPriceChange = 0.00 ,fAvgTradePrice = 0.00  , fInitiatorPrice = 0.00 ,fAuctionPrice = 0.00 ;
        LONG32          iVolTradedToday  =0 ,  iNetPriceChange =0 ,iLastTradedQty  =0 , iLastTradeTime  =0 ,iAvgTradePrice  =0 ,iBookType = 0;
        LONG32           iAuctionNumber  =0 , iAuctionStatus  =0 ,iInitiatorType = 0 ,iTradingStatus = 0 , iTempLtp = 0;
        LONG32          iInitiatorPrice  =0 , iInitiatorQty  =0 ,iAuctionPrice  =0 , iAuctionQty  =0 ,iBbTotalBuyFlg = 0 ,iBbTotalSellFlg  =0 ,iNoRecords = 0 ;
        LONG32          iQty = 0,iBbBuySellFlg = 0 ,iRowsAffcted = 0 , iNoOfOrders = 0;
        CHAR            cNetChangeIndicator = '0';

	CHAR    NormlMkt [MKT_TYPE_LEN];
        memset (&NormlMkt ,'\0',MKT_TYPE_LEN);


        logDebug2("pMbpBcast->iNoOfRecs :%d:",pMbpBcast->iNoOfRecs);
        for(iTotalRecord = 0;iTotalRecord <pMbpBcast->iNoOfRecs; iTotalRecord++)
        {
                memset (&NormlMkt ,'\0',MKT_TYPE_LEN);

                iTempScripCode  =       pMbpBcast->pCallAucMbp[iTotalRecord].iToken ;
                iBookType       =       pMbpBcast->pCallAucMbp[iTotalRecord].iBookType;
                iTradingStatus  =       pMbpBcast->pCallAucMbp[iTotalRecord].iTradingStatus;
                iVolTradedToday =        pMbpBcast->pCallAucMbp[iTotalRecord].iVolTradedToday;
                fTempLtp        = ((DOUBLE64)pMbpBcast->pCallAucMbp[iTotalRecord].iLastTradedPrice)/CONST_PRICE_FACTOR;
                fNetPriceChange = ((DOUBLE64)pMbpBcast->pCallAucMbp[iTotalRecord].iNetPriceChange)/CONST_PRICE_FACTOR ;
                iLastTradedQty  =       pMbpBcast->pCallAucMbp[iTotalRecord].iLastTradedQty;
                iLastTradeTime  =        pMbpBcast->pCallAucMbp[iTotalRecord].iLastTradeTime;
                fAvgTradePrice  =     ((DOUBLE64)pMbpBcast->pCallAucMbp[iTotalRecord].iAvgTradePrice)/CONST_PRICE_FACTOR;
                iBbTotalBuyFlg  =        pMbpBcast->pCallAucMbp[iTotalRecord].iBbTotalBuyFlg;
                iBbTotalSellFlg =        pMbpBcast->pCallAucMbp[iTotalRecord].iBbTotalSellFlg;
                fTotalBuyQty    =        pMbpBcast->pCallAucMbp[iTotalRecord].fTotalBuyQty;
                fTotalSellQty   =        pMbpBcast->pCallAucMbp[iTotalRecord].fTotalSellQty;

                fClosePrice     =        ((DOUBLE64)pMbpBcast->pCallAucMbp[iTotalRecord].iClosePrice)/CONST_PRICE_FACTOR;
                fOpenPrice      =       ((DOUBLE64) pMbpBcast->pCallAucMbp[iTotalRecord].iOpenPrice)/CONST_PRICE_FACTOR;
                fHighPrice      =       ((DOUBLE64) pMbpBcast->pCallAucMbp[iTotalRecord].iHighPrice)/CONST_PRICE_FACTOR;
                fLowPrice       =        ((DOUBLE64)pMbpBcast->pCallAucMbp[iTotalRecord].iLowPrice)/CONST_PRICE_FACTOR;


                logDebug2("------------Printing MBP Packet-----------------");
                logDebug2("iTempScripCode       :%d:",iTempScripCode);
                logDebug2("iBookType            :%d:",iBookType);
                logDebug2("iTradingStatus       :%d:",iTradingStatus);
                logDebug2("iVolTradedToday      :%d:",iVolTradedToday);
                logDebug2("fTempLtp             :%lf:",fTempLtp);
                logDebug2("cNetChangeIndicator  :%c:",cNetChangeIndicator);
		logDebug2("iNetPriceChange      :%d:",iNetPriceChange);
                logDebug2("iLastTradedQty       :%d:",iLastTradedQty);
                logDebug2("iLastTradeTime       :%d:",iLastTradeTime);
                logDebug2("iAvgTradePrice       :%d:",iAvgTradePrice);
                logDebug2("iAuctionNumber       :%d:",iAuctionNumber);
                logDebug2("iAuctionStatus       :%d:",iAuctionStatus);
                logDebug2("iInitiatorType       :%d:",iInitiatorType);
                logDebug2("iInitiatorPrice      :%d:",iInitiatorPrice);
                logDebug2("iInitiatorQty        :%d:",iInitiatorQty);
                logDebug2("iAuctionPrice        :%d:",iAuctionPrice);
                logDebug2("iAuctionQty          :%d:",iAuctionQty);

                logDebug2("iBbTotalBuyFlg       :%d:",iBbTotalBuyFlg);
                logDebug2("iBbTotalSellFlg      :%d:",iBbTotalSellFlg);
                logDebug2("iBbTotalBuyFlg       :%d:",iBbTotalBuyFlg);
                logDebug2("fTotalBuyQty         :%f:",fTotalBuyQty);
                logDebug2("fTotalSellQty        :%f:",fTotalSellQty);
                logDebug2("fClosePrice          :%f:",fClosePrice);
                logDebug2("fOpenPrice           :%f:",fOpenPrice);
                logDebug2("fHighPrice           :%lf:",fHighPrice);
                logDebug2("fLowPrice            :%lf:",fLowPrice);
		
                if(iBookType == 12 && iTradingStatus == 6)
                {
                        strncpy(NormlMkt,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
                }
                else
                {
                        logInfo("Invalid MKT Type :%d: iTradingStatus :%d:",iBookType,iTradingStatus);
                        continue;
                }

               /*
		 sprintf(supdate,"UPDATE EQ_L1_WATCH SET L1_LTP = %lf ,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \'%d\'  AND L1_LTP <> %lf ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,NormlMkt,fTempLtp);

                logDebug2("Query :%s:",supdate);

                if(mysql_query(ENMbp_con,supdate) != SUCCESS)
                {

                        logSqlFatal(" In Function [TC_CALL_AUCTION_MBP]-->ERROR IN INSERT QUERY->EQ_L1_WATCH  ");
                        sql_Error(ENMbp_con);
                }
                else
                {
                        mysql_commit(ENMbp_con);
                        logDebug2("------SUCCESS IN INSERT QUERY-----");
                        if(mysql_affected_rows(ENMbp_con) == 0)
                        {
                                sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
                                (L1_EXCHANGE ,\
                                L1_SEGMENT,\
                                L1_SCRIP_CODE,\
                                L1_EXCH_SCRIP_CODE,\
                                L1_MARKET_TYPE,\
                                L1_ENTRY_TIME,\
                                L1_LTP )\
                                VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf)",NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);
                                logDebug2("sInsertQry :%s:",sInsertQry);

				if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
                                {
                                        logSqlFatal(" In Function [TC_CALL_AUCTION_MBP]-->ERROR Inserting In table EQ_L1_WATCH");
                                        sql_Error(ENMbp_con);
                                }
                        }
                        mysql_commit(ENMbp_con);
                }

                sprintf(sUpdQry,"UPDATE L1_WATCH_ACTIVE SET L1_LTP = %f ,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);

                logDebug2("sUpdQry :%s:",sUpdQry);


                if(mysql_query(ENMbp_con,sUpdQry) != SUCCESS)
                {

                        logDebug2(" Update Query[%s]",sUpdQry);
                        logSqlFatal("In Function [TC_CALL_AUCTION_MBP]-->ERROR IN LTP UPDATE-->L1_WATCH_ACTIVE");
                        sql_Error(ENMbp_con);
                }
                else
                {
                        mysql_commit(ENMbp_con);
                        logDebug2("------SUCCESS IN LTP UPDATE-----");
                }*/
		
		// Inserted by @pratik
		
		memset(sKeyValue,'\0',RADIS_KEY_LEN);
		sprintf(sKeyValue,"%s:%c:%d",NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);
                memset(sCommand,'\0',COMMAND_LEN);
                memset(sCommand1,'\0',COMMAND_LEN);
                sprintf(sCommand,"HMGET %s LTP",sKeyValue);
                logDebug2("KEY VALUE %s",sKeyValue);
                reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                logDebug2("reply->len %d",reply->len);
	
		if(reply->len != 0)
                {
                        iCount = reply->elements;
                        logDebug2("ELEMENT COUNT =%d ",iCount);
                        logDebug2("Received message LTP : %s",reply->element[0]->str);
                        fLtpRedis = atof(reply->element[0]->str);
                        freeReplyObject(reply);

                        if(fLtpRedis == fTempLtp)
                        {
                                logDebug2("No Need To Update LTP in DB");
                        }else{

                                memset(sCommand,'\0',COMMAND_LEN);
                                sprintf(sCommand,"HMSET %s LTP %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c ",sKeyValue,fTempLtp,iTempScripCode,NormlMkt,NSE_EXCH,iTranscodeLocal,SEGMENT_EQUITY);
                                logDebug2("sCommand -> %s",sCommand);
                                reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                                freeReplyObject(reply);
				
				sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                        	logDebug2("sCommand1 -> %s",sCommand1);
                        	reply = fRedisCommand(c,sCommand1,REDIS_TYPE_PRICE_BCAST);
                        	freeReplyObject(reply);				

                                memset(sCommand,'\0',COMMAND_LEN);
                                sprintf(sCommand,"PUBLISH OMSNSECM %s",sKeyValue);
				
				logDebug2("sCommand -> %s",sCommand);
                                reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                                logDebug2("INCR counter: %lld", reply->integer);
                                freeReplyObject(reply);
                        }
                }else{
			freeReplyObject(reply);
                        memset(sCommand,'\0',COMMAND_LEN);
                	memset(sCommand1,'\0',COMMAND_LEN);
                        sprintf(sCommand,"HMSET %s LTP %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c ",sKeyValue,fTempLtp,iTempScripCode,NormlMkt,NSE_EXCH,iTranscodeLocal,SEGMENT_EQUITY);
                        logDebug2("sCommand -> %s",sCommand);
                        reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                        freeReplyObject(reply);

			sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                        logDebug2("sCommand1 -> %s",sCommand1);
                        reply = fRedisCommand(c,sCommand1,REDIS_TYPE_PRICE_BCAST);
                        freeReplyObject(reply);	

                        memset(sCommand,'\0',COMMAND_LEN);
                        sprintf(sCommand,"PUBLISH OMSNSECM %s",sKeyValue);
                        logDebug2("sCommand -> %s",sCommand);
                        reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
                        logDebug2("INCR counter: %lld", reply->integer);
                }
					

        }

	logTimestamp("EXIT [fTC_CALL_AUCTION_MBP]");
        return TRUE;
}				

fAddtoHash (LONG32 iToken , DOUBLE64 fLTP)
{

	logTimestamp("ENTRY [fAddtoHash]");
	struct  LTP_ARRAY      *Hash_ByID = NULL;
	struct LTP_ARRAY *EqLtpHsh ,*TempLtp ;
	LONG32 i =0;

	EqLtpHsh = (struct LTP_ARRAY *)malloc(sizeof(struct LTP_ARRAY));
	TempLtp = (struct LTP_ARRAY *)malloc(sizeof(struct LTP_ARRAY));

	HASH_FIND(HashID,Hash_ByID,&iToken,strlen(iToken),TempLtp);

	if(TempLtp == NULL )
	{

		logDebug2("iToken :%d:",iToken);
		sprintf(EqLtpHsh->sTokenId,"%d",iToken) ;
		EqLtpHsh->fLtp     = fLTP;
		logDebug2("EqLtpHsh->sTokenId :%s:",EqLtpHsh->sTokenId);
		HASH_ADD(HashID,Hash_ByID ,sTokenId,strlen(EqLtpHsh->sTokenId),EqLtpHsh);
		logDebug2("Success Adding LTP to Hash");


	}
	else
	{

		if (fLTP == EqLtpHsh->fLtp)
		{
			logDebug2("Ltp Already Exit in Hash for SecurityId :%d:",iToken);
			return FALSE;
		}
		else
		{
			EqLtpHsh->fLtp     = fLTP;
			sprintf(EqLtpHsh->sTokenId,"%d",iToken) ;
			HASH_ADD(HashID,Hash_ByID,sTokenId,strlen(EqLtpHsh->sTokenId),EqLtpHsh);
		}
	}
	logTimestamp("EXIT [fAddtoHash]");	
	return TRUE;

}



BOOL fAddLtpToHash (LONG32 iToken , DOUBLE64 fLTP)
{

	logTimestamp("ENTRY [fAddLtpToHash]");
	struct  LTP_ARRAY      *Hash_ByID = NULL;
	struct LTP_ARRAY *EqLtpHsh ,*TempLtp ;
	LONG32 i =0;

	EqLtpHsh = (struct LTP_ARRAY *)malloc(sizeof(struct LTP_ARRAY));
	TempLtp = (struct LTP_ARRAY *)malloc(sizeof(struct LTP_ARRAY));

	HASH_FIND(HashID,Hash_ByID,&iToken,sizeof(iToken),TempLtp);

	if(TempLtp == NULL )
	{

		logDebug2("iToken :%d:",iToken);
		sprintf(EqLtpHsh->sTokenId,"%d",iToken) ;
		EqLtpHsh->fLtp     = fLTP;
		logDebug2("EqLtpHsh->sTokenId :%s:",EqLtpHsh->sTokenId);
		HASH_ADD(HashID,Hash_ByID ,sTokenId,strlen(EqLtpHsh->sTokenId),EqLtpHsh);
		logDebug2("Success Adding LTP to Hash");


	}
	else
	{

		if (fLTP == TempLtp->fLtp)
		{
			logDebug2("Ltp Already Exit in Hash for SecurityId :%d:",iToken);
			return FALSE;
		}
		else
		{
			EqLtpHsh->fLtp     = fLTP;
			sprintf(EqLtpHsh->sTokenId,"%d",iToken) ;
			HASH_REPLACE(HashID,Hash_ByID,sTokenId,strlen(EqLtpHsh->sTokenId),TempLtp,EqLtpHsh);
		}
	}
	logTimestamp("EXIT [fAddLtpToHash]");
	return TRUE;	
}

BOOL fSendLTPtoRed(LONG32 iToken , DOUBLE64 fLTP)
{

	logTimestamp("ENTRY [fSendLTPtoRed]");
	struct          REDIS_LTP_UPD pRedLTP;
	CHAR    tempflag= FALSE                 ;
        LONG32  counter = 0                     ;
        LONG32  status = TRUE                   ;

	logDebug2("This is 1 ");

	memset(&pRedLTP,'\0',sizeof(struct REDIS_LTP_UPD));
	logDebug2("This is 2 :%d: :%lf:",iToken,fLTP);

	pRedLTP.iToken = iToken;
	logDebug2("This is 3 ");
	pRedLTP.fLtp = fLTP;
	logDebug2("This is 4 ");
	logDebug2("iToken :%d: fLtp :%lf: ",pRedLTP.iToken,pRedLTP.fLtp);	
	logDebug2("This is 5 ");
	//quesue status check added if queue is 90% full it stop sending packets @Abhishek-13Jun2019	
	status = GetQStatus (iSendQ);
        if ( status == FALSE)
        {
        	tempflag = TRUE;
                counter++;
                logDebug2("QUEUE IS FULL");
        }
	else
	{
		if((WriteMsgQ(iSendQ,(CHAR *)&pRedLTP, sizeof(struct REDIS_LTP_UPD ), 1)) != TRUE  )
		{
			logFatal("Error : failed while sending to Queue ENMbpToLTPUpd");
			//exit(ERROR);
		}
	}		

	logTimestamp("EXIT [fSendLTPtoRed]");

}
//Function for checking queue status @Abhishek-13Jun2019
int GetQStatus( int MsgQuery)
{
        struct msqid_ds sStatQ;
        DOUBLE64        checkbytes = 0.0;

        if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
        {
                checkbytes      =       (sStatQ.msg_qbytes * 0.066);



                if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
                {
                        logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
                        return FALSE ;
                }
                else
                {
                        return TRUE ;
                }
        }
}
