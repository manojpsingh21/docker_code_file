#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

//redisContext *c;
redisContext *c1;
redisReply *reply;
redisReply *reply1;
redisReply *reply2;
redisReply *repRem;
MYSQL   *ENMbp_con;
INT16	iSubInstance;
LONG32  iSleepTime;

main(int argc,char **argv)
{
	setbuf(stdout,0);
	logTimestamp("ENTRY [Main]");
	//	c = RDConnect();
	c1 = RDConnect(REDIS_TYPE_PRICE_BCAST);
	ENMbp_con=DB_Connect();
	iSubInstance = atoi(argv[1]);
	iSleepTime = atoi(argv[2]);
	if ( argc != 4 )     
        {
                logDebug2("Argument Mismstch ");
                logDebug2("USAGE : NseCMSMemMbpUpd iSubInstance iSleepTime NseCMSMemMbpUpd ");
		iSleepTime = 3 ;
        }

	logInfo("iSubInstance :%d:",iSubInstance);	
	logInfo("iSleepTime:%d:",iSleepTime);	
	ReceiveReplyPacketsBcast();
	return 0;
	logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
	logTimestamp("ENTRY [UPDATE LTP IN DB]");
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN],sRSRem[COMMAND_LEN]; 
	BOOL flag;
	int count=0;
	int iCount ;
	int i=0 ;
	CHAR sKeyValue[RADIS_KEY_LEN];
	DOUBLE64   fTempLtp=0.00;
	LONG32          iTempScripCode =0 ,iMsgCode;
	LONG32	iBcastMonCountr = 0;
	CHAR    NormlMkt [MKT_TYPE_LEN];
	CHAR	sExch [10];
	CHAR	cSegment;
	CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sUpdateQry[MAX_QUERY_SIZE];
	CHAR    supdate [MAX_QUERY_SIZE];
	CHAR    sgetMembers[MAX_QUERY_SIZE];
	CHAR    sBroadcastMon[COMMAND_LEN];



	//   sprintf(sCommand,"SUBSCRIBE OMSNSECM-%d ",iSubInstance);
	//    logDebug2("sCommand -> %s",sCommand);
	//      reply = redisCommand(c,sCommand);
	//	logDebug2("INCR counter: %lld", reply->integer);
	//while(redisGetReply(c,(void**)&reply) == REDIS_OK) 
	while(TRUE) 
	{
		//		logTimestamp("Recive Publish Key");		
		memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
		memset(&supdate,'\0',MAX_QUERY_SIZE);
		memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
		memset(&sgetMembers,'\0',MAX_QUERY_SIZE);
		sprintf(sgetMembers,"SMEMBERS NSE:E:BCAST");
		//		logDebug2("sgetMembers :%s:",sgetMembers);
//		reply = redisCommand(c1,sgetMembers);
                reply = fRedisCommand(c1,sgetMembers,REDIS_TYPE_PRICE_BCAST);
		//		logDebug2("STATUS ->  %d",reply->integer);
		iCount = reply->elements;
		//		logTimestamp("ELEMENT COUNT >>>>>>>>>>%d<<<<<<<<<<<< ",iCount);
		//                logDebug2("Element : %s", reply->element[1]->str);
		for (i=0;i<iCount;i++)
		{
			//			logDebug2("reply->element[%d]->str : %s",i,reply->element[i]->str);
			logDebug3("INTIAL iBcastMonCountr :%d:",iBcastMonCountr);
			memset(&sCommand,'\0',COMMAND_LEN);
			sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT",reply->element[i]->str);
			logTimestamp("sCommand -> %s",sCommand);
			//reply1 = redisCommand(c1,sCommand);
                        reply1 = fRedisCommand(c1,sCommand,REDIS_TYPE_PRICE_BCAST);
			//			logDebug3("reply1->element[0]->str :%s:",reply1->element[0]->str);
			if(reply1->element[0]->str != NULL)
			{
				fTempLtp = atof(reply1->element[0]->str);
				//				logDebug3("fTempLtp :%f:",fTempLtp);
				//				logDebug2("Received message LTP : %s", reply1->element[0]->str);
				//				logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
				//				logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
				//				logDebug2("Received message EXCH: %s", reply1->element[3]->str);
				//				logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
				//				logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
				fTempLtp = atof(reply1->element[0]->str);
				iTempScripCode = atoi(reply1->element[1]->str);
				iMsgCode = atoi(reply1->element[4]->str);
				sprintf(NormlMkt,"%s",reply1->element[2]->str);

				sprintf(sUpdateQry,"UPDATE EQ_L1_WATCH SET L1_LTP = %lf,L1_MARKET_TYPE = \"%s\",L1_LUT = NOW() WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \"%d\";",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);


				logTimestamp("sUpdateQry Query[%s]",sUpdateQry);
				if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
				{
					logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
					sql_Error(ENMbp_con);
				}
				else
				{
					logDebug2("------SUCCESS IN INSERT QUERY-----");
					if(mysql_affected_rows(ENMbp_con) == 0)
					{
						sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
								(L1_EXCHANGE ,\
								 L1_SEGMENT,\
								 L1_SCRIP_CODE,\
								 L1_EXCH_SCRIP_CODE,\
								 L1_MARKET_TYPE,\
								 L1_ENTRY_TIME,\
								 L1_LTP )\
								VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf)",NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);
						logTimestamp("sInsertQry :%s:",sInsertQry);
						if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
						{
							logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
							sql_Error(ENMbp_con);
						}
					}
					mysql_commit(ENMbp_con);
					iBcastMonCountr ++;
					logDebug3("iBcastMonCountr :%d:",iBcastMonCountr);
					memset(sBroadcastMon,'\0',COMMAND_LEN);
					sprintf(sBroadcastMon,"HMSET BCAST:MON NSE:E:COUNT %d ",iBcastMonCountr);
					logTimestamp("sCommand -> %s",sBroadcastMon);
				//	reply2 = redisCommand(c1,sBroadcastMon); 
                                        reply2 = fRedisCommand(c1,sBroadcastMon,REDIS_TYPE_PRICE_BCAST);
					freeReplyObject(reply2);

				}

				sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f ,L1_MARKET_TYPE = \"%s\" ,L1_LUT = NOW() WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =\"%d\" ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);

				logTimestamp(" Update Query[%s]",supdate);

				if(mysql_query(ENMbp_con,supdate) != SUCCESS)
				{
					logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
					sql_Error(ENMbp_con);
				}
				else
				{
					mysql_commit(ENMbp_con);

					logDebug2("------SUCCESS IN LTP UPDATE-----");
					logDebug2("TempScripCode :%d:",iTempScripCode);
					logDebug2(" LTP [%lf]",fTempLtp);
					iBcastMonCountr ++;
				}

			}
			freeReplyObject(reply1);
			memset(&sRSRem,'\0',COMMAND_LEN);
			sprintf(sRSRem,"SREM NSE:E:BCAST  %s",reply->element[i]->str);

			logDebug2("sRSRem :%s:",sRSRem);
			repRem = redisCommand(c1,sRSRem);

			if(repRem->type == REDIS_REPLY_INTEGER)
			{
				logInfo("Added Success");
				//					logDebug2("STATUS ->  %d",repRem->integer);
			}
			else
			{
				logFatal("Error in adding values to CLIENT HASH. :%s:",repRem->str);
			}


			freeReplyObject(repRem);



		}
		//			logDebug3("ICOUNT :%d:",iCount);



		freeReplyObject(reply);
		sleep(iSleepTime);/* Info :- Sleep time taken because
				     its effect on CPU
				     Utilization after update on every SMEM count*/

		//		logTimestamp("ELEMENT COUNT EXIT  >>>>>>>>>>%d<<<<<<<<<<<< ",iCount);
		/*                        if(reply->type == REDIS_REPLY_INTEGER)
					  {
					  logInfo("Added Success");
					  logDebug2("STATUS ->  %d",reply->integer);
					  }
					  else
					  {
					  logFatal("Error in adding values to CLIENT HASH. :%s:",reply->str);
					  }*/
		//		freeReplyObject(reply);


		/*       	if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3) 
				{
				logDebug2("Error:  Malformed subscribe response!");
		//exit(-1);
		continue;
		}
		*/
		/*             logDebug2("Channel: %s", reply->element[1]->str);
			       logDebug2("Received message: %s", reply->element[2]->str);
			       sprintf(sKeyValue,"%s",reply->element[2]->str);
			       freeReplyObject(reply);

			       memset(sCommand1,'\0',COMMAND_LEN);				
			       sprintf(sCommand1,"TTL %s",sKeyValue);
			       logTimestamp("sCommand1 -> %s",sCommand1);
			       reply = redisCommand(c1,sCommand1);		
			       logDebug2("INCR counter: %lld", reply->integer);
			       */		/*		
								if(reply->integer != 0 && reply->integer != -2)
								{
								memset(sCommand,'\0',COMMAND_LEN);
								sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT ",sKeyValue);
								logTimestamp("sCommand -> %s",sCommand);
								reply1 = redisCommand(c1,sCommand);
								iCount = reply1->elements;
								logDebug2("ELEMENT COUNT =%d ",iCount);
								logDebug2("Received message LTP : %s", reply1->element[0]->str);
								logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
								logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
								logDebug2("Received message EXCH: %s", reply1->element[3]->str);
								logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
								logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
								if(reply1->element[0]->str != NULL)
								{
								fTempLtp = atof(reply1->element[0]->str);
								iTempScripCode = atoi(reply1->element[1]->str);
								iMsgCode = atoi(reply1->element[4]->str);
								sprintf(NormlMkt,"%s",reply1->element[2]->str);	

								sprintf(sUpdateQry,"UPDATE EQ_L1_WATCH SET L1_LTP = %lf,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \"%d\";",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);


								logTimestamp("sUpdateQry Query[%s]",sUpdateQry);
								if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
								{
								logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
								sql_Error(ENMbp_con);
								}
								else
								{
								logDebug2("------SUCCESS IN INSERT QUERY-----");
								if(mysql_affected_rows(ENMbp_con) == 0)
								{
								sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
								(L1_EXCHANGE ,\
								L1_SEGMENT,\
								L1_SCRIP_CODE,\
								L1_EXCH_SCRIP_CODE,\
								L1_MARKET_TYPE,\
								L1_ENTRY_TIME,\
								L1_LTP )\
								VALUES(\"%s\",\'%c\',\"%d\",\"%d\",\"%s\",NOW(),%lf)",NSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);
								logTimestamp("sInsertQry :%s:",sInsertQry);
								if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
								{
								logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table EQ_L1_WATCH");
								sql_Error(ENMbp_con);
								}
								}
								mysql_commit(ENMbp_con);


								}

								sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f ,L1_MARKET_TYPE = \"%s\" WHERE L1_EXCHANGE = \"%s\" AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =\"%d\" ;",fTempLtp,NormlMkt,NSE_EXCH,SEGMENT_EQUITY,iTempScripCode);

								logTimestamp(" Update Query[%s]",supdate);

								if(mysql_query(ENMbp_con,supdate) != SUCCESS)
								{
								logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
								sql_Error(ENMbp_con);
								}
								else
								{
								mysql_commit(ENMbp_con);

								logDebug2("------SUCCESS IN LTP UPDATE-----");
		logDebug2("TempScripCode :%d:",iTempScripCode);
		logDebug2(" LTP [%lf]",fTempLtp);
	}
	}
	freeReplyObject(reply1);
	}*/


	//logTimestamp("#####EXIT####");


	}
	logTimestamp("EXIT [UPDATE LTP IN DB]");
}
