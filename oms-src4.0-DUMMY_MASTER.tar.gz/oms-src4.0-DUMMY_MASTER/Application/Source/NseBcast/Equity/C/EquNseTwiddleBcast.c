#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <sys/time.h>
#include "IPCS.h"
#include "EQNSEBcastStruct.h"

BOOL dTC_MULTIPLE_INDEX_BCAST (CHAR *NNFData);

BOOL TwiddleNseBroad(char * pMem)
{
	INT16   TranscodeLocal,i;
	struct NNF_HEADER 		*pForRecTransCode;
	int count;
	BOOL iReturn;

	struct TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] =
	{
		//	TC_GENERAL_MSG_BCAST			,dTC_GENERAL_MSG_BCAST
		//	,TC_MULTIPLE_INDEX_BCAST               	,dTC_MULTIPLE_INDEX_BCAST
			TC_STOCK_STATUS_CHANGE_BCAST          	,dTC_STOCK_STATUS_CHANGE_BCAST
			,TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST  	,dTC_STOCK_STATUS_CHANGE_BCAST
			,TC_MARKET_OPEN_MSG_BCAST              	,dTC_MARKET_OPEN_MSG_BCAST
			,TC_MARKET_CLOSE_MSG_BCAST             	,dTC_MARKET_OPEN_MSG_BCAST
			,TC_PREOPEN_SHUTDOWN_BCAST             	,dTC_MARKET_OPEN_MSG_BCAST
			,TC_PRE_OPEN_ENDED_MSG_BCAST           	,dTC_MARKET_OPEN_MSG_BCAST
			,TC_TICKER_INDEX_BCAST			,dTC_TICKER_INDEX_BCAST
			,TC_POST_CLOSING_START_BCAST           	,dTC_MARKET_OPEN_MSG_BCAST
			,TC_POST_CLOSING_END_BCAST             	,dTC_MARKET_OPEN_MSG_BCAST
			,TC_MBP_BCAST                          	,dTC_MBP_BCAST
			,TC_AUCTION_INQUIRY_MSG			,dTC_AUCTION_INQUIRY_MSG
			,TC_CALL_AUCTION_MBP			,dTC_CALL_AUCTION_MBP
			,TC_AUCTION_STATUS_CHNG			,dTC_AUCTION_STATUS_CHNG
			,TC_SECURITY_OPEN_MSG_BCAST		,dTC_SECURITY_OPEN_MSG_BCAST
			,TC_MBO_MBP_UPDATE_BCAST		,dTC_MBO_MBP_UPDATE_BCAST
			,TC_STOCK_DETAILS_CHANGE_BCAST          ,dTC_STOCK_DETAILS_CHANGE_BCAST
			//		,TC_MKT_STATS_RPT_BCAST			,dTC_MKT_STATS_RPT_BCAST
			,TC_AUCTION_INQUIRY_MSG_TNDTC           ,dTC_AUCTION_INQUIRY_MSG_TNDTC
			,TC_MBO_MBP_UPDATE_BCAST_TNDTC          ,dTC_MBO_MBP_UPDATE_BCAST_TNDTC
			,TC_TICKER_INDEX_BCAST_TNDTC            ,dTC_TICKER_INDEX_BCAST_TNDTC
                        ,TC_MBP_BCAST_TNDTC                     ,dTC_MBP_BCAST_TNDTC
                        ,TC_CALL_AUCTION_MBP_TNDTC              ,dTC_CALL_AUCTION_MBP_TNDTC
                        ,TC_STOCK_DETAILS_CHANGE_BCAST_TNDTC    ,dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC
                        ,TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST_TNDTC     ,dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC
                        ,TC_STOCK_STATUS_CHANGE_BCAST_TNDTC             ,dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC
	};



	pForRecTransCode  = (struct NNF_HEADER *) pMem;
	TWIDDLE( pForRecTransCode->iMsgCode );  
	TranscodeLocal = pForRecTransCode->iMsgCode;

	logDebug2("TranscodeLocal :%d:",TranscodeLocal);


	for (count=0;count<(MAX_NO_OF_TRANSCODE_TWIDDLE);count++)
	{	
		if (TransFunPair[count].Transcode == TranscodeLocal)
		{ 
			logDebug2("Hey I am here TransFunPair[count].Transcode :%d: ",TransFunPair[count].Transcode);
			iReturn = (*(TransFunPair[count].pToFun))(pMem);
			logDebug2("Hey I am here 2 ");
			return(iReturn);
		}
	}
	logDebug2("NOT TWIDDLE CASE "); 

	return(NOT_TWIDDLE);
}

BOOL dTC_MULTIPLE_INDEX_BCAST(char *NNFData)
{
	logTimestamp(" ENTRY [dTC_MULTIPLE_INDEX_BCAST]");

	logDebug2("7207 Multiple Indx Bcast");
	int	iRecordNumber = 0;
	NNF_MULTIPLE_INDEX_BCAST	*pMultipleIndexData;
	pMultipleIndexData = (NNF_MULTIPLE_INDEX_BCAST *) NNFData;

	TWIDDLE (pMultipleIndexData->pHeader.iErrorCode);
	TWIDDLE (pMultipleIndexData->pHeader.iLogTimeStamp);
	TWIDDLE (pMultipleIndexData->pHeader.iMsgLen);
	TWIDDLE (pMultipleIndexData->iNumberOfRecords);


	for(iRecordNumber = 0;iRecordNumber < pMultipleIndexData->iNumberOfRecords; iRecordNumber++)
	{
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iIndexVal); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iHighIndexVal); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iLowIndexVal); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iOpeningIndex); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iClosingIndex); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iPercentChange); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iYearlyHigh); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iYearlyLow); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iNoOfUpMoves); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].iNoOfDownMoves); 
		TWIDDLE (pMultipleIndexData->pIndicesData[iRecordNumber].fMktCapitalisation); 

	}

	logTimestamp("EXIT [dTC_MULTIPLE_INDEX_BCAST]");

	return TRUE;
}

BOOL dTC_AUCTION_INQUIRY_MSG (char *NNFData)
{
	logTimestamp(" ENTRY [dTC_AUCTION_INQUIRY_MSG]");
	logDebug2("6582 Auction Inq Bcast");
	MS_AUCTION_INQ_DATA *pAuctionInqData ;
	pAuctionInqData = (struct MS_AUCTION_INQ_DATA *) NNFData;

	TWIDDLE (pAuctionInqData->pHeader.iErrorCode);
	TWIDDLE (pAuctionInqData->pHeader.iLogTimeStamp);
	TWIDDLE (pAuctionInqData->pHeader.iMsgLen);

	TWIDDLE (pAuctionInqData->pAucInqInfo.iToken);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionNumber);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionStatus);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iInitiatorType);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iTotalBuyQty);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iBestBuyPrice);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iTotalSellQty);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iBestSellPrice);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionPrice);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionQty);
	TWIDDLE (pAuctionInqData->pAucInqInfo.iSettlementPeriod);
	logTimestamp("EXIT [dTC_AUCTION_INQUIRY_MSG]");
	return TRUE;
}

BOOL dTC_AUCTION_INQUIRY_MSG_TNDTC (char *NNFData)
{
        logTimestamp(" ENTRY [dTC_AUCTION_INQUIRY_MSG_TNDTC]");
        logDebug2("18700 Auction Inq Bcast [TNDTC]");
        MS_AUCTION_INQ_DATA_TNDTC *pAuctionInqData ;
        pAuctionInqData = (struct MS_AUCTION_INQ_DATA_TNDTC *) NNFData;

        TWIDDLE (pAuctionInqData->pHeader.iErrorCode);
        TWIDDLE (pAuctionInqData->pHeader.iLogTimeStamp);
        TWIDDLE (pAuctionInqData->pHeader.iMsgLen);

        TWIDDLE (pAuctionInqData->pAucInqInfo.iToken);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionNumber);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionStatus);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iInitiatorType);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iTotalBuyQty);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iBestBuyPrice);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iTotalSellQty);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iBestSellPrice);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionPrice);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iAuctionQty);
        TWIDDLE (pAuctionInqData->pAucInqInfo.iSettlementPeriod);
        logTimestamp("EXIT [dTC_AUCTION_INQUIRY_MSG_TNDTC]");
        return TRUE;
}


BOOL dTC_CALL_AUCTION_MBP(char *NNFData)
{
	logTimestamp(" ENTRY [dTC_CALL_AUCTION_MBP]");
	logDebug2("7214 Call_Auction_Mbp");
	LONG32 iRecord , iTotalRecord ;
	struct NNF_CALL_AUCTION_MBP *pCallAucMbp ;
	pCallAucMbp = (struct NNF_CALL_AUCTION_MBP*) NNFData;

	TWIDDLE(pCallAucMbp->pHeader.iErrorCode);
	TWIDDLE(pCallAucMbp->pHeader.iLogTimeStamp);
	TWIDDLE(pCallAucMbp->pHeader.iMsgLen);

	TWIDDLE(pCallAucMbp->iNoOfRecs);
	for(iTotalRecord=0;iTotalRecord<pCallAucMbp->iNoOfRecs;iTotalRecord++)
	{
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iToken);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iBookType);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iTradingStatus);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iVolTradedToday);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].indicativeTradedQty);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLastTradedPrice);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iNetPriceChange);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLastTradedQty);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLastTradeTime);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iAvgTradePrice);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iFirstOpenPrice);

		for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
		{
			TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iQty);
			TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iPrice);
			TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iNoOfOrders);
			TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iBbBuySellFlg);
		}

		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iBbTotalBuyFlg);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iBbTotalSellFlg);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].fTotalBuyQty);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].fTotalSellQty);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iClosePrice);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iOpenPrice);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iHighPrice);
		TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLowPrice);
	}	
}

BOOL dTC_CALL_AUCTION_MBP_TNDTC(char *NNFData)
{
        logTimestamp(" ENTRY [dTC_CALL_AUCTION_MBP_TNDTC]");
        logDebug2("18710 : Call_Auction_Mbp");
        LONG32 iRecord , iTotalRecord ;
        struct NNF_CALL_AUCTION_MBP_TNDTC *pCallAucMbp ;
        pCallAucMbp = (struct NNF_CALL_AUCTION_MBP_TNDTC*) NNFData;

        TWIDDLE(pCallAucMbp->pHeader.iErrorCode);
        TWIDDLE(pCallAucMbp->pHeader.iLogTimeStamp);
        TWIDDLE(pCallAucMbp->pHeader.iMsgLen);

        TWIDDLE(pCallAucMbp->iNoOfRecs);
        for(iTotalRecord=0;iTotalRecord<pCallAucMbp->iNoOfRecs;iTotalRecord++)
        {
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iToken);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iBookType);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iTradingStatus);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iVolTradedToday);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].indicativeTradedQty);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLastTradedPrice);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iNetPriceChange);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLastTradedQty);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLastTradeTime);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iAvgTradePrice);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iFirstOpenPrice);

                for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
                {
                        TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iQty);
                        TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iPrice);
                        TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iNoOfOrders);
                        TWIDDLE (pCallAucMbp->pCallAucMbp[iTotalRecord].pMBPRecords[iRecord].iBbBuySellFlg);
                }

                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iBbTotalBuyFlg);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iBbTotalSellFlg);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].fTotalBuyQty);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].fTotalSellQty);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iClosePrice);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iOpenPrice);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iHighPrice);
                TWIDDLE(pCallAucMbp->pCallAucMbp[iTotalRecord].iLowPrice);
        }
}


BOOL dTC_MBO_MBP_UPDATE_BCAST (char *NNFData)
{
	logTimestamp(" ENTRY [dTC_MBO_MBP_UPDATE_BCAST]");
	logDebug2("7200 Mkt by Ord / Mkt by Price upd");
	LONG32 iRecord ;
	struct BCAST_MBO_MBP_UPDATE *pMboMbpUpd ;
	pMboMbpUpd = (struct BCAST_MBO_MBP_UPDATE*) NNFData;

	TWIDDLE(pMboMbpUpd->pHeader.iErrorCode);
	TWIDDLE(pMboMbpUpd->pHeader.iLogTimeStamp);
	TWIDDLE(pMboMbpUpd->pHeader.iMsgLen);

	TWIDDLE(pMboMbpUpd->pMboData.iToken );
	TWIDDLE(pMboMbpUpd->pMboData.iBookType );
	TWIDDLE(pMboMbpUpd->pMboData.iTradingStatus );
	TWIDDLE(pMboMbpUpd->pMboData.iVolumeTradedToday );
	TWIDDLE(pMboMbpUpd->pMboData.iLastTradedPrice );
	TWIDDLE(pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice );
	TWIDDLE(pMboMbpUpd->pMboData.iLastTradeQuantity );
	TWIDDLE(pMboMbpUpd->pMboData.iLastTradeTime );
	TWIDDLE(pMboMbpUpd->pMboData.iAverageTradePrice );
	TWIDDLE(pMboMbpUpd->pMboData.iAuctionNumber );
	TWIDDLE(pMboMbpUpd->pMboData.iAuctionStatus );
	TWIDDLE(pMboMbpUpd->pMboData.iInitiatorType );
	TWIDDLE(pMboMbpUpd->pMboData.iInitiatorPrice );
	TWIDDLE(pMboMbpUpd->pMboData.iInitiatorQuantity );
	TWIDDLE(pMboMbpUpd->pMboData.iAuctionPrice );
	TWIDDLE(pMboMbpUpd->pMboData.iAuctionQuantity );
	for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
	{
		TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid);
		TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
		TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice);
		TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty);

		TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iQty);
		TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iPrice);
		TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iNoOfOrders);
		TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iBbBuySellFlg);	
	}

	TWIDDLE(pMboMbpUpd->iBbTotalBuyFlag);
	TWIDDLE(pMboMbpUpd->iBbTotalSellFlag);
	TWIDDLE(pMboMbpUpd->fTotalBuyQuantity);
	TWIDDLE(pMboMbpUpd->fTotalSellQuantity);
	TWIDDLE(pMboMbpUpd->iClosingPrice);
	TWIDDLE(pMboMbpUpd->iOpenPrice);
	TWIDDLE(pMboMbpUpd->iHighPrice);
	TWIDDLE(pMboMbpUpd->iLowPrice);
}

BOOL dTC_MBO_MBP_UPDATE_BCAST_TNDTC (char *NNFData)
{
        logTimestamp(" ENTRY [dTC_MBO_MBP_UPDATE_BCAST_TNDTC]");
        logDebug2("18701 : Mkt by Ord / Mkt by Price upd [TNDTC]");
        LONG32 iRecord ;
        struct BCAST_MBO_MBP_UPDATE_TNDTC *pMboMbpUpd ;
        pMboMbpUpd = (struct BCAST_MBO_MBP_UPDATE_TNDTC*) NNFData;

        TWIDDLE(pMboMbpUpd->pHeader.iErrorCode);
        TWIDDLE(pMboMbpUpd->pHeader.iLogTimeStamp);
        TWIDDLE(pMboMbpUpd->pHeader.iMsgLen);

        TWIDDLE(pMboMbpUpd->pMboData.iToken );
        TWIDDLE(pMboMbpUpd->pMboData.iBookType );
        TWIDDLE(pMboMbpUpd->pMboData.iTradingStatus );
        TWIDDLE(pMboMbpUpd->pMboData.iVolumeTradedToday );
        TWIDDLE(pMboMbpUpd->pMboData.iLastTradedPrice );
        TWIDDLE(pMboMbpUpd->pMboData.iNetPriceChgFrmClosingPrice );
        TWIDDLE(pMboMbpUpd->pMboData.iLastTradeQuantity );
        TWIDDLE(pMboMbpUpd->pMboData.iLastTradeTime );
        TWIDDLE(pMboMbpUpd->pMboData.iAverageTradePrice );
        TWIDDLE(pMboMbpUpd->pMboData.iAuctionNumber );
        TWIDDLE(pMboMbpUpd->pMboData.iAuctionStatus );
        TWIDDLE(pMboMbpUpd->pMboData.iInitiatorType );
        TWIDDLE(pMboMbpUpd->pMboData.iInitiatorPrice );
        TWIDDLE(pMboMbpUpd->pMboData.iInitiatorQuantity );
        TWIDDLE(pMboMbpUpd->pMboData.iAuctionPrice );
        TWIDDLE(pMboMbpUpd->pMboData.iAuctionQuantity );
        for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
        {
                TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iTrdadeid);
                TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iQty);
                TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iPrice);
                TWIDDLE (pMboMbpUpd->pMboData.pMBORecords[iRecord].iMinFillQty);

                TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iQty);
                TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iPrice);
                TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iNoOfOrders);
                TWIDDLE (pMboMbpUpd->pMBPRecords[iRecord].iBbBuySellFlg);
        }

        TWIDDLE(pMboMbpUpd->iBbTotalBuyFlag);
        TWIDDLE(pMboMbpUpd->iBbTotalSellFlag);
        TWIDDLE(pMboMbpUpd->fTotalBuyQuantity);
        TWIDDLE(pMboMbpUpd->fTotalSellQuantity);
        TWIDDLE(pMboMbpUpd->iClosingPrice);
        TWIDDLE(pMboMbpUpd->iOpenPrice);
        TWIDDLE(pMboMbpUpd->iHighPrice);
        TWIDDLE(pMboMbpUpd->iLowPrice);
}



BOOL dTC_AUCTION_STATUS_CHNG (char *NNFData)
{
	logTimestamp(" ENTRY [dTC_AUCTION_STATUS_CHNG]");
	logDebug2("6581 Auction Status Change");
	struct BC_AUCTION_STATUS_CHANGE *pAuctionInqData ;
	pAuctionInqData = (struct BC_AUCTION_STATUS_CHANGE *) NNFData;

	TWIDDLE (pAuctionInqData->pHeader.iErrorCode);
	TWIDDLE (pAuctionInqData->pHeader.iLogTimeStamp);
	TWIDDLE (pAuctionInqData->pHeader.iMsgLen);
	logDebug2("pAuctionInqData->pHeader.iMsgLen :%d:",pAuctionInqData->pHeader.iMsgLen);	

	TWIDDLE (pAuctionInqData->iAuctionNumber);
	TWIDDLE (pAuctionInqData->iBroadcastMessageLength );
	logTimestamp("EXIT [dTC_AUCTION_STATUS_CHNG]");
	return TRUE;
}



BOOL dTC_GENERAL_MSG_BCAST (char *NNFData)
{
	logTimestamp(" ENTRY [dTC_GENERAL_MSG_BCAST]");
	logDebug2("6501 gen_Msg_Bcast");

	struct NNF_GEN_MESSAGE_BCAST *PGenMsgBcast;
	PGenMsgBcast =  (struct NNF_GEN_MESSAGE_BCAST *)NNFData;

	TWIDDLE (PGenMsgBcast->sHeader.iErrorCode);
	TWIDDLE (PGenMsgBcast->sHeader.iLogTimeStamp);
	TWIDDLE (PGenMsgBcast->sHeader.iMsgLen);
	TWIDDLE (PGenMsgBcast->BranchNumber);
	TWIDDLE (PGenMsgBcast->BcastMsgLength);

	/*	logDebug2("PGenMsgBcast->ActionCode :%s:",PGenMsgBcast->ActionCode);	
		logDebug2("PGenMsgBcast->BcastMsg :%s:",PGenMsgBcast->BcastMsg);*/


	logTimestamp("EXIT [dTC_GENERAL_MSG_BCAST]");
	return TRUE;
}






BOOL dTC_TICKER_INDEX_BCAST(CHAR *NNFData)
{
	logTimestamp(" ENTRY [dTC_TICKER_INDEX_BCAST]");

	LONG32     iRecordNumber ;
	struct NNF_TICKER_TRADE_BCAST     *pTickerData;
	pTickerData = ( struct NNF_TICKER_TRADE_BCAST *) NNFData;
	logDebug2("7202 LTP");

	TWIDDLE (pTickerData->sHeader.iMsgLen);
	TWIDDLE (pTickerData->iNoOfRecords);

	/*	logDebug2("pTickerData->sHeader.iMsgLen :%d:",pTickerData->sHeader.iMsgLen);
		logDebug2("pTickerData->iNoOfRecords :%i:",pTickerData->iNoOfRecords);*/

	for(iRecordNumber = 0 ; iRecordNumber < pTickerData->iNoOfRecords; iRecordNumber++)
	{

		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iToken);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iMarketType);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iTradeVolume);
		TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iMarketIndexValue);

		/*		logDebug2("pTickerData->TickerIndexInfo[%d].iToken :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iToken);
				logDebug2("pTickerData->TickerIndexInfo[%d].iTradePrice :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice);
				logDebug2("pTickerData->TickerIndexInfo[%d].iTradeVolume :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iTradeVolume);
				logDebug2("pTickerData->TickerIndexInfo[%d].iMarketType :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iMarketType);*/
	}
	logTimestamp("EXIT [dTC_TICKER_INDEX_BCAST]");
	return TRUE;
}

BOOL dTC_TICKER_INDEX_BCAST_TNDTC(CHAR *NNFData)
{
        logTimestamp(" ENTRY [dTC_TICKER_INDEX_BCAST_TNDTC]");

        LONG32     iRecordNumber ;
        struct NNF_TICKER_TRADE_BCAST_TNDTC     *pTickerData;
        pTickerData = ( struct NNF_TICKER_TRADE_BCAST_TNDTC *) NNFData;
        logDebug2("18703 LTP");

        TWIDDLE (pTickerData->sHeader.iMsgLen);
        TWIDDLE (pTickerData->iNoOfRecords);

        /*      logDebug2("pTickerData->sHeader.iMsgLen :%d:",pTickerData->sHeader.iMsgLen);
 *       *                      logDebug2("pTickerData->iNoOfRecords :%i:",pTickerData->iNoOfRecords);*/

        for(iRecordNumber = 0 ; iRecordNumber < pTickerData->iNoOfRecords; iRecordNumber++)
        {

                TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iToken);
                TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iMarketType);
                TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice);
                TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iTradeVolume);
                TWIDDLE (pTickerData->TickerIndexInfo[iRecordNumber].iMarketIndexValue);

                /*              logDebug2("pTickerData->TickerIndexInfo[%d].iToken :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iToken);
                 *              logDebug2("pTickerData->TickerIndexInfo[%d].iTradePrice :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice);
                 *              logDebug2("pTickerData->TickerIndexInfo[%d].iTradeVolume :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iTradeVolume);
                 *              logDebug2("pTickerData->TickerIndexInfo[%d].iMarketType :%d:",iRecordNumber,pTickerData->TickerIndexInfo[iRecordNumber].iMarketType);*/
        }
        logTimestamp("EXIT [dTC_TICKER_INDEX_BCAST_TNDTC]");
        return TRUE;
}


BOOL  dTC_MBP_BCAST(char *NNFData )
{

	logTimestamp("ENTRY[TC_MBP_BCAST]");
	LONG32 iRecord,iTotalRecord;

	NNF_MBP_BCAST  *pMbpBcast = ( NNF_MBP_BCAST *) NNFData;
	//	logDebug2("sizeof( struct NNF_MBP_BCAST :%d:",sizeof(struct NNF_MBP_BCAST));
	logDebug2("7208 Market_By_price");

	TWIDDLE ( pMbpBcast->pHeader.iMsgLen		);
	//	logDebug2("pMbpBcast->pHeader.iMsgLen :%d:",pMbpBcast->pHeader.iMsgLen);
	TWIDDLE ( pMbpBcast->pHeader.iLogTimeStamp	);
	TWIDDLE ( pMbpBcast->iNoOfRecs			);


	for(iTotalRecord=0;iTotalRecord<pMbpBcast->iNoOfRecs;iTotalRecord++)
	{
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iToken		);
		//		logDebug2(" pMbpBcast->pMBPInfo[iTotalRecord].iToken :%d:",pMbpBcast->pMBPInfo[iTotalRecord].iToken);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iBookType		);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iTradingStatus	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iVolTradedToday	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice	);
		//		logDebug2(" pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice :%d:",pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iNetPriceChange	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedQty	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLastTradeTime	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAvgTradePrice	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionNumber	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionStatus	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorType	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorPrice	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorQty	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionPrice	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionQty		);

		for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
		{
			TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iQty     );
			TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iPrice	  );
			TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iNoOfOrders);	
			TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iBbBuySellFlg);
		}
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalBuyFlg	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalSellFlg	);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].fTotalBuyQty		);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].fTotalSellQty		);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iClosePrice		);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iOpenPrice		);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iHighPrice		);
		TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLowPrice			);
	}

	logTimestamp("EXIT [TC_MBP_BCAST]");
	return TRUE;
}

BOOL  dTC_MBP_BCAST_TNDTC(char *NNFData )
{

        logTimestamp("ENTRY[TC_MBP_BCAST_TNDTC]");
        LONG32 iRecord,iTotalRecord;

        NNF_MBP_BCAST_TNDTC  *pMbpBcast = ( NNF_MBP_BCAST_TNDTC *) NNFData;
        logDebug2("18705 : Market_By_price");

        TWIDDLE ( pMbpBcast->pHeader.iMsgLen            );
        TWIDDLE ( pMbpBcast->pHeader.iLogTimeStamp      );
        TWIDDLE ( pMbpBcast->iNoOfRecs                  );


        for(iTotalRecord=0;iTotalRecord<pMbpBcast->iNoOfRecs;iTotalRecord++)
        {
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iToken              );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iBookType           );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iTradingStatus      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iVolTradedToday     );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedPrice    );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iNetPriceChange     );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLastTradedQty      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLastTradeTime      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAvgTradePrice      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionNumber      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionStatus      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorType      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorPrice     );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iInitiatorQty       );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionPrice       );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iAuctionQty         );

                for (iRecord = 0;iRecord<MBP_NO_OF_RECS;iRecord++)
                {
                        TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iQty     );
                        TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iPrice    );
                        TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iNoOfOrders);
                        TWIDDLE (pMbpBcast->pMBPInfo[iTotalRecord].pMBPRecords[iRecord].iBbBuySellFlg);
                }
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalBuyFlg      );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iBbTotalSellFlg     );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].fTotalBuyQty                );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].fTotalSellQty               );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iClosePrice         );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iOpenPrice          );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iHighPrice          );
                TWIDDLE ( pMbpBcast->pMBPInfo[iTotalRecord].iLowPrice                   );
        }

        logTimestamp("EXIT [TC_MBP_BCAST_TNDTC]");
        return TRUE;
}



BOOL dTC_STOCK_DETAILS_CHANGE_BCAST (char *NNFData )
{
	logTimestamp("ENTRY [dTC_STOCK_DETAILS_CHANGE_BCAST]");

	struct  NNF_SECURITY_UPDATE_BCAST  *pSecUpdateBcast = (struct NNF_SECURITY_UPDATE_BCAST *) NNFData;
	DOUBLE64 FreezePrcent;

	TWIDDLE (pSecUpdateBcast->sHeader.iMsgLen);
	TWIDDLE (pSecUpdateBcast->sHeader.iErrorCode);
	TWIDDLE (pSecUpdateBcast->sHeader.iLogTimeStamp);
	TWIDDLE (pSecUpdateBcast->Token  );
	TWIDDLE (pSecUpdateBcast->FreezePercent);
	TWIDDLE (pSecUpdateBcast->InstrumentType);
	TWIDDLE (pSecUpdateBcast->ISINNumber);
	TWIDDLE (pSecUpdateBcast->PermittedToTrade);


	/*
	   TWIDDLE (pSecUpdateBcast->InstrumentType );
	   TWIDDLE (pSecUpdateBcast->PermittedToTrade);
	   TWIDDLE (pSecUpdateBcast->IssuedCapital);
	   TWIDDLE (pSecUpdateBcast->WarningPercent);
	   TWIDDLE (pSecUpdateBcast->IssueRate);
	   TWIDDLE (pSecUpdateBcast->BoardLotQty);
	   TWIDDLE (pSecUpdateBcast->TickSize      );
	   TWIDDLE (pSecUpdateBcast->SecurityName);
	 */
	FreezePrcent = ((DOUBLE64)pSecUpdateBcast->FreezePercent)/CONST_PRICE_FACTOR;

	logDebug2(" 7305 Stock Details Changed Bcast");
	//        logDebug2("Tokeen:%d: FreezePrcent :%.2f: CreditRating :%s:",pSecUpdateBcast->Token,FreezePrcent,pSecUpdateBcast->CreditRating);
	logTimestamp("EXIT [dTC_STOCK_DETAILS_CHANGE_BCAST]");
	return TRUE;
}

BOOL dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC (char *NNFData )
{
        logTimestamp("ENTRY [dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC]");

        struct  NNF_SECURITY_UPDATE_BCAST_TNDTC  *pSecUpdateBcast = (struct NNF_SECURITY_UPDATE_BCAST_TNDTC *) NNFData;
        DOUBLE64 FreezePrcent;

        TWIDDLE (pSecUpdateBcast->sHeader.iMsgLen);
        TWIDDLE (pSecUpdateBcast->sHeader.iErrorCode);
        TWIDDLE (pSecUpdateBcast->sHeader.iLogTimeStamp);
        TWIDDLE (pSecUpdateBcast->Token  );
        TWIDDLE (pSecUpdateBcast->FreezePercent);
        TWIDDLE (pSecUpdateBcast->InstrumentType);
        TWIDDLE (pSecUpdateBcast->ISINNumber);
        TWIDDLE (pSecUpdateBcast->PermittedToTrade);


        /*
 	*            TWIDDLE (pSecUpdateBcast->InstrumentType );
	 *                       TWIDDLE (pSecUpdateBcast->PermittedToTrade);
 	*                        TWIDDLE (pSecUpdateBcast->IssuedCapital);
 	*                        TWIDDLE (pSecUpdateBcast->WarningPercent);
 	*                        TWIDDLE (pSecUpdateBcast->IssueRate);
 	*                        TWIDDLE (pSecUpdateBcast->BoardLotQty);
 	*                        TWIDDLE (pSecUpdateBcast->TickSize      );
 	*                        TWIDDLE (pSecUpdateBcast->SecurityName);
 	*                                                                 */
        FreezePrcent = ((DOUBLE64)pSecUpdateBcast->FreezePercent)/CONST_PRICE_FACTOR;

        logDebug2("18720 : Stock Details Changed Bcast");
        logTimestamp("EXIT [dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC]");
        return TRUE;
}



BOOL dTC_STOCK_STATUS_CHANGE_BCAST(char *NNFData )
{

	logTimestamp("ENTRY [dTC_STOCK_STATUS_CHANGE_BCAST]");
	LONG32 NoOfRecords,WhichMarket;
	struct  NNF_SECURITY_STATUS_UPDATE_BCAST  *pSecStatusUpdateBcast = (struct  NNF_SECURITY_STATUS_UPDATE_BCAST *) NNFData;

	TWIDDLE (pSecStatusUpdateBcast->sHeader.iMsgLen);
	TWIDDLE (pSecStatusUpdateBcast->sHeader.iLogTimeStamp);
	TWIDDLE(pSecStatusUpdateBcast->sHeader.iMsgCode);
	TWIDDLE(pSecStatusUpdateBcast->sHeader.iErrorCode);
	TWIDDLE ( pSecStatusUpdateBcast->NoOfRecords);
	for (NoOfRecords = 0;NoOfRecords<pSecStatusUpdateBcast->NoOfRecords;NoOfRecords++)
	{
		TWIDDLE ( pSecStatusUpdateBcast->SecTokenAndEligibility[NoOfRecords].Token);
		for(WhichMarket = 0;WhichMarket <MARKET_TYPES;WhichMarket++)
		{
			TWIDDLE ( pSecStatusUpdateBcast->SecTokenAndEligibility[NoOfRecords].SecEligibilityPerMkt[WhichMarket].Status);
		}
	}
	logDebug2("7320 Security Status Changed Bcast");
	logTimestamp("EXIT [dTC_STOCK_STATUS_CHANGE_BCAST]");
	return TRUE;

}

BOOL dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC(char *NNFData )
{

        logTimestamp("ENTRY [dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC]");
        LONG32 NoOfRecords,WhichMarket;
        struct  NNF_SECURITY_STATUS_UPDATE_BCAST_TNDTC  *pSecStatusUpdateBcast = (struct  NNF_SECURITY_STATUS_UPDATE_BCAST_TNDTC *) NNFData;

        TWIDDLE (pSecStatusUpdateBcast->sHeader.iMsgLen);
        TWIDDLE (pSecStatusUpdateBcast->sHeader.iLogTimeStamp);
        TWIDDLE(pSecStatusUpdateBcast->sHeader.iMsgCode);
        TWIDDLE(pSecStatusUpdateBcast->sHeader.iErrorCode);
        TWIDDLE ( pSecStatusUpdateBcast->NoOfRecords);
        for (NoOfRecords = 0;NoOfRecords<pSecStatusUpdateBcast->NoOfRecords;NoOfRecords++)
        {
                TWIDDLE ( pSecStatusUpdateBcast->SecTokenAndEligibility[NoOfRecords].Token);
                for(WhichMarket = 0;WhichMarket <MARKET_TYPES;WhichMarket++)
                {
                        TWIDDLE ( pSecStatusUpdateBcast->SecTokenAndEligibility[NoOfRecords].SecEligibilityPerMkt[WhichMarket].Status);
                }
        }
        logDebug2("18130 : Security Status Changed Bcast");
        logTimestamp("EXIT [dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC]");
        return TRUE;

}


BOOL dTC_MARKET_OPEN_MSG_BCAST(char *NNFData )
{
	logTimestamp("ENTRY [dTC_MARKET_OPEN_MSG_BCAST]");

	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	gettimeofday(&StartPoint1, &tzp);
	StartPoint1.tv_sec = StartPoint1.tv_sec +19800;
	logDebug2("6511 Mkt Open Msg Bcast");
	struct NNF_MARKET_STATUS_CHANGE_BCAST  *pMktStatusChangeBcast = (struct  NNF_MARKET_STATUS_CHANGE_BCAST *) NNFData;

	TWIDDLE (pMktStatusChangeBcast->sHeader.iMsgLen);
	TWIDDLE (pMktStatusChangeBcast->sHeader.iLogTimeStamp);
	TWIDDLE ( pMktStatusChangeBcast->MarketType);
	TWIDDLE ( pMktStatusChangeBcast->BcastMsgLength);

	logDebug2(" Checking Bcast for mktWatch iMsgCode:%d: MarketType:%d: TIME :%d:",pMktStatusChangeBcast->sHeader.iMsgCode,pMktStatusChangeBcast->MarketType,StartPoint1.tv_sec);
	logTimestamp("EXIT [dTC_MARKET_OPEN_MSG_BCAST]");
	return TRUE;


}

BOOL dTC_SECURITY_OPEN_MSG_BCAST(char * NNFData )
{
	logTimestamp("ENTRY [dTC_SECURITY_OPEN_MSG_BCAST]");
	struct  NNF_SEC_OPEN_BCAST  *pSecOpenBcast = (struct  NNF_SEC_OPEN_BCAST *) NNFData;

	TWIDDLE (pSecOpenBcast->sHeader.iMsgLen);
	TWIDDLE (pSecOpenBcast->sHeader.iLogTimeStamp);
	TWIDDLE(pSecOpenBcast->sHeader.iMsgCode);
	TWIDDLE(pSecOpenBcast->sHeader.iErrorCode);
	TWIDDLE ( pSecOpenBcast->Token);
	TWIDDLE ( pSecOpenBcast->OpeningPrice);
	logDebug2(" 6013 New Security Open with OpeningPrice ");
	logTimestamp("EXIT  [dTC_SECURITY_OPEN_MSG_BCAST]");
	return TRUE;
}

BOOL dTC_MKT_STATS_RPT_BCAST(char * NNFData )
{
	LONG32     iRecordNumber = 0;


	struct NNF_MKT_STATS_RPT_DATA_BCAST   *pRptDataBcast = (NNF_MKT_STATS_RPT_DATA_BCAST *)NNFData;
	logDebug2(" 1833 BHAV COPY DATA RECEIVED");

	TWIDDLE(pRptDataBcast->sHeader.iErrorCode);
	TWIDDLE(pRptDataBcast->sHeader.iLogTimeStamp);
	TWIDDLE(pRptDataBcast->sHeader.iMsgLen);
	TWIDDLE(pRptDataBcast->nNumberOfRecords);
	if (pRptDataBcast->MsgType == EQ_BCPY_REPORT_DATA_BCAST)  
	{
		for(iRecordNumber = 0;iRecordNumber < pRptDataBcast->nNumberOfRecords; iRecordNumber++)
		{
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].MktType);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].OpenPrice);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].HighPrice);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].LowPrice);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].ClosingPrice);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].TotalQtyTraded);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].TotalValueTraded);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].PreviousClosePrice);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].FiftyTwoWeekHigh);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].FiftyTwoWeekLow);
			TWIDDLE(pRptDataBcast->MktStatsData[iRecordNumber].CrptActnIndicator);
			/*			logDebug2("pRptDataBcast->MktStatsData[iRecordNumber].TotalQtyTraded [%d]",pRptDataBcast->MktStatsData[iRecordNumber].TotalQtyTraded);
						logDebug2("pRptDataBcast->MktStatsData[iRecordNumber].TotalValueTraded[%.2f]",pRptDataBcast->MktStatsData[iRecordNumber].TotalValueTraded);
						logDebug2("pRptDataBcast->MktStatsData[iRecordNumber].FiftyTwoWeekLow[%.2f]",pRptDataBcast->MktStatsData[iRecordNumber].FiftyTwoWeekLow);
						logDebug2("pRptDataBcast->MktStatsData[iRecordNumber].CrptActnIndicator[%.2f]",pRptDataBcast->MktStatsData[iRecordNumber].CrptActnIndicator);*/

		}

	}
	return TRUE;
}












