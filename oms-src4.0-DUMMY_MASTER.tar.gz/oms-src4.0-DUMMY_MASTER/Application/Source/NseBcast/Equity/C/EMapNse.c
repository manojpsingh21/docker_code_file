#include "IPCS.h"
#include "MapNse.h"
#include "IntTCodes.h"
#include "EQNSEBcastStruct.h"
#include <sys/types.h>
#include <sys/stat.h>


SHORT	fConvertBktToMkt(SHORT iBookType);
BOOL	fConvert_2_Bytes(void *value_in, INT16 Bytes, INT16 value_out);
BOOL	fSendBroadcast(CHAR *sMsgBuf,LONG32 iMsgLen,CHAR *sCalladdress,LONG32 iPortNo);


extern 	CHAR   	sBcastAddr[CALLING_LENS];
extern 	LONG32 	iPortNo,iTapPort,iMbpBcastPort;

BOOL fMapNseBroad(CHAR *sExchPacket,CHAR *sExchPacket1,LONG32 *iMsgLength,LONG32 *iMsgLength1)
{
	LONG32  ilocalTcode,iRetVal=FALSE,i,iMsgLen,iMsgLen1;

	struct 	NNF_HEADER *pHeader;

	struct Bcast_Functions BcastFunctions[MAX_NO_OF_TRANSCODE_MAP] =
	{
		TC_MBP_BCAST,                                   fINT_MBP_BCAST_ITS,
		TC_MARKET_OPEN_MSG_BCAST,                       fINT_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_CLOSE_MSG_BCAST,                      fINT_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_PREOPEN_MSG_BCAST,                    fINT_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_PREOPEN_END_MSG_BCAST,                fINT_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_POSTCLOSE_MSG_BCAST,                  fINT_MARKET_STATUS_CHANGE_BCAST,
		TC_MULTIPLE_INDEX_BCAST,                        fINT_MULTIPLE_INDEX_BCAST,
		TC_MBP_BCAST_TNDTC,                             fINT_MBP_BCAST_ITS_TNDTC,

	};

	pHeader = (struct NNF_HEADER *)sExchPacket;

	ilocalTcode = pHeader->iMsgCode;
	for(i=0 ; i < MAX_NO_OF_TRANSCODE_MAP ;i++)
	{
		if(ilocalTcode == BcastFunctions[i].Transcode)
		{	
			if((iRetVal = (*(BcastFunctions[i].funcPointer))(sExchPacket,sExchPacket1,iMsgLength,iMsgLength1)) == FALSE)
			{
				logFatal("MapNseBroad: Error in Mapping to Internal Format");
				return iRetVal;
			}
			*iMsgLength= iMsgLen;
			*iMsgLength1 =iMsgLen1;

		}
	}
	return iRetVal;

}



BOOL fINT_MARKET_STATUS_CHANGE_BCAST(CHAR *sRecvBuf,CHAR *sRecvBuf1,LONG32 *iMsgLength,LONG32 *iMsgLength1)
{
	LONG32	iTcode = 0;

	struct	INT_MARKET_STATUS_CHANGE_BCAST 	pIntMktStatusChgBcast;
	struct 	NNF_MARKET_STATUS_CHANGE_BCAST  *pMktChanBcast;

	pMktChanBcast = (struct NNF_MARKET_STATUS_CHANGE_BCAST *)sRecvBuf;

	memset(&pIntMktStatusChgBcast,' ',sizeof(struct INT_MARKET_STATUS_CHANGE_BCAST));

	*iMsgLength = sizeof(struct INT_MARKET_STATUS_CHANGE_BCAST);

	switch(pMktChanBcast->pHeader.iMsgCode)
	{
		case 	6511:
			iTcode = TC_INT_MARKET_OPEN_MSG_BCAST;
			break;
		case 	6521:
			iTcode = TC_INT_MARKET_CLOSE_MSG_BCAST;
			break;
		case	6531:
			iTcode = TC_INT_MARKET_PREOPEN_MSG_BCAST;
			break;
		case	6571:
			iTcode = TC_INT_MARKET_PREOPEN_END_MSG_BCAST;
			break;
		case	6522:
			iTcode = TC_INT_MARKET_POSTCLOSE_MSG_BCAST;
			break;
		case	6583:
			iTcode = TC_INT_POST_CLOSING_START_BCAST;
			break;
		case	6584:
			iTcode = TC_INT_POST_CLOSING_END_BCAST;
			break;
		default:
			iTcode = pMktChanBcast->pHeader.iMsgCode;	

			break;

	}

	fConvert_2_Bytes(&iTcode,1,&pIntMktStatusChgBcast.pBcastHeader.iMsgCode);

	memcpy(pIntMktStatusChgBcast.sBcastMsg,pMktChanBcast->sBcastMsg,BCAST_MSG_LEN);

	memset(sRecvBuf,' ',sizeof(struct INT_MARKET_STATUS_CHANGE_BCAST));

	memcpy(sRecvBuf,(CHAR *)&pIntMktStatusChgBcast,sizeof(struct INT_MARKET_STATUS_CHANGE_BCAST));

	return TRUE;

}



BOOL  fINT_MBP_BCAST_ITS(CHAR *sInBuff,CHAR *sOutBuff,LONG32 *iMsgLen, LONG32 *MsgLen1)
{
	struct 		INT_MBP_TOUCH_LINE_BCAST pIntMbpTouchbcast;
	struct 		NNF_MBP_BCAST		*pMboMbpBcast;

	LONG32		j=0,i=0,iSell=0;
	CHAR		sStringMBP[MAX_NO_OF_SECURITIES];
	CHAR		sStringTouch[MAX_NO_OF_SECURITIES];

	LONG32		iLenString;
	CHAR		sLastTradeTime[DATE_TIME_LEN];
	LONG32		iBuyQty[5];
	LONG32		iSellQty[5];
	DOUBLE64	iBuyPrice[5];
	DOUBLE64	iSellPrice[5];
	DOUBLE64	iNetPriceChange;
	SHORT		iBuyOrdno[5];
	SHORT		iSellOrdno[5];


	pMboMbpBcast = (struct NNF_MBP_BCAST *)sInBuff;

	for(j=0;j < pMboMbpBcast->iNoOfRecs;j++)
	{
		memset((CHAR *)&pIntMbpTouchbcast,'\0',sizeof(struct  INT_MBP_TOUCH_LINE_BCAST));

		pIntMbpTouchbcast.pBcastHeader.iMsgLen = sizeof(struct  INT_MBP_TOUCH_LINE_BCAST);

		pIntMbpTouchbcast.pBcastHeader.cSegment = 'E';
		pIntMbpTouchbcast.pBcastHeader.iMsgCode = TC_INT_MBP_TOUCH_BCAST;
		strcpy(pIntMbpTouchbcast.pBcastHeader.sExchId,"NSE");

		for(i=0;i < 5 ;i++)
		{
			iBuyQty[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iQty;

			pIntMbpTouchbcast.pSubmbp[i].iBuyQty = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iQty;

			iBuyPrice[i] = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iPrice / CONST_PRICE_FACTOR;

			pIntMbpTouchbcast.pSubmbp[i].iBuyprice = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iPrice / CONST_PRICE_FACTOR;
			iBuyOrdno[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iNoOfOrders;
			pIntMbpTouchbcast.pSubmbp[i].iBuyOrdNo = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iNoOfOrders;

			iSellQty[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iQty;

			pIntMbpTouchbcast.pSubmbp[i].iSellQty = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iQty;

			iSellPrice[i] = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iPrice / CONST_PRICE_FACTOR;

			pIntMbpTouchbcast.pSubmbp[i].iSellPrice = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iPrice / CONST_PRICE_FACTOR;			

			iSellOrdno[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iNoOfOrders;

			pIntMbpTouchbcast.pSubmbp[i].iSellOrdNo = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iNoOfOrders;

		}

		memset(sLastTradeTime,'\0',DATE_STRING_LENGTH);

		convert_seconds_to_date(pMboMbpBcast->pMBPInfo[j].iLastTradeTime,sLastTradeTime);

		logDebug2("LastTradeTime is : %s",sLastTradeTime);

		iNetPriceChange = ((DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLastTradedPrice / CONST_PRICE_FACTOR)) - ((DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iClosePrice / CONST_PRICE_FACTOR));

		pIntMbpTouchbcast.iTouchBuyQty = iBuyQty[0];

		pIntMbpTouchbcast.iTouchSellQty	= iSellQty[0];

		pIntMbpTouchbcast.iTouchSellPrice = iSellPrice[0];

		pIntMbpTouchbcast.iTouchBuyPrice = iBuyPrice[0];


		pIntMbpTouchbcast.iSecurityID = pMboMbpBcast->pMBPInfo[j].iToken;

		pIntMbpTouchbcast.iLastTradedPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLastTradeTime / CONST_PRICE_FACTOR);
		pIntMbpTouchbcast.iNetPriceChange = iNetPriceChange;

		pIntMbpTouchbcast.iAvgTradePrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iAvgTradePrice/CONST_PRICE_FACTOR);

		pIntMbpTouchbcast.iClosePrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iClosePrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iOpenPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iOpenPrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iHighPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iHighPrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iLowPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLowPrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iVolTradedToday = pMboMbpBcast->pMBPInfo[j].iVolTradedToday;


		pIntMbpTouchbcast.iTotalBuyQty = pMboMbpBcast->pMBPInfo[j].iTotalBuyQty;


		pIntMbpTouchbcast.iTotalSellQty = pMboMbpBcast->pMBPInfo[j].iTotalSellQty;


		memcpy(pIntMbpTouchbcast.sLastTradeTime,sLastTradeTime,DATE_STRING_LENGTH);



		logDebug2("----------------------------Printing Structure--------------------------------%s:%d ",sBcastAddr,iPortNo);


		fSendBroadcast((CHAR *)&pIntMbpTouchbcast,sizeof(struct INT_MBP_TOUCH_LINE_BCAST),sBcastAddr,iPortNo);

		memset(sStringTouch,'\0',500);

		sprintf(sStringTouch,"T,E,%d,NL,NSE,%d,%.2lf,%d,%.2lf,%.2lf,%d,%.2lf,%d,%s,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf#",pMboMbpBcast->pMBPInfo[j].iToken,iBuyQty[0],iBuyPrice[0],iSellQty[0],iSellPrice[0],(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLastTradedPrice/CONST_PRICE_FACTOR),pMboMbpBcast->pMBPInfo[j].iVolTradedToday,iNetPriceChange,pMboMbpBcast->pMBPInfo[j].iLastTradedQty,sLastTradeTime,(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iClosePrice/CONST_PRICE_FACTOR),(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iOpenPrice/CONST_PRICE_FACTOR),(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iHighPrice/CONST_PRICE_FACTOR),(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLowPrice/CONST_PRICE_FACTOR));


		logDebug2("String is [%s]  :%s,%d,%d",sStringTouch,sBcastAddr,iPortNo,iMbpBcastPort);


		fSendBroadcast((CHAR *)sStringTouch,200,sBcastAddr,6888);

		memset(sStringMBP,'\0',500);


		sprintf(sStringMBP,"M,E,%d,NL,NSE|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%.0lf,%.0lf#",pMboMbpBcast->pMBPInfo[j].iToken,iBuyOrdno[0],iSellOrdno[0],iBuyQty[0],iBuyPrice[0],iSellQty[0],iSellPrice[0],iBuyOrdno[1],iSellOrdno[1],iBuyQty[1],iBuyPrice[1],iSellQty[1],iSellPrice[1],iBuyOrdno[2],iSellOrdno[2],iBuyQty[2],iBuyPrice[2],iSellQty[2],iSellPrice[2],iBuyOrdno[3],iSellOrdno[3],iBuyQty[3],iBuyPrice[3],iSellQty[3],iSellPrice[3],iBuyOrdno[4],iSellOrdno[4],iBuyQty[4],iBuyPrice[4],iSellQty[4],iSellPrice[4],pMboMbpBcast->pMBPInfo[j].iTotalBuyQty,pMboMbpBcast->pMBPInfo[j].iTotalSellQty);	

		memset(sOutBuff,'\0',500);

		logDebug2("StringMBP is [%s] ",sStringMBP);

		fSendBroadcast((CHAR *)sStringMBP,300,sBcastAddr,6889);

		return TRUE;

	}


}


BOOL  fINT_MBP_BCAST_ITS_TNDTC(CHAR *sInBuff,CHAR *sOutBuff,LONG32 *iMsgLen, LONG32 *MsgLen1)
{
	struct 		INT_MBP_TOUCH_LINE_BCAST pIntMbpTouchbcast;
	struct 		NNF_MBP_BCAST_TNDTC	*pMboMbpBcast;

	LONG32		j=0,i=0,iSell=0;
	CHAR		sStringMBP[MAX_NO_OF_SECURITIES];
	CHAR		sStringTouch[MAX_NO_OF_SECURITIES];

	LONG32		iLenString;
	CHAR		sLastTradeTime[DATE_TIME_LEN];
	LONG32		iBuyQty[5];
	LONG32		iSellQty[5];
	DOUBLE64	iBuyPrice[5];
	DOUBLE64	iSellPrice[5];
	DOUBLE64	iNetPriceChange;
	SHORT		iBuyOrdno[5];
	SHORT		iSellOrdno[5];


	pMboMbpBcast = (struct NNF_MBP_BCAST_TNDTC *)sInBuff;

	for(j=0;j < pMboMbpBcast->iNoOfRecs;j++)
	{
		memset((CHAR *)&pIntMbpTouchbcast,'\0',sizeof(struct  INT_MBP_TOUCH_LINE_BCAST));

		pIntMbpTouchbcast.pBcastHeader.iMsgLen = sizeof(struct  INT_MBP_TOUCH_LINE_BCAST);

		pIntMbpTouchbcast.pBcastHeader.cSegment = 'E';
		pIntMbpTouchbcast.pBcastHeader.iMsgCode = TC_INT_MBP_TOUCH_BCAST;
		strcpy(pIntMbpTouchbcast.pBcastHeader.sExchId,"NSE");

		for(i=0;i < 5 ;i++)
		{
			iBuyQty[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iQty;

			pIntMbpTouchbcast.pSubmbp[i].iBuyQty = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iQty;

			iBuyPrice[i] = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iPrice / CONST_PRICE_FACTOR;

			pIntMbpTouchbcast.pSubmbp[i].iBuyprice = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iPrice / CONST_PRICE_FACTOR;
			iBuyOrdno[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iNoOfOrders;
			pIntMbpTouchbcast.pSubmbp[i].iBuyOrdNo = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i].iNoOfOrders;

			iSellQty[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iQty;

			pIntMbpTouchbcast.pSubmbp[i].iSellQty = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iQty;

			iSellPrice[i] = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iPrice / CONST_PRICE_FACTOR;

			pIntMbpTouchbcast.pSubmbp[i].iSellPrice = (DOUBLE64)pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iPrice / CONST_PRICE_FACTOR;			

			iSellOrdno[i] = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iNoOfOrders;

			pIntMbpTouchbcast.pSubmbp[i].iSellOrdNo = pMboMbpBcast->pMBPInfo[j].pMBPRecords[i+5].iNoOfOrders;

		}

		memset(sLastTradeTime,'\0',DATE_STRING_LENGTH);

		convert_seconds_to_date(pMboMbpBcast->pMBPInfo[j].iLastTradeTime,sLastTradeTime);

		logDebug2("LastTradeTime is : %s",sLastTradeTime);

		iNetPriceChange = ((DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLastTradedPrice / CONST_PRICE_FACTOR)) - ((DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iClosePrice / CONST_PRICE_FACTOR));

		pIntMbpTouchbcast.iTouchBuyQty = iBuyQty[0];

		pIntMbpTouchbcast.iTouchSellQty	= iSellQty[0];

		pIntMbpTouchbcast.iTouchSellPrice = iSellPrice[0];

		pIntMbpTouchbcast.iTouchBuyPrice = iBuyPrice[0];


		pIntMbpTouchbcast.iSecurityID = pMboMbpBcast->pMBPInfo[j].iToken;

		pIntMbpTouchbcast.iLastTradedPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLastTradeTime / CONST_PRICE_FACTOR);
		pIntMbpTouchbcast.iNetPriceChange = iNetPriceChange;

		pIntMbpTouchbcast.iAvgTradePrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iAvgTradePrice/CONST_PRICE_FACTOR);

		pIntMbpTouchbcast.iClosePrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iClosePrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iOpenPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iOpenPrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iHighPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iHighPrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iLowPrice = (DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLowPrice/CONST_PRICE_FACTOR);


		pIntMbpTouchbcast.iVolTradedToday = pMboMbpBcast->pMBPInfo[j].iVolTradedToday;


		pIntMbpTouchbcast.iTotalBuyQty = pMboMbpBcast->pMBPInfo[j].iTotalBuyQty;


		pIntMbpTouchbcast.iTotalSellQty = pMboMbpBcast->pMBPInfo[j].iTotalSellQty;


		memcpy(pIntMbpTouchbcast.sLastTradeTime,sLastTradeTime,DATE_STRING_LENGTH);



		logDebug2("----------------------------Printing Structure--------------------------------%s:%d ",sBcastAddr,iPortNo);


		fSendBroadcast((CHAR *)&pIntMbpTouchbcast,sizeof(struct INT_MBP_TOUCH_LINE_BCAST),sBcastAddr,iPortNo);

		memset(sStringTouch,'\0',500);

		sprintf(sStringTouch,"T,E,%d,NL,NSE,%d,%.2lf,%d,%.2lf,%.2lf,%d,%.2lf,%d,%s,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf#",pMboMbpBcast->pMBPInfo[j].iToken,iBuyQty[0],iBuyPrice[0],iSellQty[0],iSellPrice[0],(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLastTradedPrice/CONST_PRICE_FACTOR),pMboMbpBcast->pMBPInfo[j].iVolTradedToday,iNetPriceChange,pMboMbpBcast->pMBPInfo[j].iLastTradedQty,sLastTradeTime,(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iClosePrice/CONST_PRICE_FACTOR),(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iOpenPrice/CONST_PRICE_FACTOR),(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iHighPrice/CONST_PRICE_FACTOR),(DOUBLE64)(pMboMbpBcast->pMBPInfo[j].iLowPrice/CONST_PRICE_FACTOR));


		logDebug2("String is [%s]  :%s,%d,%d",sStringTouch,sBcastAddr,iPortNo,iMbpBcastPort);


		fSendBroadcast((CHAR *)sStringTouch,200,sBcastAddr,6888);

		memset(sStringMBP,'\0',500);


		sprintf(sStringMBP,"M,E,%d,NL,NSE|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%d,%d,%d,%.2lf,%d,%.2lf|%.0lf,%.0lf#",pMboMbpBcast->pMBPInfo[j].iToken,iBuyOrdno[0],iSellOrdno[0],iBuyQty[0],iBuyPrice[0],iSellQty[0],iSellPrice[0],iBuyOrdno[1],iSellOrdno[1],iBuyQty[1],iBuyPrice[1],iSellQty[1],iSellPrice[1],iBuyOrdno[2],iSellOrdno[2],iBuyQty[2],iBuyPrice[2],iSellQty[2],iSellPrice[2],iBuyOrdno[3],iSellOrdno[3],iBuyQty[3],iBuyPrice[3],iSellQty[3],iSellPrice[3],iBuyOrdno[4],iSellOrdno[4],iBuyQty[4],iBuyPrice[4],iSellQty[4],iSellPrice[4],pMboMbpBcast->pMBPInfo[j].iTotalBuyQty,pMboMbpBcast->pMBPInfo[j].iTotalSellQty);	

		memset(sOutBuff,'\0',500);

		logDebug2("StringMBP is [%s] ",sStringMBP);

		fSendBroadcast((CHAR *)sStringMBP,300,sBcastAddr,6889);

		return TRUE;

	}


}


BOOL  fINT_MULTIPLE_INDEX_BCAST(CHAR *sInBuff,CHAR *sOutBuff,LONG32 *iMsgLen,LONG32 *iMsgLen1)
{
	struct INT_MULTIPLE_INDEX_BCAST  pIntMultiIndxBcast;

	BOOL 	iFlag = FALSE;
	LONG32 	i;
	LONG32	iTcode= 0 ,iNoRec = 0;

	CHAR	sStringIndex[500];
	LONG32	iLenStr;


	struct NNF_MULTIPLE_INDEX_BCAST *pMultiIndexData;

	iTcode = TC_INT_MULTIPLE_INDEX_BCAST;
	pMultiIndexData = (struct NNF_MULTIPLE_INDEX_BCAST *)sInBuff;

	memset((CHAR *)&pIntMultiIndxBcast,' ',sizeof(struct NNF_MULTIPLE_INDEX_BCAST));

	fConvert_2_Bytes(&iTcode, 1 , &pIntMultiIndxBcast.pBcastHeader.iMsgCode);

	iNoRec = sizeof(struct INT_MULTIPLE_INDEX_BCAST);

	*iMsgLen = sizeof(struct INT_MULTIPLE_INDEX_BCAST);

	logDebug2("Message Length %d ",*iMsgLen);

	logDebug2("NORECI : %d",pMultiIndexData->iNumberOfRecords);

	for(i=0;i < pMultiIndexData->iNumberOfRecords;i++)
	{
		memset((CHAR *)&pIntMultiIndxBcast,'\0',sizeof(struct INT_MULTIPLE_INDEX_BCAST));

		/**************** Populating Index Data Structure **********************/		
		pIntMultiIndxBcast.pBcastHeader.iMsgCode = TC_INT_MULTIPLE_INDEX_BCAST;

		pIntMultiIndxBcast.pBcastHeader.iMsgLen = sizeof( struct INT_MULTIPLE_INDEX_BCAST);

		memcpy(pIntMultiIndxBcast.sIndexName,pMultiIndexData->pIndicesData[i].sIndexName,DRV_INDEX_NAME_LEN);

		pIntMultiIndxBcast.iIndexVal = ((FLOAT32)(pMultiIndexData->pIndicesData[i].iIndexVal)/CONST_PRICE_FACTOR);

		pIntMultiIndxBcast.iHighIndexVal = ((FLOAT32)(pMultiIndexData->pIndicesData[i].iHighIndexVal)/CONST_PRICE_FACTOR);

		pIntMultiIndxBcast.iLowIndexVal = ((FLOAT32)(pMultiIndexData->pIndicesData[i].iLowIndexVal)/CONST_PRICE_FACTOR);

		pIntMultiIndxBcast.iOpeningIndex = ((FLOAT32)(pMultiIndexData->pIndicesData[i].iOpeningIndex)/CONST_PRICE_FACTOR);

		pIntMultiIndxBcast.iClosingIndex = ((FLOAT32)(pMultiIndexData->pIndicesData[i].iClosingIndex)/CONST_PRICE_FACTOR);

		pIntMultiIndxBcast.iPercentChange = ((FLOAT32)(pMultiIndexData->pIndicesData[i].iPercentChange)/CONST_PRICE_FACTOR);

		pIntMultiIndxBcast.cNetChangeIndicator = pMultiIndexData->pIndicesData[i].cNetChangeIndicator;


		/********************* Populating Index Data  Structure*****************************/		



		memset(sStringIndex,'\0',500);


		sprintf(sStringIndex,"I,NSE,%s,%.2lf,%.2lf,%.2lf,%.2lf,%c,%.2lf#",pIntMultiIndxBcast.sIndexName,pIntMultiIndxBcast.iIndexVal,pIntMultiIndxBcast.iHighIndexVal,pIntMultiIndxBcast.iLowIndexVal,pIntMultiIndxBcast.iOpeningIndex,pIntMultiIndxBcast.iClosingIndex,pIntMultiIndxBcast.cNetChangeIndicator,pIntMultiIndxBcast.iPercentChange);



		fSendBroadcast((CHAR *)&pIntMultiIndxBcast,sizeof(struct INT_MULTIPLE_INDEX_BCAST),sBcastAddr,6895);


		fSendBroadcast((CHAR *)sStringIndex,500,sBcastAddr,6894);


	}

}




BOOL fConvert_2_Bytes(void *value_in, INT16 Bytes, INT16 value_out)
{
	INT16     	ptrByteIn;
	INT16     	ptrByteOut;
	LONG64 		a = 0  ;

	ptrByteOut= value_out;

	ptrByteIn=value_in;

	if ( Bytes > 4 )
	{
		memcpy(ptrByteOut,ptrByteIn+(sizeof(SPARCLONG64)-Bytes),Bytes);
	}		
	else
	{
		memcpy(ptrByteOut,ptrByteIn+(sizeof(LONG32) -Bytes),Bytes);
		memcpy(ptrByteOut,ptrByteIn,Bytes);
	}

	memcpy ( &a , ptrByteOut , Bytes ) ;
	value_out=ptrByteOut;

	return TRUE;



}



