#include "HashTable.h"
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>
//#include "hiredis.h"
#include <time.h>

#define WAIT_BEFORE_RETRY 1

/* thisstruct THREAD_PARAMS
{
	MYSQL *DB_Con;
	LONG32 thread_id;
};  */

//BOOL  fBcastUpdt(void *parameter);
BOOL  fBcastUpdt();
MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32  iAutoSqoffToOrdRtr;
LONG32  iSleepTime = 0;
MYSQL 	*DB_Con;
redisContext *c1;
redisReply *reply1;

CHAR    GttBrdCst_Time  [ENV_VARIABLE_LEN] ;
void    LoadEnv();

main(int argc,char *argv[])
{
	logTimestamp("ENTRY [Main]");
	//LONG32 	iFlag;
	//LONG32 	i;
	//LONG32	iNseRecordCount;
	//CHAR	cMaxNoThread;
	//LONG32	iMaxNoThread;
	OpenMsgQue();
	LoadEnv();

	//iMaxNoThread = atoi(argv[1]);
	iSleepTime = atoi(argv[1]);

	//logDebug3("iMaxNoThread :%d: ",iMaxNoThread);
	logDebug3("iSleepTime :%d:",iSleepTime);

//this	struct THREAD_PARAMS params[iMaxNoThread];


	//setbuf(stdout,0);
//this	pthread_t thread_id[iMaxNoThread];


	DB_Con=DB_Connect();
	c1 = RDConnect();

	logDebug2("Connecting to database.......");

	if(mysql_autocommit(DB_Con,1))
	{
		sql_Error(DB_Con);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}
	mysql_free_result(result);

/*this	for(i=0;i<iMaxNoThread;i++)
	{
		params[i].thread_id=i;
		params[i].DB_Con = DB_Connect();	

		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,(void *)&params[i]))!=0)
			logDebug2("Cant create thread %d",i);
		else
			logDebug2("Created");

	}

	logDebug2("ALOK HERE 1 ");

	for(i=0;i<iMaxNoThread;i++)
	{
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logDebug2("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logDebug2("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}
*/
	fBcastUpdt();

	logTimestamp("EXIT [MAin]");
}

//BOOL fBcastUpdt(void *parameter)
BOOL fBcastUpdt()
{
	logTimestamp("ENTRY [fBcastUpdt]");
	INT16	i;
//	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];
//This	struct THREAD_PARAMS *l_parameter = parameter;
	struct  ORDER_REQUEST   pEOrdReq;
	MYSQL_RES       *Res;
	MYSQL_RES       *Res1;
	MYSQL_RES       *Res2;
        MYSQL_RES       *Res3;

	MYSQL_ROW       Row;
	MYSQL_ROW       Row1;
	LONG32	iCount;
	LONG32	iNoOfRec = 0;
	LONG32	iTempScripCode = 0;
	LONG32	iLegNo = 0;
	LONG32	iTtlQty = 0;
	LONG32	iChkFlag = 0;
	LONG32  Mkt,iGrpId = 1,iMktSts;
	LONG64  SleepTime;

	DOUBLE64 fOrderPrice = 0.00;
	BOOL	iRetVal = FALSE;
	CHAR    cSegmnt =       '\0';
	CHAR    cGTTType =       '\0';
	CHAR    cWriteFlag =       '\0';
	CHAR    cSeg =	'\0';	
	CHAR    cHolidayChk =	'\0';	
	CHAR    flag = FALSE;
	
	DOUBLE64        fMaxLtp =0.00;
	DOUBLE64        fMinLtp =0.00;
	DOUBLE64        fTempLtp=0.00;
	DOUBLE64        fCmpTriggerPrice=0.00;
	DOUBLE64	fCmpOrdTriggerPrice = 0.00;
	CHAR sKeyValue[RADIS_KEY_LEN];
	CHAR sExchId[EXCHANGE_LEN];
	CHAR sSecId[DB_SECURITY_ID_LEN];
	CHAR sCommand[COMMAND_LEN];
	CHAR    sSelectQry[MAX_QUERY_SIZE];
	CHAR    sSelQry[MAX_QUERY_SIZE];
	//CHAR    InsQuery[MAX_QUERY_SIZE];
	//memset(InsQuery,'\0',MAX_QUERY_SIZE);
	CHAR    sMkt_Exch[EXCHANGE_LEN];

	CHAR    Time    [MAX_QUERY_SIZE];	
	BOOL    iTradingHolidayFlg = TRUE;

	memset(Time,'\0',MAX_QUERY_SIZE);

	sprintf(Time,"SELECT julidate(CONCAT(current_date ,' ', \"%s\"))-julidate(sysdate());",GttBrdCst_Time );
        logTimestamp("Time  Query is[%s]",Time);


        if(mysql_query(DB_Con, Time) != SUCCESS)
        {
                        logSqlFatal("ERROR IN SELECT QUERY");
                        mysql_close(DB_Con);
                        sql_Error(DB_Con);
        }

        logDebug2("--SQL query selected successfully--");
        Res3 = mysql_store_result(DB_Con);
        logDebug2("Res4 :%d:",mysql_num_rows(Res3));

        if(mysql_num_rows(Res3) == 0)
        {
                logTimestamp("******* Zero row returned ******");
                SleepTime = 2;
        }
        else
        {
                logDebug2("Row selected");
                Row1 = mysql_fetch_row(Res3);
                logDebug2("value of julian date is | %s |", Row1[0]);
                SleepTime=atol(Row1[0]);
        }
        mysql_free_result(Res3);
        logDebug2("SleepTime :%ld:",SleepTime);

        if(SleepTime <= 0)
        {
                SleepTime = 2;
        }
	
	sleep(SleepTime);

        logDebug2("Going in whileloop");	

	while(TRUE)
	{
		sleep(iSleepTime);
		memset(sSelectQry,'\0',MAX_QUERY_SIZE);
		/****
		sprintf(sSelectQry,"SELECT GTT_EXCH_ID,GTT_SEGMENT,GTT_SCRIP_CODE,(MAX(GTT_TRIGGER_PRICE) + (MAX(GTT_TRIGGER_PRICE) * (PARAM_VALUE / 100))) AS MAX_LTP,\
				(MIN(GTT_TRIGGER_PRICE) - (MIN(GTT_TRIGGER_PRICE) * (PARAM_VALUE / 100))) AS MIN_LTP , GTT_LEG_NO\
				FROM GTT_ORDERS G1 , SYS_PARAMETERS WHERE GTT_SERIAL_NO = (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS G2 \
				WHERE G2.GTT_ORDER_NO = G1.GTT_ORDER_NO) AND  GTT_MSG_CODE NOT IN ('9114','9115') AND \
				PARAM_NAME = 'GTT_ORD_LTP_BUFFER' GROUP BY GTT_EXCH_ID , GTT_SEGMENT , GTT_SCRIP_CODE;");
		****/
		
		sprintf(sSelectQry,"SELECT GTT_EXCH_ID,GTT_SEGMENT,GTT_SCRIP_CODE,(MAX(GTT_TRIGGER_PRICE) + (MAX(GTT_TRIGGER_PRICE) * (PARAM_VALUE / 100))) AS MAX_LTP,\
				(MIN(GTT_TRIGGER_PRICE) - (MIN(GTT_TRIGGER_PRICE) * (PARAM_VALUE / 100))) AS MIN_LTP,GTT_LEG_NO \
				FROM (SELECT GTT_ORDER_NO ORD,MAX(GTT_SERIAL_NO) SER, GTT_LEG_NO LEG FROM GTT_ORDERS G2 GROUP BY G2.GTT_ORDER_NO, \
				G2.GTT_LEG_NO, G2.GTT_SERIAL_NO) AS X,GTT_ORDERS G1 LEFT JOIN SYS_PARAMETERS ON (PARAM_NAME = 'GTT_ORD_LTP_BUFFER')\
				WHERE GTT_ORDER_NO = X.ORD AND GTT_LEG_NO = X.LEG AND GTT_SERIAL_NO = X.SER AND GTT_MSG_CODE NOT IN ('9114' , '9115')\
				GROUP BY GTT_EXCH_ID , GTT_SEGMENT , GTT_SCRIP_CODE;");
		logTimestamp("sUpdateQry Query[%s]",sSelectQry);
		if(mysql_query(DB_Con,sSelectQry) != SUCCESS)
		{
			logSqlFatal("ERROR IN SELECT QUERY");
			sql_Error(DB_Con);
		}
		Res1 = mysql_store_result(DB_Con);
		if(mysql_num_rows(Res1) == 0)
		{
			logFatal(".....Zero row returned.......");
			//mysql_free_result(Res1);
		}
		logDebug3("No Of Row :%d",mysql_num_rows(Res1));
		while((Row = mysql_fetch_row(Res1)))
		{
			memset(sExchId,'\0',EXCHANGE_LEN);
			memset(sSecId,'\0',DB_SECURITY_ID_LEN);

			strncpy(sExchId,Row[0],EXCHANGE_LEN);
			cSegmnt = Row[1][0];
			strncpy(sSecId,Row[2],DB_SECURITY_ID_LEN);
			iTempScripCode = atoi(Row[2]);
			fMaxLtp = atof(Row[3]);
			fMinLtp = atof(Row[4]);
			iLegNo = atoi (Row[5]);	
			
			logDebug3("sExchId :%s:",sExchId);
			logDebug3("cSegmnt :%c:",cSegmnt);
			logDebug3("sSecId  :%s:",sSecId);
			logDebug3("iTempScripCode:%d:",iTempScripCode);
			logDebug3("fMaxLtp :%f:",fMaxLtp);
			logDebug3("fMinLtp :%f:",fMinLtp);
			logDebug3("iLegNo  :%d:",iLegNo);
			
			memset(sKeyValue,'\0',RADIS_KEY_LEN);
			sprintf(sKeyValue,"%s:%c:%d",sExchId,cSegmnt,iTempScripCode);
			memset(sCommand,'\0',COMMAND_LEN);
			sprintf(sCommand,"HMGET %s LTP ",sKeyValue);
			logTimestamp("sCommand -> %s",sCommand);
			reply1 = redisCommand(c1,sCommand);
			if(reply1->element[0]->str != NULL)
			{
				fTempLtp = atof(reply1->element[0]->str);
				logDebug3("fTempLtp :%f: of sSecId :%s:",fTempLtp,sSecId);

				if(fTempLtp <= fMaxLtp && fTempLtp >= fMinLtp )
				{
					memset(sSelQry,'\0',MAX_QUERY_SIZE);

/****					
					sprintf(sSelQry,"SELECT GTT_ORDER_NO,\
							GTT_SERIAL_NO,\
							GTT_SCRIP_CODE,\
							GTT_MKT_TYPE,\
							GTT_EXCH_ID,\
							GTT_ENTITY_ID,\
							GTT_CLIENT_ID,\
							GTT_BUY_SELL_IND,\
							GTT_TOTAL_QTY,\
							GTT_REM_QTY,\
							GTT_DISC_QTY,\
							GTT_DISC_REM_QTY,\
							GTT_TOTAL_TRADED_QTY,\
							GTT_ORDER_PRICE,\
							GTT_TRIGGER_PRICE,\
							GTT_VALIDITY,\
							GTT_ORDER_TYPE,\
							GTT_USER_ID,\
							GTT_MIN_FILL_QTY,\
							GTT_PRO_CLIENT,\
							GTT_USER_TYPE,\
							GTT_REMARKS,\
							GTT_SOURCE_FLG,\
							GTT_PRODUCT_ID,\
							GTT_MSG_CODE,\
							GTT_SEGMENT ,\
							GTT_STRATEGY_ID, \
							GTT_ORDER_OFFON, \
							GTT_PAN_NO,\
							GTT_PARTICIPANT_TYPE,\
							GTT_SETTLOR,\
							IFNULL(GTT_MKT_PROTECT_FLG,'N'),\
							GTT_MKT_PROTECT_VAL,\
							GTT_GTC_FLG,\
							GTT_ENCASH_FLG,\
							GTT_LEG_NO, \
							GTT_TYPE,\
							GTT_REMARKS1,\
							GTT_REMARKS2,\
							GTT_ORD_TRIGGER_PRICE \
							FROM    GTT_ORDERS A\
							WHERE   A.GTT_ORD_STATUS = \'%c\'\
							AND     A.GTT_MSG_CODE IN (%d,%d)\
							AND     A.GTT_SCRIP_CODE = \"%s\" \
							AND     A.GTT_SERIAL_NO = (SELECT MAX(B.GTT_SERIAL_NO) FROM GTT_ORDERS B WHERE B.GTT_ORDER_NO = A.GTT_ORDER_NO AND B.GTT_LEG_NO= %d)\
							AND     A.GTT_EXCH_ID = \"%s\" AND GTT_LEG_NO = %d ;",EXCH_CONFIRM_STATUS,TC_INT_GTT_ORDER_ENTRY,TC_INT_GTT_ORDER_MODIFY,sSecId,iLegNo,sExchId,iLegNo);  
***/					sprintf(sSelQry,"SELECT GTT_ORDER_NO,\
                                                        GTT_SERIAL_NO,\
                                                        GTT_SCRIP_CODE,\
                                                        GTT_MKT_TYPE,\
                                                        GTT_EXCH_ID,\
                                                        GTT_ENTITY_ID,\
                                                        GTT_CLIENT_ID,\
                                                        GTT_BUY_SELL_IND,\
                                                        GTT_TOTAL_QTY,\
                                                        GTT_REM_QTY,\
                                                        GTT_DISC_QTY,\
                                                        GTT_DISC_REM_QTY,\
                                                        GTT_TOTAL_TRADED_QTY,\
                                                        GTT_ORDER_PRICE,\
                                                        GTT_TRIGGER_PRICE,\
                                                        GTT_VALIDITY,\
                                                        GTT_ORDER_TYPE,\
                                                        GTT_USER_ID,\
                                                        GTT_MIN_FILL_QTY,\
                                                        GTT_PRO_CLIENT,\
                                                        GTT_USER_TYPE,\
                                                        GTT_REMARKS,\
                                                        GTT_SOURCE_FLG,\
                                                        GTT_PRODUCT_ID,\
                                                        GTT_MSG_CODE,\
                                                        GTT_SEGMENT ,\
                                                        GTT_STRATEGY_ID, \
                                                        GTT_ORDER_OFFON, \
                                                        GTT_PAN_NO,\
                                                        GTT_PARTICIPANT_TYPE,\
                                                        GTT_SETTLOR,\
                                                        IFNULL(GTT_MKT_PROTECT_FLG,'N'),\
                                                        GTT_MKT_PROTECT_VAL,\
                                                        GTT_GTC_FLG,\
                                                        GTT_ENCASH_FLG,\
                                                        GTT_LEG_NO, \
                                                        GTT_TYPE,\
                                                        GTT_REMARKS1,\
                                                        GTT_REMARKS2,\
                                                        GTT_ORD_TRIGGER_PRICE \
							FROM (SELECT C.GTT_ORDER_NO ORD,MAX(C.GTT_SERIAL_NO)SER, C.GTT_LEG_NO LEG FROM GTT_ORDERS C WHERE C.GTT_EXCH_ID = \"%s\" \
							AND C.GTT_SCRIP_CODE = \"%s\" AND C.GTT_LEG_NO =  %d  GROUP BY C.GTT_ORDER_NO ,C.GTT_LEG_NO )AS X,\
							GTT_ORDERS A WHERE A.GTT_ORDER_NO = X.ORD AND A.GTT_LEG_NO = X.LEG AND A.GTT_SERIAL_NO = X.SER AND A.GTT_ORD_STATUS = \'%c\' \ 
							AND A.GTT_MSG_CODE IN (%d,%d);" ,sExchId,sSecId,iLegNo,EXCH_CONFIRM_STATUS,TC_INT_GTT_ORDER_ENTRY,TC_INT_GTT_ORDER_MODIFY);			
					logTimestamp("sSelQry :%s:",sSelQry);
					if(mysql_query(DB_Con,sSelQry) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("Error in fEquPumpOffOrd Query.");
						exit(ERROR);
					}

					Res = mysql_store_result(DB_Con);
					iNoOfRec= mysql_num_rows(Res);

					logDebug2("Rows returned from Database = :%d:",iNoOfRec);


					for(i = 0; i < iNoOfRec ; i ++)
					{
						logDebug2("-------- iCount = %d  ----------",i);
						if(Row = mysql_fetch_row(Res))
						{
							iLegNo = 0;
							fOrderPrice = 0.00;
							iTtlQty = 0 ;
							iChkFlag = 0 ;
							cGTTType = '\0' ;
							iMktSts	= 0;
							flag = '\0';
							cHolidayChk = '\0';
		
							memset(&pEOrdReq , '\0',sizeof(struct ORDER_REQUEST));
							strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
							logDebug2("pEOrdReq.ReqHeader.sExcgId :%s:",pEOrdReq.ReqHeader.sExcgId);
						//	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
							pEOrdReq.ReqHeader.iUserId = strtoull(Row[17],NULL,10);
							pEOrdReq.ReqHeader.cSource= Row[22][0];
							pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
							pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
							strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
							pEOrdReq.ReqHeader.cSegment = Row[25][0];
							strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
							strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
							pEOrdReq.cProductId = Row[23][0]; //PROD_CNC
							pEOrdReq.cBuyOrSell = Row[7][0];
							//pEOrdReq.iOrderType = ORD_TYPE_LIMIT;
							pEOrdReq.iOrderValidity = atof(Row[15]);
							pEOrdReq.iTotalQty = atoi(Row[8]);
							pEOrdReq.iTotalQtyRem = atoi(Row[9]);
							pEOrdReq.iDiscQty = atoi(Row[10]);
							pEOrdReq.iDiscQtyRem = atoi(Row[11]);
							pEOrdReq.iTotalTradedQty = atoi(Row[12]);
							pEOrdReq.fPrice = atof(Row[13]);
							fCmpTriggerPrice = atof(Row[14]);
							/*
							if(pEOrdReq.fPrice == 0)
							{
								pEOrdReq.iOrderType = ORD_TYPE_MKT;
							}
							else
							{
								pEOrdReq.iOrderType = ORD_TYPE_LIMIT;
							}
							pEOrdReq.fTriggerPrice = 0.00;
							*/
							fCmpOrdTriggerPrice = atof(Row[39]);
							if ( pEOrdReq.fPrice == 0.00 &&  fCmpOrdTriggerPrice == 0.00 )
        						{
                						pEOrdReq.iOrderType  = ORD_TYPE_MKT ;
								pEOrdReq.fTriggerPrice = 0.00;
        						}
        						else if ( pEOrdReq.fPrice != 0.00 && fCmpOrdTriggerPrice  == 0.00 )
        						{
                						pEOrdReq.iOrderType = ORD_TYPE_LIMIT ;
								pEOrdReq.fTriggerPrice = 0.00;
        						}
        						else if ( pEOrdReq.fPrice  == 0.00 && fCmpOrdTriggerPrice != 0.00)
        						{
                						pEOrdReq.iOrderType = ORD_TYPE_STOP_LOSS_MKT ;
								pEOrdReq.fTriggerPrice = fCmpOrdTriggerPrice;
        						}
        						else if ( pEOrdReq.fPrice  != 0.00 && fCmpOrdTriggerPrice != 0.00)
        						{
                						pEOrdReq.iOrderType = ORD_TYPE_STOP_LIMIT ;
								pEOrdReq.fTriggerPrice = fCmpOrdTriggerPrice;
        						}
        						else
        						{
                						logDebug2("OrderType Not Found from price and iTriggerPrice ");
        						}

							pEOrdReq.fOrderNum = atof(Row[0]);
							pEOrdReq.iSerialNum = atoi(Row[1])+1;
							pEOrdReq.cHandleInst ='1';
							pEOrdReq.iStratergyId= STRAT_OFF_MKT_ORDS;
							pEOrdReq.cOffMarketFlg = Row[27][0];
							pEOrdReq.cProCli = Row[19][0];
							pEOrdReq.cUserType = Row[20][0];
							strncpy(pEOrdReq.sRemarks ,"GTT ORDER TRIGGERED",REMARKS_LEN);
					

							if(strcmp(Row[3],MKT_TYPE_NL)== 0)
							{
								pEOrdReq.iMktType = NORMAL_MARKET;
							}
							else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
							{
								pEOrdReq.iMktType = ODDLOT_MARKET;
							}
							else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
							{
								pEOrdReq.iMktType = SPOT_MARKET;
							}
							else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
							{
								pEOrdReq.iMktType = AUCTION_MARKET;
							}
							else
							{
								logDebug2(" %s ",Row[3]);
							}
						
							logDebug2("**GTTTTTT***");
							pEOrdReq.cMarkProFlag= Row[31][0];
							pEOrdReq.fMarkProVal= atof(Row[32]);
							pEOrdReq.cParticipantType= Row[29][0];
							strncpy(pEOrdReq.sSettlor,Row[30],SETTLOR_LEN);
							pEOrdReq.cGTCFlag= Row[33][0];
							pEOrdReq.cEncashFlag= Row[34][0];
							strncpy(pEOrdReq.sPanID,Row[28],INT_PAN_LEN);
							iLegNo = atoi(Row[35]);
							cGTTType = Row[36][0];
							strncpy(pEOrdReq.sPlatform,Row[37],PLATFORM_LEN);
                				        strncpy(pEOrdReq.sChannel,Row[38],CHANNEL_LEN);
		
							logDebug3("iLegNo :%d:",iLegNo);
							logDebug3("cGTTType:%c:",cGTTType);
							logDebug2("Writing to Queue for Order Number :%f:",pEOrdReq.fOrderNum);
							logDebug2("pEOrdReq.cOffMarketFlg ;%c:",pEOrdReq.cOffMarketFlg);
							logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
							logDebug2("pEOrdReq.sClientId  :%s:",pEOrdReq.sClientId);
							logDebug2("pEOrdReq.sPlatform:%s:",pEOrdReq.sPlatform);
							logDebug2("pEOrdReq.sChannel:%s:",pEOrdReq.sChannel);

							logDebug3("pEOrdReq.fPrice    :%f:",pEOrdReq.fPrice);
							logDebug3("fCmpTriggerPrice    :%f:",fCmpTriggerPrice);
							logDebug3("fTempLtp 	       :%f:",fTempLtp);
							logDebug3("pEOrdReq.cBuyOrSell :%c:",pEOrdReq.cBuyOrSell);
							logDebug3("fCmpOrdTriggerPrice    :%f:",fCmpOrdTriggerPrice);
							logDebug3("pEOrdReq.iOrderType    :%d:",pEOrdReq.iOrderType);				
				
                                                        cSeg = pEOrdReq.ReqHeader.cSegment;	
							memset(sMkt_Exch,'\0',EXCHANGE_LEN);
							if(strcmp(Row[4],NSE_EXCH)==0)
							{
								Mkt = NSE_EQU;
								strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
							}
							else if (strcmp(Row[4],BSE_EXCH)==0)
							{
								Mkt = BSE_EQU;
								strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
							}
							else if (strcmp(Row[4],MCX_EXCH)==0)
                                                        {
                                                                Mkt = MCX_COM;
                                                                strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
                                                        }
							else{
								logDebug2("Invalid Exch ID. Taking default ID NSE");
								Mkt = NSE_EQU;
								strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
							}
							logDebug2("Mkt type :%d: Group id %d",Mkt , iGrpId);	
							//flag = ReadConnectStatShm( Mkt , iGrpId );
					                //if(flag == EXCHANGE_UP)
							//{
							iMktSts = FALSE;
							iMktSts = fMktStatus( sMkt_Exch, cSeg);
							if(iMktSts != TRUE)
							{
								logDebug3("Market is closed. Retrying .......");
								sleep(WAIT_BEFORE_RETRY);
							}
               						//}
                					//else
							//{
                				//		logFatal("Market is not Connected. Retrying");
						//		iMktSts = FALSE;
                				//		sleep(WAIT_BEFORE_RETRY);
                					//}

							iTradingHolidayFlg = fTradingHoliday(sMkt_Exch);
							
							if(iTradingHolidayFlg == TRUE)
        						{
                						logInfo("Today is holiday for %s Exchange .Unable to Triggered GTT Orders ",sMkt_Exch);
								cHolidayChk = 'Y';
        						}
							else
							{
                						logInfo("Today is Exch Working day for %s Exchange .Triggering GTT Orders ",sMkt_Exch);
								cHolidayChk = 'N';
							}
							logDebug3("cGTTType :%c: flag :%c: iMktSts :%d: cHolidayChk :%c:",cGTTType, flag, iMktSts ,cHolidayChk);
						
							if(cGTTType == GTT_ORDER && iMktSts == TRUE)
                                                        {
                                                                if(fTempLtp <= fCmpTriggerPrice && pEOrdReq.cGTCFlag  == CHECK_LOWER_SIDE)
                                                                {
                                                                        cWriteFlag = 'Y';
                                                                }
                                                                else if(fTempLtp >= fCmpTriggerPrice && pEOrdReq.cGTCFlag == CHECK_UPPLER_SIDE )
                                                                {
                                                                        cWriteFlag = 'Y';
                                                                }
                                                                else
                                                                {
                                                                        logDebug3("GTT ORDERS ARE NOT TO BE EXECUTED");
                                                                        cWriteFlag = 'N';
                                                                }
                                                        }					
		
							
							/***
  							if(cGTTType == GTT_ORDER && iMktSts == TRUE)
							{
								if(fTempLtp <= fCmpTriggerPrice && pEOrdReq.cBuyOrSell == 'B' )
								{
									cWriteFlag = 'Y';
								}
								else if(fTempLtp >= fCmpTriggerPrice && pEOrdReq.cBuyOrSell == 'S' )
								{
									cWriteFlag = 'Y';
								}
								else
								{
									logDebug3("GTT ORDERS ARE NOT TO BE EXECUTED");
									cWriteFlag = 'N';
								}
							}
							****/
							else if(cGTTType == OCO_ORDER && iMktSts == TRUE)
							{
								iChkFlag = fOcoOrderTriggerCheck(pEOrdReq,fTempLtp,&fOrderPrice,&iLegNo,&iTtlQty);
								if(iChkFlag == TRUE)
								{
									logDebug3("iChkFlag Returned as True");
									logDebug3("fOrderPrice :%lf:",fOrderPrice);
									logDebug3("iLegNo:%d:",iLegNo);
									logDebug3("iTtlQty:%d:",iTtlQty);
									pEOrdReq.fPrice = fOrderPrice ;
									pEOrdReq.iTotalQty = iTtlQty ;
									pEOrdReq.iTotalQtyRem = iTtlQty ;		
									if(pEOrdReq.fPrice == 0)
		                                                        {
                	        	                                        pEOrdReq.iOrderType = ORD_TYPE_MKT;
                        	        	                        }
                                                	        	else
	                                                        	{	
	        	                                                        pEOrdReq.iOrderType = ORD_TYPE_LIMIT;
                		                                        }

									cWriteFlag = 'Y';
								}
								else
                                                                {
									logDebug3("iChkFlag Returned as False");
                                                                        logDebug3("OCO ORDERS ARE NOT TO BE EXECUTED");
                                                                        cWriteFlag = 'N';
                                                                }


							}
							else{
								logDebug3("Market is Closed.");
                                                                cWriteFlag = 'N';
							}

							if(cWriteFlag == 'Y' && cHolidayChk == 'N')
							{
								if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
								{
									perror("Error WriteMsgQ");
									mysql_free_result(Res);
									mysql_close(DB_Con);
									exit(ERROR);
								}
								fInsertExecuteOrds(pEOrdReq,iLegNo);
								if(cGTTType == OCO_ORDER)
								{
									logDebug3("It's a OCO Order Type");
									fOcoChkOrdStatus(pEOrdReq);
								}
								else
								{
									logDebug3("It's a GTT Order Type");
								}
							}	
							else
							{
								logDebug3("writeflag is 'N' ");
							}

						}


					}
					mysql_free_result(Res);
				}
				else
				{
					logDebug3("LTP IS NOT IN RANGE");
				}



			}
			freeReplyObject(reply1);
		}
		 mysql_free_result(Res1);

	}
	logTimestamp("EXIT [fBcastUpdt]");
}





OpenMsgQue()
{
	if( ( iAutoSqoffToOrdRtr = OpenMsgQ( (IntSqrOffToMemMap))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug2("write Q = %d",iAutoSqoffToOrdRtr);
	return TRUE;
}

fInsertExecuteOrds(struct  ORDER_REQUEST   pEOrdReq,LONG32 iLegNo1)
{
	logTimestamp("ENTRY [fInsertExecuteOrds]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	DOUBLE64 fTgpr = 0.00;
	CHAR InsQuery[MAX_QUERY_SIZE];
	memset(InsQuery,'\0',MAX_QUERY_SIZE);
	logDebug3("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
	logDebug3("iLegNo1 :%d:",iLegNo1);
	sprintf(InsQuery,"INSERT INTO GTT_ORDERS (GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,\
		GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
			GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
			GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
			GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
			GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
			GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
			GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
			GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
			GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
			GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_REMARKS1,GTT_REMARKS2,GTT_TICK_SIZE,GTT_LOT_SIZE ,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_ORD_TRIGGER_PRICE,GTT_EXPIRY_FLAG)\
		SELECT \
		GTT_ORDER_NO,(GTT_SERIAL_NO + 1),GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
		GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,%d,GTT_ORD_STATUS,NOW(),GTT_TOTAL_QTY,\
		GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,%lf,GTT_VALIDITY,\
		GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
		GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
		GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
		GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
		GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
		GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
		GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_REMARKS1,GTT_REMARKS2,GTT_TICK_SIZE,GTT_LOT_SIZE,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,\
		GTT_ORD_TRIGGER_PRICE,GTT_EXPIRY_FLAG \
		FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f  AND GTT_SERIAL_NO = \
		(SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f  AND GTT_LEG_NO = %d) AND GTT_LEG_NO = %d;",\
		TC_INT_GTT_ORDER_TRIGGERED,fTgpr,pEOrdReq.fOrderNum,pEOrdReq.fOrderNum,iLegNo1,iLegNo1);

	logTimestamp("InsQuery:%s:",InsQuery);

	if(mysql_query(DB_Con,InsQuery) != SUCCESS)
	{
		sql_Error(DB_Con);
		logSqlFatal("Error in SELECT INSERT Query.");
	}
	else
	{
		mysql_commit(DB_Con);
		logDebug2("------SUCCESS IN  SELECT INSERT QUERY-----");
	}
	logTimestamp("ENTRY [fInsertExecuteOrds]");
	return TRUE;

}

fOcoChkOrdStatus(struct  ORDER_REQUEST   pEOrdReq)
{
	logTimestamp("ENTRY [fOcoChkOrdStatus]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 i = 0;
	LONG32  iStatus[3] ;
	DOUBLE64 fTriggerPrice [3];
	DOUBLE64 fPrice [3];
	LONG32  iLegNo[3];
	LONG32  iGttMsgCode [3];

	CHAR	Query[MAX_QUERY_SIZE];
	memset(Query,'\0',MAX_QUERY_SIZE);
	CHAR	InsQuery[MAX_QUERY_SIZE];
	memset(InsQuery,'\0',MAX_QUERY_SIZE);
	logDebug3("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
	sprintf(Query,"SELECT GTT_TRIGGER_PRICE,GTT_ORDER_PRICE,GTT_ORD_STATUS , GTT_BUY_SELL_IND , GTT_LEG_NO,GTT_MSG_CODE FROM GTT_ORDERS A WHERE GTT_ORDER_NO = %lf AND GTT_SERIAL_NO = (SELECT MAX(ORD1.GTT_SERIAL_NO) FROM GTT_ORDERS ORD1 WHERE ORD1.GTT_ORDER_NO = %lf  AND A.GTT_LEG_NO = ORD1.GTT_LEG_NO) order by GTT_LEG_NO asc;",pEOrdReq.fOrderNum,pEOrdReq.fOrderNum);

	logTimestamp("Query [ %s]",Query);
	if (mysql_query(DB_Con, Query) != SUCCESS)
	{
		logSqlFatal(" Error in Select Query EQ_ORDERS in function fCoChckOrderStatus ");
		sql_Error(DB_Con);
		return ERROR ;
	}
	i  =0 ;
	Res = mysql_store_result(DB_Con);
	while((Row = mysql_fetch_row(Res)))
	{
		fTriggerPrice[i] = atof(Row[0]);
		fPrice[i] = atof(Row[1]);
		iStatus[i] = Row[2][0] ;
		iLegNo[i] = atoi(Row[4]);
		iGttMsgCode[i] = atoi(Row[5]) ;
		logDebug2("fTriggerPrice[%d]= [%f]",i,fTriggerPrice[i]);
		logDebug2("fPrice[%d]= [%f]",i,fPrice[i]);
		logDebug2("cStatus[%d] = [%c]",i,iStatus[i]);
		logDebug2("iLegNo[%d] = [%d]",i,iLegNo[i]);
		logDebug2("iGttMsgCode[%d] = [%d]",i,iGttMsgCode[i]);
		i ++ ;
	}
	if(iGttMsgCode[0] == TC_INT_GTT_ORDER_TRIGGERED)
	{
		memset(InsQuery,'\0',MAX_QUERY_SIZE);
		sprintf(InsQuery,"INSERT INTO GTT_ORDERS (GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,\
			GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
				GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
				GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
				GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
				GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
				GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
				GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
				GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
				GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
				GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_REMARKS1,GTT_REMARKS2 ,GTT_TICK_SIZE,GTT_LOT_SIZE ,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG)\
			SELECT \
			GTT_ORDER_NO,(GTT_SERIAL_NO + 1),GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
			GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,%d,\'%c\',NOW(),GTT_TOTAL_QTY,\
			GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
			GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
			GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
			GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
			GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
			GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
			GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
			GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_REMARKS1,GTT_REMARKS2 ,GTT_TICK_SIZE,GTT_LOT_SIZE ,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG \
			FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f  AND GTT_SERIAL_NO = \
			(SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d) AND GTT_LEG_NO = %d;",\
			TC_INT_GTT_ORDER_CANCEL,EXCH_DELETE_STATUS,pEOrdReq.fOrderNum,pEOrdReq.fOrderNum,iLegNo[1],iLegNo[1]);
		logTimestamp("InsQuery:%s:",InsQuery);

		if(mysql_query(DB_Con,InsQuery) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in SELECT INSERT Query.");
		}
		else
		{
			mysql_commit(DB_Con);
			logDebug2("------SUCCESS IN  SELECT INSERT QUERY-----");
		}



	}
	else if(iGttMsgCode[1] == TC_INT_GTT_ORDER_TRIGGERED)
	{
		memset(InsQuery,'\0',MAX_QUERY_SIZE);
		sprintf(InsQuery,"INSERT INTO GTT_ORDERS (GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,\
			GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
				GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
				GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
				GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
				GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
				GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
				GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
				GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
				GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
				GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_REMARKS1,GTT_REMARKS2 ,GTT_TICK_SIZE,GTT_LOT_SIZE ,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG)\
			SELECT \
			GTT_ORDER_NO,(GTT_SERIAL_NO + 1),GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
			GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,%d,\'%c\',NOW(),GTT_TOTAL_QTY,\
			GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
			GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
			GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
			GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
			GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
			GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
			GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
			GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_REMARKS1,GTT_REMARKS2 ,GTT_TICK_SIZE,GTT_LOT_SIZE ,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG\
			FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f  AND GTT_SERIAL_NO = \
			(SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d) AND GTT_LEG_NO = %d;",\
			TC_INT_GTT_ORDER_CANCEL,EXCH_DELETE_STATUS,pEOrdReq.fOrderNum,pEOrdReq.fOrderNum,iLegNo[0],iLegNo[0]);
		logTimestamp("InsQuery:%s:",InsQuery);

		if(mysql_query(DB_Con,InsQuery) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in SELECT INSERT Query.");
		}
		else
		{
			mysql_commit(DB_Con);
			logDebug2("------SUCCESS IN  SELECT INSERT QUERY-----");
		}


	}
	mysql_free_result(Res);
	logTimestamp("ENTRY [fOcoChkOrdStatus]");
	return TRUE;
}

BOOL fOcoOrderTriggerCheck(struct  ORDER_REQUEST   pEOrdReq,DOUBLE64 fTempLtp1,DOUBLE64 *fOrderPrice,LONG32 *iLegNo,LONG32 *iTtlQty)
{
	logTimestamp("ENTRY [fOcoOrderTriggerCheck]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 i = 0;
	LONG32  iStatus[3] ;
	DOUBLE64 fTriggerPrice [3];
	DOUBLE64 fPrice [3];
	LONG32  iLegNoA[3];
	LONG32  iGttMsgCode [3];
	LONG32  iTotalQty[3];
	LONG32  iRemQty[3];
	
	CHAR    Query[MAX_QUERY_SIZE];
	memset(Query,'\0',MAX_QUERY_SIZE);
	//CHAR    InsQuery[MAX_QUERY_SIZE];
	//memset(InsQuery,'\0',MAX_QUERY_SIZE);
	logDebug3("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
	logDebug3("fTempLtp1 :%lf:",fTempLtp1);
	sprintf(Query,"SELECT GTT_TRIGGER_PRICE,GTT_ORDER_PRICE,GTT_ORD_STATUS , GTT_BUY_SELL_IND , GTT_LEG_NO,GTT_MSG_CODE,GTT_TOTAL_QTY,GTT_REM_QTY FROM GTT_ORDERS A WHERE GTT_ORDER_NO = %lf AND GTT_SERIAL_NO = (SELECT MAX(ORD1.GTT_SERIAL_NO) FROM GTT_ORDERS ORD1 WHERE ORD1.GTT_ORDER_NO = %lf  AND A.GTT_LEG_NO = ORD1.GTT_LEG_NO) order by GTT_LEG_NO asc;",pEOrdReq.fOrderNum,pEOrdReq.fOrderNum);

	logTimestamp("Query [ %s]",Query);
	if (mysql_query(DB_Con, Query) != SUCCESS)
	{
		logSqlFatal(" Error in Select Query EQ_ORDERS in function fOcoOrderTriggerCheck");
		sql_Error(DB_Con);
		return ERROR ;
	}
	i  =0 ;
	Res = mysql_store_result(DB_Con);
	while((Row = mysql_fetch_row(Res)))
	{
		fTriggerPrice[i] = atof(Row[0]);
		fPrice[i] = atof(Row[1]);
		iStatus[i] = Row[2][0] ;
		iLegNoA[i] = atoi(Row[4]);
		iGttMsgCode[i] = atoi(Row[5]) ;
		iTotalQty[i] = atoi(Row[6]) ;
		iRemQty[i] = atoi(Row[7]) ;
		logDebug2("fTriggerPrice[%d]= [%f]",i,fTriggerPrice[i]);
		logDebug2("fPrice[%d]= [%f]",i,fPrice[i]);
		logDebug2("cStatus[%d] = [%c]",i,iStatus[i]);
		logDebug2("iLegNoA[%d] = [%d]",i,iLegNoA[i]);
		logDebug2("iGttMsgCode[%d] = [%d]",i,iGttMsgCode[i]);
		logDebug2("iTotalQty[%d] = [%d]",i,iTotalQty[i]);
		logDebug2("iRemQty[%d] = [%d]",i,iRemQty[i]);
		i ++ ;
	}
	
	logDebug3("pEOrdReq.cBuyOrSell :%c:",pEOrdReq.cBuyOrSell);
	if ( pEOrdReq.cBuyOrSell == 'S' )
	{
		if(fTriggerPrice[0] >= fTempLtp1)
        	{
                	logDebug3("OCO TRIGGERED FOR LEG 1");
                	*fOrderPrice = fPrice[0];
                	logDebug3("*fOrderPrice :%lf:",*fOrderPrice);
                	*iTtlQty = iTotalQty[0];
                	logDebug3("*iTtlQty :%d:",*iTtlQty);
                	*iLegNo = 1;
                	logDebug3("iLegNo :%d:",*iLegNo);
                	mysql_free_result(Res);
			logDebug3("Returning True OCO Sell for Leg1 Need to be trigger");
                	return TRUE;
			logDebug3("Returning True OCO Sell for Leg1 Need to be trigger");
        	}
        	else if(fTriggerPrice[1] <= fTempLtp1 )
        	{	
                	logDebug3("OCO TRIGGERED FOR LEG 2");
                	*fOrderPrice = fPrice[1];
                	logDebug3("*fOrderPrice :%lf:",*fOrderPrice);
                	*iTtlQty = iTotalQty[1];
                	logDebug3("*iTtlQty :%d:",*iTtlQty);
                	*iLegNo = 2;
                	logDebug3("iLegNo :%d:",*iLegNo);
                	mysql_free_result(Res);
			logDebug3("Returning True OCO Sell for Leg2 Need to be trigger");
                	return TRUE;
			logDebug3("Returning True OCO Sell for Leg2 Need to be trigger");
        	}
	}
	else if (pEOrdReq.cBuyOrSell == 'B' )
	{
		if(fTriggerPrice[0] <= fTempLtp1)
        	{
                	logDebug3("OCO TRIGGERED FOR LEG 1");
                	*fOrderPrice = fPrice[0];
                	logDebug3("*fOrderPrice :%lf:",*fOrderPrice);
                	*iTtlQty = iTotalQty[0];
                	logDebug3("*iTtlQty :%d:",*iTtlQty);
                	*iLegNo = 1;
                	logDebug3("iLegNo :%d:",*iLegNo);
                	mysql_free_result(Res);
			logDebug3("Returning True OCO Buy for Leg1 Need to be trigger");
			return TRUE;
			logDebug3("Returning True OCO Buy for Leg1 Need to be trigger");
        	}
        	else if(fTriggerPrice[1] >= fTempLtp1 )
        	{
                	logDebug3("OCO TRIGGERED FOR LEG 2");
                	*fOrderPrice = fPrice[1];
                	logDebug3("*fOrderPrice :%lf:",*fOrderPrice);
                	*iTtlQty = iTotalQty[1];
               		logDebug3("*iTtlQty :%d:",*iTtlQty);
                	*iLegNo = 2;
                	logDebug3("iLegNo :%d:",*iLegNo);
                	mysql_free_result(Res);
			logDebug3("Returning True OCO Buy for Leg2 Need to be trigger");
                	return TRUE;
			logDebug3("Returning True OCO Buy for Leg2 Need to be trigger");
        	}
	}
	else
	{
		logDebug3("Entering else case");
		mysql_free_result(Res);
		logDebug3("Returning False");
		return FALSE;
		logDebug3("Returning False");
	}
//this
	//mysql_free_result(Res);
	logTimestamp("EXIT [fOcoOrderTriggerCheck]");

}

BOOL fMktStatus(CHAR *sMktExch,CHAR *cMktSeg)
{
	CHAR	sStatusSel[MAX_QUERY_SIZE];	
	LONG32	iMktStat;
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	memset(sStatusSel,'\0',MAX_QUERY_SIZE);
        sprintf(sStatusSel,"SELECT EMM_STATUS\
        		FROM EXCH_MKT_MASTER\
                        WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\"))  AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG =\'%c\';",sMktExch,cMktSeg);
        if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
        {
        	sql_Error(DB_Con);
                logSqlFatal("Error in Query.. [fCoverSqOffExecute]");
                mysql_close(DB_Con);
                return ERROR;
        }

        Res = mysql_store_result(DB_Con);

	if((Row = mysql_fetch_row(Res)))
	{
        	logDebug2("Row :%s:",Row[0]);
                iMktStat = atoi(Row[0]);
                logDebug1("Value is: %d",iMktStat);
        }

	if(iMktStat == MKT_OPEN || iMktStat == 0)
	{
		mysql_free_result(Res);
		logDebug3("Market is Open");
		return TRUE;
	}
	else{
		mysql_free_result(Res);
		logDebug3("Market is closed");
		return FALSE;
	}

}

BOOL    fTradingHoliday(CHAR *sExchange)
{
        logTimestamp("ENTRY [fTradingHoliday]");

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;



        CHAR    sSelQry [MAX_QUERY_SIZE] ;
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
//        sprintf(sSelQry,"select if(date(HOLIDAY_DATE)=date(NOW()),'Y','N') from TRADING_HOLIDAY WHERE EXCH_ID  = \"%s\" AND date(HOLIDAY_DATE)=date(NOW()) ; ",sExchange);

	sprintf(sSelQry,"select if(COUNT(*) >=1,'Y','N') FROM TRADING_HOLIDAY WHERE EXCH_ID = \"%s\" AND DATE(HOLIDAY_DATE) = DATE(NOW()) ;",sExchange);
        logDebug1("sSelQry :%s:",sSelQry);

        if(mysql_query(DB_Con,sSelQry) != SUCCESS)
        {
                logSqlFatal("Err in select User Code Qyery");
                mysql_close(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);

       //this
       if(Row = mysql_fetch_row(Res))
        {
                mysql_free_result(Res);
                if(Row[0][0] == YES )
                {
                        return TRUE;
                }
                else
                {
                        return FALSE;
                }
        }


        logTimestamp("EXIT [fTradingHoliday]");


}


void    LoadEnv()
{
	logTimestamp("Entry :      [LoadEnv]");
	memset(GttBrdCst_Time,'\0',ENV_VARIABLE_LEN);
	if( getenv("GTTBROADCAST_TIME") ==NULL)
	{
		strcpy( GttBrdCst_Time ,"9:16:00");
		logDebug3("value not defined");
  	}
        else
        {
		strncpy(GttBrdCst_Time,getenv("GTTBROADCAST_TIME"), ENV_VARIABLE_LEN);
		logDebug3("Value is selected from env");
        }

	logDebug2("GttBrdCst_Time is %d",GttBrdCst_Time);
	logTimestamp("Exit :        [LoadEnv]");
}


LONG32  GetJuliDateTime()
{
        struct timeval tm;
        gettimeofday( &tm, NULL );
        return tm.tv_sec;
}
