#include <string.h>
#include <stdlib.h>
#include "IPCS.h"
#include "EQNSEBcastStruct.h"


int main()
{
	LONG32	iSendQ = 0 ,iScript = 0 ;
	DOUBLE64	fLtp = 0.00;

	struct  REDIS_LTP_UPD pRcvLTP;

	if((iSendQ=OpenMsgQ(ENMbpToLTPUpd))==ERROR)
	{
		perror("\n Error in Opening ENMbpToLTPUpd....");
		exit(ERROR);
	}	

	logInfo("Please Enter Token : ")	;
	scanf("%d",&iScript);

	logInfo("Please Enter Price : ")	;
	scanf("%lf",&fLtp);

	pRcvLTP.iToken = iScript;	
	pRcvLTP.fLtp= fLtp;	

	if((WriteMsgQ(iSendQ,(CHAR *)&pRcvLTP, sizeof(struct REDIS_LTP_UPD ), 1)) != TRUE  )
	{
		logFatal("Error : failed while sending to Queue ENMbpToLTPUpd");
		//exit(ERROR);
	}

}



