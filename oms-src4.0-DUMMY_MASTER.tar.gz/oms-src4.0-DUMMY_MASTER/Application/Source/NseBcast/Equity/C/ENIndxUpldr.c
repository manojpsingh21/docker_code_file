#include "IPCS.h"
//#include "Defination.h"
#include "EQNSEBcastStruct.h"
//#include "EquNseDBUpdMulti.h"
#include <my_global.h>
#include <mysql.h>
struct THREAD_PARAMS
{
	MYSQL *DB_Con;
	LONG32 thread_id;
};

INT16 iMbpCount = 0 ;
MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32 rcvQ;
BOOL fBcastUpdt(void *parameter);
BOOL	dTC_MULTIPLE_INDEX_BCAST(CHAR *NNFData,struct THREAD_PARAMS *parameter);
MYSQL *ENMbp_con;

main()
{
	LONG32 	iFlag;
	LONG32 	i;
	LONG32	iNseRecordCount;
	struct THREAD_PARAMS	params[MAX_NO_THREADS];		
	pthread_t thread_id[MAX_NO_THREADS];

	/**MYSQL *ENMbp_con[MAX_NO_OF_THREADS];    *******/




	/*****
	  if(mysql_query(ENMbp_con,"SELECT COUNT(*) FROM NSE_SECURITY_MASTER"))
	  {
	  sql_Error(ENMbp_con);
	  }

	  result = mysql_store_result(ENMbp_con);

	  if(result==NULL)
	  {
	  sql_Error(ENMbp_con);

	  }

	  rowdata = mysql_fetch_row(result);	
	  iNseRecordCount = atoi(rowdata[0]);


	  if(mysql_set_server_option(ENMbp_con,CLIENT_FOUND_ROWS) == 0)
	  {
	  logDebug2(" mysql_set_server_option SUCCESS");
	  }
	  else
	  {
	  logDebug2(" mysql_set_server_option FAILed");
	  return FALSE;
	  }	
	 **/	
	setbuf(stdout,0);
	if((rcvQ=OpenMsgQ(ENBSpltrToIndxUpld))==ERROR)
	{
		perror("\n Error in Opening ENBSpltrToIndxUpld....");
		exit(ERROR);
	}

	logDebug2("Message Queue opened BcasttoMbpMbo : %d:",rcvQ);


	for(i=0;i<MAX_NO_THREADS;i++)
	{
		params[i].thread_id=i;
		params[i].DB_Con = DB_Connect();

		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,(void *)&params[i]))!=0)
			logFatal("Cant create thread %d",i);
		else
			logDebug2("Created");
		//sleep(2);

	}

	for(i=0;i<MAX_NO_THREADS;i++)
	{
		/*Wait for thread to end */
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logFatal("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logFatal("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}
	mysql_free_result(result);

}



BOOL fBcastUpdt(void *parameter)
{
	INT16 	iTransCodeLocal,i;
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];

	struct	NNF_HEADER *pForRectTransCode;
	struct THREAD_PARAMS *l_parameter = parameter;
	LONG32	iCount;
	BOOL	iRetVal = FALSE;

	//	ENMbp_con=DB_Connect();		
	logDebug2("This is core");

	struct	TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] =
	{
		TC_MULTIPLE_INDEX_BCAST		,dTC_MULTIPLE_INDEX_BCAST
	};



	while(TRUE)
	{
		memset(&sRcvMsg, ' ',LOCAL_MAX_PACKET_SIZE);

		if(ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE,1) != TRUE)
		{
			perror("Error Read Q");
			exit(ERROR);
		}


		pForRectTransCode = (struct NNF_HEADER *)sRcvMsg;

		iTransCodeLocal = pForRectTransCode->iMsgCode;
		logDebug2("This is core");
		/******
		  for(iCount=0;iCount < MAX_NO_OF_TRANSCODE_RECV;iCount++)
		  {
		  if(TransFunPair[iCount].Transcode == iTransCodeLocal)
		  {
		  if((iRetVal = (*(TransFunPair[iCount].pToFun))(&sRcvMsg,l_parameter)==TRUE))
		  {
		  mysql_commit(ENMbp_con);

		  }
		  else
		  {
		  logFatal("DATABASE NOT UDPATED...,BroadDataUpd returned FALSE %d",iTransCodeLocal);
		  }
		  break;

		  }

		  }
		 *****/
		if(iTransCodeLocal == TC_MULTIPLE_INDEX_BCAST)
		{
			logDebug2("This is core");
			dTC_MULTIPLE_INDEX_BCAST(&sRcvMsg,l_parameter);			
		}	
		else	
		{
			logInfo("Invalid TransCode :%d:",iTransCodeLocal);
		}

	}	


}


BOOL	dTC_MULTIPLE_INDEX_BCAST(CHAR *NNFData,struct THREAD_PARAMS *parameter)
{
	logTimestamp("ENTRY [dTC_MULTIPLE_INDEX_BCAST]");
	BOOL	iRetVal;
	struct NNF_MULTIPLE_INDEX_BCAST *pPacket = (struct NNF_MULTIPLE_INDEX_BCAST *) NNFData;
	CHAR	sExchId[5];
	strcpy(sExchId,"NSE");
	logDebug2("This is core");

	iRetVal = fUpdateMktmvmtBcast(pPacket,sExchId,parameter);

	logTimestamp ("EXIT [dTC_MULTIPLE_INDEX_BCAST]");
	return iRetVal;

}


BOOL  	fUpdateMktmvmtBcast(struct NNF_MULTIPLE_INDEX_BCAST *pMktMvmt,CHAR *sExchId,struct THREAD_PARAMS *parameter)
{
	INT16 iLoopVar;
	CHAR	sLogTime[DATE_STRING_LENGTH];

	FLOAT32	fIndexVal;
	FLOAT32	fHighIndex;
	FLOAT32	fLowIndex;
	FLOAT32	fOpenIndex;
	FLOAT32	fCloseIndex;
	FLOAT32	fPctcChange;
	FLOAT32	fYearlyHigh;
	FLOAT32	fYearlyLow;
	MYSQL	*EQIndx_Con;
	logDebug2("This is core");

	EQIndx_Con = (MYSQL *)parameter->DB_Con;	

	BOOL	iQryStat;

	INT16	iIndexChange;
	INT16	iIndexChangePos;
	INT16	iIndexChangeNeg;
	INT16	iNoRowAff;

	LONG32	iNoOfUpmoves;
	LONG32	iNoOfDownmoves;

	CHAR	cNetChangeIndictr;

	CHAR	sTempExchId[EXCHANGE_LEN];
	CHAR	sIndexName[INDEX_NAME_LEN];	

	LONG32	iRecCount;
	logDebug2("This is core");
	CHAR	*sUpdInsQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	strcpy(sTempExchId,sExchId);

	convert_seconds_to_date(pMktMvmt->pHeader.iLogTimeStamp,sLogTime);

	iRecCount = pMktMvmt->iNumberOfRecords;

	for(iLoopVar = 0;iLoopVar < pMktMvmt->iNumberOfRecords;iLoopVar++)
	{

		strcpy(sIndexName,pMktMvmt->pIndicesData[iLoopVar].sIndexName);
		fIndexVal= (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iIndexVal / CONST_PRICE_FACTOR;

		fHighIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iHighIndexVal /CONST_PRICE_FACTOR;
		fLowIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iLowIndexVal /CONST_PRICE_FACTOR;
		fOpenIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iOpeningIndex /CONST_PRICE_FACTOR;
		fCloseIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iClosingIndex /CONST_PRICE_FACTOR;
		fPctcChange=(FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iPercentChange /CONST_PRICE_FACTOR;
		fYearlyHigh = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iYearlyHigh /CONST_PRICE_FACTOR;
		fYearlyLow = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iYearlyLow /CONST_PRICE_FACTOR;
		iNoOfUpmoves= pMktMvmt->pIndicesData[iLoopVar].iNoOfUpMoves;
		iNoOfDownmoves= pMktMvmt->pIndicesData[iLoopVar].iNoOfDownMoves;

		cNetChangeIndictr= pMktMvmt->pIndicesData[iLoopVar].cNetChangeIndicator;
		iIndexChange = (int)(fIndexVal-fCloseIndex);

		if(iIndexChange == 0)
		{
			fCloseIndex = 0;
		}

		if(iIndexChange < 0)
		{
			iIndexChangeNeg = abs(iIndexChange);
			iIndexChangePos = NULL;	
		}		
		else
		{
			iIndexChangePos = iIndexChange;
			iIndexChangePos = NULL;
		}

		logDebug2("Record Count :%d:",iRecCount);
		//		printf("\n host_tempNetChangeIndicator :%s: len:%d:",cNetChangeIndictr,strlen());


		sprintf(sUpdInsQ,"INSERT INTO MULTIPLE_INDEX_INQUIRY(\
			MII_INDEX_NAME ,\
			MII_EXCH_ID ,\
			MII_INDEX_VAL ,\
			MII_HIGH_INDEX_VAL,\
			MII_LOW_INDEX_VAL ,\
			MII_OPENING_INDEX ,\
			MII_CLOSING_INDEX ,\
			MII_PCT_CHANGE,\
			MII_YEARLY_HIGH ,\
			MII_YEARLY_LOW,\
			MII_NO_UPS,\
			MII_NO_DOWNS,\
			MII_TIME)\
				VALUES(\"%s\",\"%s\",%f,%f,%f,%f,%f,%f,%f,%f,%i,%i,now()) \
				on duplicate key \
				UPDATE MII_INDEX_VAL = VALUES(MII_INDEX_VAL),\
				MII_HIGH_INDEX_VAL = VALUES(MII_HIGH_INDEX_VAL) ,\
				MII_LOW_INDEX_VAL =  VALUES (MII_LOW_INDEX_VAL) ,\
				MII_OPENING_INDEX =  VALUES (MII_OPENING_INDEX) ,\
				MII_CLOSING_INDEX =  CASE VALUES(MII_CLOSING_INDEX) WHEN 0 THEN MII_CLOSING_INDEX \
				ELSE VALUES(MII_CLOSING_INDEX) END,\
				MII_PCT_CHANGE = VALUES(MII_PCT_CHANGE),\
				MII_YEARLY_HIGH =VALUES(MII_YEARLY_HIGH),\
				MII_YEARLY_LOW = VALUES(MII_YEARLY_LOW),\
				MII_NO_UPS = VALUES(MII_NO_UPS),\
				MII_NO_DOWNS = VALUES(MII_NO_DOWNS),\
				MII_TIME = VALUES(MII_TIME);	"\
				,sIndexName,sTempExchId,fIndexVal,fHighIndex,fLowIndex,fOpenIndex,fCloseIndex,\
				fPctcChange,fYearlyHigh,fYearlyLow,iIndexChangePos,iIndexChangeNeg);

		logDebug2("sUpdInsQ :%s:",sUpdInsQ);
		iQryStat = mysql_query(EQIndx_Con,sUpdInsQ);
		iNoRowAff = mysql_affected_rows(EQIndx_Con);

		logDebug3("iNoRowAff :%d:",iNoRowAff);

		if(iQryStat != SUCCESS )
		{
			sql_Error(EQIndx_Con);
		}
		else 
		{
			mysql_commit(EQIndx_Con);
		}	

	}	


	return TRUE;
}



