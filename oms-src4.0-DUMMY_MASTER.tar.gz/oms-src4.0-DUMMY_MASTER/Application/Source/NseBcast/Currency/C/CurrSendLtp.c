#include <string.h>
#include <stdlib.h>
#include "IPCS.h"
#include "CurrNseStruct.h"


int main()
{
	LONG32	iSendQ = 0 ,iScript = 0 ;
	DOUBLE64	fLtp = 0.00;

	struct  CD_REDIS_LTP_UPD pRcvLTP;

	if((iSendQ=OpenMsgQ(CNMbpToLtpUdr))==ERROR)
	{
		perror("\n Error in Opening DNMbpToLtpUdr....");
		exit(ERROR);
	}	

	logInfo("Please Enter Token : ")	;
	scanf("%d",&iScript);

	logInfo("Please Enter Price : ")	;
	scanf("%lf",&fLtp);

	pRcvLTP.iToken = iScript;	
	pRcvLTP.fLtp= fLtp;	

	if((WriteMsgQ(iSendQ,(CHAR *)&pRcvLTP, sizeof(struct CD_REDIS_LTP_UPD), 1)) != TRUE  )
	{
		logFatal("Error : failed while sending to Queue DNMbpToLtpUdr");
		//exit(ERROR);
	}

}



