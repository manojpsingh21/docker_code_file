#include <stdlib.h> 
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "CurrNseStruct.h" 


LONG32 iStartupTime;
struct THREAD_PARAMS 
{
	MYSQL *DB_Con;	 
	LONG32 thread_id; 
}; 

BOOL  BroadDataUpdate(); 
/* function to check Message queue status*/
int GetQStatus( int MsgQuery);
LONG32 rcvQ; 

MYSQL   *DNMbp_con; 
MYSQL_RES *result;
MYSQL_ROW rowdata;
INT16  iMbpCount = 0;
LONG32	iSendQ;

main(int argc,char *argv[]) 
{
	logTimestamp("ENTRY [Main]"); 
	LONG32 flag; 
	LONG32 i; 
	CHAR    cMaxNoThread;
	LONG32  iMaxNoThread;

	logDebug2("argv[1] :%s:",argv[1]);

	cMaxNoThread  = argv[1][0];

	iMaxNoThread = cMaxNoThread - '0';

	logDebug3("iMaxNoThread :%d: cMaxNoThread :%c:",iMaxNoThread,cMaxNoThread);

	struct THREAD_PARAMS params[iMaxNoThread]; 
	pthread_t thread_id[iMaxNoThread]; 

	setbuf(stdout,0); 

	DNMbp_con = DB_Connect();


	if(mysql_autocommit(DNMbp_con,1))
	{
		sql_Error(DNMbp_con);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}
	//Opening and Reading from MemMap Queue @Nitish
	if((rcvQ=OpenMsgQ(CNSptrMemToMbpUpdt)) == ERROR)  
	{ 
		perror("\n Error in opening DRV_NSE_BCAST_QUEUE ...."); 
		exit(ERROR); 
	} 

	if((iSendQ=OpenMsgQ(CNMbpToLtpUdr))==ERROR)
        {
                perror("\n Error in Opening CNMbpToLtpUdr....");
                exit(ERROR);
        }
        logDebug2("Message Queue opened DNMbpToLtpUdr : %d:",CNMbpToLtpUdr);
 

	GetStartupTimeofDay(); 

	for(i=0;i<iMaxNoThread;i++) 
	{
		params[i].thread_id=i;
		params[i].DB_Con = DB_Connect(); 

		if ((pthread_create(&thread_id[i],NULL,BroadDataUpdate,(void *)&params[i]))!=0) 
			logFatal("Cant create thread %d",i); 
		else 
			logDebug2("Created"); 
	} 

	for(i=0;i<iMaxNoThread;i++) 
	{ 

		logDebug2("Thread %d ....",i); 

		if (pthread_join(thread_id[i],NULL)) 
			logFatal("Error when waiting for thread % to terminate", i); 
		else 
			logDebug2("Stopped"); 

		logDebug2("Detach thread..."); 

		if (pthread_detach(&thread_id[i])) 
			logFatal("Error detaching thread!"); 
		else 
			logDebug2("Detached!"); 

		logDebug2("Stop Session %d....",i); 


		logDebug2("Logged Off"); 
	} 

	logTimestamp("EXIT [MAin]");
}  


BOOL   BroadDataUpdate(void *parameter) 
{ 
	INT16   TranscodeLocal,i; 
	CHAR   RcvMsg[LOCAL_MAX_PACKET_SIZE];  

	struct NNF_HEADER *pForRecTransCode; 
	LONG32 count; 
	BOOL ReturnValue;
	struct THREAD_PARAMS *l_parameter = parameter; 

	logDebug2("ALOKK U R HERE "); 
	while(TRUE) 
	{ 
		logDebug2("ALOKK U R HERE "); 
		memset(&RcvMsg,SPACE,LOCAL_MAX_PACKET_SIZE); 
		logDebug2("w8ing on read Q :%d:",rcvQ);
		if((ReadMsgQ(rcvQ,&RcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE) 
		{ 
			perror("Error Read Q "); 
			logDebug2("id %d",rcvQ); 
			exit(ERROR); 
		} 
		logDebug2(" DATA Received on queue %d",rcvQ);

		pForRecTransCode  = (struct NNF_HEADER *) RcvMsg; 
		TranscodeLocal = pForRecTransCode->iMsgCode; 
		logDebug2(" TranscodeLocal Received on queue %d",TranscodeLocal);

		if (TranscodeLocal == TC_TICKER_INDEX_BCAST)
		{
			fTC_TICKER_INDEX_BCAST(RcvMsg);
		}
		else if (TranscodeLocal== TC_STOCK_DETAILS_CHANGE_BCAST)
		{
			logDebug2("Broadcast for CktLmt");
		//	fTC_STOCK_DETAILS_CHANGE_BCAST(RcvMsg);
		}
		else if (TranscodeLocal == TC_BCAST_SPREAD_MBP)
		{
			logDebug2("pForRecTransCode->iMsgLength :%d:",pForRecTransCode->iMsgLength);
			fTC_SPRD_MBP_BCAST(&RcvMsg);
		}
		else if (TranscodeLocal == TC_MBP_BCAST)
		{
			fTC_MBP_BCAST(RcvMsg);
		}
		else
		{
			logDebug2("Printing in ELSE");
		}
	} 
} 

BOOL GetStartupTimeofDay()
{
	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
	gettimeofday(&StartPoint1, &tzp);

	iStartupTime = StartPoint1.tv_sec - OFFSET;
	logDebug2("Time of entry is :%d: iStartupTime:%d:",StartPoint1.tv_sec,iStartupTime);

}


BOOL fTC_TICKER_INDEX_BCAST(char *NNFData)
{
	logTimestamp("ENTRY [tTC_TICKER_INDEX_BCAST]");

	logDebug2("7202");
	LONG32     iRecordNumber = 0;
	LONG32	   TempMktType;
	struct NNF_TICKER_TRADE_BCAST         *pTickerData;
	pTickerData = ( struct NNF_TICKER_TRADE_BCAST *) NNFData;

	CHAR    supdate[MAX_QUERY_SIZE]; // malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR 	sInsertQry[MAX_QUERY_SIZE]; // malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32	TempScripCode;
	DOUBLE64 TempLtp;
	DOUBLE64 TempDayHiOpenInt;
	DOUBLE64 TempDayLowOpenInt;
	CHAR TempMkt [MARKET_LEN];
	memset(TempMkt,'\0',MARKET_LEN);


	logDebug2("pTickerData->iNoOfRecords :%d",pTickerData->iNoOfRecords);
	logDebug2(" 1 iMbpCount :%d:",iMbpCount);
	if (iMbpCount == 0 )//Add to open market if market is closed .@Abhishek@21Aug2019 
        {
                logDebug2("\n Going to open Market");
                if(fCheckAndOpenCurNseMarket() == TRUE)
                {
                        iMbpCount = 1 ;
                        logDebug2("\n Curr Mkt Successfully Opened : iMbpCount [%d] ",iMbpCount);

                }
		else
                {
                        logDebug2("Error while Opening Drv Mkt  :");
                }
        }
	for(iRecordNumber = 0;iRecordNumber < pTickerData->iNoOfRecords; iRecordNumber++)
	{
		memset(&supdate,'\0',MAX_QUERY_SIZE);
		memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
		TempScripCode = pTickerData->TickerIndexInfo[iRecordNumber].iToken;
		TempLtp = ((DOUBLE64)pTickerData->TickerIndexInfo[iRecordNumber].iTradePrice)/CURR_CONST_PRICE_FACTOR;
		TempDayHiOpenInt =((DOUBLE64) pTickerData->TickerIndexInfo[iRecordNumber].iDayHiOpenInt)/CURR_CONST_PRICE_FACTOR;
		TempDayLowOpenInt = ((DOUBLE64) pTickerData->TickerIndexInfo[iRecordNumber].iDayLowOpenInt)/CURR_CONST_PRICE_FACTOR;
		logDebug2("token [%d]: LTP[%lf]: DayHiOpenInt[%lf]: DayLowOpenInt[%lf]",TempScripCode,TempLtp,TempDayHiOpenInt,TempDayLowOpenInt);

/**		if( fAddLtpToHash(TempScripCode,TempLtp,TempDayHiOpenInt,TempDayLowOpenInt )== TRUE)
		{	
**/
			TempMktType =	pTickerData->TickerIndexInfo[iRecordNumber].iMarketType ;

			switch (TempMktType)
			{
				case NORMAL_MARKET :
					strncpy(TempMkt,MKT_TYPE_NL,MARKET_LEN);
					break;
				case ODDLOT_MARKET :
					strncpy(TempMkt,MKT_TYPE_OL,MARKET_LEN);
					break;
				case SPOT_MARKET :
					strncpy(TempMkt,MKT_TYPE_SP,MARKET_LEN);
					break;
				case AUCTION_MARKET :
					strncpy(TempMkt,MKT_TYPE_AU,MARKET_LEN);
					break;
				case CALL_AUCTION_MARKET1:
					strncpy(TempMkt,MKT_TYPE_CAU_1,MARKET_LEN);
					break;
				case CALL_AUCTION_MARKET2 :
					strncpy(TempMkt,MKT_TYPE_CAU_2,MARKET_LEN);
					break;

				default :
					logDebug2("MktType Incorrect");
			}
			logDebug2("MKT Type [%s]",TempMkt);
			/*For indexing purpose we are doing \'%d\' instead of %d*/	
			if (TempMktType == NORMAL_MARKET)
			{
				TempDayHiOpenInt = 1.00;
				sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
						(DL1_EXCHANGE ,\
					 	DL1_SEGMENT,\
					 	DL1_SCRIP_CODE,\
					 	DL1_EXCH_SCRIP_CODE,\
					 	DL1_MARKET_TYPE,\
					 	DL1_ENTRY_TIME,\
					 	DL1_LTP,\
					 	DL1_OI_HIGH ,\
					 	DL1_OI_LOW)\
						VALUES(\"%s\",\'%c\',\'%d\',%d,\"%s\",NOW(),%lf,%lf,%lf)\
						on duplicate key \
						UPDATE \
						DL1_EXCHANGE = VALUES(DL1_EXCHANGE) ,\
						DL1_SEGMENT = VALUES(DL1_SEGMENT),\
						DL1_SCRIP_CODE = VALUES(DL1_SCRIP_CODE),\
						DL1_EXCH_SCRIP_CODE = VALUES(DL1_EXCH_SCRIP_CODE),\
						DL1_MARKET_TYPE = VALUES(DL1_MARKET_TYPE),\
						DL1_ENTRY_TIME = VALUES(DL1_ENTRY_TIME),\
						DL1_LTP = VALUES(DL1_LTP),\
						DL1_OI_HIGH = VALUES(DL1_OI_HIGH),\			
						DL1_OI_LOW  = VALUES(DL1_OI_LOW);",NSE_EXCH,SEGMENT_CURRENCY,TempScripCode,TempScripCode,TempMkt,TempLtp,TempDayHiOpenInt,TempDayLowOpenInt);

				logDebug2("Insert Query[%s]",sInsertQry);
				if(mysql_query(DNMbp_con,sInsertQry) != SUCCESS)
				{
					logSqlFatal(" In Function [fTC_TICKER_INDEX_BCAST]-->ERROR Inserting In table DRV_L1_WATCH");
					sql_Error(DNMbp_con);
				}

				else
				{
					mysql_commit(DNMbp_con);
					logDebug2("------SUCCESS IN INSERT QUERY-----");
				}


				sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f WHERE L1_EXCHANGE =\'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \'%d\' ;",TempLtp,NSE_EXCH,SEGMENT_CURRENCY,TempScripCode);

				logDebug2("Query[%s]",supdate);

				if(mysql_query(DNMbp_con,supdate) != SUCCESS)
				{
					logSqlFatal("In Function [fTC_TICKER_INDEX_BCAST]-->ERROR In Updating L1_WATCH_ACTIVE");
					sql_Error(DNMbp_con);
				}
				else
				{
					mysql_commit(DNMbp_con);
					logDebug2("------SUCCESS IN LTP UPDATE-----");
				
				}
				fSendLTPtoRed(TempScripCode,TempLtp);
			}
/**
		}
		else
		{
			logDebug2("Ltp Already Exits");
			logDebug2("Updating Next SecurityId");

		}	
**/
	}

	logDebug2(" 2 iMbpCount :%d:",iMbpCount);

	if (iMbpCount == 0 )
	{
		logDebug2("\n Going to open Market");
		if(fCheckAndOpenCurNseMarket() == TRUE)
		{
			iMbpCount = 1 ;
			logDebug2("\n Curr Mkt Successfully Opened : iMbpCount [%d] ",iMbpCount);

		}

	}


	logTimestamp("EXIT [tTC_TICKER_INDEX_BCAST]");
	return TRUE;
}

BOOL fCheckAndOpenCurNseMarket()
{
	logTimestamp("Entry [fCheckAndOpenCurNseMarket]");

	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;
	INT16   iMktStatus              ;
	CHAR    sUpdQry[MAX_QUERY_SIZE] ;
	CHAR    sSelQry[MAX_QUERY_SIZE] ;
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	memset(sSelQry,'\0',MAX_QUERY_SIZE);


	printf("\n Checking for Market Open .... ");
	printf("\n Mkt Update Issue");

	sprintf(sSelQry,"select EMM_STATUS from EXCH_MKT_MASTER where EMM_EXM_EXCH_ID = \"%s\" AND EMM_MKT_TYPE = \"%s\" AND EMM_EXCH_SEG = \'%c\';",NSE_EXCH,MKT_TYPE_NL,SEGMENT_CURRENCY);

	logDebug2("sSelQry %s",sSelQry);

	if(mysql_query(DNMbp_con,sSelQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN SELECTING In Function fTC_MBP_BCAST ");
		sql_Error(DNMbp_con);
		return FALSE;
	}
	logDebug2("------SUCCESS IN SELECT QUERY-----");
	Res = mysql_store_result(DNMbp_con);
	while((Row = mysql_fetch_row(Res)))
	{
		iMktStatus = atoi(Row[0]);
		logDebug2("iMktStatus = %d",iMktStatus);
	}

	if(iMktStatus != 1)
	{
		iMktStatus = 1;
		logDebug2("iMktStatus = %d",iMktStatus);
		sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d WHERE  EMM_EXM_EXCH_ID  = \"%s\" AND EMM_MKT_TYPE = \"%s\"\
				AND EMM_EXCH_SEG = \'%c\';",iMktStatus,NSE_EXCH,MKT_TYPE_NL,SEGMENT_CURRENCY);

		logDebug2("Update Query[%s]",sUpdQry);
		if(mysql_query(DNMbp_con,sUpdQry) != SUCCESS)
		{
			logSqlFatal("ERROR IN UPDATING In Function fTC_MBP_BCAST ");
			sql_Error(DNMbp_con);
			return FALSE;
		}
		else
		{
			mysql_commit(DNMbp_con);
			logDebug2("------SUCCESS IN UPDATE QUERY-----");
		}
	}
	else
	{
		logDebug2("\n Market is already opened.......");

	}
	logTimestamp("Exit [fCheckAndOpenCurNseMarket]");
	return TRUE ;
}

BOOL fTC_STOCK_DETAILS_CHANGE_BCAST (char *NNFData)
{
	logTimestamp ("ENTRY [tTC_STOCK_DETAILS_CHANGE]");
	logDebug2("7305");
	struct NNF_SECURITY_UPDATE_BCAST *pSecData;
	pSecData = (struct NNF_SECURITY_UPDATE_BCAST *)NNFData;
	CHAR    supdate[MAX_QUERY_SIZE]; // malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	memset(&supdate,'\0',MAX_QUERY_SIZE);

	DOUBLE64        templowpricernge;
	DOUBLE64        temphighpricernge;
	DOUBLE64        tempfreezepercnt;

	tempfreezepercnt =((DOUBLE64)pSecData->iFreezePercent)/CURR_CONST_PRICE_FACTOR;
	templowpricernge =((DOUBLE64)pSecData->iLowPriceRange)/CURR_CONST_PRICE_FACTOR;
	temphighpricernge =((DOUBLE64)pSecData->iHighPriceRange)/CURR_CONST_PRICE_FACTOR;

	logDebug2("pSecData->Token:%d:",pSecData->iToken);
	logDebug2("SecData->sHeader.MsgCode[%d]",pSecData->sHeader.iMsgCode);
	logDebug2("pSecData->HighPriceRange :%.2f:",temphighpricernge);
	logDebug2("pSecData->FreezePercent:%.2f:",tempfreezepercnt);

	logDebug2("Token :%d: High :%.2f: Low :%.2f:",pSecData->iToken,pSecData->iHighPriceRange,pSecData->iLowPriceRange);

	//        sprintf(supdate,"UPDATE SECURITY_MASTER SET SM_UPPER_LIMIT = %.2f , SM_LOWER_LIMIT = %.2f , SM_FREEZE_PERCNT = %.2f WHERE SM_SEGMENT = \'%c\' AND SM_EXCHANGE = \'%s\' AND SM_SCRIP_CODE = %d ;",temphighpricernge,templowpricernge,tempfreezepercnt,SEGMENT_CURRENCY,NSE_EXCH,pSecData->iToken);

	sprintf(supdate,"CALL PR_CKT_LMT_UPDATE(\"%d\",\"%s\",\'%c\',%.2f,%.2f,@ZSTATUS)",\
			pSecData->iToken,NSE_EXCH,SEGMENT_CURRENCY,temphighpricernge,templowpricernge);

	logDebug2("Query[%s]",supdate);

	if(mysql_query(DNMbp_con,supdate) != SUCCESS)
	{
		logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
		sql_Error(DNMbp_con);
	}
	else
	{
		mysql_commit(DNMbp_con);
		logDebug2("------SUCCESS IN CIRCUIT LIMIT-----");
		//        logDebug2("------NO OF ROWS AFFECTED[%d]-----",mysql_affected_rows(DNMbp_con));
	}

	logTimestamp ("EXIT [tTC_STOCK_DETAILS_CHANGE]");
	//free(supdate);
	return TRUE;
}

BOOL fAddLtpToHash (LONG32 iToken , DOUBLE64 fLTP ,DOUBLE64 fDayHigh ,DOUBLE64 fDayLow)
{

	logTimestamp("ENTRY [fAddLtpToHash]");
	struct  LTP_ARRAY      *Hash_ByID = NULL;
	struct LTP_ARRAY *DrvLtpHsh ,*TempLtp ;
	LONG32 i =0;

	DrvLtpHsh = (struct LTP_ARRAY *)malloc(sizeof(struct LTP_ARRAY));
	TempLtp = (struct LTP_ARRAY *)malloc(sizeof(struct LTP_ARRAY));

	HASH_FIND(HashID,Hash_ByID,&iToken,sizeof(iToken),TempLtp);

	if(TempLtp == NULL )
	{
		logDebug2("iToken :%d:",iToken);
		sprintf(DrvLtpHsh->sTokenId,"%d",iToken) ;
		DrvLtpHsh->fLtp     = fLTP;
		DrvLtpHsh->fHighPrice = fDayHigh;
		DrvLtpHsh->fLowPrice = fDayLow ;
		logDebug2("DrvLtpHsh->sTokenId :%s:",DrvLtpHsh->sTokenId);
		HASH_ADD(HashID,Hash_ByID ,sTokenId,strlen(DrvLtpHsh->sTokenId),DrvLtpHsh);
		logDebug2("Success Adding LTP to Hash");
	}
	else
	{

		if (fLTP == TempLtp->fLtp)
		{
			logDebug2("Ltp Already Exit in Hash for SecurityId :%d:",iToken);
			return FALSE;
		}
		else
		{
			DrvLtpHsh->fLtp     = fLTP;
			DrvLtpHsh->fHighPrice = fDayHigh;
			DrvLtpHsh->fLowPrice = fDayLow ;
			sprintf(DrvLtpHsh->sTokenId,"%d",iToken) ;
			HASH_REPLACE(HashID,Hash_ByID,sTokenId,strlen(DrvLtpHsh->sTokenId),TempLtp,DrvLtpHsh);
		}
	}
	logTimestamp("EXIT [fAddLtpToHash]");
	return TRUE;

}

BOOL fTC_MBP_BCAST (char *NNFData)
{
	logTimestamp("ENTRY [7208 fTC_MBP_BCAST]");

	LONG32 iRecordNumber,iTotalRecord;
	NNF_MBP_BCAST  *pMbpBcast = ( NNF_MBP_BCAST *) NNFData;

	CHAR            supdate [MAX_QUERY_SIZE];
	CHAR            sInsertQry [MAX_QUERY_SIZE];
	CHAR            sUpdQry[MAX_QUERY_SIZE];
	memset(&supdate,'\0',MAX_QUERY_SIZE);
	memset(&sInsertQry ,'\0',MAX_QUERY_SIZE);
	memset(&sUpdQry,'\0',MAX_QUERY_SIZE);

	LONG32          iTempScripCode =0 ;
	DOUBLE64        fTempLtp=0.00 , fTotalBuyQty =0.00 , fTotalSellQty  =0.00 ;
	LONG32          iVolTradedToday  =0 ,  iNetPriceChange =0 ,iLastTradedQty  =0 , iLastTradeTime  =0 ,iAvgTradePrice  =0 ,iBookType = 0;
	LONG32           iAuctionNumber  =0 , iAuctionStatus  =0 ,iInitiatorType = 0 ,iTradingStatus = 0 , iTempLtp = 0;
	LONG32          iInitiatorPrice  =0 , iInitiatorQty  =0 ,iAuctionPrice  =0 , iAuctionQty  =0 ,iBbTotalBuyFlg = 0 ,iBbTotalSellFlg  =0 ,iNoRecords = 0 ;
	LONG32          iClosePrice  =0 ,iOpenPrice =0 ,iHighPrice =0 ,iLowPrice =0 ,iQty = 0,iPrice = 0,iBbBuySellFlg = 0 ,iRowsAffcted = 0 , iNoOfOrders = 0;
	CHAR            cNetChangeIndicator = '0';

	logDebug2("pMbpBcast->nNoOfRecords :%d:",pMbpBcast->nNoOfRecords);


	//                TempLtp       = pMbpBcast->MBPInfo[iTotalRecord].iLastTradedPrice ;


	for(iTotalRecord = 0;iTotalRecord <pMbpBcast->nNoOfRecords ; iTotalRecord++)
	{

		iTempScripCode  =       pMbpBcast->MBPInfo[iTotalRecord].iToken ;
		iBookType =     pMbpBcast->MBPInfo[iTotalRecord].iBookType;
		iTradingStatus  =       pMbpBcast->MBPInfo[iTotalRecord].iTradingStatus;
		iVolTradedToday =        pMbpBcast->MBPInfo[iTotalRecord].iVolTradedToday;
		logDebug2("Before  ltp [%lf] ",fTempLtp);
		fTempLtp = ((DOUBLE64)pMbpBcast->MBPInfo[iTotalRecord].iLastTradedPrice)/DRV_CONST_PRICE_FACTOR;
		logDebug2("After ltp [%lf] ",fTempLtp);
		iNetPriceChange =       pMbpBcast->MBPInfo[iTotalRecord].iNetPriceChange ;
		iLastTradedQty =        pMbpBcast->MBPInfo[iTotalRecord].iLastTradeQty;
		iLastTradeTime  =        pMbpBcast->MBPInfo[iTotalRecord].iLastTradeTime;
		iAvgTradePrice  =        pMbpBcast->MBPInfo[iTotalRecord].iAverageTradePrice;
		iAuctionNumber  =       pMbpBcast->MBPInfo[iTotalRecord].iAuctionNumber;
		iAuctionStatus  =       pMbpBcast->MBPInfo[iTotalRecord].iAuctionStatus;
		iInitiatorType  =        pMbpBcast->MBPInfo[iTotalRecord].iInitiatorType;
		iInitiatorPrice =        pMbpBcast->MBPInfo[iTotalRecord].iInitiatorPrice;
		iInitiatorQty   =        pMbpBcast->MBPInfo[iTotalRecord].iInitiatorQty;
		iAuctionPrice   =       pMbpBcast->MBPInfo[iTotalRecord].iAuctionPrice;
		iAuctionQty     =       pMbpBcast->MBPInfo[iTotalRecord].iAuctionQty;
		for(iNoRecords = 0 ; iNoRecords < MBP_NO_OF_RECS ; iNoRecords++)
		{
			iQty =  pMbpBcast->MBPInfo[iTotalRecord].MBPRecords[iTotalRecord].iQty ;
			iPrice =  pMbpBcast->MBPInfo[iTotalRecord].MBPRecords[iTotalRecord].iPrice ;
			iNoOfOrders =    pMbpBcast->MBPInfo[iTotalRecord].MBPRecords[iTotalRecord].iNoOfOrders;
			iBbBuySellFlg =  pMbpBcast->MBPInfo[iTotalRecord].MBPRecords[iTotalRecord].iBbBuySellFlg;
		}
		iBbTotalBuyFlg  =        pMbpBcast->MBPInfo[iTotalRecord].iBbTotalBuyFlg;
		iBbTotalSellFlg =        pMbpBcast->MBPInfo[iTotalRecord].iBbTotalSellFlg;
		fTotalBuyQty    =        pMbpBcast->MBPInfo[iTotalRecord].fTotalBuyQty;
		fTotalSellQty   =        pMbpBcast->MBPInfo[iTotalRecord].fTotalSellQty;

		iClosePrice     =        pMbpBcast->MBPInfo[iTotalRecord].iClosePrice;
		iOpenPrice      =        pMbpBcast->MBPInfo[iTotalRecord].iOpenPrice;
		iHighPrice      =        pMbpBcast->MBPInfo[iTotalRecord].iHighPrice;
		iLowPrice       =        pMbpBcast->MBPInfo[iTotalRecord].iLowPrice;
		sprintf(supdate,"UPDATE EQ_AU_L1_WATCH SET\
				L1_UPDATE_TIME= NOW() ,\
				L1_LTP  = %lf,\
				L1_BOOK_TYPE = %d,\
				L1_TRADING_STATUS = %d,\
				L1_VOL_TRD_TODAY = %d,\
				L1_EXCH_SCRIP_CODE= %d,\
				L1_NET_CHG_IND = \'%c\',\
				L1_NET_PRICE_CHG = %d,\
				L1_LAST_TRD_QTY  = %d,\
				L1_LAST_TRADE_TIME = %d,\
				L1_AVG_TRADE_PRICE =  %d,\
				L1_AUCT_NUM = %d,\
				L1_AUCT_STAT =%d,\
				L1_IND_TYPE =%d,\
				L1_IND_PRICE =%d,\
				L1_IND_QTY =%d,\
				L1_AUCT_PRICE=%d \
				L1_AUCT_QTY =%d,\
				L1_BUY_BCK_TOTAL_BUY_FLG =%d,\
				L1_BUY_BCK_TOTAL_SELL_FLG =%d,\
				L1_TOTAL_BUY_QTY  =%f,\
				L1_TOTAL_SELL_QTY  =%f,\
				L1_CLOSE_PRICE  =%d,\
				L1_OPEN_PRICE  =%d,\
				L1_HIGH_PRICE  =%d,\
				L1_LOW_PRICE   =%d \
				WHERE L1_EXCHANGE =\"%s\" AND L1_SEGMENT =\'%c\' AND L1_EXCH_SCRIP_CODE = \'%d\';",\
				fTempLtp,iBookType,iTradingStatus,iVolTradedToday,iTempScripCode,cNetChangeIndicator,iNetPriceChange,iLastTradedQty,iLastTradeTime,\
				iAvgTradePrice,iAuctionNumber,iAuctionStatus,iInitiatorType,iInitiatorPrice,iInitiatorQty,iAuctionPrice,iAuctionQty,iBbTotalBuyFlg,\
				iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,iClosePrice,iOpenPrice,iHighPrice,iLowPrice,NSE_EXCH,CURRENCY_SEGMENT,iTempScripCode);

		if(mysql_query(DNMbp_con,supdate) != SUCCESS)
		{

			logSqlFatal(" In Function [TC_MBP_BCAST]-->ERROR IN INSERT QUERY->EQ_L1_WATCH  ");
			sql_Error(DNMbp_con);
		}
		else
		{
			logDebug2("Query[%s]",supdate);
			mysql_commit(DNMbp_con);
			if(iRowsAffcted == 0)
			{

				sprintf(sInsertQry,"INSERT INTO  EQ_AU_L1_WATCH SET(L1_LTP,L1_BOOK_TYPE  ,L1_TRADING_STATUS  ,L1_VOL_TRD_TODAY  ,\
					L1_EXCH_SCRIP_CODE ,L1_NET_CHG_IND  ,L1_NET_PRICE_CHG  ,L1_LAST_TRD_QTY   ,L1_LAST_TRADE_TIME  ,\
					L1_AVG_TRADE_PRICE   ,L1_AUCT_NUM  , L1_AUCT_STAT ,L1_IND_TYPE ,L1_IND_PRICE , \
					L1_IND_QTY ,L1_AUCT_PRICE L1_AUCT_QTY ,L1_BUY_BCK_TOTAL_BUY_FLG ,L1_BUY_BCK_TOTAL_SELL_FLG ,\
					L1_TOTAL_BUY_QTY  ,L1_TOTAL_SELL_QTY  ,L1_CLOSE_PRICE  ,L1_OPEN_PRICE  ,L1_HIGH_PRICE  , L1_LOW_PRICE,\
					L1_EXCHANGE ,L1_SEGMENT)\
						VALUES(%d,%d,%d,%d,%d,\'%c\',%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%f,%f,%d,%d,%d,%d,\"%s\",\'%c\')",\
						fTempLtp,iBookType,\
						iTradingStatus,iVolTradedToday,iTempScripCode,cNetChangeIndicator,iNetPriceChange,iLastTradedQty,iLastTradeTime,\
						iAvgTradePrice,iAuctionNumber,iAuctionStatus,iInitiatorType,iInitiatorPrice,iInitiatorQty,iAuctionPrice,\
						iAuctionQty,iBbTotalBuyFlg,iBbTotalSellFlg,fTotalBuyQty,fTotalSellQty,iClosePrice,iOpenPrice,iHighPrice,iLowPrice,\
						NSE_EXCH,CURRENCY_SEGMENT);
				logDebug2("%s",sInsertQry);
				if(mysql_query(DNMbp_con, sInsertQry) != SUCCESS)
				{
					logSqlFatal("###### SQL Failed  ######");
					sql_Error(DNMbp_con);
					return FALSE;
				}
				else
				{
					mysql_commit(DNMbp_con);
					logInfo(" Trade Commit sucessful");

				}

			}
			else
			{
				logDebug2("------SUCCESS UPDATE QUERY-----");
			}
		}

		sprintf(sUpdQry,"UPDATE L1_WATCH_ACTIVE SET L1_LTP = %d WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \'%d\' ;",fTempLtp,NSE_EXCH,CURRENCY_SEGMENT,iTempScripCode);


		if(mysql_query(DNMbp_con,sUpdQry) != SUCCESS)
		{
			logDebug2(" Update Query[%s]",sUpdQry);
			logSqlFatal("In Function [TC_MBP_BCAST]-->ERROR IN LTP UPDATE-->L1_WATCH_ACTIVE");
			sql_Error(DNMbp_con);
		}
		else
		{
			mysql_commit(DNMbp_con);
			logDebug2("------SUCCESS IN LTP UPDATE-----");
		}
	}
	/**
	 ***/

	if (iMbpCount == 0 )
	{
		logDebug2("\n Going to open Market");
		if(fCheckAndOpenCurNseMarket() == TRUE)
		{
			iMbpCount = 1 ;
			logDebug2("\n Drv Mkt Successfully Opened : iMbpCount [%d] ",iMbpCount);

		}
		else
		{
			logDebug2("Error while Opening Drv Mkt  :");
		}
	}

	logTimestamp("EXIT [fTC_MBP_BCAST]");
	return TRUE;
}                                                                     	



BOOL	fTC_SPRD_MBP_BCAST(char *sNNFPkt)
{
	logTimestamp("Entry [fTC_SPRD_MBP_BCAST]");

	struct  NNF_SPRD_MBP    *pMbpBcast ;
	logDebug2("struct  NNF_SPRD_MBP :%d:",sizeof(struct  NNF_SPRD_MBP));
	pMbpBcast = ( struct  NNF_SPRD_MBP *) sNNFPkt;

	CHAR            supdate [MAX_QUERY_SIZE];
	CHAR            sInsertQry [MAX_QUERY_SIZE];
	CHAR            sSecID  [SEC_SPRD_LEN];
	memset(&supdate,'\0',MAX_QUERY_SIZE);
	memset(&sInsertQry ,'\0',MAX_QUERY_SIZE);
	memset(&sSecID,'\0',SEC_SPRD_LEN);

	DOUBLE64        TempLtp;

	logDebug2("pMbpBcast :%d:",pMbpBcast->pHeader.iMsgCode);
	sprintf(sSecID,"%d-%d",pMbpBcast->iToken1,pMbpBcast->iToken2);
	TempLtp  = pMbpBcast->iLastTrdPriceDiff;

	sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
			(DL1_EXCHANGE ,\
			 DL1_SEGMENT,\
			 DL1_SCRIP_CODE,\
			 DL1_EXCH_SCRIP_CODE,\
			 DL1_ENTRY_TIME,\
			 DL1_LTP,\
			 DL1_MARKET_TYPE)\
			VALUES(\"%s\",\'%c\',\"%s\",\"%s\",NOW(),%lf,'NL')\
			on duplicate key \
			UPDATE \
			DL1_EXCHANGE = VALUES(DL1_EXCHANGE) ,\
			DL1_SEGMENT = VALUES(DL1_SEGMENT),\
			DL1_SCRIP_CODE = VALUES(DL1_SCRIP_CODE),\
			DL1_EXCH_SCRIP_CODE = VALUES(DL1_EXCH_SCRIP_CODE),\
			DL1_ENTRY_TIME = VALUES(DL1_ENTRY_TIME),\
			DL1_LTP = VALUES(DL1_LTP);",NSE_EXCH,SEGMENT_CURRENCY,sSecID,sSecID,TempLtp);

	logDebug2("Insert Query[%s]",sInsertQry);
	if(mysql_query(DNMbp_con,sInsertQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN INSERTING[DRV_L1_WATCH]  In Function fTC_MBP_BCAST ");
		sql_Error(DNMbp_con);
	}
	else
	{
		mysql_commit(DNMbp_con);
		logDebug2("------SUCCESS IN INSERT QUERY-----");
	}

	sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f WHERE L1_EXCHANGE =\'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =\"%s\" ;",TempLtp,NSE_EXCH,SEGMENT_CURRENCY,sSecID);

	logDebug2("Query[%s]",supdate);

	if(mysql_query(DNMbp_con,supdate) != SUCCESS)
	{
		logSqlFatal(" In Function [TC_MBP_BCAST]-->ERROR IN INSERT QUERY->DRV_L1_WATCH  ");
		sql_Error(DNMbp_con);
	}
	else
	{
		mysql_commit(DNMbp_con);
	}

	logTimestamp("Exit [fTC_SPRD_MBP_BCAST]");
	return TRUE;
}

BOOL fSendLTPtoRed(LONG32 iToken , DOUBLE64 fLTP)
{

        logTimestamp("ENTRY [fSendLTPtoRed]");
        struct          CD_REDIS_LTP_UPD pRedLTP;
        CHAR    tempflag= FALSE                 ;
        LONG32  counter = 0                     ;
        LONG32  status = TRUE                   ;

	logDebug2("This is 1 ");

        memset(&pRedLTP,'\0',sizeof(struct CD_REDIS_LTP_UPD));
        logDebug2("This is 2 :%d: :%lf:",iToken,fLTP);

        pRedLTP.iToken = iToken;
        logDebug2("This is 3 ");
        pRedLTP.fLtp = fLTP;
        logDebug2("This is 4 ");
        logDebug2("iToken :%d: fLtp :%lf: ",pRedLTP.iToken,pRedLTP.fLtp);
        logDebug2("This is 5 ");
	
	status = GetQStatus (iSendQ);	//quesue status check added if queue is 90% full it stop sending packets @Abhishek-13Jun2019
        if ( status == FALSE)
        {
                tempflag = TRUE;
                counter++;
                logDebug2("QUEUE IS 90% FULL");
        }
        else
        {
	        if((WriteMsgQ(iSendQ,(CHAR *)&pRedLTP, sizeof(struct CD_REDIS_LTP_UPD ), 1)) != TRUE  )
        	{
               		 logFatal("Error : failed while sending to Queue ENMbpToLTPUpd");
               		 //exit(ERROR);
        	}
	}
        logDebug2("This is 1 ");


        logTimestamp("EXIT [fSendLTPtoRed]");

}
//Function for checking queue status @Abhishek-13Jun2019
int GetQStatus( int MsgQuery)
{
        struct msqid_ds sStatQ;
        DOUBLE64        checkbytes = 0.0;

        if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
        {
                checkbytes      =       (sStatQ.msg_qbytes * 0.066);



                if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
                {
                        logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
                        return FALSE ;
                }
                else
                {
                        return TRUE ;
                }
        }
}

