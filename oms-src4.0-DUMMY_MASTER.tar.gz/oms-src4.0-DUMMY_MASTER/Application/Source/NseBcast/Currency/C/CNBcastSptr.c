#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
/*****
#include "Queue.h"
#include "Common.h"
#include "IntTCodes.h"
#include "NseTCodes.h"
 *****/
#include "IPCS.h"
#include "CurrNseStruct.h"


#define LOCAL_MAX_PACKET_SIZE   4096
LONG32	iBcasttoSplitterQ ;
LONG32	iSplittertoMbpQ ;
LONG32	iBcasttoIndex ;
LONG32	iBcasttoMktStatus ;

/******
#pragma pack(2)
struct  NNF_HEADER_Splitter
{
LONG32      Reserved                ;  
LONG32          LogTimeStamp                    ;
CHAR            AlphaSplit [ALPHA_SPLIT_LEN]    ;
INT16           MsgCode                         ;
INT16           ErrorCode                       ;
CHAR            TimeStamp1 [DATE_TIME_LEN]      ;
CHAR            TimeStamp2 [DATE_TIME_LEN]      ;
CHAR            TimeStamp3 [DATE_TIME_LEN]      ;
INT16           MsgLength                       ;
};
#pragma pack()
 *********/
int GetQStatus( int MsgQuery);

main (int argc, char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	OpenMessgQ();
	Splitter();

}/*** End of main***/

BOOL Splitter()
{

	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    SndMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    BasicError[ERROR_MSG_LEN]	;
	struct	NNF_HEADER *pRespHeader		;
	INT16	iMsgCode			;
	INT16	iMsgLengh			;
	CHAR    tempflag= FALSE                 ;
        LONG32  counter = 0                     ;
        LONG32  status = TRUE                   ;



	while ( 1 )
	{
		memset( &sRcvMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &SndMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset (&pRespHeader,'\0',sizeof(struct  NNF_HEADER));
		iMsgCode = 0;


		logDebug2("#########Waiting in while loop to get the data ################# %d",iBcasttoSplitterQ);
        
        // change by @pratik for reading from msgtyp 1
		if((ReadMsgQ( iBcasttoSplitterQ, &sRcvMsg, LOCAL_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			logDebug2("ENBcastSplitteespHeaderead Q :Qid %d", iBcasttoSplitterQ);
			exit(ERROR);
		}

		pRespHeader =(struct NNF_HEADER *) &sRcvMsg ;	


		iMsgCode = pRespHeader->iMsgCode;
		iMsgLengh = pRespHeader->iMsgLength;

		logDebug2("iMsgCode :%d: iMsgLengh :%d:",iMsgCode,iMsgLengh);

		switch (iMsgCode)
		{	
			case TC_TICKER_INDEX_BCAST:
		//	case TC_STOCK_DETAILS_CHANGE_BCAST:
			case TC_BCAST_SPREAD_MBP:			
			case TC_MBP_BCAST :

				logDebug2("iMsgCode2123 :%d:",iMsgCode);
	
				status = GetQStatus (iSplittertoMbpQ);//queue status check ,if queue is 90% it stop sending packets to NseCMMBPUdr @Abhishek-13Jun2019
                                if ( status == FALSE)
                                {
                                        tempflag = TRUE;
                                        counter++;
                                        logDebug2("QUEUE IS 90% FULL");
                                }
                                else
                                {
					if(( WriteMsgQ( iSplittertoMbpQ ,&sRcvMsg,iMsgLengh ,1 ) != TRUE ))
					{
						perror("Error WriteQ: ");
						logDebug2("Write Q id %d", iSplittertoMbpQ);
						exit(ERROR);
					}
				}
				logDebug2("iMsgCode :%d:",iMsgCode);

				break;


				//			case TC_MKT_STATS_RPT_BCAST:
			case TC_GENERAL_MSG_BCAST:
			case TC_MARKET_OPEN_MSG_BCAST:
			case TC_MARKET_CLOSE_MSG_BCAST:
			case TC_MARKET_PREOPEN_MSG_BCAST:
			case TC_MARKET_PREOPEN_END_MSG_BCAST:
			case TC_MARKET_POSTCLOSE_MSG_BCAST:
			case TC_STOCK_STATUS_CHANGE_BCAST:
			case TC_STOCK_STATUS_CHANGE_PREOPEN_BCAST:
			case TC_PARTICIPANT_INFO_RESP:
			case TC_SYSTEM_INFORMATION_BCAST:
			case TC_SECURITY_OPEN_MSG_BCAST:
			case TC_BROKER_TURNOVER_EXCEEDED_BCAST:
			case TC_BROKER_TURNOVER_REACTIVATED_BCAST:
			case TC_INSTRUMENT_UPDATE_BCAST:
			case TC_POST_CLOSING_START_BCAST:
			case TC_POST_CLOSING_END_BCAST:
			case TC_STOCK_DETAILS_CHANGE_BCAST:

				if(( WriteMsgQ( iBcasttoMktStatus ,&sRcvMsg,iMsgLengh ,1 ) != TRUE ))
				{
					perror("Error WriteQ: ");
					printf("Write Q id %d", iSplittertoMbpQ);
					exit(ERROR);
				}

				break;





			default:
				logFatal("Invalid Tcode %d",iMsgCode);
				break;

		}


	}/** End of While**/

}
BOOL OpenMessgQ()
{
	//Opening and Reading from MemMap Queue @Nitish
	//inserted by @pratik for removing MM
	if( ( iBcasttoSplitterQ = OpenMsgQ( (CNBAdapToSpltr))) == ERROR )
	{
		perror("Open EQU_NSE_BCAST_QUEUE :");
		exit( 1 );
	}
	if( ( iSplittertoMbpQ = OpenMsgQ( (CNBSpltrToMbpUpld))) == ERROR )
	{
		perror("Open BcasttoMbpMbo :");
		exit( 1 );
	}
	if( ( iBcasttoMktStatus = OpenMsgQ( (CurSpltrToMktSts))) == ERROR )
	{
		perror("Open iBcasttoIndex :");
		exit( 1 );
	}
	return TRUE;

}/** End of OpenMsgQ**/
//function for checking queue status @abhishek-13Jun2019
int GetQStatus( int MsgQuery)
{
        struct msqid_ds sStatQ;
        DOUBLE64        checkbytes = 0.0;

        if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
        {
                checkbytes      =       (sStatQ.msg_qbytes * 0.066);



                if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
                {
                        logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
                        return FALSE ;
                }
                else
                {
                        return TRUE ;
                }
        }
}

