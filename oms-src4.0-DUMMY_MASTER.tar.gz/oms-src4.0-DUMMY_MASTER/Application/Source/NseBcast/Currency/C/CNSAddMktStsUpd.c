#include "HashTable.h"
#include "IPCS.h"
#include "DrvNseStruct.h"
#include <my_global.h>
#include <mysql.h>
//inserted by @pratik 
#include "hiredis.h"

struct THREAD_PARAMS
{
	MYSQL *DB_Con;
	LONG32 thread_id;
};
INT16 iMbpCount = 0 ;
BOOL  fBcastUpdt(void *parameter);
/* function to check Message queue status*/
MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32  rcvQ;
LONG32  iSendQ;
MYSQL 	*CDMbp_con;


// inserted by @pratik for radis
redisContext *c;
redisReply *reply;
INT16   iTranscodeLocal;
INT16   iExpSec;
INT16	iLevel;


main(int argv,char *argc[])
{
	logTimestamp("ENTRY [Main]");
	LONG32 	iFlag;
	LONG32 	i;
	LONG32	iNseRecordCount;
	CHAR	cMaxNoThread;
	LONG32	iMaxNoThread;


	cMaxNoThread  = argc[1][0];	

	iMaxNoThread = cMaxNoThread - '0';
	iLevel 	= atoi(argc[2]);

	logDebug3("iMaxNoThread :%d: cMaxNoThread :%c:",iMaxNoThread,cMaxNoThread);
	logInfo("iLevel :%d:",iLevel);
	/*	logInfo("argc :%d:",argc);
		if ( argc != 3 )  /*argument validation*/
	/*      {
		logDebug2("Argument Mismstch ");
		logDebug2("USAGE : NseCMSAddMbpUpd 1. No. of Threads 2. level (instances)");
		exit(0);
		}
		*/
	struct THREAD_PARAMS params[iMaxNoThread];


	setbuf(stdout,0);
	pthread_t thread_id[iMaxNoThread];


	CDMbp_con = DB_Connect();
	c = RDConnect();
	// inserted by @pratik for fatching sec value from env 	
	if(getenv("REDIS_KEY_EXP_SEC")== NULL)
	{
		iExpSec = 10;
		logFatal("Error : Environment variables missing : REDIS_KEY_EXP_SEC ");
	}
	else
	{

		iExpSec = atoi(getenv("REDIS_KEY_EXP_SEC"));
	}

	LONG32	iSegment;


	logDebug2("Connecting to database.......");

	if(mysql_autocommit(CDMbp_con,1))
	{
		sql_Error(CDMbp_con);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}
	// Opening and Reading from MemMap Queue @nitish
	// Direct reading from Spltr to mbp for Radis Set & get @pratik
	if((rcvQ=OpenMsgQ(CurSpltrToSAddMktSts))==ERROR)
	{
		perror("\n Error in Opening CurSpltrToSAddMktSts....");
		exit(ERROR);
	}

	logDebug2("Message Queue opened CurSpltrToSAddMktSts: %d:",rcvQ);

	mysql_free_result(result);

	for(i=0;i<iMaxNoThread;i++)
	{
		params[i].thread_id=i;
		params[i].DB_Con = DB_Connect();	

		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,(void *)&params[i]))!=0)
			logDebug2("Cant create thread %d",i);
		else
			logDebug2("Created");

	}

	logDebug2("ALOK HERE 1 ");

	for(i=0;i<iMaxNoThread;i++)
	{
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logDebug2("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logDebug2("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}

	logTimestamp("EXIT [MAin]");
}

BOOL fBcastUpdt(void *parameter)
{
	logTimestamp("ENTRY [fBcastUpdt]");
	INT16	i;
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];
	struct THREAD_PARAMS *l_parameter = parameter;
	struct	NNF_HEADER *pForRecTransCode;
	LONG32	iCount;
	BOOL	iRetVal = FALSE;

	while(TRUE)
	{
		memset(&sRcvMsg,' ',LOCAL_MAX_PACKET_SIZE);


		if((ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		pForRecTransCode = (struct NNF_HEADER *) sRcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgCode;
		logDebug2("iTranscodeLocal[%d]",iTranscodeLocal);
		if(iTranscodeLocal == TC_STOCK_DETAILS_CHANGE_BCAST)
		{
			fTC_STOCK_DETAILS_CHANGE_BCAST(sRcvMsg);	
		}

	}
	logTimestamp("EXIT [fBcastUpdt]");
}



BOOL fTC_STOCK_DETAILS_CHANGE_BCAST(char *NNFData)
{
	logTimestamp("ENTRY [fTC_TICKER_INDEX_BCAST]");
	struct NNF_SECURITY_UPDATE_BCAST *pSecData;
	pSecData = (struct NNF_SECURITY_UPDATE_BCAST *)NNFData;
	DOUBLE64        templowpricernge;
	DOUBLE64        temphighpricernge;
	DOUBLE64        tempfreezepercnt;

	CHAR sCommand[COMMAND_LEN];
	CHAR sRSAdd[MAX_QUERY_SIZE];
	CHAR sKeyValue[RADIS_KEY_LEN];

	tempfreezepercnt =((DOUBLE64)pSecData->iFreezePercent)/CONST_PRICE_FACTOR;
	templowpricernge =((DOUBLE64)pSecData->iLowPriceRange)/CONST_PRICE_FACTOR;
	temphighpricernge =((DOUBLE64)pSecData->iHighPriceRange)/CONST_PRICE_FACTOR;

	logDebug2("pSecData->Token:%d:",pSecData->iToken);
	logDebug2("SecData->sHeader.MsgCode[%d]",pSecData->sHeader.iMsgCode);
	logDebug2("Printf Token :%d: High :%.4f: Low :%.4f:",pSecData->iToken,temphighpricernge,templowpricernge);
	logDebug2("pSecData->FreezePercent[%.2f]",tempfreezepercnt);
	logDebug2("pSecData->sCreditRating [%s]",pSecData->sCreditRating);
	logDebug2("iHighPriceRange :%d: iLowPriceRange :%d:",pSecData->iHighPriceRange,pSecData->iLowPriceRange);


	memset(sKeyValue,'\0',RADIS_KEY_LEN);
	sprintf(sKeyValue,"DPR:%s:%c:%d",NSE_EXCH,CURRENCY_SEGMENT,pSecData->iToken);
	logDebug2("KEY VALUE %s",sKeyValue);

	memset(sCommand,'\0',COMMAND_LEN);
	sprintf(sCommand,"HMSET %s SCRIPT %d EXCH %s SEGMENT %c UPPERCKT %f LOWERCKT %f",sKeyValue,pSecData->iToken,NSE_EXCH,CURRENCY_SEGMENT,temphighpricernge,templowpricernge);
	logDebug2("sCommand -> %s",sCommand);
	reply = redisCommand(c,sCommand);
	freeReplyObject(reply);

	memset(sRSAdd,'\0',COMMAND_LEN);
	sprintf(sRSAdd,"SADD %s:%c:DPR DPR:%s:%c:%d",NSE_EXCH,CURRENCY_SEGMENT,NSE_EXCH,CURRENCY_SEGMENT,pSecData->iToken);

	logDebug2("sRSAdd :%s:",sRSAdd);
	reply = redisCommand(c,sRSAdd);

	if(reply->type == REDIS_REPLY_INTEGER)
	{
		logInfo("Added Success");

	}
	else
	{
		logFatal("Error in adding values to CLIENT HASH. :%s:",reply->str);
	}
	freeReplyObject(reply);


	logTimestamp("EXIT [fTC_TICKER_INDEX_BCAST]");
	return TRUE;
}


