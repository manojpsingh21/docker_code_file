#include <my_global.h>
#include <mysql.h>
#include <stdlib.h>
#include "IPCS.h"
#include "DrvNseStruct.h"

MYSQL *CrMkt_Con;
LONG32          rcvQ;


BOOL BroadDataUpdate   ();
static long iSeqNo = 0;

main()
{
	logTimestamp("ENTRY [Main]");
	LONG32          flag;
	LONG32          i;
	//pthread_t thread_id[MAX_NO_OF_THREADS];
	setbuf(stdout,NULL);
	setbuf(stdin,NULL);
	CrMkt_Con = DB_Connect();
	if((rcvQ=OpenMsgQ(CurSpltrToMktSts)) == ERROR)
	{
		perror("\n Error in opening DRV_NSE_BCAST_QUEUE ....");
		exit(ERROR);
	}
	
	/*
	for(i=0;i<1;i++)
	{
		if ((pthread_create(&thread_id[i],NULL,BroadDataUpdate,NULL))!=0)
			logDebug2("Cant create thread %d",i);
		else
			logDebug2("Created");
	}
	for(i=0;i<1;i++)
	{
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logDebug2("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logDebug2("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}
	**/
	BroadDataUpdate();
	logTimestamp ("EXIT [MAIN]");
}

BOOL   BroadDataUpdate()
{
	INT16           iTranscodeLocal,i;
	CHAR            RcvMsg[LOCAL_MAX_PACKET_SIZE];
	LONG32          count;
	BOOL            ReturnValue;
	struct NNF_BCAST_HEADER *pForRecTransCode;

	struct TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] =
	{

		//        	TC_MKT_STATS_RPT_BCAST,               dTC_MKT_STATS_RPT_BCAST,
		//TC_GENERAL_MSG_BCAST,                 dTC_GENERAL_MSG_BCAST,
		TC_MARKET_OPEN_MSG_BCAST,             dTC_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_CLOSE_MSG_BCAST,            dTC_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_PREOPEN_MSG_BCAST,          dTC_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_PREOPEN_END_MSG_BCAST,      dTC_MARKET_STATUS_CHANGE_BCAST,
		TC_MARKET_POSTCLOSE_MSG_BCAST,        dTC_MARKET_STATUS_CHANGE_BCAST,
		TC_STOCK_STATUS_CHANGE_BCAST,         dTC_STOCK_STATUS_CHANGE_BCAST,
		TC_STOCK_STATUS_CHANGE_PREOPEN_BCAST, dTC_STOCK_STATUS_CHANGE_BCAST,
		TC_PARTICIPANT_INFO_RESP,             dTC_PARTICIPANT_INFO_RESP,
		TC_SYSTEM_INFORMATION_BCAST,          dTC_SYSTEM_INFORMATION_BCAST,
		TC_SECURITY_OPEN_MSG_BCAST,           dTC_SECURITY_OPEN_MSG_BCAST,
		TC_BROKER_TURNOVER_EXCEEDED_BCAST,    dTC_BROKER_TURNOVER_EXCEEDED_BCAST,
		TC_BROKER_TURNOVER_REACTIVATED_BCAST, dTC_BROKER_TURNOVER_EXCEEDED_BCAST,
		TC_INSTRUMENT_UPDATE_BCAST,           dTC_INSTRUMENT_UPDATE_BCAST,
		TC_POST_CLOSING_START_BCAST,          dTC_MARKET_STATUS_CHANGE_BCAST,
		TC_POST_CLOSING_END_BCAST,            dTC_MARKET_STATUS_CHANGE_BCAST ,
		TC_STOCK_DETAILS_CHANGE_BCAST,	      dTC_STOCK_DETAILS_CHANGE_BCAST, 
	};	

	while(TRUE)
	{
		memset(&RcvMsg,' ',LOCAL_MAX_PACKET_SIZE);
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================Waiting on Read Q : %d=================---------",rcvQ);
		if((ReadMsgQ(rcvQ,&RcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			logDebug2("id %d",rcvQ);
			exit(ERROR);
		}
		pForRecTransCode  = (struct NNF_HEADER *) RcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgCode;
		logDebug2(" TranscodeLocal Received on queue %d",iTranscodeLocal);
		for (count=0;count<(MAX_NO_OF_TRANSCODE_RECV);count++)
		{
			if (TransFunPair[count].Transcode == iTranscodeLocal)
			{
				if(ReturnValue = (*(TransFunPair[count].pToFun))(&RcvMsg)==TRUE)
				{
					mysql_commit(CrMkt_Con);

				}
				else
				{
					logDebug2("DATABASE NOT UDPATED...,BroadDataUpd returned FALSE %d",iTranscodeLocal);
				}
				break;
			}
		}
	}
}

BOOL dTC_GENERAL_MSG_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_GENERAL_MSG_BCAST]");
	BOOL  ReturnValue;
	CHAR sCBrokerId [ENV_VARIABLE_LEN];
	NNF_GEN_MESSAGE_BCAST   *pPacket = (struct NNF_GEN_MESSAGE_BCAST *) NNFData;
	ReturnValue = UpdateGenMsgBcast(pPacket,sCBrokerId);
	logTimestamp ("EXIT [dTC_GENERAL_MSG_BCAST]");
	return ReturnValue;
}
BOOL dTC_MARKET_STATUS_CHANGE_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_MARKET_OPEN_MSG_BCAST]");
	BOOL  ReturnValue;
	NNF_MARKET_STATUS_CHANGE_BCAST *pPacket = (struct NNF_MARKET_STATUS_CHANGE_BCAST *) NNFData;
	ReturnValue = UpdateMktOpenSts(pPacket);
	logTimestamp ("EXIT [dTC_MARKET_OPEN_MSG_BCAST]");
	return ReturnValue;
}

BOOL dTC_STOCK_STATUS_CHANGE_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_STOCK_STATUS_CHANGE_BCAST]");
	BOOL  ReturnValue;
	NNF_SECURITY_STATUS_UPDATE_BCAST *pPacket=(struct NNF_SECURITY_STATUS_UPDATE_BCAST *) NNFData;
	CHAR  cpExchId[EXCHANGE_LEN] ;
	logDebug2("Security status Changed Bcast 7320");
	//logDebug2("THREAD ID in dTC_STOCK_STATUS_CHANGE_BCAST is : %d",pthread_self());
	ReturnValue = UpdateSecStatChangeBcast(pPacket);
	logTimestamp("EXIT [dTC_STOCK_STATUS_CHANGE_BCAST]");
	return ReturnValue;
}


BOOL dTC_PARTICIPANT_INFO_RESP(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_PARTICIPANT_INFO_RESP]");
	BOOL  ReturnValue;
	NNF_PARTICIPANT_INFO_RESP *pPacket = (struct NNF_PARTICIPANT_INFO_RESP *) NNFData;
	ReturnValue = UpdateParticipantInfo(pPacket);
	return ReturnValue;
	logTimestamp ("EXIT [dTC_PARTICIPANT_INFO_RESP]");
}

BOOL dTC_SYSTEM_INFORMATION_BCAST(CHAR *NNFData)
{
	logTimestamp ("ENTRY [dTC_SYSTEM_INFORMATION_BCAST]");
	BOOL  ReturnValue;
	NNF_SYSTEM_INFO_BCAST *pPacket = (struct NNF_SYSTEM_INFO_BCAST *) NNFData;
	ReturnValue = UpdateSysInfo(pPacket);
	logTimestamp("EXIT [dTC_SYSTEM_INFORMATION_BCAST]");
	return ReturnValue;
}

BOOL dTC_INSTRUMENT_UPDATE_BCAST( CHAR *NNFData)
{
	logTimestamp("ENTRY [tTC_INSTRUMENT_UPDATE_BCAST]");

	BOOL  ReturnValue;
	CHAR  cpExchId[EXCHANGE_LEN] ;
	NNF_INSTRUMENT_UPDATE_INFO_BCAST *pPacket = (NNF_INSTRUMENT_UPDATE_INFO_BCAST *)NNFData;
	ReturnValue = UpdateInstrument(pPacket);
	logTimestamp("EXIT [tTC_INSTRUMENT_UPDATE_BCAST]");
	return ReturnValue;
}

BOOL dTC_SECURITY_OPEN_MSG_BCAST(CHAR *NNFData)
{
	logTimestamp("ENTRY [dTC_SECURITY_OPEN_MSG_BCAST]");
	BOOL  ReturnValue;
	CHAR  cpExchId[EXCHANGE_LEN] ;
	NNF_SEC_OPEN_BCAST *pPacket = (NNF_SEC_OPEN_BCAST *)NNFData ;
	logDebug2("New Security status Changed Bcast 6013");
	ReturnValue = UpdateSecOpenBcast(pPacket);
	logTimestamp("ENTRY [dTC_SECURITY_OPEN_MSG_BCAST]");
	return ReturnValue;
}

BOOL dTC_BROKER_TURNOVER_EXCEEDED_BCAST(CHAR *NNFData)
{		
	logTimestamp("ENTRY [dTC_BROKER_TURNOVER_EXCEEDED_BCAST]");
	BOOL  ReturnValue;
	CHAR sCBrokerId [ENV_VARIABLE_LEN];
	NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST  *pPacket=(NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST *)NNFData;
	strncpy(sCBrokerId,getenv("NSE_CD_BROKER_ID"),ENV_VARIABLE_LEN);
	ReturnValue = UpdateTrnlmtExecdorReactivte(pPacket,sCBrokerId);
	logTimestamp("EXIT [dTC_BROKER_TURNOVER_EXCEEDED_BCAST]");
	return ReturnValue;
}


BOOL dTC_MKT_STATS_RPT_BCAST(CHAR *NNFData)
{
	logDebug2("1833");
	BOOL ReturnValue = TRUE;
	NNF_MKT_STATS_RPT_DATA_BCAST *pPacket;
	pPacket = (NNF_MKT_STATS_RPT_DATA_BCAST *) NNFData;

	if ( pPacket->iMsgType == 'R' )
	{

		ReturnValue = UpdateBhavCopyReport(pPacket);
	}
	return ReturnValue;
}

BOOL UpdateMktOpenSts(NNF_MARKET_STATUS_CHANGE_BCAST *spMktStsChgInfo)
{
	logTimestamp("Entry : [UpdateMktOpenSts]");
	LONG32  iTransCode ;
	CHAR   tempMktType[MARKET_TYPES+1];
	LONG32    Market=0;
	INT16 		iMktStat = 0;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR         AlphaSplit [ALPHA_SPLIT_LEN] ;
//	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sUpdQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);	
	

	memset(AlphaSplit,SPACE,ALPHA_SPLIT_LEN);
	memcpy(AlphaSplit,spMktStsChgInfo->sBcastHeader.sAlphaSplit,ALPHA_SPLIT_LEN);
	printf (" spMktStsChgInfo->MarketType = %d ", spMktStsChgInfo->iMarketType);
	printf (" spMktStsChgInfo->sBcastHeader.MsgCode = %d ", spMktStsChgInfo->sBcastHeader.iMsgCode);
	Market     = spMktStsChgInfo->iMarketType;
	iTransCode = spMktStsChgInfo->sBcastHeader.iMsgCode;
	if(Market <= 0 )
	{
		Market = 1;
	}

	logDebug2(" OpenMarket Market = [%d]", Market);
	logDebug2(" Transcode received is :%d:",iTransCode);
	printf("\n CHECKING MKTSTATUS DRV UpdateMktOpenSts  Market :%d: spMktStsChgInfo->MarketTyp:%d:",Market,spMktStsChgInfo->iMarketType);
	/**        sprintf(sSelQry,"SELECT MM_TYPE_ID FROM DRV_MAPPING_MASTER \
	  WHERE MM_EXCH_TYPE_ID = %d \
	  AND MM_TYPE_NAME      = \'MKT\' \
	  AND MM_EXCH_ID        = \'NSE\';",Market);
	  logDebug2("sSelQry-> %s",sSelQry);
	  if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	  {
	  sql_Error(CrMkt_Con);
	  }
	  else
	  {
	  Res = mysql_store_result(CrMkt_Con);
	  if(Row = mysql_fetch_row(Res))
	  {
	  strncpy(tempMktType,Row[0],MARKET_TYPES+1);
	  }
	  else
	  {
	  switch (iTransCode)
	  {
	  case 6511 :
	  if (!strncmp(AlphaSplit,"EX",2))
	  {
	  sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
	  SET EMM_DRV_EX_STATUS = \'1\'\
	  WHERE EMM_EXM_EXCH_ID= \'NSE\'\
	  AND EMM_MKT_SEGMENT= \'C\';");
	  logDebug2("sUpdQry-> %s",sUpdQry);
	  if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	  {
	  sql_Error(CrMkt_Con);
	  }
	  if(mysql_commit(CrMkt_Con)!=0)
	  {
	  logFatal("Failed to commit");
	  }
	  else
	  {
	  logDebug2("Committed");
	  }
	  }
	  else if (!strncmp(AlphaSplit,"PL",2))
	  {
	  sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
	  SET EMM_DRV_PL_STATUS = \'1\'\
	  WHERE EMM_EXM_EXCH_ID= \'NSE\'\
	  AND EMM_MKT_SEGMENT= \'C\';");
	  logDebug2("sUpdQry-> %s",sUpdQry);
	  if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	  {
	  sql_Error(CrMkt_Con);
	  }
	  if(mysql_commit(CrMkt_Con)!=0)
	  {
	  logFatal("Failed to commit");
	  }
	  else
	  {
	  logDebug2("Committed");
	  }
	  }
	  else
	  {
	  sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
	  SET EMM_STATUS = \'1\'\
	  WHERE EMM_EXM_EXCH_ID= \'NSE\'\
	  AND EMM_MKT_SEGMENT= \'C\';");
	  logDebug2("sUpdQry-> %s",sUpdQry);
	  if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	  {
	  sql_Error(CrMkt_Con);
}
if(mysql_commit(CrMkt_Con)!=0)
{
	logFatal("Failed to commit");
}
else
{
	logDebug2("Committed");
}

}
break;
case 6521 :
if (!strncmp(AlphaSplit,"EX",2))
{
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
			SET EMM_DRV_EX_STATUS = \'2\'\
			WHERE EMM_EXM_EXCH_ID= \'NSE\'\
			AND EMM_MKT_SEGMENT= \'C\';");
	logDebug2("sUpdQry-> %s",sUpdQry);
	if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	{
		sql_Error(CrMkt_Con);
	}
	if(mysql_commit(CrMkt_Con)!=0)
	{
		logFatal("Failed to commit");
	}
	else
	{
		logDebug2("Committed");
	}
}
else if (!strncmp(AlphaSplit,"PL",2))
{
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
			SET EMM_DRV_PL_STATUS = \'2\'\
			WHERE EMM_EXM_EXCH_ID= \'NSE\'\
			AND EMM_MKT_SEGMENT= \'C\';");
	logDebug2("sUpdQry-> %s",sUpdQry);
	if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	{
		sql_Error(CrMkt_Con);
	}
	if(mysql_commit(CrMkt_Con)!=0)
	{
		logFatal("Failed to commit");
	}
	else
	{
		logDebug2("Committed");
	}
}
else
{
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
			SET EMM_STATUS = \'2\'\
			WHERE EMM_EXM_EXCH_ID= \'NSE\'\
			AND EMM_MKT_SEGMENT= \'C\';");
	logDebug2("sUpdQry-> %s",sUpdQry);
	if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
	{
		sql_Error(CrMkt_Con);
	}
	if(mysql_commit(CrMkt_Con)!=0)
	{
		logFatal("Failed to commit");
	}
	else
	{
		logDebug2("Committed");
	}
}
break;
case 6531 :
sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
		SET EMM_STATUS = \'0\'\
		WHERE EMM_EXM_EXCH_ID= \'NSE\'\
		AND EMM_MKT_SEGMENT= \'C\';");
logDebug2("sUpdQry-> %s",sUpdQry);
if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
{
	sql_Error(CrMkt_Con);
}
if(mysql_commit(CrMkt_Con)!=0)
{
	logFatal("Failed to commit");
}
else
{
	logDebug2("Committed");
}
break;
case 6571 :
sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
		SET EMM_STATUS = \'3\'\
		WHERE EMM_EXM_EXCH_ID= \'NSE\'\
		AND EMM_MKT_SEGMENT= \'C\';");
logDebug2("sUpdQry-> %s",sUpdQry);
if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
{
	sql_Error(CrMkt_Con);
}
if(mysql_commit(CrMkt_Con)!=0)
{
	logFatal("Failed to commit");
}
else
{
	logDebug2("Committed");
}
break;
case 6522 :
sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
		SET EMM_STATUS = \'4\'\
		WHERE EMM_EXM_EXCH_ID= \'NSE\'\
		AND EMM_MKT_SEGMENT= \'C\';");
logDebug2("sUpdQry-> %s",sUpdQry);
if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
{
	sql_Error(CrMkt_Con);
}
if(mysql_commit(CrMkt_Con)!=0)
{
	logFatal("Failed to commit");
}
else
{
	logDebug2("Committed");
}
break;
case 6583 :
sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
		SET EMM_STATUS = \'4\'\
		WHERE EMM_EXM_EXCH_ID= \'NSE\'\
		AND EMM_MKT_SEGMENT= \'C\';");
logDebug2("sUpdQry-> %s",sUpdQry);
if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
{
	sql_Error(CrMkt_Con);
}
if(mysql_commit(CrMkt_Con)!=0)
{
	logFatal("Failed to commit");
}
else
{
	logDebug2("Committed");
}
break;
case 6584:
sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
		SET EMM_STATUS = \'2\'\
		WHERE EMM_EXM_EXCH_ID= \'NSE\'\
		AND EMM_MKT_SEGMENT= \'C\';");
logDebug2("sUpdQry-> %s",sUpdQry);
if(mysql_query(CrMkt_Con,sSelQry) != SUCCESS)
{
	sql_Error(CrMkt_Con);
}
if(mysql_commit(CrMkt_Con)!=0)
{
	logFatal("Failed to commit");
}
else
{
	logDebug2("Committed");
}
break;
default:
logDebug2("Invalid TransCode Received in Session Changed Bcast");
return FALSE;
}
}
}
	**/
	switch (iTransCode)
	{
		case 6511 :
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_MKT_TYPE_NO = %d \
					AND EMM_EXM_EXCH_ID= \'NSE\' \
					AND EMM_EXCH_SEG = \'C\' ;",MKT_OPEN,Market);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6511 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
		
			iMktStat = MKT_OPEN;
			break;
		case 6521:
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_EXM_EXCH_ID= \'NSE\' \
					AND EMM_EXCH_SEG = \'C\' ;",MKT_CLOSE);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6521 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
	
			iMktStat = MKT_CLOSE;
			break;
		case 6531:
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_MKT_TYPE_NO = %d \
					AND EMM_EXM_EXCH_ID= \'NSE\' \
					AND EMM_EXCH_SEG = \'C\' ;",MKT_PREOPEN,Market);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6531 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
			iMktStat = MKT_PREOPEN;
			break;
		case 6571:
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_MKT_TYPE_NO = %d \
					AND EMM_EXM_EXCH_ID= \'NSE\' \
					AND EMM_EXCH_SEG = \'C\' ;",MKT_CLOSE,Market);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6571 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
			iMktStat = MKT_CLOSE;
			break;
		case 6522:
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_MKT_TYPE_NO = %d \
					AND EMM_EXM_EXCH_ID= \'NSE\' \
					AND EMM_EXCH_SEG = \'C\' ;",MKT_OPEN,Market);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6522 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
			iMktStat = MKT_OPEN;
			break;
		case 6583:
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_MKT_TYPE_NO = %d \
					AND EMM_EXM_EXCH_ID= \'NSE\' \
					AND EMM_EXCH_SEG = \'C\' ;",MKT_OPEN,Market);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6583 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
			iMktStat = MKT_OPEN;
		
			break;
		case 6584:
			sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
					SET EMM_STATUS = \'%d\' \
					,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" \
					WHERE EMM_MKT_TYPE_NO = %d \
					AND EMM_EXM_EXCH_ID= \'NSE\'\
					AND EMM_EXCH_SEG = \'C\' ;",MKT_CLOSE,Market);
			logDebug2("sUpdQry-> %s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal(" case 6584 :Error im Updating EXCH_MKT_MASTER in Function UpdateMktOpenSts");
			}
			iMktStat = MKT_CLOSE;	
			
			break;
		default:
			logDebug2("Invalid TransCode Received in Session Changed Bcast");
			return FALSE;
	}
	logDebug2("DataBase Updated Successfully");
	if(mysql_commit(CrMkt_Con)!=0)
		logDebug2("Commit failed");
	else
		logDebug2("Committed");

		fUpdateMktStatus_InRedis(iMktStat, CURRENCY_SEGMENT, NSE_EXCH, Market);	
	return TRUE;
	logTimestamp("Exit : [UpdateMktOpenSts]");
}

BOOL UpdateSecStatChangeBcast( NNF_SECURITY_STATUS_UPDATE_BCAST *spSecstatchngBcast)
{
	logTimestamp("Entry : [UpdateSecStatChangeBcast]");
	INT16   numrec;
	LONG32  iTempToken;
	CHAR    cTempStatus;
	INT16   iTempStat;
	INT16   iMktType;
	INT16   iNoOfRec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
//	CHAR    *sUptSemQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sUptSemQ[MAX_QUERY_SIZE];
	CHAR	sUpdQry[MAX_QUERY_SIZE];
	
	memset(sUptSemQ,'\0',MAX_QUERY_SIZE);
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);

	for (numrec = 0; numrec < spSecstatchngBcast->NoOfRecords;numrec ++)
	{
		iTempToken = spSecstatchngBcast->SecTokenAndEligibility[numrec].iToken;
		for(iMktType = 1; iMktType <= 4;iMktType++)
		{
			iTempStat = spSecstatchngBcast->SecTokenAndEligibility[iNoOfRec].SecEligibilityPerMkt[iMktType].Status ;
			if(iTempStat == 3)
			{
				cTempStatus = SEM_SECURITY_SUSPENDED;
			}
			else
			{
				cTempStatus = SEM_SECURITY_STATUS;
			}
			sprintf(sUpdQry,"UPDATE SECURITY_MASTER \
					SET SM_STATUS = \'%c\', \
					SM_EXCH_STATUS = \'%c\' \
					WHERE SM_SCRIP_CODE= \"%d\" \
					AND   SM_EXCHANGE  = \"%s\" \
					AND   SM_SEGMENT = \'C\' ;",\
					cTempStatus,cTempStatus,iTempToken,CURRENCY_SEGMENT);
			logDebug2("sUpdQry ->%s",sUpdQry);
			if(mysql_query(CrMkt_Con,sUpdQry)!=SUCCESS)
			{
				logSqlFatal("ERROR IN UPDATING SECURITY_MASTER in Function UpdateSecStatChangeBcast");
				sql_Error(CrMkt_Con);
				mysql_rollback(CrMkt_Con);
				return FALSE;
			}
			else
			{
				logDebug2("SUCCESS IN UPDATING SECURITY_MASTER");
				mysql_commit(CrMkt_Con);
			}
			sprintf(sUptSemQ,"UPDATE SEM_ACTIVE \
					SET SM_STATUS = \'%c\',SM_EXCH_STATUS=\'%c\' \
					WHERE   SM_SCRIP_CODE = \"%d\" \
					AND SM_EXCHANGE = \"%s\" \
					AND SM_SEGMENT = \'%c\';",\
					cTempStatus,cTempStatus,iTempToken,NSE_EXCH,CURRENCY_SEGMENT);
			logDebug2("sUptSemQ [%s]",sUptSemQ);
			if (mysql_query(CrMkt_Con,sUptSemQ) != SUCCESS)
			{
				sql_Error(CrMkt_Con);
				logSqlFatal("ERROR IN UPDATING SEM_ACTIVE in Function UpdateSecStatChangeBcast");
				return FALSE;
			}
			else
			{
				logDebug2("SUCCESS IN UPDATING SEM_ACTIVE");
				mysql_commit(CrMkt_Con);
			}

		}

	}

	logTimestamp("Exit : [UpdateSecStatChangeBcast]");
	return TRUE;

}

BOOL UpdateGenMsgBcast( NNF_GEN_MESSAGE_BCAST   *pGenMsg ,  LONG32 *CBrokerId)
{
	logTimestamp("Entry : [UpdateGenMsgBcast]");
	logDebug2("6501 Gnral Msg Bcast");
//	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sInsQry[MAX_QUERY_SIZE];
	memset(sInsQry,'\0',MAX_QUERY_SIZE);

	iSeqNo ++ ;
	logDebug2("iSeqNo :%d: pGenMsg->BrokerNumber[%s]",iSeqNo,pGenMsg->sBrokerNumber);
	logDebug2("pGenMsg->ActionCode [%s]",pGenMsg->sActionCode);
	logDebug2("pGenMsg->BcastMsg    [%s]",pGenMsg->sBcastMsg);

	sprintf(sInsQry,"INSERT INTO EXCH_MESGS \
			(       EXMS_TIME,\
				EXMS_ACTION_CODE,\
				EXMS_GENERAL_MESG,\
				EXMS_EXM_EXCH_ID,\
				EXMS_EXM_SEGMENT,\
				EXMS_MSG_SEQ_NO)\
			VALUES  (\
				NOW(),\
				\"%s\",\
				\"%s\",\
				\"%s\" , \'%c\',%d);",pGenMsg->sActionCode,pGenMsg->sBcastMsg,NSE_EXCH,DERIVATIVE_SEGMENT,iSeqNo);

	logDebug2("sInsQry :%s:",sInsQry);

	if(mysql_query(CrMkt_Con,sInsQry) != SUCCESS)
	{
		sql_Error(CrMkt_Con);
		logSqlFatal("Error in Insert Query [EXCH_MESGS] Function UpdateGenMsgBcast");
	}


	return TRUE;
	logTimestamp("Exit : [UpdateGenMsgBcast]");

}

BOOL UpdateParticipantInfo( NNF_PARTICIPANT_INFO_RESP *spPartInfo)
{
	logTimestamp("Entry : [UpdateParticipantInfo]");
	logDebug2("7306");
	CHAR    tempExchType[EXCHANGE_LEN+1];
	CHAR    cLastUpdateDate[DATE_STRING_LENGTH];
	CHAR    vLastUpdateDate[DATE_STRING_LENGTH];
//	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sUpdQry[MAX_QUERY_SIZE];
	CHAR	sInsQry[MAX_QUERY_SIZE];

	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	memset(sInsQry,'\0',MAX_QUERY_SIZE);

	CHAR    Flag;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	convert_seconds_to_date(spPartInfo->LastUpdateTime, cLastUpdateDate);

	if(spPartInfo->Delete=='Y')
		Flag='Y';
	else
		Flag='N';



	sprintf(sUpdQry,"UPDATE DRV_PARTICIPANT_MASTER \
			SET PM_PARTICIPANT_NAME = \"%s\", \
			PM_STATUS               = \'%c\', \
			PM_DELETE_FLG           = \'%c\', \
			PM_UPDATE_DATETIME      = now()\
			WHERE PM_PARTICIPANT_ID = \"%s\" \
			AND PM_EXM_EXCH_ID      = \"%s\";",spPartInfo->ParticipantName,spPartInfo->ParticipantSts,Flag,spPartInfo->ParticipantId,NSE_EXCH);
	logDebug2("sUpdQry->%s",sUpdQry);
	if(mysql_query(CrMkt_Con,sUpdQry)!= SUCCESS)
	{
		sql_Error(CrMkt_Con);
		logSqlFatal("ERROR IN UPDATING DRV_PARTICIPANT_MASTER  in Function UpdateParticipantInfo");
	}
	if(mysql_affected_rows(CrMkt_Con) == 0)
	{
		sprintf(sInsQry,"INSERT INTO DRV_PARTICIPANT_MASTER (PM_EXM_EXCH_ID,PM_PARTICIPANT_ID,PM_PARTICIPANT_NAME,PM_STATUS,PM_DELETE_FLG,PM_UPDATE_DATETIME,\
			PM_CREATED_BY,PM_CREATED_DATE) VALUES( \"%s\",\"%s\",\"%s\",\'%c\',\'%c\',STR_TO_DATE( \"%s\",'%%d%%m%%Y-%%h:%%i:%%s'),user(),now());" \
				,NSE_EXCH,spPartInfo->ParticipantId,spPartInfo->ParticipantName,spPartInfo->ParticipantSts,Flag,cLastUpdateDate);
		logDebug2("sInsQry->%s",sInsQry);
		if(mysql_query(CrMkt_Con,sInsQry)!= SUCCESS)
		{
			sql_Error(CrMkt_Con);
			logSqlFatal("ERROR IN INSERTING  DRV_PARTICIPANT_MASTER  in Function UpdateParticipantInfo");
			mysql_rollback(CrMkt_Con);
		}
		mysql_commit(CrMkt_Con);

	}
	if(mysql_commit(CrMkt_Con)!=0)
		logFatal("Failed to commit");
	else
		logDebug2("Committed");

	logTimestamp("Exit : [UpdateParticipantInfo]");
	return TRUE;
}

BOOL UpdateSysInfo( NNF_SYSTEM_INFO_BCAST       *spSysInfo)
{
	logTimestamp("Entry : [UpdateSysInfo]");
	logDebug2("7206");
	CHAR    tempExchType[EXCHANGE_LEN+1];
//	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sSelQry[MAX_QUERY_SIZE];
	CHAR	sUpdQry[MAX_QUERY_SIZE];

	memset(sSelQry,'\0',MAX_QUERY_SIZE);
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);

	INT16 iMktType = 0;
        iMktType = NORMAL_MARKET;
	CHAR         tempMktType[5];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	sprintf(sSelQry,"SELECT EMM_MKT_TYPE \
			FROM EXCH_MKT_MASTER \
			WHERE EMM_MKT_TYPE_NO = %d\
			AND EMM_EXCH_SEG = \'%c\' \
			AND EMM_EXM_EXCH_ID = \"%s\";",NORMAL_MARKET,CURRENCY_SEGMENT,NSE_EXCH);
	logDebug2("sSelQry->%s",sSelQry);
	if(mysql_query(CrMkt_Con,sSelQry)!=SUCCESS)
	{
		sql_Error(CrMkt_Con);
		logSqlFatal("ERROR IN SELECTING EMM_MKT_TYPE in Function UpdateSysInfo");
	}
	Res = mysql_store_result(CrMkt_Con);
	Row = mysql_fetch_row(Res);
	strncpy(tempMktType,Row[0],5);
	sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER \
			SET EMM_STATUS     =%d ,\
			WHERE EMM_MKT_TYPE = \"%s\" \
			AND EMM_EXM_EXCH_ID= \"%s\" \
			AND EMM_MKT_SEGMENT= \'%c\';",spSysInfo->MarketStatus.iNormal,tempMktType,NSE_EXCH,CURRENCY_SEGMENT);
	logDebug2("sUpdQry->%s",sUpdQry);
	if(mysql_query(CrMkt_Con,sUpdQry)!=SUCCESS)
	{
		sql_Error(CrMkt_Con);
		logSqlFatal("ERROR IN UPDATING EXCH_MKT_MASTER in Function UpdateSysInfo");
		mysql_rollback(CrMkt_Con);
		return FALSE;
	}
	if(mysql_commit(CrMkt_Con)!=0)
		logFatal("Failed to commit");
	else
	{
		logDebug2("Committed");
		return TRUE;
	}
	
	fUpdateMktStatus_InRedis(spSysInfo->MarketStatus.iNormal, CURRENCY_SEGMENT, NSE_EXCH, iMktType);
	logTimestamp("Exit : [UpdateSysInfo]");
}

BOOL UpdateSecOpenBcast(NNF_SEC_OPEN_BCAST *pSecOpenBcast)
{
	logTimestamp("Entry : [UpdateSecOpenBcast]");
	logDebug2("6013");
	CHAR    tempExchType[EXCHANGE_LEN + 1] ;
	CHAR    tempSecurityId[SECURITY_LEN];
	DOUBLE64 OpenPrice ;
	LONG32  temptoken =0;
	LONG32 MsgCode = 0;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
//	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR    *sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR	sUpdQry[MAX_QUERY_SIZE];
	CHAR	sInsQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	memset(sInsQry,'\0',MAX_QUERY_SIZE);

	OpenPrice = ((DOUBLE64)pSecOpenBcast->iOpeningPrice);
	temptoken = pSecOpenBcast->iToken;
	MsgCode = pSecOpenBcast->sHeader.iMsgCode ;	
	logDebug2("New Security MsgCode [%d}",MsgCode);
	logDebug2("Token[%d]---OpeningPrice[%f]",temptoken,OpenPrice);

	sprintf(sUpdQry,"UPDATE SECURITY_MASTER SET SM_STATUS = \'%c\' , SM_EXCH_STATUS  = \'%c\' WHERE SM_EXCHANGE = \"%s\" AND SM_SEGMENT = \'%c\' AND  SM_SCRIP_CODE = %d AND SM_EXCH_SCRIP_CODE = %d);",SEM_SECURITY_STATUS,SEM_SECURITY_STATUS,NSE_EXCH,CURRENCY_SEGMENT,temptoken,temptoken);

	logDebug2("sUpdQry->%s",sUpdQry);
if(mysql_query(CrMkt_Con,sUpdQry)!=SUCCESS)
{
	sql_Error(CrMkt_Con);
	logSqlFatal("ERROR IN UPDATING SECURITY_MASTER in Function UpdateSecOpenBcast");
	return FALSE;
	logDebug2("ERROR IN UPDATING SECURITY_MASTER");
}
logDebug2("SUCCESS IN UPDATING SECURITY_MASTER");
sprintf(sInsQry,"INSERT INTO DRV_L1_WATCH \
		(DL1_EXCHANGE,\
		 DL1_SEGMENT,\
		 DL1_SCRIP_CODE,\
		 DL1_EXCH_SCRIP_CODE,\
		 DL1_MARKET_TYPE,\
		 DL1_ENTRY_TIME,\
		 DL1_BID_QTY,\
		 DL1_BID_PRICE,\
		 DL1_ASK_QTY,\
		 DL1_ASK_PRICE,\
		 DL1_TRADE_TIME,\
		 DL1_LTP,\
		 DL1_LTQ,\
		 DL1_DAY_VOLUME,\
		 DL1_NET_CHANGE,\
		 DL1_ATP,\
		 DL1_OPEN,\
		 DL1_HIGH,\
		 DL1_LOW,\
		 DL1_CLOSE,\
		 DL1_TOTAL_BID_QTY,\
		 DL1_TOTAL_ASK_QTY,\
		 DL1_OPEN_INTEREST,\
		 DL1_OI_HIGH,\
		 DL1_OI_LOW),\
		 VALUES \
		 (\"%s\", \
		  \'%c\', \
		  %d,\
		  %d,\
		  \"%s\", \
		  now(),\
		  %d,\
		  %f,\
		  %d,\
		  %f,\
		  now(),\
		  round(%f,2),\
		  %f,\
		  %d,\
		  %d,\
		  %f,\
		  %f,\
		  %f,\
		  %f,\
		  %f,\
		  %d,\
		  %d,\
		  %f,\
		  %f,\
		  %f);",NSE_EXCH,CURRENCY_SEGMENT,temptoken,temptoken,MKT_TYPE_NL,0,0.00000,0,0.00000,OpenPrice,0,0,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000,0,0,0.00000,0.00000,0.00000);

logDebug2("sInsQry->%s",sInsQry);
if(mysql_query(CrMkt_Con,sInsQry)!=SUCCESS)
{
	sql_Error(CrMkt_Con);
	mysql_rollback(CrMkt_Con);
	logSqlFatal("ERROR IN INSERTING DRV_L1_WATCH in Function UpdateSecOpenBcast");
	return FALSE;
}

logDebug2("SUCCESS IN INSERTING L1_WATCH");
return TRUE;
logTimestamp("Exit : [UpdateSecOpenBcast]");
}

BOOL UpdateTrnlmtExecdorReactivte(NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST *pTnovrlimit,LONG32 *BrokerId)
{
	logTimestamp("Entry: [UpdateTrnlmtExecdorReactivte]");
	INT16           Flag =0;
	CHAR            tempExchType[EXCHANGE_LEN + 1] ;
	CHAR            tempLogTime[DATE_STRING_LENGTH];
	CHAR            tempSymbol[SYMBOL_LEN+1];
	CHAR            tempSeries[SERIES_LEN+1];
	CHAR            Msg[ADMIN_MSG_LEN];
	CHAR            tempBrokerCode[BROKER_CODE_LEN];
	FILE            *fp_deact;
	LONG32          Counter;
	DOUBLE64        TradePrice  ;
	CHAR            BrokerCode[BROKER_CODE_LEN];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
//	CHAR    *SelQry=malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	/*
	   sprintf(SelQry,"SELECT TRIM(EAM_BROKER_ID)      FROM EXCH_ADMINISTRATION_MASTER \
	   WHERE EAM_EXM_EXCH_ID  = ltrim(rtrim(\"%s\")\
	   AND EAM_DRV_FLAG ='C';",cpExchId);
	   logDebug2("SelQry->%s",SelQry);
	   if(mysql_query(CrMkt_Con,SelQry) != SUCCESS)
	   {
	   sql_Error(CrMkt_Con);
	   return FALSE;
	   }
	   Res = mysql_store_result(CrMkt_Con);
	   Row = mysql_fetch_row(Res);
	   strncpy(BrokerCode,Row[0],BROKER_CODE_LEN);
	 */
	logDebug2("Broker Code From Exch is %s ",pTnovrlimit->BrokerCode);
	logDebug2("Broker Code From Enviornment Variable  is %s ",BrokerId);
	if(strncmp(BrokerId,pTnovrlimit->BrokerCode,BROKER_CODE_LEN)==0 || CheckSpaces(pTnovrlimit->BrokerCode, BROKER_CODE_LEN))
	{
		convert_seconds_to_date(pTnovrlimit->sHeader.iLogTimeStamp,tempLogTime);
		logDebug2("UpdateTrnlmtExecdorReactivte ");
		TradePrice = ((DOUBLE64)pTnovrlimit->TradePrice)/DRV_CONST_PRICE_FACTOR;
		if(pTnovrlimit->sHeader.iMsgCode == TC_BROKER_TURNOVER_EXCEEDED_BCAST )
		{
			if(pTnovrlimit->WarningType ==1)
			{
				sprintf(Msg,"Derivative: Broker is  about to Exceed Turnoverlimit in NSE .Details of Lasttrade: BrokerId : %d SecId : \"%s\"\"%s\"\
						Qty : %d Price :%.2lf TradeNo : %d Time : %s",pTnovrlimit->BrokerCode,pTnovrlimit->Symbol,pTnovrlimit->Series,\
						pTnovrlimit->TradeVol,TradePrice,pTnovrlimit->TradeNum,tempLogTime);

			}
			if(pTnovrlimit->WarningType ==2)
			{
				sprintf(Msg,"Derivative: Broker  Exceeded Turnoverlimit in NSE.Details of Lasttrade: BrokerId : %d Series : \"%s\" Symbol : \"%s\"\
						Qty : %d Price: %.2lf TradeNo : %d Time : \"%s\"",pTnovrlimit->BrokerCode,pTnovrlimit->Symbol,pTnovrlimit->Series,\
						pTnovrlimit->TradeVol,TradePrice,pTnovrlimit->TradeNum,tempLogTime);
			}
			fprintf(fp_deact , "\nTHIS IS THE TRANSACTION DETAILS JUST BEFORE DEACTIVATION" );
			fprintf(fp_deact , "\n---------------------------------------------------------");
			fprintf(fp_deact , "\n Time        is: %.20s",tempLogTime);
			fprintf(fp_deact , "\n Broker Code is: %.5s",pTnovrlimit->BrokerCode);
			fprintf(fp_deact , "\n Symbol      is: %.10s",pTnovrlimit->Symbol);
			fprintf(fp_deact , "\n Series      is: %.2s ",pTnovrlimit->Series);
			fprintf(fp_deact , "\n TradePrice  is: %.2lf ",TradePrice);
			fprintf(fp_deact , "\n TradeVolume is: %d ",pTnovrlimit->TradeVol);
			fprintf(fp_deact , "\n TradeNumber is: %d ",pTnovrlimit->TradeNum);
			fflush(fp_deact);
			fclose(fp_deact);
		}
		else if(pTnovrlimit->sHeader.iMsgCode ==TC_BROKER_TURNOVER_REACTIVATED_BCAST)
		{
			logDebug2("Message is ===Derivative: Broker is Reactivated in NSE===");
		}
	}
	return TRUE;
	logTimestamp("Exit: [UpdateTrnlmtExecdorReactivte]");
}

BOOL UpdateBhavCopyReport(NNF_MKT_STATS_RPT_DATA_BCAST   *spMktStatus)
{
	logTimestamp("Entry : [UpdateBhavCopyReport]");
	logDebug2("1833");
	INT16   LoopVar;
	CHAR    tempLogTime[DATE_STRING_LENGTH];
	CHAR    tempSecurityId[SECURITY_LEN];
	DOUBLE64 tempStrikePrice;
	DOUBLE64  TempPcPrice;
	DOUBLE64  TempClPrice;
	DOUBLE64  TempOpPrice;
	DOUBLE64  TempHiPrice;
	DOUBLE64  TempLoPrice;
	DOUBLE64 tempTotalValueTraded;
	DOUBLE64 tempOpnIntrst;
	DOUBLE64  tempChgOpnIntrst;
	CHAR tempSymbol [SYMBOL_LEN];
	CHAR tempinstruname [INSTR_NAME_LEN];
	CHAR tempoptiontype [OPT_TYPE_LEN];
	CHAR    NormlMkt[MKT_TYPE_LEN];
	memset(NormlMkt,'\0',MKT_TYPE_LEN);
	memset(tempSymbol,'\0',SYMBOL_LEN);
	memset(tempinstruname,'\0',INSTR_NAME_LEN);	
	memset(tempoptiontype,'\0',OPT_TYPE_LEN);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
//	CHAR     *SelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR     *InsrtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	SelQry[MAX_QUERY_SIZE];
	CHAR	InsrtQry[MAX_QUERY_SIZE];
	memset(SelQry,'\0',MAX_QUERY_SIZE);
	memset(InsrtQry,'\0',MAX_QUERY_SIZE);

	LONG32          TempMktType;
	DOUBLE64        TotalQtyTraded;
	CHAR		Option [OPTION_SIZE];
	memset (Option,'\0',OPTION_SIZE);

	logDebug2("1833 Bhavcopy Mkt Status Rpt  MsgCode[%d]",spMktStatus->sHeader.iMsgCode);
	if (spMktStatus->iMsgType == 'R');
	{
		logDebug2("spMktStatus->MsgType [%c]",spMktStatus->iMsgType);

		for (LoopVar=0; LoopVar < (spMktStatus->iNumberOfRecords );LoopVar++)
		{
			strncpy(tempSymbol,(spMktStatus->MktStatsData[LoopVar].SecInfo).sSymbol,SYMBOL_LEN);
			strncpy(tempinstruname,(spMktStatus->MktStatsData[LoopVar].SecInfo).sInstrumentName,INSTR_NAME_LEN);
			strncpy(tempoptiontype,(spMktStatus->MktStatsData[LoopVar].SecInfo).sOptionType,OPT_TYPE_LEN);
			tempStrikePrice = ((DOUBLE64)(spMktStatus->MktStatsData[LoopVar].SecInfo).iStrikePrice)/DRV_CONST_PRICE_FACTOR;  
			TempPcPrice     = ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iPreviousClosePrice)/DRV_CONST_PRICE_FACTOR;             
			TempClPrice 	= ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iClosingPrice)/DRV_CONST_PRICE_FACTOR;     
			TempOpPrice 	= ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iOpenPrice)/DRV_CONST_PRICE_FACTOR;        
			TempHiPrice 	= ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iHighPrice)/DRV_CONST_PRICE_FACTOR;       
			TempLoPrice 	= ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iLowPrice)/DRV_CONST_PRICE_FACTOR;        
			tempTotalValueTraded = ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].fTotalValueTraded)/DRV_CONST_PRICE_FACTOR;
			tempOpnIntrst 	= ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iOpenIntersest)/DRV_CONST_PRICE_FACTOR;
			tempChgOpnIntrst = ((DOUBLE64)spMktStatus->MktStatsData[LoopVar].iChgOpenInterest)/DRV_CONST_PRICE_FACTOR;
			convert_seconds_to_date(spMktStatus->MktStatsData[LoopVar].SecInfo.iExpiryDate,tempLogTime);


			if (strncmp (tempoptiontype,DRV_CE,OPT_TYPE_LEN) == 0)    /*OPT_TYPE_LEN = 2* & OPTION_SIZE =3*/
			{
				logDebug2("tempoptiontype[%s]",tempoptiontype);
				strncpy(Option,DRV_CE,OPTION_SIZE);
			}
			else if(strncmp (tempoptiontype,DRV_PE,OPT_TYPE_LEN) == 0)
			{
				logDebug2("tempoptiontype[%s]",tempoptiontype);
				strncpy(Option,DRV_PE,OPTION_SIZE);
			}
			else if(strncmp (tempoptiontype,DRV_XX,OPT_TYPE_LEN) == 0)
			{
				logDebug2("tempoptiontype[%s]",tempoptiontype);
				strncpy(Option,DRV_XX,OPTION_SIZE);
			}
			else
			{
				logDebug2("In else");
			}

			logDebug2("temCrptId is %.4s",spMktStatus->MktStatsData[LoopVar].sCrptActnIndicator);
			logDebug2("Symbol is %s ",tempSymbol);
			logDebug2("Instrument is %s",tempinstruname);
			logDebug2("Strikeprice  is %lf",tempStrikePrice);
			logDebug2("ExpiryDate   is %s ",tempLogTime);
			logDebug2("Option is %s",Option);
			logDebug2("TempOpnPrice[%.2f]",TempOpPrice);
			logDebug2("TempHighPrice[%.2f]",TempHiPrice);
			logDebug2("TempLowPrice[%.2f]",TempLoPrice);
			logDebug2("TempClosePrice[%.2f]",TempClPrice);
			logDebug2("TotalQtyTraded [%d]",TotalQtyTraded);
			logDebug2("TempTotlTrdVal[%.2f]",tempTotalValueTraded);
			logDebug2("TempPrvClose[%.2f]",TempPcPrice);
			logDebug2("tempOpnIntrst[%.2f]",tempOpnIntrst);
			logDebug2("tempChgOpnIntrst [%.2f]",tempChgOpnIntrst);

			if((strncmp((spMktStatus->MktStatsData[LoopVar].SecInfo).sInstrumentName,"FUT",3)==0))
			{
				sprintf(SelQry,"SELECT IFNULL ((SELECT SM_SCRIP_CODE \
					FROM SECURITY_MASTER \
					WHERE SM_SYMBOL = ltrim(rtrim(\'%s\')) \
					AND  SM_INSTRUMENT_NAME = ltrim(rtrim(\"%s\")) \
					AND SM_EXPIRY_DATE = STR_TO_DATE( \"%s\",'%%d-%%m-%%Y %%H:%%i:%%s')),1) as n;",tempSymbol,tempinstruname,tempLogTime);
				logDebug2("SelQry-> %s",SelQry);
				if(mysql_query(CrMkt_Con,SelQry)!=SUCCESS)
				{
					sql_Error(CrMkt_Con);
					logSqlFatal("ERROR in Selecting ScripCode In Function UpdateBhavCopyReport");
					return FALSE;
				}

				Res = mysql_store_result(CrMkt_Con);
				Row = mysql_fetch_row(Res);

				if (atoi(Row[0]) == 1)
				{
					logDebug2("Row contains Null value");
					sql_Error(CrMkt_Con);
					return FALSE;
				}
				strncpy(tempSecurityId,Row[0],SECURITY_LEN);
				logDebug2("tempSecurityId for Fut[%d]",atoi(tempSecurityId));
				logDebug2("Inside for FUT");
			}
			else
			{
				sprintf(SelQry,"SELECT IFNULL ((SELECT SM_SCRIP_CODE  FROM SECURITY_MASTER WHERE SM_SYMBOL = ltrim(rtrim(\"%s\")) \
					AND  SM_INSTRUMENT_NAME = ltrim(rtrim(\"%s\")) AND SM_EXPIRY_DATE = STR_TO_DATE( \"%s\",'%%d-%%m-%%Y %%H:%%i:%%s')\
					AND SM_STRIKE_PRICE= round(%lf,2) AND SM_OPTION_TYPE = ltrim(rtrim(\"%s\"))),1) as n;",tempSymbol,tempinstruname,tempLogTime,tempStrikePrice,Option);
				logDebug2("SelQry->%s",SelQry);
				if(mysql_query(CrMkt_Con,SelQry)!=SUCCESS)
				{
					sql_Error(CrMkt_Con);
					logSqlFatal("ERROR in Selecting SM_SCRIP_CODE In Function UpdateBhavCopyReport");
					return FALSE;
				}

				Res = mysql_store_result(CrMkt_Con);	
				Row = mysql_fetch_row(Res);

				if (atoi(Row[0]) == 1)
				{
					logDebug2("Row contains Null value");
					return FALSE;
				}
				strncpy(tempSecurityId,Row[0],SECURITY_LEN);
				logDebug2("ScripCode [%d}",atoi(tempSecurityId));
		}	
		TempMktType = spMktStatus->MktStatsData[LoopVar].iMktType ;
		switch(TempMktType)
		{
			case NORMAL_MARKET:
				strncpy(NormlMkt,MKT_TYPE_NL,MKT_TYPE_LEN);
				break;
			case ODDLOT_MARKET:
				strncpy(NormlMkt,MKT_TYPE_OL,MKT_TYPE_LEN);
				break;
			case SPOT_MARKET:
				strncpy(NormlMkt,MKT_TYPE_SP,MKT_TYPE_LEN);
				break;
			case AUCTION_MARKET:
				strncpy(NormlMkt,MKT_TYPE_AU,MKT_TYPE_LEN);
				break;
			case CALL_AUCTION_MARKET1:
				strncpy(NormlMkt,MKT_TYPE_CAU_1,MKT_TYPE_LEN);
				break;
			case CALL_AUCTION_MARKET2:
				strncpy(NormlMkt,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
				break;
			default :
				logDebug2("MktType received in Junk");
				break;
		}

		sprintf(InsrtQry," INSERT INTO DRV_BHAV_COPY \
				(	DBC_EXCHANGE,DBC_SEGMENT,\
					DBC_SCRIP_CODE,DBC_MARKET_TYPE,\
					DBC_DATE,DBC_OPEN_PRICE,\
					DBC_HIGH_PRICE,DBC_LOW_PRICE,\
					DBC_CLOSE_PRICE,DBC_VOLUME,\
					DBC_TOTAL_TRADE_VALUE,DBC_PREVIOUS_CLOSE,\
					DBC_SETTLEMENT_PRICE,DBC_OPEN_INTEREST,\
					DBC_OPEN_INTEREST_CHANGE)\
				VALUES(\
					\"%s\",\'%c\',\
					%d,\"%s\",\
					Now(),%.2f,\
					%.2f,%.2f,\
					%.2f,%.2f,\
					%.2f,%.2f,\
					%.2f,%.2f ,\
					%.2f)\
				on duplicate key \
				UPDATE \
				DBC_EXCHANGE = VALUES(DBC_EXCHANGE) ,\
				DBC_SEGMENT = VALUES(DBC_SEGMENT) ,\
				DBC_SCRIP_CODE = VALUES(DBC_SCRIP_CODE),\
				DBC_MARKET_TYPE = VALUES(DBC_MARKET_TYPE),\
				DBC_DATE = VALUES(DBC_DATE) ,\
				DBC_OPEN_PRICE  = VALUES(DBC_OPEN_PRICE) ,\
				DBC_HIGH_PRICE  = VALUES(DBC_HIGH_PRICE) ,\
				DBC_LOW_PRICE = VALUES(DBC_LOW_PRICE) ,\
				DBC_CLOSE_PRICE = VALUES(DBC_CLOSE_PRICE) ,\
				DBC_VOLUME = VALUES(DBC_VOLUME) ,\
				DBC_TOTAL_TRADE_VALUE = VALUES(DBC_TOTAL_TRADE_VALUE) ,\
				DBC_PREVIOUS_CLOSE = VALUES(DBC_PREVIOUS_CLOSE) ,\
				DBC_SETTLEMENT_PRICE = VALUES(DBC_SETTLEMENT_PRICE) ,\
				DBC_OPEN_INTEREST = VALUES(DBC_OPEN_INTEREST) ,\
				DBC_OPEN_INTEREST_CHANGE = VALUES(DBC_OPEN_INTEREST);",NSE_EXCH,CURRENCY_SEGMENT,atoi(tempSecurityId),NormlMkt,TempOpPrice,TempHiPrice,TempLoPrice,TempClPrice,tempTotalValueTraded,TempPcPrice,0.00000,tempOpnIntrst,tempChgOpnIntrst);
		logDebug2("InsrtQry->[%s]",InsrtQry);
		if(mysql_query(CrMkt_Con,InsrtQry)!=SUCCESS)
		{
			logSqlFatal("ERROR in Inserting  DRV_BHAV_COPY In Function UpdateBhavCopyReport");
			sql_Error(CrMkt_Con);
			return FALSE;
		}
		if(mysql_commit(CrMkt_Con)!=0)
			logFatal("Failed to commit");
		else
			logDebug2("Success in Insert Query");
		logDebug2("Successfully committed");

	}

}
logTimestamp("Exit : [UpdateBhavCopyReport]");
return TRUE;
}

BOOL UpdateInstrument(NNF_INSTRUMENT_UPDATE_INFO_BCAST   *spInstrumentdata)
{
	logTimestamp("Entry : [UpdateInstrument]");
	logDebug2("7324");
	CHAR    tempLogTime[DATE_STRING_LENGTH];
//	CHAR    *SelQry = malloc(sizeof(CHAR)* MAX_QUERY_SIZE);
//	CHAR    *UpdQry = malloc(sizeof(CHAR)* MAX_QUERY_SIZE);
//	CHAR    *InsQry = malloc(sizeof(CHAR)* MAX_QUERY_SIZE);
	CHAR	UpdQry[MAX_QUERY_SIZE];
	CHAR	InsQry[MAX_QUERY_SIZE];
	memset(UpdQry,'\0',MAX_QUERY_SIZE);
	memset(InsQry,'\0',MAX_QUERY_SIZE);

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	convert_seconds_to_date(spInstrumentdata->InstUpdateTime,tempLogTime);

	sprintf(UpdQry,"UPDATE DRV_NSE_INSTRUMENT_MASTER \
			SET  DNIM_DELETE_FLG = \'%c\',\
			DNIM_CREATED_DATE = now(),\
			DNIM_CREATED_BY =user() \
			DNIM_UPDATED_DATE = STR_TO_DATE( \"%s\",'%%d%%m%%y %%h%%i%%s');",spInstrumentdata->DeleteFlag,tempLogTime);
	logDebug2("UpdQry->%s",UpdQry);
	if(mysql_query(CrMkt_Con,UpdQry)!=SUCCESS)
	{
		sql_Error(CrMkt_Con);
		logSqlFatal("ERROR in Updating DRV_NSE_INSTRUMENT_MASTER In Function UpdateInstrument");
		mysql_rollback(CrMkt_Con);
		return FALSE;


	}
	if(mysql_affected_rows(CrMkt_Con) == 0)
	{
		sprintf(InsQry,"INSERT INTO  DRV_NSE_INSTRUMENT_MASTER \
				(  \
				   DNIM_INSTRUMENT_NAME, \
				   DNIM_INSTRUMENT_DESC, \
				   DNIM_DELETE_FLG, \
				   DNIM_INSTRUMENT_ID, \
				   DNIM_CREATED_DATE,\
				   DNIM_CREATED_BY, \
				   DNIM_UPDATED_DATE) \
				VALUES \
				(\"%s\",\"%s\",\'%c\',%d,now(),user(),STR_TO_DATE( \"%s\",'%%d%%m%%y %%h%%i%%s'));",\
				spInstrumentdata->InstrumentName,spInstrumentdata->InstDescription,spInstrumentdata->InstrumentId,tempLogTime);
		logDebug2("InsQry->%s",InsQry);
		if(mysql_query(CrMkt_Con,InsQry)!=SUCCESS)
		{
			sql_Error(CrMkt_Con);
			logSqlFatal("ERROR in Inserting DRV_NSE_INSTRUMENT_MASTER In Function UpdateInstrument");
			mysql_rollback(CrMkt_Con);
			return FALSE;
		}
	}
	if(mysql_commit(CrMkt_Con)!=0)
		logDebug2("Failed tocommit");
	else
		logDebug2("Successfully comitted");
	return TRUE;
	logTimestamp("Exit : [UpdateInstrument]");

}

BOOL GetTimeofDay()
{
	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
	gettimeofday(&StartPoint1, &tzp);
	logDebug2("Time of entry is :%d:",StartPoint1.tv_sec);
}

BOOL CheckSpaces( CHAR  *ChkStr, LONG32 Len )
{
	BOOL    AllSpaces = TRUE;
	LONG32  i;

	for (i=0; i < Len; i++)
	{
		if (ChkStr[i] != SPACE)
		{
			AllSpaces = FALSE;
			return AllSpaces;
		}
	}

	return AllSpaces;
}	
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST (char *NNFData)
{
        logTimestamp ("ENTRY [tTC_STOCK_DETAILS_CHANGE]");
        logDebug2("7305");
        struct NNF_SECURITY_UPDATE_BCAST *pSecData;
        pSecData = (struct NNF_SECURITY_UPDATE_BCAST *)NNFData;
        CHAR    supdate[MAX_QUERY_SIZE];// malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	memset(&supdate,'\0',MAX_QUERY_SIZE);

        DOUBLE64        templowpricernge;
        DOUBLE64        temphighpricernge;
        DOUBLE64        tempfreezepercnt;

        tempfreezepercnt =((DOUBLE64)pSecData->iFreezePercent)/CURR_CONST_PRICE_FACTOR;
        templowpricernge =((DOUBLE64)pSecData->iLowPriceRange)/CURR_CONST_PRICE_FACTOR;
        temphighpricernge =((DOUBLE64)pSecData->iHighPriceRange)/CURR_CONST_PRICE_FACTOR;

        logDebug2("pSecData->Token:%d:",pSecData->iToken);
        logDebug2("SecData->sHeader.MsgCode[%d]",pSecData->sHeader.iMsgCode);
        logDebug2("pSecData->HighPriceRange :%.4f:",temphighpricernge);
        logDebug2("pSecData->FreezePercent:%.4f:",tempfreezepercnt);

        logDebug2("Token :%d: High :%.2f: Low :%.2f:",pSecData->iToken,pSecData->iHighPriceRange,pSecData->iLowPriceRange);

	 //        sprintf(supdate,"UPDATE SECURITY_MASTER SET SM_UPPER_LIMIT = %.2f , SM_LOWER_LIMIT = %.2f , SM_FREEZE_PERCNT = %.2f WHERE SM_SEGMENT = \'%c\' AND SM_EXCHANGE = \'%s\' AND SM_SCRIP_CODE = %d ;",temphighpricernge,templowpricernge,tempfreezepercnt,SEGMENT_CURRENCY,NSE_EXCH,pSecData->iToken);

	sprintf(supdate,"CALL PR_CKT_LMT_UPDATE(\"%d\",\"%s\",\'%c\',%.4f,%.4f,@ZSTATUS)",\
                        pSecData->iToken,NSE_EXCH,SEGMENT_CURRENCY,temphighpricernge,templowpricernge);

        logDebug2("Query[%s]",supdate);

        if(mysql_query(CrMkt_Con,supdate) != SUCCESS)
        {
                logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
                sql_Error(CrMkt_Con);
        }
        else
        {
                mysql_commit(CrMkt_Con);
                logDebug2("------SUCCESS IN CIRCUIT LIMIT-----");
		
	 }

        logTimestamp ("EXIT [tTC_STOCK_DETAILS_CHANGE]");
        //free(supdate);
        return TRUE;
}












































