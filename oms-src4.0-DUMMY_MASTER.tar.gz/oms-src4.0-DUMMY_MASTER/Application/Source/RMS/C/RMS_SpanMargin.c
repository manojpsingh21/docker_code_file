#include <stdio.h>
#include <stdlib.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "HashTable.h"
#include "RMS_Struct.h"

MYSQL 	*RMS_Con;

struct  RMS_Security *SpHash = NULL;

int main()
{
	LONG32		i=0;
	LONG32		iNoOfRec;
	MYSQL_RES 	*Rec;
	MYSQL_ROW	Row;
	LONG32		iTempSecID;

	RMS_Con = DB_Connect();
	//printf("this is core 1\n");

	if(mysql_query(RMS_Con,"SELECT * FROM SECURITY_MASTER"))
	{
		sql_Error(RMS_Con);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);
	}				

	//printf("this is core 2\n");			
	Rec = mysql_store_result(RMS_Con);
	iNoOfRec = mysql_num_rows(Rec);	

	struct RMS_Security *SMData[iNoOfRec],*TempData;
	//printf("this is core 3\n");
	while(Row = mysql_fetch_row(Rec))
	{
		SMData[i] =  (struct RMS_Security *)malloc(sizeof(struct RMS_Security ));
		TempData = (struct RMS_Security *)malloc(sizeof(struct RMS_Security ));
		iTempSecID = Row[0];
		//printf("this is core 4\n");
		SMData[i]->iScripCode = atoi(Row[0]);  		
		strncpy(SMData[i]->sSymName,Row[1],DB_SYM_NAME_LEN);
		SMData[i]->RmsSpan.fSpan1 = atof(Row[2]);
		SMData[i]->RmsSpan.fSpan2 = atof(Row[3]);
		SMData[i]->RmsSpan.fSpan3 = atof(Row[4]);
		SMData[i]->RmsSpan.fSpan4 = atof(Row[5]);
		SMData[i]->RmsSpan.fSpan5 = atof(Row[6]);
		SMData[i]->RmsSpan.fSpan6 = atof(Row[7]);
		SMData[i]->RmsSpan.fSpan7 = atof(Row[8]);
		SMData[i]->RmsSpan.fSpan8 = atof(Row[9]);
		SMData[i]->RmsSpan.fSpan9 = atof(Row[10]);
		SMData[i]->RmsSpan.fSpan10 = atof(Row[11]);
		//printf("this is core 5\n");
		SMData[i]->RmsSpan.fSpan11 = atof(Row[12]);
		//printf("SMData[i]->RmsSpan.fSpan11 %lf",atof(Row[11]));
		SMData[i]->RmsSpan.fSpan12 = atof(Row[13]);
		SMData[i]->RmsSpan.fSpan13 = atof(Row[14]);
		SMData[i]->RmsSpan.fSpan14 = atof(Row[15]);
		SMData[i]->RmsSpan.fSpan15 = atof(Row[16]);
		SMData[i]->RmsSpan.fSpan16 = atof(Row[17]);
		SMData[i]->RmsSpan.fDelta 	= atof(Row[18]);
		SMData[i]->RmsSpan.fOpt_Premium = atof(Row[19]);
		strncpy(SMData[i]->RmsSpan.sUpdated_Date,Row[20],DB_DATETIME_LEN);

		if(Row[21] != NULL)
		{
			SMData[i]->RmsSpan.fSpanMargin = atof(Row[21]);
			printf("SMData[i]->RmsSpan.fSpan21 %lf",atof(Row[21]));
		}

		if(Row[21] != NULL)
		{
			SMData[i]->RmsSpan.fExpoMargin = atof(Row[22]);
		}
		strncpy(SMData[i]->sInsName,Row[23],DB_SYM_NAME_LEN);	
		strncpy(SMData[i]->sExpiryDate,Row[24],DB_DATETIME_LEN);
		SMData[i]->fStrikePrice = atof(Row[25]);
		//printf("this is core 7\n");
		strncpy(SMData[i]->sOptType,Row[26],DB_OPT_TYPE_LEN);
		SMData[i]->RmsSpan.fSOM = atof(Row[27]);
		strncpy(SMData[i]->RmsSpan.sUnderlying_SecID,Row[28],DB_SECURITY_ID_LEN);
		strncpy(SMData[i]->RmsSpan.sUnderlying_Sym,Row[29],DB_SYM_NAME_LEN);
		SMData[i]->cSeg = Row[30][0];
		strncpy(SMData[i]->sExch,Row[31],DB_EXCH_ID_LEN);
		SMData[i]->RmsSpan.fDelta_Spread = atof(Row[32]);
		//printf("this is core 8\n");
		HASH_FIND(H_By_ID,SpHash, &iTempSecID,sizeof(LONG32),TempData);	

		if(TempData == NULL)
		{
			//			printf("\n RMS Coming Soon \n");		
			HASH_ADD(H_By_ID,SpHash,iScripCode,sizeof(LONG32),SMData[i] );
			printf("\n RMS Security ID %d uploaded successfully \n",SMData[i]->iScripCode);
		}	
		else
		{
			printf("this hash is preserved  by ->\n");
		}
		i++;			
	}
	printf("RMS HASH Coming Soon\n");



	return 0;

}
