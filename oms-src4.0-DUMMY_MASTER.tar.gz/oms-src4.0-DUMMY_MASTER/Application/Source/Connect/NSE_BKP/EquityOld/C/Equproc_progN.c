//#include "EqufalloverN.h"
//#include "IntBcastStructs.h"
#include <sys/socket.h>
#include "IPCS.h"
#include <time.h>
#include "NNFStruct.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>


//static 	LONG32	tHostPCTimeDiff ;

extern	DBConNNF;
extern 	CHAR sKey[DB_KEY_LEN];

//CHAR *	GcPlainKey; 
LONG32 	iSockfdBroad;
extern	LONG32 iGlobGroupId;	
extern	LONG32 iTotalStream;	

SHORT  	fTrim( CHAR *string , SHORT iMaxLen );

BOOL 	fUpdateSignOnResponse(struct NNF_SIGNON_RESP *spSignOnResp)
{
	logTimestamp("Entry : {fUpdateSignOnResponse}");

	CHAR	sLastPasswordChangeDate[DATE_STRING_LENGTH];
	CHAR    sLastMktCloseTime[DATE_STRING_LENGTH];
	CHAR	cConnectedToExch ; 
	DOUBLE64  fSeqNo;
	LONG32  iOffset_julitime;
	LONG32	iSys_julitime;
	LONG32	iNse_julitime;
	LONG32  iCtr;
	CHAR	sDateFormat[ NNF_DATE_TIME_LEN];		
	//	CHAR	sLastMktCloseTime[DATE_STRING_LENGTH];
	//	CHAR	sLastPasswordChangeDate[DATE_STRING_LENGTH];
	CHAR	sTempPassword[P_LEN]; 
	CHAR	sEncryptPassword[75]; 
	CHAR	*sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	memset(sTempPassword,'\0',P_LEN+1) ;
	memset(sEncryptPassword,'\0',P_LEN+1) ;

	logDebug2("spSignOnResp->EligibilityPerMkt.PreOpen :%d:",spSignOnResp->pEligibilityPerMkt.PreOpen);

	/***	EXEC SQL SELECT JULIDATE(SYSDATE)
INTO :iSys_julitime
FROM DUAL;****/
	if(mysql_query(DBConNNF,"SELECT julidate(now()) from dual;")!= SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConNNF);

	while((Row = mysql_fetch_row(Res)))
	{
		iSys_julitime = atoi(Row[0]);
	}
	logDebug2(" Sys_julitime :%d:",iSys_julitime);

	mysql_free_result(Res);

	iNse_julitime=spSignOnResp->pHeader.iLogTimeStamp;

	logDebug2("Sysjulitime is :%d Nsejulitime is :%d",iSys_julitime,iNse_julitime);
	iOffset_julitime = iNse_julitime-iSys_julitime;

	memcpy (&fSeqNo,spSignOnResp->sSeqNumber,8); 
	convert_seconds_to_date(spSignOnResp->iEndTime, sLastMktCloseTime);


#ifdef	DBG
	logDebug2("NOTE: The Date Format is:%s: , Len : %s", sDateFormat , sDateFormat );
	logDebug2("UpdateSignOnResponse: The end date before passing to convert_seconds_to_date :  %d ",spSignOnResp->iEndTime);	
	logDebug2("UpdateSignOnResponse: The end date : %s ",sLastMktCloseTime);	
#endif

	strcpy(sLastMktCloseTime, sLastMktCloseTime);
	convert_seconds_to_date(spSignOnResp->iLastPasswordChange, sLastPasswordChangeDate);

#ifdef	DBG
	logDebug2("UpdateSignOnResponse: The password change date is %s ",sLastPasswordChangeDate); 	 
#endif

	strcpy(sLastPasswordChangeDate, sLastPasswordChangeDate);

	for(iCtr = 0;iCtr<NSE_PASSWORD_LEN; iCtr++)
	{
		if(spSignOnResp->sPassword[iCtr] == ' ')
		{
			logDebug2("WOWW....!!!!  Found  the  blank in the  Password....@[%d]",iCtr);
			spSignOnResp->sPassword[iCtr] = '\0';
		}
	}

	strncpy(sTempPassword, spSignOnResp->sPassword,NSE_PASSWORD_LEN);
	logDebug2("Normal Password [%s]", sTempPassword); 

	fTrim(spSignOnResp->sPassword,NSE_PASSWORD_LEN);
	logDebug2("SignOnResp->Password[%s]",spSignOnResp->sPassword); 
	fTrim(spSignOnResp->sTraderName,TRADER_NAME_LEN);


	/***	 EXEC SQL EXECUTE BEGIN :sEncryptPassword := toolkit.encrypt (
	  :sTempPassword
	  );

	  END;
	  END-EXEC;
	  if (sqlca.sqlcode !=0)
	  {
	  logDebug2("\n Error in decrypting sEncryptPassword 1 is :%d:",sqlca.sqlcode);
	  exit(0);
	  }



	  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER 
	  SET
	  EAM_OLD_PASSWORD     = :sEncryptPassword,
	  EAM_NEW_PASSWORD	 = '',
	  EAM_TRADER_NAME   = :spSignOnResp->TraderName,
	  EAM_EXCH_OFFSET_TIME =:iOffset_julitime,	
	  EAM_LAST_PASSWORD_CHANGE_DATE = to_date(:sLastPasswordChangeDate,'DD-MM-YYYY HH24:MI:SS'),
	  EAM_BROKER_ID = :spSignOnResp->BrokerCode, 
	  EAM_BRANCH_ID = to_CHAR(:spSignOnResp->BranchId),   
	  EAM_LAST_MKT_CLOSE_TIME = to_date(:sLastMktCloseTime, 'DD-MM-YYYY HH24:MI:SS'),
	  / /EAM_EXCH_USER_TYPE = to_CHAR(:spSignOnResp->UserType), 
	//         EAM_EXCH_SEQUENCE_NO = decode(ltrim(rtrim(:spSignOnResp->SeqNumber)),'','0',ltrim(rtrim(:spSignOnResp->SeqNumber))),
	EAM_BROKER_STATUS = :spSignOnResp->BrokerStatus,
	EAM_LOGON_STATUS = :cConnectedToExch   
	WHERE EAM_EXM_EXCH_ID = 'NSE'  AND
	EAM_EXCH_USER_ID = to_CHAR(:spSignOnResp->UserId)
	AND
	EAM_DRV_FLAG = 'N';

#ifdef     DBG
logDebug2("\n\t UpdateSignOnResponse: The error is %d ",sqlca.sqlcode);				
#endif*****/

	logDebug2("spSignOnResp->pHeader.iErrorCode :%d:",spSignOnResp->pHeader.iErrorCode);

	if(spSignOnResp->pHeader.iErrorCode == 0)
	{
		cConnectedToExch = CONNECTED_TO_EXCH ;



		sprintf(sQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
				EAM_OLD_PASSWORD = aes_encrypt(\"%s\",\"%s\"),\
				EAM_NEW_PASSWORD = null, \
				EAM_TRADER_NAME = \"%s\",\
				EAM_EXCH_OFFSET_TIME = %d,\
				EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'), \
				EAM_BRANCH_ID = %d ,\
				EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
				EAM_BROKER_STATUS = \'%c\',\
				EAM_LOGON_STATUS = \'%c\', \
				EAM_REASON_DESC = ifNULL((select RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \'%s\' and RM_ERR_CODE = \'%d\'),'Connected'),\
				EAM_ERROR_ID = \'%d\' \
				WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
				EAM_EXCH_USER_ID = %d AND \
				EAM_SEGMENT = \'%c\' AND \
				EAM_GROUP_ID = %d;",spSignOnResp->sPassword,sKey,spSignOnResp->sTraderName,iOffset_julitime,sLastPasswordChangeDate,
				spSignOnResp->iBranchId,sLastMktCloseTime,spSignOnResp->cBrokerStatus,cConnectedToExch,NSE_EXCH,spSignOnResp->pHeader.iErrorCode,\
				spSignOnResp->pHeader.iErrorCode,NSE_EXCH,\
				spSignOnResp->iUserId,EQUITY_SEGMENT,iGlobGroupId);
	}
	else
	{
		cConnectedToExch = EXCH_REJECT_STATUS;
		sprintf(sQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
				EAM_EXCH_OFFSET_TIME = %d,\
				EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'), \
				EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
				EAM_BROKER_STATUS = \'%c\',\
				EAM_LOGON_STATUS = \'%c\', \
				EAM_REASON_DESC = ifNULL((select RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \'%s\' and RM_ERR_CODE = \'%d\'),'Connected'),\
				EAM_ERROR_ID = \'%d\' \
				WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
				EAM_EXCH_USER_ID = %d AND \
				EAM_SEGMENT = \'%c\' AND \
				EAM_GROUP_ID = %d;",iOffset_julitime,sLastPasswordChangeDate,
				sLastMktCloseTime,spSignOnResp->cBrokerStatus,cConnectedToExch,NSE_EXCH,spSignOnResp->pHeader.iErrorCode,\
				spSignOnResp->pHeader.iErrorCode,NSE_EXCH,\
				spSignOnResp->iUserId,EQUITY_SEGMENT,iGlobGroupId);
	}		

	logDebug2("sQuery-> :%s:",sQuery);
	/**/
	if(mysql_query(DBConNNF,sQuery) != SUCCESS)
	{
		sql_Error(DBConNNF);
		free(sQuery);	
		return ERROR;
	}
	else
	{
		logDebug2("%d rows affected ",mysql_affected_rows(DBConNNF));
		mysql_commit(DBConNNF);
		free(sQuery);	
		return TRUE;

	}
	/***/

	logTimestamp("Exit : [fUpdateSignOnResponse]");
}

/*******************************************************

  Function Name : UpdateSysInfoResp

Parameters :
NNF_SYS_INFO_RESP   *spSysInfoResp

Functionality : Updates system information response  

Return Values : True/False

Tables Accessed :
MAPPING_MASTER (select)
EXCH_MKT_MASTER (update)
EXCH_MASTER (update)
EXCH_ADMINISTRATION_MASTER (update)
TRADE_LMT_ALT_EXP_MASTER (Update)
NSE_SECURITY_MASTER (update)	  

Assumptions :
NORMAL_MARKET                            1
ODDLOT_MARKET                            2
SPOT_MARKET                              3
AUCTION_MARKET                           4
 *******************************************************/
/*****/
BOOL UpdateSysInfoResp( struct  NNF_SYS_INFO_RESP *spSysInfoResp )
{
	logTimestamp("Entry : [UpdateSysInfoResp]");

	CHAR	sUpdQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	LONG32	iTempStatus = 0;
	LONG32	i = 0;
	CHAR	sMktType[MKT_TYPE_LEN];

	for(i = 1;i<= 6;i++);
	{
		memset(sMktType,'\0',MKT_TYPE_LEN);
		//switch(spSysInfoResp->pMarketStatus.iNormal )
		switch(i)
		{
			case INT_NL_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iNormal;
				strncpy(sMktType,MKT_TYPE_NL,MKT_TYPE_LEN);
				break;
			case INT_OL_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iOddlot;
				strncpy(sMktType,MKT_TYPE_OL,MKT_TYPE_LEN);
				break;
			case INT_SP_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iSpot;
				strncpy(sMktType,MKT_TYPE_SP,MKT_TYPE_LEN);
				break;
			case INT_AU_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iAuction;
				strncpy(sMktType,MKT_TYPE_AU,MKT_TYPE_LEN);
				break;
			case INT_AU1_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iCallAuction1;
				strncpy(sMktType,MKT_TYPE_CAU_1,MKT_TYPE_LEN);
				break;
			case INT_AU2_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iCallAuction2;
				strncpy(sMktType,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
				break;
		}

		switch(iTempStatus)
		{
			case EXCH_MKT_PREOPEN:
				iTempStatus = MKT_PREOPEN;
				break;
			case EXCH_MKT_OPEN:
				iTempStatus = MKT_OPEN;
				break;
			case EXCH_MKT_CLOSE:
				iTempStatus = MCX_CLOSE;
				break;
			case EXCH_MKT_PREOPENEND:
				iTempStatus = MCX_CLOSE;
				break;
		};			


		sprintf(sUpdQry,"UPDATE  EXCH_MKT_MASTER SET EMM_STATUS = %d  WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'%c\' AND EMM_MKT_TYPE = \"%s\" ;",iTempStatus,NSE_EXCH,EQUITY_SEGMENT,sMktType);

		if(mysql_query(DBConNNF,sUpdQry) != SUCCESS)	
		{
			logFatal("Update Error ");
			sql_Error(DBConNNF);
		}



	}
	return TRUE;
	logTimestamp("Exit : [UpdateSysInfoResp]");

}
/*****/

/***** 
  BOOL HandleSQL(LONG32 code, CHAR *module,CHAR *file,CHAR *table)
  {

  CHAR *error;
  CHAR *add;

  LONG32 result,iQid;

  error = (CHAR *)malloc(ERROR_STRING_LEN);
  add = (CHAR *)malloc(6);

  memset(error,NULL,ERROR_STRING_LEN);

  strcpy(error,"SQL ERROR: ");
  slogDebug2(add,"%d",code);
  strcat(error,add);
  strcat(error,file);
  strcat(error,module);
  strcat(error,table);

  logDebug2("\nNOTE::Inside HandleSQL: MessageLog Q is not opened , Error: %d", code );

  free(error);
  free(add);
  return TRUE;

  if ((code == 0) || (code == 8224))
  return TRUE;
  else
  return FALSE;
  }*////
BOOL	sendsignon(CHAR *sSendnnf, LONG32 iGroupid)
{
	logTimestamp("Entry : [sendsignon]");

	struct	NNF_SIGNON_REQ	*pSign;
	//	LONG32 	logonreq_result;
	CHAR	*sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	pSign = (struct NNF_SIGNON_REQ *)malloc(sizeof(struct NNF_SIGNON_REQ));

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	memset((CHAR*)pSign,' ',sizeof(struct NNF_SIGNON_REQ));
	memcpy(pSign,sSendnnf,sizeof(struct NNF_SIGNON_REQ));

	/*****
	  memset(pSign->sHeader.AlphaSplit,'\0',2);
	  memset(pSign->sHeader.TimeStamp1,'\0',NNF_DATE_TIME_LEN);
	  memset(pSign->sHeader.TimeStamp2,'\0',NNF_DATE_TIME_LEN);
	  memset(pSign->sHeader.TimeStamp3,'\0',NNF_DATE_TIME_LEN);
	//memset(pSign->Password,'\0',8);
	//memset(pSign->NewPassword,'\0',8);
	memset(pSign->BrokerCode,'\0',5);
	memset(pSign->WorkstationAddr,'\0',14);
	memset(pSign->BrokerName,'\0',26);

	pSign->sHeader.ErrorCode = 0 ;
	memset(pSign->sHeader.TimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pSign->sHeader.TimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pSign->sHeader.TimeStamp3,' ',NNF_DATE_TIME_LEN);

	memset(pSign->Password,' ',8);
	memset(pSign->NewPassword,' ',8);
	memset(pSign->BrokerCode,' ',5);
	memset(pSign->WorkstationAddr,' ',14);
	memset(pSign->BrokerName,' ',26);
	 *******/

	/*************** Header *****************/
	pSign->pHeader.iErrorCode = 0 ;
	pSign->pHeader.iReserved = 0 ;
	pSign->pHeader.iLogTimeStamp = 0 ;
	pSign->pHeader.iMsgCode = TC_EQU_NSE_SIGNON_REQ;

	memset(pSign->pHeader.sAlphaSplit,' ',2);
	memcpy(pSign->pHeader.sAlphaSplit,"NT",2);
	/**  pSign->sHeader.MsgLength = sizeof(struct NNF_SIGNON_REQ);**/
	pSign->pHeader.iMsgLength = sizeof(struct NNF_SIGNON_REQ);

	logDebug2("sizeof(struct NNF_SIGNON_REQ) :%d:",sizeof(struct NNF_SIGNON_REQ));

	memset(pSign->sNewPassword,'\0',NSE_PASSWORD_LEN);
	memset(pSign->sNewPassword,' ',NSE_PASSWORD_LEN);
	memset(pSign->sTraderName,'\0',26);
	//memset(pSign->sReserved,' ',30);
	/*************** Header *****************/
	/***
	  logDebug2("\n\t before inserting string ");	
	  logDebug2("\n\t sendpSignon USER Id                 :%d ",pSign->iUserId);
	  logDebug2("\n\t sendpSignon VERSION NUMBER  :%ld ",pSign->iVersionNumber);
	  logDebug2("\n\t sendpSignon TIMESTAMP               :%ld ",pSign->pHeader.iLogTimeStamp);
	  logDebug2("\n\t sendpSignon ERROR CODE              :%d ",pSign->pHeader.iErrorCode);
	  logDebug2("\n\t sendpSignon MESG LENGTH             :%d ",pSign->pHeader.iMsgLength);
	  logDebug2("\n\t sendpSignon ALPHA SPLIt     :%s: ",pSign->pHeader.sAlphaSplit );
	  logDebug2("\n\t sendpSignon BROKER NAME     :%s: ",pSign->sBrokerName );
	  logDebug2("\n\t sendpSignon Password        :%s: ",pSign->sPassword);
	  logDebug2("\n\t sendpSignon NewPassword     :%s: ",pSign->sNewPassword);
	  logDebug2("\n\t *************************************************** ");	
	 ***/
	/***
	  slogDebug2(sQuery,"SELECT   EAM_EXCH_USER_ID,\
	  EAM_OLD_PASSWORD,\
	  IF(EAM_NEW_PASSWORD = \' \',\'1\',EAM_NEW_PASSWORD),\
	  EAM_BROKER_ID,\
	  EAM_VERSION_NO,\
	  EAM_WORKSTATION_ADDRESS,\
	  EAM_TRADER_NAME\
	  FROM EXCH_ADMINISTRATION_MASTER \
	  WHERE EAM_GROUP_ID= 1 AND EAM_EXM_EXCH_ID = \"NSE\" AND EAM_DRV_FLAG=\'N\' ");
	 ***/

	sprintf(sQuery,"SELECT   EAM_EXCH_USER_ID,\
			aes_decrypt(EAM_OLD_PASSWORD,\"%s\"),\
			IFNULL(aes_decrypt(EAM_NEW_PASSWORD,\'%s\'),'1') EAM_NEW_PASSWORD,\
			EAM_BROKER_ID,\
			EAM_VERSION_NO,\
			EAM_WORKSTATION_ADDRESS,\
			EAM_TRADER_NAME\
			FROM EXCH_ADMINISTRATION_MASTER \
			WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT = \'%c\'; ",sKey,sKey,iGroupid,NSE_EXCH,EQUITY_SEGMENT);

	logDebug2("Printing sQuery :%s: ",sQuery);
	/***/
	if (mysql_query(DBConNNF, sQuery) != SUCCESS) 
	{
		sql_Error(DBConNNF);
		return ERROR;
	}

	Res = mysql_store_result(DBConNNF);



	if((Row = mysql_fetch_row(Res)))
	{
		pSign->iUserId = atoi(Row[0]);
		memset(pSign->sReserved5,' ',8);	
		strncpy(pSign->sPassword,Row[1],NSE_PASSWORD_LEN);
		logDebug2("Debug by Nitish :%s:",Row[2]);
		memset(pSign->sReserved6,' ',8);	
		if(Row[2][0] != '1')
		{
			logDebug2("NOT NULL");
			strncpy(pSign->sNewPassword,Row[2],NSE_PASSWORD_LEN);
		}
		else
		{
			logDebug2("NULL");
			memset(pSign->sNewPassword,' ',NSE_PASSWORD_LEN);
		}
		logDebug2("Debug by Nitish :%s:",pSign->sNewPassword);	
		memset(pSign->sTraderName,' ',26);
		pSign->iLastPasswdChangetime = 0;
		strncpy(pSign->sBrokerCode,Row[3],BROKER_CODE_LENGTH);
		pSign->iVersionNumber = atoi(Row[4]);
		strncpy(pSign->sWorkstationAddr,Row[5],WORK_STATION_ADDR_LEN);
		strncpy(pSign->sBrokerName,Row[6],BROKER_NAME_LEN);
		memset(pSign->sReserved7,' ',16);	
		memset(pSign->sReserved8,' ',16);	
		memset(pSign->sReserved9,' ',16);	


	}
	free(sQuery);
	/***/
	/******************* Data ****************/
	/**
	  pSign->iUserId =18016;
	  strcpy(pSign->sPassword,"Neaf@Ch1");
	  strcpy(pSign->sNewPassword,"        ");
	  strcpy(pSign->sReserved,"                              ");
	  strcpy(pSign->sBrokerCode,"11159");
	  strcpy(pSign->sReserved,"   ");
	  pSign->iVersionNumber = 93100;
	  logDebug2("\n\t After sendpSignon VERSION NUMBER  :%d: ",pSign->iVersionNumber);
	  logDebug2("\n\t After sendpSignon VERSION NUMBER 1 :%d: ",pSign->iVersionNumber);
	  strcpy(pSign->sWorkstationAddr,"4101710       ");
	  logDebug2("\n\t After sendpSignon VERSION NUMBER 2 :%d: ",pSign->iVersionNumber);
	  logDebug2("\n\t After sendpSignon VERSION NUMBER 3 :%d: ",pSign->iVersionNumber);
	  strcpy(pSign->sBrokerName,"RAMACHANDRAN C R         ");
	  logDebug2("\n\t After sendpSignon VERSION NUMBER  4:%d: ",pSign->iVersionNumber);
	 ***/
	/******************* Data ****************/
	logDebug2("After sendSignon USER Id         :%d: ",pSign->iUserId);
	logDebug2("After sendSignon VERSION NUMBER  :%d: ",pSign->iVersionNumber);
	logDebug2("After sendSignon TIMESTAMP       :%d: ",pSign->pHeader.iLogTimeStamp);
	logDebug2("After sendSignon ERROR CODE      :%d: ",pSign->pHeader.iErrorCode);
	logDebug2("After sendSignon MESG LENGTH     :%d: ",pSign->pHeader.iMsgLength);
	logDebug2("After sendSignon ALPHA SPLIt     :%s: ",pSign->pHeader.sAlphaSplit );
	logDebug2("After sendSignon BROKER NAME     :%s: ",pSign->sBrokerName );
	logDebug2("After sendSignon Password        :%s: ",pSign->sPassword);
	logDebug2("After sendSignon NewPassword     :%s: ",pSign->sNewPassword);

	/*******
	  logonreq_result = PLogOnR(pSign , iGroupid );

	  if (logonreq_result == TRUE)
	  {
#ifdef     DBG
logDebug2("\n\t  Nitish sendpSignon	USER Id 		:%d ",pSign->UserId);
logDebug2("\n\t  Nitish sendpSignon VERSION NUMBER 	:%ld ",pSign->VersionNumber);
logDebug2("\n\t sendpSignon TIMESTAMP 		:%ld ",pSign->sHeader.LogTimeStamp);
logDebug2("\n\t sendpSignon ERROR CODE		:%d ",pSign->sHeader.ErrorCode);
logDebug2("\n\t sendpSignon MESG LENGTH		:%d ",pSign->sHeader.MsgLength);
logDebug2("\n\t sendpSignon ALPHA SPLIt  	:%s: ",pSign->sHeader.AlphaSplit );
logDebug2("\n\t sendpSignon BROKER NAME     :%s: ",pSign->BrokerName );
logDebug2("\n\t sendpSignon Password	:%s: ",pSign->Password);
logDebug2("\n\t sendpSignon NewPassword	:%s: ",pSign->NewPassword);

#endif
TWIDDLE(pSign->UserId);
TWIDDLE(pSign->VersionNumber);
TWIDDLE(pSign->sHeader.LogTimeStamp);
TWIDDLE(pSign->sHeader.MsgCode);
TWIDDLE(pSign->sHeader.ErrorCode);
TWIDDLE(pSign->sHeader.MsgLength); 

}
else if (logonreq_result == FALSE)      
{				
#ifdef     DBG						
logDebug2("\nproc_progN.pc Error in PLogOnR function :: ");
#endif
return(ERROR);
}****************/

	logDebug2("Before Twiddle");
	logDebug2("sendSignon	USER Id 	:%d ",pSign->iUserId);
	logDebug2("sendSignon VERSION NUMBER 	:%d ",pSign->iVersionNumber);
	logDebug2("sendSignon TIMESTAMP 	:%d ",pSign->pHeader.iLogTimeStamp);
	logDebug2("sendSignon MSGCODE 		:%d ",pSign->pHeader.iMsgCode);

	TWIDDLE(pSign->iUserId);
	TWIDDLE(pSign->iLastPasswdChangetime);
	TWIDDLE(pSign->iVersionNumber);
	TWIDDLE(pSign->pHeader.iLogTimeStamp);
	TWIDDLE(pSign->pHeader.iMsgCode);
	TWIDDLE(pSign->pHeader.iErrorCode);
	TWIDDLE(pSign->pHeader.iMsgLength); 

	logDebug2("After Twiddle");
	logDebug2("sendSignon	USER Id 	:%d ",pSign->iUserId);
	logDebug2("sendSignon VERSION NUMBER 	:%d ",pSign->iVersionNumber);
	logDebug2("sendSignon TIMESTAMP 	:%d ",pSign->pHeader.iLogTimeStamp);
	logDebug2("sendSignon MSGCODE 		:%d ",pSign->pHeader.iMsgCode);


	memcpy(sSendnnf,pSign,sizeof(struct NNF_SIGNON_REQ));	

	free(pSign);
	logTimestamp("Exit : [sendsignon]");
	return TRUE;
	}

BOOL	fRecvsignon ( CHAR *sTemp2 )
{
	logTimestamp("Entry : [fRecvsignon]");

	LONG32	iDatasent;

	logDebug1("sTimeStamp1 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->pHeader.sTimeStamp1);
	logDebug1("sTimeStamp2 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->pHeader.sTimeStamp2);
	logDebug1("sTimeStamp3 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->pHeader.sTimeStamp3);
	logDebug1("sSeqNumber 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->sSeqNumber);

	struct 	NNF_SIGNON_RESP	*pRecv;

	pRecv = (struct NNF_SIGNON_RESP *)malloc(sizeof(struct NNF_SIGNON_RESP));
	memcpy(pRecv,sTemp2,sizeof(struct NNF_SIGNON_RESP));

	TWIDDLE(pRecv->iUserId);
	TWIDDLE(pRecv->iLastPasswordChange);
	TWIDDLE(pRecv->iBranchId);
	TWIDDLE(pRecv->iEndTime);
	TWIDDLE(pRecv->iUserType);

	TWIDDLE(pRecv->pHeader.iLogTimeStamp);
	TWIDDLE(pRecv->pHeader.iMsgCode);
	TWIDDLE(pRecv->pHeader.iErrorCode);
	TWIDDLE(pRecv->pHeader.iMsgLength);
	/**
	  TWIDDLE(pRecv->pHeader.sTimeStamp2);
	  TWIDDLE(pRecv->pHeader.sTimeStamp3);
	 **/

#ifdef     DBG
	logDebug2("RecvSignon PASSWORD 			:%s ",pRecv->sPassword);
	logDebug2("RecvSignon NEW PASSWORD 		:%s ",pRecv->sNewPassword);
	logDebug2("RecvSignon RESPONSE TRANSCODE 	:%d ",pRecv->pHeader.iMsgCode);
	logDebug2("RecvSignon user type sent 		:%d ",pRecv->iUserType);
	logDebug2("RecvSignon broker status 		:%c ",pRecv->cBrokerStatus);
	logDebug2("RecvSignon LastMktCloseTime 		:%ld",pRecv->iEndTime);
	logDebug2("RecvSignon LastPaswdchgdate 		:%ld",pRecv->iLastPasswordChange);
	logDebug2("RecvSignon Seq Number 		:%s ",pRecv->sSeqNumber);
	logDebug2("RecvSignon user id 			:%d ",pRecv->iUserId);
	logDebug2("RecvSignon Branch id 		:%d ",pRecv->iBranchId);
	logDebug2("RecvSignon End time 			:%ld",pRecv->iEndTime);
	logDebug2("RecvSignon TraderName 		:%s ",pRecv->sTraderName);
	logDebug2("RecvSignon LastPaswdchgdate 		:%ld",pRecv->iLastPasswordChange);
	logDebug2("RecvSignon BrokerName          	:%s ",pRecv->sBrokerName);
	logDebug2("RecvSignon RESPONSE sTimeStamp1	:%s: ",pRecv->pHeader.sTimeStamp1);
	logDebug2("RecvSignon RESPONSE sTimeStamp2	:%s: ",pRecv->pHeader.sTimeStamp2);
	logDebug2("RecvSignon RESPONSE sTimeStamp3	:%s: ",pRecv->pHeader.sTimeStamp3);
#endif
	/**	
	  if(pRecv->pHeader.iErrorCode == 0)
	  {
	  iDatasent = fUpdateSignOnResponse(pRecv);
	  }
	 ***/
	iDatasent = fUpdateSignOnResponse(pRecv);
	free(pRecv);

	if ( iDatasent == FALSE )			
	{					
#ifdef     DBG					
		logDebug2("Error in writing to Database ");
#endif
		return(ERROR);	
	}	
	else
	{	
#ifdef     DBG
		logDebug2("Success ");
#endif
		return TRUE;
	}	
	logTimestamp("Exit : [fRecvsignon]");

}


BOOL	PLogOnR(NNF_SIGNON_REQ *pSignOn, LONG32 iGroupid)
{
	logTimestamp("Entry : [PLogOnR]");

	CHAR	*cFilename = "proc_progN.pc";
	LONG32  iCtr;

	//CHAR	*SelectQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//	MYSQL_RES               *Res;
	//        MYSQL_ROW               Row;

	CHAR	*sNewPassword; 
	CHAR  	*sPassword; 
	CHAR  	*sBrokerCode;
	CHAR  	*sWorkstationAddr;
	CHAR  	*sBrokerName;

	sNewPassword= malloc(sizeof(CHAR) * 40);
	sPassword= malloc(sizeof(CHAR) * 40);
	sBrokerCode=malloc(sizeof(CHAR) * BROKER_CODE_LENGTH);
	sWorkstationAddr= malloc(sizeof(CHAR) * WORK_STATION_ADDR_LEN);
	sBrokerName= malloc(sizeof(CHAR) * BROKER_NAME_LEN);

	memset(sPassword,'\0',40+1);
	memset(sNewPassword,'\0',40+1);
	memset(sBrokerCode,'\0',BROKER_CODE_LENGTH );
	memset(sWorkstationAddr,'\0' ,WORK_STATION_ADDR_LEN);
	memset(sBrokerName,'\0',BROKER_NAME_LEN);


	logDebug2("******printing null of temp********");
	logDebug2("NewPassword[%s] ",sNewPassword);
	logDebug2("Password[%s]",sPassword);
	logDebug2("BrokerCode[%s]",sBrokerCode);
	logDebug2("WorkstationAddr[%s] ",sWorkstationAddr);
	logDebug2("BrokerName[%s]",sBrokerName);

	memset(sPassword,' ',40);
	memset(sNewPassword,' ',40);
	memset(sBrokerCode,' ',BROKER_CODE_LENGTH );
	memset(sWorkstationAddr,' ' ,WORK_STATION_ADDR_LEN);
	memset(sBrokerName,' ',BROKER_NAME_LEN);

	logDebug2("******printing space of temp********");
	logDebug2("NewPassword[%s] ",sNewPassword);
	logDebug2("Password[%s]",sPassword);
	logDebug2("BrokerCode[%s]",sBrokerCode);
	logDebug2("WorkstationAddr[%s] ",sWorkstationAddr);
	logDebug2("BrokerName[%s]",sBrokerName);

	pSignOn->pHeader.iReserved = 0 ;
	pSignOn->pHeader.iLogTimeStamp = 0 ;
	pSignOn->pHeader.iMsgCode = TC_EQU_NSE_SIGNON_REQ;
	pSignOn->pHeader.iErrorCode = 0 ;

	memset(pSignOn->pHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);
	memset(pSignOn->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pSignOn->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pSignOn->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	memset(pSignOn->sPassword,' ',NSE_PASSWORD_LEN);
	memset(pSignOn->sNewPassword,' ',NSE_PASSWORD_LEN);
	memset(pSignOn->sBrokerCode,' ',BROKER_CODE_LENGTH);
	memset(pSignOn->sWorkstationAddr,' ',WORK_STATION_ADDR_LEN);
	memset(pSignOn->sBrokerName,' ',BROKER_NAME_LEN);

	pSignOn->pHeader.iMsgLength = sizeof(struct NNF_SIGNON_REQ);

	logDebug2("**********MEMSET NNF_SIGNON_REQ WITH SAPCE");
	logDebug2("SignOn->sHeader.AlphaSplit [%s]",pSignOn->pHeader.sAlphaSplit);
	logDebug2("SignOn->sHeader.TimeStamp1 [%s]",pSignOn->pHeader.sTimeStamp1);
	logDebug2("SignOn->sHeader.TimeStamp2 [%s]",pSignOn->pHeader.sTimeStamp2);
	logDebug2("SignOn->sHeader.TimeStamp3 [%s]",pSignOn->pHeader.sTimeStamp3);
	logDebug2("SignOn->Password [%s]",pSignOn->sPassword);
	logDebug2("SignOn->NewPassword[%s]",pSignOn->sNewPassword);
	logDebug2("SignOn->BrokerCode[%s]",pSignOn->sBrokerCode);
	logDebug2("SignOn->WorkstationAddr [%s]",pSignOn->sWorkstationAddr);
	logDebug2("SignOn->BrokerName [%s]",pSignOn->sBrokerName);
	logDebug2("********************************************");

	memcpy( pSignOn->pHeader.sAlphaSplit,"NT",2);

	logDebug2("Group Id in PLogOnR : %d",iGroupid);

	/******
	  slogDebug2(SelectQry,"SELECT EAM_EXCH_USER_ID,EAM_OLD_PASSWORD,EAM_NEW_PASSWORD,EAM_BROKER_ID,EAM_VERSION_NO,EAM_WORKSTATION_ADDRESS,EAM_TRADER_NAME FROM EXCH_ADMINISTRATION_MASTER WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"NSE\" AND EAM_DRV_FLAG=\'N\' ",iGroupid);	

	  logDebug2("\n%s\n",SelectQry);

	  if (mysql_query(DBConNNF,SelectQry ) != SUCCESS) {
	  sql_Error(DBConNNF);
	  return ERROR;
	  }

	  Res = mysql_store_result(DBConNNF);

	  free(SelectQry);

	  if((Row = mysql_fetch_row(Res)))
	  {
	  logDebug2("\n Row[0] %d\n",atoi(Row[0]));
	  logDebug2("\n Row[1] %s\n",Row[1]);
	  if(Row[2]!=NULL)
	  logDebug2("\n Row[2] %s\n",Row[2]);
	  logDebug2("\n Row[3] %s\n",Row[3]);
	  logDebug2("\n Row[4] %d\n",atoi(Row[4]));
	  logDebug2("\n Row[5] %s\n",Row[5]);
	  logDebug2("\n Row[6] %s\n",Row[6]);

	  strcpy(sPassword,Row[1]);
	  if(Row[2]!=NULL )
	  {
	  strcpy(sNewPassword,Row[2]);
	  }
	  pSignOn->UserId = atoi(Row[0]);
	  strcpy(sBrokerCode,Row[3]);
	  pSignOn->VersionNumber = atoi(Row[4]);
	  strcpy(sWorkstationAddr,Row[5]);
	  strcpy(sBrokerName,Row[6]);

	  }*****/




	strcpy(sPassword,"Neat@cd1");
	strcpy(sNewPassword," ");
	strcpy(sBrokerCode,"08814");
	strcpy(sWorkstationAddr,"4101710");
	strcpy(sBrokerName,"SHINE N P");

	/****  memcpy(pSignOn->Password,sPassword,strlen(sPassword));*****/ /***** Nitish to be fetched from DB *****/
	strncpy(pSignOn->sPassword,sPassword,8);
	/**** memcpy(pSignOn->Password,"Neat@cd1",8);***/
	logDebug2("SignOn->Password :%s: :%d: ",pSignOn->sPassword,strlen(pSignOn->sPassword));
	logDebug2("Normal Password :[%s]",pSignOn->sPassword);
	logDebug2("Normal New Password 	[%s]",pSignOn->sNewPassword);
	logDebug2("sBrokerCode= [%d]",sBrokerCode);
	logDebug2("BROKER_CODE_LENGTH = [%d]",BROKER_CODE_LENGTH);

	strncpy(pSignOn->sBrokerCode,sBrokerCode,BROKER_CODE_LENGTH);
	if(strlen(sBrokerCode)< BROKER_CODE_LENGTH)
	{
		logDebug2("inside sBrokerCode< BROKER_CODE_LENGTH");
		memset((pSignOn->sBrokerCode + strlen(sBrokerCode)),' ',(BROKER_CODE_LENGTH - strlen(sBrokerCode)));
	}
	logDebug2("::sWorkstationAddr= [%d]",sWorkstationAddr);
	logDebug2("::WORK_STATION_ADDR_LEN = [%d] ",WORK_STATION_ADDR_LEN);
	strncpy(pSignOn->sWorkstationAddr,sWorkstationAddr,strlen(sWorkstationAddr));

	if(strlen(sWorkstationAddr)< WORK_STATION_ADDR_LEN)
	{
		logDebug2("::inside sWorkstationAddr< WORK_STATION_ADDR_LEN ");
		memset((pSignOn->sWorkstationAddr + strlen(sWorkstationAddr)),' ',(WORK_STATION_ADDR_LEN - strlen(sWorkstationAddr)));
	}

	logDebug2(":: BROKER_NAME_LEN = [%d] ",BROKER_NAME_LEN);
	strncpy(pSignOn->sBrokerName,sBrokerName,strlen(sBrokerName));

	if(strlen(sBrokerName)< BROKER_NAME_LEN)
	{
		logDebug2("::inside sBrokerName< BROKER_NAME_LEN ");
		memset((pSignOn->sBrokerName + strlen(sBrokerName)),' ',(BROKER_NAME_LEN - strlen(sBrokerName)));
	}

	logDebug2("Normal Password"); 
	pSignOn->iVersionNumber = 92700;
	pSignOn->iUserId = 8520;


	logDebug2("Nitish Printing ");
	logDebug2("SignOn->Password  :%d::%s:",NSE_PASSWORD_LEN,pSignOn->sPassword);
	logDebug2("SignOn->Password strlen:%d::%s:",strlen(pSignOn->sPassword),pSignOn->sPassword);
	logDebug2("SignOn->NewPassword:%d::%s:",NSE_PASSWORD_LEN,pSignOn->sNewPassword);
	logDebug2("SignOn->NewPassword:%d::%s:",strlen(pSignOn->sNewPassword),pSignOn->sNewPassword);
	logDebug2("SignOn->BrokerCode :%d::%s:",strlen(pSignOn->sBrokerCode),pSignOn->sBrokerCode);
	logDebug2("SignOn->WorkstationAddr :%d::%s:",strlen(pSignOn->sWorkstationAddr),pSignOn->sWorkstationAddr);
	logDebug2("SignOn->BrokerName :%d::%s:",strlen(pSignOn->sBrokerName),pSignOn->sBrokerName);
	logDebug2("SignOn->VersionNumber %d",pSignOn->iVersionNumber);
	logDebug2("SignOn->UserId %d",pSignOn->iUserId);
	logDebug2("Nitish Printing done ");

	/**
	  EXEC SQL UPDATE exch_administration_master
	  SET eam_logon_status 	= :lDisconnFromExch
	  WHERE 			eam_exm_exch_id 	= 'NSE' 		AND 
	  eam_group_id 		= to_CHAR(:iGroupid) 	AND 	
	  eam_drv_Flag 		= 'N';

	  if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	  return FALSE;
	 ****/
	logTimestamp("Exit : [PLogOnR]"); 
	return TRUE;

}


BOOL	fSendsysinfo(CHAR *cNNF )
{
	logTimestamp("Entry : [fSendsysinfo]");	

	struct NNF_SYS_INFO_REQ *pSys;
	pSys = (struct NNF_SYS_INFO_REQ *)malloc(sizeof(struct NNF_SYS_INFO_REQ));

	memcpy(pSys,cNNF,sizeof(struct NNF_SYS_INFO_REQ));

	pSys->pHeader.iReserved = 0 ;
	pSys->pHeader.iLogTimeStamp = 0 ;
	memset(pSys->pHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);

	pSys->pHeader.iMsgCode = TC_EQU_NSE_SYS_INFO_REQ;
	pSys->pHeader.iErrorCode = 0 ;
	memset(pSys->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pSys->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);

	pSys->pHeader.sTimeStamp2[0] = 0;
	memset(pSys->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pSys->pHeader.iMsgLength = sizeof(struct NNF_SYS_INFO_REQ) ;
	memcpy( pSys->pHeader.sAlphaSplit,"NT",2);

#ifdef     DBG
	logDebug2("proc_progN.pc THIS IS THE SYS INFO DOWNLOAD PROCESS ");
#endif

#ifdef     DBG
	logDebug2("proc_progN.pc The transcode is %d ",pSys->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pSys->pHeader.iMsgLength);
	logDebug2("proc_progN.pc before send .... before fork ");
#endif

	TWIDDLE(pSys->pHeader.iLogTimeStamp);
	TWIDDLE(pSys->pHeader.iMsgCode);
	TWIDDLE(pSys->pHeader.iErrorCode);
	/*	TWIDDLE(pSys->sHeader.MsgLength);	*/
	logDebug2("After TWIDDLE in sendsysinfo ");
	logDebug2("proc_progN.pc The transcode is %d ",pSys->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pSys->pHeader.iMsgLength);
	logDebug2("proc_progN.pc The errorcode is %d ",pSys->pHeader.iErrorCode);

	memcpy(cNNF,pSys,sizeof(struct NNF_SYS_INFO_REQ));

	free(pSys);
	logTimestamp("Exit : [fSendsysinfo]");
	return TRUE;

}


BOOL	fRecvsysinfo(CHAR *cNNF)
{
	logTimestamp("Entry : fRecvsysinfo");

	struct	NNF_SYS_INFO_RESP	*pSys;
	BOOL 	iDataupdate, iEDDFlag;  /**** TAP Reg Changes *****/
	CHAR 	sError[ERROR_MSG_LEN]; 

	pSys = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	memcpy(pSys,cNNF,sizeof(struct NNF_SYS_INFO_RESP));

	TWIDDLE(pSys->pHeader.iMsgCode);
	TWIDDLE(pSys->pHeader.iMsgLength);
	TWIDDLE(pSys->pMarketStatus.iNormal);
	TWIDDLE(pSys->pMarketStatus.iOddlot);
	TWIDDLE(pSys->pMarketStatus.iSpot);
	TWIDDLE(pSys->pMarketStatus.iAuction);
	TWIDDLE(pSys->iMarketIndex);
	TWIDDLE(pSys->iNormalMktDefSttlPeriod);
	TWIDDLE(pSys->iSpotMktDefSttlPeriod);
	TWIDDLE(pSys->iAuctionMktDefSttlPeriod);
	TWIDDLE(pSys->iDefCompititorPeriod);
	TWIDDLE(pSys->iDefSolicitorPeriod);
	TWIDDLE(pSys->iWarnigPercent);
	TWIDDLE(pSys->iVolFreezePercent);
	TWIDDLE(pSys->iBoardLotQty);
	TWIDDLE(pSys->iTickSize);
	TWIDDLE(pSys->iMaxGTCDays);
	TWIDDLE(pSys->iDiscQty);

	//logDebug2("proc_progN.pc The No of STREAM is :%d:", pSys->pHeader.sAlphaSplit[0]);       
	logDebug2("proc_progN.pc The No of STREAM is :%d:", *(pSys->pHeader.sAlphaSplit));      
	if(pSys->pHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP ) 
	{	
		iTotalStream = *(pSys->pHeader.sAlphaSplit);
	}
	else
	{
		iTotalStream = 3;
	}
	logDebug2("iTotalStream :%d:",iTotalStream);	
	logDebug2("proc_progN.pc The transcode is %d ",pSys->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pSys->pHeader.iMsgLength);
	logDebug2("proc_progN.pc The market status for normal  is %d ",pSys->pMarketStatus.iNormal);
	logDebug2("proc_progN.pc The market status for oddlot  is %d ",pSys->pMarketStatus.iOddlot);
	logDebug2("proc_progN.pc The market status for spot  is %d ",pSys->pMarketStatus.iSpot);
	logDebug2("proc_progN.pc The market status for auction  is %d ",pSys->pMarketStatus.iAuction);
	logDebug2("proc_progN.pc The Market Index  is %ld ",pSys->iMarketIndex);
	logDebug2("proc_progN.pc The Normal Mkt Def Sttl period  is %d ",pSys->iNormalMktDefSttlPeriod);
	logDebug2("proc_progN.pc The Spot dffl period is %d ",pSys->iSpotMktDefSttlPeriod);
	logDebug2("proc_progN.pc The Auction dffl period is %d ",pSys->iAuctionMktDefSttlPeriod);
	logDebug2("proc_progN.pc The Def Compitotor period is %d ",pSys->iDefCompititorPeriod);
	logDebug2("proc_progN.pc The Def Solicitor period is %d ",pSys->iDefSolicitorPeriod);
	logDebug2("proc_progN.pc The Warning Percent is %d ",pSys->iWarnigPercent);
	logDebug2("proc_progN.pc The Vol Freeze Percent is %d ",pSys->iVolFreezePercent);
	logDebug2("proc_progN.pc The Board Lot Qty is %ld ",pSys->iBoardLotQty);
	logDebug2("proc_progN.pc The Tick Size is %ld ",pSys->iTickSize);
	logDebug2("proc_progN.pc The Max GTC days is %d ",pSys->iMaxGTCDays);
	logDebug2("proc_progN.pc The Disc Qty is %d ",pSys->iDiscQty);

	if ((pSys->pHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP ) || (pSys->pHeader.iMsgCode == TC_EQU_NSE_PARTIAL_SYS_INFO_RESP))
	{ 
		iDataupdate = UpdateSysInfoResp(pSys);
		free(pSys);
		/*************** TAP Reg Changes*******************/
		//iDataupdate = TRUE;

		if (iDataupdate == TRUE)
		{
			iEDDFlag = fInsertExchDigital( );  

			if( iEDDFlag == TRUE) 
				return TRUE;
		}
		/************ END of TAP Reg Changes*******************/
		else
		{
			memset(sError,NULL,ERROR_MSG_LEN);
			strcpy(sError,"Could Not Update the Database in SYS INFO RESPONSE");
			return(ERROR);
		}
	}	
	else
	{
		free(pSys);

#ifdef     DBG
		logDebug2("proc_progN.pc Got someother transcode other than SYS INFO RESPONSE ");
#endif
		return ERROR;
	}	
	logTimestamp("Exit : fRecvsysinfo");

}


BOOL	fPUpLDBR ( struct NNF_UPDATE_LDB_REQ   *pUpdLDB , LONG32 iGroupid )
{
	//	LONG32	temp1;
	//    	LONG32	temp2;
	logTimestamp("Entry : fPUpLDBR");

	CHAR	*cSecdate,*cPartdate;

	cSecdate = (CHAR *)malloc(sizeof(CHAR)*80);
	cPartdate = (CHAR *)malloc(sizeof(CHAR)*80);

	/****	EXEC SQL SELECT max(JULIDATE(EAM_LAST_UPDATE_PART_TIME))
INTO :temp2
FROM EXCH_ADMINISTRATION_MASTER
WHERE			
EAM_EXCH_USER_ID   = to_CHAR(:iGroupid)  AND
EAM_EXM_EXCH_ID    = 'NSE'              AND
EAM_DRV_FLAG       = 'N';;
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

strcpy(tablename,"NSE_SECURITY_MASTER");
EXEC SQL SELECT max(JULIDATE(NSE_CREATED_DATE))
INTO :temp1
FROM NSE_SECURITY_MASTER;
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;
strcpy(tablename,"EXCH_MKT_MASTER");
EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Normal 
FROM   EXCH_MKT_MASTER
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND 	EMM_MKT_TYPE = 'NL';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Oddlot  
FROM   EXCH_MKT_MASTER 
WHERE	EMM_EXM_EXCH_ID = 'NSE'
AND	EMM_MKT_TYPE = 'OL';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Spot 
FROM   EXCH_MKT_MASTER 
WHERE 	EMM_EXM_EXCH_ID = 'NSE'
AND	EMM_MKT_TYPE = 'SP';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL SELECT EMM_STATUS
INTO   :pUpdLDB->MarketStatus.Auction 
FROM   EXCH_MKT_MASTER 
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND 	EMM_MKT_TYPE = 'AU';   
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;
	 ********/

	pUpdLDB->pMarketStatus.iNormal = 1;
	pUpdLDB->pMarketStatus.iOddlot =1;
	pUpdLDB->pMarketStatus.iSpot = 1; 
	pUpdLDB->pMarketStatus.iAuction =1;
	pUpdLDB->pHeader.iReserved = 0 ;
	pUpdLDB->pHeader.iLogTimeStamp = 0 ;

	memset(pUpdLDB->pHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);

	pUpdLDB->pHeader.iMsgCode = TC_NSE_UPD_LDB_DOWNLD_REQ;
	pUpdLDB->pHeader.iErrorCode = 0 ;

	memset(pUpdLDB->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pUpdLDB->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pUpdLDB->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);

	pUpdLDB->pHeader.iMsgLength = sizeof(struct NNF_UPDATE_LDB_REQ);
	pUpdLDB->cReqForOpenOrders = 'N';
	pUpdLDB->iLastUpdateSecTime = 1130365700;
	pUpdLDB->iLastUpdatePartTime = 991533600;
	/*****
#ifdef DBG
logDebug2("\nproc_progN.pc The Last update security date is %s \n",cSecdate);
logDebug2("\nproc_progN.pc The Last update part time is %s \n",cPartdate);
#endif


if (sqlca.sqlcode == 0)
{
return TRUE;
}
else
{
return FALSE;
}

	 *****/
	free(cSecdate);
	free(cPartdate);
	logTimestamp("Exit : fPUpLDBR");
	return TRUE;

	}

BOOL	fSendupdate( CHAR *cNNF, LONG32 iGroupid )
{
	logTimestamp("Entry : fSendupdate");	

	struct	NNF_UPDATE_LDB_REQ	*pUrequest;
	LONG32 	iUpldb_result;
	CHAR 	sError[ERROR_MSG_LEN];

	pUrequest = (struct NNF_UPDATE_LDB_REQ *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));

	memcpy(pUrequest,cNNF,sizeof(struct NNF_UPDATE_LDB_REQ));
	iUpldb_result = fPUpLDBR(pUrequest, iGroupid ) ;

	if (iUpldb_result == FALSE)
	{
		memset(sError,NULL,ERROR_MSG_LEN);
		strcpy(sError,"Could Not Query the Database in LDB REQUEST");
		logDebug2("%s",sError);
		return(ERROR);
	}

#ifdef     DBG
	logDebug2("proc_progN.pc THIS IS THE Update DATABASE DOWNLOAD PROCESS ");
	logDebug2("proc_progN.pc The result is %d ",iUpldb_result);
	logDebug2("proc_progN.pc the values to be requested are %d %d %d %d ",pUrequest->pMarketStatus.iNormal,pUrequest->pMarketStatus.iOddlot,
			pUrequest->pMarketStatus.iSpot,pUrequest->pMarketStatus.iAuction);
	logDebug2("proc_progN.pc The transcode is %d ",pUrequest->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pUrequest->pHeader.iMsgLength);
	logDebug2("proc_progN.pc before send .... before fork ");
#endif
	TWIDDLE(pUrequest->pHeader.iMsgCode);
	logDebug2("ALOKK Urequest->sHeader.MsgLength :%d:",pUrequest->pHeader.iMsgLength);
	/***    TWIDDLE(pUrequest->sHeader.MsgLength);****/
	logDebug2("ALOKK Urequest->sHeader.MsgLength :%d:",pUrequest->pHeader.iMsgLength);

	TWIDDLE(pUrequest->pHeader.iLogTimeStamp);
	TWIDDLE(pUrequest->pHeader.iErrorCode);
	TWIDDLE(pUrequest->iLastUpdateSecTime);
	TWIDDLE(pUrequest->iLastUpdatePartTime);    
	TWIDDLE(pUrequest->pMarketStatus.iNormal);
	TWIDDLE(pUrequest->pMarketStatus.iOddlot);
	TWIDDLE(pUrequest->pMarketStatus.iSpot);
	TWIDDLE(pUrequest->pMarketStatus.iAuction);

	memcpy(cNNF,pUrequest,sizeof(struct NNF_UPDATE_LDB_REQ)); 

	free(pUrequest);
	logTimestamp("Exit : fSendupdate");
	return TRUE;

}

BOOL	fSendmessage( CHAR *cNNF , LONG32 iGroupid , LONG32 iStream)  /**** TAP Reg Changes *****/
{
	logTimestamp("Entry : fSendmessage");

	struct	NNF_MSG_DOWNLOAD_REQ	*pMrequest;
	struct 	NNF_DOUBLE_INT 		*pTempTimeStamp;
	//  	LONG32 	upMsg_result;
	CHAR 	sError[ERROR_MSG_LEN];
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sSelQyr= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//	LONG32 	i, iMints1,iMints2,minoffts1,minoffts2;
	//	LONG32 	NoOfIterations,IterationStatus;

	//	unsigned	LONG32	TempTime1;
	//	unsigned	LONG32 	TempTime2;
	//	unsigned	ULONG32	iOnTime1;
	//      unsigned 	ULONG32	iOnTime2;

	SHORT	iStreamId; /**** TAP Reg Changes *****/

	pMrequest = (struct NNF_MSG_DOWNLOAD_REQ *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	pTempTimeStamp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));

	memcpy(pMrequest,cNNF,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

	memset(pMrequest,SPACE,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

#ifdef     DBG
	logDebug2("proc_progN.pc the group id is %d ",iGroupid);
#endif

	/*************** TAP Reg Changes*******************/
	iStreamId = iStream ;
	logDebug2("STREAM ID :%d", iStreamId);

	sprintf(sSelQyr,"SELECT EAM_LAST_MSG_TIME,EAM_LAST_MSG_TIME1 FROM EXCH_ADMINISTRATION_MASTER WHERE EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT = \'%c\' AND EAM_GROUP_ID = %d;",NSE_EXCH,EQUITY_SEGMENT,iGroupid)	;
	logDebug2("sSelQyr :%s:",sSelQyr);

	if(mysql_query(DBConNNF,sSelQyr) != SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConNNF);

	if(Row = mysql_fetch_row(Res))
	{
		//pMrequest->fExchSeqNum = atof(Row[0]);
		logDebug3("Last Message Time1 = %s ",Row[0]);
		logDebug3("Last Message Time2 = %s" ,Row[1]);
		sscanf(Row[0],"%u",&(pTempTimeStamp->LogTime1)   );
		sscanf(Row[1],"%u",&(pTempTimeStamp->LogTime2)        );
	}

	logDebug3("Last Message Time1 = %u ",pTempTimeStamp->LogTime1);
	logDebug3("Last Message Time2 = %u" ,pTempTimeStamp->LogTime2);

	memcpy((CHAR*)&pMrequest->fExchSeqNum,pTempTimeStamp, sizeof(struct NNF_DOUBLE_INT) );

	/***
	  pTempTimeStamp->LogTime1 = 0;
	  pTempTimeStamp->LogTime2 = 0; 
#ifdef   DBG
logDebug2("Last Message Time1 = %u ",pTempTimeStamp->LogTime1);
logDebug2("Last Message Time2 = %u" ,pTempTimeStamp->LogTime2);
#endif

memcpy((CHAR*)&pMrequest->fExchSeqNum ,pTempTimeStamp , sizeof(struct NNF_DOUBLE_INT) ); 
logDebug2("Sequence Number	:	%lf",pMrequest->fExchSeqNum);

#ifdef     DBG
logDebug2("proc_progN.pc THIS IS THE MESSAGE DOWNLOAD PROCESS ");
#endif
	 ****/
	//	pMrequest->fExchSeqNum =1186559835;    
	pMrequest->pHeader.iReserved = 0 ;
	pMrequest->pHeader.iLogTimeStamp = 0 ;
	memset(pMrequest->pHeader.sAlphaSplit," ",ALPHA_SPLIT_LEN);
	*(pMrequest->pHeader.sAlphaSplit) = iStream;
	pMrequest->pHeader.iMsgCode = TC_NSE_MSG_DOWNLOAD_REQ;
	pMrequest->pHeader.iErrorCode = 0 ;
	memset(pMrequest->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pMrequest->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pMrequest->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pMrequest->pHeader.iMsgLength = sizeof(struct NNF_MSG_DOWNLOAD_REQ);

	pMrequest->fExchSeqNum = 0;	
#ifdef     DBG
	logDebug2("proc_progN.pc The Sequence No is %lf ",pMrequest->fExchSeqNum);
	logDebug2("proc_progN.pc The transcode is %d ",pMrequest->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pMrequest->pHeader.iMsgLength);
	logDebug2("proc_progN.pc MESG_DOWN_REQ ::: before send ");
#endif
	TWIDDLE(pMrequest->pHeader.iLogTimeStamp);
	TWIDDLE(pMrequest->pHeader.iMsgCode);
	/**	TWIDDLE(pMrequest->sHeader.MsgLength);	**/
	TWIDDLE(pMrequest->pHeader.iErrorCode);	
	TWIDDLE(pMrequest->fExchSeqNum);

	memcpy(cNNF,pMrequest,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

	free(pMrequest);
	free(pTempTimeStamp);

	/***	if (sqlca.sqlcode == 0 )
	  return TRUE;
	  else****/
	logTimestamp("Exit : fSendmessage");
	return TRUE;

}

void	fSend_exch_down_nse(LONG32 iGroupid)
{
	logTimestamp("Entry : fSend_exch_down_nse");

	CHAR	*cError,*cMsg;
	//        CHAR 	status;
	CHAR 	sProgTime[40];

	memset(sProgTime,'\0',40);

	struct	NNF_HEADER	*pHeader;
	LONG32 	iQid , iWait_status, iQid1 , iWrite_status , iTemplen , iQueueId;
	struct 	NNF_DOUBLE_INT	*pTempTimeStamp;

	//	ULONG32	TempTime1;
	//        ULONG32 TempTime2;

	cError = (CHAR *)malloc(sizeof(CHAR)*80);
	cMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);

	pTempTimeStamp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));

#ifdef	DBG
	logDebug2("IN FUNCTION send_exch_down_nse with groupid %d ",iGroupid );
#endif

	fGetTime(sProgTime);
	fUpdateConnectStatus(NSE_EQU_DOWN, iGroupid);
	logDebug2("[%s] IST :EXCHANGE DOWN TIME",sProgTime);
	/*****
	  switch(iGroupid)
	  {
	  ---- Code to choose Queue from Group Id ---
	 ** Reentered for M CTCL *
	 case 1 : iQueueId = EquRmsNseToNSE1 ;          
	 break;
	 case 2 : iQueueId = EquRmsNseToNSE2 ;
	 break;
	 case 3 : iQueueId = EquRmsNseToNSE3 ;
	 break;
	 case 4 : iQueueId = EquRmsNseToNSE4 ;
	 break;	
	 default : break;
	 };

	 ****/
	iQueueId = MapperToConnNSEEQ;
	iQid = OpenMsgQ(iQueueId);

	if ( iQid < 0 )
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR : in OpenMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}

	logDebug2("Opened...");	
	iQid1 = OpenMsgQ( ConnToTrdMapNSEEQ);

	if ( iQid1 < 0 )
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR : in OpenMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}

	logDebug2("Opened...");

	for ( ;; )
	{
		logDebug2("b4 read NBQ = %d ",iQid);
		/***  iWait_status = ReadMsgQ( iQid , cMsg , NSE_PACKET_SIZE, 1);*****/
		iWait_status = ReadNBQ( iQid , cMsg , NSE_PACKET_SIZE, 1);
		logDebug2("after read NBQ");

		if ( iWait_status == TRUE )
		{
			pHeader = (struct NNF_HEADER *)cMsg;
			TWIDDLE(pHeader->iMsgCode);
			TWIDDLE(pHeader->iMsgLength);
			iTemplen  = pHeader->iMsgLength;

			logDebug2("SENDING EXCHANGE DOWN ERROR for Transcode %d",pHeader->iMsgCode);

			/** Same structures are used in Exch Request/Response, so we modify only the Msgcode. **/
			switch(pHeader->iMsgCode)
			{
				case TC_INT_ORDER_ENTRY_REQ: 
					//pHeader->iMsgCode = TC_INT_OE_ERROR_RESP;
					((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OE_ERROR_RESP;
					break;

				case TC_INT_ORDER_MODIFY: 
					//pHeader->iMsgCode = TC_INT_OM_ERROR_RESP;
					((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OM_ERROR_RESP;
					break;

				case TC_INT_ORDER_CANCEL: 
					//pHeader->iMsgCode = TC_INT_OC_ERROR_RESP;
					((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OC_ERROR_RESP;
					break;
					/**
					  case TC_EQU_NSE_TRADE_MOD_REQ: pHeader->iMsgCode = TC_EQU_NSE_TRADE_MOD_REJECT_RESP;
					  break;

					  case TC_EQU_NSE_TRADE_CAN_REQ: pHeader->iMsgCode = TRADE_CAN_REJECTION;
					  break;
					  case TC_EQU_NSE_INDEX_OE_REQ: pHeader->iMsgCode = INDEX_ORDER_REJECTION;
					  break;
					 ***/
				default : 
					break;
			}

			//pHeader->iErrorCode = EXCHANGE_DOWN_ERROR;
			((struct NNF_HEADER *)cMsg)->iErrorCode = EXCHANGE_DOWN_ERROR;

			/******     Patch for junk timestamp in the response packet     ******/

			/******            EXEC    SQL     SELECT
			  nvl(EAM_LAST_MSG_TIME,0),
			  nvl(EAM_LAST_MSG_TIME1,0)
			  INTO
			  :TempTime1,
			  :TempTime2
			  FROM            EXCH_ADMINISTRATION_MASTER
			  WHERE           EAM_EXM_EXCH_ID = 'NSE'         AND
			  EAM_GROUP_ID    = :iGroupid      AND
			  EAM_DRV_FLAG    = 'N' ;


			  if(sqlca.sqlcode != 0)
			  {
			  logDebug2("\n Error in selecting EAM_LAST_MSG_TIME(1) from EAM: %d", sqlca.sqlcode);
			  }
			 *******/
			pTempTimeStamp->LogTime1 = 3208380416;
			pTempTimeStamp->LogTime2 = 1700411950;

			TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgLength);
			TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgCode);
			TWIDDLE(((struct NNF_HEADER *)cMsg)->iErrorCode);

			memcpy((CHAR *)pHeader->sTimeStamp2 , pTempTimeStamp , sizeof(struct NNF_DOUBLE_INT));

			logDebug2("TempTimeStamp->LogTime1 = %u", pTempTimeStamp->LogTime1);
			logDebug2("TempTimeStamp->LogTime2= %u", pTempTimeStamp->LogTime2);

			iWrite_status = WriteMsgQ(iQid1,cMsg,iTemplen,1);
			if ( iWrite_status < 0)
			{
				logDebug2("inside WriteMsgQ ");
				memset(cError,NULL,80);
				strcpy(cError,"ERROR in WriteMsgQfunction : Queue.c");
				logDebug2("%s",cError);
				free(cError);
				free(cMsg);
				exit(ERROR);
			}
			/**
			  else
			  {
			  free(cError);
			  free(cMsg);
			  }
			 ***/
		}
		else
		{
			//	free(cError);
			//	free(cMsg);
			break;
		}
	}
	free(cError);
	free(cMsg);

	logTimestamp("Exit : fSend_exch_down_nse");	
}

void	fDeal_with_error_response_nse( CHAR *cGetError )
{
	logTimestamp("Entry : fDeal_with_error_response_nse");

	struct	NNF_ERROR_RESP	*pErr;

	//	INT16	count =0;
	//        INT16   TempCode;
	//        CHAR 	TempUserId[ EQU_NSECONN_USER_ID_LEN ];
	CHAR 	sTempErrorMesg[NSE_PACKET_SIZE];
	CHAR 	sTempSeries[SERIES_LEN];
	CHAR 	sTempSymbol[SYMBOL_LEN];

	pErr = (struct NNF_ERROR_RESP *)malloc(sizeof(struct NNF_ERROR_RESP));

	memcpy(pErr,cGetError,sizeof(struct NNF_ERROR_RESP));
	memcpy(sTempErrorMesg,pErr->sErrorString,ERROR_MSG_LEN);
	memcpy(sTempSeries,pErr->pSecInfo.sSeries,SERIES_LEN);
	memcpy(sTempSymbol,pErr->pSecInfo.sSymbol,SYMBOL_LEN);

	/**	TempCode = err->sHeader.ErrorCode;
	  TempErrorMesg= ERROR_STRING_LEN;
	  sTempSeries= SERIES_LEN;
	  sTempSymbol= SYMBOL_LEN;
	 ***/
	logDebug2("Test : I am here ");
	free(pErr);
	logTimestamp("Exit : fDeal_with_error_response_nse");

}

void	fDeal_with_message_nse( CHAR *cData )
{
	logTimestamp("Entry : fDeal_with_message_nse");

	CHAR 	sTempData[NSE_PACKET_SIZE];
	INT16   iTempCode;
	CHAR 	sTempUserId[ EQU_NSECONN_USER_ID_LEN ];
	CHAR 	sTempSeries[SERIES_LEN];
	CHAR 	sTempSymbol[SYMBOL_LEN];

	memset(sTempData,' ',NSE_PACKET_SIZE);
	memset(sTempUserId,' ',EQU_NSECONN_USER_ID_LEN);
	memset(sTempSeries,' ',SERIES_LEN);
	memset(sTempSymbol,' ',SYMBOL_LEN);
	memcpy(sTempData,cData,NSE_PACKET_SIZE);
	//sTempData= NSE_PACKET_SIZE;
	iTempCode = 0;
	memcpy(sTempSymbol,"EXCH-MSG",8);
	memcpy(sTempSeries,"__",2);

	logTimestamp("Exit : fDeal_with_message_nse");

}


BOOL 	fGet_mesg_or_error_nse(CHAR *cMsgbuf)
{
	logTimestamp("Entry : fGet_mesg_or_error_nse");

	struct	NNF_HEADER      *pHeader;
	struct  NNF_ORDER_ENTRY *pOrders;
	struct 	NNF_EXCH_MSG_TO_TRADER_RESP *pResp;
	CHAR    *cData;
	BOOL    iFlag;

	cData = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	pOrders = (struct NNF_ORDER_ENTRY *)malloc(sizeof(struct NNF_ORDER_ENTRY));
	pResp = (struct NNF_EXCH_MSG_TO_TRADER_RESP *)malloc(sizeof(NNF_EXCH_MSG_TO_TRADER_RESP));

	memcpy(pHeader,cMsgbuf,sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iErrorCode);
	TWIDDLE(pHeader->iMsgLength);
	TWIDDLE(pHeader->iMsgCode);
	TWIDDLE(pHeader->iLogTimeStamp);

	logDebug2("NOTE :: ReasonCode is : %d", ((struct  NNF_ORDER_ENTRY *)&cMsgbuf)->iReasonCode );
	logDebug2("NOTE :: Exch...Header->ErrorCode is : %d", pHeader->iErrorCode);

	if ( (pHeader->iErrorCode != 0)  && (pHeader->iMsgLength == sizeof(struct NNF_ERROR_RESP)) )
	{
		logDebug2("There is some error %d ", pHeader->iErrorCode );
		fDeal_with_error_response_nse( cMsgbuf );
		iFlag = TRUE;  
	}
	else
	{
		/***
		  switch(pHeader->iMsgCode)
		  {
		  case    TC_EQU_NSE_EXCH_MSG_TO_TRADER_RESP :
		  memset(cData,NULL,NSE_PACKET_SIZE);
		  memcpy(resp,cMsgbuf,sizeof(struct NNF_EXCH_MSG_TO_TRADER_RESP));
		  TWIDDLE(resp->iTraderId); 
		  logDebug2("\nNitesh here ");
		  logDebug2("Trader id = %d ,Action Code = %s , Broad Cast message %s",resp->iTraderId,resp->sActionCode,resp->sBcastMsg);
		  slogDebug2(cData,"Trader id = %d ,Action Code = %s , Broad Cast message %s",resp->iTraderId,resp->sActionCode,resp->sBcastMsg);
		  logDebug2("\nPimpale");
		  iFlag = TRUE;
		  break;

		  case    TC_EQU_NSE_NEG_ORDER_ENTERED_BY_CP_RESP :
		  memset(cData,NULL,NSE_PACKET_SIZE);
		  memcpy(orders,cMsgbuf,sizeof(struct NNF_ORDER_ENTRY));
		  TWIDDLE(orders->fOrderNum); 
		  slogDebug2(cData,"BrokerCode= %s, Counter Party Broker Code= %s, Security-Symbol= %s, OrderNum= %lf ",orders->sBrokerCode,orders->sCPBrokerCode,orders->pSecInfo.sSymbol,orders->fOrderNum);
		  iFlag = TRUE;
		  break;

		  case    TC_GENERAL_MSG_BCAST :
		  memset(cData,NULL,NSE_PACKET_SIZE);
		  memcpy(resp,cMsgbuf,sizeof(struct NNF_EXCH_MSG_TO_TRADER_RESP));
		  TWIDDLE(resp->iTraderId);   
		  slogDebug2(cData,"Trader id = %d ,Action Code = %s , Broad Cast message %s",resp->iTraderId,resp->sActionCode,resp->sBcastMsg);
		  iFlag = TRUE;
		  break;


		  default  :      iFlag = FALSE;
		  break;

		  };
		 ***/
		if ( iFlag == TRUE )
			fDeal_with_message_nse( cData );

	}

	free(cData);
	free(pHeader);
	free(pOrders);
	free(pResp);
	logDebug2("Test : I am REturning  %d ", iFlag);
	logTimestamp("Exit : fGet_mesg_or_error_nse");
	return(iFlag);

}		


void	fSend_exch_down_buf_nse(LONG32 iGroupid,CHAR * cMsg)
{
	logTimestamp("Entry : fSend_exch_down_buf_nse");

	CHAR	*sMessageLog="MessageLog";
	CHAR 	*cError;
	//        CHAR 	status;

	struct 	NNF_HEADER	*pHeader;

	LONG32	iQid , iWait_status, iQid1 , iWrite_status , iTemplen;
	cError = (CHAR *)malloc(sizeof(CHAR)*80);

	iQid1 = OpenMsgQ( ConnToTrdMapNSEEQ);

	if ( iQid1 < 0 )
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR : in OpenMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}

	pHeader = (struct NNF_HEADER *)cMsg;

	TWIDDLE(pHeader->iMsgCode);
	TWIDDLE(pHeader->iMsgLength);

	iTemplen  = pHeader->iMsgLength;

	switch(pHeader->iMsgCode)
	{
		case TC_INT_ORDER_ENTRY_REQ:
			//pHeader->iMsgCode = TC_INT_OE_ERROR_RESP;
			((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OE_ERROR_RESP;
			break;

		case TC_INT_ORDER_MODIFY:
			//pHeader->iMsgCode = TC_INT_OM_ERROR_RESP;
			((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OM_ERROR_RESP;
			break;

		case TC_INT_ORDER_CANCEL:
			//pHeader->iMsgCode = TC_INT_OC_ERROR_RESP;
			((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OC_ERROR_RESP;
			break;
		default :
			break;
	}
	((struct NNF_HEADER *)cMsg)->iErrorCode = EXCHANGE_DOWN_ERROR;

	TWIDDLE(((struct NNF_HEADER *)cMsg)->iErrorCode);
	TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgLength);
	TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgCode);

	iWrite_status = WriteMsgQ(iQid1,cMsg,iTemplen,1);
	if ( iWrite_status < 0)
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR in WriteMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}
	free(cError);
	logTimestamp("Exit : fSend_exch_down_buf_nse");

}

BOOL	fOpenBcastSocket()
{
	logTimestamp("Entry : fOpenBcastSocket");

	LONG32	iOptval=1;
	LONG32  iVal;

	if ( (iSockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}

	iVal = setsockopt(iSockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&iOptval,sizeof(iOptval));

	if ( iVal < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	logTimestamp("Exit : fOpenBcastSocket");
	return TRUE;

}

BOOL 	fInsertExchDigital( )
{
	logTimestamp("Entry : fInsertExchDigital");

	SHORT   iNoStreams =0, j=0;
	LONG32  iGroupId=0;
	SHORT   iStreamId =0;
	//        ULONG32 Time1 =0;
	//        ULONG32 Time2 =0 ;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	LONG32	iNumRow;

	CHAR	*sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	CHAR	*sInsQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	logDebug2("iGlobGroupId : %d iTotalStream :%d ", iGlobGroupId, iTotalStream);
	iGroupId =iGlobGroupId;
	iNoStreams = 3;//iTotalStream ;
	logDebug2("Local iGroupId : %d", iGroupId);

	logDebug2("===========iGlobGroupId [%d]== iTotalStream [%d]==",iGroupId, iNoStreams);
	for ( j=1 ; j <= iNoStreams; j++)
	{
		iStreamId = j;

		sprintf(sSelQry,"SELECT * FROM EXCH_DOWNLOAD_DATA\
				WHERE EDD_STREAM_ID = %d \
				AND EDD_EXCH_ID=\"%s\"\
				AND EDD_SEGMENT=\'%c\'\
				AND EDD_GROUP_ID=%d ;",iStreamId,NSE_EXCH,EQUITY_SEGMENT,iGroupId);		
			logDebug2("sSelQry :%s:",sSelQry);	

		if(mysql_query(DBConNNF,sSelQry) != SUCCESS)
		{
			sql_Error(DBConNNF);	
			return FALSE;
		}

		Res = mysql_store_result(DBConNNF);	

		iNumRow = mysql_num_rows(Res);	

		logDebug2("NumRow :%d: StreamId:%d:",iNumRow,iStreamId);

		if(iNumRow == 0)
		{
			sprintf(sInsQry,"INSERT INTO  EXCH_DOWNLOAD_DATA(\ 
				EDD_GROUP_ID,\
				EDD_EXCH_ID,\
				EDD_SEGMENT,\
				EDD_STREAM_ID,\
				EDD_TIMESTAMP1,\
				EDD_TIMESTAMP2)\
					VALUES (\
						%d,\
						\"%s\",\
						\'%c\',\
						%d,\
						0,\
						0 );",iGroupId,NSE_EXCH,EQUITY_SEGMENT,iStreamId);	

					logDebug2("sInsQry :%s:",sInsQry);
			if(mysql_query(DBConNNF,sInsQry) != SUCCESS)
			{
				sql_Error(DBConNNF);
				return FALSE;
			}	
			else
			{
				mysql_commit(DBConNNF);
			}
		}
		mysql_free_result(Res);

	}

	free(sSelQry);
	free(sInsQry);
	logTimestamp("Exit : fInsertExchDigital");
	return TRUE ;

}


LONG32	fGetTotalStream()
{
	logTimestamp("Entry : fGetTotalStream");

	CHAR    *sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	LONG32	iStream;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32	iGroupId = 0;

	iGroupId =iGlobGroupId;

	sprintf(sSelQry,"SELECT max(EDD_STREAM_ID) \
			FROM EXCH_DOWNLOAD_DATA \
			WHERE  EDD_EXCH_ID=\"%s\"\
			AND EDD_SEGMENT=\'%c\'\
			AND EDD_GROUP_ID=%d;",NSE_EXCH,EQUITY_SEGMENT,iGroupId );		

		logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConNNF,sSelQry) != SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConNNF);

	if(Row = mysql_fetch_row(Res))
	{
		iStream = atoi(Row[0]);
	}

	logTimestamp("Exit : fGetTotalStream");
	return iStream;

}

BOOL    fUpdateTimeStamp(struct  NNF_DOUBLE_INT *pTempTimeStamp )
{
	logTimestamp("Entry : fUpdateTimeStamp");

	CHAR	*sUpdateQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	SHORT   j;
	LONG32  iGroupId=0;
	SHORT   iStreamId =0;
	ULONG32 iTime1 =0;
	ULONG32 iTime2 =0 ;
	logDebug2(" iGlobGroupId : %d", iGlobGroupId);
	iGroupId =iGlobGroupId;
	logDebug2("Local GroupId : %d", iGroupId);

	logDebug2("===========GlobGroupId [%d]====Updating  Timestamp ",iGroupId);
	/***
	  for ( j=1 ; j <= iTotalStream; j++)
	  {
	  iStreamId = Msg_Dow_Data[j].Stream_Id ;
	  iTime1     = Msg_Dow_Data[j].TimeStamp1 ;
	  iTime2     = Msg_Dow_Data[j].TimeStamp2 ;

	  logDebug2("iStreamId : %d Time1 :%u Time2 :%u ", iStreamId, iTime1, iTime2);
	  }
	 **/
	sprintf(sUpdateQry,"UPDATE EXCH_ADMINISTRATION_MASTER SET EAM_LAST_MSG_TIME = %u,EAM_LAST_MSG_TIME1 = %u  WHERE EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\' AND EAM_GROUP_ID = %d",pTempTimeStamp->LogTime1,pTempTimeStamp->LogTime2,NSE_EXCH,EQUITY_SEGMENT,iGroupId);	

	logDebug2("sUpdateQry :%s:",sUpdateQry);

	if(mysql_query(DBConNNF,sUpdateQry) != SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}
	else
	{
		mysql_commit(DBConNNF);
		return TRUE;
	}	

	logTimestamp("Exit : fUpdateTimeStamp");

}

/****

  void convert_seconds_to_date(long seconds,CHAR *pDateTime)
  {
  struct tm *tmr;

  time_t julian;


  tmr = (struct tm *) malloc (sizeof(struct tm )) ;
  julian = seconds + OFFSET - TIMEZONE;
  localtime_r(&julian,tmr);
//    slogDebug2(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_mday, tmr->tm_mon+1,tmr->tm_year+1900,tmr->tm_hour ,tmr->tm_min  ,tmr->tm_sec );
slogDebug2(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_year+1900,tmr->tm_mon+1,tmr->tm_mday,tmr->tm_hour,tmr->tm_min  ,tmr->tm_sec );
free(tmr);

}
SHORT  fTrim( CHAR *string , SHORT MaxLen )
{
logTimestamp("Entry : [fTrim]");

SHORT index=0;
if ( MaxLen <= 0 )
return 0 ;

for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
continue;

string[index]='\0';
logTimestamp("Exit : [fTrim]");
return index ;
}
 ***/
