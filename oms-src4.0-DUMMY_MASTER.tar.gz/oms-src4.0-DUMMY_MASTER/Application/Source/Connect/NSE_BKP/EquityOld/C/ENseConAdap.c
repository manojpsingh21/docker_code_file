#include "IPCS.h"
#include "NNFStruct.h"
#include <memory.h>
#include <time.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

void	fConvertSeqNO(CHAR *, CHAR *);
//#define 	CALLING_LENS	20
//#define TWIDDLE(A)      Twiddle ((char *) &A, sizeof(A))
void	fUpdateTimeStamp(struct  NNF_DOUBLE_INT                  *pTempTimeStamp ) ;
void   	fExit( LONG32 );
BOOL   	fUpdateConnectStatus(SHORT,LONG32);//,LONG32,BOOL);
void   	fInitSharedMemory(LONG32); 
LONG32 	iGlobGroupId;
key_t  	iGlobQueueId;
LONG32  iSockfd1;
LONG32  iConnectToExchange =1;               
FILE 	*fpOrderNum;

SHORT 	iConnectionCounter=0;
SHORT 	iCounterTotalInvite=0;
SHORT 	iCounterTotalTransmit=0;

SHORT 	iTotalStream = 0;  
LONG32 	iTransmitSeq =0, iRecieveSeq =0 ; 
CHAR    sKey[DB_KEY_LEN];        
CHAR    sProgName[15] = "NseCMConnect";
MYSQL 	*DBConNNF;                                                  
LONG32  iMainwait = -1;
LONG32  iRespChild,iransChild;
LONG32	iSleepTime;
LONG32  iBusyTimer = 0;
CHAR	sPrimTAPip[CALLING_LENS];
CHAR	sSecoTAPip[CALLING_LENS];
LONG32	iPrimTAPport;
LONG32	iSecoTAPport;
	

main( LONG32 argc, CHAR **argv )
{
	logTimestamp("Entry : Main");

	//	LONG32	iFailoverCounter=0; 
	LONG32 	iPrimarySecondary=0;
	LONG32 	iRespChild,iTransChild,iInvitationChild,iStatus,iTransKill = -1;
	//	LONG32 	iInvitationChild,iStatus,iTransKill = -1;
	LONG32 	iSig1 = 0,iSig2 = 0; 
	LONG32 	iFlag;
	LONG32 	iFla;
	LONG32 	iFl;
	LONG32 	iGroupId ;
	LONG32 	iTapPort[2]; 
	CHAR 	sTapIp[2][CALLING_LENS];
	CHAR 	sConnectOption[5];   
	LONG32 	iNSE_CONNECTED_STATUS = FALSE;
	//	LONG32 	iConnectCode = 0;
	//	LONG32 	iSeqNo = 0;
	LONG32 	iMaxPacketCount,iInvFlag = FALSE; 
	CHAR 	cDummyChar;
	LONG32 	iDummy;
	CHAR 	sProgTime[40];
	CHAR    sBusyTimer[10];

	memset(sProgTime,'\0',40);
	memset(sBusyTimer,'\0',10);
	memset(sPrimTAPip,'\0',CALLING_LENS);
	memset(sSecoTAPip,'\0',CALLING_LENS);

	//     	CHAR	sRetCode[50];
	//    	CHAR	sRetString[50];        
	//	CHAR	lvar_uid[30];
	//      LONG32 	seqval;  

	sigset_t	SequenceSet;  				/* Signal set containing SIGUSR1 , SIGUSR2 , SIGTERM */
	CHAR	*cError;

	setbuf(stdout,NULL);
	setbuf(stderr,NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );    			/* Signal functions initialization */

	cError = (char *)malloc(sizeof(char)*SIZE);
	memset(sKey,'\0',DB_KEY_LEN);	
	fGetTime(sProgTime);

	logTimestamp("--------------------------Started NSE EQ Connect-----------------------------------------------");

	if ( argc < 8 )
	{
		logTimestamp(" Invalid number of arguments");
		exit(ERROR);				
	}

	strcpy(sConnectOption,argv[1]);
	iGroupId = atoi(argv[2]);
/**
	strcpy(sTapIp[0],argv[3]); 
	iTapPort[0] = atoi ( argv[4]); 
	strcpy(sTapIp[1],argv[5]); 
	iTapPort[1] = atoi ( argv[6]);
**/
	strcpy(sPrimTAPip,argv[3]); 
	iPrimTAPport = atoi ( argv[4]); 
	strcpy(sSecoTAPip,argv[5]); 
	iSecoTAPport = atoi ( argv[6]);
	
	iSleepTime = atoi(argv[7]); // This is in seconds 

	if(getenv("NEQ_SLEEP_TIME") == NULL)
        {
                logInfo("NEQ_SLEEP_TIME not Define in ENV");
                iBusyTimer = 40000;
        }
        else
        {
                strncpy(sBusyTimer,getenv("NEQ_SLEEP_TIME"),10);
                if(strlen(sBusyTimer) == 0)
                {
                        logInfo("NEQ_SLEEP_TIME Define with srlen zero");
                        iBusyTimer = 40000;
                }
                else
                {
                        logInfo("NEQ_SLEEP_TIME Define with value :%s:",sBusyTimer);
                        iBusyTimer = atoi(sBusyTimer);
                }
        }

	if(strncmp(sConnectOption,"EXCH", 4 )==0)
	{
		iConnectToExchange = 1;
	}
	else
	{
		iConnectToExchange = 0;
	}

	iGlobGroupId = iGroupId ;
	if (( iGroupId <= 0 ) || (iGroupId > 4))
	{
		logError("NSE EQ Connect:  Wrong GroupId ");                
		exit(ERROR);
	}

	logInfo("------------------- PARAMETERS PASSED ----------");
	logInfo("ConnectOption 				: [%s]", sConnectOption ) ;
	logInfo("Groupid is 					: [%d]", iGroupId);
	logInfo("sTapIp 					: [%s]", sPrimTAPip ) ; 
	logInfo("sTapIp Failover				: [%s]", sSecoTAPip ) ; 
	logInfo("iTapPort  					: [%d]", iPrimTAPport ) ; 
	logInfo("iTapPort Failover				: [%d]", iSecoTAPport ) ; 
	logInfo(" DB_AES_KEYS : %s", getenv("DB_AES_KEYS") ) ;
	logInfo("------------------------------------------------");

	strcpy(sKey,getenv("DB_AES_KEYS"));

	/******		switch(iGroupId)
	  {
	  case 1 : GlobQueueId = EquRmsNseToNSE1;        
	  break;
	  case 2 : GlobQueueId = EquRmsNseToNSE2;
	  break;
	  case 3 : GlobQueueId = EquRmsNseToNSE3;
	  break;
	  case 4 : GlobQueueId = EquRmsNseToNSE4;
	  break;
	  default : break;
	  };******/

	iGlobQueueId = MapperToConnNSEEQ;

	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGTERM);
	sigaddset ( &SequenceSet , SIGUSR1);


	/****	EXEC SQL CONNECT :lvar_uid ;****/
	/****		if ( sqlca.sqlcode != 0 )
	  {
	  logDebug2 ("\nEquNseConnect.pc Error in connecting to oracle %d",sqlca.sqlcode);	
	  fGetTime(sProgTime);
	  logDebug2("\nThe Process Ended at [%s] IST\n",sProgTime);
	  exit(ERROR);
	  }******/

	DBConNNF = DB_Connect();
	logInfo("Connection to DB SUCCESS......"); 

	fpOrderNum = fopen("../OrderNum.txt","a+" ) ;
	if( fpOrderNum == NULL )
	{
		logError(" UNABLE TO OPEN FILE " ) ;
	}


	for ( ; ; )						
	{
		iNSE_CONNECTED_STATUS = FALSE;
		signal(SIGPIPE,SIG_IGN);
		signal(SIGHUP,SIG_IGN);
		for ( ; ; )
		{
			fInitSharedMemory(iGroupId); /** Added for inv initialization **/
		//	iSockfd1  =CONNECT( sTapIp[iPrimarySecondary] , iTapPort[iPrimarySecondary]  );
			iSockfd1 = tcpConnect(iPrimarySecondary);
			if (iSockfd1 <= 0 )
			{
				iNSE_CONNECTED_STATUS = FALSE;
				memset(cError,NULL,SIZE);
				strcpy(cError,"FATAL ERROR .... NO SOCKET CONNECTION .... ");

				fSend_exch_down_nse( iGroupId );

				sleep(2);
				iPrimarySecondary=(iPrimarySecondary==1)?0:1;
			}
			else
			{
				iNSE_CONNECTED_STATUS =TRUE;
				iFlag=100000;
				iFla=100000;
				iFl=1;
				if (setsockopt( iSockfd1 ,SOL_SOCKET,SO_RCVBUF,&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:SO_  RCVBUF");
					return FALSE;
				}
				if (setsockopt( iSockfd1 ,SOL_SOCKET,SO_SNDBUF,&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:SO_SNDBUF");
					return FALSE;
				}


				/*************** TAP Reg Changes*******************/  
				iTransmitSeq =0; 
				iRecieveSeq  =0;  	
				logDebug2("Sequence Number Transmit is [%d]", iTransmitSeq);
				logDebug2("Sequence Number Recieve is [%d]", iRecieveSeq); 
				/************ END of TAP Reg Changes*******************/

				fGetTime(sProgTime);

				logDebug2("Before Calling fHandleSignon at [%s] IST",sProgTime);

				if (fHandleSignon(iGroupId) == TRUE)	
				{
					if ( (iRespChild = fork()) == 0 )
					{
						fGetTime(sProgTime);
						iRespChild = getppid();
						logDebug2("RespChild PID :%d:",iRespChild);
						logDebug2("Before Receive Packet at [%s] IST",sProgTime);
						fReceiveReplyPackets(iSockfd1,iGroupId);
					}
					else if( ( iTransChild = fork() ) == 0 )
					{
						fGetTime(sProgTime);
						iTransChild = getppid();
						logDebug2("TransChild PID :%d:",iTransChild);

						logDebug2("Before Receive Packet at [%s] IST",sProgTime);
						fTransmitRequestPackets(iGroupId);
					}	
					break;/*** break infinite for loop if signon true ***/	
				}
				else
				{
					close(iSockfd1);
					logDebug2("------------------------------------------- Signon problem ");
					logDebug2("Reconnect Attempt  [%d]---------------  ",iConnectionCounter); 

					fGetTime(sProgTime);

					logDebug2("The Process Ended at [%s] IST",sProgTime);
					if( iConnectionCounter ==  2 )
					{       
						logDebug2(" Switch over to Fail over Server");
						iConnectionCounter = 0;	
						iPrimarySecondary=(iPrimarySecondary==1)?0:1;
						sleep(10); 	
					}	
					sleep(15);
				}
			} /**End of else **/

		} /**end of inner for loop **/		



		while( TRUE )
		{
			iTransKill = -1;
			iSig1 = 0;
			sigemptyset ( &SequenceSet );
			sigaddset ( &SequenceSet , SIGTERM);
			sigaddset ( &SequenceSet , SIGUSR1);
			sigaddset ( &SequenceSet , SIGUSR2);
			sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);

			logDebug2("Waiting for signal, in loop.");
#ifdef SOLARIS
			iMainwait = sigwait( &SequenceSet);
			iSig1 = iMainwait ;
			logDebug2("=============Recv Signal : %d, Sig1:%d==============", iMainwait , iSig1 );
#else
			iMainwait = sigwait( &SequenceSet, &iSig1);
			logDebug2("=============Recv Signal : %d, Sig1:%d==============", iMainwait , iSig1 );
#endif 
			logDebug2("==================Recv Signal : %d, Sig1:%d==============", iMainwait , iSig1 );
			logDebug2("================= Sockfd1 [%d] ============= ");

			//close(iSockfd1);    /*** Dicuss***/

			if (iMainwait >= 0 && iSig1 != SIGTERM)
			{
				logDebug2("Got Mainwait >= 0, Sig1: %d", iSig1 );
				iTransKill = kill(iTransChild,iSig1);
				logDebug2("Return value from KILL : %d", iTransKill );

				iTransKill = kill(iRespChild,iSig1);
				logDebug2("Return value from KILL : %d", iTransKill );
				perror ( "After kill to TransChild: ");
				if (iTransKill < 0)
				{
					logDebug2("EquNseConnect.pc Fatal error in sending signal %d",iTransKill);
					memset(cError,NULL,SIZE);
					strcpy(cError,strerror(errno));
					exit(ERROR);
				}
			}	
			else if ( iSig1 == SIGTERM )	
			{
				/****	EXEC SQL CONNECT :lvar_uid ;*****//**nitish***/
				/****	logDebug2("\n************Error in Connecting: %d", sqlca.sqlcode );******/
				logDebug2(" starting fall over mechanism ");
				logDebug2("  the group id is [%d] ", iGlobGroupId );
				/****	EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
				  SET  EAM_LOGON_STATUS = 'N'
				  WHERE EAM_EXM_EXCH_ID = 'NSE'
				  AND EAM_DRV_FLAG = 'N'
				  AND EAM_GROUP_ID = to_char(:iGlobGroupId);*****/

				/*******                        logDebug2("nError in Updating: %d", sqlca.sqlcode );
				  EXEC SQL COMMIT;******/

				//fUpdateConnectStatus(NSE_EQU_DOWN, iGlobGroupId);// ,BCAST_YES,FALSE);
				fConnectUpdt(NSE_EQU_DOWN, iGlobGroupId,0);// ,BCAST_YES,FALSE);

				fSend_exch_down_nse( iGlobGroupId );

				logDebug2("Databse and shared memory updated and broadcast sent ");
				kill(iTransChild,SIGKILL);
				kill(iRespChild,SIGKILL);
				sleep(3);
				waitpid(iTransChild,&iStatus,WNOHANG);
				waitpid(iRespChild,&iStatus,WNOHANG);
				close(iSockfd1);
				break;
			}
			else if(iSig1 == SIGCHLD)
			{
				logDebug2(" Killing Children ");
				kill(iTransChild,SIGKILL);/* To exit from the program b'coz of signal error */
				kill(iRespChild,SIGKILL);
				exit(ERROR);
			}
		}/** End of While loop ***/
	}	 /**End of for loop **/
	free(cError);
	fclose(fpOrderNum);
	logTimestamp("Exit : Main");
}	/* End of main function */


LONG32 	fHandleSignon(LONG32 iGroupId)
{
	logTimestamp("Entry : fHandleSignon");

	CHAR	*cSendsign;
	CHAR   	sRecvsign[NSE_PACKET_SIZE];
	LONG32	iSent_bytes,iRecv_bytes,iLog_result;
	LONG32 	iInv_flag = FALSE;
	CHAR   	cDummyChar;
	LONG32 	iDummy;
	CHAR 	sError[SIZE];
	CHAR 	sFerror[SIZE];
	LONG32 	iTemp_code,iTemp_size,iInvFlag;
	LONG32  iSeqNo;
	LONG32  iUserID;

	CHAR 	*cBdata;
	LONG32 	iBlen;
	//   	SHORT 	iInvCount;
	CHAR 	*cSendsignTAP;

	sigset_t	SequenceSet;

	LONG32	iInvPacketCount;
	//	unsigned CHAR sDigest[16];
	UCHAR sDigest[16];

	struct	TAP_WRAPPER		*pTap_wrap;
	struct 	NNF_HEADER 		*pHeader;
	struct 	INVITATION_PACKET 	*pInv_packet;
	struct 	InvitationCount 	*pInvcount;
	CHAR 	sProgTime[40];

	memset(sProgTime,'\0',40);
	INT16  	iErrMsgCode;
	/******        varchar lvar_uid[30];
	  VARCHAR sConErrMsg[128];
	  INT16   iErrMsgCode;

	  memset(sConErrMsg.arr,'\0',128) ;
	  sConErrMsg.len=128;******/

	LONG32 iSig1 = 0;
	sigemptyset( &SequenceSet );
	sigaddset( &SequenceSet , SIGUSR1);
	sigaddset( &SequenceSet , SIGUSR2);                /* Signal function Initialization */
	sigprocmask( SIG_BLOCK, &SequenceSet, NULL);

	cSendsign = (char *)malloc(sizeof(struct NNF_SIGNON_REQ));
	pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTap_wrap,'\0',sizeof(struct TAP_WRAPPER));
	pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
	memset(pHeader,'\0',sizeof(struct NNF_HEADER));
	cSendsignTAP = (char *)malloc(sizeof(struct NNF_SIGNON_REQ) + sizeof(struct TAP_WRAPPER));
	/*******
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=sizeof(lvar_uid.arr);

	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  memset(error,NULL,SIZE);
	  sprintf(error,"EquNseConAdapter.pc Error in connecting to oracle ");
	  exit(ERROR);
	  }*******/
	logInfo("TRANSMIT CHILD Connction to Oracle SUCCESS......      ");

	logDebug2("Before Calling fHandleInvitationPacket at ");
	if( !(fHandleInvitationPacket(iSockfd1,iGroupId))  )
	{
		iConnectionCounter++;
		logDebug2("Received <=0 byte:closing TAP BOX Connection..");
		return FALSE;
	}
	logDebug2("Before Calling fHandleSignon at ");

	iLog_result = sendsignon( cSendsign , iGroupId);
	if ( iLog_result != TRUE )
	{
		exit(ERROR);
	}

	memcpy(pHeader,cSendsign ,sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);
	iTemp_size = pHeader->iMsgLength;
	iTemp_code = pHeader->iMsgCode;

	logDebug2(" pHeader->iMsgCode  : %d ", pHeader->iMsgCode   );
	logDebug2(" iTemp_code        : %d ", iTemp_code         );
	logDebug2(" pHeader->MsgLength : %d ", pHeader->iMsgLength );
	logDebug2(" pHeader->MsgLength : %d ", pHeader->iMsgLength );

	fMD5_Digest(sDigest,cSendsign,iTemp_size );

	logDebug2(" after MD5 ");			
	pTap_wrap = (char *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
	iTemp_size = iTemp_size+sizeof(struct TAP_WRAPPER);
	pTap_wrap->Message_Len = iTemp_size;

	/**** TAP Reg Changes *****/ 
	iTransmitSeq ++; 
	pTap_wrap->Seq_No = iTransmitSeq ; 

	memcpy(pTap_wrap->digest,sDigest,16);

	TWIDDLE(pTap_wrap->Seq_No);
	TWIDDLE(pTap_wrap->Message_Len);

	logDebug2("Twiddled Message_Len = [%d] and Twiddled->SeqNo = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
	memcpy(cSendsignTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
	memcpy(cSendsignTAP+ sizeof(struct TAP_WRAPPER),cSendsign,sizeof(struct NNF_SIGNON_REQ)); 
	iSent_bytes = SEND(iSockfd1,cSendsignTAP,iTemp_size);
	iCounterTotalTransmit++;
	logDebug2("SIGNON REQUEST SENT TO EXCHANGE");

	fReduceInvitationCount(iGroupId);

	logDebug2("SIGN ON REQUEST Sent to exchange ....[%d]  ",iSent_bytes);

	/*------------------------------recv signon response-----------------------------------*/

	fGetInvitationPacketCount(&iInvPacketCount,iGroupId);

	logDebug2(" fHandleSignon :: InvPacketCount = [%d]",iInvPacketCount);
	if(iInvPacketCount == 0)
	{
		iRecv_bytes = RECV_INV(iSockfd1,sRecvsign,&iInv_flag);
		if( iRecv_bytes <= 0)
		{
			iConnectionCounter++;
			logDebug2("Received <=0 byted:closing TAP BOX Connection..");
			return FALSE;

		}	
		logDebug2(" Inv_flag [%d] ",iInv_flag);
		if(iInv_flag == TRUE)
		{
			if(  !(fHandleInvitationPacket(iSockfd1,iGroupId))  )
			{
				iConnectionCounter++;
				logDebug2("Received <=0 byted:closing TAP BOX Connection..");
				return FALSE;
			} 	
		}
	}
	logDebug2(" Alok bfr receive ");
	iRecv_bytes = RECV(iSockfd1,sRecvsign);

	logDebug2(" Alok after receive ");
	if( iRecv_bytes <= 0)
	{
		iConnectionCounter++;
		logDebug2("Received <=0 byted:closing TAP BOX Connection..");
		return FALSE;
	}

	//fDeal_with_SendRecv( iRecv_bytes , iGroupId );	

	memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);
	iBlen = pHeader->iMsgLength;
	cBdata = (char *)malloc(iBlen);
	memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER),iBlen);

	if (fGet_mesg_or_error_nse(cBdata) == TRUE )
		return(FALSE);

	memcpy(pTap_wrap,sRecvsign,sizeof(struct TAP_WRAPPER));
	logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
	logDebug2("Received->SeqNo = [%d]",pTap_wrap->Seq_No);
	iSeqNo = 0;

	/**** TAP Reg Changes *****/
	iRecieveSeq++;
	iSeqNo = iRecieveSeq ;
	TWIDDLE(pTap_wrap->Seq_No); 
	logDebug2("After Twiddling pTap_wrap->SeqNo   %d",pTap_wrap->Seq_No);
	logDebug2("After Received Signon Packet Receive Seq No =[%d]",iSeqNo);

	if(iSeqNo != pTap_wrap->Seq_No)
	{
		logDebug2("FATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection..");
		memset(sError,NULL,SIZE);
		strcpy(sError,"ERROR::sequence no mismatch ");
		fExit(ERROR);
	}
	logDebug2("Passed Seq No Check...");
	memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);
	logDebug2(" After Twiddling pHeader->MsgLength     %d ",pHeader->iMsgLength);
	iBlen = pHeader->iMsgLength;
	cBdata = (char *)malloc(iBlen);
	memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER),iBlen);
	logDebug2("Computing the Digest ...");

	fMD5_Digest(sDigest,cBdata,iBlen)  ;

	if(strncmp(sDigest,pTap_wrap->digest,16) !=0)
	{
		logDebug2("FATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection..");
		memset(sError,NULL,SIZE);
		strcpy(sError,"ERROR::Mismatch in MD5 Checksum ");
		fExit(ERROR);
	}
	logDebug2("Passed MD5 Checksum Check..");
	memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);	
	TWIDDLE(pHeader->iErrorCode);	
	iBlen = pHeader->iMsgLength;
	cBdata = (char *)malloc(iBlen);
	logDebug2(" MsgLength [%d]  ",pHeader->iMsgLength);

	memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER),iBlen);

	logDebug1("sTimeStamp1  :%d:",((struct NNF_SIGNON_RESP *)(sRecvsign+sizeof(struct TAP_WRAPPER)))->pHeader.iMsgLength);
	logDebug1("sTimeStamp1  :%s:",((struct NNF_SIGNON_RESP *)(sRecvsign+sizeof(struct TAP_WRAPPER)))->pHeader.sTimeStamp1);
	logDebug1("sTimeStamp2  :%s:",((struct NNF_SIGNON_RESP *)(sRecvsign+sizeof(struct TAP_WRAPPER)))->pHeader.sTimeStamp2);
	logDebug1("sTimeStamp3  :%s:",((struct NNF_SIGNON_RESP *)(sRecvsign+sizeof(struct TAP_WRAPPER)))->pHeader.sTimeStamp3);
	logDebug1("sSeqNumber   :%s:",((struct NNF_SIGNON_RESP *)(sRecvsign+sizeof(struct TAP_WRAPPER)))->sSeqNumber);
	logDebug1("sPassword	:%s:",((struct NNF_SIGNON_RESP *)(sRecvsign+sizeof(struct TAP_WRAPPER)))->sPassword);

	iLog_result = fRecvsignon(cBdata);

	logDebug2(" The log result for signon response recieved is %d ",iLog_result );

	fDeal_with_LogResult(iLog_result);

	memset(sFerror,NULL,SIZE);
	if(pHeader->iErrorCode != 0)
	{
		logDebug2(" Error code received is [%d] ",pHeader->iErrorCode);
		iErrMsgCode = pHeader->iErrorCode;
		iUserID = ((struct NNF_SIGNON_RESP *)cBdata)->iUserId;
		TWIDDLE(iUserID);
		logDebug2("This is iUserID :%d: ",iUserID);

		//sprintf(sFerror,"%s\t%s",getenv("NSE_EQ_USERID"),"USER SUCCESSFULLY LOGIN FOR TRADING");
		sprintf(sFerror,"%d\t%s",iUserID,"USER SUCCESSFULLY LOGIN FOR TRADING");
		fLogEQConFatal(sProgName,sFerror);

		fConnectUpdt(NSE_EQU_DOWN,iGroupId,pHeader->iErrorCode);
		free(cSendsign);
		exit(ERROR);
		//return(FALSE);
	}
	else
	{
		/**
		  iUserID = ((struct NNF_SIGNON_RESP *)cBdata)->iUserId;
		  TWIDDLE(iUserID);
		  logDebug2("This is iUserID :%d: ",iUserID);
		  sprintf(sFerror,"%d\t%s",iUserID,"USER SUCCESSFULLY LOGIN FOR TRADING");
		  fLogEQConFatal(sProgName,sFerror);
		 **/
	}
	free(cSendsign);
	logDebug2("Returned from fHandleSignon at ");

	logTimestamp("Exit : fHandleSignon");
	return(TRUE);
}

void 	fTransmitRequestPackets( LONG32 iGroupId )
{
	logTimestamp("Entry : fTransmitRequestPackets");

	LONG32	iSig1 = 0;
	LONG32 	iSig2 = 0;
	LONG32 	iTransKill = -1,iRespkill = -1;
	LONG32 	iPid,iPPid;
	LONG32 	j;    
	LONG32 	iRespChild,iTransChild;
	CHAR 	*cMsg,
		*cError,
		*cSendsign,
		*cSendsys,
		*cSendup,
		*cSendMsg,
		*cRecvgen;
	struct	NNF_HEADER	*pHeader; 
	NNF_ORDER_ENTRY_REQ 	*pNnf_order;
	LONG32	iQid,
		iWait_status,
		iSent_bytes,
		iRecv_bytes,
		iLog_result,
		iTemp_code,
		iTemp_size;
	CHAR 	cDummyChar;
	LONG32 	iDummy;

	SHORT 	*iTempReadRmsDaemonStatus ;
	SHORT   iDaemonStatus=-1 ;
	BOOL 	iOFFLINEFLAG = TRUE;
	SHORT 	iMaxNoOfIterations;  
	iTempReadRmsDaemonStatus=&iDaemonStatus;    

	LONG32 	isqlgroupid;
	LONG32	iInvWaitCounter = 0;
	SHORT 	iMaxStream =0 ;  
	CHAR 	sProgTime[40];
	memset(sProgTime,'\0',40); 

	sigset_t SequenceSet;
	signal(SIGPIPE,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGUSR1);
	sigaddset ( &SequenceSet , SIGUSR2);				/* Signal function Initialization */
	sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,'\0');
	setbuf(stderr,'\0');


	//  	unsigned CHAR sDigest[16];

	UCHAR sDigest[16];
	struct 	TAP_WRAPPER *pTap_wrap;
	LONG32	iInvPacketCount;
	struct 	InvitationCount *pInvcount;

	CHAR 	* cSendsysTAP;
	CHAR 	* cSendupTAP;
	CHAR 	* cSendMsgTAP;
	CHAR 	* cMsgTAP;
	LONG32 	iInv_flag = FALSE;

	/****************  End ***********************/

	iPid = getpid();
	iPPid = getppid();
	isqlgroupid = iGroupId;

	cMsg = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE); 
	pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	cError = (char *)malloc(sizeof(char)*SIZE);
	cSendsys  = (char *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
	cSendup = (char *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));
	cSendMsg = (char *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	cRecvgen = (char *)malloc(NSE_PACKET_SIZE);
	pNnf_order = (NNF_ORDER_ENTRY_REQ *)malloc(sizeof(NNF_ORDER_ENTRY_REQ));
	cSendsysTAP  = (char *)malloc(sizeof(struct NNF_SYS_INFO_REQ) + sizeof(struct TAP_WRAPPER));
	cSendupTAP = (char *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ) + sizeof(struct TAP_WRAPPER));
	cSendMsgTAP = (char *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ) + sizeof(struct TAP_WRAPPER));  
	cMsgTAP = (char *)malloc((sizeof(char)*NSE_PACKET_SIZE) + sizeof(struct TAP_WRAPPER));


	/*********    
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=sizeof(lvar_uid.arr);

	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  logDebug2 ("\n EquNseConAdapter.pc Error in connecting to oracle ");	
	  exit(ERROR);
	  }******/
	logDebug2("TRANSMIT CHILD Connction to Oracle SUCCESS......      ");
	logDebug2(" IN Function fTransmitRequestPackets with nitish ");

	pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	if(iConnectToExchange == 1)
	{        
		/*-------------------------------sys info request-------------------------------------*/
		while(TRUE)
		{
			fGetInvitationPacketCount(&iInvPacketCount,iGroupId);

			if(iInvPacketCount != 0)
			{
				logDebug2("TRANSMIT CHILDInvPacketCount [%d]      ",iInvPacketCount);
				break;
			}
		}
		logDebug2("TRANSMIT CHAftre fGetInvitationPacketCount  InvPacketCount [%d]    ",iInvPacketCount);
		logDebug2("TRANSMIT CHBefore Sendsysinfo      ");

		fSendsysinfo(cSendsys);

		logDebug2(" alok after Sendsysinfo "); 
		iTemp_size = ((struct NNF_HEADER *)(cSendsys))->iMsgLength;
		TWIDDLE(((struct NNF_HEADER *)(cSendsys))->iMsgLength); 

		fMD5_Digest(sDigest,cSendsys ,iTemp_size)  ;

		memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
		iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);
		pTap_wrap->Message_Len = iTemp_size;

		iTransmitSeq++;
		pTap_wrap->Seq_No = iTransmitSeq ; 
		TWIDDLE(pTap_wrap->Message_Len); 
		TWIDDLE(pTap_wrap->Seq_No);  
		logDebug2(" TRANSMIT CHILD Transmit Seq No incremented to [%d] ",pTap_wrap->Seq_No);
		memcpy(pTap_wrap->digest,sDigest,16);
		memcpy(cSendsysTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
		memcpy(cSendsysTAP+ sizeof(struct TAP_WRAPPER),cSendsys,sizeof(struct NNF_SYS_INFO_REQ)); 
		logDebug2("TRANSMIT CHILD Bfore sending     ");
		iSent_bytes = SEND(iSockfd1,cSendsysTAP,iTemp_size);
		iCounterTotalTransmit++;

		fDeal_with_SendRecv(iSent_bytes , iGroupId);

		fReduceInvitationCount(iGroupId);

		/**** ALOK Added for Download  on 22 Apr 2013**************/
		/*----------------------------update local database request--------------------------*/
		logDebug2(" ALOKK HERE 123 ");
		iSig1 = 0;
		/*** TAP Reg Changes ***/
		/*****         iMainwait = sigwait( &SequenceSet, &iSig1);******ALOKKK*****/
		sigwait( &SequenceSet, &iSig1);
		logDebug2(" ALOKK HERE ");
		logDebug2(" SIGNAL 1:%d", iSig1);
		/*** TAP Reg Changes ***/
		logDebug2("TRANSMIT CHILD SYS INFO RESPONSE COMPLETED");
		if ( iSig1 == SIGUSR1 )
		{
			while(TRUE)
			{
				fGetInvitationPacketCount(&iInvPacketCount,iGroupId);

				if(iInvPacketCount != 0)
				{
					logDebug2("TRANSMIT CHILDInvPacketCount [%d]      ",iInvPacketCount);
					break;
				}
			}
			logDebug2("TRANSMIT CHILDAfter fGetInvitationPacketCount InvPacketCount [%d] ",iInvPacketCount);
			logDebug2("TRANSMIT CHILDBefore sendupdate      ");

			fSendupdate( cSendup,iGroupId );

			logDebug2(" After sendupdate with nitish ");

			iTemp_size = ((struct NNF_HEADER *)(cSendup ))->iMsgLength;
			TWIDDLE(((struct NNF_HEADER *)(cSendup))->iMsgLength);

			fMD5_Digest(sDigest,cSendup  ,iTemp_size )  ;

			memset(pTap_wrap,0,sizeof(struct TAP_WRAPPER));

			logDebug2("======== Before Send LDB Update Request %d======",iTemp_size);
			iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);
			pTap_wrap->Message_Len = iTemp_size;

			/*** TAP Reg Changes ***/
			iTransmitSeq ++;
			pTap_wrap->Seq_No = iTransmitSeq;
			/*** TAP Reg Changes ***/
			TWIDDLE(pTap_wrap->Message_Len);
			TWIDDLE(pTap_wrap->Seq_No);


			logDebug2("TRANSMIT CHILD:Transmit Seq No incremented to [%d] ",pTap_wrap->Seq_No);
			logDebug2("  SEQ NO pTap_wrap->SeqNo = [%d]",pTap_wrap->Seq_No);
			memcpy(pTap_wrap->digest,sDigest,16);
			memcpy(cSendupTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(cSendupTAP + sizeof(struct TAP_WRAPPER),cSendup,sizeof(struct NNF_UPDATE_LDB_REQ));
			logDebug2("TRANSMIT CHILD Bfefore Sending  ");
			iSent_bytes = SEND(iSockfd1,cSendupTAP,iTemp_size);

			fDeal_with_SendRecv(iSent_bytes , iGroupId);

			logDebug2(" TRANSMIT CHILD Before fReduceInvitationCount      ");

			fReduceInvitationCount(iGroupId);

			logDebug2(" TRANSMIT CHILD Lock on ProcessDataLock1 ");

			//LockShm( ProcessDataLock1 );

			logDebug2("TRANSMIT CHILD UPDATE LDB REQUEST :: SENT TO EXCHANGE       ");
			logDebug2("DrvNseConnect.pc UPDATE LDB REQUEST :: SENT TO EXCHANGE ... ");
		}

		logDebug2("TRANSMIT CHILD WAITING FOR SIGNAL 2 ");
		iSig1 = 0;

		/***/           iMainwait = sigwait( &SequenceSet,&iSig1);/*****ALOKKKK***/
		logDebug2(" SIGNAL 2:%d", iSig1);

		if ( iSig1 == SIGUSR2 )
		{
			while(TRUE)
			{
				fGetInvitationPacketCount(&iInvPacketCount,iGroupId);

				if(iInvPacketCount != 0)
				{
					logDebug2("TRANSMIT CHILDInvPacketCount [%d]      ",iInvPacketCount);
					break;
				}	
			}
			logDebug2("TRANSMIT CHILD After fGetInvitationPacketCount InvPacketCount [%d]",iInvPacketCount);
			logDebug2("TRANSMIT CHILD Before fcSendupdate      ");

			fSendupdate( cSendup,iGroupId );

			iTemp_size = ((struct NNF_HEADER *)(cSendup ))->iMsgLength;
			TWIDDLE(((struct NNF_HEADER *)(cSendup))->iMsgLength);

			fMD5_Digest(sDigest,cSendup ,iTemp_size )  ;

			memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
			iTemp_size = iTemp_size + 22;
			pTap_wrap->Message_Len = iTemp_size;

			iTransmitSeq ++;
			pTap_wrap->Seq_No = iTransmitSeq;
			TWIDDLE(pTap_wrap->Seq_No);
			TWIDDLE(pTap_wrap->Message_Len);

			logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d] ",pTap_wrap->Seq_No);
			memcpy(pTap_wrap->digest,sDigest,16);
			memcpy(cSendupTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(cSendupTAP + sizeof(struct TAP_WRAPPER),cSendup,sizeof(struct NNF_UPDATE_LDB_REQ));
			logDebug2("TRANSMIT CHILD Before Sending     ");
			iSent_bytes =SEND(iSockfd1,cSendupTAP,iTemp_size);

			fDeal_with_SendRecv(iSent_bytes , iGroupId);

			logDebug2("TRANSMIT CHILD Before fReduceInvitationCount      ");

			fReduceInvitationCount(iGroupId);

			logDebug2("TRANSMIT CHILD AGAIN UPDATE LDB REQUEST :: SENT TO EXCHANGE      ");
			//LockShm( ProcessDataLock1 ); /*** Discuss***/
		}
		else if ( iSig1 == SIGUSR1 )
		{
			/*----------------------------------message area download-------------------------------------*/
			logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD ");

			/*** TAP Reg Changes ***/
			/***** EXEC SQL SELECT max(EDD_STREAM_ID)
INTO :MaxStream
FROM EXCH_DOWNLOAD_DIGITAL
WHERE  EDD_EXCH_ID='NSE'
AND EDD_DRV_FLAG='N'
AND EDD_GROUP_ID=:iGroupId;*****/

			/*****                    if ( sqlca.sqlcode != 0)
			  {
			  logDebug2("\n Error in Selecting EDD for iStreamId  is %d ", sqlca.sqlcode );
			  exit(ERROR);
			  }******/
			//iTotalStream = 0;
			//iTotalStream = fGetTotalStream();
			iTotalStream =  5;

			logDebug2(" TOTAL No Of STREAM : [%d] ", iTotalStream);

			for (j=1; j<= iTotalStream; j++) /*** TAP Reg Changes ***/
			{
				while(TRUE)
				{
					fGetInvitationPacketCount(&iInvPacketCount,iGroupId);

					if(iInvPacketCount != 0)
					{
						logDebug2("TRANSMIT CHILD InvPacketCount [%d]      ",iInvPacketCount);
						break;
					}
				}
				logDebug2("TRANSMIT CHILD After fGetInvitationPacketCount InvPacketCount [%d]    ",iInvPacketCount);
				logDebug2("TRANSMIT CHILD Before sendmessage     ");

				/*** TAP Reg Changes ***/
				fSendmessage( cSendMsg , iGroupId, j);
				memset((((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit)," ",2);
				sprintf((((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit),"%d", j);
				//*((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit = j;
				//((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit[0] = 3;

				logDebug2(" Alpha Split value : [%s] ", (((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit));
				/*** TAP Reg Changes ***/

				iTemp_size = ((struct NNF_HEADER *)(cSendMsg ))->iMsgLength;
				logDebug2("fSendmessage message length :%d:",iTemp_size);
				TWIDDLE(((struct NNF_HEADER *)(cSendMsg))->iMsgLength);

				fMD5_Digest(sDigest,cSendMsg  ,iTemp_size)  ;

				memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				iTemp_size = iTemp_size + 22;
				pTap_wrap->Message_Len = iTemp_size;
				logDebug2("GROUP ID CHECK::: [%d]",iGroupId);
				logDebug2(" 1>>>SEQ No SENT IS : [%d]",pTap_wrap->Seq_No);

				/*** TAP Reg Changes ***/
				iTransmitSeq ++;
				pTap_wrap->Seq_No = iTransmitSeq;
				/*** TAP Reg Changes ***/
				TWIDDLE(pTap_wrap->Seq_No);
				TWIDDLE(pTap_wrap->Message_Len);
				logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d] ",pTap_wrap->Seq_No);
				logDebug2(" 1>>>SEQ No SENT IS : [%d]",pTap_wrap->Seq_No);

				memcpy(pTap_wrap->digest,sDigest,16);
				memcpy(cSendMsgTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(cSendMsgTAP + sizeof(struct TAP_WRAPPER) , cSendMsg,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
				logDebug2("TRANSMIT CHILDBefore Sending      ");
				iSent_bytes = SEND(iSockfd1,cSendMsgTAP ,iTemp_size);

				fDeal_with_SendRecv(iSent_bytes , iGroupId);

				logDebug2("RANSMIT CHILD Before fReduceInvitationCount     ");

				fReduceInvitationCount(iGroupId);

				logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD REQUEST :: SENT TO EXCHANGE ..      ");
			} /*** TAP Reg Changes ***/
		}
		/*-------------------------------fallover complete set shared memory iiFlag to true------------*/
		iSig1 = 0;
		/*** TAP Reg Changes ***/
		/****/           iMainwait = sigwait( &SequenceSet,&iSig1);/****ALOKKK ************/ /*** Discuss**/
		//                iMainwait = 0;
		//iMainwait = sigwait( &SequenceSet,&iSig1);
		//               iSig1 = iMainwait ;
		logDebug2(" SIGNAL 3:%d", iSig1);
		/*** TAP Reg Changes ***/
		if(iSig1 == SIGUSR1)
		{
			/*** TAP Reg Changes ***/
			for (j=1; j<= iTotalStream; j++)
			{
				logDebug2("TRANSMIT CHILD Before fGetInvitationPacketCount     ");

				fGetInvitationPacketCount(&iInvPacketCount,iGroupId);

				logDebug2("TRANSMIT CHILD After fGetInvitationPacketCount InvPacketCount [%d] ",iInvPacketCount);
				if(iInvPacketCount == 0)
				{
					iRecv_bytes  = RECV_INV(iSockfd1,cRecvgen,iInv_flag);
					if(iInv_flag == TRUE)
					{
						logDebug2("TRANSMIT CHILD Before fReceiveInvitationPacket      ");
						fReceiveInvitationPacket(iSockfd1,iGroupId);
					}
				}
				logDebug2("TRANSMIT CHILD Before sendmessage      ");
				fSendmessage( cSendMsg , iGroupId, j );

				memset((((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit),'\0',2);
				sprintf((((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit),"%d", j);
				logDebug2(" Alpha Split value : [%s] ", (((struct NNF_HEADER *)(cSendMsg))->sAlphaSplit));

				iTemp_size = ((struct NNF_HEADER *)(cSendMsg ))->iMsgLength;
				TWIDDLE(((struct NNF_HEADER *)(cSendMsg ))->iMsgLength);

				fMD5_Digest(sDigest,cSendMsg  ,iTemp_size )  ;

				memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				iTemp_size = iTemp_size + 22;
				pTap_wrap->Message_Len = iTemp_size;

				/*** TAP Reg Changes ***/
				iTransmitSeq ++;
				pTap_wrap->Seq_No = iTransmitSeq;
				/*** TAP Reg Changes ***/
				TWIDDLE(pTap_wrap->Seq_No);
				TWIDDLE(pTap_wrap->Message_Len);

				logDebug2("ANSMIT CHILD Transmit Seq No incremented to [%d] ",pTap_wrap->Seq_No);
				logDebug2(" SEQ No SENT IS : [%d]",pTap_wrap->Seq_No);
				memcpy(pTap_wrap->digest,sDigest,16);
				memcpy(cSendMsgTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(cSendMsgTAP + sizeof(struct TAP_WRAPPER),cSendMsg,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
				logDebug2("TRANSMIT CHILD Before Sending      ");
				iSent_bytes = SEND(iSockfd1,cSendMsgTAP,iTemp_size);
				if ( iSent_bytes < 0 )
				{
					fSend_exch_down_buf_nse( iGroupId ,cSendMsg );
				}

				fDeal_with_SendRecv(iSent_bytes , iGroupId);

				logDebug2("TRANSMIT CHILD Before fReduceInvitationCount       ");

				fReduceInvitationCount(iGroupId);

				logDebug2(" TRANSMIT CHILD MESSAGE AREA DOWNLOAD REQUEST :: SENT TO EXCHANGE ...       ");
			}
			/*** TAP Reg Changes ***/
		}
		else if ( iSig1 == SIGUSR2 )
		{
			logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD COMPLETE NORMAL PROCESS STARTS ");
		}
		/*** Only if this iiFlag is set during SysInfoResp will we send the portfolio req ***/
		logDebug2("fTransmitRequestPackets: DOWNLOAD COMLETE NORMAL PROCESS STARTS");

		/***** ALOKK Added for Download on 22-Apr-2013 ***/
	}   

	logDebug2("OPENING  GlobQueueId  %d",iGlobQueueId) ;
	iQid = OpenMsgQ(MapperToConnNSEEQ);		

	if ( iQid < 0 )
	{
		strcpy(cError,"ERROR : in OpenMsgQ function ");
		fExit(ERROR);
	}
	logDebug2("TRANSMIT CHILD Before UpdateConnectStatus     ");
	/*****/	
	//fUpdateConnectStatus(NSE_EQU_UP, iGroupId);// ,BCAST_YES,FALSE);/*****/
	fConnectUpdt(NSE_EQU_UP, iGroupId,0);// ,BCAST_YES,FALSE);/*****/

	while ( TRUE )
	{
		logDebug2("TRANSMIT CHILD At the start of the While Loop     ");
		iInvWaitCounter  = 0;
		while(TRUE)
		{
			logInfo("Inv Counter :%d:",iInvWaitCounter);
			fGetInvitationPacketCount(&iInvPacketCount,iGroupId);
			logDebug2("After fGetInvitationPacketCount InvPacketCount [%d]      ",iInvPacketCount);
			logDebug2(" iSleepTime  [%d]      ",iSleepTime);
			iInvWaitCounter++;

			if(iInvPacketCount != 0)
			{
				if(iInvWaitCounter > iSleepTime)
				{
					fUpdateConnectStatus(NSE_EQU_UP, iGroupId);
				}
				logDebug2("TRANSMIT CHILD InvPacketCount [%d]      ",iInvPacketCount);

				break;
			}

			if(iInvWaitCounter == iSleepTime)
			{ 
				logInfo("Sending Rejection");
				fSend_exch_down_nse(iGroupId);
			}
			logDebug2("Before Sleep ");


			//usleep(5000);
                        //usleep(10000);
                        usleep(iBusyTimer);
/**
                        sleep(1);
                        1. Causing Slowness while sending Order to Exch ...so reducing sleep to usleep(5000)
                        2. Changing 5000 useconds to 10000
                        3. Fetching Value from ENV var according to 40 or 100 order per sec
**/


		}
		logDebug2("Before ReadMsgQ  InvPacketCount [%d]      ",iInvPacketCount);
		if(iInvPacketCount >0)
		{
			memset(cMsg,NULL,NSE_PACKET_SIZE);	
			memset(cError,NULL,SIZE);
			logTimestamp("TRANSMIT CHILD ReadMsgQ id is %d",iQid);

			iWait_status = ReadMsgQ( iQid , cMsg , NSE_PACKET_SIZE , 1);

			if (iWait_status == TRUE)
			{
				memset(pNnf_order,'\0',sizeof(NNF_ORDER_ENTRY_REQ));
				memcpy(pHeader,cMsg,sizeof(struct NNF_HEADER)); 
				TWIDDLE(pHeader->iMsgLength);
				TWIDDLE(pHeader->iMsgCode);	

				iTemp_size = pHeader->iMsgLength;
				iTemp_code = pHeader->iMsgCode;
				memcpy(pNnf_order,cMsg,sizeof(NNF_ORDER_ENTRY_REQ));	

				logTimestamp("==================Saurabh PrLONG32ing request Packet====================");
/**
				logDebug2(" pHeader->Reserved [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iReserved);
				logDebug2(" pHeader->LogTimeStamp [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iLogTimeStamp);
				logDebug2(" pHeader->AlphaSplit [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sAlphaSplit,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sAlphaSplit));
				logDebug2(" pHeader->MsgCode [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iMsgCode);
				logDebug2(" pHeader->ErrorCode [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iErrorCode);
				logDebug2(" pHeader->TimeStamp1 [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sTimeStamp1,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sTimeStamp1));
				logDebug2(" pHeader->TimeStamp2 [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sTimeStamp2,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sTimeStamp2));
				logDebug2(" pHeader->TimeStamp3 [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sTimeStamp3,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.sTimeStamp3));
				logDebug2(" pHeader->MsgLength [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iMsgLength);
				logDebug2(" ParticipantType  [%c]",((struct NNF_ORDER_ENTRY *)cMsg)->cParticipantType);
				logDebug2(" Reserved  [%c]",((struct NNF_ORDER_ENTRY *)cMsg)->cReserved);
				logDebug2(" CompititorPeriod  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iCompititorPeriod);
				logDebug2(" SolicitorPeriod  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iSolicitorPeriod);
				logDebug2(" ModCanBy  [%c]",((struct NNF_ORDER_ENTRY *)cMsg)->cModCanBy);
				logDebug2(" Reserved1  [%c]",((struct NNF_ORDER_ENTRY *)cMsg)->cReserved1);
				logDebug2(" ReasonCode  [%d",((struct NNF_ORDER_ENTRY *)cMsg)->iReasonCode);
				logDebug2(" StartAlpha [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->sStartAlpha,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->sStartAlpha));
				logDebug2(" EndAlpha [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->sEndAlpha,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->sEndAlpha));
				logDebug2(" Symbol [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pSecInfo.sSymbol,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->pSecInfo.sSymbol));
				logDebug2(" Series [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pSecInfo.sSeries,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->pSecInfo.sSeries));
				logDebug2(" AuctionNum  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iAuctionNum);
				logDebug2(" CPBrokerCode  [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->sCPBrokerCode,strlen(((struct NNF_ORDER_ENTRY *)cMsg)->sCPBrokerCode));
				logDebug2(" SecSuspInd  [%c]",((struct NNF_ORDER_ENTRY *)cMsg)->cSecSuspInd);
				logDebug2(" OrderNum  [%lf]",((struct NNF_ORDER_ENTRY *)cMsg)->fOrderNum);
				logDebug2(" AccCode  [%s]",((struct NNF_ORDER_ENTRY *)cMsg)->sAccCode);
				logDebug2(" BookType  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iBookType);
				logDebug2(" BuyOrSell  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iBuyOrSell);
				logDebug2(" DiscQty  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iDiscQty);
				logDebug2(" DiscQtyRemaining  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iDiscQtyRemaining);
				logDebug2(" TotalQtyRemaining  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iTotalQtyRemaining);
				logDebug2(" TotalQty  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iTotalQty);
				logDebug2(" QtyFilledToday  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iQtyFilledToday);
				logDebug2(" Price  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iPrice);
				logDebug2(" TriggerPrice  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iTriggerPrice);
				logDebug2(" GoodTillDate  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iGoodTillDate);
				logDebug2(" MinFillQty  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iMinFillQty);
				logDebug2(" LastModifiedTime  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iLastModifiedTime);
				logDebug2(" MFTerm [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.MFTerm);
				logDebug2(" AONTerm [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.AONTerm);
				logDebug2(" IOCTerm [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.IOCTerm);
				logDebug2(" GTCTerm [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.GTCTerm);
				logDebug2(" DayTerm [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.DayTerm);
				logDebug2(" StopLossTerm [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.StopLossTerm);
				logDebug2(" Market [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.Market);
				logDebug2(" ATO [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.ATO);
				logDebug2(" Reserved [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.Reserved);
				logDebug2(" PreOpen [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.PreOpen);
				logDebug2(" Frozen [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.Frozen);
				logDebug2(" Modified [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.Modified);
				logDebug2(" Traded [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.Traded);
				logDebug2(" MatchedInd [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->pOrderTerms.MatchedInd);
				logDebug2(" BranchId  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iBranchId);
				logDebug2(" ExcgUserId  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iExcgUserId);
				logDebug2(" BrokerCode  [%s]",((struct NNF_ORDER_ENTRY *)cMsg)->sBrokerCode);
				logDebug2(" Remarks  [%s]",((struct NNF_ORDER_ENTRY *)cMsg)->sRemarks);
				logDebug2(" Settlor  [%s]",((struct NNF_ORDER_ENTRY *)cMsg)->sSettlor);
				logDebug2(" ProCli  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iProCli);
				logDebug2(" SettlementDays  [%d]",((struct NNF_ORDER_ENTRY *)cMsg)->iSettlementDays);
				logDebug2(" dUserInfo  [%lf]",((struct NNF_ORDER_ENTRY *)cMsg)->fUserInfo);
				logDebug2(" dReservedPrgTrd  [%lf]",((struct NNF_ORDER_ENTRY *)cMsg)->fReservedPrgTrd);

				logDebug2("==================Saurabh PrLONG32ing request Packet End====================");
**/
				fMD5_Digest(sDigest,cMsg  ,iTemp_size)  ;

				pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
				memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);
				pTap_wrap->Message_Len = iTemp_size;

				iTransmitSeq ++ ;
				pTap_wrap->Seq_No = iTransmitSeq; 
				TWIDDLE(pTap_wrap->Seq_No);
				TWIDDLE(pTap_wrap->Message_Len);	
				logDebug2("TRANSMIT CHILD Seq No Sending Order Packet [%d] ----",pTap_wrap->Seq_No);
				memcpy(pTap_wrap->digest,sDigest,16);
				memcpy(cMsgTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(cMsgTAP + sizeof(struct TAP_WRAPPER),cMsg,(iTemp_size - sizeof(struct TAP_WRAPPER)));
				logDebug2("TRANSMIT CHILD BEFORE SEND 1 iTemp_size : %d",iTemp_size )  ;

				fReduceInvitationCount(iGroupId);

				iSent_bytes = SEND(iSockfd1,cMsgTAP,iTemp_size);

				iCounterTotalTransmit++;
				logDebug2("TRANSMIT CHILD Before AFTER SEND  [%d]    ",iCounterTotalTransmit);
				if (iSent_bytes  <= 0 )
				{
					logInfo("Calling send_exch_down_buf_nse iSent_bytes  <= 0");
					fSend_exch_down_buf_nse( iGroupId , cMsg );
				}

				logDebug1("OrderPack Send Bytes :%d:",iSent_bytes);
				//if ( iSent_bytes <= 0 ) /*** Discuss***/ /** This should be there ***/
				/***
				  if (0 <= 0 )
				  {
				  send_exch_down_buf_nse( iGroupId , cMsg );
				  }

				  system("echo 'Date and Time is' ");
				  system("date");
				 **/
				fDeal_with_SendRecv(iSent_bytes , iGroupId);
			}
			else
			{
				memset(cError,NULL,SIZE);
				strcpy(cError,"EquNseConAdapter ERROR in ReadMsgQ function ");
				logDebug2("EquNseConAdapter ERROR in ReadMsgQ function " )  ;
				fExit(ERROR);
			}
		}
	}

	logTimestamp("Exit : fTransmitRequestPackets");

}       /* End of fTransmitRequestPackets*/

void 	fReceiveReplyPackets( LONG32 iSockfd1 , LONG32 iLocalId)
{
	logTimestamp("Entry : fReceiveReplyPackets");

	//	LONG32  FileFlag=FALSE;
	static	LONG32 iPacketCounter =0 ;

	//    	LONG32 	ExchPacketCounter=0;
	CHAR 	sProgTime[40];
	memset(sProgTime,'\0',40);

	CHAR  	sSeqArr1[1];
	SHORT 	iSeq1=0;
	CHAR  	sTempSeqNo[ 9 ];
	USHORT 	d[16];
	SHORT 	i=15, j=0;
	LONG32 	iTemp = 0;
	SHORT 	iStream = 0, iDowCounter =0; 
	//    	CHAR 	tempStream;  

	LONG32	iQidnormal,
		iQidaucodd,
		iRecv_bytes,
		iWrite_status;

	//	LONG32 	clen3,
	LONG32  iQueue_bytes,
		iSent_bytes,
		iTemp_size,
		iTemp_code,
		iWait_status,
		iLog_result,
		iFlag=1,iPid,iPPid,
		iPut_in_queue=FALSE,
		iTimeStampUpdateFlag =FALSE,
		iDownloadFlag = FALSE; 
	CHAR	*cMsg,
		*cRecvgen,
		*cRecvgen1,
		*cWrite_mess,
		*cError,
		*cRecv_temp,		
		*cRecv_sys;
	LONG32 	iIndexrec = 1;
	LONG32 	iInv_flag = FALSE;
	struct 	INVITATION_PACKET	*pInv_packet;
	//    	SHORT 	pInvcount;
	struct 	TAP_WRAPPER *pTap_wrap;
	LONG32 	iSeqNo;

	//	unsigned char sDigest[16];
	UCHAR	sDigest[16];
	CHAR 	*cBdata;
	LONG32 	iBlen;
	CHAR 	cDummyChar;
	LONG32 	iInvPacketCount;
	LONG32 	iDummy;
	struct 	NNF_HEADER 			*pHeader;
	struct 	NNF_SYS_INFO_RESP 		*pSysresp;
	struct 	NNF_UPDATE_LDB_HDR_RESP 	*pUhresponse;
	struct 	NNF_UPDATE_LDB_TRAILER_RESP 	*pUtresponse;
	struct 	NNF_UPDATE_LDB_DATA_RESP 	*pUdresponse;
	struct 	NNF_MSG_DOWNLOAD_START_RESP 	*pMhresponse;
	struct 	NNF_MSG_DOWNLOAD_DATA_RESP 	*pMdresponse;
	struct 	NNF_MSG_DOWNLOAD_END_RESP 	*pMtresponse;
	struct 	NNF_DOUBLE_INT  		pTempTimeStamp , pDowTime;

	pTap_wrap = ( struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTap_wrap,'\0',sizeof(struct TAP_WRAPPER));
	LONG32 	iSig1 = 0;
	LONG32 	iSig2 = 0;
	LONG32 	iTransKill = -1,iRespkill = -1,iDownkill = -1 ;
	LONG32 	iSpecial_id=0;

	LONG32 	iRespChild,iDownchild,iTransChild,iGroupId;
	//	unsigned int  iTempTime1 ;
	//      unsigned int  iTempTime2 ;
	ULONG32	iTempTime1;
	ULONG32	iTempTime2;	

	LONG32 iSqlGroupId = 0;
	sigset_t SequenceSet;
	signal(SIGPIPE,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGUSR1);
	sigaddset ( &SequenceSet , SIGUSR2);			/* Signal Initialization Functions */
	sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,'\0');
	setbuf(stderr,'\0');

	iPid = getpid();
	iPPid = getppid();
	iSpecial_id = iLocalId;
	iSqlGroupId = iSpecial_id;
	logDebug2(" Inside Function fReceiveReplyPackets Sql Local Group Id : %d Local Group Id : %d ",iSqlGroupId,iLocalId);

	cMsg = (char *)malloc(NSE_PACKET_SIZE); 
	cError = (char *)malloc(sizeof(char)*SIZE);
	cRecvgen = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	cRecv_temp = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	cRecvgen1 = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	cRecv_sys = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	memset(pHeader,'\0',sizeof(struct NNF_HEADER));
	pSysresp = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	pUhresponse = (struct  NNF_UPDATE_LDB_HDR_RESP *)malloc(sizeof(struct  NNF_UPDATE_LDB_HDR_RESP));
	pUtresponse=(struct NNF_UPDATE_LDB_TRAILER_RESP *)malloc(sizeof(struct NNF_UPDATE_LDB_TRAILER_RESP));
	pUdresponse = (struct NNF_UPDATE_LDB_DATA_RESP *)malloc(sizeof(struct NNF_UPDATE_LDB_DATA_RESP));
	pMhresponse = (struct NNF_MSG_DOWNLOAD_START_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_START_RESP));
	pMdresponse = (struct  NNF_MSG_DOWNLOAD_DATA_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));
	pMtresponse = (struct NNF_MSG_DOWNLOAD_END_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_END_RESP));
	pInv_packet = (struct INVITATION_PACKET *)malloc(sizeof(struct INVITATION_PACKET));

	logDebug2("EquNseConAdapter.pc fReceiveReplyPackets connecting to database.......");
	/****** EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  logDebug2 ("\n EquNseConAdapter.pc Error in connecting to oracle ");
	  exit(ERROR);		
	  }*****/
	//  qidnormal = OpenMsgQ(EquNSEToRmsNse); 
	iQidnormal = OpenMsgQ(ConnToTrdMapNSEEQ);

	if ( iQidnormal < 0 )
	{
		memset(cError,NULL,SIZE);
		strcpy(cError,"ERROR : in OpenMsgQ function ");
		fExit(ERROR);
	}
	while(TRUE)
	{
		iPut_in_queue = FALSE;
		iInv_flag = FALSE;
		logDebug2("--------------------------------- RECEIVE CHILD NEW PACKET --------------------------------------");
		iRecv_bytes = RECV_INV(iSockfd1,cRecvgen1,&iInv_flag);

		fDeal_with_SendRecv(iRecv_bytes , iLocalId);

		logDebug2("RECEIVE CHILD Inv_flag [%d] ",iInv_flag);
		if(iInv_flag == TRUE)
		{
			logDebug2("RECEIVE CHILD Receive child calling fReceiveInvitationPacket ");
			fReceiveInvitationPacket(iSockfd1,iLocalId);			
		}
		else
		{
			logDebug2("RECEIVE CHILD RECEVING NON INVITATION PACKET ");	
			iRecv_bytes = RECV(iSockfd1,cRecvgen1);

			fDeal_with_SendRecv(iRecv_bytes , iLocalId);

			memcpy(pHeader,cRecvgen1+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
			memcpy(pTap_wrap,cRecvgen1,sizeof(struct TAP_WRAPPER));
			logDebug2("RECEIVE CHILD Received message with total length = [%d]",pTap_wrap->Message_Len);
			logDebug2("RECEIVE CHILD Received SeqNo = [%d]",pTap_wrap->Seq_No);

			/**** TAP Reg Changes *****/
			iRecieveSeq ++;
			iSeqNo =  iRecieveSeq ; 
			TWIDDLE(pTap_wrap->Seq_No); 
			TWIDDLE(pHeader->iMsgLength );
			TWIDDLE(pHeader->iMsgCode );
			TWIDDLE(pHeader->iErrorCode);
			logDebug2("RECEIVE CHILD Required SeqNo is =[%d]",iSeqNo);
			if(iSeqNo != pTap_wrap->Seq_No)
			{
				logDebug2("FATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection..");/** Discuss***/ /** Fatal **/
				memset(cError,NULL,SIZE);
				strcpy(cError,"ERROR::sequence no mismatch ");
				fExit(ERROR);
			}
			iBlen = pHeader->iMsgLength ;
			cBdata = (char *)malloc(iBlen);
			memcpy(cBdata,cRecvgen1+sizeof(struct TAP_WRAPPER) ,iBlen);

			fMD5_Digest(sDigest,cBdata,iBlen);

			if(strncmp(sDigest,pTap_wrap->digest,16) !=0)
			{
				logDebug2("FATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection.."); /** Discuss***/ /** Fatal **/
				memset(cError,NULL,SIZE);
				strcpy(cError,"ERROR::Mismatch in MD5 Checksum ");
				fExit(ERROR);
			}
			logDebug2("RECEIVE CHILD  The transcode in NNF_HADER [%d] ",pHeader->iMsgCode);
			logDebug2("RECEIVE CHILD  The mesg length recvd is %d ",pHeader->iMsgLength);
			logDebug2("RECEIVE CHILD  The  ERROR ID in NNF_HADER [%d] ",pHeader->iErrorCode);

			memset(cRecvgen,'\0',NSE_PACKET_SIZE); 
			logDebug2("RECEIVE CHILD blen [%d] ",iBlen);
			memcpy(cRecvgen,cBdata,iBlen);

			/*********************** ALOKK PANDEY*********************

			  if (get_mesg_or_error_nse(cRecvgen) == TRUE )
			  {
			  logDebug2("\n Before Continue");
			  continue;
			  }
			 ***************************ALOKK PANDEY*******************/
			switch(pHeader->iMsgCode)
			{
				case TC_EQU_NSE_SYS_INFO_RESP :
					//	UnLockShm( ProcessDataLock1 );
					memcpy(cRecv_sys,cRecvgen,sizeof(struct NNF_SYS_INFO_RESP));

					/*************** TAP Reg Changes*******************/
					logDebug2("STREAM in SYSINFO :[%d] [%d]",((struct NNF_HEADER *)cRecvgen)->sAlphaSplit, ((struct NNF_HEADER *)cRecvgen)->iMsgCode); 
					iTotalStream = *(pHeader->sAlphaSplit); 
					logDebug2(" Total No of STREAMS  :[%d] ",iTotalStream );
					for(j=1; j<= iTotalStream ;j++)
					{
						Msg_Dow_Data[j].Stream_Id  = j ;
						Msg_Dow_Data[j].Stream_Flag= 1;
						Msg_Dow_Data[j].TimeStamp1 = 0;
						Msg_Dow_Data[j].TimeStamp2 = 0;
					}
					/************ END of TAP Reg Changes*******************/

					iLog_result = fRecvsysinfo( cRecv_sys );

					fDeal_with_LogResult(iLog_result); 

					if ( iLog_result == TRUE )
					{
						logDebug2("RECEIVE CHILD  RAISING SIGNAL 1 AFTER SYS_INFO_RESP");
						iDownkill = -1;
						iDownkill = kill( iPPid , SIGUSR1 );
						//logDebug2("iTransChild :%d:",iTransChild);
						//iDownkill = kill( iTransChild, SIGUSR1 );
						if ( iDownkill < 0 )
						{
							memset(cError,NULL,SIZE);
							strcpy(cError,strerror(errno));
							exit(ERROR);
						}
					}
					break;

				case TC_EQU_NSE_PARTIAL_SYS_INFO_RESP : 
					//UnLockShm( ProcessDataLock1 );
					logDebug2("EquNseConnect.pc MARKET STATUS MISMATCH ");
					memcpy(pSysresp,cRecvgen,sizeof(struct NNF_SYS_INFO_RESP));
					iLog_result = fRecvsysinfo( cRecvgen );
					if ( iLog_result == TRUE )
					{
						logDebug2("RECEIVE CHILD  RAISING SIGNAL 2 AFTER PARTIAL_SYS_INFO_RESP");
						iDownkill = -1;
						//iDownkill = kill( iPPid , SIGUSR2 ); /** Discuss***/ /** Why SIGUSR2 is commented ***/
						iDownkill = kill( iPPid , SIGUSR1 );
						//logDebug2("iTransChild :%d:",iTransChild);
						//iDownkill = kill( iTransChild, SIGUSR2 );
						if ( iDownkill < 0 )
						{
							memset(cError,NULL,SIZE);
							strcpy(cError,strerror(errno));
							exit(ERROR);
						}
					}
					break;

				case TC_EQU_NSE_UPDATE_LDB_HEADER_RESP : 
					logDebug2("EquNseConAdapter.pc Update Database Header Messg :: recieved ");
					iTimeStampUpdateFlag =FALSE;
					break;

				case TC_EQU_NSE_UPDATE_LDB_DATA_RESP : 
					memcpy(pUdresponse,cRecvgen,sizeof(struct NNF_UPDATE_LDB_DATA_RESP));
					logDebug2("MsgCode of InnerTransCode is %d ",pUdresponse->pInnerHeader.iMsgCode);
					TWIDDLE(pUdresponse->pInnerHeader.iMsgLength); 
					iQueue_bytes = pUdresponse->pInnerHeader.iMsgLength;
					cWrite_mess = cRecvgen + sizeof(NNF_HEADER);
					iPut_in_queue = TRUE;
					break;

				case TC_EQU_NSE_UPDATE_LDB_TRAILER_RESP : 
					//UnLockShm( ProcessDataLock1 );
					logDebug2("EquNseConAdapter.pc Update Database Trailer Messg :: recieved ");
					iDownkill = -1;
					iDownkill = kill( iPPid , SIGUSR1 );
					//logDebug2("iTransChild :%d:",iTransChild);
					//iDownkill = kill( iTransChild, SIGUSR1 );
					if ( iDownkill < 0 )
					{
						memset(cError,NULL,SIZE);
						strcpy(cError,strerror(errno));
						exit(ERROR);
					}
					break;

				case TC_EQU_NSE_MSG_DOWNLOAD_START_RESP : 
					logDebug2("EquNseConAdapter.pc Message Area pHeader Messg :: recieved ");
					break;

				case TC_EQU_NSE_MSG_DOWNLOAD_DATA_RESP : 
					memcpy(pMdresponse,cRecvgen,sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));
					memcpy(&pTempTimeStamp,(pMdresponse->pInnerHeader.sTimeStamp2),NNF_DATE_TIME_LEN);
					TWIDDLE(pMdresponse->pInnerHeader.iMsgCode);
					TWIDDLE(pMdresponse->pInnerHeader.iMsgLength);
					logDebug2("The inner transcode in message download recvd is %d ",pMdresponse->pInnerHeader.iMsgCode);

					if (	pMdresponse->pInnerHeader.iMsgCode == 2073 || pMdresponse->pInnerHeader.iMsgCode == 2074 ||
							pMdresponse->pInnerHeader.iMsgCode == 2075 || pMdresponse->pInnerHeader.iMsgCode == 2072 ||
							pMdresponse->pInnerHeader.iMsgCode == 2231 || pMdresponse->pInnerHeader.iMsgCode == 2170 ||
							pMdresponse->pInnerHeader.iMsgCode == 2042 || pMdresponse->pInnerHeader.iMsgCode == 2222 ||
							pMdresponse->pInnerHeader.iMsgCode == 3034 || pMdresponse->pInnerHeader.iMsgCode == 3037 ||
							pMdresponse->pInnerHeader.iMsgCode == 3044 || pMdresponse->pInnerHeader.iMsgCode == 3047 ||
							pMdresponse->pInnerHeader.iMsgCode == 2012 || pMdresponse->pInnerHeader.iMsgCode == 2076 ||
							pMdresponse->pInnerHeader.iMsgCode == 2009 || pMdresponse->pInnerHeader.iMsgCode == 2008 ||
							pMdresponse->pInnerHeader.iMsgCode ==9002  )
					{
						logDebug2(" ----------PACKET DATA RECEIVED IN DOWNLOAD--------------- "); 
						cRecv_temp =cRecvgen + sizeof(NNF_HEADER);        

						fConvertSeqNO( cRecv_temp ,sTempSeqNo); 

						logDebug2("##########sTempSeqNo   [%s]",sTempSeqNo);
						memset( ((struct NNF_ORDER_ENTRY *)cRecv_temp)->sRemarks ,' ',OE_REMARKS_LEN);
						strncpy( ((struct NNF_ORDER_ENTRY *)cRecv_temp)->sRemarks,";",1);    
						memcpy ( ((struct NNF_ORDER_ENTRY *)cRecv_temp)->sRemarks + DELTA_REMARKS,sTempSeqNo, strlen(sTempSeqNo ));
					}		 
					iQueue_bytes = pMdresponse->pInnerHeader.iMsgLength;
					cWrite_mess = cRecvgen + sizeof(NNF_HEADER);
					iPut_in_queue = TRUE;		
					logDebug2("TCODE :[%d]",((struct NNF_ORDER_ENTRY *)cWrite_mess)->pHeader.iMsgCode);  	
					break;

				case TC_EQU_NSE_MSG_DOWNLOAD_END_RESP : 
					logDebug2("EquNseConnect.pc Message Area trailer Messg :: recieved ");
					//fConnectUpdt(NSE_EQU_UP, iGroupId,0);// ,BCAST_YES,FALSE);/*****/
					iTimeStampUpdateFlag =TRUE;

					/*************** TAP Reg Changes*******************/
					iDownkill = kill( iPPid , SIGUSR2 );
					iDowCounter++ ; 
					logDebug2("MSG_DOWNLOAD Trailer Resp for STREAM :[%d] TotalStream :%d ",*(pHeader->sAlphaSplit), iTotalStream);
					if( iTotalStream == iDowCounter )
					{ 	
						logDebug2("RECEIVE CHILD  RAISING SIGNAL 2 AFTER MSG_DOWNLOAD_END");
						iDownloadFlag = TRUE ;   
						iDownkill = -1;
						iDownkill = kill( iPPid , SIGUSR2 );
						//logDebug2("iTransChild :%d:",iTransChild);
						//iDownkill = kill( iTransChild, SIGUSR2 );
						if ( iDownkill < 0 )
						{ 
							memset(cError,NULL,SIZE);
							strcpy(cError,strerror(errno));
							exit(ERROR);
						}
					}
					/************ END of TAP Reg Changes*******************/

					break;

				default	:
					if ( 	pHeader->iMsgCode == 2073 || pHeader->iMsgCode == 2074 || pHeader->iMsgCode == 2075 || \
							pHeader->iMsgCode == 2072 || pHeader->iMsgCode == 2231 || pHeader->iMsgCode == 2170 || \
							pHeader->iMsgCode == 2042 || pHeader->iMsgCode == 9002 || pHeader->iMsgCode == 3034 || \
							pHeader->iMsgCode == 3037 || pHeader->iMsgCode == 3044 || pHeader->iMsgCode == 3047 || \
							pHeader->iMsgCode == 2012 || pHeader->iMsgCode == 2076 || pHeader->iMsgCode == 2009 || \
							pHeader->iMsgCode == 2008 || pHeader->iMsgCode == 2009 || pHeader->iMsgCode == 5295  )
					{
						logDebug2(" ----------PACKET DATA RECEIVED IN NORMAL Packet ------------");	

						fConvertSeqNO(cRecvgen, sTempSeqNo);

						logDebug2("--------------sTempSeqNo [%s]",sTempSeqNo);

						/**memcpy ( ((struct NNF_ORDER_ENTRY *)cRecvgen)->Remarks ,';',DELTA_REMARKS);  Commented as Junk Values sending to TWS ****/
						memset( ((struct NNF_ORDER_ENTRY *)cRecvgen)->sRemarks ,' ',OE_REMARKS_LEN);
						strncpy( ((struct NNF_ORDER_ENTRY *)cRecvgen)->sRemarks,";",1);      
						memcpy ( ((struct NNF_ORDER_ENTRY *)cRecvgen)->sRemarks + DELTA_REMARKS,sTempSeqNo, strlen(sTempSeqNo ));
					}



					/*************** TAP Reg Changes*******************/

					memcpy(&pDowTime,(pHeader->sTimeStamp2),NNF_DATE_TIME_LEN);
					logDebug2 (" iMsgCode :%d: pDowTime :%u :%u",pHeader->iMsgCode, pDowTime.LogTime1, pDowTime.LogTime2);
					logDebug2(" Normal Order :[%d] , [%s]", *(pHeader->sTimeStamp3), pHeader->sTimeStamp3); 
					logDebug2("pHeader->sTimeStamp1 :%s:",pHeader->sTimeStamp1);	
					logDebug2("pHeader->sTimeStamp2 :%s:",pHeader->sTimeStamp2);	
					logDebug2("pHeader->sTimeStamp3 :%s:",pHeader->sTimeStamp3);	
					//logDebug2(" Value :%d", *(pHeader->sAlphaSplit));
					logDebug2(" Value :%s", (pHeader->sAlphaSplit));
					memcpy(&pTempTimeStamp,(pHeader->sTimeStamp2),NNF_DATE_TIME_LEN);
					iStream = pDowTime.LogTime2;

					logDebug2("Normal PKT STREAM = %d Time1= %u,Time2=%u ",iStream, pTempTimeStamp.LogTime1,pTempTimeStamp.LogTime2);
					//Msg_Dow_Data[iStream].Stream_Id  =iStream ;   
					logInfo("Here 1"); 
					//Msg_Dow_Data[iStream].TimeStamp1 = pTempTimeStamp.LogTime1 ;
					logInfo("Here 2"); 
					//Msg_Dow_Data[iStream].TimeStamp2 = pTempTimeStamp.LogTime2 ;
					logInfo("Here 3"); 

					//if ( iIndexrec % MAX_NO_UPDATE == 0  && iDownloadFlag == TRUE ) /** Discuss**/
				//	fUpdateTimeStamp(&pTempTimeStamp);          
					logInfo("Here 4"); 



					/************ END of TAP Reg Changes*******************/   


					logDebug2("-------------------------------------------------------------"); 

					if ( pHeader->iMsgCode ==  2222  )
					{
						logDebug2("Trade ");
					}
					logDebug2("Default");
					cWrite_mess = cRecvgen;
					iQueue_bytes = pHeader->iMsgLength;
					iPut_in_queue = TRUE;
					break;
			};

			if(iPut_in_queue == TRUE)
			{
				iIndexrec= iIndexrec +1;
				logDebug2("Total No of Packets: counter %d ",iIndexrec);
				//logDebug2("AccCodeBy Nitish [%s]",(( struct NNF_ORDER_ENTRY * )cWrite_mess)->sAccCode);
				iWrite_status = WriteMsgQ(iQidnormal,cWrite_mess,iQueue_bytes,1);

				if ( iWrite_status == ERROR)
				{
					memset(cError,NULL,SIZE);
					strcpy(cError,"ERROR in WriteMsgQ function ");
					fExit(ERROR);
				}
			}

			if (iTimeStampUpdateFlag == TRUE)  
			{
				iTempTime1 = pTempTimeStamp.LogTime1;
				iTempTime2 = pTempTimeStamp.LogTime2;
				logDebug2("DOWNLAOD PKT  LastMesgTime1= %u,LastMesgTime2=%u ",iTempTime1,iTempTime2 );
			}
		} 
	}

	logTimestamp("Exit : fReceiveReplyPackets");
	/* ------- while loop ends -----------------------*/
}						/* -- Recieve Reply packets function ---- */

void 	fDeal_with_LogResult(LONG32 iLog_result)
{
	logTimestamp("Entry : fDeal_with_LogResult");

	if (iLog_result == TRUE )
	{
#ifdef DBG
		logDebug2("EquNseConnect.pc SUCCESS ");
#endif
	}
	else
	{
#ifdef DBG
		logDebug2("EquNseConnect.pc FAILED ");
#endif	
	}
#ifdef DBG
	logDebug2("EquNseConnect.pc The iLog_result is %d ",iLog_result);
#endif

	logTimestamp("Exit : fDeal_with_LogResult");

}

void 	fdeal_with_Socket(LONG32 isockfd)
{
	logTimestamp("Entry : fdeal_with_Socket");

	if (isockfd < 0)
	{
#ifdef DBG
		logDebug2("EquNseConnect.pc Fatal Socket Error :: closed ");
#endif
		exit(ERROR);
	}
	else
	{
#ifdef DBG
		logDebug2("EquNseConnect.pc Socket connected :: socket id %d ",isockfd);
#endif
	}
	logTimestamp("Exit : fdeal_with_Socket");

}

void 	fDeal_with_SendRecv(LONG32 iRecv_bytes, LONG32 iGroupId)
{
	logTimestamp("Entry : fDeal_with_SendRecv");

	LONG32	iSql_groupid;
	iSql_groupid = iGroupId;
	if ( iRecv_bytes <= 0 )
	{
		logDebug2("EquNseConnect.pc Send / Recv Error or socket close request....%d bytes recvd  ",iRecv_bytes);
		logDebug2("Group id Recvd in fDeal_with_SendRecv is %d ", iGroupId );
		logDebug2("Sql variable groupid is %d ", iSql_groupid );

		fConnectUpdt(NSE_EQU_DOWN, iGroupId,0);// ,BCAST_YES,FALSE);

		if(fSend_exch_down_nse( iGroupId ) == ERROR) 
		{
			logDebug2("Error in send_exch_down_nse at prLONG32ing at place fDeal_with_SendRecv");
		}

		//kill(getppid(),SIGTERM);
		fExit(0);
	}
	logDebug2("End Of fDeal_with_SendRecv the no.of bytes sent / recieved are [%d] ",iRecv_bytes);	
	logTimestamp("Exit : fDeal_with_SendRecv");

}

void	fExit( LONG32 Error)
{
	logTimestamp("Entry : fExit");

	CHAR	sProgTime[40];
	memset(sProgTime,'\0',40);	
	logDebug2("EquNseConnect.pc In exit Fun");
	fGetTime(sProgTime);
	logDebug2("[%s] IST:PROGRAM EXIT TIME",sProgTime);
	kill (getppid(),SIGTERM);
	//exit(Error);
	logTimestamp("Exit : fExit");

}


void 	fReceiveInvitationPacket (LONG32 iSockfd1,LONG32 iGroupId)
{
	logTimestamp("Entry : fReceiveInvitationPacket");

	//	fd_set	ActiveSocketSet;
	//   	fd_set  ReadSocketSet;
	//   	LONG32  MaxSocketId;
	CHAR  	sInvPacket[NSE_PACKET_SIZE];
	LONG32  iRecv_bytes;
	LONG32 	iSeqNo;
	//   	LONG32 	Retval;
	LONG32 	iLen;
	INT16 	iMsgCode;
	LONG32 	iPPid,iDownkill;
	CHAR 	cDummyChar;
	CHAR 	sProgTime[40];
	memset(sProgTime,'\0',40);

	SHORT 	iCount;
	LONG32 	iGid;

	struct 	InvitationCount	*pInvcount;
	iGid = iGroupId -1;
	logDebug2("============================ Waiting for Invitation Packet ============================");
	iRecv_bytes = RECV(iSockfd1,sInvPacket);
	TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode);
	TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgLength);
	TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->invitation_count);
	logDebug2("fReceiveInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode);
	if(((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode == TC_EQU_NSE_INVITATION_REQ)
	{ 
		logDebug2("fReceiveInvitationPacket Invitation Packet Received");
	}

	fDeal_with_SendRecv( iRecv_bytes , iGroupId );

	iLen = ((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgLength;
	iMsgCode = ((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode;
	if(iMsgCode == TC_EQU_NSE_INVITATION_REQ)
	{
		iCount = ((struct INVITATION_PACKET *)sInvPacket)->invitation_count;
		logDebug2("fReceiveInvitationPacket iCount : [%d]  GroupId:[%d]",iCount,iGroupId);

		LockShm(InvitationCountShm);

		pInvcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);

		if ( *( (LONG32 *) pInvcount) == ERROR )
		{
			logDebug2 ("Error in Creating Shm ");
			perror ("Creating Shm InvitationCountShm Failed ");	
			exit(1);
		}
		pInvcount->InvCount_group[iGid].iInvPacketCount = pInvcount->InvCount_group[iGid].iInvPacketCount + iCount;

		if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
		{
			logDebug2 ("Error in Closing Shm ");
			exit(1);
		}

		UnLockShm(InvitationCountShm);
		logDebug2("SeqNo before switch is :[%d] GroupId is :[%d]",iSeqNo,iGroupId); 

		/**** TAP Reg Changes *****/ 
		iRecieveSeq ++;
		iSeqNo =  iRecieveSeq ; 
		iCounterTotalInvite++;

		fflush(fpOrderNum);

		logDebug2("============================ Received Invitation Packet : [%d] ============================",iSeqNo);

	}
	logTimestamp("Exit : fReceiveInvitationPacket");

}

void 	fReduceInvitationCount(iGid)
{
	logTimestamp("Entry : fReduceInvitationCount");

	LONG32	iGroupId;
	struct 	InvitationCount * pInvcount;
	CHAR 	sProgTime[40];
	memset(sProgTime,'\0',40);
	iGroupId = iGid - 1;

	LockShm(InvitationCountShm);
	pInvcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);

	if ( *( (LONG32 *) pInvcount) == ERROR )
	{
		logDebug2 ("Error in Creating Shm ");
		exit(1);
	}	

	pInvcount->InvCount_group[iGroupId].iInvPacketCount--;
	logDebug2("REDUCED INVITATION COUNT IS [%d]",pInvcount->InvCount_group[iGroupId].iInvPacketCount);

	if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
	{
		logDebug2 ("Error in Closing Shm ");
		exit(1);
	}
	UnLockShm(InvitationCountShm);
	logTimestamp("Exit : fReduceInvitationCount");

}

void 	fGetInvitationPacketCount(LONG32 * iInvPacketCount,LONG32 iGid)
{
	logTimestamp("Entry : fGetInvitationPacketCount");

	LONG32	iGroupId;
	struct 	InvitationCount * pInvcount;
	iGroupId = iGid -1;

	LockShm(InvitationCountShm);
	pInvcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);

	if ( *( (LONG32 *) pInvcount) == ERROR )
	{
		logDebug2 ("Error in Creating Shm ");
		exit(1);
	}

	*iInvPacketCount = pInvcount->InvCount_group[iGroupId].iInvPacketCount;
	if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
	{
		logDebug2 ("Error in Closing Shm ");
		exit(1);
	}
	UnLockShm(InvitationCountShm);
	logTimestamp("Exit : fGetInvitationPacketCount");

}

fGetTime(CHAR *sProgTime)
{
	/**
	  logTimestamp("Entry : fGetTime");

	  CHAR	slocTime[40]  ;
	  time_t 	pCurrenttime  ;
	  LONG32 	yr = 1900    ;
	  struct 	tm tm        ;
	  memset(slocTime,'\0',40);
	  pCurrenttime = time(0)  ;       
	  tm = *localtime(&pCurrenttime);
	  yr = yr + tm.tm_year  ;
	  sprintf(slocTime,"TIME : %d:%d:%d DATE : %d-%d-%d",tm.tm_hour,tm.tm_min,tm.tm_sec,tm.tm_mday, tm.tm_mon, yr);
	  memcpy(sProgTime,&slocTime,40);
	  logTimestamp("Exit : fGetTime");
	 ***/
}

LONG32 	fHandleInvitationPacket (LONG32 iSockfd1,LONG32 iGroupId)
{
	logTimestamp("Entry : fHandleInvitationPacket");	

	//	fd_set	ActiveSocketSet;
	//   	fd_set	ReadSocketSet;
	//   	LONG32  MaxSocketId;
	CHAR  	sInvPacket[NSE_PACKET_SIZE];
	LONG32  iRecv_bytes;
	LONG32  iSeqNo;
	//   	LONG32 	Retval;
	LONG32 	iLen;
	INT16 	iMsgCode;
	LONG32 	iPPid,iDownkill;
	char 	sProgTime[40];
	memset(sProgTime,'\0',40);

	SHORT 	iCount;
	LONG32 	iGid;

	struct 	InvitationCount	*pInvcount;
	iGid = iGroupId -1;
	logDebug2("============================ Waiting for Invitation Packet ============================");

	iRecv_bytes = RECV(iSockfd1,sInvPacket);
	if( iRecv_bytes <= 0 )
	{
		logDebug2("In handle Invitation packet ---Failed Recv"); 
		return FALSE;
	}
	else
	{
		logDebug2("fHandleInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode);
		TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode);
		if(((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode == TC_EQU_NSE_INVITATION_REQ)
		{
			logDebug2("fHandleInvitationPacket Invitation Packet Received");
		}
		TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgLength);
		iLen = ((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgLength;
		iMsgCode = ((struct INVITATION_PACKET *)sInvPacket)->pHeader.iMsgCode;
		if(iMsgCode == TC_EQU_NSE_INVITATION_REQ)
		{
			TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->invitation_count);
			iCount = ((struct INVITATION_PACKET *)sInvPacket)->invitation_count;
			logDebug2("fReceiveInvitationPacket iCount : [%d]",iCount);

			LockShm(InvitationCountShm);
			pInvcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);

			if ( *( (LONG32 *) pInvcount) == ERROR )
			{
				logDebug2 (" Error in Creating Shm ");
				exit(1);
			}
			pInvcount->InvCount_group[iGid].iInvPacketCount = pInvcount->InvCount_group[iGid].iInvPacketCount + iCount;
			logDebug2("Nitish here is %d count %d",pInvcount->InvCount_group[iGid].iInvPacketCount,iCount);
			logDebug2("alok testing bfr CloseSharedMemory ");

			if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
			{
				logDebug2 ("Error in Closing Shm ");
				exit(1);
			}
			UnLockShm(InvitationCountShm);

			/**** TAP Reg Changes *****/ 
			iRecieveSeq ++;
			iSeqNo =  iRecieveSeq ; 
			iCounterTotalInvite++;

			fflush(fpOrderNum);
			logDebug2("======================= Handle Invitation Packet : [%d] =========================",iSeqNo);
		}
		else
		{
			logDebug2("in flase cae of Handle Invitation Packet ");
			return FALSE;
		}	
	}
	logDebug2("returning true in Handle inv packet");
	logTimestamp("Exit : fHandleInvitationPacket");
	return TRUE;

}


void 	fConvertSeqNO(CHAR *cRecvgen, CHAR *sTempSeqNo)
{
	logTimestamp("Entry : fConvertSeqNO");

	CHAR	sSeqArr1[2];
	SHORT 	iSeq1=0;
	SHORT 	i;
	LONG32 	iTemp = 0;
	CHAR 	*cRecv_temp;
	CHAR 	sProgTime[40];
	//USHORT 	d[16];    
	USHORT 	d[32];    
	cRecv_temp = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	logDebug2("----------In fConvertSeqNO Function: ------------");
	memset( sSeqArr1,'\0',2);  
	cRecv_temp = cRecvgen;
	d[0]    =	((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b1 ;
	d[1]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b2 ;
	d[2]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b3 ;
	d[3]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b4 ;
	d[4]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b5 ;
	d[5]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b6 ;
	d[6]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b7 ;
	d[7]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b8 ;
	d[8]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b9 ;
	d[9]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b10 ;
	d[10]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b11 ;
	d[11]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b12 ;
	d[12]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b13 ;
	d[13]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b14 ;
	d[14]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b15 ;
	d[15]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b16 ;
	d[16]    =	((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b17 ;
	d[17]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b18;
	d[18]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b19;
	d[19]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b20;
	d[20]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b21;
	d[21]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b22;
	d[22]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b23;
	d[23]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b24;
	d[24]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b25;
	d[25]    =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b26 ;
	d[26]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b27 ;
	d[27]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b28 ;
	d[28]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b29 ;
	d[29]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b30 ;
	d[30]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b31 ;
	d[31]   =       ((struct NNF_ORDER_ENTRY *)cRecv_temp)->pExchRsrvdFlds.b32 ;

	//	logDebug2("------------------ Seq [%s] ",((struct NNF_ORDER_ENTRY *)cRecv_temp)->sSeq);
	//	memcpy(sSeqArr1,((struct NNF_ORDER_ENTRY *)cRecv_temp)->sSeq,2);
	/**
	  iSeq1 = atoi(sSeqArr1);
	  logDebug2("----------------------------- Seq1 [%d]", iSeq1);
	 **/                 /***    */    
	//for(i=0;i<=15;i++)
	for(i=0;i<=31;i++)
	{
		logDebug2("[%d] ",d[i]);
	} /****/
	i=31;
	iTemp = d[i];
	while(i>0)
	{
		iTemp = iTemp * 2 + d[i-1];
		i--;
	}
	/**
	  iTemp = iTemp + iSeq1*65535 ;
	  sprintf( sTempSeqNo, "%d"    , iTemp);
	 **/
	sprintf( sTempSeqNo, "%d"    , iTemp);
	logDebug2("In fConvertSeqNO function sTempSeqNo is : [%s]",sTempSeqNo);
	logTimestamp("Exit : fConvertSeqNO");

}

void 	fInitSharedMemory(LONG32 iGid )  /** Added for inv initialization **/
{
	logTimestamp("Entry : fInitSharedMemory");

	LONG32	iGroupId;
	struct 	InvitationCount * pInvcount;
	iGroupId = iGid -1;

	LockShm(InvitationCountShm);
	pInvcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);

	if ( *( (LONG32 *) pInvcount) == ERROR )
	{
		logError ("Error in Creating Shm InvitationCountShm ");
		exit(1);
	}

	pInvcount->InvCount_group[iGroupId].iInvPacketCount=0;
	logDebug1("SHARED MEMORY INITIAL VALUE[%d]",pInvcount->InvCount_group[iGroupId].iInvPacketCount);

	if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
	{
		logError ("Error in Closing Shm ");
		exit(1);
	}
	UnLockShm(InvitationCountShm);
	logTimestamp("Exit : fInitSharedMemory");

}

/*************** TAP Reg Changes*******************/
/***
  void 	fUpdateTimeStamp( )  
  {
  logTimestamp("Entry : fUpdateTimeStamp");

  SHORT	j;
  LONG32	iGroupId=0;
  SHORT   iStreamId =0;
  ULONG32 iTime1 =0;
  ULONG32 iTime2 =0 ; 
  logDebug2(" iGlobGroupId : %d", iGlobGroupId);
  iGroupId =iGlobGroupId;
  logDebug2("Local GroupId : %d", iGroupId);

  logDebug2("===========GlobGroupId [%d]====Updating  Timestamp ",iGroupId);
  for ( j=1 ; j <= iTotalStream; j++)
  {
  iStreamId = Msg_Dow_Data[j].Stream_Id ;
  iTime1     = Msg_Dow_Data[j].TimeStamp1 ;
  iTime2     = Msg_Dow_Data[j].TimeStamp2 ; 

  logDebug2("iStreamId : %d Time1 :%u Time2 :%u ", iStreamId, iTime1, iTime2); 
  }
  logTimestamp("Exit : fUpdateTimeStamp");

  }
 ***/
/***
  BOOL fInsertExchDigital( )
  {
  SHORT	iNoStreams =0, j=0;
  LONG32  iGroupId=0;
  SHORT   iStreamId =0;
  ULONG32 Time1 =0;
  ULONG32 Time2 =0 ;

  logDebug2("iGlobGroupId : %d iTotalStream :%d ", iGlobGroupId, iTotalStream);
  iGroupId =iGlobGroupId;
  iNoStreams = iTotalStream ;
  logDebug2("Local iGroupId : %d", iGroupId);

  logDebug2("===========iGlobGroupId [%d]== iTotalStream [%d]== \n",iGroupId, iNoStreams);
  for ( j=1 ; j <= iNoStreams; j++)
  {
  iStreamId = j;


  }
  return TRUE ;

  }
 ****/
/************ END of TAP Reg Changes*******************/

void	fConnectUpdt(SHORT iExchConnFlg,LONG32 iGroupID,LONG32 iErrorID)
{
	logTimestamp("Entry [fConnectUpdt]");

	logDebug1("iExchConnFlg :%d: iGroupID :%d: iErrorID :%d:",iExchConnFlg,iGroupID,iErrorID);	

	fUpdateConnectStatus(iExchConnFlg,iGroupID);	
	/* 
	if(iExchConnFlg == NSE_EQU_DOWN)
	{
		NotifyMonTool(FALSE,iErrorID);
	}
	else
	{
		NotifyMonTool(TRUE,iErrorID);
	}				
	 */


	logTimestamp("Exit [fConnectUpdt]");
}
/*
   void NotifyMonTool(BOOL Status,LONG32 iErrorID)
   {

   CHAR sCmd[200];
   memset(sCmd,'\0',200);
   sprintf(sCmd,"%s/ExchStats.py %s %c %s %d >> %s/log.ExchStats &",getenv("PYTHON_PATH"),NSE_EXCH,EQUITY_SEGMENT,Status==1?"UP":"DOWN",iErrorID,getenv("LOGDIR"));
   logDebug2("Command -> %s",sCmd);
   system(sCmd);

   }
 */
