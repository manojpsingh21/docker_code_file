#include <sys/socket.h>
#include <stdlib.h>
#include "IPCS.h"
#include "NseEQNNFStruct.h"

extern 	iTransmitSeq,iRecieveSeq;
extern 	iTotalStram;	
extern 	iConnToTrdMapNSECur;

BOOL	fSendSysInfoReq(CHAR *sSendmsg)
{
	logTimestamp("Entry : [SendSysInfoReq]");

	struct	NNF_SYS_INFO_REQ *pSysReq;		
	BOOL	iSendFlg =FALSE;

	pSysReq = (struct NNF_SYS_INFO_REQ *)malloc(sizeof(struct NNF_SYS_INFO_REQ));

	pSysReq->sHeader.iReserved = 0;
	pSysReq->sHeader.iLogTimeStamp = 0;
	memset(pSysReq->sHeader.sAlphaSplit ,SPACE,ALPHA_SPLIT_LEN);
	pSysReq->sHeader.iMsgCode= 0;
	pSysReq->sHeader.iErrorCode= 0;
	memset(pSysReq->sHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);
	memset(pSysReq->sHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	memset(pSysReq->sHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	pSysReq->sHeader.iMsgLength= 0;



	memcpy(pSysReq->sHeader.sAlphaSplit , "NT",ALPHA_SPLIT_LEN);
	pSysReq->sHeader.iMsgCode= TC_EQU_NSE_SYS_INFO_REQ;
	pSysReq->sHeader.iMsgLength= sizeof(struct NNF_SYS_INFO_REQ);

	TWIDDLE(pSysReq->sHeader.iMsgCode);
	TWIDDLE(pSysReq->sHeader.iLogTimeStamp);
	TWIDDLE(pSysReq->sHeader.iErrorCode);


	memcpy(sSendmsg,(CHAR *)pSysReq,sizeof(struct NNF_SYS_INFO_REQ));

	logTimestamp("Exit : [SendSysInfoReq]");
}


BOOL	fRecvSysInfo(CHAR *sRcvMsg)
{
	CHAR	*sDataMsg;
	INT16	 i;
	sDataMsg = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	memcpy(sDataMsg,sRcvMsg,sizeof(struct NNF_SYS_INFO_RESP));		
	BOOL	iUpdFlag = FALSE;

	iTotalStram = ((struct NNF_HEADER *)sRcvMsg)->sAlphaSplit;
	for(i=0;i < iTotalStram;i++)
	{
		Msg_Dow_Data[i].iStream_Id = i;	
		Msg_Dow_Data[i].iStream_Flag= 1;	
		Msg_Dow_Data[i].iTimeStamp1= 0;	
		Msg_Dow_Data[i].iTimeStamp2= 0;	
	}

	iUpdFlag = fUpdSysInfo(sDataMsg);		

	if(iUpdFlag == TRUE)
	{
		fInsertExchDigit();	
		return TRUE;
	}
	else
	{
		return FALSE;
	}	

}

BOOL	fRecvDownloadResp(LONG32	iSockFd)
{
	BOOL	iCkFlag = FALSE;
	INT16	iBytRcv;
	CHAR	*sRcvMsg = (CHAR *)malloc(sizeof(CHAR) * NSE_PACKET_SIZE);		
	LONG32	iTempCode,iTemSeqNo = 0,iTempLen;
	CHAR	*sDataMsg;
	unsigned char	sDigest[DIGEST_LEN];

	struct	NNF_HEADER *sHeader;	
	struct	TAP_WRAPPER *pTapWrp;

	INT16	iDowCounter = 0;	
	sHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	memset(sHeader,'\0',sizeof(struct NNF_HEADER));
	pTapWrp = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTapWrp ,'\0',sizeof(struct TAP_WRAPPER));

	BOOL	iTimeStampUpdateFlag = FALSE;

	while(TRUE)
	{


		iCkFlag = fHndleInvitnPack(iSockFd,1);

		if(iCkFlag == TRUE)
		{
			logInfo("This is an Invitation Packet");
		}	
		else
		{
			iBytRcv = fTcpRecv(iSockFd,sRcvMsg);	
			iCkFlag = FALSE;

			if(iBytRcv <= 0)
			{

			}

			memcpy(sHeader ,sRcvMsg,sizeof(struct NNF_HEADER));	
			memcpy(pTapWrp,sRcvMsg,sizeof(struct TAP_WRAPPER));

			TWIDDLE(sHeader->iMsgCode);	
			TWIDDLE(sHeader->iMsgLength);	
			iRecieveSeq++;
			iTemSeqNo = iRecieveSeq;

			TWIDDLE(pTapWrp->iSeqNo);
			TWIDDLE(pTapWrp->iMsgLen);

			if(iTemSeqNo != pTapWrp->iSeqNo)
			{
				logFatal("Error in Seq");
				close(iSockFd);
				exit(ERROR);
			}

			iTempLen = sHeader->iMsgLength;
			sDataMsg = (CHAR *)malloc(iTempLen);

			memcpy(sDataMsg , sRcvMsg + sizeof(struct TAP_WRAPPER) ,iTempLen);

			MD5_Digest(sDigest,pTapWrp->sDigest,DIGEST_LEN);

			if(strncmp(sDigest,pTapWrp->sDigest,DIGEST_LEN) != 0)
			{
				logFatal("Mismatch in MD5 Checksum ....closing TAP BOX Connection..");
				close(iSockFd);
				exit(ERROR);
			}

			switch(iTempCode)
			{
				case TC_EQU_NSE_SYS_INFO_RESP :
				case TC_EQU_NSE_PARTIAL_SYS_INFO_RESP:
					iCkFlag = fRecvSysInfo(sRcvMsg);			
					break;
				case TC_EQU_NSE_UPDATE_LDB_HEADER_RESP:
					logInfo(" Update Database Header Messg :: recieved ");
					iTimeStampUpdateFlag = FALSE;

					break;
				case TC_EQU_NSE_UPDATE_LDB_DATA_RESP:
					iCkFlag = fLdbDataUpd(sRcvMsg);	

					break;
				case TC_EQU_NSE_UPDATE_LDB_TRAILER_RESP:
					logInfo("Ufpdate Database Trailer Messg :: recieved ");
					iCkFlag = TRUE;

					break;
				case TC_EQU_NSE_MSG_DOWNLOAD_START_RESP :

					logInfo("Update Download Start ");
					iCkFlag = TRUE;

					break;
				case TC_EQU_NSE_MSG_DOWNLOAD_DATA_RESP :
					logInfo("------------==========Packet Recv in Download==========------------ ");
					iCkFlag = fMsgDownLdDataResp(sRcvMsg);	
					break;
				case TC_EQU_NSE_MSG_DOWNLOAD_END_RESP:
					logInfo("Message Area trailer Messg :: recieved");
					iTimeStampUpdateFlag = TRUE;
					iDowCounter++;

					if(iDowCounter == iTotalStram)				
					{
						iCkFlag = TRUE;
					}
					else
					{
						iCkFlag = FALSE;
					}

					break;
				default :
					logInfo("Invalid MsgCode Recv");
					break;

			};

		}

		return iCkFlag;
	}


}

BOOL	fSendReqToNse(LONG32 iReqCode,LONG32 iSockFd)
{
	struct TAP_WRAPPER *pTapWrp;
	struct NNF_HEADER *sHeader;	

	CHAR 	*sSendInfo;
	CHAR 	*sSendTap;
	CHAR 	*sMsgTAP;
	CHAR	*sTempMsg;

	CHAR	sDigest[DIGEST_LEN];

	BOOL	iIsSend = FALSE;

	LONG32	iMsgSize = 0;
	LONG32	iSendBytes = 0,iInvPack = 0;
	LONG32	iTempStream = 0,j;

	sTempMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	sHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));

	memset(pTapWrp,NULL,sizeof(struct TAP_WRAPPER));

	switch(iReqCode)
	{
		case TC_EQU_NSE_SYS_INFO_REQ :
			sSendInfo = (CHAR *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
			sSendTap = (CHAR *)malloc(sizeof(struct NNF_SYS_INFO_REQ) + sizeof(struct TAP_WRAPPER));		
			fSendSysInfoReq(sSendInfo);				
			iMsgSize = sizeof(struct NNF_SYS_INFO_REQ);
			TWIDDLE(((struct NNF_HEADER *)(sSendInfo))->iMsgLength);

			MD5_Digest(sDigest,sSendInfo,iMsgSize);
			iMsgSize = iMsgSize + sizeof(struct TAP_WRAPPER);				
			pTapWrp->iMsgLen = iMsgSize;

			iTransmitSeq++;
			pTapWrp->iSeqNo = iTransmitSeq;	

			TWIDDLE(pTapWrp->iMsgLen);
			TWIDDLE(pTapWrp->iSeqNo);

			memcpy(pTapWrp->sDigest,sDigest,DIGEST_LEN);
			memcpy(sSendTap,pTapWrp,sizeof(struct TAP_WRAPPER));
			memcpy(sSendTap + sizeof(struct TAP_WRAPPER),sSendInfo,sizeof(struct NNF_SYS_INFO_REQ));
			iIsSend = FALSE;

			break;

		case TC_NSE_UPD_LDB_DOWNLD_REQ:
			sSendInfo = (CHAR *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));
			sSendTap = (CHAR *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ) + sizeof(struct TAP_WRAPPER));		

			fSendUpdReq(sSendInfo);  /** EAM_LAST_UPDATE_PART_TIME FROM EXCH_ADMINISTRATION_MASTER */

			iMsgSize = sizeof(struct NNF_UPDATE_LDB_REQ);
			TWIDDLE(((struct NNF_HEADER *)(sSendInfo))->iMsgLength);

			MD5_Digest(sDigest,sSendInfo,iMsgSize);
			iMsgSize = iMsgSize + sizeof(struct TAP_WRAPPER);
			pTapWrp->iMsgLen = iMsgSize;

			iTransmitSeq++;
			pTapWrp->iSeqNo = iTransmitSeq;

			TWIDDLE(pTapWrp->iMsgLen);
			TWIDDLE(pTapWrp->iSeqNo);

			memcpy(pTapWrp->sDigest,sDigest,DIGEST_LEN);
			memcpy(sSendTap,pTapWrp,sizeof(struct TAP_WRAPPER));
			memcpy(sSendTap + sizeof(struct TAP_WRAPPER),sSendInfo,sizeof(struct NNF_UPDATE_LDB_REQ));
			iIsSend = FALSE;

			break;
			/***/

		case TC_NSE_MSG_DOWNLOAD_REQ:
			sSendInfo = (CHAR *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
			sSendTap = (CHAR *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ) + sizeof(struct TAP_WRAPPER));	

			fGetStream(&iTempStream);	

			for(j =1 ;j< iTempStream;j++)
			{
				while(TRUE)
				{
					fGetInvPackCnt(&iInvPack,1);

					if(iInvPack > 0)
					{
						break;
					}
				}


				fSendMsgDwnLd(sSendInfo,j);	

				memset((((struct NNF_HEADER *)(sSendInfo))->sAlphaSplit),'\0',ALPHA_SPLIT_LEN);
				sprintf((((struct NNF_HEADER *)(sSendInfo))->sAlphaSplit),"%d",j);

				iMsgSize = ((struct NNF_HEADER *)(sSendInfo))->iMsgLength;			
				TWIDDLE((((struct NNF_HEADER *)(sSendInfo)))->iMsgLength);
				MD5_Digest(sDigest,sSendInfo,iMsgSize);
				iMsgSize = iMsgSize + sizeof(struct TAP_WRAPPER);
				pTapWrp->iMsgLen = iMsgSize;

				iTransmitSeq++;
				pTapWrp->iSeqNo = iTransmitSeq;

				TWIDDLE(pTapWrp->iMsgLen);
				TWIDDLE(pTapWrp->iSeqNo);

				memcpy(pTapWrp->sDigest,sDigest,DIGEST_LEN);
				memcpy(sSendTap,pTapWrp,sizeof(struct TAP_WRAPPER));
				memcpy(sSendTap + sizeof(struct TAP_WRAPPER),sSendInfo,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

				iSendBytes = fTcpSend(iSockFd,sSendTap,iMsgSize) ;

				if(iSendBytes <= 0)
				{
					return FALSE;
				}
				else
				{
					fReduceInvPack(1);
					iIsSend = TRUE;
					return TRUE;
				}


			}



			break;
			/***/
		default:

			break;
	};

	if(iIsSend == FALSE)
	{	

		while(TRUE)
		{
			fGetInvPackCnt(&iInvPack,1);

			if(iInvPack > 0)
			{
				break;
			}
		}

		iSendBytes = fTcpSend(iSockFd,sSendTap,iMsgSize)	;	

		if(iSendBytes <= 0)
		{
			return FALSE;
		}	
		else
		{
			fReduceInvPack(1);
			return TRUE;
		}
	}

}


BOOL	fLdbDataUpd(CHAR *sRcvMsg)
{
	logTimestamp("Entry :LdbDataUpd:");

	LONG32	iMsgLen;
	struct NNF_UPDATE_LDB_DATA_RESP *pLdbMsg = (struct NNF_UPDATE_LDB_DATA_RESP *)malloc(sizeof(struct NNF_UPDATE_LDB_DATA_RESP));
	CHAR	*sWrtMsg;

	memcpy(pLdbMsg,sRcvMsg,sizeof(struct NNF_UPDATE_LDB_DATA_RESP));

	TWIDDLE(pLdbMsg->sInnerHeader.iMsgLength);

	iMsgLen = pLdbMsg->sInnerHeader.iMsgLength;

	sWrtMsg = sRcvMsg +  sizeof(struct NNF_HEADER);

	if(WriteMsgQ(iConnToTrdMapNSECur,sWrtMsg,iMsgLen,1) != TRUE)
	{
		logFatal("Error in Writing on Q iQueueId ");
		exit(ERROR);
	}		

}

BOOL	fMsgDownLdDataResp(CHAR *sRcvMsg)
{
	struct NNF_MSG_DOWNLOAD_DATA_RESP *pDataDL;	
	struct NNF_DOUBLE_INT  pTempTimeStamp;
	CHAR    *sWrtMsg;
	LONG32	iMsgCode,iLength;
	CHAR	*sRecvTemp;
	CHAR	sTempSeqNo[9];

	pDataDL = (struct  NNF_MSG_DOWNLOAD_DATA_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));
	sRecvTemp = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	memcpy(pDataDL,sRcvMsg,sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));	
	memcpy(&pTempTimeStamp,pDataDL->sInnerHeader.sTimeStamp2,DATE_TIME_LEN);

	TWIDDLE(pDataDL->sInnerHeader.iMsgCode);
	TWIDDLE(pDataDL->sInnerHeader.iMsgLength);

	iMsgCode = pDataDL->sInnerHeader.iMsgCode;
	logDebug2("iMsgCode :%d:",iMsgCode);

	if(	iMsgCode == TC_INT_OE_CONF_RESP || iMsgCode == TC_INT_OC_ERROR_RESP || iMsgCode == TC_INT_OC_CONF_RESP ||
			iMsgCode == TC_INT_OM_CONF_RESP || iMsgCode == TC_INT_OE_ERROR_RESP || iMsgCode == TC_INT_OE_FREEZE_RESP  ||
			iMsgCode == TC_INT_OM_ERROR_RESP|| iMsgCode == TC_INT_TRADE_RESP    || iMsgCode == TC_INT_MKT_LMT_CONVT_RESP || 
			iMsgCode == TC_INT_NEG_ORD_CAN_RESP|| iMsgCode == TC_INT_NEG_ORD_REG_LOT_RESP|| iMsgCode ==TC_INT_NEG_ORD_ENT_CP_RESP 
	  )
	{
		sRecvTemp = sRcvMsg + sizeof(struct NNF_HEADER);
		fConvertSeqNo(sRecvTemp,sTempSeqNo);

		memset( ((struct NNF_ORDER_ENTRY *)sRecvTemp)->sRemarks ,' ',OE_REMARKS_LEN);
		strncpy( ((struct NNF_ORDER_ENTRY *)sRecvTemp)->sRemarks,";",1);
		memcpy ( ((struct NNF_ORDER_ENTRY *)sRecvTemp)->sRemarks + DELTA_REMARKS,sTempSeqNo, strlen(sTempSeqNo));

	}

	iLength =pDataDL->sInnerHeader.iMsgLength;
	sWrtMsg = sRcvMsg + sizeof(struct NNF_HEADER);

	if(WriteMsgQ(iConnToTrdMapNSECur,sWrtMsg,iLength,1) != TRUE)
	{
		logFatal("Error in Writing on Q iQueueId ");
		exit(ERROR);
	}	



}

BOOL	fConvertSeqNo(CHAR *sRecvStr,CHAR *sTempSeqNo)
{
	CHAR	sSeqArr[2];
	INT16	iSeq1=0,i;
	LONG32	iTemp = 0;
	CHAR	*sRecvTemp;
	USHORT	iTempVar[16];

	sRecvTemp = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);

	memset(sSeqArr,'\0',2);
	sRecvTemp = sRecvStr;

	iTempVar[0] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b1;
	iTempVar[1] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b2;
	iTempVar[2] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b3;
	iTempVar[3] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b4;
	iTempVar[4] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b5;
	iTempVar[5] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b6;
	iTempVar[6] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b7;
	iTempVar[7] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b8;
	iTempVar[8] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b9;
	iTempVar[9] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b10;
	iTempVar[10] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b11;
	iTempVar[11] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b12;
	iTempVar[12] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b13;
	iTempVar[13] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b14;
	iTempVar[14] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b15;
	iTempVar[15] = ((struct NNF_ORDER_ENTRY *)sRecvTemp)->pExchRsrvdFlds.b16;

	memcpy(sSeqArr,((struct NNF_ORDER_ENTRY *)sRecvTemp)->sSeq,2 );

	iSeq1 = atoi(sSeqArr);

	for(i = 0;i <=15;i++ )
	{
		logDebug2("iTempVar [%d] = ",i,iTempVar[i]);	
	}

	while(i > 0)
	{
		iTemp =iTemp * 2 + iTempVar[i - 1]; 
		i--;
	}

	iTemp = iTemp + iSeq1 * 65535;

	sprintf(sTempSeqNo,"%d",iTemp);
	logDebug2("sTempSeqNo :%s:",sTempSeqNo);


}
