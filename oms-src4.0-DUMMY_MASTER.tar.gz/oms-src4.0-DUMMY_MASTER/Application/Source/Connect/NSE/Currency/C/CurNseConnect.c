#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include "CurrNseStruct.h"

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void 	fConnectionUP();
void 	fConnectionDOWN();
void 	fRestartProcess();
BOOL 	fSendBusinessRejectFor();

LONG32  isConnected = FALSE; 

LONG32 	iTransmitSeq =0, iRecieveSeq =0 ;
LONG32	iConnCntr = 0;
LONG32  iSocket;
INT16	iMsgType;
CHAR	cSegment;
CHAR    sKey[DB_KEY_LEN];

LONG32	iTotalStram;
LONG32	iGroupId = 0;

LONG32	iOrdSrvToConnNSECR,iConnToTrdMapNSECur;

MYSQL	*DBConNCUR;


int main(LONG32 argc, CHAR **argv)
{
	logTimestamp("Entry :main:");
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	LONG32  mainwait = -1, sig1=0;

	BOOL	iChkFlg = FALSE;
	LONG32	iReplyChild=0,iTransmitChild=0;

	sigset_t SequenceSet;
	LONG32  iSocket,iRetval, iMaster_Port;
	LONG32  Signal;
	CHAR	sTapIPAddrs[IP_ADDR_LEN];	

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );
	memset(sTapIPAddrs,'\0',IP_ADDR_LEN);
	memset(sKey,'\0',DB_KEY_LEN);

	logInfo("Argc :%d:",argc);

	if(argc != 5)
	{
		logInfo("CNseConnect <GRUOP_ID> <TAP_IP> <TAP_PORT>");
		exit(ERROR);
	}

	logInfo(" PARAMETERS COUNT : %d", argc ) ;
	logDebug2("argv[2] :%s:",argv[2]);
	logDebug2("argv[3] :%s:",argv[3]);
	logDebug2("argv[4] :%s:",argv[4]);

	iGroupId	= atoi(argv[2]);
	strncpy(sTapIPAddrs,argv[3],IP_ADDR_LEN);	
	iMaster_Port = atol(argv[4]) ;

	strcpy(sKey,getenv("DB_AES_KEYS"));


	logDebug3(" PORT : %d", iMaster_Port ) ;
	logDebug3(" IP 	 : %s", sTapIPAddrs) ;

	DBConNCUR = DB_Connect();

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);
	sigaddset ( &SequenceSet, SIGUSR2);

	fOpenMsgQue();


	while(TRUE)
	{
		fConnectionDOWN();
		fInitMemory(iGroupId);
		iSocket= fConnectTAP(sTapIPAddrs,iMaster_Port);
		if(iSocket== ERROR)
		{
			logFatal("Error in Connection TAP ");
			exit(ERROR);
		}

		iTransmitSeq =0; 
		iRecieveSeq  =0 ;

		iChkFlg = fHandleSignOnReq(iSocket,iGroupId);

		if(iChkFlg == FALSE)
		{
			close(iSocket);
			continue;
		}
		else
		{
			fNseDownStart(iSocket);	
		}

		if((iReplyChild=fork()) == 0)
		{
			logTimestamp("iReplyChild Created");
			fReplyChild(iSocket);
		}
		else if((iTransmitChild=fork()) == 0)
		{
			logTimestamp("iTransmitChild Created");
			fTransmitChild(iSocket);	
		}

		if(iReplyChild == 0 && iTransmitChild == 0 )
		{
			fConnectionUP();
		}


		while( TRUE )
		{
			sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
			logInfo("Waiting For Signal");
			mainwait = sigwait( &SequenceSet,&Signal);
			logDebug1("Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				logInfo("SIGTERM in Main");
				fConnectionDOWN();
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				fSendBusinessRejectFor();
				close(iSocket);
				logFatal("Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				logInfo("SIGUSR1 in Main");
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				//close(iSocket);
				fSendBusinessRejectFor();
				close(iSocket);
				logFatal("Break from loop");
				break;
			}
			else if(Signal == SIGUSR2)
			{
				logInfo("SIGUSR2 in Main");
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				//close(iSocket);
				fSendBusinessRejectFor();					
				logFatal("Break from loop");
				break;
			}
			else
			{
				logInfo(" Received some other signal");
				logFatal(" Closing Socket");
				fConnectionDOWN();
				close(iSocket);
				logFatal("Exiting");
				exit(ERROR);
			}

		}
		logDebug1(" Socket Connection closed on : %d", iSocket);
		logInfo(" While Loop");
	}
	logTimestamp("Exit :main:");
}



void fRestartProcess()
{
	logTimestamp("Entry :fRestartProcess:");
	isConnected = FALSE ;
	fConnectionDOWN();
	logDebug1("getpid :%d:",getpid());
	kill(getpid(), SIGUSR1);
	logDebug1(" Sent Signal %d To pid %d", SIGUSR1, getpid());
	logTimestamp("Exit :fRestartProcess:");
	return;
}

void fRejectProcess()
{
	logTimestamp("Entry :fRejectProcess:");
	isConnected = FALSE ;
	fConnectionDOWN();
	logDebug1("getpid :%d:",getpid());
	kill(getpid(), SIGUSR2);
	logDebug1(" Sent Signal %d To pid %d", SIGUSR2, getpid());
	logTimestamp("Exit :fRejectProcess:");
	return;
}

BOOL fSendBusinessRejectFor()
{
	logTimestamp("Entry : [fSendBusinessRejectFor]");
	BOOL	iRetVal = FALSE ;
	LONG32	iMsgLen = 0;
	CHAR	*sReadMsg;
	struct NNF_HEADER *sHeader;

	sReadMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);

	while(TRUE)
	{
		if ((iRetVal = ReadNBQ(iOrdSrvToConnNSECR,sReadMsg,NSE_PACKET_SIZE, 1)) != TRUE)
		{
			logFatal(" Now no pending orders in queue");
			break;
		}

		logFatal(" Clearing pending orders in queue");
		sHeader = (struct NNF_HEADER *)sReadMsg;

		TWIDDLE(sHeader->iMsgLength);
		iMsgLen = sHeader->iMsgLength;		
		TWIDDLE(sHeader->iMsgCode);

		logDebug2("fSendBusinessRejectFor for iMsgCode :%d: MsgLen :%d:",sHeader->iMsgCode,iMsgLen);

		switch(sHeader->iMsgCode)
		{
			case TC_INT_ORDER_ENTRY_REQ :
				sHeader->iMsgCode = TC_INT_OE_ERROR_RESP;
				break;
			case TC_INT_ORDER_MODIFY:
				sHeader->iMsgCode = TC_INT_OM_ERROR_RESP;
				break;
			case TC_INT_ORDER_CANCEL:
				sHeader->iMsgCode = TC_INT_OC_ERROR_RESP;
				break;
			default :
				logInfo("Invalid iMsgCode :%d:",sHeader->iMsgCode);
				break;
		};

		sHeader->iErrorCode = EXCHANGE_DOWN_ERROR;
		TWIDDLE(sHeader->iMsgLength);
		TWIDDLE(sHeader->iMsgCode);
		TWIDDLE(sHeader->iErrorCode);

		if ((iRetVal=WriteMsgQ(iConnToTrdMapNSECur,sReadMsg,iMsgLen,1))== ERROR)
		{
			logFatal("Error in Sending Rej Msg");
			exit(ERROR);
		}
	}
	logTimestamp("Exit : [fSendBusinessRejectFor]");

}


void fConnectionUP()
{
	logTimestamp("Entry : [fConnectionUP]");
	fUpdateConnectStatus(NSE_CUR_UP, 0);
	logInfo("fUpdateConnectStatus UP");
	logTimestamp("Exit : [fConnectionUP]");
	//NotifyMonTool(TRUE);
	return;
}


void fConnectionDOWN()
{
	logTimestamp("Entry : [fConnectionDOWN]");
	fUpdateConnectStatus(NSE_CUR_DOWN, 0);
	logInfo(" fUpdateConnectStatus DOWN");
	//NotifyMonTool(FALSE);
	logTimestamp("Exit : [fConnectionDOWN]");
	return;
}

void NotifyMonTool(BOOL Status)
{

	CHAR sCmd[200];
	memset(sCmd,'\0',200);
	sprintf(sCmd,"%s/ExchStats.py %s %c %s >> %s/log.ExchStats &",getenv("PYTHON_PATH"),NSE_EXCH,CURRENCY_SEGMENT,Status==1?"UP":"DOWN",getenv("LOGDIR"));
	logDebug2("Command -> %s",sCmd);
	system(sCmd);

}

void fOpenMsgQue()
{
	logTimestamp("Entry : [fOpenMsgQue]");	
	if((iOrdSrvToConnNSECR= OpenMsgQ(OrdSrvToConnNSECR)) == ERROR)
	{
		perror("OpenMsgQ ...OrdSrvToConnNSECR");
		exit(ERROR);
	}
	logDebug1(" OrdSrvToConnNSECR opened successfully with id = %d", iOrdSrvToConnNSECR);

	if((iConnToTrdMapNSECur= OpenMsgQ(ConnToTrdMapNSECur)) == ERROR)
	{
		perror("OpenMsgQ ...ConnToTrdMapNSECur ");
		exit(ERROR);
	}
	logDebug1(" ConnToTrdMapNSECur opened successfully with id = %d", iConnToTrdMapNSECur);
	logTimestamp("Exit : [fOpenMsgQue]");	
}

LONG32 fConnectTAP(CHAR *sIPAddrs,LONG32 iTapPort)
{
	logTimestamp("Entry : [fConnectTAP]");

	struct  sockaddr_in cliadd, servadd;
	LONG32	iMasterSocket,iConnStat;
	INT16	iConnRetry=0,iSleepTime = 1;
	LONG32  iSize=512*1024;


	do
	{
		if ((iMasterSocket = socket(PF_INET, SOCK_STREAM, 0)) < 0)
		{
			perror("socket: ");
			logFatal(" Error in creating the iMasterSocket");
			exit(ERROR);
		}
		logDebug3(" Socket Created : %d", iMasterSocket);

		if(iMasterSocket > 0)
		{

			logDebug2("sIPAddrs :%s:",sIPAddrs);	
			logDebug2("iTapPort :%d:",iTapPort);	

			memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
			servadd.sin_family      = AF_INET;
			servadd.sin_port        = htons(iTapPort);
			servadd.sin_addr.s_addr = inet_addr(sIPAddrs);
		}
		else
		{
			perror("Connection To TAP Fails ,Reason :");
			return ERROR;
		}	


		iConnStat = connect(iMasterSocket,(struct sockaddr *) &servadd, sizeof(servadd));
		logDebug3("iConnStat :%d:",iConnStat);

		if(iConnStat  < 0)	
		{
			close(iConnStat);
			sleep(iSleepTime++);		

			if(iConnRetry > 3)
			{
				logFatal("Retry Connection is Done...Not  Able to Connect to TAP is Disable");
				return ERROR;
			}
			else
			{
				iConnRetry++;
				continue;	
			}

		}	

		if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&iSize, sizeof(iSize))<0)
		{
			perror("setsockopt: ");
			logFatal(" Error in setsockopt on the MasterSocket:SO_RCVBUF:");
			exit(1);
		}

		if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&iSize, sizeof(iSize))<0)
		{
			perror("setsockopt: ");
			logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
			exit(1);
		}

		if (setsockopt(iMasterSocket, SOL_SOCKET, SO_KEEPALIVE, (char *)&iSize, sizeof(iSize))<0)
		{
			perror("setsockopt: ");
			logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
			exit(1);
		}

	}
	while(iConnStat != 0);
	logTimestamp("Exit : [fConnectTAP]");

	return iMasterSocket;

}

BOOL	fHandleSignOnReq(LONG32	iMasterSocket,LONG32	iGroupId)
{
	logTimestamp("Entry : [fHandleSignOnReq]");

	struct 	TAP_WRAPPER 		*pTap_wrap;
	struct 	NNF_HEADER 		*sHeader;
	struct 	INVITATION_PACKET 	*pInv_packet;
	struct 	InvitationCount 	*pInvcount;	

	unsigned char sDigest[DIGEST_LEN];

	CHAR   	*sSendsign;
	CHAR 	*sSendsignTAP;
	CHAR	*sRecvData;
	CHAR	sRecvSignOn[NSE_PACKET_SIZE];
	CHAR	sErrorMsg[200];
	CHAR	Ferror[80];

	BOOL	iChkFlag = FALSE;
	LONG32	iTempLen,iTempiMsgCode;
	LONG32	iSendBytes,iInvPackCnt,iRecvBytes;
	LONG32	iRecvLen,iTempSeqNo = 0;
	LONG32	iErriMsgCode;


	sSendsign = (char *)malloc(sizeof(struct NNF_SIGNON_REQ));
	pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTap_wrap,'\0',sizeof(struct TAP_WRAPPER));
	sHeader	= (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
	memset(sHeader,'\0',sizeof(struct NNF_HEADER));
	sSendsignTAP = (char *)malloc(sizeof(struct NNF_SIGNON_REQ) + sizeof(struct TAP_WRAPPER));
	memset(sErrorMsg,'\0',200);
	memset(Ferror,'\0',80);

	if(  (fHndleInvitnPack(iMasterSocket)) == FALSE )
	{
		iConnCntr++;
		logInfo("Received <=0 byte:closing TAP BOX Connection..");
		return FALSE;
	}
	logInfo("Before Calling HandleSignon at ");	

	iChkFlag = fFetchSignOnDet(sSendsign,iGroupId);		

	if(iChkFlag == FALSE)
	{
		logFatal("Error in SendSignOn ");
		exit(ERROR);
	}	

	memcpy(sHeader,sSendsign,sizeof(struct NNF_HEADER));
	TWIDDLE(sHeader->iMsgLength);
	iTempLen = sHeader->iMsgLength;
	iTempiMsgCode = sHeader->iMsgCode;

	MD5_Digest(sDigest,sSendsign,iTempLen);

	pTap_wrap = (CHAR *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));

	iTempLen = iTempLen + sizeof(struct TAP_WRAPPER);

	pTap_wrap->iMsgLen = iTempLen;
	iTransmitSeq++;

	pTap_wrap->iSeqNo = iTransmitSeq;

	memcpy(pTap_wrap->sDigest,sDigest,DIGEST_LEN);

	TWIDDLE(pTap_wrap->iSeqNo);
	TWIDDLE(pTap_wrap->iMsgLen);

	logDebug2("pTap_wrap->iSeqNo :%d:  pTap_wrap->iMsgLen :%d:",pTap_wrap->iSeqNo,pTap_wrap->iMsgLen);

	memcpy(sSendsignTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
	memcpy(sSendsignTAP + sizeof(struct TAP_WRAPPER),sSendsign,sizeof(struct NNF_SIGNON_REQ));

	iSendBytes = fTcpSend(iMasterSocket,sSendsignTAP,iTempLen);	

	fReduceInvPack(iGroupId);


	fGetInvPackCnt(&iInvPackCnt,iGroupId);	

	if(iInvPackCnt == 0)
	{
		/*
		   iRecvBytes =  fTcpRecvInvPack(iMasterSocket,sRecvSignOn);		

		   if(iRecvBytes <= 0)
		   {
		   iConnCntr++;		
		   logDebug2("iRecvBytes is 0 with Connection Counter :%d:",iConnCntr);
		   return FALSE;
		   }
		   else		
		   {
		 */
		if(fHndleInvitnPack(iMasterSocket,iGroupId)== FALSE)
		{
			//			iConnCntr++;
			logDebug2("iRecvBytes is 0 with Connection Counter :%d:",iConnCntr);
			return FALSE;

		}

	}

	iRecvBytes = fTcpRecv(iMasterSocket,sRecvSignOn);

	if(iRecvBytes <= 0)
	{
		iConnCntr++;
		logDebug2("iRecvBytes is 0 with Connection Counter :%d:",iConnCntr);
		fRestartProcess();
	}

	memcpy(sHeader,sRecvSignOn+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));

	TWIDDLE(sHeader->iMsgLength);	

	iRecvLen = sHeader->iMsgLength;
	sRecvData = (CHAR *) malloc(iRecvLen);	

	memcpy(sRecvData,sRecvSignOn,sizeof(struct TAP_WRAPPER));
	memcpy(pTap_wrap,sRecvSignOn,sizeof(struct TAP_WRAPPER));	

	iRecieveSeq++;	

	iTempSeqNo = iRecieveSeq;	

	TWIDDLE(pTap_wrap->iSeqNo);

	logDebug2("pTap_wrap->iSeqNo :%d:",pTap_wrap->iSeqNo);

	if(iTempSeqNo != pTap_wrap->iSeqNo)	
	{
		logFatal("FATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection..");
		close(iMasterSocket);
		exit(ERROR);
	}

	memcpy(sHeader,sRecvSignOn+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));

	TWIDDLE(sHeader->iMsgLength);

	iRecvLen = sHeader->iMsgLength;
	sRecvData = (CHAR *) malloc(iRecvLen);

	memcpy(sRecvData,sRecvSignOn + sizeof(struct TAP_WRAPPER),iRecvLen);
	logInfo("Computing MD5 Digest");
	MD5_Digest(sDigest,sRecvData,iRecvLen);

	if(strncmp(sDigest,pTap_wrap->sDigest,DIGEST_LEN) != 0)
	{
		logFatal("FATAL::there is MD5 Digest  mismatch..");
		close(iMasterSocket);
		exit(ERROR);
	}
	logInfo("MD5 Checksum is Correct");

	memcpy(sHeader,sRecvSignOn+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(sHeader->iMsgLength);	
	TWIDDLE(sHeader->iMsgCode);	

	iRecvLen = sHeader->iMsgLength;
	sRecvData = (CHAR *) malloc(iRecvLen);
	memcpy(sRecvData,sRecvSignOn + sizeof(struct TAP_WRAPPER),iRecvLen);

	iChkFlag = FALSE;
	iChkFlag = fRecvSignOn(sRecvSignOn);

	if(iChkFlag == FALSE)
	{
		logDebug2("fRecvSignOn Failed");
		return ERROR;
	}
	else
	{

		iErriMsgCode = sHeader->iErrorCode;

		if(iErriMsgCode != 0)
		{
			fGetStrForCode(iErriMsgCode,sErrorMsg);

			logDebug2("sErrorMsg :%s:",sErrorMsg);	

			sprintf(Ferror,"%s\t%d\t%s",getenv("NSE_CD_EXCH_USER_ID"),iErriMsgCode,sErrorMsg);

			fLogCDConFatal(NseCDProgName,Ferror);	
			return FALSE;


		}
		else
		{
			sprintf(Ferror,"%s\t%d\t%s",getenv("NSE_CD_EXCH_USER_ID"),iErriMsgCode,"USER SUCCESSFULLY LOGIN FOR TRADING");
			fLogCDConFatal(NseCDProgName,Ferror);	

		}	

		free(sSendsign);
		logTimestamp("Exit : [fHandleSignOnReq]");

		return TRUE;
	}
	}

	BOOL	fHndleInvitnPack(LONG32	iSockFd,LONG32	iGroupId)
	{
		logTimestamp("Entry : [fHndleInvitnPack]");
		CHAR	sInvPack[NSE_PACKET_SIZE];
		LONG32	iRecvBytes,iMsgCode;
		LONG32	iInvPackCnt = 0,i = 0;


		struct InvitationCount *pInvCnt;

		iRecvBytes = fTcpRecv(iSockFd,sInvPack);

		i = iGroupId -1;	

		if(iRecvBytes <= 0)
		{
			logInfo("In handle Invitation packet ---Failed Recv");
			return FALSE;	
		}
		else
		{
			logDebug2("HandleInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)sInvPack)->sHeader.iMsgCode);	


			TWIDDLE(((struct INVITATION_PACKET *)sInvPack)->sHeader.iMsgCode);
			iMsgCode =  ((struct INVITATION_PACKET *)sInvPack)->sHeader.iMsgCode;

			logDebug2("HandleInvitationPacket iMsgCode :%d:",iMsgCode);

			if(iMsgCode == TC_EQU_NSE_INVITATION_REQ)
			{

				TWIDDLE(((struct INVITATION_PACKET *)sInvPack)->iInvitation_count);
				iInvPackCnt = ((struct INVITATION_PACKET *)sInvPack)->iInvitation_count;	
				logDebug2("iInvitation_count %d",iInvPackCnt);


				LockShm(CurrInvitatnCntShm);			

				pInvCnt= (struct InvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);	
				if(*((int *)pInvCnt) == ERROR)
				{
					logInfo("Error in Creating Shm ");
					exit(1);
				}

				pInvCnt->InvCount_group[i].iInvPacketCount = pInvCnt->InvCount_group[i].iInvPacketCount + iInvPackCnt; 


				if ( CloseSharedMemory( (void * ) pInvCnt) == ERROR )
				{
					logFatal("Error in Closing Shm ");
					exit(1);
				}
				UnLockShm(CurrInvitatnCntShm);

				logInfo("============================ Received Invitation Packet  ============================");	
			}
			else
			{
				return FALSE;
			}

		}
		logTimestamp("Exit : [fHndleInvitnPack]");
		return TRUE;	


	}

	BOOL	fReduceInvPack(LONG32	iGroupId)
	{
		logTimestamp("Entry : [fReduceInvPack]");
		struct InvitationCount *pInvCnt;

		LockShm(CurrInvitatnCntShm);
		LONG32 	iTempGid;

		iTempGid = iGroupId - 1;

		pInvCnt = (struct InvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

		if(*((int *)pInvCnt ) == ERROR)
		{
			logInfo("Error in Creating CurrInvitatnCntShm  Shm");
			exit(1);
		}

		pInvCnt->InvCount_group[iTempGid].iInvPacketCount--;	

		logDebug2("REDUCED INVITATION COUNT IS  :%d:",pInvCnt->InvCount_group[iTempGid].iInvPacketCount);

		if ( CloseSharedMemory( (void * ) pInvCnt) == ERROR )
		{
			logInfo("Error in Closing Shm ");
			exit(1);
		}
		UnLockShm(CurrInvitatnCntShm);
		logTimestamp("Exit : [fReduceInvPack]");
		return TRUE;
	}

	void 	fGetInvPackCnt(LONG32 *iInvPackCnt,LONG32 iGroupId)	
	{
		logTimestamp("Entry : [fGetInvPackCnt]");
		struct InvitationCount *pInvCnt;
		LONG32  iTempGid;

		LockShm(CurrInvitatnCntShm);


		iTempGid = iGroupId - 1;

		pInvCnt = (struct InvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

		if(*((int *)pInvCnt ) == ERROR)
		{
			logInfo("Error in Creating CurrInvitatnCntShm  Shm");
			exit(1);
		}

		*iInvPackCnt = pInvCnt->InvCount_group[iTempGid].iInvPacketCount;

		logDebug2("GET INVITATION COUNT IS  :%d:",iInvPackCnt);

		if ( CloseSharedMemory( (void * ) pInvCnt) == ERROR )
		{
			logInfo("Error in Closing Shm ");
			exit(1);
		}
		UnLockShm(CurrInvitatnCntShm);
		logTimestamp("Exit : [fGetInvPackCnt]");
		return TRUE;
	}

	BOOL    fRecvSignOn(CHAR *sRecvSignOn)
	{
		logTimestamp("Entry : [recvsignon]");
		BOOL	iDataSentFlg = FALSE;

		struct	NNF_SIGNON_RESP *pRecv;

		pRecv = (struct NNF_SIGNON_RESP *)malloc(sizeof(struct NNF_SIGNON_RESP));

		memcpy(pRecv,sRecvSignOn,sizeof(struct NNF_SIGNON_RESP));

		TWIDDLE(pRecv->iUserId);
		TWIDDLE(pRecv->iLastPasswordChange);
		TWIDDLE(pRecv->iBranchId);
		TWIDDLE(pRecv->iEndTime);
		TWIDDLE(pRecv->iUserType);

		TWIDDLE(pRecv->sHeader.iLogTimeStamp);
		TWIDDLE(pRecv->sHeader.iMsgCode);
		TWIDDLE(pRecv->sHeader.iErrorCode);
		TWIDDLE(pRecv->sHeader.iMsgLength);

		logDebug2("RecvSignOn iUserId :%d:",pRecv->iUserId);
		logDebug2("RecvSignOn iLastPasswordChange :%d:",pRecv->iLastPasswordChange);
		logDebug2("RecvSignOn iBranchId:%d:",pRecv->iBranchId);
		logDebug2("RecvSignOn iEndTime:%d:",pRecv->iEndTime);
		logDebug2("RecvSignOn iUserType:%d:",pRecv->iUserType);
		logDebug2("RecvSignOn iLogTimeStamp:%d:",pRecv->sHeader.iLogTimeStamp);
		logDebug2("RecvSignOn iMsgCode:%d:",pRecv->sHeader.iMsgCode);
		logDebug2("RecvSignOn iErrorCode:%d:",pRecv->sHeader.iErrorCode);
		logDebug2("RecvSignOn iMsgLength:%d:",pRecv->sHeader.iMsgLength);
		logDebug2("RecvSignOn sAlphaSplit:%s",pRecv->sHeader.sAlphaSplit);
		logDebug2("RecvSignOn sPassword:%s",pRecv->sPassword);
		logDebug2("RecvSignOn sNewPassword :%s:",pRecv->sNewPassword);
		logDebug2("RecvSignOn sTraderName:%s:",pRecv->sTraderName);
		logDebug2("RecvSignOn sBrokerCode:%s:",pRecv->sBrokerCode);
		logDebug2("RecvSignOn cBrokerStatus:%c:",pRecv->cBrokerStatus);

		iDataSentFlg = fUpdateSignOnResp(pRecv);

		logTimestamp("Exit : [recvsignon]");

		if(iDataSentFlg != TRUE)
		{
			return ERROR;
		}
		else
		{
			return TRUE;
		}		
	}

	void	fNseDownStart(LONG32	iMasterSocket)
	{
		logTimestamp("Entry : [fNseDownStart]");
		BOOL	iChkFlag = FALSE;

		iChkFlag = fSendReqToNse(TC_EQU_NSE_SYS_INFO_REQ,iMasterSocket);
		if(iChkFlag == TRUE)
		{
			fRecvDownloadResp(iMasterSocket);	
		}	

		iChkFlag = FALSE;
		iChkFlag = fSendReqToNse(TC_NSE_UPD_LDB_DOWNLD_REQ,iMasterSocket);
		if(iChkFlag == TRUE)
		{
			fRecvDownloadResp(iMasterSocket);
		}

		iChkFlag = FALSE;
		iChkFlag = fSendReqToNse(TC_NSE_MSG_DOWNLOAD_REQ,iMasterSocket);
		if(iChkFlag == TRUE)
		{
			fRecvDownloadResp(iMasterSocket);
		}

		logTimestamp("Exit : [fNseDownStart]");


	}	

	void	fTransmitChild(LONG32	iSockFd)
	{
		logTimestamp("Entry :[fTransmitChild]");
		struct 	TAP_WRAPPER *pTapWrp;
		struct 	NNF_HEADER *sHeader;
		struct	NNF_ORDER_ENTRY	*pOrdReq;	

		CHAR    *sRcvMsg;
		CHAR	*sMsgTap;

		CHAR    sDigest[DIGEST_LEN];

		BOOL    iIsSend = FALSE;

		LONG32  iMsgSize = 0,iGrpId,iMsgCode;
		LONG32  iSendBytes = 0,iInvPack = 0;
		LONG32  iCount=0,iRetryCnt = 0;


		sRcvMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
		sHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));

		memset(pTapWrp,NULL,sizeof(struct TAP_WRAPPER));
		pOrdReq = (struct  NNF_ORDER_ENTRY *) malloc(sizeof(struct  NNF_ORDER_ENTRY ));
		sMsgTap = (CHAR *)malloc((sizeof(CHAR)*NSE_PACKET_SIZE) + sizeof(struct TAP_WRAPPER));

		iGrpId = iGroupId;

		while(TRUE)
		{
			while(TRUE)
			{
				logInfo("Getting Invitation ");
				fGetInvPackCnt(&iInvPack,iGrpId);

				if(iInvPack != 0)
				{
					logDebug2("Recv Invitation Packet :%d:",iInvPack);
					if(iRetryCnt > 50)
					{
						logInfo("Making Connection UP After 50 Retries of Invitation Packet");
						fConnectionUP();		
					}
					break;
				}		

				if(iRetryCnt == 50)
				{
					fRejectProcess();	
				}
				iRetryCnt++;
			}	

			memset(pOrdReq,'\0',sizeof(struct  NNF_ORDER_ENTRY ));
			memset(sHeader,'\0',sizeof(struct  NNF_HEADER ));
			memset(sRcvMsg,NULL,NSE_PACKET_SIZE);
			logInfo("---------==================|||||||||||||||||||||||=================---------");
			logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
			logInfo("---------==================|||||||||||||||||||||||=================---------");

			if((ReadMsgQ(iOrdSrvToConnNSECR,sRcvMsg,NSE_PACKET_SIZE, 1)) != 1)
			{
				logFatal("Error : MsgQId is %d",iOrdSrvToConnNSECR);
				exit(ERROR);
			}

			memcpy(sHeader,sRcvMsg,sizeof(struct  NNF_HEADER));		

			TWIDDLE(sHeader->iMsgCode);
			TWIDDLE(sHeader->iMsgLength);
			iMsgSize = sHeader->iMsgLength;	
			iMsgCode = sHeader->iMsgCode;
			memcpy(pOrdReq,sRcvMsg,sizeof(struct  NNF_ORDER_ENTRY ));

			fPrintfAll(pOrdReq);

			MD5_Digest(sDigest,sRcvMsg,iMsgSize);         

			pTapWrp = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
			memset(pTapWrp,NULL,sizeof(struct TAP_WRAPPER));	

			pTapWrp->iMsgLen = iMsgSize;
			iTransmitSeq++;
			pTapWrp->iSeqNo = iTransmitSeq;
			TWIDDLE(pTapWrp->iMsgLen);
			TWIDDLE(pTapWrp->iSeqNo);

			memcpy(pTapWrp->sDigest,sDigest,DIGEST_LEN);
			memcpy(sMsgTap,pTapWrp,sizeof(struct TAP_WRAPPER));

			memcpy(sMsgTap+sizeof(struct TAP_WRAPPER),sRcvMsg,iMsgSize - sizeof(struct TAP_WRAPPER));
			fReduceInvPack(iGrpId);		

			iSendBytes = fTcpSend(iSockFd,sMsgTap,iMsgSize);	

			if(iSendBytes <= 0)
			{
				fRejCurrPacket(sRcvMsg);
			}
			else
			{
				logTimestamp("Order Send Successfully");
			}



		}	

		logTimestamp("Exit : [fTransmitChild]");




	}

	void	fReplyChild(LONG32	iSockFd)
	{
		logTimestamp("Entry : [fReplyChild]");

		BOOL    iCkFlag = FALSE;
		INT16   iBytRcv;
		CHAR    *sRcvMsg = (CHAR *)malloc(sizeof(CHAR) * NSE_PACKET_SIZE);
		LONG32  iTempCode,iTemSeqNo = 0,iTempLen;
		CHAR    *sDataMsg;
		CHAR    *sRecvTemp;	
		CHAR    *sTempSeqNo;	
		CHAR	*sWrtMsg;
		unsigned char   sDigest[DIGEST_LEN];

		struct  NNF_HEADER *sHeader;
		struct  TAP_WRAPPER *pTapWrp;

		INT16   iDowCounter = 0;
		sHeader= (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
		memset(sHeader,'\0',sizeof(struct NNF_HEADER));
		pTapWrp = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
		memset(pTapWrp ,'\0',sizeof(struct TAP_WRAPPER));

		BOOL    iTimeStampUpdateFlag = FALSE;

		while(TRUE)
		{


			iCkFlag = fHndleInvitnPack(iSockFd,1);

			if(iCkFlag == TRUE)
			{
				logInfo("This is an Invitation Packet");
			}
			else
			{
				iBytRcv = fTcpRecv(iSockFd,sRcvMsg);
				iCkFlag = FALSE;

				if(iBytRcv <= 0)
				{
					logFatal("Something went wrong while Recving ");
					continue;
				}

				memcpy(sHeader,sRcvMsg,sizeof(struct NNF_HEADER));
				memcpy(pTapWrp,sRcvMsg,sizeof(struct TAP_WRAPPER));

				TWIDDLE(sHeader->iMsgCode);
				TWIDDLE(sHeader->iMsgLength);
				iRecieveSeq++;
				iTemSeqNo = iRecieveSeq;

				TWIDDLE(pTapWrp->iSeqNo);
				TWIDDLE(pTapWrp->iMsgLen);

				if(iTemSeqNo != pTapWrp->iSeqNo)
				{
					logFatal("Error in Seq");
					close(iSocket);
					exit(ERROR);
				}

				iTempLen = sHeader->iMsgLength;
				iTempCode = sHeader->iMsgCode;
				sDataMsg = (CHAR *)malloc(iTempLen);

				memcpy(sDataMsg , sRcvMsg + sizeof(struct TAP_WRAPPER) ,iTempLen);

				MD5_Digest(sDigest,pTapWrp->sDigest,DIGEST_LEN);

				if(strncmp(sDigest,pTapWrp->sDigest,DIGEST_LEN) != 0)
				{
					logFatal("Mismatch in MD5 Checksum ....closing TAP BOX Connection..");
					close(iSocket);
					exit(ERROR);
				}

				if(     iTempCode== TC_INT_OE_CONF_RESP || iTempCode== TC_INT_OC_ERROR_RESP || iTempCode== TC_INT_OC_CONF_RESP ||
						iTempCode== TC_INT_OM_CONF_RESP || iTempCode== TC_INT_OE_ERROR_RESP || iTempCode== TC_INT_OE_FREEZE_RESP  ||
						iTempCode== TC_INT_OM_ERROR_RESP|| iTempCode== TC_INT_TRADE_RESP    || iTempCode== TC_INT_MKT_LMT_CONVT_RESP ||
						iTempCode== TC_INT_SL_ORDER_TRIG_RESP 
				  )
				{
					sRecvTemp = sRcvMsg + sizeof(struct NNF_HEADER);
					fConvertSeqNo(sRecvTemp,sTempSeqNo);

					memset( ((struct NNF_ORDER_ENTRY *)sRecvTemp)->sRemarks ,' ',OE_REMARKS_LEN);
					strncpy( ((struct NNF_ORDER_ENTRY *)sRecvTemp)->sRemarks,";",1);
					memcpy ( ((struct NNF_ORDER_ENTRY *)sRecvTemp)->sRemarks + DELTA_REMARKS,sTempSeqNo, strlen(sTempSeqNo));

				}

				sWrtMsg = sRecvTemp;

				if(WriteMsgQ(iConnToTrdMapNSECur,sWrtMsg,iTempLen ,1) != TRUE)
				{
					logFatal("Error in Writing on Q iQueueId ");
					exit(ERROR);
				}				



			}

			return iCkFlag;
		}

		logTimestamp("Exit : [fReplyChild]");
	}

	void 	fPrintfAll(struct  NNF_ORDER_ENTRY *pPrtReq)
	{
		logInfo("==================Printing request Packet====================");

		logDebug2(" header->iReserved [%d]",pPrtReq->sHeader.iReserved);
		logDebug2(" header->iLogTimeStamp [%d]",pPrtReq->sHeader.iLogTimeStamp);
		logDebug2(" header->sAlphaSplit [%s]",pPrtReq->sHeader.sAlphaSplit);
		logDebug2(" header->iMsgCode [%d]",pPrtReq->sHeader.iMsgCode);
		logDebug2(" header->iErrorCode [%d]",pPrtReq->sHeader.iErrorCode);
		logDebug2(" header->sTimeStamp1 [%s]",pPrtReq->sHeader.sTimeStamp1);
		logDebug2(" header->sTimeStamp2 [%s]",pPrtReq->sHeader.sTimeStamp2);
		logDebug2(" header->sTimeStamp3 [%s]",pPrtReq->sHeader.sTimeStamp3);
		logDebug2(" header->iMsgLength [%d]",pPrtReq->sHeader.iMsgLength);


		logDebug2(" cParticipantType  [%c]",pPrtReq->cParticipantType);
		logDebug2(" cReserved  [%c]",pPrtReq->cReserved1);
		logDebug2(" iCompititorPeriod  [%d]",pPrtReq->iCompititorPeriod);
		logDebug2(" iSolicitorPeriod  [%d",pPrtReq->iSolicitorPeriod);
		logDebug2(" cModCanBy  [%c]",pPrtReq->cModCanBy);
		logDebug2(" cReserved1  [%c]",pPrtReq->cReserved2);
		logDebug2(" iReasonCode  [%d]",pPrtReq->iReasonCode);
		logDebug2(" sSymbol [%s]",pPrtReq->ContractDesc.sSymbol);
		logDebug2("pPrtReq->sCPBrokerCode   [%s]",pPrtReq->sCPBrokerCode);
		logDebug2(" fOrderNum  [%lf",pPrtReq->fOrderNum);
		logDebug2(" sAccCode  [%s]",pPrtReq->sAccCode);
		logDebug2(" iBookType  [%d]",pPrtReq->iBookType);
		logDebug2(" iBuyOrSell  [%d]",pPrtReq->iBuyOrSell);
		logDebug2(" iDiscQty  [%d]",pPrtReq->iDiscQty);
		logDebug2(" iDiscQtyRemaining  [%d]",pPrtReq->iDiscQtyRemaining);
		logDebug2(" iTotalQtyRemaining  [%d]",pPrtReq->iTotalQtyRemaining);
		logDebug2(" iTotalQty  [%d]",pPrtReq->iTotalQty);
		logDebug2(" iQtyFilledToday  [%d]",pPrtReq->iQtyFilledToday);
		logDebug2(" iPrice  [%d]",pPrtReq->iPrice);
		logDebug2(" iTriggerPrice  [%d]",pPrtReq->iTriggerPrice);
		logDebug2(" iGoodTillDate  [%d]",pPrtReq->iGoodTillDate);
		logDebug2(" iMinFillQty  [%d]",pPrtReq->iMinFillQty);
		logDebug2(" iLastModifiedTime  [%d]",pPrtReq->iLastModifiedTime);
		logDebug2(" MFTerm [%d]",pPrtReq->OrderTerms.MFTerm);
		logDebug2(" AONTerm [%d]",pPrtReq->OrderTerms.AONTerm);
		logDebug2(" OCTerm [%d]",pPrtReq->OrderTerms.IOCTerm);
		logDebug2(" GTCTerm [%d]",pPrtReq->OrderTerms.GTCTerm);
		logDebug2(" DayTerm [%d]",pPrtReq->OrderTerms.DayTerm);
		logDebug2(" StopLossTerm [%d]",pPrtReq->OrderTerms.StopLossTerm);
		logDebug2(" Market [%d]",pPrtReq->OrderTerms.Market);
		logDebug2(" ATO [%d]",pPrtReq->OrderTerms.ATO);
		logDebug2(" Reserved [%d]",pPrtReq->OrderTerms.Reserved1);
		logDebug2(" Frozen [%d]",pPrtReq->OrderTerms.Frozen);
		logDebug2(" Modified [%d]",pPrtReq->OrderTerms.Modified);
		logDebug2(" Traded [%d]",pPrtReq->OrderTerms.Traded);
		logDebug2(" MatchedInd [%d]",pPrtReq->OrderTerms.MatchedInd);
		logDebug2(" iBranchId  [%d]",pPrtReq->iBranchId);
		logDebug2(" iExchUserId  [%d]",pPrtReq->iExchUserId);
		logDebug2(" sBrokerCode  [%s]",pPrtReq->sBrokerCode);
		logDebug2(" sRemarks  [%s]",pPrtReq->sRemarks);
		logDebug2(" sSettlor  [%s]",pPrtReq->sSettlor);
		logDebug2(" iProCli  [%d]",pPrtReq->iProCli);
		logDebug2(" iSettlementDays  [%d]",pPrtReq->iSettlementDays);
		logDebug2(" fUserInfo  [%lf]",pPrtReq->fUserInfo);
		logDebug2(" fReservedPrgTrd  [%lf]",pPrtReq->fReservedPrgTrd);

		logInfo("==================Printing request Packet End====================");


	}

	void	fRejCurrPacket(CHAR *sRcvMsg)
	{
		struct NNF_HEADER *sHeader;	

		sHeader = (struct NNF_HEADER *)sRcvMsg;
		LONG32	iMsgLen,iMsgCode;

		BOOL	iRetVal;
		TWIDDLE(sHeader->iMsgLength);
		TWIDDLE(sHeader->iMsgCode);

		iMsgLen = sHeader->iMsgLength;
		iMsgCode = sHeader->iMsgCode;

		switch(iMsgCode)
		{
			case TC_INT_ORDER_ENTRY_REQ :
				sHeader->iMsgCode = TC_INT_OE_ERROR_RESP;	
				break;
			case TC_INT_ORDER_MODIFY:
				sHeader->iMsgCode = TC_INT_OM_ERROR_RESP;	
				break;
			case TC_INT_ORDER_CANCEL:
				sHeader->iMsgCode = TC_INT_OC_ERROR_RESP;	
				break;
			default :
				logInfo("Invalid iMsgCode :%d:",iMsgCode);
				break;	

		};
		sHeader->iErrorCode = EXCHANGE_DOWN_ERROR;
		TWIDDLE(sHeader->iMsgLength);
		TWIDDLE(sHeader->iMsgCode);
		TWIDDLE(sHeader->iErrorCode);

		if ((iRetVal=WriteMsgQ(iConnToTrdMapNSECur,sRcvMsg,strlen(sRcvMsg)-1,1))== ERROR)
		{
			logFatal("Error in Sending Rej Msg");
			exit(ERROR);
		}


	}



	BOOL    fInitMemory(LONG32  iGrpId)
	{
		logTimestamp("Entry : [fInitMemory]");
		CHAR    sInvPack[NSE_PACKET_SIZE];
		LONG32  iRecvBytes,iMsgCode;
		LONG32  iInvPackCnt = 0,i = 0;


		struct InvitationCount *pInvCnt;

		//iRecvBytes = fTcpRecvInvPack(iSockFd,&sInvPack);

		i = iGrpId -1;

		LockShm(InvitationCountShm);

		pInvCnt= (struct InvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);
		if(*((int *)pInvCnt) == ERROR)
		{
			logInfo("Error in Creating Shm ");
			exit(ERROR);
		}

		pInvCnt->InvCount_group[i].iInvPacketCount = 0;


		if ( CloseSharedMemory( (void * ) pInvCnt) == ERROR )
		{
			logFatal("Error in Closing Shm ");
			exit(ERROR);
		}
		UnLockShm(InvitationCountShm);

		logTimestamp("Exit : [fInitMemory]");
		return TRUE;
	}
