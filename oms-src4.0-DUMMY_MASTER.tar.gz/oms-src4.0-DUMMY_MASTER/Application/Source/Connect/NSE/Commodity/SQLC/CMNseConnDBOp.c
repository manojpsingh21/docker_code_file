#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "ComNseStruct.h"

extern DBConNDr;
extern  LONG32 iGroupId;
extern CHAR sKey[DB_KEY_LEN];

BOOL	fFetchSignOnDet(CHAR *sSignOnReq,LONG32	iGrpId)
{
	logTimestamp("Entry :fFetchSignOnDet:");

	struct NNF_SIGNON_REQ *pSign;
	LONG32 iNumRow;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	pSign = (struct NNF_SIGNON_REQ *)malloc(sizeof(struct NNF_SIGNON_REQ));

	memcpy(pSign,sSignOnReq,sizeof(struct NNF_SIGNON_REQ));

	memset(pSign,' ',sizeof(struct NNF_SIGNON_REQ));

	CHAR	*sSignQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pSign->sHeader.iReserved = 0;
	memset(pSign->sHeader.sAlphaSplit ,SPACE,ALPHA_SPLIT_LEN);
	pSign->sHeader.iMsgCode= 0;
	pSign->sHeader.iErrorCode= 0;
	memset(pSign->sHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);
	memset(pSign->sHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	memset(pSign->sHeader.sTimeStamp3,SPACE,DATE_TIME_LEN);
	pSign->sHeader.iLogTimeStamp = 0;

	pSign->iUserId = 0;
	memset(pSign->sPassword,SPACE,NSE_PASSWORD_LEN);
	memset(pSign->sNewPassword,SPACE,NSE_PASSWORD_LEN);
	//	memset(pSign->sTraderName,SPACE,TRADER_NAME_LEN);

	memset(pSign->sBrokerCode,SPACE,BROKER_CODE_LEN);
	//	memset(pSign->cReserved1,SPACE,3);
	//	pSign->cReserved1 = '0';
	//	pSign->cReserved2  = '0';


	//	memset(pSign->Reserved2,SPACE,66);
	memset(pSign->sBrokerName,SPACE,BROKER_NAME_LEN);
	memset(pSign->sColour,SPACE,COLOUR_LEN);
	memset(pSign->sWorkstationAddr,SPACE,WORK_STATION_ADDR_LEN);

	pSign->sHeader.iMsgCode = TC_DRV_NSE_SIGNON_REQ;
	memset(pSign->sHeader.sAlphaSplit,SPACE,2);
	memcpy(pSign->sHeader.sAlphaSplit,"NT",2);
	pSign->sHeader.iMsgLength = sizeof(struct NNF_SIGNON_REQ);

	logDebug2("Before Fetch Querey :%s:",sKey);
	logDebug2("Before Fetch Querey :%d:",iGrpId);
	/*

	   sprintf(sSignQry,"SELECT     EAM_EXCH_USER_ID,    aes_decrypt(EAM_OLD_PASSWORD,\'%s\'),  IFNULL(aes_decrypt(EAM_NEW_PASSWORD,\'%s\'),' '),    EAM_BROKER_ID, \
	   EAM_VERSION_NO, EAM_WORKSTATION_ADDRESS,EAM_TRADER_NAME  FROM  EXCH_ADMINISTRATION_MASTER \
	   WHERE  \
	   EAM_GROUP_ID = %d\
	   AND EAM_EXM_EXCH_ID = \"%s\"\
	   AND EAM_DRV_FLAG = \'%c\' \
	   AND EAM_SEGMENT =\'%c\';",sKey,sKey,iGrpId,NSE_EXCH,FO_DRV_FLAG,DERIVATIVE_SEGMENT);

	   logDebug2("sSignQry :%s:",sSignQry);

	   if(mysql_query(DBConNDr,sSignQry) != SUCCESS)
	   {
	   sql_Error(DBConNDr);
	   return FALSE;
	   }


	   Res = mysql_store_result(DBConNDr);

	   iNumRow = mysql_num_rows(Res);
	   if (iNumRow != 1)
	   {
	   logFatal("Error with the Data");
	   return FALSE;

	   }

	   if(Row = mysql_fetch_row(Res))
	   {
	   pSign->iUserId = atoi(Row[0]);
	   strncpy(pSign->sPassword, Row[1],NSE_PASSWORD_LEN);
	   if(Row[2][0] == SPACE)
	   {
	   strncpy(pSign->sNewPassword,SPACE,NSE_PASSWORD_LEN);
	   }
	   else
	   {
	   strncpy(pSign->sNewPassword,Row[2],NSE_PASSWORD_LEN);
	   }		

	   strncpy(pSign->sBrokerCode,Row[3] ,BROKER_CODE_LEN);
	   pSign->iVersionNumber = atoi(Row[4]);
	   strncpy(pSign->sWorkstationAddr,Row[5] ,WORK_STATION_ADDR_LEN);
	   strncpy(pSign->sBrokerName ,Row[6] ,BROKER_NAME_LEN);

	   }
	 */
	pSign->iUserId = 8091;
	strncpy(pSign->sPassword,"Neat@FO1",NSE_PASSWORD_LEN);
	strncpy(pSign->sNewPassword,"Nsed@K65",NSE_PASSWORD_LEN);
	strncpy(pSign->sBrokerCode,"11159",BROKER_CODE_LENGTH);
	//	pSign->iBranchId= 1;
	pSign->iVersionNumber = 93700;
	strncpy(pSign->sWorkstationAddr,"4101710       ",WORK_STATION_ADDR_LEN);
	strncpy(pSign->sBrokerName ,"RAMACHANDRAN C R         " ,BROKER_NAME_LEN);

	logInfo("Printing SignOn Before Twiddle ---------------------------------------------- ");

	logDebug2("pSign->sHeader.iMsgCode 	:%d:",pSign->sHeader.iMsgCode);
	logDebug2("pSign->sHeader.sAlphaSplit	:%s:",pSign->sHeader.sAlphaSplit);
	logDebug2("pSign->sHeader.iMsgLength 	:%d:",pSign->sHeader.iMsgLength);

	logDebug2("pSign->iUserId 		:%d:",pSign->iUserId);
	logDebug2("pSign->sPassword 		:%s:",pSign->sPassword);
	logDebug2("pSign->sNewPassword		:%s:",pSign->sNewPassword);
	logDebug2("pSign->sBrokerCode		:%s:",pSign->sBrokerCode);
	//	logDebug2("pSign->iBranchId             :%d:",pSign->iBranchId);
	logDebug2("pSign->iVersionNumber	:%d:",pSign->iVersionNumber);
	logDebug2("pSign->sWorkstationAddr	:%s:",pSign->sWorkstationAddr);
	logDebug2("pSign->sBrokerName		:%s:",pSign->sBrokerName);
	logInfo("Printing SignOn Before Twiddle ---------------------------------------------- ");

	TWIDDLE(pSign->sHeader.iLogTimeStamp);
	TWIDDLE(pSign->sHeader.iMsgCode);
	TWIDDLE(pSign->sHeader.iErrorCode);
	TWIDDLE(pSign->sHeader.iMsgLength);
	TWIDDLE(pSign->iUserId);
	//	TWIDDLE(pSign->iBranchId);
	TWIDDLE(pSign->iVersionNumber);

	logInfo("Printing SignOn After Twiddle ---------------------------------------------- ");
	logDebug2("pSign->sHeader.iMsgCode      :%d:",pSign->sHeader.iMsgCode);
	logDebug2("pSign->sHeader.sAlphaSplit   :%s:",pSign->sHeader.sAlphaSplit);
	logDebug2("pSign->sHeader.iMsgLength    :%d:",pSign->sHeader.iMsgLength);

	logDebug2("pSign->iUserId               :%d:",pSign->iUserId);
	logDebug2("pSign->sPassword             :%s:",pSign->sPassword);
	logDebug2("pSign->sNewPassword          :%s:",pSign->sNewPassword);
	logDebug2("pSign->sBrokerCode           :%s:",pSign->sBrokerCode);
	//	logDebug2("pSign->iBranchId             :%d:",pSign->iBranchId);
	logDebug2("pSign->iVersionNumber	:%d:",pSign->iVersionNumber);
	logDebug2("pSign->iVersionNumber        :%d:",pSign->iVersionNumber);
	logDebug2("pSign->sBrokerName           :%s:",pSign->sBrokerName);
	logInfo("Printing SignOn After  Twiddle ---------------------------------------------- ");

	memcpy(sSignOnReq,pSign,sizeof(struct NNF_SIGNON_REQ));

	free(pSign);

	return TRUE;


}


BOOL	fUpdateSignOnResp(struct NNF_SIGNON_RESP *pSignOnResp)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	LONG64		iSysTimeStmp,iNseTimeStmp,iTempTimeStmp;	

	CHAR		sNseEndTime[DATE_STRING_LENGTH];
	CHAR		sLastPswdChng[DATE_STRING_LENGTH];
	CHAR		*UpdQuery= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	if(mysql_query(DBConNDr,"SELECT JULIDATE(now());") != SUCCESS)
	{
		sql_Error(DBConNDr);
		return FALSE;
	}

	Res = mysql_store_result(DBConNDr);
	if(Row = mysql_fetch_row(Res))
	{
		iSysTimeStmp = atol(Row[0]);	
	}
	iNseTimeStmp = pSignOnResp->sHeader.iLogTimeStamp;

	logDebug2("iSysTimeStmp :%ld:",iSysTimeStmp);

	iTempTimeStmp = iNseTimeStmp - iSysTimeStmp;	

	logDebug2("iTempTimeStmp :%d:",iTempTimeStmp);

	ConvSecToDate(pSignOnResp->iLastPasswordChange,sLastPswdChng);

	logDebug3(" sLastPswdChng :%s:",sLastPswdChng);
	ConvSecToDate(pSignOnResp->iEndTime,sNseEndTime);

	logDebug3(" sNseEndTime :%s:",sNseEndTime);


	sprintf(UpdQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET  \
			EAM_OLD_PASSWORD = \"%s\" ,\
			EAM_NEW_PASSWORD = '',\
			EAM_TRADER_NAME = \"%s\" ,\
			EAM_EXCH_OFFSET_TIME = %ld \
			EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y%%m%%d-%%H:%%i:%%S\')\
			EAM_BROKER_ID = \"%s\" ,\
			EAM_BRANCH_ID = %d \
			EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y%%m%%d-%%H:%%i:%%S\')\
			EAM_BROKER_STATUS = \'%c\'\
			EAM_LOGON_STATUS = 'A' \
			WHERE \
			EAM_EXM_EXCH_ID = \"%s\" \
			AND EAM_EXCH_USER_ID = %d \
			AND EAM_DRV_FLAG = \'%c\';",pSignOnResp->sPassword,pSignOnResp->sBrokerName,iTempTimeStmp,sLastPswdChng,pSignOnResp->sBrokerCode,\
			pSignOnResp->iBranchId,sNseEndTime,pSignOnResp->cBrokerStatus,NSE_EXCH,pSignOnResp->iUserId,FO_DRV_FLAG);

	logDebug1("UpdQuery :%s:",UpdQuery);
	if(mysql_query(DBConNDr,UpdQuery) != SUCCESS)	
	{
		sql_Error(DBConNDr);
		return FALSE;	
	}
	else
	{
		mysql_commit(DBConNDr);
	}

	return TRUE;	


}

void	GetStrForCode(LONG32	iCode,CHAR *sStrMsg)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	CHAR	*sSelQury = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	

	sprintf(sSelQury ,"SELECT ERM_REASON_DESCRIPTION FROM EXCH_REASON_MASTER WHERE ERM_REASON_CODE = %d;",iCode);	

	logDebug2("sSelQury :%d:",sSelQury);

	if(mysql_query(DBConNDr,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNDr);
	}

	Res = mysql_store_result(DBConNDr);
	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sStrMsg,Row[0],200 );	
	}

}

BOOL    fSendUpdReq(CHAR *sSendmsg)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR    sSelQury[MAX_QUERY_SIZE];

	LONG32  iLastUpdTime,iCreatTime;
	INT16   iMktType=0;


	struct  NNF_UPDATE_LDB_REQ      *pSndUpd;

	memset(sSelQury,'\0',MAX_QUERY_SIZE);

	sprintf(sSelQury,"SELECT JULIDATE(EAM_LAST_UPDATE_PART_TIME) FROM EXCH_ADMINISTRATION_MASTER \
			WHERE  \
			EAM_GROUP_ID   = 1\
			AND EAM_EXM_EXCH_ID = \"%s\" \
			AND EAM_DRV_FLAG = \'%c\'",NSE_EXCH,FO_DRV_FLAG);

	logDebug1("sSelQury :%s:",sSelQury);
	if(mysql_query(DBConNDr,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNDr);
		return FALSE;
	}

	Res = mysql_store_result(DBConNDr);
	if (Row = mysql_fetch_row(Res))
	{
		iLastUpdTime = atol(Row[0]);
	}

	memset(sSelQury,'\0',MAX_QUERY_SIZE);
	mysql_free_result(Res);

	sprintf(sSelQury,"SELECT max(JULIDATE(SM_UPDATE_DATE)) FROM SECURITY_MASTER ");

	logDebug1("sSelQury :%s:",sSelQury);
	if(mysql_query(DBConNDr,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNDr);
		return FALSE;
	}

	Res = mysql_store_result(DBConNDr);
	if (Row = mysql_fetch_row(Res))
	{
		iCreatTime = atol(Row[0]);
	}


	memset(sSelQury,'\0',MAX_QUERY_SIZE);
	mysql_free_result(Res);

	sprintf(sSelQury,"SELECT EMM_STATUS,EMM_MKT_TYPE_NO from EXCH_MKT_MASTER WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG = \'%c'\;",NSE_EXCH,DERIVATIVE_SEGMENT);

	logDebug1("sSelQury :%s:",sSelQury);
	if(mysql_query(DBConNDr,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNDr);
		return FALSE;
	}

	Res = mysql_store_result(DBConNDr);

	while(Row = mysql_fetch_row(Res))
	{
		iMktType = atoi(Row[1]);
		switch (iMktType)
		{
			case NORMAL_MARKET :
				pSndUpd->sMktStat.iNormal = atoi(Row[0]);
				break;
			case ODDLOT_MARKET :
				pSndUpd->sMktStat.iOddlot = atoi(Row[0]);

				break;
			case SPOT_MARKET :
				pSndUpd->sMktStat.iSpot = atoi(Row[0]);

				break;
			case AUCTION_MARKET :
				pSndUpd->sMktStat.iAuction= atoi(Row[0]);

				break;
			default :
				break;
		}

	}
	pSndUpd->sHeader.iReserved = 0;
	pSndUpd->sHeader.iLogTimeStamp = 0;
	memset(pSndUpd->sHeader.sAlphaSplit,SPACE,ALPHA_SPLIT_LEN);
	pSndUpd->sHeader.iMsgCode = TC_NSE_UPD_LDB_DOWNLD_REQ;
	pSndUpd->sHeader.iErrorCode = 0;
	memset(pSndUpd->sHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);
	memset(pSndUpd->sHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	memset(pSndUpd->sHeader.sTimeStamp3,SPACE,DATE_TIME_LEN);
	pSndUpd->sHeader.iMsgLength = sizeof(struct  NNF_UPDATE_LDB_REQ);

	pSndUpd->iLastUpdateSecTime =   iCreatTime;
	pSndUpd->iLastUpdatePartTime =  iLastUpdTime;

	return TRUE;

}

BOOL    fUpdSysInfo(CHAR *sDataMsg)
{
	struct NNF_SYSTEM_INFO_BCAST *pSysin;
	CHAR    sUpdQry [MAX_QUERY_SIZE];
	CHAR    sInsQry [MAX_QUERY_SIZE];
	LONG32  iNoStream,iTempGid;;

	pSysin = (struct NNF_SYSTEM_INFO_BCAST *)malloc(sizeof(struct NNF_SYSTEM_INFO_BCAST));

	memcpy(pSysin,sDataMsg,sizeof(struct NNF_SYSTEM_INFO_BCAST));


	TWIDDLE(pSysin->sHeader.iMsgCode);
	TWIDDLE(pSysin->sHeader.iMsgLength);
	TWIDDLE(pSysin->MarketStatus.iNormal);
	TWIDDLE(pSysin->MarketStatus.iOddlot);
	TWIDDLE(pSysin->MarketStatus.iSpot);
	TWIDDLE(pSysin->MarketStatus.iAuction);
	//        TWIDDLE(pSysin->MarketStatus.iCallAuction1);
	//       TWIDDLE(pSysin->MarketStatus.iCallAuction2);
	TWIDDLE(pSysin->iMktIndex);
	//        TWIDDLE(pSysin->iNormalMktDefSttlPeriod);
	TWIDDLE(pSysin->iDefaultSettNormal);

	//        TWIDDLE(pSysin->iSpotMktDefSttlPeriod);
	TWIDDLE(pSysin->iDefaultSettSpot);

	//        TWIDDLE(pSysin->iAuctionMktDefSttlPeriod);
	TWIDDLE(pSysin->iDefaultSettAuction);

	//        TWIDDLE(pSysin->iDefCompititorPeriod);
	TWIDDLE(pSysin->iCompetitorPeriod);

	//        TWIDDLE(pSysin->iDefSolicitorPeriod);
	TWIDDLE(pSysin->iSolicitorPeriod);
	TWIDDLE(pSysin->iWarnigPercent);
	TWIDDLE(pSysin->iVolFreezePercent);
	TWIDDLE(pSysin->iBoardLotQty);
	TWIDDLE(pSysin->iTickSize);
	TWIDDLE(pSysin->iMaxGtcDays);
	TWIDDLE(pSysin->iDiscQty);

	iTempGid = iGroupId;

	if((pSysin->sHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP) || (pSysin->sHeader.iMsgCode == TC_EQU_NSE_PARTIAL_SYS_INFO_RESP))
	{
		memset(sUpdQry,'\0',MAX_QUERY_SIZE);

		sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_SETTLEMENT_PERIOD =  %d WHERE EMM_MKT_TYPE = %d AND EMM_EXM_EXCH_ID = \"%s\" AND  EMM_EXCH_SEG = \'%c\';",pSysin->iDefaultSettNormal,NORMAL_MARKET,NSE_EXCH,DERIVATIVE_SEGMENT );
		logDebug2("sUpdQry :%s:",sUpdQry);
		if(mysql_query(DBConNDr,sUpdQry) != SUCCESS)
		{
			sql_Error(DBConNDr);
			return FALSE;
		}

		memset(sUpdQry,'\0',MAX_QUERY_SIZE);

		sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_SETTLEMENT_PERIOD =  %d WHERE EMM_MKT_TYPE = %d AND EMM_EXM_EXCH_ID = \"%s\" AND  EMM_EXCH_SEG = \'%c\';",pSysin->iDefaultSettSpot,SPOT_MARKET,NSE_EXCH ,DERIVATIVE_SEGMENT);

		logDebug2("sUpdQry :%s:",sUpdQry);
		if(mysql_query(DBConNDr,sUpdQry) != SUCCESS)
		{
			sql_Error(DBConNDr);
			return FALSE;
		}
		memset(sUpdQry,'\0',MAX_QUERY_SIZE);

		sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_SETTLEMENT_PERIOD =  %d WHERE EMM_MKT_TYPE = %d AND EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG = \'%c\';",pSysin->iDefaultSettAuction,AUCTION_MARKET,NSE_EXCH ,DERIVATIVE_SEGMENT);

		logDebug2("sUpdQry :%s:",sUpdQry);
		if(mysql_query(DBConNDr,sUpdQry) != SUCCESS)
		{
			sql_Error(DBConNDr);
			return FALSE;
		}

		return TRUE;

	}



}

void    InsertExchDigit()
{

	CHAR    sInsQry [MAX_QUERY_SIZE];
	LONG32  iNoStream,iTempGid,j;

	iTempGid = iGroupId;
	for(j =1 ;j<= iNoStream;j++ )
	{
		memset(sInsQry,'\0',MAX_QUERY_SIZE);
		sprintf(sInsQry,"INSERT INTO EXCH_DOWNLOAD_DATA(EDD_GROUP_ID,EDD_EXCH_ID,EDD_DRV_FLAG,EDD_STREAM_ID,EDD_TIMESTAMP1,EDD_TIMESTAMP2)\
				VALUES(%d,\"%s\",\'%c'\,%d,0,0) \
				on duplicate key \
				UPDATE \
				EDD_GROUP_ID = VALUES(EDD_GROUP_ID) ,\
				EDD_EXCH_ID     = VALUES(EDD_EXCH_ID) ,\
				EDD_DRV_FLAG= VALUES(EDD_DRV_FLAG) ,\
				EDD_STREAM_ID= VALUES(EDD_STREAM_ID) ,\
				EDD_TIMESTAMP1= VALUES(EDD_TIMESTAMP1) ,\
				EDD_TIMESTAMP2= VALUES(EDD_TIMESTAMP2) ;",iTempGid,NSE_EXCH,FO_DRV_FLAG,j);

		logDebug2("sInsQry :%s:",sInsQry);
		if(mysql_query(DBConNDr,sInsQry) != SUCCESS)
		{
			logFatal("Error in Update");
			sql_Error(DBConNDr);
		}
		else
		{
			mysql_commit(DBConNDr);
		}



	}

}

void    SendMsgDwnLd(CHAR *sSendData,LONG32     iStrmId)
{
	logTimestamp("Entry :SendMsgDwnLd:");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32  iGrpId;
	struct  NNF_MSG_DOWNLOAD_REQ *pMsgReq;

	CHAR    sSelQry[MAX_QUERY_SIZE];

	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	struct NNF_DOUBLE_INT *pTemp;

	pMsgReq = (struct NNF_MSG_DOWNLOAD_REQ *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	pTemp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));

	memcpy(pMsgReq,sSendData,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

	iGrpId = iGroupId;


	sprintf(sSelQry,"SELECT EDD_TIMESTAMP1,EDD_TIMESTAMP2 FROM    EXCH_DOWNLOAD_DATA  WHERE   EDD_EXCH_ID = \"%s\" AND     EDD_STREAM_ID   = %d\
			AND     EDD_GROUP_ID    = %d\
			AND     EDD_DRV_FLAG    = \'%c\';",NSE_EXCH,iStrmId,iGrpId,FO_DRV_FLAG);

	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConNDr,sSelQry) != SUCCESS)
	{
		sql_Error(DBConNDr);
	}
	else
	{
		Res = mysql_store_result(DBConNDr);

		if(Row = mysql_fetch_row(Res))
		{
			pTemp->iLogTime1 = atoi(Row[0]);
			pTemp->iLogTime2 = atoi(Row[1]);
		}
	}


	logDebug2("iLogTime1 :%u:",pTemp->iLogTime1);
	logDebug2("iLogTime2 :%u:",pTemp->iLogTime2);

	memcpy((CHAR *)&pMsgReq->fExchSeqNum,pTemp,sizeof(struct NNF_DOUBLE_INT));

	logDebug2("fExchSeqNum :%lf:",pMsgReq->fExchSeqNum);

	pMsgReq->sHeader.iLogTimeStamp =0;
	memset(pMsgReq->sHeader.sAlphaSplit,SPACE,ALPHA_SPLIT_LEN);
	pMsgReq->sHeader.iMsgCode = TC_NSE_MSG_DOWNLOAD_REQ;
	pMsgReq->sHeader.iErrorCode = 0;
	memset(pMsgReq->sHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);
	memset(pMsgReq->sHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	memset(pMsgReq->sHeader.sTimeStamp3,SPACE,DATE_TIME_LEN);

	pMsgReq->sHeader.iMsgLength = sizeof(struct NNF_MSG_DOWNLOAD_REQ);

	TWIDDLE(pMsgReq->sHeader.iLogTimeStamp);
	TWIDDLE(pMsgReq->sHeader.iMsgCode);
	TWIDDLE(pMsgReq->sHeader.iErrorCode);
	TWIDDLE(pMsgReq->sHeader.iLogTimeStamp);
	TWIDDLE(pMsgReq->fExchSeqNum);

	memcpy(sSendData,pMsgReq,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

	free(pMsgReq);

	logTimestamp("Exit :SendMsgDwnLd:");

}

void    GetStream(LONG32 *iStream)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32  iTempGrpId;

	CHAR    sSelQry[MAX_QUERY_SIZE];

	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	iTempGrpId = iGroupId;

	sprintf(sSelQry,"SELECT MAX(EDD_STREAM_ID) FROM EXCH_DOWNLOAD_DATA WHERE  EDD_EXCH_ID=\"%s\" AND EDD_DRV_FLAG='N' \
			AND EDD_GROUP_ID=%d",NSE_EXCH,iTempGrpId);
	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConNDr,sSelQry) != SUCCESS)
	{
		sql_Error(DBConNDr);

	}
	else
	{
		Res = mysql_store_result(DBConNDr);

		Row = mysql_fetch_row(Res);
		*iStream = atoi(Row[0]);
	}


}
