#include        <stdlib.h>
#include	<time.h>
#include	"IPCS.h"
#include 	"NseMFSSStruct.h"


BOOL	fTcpSend(LONG32 iSockFd,CHAR *sSendMsg,LONG32 iSendLen)
{
	logTimestamp("Entry : [tcpSend]");

	LONG32	iSendByte = 0,iCntErr = 1;	

	do
	{
		iSendByte = send(iSockFd,sSendMsg,iSendLen,0);

		logDebug2("iSendByte %d iCntErr %d ",iSendByte,iCntErr);

		if(iSendByte < 0)
		{
			perror("Error in Sending... Please Check");
			iCntErr++;
		}
	}
	while((iSendByte < 0) && (iCntErr < RETRY_CNTR ));   /*----RETRY_CNTR =100 */

	if((iSendByte < 0) && (iCntErr >= RETRY_CNTR ))
	{
		free(ERROR);	
		return ERROR;	
	}
	else if(iSendByte > 0)
	{
		return iSendByte;
	}
	else
	{
		logDebug2("Something went Wrong");
		return ERROR;
	}

	logTimestamp("Exit : [tcpSend]");
}

BOOL	fTcpRecv(LONG32 iSockFd,CHAR *sReply)
{
	LONG32	iRecvBytes,iReadBytes;
	SHORT	iMsgLen,iConnToErr =1;
	CHAR	*sPeekMsg;

	struct	MFSS_HEADER 	*pHeader;
	struct 	TAP_WRAPPER 	*pTapHeader;


	pHeader		= (struct MFSS_HEADER *)malloc(sizeof(struct MFSS_HEADER));
	pTapHeader 	= (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));

	memset(pTapHeader,'\0', sizeof(struct TAP_WRAPPER));
	memset(pHeader,'\0',sizeof(struct MFSS_HEADER));

	sPeekMsg 	= (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);

	iReadBytes 	= sizeof(struct TAP_WRAPPER);

	while(TRUE)
	{
		memset(sPeekMsg,NULL,NSE_PACKET_SIZE);	

		iRecvBytes = recv(iSockFd,sPeekMsg,iReadBytes,MSG_PEEK);	

		logDebug2("Receivd total Bytes length:%d:",iRecvBytes);
		logDebug2("Receivd PEEK String :%s:",sPeekMsg);

		if(iRecvBytes < 0)
		{
			perror("Error In Recv:");
			close(iSockFd);
			return (ERROR);

		}

		if(iRecvBytes == 0)
		{
			logTimestamp("Recv Bytes is '0'.......Connection close requested.... ");		
			free(sPeekMsg);
			//close(iSockFd);
			fRestartProcess();	
			return (ERROR);

		}	


		memcpy(pTapHeader,sPeekMsg,sizeof(struct TAP_WRAPPER));

		logDebug3("UnTwidddle Tap Header Msg Length :%d:",pTapHeader->iMsgLen);				
		TWIDDLE(pTapHeader->iMsgLen);	
		logDebug3("Twiddle Tap Header Msg Length :%d:",pTapHeader->iMsgLen);				

		iReadBytes = pTapHeader->iMsgLen;

		while(TRUE)
		{
			iRecvBytes = recv(iSockFd,sPeekMsg,iReadBytes,MSG_PEEK);

			if(iRecvBytes < iReadBytes)
			{
				if(iConnToErr < 100)
				{
					iConnToErr++;
					logInfo("Sleep For 1 Sec");
					sleep(1);
					continue;
				}
				else
				{
					logInfo("Full Packet Not Received ...");
					free(sPeekMsg);
					close(iSockFd);
					return ERROR;
				}
			}
			else
			{
				logInfo("Success Full Recv of Bytes :%d:",iRecvBytes);
				break;
			}
		}

		break;	

	}

	iRecvBytes = recv(iSockFd,sReply,iReadBytes,0);	

	free(sPeekMsg);
	free(pTapHeader);	
	free(pTapHeader);	
	logTimestamp("Exit : TcpRecv ");

	return iRecvBytes;

}

BOOL    fTcpRecvInvPack(LONG32 iSockFd,CHAR *sReplyInv)
{
	INT16   iRecvBytes,iReadBytes;
	LONG32  iMsgLen,iMsgCode,iConnToErr =1;

	struct  MFSS_HEADER      *pHeader;
	struct  TAP_WRAPPER     *pTapHeader;


	pHeader 	= (struct MFSS_HEADER *)malloc(sizeof(struct MFSS_HEADER));
	pTapHeader 	= (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));

	memset(pTapHeader,'\0', sizeof(struct TAP_WRAPPER));
	memset(pHeader,'\0',sizeof(struct MFSS_HEADER));

	sReplyInv 	= (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);

	iReadBytes 	= sizeof(struct TAP_WRAPPER);

	memset(sReplyInv,NULL,NSE_PACKET_SIZE);

	iRecvBytes 	= recv(iSockFd,sReplyInv,NSE_PACKET_SIZE,MSG_PEEK);

	logDebug2("Receivd Bytes :%d:",iRecvBytes);
	logDebug2("Receivd PEEK String :%s:",sReplyInv);
	if(iRecvBytes < 0)
	{
		perror("Error In Recv:");
		close(iSockFd);
		return (ERROR);
	}

	if(iRecvBytes == 0)
	{
		perror("Connection Lost with TAP:");
		//	close(iSockFd);
		fRestartProcess();
		return (ERROR);
	}

	TWIDDLE(((struct INVITATION_PACKET *)sReplyInv)->pHeader.iMsgLength);
	TWIDDLE(((struct INVITATION_PACKET *)sReplyInv)->pHeader.iMsgCode);

	iMsgLen = ((struct INVITATION_PACKET *)sReplyInv)->pHeader.iMsgLength;
	iMsgCode = ((struct INVITATION_PACKET *)sReplyInv)->pHeader.iMsgCode;	

	logInfo("MsgCode = :%d:",iMsgCode);
	logInfo("iMsgLen = :%d:",iMsgLen);

	if(iMsgCode == TC_EQU_NSE_INVITATION_REQ) /* 15000 */
	{
		logInfo("Successfully Recv Invitation Pack ");
		return iRecvBytes;
	}		
	else
	{
		logInfo("Error in  Recv Invitation Pack ");
		return ERROR;
	}

} 


