#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "NseMFSSStruct.h"

extern DBConNEQ;
extern iGroupId;
extern sKey;

BOOL	fFetchSignOnDet(CHAR *sSignOnReq,LONG32	iGrpId)
{
	struct MFSS_SIGNON_REQ *pSign;
	LONG32 logonreq_result;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	pSign = (struct MFSS_SIGNON_REQ *)malloc(sizeof(struct MFSS_SIGNON_REQ));

	memcpy(pSign,sSignOnReq,sizeof(struct MFSS_SIGNON_REQ));

	memset(pSign,' ',sizeof(struct MFSS_SIGNON_REQ));

	CHAR	*sSignQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	memset(pSign->pHeader.sReserved,SPACE,2);
	pSign->pHeader.iLogTime = 0;
	memset(pSign->pHeader.sAlphaChar ,SPACE,ALPHA_SPLIT_LEN);
	pSign->pHeader.iMsgCode= 0;
	pSign->pHeader.iErrorCode= 0;
	memset(pSign->pHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);
	memset(pSign->pHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	memset(pSign->pHeader.sTimeStamp3,SPACE,DATE_TIME_LEN);
	pSign->pHeader.iLogTime = 0;

	pSign->iExchUserID= 0;
	memset(pSign->sPassword,SPACE,NSE_PASSWORD_LEN);
	memset(pSign->sNewPassword,SPACE,NSE_PASSWORD_LEN);
	pSign->cReserve1 = SPACE;
	memset(pSign->sBrokerID,SPACE,BROKER_CODE_LEN);
	pSign->cReserve2 = SPACE;


	pSign->cReserve3 = SPACE;
	memset(pSign->sWorkStatName,SPACE,WORK_STATION_ADDR_LEN);
	memset(pSign->sTraderName,SPACE,BROKER_NAME_LEN);

	pSign->pBrkElgMk.iReserve1 = 0;
	pSign->pBrkElgMk.iReserve2 = 0;
	pSign->pBrkElgMk.iSPOTMkt = 0;
	pSign->pBrkElgMk.iReserve3 = 0;
	pSign->pBrkElgMk.iReserve4 = 0;
	pSign->pBrkElgMk.iReserve5 = 0;

	pSign->pHeader.iErrorCode = 0 ;
	pSign->pHeader.iLogTime = 0 ;
	pSign->pHeader.iMsgCode = TC_EQU_NSE_SIGNON_REQ;
	memset(pSign->pHeader.sAlphaChar,SPACE,2);
	memcpy(pSign->pHeader.sAlphaChar,ALPHA_SPLIT,ALPHA_SPLIT_LEN);
	pSign->pHeader.iMsgLength = sizeof(struct MFSS_SIGNON_REQ);
	/***
	  sprintf(sSignQry,"SELECT     EAM_EXCH_USER_ID,    EAM_OLD_PASSWORD,    IFNULL(EAM_NEW_PASSWORD,' '),    EAM_BROKER_ID, \
	  EAM_VERSION_NO,    EAM_WORKSTATION_ADDRESS,    EAM_TRADER_NAME FROM\
	  EXCH_ADMINISTRATION_MASTER 	WHERE  \
	  EAM_GROUP_ID = %d\
	  AND EAM_EXM_EXCH_ID = \"%s\"\
	  AND EAM_DRV_FLAG = \'%c\' \
	  AND EAM_SEGMENT =\'%c\';",iGrpId,NSE_EXCH,EQ_DRV_FLAG,EQUITY_SEGMENT);
	 ***/
	sprintf(sSignQry,"SELECT     EAM_EXCH_USER_ID,    aes_decrypt(EAM_OLD_PASSWORD,\'%s\'),    IFNULL(aes_decrypt(EAM_NEW_PASSWORD,\'%s\'),' '),    EAM_BROKER_ID, \
			EAM_VERSION_NO,    EAM_WORKSTATION_ADDRESS,    EAM_TRADER_NAME FROM\
			EXCH_ADMINISTRATION_MASTER      WHERE  \
			EAM_GROUP_ID = %d\
			AND EAM_EXM_EXCH_ID = \"%s\"\
			AND EAM_DRV_FLAG = \'%c\' \
			AND EAM_SEGMENT =\'%c\';",sKey,sKey,iGrpId,NSE_EXCH,EQ_DRV_FLAG,EQUITY_SEGMENT);

	logDebug2("sSignQry :%s:",sSignQry);

	if(mysql_query(DBConNEQ,sSignQry) != SUCCESS)
	{
		sql_Error(DBConNEQ);
		return FALSE;
	}


	Res = mysql_store_result(DBConNEQ);

	if(Row = mysql_fetch_row(Res))
	{
		pSign->iExchUserID= atoi(Row[0]);
		strncpy(pSign->sPassword, Row[1],NSE_PASSWORD_LEN);
		if(Row[2][0] == SPACE)
		{
			strncpy(pSign->sNewPassword,SPACE ,NSE_PASSWORD_LEN);
		}
		else
		{
			strncpy(pSign->sNewPassword,Row[2],NSE_PASSWORD_LEN);
		}		

		strncpy(pSign->sBrokerID,Row[3] ,BROKER_CODE_LEN);
		pSign->iVersionNum = atoi(Row[4]);
		strncpy(pSign->sWorkStatName,Row[5] ,WORK_STATION_ADDR_LEN);
		strncpy(pSign->sTraderName,Row[6] ,BROKER_NAME_LEN);

	}

	logInfo("Printing SignOn Before Twiddle ---------------------------------------------- ");
	logDebug2("pSign->pHeader.iMsgCode 	:%d:",pSign->pHeader.iMsgCode);
	logDebug2("pSign->pHeader.sAlphaChar	:%s:",pSign->pHeader.sAlphaChar);
	logDebug2("pSign->pHeader.iMsgLength 	:%d:",pSign->pHeader.iMsgLength);

	logDebug2("pSign->iExchUserID	:%d:",pSign->iExchUserID);
	logDebug2("pSign->sPassword 		:%s:",pSign->sPassword);
	logDebug2("pSign->sNewPassword		:%s:",pSign->sNewPassword);
	logDebug2("pSign->sBrokerID		:%s:",pSign->sBrokerID);
	logDebug2("pSign->iVersionNum	:%s:",pSign->iVersionNum);
	logDebug2("pSign->sWorkStatName		:%s:",pSign->sWorkStatName);
	logDebug2("pSign->sTraderName 		:%s:",pSign->sTraderName);
	logInfo("Printing SignOn Before Twiddle ---------------------------------------------- ");

	TWIDDLE(pSign->pHeader.iLogTime);
	TWIDDLE(pSign->pHeader.iMsgCode);
	TWIDDLE(pSign->pHeader.iErrorCode);
	TWIDDLE(pSign->pHeader.iMsgLength);
	TWIDDLE(pSign->iExchUserID);
	TWIDDLE(pSign->iVersionNum);

	logInfo("Printing SignOn After Twiddle ---------------------------------------------- ");
	logDebug2("pSign->pHeader.iMsgCode      :%d:",pSign->pHeader.iMsgCode);
	logDebug2("pSign->pHeader.sAlphaChar   :%s:",pSign->pHeader.sAlphaChar);
	logDebug2("pSign->pHeader.iMsgLength    :%d:",pSign->pHeader.iMsgLength);

	logDebug2("pSign->iExchUserID		:%d:",pSign->iExchUserID);
	logDebug2("pSign->sPassword             :%s:",pSign->sPassword);
	logDebug2("pSign->sNewPassword          :%s:",pSign->sNewPassword);
	logDebug2("pSign->sBrokerID           	:%s:",pSign->sBrokerID);
	logDebug2("pSign->iVersionNum        :%s:",pSign->iVersionNum);
	logDebug2("pSign->sWorkStatName		:%s:",pSign->sWorkStatName);
	logDebug2("pSign->sTraderName 		:%s:",pSign->sTraderName);
	logInfo("Printing SignOn After  Twiddle ---------------------------------------------- ");

	memcpy(sSignOnReq,pSign,sizeof(struct MFSS_SIGNON_REQ));

	free(pSign);

	return TRUE;


}


BOOL	fUpdateSignOnResp(struct MFSS_SIGNON_RESP *pSignOnResp)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	LONG64		iSysTimeStmp,iNseTimeStmp,iTempTimeStmp;	

	CHAR		sNseEndTime[DATE_STRING_LENGTH];
	CHAR		sLastPswdChng[DATE_STRING_LENGTH];
	CHAR		*UpdQuery= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	if(mysql_query(DBConNEQ,"SELECT JULIDATE(now());") != SUCCESS)
	{
		sql_Error(DBConNEQ);
		return FALSE;
	}

	Res = mysql_store_result(DBConNEQ);
	if(Row = mysql_fetch_row(Res))
	{
		iSysTimeStmp = atol(Row[0]);	
	}
	iNseTimeStmp = pSignOnResp->pHeader.iLogTime;

	logDebug2("iSysTimeStmp :%ld:",iSysTimeStmp);

	iTempTimeStmp = iNseTimeStmp - iSysTimeStmp;	

	logDebug2("iTempTimeStmp :%d:",iTempTimeStmp);

	ConvSecToDate(pSignOnResp->iPasswdChngDate,sLastPswdChng);

	logDebug3(" sLastPswdChng :%s:",sLastPswdChng);
	ConvSecToDate(pSignOnResp->iEndTime,sNseEndTime);

	logDebug3(" sNseEndTime :%s:",sNseEndTime);

	sprintf(UpdQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET  \
			EAM_OLD_PASSWORD = \"%s\" ,\
			EAM_NEW_PASSWORD = '',\
			EAM_TRADER_NAME = \"%s\" ,\
			EAM_EXCH_OFFSET_TIME = %ld \
			EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y%%m%%d-%%H:%%i:%%S\')\
			EAM_BROKER_ID = \"%s\" ,\
			EAM_BRANCH_ID = %d \
			EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y%%m%%d-%%H:%%i:%%S\')\
			EAM_BROKER_STATUS = \'%c\'\
			EAM_LOGON_STATUS = 'A' \
			WHERE \
			EAM_EXM_EXCH_ID = \"%s\" \
			AND EAM_EXCH_USER_ID = %d \
			AND EAM_DRV_FLAG = \'%c'\;",pSignOnResp->sPassword,pSignOnResp->sTraderName,iTempTimeStmp,sLastPswdChng,pSignOnResp->sBrokerID,\
			pSignOnResp->iBranchID,sNseEndTime,pSignOnResp->cBrokerStat,NSE_EXCH,pSignOnResp->iExchUserID,EQ_DRV_FLAG);

	logDebug1("UpdQuery :%s:",UpdQuery);
	if(mysql_query(DBConNEQ,UpdQuery) != SUCCESS)	
	{
		sql_Error(DBConNEQ);
		return FALSE;	
	}
	else
	{
		mysql_commit(DBConNEQ);
	}

	return TRUE;	


}

void	fGetStrForCode(LONG32	iCode,CHAR *sStrMsg)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	CHAR	*sSelQury = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	

	sprintf(sSelQury ,"SELECT ERM_REASON_DESCRIPTION FROM EXCH_REASON_MASTER WHERE ERM_REASON_CODE = %d;",iCode);	

	logDebug2("sSelQury :%d:",sSelQury);

	if(mysql_query(DBConNEQ,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNEQ);
	}

	Res = mysql_store_result(DBConNEQ);
	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sStrMsg,Row[0],DB_REASON_DESC_LEN);	
	}

}

BOOL    SendUpdReq(CHAR *sSendmsg)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	CHAR	sSelQury[MAX_QUERY_SIZE];

	LONG32	iLastUpdTime,iCreatTime;	
	INT16	iMktType=0;


	struct  MFSS_UPD_LDB_REQ	*pSndUpd;

	memset(sSelQury,'\0',MAX_QUERY_SIZE);

	sprintf(sSelQury,"SELECT JULIDATE(EAM_LAST_UPDATE_PART_TIME) FROM EXCH_ADMINISTRATION_MASTER \
			WHERE  \                 
			EAM_GROUP_ID   = 1\
			AND EAM_EXM_EXCH_ID = \"%s\" \
			AND EAM_DRV_FLAG = \'%c\'",EQ_DRV_FLAG,NSE_EXCH);

	logDebug1("sSelQury :%s:",sSelQury);
	if(mysql_query(DBConNEQ,sSelQury) != SUCCESS)	
	{
		sql_Error(DBConNEQ);
		return FALSE;
	}

	Res = mysql_store_result(DBConNEQ);
	if (Row = mysql_fetch_row(Res))
	{
		iLastUpdTime = atol(Row[0]);	
	}

	memset(sSelQury,'\0',MAX_QUERY_SIZE);
	mysql_free_result(Res);

	sprintf(sSelQury,"SELECT max(JULIDATE(SM_UPDATE_DATE)) FROM SECURITY_MASTER ");

	logDebug1("sSelQury :%s:",sSelQury);
	if(mysql_query(DBConNEQ,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNEQ);
		return FALSE;
	}

	Res = mysql_store_result(DBConNEQ);
	if (Row = mysql_fetch_row(Res))
	{
		iCreatTime = atol(Row[0]);
	}


	memset(sSelQury,'\0',MAX_QUERY_SIZE);
	mysql_free_result(Res);

	sprintf(sSelQury,"SELECT EMM_STATUS,EMM_MKT_TYPE_NO from EXCH_MKT_MASTER WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG = \'%c'\ AND EMM_MKT_TYPE_NO = %d;",NSE_EXCH,EQUITY_SEGMENT,SPOT_MARKET);

	logDebug1("sSelQury :%s:",sSelQury);
	if(mysql_query(DBConNEQ,sSelQury) != SUCCESS)
	{
		sql_Error(DBConNEQ);
		return FALSE;
	}

	Res = mysql_store_result(DBConNEQ);
	if(Row = mysql_fetch_row(Res))
	{
		iMktType = atoi(Row[1]);			
		pSndUpd->pMktStat.iSpotMkt = atoi(Row[0]);

	}	

	memset(pSndUpd->pHeader.sReserved ,SPACE,2);
	pSndUpd->pHeader.iLogTime = 0;
	memset(pSndUpd->pHeader.sAlphaChar,SPACE,ALPHA_SPLIT_LEN);
	pSndUpd->pHeader.iMsgCode = TC_NSE_UPD_LDB_DOWNLD_REQ;
	pSndUpd->pHeader.iErrorCode = 0;
	memset(pSndUpd->pHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);	
	memset(pSndUpd->pHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);	
	memset(pSndUpd->pHeader.sTimeStamp3,SPACE,DATE_TIME_LEN);	
	pSndUpd->pHeader.iMsgLength = sizeof(struct  MFSS_UPD_LDB_REQ);	

	pSndUpd->iLastUpdSecTime = 	iCreatTime;
	pSndUpd->iLastUpdCatTime = 	iLastUpdTime;
	pSndUpd->iLastUpdSIPTime = 	iLastUpdTime;

	return TRUE;

}


BOOL	fUpdSysInfo(CHAR *sDataMsg)
{
	struct MFSS_SYS_INFO_RESP *pSysin;
	CHAR	sUpdQry [MAX_QUERY_SIZE];
	CHAR	sInsQry [MAX_QUERY_SIZE];
	LONG32	iNoStream,iTempGid;;

	pSysin = (struct MFSS_SYS_INFO_RESP *)malloc(sizeof(struct MFSS_SYS_INFO_RESP));

	memcpy(pSysin,sDataMsg,sizeof(struct MFSS_SYS_INFO_RESP));


	TWIDDLE(pSysin->pHeader.iMsgCode);
	TWIDDLE(pSysin->pHeader.iMsgLength);
	TWIDDLE(pSysin->pMktStat.iSpotMkt);
	TWIDDLE(pSysin->iTerminalIdleID);
	TWIDDLE(pSysin->iInqTimer);

	iTempGid = iGroupId;	

	if((pSysin->pHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP) || (pSysin->pHeader.iMsgCode == TC_EQU_NSE_PARTIAL_SYS_INFO_RESP))
	{
		memset(sUpdQry,'\0',MAX_QUERY_SIZE);

		sprintf(sUpdQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS =  %d WHERE EMM_MKT_TYPE = %d AND EMM_EXM_EXCH_ID = \"%s\" AND  EMM_EXCH_SEG = \'%c\';",pSysin->pMktStat.iSpotMkt,SPOT_MARKET,NSE_EXCH ,SEGMENT_EQUITY);

		logDebug2("sUpdQry :%s:",sUpdQry);
		if(mysql_query(DBConNEQ,sUpdQry) != SUCCESS)
		{
			sql_Error(DBConNEQ);
			return FALSE;
		}

		return TRUE;		

	}



}

void	InsertExchDigit()
{

	CHAR    sInsQry [MAX_QUERY_SIZE];
	LONG32  iNoStream,iTempGid,j;

	iTempGid = iGroupId;
	for(j =1 ;j<= iNoStream;j++ )
	{
		memset(sInsQry,'\0',MAX_QUERY_SIZE);
		sprintf(sInsQry,"INSERT INTO EXCH_DOWNLOAD_DATA(EDD_GROUP_ID,EDD_EXCH_ID,EDD_DRV_FLAG,EDD_STREAM_ID,EDD_TIMESTAMP1,EDD_TIMESTAMP2)\
				VALUES(%d,\"%s\",'N',%d,0,0) \
				on duplicate key \
				UPDATE \
				EDD_GROUP_ID = VALUES(EDD_GROUP_ID) ,\
				EDD_EXCH_ID     = VALUES(EDD_EXCH_ID) ,\
				EDD_DRV_FLAG= VALUES(EDD_DRV_FLAG) ,\
				EDD_STREAM_ID= VALUES(EDD_STREAM_ID) ,\
				EDD_TIMESTAMP1= VALUES(EDD_TIMESTAMP1) ,\
				EDD_TIMESTAMP2= VALUES(EDD_TIMESTAMP2) ;",iTempGid,NSE_EXCH,j);

		logDebug2("sInsQry :%s:",sInsQry);
		if(mysql_query(DBConNEQ,sInsQry) != SUCCESS)
		{
			logFatal("Error in Update");
			sql_Error(DBConNEQ);
		}
		else
		{
			mysql_commit(DBConNEQ);
		}



	}

}



void	SendMsgDwnLd(CHAR *sSendData,LONG32	iStrmId)
{
	logTimestamp("Entry :SendMsgDwnLd:");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	LONG32	iGrpId;
	struct	MFSS_MSG_DOWNLOAD_REQ *pMsgReq;

	CHAR	sSelQry[MAX_QUERY_SIZE];

	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	struct MFSS_DOUBLE_INT *pTemp;

	pMsgReq = (struct MFSS_MSG_DOWNLOAD_REQ *)malloc(sizeof(struct MFSS_MSG_DOWNLOAD_REQ));
	pTemp = ( struct MFSS_DOUBLE_INT *)malloc(sizeof(struct MFSS_DOUBLE_INT));	

	memcpy(pMsgReq,sSendData,sizeof(struct MFSS_MSG_DOWNLOAD_REQ));

	iGrpId = iGroupId;


	sprintf(sSelQry,"SELECT EDD_TIMESTAMP1,EDD_TIMESTAMP2 FROM    EXCH_DOWNLOAD_DATA  WHERE   EDD_EXCH_ID = \"%s\" AND     EDD_STREAM_ID   = %d\
			AND     EDD_GROUP_ID    = %d\
			AND     EDD_DRV_FLAG    = 'N';",NSE_EXCH,iStrmId,iGrpId);	

		logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConNEQ,sSelQry) != SUCCESS)
	{
		sql_Error(DBConNEQ);
	}
	else
	{
		Res = mysql_store_result(DBConNEQ);

		if(Row = mysql_fetch_row(Res))
		{
			pTemp->iLogTime1 = atoi(Row[0]);
			pTemp->iLogTime2 = atoi(Row[1]);
		}


	}


	logDebug2("iLogTime1 :%u:",pTemp->iLogTime1);
	logDebug2("iLogTime2 :%u:",pTemp->iLogTime2);

	memcpy((CHAR *)&pMsgReq->fExchSeqNum,pTemp,sizeof(struct MFSS_DOUBLE_INT));

	logDebug2("fExchSeqNum :%lf:",pMsgReq->fExchSeqNum);

	pMsgReq->pHeader.iLogTime =0;
	memset(pMsgReq->pHeader.sAlphaChar,"",ALPHA_SPLIT_LEN);
	pMsgReq->pHeader.iMsgCode = TC_NSE_MSG_DOWNLOAD_REQ;
	pMsgReq->pHeader.iErrorCode = 0;
	memset(pMsgReq->pHeader.sTimeStamp1,SPACE,DATE_TIME_LEN);
	memset(pMsgReq->pHeader.sTimeStamp2,SPACE,DATE_TIME_LEN);
	memset(pMsgReq->pHeader.sTimeStamp3,SPACE,DATE_TIME_LEN);

	pMsgReq->pHeader.iMsgLength = sizeof(struct MFSS_MSG_DOWNLOAD_REQ);

	TWIDDLE(pMsgReq->pHeader.iLogTime);	
	TWIDDLE(pMsgReq->pHeader.iMsgCode);	
	TWIDDLE(pMsgReq->pHeader.iErrorCode);	
	TWIDDLE(pMsgReq->pHeader.iLogTime);	
	TWIDDLE(pMsgReq->fExchSeqNum);	

	memcpy(sSendData,pMsgReq,sizeof(struct MFSS_MSG_DOWNLOAD_REQ));

	free(pMsgReq);

	logTimestamp("Exit :SendMsgDwnLd:");	

}

void	GetStream(LONG32 *iStream)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	LONG32	iTempGrpId;

	CHAR	sSelQry[MAX_QUERY_SIZE];

	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	iTempGrpId = iGroupId;

	sprintf(sSelQry,"SELECT MAX(EDD_STREAM_ID) FROM EXCH_DOWNLOAD_DATA WHERE  EDD_EXCH_ID=\"%s\" AND EDD_DRV_FLAG=\'%c\' \ 
			AND EDD_GROUP_ID=%d",NSE_EXCH,EQ_DRV_FLAG,iTempGrpId);
	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConNEQ,sSelQry) != SUCCESS)
	{
		sql_Error(DBConNEQ);

	}
	else
	{
		Res = mysql_store_result(DBConNEQ);

		Row = mysql_fetch_row(Res);
		*iStream = atoi(Row[0]);
	}


}
