#include        <stdlib.h>
#include	<time.h>
#include	"IPCS.h"
#include 	"DrvNseStruct.h"


BOOL	fTcpSend(LONG32 iSockFd,CHAR *sSendMsg,LONG32 iSendLen)
{
	logTimestamp("Entry : [tcpSend]");

	LONG32	iSendByte = 0,iCntErr = 1;	

	do
	{
		iSendByte = send(iSockFd,sSendMsg,iSendLen,0);

		if(iSendByte < 0)
		{
			perror("Error in Sending... Please Check");
			iCntErr++;
		}
	}
	while((iSendByte < 0) && (iCntErr < 100 ));

	if((iSendByte < 0) && (iCntErr >= 100 ))
	{
		free(ERROR);	
		return ERROR;	
	}
	logTimestamp("Exit : [tcpSend]");
	return iSendByte;
}

BOOL	fTcpRecv(LONG32 iSockFd,CHAR *sReply)
{
	logTimestamp("Entry [fTcpRecv]");
	LONG32	iRecvBytes,iReadBytes;
	SHORT	iMsgLen,iConnToErr =1;
	CHAR	*sPeekMsg;

	struct	NNF_HEADER 	*sHeader;
	struct 	TAP_WRAPPER 	*pTapHeader;

	sHeader	= (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	pTapHeader = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTapHeader,'\0', sizeof(struct TAP_WRAPPER));
	memset(sHeader,'\0',sizeof(struct NNF_HEADER));

	sPeekMsg = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);

	iReadBytes = sizeof(struct TAP_WRAPPER);

	memset(sReply,NULL,NSE_PACKET_SIZE);
	while(TRUE)
	{
		memset(sPeekMsg,NULL,NSE_PACKET_SIZE);	

		iRecvBytes = recv(iSockFd,sPeekMsg,iReadBytes,MSG_PEEK);	

		logDebug2("Receivd Bytes :%d:",iRecvBytes);
		logDebug2("Receivd PEEK String :%s:",sPeekMsg);

		if(iRecvBytes < 0)
		{
			perror("Error In Recv:");
			close(iSockFd);
			return (ERROR);

		}

		if(iRecvBytes == 0)
		{
			logTimestamp("Recv Bytes is '0'.......Connection close requested.... ");		
			free(sPeekMsg);
			//close(iSockFd);
			fRestartProcess();	
			return (ERROR);

		}	


		memcpy(pTapHeader,sPeekMsg,sizeof(struct TAP_WRAPPER));

		logDebug3("UnTwidddle Tap Header Msg Length :%d:",pTapHeader->iMsgLen);				
		TWIDDLE(pTapHeader->iMsgLen);	
		logDebug3("Twiddle Tap Header Msg Length :%d:",pTapHeader->iMsgLen);				

		iReadBytes = pTapHeader->iMsgLen;

		while(TRUE)
		{
			iRecvBytes = recv(iSockFd,sPeekMsg,iReadBytes,MSG_PEEK);

			if(iRecvBytes < iReadBytes)
			{
				if(iConnToErr < 100)
				{
					iConnToErr++;
					logInfo("Sleep For 1 Sec");
					sleep(1);
					continue;
				}
				else
				{
					logInfo("Full Packet Not Received ...");
					free(sPeekMsg);
					close(iSockFd);
					return ERROR;
				}
			}
			else
			{
				logInfo("Success Full Recv of Bytes :%d:",iRecvBytes);
				break;
			}
		}

		break;	

	}

	iRecvBytes = recv(iSockFd,sReply,iReadBytes,0);	

	free(sHeader);
	free(pTapHeader);	
	logTimestamp("Exit : TcpRecv ");

	return iRecvBytes;


}

BOOL    fTcpRecvInvPack(LONG32 iSockFd,CHAR *sReplyInv)
{
	INT16   iRecvBytes,iReadBytes;
	LONG32  iMsgLen,iMsgCode,iConnToErr =1;

	struct  NNF_HEADER      *sHeader;
	struct  TAP_WRAPPER     *pTapHeader;


	sHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	pTapHeader = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTapHeader,'\0', sizeof(struct TAP_WRAPPER));
	memset(sHeader,'\0',sizeof(struct NNF_HEADER));

	sReplyInv = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);

	iReadBytes = sizeof(struct TAP_WRAPPER);

	memset(sReplyInv,NULL,NSE_PACKET_SIZE);

	iRecvBytes = recv(iSockFd,sReplyInv,NSE_PACKET_SIZE,MSG_PEEK);

	logDebug2("Receivd Bytes :%d:",iRecvBytes);
	logDebug2("Receivd PEEK String :%s:",sReplyInv);
	if(iRecvBytes < 0)
	{
		perror("Error In Recv:");
		close(iSockFd);
		return (ERROR);
	}

	if(iRecvBytes == 0)
	{
		perror("Connection Lost with TAP:");
		//	close(iSockFd);
		fRestartProcess();
		return (ERROR);
	}

	TWIDDLE(((struct INVITATION_PACKET *)sReplyInv)->sHeader.iMsgLength);
	TWIDDLE(((struct INVITATION_PACKET *)sReplyInv)->sHeader.iMsgCode);

	iMsgLen = ((struct INVITATION_PACKET *)sReplyInv)->sHeader.iMsgLength;
	iMsgCode = ((struct INVITATION_PACKET *)sReplyInv)->sHeader.iMsgCode;	

	logInfo("MsgCode = :%d:",iMsgCode);
	logInfo("iMsgLen = :%d:",iMsgLen);

	if(iMsgCode == TC_EQU_NSE_INVITATION_REQ)
	{
		logInfo("Successfully Recv Invitation Pack ");
		return iRecvBytes;
	}		
	else
	{
		logInfo("Error in  Recv Invitation Pack ");
		return ERROR;
	}

} 


