#include <stdlib.h>
//#include    "EquNseConnect.h" 
//#include    "Queue.h"				/* function defining the message queue parameters */
#include <errno.h>
#include "IPCS.h" 
#include "NNFStruct.h"
//#define 	LOOP_COUNTER 10
#include <time.h>
//#define TWIDDLE(A)      Twiddle ((CHAR *) &A, sizeof(A))

//LONG32	tcpConnect(CHAR *sIPaddr, LONG32 iPort)
extern	CHAR    sPrimTAPip[CALLING_LENS];
extern  CHAR    sSecoTAPip[CALLING_LENS];
extern  LONG32  iPrimTAPport;
extern  LONG32  iSecoTAPport;
extern  LONG32  iBusyTimer;

LONG32	tcpConnect(LONG32 iPrimarySecondary)
{
	logTimestamp("Entry : [tcpConnect]");
	logInfo("Hey in tcpConnect ");
	struct	sockaddr_in	pServaddr;

	LONG32 	iSockfd,				/* this variable defines the socket connection descriptor */
		iDiditconnect,				/* variable used as iFlag for testing connection */
		iSleeptime=1,				/* incremental sleep time variable */
		iCount_to_error=1;			/* this counter when exceeds 99 the function terminates */
	CHAR 	*sError;							
	LONG32 	iCounterForConnect=0;
	sError = (CHAR *)malloc(sizeof(CHAR)*SIZE);
	logInfo(".c file here11");

	do
	{   
		if( (iSockfd = socket( PF_INET, SOCK_STREAM, 0 )) < 0 )
		{
			logDebug1("iSockfd = %d",iSockfd);
			memset(sError,NULL,SIZE);
			strcpy(sError,strerror(errno));
			sleep(iSleeptime);
		}
		logDebug1("iSockfd111111111 = %d", iSockfd);

		if ( iSockfd > 0 )
		{
			logInfo("Inside loop sopckfd > 0 ");
			memset(&pServaddr,0,sizeof(pServaddr));    
			if(iPrimarySecondary == 1)
			{
				logInfo("Try connecting with Secondary IP PORT :%s: :%d:",sSecoTAPip,iSecoTAPport);
				pServaddr.sin_family = AF_INET;

	                        pServaddr.sin_addr.s_addr = inet_addr(sSecoTAPip);
	                        pServaddr.sin_port=htons(iSecoTAPport);
				// Printing for monitoring purpose @NItish
				logTimestamp(":%s: TRYING TO CONNNECT GATEROUTER SECONDARY IP :%s: PORT :%d:",KEY_WORD_MONITORING,sSecoTAPip,iSecoTAPport);
			}
			else
			{
				logInfo("Try connecting with Primary IP PORT :%s: :%d:",sPrimTAPip,iPrimTAPport);
				pServaddr.sin_family = AF_INET;

	                        pServaddr.sin_addr.s_addr = inet_addr(sPrimTAPip);
	                        pServaddr.sin_port=htons(iPrimTAPport);
				// Printing for monitoring purpose @NItish
				logTimestamp(":%s: TRYING TO CONNNECT GATEROUTER PRIMARY IP :%s: PORT :%d:",KEY_WORD_MONITORING,sPrimTAPip,iPrimTAPport);
			}

/**
			pServaddr.sin_family = AF_INET;

			pServaddr.sin_addr.s_addr = inet_addr(getenv("TAP_IP1"));
			pServaddr.sin_port=htons(9601);
**/
			/****		pServaddr.sin_addr.s_addr = inet_addr(IPaddr);
			  pServaddr.sin_port=htons(port);****/

			/*------- Checking for socket connection -------*/

			do
			{
				iDiditconnect = connect( iSockfd, (struct sockaddr *) &pServaddr, sizeof(pServaddr) );
				logDebug2("iDiditconnect = %d ", iDiditconnect);
				if (iDiditconnect < 0)
				{
					iCounterForConnect++;
					logInfo("Connection to the server Denied......... Closing Socket Connection........");
					memset(sError,NULL,SIZE);
					strcpy(sError,strerror(errno));
					logTimestamp(":%s: GETTING DISCONNNECTED GATEROUTER  IP :%s: PORT :%d: DUE TO REASON :%s:",KEY_WORD_MONITORING,sPrimTAPip,iPrimTAPport,sError);
					sleep(iSleeptime);
					iSleeptime++;
					close(iSockfd);						/* closing socket before termination */
					if( (iSockfd = socket( PF_INET, SOCK_STREAM, 0 )) < 0 )
					{
						logDebug1("iSockfd = %d", iSockfd); 
						memset(sError,NULL,SIZE);
						strcpy(sError,strerror(errno));
						sleep(iSleeptime);
					}
					logDebug1("Outside loop <0, iSockfd = %d ", iSockfd);
				}
				if(iCounterForConnect == 3 )
				{
					close(iSockfd);                      /* closing socket before termination */
					break;
				}
			}while( iDiditconnect < 0 );
		}
		logInfo("outside loop of iSockfd >0");
		iSleeptime++;
		iCount_to_error++;
	}while(( iSockfd < 0 ) && (iCounterForConnect == 3));

	free(sError);

	if( iCounterForConnect == 3)
	{
		logInfo("Returned Failover Signal Successfully........");
		return (-1);
	}
	logInfo("Returned Sockfd Successfully........");
	// Printing for monitoring purpose @NItish
	logTimestamp(":%s: CONNNECTION SUCCESSFULL TO GATEROUTER IP :%s: PORT :%d:",KEY_WORD_MONITORING,sPrimTAPip,iPrimTAPport);

	logTimestamp("Exit : [tcpConnect]");
	return (iSockfd);
}


/***********
  Function Name:				tcpSend
Arguments:				iSockfd 		- LONG32
request 	- CHAR *
size		- LONG32	
Return Values:				iSent_bytes	- LONG32				
Tables Used:				Null
Dependencies:				socket.h 	functions called - send
Comments:				This function sends the specified no. of bytes through the socket
 **********/


LONG32	tcpSend( LONG32 iSockfd, CHAR* cRequest, LONG32 iSize ) 
{
	logTimestamp("Entry : [tcpSend]");	

	LONG32 	iSent_bytes,iCount_to_error = 1;
	CHAR 	*sError;
	CHAR 	sProgTime[40];

	memset(sProgTime,'\0',40);
	sError = (CHAR *)malloc(sizeof(CHAR)*SIZE);


	do
	{
/**
 *	1. Busy Timer moved from ReadMsgQ to sending to exchange @Nitish
 *
 * **/
		logInfo("iBusyTimer :%d:",iBusyTimer);
		usleep(iBusyTimer);

		iSent_bytes = send ( iSockfd, cRequest , iSize , 0 );
		//fGetTime(sProgTime);
		logDebug1(" DATA Sent at [%d] IST",iSent_bytes);

		if (iSent_bytes < 0)
		{	
			memset(sError,NULL,SIZE);
			strcpy(sError,strerror(errno));
			logDebug3(" prLONG32ing Error size: %d",iSize )  ;
			logDebug3(" EquStcpComm.c : %s ", strerror(errno));

			fGetTime(sProgTime);

			logDebug3(" DATA Sent is 0 Bytes [%s] IST",sProgTime);
			iCount_to_error++;
		}

	}while(( iSent_bytes < 0 ) && (iCount_to_error < 100 ));		/* try to send the data on socket 99 times after which fails */

	if (( iSent_bytes < 0 ) && (iCount_to_error >= 100 ))
	{
		free(sError);
		exit(ERROR);
	}

	free(sError);
	logTimestamp("Exit : [tcpSend]");
	return(iSent_bytes);
}


/***********
  Function Name:				tcpRecv
Arguments:				iSockfd		- LONG32
sReply		- CHAR *
Return Values:				iRecv_bytes  - LONG32
Tables Used:				Null
Dependencies:				socket.h functions used - recv 
Comments:				This function recieves the data through the socket  
- 	recieves bytes not more than that specified in size
 **********/

LONG32	tcpRecv( LONG32 iSockfd, CHAR* sReply )
{
	logTimestamp("Entry : [tcpRecv]");

	LONG32	iRecv_bytes=0,
		iCount_to_error=1,
		iReadBytes = 0;
	//    	short 	msg_length;
	//struct  NNF_HEADER	*pHeader;
	struct 	TAP_WRAPPER 	*pTapHeader;
	CHAR    *sTake_peek,         /* variable to just peek LONG32o the socket for data arrival */
		*sError;
	CHAR 	sProgTime[40];

	memset(sProgTime,'\0',40);
	LONG32	iCounterForConnect=0;

	//pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	pTapHeader = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTapHeader,'\0', sizeof(struct TAP_WRAPPER));
	//memset(pHeader,'\0',sizeof(struct NNF_HEADER));

	sTake_peek = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	sError = (CHAR *)malloc(sizeof(CHAR)*SIZE);


	iReadBytes = sizeof(struct TAP_WRAPPER);

	for( ; ; )      
	{
		memset(sTake_peek,NULL,NSE_PACKET_SIZE);
		logDebug3("IN TAPCOMM bfr receive :%d: iSockfd :%d:",iRecv_bytes,iSockfd);

		iRecv_bytes = recv( iSockfd, sTake_peek , iReadBytes ,MSG_PEEK );
		logDebug3("IN TAPCOMM after receive ");

		logDebug2(" Received Successfully : %d",iRecv_bytes);
		logDebug2(" Take_peek is [%s]", sTake_peek);

		if (iRecv_bytes < 0)
		{
			memset(sError,NULL,SIZE);
			strcpy(sError,strerror(errno));
			free(sTake_peek);
			logInfo(" Received byte is < 0");

			fGetTime(sProgTime);

			logInfo(" DATA RECV < 0 BYTES at [%s] IST",sProgTime);
			//close(iSockfd);
			return(ERROR);
		}

		if (iRecv_bytes == 0)
		{
			fGetTime(sProgTime);
			logInfo("[%s]BYTES RECIVED IS 0..............Connection close requested ......  ",sProgTime);    
			free(sTake_peek);

			fGetTime(sProgTime);

			logInfo(" DATA RECV = 0 BYTES at [%s] IST",sProgTime);
			//close(iSockfd);
			return(iRecv_bytes);
		}
		logDebug1(" Received Successfully : %d",iRecv_bytes);

		memcpy(pTapHeader,sTake_peek,sizeof(struct TAP_WRAPPER));

		logDebug1(" TapHeader->Message_Len [%d] ",pTapHeader->Message_Len);
		TWIDDLE(pTapHeader->Message_Len);

		logDebug1(" TapHeader->Message_Len [%d] ",pTapHeader->Message_Len);
		iReadBytes = pTapHeader->Message_Len;

		for( ; ; )
		{
			iRecv_bytes = recv( iSockfd ,sTake_peek ,iReadBytes, MSG_PEEK );
			if ( iRecv_bytes < iReadBytes )
			{
				if (iCount_to_error <= 100 )
				{
					iCount_to_error ++ ;
					logInfo("Sleeping for 1S");
					sleep(1);
					continue;
				}
				else
				{
					logInfo("Full Packet Not Received ...");
					iReadBytes = ERROR ;
					free(sTake_peek);
					close(iSockfd);
					return(iReadBytes) ;
				}
			}
			else
			{
				break;
			}
		}
		break;    
	}
	iRecv_bytes = recv(iSockfd , sReply , iReadBytes , 0);   

	fGetTime(sProgTime);
	logInfo(" DATA RECV at [%s] IST",sProgTime); 

	free(sTake_peek);
	free(sError);
	//free(pHeader);
	logTimestamp("Exit : [tcpRecv]");
	return(iRecv_bytes);
}

/****************Added By  for TAP BOX *******************************/

LONG32	tcpRecv_Inv( LONG32 iSockfd, CHAR* sReply ,LONG32 * iFlag)
{
	logTimestamp("Entry : [tcpRecv_Inv]");

	LONG32	iRecv_bytes,
		iCount_to_error=1,
		iReadBytes = 0;
	//		temp_size;

	//	unsigned char	digest[16];

	struct  NNF_HEADER	*pHeader;
	//	struct  TAP_WRAPPER   	*tap_peek;    
	CHAR 	*sTake_peek,			/* variable to just peek LONG32o the socket for data arrival */
		*sError;
	CHAR 	sProgTime[40];

	memset(sProgTime,'\0',40);
	LONG32	i;
	LONG32 	iMsgCode,iLen,iErrCode;

	iReadBytes = 1024;

	memset(sReply,NULL,NSE_PACKET_SIZE);
	logDebug2(" Recv iSockfd :%d:",iSockfd);		

	iRecv_bytes = recv( iSockfd, sReply , iReadBytes ,MSG_PEEK );	/* copy data from socket without erasing from socket */

	fGetTime(sProgTime);
	logDebug2(" DATA RECV_INV at [%s] IST with iRecv_bytes = [%d]",sProgTime,iRecv_bytes);

	if (iRecv_bytes < 0)
	{
		logDebug2(" Received byte is < 0");
		*iFlag = FALSE;

		fGetTime(sProgTime);

		logDebug2(" DATA RECV < 0 BYTES at [%s] IST",sProgTime);
		logInfo("------------------- closing socket [%d] ",iSockfd);
		close(iSockfd);
		return(ERROR);
	}

	if (iRecv_bytes == 0)
	{
		logInfo("tcpComm.c Connection close requested ..  ");		/* when 0 is recieved it signifies connection close */
		*iFlag = FALSE;

		fGetTime(sProgTime);

		logInfo(" DATA RECV = 0 BYTES at [%s] IST",sProgTime);
		logInfo("------------------- closing socket [%d] ",iSockfd);
		close(iSockfd);
		return(iRecv_bytes);			
	}
	logInfo("tcpRecv_Inv:: Received Successfully : %d",iRecv_bytes);
	TWIDDLE(((struct INVITATION_PACKET *)sReply)->pHeader.iMsgLength);
	TWIDDLE(((struct INVITATION_PACKET *)sReply)->pHeader.iMsgCode);
	iLen = ((struct INVITATION_PACKET *)sReply)->pHeader.iMsgLength;
	iMsgCode = ((struct INVITATION_PACKET *)sReply)->pHeader.iMsgCode;
	logInfo(" MsgCode = [%d]",iMsgCode);

	logInfo(" len    = [%d]",iLen);

	if(iMsgCode == TC_EQU_NSE_INVITATION_REQ)
	{
		*iFlag = TRUE;
	}
	else
	{
		*iFlag = FALSE;
	}
	logTimestamp("Exit : [tcpRecv_Inv]");

	return(iRecv_bytes);
}
/******************************************************/
/******void Twiddle(void *pVoid,short iLen)
  {	
//	logTimestamp("Entry : [Twiddle]");

CHAR  * pStr = (CHAR  *)pVoid;
CHAR    cTemp[ 500 ];
short   i;

memcpy (cTemp,
pStr,
iLen);

for (i = 0; i < iLen; i++)
{
 *(pStr + i) = cTemp[iLen - i - 1];
 }

 }******/
/*****************************/

void	Sleep ( LONG32 iTimeSleep )						/* This function accepts parameters in milliseconds */
{
	logTimestamp("Entry :[Sleep]");
	poll((struct pollfd **) NULL, 0,iTimeSleep  );

	logTimestamp("exit : [Sleep]");
}

BOOL 	tcpServe(LONG32 iPort)
{
	logTimestamp("Entry : [tcpServe]");

	struct	sockaddr_in	pServaddr,pCliaddr;
	LONG32	iSockfd,
		iconnfd,
		iDiditconnect,
		iSleeptime=1,
		iCount_to_error=1,
		iClen,
		iFlag = 1;
	CHAR 	*sError;

	sError = (CHAR *)malloc(sizeof(CHAR)*SIZE); 	

	do
	{
		if( (iSockfd = socket( AF_INET, SOCK_STREAM, 0 )) < 0 )
		{
			memset(sError,NULL,SIZE);
			strcpy(sError,strerror(errno));
			sleep(iSleeptime);
		}

		if ( iSockfd  > 0 )
		{
			memset(&pServaddr,0,sizeof(pServaddr));
			pServaddr.sin_family = AF_INET;
			pServaddr.sin_addr.s_addr = htonl(INADDR_ANY);
			pServaddr.sin_port=htons(iPort);	

			if( setsockopt( iSockfd , SOL_SOCKET , SO_REUSEADDR , ( CHAR * )&iFlag , sizeof( iFlag ) ) < 0 ) /* socket options setting */
			{
				memset(sError,NULL,SIZE);
				strcpy(sError,strerror(errno));
				return(ERROR);
			}

			if ( bind( iSockfd, (struct sockaddr *)&pServaddr, sizeof(pServaddr) ) < 0)		     /*  socket binding */	
			{
				memset(sError,NULL,SIZE);
				strcpy(sError,strerror(errno));
				return(ERROR);
			}

			if ( listen(iSockfd,LISTENQ) < 0 )							    /* socket listening */
			{
				memset(sError,NULL,SIZE);
				strcpy(sError,strerror(errno));
				return(ERROR);
			}

			iClen = sizeof( pCliaddr );

			if( (iconnfd = accept( iSockfd, (struct sockaddr *)&pCliaddr , &iClen )) < 0)       /* wait for a connect from remote host */
			{
				memset(sError,NULL,SIZE);
				strcpy(sError,strerror(errno));
				return(ERROR);
			}

		}
		iSleeptime++;	
		iCount_to_error++;

	}while( (iSockfd < 0) && ( iCount_to_error < 100) );

	logTimestamp("Exit : [tcpServe]");

	return (iconnfd);									/* returns the connection descriptor */
}
/*************Commenting as already defined in EquNseConTAP.pc************
  fGetTime(CHAR *sProgTime)
  {
  CHAR locTime[40]    ;
  time_t currenttime  ;
  LONG32 yr = 1900       ;
  struct tm tm        ;
  memset(locTime,'\0',40)                             ;
  currenttime = time(0)                                   ;       
  tm = *localtime(&currenttime)                           ;
  yr = yr + tm.tm_year                                    ;
  slogDebug3(locTime,"TIME : [%d:%d:%d] DATE : [%d-%d-%d]",tm.tm_hour,tm.tm_min,tm.tm_sec,tm.tm_mday, tm.tm_mon, yr);
  memcpy(sProgTime,&locTime,40)                            ;
  }
 *************END:Commenting as already defined in EquNseConTAP.pc************/

LONG32  tcpDirConnection(CHAR *sDCip,LONG32 iDCport)
{
        logTimestamp("Entry : [tcpConnect]");
        logInfo("Hey in tcpConnect ");
        struct  sockaddr_in     pServaddr;

        LONG32  iSockfd,                                /* this variable defines the socket connection descriptor */
                iDiditConnect,                          /* variable used as iFlag for testing connection */
                iSleepTime=1,                           /* incremental sleep time variable */
                iCount_to_error=1;                      /* this counter when exceeds 99 the function terminates */
        CHAR    *sError;
        LONG32  iCounterForConnect=0;
        sError = (CHAR *)malloc(sizeof(CHAR)*SIZE);
        logInfo(".c file here11");

        do
        {
                if( (iSockfd = socket( PF_INET, SOCK_STREAM, 0 )) < 0 )
                {
                        logDebug1("iSockfd = %d",iSockfd);
                        memset(sError,NULL,SIZE);
                        strcpy(sError,strerror(errno));
                        sleep(iSleepTime);
                }
                logDebug1("iSockfd111111111 = %d", iSockfd);

                if ( iSockfd > 0 )
                {
                        logInfo("Inside loop sopckfd > 0 ");
                        memset(&pServaddr,0,sizeof(pServaddr));
                        logInfo("Direction Connection IP PORT :%s: :%d:",sDCip,iDCport);
                        pServaddr.sin_family = AF_INET;
			pServaddr.sin_addr.s_addr = inet_addr(sDCip);
                        pServaddr.sin_port=htons(iDCport);	

			do
                        {
                                iDiditConnect = connect( iSockfd, (struct sockaddr *) &pServaddr, sizeof(pServaddr) );
                                perror(" Reason If Connect failed is : ");

                                if (iDiditConnect < 0)
                                {
                                        iCounterForConnect++;
                                        logInfo(" FAILED.................");
					// Printing for monitoring purpose @NItish
					logTimestamp(":%s: TRYING TO CONNNECT BOX SIGN PRIMARY IP :%s: PORT :%d:",KEY_WORD_MONITORING,sDCip,iDCport);
                                        memset(sError,NULL,SIZE);
                                        strcpy(sError,strerror(errno));
                                        logFatal("tcpComm.c %s",sError);
                                        sleep(iSleepTime);
                                        iSleepTime++;
                                        close(iSockfd);                                         /* closing socket before termination */

                                        if( (iSockfd = socket( AF_INET, SOCK_STREAM, 0 )) < 0 )
                                                logInfo(" Socket failed in StcpComm ");
                                        {
                                                memset(sError,NULL,SIZE);
                                                strcpy(sError,strerror(errno));
                                                logFatal("tcpComm.c %s",sError);
                                                sleep(iSleepTime);
                                        }
                                }

                                if(iCounterForConnect == 3 )
                                {
                                        close(iSockfd);                      /* closing socket before termination */
                                        break;
                                }
                        }

                        while( iDiditConnect < 0 );

                }
                iSleepTime++;
                iCount_to_error++;
        }
        while(( iSockfd < 0 ) && (iCounterForConnect == 3));
        free(sError);

	if( iCounterForConnect == 3)
        {
                logInfo("Returned Failover Signal Successfully........");
                return (-1);
        }
        logInfo("Returned Sockfd Successfully........:%d:",iSockfd);
	// Printing for monitoring purpose @NItish	
	logTimestamp(":%s: CONNNECT BOX SIGN IS SUCCESS WITH IP :%s: PORT :%d:",KEY_WORD_MONITORING,sDCip,iDCport);
        logTimestamp("Exit : [fTcpConnect]");
        return (iSockfd);

}
