#include <stdio.h>
#include <string.h>
#include "Common.h"
#include "Comm_def.h"
#include <openssl/crypto.h>
#include <openssl/rand.h>
#include <openssl/des.h>
#include <openssl/rsa.h>

#define     TWIDDLE(A)      UtlTwiddle ((char *) &A, sizeof(A)) 

void Rotate(char *chr, int cRotateBy)
{
	unsigned short iTemp = 0, iCarry = 0;

	memcpy(&iTemp, chr, 1);

#ifdef LITTLEENDIAN
	printf("LITTLEENDIAN SERVER");
#else
	TWIDDLE(iTemp);
#endif

	iTemp <<= cRotateBy;
	iCarry = iTemp & 0xFF00;
	iCarry >>= 8;
	iTemp |= iCarry;
#ifdef LITTLEENDIAN
	printf("LITTLEENDIAN SERVER");
#else
	TWIDDLE(iTemp);
#endif
	memcpy(chr, &iTemp, 1);

}
int UtlTwiddle(void *pVoid,int iLen)
{
	/*******************
	  printf("\n\t\t\t Hi I am In TWIDDLE OF ConnPwdUtl.c");
	  char  * pStr = (char  *)pVoid;
	  char    cTemp[ 500 ];
	  short   i;
	  memcpy (cTemp,
	  pStr,
	  iLen);

	  for (i = 0; i < iLen; i++)
	  {
	 *(pStr + i) = cTemp[iLen - i - 1];
	 }
	 *******************/
}
int f(struct DESSTRUCT *DesStruct, unsigned char *sObf, int iDirection)
{
	int iRetVal = 0, iCnt;
	int RotIndex[OBFS_LEN];
	int ctr     =       0;

	RotIndex[0]  = 3;
	RotIndex[1]  = 7;
	RotIndex[2]  = 1;
	RotIndex[3]  = 5;
	RotIndex[4]  = 2;
	RotIndex[5]  = 6;
	RotIndex[6]  = 2;
	RotIndex[7]  = 4;
	RotIndex[8]  = 1;
	RotIndex[9]  = 3;
	RotIndex[10] = 7;
	RotIndex[11] = 4;
	RotIndex[12] = 5;

	switch(iDirection)
	{
		case 0:
			memcpy(sObf, DesStruct, 24);
			memcpy(sObf + 24, DesStruct->CipherText, 16);

			for (iCnt = 0; iCnt < OBFS_LEN; iCnt++)
				Rotate(sObf + iCnt, RotIndex[iCnt % INDEX_LEN]);
			break;
		case 1:
			for (iCnt = 0; iCnt < OBFS_LEN; iCnt++)
				Rotate(sObf + iCnt, 8 - RotIndex[iCnt % INDEX_LEN]);

			memcpy(DesStruct, sObf , 24);
			memcpy(DesStruct->CipherText, sObf + 24, 16);
			break;
		default:
			iRetVal = 1;
	};

	printf("\n\t Value being returned for 'f' function.............. 0 if successfull [%d]",iRetVal);
	return iRetVal;
}



/**************************************************************************************/
/*            New   Functionalities  added  by  Kshitij  for  Citigroup
	      Date  05/05/06, Friday
	      Function Name     : BinToHex
	      Input  Parameters : 1. Input Binary Value as character array
	      2. Return Value in the form of Hex character array
	      3. Length of the input binary value array
	      Return values : 0 - if successfull
	      1 - if any error in creating Hex Value

	      Prototype for the function is :
	      if ((BinToHex(sBin, sHex, iLeni)) == 0)
 ***************************************************************************************/

int BinToHex(char *pBin, char *pHex, int iBinLen)
{
	int iCnt;
	char sTemp[3];
	unsigned char bTemp;
	int iRet=0;

	for (iCnt = 0; iCnt < iBinLen; iCnt++)
	{
		bTemp = *(pBin + iCnt);
		sprintf(sTemp, "%02X", bTemp);
		memcpy(pHex + 2*iCnt, sTemp, 2);
	}
	return iRet;
}

/**************************************************************************************/
/*            New   Functionalities  added  by  Kshitij  for  Citigroup
	      Date  05/05/06, Friday
	      Function Name     : HexToBin

	      Input  Parameters : 1. Input Value in the form of Hex character array
	      2. Return Value in the form of Binary character array
	      3. Length of the input Hex value array

	      Return values : 0 - if successfull
	      1 - if any error in creating Binary Value

	      Prototype for the function is :
	      if ((HexToBin(sHex,sBin,iLen)) == 0)
 ***************************************************************************************/

int HexToBin(char *pHex, char *pBin, int iHexLen)
{
	int iRet = 0, iCnt, iChar, iFound;
	char sTemp[3], sTrial[3];

	printf("\n\n###################  Inside HexToBin ##############\n");
	printf("\n Value recieved inside function from DB is \n :: [%s] :: Len [%d]",pHex,strlen(pHex));

	for (iCnt = 0; iCnt < iHexLen; iCnt += 2)
	{
		memset(sTemp, '\0', 3);
		memcpy(sTemp, pHex + iCnt, 2);
		iFound = 0;

		for (iChar = 0; iChar < 256; iChar++)
		{
			memset(sTrial, '\0', 3);
			sprintf(sTrial, "%02X", iChar);
			if (strcmp(sTemp, sTrial) == 0)
			{
				*(pBin + iCnt/2) = iChar;
				iFound = 1;
				break;
			}
		}
		if (iFound == 0)
		{
			iRet = 1;
			break;
		}
	}
	return iRet;
}


