//#include "EqufalloverN.h"
//#include "IntBcastStructs.h"
#include <sys/socket.h>
#include "IPCS.h"
#include <time.h>
#include "NNFStruct.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>


//static 	LONG32	tHostPCTimeDiff ;

extern	DBConNNF;
extern 	CHAR sKey[DB_KEY_LEN];

//CHAR *	GcPlainKey; 
LONG32 	iSockfdBroad;
extern	LONG32 iGlobGroupId;	
extern	LONG32 iTotalStream;
extern  LONG32 iGrSockFd;
extern  CHAR sSessionKey[NNF_SESSION_KEY_LEN];	
extern  LONG32 iTmpTradeId ;
extern  LONG32 iJiffyTime;
extern  CHAR cSignOnShowIndex;
SHORT  	fTrim( CHAR *string , SHORT iMaxLen );
BOOL 	fInsertExchDigital(SHORT iNoStreams );

BOOL 	fUpdateSignOnResponse(struct NNF_SIGNON_RESP *spSignOnResp,LONG32 iGroupId)
{
	logTimestamp("Entry : {fUpdateSignOnResponse}");

	CHAR	sLastPasswordChangeDate[DATE_STRING_LENGTH];
	CHAR    sLastMktCloseTime[DATE_STRING_LENGTH];
	CHAR	cConnectedToExch ; 
	DOUBLE64  fSeqNo;
	LONG32  iOffset_julitime;
	LONG32	iSys_julitime;
	LONG32	iNse_julitime;
	LONG32  iCtr;
	CHAR	sDateFormat[ NNF_DATE_TIME_LEN];		
	//	CHAR	sLastMktCloseTime[DATE_STRING_LENGTH];
	//	CHAR	sLastPasswordChangeDate[DATE_STRING_LENGTH];
	CHAR	sTempPassword[P_LEN]; 
	CHAR	sEncryptPassword[75]; 
	CHAR	*sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	memset(sTempPassword,'\0',P_LEN+1) ;
	memset(sEncryptPassword,'\0',P_LEN+1) ;

	logDebug2("spSignOnResp->EligibilityPerMkt.PreOpen :%d:",spSignOnResp->pEligibilityPerMkt.PreOpen);

	/***	EXEC SQL SELECT JULIDATE(SYSDATE)
INTO :iSys_julitime
FROM DUAL;****/
	if(mysql_query(DBConNNF,"SELECT julidate(now()) from dual;")!= SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConNNF);

	while((Row = mysql_fetch_row(Res)))
	{
		iSys_julitime = atoi(Row[0]);
	}
	logDebug2(" Sys_julitime :%d:",iSys_julitime);

	mysql_free_result(Res);

	iNse_julitime=spSignOnResp->pHeader.iLogTimeStamp;

	logDebug2("Sysjulitime is :%d Nsejulitime is :%d",iSys_julitime,iNse_julitime);
	iOffset_julitime = iNse_julitime-iSys_julitime;

	memcpy (&fSeqNo,spSignOnResp->sSeqNumber,8); 
	convert_seconds_to_date(spSignOnResp->iEndTime, sLastMktCloseTime);


#ifdef	DBG
	logDebug2("NOTE: The Date Format is:%s: , Len : %s", sDateFormat , sDateFormat );
	logDebug2("UpdateSignOnResponse: The end date before passing to convert_seconds_to_date :  %d ",spSignOnResp->iEndTime);	
	logDebug2("UpdateSignOnResponse: The end date : %s ",sLastMktCloseTime);	
#endif

	strcpy(sLastMktCloseTime, sLastMktCloseTime);
	convert_seconds_to_date(spSignOnResp->iLastPasswordChange, sLastPasswordChangeDate);

#ifdef	DBG
	logDebug2("UpdateSignOnResponse: The password change date is %s ",sLastPasswordChangeDate); 	 
#endif

	strcpy(sLastPasswordChangeDate, sLastPasswordChangeDate);

	for(iCtr = 0;iCtr<NSE_PASSWORD_LEN; iCtr++)
	{
		if(spSignOnResp->sPassword[iCtr] == ' ')
		{
			logDebug2("WOWW....!!!!  Found  the  blank in the  Password....@[%d]",iCtr);
			spSignOnResp->sPassword[iCtr] = '\0';
		}
	}

	strncpy(sTempPassword, spSignOnResp->sPassword,NSE_PASSWORD_LEN);
	logDebug2("Normal Password [%s]", sTempPassword); 

	fTrim(spSignOnResp->sPassword,NSE_PASSWORD_LEN);
	logDebug2("SignOnResp->Password[%s]",spSignOnResp->sPassword); 
	fTrim(spSignOnResp->sTraderName,TRADER_NAME_LEN);


	/***	 EXEC SQL EXECUTE BEGIN :sEncryptPassword := toolkit.encrypt (
	  :sTempPassword
	  );

	  END;
	  END-EXEC;
	  if (sqlca.sqlcode !=0)
	  {
	  logDebug2("\n Error in decrypting sEncryptPassword 1 is :%d:",sqlca.sqlcode);
	  exit(0);
	  }



	  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER 
	  SET
	  EAM_OLD_PASSWORD     = :sEncryptPassword,
	  EAM_NEW_PASSWORD	 = '',
	  EAM_TRADER_NAME   = :spSignOnResp->TraderName,
	  EAM_EXCH_OFFSET_TIME =:iOffset_julitime,	
	  EAM_LAST_PASSWORD_CHANGE_DATE = to_date(:sLastPasswordChangeDate,'DD-MM-YYYY HH24:MI:SS'),
	  EAM_BROKER_ID = :spSignOnResp->BrokerCode, 
	  EAM_BRANCH_ID = to_CHAR(:spSignOnResp->BranchId),   
	  EAM_LAST_MKT_CLOSE_TIME = to_date(:sLastMktCloseTime, 'DD-MM-YYYY HH24:MI:SS'),
	  / /EAM_EXCH_USER_TYPE = to_CHAR(:spSignOnResp->UserType), 
	//         EAM_EXCH_SEQUENCE_NO = decode(ltrim(rtrim(:spSignOnResp->SeqNumber)),'','0',ltrim(rtrim(:spSignOnResp->SeqNumber))),
	EAM_BROKER_STATUS = :spSignOnResp->BrokerStatus,
	EAM_LOGON_STATUS = :cConnectedToExch   
	WHERE EAM_EXM_EXCH_ID = 'NSE'  AND
	EAM_EXCH_USER_ID = to_CHAR(:spSignOnResp->UserId)
	AND
	EAM_DRV_FLAG = 'N';

#ifdef     DBG
logDebug2("\n\t UpdateSignOnResponse: The error is %d ",sqlca.sqlcode);				
#endif*****/

	logDebug2("spSignOnResp->pHeader.iErrorCode :%d:",spSignOnResp->pHeader.iErrorCode);

	if(spSignOnResp->pHeader.iErrorCode == 0)
	{
		cConnectedToExch = CONNECTED_TO_EXCH ;



		sprintf(sQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
				EAM_OLD_PASSWORD = aes_encrypt(\"%s\",\"%s\"),\
				EAM_NEW_PASSWORD = null, \
				EAM_TRADER_NAME = \"%s\",\
				EAM_EXCH_OFFSET_TIME = %d,\
				EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'), \
				EAM_BRANCH_ID = %d ,\
				EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
				EAM_BROKER_STATUS = \'%c\',\
				EAM_LOGON_STATUS = \'%c\', \
				EAM_REASON_DESC = ifNULL((select RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \'%s\' and RM_ERR_CODE = \'%d\'),'Connected'),\
				EAM_ERROR_ID = \'%d\' \
				WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
				EAM_EXCH_USER_ID = %d AND \
				EAM_SEGMENT = \'%c\' AND \
				EAM_GROUP_ID = %d;",spSignOnResp->sPassword,sKey,spSignOnResp->sTraderName,iOffset_julitime,sLastPasswordChangeDate,
				spSignOnResp->iBranchId,sLastMktCloseTime,spSignOnResp->cBrokerStatus,cConnectedToExch,NSE_EXCH,spSignOnResp->pHeader.iErrorCode,\
				spSignOnResp->pHeader.iErrorCode,NSE_EXCH,\
				spSignOnResp->iUserId,EQUITY_SEGMENT,iGroupId);
	}
	else
	{
		cConnectedToExch = EXCH_REJECT_STATUS;
		sprintf(sQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
				EAM_EXCH_OFFSET_TIME = %d,\
				EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'), \
				EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
				EAM_LOGON_STATUS = \'%c\', \
				EAM_REASON_DESC = ifNULL((select RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \'%s\' and RM_ERR_CODE = \'%d\'),'Connected'),\
				EAM_ERROR_ID = \'%d\' \
				WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
				EAM_EXCH_USER_ID = %d AND \
				EAM_SEGMENT = \'%c\' AND \
				EAM_GROUP_ID = %d;",iOffset_julitime,sLastPasswordChangeDate,
				sLastMktCloseTime,cConnectedToExch,NSE_EXCH,spSignOnResp->pHeader.iErrorCode,\
				spSignOnResp->pHeader.iErrorCode,NSE_EXCH,\
				spSignOnResp->iUserId,EQUITY_SEGMENT,iGroupId);
	}		

	logDebug2("sQuery-> :%s:",sQuery);
	/**/
	if(mysql_query(DBConNNF,sQuery) != SUCCESS)
	{
		sql_Error(DBConNNF);
		free(sQuery);	
		return ERROR;
	}
	else
	{
		logDebug2("%d rows affected ",mysql_affected_rows(DBConNNF));
		mysql_commit(DBConNNF);
		free(sQuery);	
		return TRUE;

	}
	/***/

	logTimestamp("Exit : [fUpdateSignOnResponse]");
}

/*******************************************************

  Function Name : UpdateSysInfoResp

Parameters :
NNF_SYS_INFO_RESP   *spSysInfoResp

Functionality : Updates system information response  

Return Values : True/False

Tables Accessed :
MAPPING_MASTER (select)
EXCH_MKT_MASTER (update)
EXCH_MASTER (update)
EXCH_ADMINISTRATION_MASTER (update)
TRADE_LMT_ALT_EXP_MASTER (Update)
NSE_SECURITY_MASTER (update)	  

Assumptions :
NORMAL_MARKET                            1
ODDLOT_MARKET                            2
SPOT_MARKET                              3
AUCTION_MARKET                           4
 *******************************************************/
/*****/
BOOL UpdateSysInfoResp( struct  NNF_SYS_INFO_RESP *spSysInfoResp )
{
	logTimestamp("Entry : [UpdateSysInfoResp]");

	CHAR	sUpdQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	LONG32	iTempStatus = 0;
	LONG32	i = 0;
	CHAR	sMktType[MKT_TYPE_LEN];

	for(i = 1;i<= 6;i++)
	{
		memset(sMktType,'\0',MKT_TYPE_LEN);
		//switch(spSysInfoResp->pMarketStatus.iNormal )
		logInfo("value of i :%d:",i);
		switch(i)
		{
			case INT_NL_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iNormal;
				strncpy(sMktType,MKT_TYPE_NL,MKT_TYPE_LEN);
				break;
			case INT_OL_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iOddlot;
				strncpy(sMktType,MKT_TYPE_OL,MKT_TYPE_LEN);
				break;
			case INT_SP_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iSpot;
				strncpy(sMktType,MKT_TYPE_SP,MKT_TYPE_LEN);
				break;
			case INT_AU_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iAuction;
				strncpy(sMktType,MKT_TYPE_AU,MKT_TYPE_LEN);
				break;
			case INT_AU1_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iCallAuction1;
				strncpy(sMktType,MKT_TYPE_CAU_1,MKT_TYPE_LEN);
				break;
			case INT_AU2_MKT_TYPE:
				iTempStatus = spSysInfoResp->pMarketStatus.iCallAuction2;
				strncpy(sMktType,MKT_TYPE_CAU_2,MKT_TYPE_LEN);
				break;
		}

		switch(iTempStatus)
		{
			case EXCH_MKT_PREOPEN:
				iTempStatus = MKT_PREOPEN;
				break;
			case EXCH_MKT_OPEN:
				iTempStatus = MKT_OPEN;
				break;
			case EXCH_MKT_CLOSE:
				iTempStatus = MKT_CLOSE;
				break;
			case EXCH_MKT_PREOPENEND:
				iTempStatus = MKT_CLOSE;
				break;
		};			


		sprintf(sUpdQry,"UPDATE  EXCH_MKT_MASTER SET EMM_STATUS = %d  WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_EXCH_SEG =\'%c\' AND EMM_MKT_TYPE = \"%s\" ;",iTempStatus,NSE_EXCH,EQUITY_SEGMENT,sMktType);

		logDebug3("sUpdQry :%s:",sUpdQry);

		if(mysql_query(DBConNNF,sUpdQry) != SUCCESS)	
		{
			logFatal("Update Error ");
			sql_Error(DBConNNF);
		}



	}
	return TRUE;
	logTimestamp("Exit : [UpdateSysInfoResp]");

}
/*****/

/***** 
  BOOL HandleSQL(LONG32 code, CHAR *module,CHAR *file,CHAR *table)
  {

  CHAR *error;
  CHAR *add;

  LONG32 result,iQid;

  error = (CHAR *)malloc(ERROR_STRING_LEN);
  add = (CHAR *)malloc(6);

  memset(error,NULL,ERROR_STRING_LEN);

  strcpy(error,"SQL ERROR: ");
  slogDebug2(add,"%d",code);
  strcat(error,add);
  strcat(error,file);
  strcat(error,module);
  strcat(error,table);

  logDebug2("\nNOTE::Inside HandleSQL: MessageLog Q is not opened , Error: %d", code );

  free(error);
  free(add);
  return TRUE;

  if ((code == 0) || (code == 8224))
  return TRUE;
  else
  return FALSE;
  }*////
BOOL	sendsignon(CHAR *sSendnnf, LONG32 iGroupid)
{
	logTimestamp("Entry : [sendsignon]");

	struct	NNF_SIGNON_REQ	*pSign;
	CHAR	*sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	pSign = (struct NNF_SIGNON_REQ *)malloc(sizeof(struct NNF_SIGNON_REQ));

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	memset((CHAR*)pSign,' ',sizeof(struct NNF_SIGNON_REQ));
	memcpy(pSign,sSendnnf,sizeof(struct NNF_SIGNON_REQ));

	pSign->pHeader.iMsgCode = TC_EQU_NSE_SIGNON_REQ;
	pSign->pHeader.iLogTimeStamp = 0 ;
	memset(pSign->pHeader.sAlphaSplit,' ',2);
	memcpy(pSign->pHeader.sAlphaSplit,"NT",2);

	pSign->pHeader.iErrorCode = 0 ;
	memset(pSign->pHeader.sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
        memset(pSign->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
        memset(pSign->pHeader.sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
        memset(pSign->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
        memset(pSign->pHeader.sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
        memset(pSign->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pSign->pHeader.iMsgLength = sizeof(struct NNF_SIGNON_REQ);

	logDebug2("sizeof(struct NNF_SIGNON_REQ) :%d:",sizeof(struct NNF_SIGNON_REQ));

	memset(pSign->sNewPassword,'\0',NSE_PASSWORD_LEN);
	memset(pSign->sNewPassword,' ',NSE_PASSWORD_LEN);
	memset(pSign->sTraderName,'\0',26);

	sprintf(sQuery,"SELECT   EAM_EXCH_USER_ID,\
			aes_decrypt(EAM_OLD_PASSWORD,\"%s\"),\
			IFNULL(aes_decrypt(EAM_NEW_PASSWORD,\'%s\'),'1') EAM_NEW_PASSWORD,\
			EAM_BROKER_ID,\
			EAM_VERSION_NO,\
			EAM_WORKSTATION_ADDRESS,\
			EAM_TRADER_NAME,\
			EAM_BRANCH_ID\
			FROM EXCH_ADMINISTRATION_MASTER \
			WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT = \'%c\'; ",sKey,sKey,iGroupid,NSE_EXCH,EQUITY_SEGMENT);

	logDebug2("Printing sQuery :%s: ",sQuery);
	if (mysql_query(DBConNNF, sQuery) != SUCCESS) 
	{
		sql_Error(DBConNNF);
		return ERROR;
	}

	Res = mysql_store_result(DBConNNF);



	if((Row = mysql_fetch_row(Res)))
	{
		//pSign->pHeader.iTraderID = atoi(Row[3]) ;
		pSign->pHeader.iTraderID = atoi(Row[0]);
		pSign->iUserId = atoi(Row[0]);
		memset(pSign->sReserved5,' ',8);	
		strncpy(pSign->sPassword,Row[1],NSE_PASSWORD_LEN);
		logDebug2("Debug by Nitish :%s:",Row[2]);
		memset(pSign->sReserved6,' ',8);	
		if(Row[2][0] != '1')
		{
			logDebug2("NOT NULL");
			strncpy(pSign->sNewPassword,Row[2],NSE_PASSWORD_LEN);
		}
		else
		{
			logDebug2("NULL");
			memset(pSign->sNewPassword,' ',NSE_PASSWORD_LEN);
		}
		logDebug2("Debug by Nitish :%s:",pSign->sNewPassword);	
		memset(pSign->sTraderName,' ',26);
		strncpy(pSign->sTraderName,Row[6],26);
		pSign->iLastPasswdChangetime = 0;
		memset(pSign->sBrokerCode,' ',BROKER_CODE_LENGTH);
		strncpy(pSign->sBrokerCode,Row[3],BROKER_CODE_LENGTH);
		pSign->iBranchID= atoi(Row[7]);
		pSign->iVersionNumber = atoi(Row[4]);
		memset(pSign->sReserved2,' ',16);	
		pSign->iUserType = 0;
		pSign->fSequenceNum= 0.00;

		strncpy(pSign->sWorkstationAddr,Row[5],WORK_STATION_ADDR_LEN);
		pSign->cBrokerStat= ' ';
		//pSign->cShowIndex = 'T';
		pSign->cShowIndex = cSignOnShowIndex;
		memset(pSign->sReserved3,' ',2);	
		strncpy(pSign->sBrokerName,Row[6],BROKER_NAME_LEN);
		memset(pSign->sReserved7,' ',16);	
		memset(pSign->sReserved8,' ',16);	
		memset(pSign->sReserved9,' ',16);	


	}
	free(sQuery);

	logDebug2("Before Twiddle");
	logDebug2("After sendSignon TIMESTAMP       :%d: ",pSign->pHeader.iLogTimeStamp);
	logDebug2("After sendSignon iMsgCode	    :%d: ",pSign->pHeader.iMsgCode);
	logDebug2("After sendSignon ERROR CODE      :%d: ",pSign->pHeader.iErrorCode);
	logDebug2("After sendSignon MESG LENGTH     :%d: ",pSign->pHeader.iMsgLength);
	logDebug2("After sendSignon ALPHA SPLIt     :%s: ",pSign->pHeader.sAlphaSplit );
	logDebug2("After sendSignon TraderID        :%d: ",pSign->pHeader.iTraderID);
	logDebug2("After sendSignon USER Id         :%d: ",pSign->iUserId);
	logDebug2("After sendSignon Password        :%s: ",pSign->sPassword);
	logDebug2("After sendSignon NewPassword     :%s: ",pSign->sNewPassword);
	logDebug2("After sendSignon TRADER NAME     :%s: ",pSign->sTraderName);
	logDebug2("After sendSignon LastPasswdChangetime  :%d: ",pSign->iLastPasswdChangetime);
	logDebug2("After sendSignon sBrokerCode     :%s: ",pSign->sBrokerCode);
	logDebug2("After sendSignon iBranchID	    :%d: ",pSign->iBranchID);
	logDebug2("After sendSignon VERSION NUMBER  :%d: ",pSign->iVersionNumber);
	logDebug2("After sendSignon iUserType       :%d: ",pSign->iUserType);
	logDebug2("After sendSignon fSequenceNum    :%f: ",pSign->fSequenceNum);
	logDebug2("After sendSignon sWorkstationAddr:%s: ",pSign->sWorkstationAddr);
	logDebug2("After sendSignon cBrokerStat	    :%c: ",pSign->cBrokerStat);
	logDebug2("After sendSignon cShowIndex      :%c: ",pSign->cShowIndex);
	logDebug2("After sendSignon BROKER NAME     :%s: ",pSign->sBrokerName );


	TWIDDLE(pSign->pHeader.iLogTimeStamp);
	TWIDDLE(pSign->pHeader.iMsgCode);
	TWIDDLE(pSign->pHeader.iTraderID);
	TWIDDLE(pSign->pHeader.iErrorCode);
	TWIDDLE(pSign->pHeader.iMsgLength); 
	TWIDDLE(pSign->iUserId);
	TWIDDLE(pSign->iLastPasswdChangetime);
	TWIDDLE(pSign->iBranchID);
	TWIDDLE(pSign->iVersionNumber);
	TWIDDLE(pSign->iUserType);
	TWIDDLE(pSign->fSequenceNum);


	logDebug2("After Twiddle");
	logDebug2("After sendSignon TIMESTAMP       :%d: ",pSign->pHeader.iLogTimeStamp);
        logDebug2("After sendSignon iMsgCode        :%d: ",pSign->pHeader.iMsgCode);
        logDebug2("After sendSignon ERROR CODE      :%d: ",pSign->pHeader.iErrorCode);
        logDebug2("After sendSignon MESG LENGTH     :%d: ",pSign->pHeader.iMsgLength);
        logDebug2("After sendSignon ALPHA SPLIt     :%s: ",pSign->pHeader.sAlphaSplit );
        logDebug2("After sendSignon TraderID        :%d: ",pSign->pHeader.iTraderID);
        logDebug2("After sendSignon USER Id         :%d: ",pSign->iUserId);
        logDebug2("After sendSignon Password        :%s: ",pSign->sPassword);
        logDebug2("After sendSignon NewPassword     :%s: ",pSign->sNewPassword);
        logDebug2("After sendSignon TRADER NAME     :%s: ",pSign->sTraderName);
        logDebug2("After sendSignon LastPasswdChangetime  :%d: ",pSign->iLastPasswdChangetime);
        logDebug2("After sendSignon sBrokerCode     :%s: ",pSign->sBrokerCode);
        logDebug2("After sendSignon iBranchID       :%d: ",pSign->iBranchID);
        logDebug2("After sendSignon VERSION NUMBER  :%d: ",pSign->iVersionNumber);
        logDebug2("After sendSignon iUserType       :%d: ",pSign->iUserType);
        logDebug2("After sendSignon fSequenceNum    :%f: ",pSign->fSequenceNum);
        logDebug2("After sendSignon sWorkstationAddr:%s: ",pSign->sWorkstationAddr);
        logDebug2("After sendSignon cBrokerStat     :%c: ",pSign->cBrokerStat);
        logDebug2("After sendSignon cShowIndex      :%c: ",pSign->cShowIndex);
        logDebug2("After sendSignon BROKER NAME     :%s: ",pSign->sBrokerName );

	memcpy(sSendnnf,pSign,sizeof(struct NNF_SIGNON_REQ));	

	free(pSign);
	logTimestamp("Exit : [sendsignon]");
	return TRUE;
}

BOOL	fRecvsignon ( CHAR *sTemp2 ,LONG32 iGroupId )
{
	logTimestamp("Entry : [fRecvsignon]");

	LONG32	iDatasent;

	logDebug1("sTimeStamp1 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->pHeader.sTimeStamp1);
	logDebug1("sTimeStamp2 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->pHeader.sTimeStamp2);
	logDebug1("sTimeStamp3 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->pHeader.sTimeStamp3);
	logDebug1("sSeqNumber 	:%s:",((struct NNF_SIGNON_RESP *)sTemp2)->sSeqNumber);

	struct 	NNF_SIGNON_RESP	*pRecv;

	pRecv = (struct NNF_SIGNON_RESP *)malloc(sizeof(struct NNF_SIGNON_RESP));
	memcpy(pRecv,sTemp2,sizeof(struct NNF_SIGNON_RESP));

	TWIDDLE(pRecv->iUserId);
	TWIDDLE(pRecv->iLastPasswordChange);
	TWIDDLE(pRecv->iBranchId);
	TWIDDLE(pRecv->iEndTime);
	TWIDDLE(pRecv->iUserType);

	TWIDDLE(pRecv->pHeader.iLogTimeStamp);
	TWIDDLE(pRecv->pHeader.iMsgCode);
	TWIDDLE(pRecv->pHeader.iErrorCode);
	TWIDDLE(pRecv->pHeader.iMsgLength);
	/**
	  TWIDDLE(pRecv->pHeader.sTimeStamp2);
	  TWIDDLE(pRecv->pHeader.sTimeStamp3);
	 **/

#ifdef     DBG
	logDebug2("RecvSignon PASSWORD 			:%s ",pRecv->sPassword);
	logDebug2("RecvSignon NEW PASSWORD 		:%s ",pRecv->sNewPassword);
	logDebug2("RecvSignon RESPONSE TRANSCODE 	:%d ",pRecv->pHeader.iMsgCode);
	logDebug2("RecvSignon user type sent 		:%d ",pRecv->iUserType);
	logDebug2("RecvSignon broker status 		:%c ",pRecv->cBrokerStatus);
	logDebug2("RecvSignon LastMktCloseTime 		:%ld",pRecv->iEndTime);
	logDebug2("RecvSignon LastPaswdchgdate 		:%ld",pRecv->iLastPasswordChange);
	logDebug2("RecvSignon Seq Number 		:%s ",pRecv->sSeqNumber);
	logDebug2("RecvSignon user id 			:%d ",pRecv->iUserId);
	logDebug2("RecvSignon Branch id 		:%d ",pRecv->iBranchId);
	logDebug2("RecvSignon End time 			:%ld",pRecv->iEndTime);
	logDebug2("RecvSignon TraderName 		:%s ",pRecv->sTraderName);
	logDebug2("RecvSignon LastPaswdchgdate 		:%ld",pRecv->iLastPasswordChange);
	logDebug2("RecvSignon BrokerName          	:%s ",pRecv->sBrokerName);
	logDebug2("RecvSignon RESPONSE sTimeStamp1	:%s: ",pRecv->pHeader.sTimeStamp1);
	logDebug2("RecvSignon RESPONSE sTimeStamp2	:%s: ",pRecv->pHeader.sTimeStamp2);
	logDebug2("RecvSignon RESPONSE sTimeStamp3	:%s: ",pRecv->pHeader.sTimeStamp3);
#endif
	/**	
	  if(pRecv->pHeader.iErrorCode == 0)
	  {
	  iDatasent = fUpdateSignOnResponse(pRecv);
	  }
	 ***/
	iDatasent = fUpdateSignOnResponse(pRecv,iGroupId);
	free(pRecv);

	if ( iDatasent == FALSE )			
	{					
#ifdef     DBG					
		logDebug2("Error in writing to Database ");
#endif
		return(ERROR);	
	}	
	else
	{	
#ifdef     DBG
		logDebug2("Success ");
#endif
		return TRUE;
	}	
	logTimestamp("Exit : [fRecvsignon]");

}


BOOL	PLogOnR(NNF_SIGNON_REQ *pSignOn, LONG32 iGroupid)
{
	logTimestamp("Entry : [PLogOnR]");

	CHAR	*cFilename = "proc_progN.pc";
	LONG32  iCtr;

	//CHAR	*SelectQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//	MYSQL_RES               *Res;
	//        MYSQL_ROW               Row;

	CHAR	*sNewPassword; 
	CHAR  	*sPassword; 
	CHAR  	*sBrokerCode;
	CHAR  	*sWorkstationAddr;
	CHAR  	*sBrokerName;

	sNewPassword= malloc(sizeof(CHAR) * 40);
	sPassword= malloc(sizeof(CHAR) * 40);
	sBrokerCode=malloc(sizeof(CHAR) * BROKER_CODE_LENGTH);
	sWorkstationAddr= malloc(sizeof(CHAR) * WORK_STATION_ADDR_LEN);
	sBrokerName= malloc(sizeof(CHAR) * BROKER_NAME_LEN);

	memset(sPassword,'\0',40+1);
	memset(sNewPassword,'\0',40+1);
	memset(sBrokerCode,'\0',BROKER_CODE_LENGTH );
	memset(sWorkstationAddr,'\0' ,WORK_STATION_ADDR_LEN);
	memset(sBrokerName,'\0',BROKER_NAME_LEN);


	logDebug2("******printing null of temp********");
	logDebug2("NewPassword[%s] ",sNewPassword);
	logDebug2("Password[%s]",sPassword);
	logDebug2("BrokerCode[%s]",sBrokerCode);
	logDebug2("WorkstationAddr[%s] ",sWorkstationAddr);
	logDebug2("BrokerName[%s]",sBrokerName);

	memset(sPassword,' ',40);
	memset(sNewPassword,' ',40);
	memset(sBrokerCode,' ',BROKER_CODE_LENGTH );
	memset(sWorkstationAddr,' ' ,WORK_STATION_ADDR_LEN);
	memset(sBrokerName,' ',BROKER_NAME_LEN);

	logDebug2("******printing space of temp********");
	logDebug2("NewPassword[%s] ",sNewPassword);
	logDebug2("Password[%s]",sPassword);
	logDebug2("BrokerCode[%s]",sBrokerCode);
	logDebug2("WorkstationAddr[%s] ",sWorkstationAddr);
	logDebug2("BrokerName[%s]",sBrokerName);

	pSignOn->pHeader.iTraderID = 0 ;
	pSignOn->pHeader.iLogTimeStamp = 0 ;
	pSignOn->pHeader.iMsgCode = TC_EQU_NSE_SIGNON_REQ;
	pSignOn->pHeader.iErrorCode = 0 ;

	memset(pSignOn->pHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);
	memset(pSignOn->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pSignOn->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pSignOn->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	memset(pSignOn->sPassword,' ',NSE_PASSWORD_LEN);
	memset(pSignOn->sNewPassword,' ',NSE_PASSWORD_LEN);
	memset(pSignOn->sBrokerCode,' ',BROKER_CODE_LENGTH);
	memset(pSignOn->sWorkstationAddr,' ',WORK_STATION_ADDR_LEN);
	memset(pSignOn->sBrokerName,' ',BROKER_NAME_LEN);

	pSignOn->pHeader.iMsgLength = sizeof(struct NNF_SIGNON_REQ);

	logDebug2("**********MEMSET NNF_SIGNON_REQ WITH SAPCE");
	logDebug2("SignOn->sHeader.AlphaSplit [%s]",pSignOn->pHeader.sAlphaSplit);
	logDebug2("SignOn->sHeader.TimeStamp1 [%s]",pSignOn->pHeader.sTimeStamp1);
	logDebug2("SignOn->sHeader.TimeStamp2 [%s]",pSignOn->pHeader.sTimeStamp2);
	logDebug2("SignOn->sHeader.TimeStamp3 [%s]",pSignOn->pHeader.sTimeStamp3);
	logDebug2("SignOn->Password [%s]",pSignOn->sPassword);
	logDebug2("SignOn->NewPassword[%s]",pSignOn->sNewPassword);
	logDebug2("SignOn->BrokerCode[%s]",pSignOn->sBrokerCode);
	logDebug2("SignOn->WorkstationAddr [%s]",pSignOn->sWorkstationAddr);
	logDebug2("SignOn->BrokerName [%s]",pSignOn->sBrokerName);
	logDebug2("********************************************");

	memcpy( pSignOn->pHeader.sAlphaSplit,"NT",2);

	logDebug2("Group Id in PLogOnR : %d",iGroupid);

	/******
	  slogDebug2(SelectQry,"SELECT EAM_EXCH_USER_ID,EAM_OLD_PASSWORD,EAM_NEW_PASSWORD,EAM_BROKER_ID,EAM_VERSION_NO,EAM_WORKSTATION_ADDRESS,EAM_TRADER_NAME FROM EXCH_ADMINISTRATION_MASTER WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"NSE\" AND EAM_DRV_FLAG=\'N\' ",iGroupid);	

	  logDebug2("\n%s\n",SelectQry);

	  if (mysql_query(DBConNNF,SelectQry ) != SUCCESS) {
	  sql_Error(DBConNNF);
	  return ERROR;
	  }

	  Res = mysql_store_result(DBConNNF);

	  free(SelectQry);

	  if((Row = mysql_fetch_row(Res)))
	  {
	  logDebug2("\n Row[0] %d\n",atoi(Row[0]));
	  logDebug2("\n Row[1] %s\n",Row[1]);
	  if(Row[2]!=NULL)
	  logDebug2("\n Row[2] %s\n",Row[2]);
	  logDebug2("\n Row[3] %s\n",Row[3]);
	  logDebug2("\n Row[4] %d\n",atoi(Row[4]));
	  logDebug2("\n Row[5] %s\n",Row[5]);
	  logDebug2("\n Row[6] %s\n",Row[6]);

	  strcpy(sPassword,Row[1]);
	  if(Row[2]!=NULL )
	  {
	  strcpy(sNewPassword,Row[2]);
	  }
	  pSignOn->UserId = atoi(Row[0]);
	  strcpy(sBrokerCode,Row[3]);
	  pSignOn->VersionNumber = atoi(Row[4]);
	  strcpy(sWorkstationAddr,Row[5]);
	  strcpy(sBrokerName,Row[6]);

	  }*****/




	strcpy(sPassword,"Neat@cd1");
	strcpy(sNewPassword," ");
	strcpy(sBrokerCode,"08814");
	strcpy(sWorkstationAddr,"4101710");
	strcpy(sBrokerName,"SHINE N P");

	/****  memcpy(pSignOn->Password,sPassword,strlen(sPassword));*****/ /***** Nitish to be fetched from DB *****/
	strncpy(pSignOn->sPassword,sPassword,8);
	/**** memcpy(pSignOn->Password,"Neat@cd1",8);***/
	logDebug2("SignOn->Password :%s: :%d: ",pSignOn->sPassword,strlen(pSignOn->sPassword));
	logDebug2("Normal Password :[%s]",pSignOn->sPassword);
	logDebug2("Normal New Password 	[%s]",pSignOn->sNewPassword);
	logDebug2("sBrokerCode= [%d]",sBrokerCode);
	logDebug2("BROKER_CODE_LENGTH = [%d]",BROKER_CODE_LENGTH);

	strncpy(pSignOn->sBrokerCode,sBrokerCode,BROKER_CODE_LENGTH);
	if(strlen(sBrokerCode)< BROKER_CODE_LENGTH)
	{
		logDebug2("inside sBrokerCode< BROKER_CODE_LENGTH");
		memset((pSignOn->sBrokerCode + strlen(sBrokerCode)),' ',(BROKER_CODE_LENGTH - strlen(sBrokerCode)));
	}
	logDebug2("::sWorkstationAddr= [%d]",sWorkstationAddr);
	logDebug2("::WORK_STATION_ADDR_LEN = [%d] ",WORK_STATION_ADDR_LEN);
	strncpy(pSignOn->sWorkstationAddr,sWorkstationAddr,strlen(sWorkstationAddr));

	if(strlen(sWorkstationAddr)< WORK_STATION_ADDR_LEN)
	{
		logDebug2("::inside sWorkstationAddr< WORK_STATION_ADDR_LEN ");
		memset((pSignOn->sWorkstationAddr + strlen(sWorkstationAddr)),' ',(WORK_STATION_ADDR_LEN - strlen(sWorkstationAddr)));
	}

	logDebug2(":: BROKER_NAME_LEN = [%d] ",BROKER_NAME_LEN);
	strncpy(pSignOn->sBrokerName,sBrokerName,strlen(sBrokerName));

	if(strlen(sBrokerName)< BROKER_NAME_LEN)
	{
		logDebug2("::inside sBrokerName< BROKER_NAME_LEN ");
		memset((pSignOn->sBrokerName + strlen(sBrokerName)),' ',(BROKER_NAME_LEN - strlen(sBrokerName)));
	}

	logDebug2("Normal Password"); 
	pSignOn->iVersionNumber = 92700;
	pSignOn->iUserId = 8520;


	logDebug2("Nitish Printing ");
	logDebug2("SignOn->Password  :%d::%s:",NSE_PASSWORD_LEN,pSignOn->sPassword);
	logDebug2("SignOn->Password strlen:%d::%s:",strlen(pSignOn->sPassword),pSignOn->sPassword);
	logDebug2("SignOn->NewPassword:%d::%s:",NSE_PASSWORD_LEN,pSignOn->sNewPassword);
	logDebug2("SignOn->NewPassword:%d::%s:",strlen(pSignOn->sNewPassword),pSignOn->sNewPassword);
	logDebug2("SignOn->BrokerCode :%d::%s:",strlen(pSignOn->sBrokerCode),pSignOn->sBrokerCode);
	logDebug2("SignOn->WorkstationAddr :%d::%s:",strlen(pSignOn->sWorkstationAddr),pSignOn->sWorkstationAddr);
	logDebug2("SignOn->BrokerName :%d::%s:",strlen(pSignOn->sBrokerName),pSignOn->sBrokerName);
	logDebug2("SignOn->VersionNumber %d",pSignOn->iVersionNumber);
	logDebug2("SignOn->UserId %d",pSignOn->iUserId);
	logDebug2("Nitish Printing done ");

	/**
	  EXEC SQL UPDATE exch_administration_master
	  SET eam_logon_status 	= :lDisconnFromExch
	  WHERE 			eam_exm_exch_id 	= 'NSE' 		AND 
	  eam_group_id 		= to_CHAR(:iGroupid) 	AND 	
	  eam_drv_Flag 		= 'N';

	  if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	  return FALSE;
	 ****/
	logTimestamp("Exit : [PLogOnR]"); 
	return TRUE;

}


BOOL	fSendsysinfo(CHAR *cNNF )
{
	logTimestamp("Entry : [fSendsysinfo]");	

	struct NNF_SYS_INFO_REQ *pSys;
	pSys = (struct NNF_SYS_INFO_REQ *)malloc(sizeof(struct NNF_SYS_INFO_REQ));

	memcpy(pSys,cNNF,sizeof(struct NNF_SYS_INFO_REQ));

	pSys->pHeader.iTraderID = iTmpTradeId ;
	pSys->pHeader.iLogTimeStamp = 0 ;
	memset(pSys->pHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);

	pSys->pHeader.iMsgCode = TC_EQU_NSE_SYS_INFO_REQ;
	pSys->pHeader.iErrorCode = 0 ;
	memset(pSys->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pSys->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);

	pSys->pHeader.sTimeStamp2[0] = 0;
	memset(pSys->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pSys->pHeader.iMsgLength = sizeof(struct NNF_SYS_INFO_REQ) ;
	memcpy( pSys->pHeader.sAlphaSplit,"NT",2);

#ifdef     DBG
	logDebug2("proc_progN.pc THIS IS THE SYS INFO DOWNLOAD PROCESS ");
#endif

#ifdef     DBG
	logDebug2("proc_progN.pc The transcode is %d ",pSys->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pSys->pHeader.iMsgLength);
	logDebug2("proc_progN.pc before send .... before fork ");
#endif

	TWIDDLE(pSys->pHeader.iLogTimeStamp);
	TWIDDLE(pSys->pHeader.iMsgCode);
	TWIDDLE(pSys->pHeader.iErrorCode);
	TWIDDLE(pSys->pHeader.iTraderID);
	/*	TWIDDLE(pSys->sHeader.MsgLength);	*/
	logDebug2("After TWIDDLE in sendsysinfo ");
	logDebug2("proc_progN.pc The transcode is %d ",pSys->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pSys->pHeader.iMsgLength);
	logDebug2("proc_progN.pc The errorcode is %d ",pSys->pHeader.iErrorCode);

	memcpy(cNNF,pSys,sizeof(struct NNF_SYS_INFO_REQ));

	free(pSys);
	logTimestamp("Exit : [fSendsysinfo]");
	return TRUE;

}


BOOL	fRecvsysinfo(CHAR *cNNF)
{
	logTimestamp("Entry : fRecvsysinfo");

	struct	NNF_SYS_INFO_RESP	*pSys;
	BOOL 	iDataupdate, iEDDFlag;  /**** TAP Reg Changes *****/
	CHAR 	sError[ERROR_MSG_LEN]; 

	pSys = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	memcpy(pSys,cNNF,sizeof(struct NNF_SYS_INFO_RESP));

	CHAR    sErrorStr[DB_REASON_DESC_LEN];
        memset(sErrorStr,'\0',DB_REASON_DESC_LEN);
	SHORT iNumberOfStream= 0;	

	TWIDDLE(pSys->pHeader.iMsgCode);
	TWIDDLE(pSys->pHeader.iMsgLength);
	TWIDDLE(pSys->pMarketStatus.iNormal);
	TWIDDLE(pSys->pMarketStatus.iOddlot);
	TWIDDLE(pSys->pMarketStatus.iSpot);
	TWIDDLE(pSys->pMarketStatus.iAuction);
	TWIDDLE(pSys->pMarketStatus.iCallAuction1);
	TWIDDLE(pSys->pMarketStatus.iCallAuction2);
	TWIDDLE(pSys->iMarketIndex);
	TWIDDLE(pSys->iNormalMktDefSttlPeriod);
	TWIDDLE(pSys->iSpotMktDefSttlPeriod);
	TWIDDLE(pSys->iAuctionMktDefSttlPeriod);
	TWIDDLE(pSys->iDefCompititorPeriod);
	TWIDDLE(pSys->iDefSolicitorPeriod);
	TWIDDLE(pSys->iWarnigPercent);
	TWIDDLE(pSys->iVolFreezePercent);
	TWIDDLE(pSys->iBoardLotQty);
	TWIDDLE(pSys->iTickSize);
	TWIDDLE(pSys->iMaxGTCDays);
	TWIDDLE(pSys->iDiscQty);

	//logDebug2("proc_progN.pc The No of STREAM is :%d:", pSys->pHeader.sAlphaSplit[0]);       
	logDebug2("proc_progN.pc The No of STREAM is :%d:", *(pSys->pHeader.sAlphaSplit));      
	if(pSys->pHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP ) 
	{	
		iNumberOfStream = *(pSys->pHeader.sAlphaSplit);
	}
	else
	{
		iNumberOfStream = 3;
	}
	logDebug2("iNumberOfStream :%d:",iNumberOfStream);	
	logDebug2("proc_progN.pc The transcode is %d ",pSys->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pSys->pHeader.iMsgLength);
	logDebug2("proc_progN.pc The market status for normal  is %d ",pSys->pMarketStatus.iNormal);
	logDebug2("proc_progN.pc The market status for oddlot  is %d ",pSys->pMarketStatus.iOddlot);
	logDebug2("proc_progN.pc The market status for spot  is %d ",pSys->pMarketStatus.iSpot);
	logDebug2("proc_progN.pc The market status for auction  is %d ",pSys->pMarketStatus.iAuction);
	logDebug2("proc_progN.pc The Market Index  is %ld ",pSys->iMarketIndex);
	logDebug2("proc_progN.pc The Normal Mkt Def Sttl period  is %d ",pSys->iNormalMktDefSttlPeriod);
	logDebug2("proc_progN.pc The Spot dffl period is %d ",pSys->iSpotMktDefSttlPeriod);
	logDebug2("proc_progN.pc The Auction dffl period is %d ",pSys->iAuctionMktDefSttlPeriod);
	logDebug2("proc_progN.pc The Def Compitotor period is %d ",pSys->iDefCompititorPeriod);
	logDebug2("proc_progN.pc The Def Solicitor period is %d ",pSys->iDefSolicitorPeriod);
	logDebug2("proc_progN.pc The Warning Percent is %d ",pSys->iWarnigPercent);
	logDebug2("proc_progN.pc The Vol Freeze Percent is %d ",pSys->iVolFreezePercent);
	logDebug2("proc_progN.pc The Board Lot Qty is %ld ",pSys->iBoardLotQty);
	logDebug2("proc_progN.pc The Tick Size is %ld ",pSys->iTickSize);
	logDebug2("proc_progN.pc The Max GTC days is %d ",pSys->iMaxGTCDays);
	logDebug2("proc_progN.pc The Disc Qty is %d ",pSys->iDiscQty);

	if ((pSys->pHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP ) || (pSys->pHeader.iMsgCode == TC_EQU_NSE_PARTIAL_SYS_INFO_RESP))
	{ 
		iDataupdate = UpdateSysInfoResp(pSys);
		free(pSys);
		/*************** TAP Reg Changes*******************/
		//iDataupdate = TRUE;

		if (iDataupdate == TRUE)
		{
			iEDDFlag = fInsertExchDigital(iNumberOfStream);  

			if( iEDDFlag == TRUE)
			{ 
				// Printing for monitoring purpose @NItish
				logTimestamp(":%s: SYS INFO RESPONSE UPDATE SUCCESS ",KEY_WORD_MONITORING);	
				return TRUE;
			}	
		}
		/************ END of TAP Reg Changes*******************/
		else
		{
			memset(sError,NULL,ERROR_MSG_LEN);
			strcpy(sError,"Could Not Update the Database in SYS INFO RESPONSE");
			// Printing for monitoring purpose @NItish
			logTimestamp(":%s: SYS INFO RESPONSE UPDATE FAILS ",KEY_WORD_MONITORING);	
			return(ERROR);
		}
	}	
	else
	{
		free(pSys);

#ifdef     DBG
		logDebug2("proc_progN.pc Got someother transcode other than SYS INFO RESPONSE ");
#endif
		return ERROR;
	}	
	logTimestamp("Exit : fRecvsysinfo");

}


BOOL	fPUpLDBR ( struct NNF_UPDATE_LDB_REQ   *pUpdLDB , LONG32 iGroupid )
{
	//	LONG32	temp1;
	//    	LONG32	temp2;
	logTimestamp("Entry : fPUpLDBR");

	CHAR	*cSecdate,*cPartdate;

	cSecdate = (CHAR *)malloc(sizeof(CHAR)*80);
	cPartdate = (CHAR *)malloc(sizeof(CHAR)*80);

	/****	EXEC SQL SELECT max(JULIDATE(EAM_LAST_UPDATE_PART_TIME))
INTO :temp2
FROM EXCH_ADMINISTRATION_MASTER
WHERE			
EAM_EXCH_USER_ID   = to_CHAR(:iGroupid)  AND
EAM_EXM_EXCH_ID    = 'NSE'              AND
EAM_DRV_FLAG       = 'N';;
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

strcpy(tablename,"NSE_SECURITY_MASTER");
EXEC SQL SELECT max(JULIDATE(NSE_CREATED_DATE))
INTO :temp1
FROM NSE_SECURITY_MASTER;
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;
strcpy(tablename,"EXCH_MKT_MASTER");
EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Normal 
FROM   EXCH_MKT_MASTER
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND 	EMM_MKT_TYPE = 'NL';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Oddlot  
FROM   EXCH_MKT_MASTER 
WHERE	EMM_EXM_EXCH_ID = 'NSE'
AND	EMM_MKT_TYPE = 'OL';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Spot 
FROM   EXCH_MKT_MASTER 
WHERE 	EMM_EXM_EXCH_ID = 'NSE'
AND	EMM_MKT_TYPE = 'SP';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL SELECT EMM_STATUS
INTO   :pUpdLDB->MarketStatus.Auction 
FROM   EXCH_MKT_MASTER 
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND 	EMM_MKT_TYPE = 'AU';   
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;
	 ********/

	pUpdLDB->pMarketStatus.iNormal = 1;
	pUpdLDB->pMarketStatus.iOddlot =1;
	pUpdLDB->pMarketStatus.iSpot = 1; 
	pUpdLDB->pMarketStatus.iAuction =1;
	pUpdLDB->pHeader.iTraderID = iTmpTradeId ;
	pUpdLDB->pHeader.iLogTimeStamp = 0 ;

	memset(pUpdLDB->pHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);

	pUpdLDB->pHeader.iMsgCode = TC_NSE_UPD_LDB_DOWNLD_REQ;
	pUpdLDB->pHeader.iErrorCode = 0 ;

	memset(pUpdLDB->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pUpdLDB->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pUpdLDB->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);

	pUpdLDB->pHeader.iMsgLength = sizeof(struct NNF_UPDATE_LDB_REQ);
	pUpdLDB->cReqForOpenOrders = 'N';
	pUpdLDB->iLastUpdateSecTime = 1130365700;
	pUpdLDB->iLastUpdatePartTime = 991533600;
	/*****
#ifdef DBG
logDebug2("\nproc_progN.pc The Last update security date is %s \n",cSecdate);
logDebug2("\nproc_progN.pc The Last update part time is %s \n",cPartdate);
#endif


if (sqlca.sqlcode == 0)
{
return TRUE;
}
else
{
return FALSE;
}

	 *****/
	free(cSecdate);
	free(cPartdate);
	logTimestamp("Exit : fPUpLDBR");
	return TRUE;

	}

BOOL	fSendupdate( CHAR *cNNF, LONG32 iGroupid )
{
	logTimestamp("Entry : fSendupdate");	

	struct	NNF_UPDATE_LDB_REQ	*pUrequest;
	LONG32 	iUpldb_result;
	CHAR 	sError[ERROR_MSG_LEN];

	pUrequest = (struct NNF_UPDATE_LDB_REQ *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));

	memcpy(pUrequest,cNNF,sizeof(struct NNF_UPDATE_LDB_REQ));
	iUpldb_result = fPUpLDBR(pUrequest, iGroupid ) ;

	if (iUpldb_result == FALSE)
	{
		memset(sError,NULL,ERROR_MSG_LEN);
		strcpy(sError,"Could Not Query the Database in LDB REQUEST");
		logDebug2("%s",sError);
		return(ERROR);
	}

#ifdef     DBG
	logDebug2("proc_progN.pc THIS IS THE Update DATABASE DOWNLOAD PROCESS ");
	logDebug2("proc_progN.pc The result is %d ",iUpldb_result);
	logDebug2("proc_progN.pc the values to be requested are %d %d %d %d ",pUrequest->pMarketStatus.iNormal,pUrequest->pMarketStatus.iOddlot,
			pUrequest->pMarketStatus.iSpot,pUrequest->pMarketStatus.iAuction);
	logDebug2("proc_progN.pc The transcode is %d ",pUrequest->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pUrequest->pHeader.iMsgLength);
	logDebug2("proc_progN.pc before send .... before fork ");
#endif
	TWIDDLE(pUrequest->pHeader.iMsgCode);
	logDebug2("ALOKK Urequest->sHeader.MsgLength :%d:",pUrequest->pHeader.iMsgLength);
	/***    TWIDDLE(pUrequest->sHeader.MsgLength);****/
	logDebug2("ALOKK Urequest->sHeader.MsgLength :%d:",pUrequest->pHeader.iMsgLength);

	TWIDDLE(pUrequest->pHeader.iLogTimeStamp);
	TWIDDLE(pUrequest->pHeader.iErrorCode);
	TWIDDLE(pUrequest->pHeader.iTraderID);
	TWIDDLE(pUrequest->iLastUpdateSecTime);
	TWIDDLE(pUrequest->iLastUpdatePartTime);    
	TWIDDLE(pUrequest->pMarketStatus.iNormal);
	TWIDDLE(pUrequest->pMarketStatus.iOddlot);
	TWIDDLE(pUrequest->pMarketStatus.iSpot);
	TWIDDLE(pUrequest->pMarketStatus.iAuction);

	memcpy(cNNF,pUrequest,sizeof(struct NNF_UPDATE_LDB_REQ)); 

	free(pUrequest);
	logTimestamp("Exit : fSendupdate");
	return TRUE;

}

BOOL	fSendmessage( CHAR *cNNF , LONG32 iGroupid , LONG32 iStream)  /**** TAP Reg Changes *****/
{
	logTimestamp("Entry : fSendmessage");

	struct	NNF_MSG_DOWNLOAD_REQ	*pMrequest;
	struct 	NNF_DOUBLE_INT 		*pTempTimeStamp;
	//  	LONG32 	upMsg_result;
	CHAR 	sError[ERROR_MSG_LEN];
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sSelQyr= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//	LONG32 	i, iMints1,iMints2,minoffts1,minoffts2;
	//	LONG32 	NoOfIterations,IterationStatus;

	//	unsigned	LONG32	TempTime1;
	//	unsigned	LONG32 	TempTime2;
	//	unsigned	ULONG32	iOnTime1;
	//      unsigned 	ULONG32	iOnTime2;

	SHORT	iStreamId; /**** TAP Reg Changes *****/

	pMrequest = (struct NNF_MSG_DOWNLOAD_REQ *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	pTempTimeStamp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));

	memcpy(pMrequest,cNNF,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

	memset(pMrequest,SPACE,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

#ifdef     DBG
	logDebug2("proc_progN.pc the group id is %d ",iGroupid);
#endif

	/*************** TAP Reg Changes*******************/
	iStreamId = iStream ;
	logDebug2("STREAM ID :%d", iStreamId);

	sprintf(sSelQyr,"SELECT (case when (EDD_TIMESTAMP1 - %d) < 0 then 0 else (EDD_TIMESTAMP1 - %d) end) ,EDD_TIMESTAMP2 FROM EXCH_DOWNLOAD_DATA WHERE EDD_EXCH_ID = \"%s\" AND EDD_SEGMENT = \'%c\' AND EDD_GROUP_ID = %d AND EDD_STREAM_ID = '%d' ;",iJiffyTime,iJiffyTime,NSE_EXCH,EQUITY_SEGMENT,iGroupid,iStreamId)	;
	logDebug2("sSelQyr :%s:",sSelQyr);

	if(mysql_query(DBConNNF,sSelQyr) != SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConNNF);

	if(Row = mysql_fetch_row(Res))
	{
		//pMrequest->fExchSeqNum = atof(Row[0]);
		logDebug3("Last Message Time1 = %s ",Row[0]);
		logDebug3("Last Message Time2 = %s" ,Row[1]);
//		sscanf(Row[0],"%u",&(pTempTimeStamp->LogTime1)   );
//		sscanf(Row[1],"%u",&(pTempTimeStamp->LogTime2)        );
		pTempTimeStamp->LogTime1 = strtoul(Row[0],NULL,10);
		pTempTimeStamp->LogTime2 = strtoul(Row[1],NULL,10);
	}
	else
	{
		pTempTimeStamp->LogTime1 = 0 ;
		pTempTimeStamp->LogTime2 = 0 ;
	}
	logDebug3("Last Message Time1 = %u ",pTempTimeStamp->LogTime1);
	logDebug3("Last Message Time2 = %u" ,pTempTimeStamp->LogTime2);

	memcpy((CHAR*)&pMrequest->fExchSeqNum,pTempTimeStamp, sizeof(struct NNF_DOUBLE_INT) );

	/***
	  pTempTimeStamp->LogTime1 = 0;
	  pTempTimeStamp->LogTime2 = 0; 
#ifdef   DBG
logDebug2("Last Message Time1 = %u ",pTempTimeStamp->LogTime1);
logDebug2("Last Message Time2 = %u" ,pTempTimeStamp->LogTime2);
#endif

memcpy((CHAR*)&pMrequest->fExchSeqNum ,pTempTimeStamp , sizeof(struct NNF_DOUBLE_INT) ); 
logDebug2("Sequence Number	:	%lf",pMrequest->fExchSeqNum);

#ifdef     DBG
logDebug2("proc_progN.pc THIS IS THE MESSAGE DOWNLOAD PROCESS ");
#endif
	 ****/
	//	pMrequest->fExchSeqNum =1186559835;    
	pMrequest->pHeader.iTraderID = iTmpTradeId ;
	pMrequest->pHeader.iLogTimeStamp = 0 ;
	//memset(pMrequest->pHeader.sAlphaSplit," ",ALPHA_SPLIT_LEN);
	sprintf(pMrequest->pHeader.sAlphaSplit,"%d",iStreamId);
	*(pMrequest->pHeader.sAlphaSplit) = iStream;
	pMrequest->pHeader.iMsgCode = TC_NSE_MSG_DOWNLOAD_REQ;
	pMrequest->pHeader.iErrorCode = 0 ;
	memset(pMrequest->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pMrequest->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pMrequest->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pMrequest->pHeader.iMsgLength = sizeof(struct NNF_MSG_DOWNLOAD_REQ);

	//pMrequest->fExchSeqNum = 0;	
#ifdef     DBG
	logDebug2("proc_progN.pc The Sequence No is :%lf: ",pMrequest->fExchSeqNum);
	logDebug2("proc_progN.pc The transcode is %d ",pMrequest->pHeader.iMsgCode);
	logDebug2("proc_progN.pc The Msglength is %d ",pMrequest->pHeader.iMsgLength);
	logDebug2("proc_progN.pc MESG_DOWN_REQ ::: before send ");
#endif
	TWIDDLE(pMrequest->pHeader.iLogTimeStamp);
	TWIDDLE(pMrequest->pHeader.iMsgCode);
	/**	TWIDDLE(pMrequest->sHeader.MsgLength);	**/
	TWIDDLE(pMrequest->pHeader.iErrorCode);	
	TWIDDLE(pMrequest->pHeader.iTraderID);	
	TWIDDLE(pMrequest->fExchSeqNum);

	memcpy(cNNF,pMrequest,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

	free(pMrequest);
	free(pTempTimeStamp);

	/***	if (sqlca.sqlcode == 0 )
	  return TRUE;
	  else****/
	logTimestamp("Exit : fSendmessage");
	return TRUE;

}

void	fSend_exch_down_nse(LONG32 iGroupid)
{
	logTimestamp("Entry : fSend_exch_down_nse");

	CHAR	*cError,*cMsg;
	//        CHAR 	status;
	CHAR 	sProgTime[40];
	
	memset(sProgTime,'\0',40);
	CHAR    sMapMsg[LOCAL_MAX_PACKET_SIZE];
	struct	NNF_HEADER	*pHeader;
	LONG32 	iQid , iWait_status, iQid1 , iWrite_status , iTemplen , iQueueId;
	struct 	NNF_DOUBLE_INT	*pTempTimeStamp;
	LONG32  iTMChk = 0 ;


	//	ULONG32	TempTime1;
	//        ULONG32 TempTime2;

	cError = (CHAR *)malloc(sizeof(CHAR)*80);
	cMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);

	pTempTimeStamp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));

#ifdef	DBG
	logDebug2("IN FUNCTION send_exch_down_nse with groupid %d ",iGroupid );
#endif

	fGetTime(sProgTime);
	fUpdateConnectStatus(NSE_EQU_DOWN, iGroupid);
	logDebug2("[%s] IST :EXCHANGE DOWN TIME",sProgTime);
	/*****
	  switch(iGroupid)
	  {
	  ---- Code to choose Queue from Group Id ---
	 ** Reentered for M CTCL *
	 case 1 : iQueueId = EquRmsNseToNSE1 ;          
	 break;
	 case 2 : iQueueId = EquRmsNseToNSE2 ;
	 break;
	 case 3 : iQueueId = EquRmsNseToNSE3 ;
	 break;
	 case 4 : iQueueId = EquRmsNseToNSE4 ;
	 break;	
	 default : break;
	 };

	 ****/
	iQueueId = FwdMMapToConAdapNSECM;
	iQid = OpenMsgQ(iQueueId);

	if ( iQid < 0 )
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR : in OpenMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}

	logDebug2("Opened...");	
	iQid1 = OpenMsgQ( ConnToTrdMapNSEEQ);

	if ( iQid1 < 0 )
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR : in OpenMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}

	logDebug2("Opened...");

	for ( ;; )
	{
		logDebug2("b4 read NBQ = %d ",iQid);
		/***  iWait_status = ReadMsgQ( iQid , cMsg , NSE_PACKET_SIZE, 1);*****/
		memset ( &sMapMsg,' ', LOCAL_MAX_PACKET_SIZE );
		iWait_status = ReadNBQ( iQid , cMsg , NSE_PACKET_SIZE, 0);
		logDebug2("after read NBQ");

		if ( iWait_status == TRUE )
		{
			pHeader = (struct NNF_HEADER *)cMsg;
			TWIDDLE(pHeader->iMsgCode);

			logDebug2("SENDING EXCHANGE DOWN ERROR for Transcode %d",pHeader->iMsgCode);

			/** Same structures are used in Exch Request/Response, so we modify only the Msgcode. **/
			switch(pHeader->iMsgCode)
			{
				case TC_INT_ORDER_ENTRY_REQ: 
					//pHeader->iMsgCode = TC_INT_OE_ERROR_RESP;
//					((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OE_ERROR_RESP;
					((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iMsgCode = TC_INT_OE_ERROR_RESP;
					TWIDDLE(pHeader->iMsgLength);
					iTemplen  = pHeader->iMsgLength;
					iTMChk = 0 ;
					break;

				case TC_INT_ORDER_MODIFY: 
					//pHeader->iMsgCode = TC_INT_OM_ERROR_RESP;
				//	((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OM_ERROR_RESP;
					((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iMsgCode = TC_INT_OM_ERROR_RESP;
					TWIDDLE(pHeader->iMsgLength);
					iTemplen  = pHeader->iMsgLength;
					iTMChk = 0 ;
					break;

				case TC_INT_ORDER_CANCEL: 
					//pHeader->iMsgCode = TC_INT_OC_ERROR_RESP;
					//((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OC_ERROR_RESP;
					((struct NNF_ORDER_ENTRY *)cMsg)->pHeader.iMsgCode = TC_INT_OC_ERROR_RESP;
					TWIDDLE(pHeader->iMsgLength);
					iTemplen  = pHeader->iMsgLength;
					iTMChk = 0 ;
					break;
					/**
					  case TC_EQU_NSE_TRADE_MOD_REQ: pHeader->iMsgCode = TC_EQU_NSE_TRADE_MOD_REJECT_RESP;
					  break;

					  case TC_EQU_NSE_TRADE_CAN_REQ: pHeader->iMsgCode = TRADE_CAN_REJECTION;
					  break;
					  case TC_EQU_NSE_INDEX_OE_REQ: pHeader->iMsgCode = INDEX_ORDER_REJECTION;
					  break;
					 ***/
				case TC_EQU_NSE_ORD_ENTRY_REQ_TM:
				        fNseCMOrdEntErrResp(cMsg,sMapMsg);
				        pHeader->iMsgLength = sizeof(struct  NNF_ORD_RESPONSE_TM);
				        iTemplen = sizeof(struct  NNF_ORD_RESPONSE_TM);
				        iTMChk = 1 ;
				        break;
				case TC_EQU_NSE_ORD_MOD_REQ_TM:
				        fNseCMOrdModErrResp(cMsg,sMapMsg);
				        pHeader->iMsgLength = sizeof(struct  NNF_ORD_RESPONSE_TM);
				        iTemplen = sizeof(struct  NNF_ORD_RESPONSE_TM);
				        iTMChk = 1 ;
				        break;
				case TC_EQU_NSE_ORD_CAN_REQ_TM:
				        fNseCMOrdCanErrResp(cMsg,sMapMsg);
				        pHeader->iMsgLength = sizeof(struct  NNF_ORD_RESPONSE_TM);
				        iTemplen = sizeof(struct  NNF_ORD_RESPONSE_TM);
				        iTMChk = 1 ;
				        break;
				default : 
					break;
			}

			//pHeader->iErrorCode = EXCHANGE_DOWN_ERROR;
			((struct NNF_HEADER *)cMsg)->iErrorCode = EXCHANGE_DOWN_ERROR;

			/******     Patch for junk timestamp in the response packet     ******/

			/******            EXEC    SQL     SELECT
			  nvl(EAM_LAST_MSG_TIME,0),
			  nvl(EAM_LAST_MSG_TIME1,0)
			  INTO
			  :TempTime1,
			  :TempTime2
			  FROM            EXCH_ADMINISTRATION_MASTER
			  WHERE           EAM_EXM_EXCH_ID = 'NSE'         AND
			  EAM_GROUP_ID    = :iGroupid      AND
			  EAM_DRV_FLAG    = 'N' ;


			  if(sqlca.sqlcode != 0)
			  {
			  logDebug2("\n Error in selecting EAM_LAST_MSG_TIME(1) from EAM: %d", sqlca.sqlcode);
			  }
			 *******/
			pTempTimeStamp->LogTime1 = 3208380416;
			pTempTimeStamp->LogTime2 = 1700411950;

			TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgLength);
			TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgCode);
			TWIDDLE(((struct NNF_HEADER *)cMsg)->iErrorCode);

			memcpy((CHAR *)pHeader->sTimeStamp2 , pTempTimeStamp , sizeof(struct NNF_DOUBLE_INT));

			logDebug2("TempTimeStamp->LogTime1 = %u", pTempTimeStamp->LogTime1);
			logDebug2("TempTimeStamp->LogTime2= %u", pTempTimeStamp->LogTime2);
			
			if(iTMChk == 0)
                        {
				iWrite_status = WriteMsgQ(iQid1,cMsg,iTemplen,1);
			}
			else
			{
				iWrite_status = WriteMsgQ(iQid1,sMapMsg,iTemplen,1);
			}
			if ( iWrite_status < 0)
			{
				logDebug2("inside WriteMsgQ ");
				memset(cError,NULL,80);
				strcpy(cError,"ERROR in WriteMsgQfunction : Queue.c");
				logDebug2("%s",cError);
				free(cError);
				free(cMsg);
				exit(ERROR);
			}
			/**
			  else
			  {
			  free(cError);
			  free(cMsg);
			  }
			 ***/
		}
		else
		{
			//	free(cError);
			//	free(cMsg);
			break;
		}
	}
	free(cError);
	free(cMsg);

	logTimestamp("Exit : fSend_exch_down_nse");	
}

void	fDeal_with_error_response_nse( CHAR *cGetError )
{
	logTimestamp("Entry : fDeal_with_error_response_nse");

	struct	NNF_ERROR_RESP	*pErr;

	//	INT16	count =0;
	//        INT16   TempCode;
	//        CHAR 	TempUserId[ EQU_NSECONN_USER_ID_LEN ];
	CHAR 	sTempErrorMesg[NSE_PACKET_SIZE];
	CHAR 	sTempSeries[SERIES_LEN];
	CHAR 	sTempSymbol[SYMBOL_LEN];

	pErr = (struct NNF_ERROR_RESP *)malloc(sizeof(struct NNF_ERROR_RESP));

	memcpy(pErr,cGetError,sizeof(struct NNF_ERROR_RESP));
	memcpy(sTempErrorMesg,pErr->sErrorString,ERROR_MSG_LEN);
	memcpy(sTempSeries,pErr->pSecInfo.sSeries,SERIES_LEN);
	memcpy(sTempSymbol,pErr->pSecInfo.sSymbol,SYMBOL_LEN);

	/**	TempCode = err->sHeader.ErrorCode;
	  TempErrorMesg= ERROR_STRING_LEN;
	  sTempSeries= SERIES_LEN;
	  sTempSymbol= SYMBOL_LEN;
	 ***/
	logDebug2("Test : I am here ");
	free(pErr);
	logTimestamp("Exit : fDeal_with_error_response_nse");

}

void	fDeal_with_message_nse( CHAR *cData )
{
	logTimestamp("Entry : fDeal_with_message_nse");

	CHAR 	sTempData[NSE_PACKET_SIZE];
	INT16   iTempCode;
	CHAR 	sTempUserId[ EQU_NSECONN_USER_ID_LEN ];
	CHAR 	sTempSeries[SERIES_LEN];
	CHAR 	sTempSymbol[SYMBOL_LEN];

	memset(sTempData,' ',NSE_PACKET_SIZE);
	memset(sTempUserId,' ',EQU_NSECONN_USER_ID_LEN);
	memset(sTempSeries,' ',SERIES_LEN);
	memset(sTempSymbol,' ',SYMBOL_LEN);
	memcpy(sTempData,cData,NSE_PACKET_SIZE);
	//sTempData= NSE_PACKET_SIZE;
	iTempCode = 0;
	memcpy(sTempSymbol,"EXCH-MSG",8);
	memcpy(sTempSeries,"__",2);

	logTimestamp("Exit : fDeal_with_message_nse");

}


BOOL 	fGet_mesg_or_error_nse(CHAR *cMsgbuf)
{
	logTimestamp("Entry : fGet_mesg_or_error_nse");

	struct	NNF_HEADER      *pHeader;
	struct  NNF_ORDER_ENTRY *pOrders;
	struct 	NNF_EXCH_MSG_TO_TRADER_RESP *pResp;
	CHAR    *cData;
	BOOL    iFlag;

	cData = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	pOrders = (struct NNF_ORDER_ENTRY *)malloc(sizeof(struct NNF_ORDER_ENTRY));
	pResp = (struct NNF_EXCH_MSG_TO_TRADER_RESP *)malloc(sizeof(NNF_EXCH_MSG_TO_TRADER_RESP));

	memcpy(pHeader,cMsgbuf,sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iErrorCode);
	TWIDDLE(pHeader->iMsgLength);
	TWIDDLE(pHeader->iMsgCode);
	TWIDDLE(pHeader->iLogTimeStamp);

	logDebug2("NOTE :: ReasonCode is : %d", ((struct  NNF_ORDER_ENTRY *)&cMsgbuf)->iReasonCode );
	logDebug2("NOTE :: Exch...Header->ErrorCode is : %d", pHeader->iErrorCode);

	if ( (pHeader->iErrorCode != 0)  && (pHeader->iMsgLength == sizeof(struct NNF_ERROR_RESP)) )
	{
		logDebug2("There is some error %d ", pHeader->iErrorCode );
		fDeal_with_error_response_nse( cMsgbuf );
		iFlag = TRUE;  
	}
	else
	{
		/***
		  switch(pHeader->iMsgCode)
		  {
		  case    TC_EQU_NSE_EXCH_MSG_TO_TRADER_RESP :
		  memset(cData,NULL,NSE_PACKET_SIZE);
		  memcpy(resp,cMsgbuf,sizeof(struct NNF_EXCH_MSG_TO_TRADER_RESP));
		  TWIDDLE(resp->iTraderId); 
		  logDebug2("\nNitesh here ");
		  logDebug2("Trader id = %d ,Action Code = %s , Broad Cast message %s",resp->iTraderId,resp->sActionCode,resp->sBcastMsg);
		  slogDebug2(cData,"Trader id = %d ,Action Code = %s , Broad Cast message %s",resp->iTraderId,resp->sActionCode,resp->sBcastMsg);
		  logDebug2("\nPimpale");
		  iFlag = TRUE;
		  break;

		  case    TC_EQU_NSE_NEG_ORDER_ENTERED_BY_CP_RESP :
		  memset(cData,NULL,NSE_PACKET_SIZE);
		  memcpy(orders,cMsgbuf,sizeof(struct NNF_ORDER_ENTRY));
		  TWIDDLE(orders->fOrderNum); 
		  slogDebug2(cData,"BrokerCode= %s, Counter Party Broker Code= %s, Security-Symbol= %s, OrderNum= %lf ",orders->sBrokerCode,orders->sCPBrokerCode,orders->pSecInfo.sSymbol,orders->fOrderNum);
		  iFlag = TRUE;
		  break;

		  case    TC_GENERAL_MSG_BCAST :
		  memset(cData,NULL,NSE_PACKET_SIZE);
		  memcpy(resp,cMsgbuf,sizeof(struct NNF_EXCH_MSG_TO_TRADER_RESP));
		  TWIDDLE(resp->iTraderId);   
		  slogDebug2(cData,"Trader id = %d ,Action Code = %s , Broad Cast message %s",resp->iTraderId,resp->sActionCode,resp->sBcastMsg);
		  iFlag = TRUE;
		  break;


		  default  :      iFlag = FALSE;
		  break;

		  };
		 ***/
		if ( iFlag == TRUE )
			fDeal_with_message_nse( cData );

	}

	free(cData);
	free(pHeader);
	free(pOrders);
	free(pResp);
	logDebug2("Test : I am REturning  %d ", iFlag);
	logTimestamp("Exit : fGet_mesg_or_error_nse");
	return(iFlag);

}		


void	fSend_exch_down_buf_nse(LONG32 iGroupid,CHAR * cMsg)
{
	logTimestamp("Entry : fSend_exch_down_buf_nse");

	CHAR	*sMessageLog="MessageLog";
	CHAR 	*cError;
	//        CHAR 	status;

	struct 	NNF_HEADER	*pHeader;

	LONG32	iQid , iWait_status, iQid1 , iWrite_status , iTemplen;
	cError = (CHAR *)malloc(sizeof(CHAR)*80);

	iQid1 = OpenMsgQ( ConnToTrdMapNSEEQ);

	if ( iQid1 < 0 )
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR : in OpenMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}

	pHeader = (struct NNF_HEADER *)cMsg;

	TWIDDLE(pHeader->iMsgCode);
	TWIDDLE(pHeader->iMsgLength);

	iTemplen  = pHeader->iMsgLength;

	switch(pHeader->iMsgCode)
	{
		case TC_INT_ORDER_ENTRY_REQ:
			//pHeader->iMsgCode = TC_INT_OE_ERROR_RESP;
			((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OE_ERROR_RESP;
			break;

		case TC_INT_ORDER_MODIFY:
			//pHeader->iMsgCode = TC_INT_OM_ERROR_RESP;
			((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OM_ERROR_RESP;
			break;

		case TC_INT_ORDER_CANCEL:
			//pHeader->iMsgCode = TC_INT_OC_ERROR_RESP;
			((struct NNF_HEADER *)cMsg)->iMsgCode = TC_INT_OC_ERROR_RESP;
			break;
		default :
			break;
	}
	((struct NNF_HEADER *)cMsg)->iErrorCode = EXCHANGE_DOWN_ERROR;

	TWIDDLE(((struct NNF_HEADER *)cMsg)->iErrorCode);
	TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgLength);
	TWIDDLE(((struct NNF_HEADER *)cMsg)->iMsgCode);

	iWrite_status = WriteMsgQ(iQid1,cMsg,iTemplen,1);
	if ( iWrite_status < 0)
	{
		memset(cError,NULL,80);
		strcpy(cError,"ERROR in WriteMsgQ function : Queue.c");
		free(cError);
		exit(ERROR);
	}
	free(cError);
	logTimestamp("Exit : fSend_exch_down_buf_nse");

}

BOOL	fOpenBcastSocket()
{
	logTimestamp("Entry : fOpenBcastSocket");

	LONG32	iOptval=1;
	LONG32  iVal;

	if ( (iSockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}

	iVal = setsockopt(iSockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&iOptval,sizeof(iOptval));

	if ( iVal < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	logTimestamp("Exit : fOpenBcastSocket");
	return TRUE;

}

BOOL 	fInsertExchDigital(SHORT iNoStreams )
{
	logTimestamp("Entry : fInsertExchDigital");

	SHORT    j=0;
	LONG32  iGroupId=0;
	SHORT   iStreamId =0;
	//        ULONG32 Time1 =0;
	//        ULONG32 Time2 =0 ;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	LONG32	iNumRow;

	CHAR	*sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	CHAR	*sInsQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	logDebug2("iGlobGroupId : %d iNoStreams :%d ", iGlobGroupId, iNoStreams);
	iGroupId =iGlobGroupId;
	//iNoStreams = 3;//iTotalStream ;
	logDebug2("Local iGroupId : %d", iGroupId);

	logDebug2("===========iGlobGroupId [%d]== iNoStreams[%d]==",iGroupId, iNoStreams);
	for ( j=1 ; j <= iNoStreams; j++)
	{
		iStreamId = j;

		sprintf(sSelQry,"SELECT * FROM EXCH_DOWNLOAD_DATA\
				WHERE EDD_STREAM_ID = %d \
				AND EDD_EXCH_ID=\"%s\"\
				AND EDD_SEGMENT=\'%c\'\
				AND EDD_GROUP_ID=%d ;",iStreamId,NSE_EXCH,EQUITY_SEGMENT,iGroupId);		
			logDebug2("sSelQry :%s:",sSelQry);	

		if(mysql_query(DBConNNF,sSelQry) != SUCCESS)
		{
			sql_Error(DBConNNF);	
			return FALSE;
		}

		Res = mysql_store_result(DBConNNF);	

		iNumRow = mysql_num_rows(Res);	

		logDebug2("NumRow :%d: StreamId:%d:",iNumRow,iStreamId);

		if(iNumRow == 0)
		{
			sprintf(sInsQry,"INSERT INTO  EXCH_DOWNLOAD_DATA(\ 
				EDD_GROUP_ID,\
				EDD_EXCH_ID,\
				EDD_SEGMENT,\
				EDD_STREAM_ID,\
				EDD_TIMESTAMP1,\
				EDD_TIMESTAMP2)\
					VALUES (\
						%d,\
						\"%s\",\
						\'%c\',\
						%d,\
						0,\
						0 );",iGroupId,NSE_EXCH,EQUITY_SEGMENT,iStreamId);	

					logDebug2("sInsQry :%s:",sInsQry);
			if(mysql_query(DBConNNF,sInsQry) != SUCCESS)
			{
				sql_Error(DBConNNF);
				return FALSE;
			}	
			else
			{
				mysql_commit(DBConNNF);
			}
		}
		mysql_free_result(Res);

	}

	free(sSelQry);
	free(sInsQry);
	logTimestamp("Exit : fInsertExchDigital");
	return TRUE ;

}


LONG32	fGetTotalStream()
{
	logTimestamp("Entry : fGetTotalStream");

	CHAR    *sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	LONG32	iStream;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32	iGroupId = 0;

	iGroupId =iGlobGroupId;

	sprintf(sSelQry,"SELECT max(EDD_STREAM_ID) \
			FROM EXCH_DOWNLOAD_DATA \
			WHERE  EDD_EXCH_ID=\"%s\"\
			AND EDD_SEGMENT=\'%c\'\
			AND EDD_GROUP_ID=%d;",NSE_EXCH,EQUITY_SEGMENT,iGroupId );		

		logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConNNF,sSelQry) != SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConNNF);

	if(Row = mysql_fetch_row(Res))
	{
		iStream = atoi(Row[0]);
	}
	else
	{
		iStream = 5;
	}

	logTimestamp("Exit : fGetTotalStream");
	return iStream;

}

BOOL    fUpdateTimeStamp(struct  NNF_DOUBLE_INT *pTempTimeStamp ,CHAR cStreamNum)
{
	logTimestamp("Entry : fUpdateTimeStamp");

	CHAR	sUpdateQry [MAX_QUERY_SIZE];
	memset(sUpdateQry,'\0',MAX_QUERY_SIZE);
	SHORT   j;
	LONG32  iGroupId=0;
	SHORT   iStreamId =0;
	ULONG32 iTime1 =0;
	ULONG32 iTime2 =0 ;
	logDebug2(" iGlobGroupId : %d", iGlobGroupId);
	iGroupId =iGlobGroupId;
	logDebug2("Local GroupId : %d", iGroupId);

	logDebug2("===========GlobGroupId [%d] stream [%c]====Updating  Timestamp ",iGroupId,cStreamNum);
	sprintf(sUpdateQry,"UPDATE EXCH_DOWNLOAD_DATA SET EDD_TIMESTAMP1 = %u,EDD_TIMESTAMP2= %u  WHERE EDD_EXCH_ID = \"%s\" AND EDD_SEGMENT =\'%c\' AND EDD_GROUP_ID = %d AND EDD_STREAM_ID = \'%c\' ; ",pTempTimeStamp->LogTime1,pTempTimeStamp->LogTime2,NSE_EXCH,EQUITY_SEGMENT,iGroupId,cStreamNum);	

	logDebug2("sUpdateQry :%s:",sUpdateQry);

	if(mysql_query(DBConNNF,sUpdateQry) != SUCCESS)
	{
		sql_Error(DBConNNF);
		return FALSE;
	}
	else
	{
		mysql_commit(DBConNNF);
		return TRUE;
	}	

	logTimestamp("Exit : fUpdateTimeStamp");

}

/****

  void convert_seconds_to_date(long seconds,CHAR *pDateTime)
  {
  struct tm *tmr;

  time_t julian;


  tmr = (struct tm *) malloc (sizeof(struct tm )) ;
  julian = seconds + OFFSET - TIMEZONE;
  localtime_r(&julian,tmr);
//    slogDebug2(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_mday, tmr->tm_mon+1,tmr->tm_year+1900,tmr->tm_hour ,tmr->tm_min  ,tmr->tm_sec );
slogDebug2(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_year+1900,tmr->tm_mon+1,tmr->tm_mday,tmr->tm_hour,tmr->tm_min  ,tmr->tm_sec );
free(tmr);

}
SHORT  fTrim( CHAR *string , SHORT MaxLen )
{
logTimestamp("Entry : [fTrim]");

SHORT index=0;
if ( MaxLen <= 0 )
return 0 ;

for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
continue;

string[index]='\0';
logTimestamp("Exit : [fTrim]");
return index ;
}
 ***/

BOOL    fSendGRrequest(CHAR *sSendnnf, LONG32 iGroupid,LONG32	iPrimarySecondary)
{
        logTimestamp("Entry : [fSendGRrequest]");

        struct  NNF_GR_REQUEST	*pGRSign;

	CHAR    *sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
        pGRSign= (struct NNF_GR_REQUEST *)malloc(sizeof(struct NNF_GR_REQUEST));

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        memset((CHAR*)pGRSign,' ',sizeof(struct NNF_GR_REQUEST));
        memcpy(pGRSign,sSendnnf,sizeof(struct NNF_GR_REQUEST));

	//memset(sUserID,'\0',5);
        pGRSign->pHeader.iErrorCode = 0 ;
        pGRSign->pHeader.iTraderID= 0 ;
        pGRSign->pHeader.iLogTimeStamp = 0 ;
        pGRSign->pHeader.iMsgCode = TC_EQU_NSE_GR_REQ;
	memset(pGRSign->pHeader.sAlphaSplit,' ',2);
	memset(pGRSign->pHeader.sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
	memset(pGRSign->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pGRSign->pHeader.sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
	memset(pGRSign->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pGRSign->pHeader.sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
	memset(pGRSign->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
        memcpy(pGRSign->pHeader.sAlphaSplit,"NT",2);
        pGRSign->pHeader.iMsgLength = sizeof(struct NNF_GR_REQUEST);

        logDebug3("sizeof(struct NNF_GR_REQUEST) :%d:",sizeof(struct NNF_GR_REQUEST));
//1. Connection with primary or secondary Box id changes.New Column EAM_BOX_ID_SEC added  @Nitish
	sprintf(sQuery,"SELECT EAM_BROKER_ID,EAM_BOX_ID,EAM_EXCH_USER_ID,EAM_BOX_ID_SEC  FROM EXCH_ADMINISTRATION_MASTER \
                        WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\'; ",iGroupid,NSE_EXCH,EQUITY_SEGMENT);

	logDebug2("sQuery :%s:",sQuery);

/***/
        if (mysql_query(DBConNNF, sQuery) != SUCCESS)
        {
                sql_Error(DBConNNF);
                return ERROR;
        }

        Res = mysql_store_result(DBConNNF);
/***/
        free(sQuery);
/**/
        while((Row = mysql_fetch_row(Res)))
        {


        	pGRSign->pHeader.iTraderID= atoi(Row[2]) ;
        	iTmpTradeId = atoi(Row[2]) ;
        	//pGRSign->pHeader.iTraderID= 90061 ;
        	// Printing for monitoring purpose @NItish
        	if(iPrimarySecondary == 0)
		{
			logTimestamp(":%s: TRYING TO CONNECT TO PRIMARY BOX :%s: ",KEY_WORD_MONITORING,Row[1]);
                	pGRSign->iBoxID= atoi(Row[1]);
		}
		else
		{
			logTimestamp(":%s: TRYING TO CONNECT TO SECONDARY BOX :%s: ",KEY_WORD_MONITORING,Row[3]);
                	pGRSign->iBoxID= atoi(Row[3]);
		}	
		strncpy(pGRSign->sBrokerID,Row[0],BROKER_CODE_LENGTH);
		pGRSign->cFiller1 = ' ';

	}

/**
       	pGRSign->pHeader.iTraderID= 90061 ;
        pGRSign->iBoxID= 9527;//9462 First we used this
	strncpy(pGRSign->sBrokerID,"90061",BROKER_CODE_LENGTH);
	pGRSign->cFiller1 = ' ';
***/
	logInfo("fSendGRrequest Before Twiddle ");
	logDebug3("sendGRreq 	TimeStamp       :%d:",pGRSign->pHeader.iLogTimeStamp);
        logDebug3("sendGRreq	Error Code      :%d:",pGRSign->pHeader.iErrorCode);
        logDebug3("sendGRreq	Mesg Length     :%d:",pGRSign->pHeader.iMsgLength);
        logDebug3("sendGRreq	iTraderID       :%d:",pGRSign->pHeader.iTraderID);
        logDebug3("sendGRreq	sAlphaSplit     :%s:",pGRSign->pHeader.sAlphaSplit);
        logDebug3("sendGRreq	sTimeStamp1	:%s:",pGRSign->pHeader.sTimeStamp1);
        logDebug3("sendGRreq	sTimeStamp2	:%s:",pGRSign->pHeader.sTimeStamp2);
        logDebug3("sendGRreq	sTimeStamp3	:%s:",pGRSign->pHeader.sTimeStamp3);
        logDebug3("sendGRreq 	sBrokerID	:%s:",pGRSign->sBrokerID);
        logDebug3("sendGRreq	iBoxID		:%d:",pGRSign->iBoxID);

	TWIDDLE( pGRSign->pHeader.iLogTimeStamp);
        TWIDDLE( pGRSign->pHeader.iMsgCode);
        TWIDDLE( pGRSign->pHeader.iErrorCode);
        TWIDDLE( pGRSign->pHeader.iMsgLength);
        TWIDDLE( pGRSign->pHeader.iTraderID);
        TWIDDLE( pGRSign->iBoxID);

	logInfo("fSendGRrequest After Twiddle ");
        logDebug3("sendGRreq    TimeStamp       :%d:",pGRSign->pHeader.iLogTimeStamp);
        logDebug3("sendGRreq    Error Code      :%d:",pGRSign->pHeader.iErrorCode);
        logDebug3("sendGRreq    Mesg Length     :%d:",pGRSign->pHeader.iMsgLength);
        logDebug3("sendGRreq    iTraderID       :%d:",pGRSign->pHeader.iTraderID);
        logDebug3("sendGRreq    sAlphaSplit     :%s:",pGRSign->pHeader.sAlphaSplit);
	logDebug3("sendGRreq    sTimeStamp1     :%s:",pGRSign->pHeader.sTimeStamp1);
        logDebug3("sendGRreq    sTimeStamp2     :%s:",pGRSign->pHeader.sTimeStamp2);
        logDebug3("sendGRreq    sTimeStamp3     :%s:",pGRSign->pHeader.sTimeStamp3);
        logDebug3("sendGRreq    sBrokerID       :%s:",pGRSign->sBrokerID);
        logDebug3("sendGRreq    iBoxID          :%d:",pGRSign->iBoxID);

	memcpy(sSendnnf,pGRSign,sizeof(struct NNF_GR_REQUEST));
        free(pGRSign);
        logTimestamp("Exit : fSendGRrequest");
        return TRUE;

}


BOOL	RecvGRresp(CHAR	*sTempData)
{
	logTimestamp("Entry : RecvGRresp");

	LONG32  iDatasent;
//	LONG32	iGRsockFd;

	struct NNF_GR_RESP	*pRecv;

	pRecv = (struct NNF_GR_RESP	*)malloc(sizeof(struct NNF_GR_RESP));
        memset((CHAR *)pRecv,' ',sizeof(struct NNF_GR_RESP));
        memcpy(pRecv,sTempData,sizeof(struct NNF_GR_RESP));

	CHAR    sQuery [MAX_QUERY_SIZE];
	
	memset(sQuery,'\0',MAX_QUERY_SIZE);
	CHAR	sErrorStr[DB_REASON_DESC_LEN];
	memset(sErrorStr,'\0',DB_REASON_DESC_LEN);

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	logInfo("This RecvGRresp Before Twiddle ");
        logDebug3("RecvGRresp: iMsgCode		:%d: ",pRecv->pHeader.iMsgCode);
        logDebug3("RecvGRresp: iLogTimeStamp	:%d: ",pRecv->pHeader.iLogTimeStamp);
        logDebug3("RecvGRresp: sAlphaSplit	:%s: ",pRecv->pHeader.sAlphaSplit);
        logDebug3("RecvGRresp: iTraderID	:%d: ",pRecv->pHeader.iTraderID);
        logDebug3("RecvGRresp: iErrorCode	:%d: ",pRecv->pHeader.iErrorCode);
        logDebug3("RecvGRresp: sTimeStamp1	:%s: ",pRecv->pHeader.sTimeStamp1);
        logDebug3("RecvGRresp: sTimeStamp2	:%s: ",pRecv->pHeader.sTimeStamp2);
        logDebug3("RecvGRresp: sTimeStamp3	:%s: ",pRecv->pHeader.sTimeStamp3);
        logDebug3("RecvGRresp: iMsgLength	:%d: ",pRecv->pHeader.iMsgLength);

        logDebug3("RecvGRresp: iBoxID   	:%d: ",pRecv->iBoxID);
        logDebug3("RecvGRresp: sBrokerID        :%s: ",pRecv->sBrokerID);
        logDebug3("RecvGRresp: sHostIP          :%s: ",pRecv->sHostIP);
        logDebug3("RecvGRresp: iHostPort        :%d: ",pRecv->iHostPort);
        logDebug3("RecvGRresp: sSessionKey      :%s: ", pRecv->sSessionKey);
        logDebug3("RecvGRresp: iErrorCod      	:%d: ", pRecv->pHeader.iErrorCode);

	TWIDDLE( pRecv->pHeader.iLogTimeStamp);
        TWIDDLE( pRecv->pHeader.iMsgCode);
        TWIDDLE( pRecv->pHeader.iErrorCode);
        TWIDDLE( pRecv->pHeader.iMsgLength);

	TWIDDLE(pRecv->iBoxID);
	TWIDDLE(pRecv->iHostPort);

	logInfo("This RecvGRresp After Twiddle ");
        logDebug3("RecvGRresp: iMsgCode         :%d: ",pRecv->pHeader.iMsgCode);
        logDebug3("RecvGRresp: iLogTimeStamp    :%d: ",pRecv->pHeader.iLogTimeStamp);
        logDebug3("RecvGRresp: sAlphaSplit      :%s: ",pRecv->pHeader.sAlphaSplit);
        logDebug3("RecvGRresp: iTraderID        :%d: ",pRecv->pHeader.iTraderID);
        logDebug3("RecvGRresp: iErrorCode       :%d: ",pRecv->pHeader.iErrorCode);
        logDebug3("RecvGRresp: sTimeStamp1      :%s: ",pRecv->pHeader.sTimeStamp1);
        logDebug3("RecvGRresp: sTimeStamp2      :%s: ",pRecv->pHeader.sTimeStamp2);
        logDebug3("RecvGRresp: sTimeStamp3      :%s: ",pRecv->pHeader.sTimeStamp3);
        logDebug3("RecvGRresp: iMsgLength       :%d: ",pRecv->pHeader.iMsgLength);

        logDebug3("RecvGRresp: iErrorCode      :%d: ", pRecv->pHeader.iErrorCode);
	logDebug3("RecvGRresp: iBoxID          :%d: ",pRecv->iBoxID);
        logDebug3("RecvGRresp: iHostPort       :%d: ",pRecv->iHostPort);
        logDebug3("RecvGRresp: sBrokerID       :%s: ",pRecv->sBrokerID);
        logDebug3("RecvGRresp: sHostIP         :%s: ",pRecv->sHostIP);
        logDebug3("RecvGRresp: sSessionKey     :%s: ", pRecv->sSessionKey);

//	sprintf(sQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET ");

	memset(sSessionKey,' ',NNF_SESSION_KEY_LEN);
	strncpy(sSessionKey,pRecv->sSessionKey,NNF_SESSION_KEY_LEN);
	if(pRecv->pHeader.iErrorCode == 0)
	{

	//	sleep(120);

		iGrSockFd = tcpDirConnection(pRecv->sHostIP,pRecv->iHostPort);	
		//iGrSockFd = tcpDirConnection("192.168.153.11",7601);
		logDebug2("Returning iGrsockFd :%d:",iGrSockFd);	
		return iGrSockFd;		
	}
	else
	{
		logFatal("GR req rejected with Error ID :%d:",pRecv->pHeader.iErrorCode);
		logInfo("Exiting Process here ");
		fFetchErrStr(pRecv->pHeader.iErrorCode,&sErrorStr);
		// Printing for monitoring purpose @NItish
		logTimestamp(":%s: GATEWAY ROUTER SIGNON RESPONSE FROM EXCHANGE WITH ERROR CODE :%s: ",KEY_WORD_MONITORING,sErrorStr);
		return ERROR;		
		//exit(ERROR);
	}

	logTimestamp("Exit : RecvGRresp");

}

BOOL    fSendBoxSignreq(CHAR *sSendnnf, LONG32 iGroupid,LONG32	iPrimarySecondary)
{
        logTimestamp("Entry : [fSendBoxSignreq]");

        struct  NNF_BOX_SIGNIN_REQUEST *pBoxSignReq;

        CHAR    *sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
        pBoxSignReq= (struct NNF_BOX_SIGNIN_REQUEST *)malloc(sizeof(struct NNF_BOX_SIGNIN_REQUEST));

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        memset((CHAR*)pBoxSignReq,' ',sizeof(struct NNF_BOX_SIGNIN_REQUEST));
        memcpy(pBoxSignReq,sSendnnf,sizeof(struct NNF_BOX_SIGNIN_REQUEST));

        pBoxSignReq->pHeader.iMsgCode = TC_EQU_NSE_BOX_SIGN_ON_REQ;
        pBoxSignReq->pHeader.iLogTimeStamp = 0 ;
        memset(pBoxSignReq->pHeader.sAlphaSplit,' ',2);
        memcpy(pBoxSignReq->pHeader.sAlphaSplit,"NT",2);
        pBoxSignReq->pHeader.iTraderID= 0;
	pBoxSignReq->pHeader.iErrorCode = 0 ;
	memset(pBoxSignReq->pHeader.sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
	memset(pBoxSignReq->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
	memset(pBoxSignReq->pHeader.sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
	memset(pBoxSignReq->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
	memset(pBoxSignReq->pHeader.sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
	memset(pBoxSignReq->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
        pBoxSignReq->pHeader.iMsgLength = sizeof(struct NNF_BOX_SIGNIN_REQUEST);
	pBoxSignReq->iBoxID =0 ;
	memset(pBoxSignReq->sBrokerID,'\0',BROKER_CODE_LENGTH);
        memset(pBoxSignReq->sBrokerID,' ',BROKER_CODE_LENGTH);
	memset(pBoxSignReq->sFiller1,'\0',5);
//        memset(pBoxSignReq->sFiller1,' ',5);
	memset(pBoxSignReq->sSessionKey,'\0',NNF_SESSION_KEY_LEN);
        memset(pBoxSignReq->sSessionKey,' ',NNF_SESSION_KEY_LEN);

        logDebug3("sizeof(struct NNF_BOX_SIGNIN_REQUEST) :%d:",sizeof(struct NNF_BOX_SIGNIN_REQUEST));
//1. Connection with primary or secondary Box id changes.New Column EAM_BOX_ID_SEC added  @Nitish
        sprintf(sQuery,"SELECT EAM_BROKER_ID,EAM_BOX_ID,EAM_EXCH_USER_ID,EAM_BOX_ID_SEC  FROM EXCH_ADMINISTRATION_MASTER \
                        WHERE EAM_GROUP_ID=%d  AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\'; ",iGroupid,NSE_EXCH,EQUITY_SEGMENT);

        logDebug2("sQuery :%s:",sQuery);
/**/
        if (mysql_query(DBConNNF, sQuery) != SUCCESS)
        {
                sql_Error(DBConNNF);
                return ERROR;
        }

        Res = mysql_store_result(DBConNNF);
/***/
        free(sQuery);
/***/
        while((Row = mysql_fetch_row(Res)))
        {
		pBoxSignReq->pHeader.iTraderID = atoi(Row[2]);
        //        pBoxSignReq->iBoxID= atoi(Row[1]);
        //        	// Printing for monitoring purpose @NItish
        	if(iPrimarySecondary == 0)
                {
                        logTimestamp(":%s: SENDING BOX SIGN IN  TO PRIMARY BOX :%s: ",KEY_WORD_MONITORING,Row[1]);
                        pBoxSignReq->iBoxID= atoi(Row[1]);
                }
                else
                {
                        logTimestamp(":%s: SENDING BOX SIGN IN TO SECONDARY BOX :%s: ",KEY_WORD_MONITORING,Row[3]);
                        pBoxSignReq->iBoxID= atoi(Row[3]);
                }
                strncpy(pBoxSignReq->sBrokerID,Row[0],BROKER_CODE_LENGTH);
        	strncpy(pBoxSignReq->sSessionKey,sSessionKey,NNF_SESSION_KEY_LEN);

        }
/***

	pBoxSignReq->pHeader.iTraderID= 90061 ;
        pBoxSignReq->iBoxID= 9527;//9462 First we used this
        strncpy(pBoxSignReq->sBrokerID,"90061",BROKER_CODE_LENGTH);
        strncpy(pBoxSignReq->sSessionKey,sSessionKey,NNF_SESSION_KEY_LEN);

****/	
	
	logInfo("*********************Before Twiddle*********************");
        logDebug3("sendBoxSignreq    	MsgCode		:%d:",pBoxSignReq->pHeader.iMsgCode);
        logDebug3("sendBoxSignreq    	TimeStamp       :%ld:",pBoxSignReq->pHeader.iLogTimeStamp);
        logDebug3("sendBoxSignreq	sAlphaSplit     :%s:",pBoxSignReq->pHeader.sAlphaSplit);
        logDebug3("sendBoxSignreq	iTraderID	:%d:",pBoxSignReq->pHeader.iTraderID);
        logDebug3("sendBoxSignreq	sTimeStamp1	:%s:",pBoxSignReq->pHeader.sTimeStamp1);
        logDebug3("sendBoxSignreq	sTimeStamp2	:%s:",pBoxSignReq->pHeader.sTimeStamp2);
        logDebug3("sendBoxSignreq	sTimeStamp3	:%s:",pBoxSignReq->pHeader.sTimeStamp3);
        logDebug3("sendBoxSignreq	Error Code      :%d:",pBoxSignReq->pHeader.iErrorCode);
        logDebug3("sendBoxSignreq	Mesg Length     :%d:",pBoxSignReq->pHeader.iMsgLength);

        logDebug3("sendBoxSignreq	iBoxID          :%d:",pBoxSignReq->iBoxID);
        logDebug3("sendBoxSignreq	sBrokerID       :%s:",pBoxSignReq->sBrokerID);
        logDebug3("sendBoxSignreq	sSessionKey	:%s:",pBoxSignReq->sSessionKey);
	logInfo("*********************Before Twiddle*********************");

        TWIDDLE( pBoxSignReq->pHeader.iLogTimeStamp);
        TWIDDLE( pBoxSignReq->pHeader.iMsgCode);
	TWIDDLE( pBoxSignReq->pHeader.iErrorCode);
        TWIDDLE( pBoxSignReq->pHeader.iMsgLength);
        TWIDDLE( pBoxSignReq->pHeader.iTraderID);
        TWIDDLE( pBoxSignReq->iBoxID);

	logInfo("*********************After Twiddle*********************");
	logDebug3("sendBoxSignreq       MsgCode         :%d:",pBoxSignReq->pHeader.iMsgCode);
        logDebug3("sendBoxSignreq       TimeStamp       :%ld:",pBoxSignReq->pHeader.iLogTimeStamp);
        logDebug3("sendBoxSignreq       sAlphaSplit     :%s:",pBoxSignReq->pHeader.sAlphaSplit);
        logDebug3("sendBoxSignreq       iTraderID       :%d:",pBoxSignReq->pHeader.iTraderID);
        logDebug3("sendBoxSignreq       sTimeStamp1     :%s:",pBoxSignReq->pHeader.sTimeStamp1);
        logDebug3("sendBoxSignreq       sTimeStamp2     :%s:",pBoxSignReq->pHeader.sTimeStamp2);
        logDebug3("sendBoxSignreq       sTimeStamp3     :%s:",pBoxSignReq->pHeader.sTimeStamp3);
        logDebug3("sendBoxSignreq       Error Code      :%d:",pBoxSignReq->pHeader.iErrorCode);
        logDebug3("sendBoxSignreq       Mesg Length     :%d:",pBoxSignReq->pHeader.iMsgLength);

        logDebug3("sendBoxSignreq       iBoxID          :%d:",pBoxSignReq->iBoxID);
        logDebug3("sendBoxSignreq       sBrokerID       :%s:",pBoxSignReq->sBrokerID);
        logDebug3("sendBoxSignreq       sSessionKey     :%s:",pBoxSignReq->sSessionKey);
	logInfo("*********************After Twiddle*********************");

        memcpy(sSendnnf,pBoxSignReq,sizeof(struct NNF_BOX_SIGNIN_REQUEST));
        free(pBoxSignReq);
        logTimestamp("Exit : fSendBoxSignreq");
        return TRUE;

}

BOOL    RecvBoxSignResp(CHAR *sTempData)
{
        logTimestamp("Entry : RecvBoxSignResp");

        LONG32  iDatasent;
//        LONG32  iGRsockFd;

        struct NNF_BOX_SIGNIN_RESPONSE	*pBoxResp;

        pBoxResp = (struct NNF_BOX_SIGNIN_RESPONSE *)malloc(sizeof(struct NNF_BOX_SIGNIN_RESPONSE));
        memset((CHAR *)pBoxResp,' ',sizeof(struct NNF_BOX_SIGNIN_RESPONSE));
        memcpy(pBoxResp,sTempData,sizeof(struct NNF_BOX_SIGNIN_RESPONSE));

        CHAR    sQuery [MAX_QUERY_SIZE];

        memset(sQuery,'\0',MAX_QUERY_SIZE);
	CHAR    sErrorStr[DB_REASON_DESC_LEN];
        memset(sErrorStr,'\0',DB_REASON_DESC_LEN);

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	logInfo("RecvBoxSignResp Before Twiddle ");
	logDebug3("RecvBoxSignResp: iMsgCode         :%d: ",pBoxResp->pHeader.iMsgCode);
        logDebug3("RecvBoxSignResp: iLogTimeStamp    :%d: ",pBoxResp->pHeader.iLogTimeStamp);
        logDebug3("RecvBoxSignResp: sAlphaSplit      :%s: ",pBoxResp->pHeader.sAlphaSplit);
        logDebug3("RecvBoxSignResp: iTraderID        :%d: ",pBoxResp->pHeader.iTraderID);
        logDebug3("RecvBoxSignResp: iErrorCode       :%d: ",pBoxResp->pHeader.iErrorCode);
        logDebug3("RecvBoxSignResp: sTimeStamp1      :%s: ",pBoxResp->pHeader.sTimeStamp1);
        logDebug3("RecvBoxSignResp: sTimeStamp2      :%s: ",pBoxResp->pHeader.sTimeStamp2);
        logDebug3("RecvBoxSignResp: sTimeStamp3      :%s: ",pBoxResp->pHeader.sTimeStamp3);
        logDebug3("RecvBoxSignResp: iMsgLength       :%d: ",pBoxResp->pHeader.iMsgLength);

        logDebug3("RecvBoxSignResp: iBoxID                 :%d: ",pBoxResp->iBoxID);

        TWIDDLE( pBoxResp->pHeader.iLogTimeStamp);
        TWIDDLE( pBoxResp->pHeader.iMsgCode);
        TWIDDLE( pBoxResp->pHeader.iErrorCode);
        TWIDDLE( pBoxResp->pHeader.iMsgLength);

        TWIDDLE(pBoxResp->iBoxID);
	
	logInfo("RecvBoxSignResp Before Twiddle ");
        logDebug3("RecvBoxSignResp: iMsgCode         :%d: ",pBoxResp->pHeader.iMsgCode);
        logDebug3("RecvBoxSignResp: iLogTimeStamp    :%d: ",pBoxResp->pHeader.iLogTimeStamp);
        logDebug3("RecvBoxSignResp: sAlphaSplit      :%s: ",pBoxResp->pHeader.sAlphaSplit);
        logDebug3("RecvBoxSignResp: iTraderID        :%d: ",pBoxResp->pHeader.iTraderID);
        logDebug3("RecvBoxSignResp: iErrorCode       :%d: ",pBoxResp->pHeader.iErrorCode);
        logDebug3("RecvBoxSignResp: sTimeStamp1      :%s: ",pBoxResp->pHeader.sTimeStamp1);
        logDebug3("RecvBoxSignResp: sTimeStamp2      :%s: ",pBoxResp->pHeader.sTimeStamp2);
        logDebug3("RecvBoxSignResp: sTimeStamp3      :%s: ",pBoxResp->pHeader.sTimeStamp3);
        logDebug3("RecvBoxSignResp: iMsgLength       :%d: ",pBoxResp->pHeader.iMsgLength);

        logDebug3("RecvBoxSignResp: iBoxID                 :%d: ",pBoxResp->iBoxID);
	
	if(pBoxResp->pHeader.iErrorCode != 0)
	{
		logFatal(" BOX Sign On pBoxResp->pHeader.iErrorCode :%d:",pBoxResp->pHeader.iErrorCode);
		fFetchErrStr(pBoxResp->pHeader.iErrorCode,&sErrorStr);
		// Printing for monitoring purpose @NItish
		logTimestamp(":%s: BOX SIGNON RESPONSE RECEIVE FROM EXCHANGE WITH ERROR :%s:",KEY_WORD_MONITORING,sErrorStr);
	//	exit(ERROR);
		return FALSE;
	}	
		
	logTimestamp("Exit : RecvBoxSignResp");

}

BOOL    fSendSignOff(CHAR *sSendnnf, LONG32 iGroupid)
{
        logTimestamp("Entry : [fSendSignOff]");

        struct  NNF_HEADER *pSignOff;
        CHAR    *sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
        pSignOff = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));

        memset((CHAR*)pSignOff,' ',sizeof(struct NNF_HEADER));
        memcpy(pSignOff,sSendnnf,sizeof(struct NNF_HEADER));	

	pSignOff->iMsgCode = TC_EQU_NSE_SIGN_OFF_REQ;
        pSignOff->iLogTimeStamp = 0 ;
        memset(pSignOff->sAlphaSplit,' ',2);
        memcpy(pSignOff->sAlphaSplit,"NT",2);
        pSignOff->iTraderID= iTmpTradeId;
        pSignOff->iErrorCode = 0 ;
        memset(pSignOff->sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
        memset(pSignOff->sTimeStamp1,' ',NNF_DATE_TIME_LEN);
        memset(pSignOff->sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
        memset(pSignOff->sTimeStamp2,' ',NNF_DATE_TIME_LEN);
        memset(pSignOff->sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
        memset(pSignOff->sTimeStamp3,' ',NNF_DATE_TIME_LEN);
        pSignOff->iMsgLength = sizeof(struct NNF_HEADER);
	
	logInfo("fSendSignOff Before Twiddle ");
        logDebug3("fSendSignOff: iMsgCode         :%d: ",pSignOff->iMsgCode);
        logDebug3("fSendSignOff: iLogTimeStamp    :%d: ",pSignOff->iLogTimeStamp);
        logDebug3("fSendSignOff: sAlphaSplit      :%s: ",pSignOff->sAlphaSplit);
        logDebug3("fSendSignOff: iTraderID        :%d: ",pSignOff->iTraderID);
        logDebug3("fSendSignOff: iErrorCode       :%d: ",pSignOff->iErrorCode);
        logDebug3("fSendSignOff: sTimeStamp1      :%s: ",pSignOff->sTimeStamp1);
        logDebug3("fSendSignOff: sTimeStamp2      :%s: ",pSignOff->sTimeStamp2);
        logDebug3("fSendSignOff: sTimeStamp3      :%s: ",pSignOff->sTimeStamp3);
        logDebug3("fSendSignOff: iMsgLength       :%d: ",pSignOff->iMsgLength);

	TWIDDLE( pSignOff->iLogTimeStamp);
        TWIDDLE( pSignOff->iMsgCode);
        TWIDDLE( pSignOff->iErrorCode);
        TWIDDLE( pSignOff->iMsgLength);
        TWIDDLE( pSignOff->iTraderID);

	logInfo("fSendSignOff After Twiddle ");
        logDebug3("fSendSignOff: iMsgCode         :%d: ",pSignOff->iMsgCode);
        logDebug3("fSendSignOff: iLogTimeStamp    :%d: ",pSignOff->iLogTimeStamp);
        logDebug3("fSendSignOff: sAlphaSplit      :%s: ",pSignOff->sAlphaSplit);
        logDebug3("fSendSignOff: iTraderID        :%d: ",pSignOff->iTraderID);
        logDebug3("fSendSignOff: iErrorCode       :%d: ",pSignOff->iErrorCode);
        logDebug3("fSendSignOff: sTimeStamp1      :%s: ",pSignOff->sTimeStamp1);
        logDebug3("fSendSignOff: sTimeStamp2      :%s: ",pSignOff->sTimeStamp2);
        logDebug3("fSendSignOff: sTimeStamp3      :%s: ",pSignOff->sTimeStamp3);
        logDebug3("fSendSignOff: iMsgLength       :%d: ",pSignOff->iMsgLength);

	memcpy(sSendnnf,pSignOff,sizeof(struct NNF_HEADER));
        free(pSignOff);

	logTimestamp("Exit : [fSendSignOff]");	
	return TRUE;	

}

BOOL    fFetchErrStr(LONG32	iErrorID,CHAR *sErrString)
{

        logTimestamp("Entry : fFetchErrStr");
        MYSQL_RES               *Res;
        MYSQL_ROW               Row;
        INT16   iNumRow;


        CHAR SelQuery [MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

        logDebug2(" fFetchErrStr iErrorID :%d:",iErrorID);

        sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \"%s\" AND RM_ERR_CODE = \"%d\" ;",NSE_EXCH,iErrorID);

        logDebug2("%s",SelQuery);
        if (mysql_query(DBConNNF, SelQuery) != SUCCESS)
        {
                logSqlFatal("Error in Select Serial No Query [Equproc_progN].");
                sql_Error(DBConNNF);
                return FALSE;
        }

        Res = mysql_store_result(DBConNNF);
        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);


        if(iNumRow != 0)
        {

                if((Row = mysql_fetch_row(Res)))
                {
                        logDebug2("serial no  :%s: ",Row[0]);
                        sprintf(sErrString,"EXCH:%d:%s:",iErrorID,Row[0]);

                }
        }
        else
        {
                sprintf(sErrString,"EXCH:%d:Not Specified in DB",DB_REASON_DESC_LEN);
                logDebug2("Error ID not Found in DB :%s:",sErrString);
		return FALSE;
        }

        logTimestamp("Exit : fFetchErrStr");
        return TRUE;
}

BOOL fNseCMOrdEntErrResp(CHAR *sOrderPck , CHAR *pOrdEntTMRsp)
{
        logTimestamp("Entry  fNseCMOrdEntErrResp");
        struct  NNF_ORDER_ENTRY_REQ_TM  *pDrvNNFTM = (struct  NNF_ORDER_ENTRY_REQ_TM  *)sOrderPck;
        struct  NNF_ORD_RESPONSE_TM *pOrdEntConfTMRsp = ( struct  NNF_ORD_RESPONSE_TM *) pOrdEntTMRsp ;

        TWIDDLE(pDrvNNFTM->iTradeID);
        TWIDDLE(pDrvNNFTM->iBookType);
        TWIDDLE(pDrvNNFTM->iBuyOrSell);
        TWIDDLE(pDrvNNFTM->iDiscQty);
        TWIDDLE(pDrvNNFTM->iTotalQty);
        TWIDDLE(pDrvNNFTM->iPrice);
        TWIDDLE(pDrvNNFTM->iBranchId);
        TWIDDLE(pDrvNNFTM->iExcgUserId);
        TWIDDLE(pDrvNNFTM->iProCli);
        TWIDDLE(pDrvNNFTM->fUserInfo);
        TWIDDLE(pDrvNNFTM->iAlgoId);
        TWIDDLE(pDrvNNFTM->iReservFiller);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pDrvNNFTM->iTransCode);
        logDebug3("iTradeID     :%d:",pDrvNNFTM->iTradeID);
        logDebug3("sInstrumentName      :%s:",pDrvNNFTM->pSecInfo.sSymbol);
        logDebug3("iExpiryDate  :%d:",pDrvNNFTM->pSecInfo.sSeries);
        logDebug3("sAccCode     :%s:",pDrvNNFTM->sAccCode);
        logDebug3("iBookType    :%d:",pDrvNNFTM->iBookType);
        logDebug3("iBuyOrSell   :%d:",pDrvNNFTM->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pDrvNNFTM->iDiscQty);
        logDebug3("iTotalQty    :%d:",pDrvNNFTM->iTotalQty);
        logDebug3("iPrice       :%d:",pDrvNNFTM->iPrice);
        logDebug3("iBranchId    :%d:",pDrvNNFTM->iBranchId);
        logDebug3("iExcgUserId  :%d:",pDrvNNFTM->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pDrvNNFTM->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pDrvNNFTM->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pDrvNNFTM->sSettlor);
        logDebug3("iProCli      :%d:",pDrvNNFTM->iProCli);
        logDebug3("fUserInfo    :%lf:",pDrvNNFTM->fUserInfo);
        logDebug3("sPanId       :%s:",pDrvNNFTM->sPanId);
        logDebug3("iAlgoId      :%d:",pDrvNNFTM->iAlgoId);
        logDebug3("iReservFiller        :%d:",pDrvNNFTM->iReservFiller);
        logDebug3("MFTerm       :%d:",pDrvNNFTM->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pDrvNNFTM->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pDrvNNFTM->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pDrvNNFTM->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pDrvNNFTM->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pDrvNNFTM->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pDrvNNFTM->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pDrvNNFTM->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pDrvNNFTM->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pDrvNNFTM->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pDrvNNFTM->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pDrvNNFTM->pOrderTerms.MatchedInd);

        pOrdEntConfTMRsp->iTransCode    = TC_EQU_NSE_ORD_ENT_ERR_RSP_TM ;
        pOrdEntConfTMRsp->iLogTime      = 0;
        pOrdEntConfTMRsp->iUserID       = pDrvNNFTM->iExcgUserId ;
        pOrdEntConfTMRsp->iErrorCode    = EXCHANGE_DOWN_ERROR;
        pOrdEntConfTMRsp->fTimeStamp1= 0;
        pOrdEntConfTMRsp->cTimeStamp2= 0;
        pOrdEntConfTMRsp->cModCanBy= MOD_CAN_CODE_FOR_DEALER;
        pOrdEntConfTMRsp->iReasonCode   = EXCHANGE_DOWN_ERROR;
        pOrdEntConfTMRsp->fOrderNum = 0 ;
        strncpy(pOrdEntConfTMRsp->sAccCode,pDrvNNFTM->sAccCode,ACCOUNT_CODE_LEN);
        pOrdEntConfTMRsp->iBookType = pDrvNNFTM->iBookType ;
        pOrdEntConfTMRsp->iBuyOrSell = pDrvNNFTM->iBuyOrSell ;
        pOrdEntConfTMRsp->iDiscQty = pDrvNNFTM->iDiscQty ;
        pOrdEntConfTMRsp->iDiscQtyRemaining = pDrvNNFTM->iDiscQty ;
        pOrdEntConfTMRsp->iTotalQtyRemaining = pDrvNNFTM->iTotalQty ;
        pOrdEntConfTMRsp->iTotalQty = pDrvNNFTM->iTotalQty ;
        pOrdEntConfTMRsp->iQtyFilledToday = 0 ;
        pOrdEntConfTMRsp->iPrice = pDrvNNFTM->iPrice ;
        pOrdEntConfTMRsp->iEntryTime= 1259513131;
        pOrdEntConfTMRsp->iLastModifiedTime= 1259513131;
        pOrdEntConfTMRsp->pOrderTerms.ATO = pDrvNNFTM->pOrderTerms.ATO ;
        pOrdEntConfTMRsp->pOrderTerms.Market = pDrvNNFTM->pOrderTerms.Market ;
        pOrdEntConfTMRsp->pOrderTerms.StopLossTerm = pDrvNNFTM->pOrderTerms.StopLossTerm ;
        pOrdEntConfTMRsp->pOrderTerms.DayTerm = pDrvNNFTM->pOrderTerms.DayTerm ;
        pOrdEntConfTMRsp->pOrderTerms.GTCTerm = pDrvNNFTM->pOrderTerms.GTCTerm ;
        pOrdEntConfTMRsp->pOrderTerms.IOCTerm = pDrvNNFTM->pOrderTerms.IOCTerm ;
        pOrdEntConfTMRsp->pOrderTerms.AONTerm = pDrvNNFTM->pOrderTerms.AONTerm ;
        pOrdEntConfTMRsp->pOrderTerms.MFTerm = pDrvNNFTM->pOrderTerms.MFTerm ;
        pOrdEntConfTMRsp->pOrderTerms.MatchedInd = pDrvNNFTM->pOrderTerms.MatchedInd ;
        pOrdEntConfTMRsp->pOrderTerms.Traded = pDrvNNFTM->pOrderTerms.Traded ;
        pOrdEntConfTMRsp->pOrderTerms.Modified = pDrvNNFTM->pOrderTerms.Modified ;
        pOrdEntConfTMRsp->pOrderTerms.Frozen = pDrvNNFTM->pOrderTerms.Frozen ;
        pOrdEntConfTMRsp->iBranchId = pDrvNNFTM->iBranchId ;
        pOrdEntConfTMRsp->iExcgUserId = pDrvNNFTM->iExcgUserId ;
        strncpy(pOrdEntConfTMRsp->sBrokerCode,pDrvNNFTM->sBrokerCode,BROKER_CODE_LENGTH);
        pOrdEntConfTMRsp->cSecSuspInd= 'C';
        pOrdEntConfTMRsp->cSecSuspInd = pDrvNNFTM->cSecSuspInd ;
        strncpy(pOrdEntConfTMRsp->sSettlor,pDrvNNFTM->sSettlor,NNF_SETTLOR_LEN);
        pOrdEntConfTMRsp->iProCli = pDrvNNFTM->iProCli ;
        pOrdEntConfTMRsp->fUserInfo = pDrvNNFTM->fUserInfo ;
        pOrdEntConfTMRsp->pExchRsrvdFlds=pDrvNNFTM->pExchRsrvdFlds ;
        strncpy(pOrdEntConfTMRsp->sPanId,pDrvNNFTM->sPanId,NNF_PAN_NUM_LEN);
        pOrdEntConfTMRsp->iAlgoId = pDrvNNFTM->iAlgoId ;
        pOrdEntConfTMRsp->iReservedFill = pDrvNNFTM->iReservFiller ;
        pOrdEntConfTMRsp->iLastActiRef= 0;

        logDebug2(" Before twiddle pOrdEntConfTMRsp->iTransCode :%d:",pOrdEntConfTMRsp->iTransCode);
        TWIDDLE(pOrdEntConfTMRsp->iTransCode);
        TWIDDLE(pOrdEntConfTMRsp->iErrorCode);
        TWIDDLE(pOrdEntConfTMRsp->iReasonCode);
        TWIDDLE(pOrdEntConfTMRsp->iBookType);
        TWIDDLE(pOrdEntConfTMRsp->iBuyOrSell);
        TWIDDLE(pOrdEntConfTMRsp->iDiscQty);
        TWIDDLE(pOrdEntConfTMRsp->iTotalQty);
        TWIDDLE(pOrdEntConfTMRsp->iTotalQtyRemaining);
        TWIDDLE(pOrdEntConfTMRsp->iPrice);
        TWIDDLE(pOrdEntConfTMRsp->iBranchId);
        TWIDDLE(pOrdEntConfTMRsp->iExcgUserId);
        TWIDDLE(pOrdEntConfTMRsp->iProCli);
        TWIDDLE(pOrdEntConfTMRsp->fUserInfo);
        TWIDDLE(pOrdEntConfTMRsp->iAlgoId);

        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pOrdEntConfTMRsp->iTransCode);
        logDebug3("sAccCode     :%s:",pOrdEntConfTMRsp->sAccCode);
        logDebug3("iBookType    :%d:",pOrdEntConfTMRsp->iBookType);
        logDebug3("iBuyOrSell   :%d:",pOrdEntConfTMRsp->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pOrdEntConfTMRsp->iDiscQty);
        logDebug3("iTotalQty    :%d:",pOrdEntConfTMRsp->iTotalQty);
        logDebug3("iPrice       :%d:",pOrdEntConfTMRsp->iPrice);
        logDebug3("iBranchId    :%d:",pOrdEntConfTMRsp->iBranchId);
        logDebug3("iExcgUserId  :%d:",pOrdEntConfTMRsp->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pOrdEntConfTMRsp->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pOrdEntConfTMRsp->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pOrdEntConfTMRsp->sSettlor);
        logDebug3("iProCli      :%d:",pOrdEntConfTMRsp->iProCli);
        logDebug3("fUserInfo    :%lf:",pOrdEntConfTMRsp->fUserInfo);
        logDebug3("sPanId       :%s:",pOrdEntConfTMRsp->sPanId);
        logDebug3("iAlgoId      :%d:",pOrdEntConfTMRsp->iAlgoId);
        logDebug3("iReservFiller        :%d:",pOrdEntConfTMRsp->iReservedFill);
        logDebug3("MFTerm       :%d:",pOrdEntConfTMRsp->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pOrdEntConfTMRsp->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pOrdEntConfTMRsp->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pOrdEntConfTMRsp->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pOrdEntConfTMRsp->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pOrdEntConfTMRsp->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pOrdEntConfTMRsp->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pOrdEntConfTMRsp->pOrderTerms.MatchedInd);

        memcpy(pOrdEntTMRsp ,( CHAR *) pOrdEntConfTMRsp,sizeof(struct NNF_ORD_RESPONSE_TM));
        logTimestamp("Exit  fNseCMOrdEntErrResp");
                                                                                        
}

BOOL fNseCMOrdModErrResp(CHAR *sOrderPck , CHAR *pOrdModTMRsp)
{
        logTimestamp("Entry  fNseCMOrdModErrResp");
        struct  NNF_ORD_MOD_CAN_REQ_TM *pDrvNNFTM = (struct  NNF_ORD_MOD_CAN_REQ_TM *)sOrderPck;
        struct  NNF_ORD_RESPONSE_TM *pOrdModConfTMRsp = ( struct  NNF_ORD_RESPONSE_TM *) pOrdModTMRsp ;

        TWIDDLE(pDrvNNFTM->iBookType);
        TWIDDLE(pDrvNNFTM->iBuyOrSell);
        TWIDDLE(pDrvNNFTM->iDiscQty);
        TWIDDLE(pDrvNNFTM->iTotalQty);
        TWIDDLE(pDrvNNFTM->iPrice);
        TWIDDLE(pDrvNNFTM->iBranchId);
        TWIDDLE(pDrvNNFTM->iExcgUserId);
        TWIDDLE(pDrvNNFTM->iProCli);
        TWIDDLE(pDrvNNFTM->fUserInfo);
        TWIDDLE(pDrvNNFTM->iAlgoId);
        TWIDDLE(pDrvNNFTM->iReservdFiller1);
	TWIDDLE(pDrvNNFTM->iEntryTime);
	TWIDDLE(pDrvNNFTM->iLastModifiedTime);
	TWIDDLE(pDrvNNFTM->fOrderNum);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pDrvNNFTM->iTransCode);
        logDebug3("sAccCode     :%s:",pDrvNNFTM->sAccCode);
        logDebug3("iBookType    :%d:",pDrvNNFTM->iBookType);
        logDebug3("iBuyOrSell   :%d:",pDrvNNFTM->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pDrvNNFTM->iDiscQty);
        logDebug3("iTotalQty    :%d:",pDrvNNFTM->iTotalQty);
        logDebug3("iPrice       :%d:",pDrvNNFTM->iPrice);
        logDebug3("iBranchId    :%d:",pDrvNNFTM->iBranchId);
        logDebug3("iExcgUserId  :%d:",pDrvNNFTM->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pDrvNNFTM->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pDrvNNFTM->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pDrvNNFTM->sSettlor);
        logDebug3("iProCli      :%d:",pDrvNNFTM->iProCli);
        logDebug3("fUserInfo    :%lf:",pDrvNNFTM->fUserInfo);
        logDebug3("sPanId       :%s:",pDrvNNFTM->sPanId);
        logDebug3("iAlgoId      :%d:",pDrvNNFTM->iAlgoId);
        logDebug3("iReservdFiller1:%d:",pDrvNNFTM->iReservdFiller1);
        logDebug3("MFTerm       :%d:",pDrvNNFTM->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pDrvNNFTM->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pDrvNNFTM->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pDrvNNFTM->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pDrvNNFTM->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pDrvNNFTM->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pDrvNNFTM->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pDrvNNFTM->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pDrvNNFTM->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pDrvNNFTM->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pDrvNNFTM->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pDrvNNFTM->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pDrvNNFTM->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pDrvNNFTM->iLastModifiedTime);
	logDebug3("fOrderNum :%lf:",pDrvNNFTM->fOrderNum);

        pOrdModConfTMRsp->iTransCode    = TC_EQU_NSE_ORD_MOD_ERR_RSP_TM;
        pOrdModConfTMRsp->iLogTime      = 0;
        pOrdModConfTMRsp->iUserID       = pDrvNNFTM->iExcgUserId ;
        pOrdModConfTMRsp->iErrorCode    = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->fTimeStamp1= 0;
        pOrdModConfTMRsp->cTimeStamp2= 0;
        pOrdModConfTMRsp->cModCanBy= MOD_CAN_CODE_FOR_DEALER;
        pOrdModConfTMRsp->iReasonCode   = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->fOrderNum = 0 ;
        strncpy(pOrdModConfTMRsp->sAccCode,pDrvNNFTM->sAccCode,ACCOUNT_CODE_LEN);
        pOrdModConfTMRsp->iBookType = pDrvNNFTM->iBookType ;
        pOrdModConfTMRsp->iBuyOrSell = pDrvNNFTM->iBuyOrSell ;
        pOrdModConfTMRsp->iDiscQty = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iDiscQtyRemaining = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iTotalQtyRemaining = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iTotalQty = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iQtyFilledToday = 0 ;
        pOrdModConfTMRsp->iPrice = pDrvNNFTM->iPrice ;
	pOrdModConfTMRsp->iEntryTime= pDrvNNFTM->iEntryTime;
	pOrdModConfTMRsp->iLastModifiedTime= pDrvNNFTM->iLastModifiedTime;
        pOrdModConfTMRsp->pOrderTerms.ATO = pDrvNNFTM->pOrderTerms.ATO ;
        pOrdModConfTMRsp->pOrderTerms.Market = pDrvNNFTM->pOrderTerms.Market ;
        pOrdModConfTMRsp->pOrderTerms.StopLossTerm = pDrvNNFTM->pOrderTerms.StopLossTerm ;
        pOrdModConfTMRsp->pOrderTerms.DayTerm = pDrvNNFTM->pOrderTerms.DayTerm ;
        pOrdModConfTMRsp->pOrderTerms.GTCTerm = pDrvNNFTM->pOrderTerms.GTCTerm ;
        pOrdModConfTMRsp->pOrderTerms.IOCTerm = pDrvNNFTM->pOrderTerms.IOCTerm ;
        pOrdModConfTMRsp->pOrderTerms.AONTerm = pDrvNNFTM->pOrderTerms.AONTerm ;
        pOrdModConfTMRsp->pOrderTerms.MFTerm = pDrvNNFTM->pOrderTerms.MFTerm ;
        pOrdModConfTMRsp->pOrderTerms.MatchedInd = pDrvNNFTM->pOrderTerms.MatchedInd ;
        pOrdModConfTMRsp->pOrderTerms.Traded = pDrvNNFTM->pOrderTerms.Traded ;
        pOrdModConfTMRsp->pOrderTerms.Modified = pDrvNNFTM->pOrderTerms.Modified ;
        pOrdModConfTMRsp->pOrderTerms.Frozen = pDrvNNFTM->pOrderTerms.Frozen ;
        pOrdModConfTMRsp->iBranchId = pDrvNNFTM->iBranchId ;
        pOrdModConfTMRsp->iExcgUserId = pDrvNNFTM->iExcgUserId ;
        strncpy(pOrdModConfTMRsp->sBrokerCode,pDrvNNFTM->sBrokerCode,BROKER_CODE_LENGTH);
        pOrdModConfTMRsp->cSecSuspInd= 'C';
        pOrdModConfTMRsp->cSecSuspInd = pDrvNNFTM->cSecSuspInd ;
        strncpy(pOrdModConfTMRsp->sSettlor,pDrvNNFTM->sSettlor,NNF_SETTLOR_LEN);
        pOrdModConfTMRsp->iProCli = pDrvNNFTM->iProCli ;
        pOrdModConfTMRsp->fUserInfo = pDrvNNFTM->fUserInfo ;
        pOrdModConfTMRsp->pExchRsrvdFlds=pDrvNNFTM->pExchRsrvdFlds ;
        strncpy(pOrdModConfTMRsp->sPanId,pDrvNNFTM->sPanId,NNF_PAN_NUM_LEN);
        pOrdModConfTMRsp->iAlgoId = pDrvNNFTM->iAlgoId ;
        pOrdModConfTMRsp->iReservedFill = pDrvNNFTM->iReservdFiller1;
        pOrdModConfTMRsp->iLastActiRef= 0;
        pOrdModConfTMRsp->fOrderNum = pDrvNNFTM->fOrderNum;

        logDebug2(" Before twiddle pOrdModConfTMRsp->iTransCode :%d:",pOrdModConfTMRsp->iTransCode);
        TWIDDLE(pOrdModConfTMRsp->iTransCode);
        TWIDDLE(pOrdModConfTMRsp->iErrorCode);
        TWIDDLE(pOrdModConfTMRsp->iReasonCode);
        TWIDDLE(pOrdModConfTMRsp->iBookType);
        TWIDDLE(pOrdModConfTMRsp->iBuyOrSell);
        TWIDDLE(pOrdModConfTMRsp->iDiscQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQtyRemaining);
        TWIDDLE(pOrdModConfTMRsp->iPrice);
        TWIDDLE(pOrdModConfTMRsp->iBranchId);
        TWIDDLE(pOrdModConfTMRsp->iExcgUserId);
        TWIDDLE(pOrdModConfTMRsp->iProCli);
        TWIDDLE(pOrdModConfTMRsp->fUserInfo);
        TWIDDLE(pOrdModConfTMRsp->iAlgoId);
	TWIDDLE(pOrdModConfTMRsp->iEntryTime);
	TWIDDLE(pOrdModConfTMRsp->iLastModifiedTime);
	TWIDDLE(pOrdModConfTMRsp->fOrderNum);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pOrdModConfTMRsp->iTransCode);
        logDebug3("sAccCode     :%s:",pOrdModConfTMRsp->sAccCode);
        logDebug3("iBookType    :%d:",pOrdModConfTMRsp->iBookType);
        logDebug3("iBuyOrSell   :%d:",pOrdModConfTMRsp->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pOrdModConfTMRsp->iDiscQty);
        logDebug3("iTotalQty    :%d:",pOrdModConfTMRsp->iTotalQty);
        logDebug3("iPrice       :%d:",pOrdModConfTMRsp->iPrice);
        logDebug3("iBranchId    :%d:",pOrdModConfTMRsp->iBranchId);
        logDebug3("iExcgUserId  :%d:",pOrdModConfTMRsp->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pOrdModConfTMRsp->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pOrdModConfTMRsp->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pOrdModConfTMRsp->sSettlor);
        logDebug3("iProCli      :%d:",pOrdModConfTMRsp->iProCli);
        logDebug3("fUserInfo    :%lf:",pOrdModConfTMRsp->fUserInfo);
        logDebug3("sPanId       :%s:",pOrdModConfTMRsp->sPanId);
        logDebug3("iAlgoId      :%d:",pOrdModConfTMRsp->iAlgoId);
        logDebug3("iReservdFiller1:%d:",pOrdModConfTMRsp->iReservedFill);
        logDebug3("MFTerm       :%d:",pOrdModConfTMRsp->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pOrdModConfTMRsp->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pOrdModConfTMRsp->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pOrdModConfTMRsp->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pOrdModConfTMRsp->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pOrdModConfTMRsp->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pOrdModConfTMRsp->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pOrdModConfTMRsp->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pOrdModConfTMRsp->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pOrdModConfTMRsp->iLastModifiedTime);
	logDebug3("fOrderNum :%lf:",pOrdModConfTMRsp->fOrderNum);

        memcpy(pOrdModTMRsp ,( CHAR *) pOrdModConfTMRsp,sizeof(struct NNF_ORD_RESPONSE_TM));
        logTimestamp("Exit  fNseCMOrdModErrResp");
}

BOOL fNseCMOrdCanErrResp(CHAR *sOrderPck , CHAR *pOrdModTMRsp)
{
        logTimestamp("Entry  fNseCMOrdCanErrResp");
        struct  NNF_ORD_MOD_CAN_REQ_TM *pDrvNNFTM = (struct  NNF_ORD_MOD_CAN_REQ_TM *)sOrderPck;
        struct  NNF_ORD_RESPONSE_TM *pOrdModConfTMRsp = ( struct  NNF_ORD_RESPONSE_TM *) pOrdModTMRsp ;

        TWIDDLE(pDrvNNFTM->iBookType);
        TWIDDLE(pDrvNNFTM->iBuyOrSell);
        TWIDDLE(pDrvNNFTM->iDiscQty);
        TWIDDLE(pDrvNNFTM->iTotalQty);
        TWIDDLE(pDrvNNFTM->iPrice);
        TWIDDLE(pDrvNNFTM->iBranchId);
        TWIDDLE(pDrvNNFTM->iExcgUserId);
        TWIDDLE(pDrvNNFTM->iProCli);
        TWIDDLE(pDrvNNFTM->fUserInfo);
        TWIDDLE(pDrvNNFTM->iAlgoId);
        TWIDDLE(pDrvNNFTM->iReservdFiller1);
	TWIDDLE(pDrvNNFTM->iEntryTime);
	TWIDDLE(pDrvNNFTM->iLastModifiedTime);
	TWIDDLE(pDrvNNFTM->fOrderNum);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pDrvNNFTM->iTransCode);
        logDebug3("sAccCode     :%s:",pDrvNNFTM->sAccCode);
        logDebug3("iBookType    :%d:",pDrvNNFTM->iBookType);
        logDebug3("iBuyOrSell   :%d:",pDrvNNFTM->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pDrvNNFTM->iDiscQty);
        logDebug3("iTotalQty    :%d:",pDrvNNFTM->iTotalQty);
        logDebug3("iPrice       :%d:",pDrvNNFTM->iPrice);
        logDebug3("iBranchId    :%d:",pDrvNNFTM->iBranchId);
        logDebug3("iExcgUserId  :%d:",pDrvNNFTM->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pDrvNNFTM->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pDrvNNFTM->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pDrvNNFTM->sSettlor);
        logDebug3("iProCli      :%d:",pDrvNNFTM->iProCli);
        logDebug3("fUserInfo    :%lf:",pDrvNNFTM->fUserInfo);
        logDebug3("sPanId       :%s:",pDrvNNFTM->sPanId);
        logDebug3("iAlgoId      :%d:",pDrvNNFTM->iAlgoId);
        logDebug3("iReservdFiller1 :%d:",pDrvNNFTM->iReservdFiller1);
        logDebug3("MFTerm       :%d:",pDrvNNFTM->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pDrvNNFTM->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pDrvNNFTM->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pDrvNNFTM->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pDrvNNFTM->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pDrvNNFTM->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pDrvNNFTM->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pDrvNNFTM->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pDrvNNFTM->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pDrvNNFTM->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pDrvNNFTM->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pDrvNNFTM->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pDrvNNFTM->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pDrvNNFTM->iLastModifiedTime);
	logDebug3("fOrderNum :%lf:",pDrvNNFTM->fOrderNum);

        pOrdModConfTMRsp->iTransCode    = TC_EQU_NSE_ORD_CAN_ERR_RSP_TM;
        pOrdModConfTMRsp->iLogTime      = 0;
        pOrdModConfTMRsp->iUserID       = pDrvNNFTM->iExcgUserId ;
        pOrdModConfTMRsp->iErrorCode    = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->fTimeStamp1= 0;
        pOrdModConfTMRsp->cTimeStamp2= 0;
        pOrdModConfTMRsp->cModCanBy= MOD_CAN_CODE_FOR_DEALER;
        pOrdModConfTMRsp->iReasonCode   = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->fOrderNum = 0 ;
        strncpy(pOrdModConfTMRsp->sAccCode,pDrvNNFTM->sAccCode,ACCOUNT_CODE_LEN);
        pOrdModConfTMRsp->iBookType = pDrvNNFTM->iBookType ;
        pOrdModConfTMRsp->iBuyOrSell = pDrvNNFTM->iBuyOrSell ;
        pOrdModConfTMRsp->iDiscQty = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iDiscQtyRemaining = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iTotalQtyRemaining = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iTotalQty = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iQtyFilledToday = 0 ;
        pOrdModConfTMRsp->iPrice = pDrvNNFTM->iPrice ;
	pOrdModConfTMRsp->iEntryTime= pDrvNNFTM->iEntryTime;
	pOrdModConfTMRsp->iLastModifiedTime= pDrvNNFTM->iLastModifiedTime;
        pOrdModConfTMRsp->pOrderTerms.ATO = pDrvNNFTM->pOrderTerms.ATO ;
        pOrdModConfTMRsp->pOrderTerms.Market = pDrvNNFTM->pOrderTerms.Market ;
        pOrdModConfTMRsp->pOrderTerms.StopLossTerm = pDrvNNFTM->pOrderTerms.StopLossTerm ;
        pOrdModConfTMRsp->pOrderTerms.DayTerm = pDrvNNFTM->pOrderTerms.DayTerm ;
        pOrdModConfTMRsp->pOrderTerms.GTCTerm = pDrvNNFTM->pOrderTerms.GTCTerm ;
        pOrdModConfTMRsp->pOrderTerms.IOCTerm = pDrvNNFTM->pOrderTerms.IOCTerm ;
        pOrdModConfTMRsp->pOrderTerms.AONTerm = pDrvNNFTM->pOrderTerms.AONTerm ;
        pOrdModConfTMRsp->pOrderTerms.MFTerm = pDrvNNFTM->pOrderTerms.MFTerm ;
        pOrdModConfTMRsp->pOrderTerms.MatchedInd = pDrvNNFTM->pOrderTerms.MatchedInd ;
        pOrdModConfTMRsp->pOrderTerms.Traded = pDrvNNFTM->pOrderTerms.Traded ;
        pOrdModConfTMRsp->pOrderTerms.Modified = pDrvNNFTM->pOrderTerms.Modified ;
        pOrdModConfTMRsp->pOrderTerms.Frozen = pDrvNNFTM->pOrderTerms.Frozen ;
        pOrdModConfTMRsp->iBranchId = pDrvNNFTM->iBranchId ;
        pOrdModConfTMRsp->iExcgUserId = pDrvNNFTM->iExcgUserId ;
        strncpy(pOrdModConfTMRsp->sBrokerCode,pDrvNNFTM->sBrokerCode,BROKER_CODE_LENGTH);
        pOrdModConfTMRsp->cSecSuspInd= 'C';
        pOrdModConfTMRsp->cSecSuspInd = pDrvNNFTM->cSecSuspInd ;
        strncpy(pOrdModConfTMRsp->sSettlor,pDrvNNFTM->sSettlor,NNF_SETTLOR_LEN);
        pOrdModConfTMRsp->iProCli = pDrvNNFTM->iProCli ;
        pOrdModConfTMRsp->fUserInfo = pDrvNNFTM->fUserInfo ;
        pOrdModConfTMRsp->pExchRsrvdFlds=pDrvNNFTM->pExchRsrvdFlds ;
        strncpy(pOrdModConfTMRsp->sPanId,pDrvNNFTM->sPanId,NNF_PAN_NUM_LEN);
        pOrdModConfTMRsp->iAlgoId = pDrvNNFTM->iAlgoId ;
        pOrdModConfTMRsp->iReservedFill = pDrvNNFTM->iReservdFiller1;
        pOrdModConfTMRsp->iLastActiRef= 0;
        pOrdModConfTMRsp->fOrderNum = pDrvNNFTM->fOrderNum;

        logDebug2(" Before twiddle pOrdModConfTMRsp->iTransCode :%d:",pOrdModConfTMRsp->iTransCode);
        TWIDDLE(pOrdModConfTMRsp->iTransCode);
        TWIDDLE(pOrdModConfTMRsp->iErrorCode);
        TWIDDLE(pOrdModConfTMRsp->iReasonCode);
        TWIDDLE(pOrdModConfTMRsp->iBookType);
        TWIDDLE(pOrdModConfTMRsp->iBuyOrSell);
        TWIDDLE(pOrdModConfTMRsp->iDiscQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQtyRemaining);
        TWIDDLE(pOrdModConfTMRsp->iPrice);
        TWIDDLE(pOrdModConfTMRsp->iBranchId);
        TWIDDLE(pOrdModConfTMRsp->iExcgUserId);
        TWIDDLE(pOrdModConfTMRsp->iProCli);
        TWIDDLE(pOrdModConfTMRsp->fUserInfo);
        TWIDDLE(pOrdModConfTMRsp->iAlgoId);
	TWIDDLE(pOrdModConfTMRsp->iEntryTime);
	TWIDDLE(pOrdModConfTMRsp->iLastModifiedTime);
	TWIDDLE(pOrdModConfTMRsp->fOrderNum);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pOrdModConfTMRsp->iTransCode);
        logDebug3("sAccCode     :%s:",pOrdModConfTMRsp->sAccCode);
        logDebug3("iBookType    :%d:",pOrdModConfTMRsp->iBookType);
        logDebug3("iBuyOrSell   :%d:",pOrdModConfTMRsp->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pOrdModConfTMRsp->iDiscQty);
        logDebug3("iTotalQty    :%d:",pOrdModConfTMRsp->iTotalQty);
        logDebug3("iPrice       :%d:",pOrdModConfTMRsp->iPrice);
        logDebug3("iBranchId    :%d:",pOrdModConfTMRsp->iBranchId);
        logDebug3("iExcgUserId  :%d:",pOrdModConfTMRsp->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pOrdModConfTMRsp->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pOrdModConfTMRsp->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pOrdModConfTMRsp->sSettlor);
        logDebug3("iProCli      :%d:",pOrdModConfTMRsp->iProCli);
        logDebug3("fUserInfo    :%lf:",pOrdModConfTMRsp->fUserInfo);
        logDebug3("sPanId       :%s:",pOrdModConfTMRsp->sPanId);
        logDebug3("iAlgoId      :%d:",pOrdModConfTMRsp->iAlgoId);
        logDebug3("iReservdFiller1 :%d:",pOrdModConfTMRsp->iReservedFill);
        logDebug3("MFTerm       :%d:",pOrdModConfTMRsp->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pOrdModConfTMRsp->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pOrdModConfTMRsp->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pOrdModConfTMRsp->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pOrdModConfTMRsp->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pOrdModConfTMRsp->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pOrdModConfTMRsp->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pOrdModConfTMRsp->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pOrdModConfTMRsp->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pOrdModConfTMRsp->iLastModifiedTime);
	logDebug3("fOrderNum :%lf:",pOrdModConfTMRsp->fOrderNum);

        memcpy(pOrdModTMRsp ,( CHAR *) pOrdModConfTMRsp,sizeof(struct NNF_ORD_RESPONSE_TM));
        logTimestamp("Exit fNseCMOrdCanErrResp");
}

