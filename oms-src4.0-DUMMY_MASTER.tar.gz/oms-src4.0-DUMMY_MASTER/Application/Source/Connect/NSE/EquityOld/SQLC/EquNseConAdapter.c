/****#include    "EquNseConnect.h"
#include "global.h"
#include "md5.h"
#include    "Queue.h"
#include    "Common.h"
#include    "Unix.h"*****/
#include "IPCS.h"
#include "NNFStruct.h"
#include <memory.h>
#include <time.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
void ConvertSeqNO(CHAR *, CHAR *);
#define 	CALLING_LENS	20
#define TWIDDLE(A)      Twiddle ((char *) &A, sizeof(A))
void   UpdateTimeStamp ( ) ;
void   Exit( int );
BOOL   fUpdateConnectStatus(SHORT,LONG32,LONG32,BOOL);
void   fInitSharedMemory(LONG32); 
LONG32 GlobGroupId;
key_t  GlobQueueId;
int    sockfd1;
int    ConnectToExchange =1;               
FILE *fpOrderNum;

SHORT ConnectionCounter=0;
SHORT CounterTotalInvite=0;
SHORT CounterTotalTransmit=0;

SHORT TotalStream = 0;  
LONG32 TransmitSeq =0, RecieveSeq =0 ; 

CHAR    sProgName[15] = "NseCMConnect";
MYSQL *DBConNNF;                                                  
#define RESET_EQU 1
#define SET_EQU 2
#define TAP 1
#define MAX_NO_UPDATE 100 
int mainwait = -1;
main( int argc, char **argv )
{

	int FailoverCounter=0; 
	int PrimarySecondary=0;
	int respchild,transchild,Invitationchild,Status,transkill = -1;
	int sig1 = 0,sig2 = 0; 
	int flag;
	int fla;
	int fl;
	int groupid ;
	int TapPort[2]; 
	char TapIp[2][CALLING_LENS];
	char ConnectOption[5];   
	int NSE_CONNECTED_STATUS = FALSE;
	int ConnectCode = 0;
	int dSeq_No = 0;
	int MaxPacketCount,invFlag = FALSE; 
	CHAR DummyChar;
	LONG32 Dummy;
	char ProgTime[40];
	memset(ProgTime,'\0',40);

	CHAR	RetCode[50];
	CHAR	RetString[50];
	CHAR	lvar_uid[30];
	LONG32 seqval;  

	sigset_t SequenceSet;  				/* Signal set containing SIGUSR1 , SIGUSR2 , SIGTERM */
	char *error;

	setbuf(stdout,NULL);
	setbuf(stderr,NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );    			/* Signal functions initialization */

	error = (char *)malloc(sizeof(char)*SIZE);

	GetTime(ProgTime);
	logTimestamp("--------------------------Started NSE EQ Connect-----------------------------------------------");

	if ( argc < 7 )
	{
		logTimestamp(" Invalid number of arguments");
		exit(ERROR);				
	}

	strcpy(ConnectOption,argv[1]);
	groupid = atoi(argv[2]);
	strcpy(TapIp[0],argv[3]); 
	TapPort[0] = atoi ( argv[4]); 
	strcpy(TapIp[1],argv[5]); 
	TapPort[1] = atoi ( argv[6]); 

	if(strncmp(ConnectOption,"EXCH", 4 )==0)
	{
		ConnectToExchange = 1;
	}
	else
	{
		ConnectToExchange = 0;
	}

	GlobGroupId = groupid ;
	if (( groupid <= 0 ) || (groupid > 4))
	{
		logError("NSE EQ Connect:  Wrong groupid ");                
		exit(ERROR);
	}

	logInfo("------------------- PARAMETERS PASSED ----------");
	logInfo("ConnectOption 				: [%s]", ConnectOption ) ;
	logInfo("Groupid is 					: [%d] ",groupid);
	logInfo("TapIp 					: [%s]", TapIp[0] ) ; 
	logInfo("TapIp Failover				: [%s]", TapIp[1] ) ; 
	logInfo("TapPort  					: [%d]", TapPort[0] ) ; 
	logInfo("TapPort Failover				: [%d]", TapPort[1] ) ; 
	logInfo("------------------------------------------------");

	/******		switch(groupid)
	  {
	  case 1 : GlobQueueId = EquRmsNseToNSE1;        
	  break;
	  case 2 : GlobQueueId = EquRmsNseToNSE2;
	  break;
	  case 3 : GlobQueueId = EquRmsNseToNSE3;
	  break;
	  case 4 : GlobQueueId = EquRmsNseToNSE4;
	  break;
	  default : break;
	  };******/

	GlobQueueId = OrdSrvToFwdMapNSEEQ;

	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGTERM);
	sigaddset ( &SequenceSet , SIGUSR1);


	/****	EXEC SQL CONNECT :lvar_uid ;****/
	/****		if ( sqlca.sqlcode != 0 )
	  {
	  printf ("\nEquNseConnect.pc Error in connecting to oracle %d",sqlca.sqlcode);	
	  GetTime(ProgTime);
	  printf("\nThe Process Ended at [%s] IST\n",ProgTime);
	  exit(ERROR);
	  }******/

	DBConNNF = DB_Connect();
	logInfo("Connection to DB SUCCESS......"); 



	fpOrderNum = fopen("../OrderNum.txt","a+" ) ;
	if( fpOrderNum == NULL )
	{
		logPError(" UNABLE TO OPEN FILE " ) ;
	}


	for ( ; ; )						
	{
		NSE_CONNECTED_STATUS = FALSE;
		signal(SIGPIPE,SIG_IGN);
		signal(SIGHUP,SIG_IGN);
		for ( ; ; )
		{
			fInitSharedMemory(groupid); /** Added for inv initialization **/
			sockfd1 =CONNECT( TapIp[PrimarySecondary] , TapPort[PrimarySecondary]  );
			if (sockfd1 <= 0 )
			{
				NSE_CONNECTED_STATUS = FALSE;
				memset(error,NULL,SIZE);
				strcpy(error,"FATAL ERROR .... NO SOCKET CONNECTION .... ");
				LogFatal("EquNseConAdapter.pc",error);
				send_exch_down_nse( groupid );
				sleep(2);
				PrimarySecondary=(PrimarySecondary==1)?0:1;
			}
			else
			{
				NSE_CONNECTED_STATUS =TRUE;
				flag=100000;
				fla=100000;
				fl=1;
				if (setsockopt( sockfd1 ,SOL_SOCKET,SO_RCVBUF,&flag,sizeof( flag ))<0)
				{
					printf("Error in setting socket option:SO_RCVBUF");
					return FALSE;
				}
				if (setsockopt( sockfd1 ,SOL_SOCKET,SO_SNDBUF,&flag,sizeof( flag ))<0)
				{
					printf("Error in setting socket option:SO_SNDBUF");
					return FALSE;
				}


				/*************** TAP Reg Changes*******************/  
				TransmitSeq =0; 
				RecieveSeq  =0;  	
				printf("\nSequence Number Transmit is [%d]", TransmitSeq);
				printf("\tSequence Number Recieve is [%d]", RecieveSeq); 
				/************ END of TAP Reg Changes*******************/

				GetTime(ProgTime);
				printf("\nBefore Calling HandleSignon at [%s] IST\n",ProgTime);

				if (HandleSignon(groupid) == TRUE)	
				{
					if ( (respchild = fork()) == 0 )
					{
						GetTime(ProgTime);
						printf("\nBefore Receive Packet at [%s] IST\n",ProgTime);
						ReceiveReplyPackets(sockfd1,groupid);
					}
					else if( ( transchild = fork() ) == 0 )
					{
						GetTime(ProgTime);
						printf("\nBefore Receive Packet at [%s] IST\n",ProgTime);
						TransmitRequestPackets(groupid);
					}	
					break;/*** break infinite for loop if signon true ***/	
				}
				else
				{
					close(sockfd1);
					printf("\n------------------------------------------- Signon problem ");
					printf("\nReconnect Attempt  [%d]---------------  ",ConnectionCounter); 
					GetTime(ProgTime);
					printf("\nThe Process Ended at [%s] IST\n",ProgTime);
					if( ConnectionCounter ==  2 )
					{       
						printf("\n\t Switch over to Fail over Server");
						ConnectionCounter = 0;	
						PrimarySecondary=(PrimarySecondary==1)?0:1;
						sleep(10); 	
					}	
					sleep(15);
				}
			} /**End of else **/

		} /**end of inner for loop **/		



		while( TRUE )
		{
			transkill = -1;
			sig1 = 0;
			sigemptyset ( &SequenceSet );
			sigaddset ( &SequenceSet , SIGTERM);
			sigaddset ( &SequenceSet , SIGUSR1);
			sigaddset ( &SequenceSet , SIGUSR2);
			sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);

			printf("\nWaiting for signal, in loop.");
#ifdef SOLARIS
			mainwait = sigwait( &SequenceSet);
			sig1 = mainwait ;
			printf("\n=============Recv Signal : %d, sig1:%d==============", mainwait , sig1 );
#else
			mainwait = sigwait( &SequenceSet, &sig1);
			printf("\n=============Recv Signal : %d, sig1:%d==============", mainwait , sig1 );
#endif 
			printf("\n==================Recv Signal : %d, sig1:%d==============", mainwait , sig1 );
			printf("\n================= sockfd1 [%d] ============= \n");
			close(sockfd1);	
			if (mainwait >= 0 && sig1 != SIGTERM)
			{
				printf("\nGot mainwait >= 0, sig1: %d", sig1 );
				transkill = kill(transchild,sig1);
				printf("\nReturn value from KILL : %d", transkill );
				transkill = kill(respchild,sig1);
				printf("\nReturn value from KILL : %d", transkill );
				perror ( "After kill to transchild: ");
				if (transkill < 0)
				{
					printf("\nEquNseConnect.pc Fatal error in sending signal %d\n",transkill);
					memset(error,NULL,SIZE);
					strcpy(error,strerror(errno));
					LogFatal("EquNseConnect.pc",error);
					exit(ERROR);
				}
			}	
			else if ( sig1 == SIGTERM )	
			{
				/****	EXEC SQL CONNECT :lvar_uid ;*****//**nitish***/
				/****	printf("\n************Error in Connecting: %d", sqlca.sqlcode );******/
				printf("\n starting fall over mechanism ");
				printf("\n  the group id is [%d] ", GlobGroupId );
				/****	EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
				  SET  EAM_LOGON_STATUS = 'N'
				  WHERE EAM_EXM_EXCH_ID = 'NSE'
				  AND EAM_DRV_FLAG = 'N'
				  AND EAM_GROUP_ID = to_char(:GlobGroupId);*****/

				/*******                        printf("nError in Updating: %d", sqlca.sqlcode );
				  EXEC SQL COMMIT;******/

				fUpdateConnectStatus(NSE_EQU_DOWN, GlobGroupId ,BCAST_YES,FALSE);
				send_exch_down_nse( GlobGroupId );
				printf("\n Databse and shared memory updated and broadcast sent ");
				kill(transchild,SIGKILL);
				kill(respchild,SIGKILL);
				sleep(3);
				waitpid(transchild,&Status,WNOHANG);
				waitpid(respchild,&Status,WNOHANG);
				break;
			}
			else if(sig1 == SIGCHLD)
			{
				printf("\n Killing Children ");
				kill(transchild,SIGKILL);/* To exit from the program b'coz of signal error */
				kill(respchild,SIGKILL);
				exit(ERROR);
			}
		}/** End of While loop ***/
	}	 /**End of for loop **/
	free(error);
	fclose(fpOrderNum);
}	/* End of main function */


int HandleSignon(int groupid)
{
	char   *sendsign;
	char   recvsign[NSE_PACKET_SIZE];
	int    sent_bytes,recv_bytes,log_result;
	LONG32 inv_flag = FALSE;
	CHAR   DummyChar;
	LONG32 Dummy;
	CHAR error[SIZE];
	CHAR Ferror[SIZE];
	int temp_code,temp_size,invFlag;
	int Seq_No;

	char *bdata;
	LONG32 blen;
	SHORT InvCount;
	char *sendsignTAP;

	sigset_t SequenceSet;

	LONG32 InvPacketCount;
	unsigned char digest[16];
	struct TAP_WRAPPER *tap_wrap;
	struct NNF_HEADER *header;
	struct INVITATION_PACKET *inv_packet;
	struct InvitationCount *invcount;
	char ProgTime[40];
	memset(ProgTime,'\0',40);
	INT16   iErrMsgCode;
	/******        varchar lvar_uid[30];
	  VARCHAR sConErrMsg[128];
	  INT16   iErrMsgCode;

	  memset(sConErrMsg.arr,'\0',128) ;
	  sConErrMsg.len=128;******/

	int sig1 = 0;
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGUSR1);
	sigaddset ( &SequenceSet , SIGUSR2);                /* Signal function Initialization */
	sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);

	sendsign = (char *)malloc(sizeof(struct NNF_SIGNON_REQ));
	tap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(tap_wrap,'\0',sizeof(struct TAP_WRAPPER));
	header = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
	memset(header,'\0',sizeof(struct NNF_HEADER));
	sendsignTAP = (char *)malloc(sizeof(struct NNF_SIGNON_REQ) + sizeof(struct TAP_WRAPPER));
	/*******
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=sizeof(lvar_uid.arr);

	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  memset(error,NULL,SIZE);
	  sprintf(error,"EquNseConAdapter.pc Error in connecting to oracle ");
	  LogFatal(&sProgName,error);
	  exit(ERROR);
	  }*******/
	logInfo("TRANSMIT CHILD Connction to Oracle SUCCESS......      ");

	printf("\nBefore Calling HandleInvitationPacket at ");
	if( !(HandleInvitationPacket(sockfd1,groupid))  )
	{
		ConnectionCounter++;
		printf("Received <=0 byte:closing TAP BOX Connection..\n");
		return FALSE;
	}
	printf("\nBefore Calling HandleSignon at ");

	log_result = sendsignon( sendsign , groupid);
	if ( log_result != TRUE )
	{
		exit(ERROR);
	}

	memcpy(header,sendsign ,sizeof(struct NNF_HEADER));
	TWIDDLE(header->iMsgLength);
	temp_size = header->iMsgLength;
	temp_code = header->iMsgCode;

	printf("\n\n\t header->iMsgCode  : %d",header->iMsgCode   );
	printf("\n\t temp_code        : %d",temp_code         );
	printf("\n\t header->iMsgLength : %d ", header->iMsgLength )  ;

	printf("\n\t header->iMsgLength : %d ", header->iMsgLength )  ;
	MD5_Digest(digest,sendsign,temp_size )  ;
	printf("\n after MD5 ");			
	tap_wrap = (char *)malloc(sizeof(struct TAP_WRAPPER));
	memset(tap_wrap,NULL,sizeof(struct TAP_WRAPPER));

	temp_size = temp_size+sizeof(struct TAP_WRAPPER);
	tap_wrap->Message_Len = temp_size;

	/**** TAP Reg Changes *****/ 
	TransmitSeq ++; 
	tap_wrap->Seq_No = TransmitSeq ; 

	memcpy(tap_wrap->digest,digest,16);

	TWIDDLE(tap_wrap->Seq_No);
	TWIDDLE(tap_wrap->Message_Len);

	printf("\n\t\tTwiddled Message_Len = [%d] and Twiddled Seq_No = [%d]",tap_wrap->Message_Len,tap_wrap->Seq_No);
	memcpy(sendsignTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
	memcpy(sendsignTAP+ sizeof(struct TAP_WRAPPER),sendsign,sizeof(struct NNF_SIGNON_REQ)); 
	sent_bytes = SEND(sockfd1,sendsignTAP,temp_size);
	CounterTotalTransmit++;
	printf("\n\t\t\tSIGNON REQUEST SENT TO EXCHANGE");
	ReduceInvitationCount(groupid);
	printf("\n\t\t\tSIGN ON REQUEST Sent to exchange ....[%d]  ",sent_bytes);

	/*------------------------------recv signon response-----------------------------------*/

	GetInvitationPacketCount(&InvPacketCount,groupid);
	printf("\n\n\n HandleSignon :: InvPacketCount = [%d]",InvPacketCount);
	if(InvPacketCount == 0)
	{
		recv_bytes = RECV_INV(sockfd1,recvsign,&inv_flag);
		if( recv_bytes <= 0)
		{
			ConnectionCounter++;
			printf("Received <=0 byted:closing TAP BOX Connection..\n");
			return FALSE;

		}	
		printf("\n\t\t\t inv_flag [%d] \n",inv_flag);
		if(inv_flag == TRUE)
		{
			if(  !(HandleInvitationPacket(sockfd1,groupid))  )
			{
				ConnectionCounter++;
				printf("Received <=0 byted:closing TAP BOX Connection..\n");
				return FALSE;
			} 	
		}
	}
	printf("\n Alok bfr receive ");
	recv_bytes = RECV(sockfd1,recvsign);

	printf("\n Alok after receive ");
	if( recv_bytes <= 0)
	{
		ConnectionCounter++;
		printf("Received <=0 byted:closing TAP BOX Connection..\n");
		return FALSE;
	}
	deal_with_SendRecv( recv_bytes , groupid );	
	memcpy(header,recvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(header->iMsgLength);
	blen = header->iMsgLength;
	bdata = (char *)malloc(blen);
	memcpy(bdata,recvsign+sizeof(struct TAP_WRAPPER),blen);
	if (get_mesg_or_error_nse(bdata) == TRUE )
		return(FALSE);
	memcpy(tap_wrap,recvsign,sizeof(struct TAP_WRAPPER));
	printf("\nReceived message with total length = [%d]\n",tap_wrap->Message_Len);
	printf("\nReceived Seq_No = [%d]\n",tap_wrap->Seq_No);
	Seq_No = 0;

	/**** TAP Reg Changes *****/
	RecieveSeq++;
	Seq_No = RecieveSeq ;
	TWIDDLE(tap_wrap->Seq_No); 
	printf("\nAfter Twiddling tap_wrap->Seq_No   %d",tap_wrap->Seq_No);
	printf("\nAfter Received Signon Packet Receive Seq No =[%d]\n",Seq_No);
	if(Seq_No != tap_wrap->Seq_No)
	{
		printf("\nFATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection..\n");
		memset(error,NULL,SIZE);
		strcpy(error,"ERROR::sequence no mismatch ");
		LogFatal("EquNseConTAP.pc",error);
		Exit(ERROR);
	}
	printf("\nPassed Seq No Check...\n");
	memcpy(header,recvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(header->iMsgLength);
	printf("\n After Twiddling header->MsgLength     %d ",header->MsgLength);
	blen = header->MsgLength;
	bdata = (char *)malloc(blen);
	memcpy(bdata,recvsign+sizeof(struct TAP_WRAPPER),blen);
	printf("\nComputing the digest ...\n");
	MD5_Digest(digest,bdata,blen)  ;
	if(strncmp(digest,tap_wrap->digest,16) !=0)
	{
		printf("\nFATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection..\n");
		memset(error,NULL,SIZE);
		strcpy(error,"ERROR::Mismatch in MD5 Checksum ");
		LogFatal("EquNseConTAP.pc",error);
		Exit(ERROR);
	}
	printf("\nPassed MD5 Checksum Check...\n");
	memcpy(header,recvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(header->MsgLength);	
	TWIDDLE(header->ErrorCode);	
	blen = header->MsgLength;
	bdata = (char *)malloc(blen);
	printf("\n MsgLength [%d]  ",header->MsgLength);
	memcpy(bdata,recvsign+sizeof(struct TAP_WRAPPER),blen);
	log_result = frecvsignon(bdata);
	printf("\n The log result for signon response recieved is %d ",log_result );
	deal_with_LogResult(log_result);

	memset(Ferror,NULL,SIZE);
	if(header->ErrorCode != 0)
	{
		logDebug2(" Error code received is [%d] ",header->ErrorCode);
		iErrMsgCode = header->ErrorCode;
		/****** EXEC SQL SELECT ERM_REASON_DESCRIPTION INTO :sConErrMsg FROM EXCH_REASON_MASTER WHERE ERM_REASON_CODE =:iErrMsgCode;******/
		if ( iErrMsgCode == 16006)
		{
			memset(error,NULL,SIZE);
			//sprintf(error,"Error in Selecting EDD for StreamId  is %d ", sqlca.sqlcode );
			LogFatal(sProgName,error);
			exit(ERROR);
		}


		//logInfo("Returned from HandleSignon at ");

		//strncpy(error,sConErrMsg.arr,strlen(sConErrMsg.arr));
		//logDebug2("iUserID %d ",iUserID);


		free(sendsign);
		exit(ERROR);
		return(FALSE);
	}
	else
	{
		sprintf(Ferror,"%s\t%s",getenv("NSE_EQ_USERID"),"USER SUCCESSFULLY LOGIN FOR TRADING");


		//LogEQConFatal(sProgName,Ferror);
	}

	free(sendsign);
	printf("\n\n\tReturned from HandleSignon at ");
	return(TRUE);
}

void TransmitRequestPackets( int groupid )
{
	int sig1 = 0;
	int sig2 = 0;
	int transkill = -1,respkill = -1;
	int pid,ppid;
	int j;    
	int respchild,transchild;
	char *msg,
	     *error,
	     *sendsign,
	     *sendsys,
	     *sendup,
	     *sendmsg,
	     *recvgen;
	struct NNF_HEADER *header; 
	NNF_ORDER_ENTRY_REQ *nnf_order;
	int	qid,
		wait_status,
		sent_bytes,
		recv_bytes,
		log_result,
		temp_code,
		temp_size;
	CHAR DummyChar;
	LONG32 Dummy;

	SHORT *TempReadRmsDaemonStatus ;
	SHORT   DaemonStatus=-1 ;
	BOOL OFFLINEFLAG = TRUE;
	SHORT MaxNoOfIterations;  
	TempReadRmsDaemonStatus=&DaemonStatus;    

	int sqlgroupid;
	SHORT MaxStream =0 ;  
	char ProgTime[40];
	memset(ProgTime,'\0',40); 

	sigset_t SequenceSet;
	signal(SIGPIPE,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGUSR1);
	sigaddset ( &SequenceSet , SIGUSR2);				/* Signal function Initialization */
	sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,'\0');
	setbuf(stderr,'\0');


	unsigned char digest[16];
	struct TAP_WRAPPER *tap_wrap;
	LONG32 InvPacketCount;
	struct InvitationCount *invcount;

	char * sendsysTAP;
	char * sendupTAP;
	char * sendmsgTAP;
	char * msgTAP;
	LONG32 inv_flag = FALSE;

	/****************  End ***********************/

	pid = getpid();
	ppid = getppid();
	sqlgroupid = groupid;


	msg = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE); 
	header = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	error = (char *)malloc(sizeof(char)*SIZE);
	sendsys  = (char *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
	sendup = (char *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));
	sendmsg = (char *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	recvgen = (char *)malloc(NSE_PACKET_SIZE);
	nnf_order = (NNF_ORDER_ENTRY_REQ *)malloc(sizeof(NNF_ORDER_ENTRY_REQ));
	sendsysTAP  = (char *)malloc(sizeof(struct NNF_SYS_INFO_REQ) + sizeof(struct TAP_WRAPPER));
	sendupTAP = (char *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ) + sizeof(struct TAP_WRAPPER));
	sendmsgTAP = (char *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ) + sizeof(struct TAP_WRAPPER));  
	msgTAP = (char *)malloc((sizeof(char)*NSE_PACKET_SIZE) + sizeof(struct TAP_WRAPPER));


#ifdef OFFLINE
	PumperFlg = (struct PUMPER_FLAGS *)OpenSharedMemory(PumperFlgShm,PumperFlg_SIZE);
	if(PumperFlg == NULL)
	{
		printf("\n Error in Opening Shared Memory PumperFlgShm");
		Exit(ERROR);	      
	}
#endif


	/*********    
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=sizeof(lvar_uid.arr);

	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  printf ("\n EquNseConAdapter.pc Error in connecting to oracle ");	
	  exit(ERROR);
	  }******/
	printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Connction to Oracle SUCCESS......      ");
	printf("\n IN Function TransmitRequestPackets with nitish \n");

	tap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	if(ConnectToExchange == 1)
	{        
		/*-------------------------------sys info request-------------------------------------*/
		while(TRUE)
		{
			GetInvitationPacketCount(&InvPacketCount,groupid);
			if(InvPacketCount != 0)
			{
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILDInvPacketCount [%d]      ",InvPacketCount);
				break;
			}
		}
		printf("\n\t\t\t\t\t\tTRANSMIT CHAftre GetInvitationPacketCount  InvPacketCount [%d]    ",InvPacketCount);
		printf("\n\t\t\t\t\t\t\tTRANSMIT CHBefore sendsysinfo      ");

		sendsysinfo(sendsys);

		printf("\n alok after sendsysinfo "); 
		temp_size = ((struct NNF_HEADER *)(sendsys))->MsgLength;
		TWIDDLE(((struct NNF_HEADER *)(sendsys))->MsgLength); 
		MD5_Digest(digest,sendsys ,temp_size)  ;
		memset(tap_wrap,NULL,sizeof(struct TAP_WRAPPER));
		temp_size = temp_size + sizeof(struct TAP_WRAPPER);
		tap_wrap->Message_Len = temp_size;

		TransmitSeq++;
		tap_wrap->Seq_No = TransmitSeq ; 
		TWIDDLE(tap_wrap->Message_Len); 
		TWIDDLE(tap_wrap->Seq_No);  
		printf("\n\t\t\t\t\t\t\t TRANSMIT CHILD Transmit Seq No incremented to [%d] \n",tap_wrap->Seq_No);
		memcpy(tap_wrap->digest,digest,16);
		memcpy(sendsysTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
		memcpy(sendsysTAP+ sizeof(struct TAP_WRAPPER),sendsys,sizeof(struct NNF_SYS_INFO_REQ)); 
		printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Bfore sending     ");
		sent_bytes = SEND(sockfd1,sendsysTAP,temp_size);
		CounterTotalTransmit++;
		deal_with_SendRecv(sent_bytes , groupid);
		ReduceInvitationCount(groupid);

		/**** ALOK Added for Download  on 22 Apr 2013**************/
		/*----------------------------update local database request--------------------------*/

		printf("\n ALOKK HERE 123 ");
		sig1 = 0;
		/*** TAP Reg Changes ***/
		/*****         mainwait = sigwait( &SequenceSet, &sig1);******ALOKKK*****/
		sigwait( &SequenceSet, &sig1);
		printf("\n ALOKK HERE ");
		printf("\n SIGNAL 1:%d", sig1);
		/*** TAP Reg Changes ***/
		printf("\nTRANSMIT CHILD SYS INFO RESPONSE COMPLETED");


		if ( sig1 == SIGUSR1 )
		{

			while(TRUE)
			{
				GetInvitationPacketCount(&InvPacketCount,groupid);
				if(InvPacketCount != 0)
				{
					printf("\n\t\t\t\t\t\t\tTRANSMIT CHILDInvPacketCount [%d]      ",InvPacketCount);
					break;
				}
			}
			printf("\n \t\t\t\t\t\t\tTRANSMIT CHILDAfter GetInvitationPacketCount InvPacketCount [%d] \n",InvPacketCount);
			printf("\n \t\t\t\t\t\t\tTRANSMIT CHILDBefore sendupdate      ");
			sendupdate( sendup,groupid );
			printf("\n After sendupdate with nitish \n");
			temp_size = ((struct NNF_HEADER *)(sendup ))->MsgLength;
			TWIDDLE(((struct NNF_HEADER *)(sendup))->MsgLength);
			MD5_Digest(digest,sendup  ,temp_size )  ;
			memset(tap_wrap,0,sizeof(struct TAP_WRAPPER));

			printf("\n======== Before Send LDB Update Request %d======",temp_size);
			temp_size = temp_size + sizeof(struct TAP_WRAPPER);
			tap_wrap->Message_Len = temp_size;

			/*** TAP Reg Changes ***/
			TransmitSeq ++;
			tap_wrap->Seq_No = TransmitSeq;
			/*** TAP Reg Changes ***/
			TWIDDLE(tap_wrap->Message_Len);
			TWIDDLE(tap_wrap->Seq_No);


			printf("\n\t\t TRANSMIT CHILD:Transmit Seq No incremented to [%d] \n",tap_wrap->Seq_No);

			printf("\n  SEQ NO tap_wrap->Seq_No = [%d]",tap_wrap->Seq_No);
			memcpy(tap_wrap->digest,digest,16);
			memcpy(sendupTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(sendupTAP + sizeof(struct TAP_WRAPPER),sendup,sizeof(struct NNF_UPDATE_LDB_REQ));
			printf("\n \t\t\t\t\t\t\tTRANSMIT CHILD Bfefore Sending \n  ");
			sent_bytes = SEND(sockfd1,sendupTAP,temp_size);
			deal_with_SendRecv(sent_bytes , groupid);
			printf("\n\t\t\t\t\t\t\t TRANSMIT CHILD Before ReduceInvitationCount      ");
			ReduceInvitationCount(groupid);
			printf("\n\t\t\t\t\t\t\t TRANSMIT CHILD Lock on ProcessDataLock1 ");
			LockShm( ProcessDataLock1 );
			printf("\n \t\t\t\t\t\t\tTRANSMIT CHILD UPDATE LDB REQUEST :: SENT TO EXCHANGE       ");
			printf("\nDrvNseConnect.pc UPDATE LDB REQUEST :: SENT TO EXCHANGE ... ");

		}

		printf("\n \t\t\t\t\t\t\tTRANSMIT CHILD WAITING FOR SIGNAL 2 ");
		sig1 = 0;

		/***/           mainwait = sigwait( &SequenceSet,&sig1);/*****ALOKKKK***/
		printf("\n SIGNAL 2:%d", sig1);

		if ( sig1 == SIGUSR2 )
		{

			while(TRUE)
			{
				GetInvitationPacketCount(&InvPacketCount,groupid);
				if(InvPacketCount != 0)
				{
					printf("\n\t\t\t\t\t\t\tTRANSMIT CHILDInvPacketCount [%d]      ",InvPacketCount);
					break;
				}
			}
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD After GetInvitationPacketCount InvPacketCount [%d] \n",InvPacketCount);
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before sendupdate      ");
			sendupdate( sendup,groupid );
			temp_size = ((struct NNF_HEADER *)(sendup ))->MsgLength;
			TWIDDLE(((struct NNF_HEADER *)(sendup))->MsgLength);
			MD5_Digest(digest,sendup ,temp_size )  ;
			memset(tap_wrap,NULL,sizeof(struct TAP_WRAPPER));
			temp_size = temp_size + 22;
			tap_wrap->Message_Len = temp_size;

			TransmitSeq ++;
			tap_wrap->Seq_No = TransmitSeq;
			TWIDDLE(tap_wrap->Seq_No);
			TWIDDLE(tap_wrap->Message_Len);

			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Transmit Seq No incremented to [%d] \n",tap_wrap->Seq_No);
			memcpy(tap_wrap->digest,digest,16);
			memcpy(sendupTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(sendupTAP + sizeof(struct TAP_WRAPPER),sendup,sizeof(struct NNF_UPDATE_LDB_REQ));
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before Sending     ");
			sent_bytes =SEND(sockfd1,sendupTAP,temp_size);
			deal_with_SendRecv(sent_bytes , groupid);
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before ReduceInvitationCount      ");
			ReduceInvitationCount(groupid);
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD AGAIN UPDATE LDB REQUEST :: SENT TO EXCHANGE      ");
		}
		else if ( sig1 == SIGUSR1 )
		{
			/*----------------------------------message area download-------------------------------------*/
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD MESSAGE AREA DOWNLOAD \n");

			/*** TAP Reg Changes ***/
			/***** EXEC SQL SELECT max(EDD_STREAM_ID)
INTO :MaxStream
FROM EXCH_DOWNLOAD_DIGITAL
WHERE  EDD_EXCH_ID='NSE'
AND EDD_DRV_FLAG='N'
AND EDD_GROUP_ID=:groupid;*****/

			/*****                    if ( sqlca.sqlcode != 0)
			  {
			  printf("\n Error in Selecting EDD for StreamId  is %d ", sqlca.sqlcode );
			  exit(ERROR);
			  }******/




			TotalStream = MaxStream ;
			printf("\n TOTAL No Of STREAM : [%d] ", TotalStream);

			for (j=1; j<= TotalStream; j++) /*** TAP Reg Changes ***/
			{

				while(TRUE)
				{
					GetInvitationPacketCount(&InvPacketCount,groupid);
					if(InvPacketCount != 0)
					{
						printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD InvPacketCount [%d]      ",InvPacketCount);
						break;
					}
				}
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD After GetInvitationPacketCount InvPacketCount [%d]    ",InvPacketCount);
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before sendmessage     ");

				/*** TAP Reg Changes ***/
				sendmessage( sendmsg , groupid, j);
				memset((((struct NNF_HEADER *)(sendmsg))->AlphaSplit),'\0',2);
				sprintf((((struct NNF_HEADER *)(sendmsg))->AlphaSplit),"%d", j);
				printf("\n Alpha Split value : [%s] \n\n", (((struct NNF_HEADER *)(sendmsg))->AlphaSplit));
				/*** TAP Reg Changes ***/

				temp_size = ((struct NNF_HEADER *)(sendmsg ))->MsgLength;
				TWIDDLE(((struct NNF_HEADER *)(sendmsg))->MsgLength);
				MD5_Digest(digest,sendmsg  ,temp_size)  ;
				memset(tap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				temp_size = temp_size + 22;
				tap_wrap->Message_Len = temp_size;
				printf("\nGROUP ID CHECK::: [%d]",groupid);
				printf("\n 1>>>SEQ No SENT IS : [%d]",tap_wrap->Seq_No);

				/*** TAP Reg Changes ***/
				TransmitSeq ++;
				tap_wrap->Seq_No = TransmitSeq;
				/*** TAP Reg Changes ***/
				TWIDDLE(tap_wrap->Seq_No);
				TWIDDLE(tap_wrap->Message_Len);
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Transmit Seq No incremented to [%d] \n",tap_wrap->Seq_No);
				printf("\n 1>>>SEQ No SENT IS : [%d]",tap_wrap->Seq_No);

				memcpy(tap_wrap->digest,digest,16);
				memcpy(sendmsgTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(sendmsgTAP + sizeof(struct TAP_WRAPPER) , sendmsg,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILDBefore Sending      ");
				sent_bytes = SEND(sockfd1,sendmsgTAP ,temp_size);
				deal_with_SendRecv(sent_bytes , groupid);
				printf("\n\t\t\t\t\t\tTRANSMIT CHILD Before ReduceInvitationCount     ");
				ReduceInvitationCount(groupid);
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD MESSAGE AREA DOWNLOAD REQUEST :: SENT TO EXCHANGE ..      ");
			} /*** TAP Reg Changes ***/
		}
		/*-------------------------------fallover complete set shared memory flag to true------------*/
		sig1 = 0;
		/*** TAP Reg Changes ***/
		/****           mainwait = sigwait( &SequenceSet,&sig1);****ALOKKK ************/
		mainwait = 0;

		sig1 = mainwait ;
		printf("\n SIGNAL 3:%d", sig1);
		/*** TAP Reg Changes ***/

		if (sig1 == SIGUSR1)
		{
			/*** TAP Reg Changes ***/
			for (j=1; j<= TotalStream; j++)
			{
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before GetInvitationPacketCount     ");
				GetInvitationPacketCount(&InvPacketCount,groupid);
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD After GetInvitationPacketCount InvPacketCount [%d] ",InvPacketCount);
				if(InvPacketCount == 0)
				{
					recv_bytes  = RECV_INV(sockfd1,recvgen,inv_flag);
					if(inv_flag == TRUE)
					{
						printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before ReceiveInvitationPacket      ");
						ReceiveInvitationPacket(sockfd1,groupid);
					}
				}
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before sendmessage      ");
				sendmessage( sendmsg , groupid, j );

				memset((((struct NNF_HEADER *)(sendmsg))->AlphaSplit),'\0',2);
				sprintf((((struct NNF_HEADER *)(sendmsg))->AlphaSplit),"%d", j);
				printf("\n Alpha Split value : [%s] \n\n", (((struct NNF_HEADER *)(sendmsg))->AlphaSplit));

				temp_size = ((struct NNF_HEADER *)(sendmsg ))->MsgLength;
				TWIDDLE(((struct NNF_HEADER *)(sendmsg ))->MsgLength);
				MD5_Digest(digest,sendmsg  ,temp_size )  ;
				memset(tap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				temp_size = temp_size + 22;
				tap_wrap->Message_Len = temp_size;

				/*** TAP Reg Changes ***/
				TransmitSeq ++;
				tap_wrap->Seq_No = TransmitSeq;
				/*** TAP Reg Changes ***/
				TWIDDLE(tap_wrap->Seq_No);
				TWIDDLE(tap_wrap->Message_Len);

				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Transmit Seq No incremented to [%d] \n",tap_wrap->Seq_No);
				printf("\n SEQ No SENT IS : [%d]",tap_wrap->Seq_No);
				memcpy(tap_wrap->digest,digest,16);
				memcpy(sendmsgTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(sendmsgTAP + sizeof(struct TAP_WRAPPER),sendmsg,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before Sending      ");
				sent_bytes = SEND(sockfd1,sendmsgTAP,temp_size);
				if ( sent_bytes < 0 )
				{
					send_exch_down_buf_nse( groupid ,sendmsg );
				}
				deal_with_SendRecv(sent_bytes , groupid);
				printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before ReduceInvitationCount       ");
				ReduceInvitationCount(groupid);
				printf("\n\t\t\t\t\t\t\t TRANSMIT CHILD MESSAGE AREA DOWNLOAD REQUEST :: SENT TO EXCHANGE ...       ");
			}
			/*** TAP Reg Changes ***/
		}
		else if ( sig1 == SIGUSR2 )
		{
			printf("\n\n\t\t\t\t TRANSMIT CHILD MESSAGE AREA DOWNLOAD COMPLETE NORMAL PROCESS STARTS \n");
		}


		/*** Only if this flag is set during SysInfoResp will we send the portfolio req ***/
		printf("\nTransmitRequestPackets: DOWNLOAD COMLETE NORMAL PROCESS STARTS");



		/***** ALOKK Added for Download on 22-Apr-2013 ***/
	}   

	printf("\nOPENING  GlobQueueId  %d\n",GlobQueueId) ;
	qid = OpenMsgQ(OrdSrvToFwdMapNSEEQ);			
	if ( qid < 0 )
	{
		strcpy(error,"ERROR : in OpenMsgQ function ");
		LogFatal("EquNseConnect.pc",error);
		Exit(ERROR);
	}
	/*******
#ifdef OFFLINE

EXEC SQL SELECT nvl(OC_NO_OF_ITERATION,0)
INTO        :MaxNoOfIterations
FROM        OFFLINE_CONFIGURATION;
if (sqlca.sqlcode != 0)
{
printf("\n Sql error for OFFLINE_CONFIGURATION  %d ", sqlgroupid );
}

#endif
	 *****/

/****	EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
  SET  EAM_LOGON_STATUS = 'R'
  WHERE EAM_EXM_EXCH_ID = 'NSE'
  AND EAM_GROUP_ID = to_char(:sqlgroupid)
  AND EAM_DRV_FLAG = 'N';
  if ( sqlca.sqlcode == -1036 )
  {
  printf("\n Inside 1036 error ************** ");
  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
  SET  EAM_LOGON_STATUS = 'R'
  WHERE EAM_EXM_EXCH_ID = 'NSE'
  AND EAM_GROUP_ID = to_char(:sqlgroupid)
  AND EAM_DRV_FLAG = 'N';
  if ( sqlca.sqlcode == 0 )
  {
  printf("\n Wov no error now ");
  EXEC SQL COMMIT;
  }
  }
  else if (sqlca.sqlcode != 0)
  {
  printf("UPDATE EXCH_ADMINISTRATION_MASTER sql error : %d\n",sqlca.sqlcode);
  printf("\n SqlGroupId for which this error occurs is %d ", sqlgroupid );
  } 
  else
  {	
  EXEC SQL COMMIT;
  }*****/
printf("\n\tTRANSMIT CHILD Before fUpdateConnectStatus     ");
/*****/	fUpdateConnectStatus(NSE_EQU_UP, groupid ,BCAST_YES,FALSE);/*****/
while ( TRUE )
{
	printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD At the start of the While Loop     ");
	while(TRUE)
	{
		GetInvitationPacketCount(&InvPacketCount,groupid);
		if(InvPacketCount != 0)
		{
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD InvPacketCount [%d]      ",InvPacketCount);
			break;
		}
	}
	printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD InvPacketCount [%d]      ",InvPacketCount);
	if(InvPacketCount >0)
	{
		memset(msg,NULL,NSE_PACKET_SIZE);	
		memset(error,NULL,SIZE);
		printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD ReadMsgQ id is %d",qid);
		wait_status = ReadMsgQ( qid , msg , NSE_PACKET_SIZE , 1);
		if (wait_status == TRUE)
		{
			memset(nnf_order,'\0',sizeof(NNF_ORDER_ENTRY_REQ));
			memcpy(header,msg,sizeof(struct NNF_HEADER)); 
			TWIDDLE(header->MsgLength);
			TWIDDLE(header->MsgCode);	

			temp_size = header->MsgLength;
			temp_code = header->MsgCode;
			memcpy(nnf_order,msg,sizeof(NNF_ORDER_ENTRY_REQ));	

			printf("\n==================Saurabh Printing request Packet====================");

			printf("\n header->Reserved [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.iReserved);
			printf("\n header->LogTimeStamp [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.iLogTimeStamp);
			printf("\n header->AlphaSplit [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.sAlphaSplit,strlen(((struct NNF_ORDER_ENTRY *)msg)->pHeader.sAlphaSplit));
			printf("\n header->MsgCode [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.iMsgCode);
			printf("\n header->ErrorCode [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.iErrorCode);
			printf("\n header->TimeStamp1 [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.sTimeStamp1,strlen(((struct NNF_ORDER_ENTRY *)msg)->pHeader.sTimeStamp1));
			printf("\n header->TimeStamp2 [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.sTimeStamp2,strlen(((struct NNF_ORDER_ENTRY *)msg)->pHeader.sTimeStamp2));
			printf("\n header->TimeStamp3 [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.sTimeStamp3,strlen(((struct NNF_ORDER_ENTRY *)msg)->pHeader.sTimeStamp3));
			printf("\n header->MsgLength [%d]",((struct NNF_ORDER_ENTRY *)msg)->pHeader.iMsgLength);
			printf("\n ParticipantType  [%c]",((struct NNF_ORDER_ENTRY *)msg)->cParticipantType);
			printf("\n Reserved  [%c]",((struct NNF_ORDER_ENTRY *)msg)->cReserved);
			printf("\n CompititorPeriod  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iCompititorPeriod);
			printf("\n SolicitorPeriod  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iSolicitorPeriod);
			printf("\n ModCanBy  [%c]",((struct NNF_ORDER_ENTRY *)msg)->cModCanBy);
			printf("\n Reserved1  [%c]",((struct NNF_ORDER_ENTRY *)msg)->cReserved1);
			printf("\n ReasonCode  [%d",((struct NNF_ORDER_ENTRY *)msg)->iReasonCode);
			printf("\n StartAlpha [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->sStartAlpha,strlen(((struct NNF_ORDER_ENTRY *)msg)->sStartAlpha));
			printf("\n EndAlpha [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->sEndAlpha,strlen(((struct NNF_ORDER_ENTRY *)msg)->sEndAlpha));
			printf("\n Symbol [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->pSecInfo.sSymbol,strlen(((struct NNF_ORDER_ENTRY *)msg)->pSecInfo.Symbol));
			printf("\n Series [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->pSecInfo.sSeries,strlen(((struct NNF_ORDER_ENTRY *)msg)->pSecInfo.Series));
			printf("\n AuctionNum  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iAuctionNum);
			printf("\n CPBrokerCode  [%s] Lenght [%d]",((struct NNF_ORDER_ENTRY *)msg)->sCPBrokerCode,strlen(((struct NNF_ORDER_ENTRY *)msg)->sCPBrokerCode));
			printf("\n SecSuspInd  [%c]",((struct NNF_ORDER_ENTRY *)msg)->cSecSuspInd);
			printf("\n OrderNum  [%lf]",((struct NNF_ORDER_ENTRY *)msg)->fOrderNum);
			printf("\n AccCode  [%s]",((struct NNF_ORDER_ENTRY *)msg)->sAccCode);
			printf("\n BookType  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iBookType);
			printf("\n BuyOrSell  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iBuyOrSell);
			printf("\n DiscQty  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iDiscQty);
			printf("\n DiscQtyRemaining  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iDiscQtyRemaining);
			printf("\n TotalQtyRemaining  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iTotalQtyRemaining);
			printf("\n TotalQty  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iTotalQty);
			printf("\n QtyFilledToday  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iQtyFilledToday);
			printf("\n Price  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iPrice);
			printf("\n TriggerPrice  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iTriggerPrice);
			printf("\n GoodTillDate  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iGoodTillDate);
			printf("\n MinFillQty  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iMinFillQty);
			printf("\n LastModifiedTime  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iLastModifiedTime);
			printf("\n MFTerm [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.MFTerm);
			printf("\n AONTerm [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.AONTerm);
			printf("\n IOCTerm [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.IOCTerm);
			printf("\n GTCTerm [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.GTCTerm);
			printf("\n DayTerm [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.DayTerm);
			printf("\n StopLossTerm [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.StopLossTerm);
			printf("\n Market [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.Market);
			printf("\n ATO [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.ATO);
			printf("\n Reserved [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.Reserved);
			printf("\n PreOpen [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.PreOpen);
			printf("\n Frozen [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.Frozen);
			printf("\n Modified [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.Modified);
			printf("\n Traded [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.Traded);
			printf("\n MatchedInd [%d]",((struct NNF_ORDER_ENTRY *)msg)->pOrderTerms.MatchedInd);
			printf("\n BranchId  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iBranchId);
			printf("\n ExcgUserId  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iExcgUserId);
			printf("\n BrokerCode  [%s]",((struct NNF_ORDER_ENTRY *)msg)->sBrokerCode);
			printf("\n Remarks  [%s]",((struct NNF_ORDER_ENTRY *)msg)->sRemarks);
			printf("\n Settlor  [%s]",((struct NNF_ORDER_ENTRY *)msg)->sSettlor);
			printf("\n ProCli  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iProCli);
			printf("\n SettlementDays  [%d]",((struct NNF_ORDER_ENTRY *)msg)->iSettlementDays);
			printf("\n dUserInfo  [%lf]",((struct NNF_ORDER_ENTRY *)msg)->fUserInfo);
			printf("\n dReservedPrgTrd  [%lf]",((struct NNF_ORDER_ENTRY *)msg)->fReservedPrgTrd);

			printf("\n==================Saurabh Printing request Packet End====================");


			MD5_Digest(digest,msg  ,temp_size)  ;
			tap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
			memset(tap_wrap,NULL,sizeof(struct TAP_WRAPPER));
			temp_size = temp_size + sizeof(struct TAP_WRAPPER);
			tap_wrap->Message_Len = temp_size;

			TransmitSeq ++ ;
			tap_wrap->Seq_No = TransmitSeq; 
			TWIDDLE(tap_wrap->Seq_No);
			TWIDDLE(tap_wrap->Message_Len);	
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Seq No Sending Order Packet [%d] ----\n",tap_wrap->Seq_No);
			memcpy(tap_wrap->digest,digest,16);
			memcpy(msgTAP,tap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(msgTAP + sizeof(struct TAP_WRAPPER),msg,(temp_size - sizeof(struct TAP_WRAPPER)));
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD BEFORE SEND 1 temp_size : %d",temp_size )  ;
			ReduceInvitationCount(groupid);
			sent_bytes = SEND(sockfd1,msgTAP,temp_size);
			CounterTotalTransmit++;
			printf("\n\t\t\t\t\t\t\tTRANSMIT CHILD Before AFTER SEND  [%d]    ",CounterTotalTransmit);
			//if ( sent_bytes <= 0 )
			if (0 <= 0 )
			{
				send_exch_down_buf_nse( groupid , msg );
			}
			system("echo 'Date and Time is' ");
			system("date");
			deal_with_SendRecv(sent_bytes , groupid);

#ifdef OFFLINE
			if(sent_bytes > 0 && OFFLINEFLAG==TRUE )
			{
				if(fReadRmsDaemonStatus(TempReadRmsDaemonStatus) == TRUE)
				{
					printf("\nRmsDaemonStatus %d",*TempReadRmsDaemonStatus);
					if((*TempReadRmsDaemonStatus) >= (MaxNoOfIterations -1))
					{
						printf("\n Offline orders are over now." ) ;
						OFFLINEFLAG = FALSE ;
					}
					else
					{
						printf("\n Update the status of offline orders to S") ;
						/** Additions to avoid Update_Offline_Status for each packet **/
					}
				}
				else
					printf("\n Rms Daemon  process fails");
			}
#endif
		}
		else
		{
			memset(error,NULL,SIZE);
			strcpy(error,"EquNseConAdapter ERROR in ReadMsgQ function ");
			printf("\n\t EquNseConAdapter ERROR in ReadMsgQ function " )  ;
			LogFatal("EquNseConAdapter.pc",error);
			Exit(ERROR);
		}
	}


}
}       /* End of TransmitRequestPackets*/

void ReceiveReplyPackets( int sockfd1 , int iLocalId)
{
	LONG32  FileFlag=FALSE;
	static int iPacketCounter =0 ;

	int ExchPacketCounter=0;
	char ProgTime[40];
	memset(ProgTime,'\0',40);

	CHAR  SeqArr1[1];
	SHORT seq1=0;
	CHAR  TempSeqNo[ 9 ];
	USHORT d[16];
	SHORT i=15, j=0;
	LONG32 temp = 0;
	SHORT Stream = 0, DowCounter =0; 
	CHAR tempStream;  

	int	qidnormal,
		qidaucodd,
		recv_bytes,
		write_status;

	int clen3,
	    queue_bytes,
	    sent_bytes,
	    temp_size,
	    temp_code,
	    wait_status,
	    log_result,
	    flag=1,pid,ppid,
	    put_in_queue=FALSE,
	    TimeStampUpdateFlag =FALSE,
	    DownloadFlag = FALSE; 

	char    *msg,
		*recvgen,
		*recvgen1,
		*write_mess,
		*error,
		*recv_temp,		
		*recv_sys;
	int indexrec = 1;


	LONG32 inv_flag = FALSE;
	struct INVITATION_PACKET *inv_packet;
	short invcount;
	struct TAP_WRAPPER *tap_wrap;
	int Seq_No;

	unsigned char digest[16];

	char *bdata;
	LONG32 blen;

	CHAR DummyChar;
	LONG32 InvPacketCount;
	LONG32 Dummy;


	struct NNF_HEADER *header;
	struct NNF_SYS_INFO_RESP *sysresp;
	struct NNF_UPDATE_LDB_HDR_RESP *uhresponse;
	struct NNF_UPDATE_LDB_TRAILER_RESP *utresponse;
	struct NNF_UPDATE_LDB_DATA_RESP *udresponse;
	struct NNF_MSG_DOWNLOAD_START_RESP *mhresponse;
	struct NNF_MSG_DOWNLOAD_DATA_RESP *mdresponse;
	struct NNF_MSG_DOWNLOAD_END_RESP *mtresponse;
	struct NNF_DOUBLE_INT  TempTimeStamp , DowTime;

	tap_wrap = ( struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(tap_wrap,'\0',sizeof(struct TAP_WRAPPER));
	int sig1 = 0;
	int sig2 = 0;
	int transkill = -1,respkill = -1,downkill = -1 ;
	int special_id=0;

	int respchild,downchild,transchild,groupid;


	unsigned int  TempTime1 ;
	unsigned int  TempTime2 ;
	int iSqlGroupId = 0;
	sigset_t SequenceSet;
	signal(SIGPIPE,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGUSR1);
	sigaddset ( &SequenceSet , SIGUSR2);			/* Signal Initialization Functions */
	sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,'\0');
	setbuf(stderr,'\0');


	pid = getpid();
	ppid = getppid();
	special_id = iLocalId;
	iSqlGroupId = special_id;
	printf("\n Inside Function ReceiveReplyPackets Sql Local Group Id : %d Local Group Id : %d \n",iSqlGroupId,iLocalId);

	msg = (char *)malloc(NSE_PACKET_SIZE); 
	error = (char *)malloc(sizeof(char)*SIZE);
	recvgen = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	recv_temp = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	recvgen1 = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	recv_sys = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	header = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	memset(header,'\0',sizeof(struct NNF_HEADER));
	sysresp = (struct NNF_SYS_INFO_RESP *)malloc(sizeof(struct NNF_SYS_INFO_RESP));
	uhresponse = (struct  NNF_UPDATE_LDB_HDR_RESP *)malloc(sizeof(struct  NNF_UPDATE_LDB_HDR_RESP));
	utresponse=(struct NNF_UPDATE_LDB_TRAILER_RESP *)malloc(sizeof(struct NNF_UPDATE_LDB_TRAILER_RESP));
	udresponse = (struct NNF_UPDATE_LDB_DATA_RESP *)malloc(sizeof(struct NNF_UPDATE_LDB_DATA_RESP));
	mhresponse = (struct NNF_MSG_DOWNLOAD_START_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_START_RESP));
	mdresponse = (struct  NNF_MSG_DOWNLOAD_DATA_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));
	mtresponse = (struct NNF_MSG_DOWNLOAD_END_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_END_RESP));
	inv_packet = (struct INVITATION_PACKET *)malloc(sizeof(struct INVITATION_PACKET));


	printf("\nEquNseConAdapter.pc ReceiveReplyPackets connecting to database.......");
	/****** EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  printf ("\n EquNseConAdapter.pc Error in connecting to oracle ");
	  exit(ERROR);		
	  }*****/
	qidnormal = OpenMsgQ(EquNSEToRmsNse); 

	if ( qidnormal < 0 )
	{
		memset(error,NULL,SIZE);
		strcpy(error,"ERROR : in OpenMsgQ function ");
		LogFatal("EquNseConnect.pc",error);
		Exit(ERROR);
	}


	while(TRUE)
	{
		put_in_queue = FALSE;
		inv_flag = FALSE;
		printf("\n--------------------------------- RECEIVE CHILD NEW PACKET --------------------------------------\n");
		recv_bytes = RECV_INV(sockfd1,recvgen1,&inv_flag);
		deal_with_SendRecv(recv_bytes , iLocalId);
		printf("\nRECEIVE CHILD inv_flag [%d] ",inv_flag);
		if(inv_flag == TRUE)
		{
			printf("\nRECEIVE CHILD Receive child calling ReceiveInvitationPacket \n");
			ReceiveInvitationPacket(sockfd1,iLocalId);			
		}
		else
		{
			printf("\nRECEIVE CHILD RECEVING NON INVITATION PACKET \n");	
			recv_bytes = RECV(sockfd1,recvgen1);
			deal_with_SendRecv(recv_bytes , iLocalId);
			memcpy(header,recvgen1+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
			memcpy(tap_wrap,recvgen1,sizeof(struct TAP_WRAPPER));
			printf("\nRECEIVE CHILD Received message with total length = [%d]\n",tap_wrap->Message_Len);
			printf("RECEIVE CHILD Received Seq_No = [%d]\n",tap_wrap->Seq_No);

			/**** TAP Reg Changes *****/
			RecieveSeq ++;
			Seq_No =  RecieveSeq ; 
			TWIDDLE(tap_wrap->Seq_No); 
			TWIDDLE(header->MsgLength );
			TWIDDLE(header->MsgCode );
			printf("RECEIVE CHILD Required Seq_No is =[%d]\n",Seq_No);
			if(Seq_No != tap_wrap->Seq_No)
			{
				printf("\nFATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection..\n");

				memset(error,NULL,SIZE);
				strcpy(error,"ERROR::sequence no mismatch ");
				LogFatal("EquNseConTAP.pc",error);
				Exit(ERROR);
			}
			blen = header->MsgLength ;
			bdata = (char *)malloc(blen);
			memcpy(bdata,recvgen1+sizeof(struct TAP_WRAPPER) ,blen);
			MD5_Digest(digest,bdata,blen)  ;
			if(strncmp(digest,tap_wrap->digest,16) !=0)
			{
				printf("\nFATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection..\n");
				memset(error,NULL,SIZE);
				strcpy(error,"ERROR::Mismatch in MD5 Checksum ");
				LogFatal("EquNseConTAP.pc",error);
				Exit(ERROR);
			}
			printf("RECEIVE CHILD  The transcode in NNF_HADER [%d] ",header->MsgCode);
			printf("\nRECEIVE CHILD  The mesg length recvd is %d ",header->MsgLength);

			memset(recvgen,'\0',NSE_PACKET_SIZE); 
			printf("\nRECEIVE CHILD blen [%d] \n",blen);
			memcpy(recvgen,bdata,blen);

			/*********************** ALOKK PANDEY*********************

			  if (get_mesg_or_error_nse(recvgen) == TRUE )
			  {
			  printf("\n Before Continue");
			  continue;
			  }
			 ***************************ALOKK PANDEY*******************/
			switch(header->MsgCode)
			{
				case TC_EQU_NSE_SYS_INFO_RESP :
					memcpy(recv_sys,recvgen,sizeof(struct NNF_SYS_INFO_RESP));

					/*************** TAP Reg Changes*******************/
					printf("\n STREAM in SYSINFO :[%d] [%d]",((struct NNF_HEADER *)recvgen)->AlphaSplit, ((struct NNF_HEADER *)recvgen)->MsgCode); 
					TotalStream = *(header->AlphaSplit); 
					printf("\n Total No of STREAMS  :[%d] ",TotalStream );
					for(j=1; j<= TotalStream ;j++)
					{
						Msg_Dow_Data[j].Stream_Id  = j ;
						Msg_Dow_Data[j].Stream_Flag= 1;
						Msg_Dow_Data[j].TimeStamp1 = 0;
						Msg_Dow_Data[j].TimeStamp2 = 0;
					}
					/************ END of TAP Reg Changes*******************/

					log_result = recvsysinfo( recv_sys );
					deal_with_LogResult(log_result); 
					if ( log_result == TRUE )
					{
						printf("\nRECEIVE CHILD  RAISING SIGNAL 1 AFTER SYS_INFO_RESP\n");
						downkill = -1;
						downkill = kill( ppid , SIGUSR1 );
						if ( downkill < 0 )
						{
							memset(error,NULL,SIZE);
							strcpy(error,strerror(errno));
							LogFatal("EquNseConnect.pc",error);
							exit(ERROR);
						}
					}
					break;
				case TC_EQU_NSE_PARTIAL_SYS_INFO_RESP : 
					printf("\nEquNseConnect.pc MARKET STATUS MISMATCH ");
					memcpy(sysresp,recvgen,sizeof(struct NNF_SYS_INFO_RESP));

					log_result = recvsysinfo( recvgen );
					if ( log_result == TRUE )
					{
						printf("\nRECEIVE CHILD  RAISING SIGNAL 2 AFTER PARTIAL_SYS_INFO_RESP\n");
						downkill = -1;
						downkill = kill( ppid , SIGUSR2 );
						if ( downkill < 0 )
						{
							memset(error,NULL,SIZE);
							strcpy(error,strerror(errno));
							LogFatal("EquNseConAdapter.pc",error);
							exit(ERROR);
						}
					}
					break;
				case TC_EQU_NSE_UPDATE_LDB_HEADER_RESP : 
					printf("\nEquNseConAdapter.pc Update Database Header Messg :: recieved ");
					TimeStampUpdateFlag =FALSE;
					break;
				case TC_EQU_NSE_UPDATE_LDB_DATA_RESP : 
					memcpy(udresponse,recvgen,sizeof(struct NNF_UPDATE_LDB_DATA_RESP));
					printf("\n MsgCode of InnerTransCode is %d ",udresponse->sInnerHeader.MsgCode);
					TWIDDLE(udresponse->sInnerHeader.MsgLength); 
					queue_bytes = udresponse->sInnerHeader.MsgLength;

					write_mess = recvgen + sizeof(NNF_HEADER);
					put_in_queue = TRUE;
					break;
				case TC_EQU_NSE_UPDATE_LDB_TRAILER_RESP : 
					UnLockShm( ProcessDataLock1 );
					printf("\nEquNseConAdapter.pc Update Database Trailer Messg :: recieved ");
					downkill = -1;
					downkill = kill( ppid , SIGUSR1 );
					if ( downkill < 0 )
					{
						memset(error,NULL,SIZE);
						strcpy(error,strerror(errno));
						LogFatal("EquNseConnect.pc",error);
						exit(ERROR);
					}
					break;
				case TC_EQU_NSE_MSG_DOWNLOAD_START_RESP : 
					printf("\n EquNseConAdapter.pc Message Area header Messg :: recieved ");
					break;
				case TC_EQU_NSE_MSG_DOWNLOAD_DATA_RESP : 
					memcpy(mdresponse,recvgen,sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));
					memcpy(&TempTimeStamp,(mdresponse->sInnerHeader.TimeStamp2),NNF_DATE_TIME_LEN);
					TWIDDLE(mdresponse->sInnerHeader.MsgCode);
					TWIDDLE(mdresponse->sInnerHeader.MsgLength);
					printf("\n The inner transcode in message download recvd is %d ",mdresponse->sInnerHeader.MsgCode);
					if ( mdresponse->sInnerHeader.MsgCode == 2073 || mdresponse->sInnerHeader.MsgCode == 2074 ||
							mdresponse->sInnerHeader.MsgCode == 2075 || mdresponse->sInnerHeader.MsgCode == 2072 ||
							mdresponse->sInnerHeader.MsgCode == 2231 || mdresponse->sInnerHeader.MsgCode == 2170 ||
							mdresponse->sInnerHeader.MsgCode == 2042 || mdresponse->sInnerHeader.MsgCode == 2222 ||
							mdresponse->sInnerHeader.MsgCode == 3034 || mdresponse->sInnerHeader.MsgCode == 3037 ||
							mdresponse->sInnerHeader.MsgCode == 3044 || mdresponse->sInnerHeader.MsgCode == 3047 ||
							mdresponse->sInnerHeader.MsgCode == 2012 || mdresponse->sInnerHeader.MsgCode == 2076 ||
							mdresponse->sInnerHeader.MsgCode == 2009 || mdresponse->sInnerHeader.MsgCode == 2008 ||
							mdresponse->sInnerHeader.MsgCode ==9002)
					{
						printf("\n ----------PACKET DATA RECEIVED IN DOWNLOAD--------------- "); 
						recv_temp =recvgen + sizeof(NNF_HEADER);        
						ConvertSeqNO( recv_temp ,TempSeqNo); 		
						printf("\n ##########TempSeqNo   [%s]\n",TempSeqNo);
						memset( ((struct NNF_ORDER_ENTRY *)recv_temp)->sRemarks ,' ',OE_REMARKS_LEN);
						strncpy( ((struct NNF_ORDER_ENTRY *)recv_temp)->sRemarks,";",1);    
						memcpy ( ((struct NNF_ORDER_ENTRY *)recv_temp)->sRemarks + DELTA_REMARKS,TempSeqNo, strlen(TempSeqNo ));
					} 
					queue_bytes = mdresponse->sInnerHeader.MsgLength;
					write_mess = recvgen + sizeof(NNF_HEADER);
					put_in_queue = TRUE;

					printf("\n\t TCODE :[%d]",((struct NNF_ORDER_ENTRY *)write_mess)->pHeader.iMsgCode);  	
					break;

				case TC_EQU_NSE_MSG_DOWNLOAD_END_RESP : 
					printf("\nEquNseConnect.pc Message Area trailer Messg :: recieved ");
					TimeStampUpdateFlag =TRUE;

					/*************** TAP Reg Changes*******************/
					DowCounter++ ; 
					printf("\n MSG_DOWNLOAD Trailer Resp for STREAM :[%d] TotalStream :%d ",*(header->AlphaSplit), TotalStream);
					if( TotalStream == DowCounter )
					{ 	
						printf("\nRECEIVE CHILD  RAISING SIGNAL 2 AFTER MSG_DOWNLOAD_END\n");
						DownloadFlag = TRUE ;   
						downkill = -1;
						downkill = kill( ppid , SIGUSR2 );
						if ( downkill < 0 )
						{ 
							memset(error,NULL,SIZE);
							strcpy(error,strerror(errno));
							LogFatal("EquNseConnect.pc",error);
							exit(ERROR);
						}
					}
					/************ END of TAP Reg Changes*******************/

					break;

				default     :
					if ( header->MsgCode == 2073 || header->MsgCode == 2074 || header->MsgCode == 2075 || \
							header->MsgCode == 2072 || header->MsgCode == 2231 || header->MsgCode == 2170 || \
							header->MsgCode == 2042 || header->MsgCode == 9002 || header->MsgCode == 3034 || \
							header->MsgCode == 3037 || header->MsgCode == 3044 || header->MsgCode == 3047 || \
							header->MsgCode == 2012 || header->MsgCode == 2076 || header->MsgCode == 2009 || \
							header->MsgCode == 2008 || header->MsgCode == 2009 )
					{
						printf("\n ----------PACKET DATA RECEIVED IN NORMAL Packet ------------");	
						ConvertSeqNO(recvgen, TempSeqNo);		
						printf("\n\t--------------TempSeqNo [%s]\n",TempSeqNo);
						/**memcpy ( ((struct NNF_ORDER_ENTRY *)recvgen)->Remarks ,';',DELTA_REMARKS);  Commented as Junk Values sending to TWS ****/
						memset( ((struct NNF_ORDER_ENTRY *)recvgen)->sRemarks ,' ',OE_REMARKS_LEN);
						strncpy( ((struct NNF_ORDER_ENTRY *)recvgen)->sRemarks,";",1);      
						memcpy ( ((struct NNF_ORDER_ENTRY *)recvgen)->sRemarks + DELTA_REMARKS,TempSeqNo, strlen(TempSeqNo ));
					}

					/*************** TAP Reg Changes*******************/
					memcpy(&DowTime,(header->TimeStamp3),NNF_DATE_TIME_LEN);
					printf ("\n DowTime :%u :%u", DowTime.LogTime1, DowTime.LogTime2);
					printf("\n Normal Order :[%d] , [%s]", *(header->TimeStamp3), header->TimeStamp3); 
					printf("\n Value :%d", *(header->AlphaSplit));

					memcpy(&TempTimeStamp,(header->TimeStamp2),NNF_DATE_TIME_LEN);
					Stream = DowTime.LogTime2;

					printf("\n Normal PKT STREAM = %d Time1= %u,Time2=%u \n",Stream, TempTimeStamp.LogTime1, \
							TempTimeStamp.LogTime2);

					Msg_Dow_Data[Stream].Stream_Id  =Stream ;    
					Msg_Dow_Data[Stream].TimeStamp1 = TempTimeStamp.LogTime1 ;
					Msg_Dow_Data[Stream].TimeStamp2 = TempTimeStamp.LogTime2 ;

					if ( indexrec % MAX_NO_UPDATE == 0  && DownloadFlag == TRUE )
						UpdateTimeStamp( );          

					/************ END of TAP Reg Changes*******************/   


					printf("\n -------------------------------------------------------------"); 

					if ( header->MsgCode ==  2222  )
					{
						printf("\n Trade ");
					}
					printf("\n Default");
					write_mess = recvgen;
					queue_bytes = header->MsgLength;
					put_in_queue = TRUE;
					break;
			};

			if(put_in_queue == TRUE)
			{
				indexrec= indexrec +1;
				printf("\n Total No of Packets: counter %d ",indexrec);
				printf("\n AccCodeBy Nitish [%s]\n",(( struct NNF_ORDER_ENTRY * )write_mess)->sAccCode);
				write_status = WriteMsgQ(qidnormal,write_mess,queue_bytes,1);

				if ( write_status == ERROR)
				{
					memset(error,NULL,SIZE);
					strcpy(error,"ERROR in WriteMsgQ function ");
					LogFatal("BGSEconnect.pc",error);
					Exit(ERROR);
				}
			}

			if (TimeStampUpdateFlag == TRUE)  
			{
				TempTime1 = TempTimeStamp.LogTime1;
				TempTime2 = TempTimeStamp.LogTime2;
				printf("\n  DOWNLAOD PKT  LastMesgTime1= %u,LastMesgTime2=%u \n",TempTime1,TempTime2 );
			}
		} 
	}     					/* ------- while loop ends -----------------------*/
}						/* -- Recieve Reply packets function ---- */

void deal_with_LogResult(int log_result)
{
	if (log_result == TRUE )
	{
#ifdef DBG
		printf("\nEquNseConnect.pc SUCCESS ");
#endif
	}
	else
	{
#ifdef DBG
		printf("\nEquNseConnect.pc FAILED ");
#endif
	}
#ifdef DBG
	printf("\nEquNseConnect.pc The log_result is %d ",log_result);
#endif
}

void deal_with_Socket(int sockfd)
{
	if (sockfd < 0)
	{
#ifdef DBG
		printf("\nEquNseConnect.pc Fatal Socket Error :: closed ");
#endif
		exit(ERROR);
	}
	else
	{
#ifdef DBG
		printf("\nEquNseConnect.pc Socket connected :: socket id %d ",sockfd);
#endif
	}
}

void deal_with_SendRecv(int recv_bytes, int groupid)
{

	int sql_groupid;

	sql_groupid = groupid;

	if ( recv_bytes <= 0 )
	{
#ifdef DBG
		printf("\nEquNseConnect.pc Send / Recv Error or socket close request....%d bytes recvd  ",recv_bytes);
		printf("\nGroup id Recvd in deal_with_SendRecv is %d ", groupid );
		printf("\nSql variable groupid is %d ", sql_groupid );
#endif



		/*****			EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
		  SET  EAM_LOGON_STATUS = 'N'
		  WHERE EAM_EXM_EXCH_ID = 'NSE'
		  AND EAM_GROUP_ID = to_char(:sql_groupid)
		  AND EAM_DRV_FLAG = 'N';


		  if (sqlca.sqlcode == -1036)
		  {
		  printf("\n Inside 1036 error ************** ");
		  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
		  SET  EAM_LOGON_STATUS = 'N'
		  WHERE EAM_EXM_EXCH_ID = 'NSE'
		  AND EAM_GROUP_ID = to_char(:sql_groupid)
		  AND EAM_DRV_FLAG = 'N';

		  if ( sqlca.sqlcode == 0 )
		  {
		  printf("\n&&&&&&&&&& Changed Exchange Status to N &&&&&&&&&&&&");
		  EXEC SQL COMMIT;
		  }

		  } 
		  else if (sqlca.sqlcode !=0) 
		  {	
		  printf("EXCH_ADMINISTRATION_MASTER N update sql error : %d\n",sqlca.sqlcode);
		  printf("\nSql variable groupid is %d ", sql_groupid );
		  }
		  else
		  {
		  EXEC SQL COMMIT; 
		  }*******/

		fUpdateConnectStatus(NSE_EQU_DOWN, groupid ,BCAST_YES,FALSE);
		if(send_exch_down_nse( groupid ) == ERROR) 
		{
			printf("Error in send_exch_down_nse at printing at place deal_with_SendRecv");
		}
		Exit(0);
	}
	printf("\nEnd Of deal_with_SendRecv the no.of bytes sent / recieved are [%d] ",recv_bytes);	
}

void Exit( int Error)
{
	char ProgTime[40];
	memset(ProgTime,'\0',40);	
	printf("\nEquNseConnect.pc In exit Fun");
	GetTime(ProgTime);
	printf("\n[%s] IST:PROGRAM EXIT TIME",ProgTime);
	kill (getppid(),SIGTERM);
	exit(Error);
}


void ReceiveInvitationPacket (LONG32 sockfd1,int groupid)
{
	fd_set      ActiveSocketSet;
	fd_set      ReadSocketSet;
	LONG32      MaxSocketId;
	char  invPacket[NSE_PACKET_SIZE];
	int   recv_bytes;
	int Seq_No;
	LONG32 Retval;
	LONG32 ilen;
	INT16 MsgCode;
	LONG32 ppid,downkill;
	CHAR DummyChar;
	char ProgTime[40];
	memset(ProgTime,'\0',40);

	SHORT iCount;
	LONG32 gid;

	struct InvitationCount *invcount;
	gid = groupid -1;
	printf("\n============================ Waiting for Invitation Packet ============================");
	recv_bytes = RECV(sockfd1,invPacket);
	TWIDDLE(((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode);
	TWIDDLE(((struct INVITATION_PACKET *)invPacket)->sHeader.MsgLength);
	TWIDDLE(((struct INVITATION_PACKET *)invPacket)->invitation_count);
	printf("\nReceiveInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode);
	if(((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode == TC_EQU_NSE_INVITATION_REQ)
	{ 
		printf("\nReceiveInvitationPacket Invitation Packet Received");
	}
	deal_with_SendRecv( recv_bytes , groupid );
	ilen = ((struct INVITATION_PACKET *)invPacket)->sHeader.MsgLength;
	MsgCode = ((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode;
	if(MsgCode == TC_EQU_NSE_INVITATION_REQ)
	{
		iCount = ((struct INVITATION_PACKET *)invPacket)->invitation_count;
		printf("\nReceiveInvitationPacket iCount : [%d]  groupid:[%d]",iCount,groupid);
		LockShm(InvitationCountShm);
		invcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);

		if ( *( (int *) invcount) == ERROR )
		{
			printf ("\n Error in Creating Shm \n");
			exit(1);
		}
		invcount->InvCount_group[gid].InvPacketCount = invcount->InvCount_group[gid].InvPacketCount + iCount;
		if ( CloseSharedMemory( (void * ) invcount ) == ERROR )
		{
			printf ("\n Error in Closing Shm \n");
			exit(1);
		}
		UnLockShm(InvitationCountShm);
		printf("\n Seq_No before switch is :[%d] groupid is :[%d]",Seq_No,groupid); 

		/**** TAP Reg Changes *****/ 
		RecieveSeq ++;
		Seq_No =  RecieveSeq ; 

		CounterTotalInvite++;
		fflush(fpOrderNum);
		printf("\n============================ Received Invitation Packet : [%d] ============================",Seq_No);

	}
}

void ReduceInvitationCount(gid)
{
	LONG32 groupid;
	struct InvitationCount * invcount;
	char ProgTime[40];
	memset(ProgTime,'\0',40);

	groupid = gid - 1;
	LockShm(InvitationCountShm);
	invcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);
	if ( *( (int *) invcount) == ERROR )
	{
		printf ("\n Error in Creating Shm \n");
		//exit(1);
	}

	invcount->InvCount_group[groupid].InvPacketCount--;
	printf("\n REDUCED INVITATION COUNT IS [%d]",invcount->InvCount_group[groupid].InvPacketCount);
	if ( CloseSharedMemory( (void * ) invcount ) == ERROR )
	{
		printf ("\n Error in Closing Shm \n");
		exit(1);
	}
	UnLockShm(InvitationCountShm);

}

void GetInvitationPacketCount(LONG32 * InvPacketCount,LONG32 gid)
{
	LONG32 groupid;
	struct InvitationCount * invcount;
	groupid = gid -1;

	LockShm(InvitationCountShm);
	invcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);
	if ( *( (int *) invcount) == ERROR )
	{
		printf ("\n Error in Creating Shm \n");
		exit(1);
	}

	*InvPacketCount = invcount->InvCount_group[groupid].InvPacketCount;
	if ( CloseSharedMemory( (void * ) invcount ) == ERROR )
	{
		printf ("\n Error in Closing Shm \n");
		exit(1);
	}
	UnLockShm(InvitationCountShm);
}

GetTime(char *ProgTime)
{
	char locTime[40]   ;
	time_t currenttime  ;
	int yr = 1900       ;
	struct tm tm        ;
	memset(locTime,'\0',40)                                ;
	currenttime = time(0)                                   ;       /*** get system time ***/
	tm = *localtime(&currenttime)                           ;
	yr = yr + tm.tm_year                                    ;
	sprintf(locTime,"TIME : %d:%d:%d DATE : %d-%d-%d",tm.tm_hour,tm.tm_min,tm.tm_sec,tm.tm_mday, tm.tm_mon, yr);
	memcpy(ProgTime,&locTime,40)                           ;
}
int HandleInvitationPacket (LONG32 sockfd1,int groupid)
{
	fd_set      ActiveSocketSet;
	fd_set      ReadSocketSet;
	LONG32      MaxSocketId;
	char  invPacket[NSE_PACKET_SIZE];
	int   recv_bytes;
	int Seq_No;
	LONG32 Retval;
	LONG32 ilen;
	INT16 MsgCode;
	LONG32 ppid,downkill;
	char ProgTime[40];
	memset(ProgTime,'\0',40);

	SHORT iCount;
	LONG32 gid;

	struct InvitationCount *invcount;

	gid = groupid -1;
	printf("\n============================ Waiting for Invitation Packet ============================");
	recv_bytes = RECV(sockfd1,invPacket);
	if( recv_bytes <= 0 )
	{
		printf("\n In handle Invitation packet ---Failed Recv"); 
		return FALSE;
	}
	else
	{

		printf("\nHandleInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode);

		TWIDDLE(((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode);
		if(((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode == TC_EQU_NSE_INVITATION_REQ)
		{
			printf("\nHandleInvitationPacket Invitation Packet Received");
		}
		TWIDDLE(((struct INVITATION_PACKET *)invPacket)->sHeader.MsgLength);
		ilen = ((struct INVITATION_PACKET *)invPacket)->sHeader.MsgLength;
		MsgCode = ((struct INVITATION_PACKET *)invPacket)->sHeader.MsgCode;
		if(MsgCode == TC_EQU_NSE_INVITATION_REQ)
		{
			TWIDDLE(((struct INVITATION_PACKET *)invPacket)->invitation_count);
			iCount = ((struct INVITATION_PACKET *)invPacket)->invitation_count;
			printf("\nReceiveInvitationPacket iCount : [%d]",iCount);
			LockShm(InvitationCountShm);
			invcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);
			if ( *( (int *) invcount) == ERROR )
			{
				printf ("\n Error in Creating Shm \n");
				exit(1);
			}
			invcount->InvCount_group[gid].InvPacketCount = invcount->InvCount_group[gid].InvPacketCount + iCount;
			printf("\nNitish here is %d count %d\n",invcount->InvCount_group[gid].InvPacketCount,iCount);
			printf("\n alok testing bfr CloseSharedMemory ");

			if ( CloseSharedMemory( (void * ) invcount ) == ERROR )
			{
				printf ("\n Error in Closing Shm \n");
				exit(1);
			}
			UnLockShm(InvitationCountShm);

			/**** TAP Reg Changes *****/ 
			RecieveSeq ++;
			Seq_No =  RecieveSeq ; 

			CounterTotalInvite++;
			fflush(fpOrderNum);
			printf("\n\n\t======================= Handle Invitation Packet : [%d] =========================",Seq_No);
		}
		else
		{
			printf("\n in flase cae of Handle Invitation Packet ");
			return FALSE;
		}	
	}
	printf("\n returning true in Handle inv packet");
	return TRUE;
}


void ConvertSeqNO(CHAR *recvgen, CHAR *TempSeqNo)
{

	char  SeqArr1[2];
	short seq1=0;
	short i;
	int temp = 0;
	char *recv_temp;
	char ProgTime[40];
	USHORT d[16];    
	recv_temp = (char *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	printf("\n ----------In ConvertSeqNO Function: ------------");
	memset( SeqArr1,'\0',2);  
	recv_temp = recvgen;
	d[0]    =          ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b1 ;
	d[1]    =          ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b2 ;
	d[2]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b3 ;
	d[3]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b4 ;
	d[4]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b5 ;
	d[5]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b6 ;
	d[6]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b7 ;
	d[7]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b8 ;
	d[8]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b9 ;
	d[9]    =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b10 ;
	d[10]   =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b11 ;
	d[11]   =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b12 ;
	d[12]   =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b13 ;
	d[13]   =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b14 ;
	d[14]   =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b15 ;
	d[15]   =           ((struct NNF_ORDER_ENTRY *)recv_temp)->pExchRsrvdFlds.b16 ;
	printf("\n------------------ Seq [%s] \n",((struct NNF_ORDER_ENTRY *)recv_temp)->sSeq);

	memcpy(SeqArr1,((struct NNF_ORDER_ENTRY *)recv_temp)->sSeq,2);
	seq1 = atoi(SeqArr1);
	printf("\n----------------------------- seq1 [%d]\n", seq1);
	/***    */    for(i=0;i<=15;i++)
	{
		printf("\t [%d] ",d[i]);
	} /****/
	i=15;
	temp = d[i];
	while(i>0)
	{
		temp = temp * 2 + d[i-1];
		i--;
	}
	temp = temp + seq1*65535 ;
	sprintf( TempSeqNo, "%d"    , temp);
	printf("\n In ConvertSeqNO function TempSeqNo is : [%s]\n",TempSeqNo);
}

void fInitSharedMemory(LONG32 gid )  /** Added for inv initialization **/
{
	LONG32 groupid;
	struct InvitationCount * invcount;
	groupid = gid -1;
	LockShm(InvitationCountShm);
	invcount = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE);
	if ( *( (int *) invcount) == ERROR )
	{
		logError ("\n Error in Creating Shm \n");
		exit(1);
	}

	invcount->InvCount_group[groupid].InvPacketCount=0;
	logDebug1("SHARED MEMORY INITIAL VALUE[%d]",invcount->InvCount_group[groupid].InvPacketCount);
	if ( CloseSharedMemory( (void * ) invcount ) == ERROR )
	{
		logError ("\n Error in Closing Shm \n");
		exit(1);
	}
	UnLockShm(InvitationCountShm);

}

/*************** TAP Reg Changes*******************/
void UpdateTimeStamp( )  
{

	SHORT j;

	LONG32   groupid=0;
	SHORT    StreamId =0;
	ULONG32  Time1 =0;
	ULONG32  Time2 =0 ; 

	printf("\n GlobGroupId : %d", GlobGroupId);
	groupid =GlobGroupId;
	printf("\n  Local groupid : %d", groupid);

	printf("\n===========GlobGroupId [%d]====Updating  Timestamp \n",groupid);
	for ( j=1 ; j <= TotalStream; j++)
	{
		StreamId = Msg_Dow_Data[j].Stream_Id ;
		Time1    = Msg_Dow_Data[j].TimeStamp1 ;
		Time2    = Msg_Dow_Data[j].TimeStamp2 ; 

		printf("\n StreamId : %d Time1 :%u Time2 :%u ", StreamId, Time1, Time2); 
		/****** EXEC SQL UPDATE EXCH_DOWNLOAD_DIGITAL 
		  SET EDD_TIMESTAMP1 = :Time1 ,
		  EDD_TIMESTAMP2 =:Time2  
		  WHERE EDD_STREAM_ID = :StreamId  
		  AND	EDD_EXCH_ID='NSE'
		  AND EDD_DRV_FLAG='N'
		  AND EDD_GROUP_ID=:groupid;

		  if ( sqlca.sqlcode != 0 )
		  {
		  printf("\n Error in updating EAM for GlobGroupId %d is %d ",GlobGroupId,sqlca.sqlcode );
		  printf ("\n\tOracle error : %s",sqlca.sqlerrm.sqlerrmc);
		  EXEC SQL ROLLBACK;
		  }
		  EXEC SQL COMMIT;*****/

	}

}


BOOL InsertExchDigital( )
{

	SHORT  NoStreams =0, j=0;

	LONG32   groupid=0;
	SHORT    StreamId =0;
	ULONG32  Time1 =0;
	ULONG32  Time2 =0 ;

	printf("\n GlobGroupId : %d TotalStream :%d ", GlobGroupId, TotalStream);
	groupid =GlobGroupId;
	NoStreams = TotalStream ;
	printf("\n  Local groupid : %d", groupid);

	printf("\n===========GlobGroupId [%d]== TotalStream [%d]== \n",groupid, NoStreams);
	for ( j=1 ; j <= NoStreams; j++)
	{
		StreamId = j;

		/*****                          EXEC SQL SELECT EDD_TIMESTAMP1, EDD_TIMESTAMP2
INTO :Time1, :Time2
FROM EXCH_DOWNLOAD_DIGITAL
WHERE EDD_STREAM_ID = :StreamId
AND EDD_EXCH_ID='NSE'
AND EDD_DRV_FLAG='N'
AND EDD_GROUP_ID=:groupid ;

if ( sqlca.sqlcode ==1403 || sqlca.sqlcode == -1403)
{
printf("\n Inside Insertion EXCH_DOWNLOAD_DIGITAL  :%d", StreamId);
EXEC SQL INSERT INTO  EXCH_DOWNLOAD_DIGITAL (
EDD_GROUP_ID,
EDD_EXCH_ID,
EDD_DRV_FLAG,
EDD_STREAM_ID,
EDD_TIMESTAMP1,
EDD_TIMESTAMP2)
VALUES (
:groupid,
'NSE',
'N',
:StreamId,
0,
0 );

if ( sqlca.sqlcode != 0 )
{
printf("\n Error in Inserting EDD for StreamId %d is %d ",StreamId ,sqlca.sqlcode );
printf ("\n\tOracle error : %s",sqlca.sqlerrm.sqlerrmc);
EXEC SQL ROLLBACK;
}
EXEC SQL COMMIT;
}
else if ( sqlca.sqlcode != 0)
{
printf("\n Error in Selecting EDD for StreamId %d is %d ",StreamId ,sqlca.sqlcode );
return FALSE;
}
printf("\n Successfully selected from EDD for Stream %d is %d ",StreamId ,sqlca.sqlcode );
		 ******/
		}
return TRUE ;

}

/************ END of TAP Reg Changes*******************/

