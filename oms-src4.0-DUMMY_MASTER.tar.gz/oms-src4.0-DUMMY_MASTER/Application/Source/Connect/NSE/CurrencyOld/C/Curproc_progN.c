/***#include "falloverN.h"
#include "IntBcastStructs.h"

#include "Comm_def.h"
#include  "Common.h"***/
#include <sys/socket.h>
#include "IPCS.h"
#include "NNFCurrStruct.h"
#include <time.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

/***EXEC SQL INCLUDE sqlca.h;***/

//static	LONG32	tHostPCTimeDiff ;

LONG32 	iSockfdBroad  ;
extern 	CHAR	cMulticastFlg; 
//extern 	CHAR 	exchange[EXCHANGE_LEN]; 
extern 	DBConDrvNNF;
//CHAR 	*GcPlainKey; 
extern 	CHAR 	sKey[DB_KEY_LEN];
extern  LONG32  iGlobGroupId;
extern  SHORT   iTotalStream;
BOOL 	fInsertExchDigital(SHORT iNumOfStream); 
SHORT  	fTrim( CHAR *string , SHORT MaxLen );
extern  LONG32 iTmpTradeId ;
extern  LONG32 iJiffyTime;
void 	convert_seconds_to_date(LONG32 seconds,CHAR *pDateTime);
extern  LONG32 iGrSockFd;	
extern  CHAR sSessionKey[NNF_SESSION_KEY_LEN];	
/*******************************************************

  Function Name : UpdateSignOnResponse

Parameters :
NNF_SIGNON_RESP     *spSignOnResp

Functionality : Updates Sign On Response

Return Values : True/False

Tables Accessed :
EXCH_ADMINISTRATION_MASTER (update)
 *******************************************************/

BOOL	fUpdateSignOnResponse(struct NNF_SIGNON_RESP *spSignOnResp,LONG32 iGroupId)
{
	logTimestamp("Entry : fUpdateSignOnResponse");

	CHAR	sLastPasswordChangeDate[DATE_STRING_LENGTH];
	CHAR    sLastMktCloseTime[DATE_STRING_LENGTH];
	LONG32  iSys_julitime;
	LONG32  iNse_julitime;
	LONG32  iOffset_julitime;
	CHAR    cConnectedToExch ;//= CONNECTED_TO_EXCH ;
	CHAR    sUptQuery [MAX_QUERY_SIZE];

	MYSQL_RES	*Res;
	MYSQL_ROW       Row;

	CHAR	vLastMktCloseTime[DATE_STRING_LENGTH];
	CHAR    vLastPasswordChangeDate[DATE_STRING_LENGTH];
	memset(sUptQuery,'\0',MAX_QUERY_SIZE);

	LONG32	iCtr;
	logDebug3("UpdateSignOnResponse:NO ENCRYPT");
	if(mysql_query(DBConDrvNNF,"SELECT julidate(now()) from dual;")!= SUCCESS)
	{
		sql_Error(DBConDrvNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConDrvNNF);

	while((Row = mysql_fetch_row(Res)))
	{
		iSys_julitime = atoi(Row[0]);
	}
	logDebug3("Sys_julitime :%d:",iSys_julitime);

	mysql_free_result(Res);

	logDebug3("Sysjulitime is :%d  Nsejulitime is :%d",iSys_julitime,iNse_julitime);
	iOffset_julitime = iNse_julitime - iSys_julitime; 

	convert_seconds_to_date(spSignOnResp->iEndTime, sLastMktCloseTime);

#ifdef  DBG
	logDebug3("proc_progN.pc The end date is %s ",sLastMktCloseTime);	
	logDebug3("Offset juli time : %d", iOffset_julitime);
#endif

	strcpy(vLastMktCloseTime,sLastMktCloseTime);
	convert_seconds_to_date(spSignOnResp->iLastPasswordChange, sLastPasswordChangeDate);

#ifdef	DBG
	logDebug3("proc_progN.pc The password change date is %s ",sLastPasswordChangeDate); 	 
	logDebug3("proc_progN.pc spSignOnResp->UserId : %d ", spSignOnResp->iUserId );
#endif
	logDebug3("After Twiddle proc_progN.pc spSignOnResp->UserId : %d ", spSignOnResp->iUserId );

	logDebug3("::UpdateSignOnResponse:spSignOnResp->Password = Len [%d] [%s]",strlen(spSignOnResp->sPassword),spSignOnResp->sPassword);

	strcpy(vLastPasswordChangeDate,sLastPasswordChangeDate);


	fTrim(spSignOnResp->sPassword,NSE_PASSWORD_LEN);
	fTrim(spSignOnResp->sTraderName,TRADER_NAME_LEN);

	if(spSignOnResp->sHeader.iErrorCode == 0)
	{
		cConnectedToExch = CONNECTED_TO_EXCH ;


		sprintf(sUptQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
			EAM_OLD_PASSWORD = aes_encrypt(\"%s\",\"%s\"),\
			EAM_NEW_PASSWORD = NULL, \
			EAM_TRADER_NAME = \"%s\",\
			EAM_EXCH_OFFSET_TIME = %d,\
			EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'), \
			EAM_BRANCH_ID = %d ,\
			EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
			EAM_BROKER_STATUS = \'%c\',\
			EAM_LOGON_STATUS = \'%c\',\
			EAM_REASON_DESC = ifNULL((select RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \'%s\' and RM_ERR_CODE = \'%d\'),'Connected'),\
			EAM_ERROR_ID = \'%d\' \	
			WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
			EAM_EXCH_USER_ID = %d AND \
			EAM_SEGMENT = \'%c\' AND \
			EAM_GROUP_ID = %d;",spSignOnResp->sPassword,sKey,spSignOnResp->sTraderName,iOffset_julitime,sLastPasswordChangeDate,
			spSignOnResp->iBranchId,sLastMktCloseTime,spSignOnResp->cBrokerStatus,cConnectedToExch,NSE_EXCH,
			spSignOnResp->sHeader.iErrorCode,spSignOnResp->sHeader.iErrorCode,NSE_EXCH,spSignOnResp->iUserId,CURRENCY_SEGMENT,iGroupId);
	}
	else
	{
		cConnectedToExch = EXCH_REJECT_STATUS;
		sprintf(sUptQuery,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
			EAM_EXCH_OFFSET_TIME = %d,\
			EAM_LAST_PASSWORD_CHANGE_DATE = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'), \
			EAM_LAST_MKT_CLOSE_TIME = STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
			EAM_LOGON_STATUS = \'%c\',\
			EAM_REASON_DESC = ifNULL((select RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \'%s\' and RM_ERR_CODE = \'%d\'),'Connected'),\
			EAM_ERROR_ID = \'%d\' \
			WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
			EAM_EXCH_USER_ID = %d AND \
			EAM_SEGMENT = \'%c\' AND \
			EAM_GROUP_ID = %d;",iOffset_julitime,sLastPasswordChangeDate,
			sLastMktCloseTime,cConnectedToExch,NSE_EXCH,
			spSignOnResp->sHeader.iErrorCode,spSignOnResp->sHeader.iErrorCode,NSE_EXCH,spSignOnResp->iUserId,CURRENCY_SEGMENT,iGroupId);	

	}

	logDebug3("Query-> :%s:",sUptQuery);

	if(mysql_query(DBConDrvNNF,sUptQuery) != SUCCESS)
	{
		sql_Error(DBConDrvNNF);
		//free(sUptQuery);
		return ERROR;
	}
	else
	{
		logDebug3("%d rows affected ",mysql_affected_rows(DBConDrvNNF));
		mysql_commit(DBConDrvNNF);
		//free(sUptQuery);	
		return TRUE;

	}

	logTimestamp("exit : fUpdateSignOnResponse");

}

/*******************************************************

  Function Name : fUpdateSysInfoResp

Parameters :
struct NNF_SYS_INFO_RESP   *spSysInfoResp

Functionality : Updates pSystem information pResponse  

Return Values : True/False

Tables Accessed :
DRV_MAPPING_MASTER (select)
DRV_EXCH_MKT_MASTER (update)
EXCH_MASTER (update)
EXCH_ADMINISTRATION_MASTER (update)
TRADE_LMT_ALT_EXP_MASTER (Update)
DRV_NSE_SECURITY_MASTER (update)	  

Assumptions :
NORMAL_MARKET                            1
ODDLOT_MARKET                            2
SPOT_MARKET                              3
AUCTION_MARKET                           4
 *******************************************************/
BOOL	fUpdateSysInfoResp(struct NNF_SYS_INFO_RESP   *spSysInfoResp )
{
	logTimestamp("Entry : fUpdateSysInfoResp");
	//	BOOL	validpResp = FALSE;
	//    	DOUBLE64 tempBaseCap;

	/****	SHORT	lNormalMkt  = NORMAL_MARKET ;
	  SHORT   lOddLotMkt  = ODDLOT_MARKET ;
	  SHORT   lSpotMkt    = SPOT_MARKET   ;
	  SHORT   lAuctionMkt = AUCTION_MARKET;

	  EXEC SQL BEGIN DECLARE SECTION;
	  VARCHAR 	Aonallowed[2];
	  VARCHAR 	MFallowed[2];
	  VARCHAR 	tempMktType[5];
	  LONG32 		tmpMarketIndex;
	  INT16 		tmpGTCdays;
	  INT16  		tempSettlPeriod;
	  VARCHAR     exchId[EXCHANGE_LEN];
	  CHAR        drvFlg='Y'; 
	  EXEC SQL END DECLARE SECTION;

	  strcpy(procname,"fUpdateSysInfoResp");
	  strcpy(tablename,"DRV_MAPPING_MASTER");
	  strcpy(filename,"proc_progN.pc");

	  VMEMCPY(exchId,exchange,EXCHANGE_LEN);

	  memset(tempMktType.arr,' ',5);
	  memset(Aonallowed.arr,' ',2);
	  memset(MFallowed.arr,' ',2);

	  EXEC SQL SELECT MM_TYPE_ID 
INTO :tempMktType
FROM DRV_MAPPING_MASTER
WHERE 	MM_EXCH_TYPE_ID = :lNormalMkt AND
MM_TYPE_NAME 	= 'MKT' 		AND 
MM_EXCH_ID 		= ltrim(rtrim(:exchId));

if (sqlca.sqlcode != 0)
{
logDebug3("\nUpdateSysInfo: Error in Selecting MM_TYPE_ID from DRV_MAPPING_MASTER is :%d",sqlca.sqlcode);
return FALSE;
}

logDebug3("\n chk 1 "); 

strcpy(tablename,"DRV_EXCH_MKT_MASTER");
EXEC SQL UPDATE DRV_EXCH_MKT_MASTER
SET
EMM_STATUS 		= to_CHAR(:spSysInfoResp->MarketStatus.Normal),
EMM_SETTLEMENT_PERIOD 	= :spSysInfoResp->DefaultSettNormal,
EMM_DRV_EX_STATUS =to_CHAR(:spSysInfoResp->sExStatus.Normal),
EMM_DRV_PL_STATUS = to_CHAR(:spSysInfoResp->sPlStatus.Normal)
WHERE
EMM_MKT_TYPE 	= :tempMktType AND
EMM_EXM_EXCH_ID ='NSE'
AND EMM_MKT_SEGMENT = 'D';

if (sqlca.sqlcode != 0)
{
logDebug3("\nUpdateSysInfo: ERROR in Updating DRV_EXCH_MKT_MASTER is :%d",sqlca.sqlcode);
	//		return FALSE;
	}


	logDebug3("\n chk 1 "); 
	strcpy(tablename,"DRV_MAPPING_MASTER");
	EXEC SQL SELECT MM_TYPE_ID INTO :tempMktType
	FROM DRV_MAPPING_MASTER
	WHERE MM_EXCH_TYPE_ID = :lOddLotMkt AND
	MM_TYPE_NAME = 'MKT' AND MM_EXCH_ID = 'NSE';

#ifdef     DBG
logDebug3("\nproc_progN.pc The sError code is %d and %s ",sqlca.sqlcode,tablename);
#endif

if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;
	strcpy(tablename,"DRV_EXCH_MKT_MASTER");
	EXEC SQL UPDATE DRV_EXCH_MKT_MASTER
	SET
EMM_STATUS = to_CHAR(:spSysInfoResp->MarketStatus.Oddlot),
	   EMM_DRV_EX_STATUS =to_CHAR(:spSysInfoResp->sExStatus.Oddlot),
	   EMM_DRV_PL_STATUS = to_CHAR(:spSysInfoResp->sPlStatus.Oddlot)
	WHERE
	EMM_MKT_TYPE = :tempMktType  AND
	EMM_EXM_EXCH_ID  = 'NSE'
	AND EMM_MKT_SEGMENT = 'D';
#ifdef     DBG

	logDebug3("\n chk 1 tempMktType %s ", tempMktType.arr); 

	logDebug3("\nproc_progN.pc The sError code is %d and %s ",sqlca.sqlcode,tablename);
#endif
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;




	strcpy(tablename,"DRV_MAPPING_MASTER");
	EXEC SQL SELECT MM_TYPE_ID INTO :tempMktType
	FROM DRV_MAPPING_MASTER
	WHERE MM_EXCH_TYPE_ID = :lSpotMkt AND
	MM_TYPE_NAME = 'MKT' AND MM_EXCH_ID = 'NSE';
#ifdef     DBG

	logDebug3("\n :lSpotMkt = %d ", lSpotMkt);
	logDebug3("\nproc_progN.pc The sError code is %d and %s ",sqlca.sqlcode,tablename);
#endif
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;

	logDebug3("\n chk 1 "); 
	strcpy(tablename,"DRV_EXCH_MKT_MASTER");
	tempSettlPeriod = spSysInfoResp->DefaultSettSpot ;
	EXEC SQL UPDATE DRV_EXCH_MKT_MASTER
	SET
EMM_STATUS = to_CHAR(:spSysInfoResp->MarketStatus.Spot),
	   EMM_SETTLEMENT_PERIOD = :tempSettlPeriod,
	   EMM_DRV_EX_STATUS =to_CHAR(:spSysInfoResp->sExStatus.Spot),
	   EMM_DRV_PL_STATUS = to_CHAR(:spSysInfoResp->sPlStatus.Spot)
	WHERE
	EMM_MKT_TYPE = :tempMktType  AND
	EMM_EXM_EXCH_ID  = 'NSE'
	AND EMM_MKT_SEGMENT = 'D';
#ifdef     DBG

	logDebug3("\n :tempMktType %s", tempMktType.arr);

	logDebug3("\nproc_progN.pc The sError code is %d and %s ",sqlca.sqlcode,tablename);
#endif
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;


	strcpy(tablename,"DRV_MAPPING_MASTER");
	EXEC SQL SELECT MM_TYPE_ID INTO :tempMktType
	FROM DRV_MAPPING_MASTER
	WHERE MM_EXCH_TYPE_ID = :lAuctionMkt AND
	MM_TYPE_NAME = 'MKT' AND MM_EXCH_ID = 'NSE';
#ifdef     DBG
	logDebug3("\nproc_progN.pc The sError code is %d and %s ",sqlca.sqlcode,tablename);
#endif
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;

	strcpy(tablename,"DRV_EXCH_MKT_MASTER");
	EXEC SQL UPDATE DRV_EXCH_MKT_MASTER
	SET
EMM_STATUS = to_CHAR(:spSysInfoResp->MarketStatus.Auction),
	   EMM_SETTLEMENT_PERIOD = :spSysInfoResp->DefaultSettAuction,
	   EMM_DRV_EX_STATUS =to_CHAR(:spSysInfoResp->sExStatus.Auction),
	   EMM_DRV_PL_STATUS = to_CHAR(:spSysInfoResp->sPlStatus.Auction)
	WHERE
	EMM_MKT_TYPE = :tempMktType  AND
	EMM_EXM_EXCH_ID  = 'NSE'
	AND EMM_MKT_SEGMENT = 'D';
#ifdef     DBG
	logDebug3("\nproc_progN.pc The sError code is %d and %s ",sqlca.sqlcode,tablename);
#endif
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;






if (spSysInfoResp->StockEligibilityInd.uiMinFill)
	memcpy(Aonallowed.arr,"1",1);
	else
	memcpy(Aonallowed.arr,"0",1);

if (spSysInfoResp->StockEligibilityInd.uiAON)
	memcpy(MFallowed.arr,"1",1);
	else
	memcpy(MFallowed.arr,"0",1);

	Aonallowed.len 	=1;
	MFallowed.len 	=1;

#ifdef	DBG
	logDebug3("\n spSysInfoResp->UpdatePortFolio	:%c",spSysInfoResp->UpdatePortFolio);
	logDebug3("\n spSysInfoResp->MaxGtcDays		:%u",spSysInfoResp->MaxGtcDays);
	logDebug3("\n spSysInfoResp->DiscQty			:%u",spSysInfoResp->DiscQty);
	logDebug3("\n spSysInfoResp->DefaultSettNormal	:%u",spSysInfoResp->DefaultSettNormal);
	logDebug3("\n spSysInfoResp->MktIndex			:%d",spSysInfoResp->MktIndex);
	logDebug3("\n spSysInfoResp->CompetitorPeriod	:%u",spSysInfoResp->CompetitorPeriod);
	logDebug3("\n spSysInfoResp->SolicitorPeriod	:%u",spSysInfoResp->SolicitorPeriod);
	logDebug3("\n spSysInfoResp->WarnigPercent		:%u",spSysInfoResp->WarnigPercent);
	logDebug3("\n spSysInfoResp->VolFreezePercent	:%u",spSysInfoResp->VolFreezePercent);
	logDebug3("\n spSysInfoResp->BoardLotQty		:%d",spSysInfoResp->BoardLotQty);
	logDebug3("\n spSysInfoResp->TickSize			:%ld",spSysInfoResp->TickSize);

	logDebug3("\n MFallowed						:%.2s",MFallowed.arr);
	logDebug3("\n AONallowed						:%.2s",Aonallowed.arr);
#endif


if (spSysInfoResp->sHeader.iMsgCode == TC_DRV_NSE_SYS_INFO_RESP  )	
{
	EXEC SQL UPDATE EXCH_MASTER
		SET
		EXM_DRV_MAX_GTC_DAYS			= :spSysInfoResp->MaxGtcDays,
							EXM_DRV_DISCLOSE_QTY 			= :spSysInfoResp->DiscQty,
							EXM_DRV_NO_OF_SETTLEMENT_DAYS		= :spSysInfoResp->DefaultSettNormal,
							EXM_DRV_MKT_INDEX 			= :spSysInfoResp->MktIndex,
							EXM_DRV_COMPETITOR_PERIOD		= :spSysInfoResp->CompetitorPeriod,
							EXM_DRV_SOLICITOR_PERIOD 		= :spSysInfoResp->SolicitorPeriod,
							EXM_WARNING_PCT 			= :spSysInfoResp->WarnigPercent,
							EXM_DRV_VOL_FREEZE_PCT 			= :spSysInfoResp->VolFreezePercent,
							EXM_DRV_BOARD_LOT_QTY 			= :spSysInfoResp->BoardLotQty,
							EXM_DRV_TICK_SIZE 			= :spSysInfoResp->TickSize,
							EXM_DRV_MF_FLG 				= trim(:MFallowed),
							EXM_DRV_AON_FLG 			= trim(:Aonallowed),
							EXM_DRV_PORTFOLIO_FLG			= :spSysInfoResp->UpdatePortFolio
								WHERE
								EXM_EXCH_ID	= 'NSE';
}

if (sqlca.sqlcode != 0)
{
	logDebug3("\nUpdateSysInfo: ERROR in Updating EXCH_MASTER is :%d",sqlca.sqlcode);
	EXEC SQL ROLLBACK;
	//		return FALSE;
}
EXEC SQL COMMIT;
*****/
logTimestamp("exit : fUpdateSysInfoResp");
return TRUE;

}

BOOL	fHandleSQL(LONG32 iCode, CHAR *cModule,CHAR *sFile,CHAR *sTable)
{
	logTimestamp("Entry : fHandleSQL");

	CHAR	*sError;
	CHAR 	*sAdd;

	LONG32	iResult,iQid;
	sError = (CHAR *)malloc(ERROR_STRING_LEN);
	sAdd = (CHAR *)malloc(6);

	memset(sError,NULL,ERROR_STRING_LEN);

	strcpy(sError,"SQL ERROR: ");
	sprintf(sAdd,"%d",iCode);
	strcat(sError,sAdd);
	strcat(sError,sFile);
	strcat(sError,cModule);
	strcat(sError,sTable);

	free(sError);
	free(sAdd);
	/*****

	  if ((code == 0) || (code == 8224))
	  return TRUE;
	  else
	  {
	  EXEC SQL ROLLBACK;
	  return FALSE;
	  }*****/

	logTimestamp("exit : fHandleSQL");
}

BOOL	fSendsignon(CHAR *sSendnnf, LONG32 iGroupid)
{
	logTimestamp("Entry : fSendsignon");

	struct	NNF_SIGNON_REQ	*pSign;
	//	LONG32 	logonreq_result;

	MYSQL_RES	*Res;
	MYSQL_ROW        Row;

	CHAR 	sUserID [5];
	CHAR 	*sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pSign = (struct NNF_SIGNON_REQ *)malloc(sizeof(struct NNF_SIGNON_REQ));
	memset((CHAR*)pSign,' ',sizeof(struct NNF_SIGNON_REQ));
	memcpy(pSign,sSendnnf,sizeof(struct NNF_SIGNON_REQ));

#ifdef  DBG
	logDebug3("sendsignon: Before Calling PLogOnR..");
#endif
	/*****
	  if ((logonreq_result = PLogOnR(pSign ,iGroupid )) == FALSE)
	  {
	  logDebug3("\nsendsignon: ERROR in getting sData from PlogOnR ... returning FALSE");
	  return FALSE;
	  }
	 ***/
	/*****************
	  pSign->SequenceNumber = 127823 ;
	  logDebug3("\nsendsignon SequenceNumber	:%ld",pSign->SequenceNumber);
	  pSign->BranchId	= 1 ;
	  pSign->BrokerStatus = 'A' ;
	  pSign->UserType = 5 ;
	 ******************/

	memset(sUserID,'\0',5);
	pSign->sHeader.iErrorCode = 0 ;

	pSign->sHeader.iLogTimeStamp = 0 ;
	pSign->sHeader.iMsgCode = TC_EQU_NSE_SIGNON_REQ;
	memset(pSign->sHeader.sAlphaSplit,' ',2);
	memcpy(pSign->sHeader.sAlphaSplit,"NT",2);
	memset(pSign->sHeader.sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
        memset(pSign->sHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
        memset(pSign->sHeader.sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
        memset(pSign->sHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
        memset(pSign->sHeader.sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
        memset(pSign->sHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pSign->sHeader.iMsgLength = sizeof(struct NNF_SIGNON_REQ);

	logDebug3("sizeof(struct NNF_SIGNON_REQ) :%d:",sizeof(struct NNF_SIGNON_REQ));
	/****
	  strncpy(sUserID,"0049",5);
	  pSign->UserId = atoi(sUserID);
	  strcpy(pSign->Password,"Algo@la6");
	  strcpy(pSign->NewPassword,"        ");
	  strcpy(pSign->sBrokerCode,"90066");
	  strcpy(pSign->BrokerName,"RAMACHANDRAN C R");
	  pSign->BrokerStatus = 'A' ;
	  pSign->SequenceNumber = 127823 ;
	  pSign->BranchId  = 19 ;
	  pSign->VersionNumber = 93600;	
	 ******/
	/**
	  sprintf(sQuery,"SELECT   EAM_EXCH_USER_ID,\
	  EAM_OLD_PASSWORD,\
	  IFNULL(aes_decrypt(EAM_NEW_PASSWORD,\'%s\'),'1') EAM_NEW_PASSWORD,\
	  EAM_BROKER_ID,\
	  EAM_VERSION_NO,\
	  EAM_WORKSTATION_ADDRESS,\
	  EAM_TRADER_NAME,\
	  EAM_BROKER_STATUS,\
	  EAM_BRANCH_ID,\
	  EAM_EXCH_USER_TYPE\
	  FROM EXCH_ADMINISTRATION_MASTER \
	  WHERE EAM_GROUP_ID= 1 AND EAM_EXM_EXCH_ID = \"NSE\" AND EAM_DRV_FLAG=\'Y\' ");
	 ***/

	sprintf(sQuery,"SELECT	EAM_EXCH_USER_ID,\
			aes_decrypt(EAM_OLD_PASSWORD,\'%s\'),\
			IFNULL(aes_decrypt(EAM_NEW_PASSWORD,\'%s\'),'1') EAM_NEW_PASSWORD,\
			EAM_BROKER_ID,\
			EAM_VERSION_NO,\
			EAM_WORKSTATION_ADDRESS,\
			EAM_TRADER_NAME,\
			EAM_BROKER_STATUS,\
			EAM_BRANCH_ID,\
			EAM_EXCH_USER_TYPE\
			FROM EXCH_ADMINISTRATION_MASTER \
			WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\'; ",sKey,sKey,iGroupid,NSE_EXCH,CURRENCY_SEGMENT);

	logDebug2("sQuery :%s:",sQuery);

	if (mysql_query(DBConDrvNNF, sQuery) != SUCCESS) 
	{
		sql_Error(DBConDrvNNF);
		return ERROR;
	}

	Res = mysql_store_result(DBConDrvNNF);

	free(sQuery);

	while((Row = mysql_fetch_row(Res)))
	{
		pSign->sHeader.iTraderID = atoi(Row[0]);
		pSign->iUserId= atoi(Row[0]);
		memset(pSign->sReserved5,' ',8);
		strncpy(pSign->sPassword,Row[1],8);
		memset(pSign->sReserved6,' ',8);
		if(Row[2][0] != '1')
		{
			logDebug3("NewPassword is Not Null");
			strncpy(pSign->sNewPassword,Row[2],8);
		}
		else
		{
			logDebug3("NewPassword is Null");
			memset(pSign->sNewPassword,' ',8);
		}
		memset(pSign->sTraderName,Row[6],TRADER_NAME_LEN);
		pSign->iLastPasswdChangetime= 0;	
		strncpy(pSign->sBrokerCode,Row[3],BROKER_CODE_LEN);
		pSign->iBranchId= atoi(Row[8]); 
		pSign->iVersionNumber= atoi(Row[4]);

		pSign->iUserType= atoi(Row[9]); 
		pSign->fSequenceNumber= 0; 
		strncpy(pSign->sWorkstationAddr,Row[5],WORK_STATION_ADDR_LEN);

		pSign->cBrokerStat= SPACE; 
		pSign->cShowIndex= 'T'; 
		memset(pSign->sReserved3,' ',2);
		pSign->cClearingStatus= SPACE; 


		memset(pSign->sBrokerName,' ',DRV_BROKER_NAME_LEN);
		strncpy(pSign->sBrokerName,Row[6],DRV_BROKER_NAME_LEN);
		memset(pSign->sReserved5,' ',16);
		memset(pSign->sReserved6,' ',16);
		memset(pSign->sReserved7,' ',16);


	}

#ifdef	DBG
	logDebug3("sendsignon UserId		:%d ",pSign->iUserId);
	logDebug3("sendsignon Password		:%s:",pSign->sPassword);
	logDebug3("sendsignon New Password	:%s:",pSign->sNewPassword);
	logDebug3("sendsignon Trader Name	:%s:",pSign->sTraderName);
	logDebug3("sendsignon LastPasswdChgDt	:%d",pSign->iLastPasswdChangetime);	
	logDebug3("sendsignon Broker Code 	:%s:",pSign->sBrokerCode);
	logDebug3("sendsignon Branch Id		:%u:",pSign->iBranchId);
	logDebug3("sendsignon Version Number 	:%d:",pSign->iVersionNumber);
	logDebug3("sendsignon UserType		:%d:",pSign->iUserType);
	logDebug3("sendsignon SequenceNumber	:%lf:",pSign->fSequenceNumber);
	logDebug3("sendsignon Broker Status	:%c:",pSign->cBrokerStat);
	logDebug3("sendsignon iUserType		:%d:",pSign->iUserType);
	logDebug3("sendsignon cShowIndex	:%c:",pSign->cShowIndex);
	logDebug3("sendsignon sTimeStamp	:%ld: ",pSign->sHeader.iLogTimeStamp);
	logDebug3("sendsignon Error Code	:%d: ",pSign->sHeader.iErrorCode);
	logDebug3("sendsignon Mesg Length	:%d: ",pSign->sHeader.iMsgLength);
	logDebug3("sendsignon sAlphaSplit	:%d: ",pSign->sHeader.sAlphaSplit);
	logDebug3("sendsignon BrokerName        :%s: ",pSign->sBrokerName);
#endif

	logDebug3("After Twiddle") ;
	TWIDDLE( pSign->sHeader.iLogTimeStamp);
	TWIDDLE( pSign->sHeader.iMsgCode);
	TWIDDLE( pSign->sHeader.iErrorCode);
	TWIDDLE( pSign->sHeader.iMsgLength);
	TWIDDLE( pSign->sHeader.iTraderID);
	TWIDDLE( pSign->iUserId);
	TWIDDLE( pSign->iVersionNumber);
	TWIDDLE( pSign->iLastPasswdChangetime);
	TWIDDLE( pSign->iBranchId);
	TWIDDLE( pSign->fSequenceNumber);
	TWIDDLE( pSign->iUserType);

	memcpy(sSendnnf,pSign,sizeof(struct NNF_SIGNON_REQ));	
	free(pSign);
	logTimestamp("exit : fSendsignon");
	return TRUE;

}

BOOL	fRecvsignon ( CHAR *cTemp2 ,LONG32  iGroupId)
{
	logTimestamp("Entry : fRecvsignon");

	LONG32	iDatasent;
	struct 	NNF_SIGNON_RESP	*pRecv;

	pRecv = (struct NNF_SIGNON_RESP *)malloc(sizeof(struct NNF_SIGNON_RESP));
	memset((CHAR *)pRecv,' ',sizeof(struct NNF_SIGNON_RESP));
	memcpy(pRecv,cTemp2,sizeof(struct NNF_SIGNON_RESP));

#ifdef	DBG
	logDebug3("Recvsignon: Inside Recvsignon");
#endif

#ifdef  DBG
	logDebug3("Recvsignon: The password			: %.8s ",pRecv->sPassword);
	logDebug3("Recvsignon: The new password			: %.8s ",pRecv->sNewPassword);
	logDebug3("Recvsignon: The transcode of Response is 	: %d ",pRecv->sHeader.iMsgCode);
	logDebug3("Recvsignon: The user type sent is 		: %d ",pRecv->iUserType);
	logDebug3("Recvsignon: The broker Status is 		: %c ",pRecv->cBrokerStatus);
	logDebug3("Recvsignon: LastMktCloseTime 		: %ld", pRecv->iEndTime);
	logDebug3("Recvsignon: LastPaswdchgdate 		: %ld", pRecv->iLastPasswordChange);
	logDebug3("Recvsignon: Seq Number 			: %lf ",pRecv->fSeqNumber);
	logDebug3("Recvsignon: User id 				: %d ",pRecv->iUserId);
	logDebug3("Recvsignon: Branch id 			: %d ",pRecv->iBranchId);
	logDebug3("Recvsignon: End time  			: %ld ",pRecv->iEndTime);
	logDebug3("Recvsignon: TraderName  			: %s ",pRecv->sTraderName);
	logDebug3("Recvsignon: LastPaswdchgdate  		: %ld", pRecv->iLastPasswordChange);
	logDebug3("Recvsignon: BrokerName                   	: %s ", pRecv->sBrokerName);
	logDebug3("Before Calling UpdateSignOnResponse");
#endif

	TWIDDLE( pRecv->sHeader.iLogTimeStamp);
	TWIDDLE( pRecv->sHeader.iMsgCode);
	TWIDDLE( pRecv->sHeader.iErrorCode);
	TWIDDLE( pRecv->sHeader.iMsgLength);

	TWIDDLE( pRecv->iUserId);
	TWIDDLE( pRecv->iLastPasswordChange);
	TWIDDLE( pRecv->iBranchId);
	TWIDDLE( pRecv->fSeqNumber);
	TWIDDLE( pRecv->iVersionNumber);
	TWIDDLE( pRecv->iEndTime);
	TWIDDLE( pRecv->iUserType);

#ifdef  DBG
	logDebug3("After RecvSignon ....................");
	logDebug3("Recvsignon: The password                     : %.8s ",pRecv->sPassword);
        logDebug3("Recvsignon: The new password                 : %.8s ",pRecv->sNewPassword);
        logDebug3("Recvsignon: The transcode of Response is     : %d ",pRecv->sHeader.iMsgCode);
        logDebug3("Recvsignon: The user type sent is            : %d ",pRecv->iUserType);
        logDebug3("Recvsignon: The broker Status is             : %c ",pRecv->cBrokerStatus);
        logDebug3("Recvsignon: LastMktCloseTime                 : %ld", pRecv->iEndTime);
        logDebug3("Recvsignon: LastPaswdchgdate                 : %ld", pRecv->iLastPasswordChange);
        logDebug3("Recvsignon: Seq Number                       : %lf ",pRecv->fSeqNumber);
        logDebug3("Recvsignon: User id                          : %d ",pRecv->iUserId);
        logDebug3("Recvsignon: Branch id                        : %d ",pRecv->iBranchId);
        logDebug3("Recvsignon: End time                         : %ld ",pRecv->iEndTime);
        logDebug3("Recvsignon: TraderName                       : %s ",pRecv->sTraderName);
        logDebug3("Recvsignon: LastPaswdchgdate                 : %ld", pRecv->iLastPasswordChange);
        logDebug3("Recvsignon: BrokerName                       : %s ", pRecv->sBrokerName);
	logDebug3("Before Calling UpdateSignOnResponse");
#endif
	/**
	  if(pRecv->sHeader.iErrorCode == 0)
	  {
	  iDatasent = fUpdateSignOnResponse(pRecv);
	  }
	 **/
	iDatasent = fUpdateSignOnResponse(pRecv,iGroupId);
	/***	free(pRecv);****/
	if ( iDatasent == FALSE )			
	{					
#ifdef  DBG					
		logDebug3("Error in writing to Database ");
#endif
		return(ERROR);	
	}	
	else
	{	
#ifdef 	DBG
		logDebug3("Success ");
#endif
		return TRUE;
	}
	logTimestamp("exit : fRecvsignon");
}


BOOL	fPLogOnR(struct NNF_SIGNON_REQ *pSignOn, LONG32 iGroupid)
{
	logTimestamp("Entry : fPLogOnR");
	//	LONG32	sql_error,
	LONG32	iCtr;

	/*****
	  EXEC SQL BEGIN DECLARE SECTION;
	  VARCHAR  TempNewPassword[40];**/ /*  Additions */
	// VARCHAR  TempPassword[40]; /*  Additions */
	//VARCHAR  TempsBrokerCode[BROKER_CODE_LEN];
	//VARCHAR  v_aBrokerName[BROKER_NAME_LEN];
	//VARCHAR lvar_uid[30];		
	//VARCHAR  EncryptPassword[75]; /*  Additions */
	//VARCHAR  EncryptNewPassword[75]; /*  Additions */
	//VARCHAR exchId[EXCHANGE_LEN];
	//CHAR    drvFlg = 'Y';
	//VARCHAR GrpId[30];
	//EXEC SQL END DECLARE SECTION;

	/****        VMEMCPY(exchId,exchange,EXCHANGE_LEN);

	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=sizeof(lvar_uid.arr);

	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  logDebug3 ("\nEquNseConnect.pc Error in connecting to oracle %d",sqlca.sqlcode);
	  exit(ERROR);
	  }


	  logDebug3 ("\nEquNseConnect.pc  connecting to oracle Sucess : %s  ",lvar_uid.arr );

	  memset(GrpId.arr        ,   '\0',  30)          ;
	  sprintf(GrpId.arr,"%d",iGroupid);
	  GrpId.len=1;
	  memset(SignOn->sHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);
	  memset(SignOn->sHeader.sTimeStamp1,' ',DATE_TIME_LEN);
	  memset(SignOn->sHeader.sTimeStamp2,' ',DATE_TIME_LEN);
	  memset(SignOn->sHeader.sTimeStamp3,' ',DATE_TIME_LEN);
	  memset(SignOn->Password,' ',NSE_PASSWORD_LEN);
	  memset(SignOn->NewPassword,' ',NSE_PASSWORD_LEN);
	  memset(SignOn->sBrokerCode ,' ',BROKER_CODE_LEN);
	  memset(SignOn->BrokerName ,' ',BROKER_NAME_LEN);

	  memset(v_aBrokerName.arr,' ',BROKER_NAME_LEN);


	  memset(TempPassword.arr,'\0',40);
	  TempPassword.len=40;
	  memset(TempNewPassword.arr,' ',40);
	  TempNewPassword.len=8;
	  memset(EncryptPassword.arr,'\0',75);
	  EncryptPassword.len=75;
	  memset(EncryptNewPassword.arr,'\0',75);
	  EncryptNewPassword.len=75;


	  SignOn->sHeader.iTraderID 		= 0 ;
	  SignOn->sHeader.iLogTimeStamp 	= 0 ;
	  SignOn->sHeader.iMsgCode 		= TC_DRV_NSE_SIGNON_REQ;
	  SignOn->sHeader.iErrorCode 		= 0 ;
	  SignOn->sHeader.iMsgLength 		= sizeof(struct NNF_SIGNON_REQ);
	  logDebug3("\nTEST:iMsgLength = [%d]",SignOn->sHeader.iMsgLength);
	  memcpy( SignOn->sHeader.sAlphaSplit,"NT",2);

#ifdef DBG
logDebug3("\nPLogOnR:Messg Len is%d ",SignOn->sHeader.iMsgLength);
#endif

strcpy(procname,"PLogOnR");
strcpy(tablename,"EXCH_ADMINISTRATION_MASTER");
logDebug3("Group Id in PLogOnR : %d\n",iGroupid);

EXEC SQL SELECT 
to_number(EAM_EXCH_USER_ID),
EAM_OLD_PASSWORD,
nvl(EAM_NEW_PASSWORD ,'NULL'),
EAM_BROKER_ID,
to_number(EAM_VERSION_NO),
EAM_TRADER_NAME,
to_number(EAM_BRANCH_ID),
to_number(EAM_EXCH_USER_TYPE),
EAM_BROKER_STATUS
INTO
:SignOn->UserId,
:EncryptPassword,
:EncryptNewPassword,
:TempsBrokerCode,
	:SignOn->VersionNumber,
		:v_aBrokerName,
		:SignOn->BranchId,
		:SignOn->UserType,
		:SignOn->BrokerStatus
			FROM    EXCH_ADMINISTRATION_MASTER
			WHERE   EAM_GROUP_ID 	= to_CHAR(:iGroupid) AND 
			EAM_EXM_EXCH_ID = ltrim(rtrim(:exchId)) 
			AND EAM_DRV_FLAG    = :drvFlg;

	if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
		return FALSE;    


	EXEC SQL EXECUTE BEGIN :TempPassword := toolkit.decrypt (
			:EncryptPassword
			);

	END;
	END-EXEC;
	if (sqlca.sqlcode !=0)
	{
		logDebug3("\n Error in decrypting EncryptPassword 1 is :%d:",sqlca.sqlcode);
		exit(0);
	}

	logDebug3("\n EncryptNewPassword.arr :%s:",EncryptNewPassword.arr);

	if(strcmp(EncryptNewPassword.arr,"NULL"))
	{

		EXEC SQL EXECUTE BEGIN :TempNewPassword := toolkit.decrypt (
				:EncryptNewPassword
				);

		END;
		END-EXEC;
		if (sqlca.sqlcode !=0)
		{
			logDebug3("\n Error in decrypting EncryptPassword 1 is :%d:",sqlca.sqlcode);
			exit(0);
		}
		TempNewPassword.len = 8;

	}

	logDebug3("\n ALOKK U r here TempNewPassword :%s: TempNewPassword.len:%d:",TempNewPassword.arr,TempNewPassword.len);

	memcpy(SignOn->Password,TempPassword.arr,TempPassword.len);
	memcpy(SignOn->NewPassword,TempNewPassword.arr,TempNewPassword.len);****/
		/*****memcpy(SignOn->NewPassword,"        ",8);****/
		/*****         logDebug3("\nNormal Password :[%s]",SignOn->Password);
		  logDebug3("\n Normal New Password [%s]",SignOn->NewPassword);



		  memcpy(SignOn->sBrokerCode,TempsBrokerCode.arr,TempsBrokerCode.len);
		  memcpy(SignOn->BrokerName,v_aBrokerName.arr,v_aBrokerName.len);

#ifdef     DBG
logDebug3("\n:####### Signon Passwd 	:[%.*s]:",strlen(SignOn->Password),SignOn->Password);
logDebug3("\n:######   New Passwd 		:[%.*s]:",strlen(SignOn->NewPassword),SignOn->NewPassword);
logDebug3("\nPlogOnR: sBrokerCode   	:[%.*s]",strlen(SignOn->sBrokerCode),SignOn->sBrokerCode);
logDebug3("\nPlogOnR: Error Code		:%d\n",sqlca.sqlcode);
logDebug3("\nPlogOnR: BrokerName       :%s\n",SignOn->BrokerName);
#endif

EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
SET EAM_LOGON_STATUS = DISCONNECTED_FROM_EXCH
WHERE 	EAM_EXM_EXCH_ID = ltrim(rtrim(:exchId))	AND 
EAM_GROUP_ID 	= to_CHAR(:iGroupid) AND
EAM_DRV_FLAG	= :drvFlg; 

SignOn->SequenceNumber = 0.0 ;
logDebug3("\nPlogOnR: SequenceNumber		:%d\n",SignOn->SequenceNumber);


if (HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

EXEC SQL COMMIT ;


#ifdef     DBG
logDebug3("\nPLogOnR: Error in Updation of Exch_Admn_Master is %d ",sqlca.sqlcode);
logDebug3("\nPlogOnR: After Updating EXCH_ADMN_MASTER\n");
#endif

if (sqlca.sqlcode == 0)
return TRUE;
else
return FALSE;****/
		logTimestamp("exit : fPLogOnR");
	return	TRUE;

}


BOOL 	fSendsysinfo(CHAR *sNNF )
{
	logTimestamp("Entry : fSendsysinfo");

	struct 	NNF_SYS_INFO_REQ 	*pSys;/*****
						EXEC SQL BEGIN DECLARE SECTION;
						LONG32 	portfolioDate =0;	
						EXEC SQL END DECLARE SECTION;



						EXEC SQL SELECT max(JULIDATE(PL_UPDATE_DATETIME))
INTO :portfolioDate
FROM DRV_PORTFOLIO_LDB;

if (sqlca.sqlcode != 0)
{
logDebug3("\nsendsysinfo:Error in Selecting the PortfolioDate from Exch_Admn_Master is :%d",sqlca.sqlcode);
	//		return FALSE;
	}
					       ****/
	pSys = (struct NNF_SYS_INFO_REQ *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
	memset((CHAR *)pSys,' ',sizeof(struct NNF_SYS_INFO_REQ)); 
	pSys->sHeader.iMsgCode 		= TC_NSE_SYS_INFO_REQ;
	pSys->sHeader.iLogTimeStamp 	= 0 ;
	memcpy(pSys->sHeader.sAlphaSplit,"NT",2);
	pSys->sHeader.iTraderID = iTmpTradeId ;
	pSys->sHeader.iErrorCode 	= 0 ;
	memset(pSys->sHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
        memset(pSys->sHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
        memset(pSys->sHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
	pSys->sHeader.sTimeStamp2[0] 	= '0';
	pSys->sHeader.iMsgLength 	= sizeof(struct NNF_SYS_INFO_REQ) ;
	pSys->LastUpdateTimePortfolio	= 0;


#ifdef  DBG
	logDebug3("proc_progN.pc : sendsysinfo : THIS IS THE SYS INFO DOWNLOAD PROCESS ***");
	logDebug3("sendsysinfo: The transcode is %d ",pSys->sHeader.iMsgCode);
	logDebug3("sendsysinfo: The Msglength is %d ",pSys->sHeader.iMsgLength);
	//	logDebug3("\n sendsysinfo: The portfoliodate is :%d",portfolioDate);
#endif

	TWIDDLE(pSys->sHeader.iLogTimeStamp);
	TWIDDLE(pSys->sHeader.iMsgCode);
	TWIDDLE(pSys->sHeader.iErrorCode);
	TWIDDLE(pSys->sHeader.iTraderID);
	/*    TWIDDLE(pSys->sHeader.iMsgLength);	*/
	TWIDDLE(pSys->LastUpdateTimePortfolio);
	memcpy(sNNF,pSys,sizeof(struct NNF_SYS_INFO_REQ));
	free(pSys);
	logDebug3("########################### exit sendsysinfo ###########################");

	logTimestamp("exit : fSendsysinfo");
	return TRUE;

	}


BOOL	fRecvsysinfo(CHAR *sNNF)
{
	logTimestamp ("Entry : fRecvsysinfo");	

	NNF_SYS_INFO_RESP	*pSys;			
	SHORT	iNumOfStream = 0 ;
	BOOL 	iDataupdate, iEDDFlag; /*** TAP Reg Changes ***/
	CHAR 	sError[ERROR_STRING_LEN]; 
/*****/
	pSys = (NNF_SYS_INFO_RESP *)malloc(sizeof(NNF_SYS_INFO_RESP));
	memset((CHAR *)pSys,' ',sizeof(NNF_SYS_INFO_RESP));
	memcpy(pSys,sNNF,sizeof(NNF_SYS_INFO_RESP));

	TWIDDLE(pSys->sHeader.iLogTimeStamp);
	TWIDDLE(pSys->sHeader.iMsgCode);
	TWIDDLE(pSys->sHeader.iErrorCode);
	TWIDDLE(pSys->sHeader.iMsgLength);

	TWIDDLE(pSys->MarketStatus.Normal);
	TWIDDLE(pSys->MarketStatus.Oddlot);
	TWIDDLE(pSys->MarketStatus.Spot);
	TWIDDLE(pSys->MarketStatus.Auction);

	TWIDDLE(pSys->sExStatus.Normal);
	TWIDDLE(pSys->sExStatus.Oddlot);
	TWIDDLE(pSys->sExStatus.Spot);
	TWIDDLE(pSys->sExStatus.Auction);

	TWIDDLE(pSys->sPlStatus.Normal);
	TWIDDLE(pSys->sPlStatus.Oddlot);
	TWIDDLE(pSys->sPlStatus.Spot);
	TWIDDLE(pSys->sPlStatus.Auction);

	TWIDDLE(pSys->MktIndex);
	TWIDDLE(pSys->DefaultSettNormal);
	TWIDDLE(pSys->DefaultSettSpot);
	TWIDDLE(pSys->DefaultSettAuction);
	TWIDDLE(pSys->CompetitorPeriod);
	TWIDDLE(pSys->SolicitorPeriod);
	TWIDDLE(pSys->WarnigPercent);
	TWIDDLE(pSys->VolFreezePercent);
	TWIDDLE(pSys->BoardLotQty);
	TWIDDLE(pSys->TickSize);
	TWIDDLE(pSys->MaxGtcDays);
	TWIDDLE(pSys->StockEligibilityInd);
	TWIDDLE(pSys->DiscQty);
	TWIDDLE(pSys->RiskFreeInterestRate);

	logDebug2("proc_progN.pc The No of STREAM is :%d:", *(pSys->sHeader.sAlphaSplit));
        if(pSys->sHeader.iMsgCode == TC_EQU_NSE_SYS_INFO_RESP )
        {
                iNumOfStream = *(pSys->sHeader.sAlphaSplit);
        }
        else
        {
                iNumOfStream = 3;
        }
        logDebug2("iNumOfStream :%d:",iNumOfStream );

#ifdef  DBG
	logDebug3("*** proc_progN.pc Inside RECVSYSINFO  ***");
	logDebug3("Recvsysinfo: The TransCOde is 			%d:",pSys->sHeader.iMsgCode);
	logDebug3("Recvsysinfo: The iMsgLength is 			%d:",pSys->sHeader.iMsgLength);
	logDebug3("Recvsysinfo: The iErrorCode is 			%d:",pSys->sHeader.iErrorCode);
	logDebug3("Recvsysinfo: The market Status for normal is 	%d:",pSys->MarketStatus.Normal);
	logDebug3("Recvsysinfo: The market Status for oddlot is 	%d:",pSys->MarketStatus.Oddlot);
	logDebug3("Recvsysinfo: The market Status for spot is 		%d:",pSys->MarketStatus.Spot);
	logDebug3("Recvsysinfo: The market Status for auction is 	%d:",pSys->MarketStatus.Auction);
	logDebug3("Recvsysinfo: The Status sPlStatus for normal is 	%d:",pSys->sPlStatus.Normal);
	logDebug3("Recvsysinfo: The Status sExStatus for normal is 	%d:",pSys->sExStatus.Normal);
	logDebug3("Recvsysinfo: The Market Index  is 			%ld:",pSys->MktIndex);
	logDebug3("Recvsysinfo: The Normal Mkt Def Sttl period  is 	%d:",pSys->DefaultSettNormal);
	logDebug3("Recvsysinfo: The Def Competitior period is 		%d:",pSys->CompetitorPeriod);
	logDebug3("Recvsysinfo: The Def Solicitor period is 		%d:",pSys->SolicitorPeriod);
	logDebug3("Recvsysinfo: The Warning Percent is 			%d:",pSys->WarnigPercent);
	logDebug3("Recvsysinfo: The Vol Freeze Percent is 		%d:",pSys->VolFreezePercent);
	logDebug3("Recvsysinfo: The Board Lot Qty is 			%ld:",pSys->BoardLotQty);
	logDebug3("Recvsysinfo: The Tick Size is 			%ld:",pSys->TickSize);
	logDebug3("Recvsysinfo: The Max GTC days is 			%d:",pSys->MaxGtcDays);
	logDebug3("Recvsysinfo: The StockEligibilityInd is 		%u:",pSys->StockEligibilityInd);
	logDebug3("Recvsysinfo: The Disc Qty is 			%d:",pSys->DiscQty);
	logDebug3("Recvsysinfo: The RiskFreeInterestRate is 		%d:",pSys->RiskFreeInterestRate);
#endif

	if ((pSys->sHeader.iMsgCode == TC_NSE_SYS_INFO_RESP ) || (pSys->sHeader.iMsgCode == TC_NSE_PARTIAL_SYS_INFO_RESP))
	{ 
		iDataupdate = fUpdateSysInfoResp(pSys);
		free(pSys);
		if (iDataupdate == TRUE)
		{
			iEDDFlag = fInsertExchDigital(iNumOfStream);
			// Printing for monitoring purpose @NItish	
			if(iEDDFlag == TRUE)
			{
				// Printing for monitoring purpose @NItish
				logTimestamp(":%s: SYS INFO RESPONSE UPDATE SUCCESS ",KEY_WORD_MONITORING);
				return TRUE;
			}
			else
				return FALSE;
		}
		else
		{
			memset(sError,NULL,ERROR_STRING_LEN);
			strcpy(sError,"Could Not Update the Database in SYS INFO RESPONSE");
			logFatal("proc_progN.pc %s",sError);
			// Printing for monitoring purpose @NItish
			logTimestamp(":%s: SYS INFO RESPONSE UPDATE SUCCESS ",KEY_WORD_MONITORING);	
			return(ERROR);
		}
	}	
	else
	{
		free(pSys);
#ifdef  DBG
		logDebug3("proc_progN.pc Got someother transcode other than SYS INFO RESPONSE ");
#endif
		return ERROR;
	}	
/****/
	logTimestamp("exit : fRecvsysinfo");
	return TRUE;

}


BOOL	fPUpLDBR ( struct NNF_UPDATE_LDB_REQ   *pUpdLDB )
{
	logTimestamp("Entry : fPUpLDBR");
	/**
	  EXEC SQL BEGIN DECLARE SECTION;
	  LONG32    temp1;
	  LONG32    cTemp2;
	  VARCHAR   exchId[EXCHANGE_LEN];
	  CHAR      drvFlg ='Y';
	  EXEC SQL END DECLARE SECTION;

	  VMEMCPY(exchId,exchange,EXCHANGE_LEN);

	  CHAR *filename = "proc_progN.pc";
	 *****/
	setvbuf( stdout , NULL , _IONBF , 0 );

	setbuf(stdout,NULL);
	setbuf(stdin,NULL);

	/*****	strcpy(tablename,"EXCH_ADMINISTRATION_MASTER");

#ifdef	DBG
logDebug3("\n Iam inside the func fPUpLDBR ");
#endif

EXEC SQL SELECT max(JULIDATE(EAM_LAST_UPDATE_PART_TIME))
INTO :cTemp2
FROM EXCH_ADMINISTRATION_MASTER;

logDebug3("\nSelecting LastThe sError in execution is %d",sqlca.sqlcode);

if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

strcpy(tablename,"DRV_NSE_SECURITY_MASTER");
EXEC SQL SELECT max(JULIDATE(NSE_CREATED_DATE))
INTO :temp1
FROM DRV_NSE_SECURITY_MASTER;

logDebug3("\nThe sError in execution is %d",sqlca.sqlcode);

if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
{
return FALSE;
logDebug3("\n returnig false");
}

strcpy(tablename,"DRV_EXCH_MKT_MASTER");

EXEC SQL SELECT EMM_STATUS 
INTO   :pUpdLDB->MarketStatus.Normal 
FROM   DRV_EXCH_MKT_MASTER
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND 	EMM_MKT_TYPE = 'NL'
AND EMM_MKT_SEGMENT = 'D';

logDebug3("\nThe sError in execution is %d",sqlca.sqlcode);

if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;

strcpy(tablename,"DRV_EXCH_MKT_MASTER");
EXEC SQL SELECT EMM_STATUS,EMM_DRV_EX_STATUS,EMM_DRV_PL_STATUS
INTO   :pUpdLDB->MarketStatus.Normal,
:pUpdLDB->sExStatus.Normal,
:pUpdLDB->sPlStatus.Normal
FROM   DRV_EXCH_MKT_MASTER
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND    EMM_MKT_TYPE = 'NL'
AND EMM_MKT_SEGMENT = 'D';

logDebug3("\nThe sError in execution is %d",sqlca.sqlcode);

if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;



EXEC SQL SELECT EMM_STATUS,EMM_DRV_EX_STATUS,EMM_DRV_PL_STATUS
INTO   :pUpdLDB->MarketStatus.Oddlot,
:pUpdLDB->sExStatus.Oddlot,
:pUpdLDB->sPlStatus.Oddlot
FROM   DRV_EXCH_MKT_MASTER
WHERE  EMM_EXM_EXCH_ID = 'NSE'
AND    EMM_MKT_TYPE = 'OL'
AND EMM_MKT_SEGMENT = 'D';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
return FALSE;



	EXEC SQL SELECT EMM_STATUS,EMM_DRV_EX_STATUS,EMM_DRV_PL_STATUS
	INTO   :pUpdLDB->MarketStatus.Spot,
	:pUpdLDB->sExStatus.Spot,
	:pUpdLDB->sPlStatus.Spot
	FROM   DRV_EXCH_MKT_MASTER
	WHERE  EMM_EXM_EXCH_ID = 'NSE'
	AND    EMM_MKT_TYPE = 'SP'
	AND EMM_MKT_SEGMENT = 'D';


if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;

	EXEC SQL SELECT EMM_STATUS,EMM_DRV_EX_STATUS,EMM_DRV_PL_STATUS
	INTO   :pUpdLDB->MarketStatus.Auction,
	:pUpdLDB->sExStatus.Auction,
	:pUpdLDB->sPlStatus.Auction
	FROM   DRV_EXCH_MKT_MASTER
	WHERE  EMM_EXM_EXCH_ID = 'NSE'
	AND    EMM_MKT_TYPE = 'AU'
	AND EMM_MKT_SEGMENT = 'D';
if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	return FALSE;

	****/



	memset(pUpdLDB->sHeader.sTimeStamp1,' ',DATE_TIME_LEN);
	memset(pUpdLDB->sHeader.sTimeStamp2,' ',DATE_TIME_LEN);
	memset(pUpdLDB->sHeader.sTimeStamp3,' ',DATE_TIME_LEN);
	memset(pUpdLDB->sHeader.sAlphaSplit,' ',ALPHA_SPLIT_LEN);

	pUpdLDB->sHeader.iTraderID = iTmpTradeId ;
	pUpdLDB->sHeader.iLogTimeStamp 	= 0 ;
	pUpdLDB->sHeader.iMsgCode 	= TC_NSE_UPD_LDB_DOWNLD_REQ;
	pUpdLDB->sHeader.iErrorCode 	= 0 ;
	pUpdLDB->sHeader.iMsgLength 	= sizeof(struct NNF_UPDATE_LDB_REQ);
	/*    pUpdLDB->ReqForOpenOrders 	= NO_OPEN_ORD_REQ_IND;*/
	pUpdLDB->ReqForOpenOrders 	= 'N';
	pUpdLDB->LastUpdateSecTime 	= 0;
	pUpdLDB->LastUpdateSecTime 	= 1142099022;
	pUpdLDB->LastUpdatePartTime 	= 1023933600;
	logDebug3("LastupdateSectime is :%d",pUpdLDB->LastUpdateSecTime);

	/*    pUpdLDB->LastUpdatePartTime 	= 0;*/
	pUpdLDB->LastUpdateInstTime	= 0; /* ganesh |dont know which table to pick from*/
	pUpdLDB->LastUpdateIndxTime	= 0; /* ganesh |and what to send*/


	pUpdLDB->MarketStatus.Normal   	= 1 ;
	pUpdLDB->MarketStatus.Spot   	= 2 ;
	pUpdLDB->MarketStatus.Oddlot 	= 2 ;
	pUpdLDB->MarketStatus.Auction 	= 2 ;
	pUpdLDB->sPlStatus.Normal 	= 1 ;
	pUpdLDB->sPlStatus.Spot   	= 2 ;
	pUpdLDB->sPlStatus.Oddlot 	= 2 ;
	pUpdLDB->sPlStatus.Auction	= 2 ;
	pUpdLDB->sPlStatus.Normal 	= 2 ;
	pUpdLDB->sPlStatus.Spot   	= 2 ;
	pUpdLDB->sPlStatus.Oddlot 	= 2 ;
	pUpdLDB->sPlStatus.Auction 	= 2 ;
	/******
	  if (sqlca.sqlcode == 0)
	  {
	  logDebug3("\nfPUpLDBR: returning TRUE");
	  return TRUE;
	  }
	  else
	  {
	  logDebug3("\nfPUpLDBR: returning FALSE");
	  return FALSE;
	  }*****/
	logTimestamp("exit : fPUpLDBR");
	return TRUE;

	}

BOOL	fSendupdate( CHAR *sNNF)
{
	logTimestamp("Entry : fSendupdate");	

	struct	NNF_UPDATE_LDB_REQ	*pUrequest;
	LONG32 	iUpldb_result;
	CHAR 	sError[ERROR_STRING_LEN];

	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,NULL);
	setbuf(stdin,NULL);

	pUrequest = (struct NNF_UPDATE_LDB_REQ *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));
	memset((CHAR *)pUrequest,' ',sizeof(struct NNF_UPDATE_LDB_REQ));
	memcpy(pUrequest,sNNF,sizeof(struct NNF_UPDATE_LDB_REQ));

#ifdef	DBG
	logDebug3("I am inside the func sendupdate ");
#endif
	iUpldb_result = fPUpLDBR(pUrequest) ;
	logDebug3("the iUpldb_result is %d",iUpldb_result);

	if (iUpldb_result == FALSE)
	{
		memset(sError,NULL,ERROR_STRING_LEN);
		strcpy(sError,"Could Not Query the Database in LDB REQUEST");
		logFatal("proc_progN.pc %s",sError);
		return(ERROR);
	}

#ifdef	DBG
	logDebug3("*** THIS IS THE Update DATABASE DOWNLOAD PROCESS *** ");
	logDebug3("sendupdate: The result is %d ",iUpldb_result);
	logDebug3("proc_progNpc the values to be requested are %d %d %d %d ",pUrequest->MarketStatus.Normal, pUrequest->MarketStatus.Oddlot, 
			pUrequest->MarketStatus.Spot, pUrequest->MarketStatus.Auction);
	logDebug3("sendupdate: TransCode is 		:%d ",pUrequest->sHeader.iMsgCode);
	logDebug3("sendupdate: iMsgLength is 		:%d ",pUrequest->sHeader.iMsgLength);
	logDebug3("sendupdate: LastUpdateSecTime is 	:%d",pUrequest->LastUpdateSecTime);
	logDebug3("sendupdate: LastUpdatePartTime is	:%d",pUrequest->LastUpdatePartTime);
	logDebug3("sendupdate: LastUpdateInstTime is	:%d",pUrequest->LastUpdateInstTime);
	logDebug3("sendupdate: LastUpdateIndxTime is	:%d",pUrequest->LastUpdateIndxTime);
	logDebug3("sendupdate: MarketStatus.Normal is 	%u",pUrequest->MarketStatus.Normal);
	logDebug3("sendupdate: MarketStatus.Oddlot is 	%u",pUrequest->MarketStatus.Oddlot);
	logDebug3("sendupdate: MarketStatus.Spot is 	%u",pUrequest->MarketStatus.Spot);
	logDebug3("sendupdate: sExStatus.Normal is 	%u",pUrequest->sExStatus.Normal);
	logDebug3("sendupdate: sExStatus.Spot is 	%u",pUrequest->sExStatus.Spot);
	logDebug3("sendupdate: sExStatus.Auction is 	%u",pUrequest->sExStatus.Auction);
	logDebug3("sendupdate: sExStatus.Oddlot is 	%u",pUrequest->sExStatus.Oddlot);
	logDebug3("sendupdate: sPlStatus.Normal is 	%u",pUrequest->sPlStatus.Normal);
	logDebug3("sendupdate: sPlStatus.Oddlot is 	%u",pUrequest->sPlStatus.Oddlot);
	logDebug3("sendupdate: sPlStatus.Spot is 	%u",pUrequest->sPlStatus.Spot);
	logDebug3("sendupdate: sPlStatus.Auction is 	%u",pUrequest->sPlStatus.Auction);

	logDebug3("sendupdate:pc before send .... ");
#endif
	TWIDDLE(pUrequest->sHeader.iLogTimeStamp);
	TWIDDLE(pUrequest->sHeader.iMsgCode);
	TWIDDLE(pUrequest->sHeader.iErrorCode);
	TWIDDLE(pUrequest->sHeader.iTraderID);
	/*	TWIDDLE(pUrequest->sHeader.iMsgLength);	*/
	TWIDDLE(pUrequest->LastUpdateSecTime);
	TWIDDLE(pUrequest->LastUpdatePartTime);
	TWIDDLE(pUrequest->LastUpdateInstTime);
	TWIDDLE(pUrequest->LastUpdateIndxTime);
	TWIDDLE(pUrequest->MarketStatus.Normal); 
	TWIDDLE(pUrequest->MarketStatus.Oddlot);
	TWIDDLE(pUrequest->MarketStatus.Spot);
	TWIDDLE(pUrequest->MarketStatus.Auction);
	TWIDDLE(pUrequest->sExStatus.Normal);    
	TWIDDLE(pUrequest->sExStatus.Oddlot);   
	TWIDDLE(pUrequest->sExStatus.Spot);
	TWIDDLE(pUrequest->sExStatus.Auction);
	TWIDDLE(pUrequest->sPlStatus.Normal);
	TWIDDLE(pUrequest->sPlStatus.Oddlot);
	TWIDDLE(pUrequest->sPlStatus.Spot);
	TWIDDLE(pUrequest->sPlStatus.Auction);

	memcpy(sNNF,pUrequest,sizeof(struct NNF_UPDATE_LDB_REQ)); 

	free(pUrequest);
	logTimestamp("exit : fSendupdate");
	return TRUE;

}

BOOL	fSendmessage( CHAR *sNNF , LONG32 iGroupid, LONG32 iStream) /*** TAP Reg Changes ***/
{
	logTimestamp("Entry : fSendmessage");	

	struct	NNF_MSG_DOWNLOAD_REQ	*pMrequest;
	struct 	NNF_DOUBLE_INT 		*pTempsTimeStamp;
	//	LONG32 	upsMsg_result;
	CHAR 	sError[ERROR_STRING_LEN];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sSelQyr= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	/******
	  EXEC SQL BEGIN DECLARE SECTION;
	  ULONG32  TempTime1;
	  ULONG32  TempTime2;
	  SHORT    StreamId;  
	  VARCHAR  exchId[EXCHANGE_LEN];
	  CHAR     drvFlg = 'Y';
	  EXEC SQL END DECLARE SECTION;
	 ****/
	//    VMEMCPY(exchId,exchange,EXCHANGE_LEN);

	pMrequest = (struct NNF_MSG_DOWNLOAD_REQ *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	pTempsTimeStamp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));
	memset((CHAR *)pMrequest,' ',sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	memcpy(pMrequest,sNNF,sizeof(struct NNF_MSG_DOWNLOAD_REQ));

#ifdef  DBG
	logDebug3("sendmessage.pc the group id is %d ",iGroupid);
#endif


	/*** Commented TAP Reg Changes ** 
	  EXEC SQL SELECT	
	  nvl(EAM_LAST_MSG_TIME,0),
	  nvl(EAM_LAST_MSG_TIME1,0)
	  INTO	
	  :TempTime1,
	  :TempTime2
	  FROM	EXCH_ADMINISTRATION_MASTER
	  WHERE	EAM_EXM_EXCH_ID = 'NSE'	AND	
	  EAM_GROUP_ID 	= :iGroupid	AND
	  EAM_DRV_FLAG	= 'Y' ; **/

	/*** TAP Reg Changes ***/
	//StreamId = stream;  
	/*****
	  EXEC SQL SELECT
	  EDD_TIMESTAMP1,
	  EDD_TIMESTAMP2
	  INTO 
	  :TempTime1,
	  :TempTime2
	  FROM   EXCH_DOWNLOAD_DIGITAL 
	  WHERE   EDD_EXCH_ID = 'NSE'
	  AND     EDD_STREAM_ID   = :StreamId
	  AND     EDD_GROUP_ID    = to_CHAR (:iGroupid)
	  AND     EDD_DRV_FLAG    = 'Y';****/
	/*** TAP Reg Changes ***/
	/*****
	  if ( HandleSQL(sqlca.sqlcode,procname,filename,tablename) == FALSE )
	  {
	  memset(sError,NULL,ERROR_STRING_LEN);
	  strcpy(sError,"Could Not Query the Database in MADL REQUEST");
	  logFatal("proc_progN.pc",sError);
	  return(ERROR);
	  }*****/
	//      logDebug3("\nIn sendmessage - time from db is => TempTime1 :[%u], TempTime2 :[%u]",TempTime1,TempTime2);
	/* logDebug3("\nVariable set before pSignon => EAM_sTimeStamp.sTimeStamp:[%u],EAM_sTimeStamp.sTimeStamp1:[%u]",\
	   EAM_sTimeStamp.sTimeStamp,EAM_sTimeStamp.sTimeStamp1); */ /*** Commented TAP Reg Changes ***/

	/*** TAP Reg Changes ***/
	/****
	  pTempsTimeStamp->iLogTime1 = TempTime1;
	  pTempsTimeStamp->iLogTime2 = TempTime2;*****/



	pTempsTimeStamp->iLogTime1 = 0;
	pTempsTimeStamp->iLogTime2 = 0;

	sprintf(sSelQyr,"SELECT (case when (EDD_TIMESTAMP1 - %d) < 0 then 0 else (EDD_TIMESTAMP1 - %d) end),EDD_TIMESTAMP2 FROM EXCH_DOWNLOAD_DATA WHERE EDD_EXCH_ID = \"%s\" AND EDD_SEGMENT = \'%c\' AND EDD_GROUP_ID = %d  AND EDD_STREAM_ID = '%d' ;",iJiffyTime,iJiffyTime,NSE_EXCH,CURRENCY_SEGMENT,iGroupid,iStream)     ;
	logDebug2("sSelQyr :%s:",sSelQyr);

	if(mysql_query(DBConDrvNNF,sSelQyr) != SUCCESS)
	{
		sql_Error(DBConDrvNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConDrvNNF);

	if(Row = mysql_fetch_row(Res))
	{

		logDebug3("Last Message Time1 = %s ",Row[0]);
		logDebug3("Last Message Time2 = %s" ,Row[1]);
		pTempsTimeStamp->iLogTime1 = strtoul(Row[0],NULL,10);
                pTempsTimeStamp->iLogTime2 = strtoul(Row[1],NULL,10);
        }
        else
        {
                pTempsTimeStamp->iLogTime1 = 0;
                pTempsTimeStamp->iLogTime2 = 0;
	}
	logDebug3("Last Message Time1 = %u ",pTempsTimeStamp->iLogTime1);
	logDebug3("Last Message Time2 = %u" ,pTempsTimeStamp->iLogTime2);

	/**pTempsTimeStamp->iLogTime1=EAM_sTimeStamp.sTimeStamp;
	  pTempsTimeStamp->iLogTime2=EAM_sTimeStamp.sTimeStamp1;**/
	/*** TAP Reg Changes ***/

	memcpy((CHAR*)&pMrequest->ExchSeqNum ,pTempsTimeStamp , sizeof(struct NNF_DOUBLE_INT) );

#ifdef  DBG
	logDebug3("*** sendmessage THIS IS THE MESSAGE DOWNLOAD PROCESS ***");
	logDebug3("sendmessage: Last Message Time1 = %u ",pTempsTimeStamp->iLogTime1);
	logDebug3("sendmessage:Last Message Time2 = %u" ,pTempsTimeStamp->iLogTime2);
#endif

	pMrequest->sHeader.iTraderID = iTmpTradeId ;
	pMrequest->sHeader.iLogTimeStamp = 0 ;
	pMrequest->sHeader.iMsgCode = TC_NSE_MSG_DOWNLOAD_REQ;
	pMrequest->sHeader.iErrorCode = 0 ;
	pMrequest->sHeader.iMsgLength = sizeof(struct NNF_MSG_DOWNLOAD_REQ);

#ifdef  DBG
	logDebug3("sendmessage: The Sequence No is %lf ",pMrequest->ExchSeqNum);
	logDebug3("sendmessage: The transcode is %d ",pMrequest->sHeader.iMsgCode);
	logDebug3("sendmessage: The Msglength is %d ",pMrequest->sHeader.iMsgLength);
	logDebug3("sendmessage: MESG_DOWN_REQ ::: before send ");
#endif

	TWIDDLE(pMrequest->sHeader.iLogTimeStamp);
	TWIDDLE(pMrequest->sHeader.iMsgCode);
	TWIDDLE(pMrequest->sHeader.iErrorCode);
	TWIDDLE(pMrequest->sHeader.iTraderID);
	/*casue partial down issue hence refer eq and twiddle ExchSeqNum*/
        TWIDDLE(pMrequest->ExchSeqNum);

	/*    TWIDDLE(pMrequest->sHeader.iMsgLength);*/
	memcpy(sNNF,pMrequest,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	free(pMrequest);
	/******
	  if (sqlca.sqlcode == 0 )
	  {
	  logDebug3("\n sendmessage: returning TRUE");
	  return TRUE;
	  }
	  else
	  {
	  logDebug3("\n sendmessage: returning FALSE");
	  return ERROR;
	  }******/
	logTimestamp("exit : fSendmessage");
	return TRUE;

}

/* new functions sAdded for fallover mechanism with effect from 13/4/2000          */


void	fSend_exch_down_nse( LONG32 iGroupid)
{
	logTimestamp("Entry : fSend_exch_down_nse");

	CHAR	*sError,*sMsg;
	CHAR 	*sRcvMsg;
	CHAR 	sMapMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR 	sStatus;
	struct 	NNF_HEADER 	*pHeader;
	struct 	NNF_DOUBLE_INT 	*pTempsTimeStamp;	
	LONG32 	iQid , iWait_status, iQid1 , iWrite_status , iTemplen , queueId;
	LONG32  iTMChk = 0 ;
	/********

	  EXEC SQL BEGIN DECLARE SECTION;
	  ULONG32  TempTime1;
	  ULONG32  TempTime2;
	  LONG32   IntTime; 
	  VARCHAR  exchId[EXCHANGE_LEN];
	  CHAR     drvFlg = 'Y';
	  EXEC SQL END DECLARE SECTION;

	  VMEMCPY(exchId,exchange,EXCHANGE_LEN);
	 ******/
	sError = (CHAR *)malloc(sizeof(CHAR)*80);
	sMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	sRcvMsg = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);	
	pTempsTimeStamp = ( struct NNF_DOUBLE_INT *)malloc(sizeof(struct NNF_DOUBLE_INT));

#ifdef	DBG
	logDebug3("IN FUNCTION send_exch_down_nse with iGroupid %d ",iGroupid );
#endif

	//	switch(iGroupid) /*---- Code to choose Queue from Group Id ---*/
	/*****	{
	  case 1 : 
	  queueId = DrvRmsnseToNse1;       
	  break;
	  case 2 : 
	  queueId = DrvRmsnseToNse2;
	  break;
	  case 3 : 
	  queueId = DrvRmsnseToNse3;
	  break;
	  case 4 :
	  queueId = DrvRmsnseToNse4;
	  break;
	  default : 
	  break;
	  };
	 ****/
	fUpdateConnectStatus(NSE_CUR_DOWN, iGroupid );
	iQid = OpenMsgQ(FwdMMapToConAdapNSECD);
	if ( iQid < 0 )
	{
		memset(sError,NULL,80);
		strcpy(sError,"ERROR : in OpenMsgQ function : Queue.c");
		logFatal("NSEx25.pc %s",sError);
		free(sError);
		exit(ERROR);
	}

	/******* Open the reverse path Q, for retruning the packets *******/
	iQid1 = OpenMsgQ(ConnToTrdMapNSECR);
	if ( iQid1 < 0 )
	{
		memset(sError,NULL,80);
		strcpy(sError,"ERROR : in OpenMsgQ function : Queue.c");
		logFatal("NSEx25.pc %s",sError);
		free(sError);
		exit(ERROR);
	}

	for ( ;; )
	{
		memset ( &sMapMsg,' ', LOCAL_MAX_PACKET_SIZE );
		iWait_status = ReadNBQ( iQid , sMsg , NSE_PACKET_SIZE , iGlobGroupId);
		if ( iWait_status == TRUE )
		{
			pHeader = (struct NNF_HEADER *)sMsg;

			TWIDDLE(pHeader->iMsgCode); 

			//TWIDDLE(pHeader->iMsgLength);
			logDebug3("SENDING EXCHANGE DOWN ERROR for Transcode %d",pHeader->iMsgCode);
			logDebug3("By Nitish  Transcode :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode);

			switch(pHeader->iMsgCode)
			{
				case TC_INT_ORDER_ENTRY_REQ: 
					((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode = TC_INT_OE_ERROR_RESP;
					TWIDDLE(pHeader->iMsgLength); 
					iTemplen  = pHeader->iMsgLength;
					iTMChk = 0 ;
					break;
				case TC_INT_ORDER_MODIFY: 
					((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode = TC_INT_OM_ERROR_RESP;
					TWIDDLE(pHeader->iMsgLength); 
					iTemplen  = pHeader->iMsgLength;
					iTMChk = 0 ;
					break;
				case TC_INT_ORDER_CANCEL: 
					((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode = TC_INT_OC_ERROR_RESP;
					TWIDDLE(pHeader->iMsgLength); 
					iTemplen  = pHeader->iMsgLength;
					iTMChk = 0 ;
					break;
				case TC_EQU_NSE_ORD_ENTRY_REQ_TM:
					fNseCMOrdEntErrResp(sMsg,sMapMsg);
					pHeader->iMsgLength = sizeof(struct  NNF_ORD_RESPONSE_TM);
					iTemplen = sizeof(struct  NNF_ORD_RESPONSE_TM);
					iTMChk = 1 ;
					break;
				case TC_EQU_NSE_ORD_MOD_REQ_TM:
					fNseCMOrdModErrResp(sMsg,sMapMsg);
					pHeader->iMsgLength = sizeof(struct  NNF_ORD_RESPONSE_TM);
					iTemplen = sizeof(struct  NNF_ORD_RESPONSE_TM);
					iTMChk = 1 ;
					break;	
				case TC_EQU_NSE_ORD_CAN_REQ_TM:
					fNseCMOrdCanErrResp(sMsg,sMapMsg);
					pHeader->iMsgLength = sizeof(struct  NNF_ORD_RESPONSE_TM);
					iTemplen = sizeof(struct  NNF_ORD_RESPONSE_TM);
					iTMChk = 1 ;
					break;
				default	: 
					break;
			}

			logDebug3("By Nitish  Transcode :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode);
			//			pHeader->iErrorCode = EXCHANGE_DOWN_ERROR;
			((struct NNF_HEADER *)sMsg)->iErrorCode = EXCHANGE_DOWN_ERROR;
			/*****
			  EXEC SQL SELECT julidate(pSysdate)
			  INTO
			  :IntTime
			  FROM DUAL;***/
			//               logDebug3("EXCH_DOWN Time :%d",IntTime);  
			((struct NNF_ORDER_ENTRY *)sMsg)->iEntryTime =1142440273;
			((struct NNF_ORDER_ENTRY *)sMsg)->iLastModifiedTime =1142440273;        

			//TWIDDLE(((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode);
			TWIDDLE(((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iErrorCode); 
			/****

			  EXEC    SQL     SELECT
			  nvl(EAM_LAST_MSG_TIME,0),
			  nvl(EAM_LAST_MSG_TIME1,0)
			  INTO
			  :TempTime1,
			  :TempTime2
			  FROM            EXCH_ADMINISTRATION_MASTER
			  WHERE           EAM_EXM_EXCH_ID = 'NSE'         AND
			  EAM_GROUP_ID    = :iGroupid      AND
			  EAM_DRV_FLAG    = 'Y' ;


			  if(sqlca.sqlcode != 0)
			  {
			  logDebug3("\n Error in selecting EAM_LAST_MSG_TIME(1) from EAM: %d", sqlca.sqlcode);
			  }
			 ****/
			pTempsTimeStamp->iLogTime1 = 0;
			pTempsTimeStamp->iLogTime2 = 0;
			memcpy((CHAR *)pHeader->sTimeStamp2 , pTempsTimeStamp , sizeof(struct NNF_DOUBLE_INT));

			//      logDebug3("\n   TempTime1 = %u", TempTime1);
			//     logDebug3("\n   TempTime2 = %u", TempTime2);
			
			if(iTMChk == 0)
			{
				iWrite_status = WriteMsgQ(iQid1,sMsg,iTemplen,1);
			}
			else
			{
				iWrite_status = WriteMsgQ(iQid1,sMapMsg,iTemplen,1);
			}
			if ( iWrite_status < 0)
			{
				memset(sError,NULL,80);
				strcpy(sError,"ERROR in WriteMsgQ function : Queue.c");
				logFatal("BGSEconnect.pc %s",sError);
				free(sError);
				free(sMsg);
				exit(ERROR);
			}

		}
		else
		{
			break; 
		}

	}
	free(sError);
	free(sMsg);
	logTimestamp("exit : fSend_exch_down_nse");
}




BOOL	fGet_mesg_or_error_nse(CHAR *sMsgbuf)
{
	logTimestamp("Entry : fGet_mesg_or_error_nse");

	struct	NNF_HEADER      		*pHeader;
	struct	NNF_ORDER_ENTRY			*pOrders;
	struct	NNF_EXCH_MSG_TO_TRADER_RESP 	*pResp;
	BOOL	iFlag;
	CHAR    sData[NSE_PACKET_SIZE];

	pHeader = (struct NNF_HEADER *)sMsgbuf;

	TWIDDLE(pHeader->iMsgLength);
	TWIDDLE(pHeader->iMsgCode);
	TWIDDLE(pHeader->iErrorCode); 

	logDebug3("TEMP : iErrorCode in NNF pHeader : %d ", pHeader->iErrorCode );

	if ((pHeader->iErrorCode != 0)  &&  (pHeader->iMsgLength == sizeof(struct NNF_ERROR_RESP)) )
	{
		logDebug3("get_mesg_or_error_nse: There is some Error ");
		iFlag = TRUE;
	}
	else
	{
		switch(pHeader->iMsgCode)
		{
			case 	TC_NSE_EXCH_MSG_TO_TRADER_RESP:

				memset(sData,NULL,NSE_PACKET_SIZE);
				/*memcpy(pResp,sMsgbuf,sizeof(struct NNF_EXCH_MSG_TO_TRADER_RESP)); */
				pResp = (struct NNF_EXCH_MSG_TO_TRADER_RESP *)sMsgbuf;
				TWIDDLE(pResp->iTraderId);
				logDebug3("Trader id = %d , Broad Cast message %s",pResp->iTraderId,pResp->sBcastMsg);
				sprintf(sData,"Trader id = %d , Broad Cast message %s",pResp->iTraderId,pResp->sBcastMsg);
				iFlag = TRUE;
				break;

			case    TC_INT_NEG_ORD_ENT_CP_RESP:

				memset(sData,NULL,NSE_PACKET_SIZE);
				/*memcpy(pOrders,sMsgbuf,sizeof(struct NNF_ORDER_ENTRY)); */
				pOrders = (struct NNF_ORDER_ENTRY *)sMsgbuf;
				TWIDDLE(pOrders->fOrderNum);
				sprintf(sData,"sBrokerCode= %s, Counter Party Broker Code= %s, fOrderNum= %lf ",pOrders->sBrokerCode,pOrders->sCPBrokerCode,
						pOrders->fOrderNum);
				iFlag = TRUE;
				break;

			case    TC_GENERAL_MSG_BCAST :

				memset(sData,NULL,NSE_PACKET_SIZE);
				/*memcpy(pResp,sMsgbuf,sizeof(struct NNF_EXCH_MSG_TO_TRADER_RESP));*/
				pResp = (struct NNF_EXCH_MSG_TO_TRADER_RESP *)sMsgbuf;
				TWIDDLE(pResp->iTraderId);
				sprintf(sData,"Trader id = %d , Broad Cast message %s",pResp->iTraderId,pResp->sBcastMsg);
				iFlag = TRUE;
				break;

			case    TC_NSE_BATCH_ORDER_CANCEL_RESP:

				memset(sData,NULL,NSE_PACKET_SIZE);
				/*memcpy(pOrders,sMsgbuf,sizeof(struct NNF_ORDER_ENTRY)); */
				pOrders = (struct NNF_ORDER_ENTRY *)sMsgbuf;
				TWIDDLE(pOrders->fOrderNum);
				sprintf(sData,"sBrokerCode= %s, fOrderNum= %lf ",pOrders->sBrokerCode,pOrders->fOrderNum);
				iFlag = FALSE ; 
				/*** WE Need to make it false so that packet can go to Child infact this case can be deleted here**/
				break;

			default	:	iFlag = FALSE;
					break;
		};

	}

	free(sData);
	free(pHeader);
	free(pOrders);
	free(pResp);
	logTimestamp("exit : fGet_mesg_or_error_nse");
	return(iFlag);

}

void	fSend_exch_down_buf_nse(LONG32 iGroupid,CHAR * sMsg)
{
	logTimestamp("Entry : fSend_exch_down_buf_nse");

	CHAR 	*sError;
	CHAR 	sStatus;
	struct 	NNF_HEADER 	*pHeader;
	LONG32 	iQid , iWait_status, iQid1 , iWrite_status , iTemplen;

	sError = (CHAR *)malloc(sizeof(CHAR)*80);
	iQid1 = OpenMsgQ(ConnToTrdMapNSECR);

	if ( iQid1 < 0 )
	{
		memset(sError,NULL,80);
		strcpy(sError,"ERROR : in OpenMsgQ function : Queue.c");
		logFatal("NSEx25.pc %s",sError);
		free(sError);
		exit(ERROR);
	}

	pHeader = (struct NNF_HEADER *)sMsg;
	TWIDDLE(pHeader->iMsgCode); 
	TWIDDLE(pHeader->iMsgLength);
	iTemplen  = pHeader->iMsgLength;
	TWIDDLE(pHeader->iMsgLength);
	/**
	  switch(pHeader->iMsgCode)
	  {
	  case	TC_INT_ORDER_ENTRY_REQ: pHeader->iMsgCode = TC_INT_OE_ERROR_RESP;
	  break;
	  case 	TC_INT_ORDER_MODIFY: pHeader->iMsgCode = TC_INT_OM_ERROR_RESP;
	  break;
	  case 	TC_INT_ORDER_CANCEL: pHeader->iMsgCode = TC_INT_OC_ERROR_RESP;
	  break;
	  default : 
	  break;
	  }
	  pHeader->iErrorCode = EXCHANGE_DOWN_ERROR;
	 ***/

	switch(pHeader->iMsgCode)
	{
		case TC_INT_ORDER_ENTRY_REQ:
			((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode = TC_INT_OE_ERROR_RESP;
			break;
		case TC_INT_ORDER_MODIFY:
			((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode = TC_INT_OM_ERROR_RESP;
			break;
		case TC_INT_ORDER_CANCEL:
			((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode = TC_INT_OC_ERROR_RESP;
			break;
		default :
			break;
	}

	logDebug3("By Nitish  Transcode :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode);
	((struct NNF_HEADER *)sMsg)->iErrorCode = EXCHANGE_DOWN_ERROR;


	//	TWIDDLE(pHeader->iMsgCode);
	//	TWIDDLE(pHeader->iErrorCode); 
	iWrite_status = WriteMsgQ(iQid1,sMsg,iTemplen,1);
	if ( iWrite_status < 0)
	{
		memset(sError,NULL,80);
		strcpy(sError,"ERROR in WriteMsgQ function : Queue.c");
		logFatal("BGSEconnect.pc %s",sError);
		free(sError);
		exit(ERROR);
	}
	logTimestamp("exit : fSend_exch_down_buf_nse");
	free(sError);

}

LONG32  fGetTotalStream()
{
	logTimestamp("Entry : fGetTotalStream");

	CHAR    *sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	LONG32  iStream;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32  iGroupId = 0;

	iGroupId =iGlobGroupId;

	sprintf(sSelQry,"SELECT max(EDD_STREAM_ID) \
			FROM EXCH_DOWNLOAD_DATA \
			WHERE  EDD_EXCH_ID=\"%s\"\
			AND EDD_SEGMENT=\'%c\'\
			AND EDD_GROUP_ID=%d;",NSE_EXCH,CURRENCY_SEGMENT,iGroupId );

	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConDrvNNF,sSelQry) != SUCCESS)
	{
		sql_Error(DBConDrvNNF);
		return FALSE;
	}

	Res = mysql_store_result(DBConDrvNNF);

	if(Row = mysql_fetch_row(Res))
	{
		iStream = atoi(Row[0]);
	}
	logTimestamp("Exit : fGetTotalStream");
	return iStream;

}

BOOL	fSendPortfolioReq(CHAR *sNNF )
{
	logTimestamp("Entry : fSendPortfolioReq");
	/***
	  struct NNF_PORTFOLIO_REQ *portfolioReq;

	  portfolioReq = (struct NNF_PORTFOLIO_REQ *)malloc(sizeof(struct NNF_PORTFOLIO_REQ));
	  memset(portfolioReq,' ',sizeof(struct NNF_PORTFOLIO_REQ));

	  portfolioReq->sHeader.iTraderID       = 0 ;
	  portfolioReq->sHeader.iLogTimeStamp   = 0 ;
	  portfolioReq->sHeader.iMsgCode        = TC_DRV_NSE_PORTFOLIO_REQ;
	  portfolioReq->sHeader.iErrorCode      = 0 ;
	  portfolioReq->sHeader.sTimeStamp2[0]  = 0;
	  portfolioReq->sHeader.iMsgLength      = sizeof(struct NNF_PORTFOLIO_REQ) ;
	  memcpy(portfolioReq->sHeader.sAlphaSplit,"NT",2);

	  portfolioReq->lLastUpdateDtTime	= 0;

#ifdef     DBG
logDebug3("\n\n\n*** SendPortfolioReq THIS IS THE PORTFOLIO DOWNLOAD PROCESS ***");
logDebug3("\n SendPortfolioReq: The transcode is %d ",portfolioReq->sHeader.iMsgCode);
logDebug3("\n SendPortfolioReq: The sMsglength is %d \n",portfolioReq->sHeader.iMsgLength);
logDebug3("\n SendPortfolioReq: before send ....");
#endif

TWIDDLE(portfolioReq->sHeader.iLogTimeStamp);
TWIDDLE(portfolioReq->sHeader.iMsgCode);
TWIDDLE(portfolioReq->sHeader.iErrorCode);
TWIDDLE(portfolioReq->lLastUpdateDtTime);

memcpy(NNF,portfolioReq,sizeof(struct NNF_PORTFOLIO_REQ));
free(portfolioReq);
	 ***/
	logTimestamp("exit : fSendPortfolioReq");
	return TRUE;

}


BOOL	fOpenBcastSocket()
{
	logTimestamp("Entry : fOpenBcastSocket");

	LONG32	iOptval=1;
	LONG32  iVal;
	if ( (iSockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}
	if(cMulticastFlg == 'M')
	{
		logDebug3("Multicast option set");
		UCHAR ttl = 254;
		iVal = setsockopt(iSockfdBroad,IPPROTO_IP,IP_MULTICAST_TTL,(void *)&ttl,sizeof(ttl));
	}
	else if(cMulticastFlg == 'B')
	{
		iVal = setsockopt(iSockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&iOptval,sizeof(iOptval));
	}
	if ( iVal < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	logTimestamp("exit : fOpenBcastSocket");
	return TRUE;

}
/***

  void convert_seconds_to_date(LONG32 seconds,CHAR *pDateTime)
  {
  struct tm *tmr;

  time_t julian;


  tmr = (struct tm *) malloc (sizeof(struct tm )) ;
  julian = seconds + OFFSET - TIMEZONE;
  localtime_r(&julian,tmr);
  sprintf(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_year+1900,tmr->tm_mon+1,tmr->tm_mday,tmr->tm_hour,tmr->tm_min  ,tmr->tm_sec );
  free(tmr);

  }

  SHORT  fTrim( CHAR *string , SHORT MaxLen )
  {
  logTimestamp("Entry : [fTrim]");

  SHORT index=0;
  if ( MaxLen <= 0 )
  return 0 ;

  for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
  continue;

  string[index]='\0';
  logTimestamp("exit : [fTrim]");
  return index ;
  }
 ***/

BOOL    fInsertExchDigital(SHORT iNoStreams)
{
	logTimestamp("Entry : fInsertExchDigital");

	SHORT    j=0;
	LONG32  iGroupId=0;
	SHORT   iStreamId =0;
	//        ULONG32 Time1 =0;
	//        ULONG32 Time2 =0 ;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32          iNumRow;

	CHAR    *sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	CHAR    *sInsQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	logDebug2("iGlobGroupId : %d iNoStreams :%d ", iGlobGroupId, iNoStreams);
	iGroupId =iGlobGroupId;
//	iNoStreams = iTotalStream ;
	logDebug2("Local iGroupId : %d", iGroupId);

	logDebug2("===========iGlobGroupId [%d]== iNoStreams [%d]==",iGroupId, iNoStreams);
	for ( j=1 ; j <= iNoStreams; j++)
	{
		iStreamId = j;
		sprintf(sSelQry,"SELECT * FROM EXCH_DOWNLOAD_DATA\
				WHERE EDD_STREAM_ID = %d \
				AND EDD_EXCH_ID=\"%s\"\
				AND EDD_SEGMENT = \'%c\' \
				AND EDD_GROUP_ID=%d ;",iStreamId,NSE_EXCH,CURRENCY_SEGMENT,iGroupId);
		logDebug2("sSelQry :%s:",sSelQry);

		if(mysql_query(DBConDrvNNF,sSelQry) != SUCCESS)
		{
			sql_Error(DBConDrvNNF);
			return FALSE;
		}

		Res = mysql_store_result(DBConDrvNNF);

		iNumRow = mysql_num_rows(Res);
		logDebug2("iNumRow :%d: iStreamId:%d:",iNumRow,iStreamId);

		if(iNumRow == 0)
		{
			sprintf(sInsQry,"INSERT INTO  EXCH_DOWNLOAD_DATA(\
				EDD_GROUP_ID,\
				EDD_EXCH_ID,\
				EDD_SEGMENT,\
				EDD_STREAM_ID,\
				EDD_TIMESTAMP1,\
				EDD_TIMESTAMP2)\
					VALUES (%d,\"%s\",\'%c\',%d,0,0 );",iGroupId,NSE_EXCH,CURRENCY_SEGMENT,iStreamId);

			logDebug2("sInsQry :%s:",sInsQry);
			if(mysql_query(DBConDrvNNF,sInsQry) != SUCCESS)
			{
				sql_Error(DBConDrvNNF);
				return FALSE;
			}
			else
			{
				mysql_commit(DBConDrvNNF);
			}

		}
		mysql_free_result(Res);
	}

	free(sSelQry);
	free(sInsQry);
	logTimestamp("Exit : fInsertExchDigital");
	return TRUE ;

}

BOOL    fUpdateTimeStamp(struct  NNF_DOUBLE_INT *pDowTime,CHAR cStreamNum )
{
	logTimestamp("Entry : fUpdateTimeStamp");

	CHAR    *sUpdateQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
	SHORT   j;
	LONG32  iGroupId=0;
	SHORT   iStreamId =0;
	ULONG32 iTime1 =0;
	ULONG32 iTime2 =0 ;
	logDebug2(" iGlobGroupId : %d", iGlobGroupId);
	iGroupId =iGlobGroupId;
	logDebug2("Local GroupId : %d", iGroupId);

	logDebug2("===========GlobGroupId [%d]====Updating  Timestamp ",iGroupId);
	sprintf(sUpdateQry,"UPDATE EXCH_DOWNLOAD_DATA SET EDD_TIMESTAMP1= %u,EDD_TIMESTAMP2= %u  WHERE EDD_EXCH_ID= \"%s\" AND EDD_SEGMENT=\'%c\' AND EDD_GROUP_ID= %d AND EDD_STREAM_ID = \'%c\' ;",pDowTime->iLogTime1,pDowTime->iLogTime2,NSE_EXCH,CURRENCY_SEGMENT,iGroupId,cStreamNum);

	logDebug2("sUpdateQry :%s:",sUpdateQry);

	if(mysql_query(DBConDrvNNF,sUpdateQry) != SUCCESS)
	{
		sql_Error(DBConDrvNNF);
		return FALSE;
	}
	else
	{
		mysql_commit(DBConDrvNNF);
		return TRUE;
	}

	logTimestamp("Exit : fUpdateTimeStamp");

}

	
BOOL    fSendGRrequest(CHAR *sSendnnf, LONG32 iGroupid,LONG32  iPrimarySecondary)
{
        logTimestamp("Entry : [fSendGRrequest]");

        struct  NNF_GR_REQUEST  *pGRSign;

        CHAR    *sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
        pGRSign= (struct NNF_GR_REQUEST *)malloc(sizeof(struct NNF_GR_REQUEST));

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        memset((CHAR*)pGRSign,' ',sizeof(struct NNF_GR_REQUEST));
        memcpy(pGRSign,sSendnnf,sizeof(struct NNF_GR_REQUEST));

        pGRSign->pHeader.iErrorCode = 0 ;
        pGRSign->pHeader.iTraderID= 0 ;
        pGRSign->pHeader.iLogTimeStamp = 0 ;
        pGRSign->pHeader.iMsgCode = TC_EQU_NSE_GR_REQ;
        memset(pGRSign->pHeader.sAlphaSplit,' ',2);
        memset(pGRSign->pHeader.sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
        memset(pGRSign->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
        memset(pGRSign->pHeader.sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
        memset(pGRSign->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
        memset(pGRSign->pHeader.sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
        memset(pGRSign->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
        memcpy(pGRSign->pHeader.sAlphaSplit,"NT",2);
        pGRSign->pHeader.iMsgLength = sizeof(struct NNF_GR_REQUEST);

        logDebug3("sizeof(struct NNF_GR_REQUEST) :%d:",sizeof(struct NNF_GR_REQUEST));

        sprintf(sQuery,"SELECT EAM_BROKER_ID,EAM_BOX_ID,EAM_EXCH_USER_ID,EAM_BOX_ID_SEC FROM EXCH_ADMINISTRATION_MASTER \
                        WHERE EAM_GROUP_ID= %d AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\'; ",iGroupid,NSE_EXCH,CURRENCY_SEGMENT);

        logDebug2("sQuery :%s:",sQuery);

/***/
        if (mysql_query(DBConDrvNNF, sQuery) != SUCCESS)
        {
                sql_Error(DBConDrvNNF);
                return ERROR;
        }
	
	Res = mysql_store_result(DBConDrvNNF);
/***/
        free(sQuery);
/**/
        while((Row = mysql_fetch_row(Res)))
        {


                pGRSign->pHeader.iTraderID= atoi(Row[2]) ;
                iTmpTradeId = atoi(Row[2]) ;
//                pGRSign->iBoxID= atoi(Row[1]);
		// Printing for monitoring purpose @NItish
		if(iPrimarySecondary == 0)
                {
                        logTimestamp(":%s: TRYING TO CONNECT TO PRIMARY BOX :%s: ",KEY_WORD_MONITORING,Row[1]);
                        pGRSign->iBoxID= atoi(Row[1]);
                }
                else
                {
                        logTimestamp(":%s: TRYING TO CONNECT TO SECONDARY BOX :%s: ",KEY_WORD_MONITORING,Row[3]);
                        pGRSign->iBoxID= atoi(Row[3]);
                }
                strncpy(pGRSign->sBrokerID,Row[0],BROKER_CODE_LENGTH);
                pGRSign->cFiller1 = ' ';

        }

/**
 *  *         pGRSign->pHeader.iTraderID= 90061 ;
 *   *                 pGRSign->iBoxID= 9527;//9462 First we used this
 *    *                         strncpy(pGRSign->sBrokerID,"90061",BROKER_CODE_LENGTH);
 *     *                                 pGRSign->cFiller1 = ' ';
 *      *                                 ***/
        logInfo("fSendGRrequest Before Twiddle ");
        logDebug3("sendGRreq    TimeStamp       :%d:",pGRSign->pHeader.iLogTimeStamp);
        logDebug3("sendGRreq    Error Code      :%d:",pGRSign->pHeader.iErrorCode);
        logDebug3("sendGRreq    Mesg Length     :%d:",pGRSign->pHeader.iMsgLength);
        logDebug3("sendGRreq    iTraderID       :%d:",pGRSign->pHeader.iTraderID);
        logDebug3("sendGRreq    sAlphaSplit     :%s:",pGRSign->pHeader.sAlphaSplit);
        logDebug3("sendGRreq    sTimeStamp1     :%s:",pGRSign->pHeader.sTimeStamp1);
        logDebug3("sendGRreq    sTimeStamp2     :%s:",pGRSign->pHeader.sTimeStamp2);
        logDebug3("sendGRreq    sTimeStamp3     :%s:",pGRSign->pHeader.sTimeStamp3);
        logDebug3("sendGRreq    sBrokerID       :%s:",pGRSign->sBrokerID);
        logDebug3("sendGRreq    iBoxID          :%d:",pGRSign->iBoxID);

        TWIDDLE( pGRSign->pHeader.iLogTimeStamp);
        TWIDDLE( pGRSign->pHeader.iMsgCode);
        TWIDDLE( pGRSign->pHeader.iErrorCode);
        TWIDDLE( pGRSign->pHeader.iMsgLength);
        TWIDDLE( pGRSign->pHeader.iTraderID);
        TWIDDLE( pGRSign->iBoxID);
	logInfo("fSendGRrequest After Twiddle ");
        logDebug3("sendGRreq    TimeStamp       :%d:",pGRSign->pHeader.iLogTimeStamp);
        logDebug3("sendGRreq    Error Code      :%d:",pGRSign->pHeader.iErrorCode);
        logDebug3("sendGRreq    Mesg Length     :%d:",pGRSign->pHeader.iMsgLength);
        logDebug3("sendGRreq    iTraderID       :%d:",pGRSign->pHeader.iTraderID);
        logDebug3("sendGRreq    sAlphaSplit     :%s:",pGRSign->pHeader.sAlphaSplit);
        logDebug3("sendGRreq    sTimeStamp1     :%s:",pGRSign->pHeader.sTimeStamp1);
        logDebug3("sendGRreq    sTimeStamp2     :%s:",pGRSign->pHeader.sTimeStamp2);
        logDebug3("sendGRreq    sTimeStamp3     :%s:",pGRSign->pHeader.sTimeStamp3);
        logDebug3("sendGRreq    sBrokerID       :%s:",pGRSign->sBrokerID);
        logDebug3("sendGRreq    iBoxID          :%d:",pGRSign->iBoxID);

        memcpy(sSendnnf,pGRSign,sizeof(struct NNF_GR_REQUEST));
        free(pGRSign);
        logTimestamp("Exit : fSendGRrequest");
        return TRUE;

}


BOOL    RecvGRresp(CHAR *sTempData)
{
        logTimestamp("Entry : RecvGRresp");

        LONG32  iDatasent;

        struct NNF_GR_RESP      *pRecv;

        pRecv = (struct NNF_GR_RESP     *)malloc(sizeof(struct NNF_GR_RESP));
        memset((CHAR *)pRecv,' ',sizeof(struct NNF_GR_RESP));
        memcpy(pRecv,sTempData,sizeof(struct NNF_GR_RESP));

        CHAR    sQuery [MAX_QUERY_SIZE];

        memset(sQuery,'\0',MAX_QUERY_SIZE);
	CHAR    sErrorStr[DB_REASON_DESC_LEN];
        memset(sErrorStr,'\0',DB_REASON_DESC_LEN);	

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logInfo("This RecvGRresp Before Twiddle ");
        logDebug3("RecvGRresp: iMsgCode         :%d: ",pRecv->pHeader.iMsgCode);
	logDebug3("RecvGRresp: iLogTimeStamp    :%d: ",pRecv->pHeader.iLogTimeStamp);
        logDebug3("RecvGRresp: sAlphaSplit      :%s: ",pRecv->pHeader.sAlphaSplit);
        logDebug3("RecvGRresp: iTraderID        :%d: ",pRecv->pHeader.iTraderID);
        logDebug3("RecvGRresp: iErrorCode       :%d: ",pRecv->pHeader.iErrorCode);
        logDebug3("RecvGRresp: sTimeStamp1      :%s: ",pRecv->pHeader.sTimeStamp1);
        logDebug3("RecvGRresp: sTimeStamp2      :%s: ",pRecv->pHeader.sTimeStamp2);
        logDebug3("RecvGRresp: sTimeStamp3      :%s: ",pRecv->pHeader.sTimeStamp3);
        logDebug3("RecvGRresp: iMsgLength       :%d: ",pRecv->pHeader.iMsgLength);

        logDebug3("RecvGRresp: iBoxID           :%d: ",pRecv->iBoxID);
        logDebug3("RecvGRresp: sBrokerID        :%s: ",pRecv->sBrokerID);
        logDebug3("RecvGRresp: sHostIP          :%s: ",pRecv->sHostIP);
        logDebug3("RecvGRresp: iHostPort        :%d: ",pRecv->iHostPort);
        logDebug3("RecvGRresp: sSessionKey      :%s: ", pRecv->sSessionKey);
        logDebug3("RecvGRresp: iErrorCod        :%d: ", pRecv->pHeader.iErrorCode);

        TWIDDLE( pRecv->pHeader.iLogTimeStamp);
        TWIDDLE( pRecv->pHeader.iMsgCode);
        TWIDDLE( pRecv->pHeader.iErrorCode);
        TWIDDLE( pRecv->pHeader.iMsgLength);

        TWIDDLE(pRecv->iBoxID);
        TWIDDLE(pRecv->iHostPort);
        logInfo("This RecvGRresp After Twiddle ");
        logDebug3("RecvGRresp: iMsgCode         :%d: ",pRecv->pHeader.iMsgCode);
        logDebug3("RecvGRresp: iLogTimeStamp    :%d: ",pRecv->pHeader.iLogTimeStamp);
        logDebug3("RecvGRresp: sAlphaSplit      :%s: ",pRecv->pHeader.sAlphaSplit);
        logDebug3("RecvGRresp: iTraderID        :%d: ",pRecv->pHeader.iTraderID);
        logDebug3("RecvGRresp: iErrorCode       :%d: ",pRecv->pHeader.iErrorCode);
        logDebug3("RecvGRresp: sTimeStamp1      :%s: ",pRecv->pHeader.sTimeStamp1);
        logDebug3("RecvGRresp: sTimeStamp2      :%s: ",pRecv->pHeader.sTimeStamp2);
        logDebug3("RecvGRresp: sTimeStamp3      :%s: ",pRecv->pHeader.sTimeStamp3);
        logDebug3("RecvGRresp: iMsgLength       :%d: ",pRecv->pHeader.iMsgLength);

        logDebug3("RecvGRresp: iErrorCode      :%d: ", pRecv->pHeader.iErrorCode);
        logDebug3("RecvGRresp: iBoxID          :%d: ",pRecv->iBoxID);
        logDebug3("RecvGRresp: iHostPort       :%d: ",pRecv->iHostPort);
        logDebug3("RecvGRresp: sBrokerID       :%s: ",pRecv->sBrokerID);
        logDebug3("RecvGRresp: sHostIP         :%s: ",pRecv->sHostIP);
        logDebug3("RecvGRresp: sSessionKey     :%s: ", pRecv->sSessionKey);	
	memset(sSessionKey,' ',NNF_SESSION_KEY_LEN);
        strncpy(sSessionKey,pRecv->sSessionKey,NNF_SESSION_KEY_LEN);
        if(pRecv->pHeader.iErrorCode == 0)
        {

                iGrSockFd = tcpDirConnection(pRecv->sHostIP,pRecv->iHostPort);
                logDebug2("Returning iGrsockFd :%d:",iGrSockFd);
                return iGrSockFd;
        }
        else
        {
                logFatal("GR req rejected with Error ID :%d:",pRecv->pHeader.iErrorCode);
                logInfo("Exiting Process here ");
		fFetchErrStr(pRecv->pHeader.iErrorCode,&sErrorStr);
		// Printing for monitoring purpose @NItish
                logTimestamp(":%s: GATEWAY ROUTER SIGNON RESPONSE FROM EXCHANGE WITH ERROR CODE :%s: ",KEY_WORD_MONITORING,sErrorStr);
                return FALSE;
        //        exit(ERROR);
        }
        logTimestamp("Exit : RecvGRresp");

}

BOOL    fSendBoxSignreq(CHAR *sSendnnf, LONG32 iGroupid,LONG32  iPrimarySecondary)
{
        logTimestamp("Entry : [fSendBoxSignreq]");

        struct  NNF_BOX_SIGNIN_REQUEST *pBoxSignReq;

        CHAR    *sQuery= malloc(sizeof(CHAR) *MAX_QUERY_SIZE);
        pBoxSignReq= (struct NNF_BOX_SIGNIN_REQUEST *)malloc(sizeof(struct NNF_BOX_SIGNIN_REQUEST));

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        memset((CHAR*)pBoxSignReq,' ',sizeof(struct NNF_BOX_SIGNIN_REQUEST));
        memcpy(pBoxSignReq,sSendnnf,sizeof(struct NNF_BOX_SIGNIN_REQUEST));

        pBoxSignReq->pHeader.iMsgCode = TC_EQU_NSE_BOX_SIGN_ON_REQ;
        pBoxSignReq->pHeader.iLogTimeStamp = 0 ;
        memset(pBoxSignReq->pHeader.sAlphaSplit,' ',2);
        memcpy(pBoxSignReq->pHeader.sAlphaSplit,"NT",2);
        pBoxSignReq->pHeader.iTraderID= 0;
        pBoxSignReq->pHeader.iErrorCode = 0 ;
        memset(pBoxSignReq->pHeader.sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
	memset(pBoxSignReq->pHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
        memset(pBoxSignReq->pHeader.sTimeStamp2,'\0',NNF_DATE_TIME_LEN);
        memset(pBoxSignReq->pHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
        memset(pBoxSignReq->pHeader.sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
        memset(pBoxSignReq->pHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
        pBoxSignReq->pHeader.iMsgLength = sizeof(struct NNF_BOX_SIGNIN_REQUEST);
        pBoxSignReq->iBoxID =0 ;
        memset(pBoxSignReq->sBrokerID,'\0',BROKER_CODE_LENGTH);
        memset(pBoxSignReq->sBrokerID,' ',BROKER_CODE_LENGTH);
        memset(pBoxSignReq->sFiller1,'\0',5);
        memset(pBoxSignReq->sSessionKey,'\0',NNF_SESSION_KEY_LEN);
        memset(pBoxSignReq->sSessionKey,' ',NNF_SESSION_KEY_LEN);

        logDebug3("sizeof(struct NNF_BOX_SIGNIN_REQUEST) :%d:",sizeof(struct NNF_BOX_SIGNIN_REQUEST));

        sprintf(sQuery,"SELECT EAM_BROKER_ID,EAM_BOX_ID,EAM_EXCH_USER_ID,EAM_BOX_ID_SEC FROM EXCH_ADMINISTRATION_MASTER \
                        WHERE EAM_GROUP_ID=%d  AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\'; ",iGroupid,NSE_EXCH,CURRENCY_SEGMENT);

        logDebug2("sQuery :%s:",sQuery);
/**/
        if (mysql_query(DBConDrvNNF, sQuery) != SUCCESS)
        {
                sql_Error(DBConDrvNNF);
                return ERROR;
        }

        Res = mysql_store_result(DBConDrvNNF);
/***/
        free(sQuery);
/***/
        while((Row = mysql_fetch_row(Res)))
        {
                pBoxSignReq->pHeader.iTraderID = atoi(Row[2]);
//                pBoxSignReq->iBoxID= atoi(Row[1]);
		// Printing for monitoring purpose @NItish
		if(iPrimarySecondary == 0)
                {
                        logTimestamp(":%s: SENDING BOX SIGN IN  TO PRIMARY BOX :%s: ",KEY_WORD_MONITORING,Row[1]);
                        pBoxSignReq->iBoxID= atoi(Row[1]);
                }
                else
                {
                        logTimestamp(":%s: SENDING BOX SIGN IN TO SECONDARY BOX :%s: ",KEY_WORD_MONITORING,Row[3]);
                        pBoxSignReq->iBoxID= atoi(Row[3]);
                }
                strncpy(pBoxSignReq->sBrokerID,Row[0],BROKER_CODE_LENGTH);
                strncpy(pBoxSignReq->sSessionKey,sSessionKey,NNF_SESSION_KEY_LEN);

        }
/***
 *  *
 *   *         pBoxSignReq->pHeader.iTraderID= 90061 ;
 *   		pBoxSignReq->iBoxID= 9527;//9462 First we used this
 *   		 *                         strncpy(pBoxSignReq->sBrokerID,"90061",BROKER_CODE_LENGTH);
 *   		  *                                 strncpy(pBoxSignReq->sSessionKey,sSessionKey,NNF_SESSION_KEY_LEN);
 *   		   *
 *   		    *                                 ****/

        logInfo("*********************Before Twiddle*********************");
        logDebug3("sendBoxSignreq       MsgCode         :%d:",pBoxSignReq->pHeader.iMsgCode);
        logDebug3("sendBoxSignreq       TimeStamp       :%ld:",pBoxSignReq->pHeader.iLogTimeStamp);
        logDebug3("sendBoxSignreq       sAlphaSplit     :%s:",pBoxSignReq->pHeader.sAlphaSplit);
        logDebug3("sendBoxSignreq       iTraderID       :%d:",pBoxSignReq->pHeader.iTraderID);
        logDebug3("sendBoxSignreq       sTimeStamp1     :%s:",pBoxSignReq->pHeader.sTimeStamp1);
        logDebug3("sendBoxSignreq       sTimeStamp2     :%s:",pBoxSignReq->pHeader.sTimeStamp2);
        logDebug3("sendBoxSignreq       sTimeStamp3     :%s:",pBoxSignReq->pHeader.sTimeStamp3);
        logDebug3("sendBoxSignreq       Error Code      :%d:",pBoxSignReq->pHeader.iErrorCode);
        logDebug3("sendBoxSignreq       Mesg Length     :%d:",pBoxSignReq->pHeader.iMsgLength);

        logDebug3("sendBoxSignreq       iBoxID          :%d:",pBoxSignReq->iBoxID);
        logDebug3("sendBoxSignreq       sBrokerID       :%s:",pBoxSignReq->sBrokerID);
        logDebug3("sendBoxSignreq       sSessionKey     :%s:",pBoxSignReq->sSessionKey);
        logInfo("*********************Before Twiddle*********************");

        TWIDDLE( pBoxSignReq->pHeader.iLogTimeStamp);
        TWIDDLE( pBoxSignReq->pHeader.iMsgCode);
        TWIDDLE( pBoxSignReq->pHeader.iErrorCode);
        TWIDDLE( pBoxSignReq->pHeader.iMsgLength);
        TWIDDLE( pBoxSignReq->pHeader.iTraderID);
        TWIDDLE( pBoxSignReq->iBoxID);

        logInfo("*********************After Twiddle*********************");
        logDebug3("sendBoxSignreq       MsgCode         :%d:",pBoxSignReq->pHeader.iMsgCode);
        logDebug3("sendBoxSignreq       TimeStamp       :%ld:",pBoxSignReq->pHeader.iLogTimeStamp);
        logDebug3("sendBoxSignreq       sAlphaSplit     :%s:",pBoxSignReq->pHeader.sAlphaSplit);
        logDebug3("sendBoxSignreq       iTraderID       :%d:",pBoxSignReq->pHeader.iTraderID);
        logDebug3("sendBoxSignreq       sTimeStamp1     :%s:",pBoxSignReq->pHeader.sTimeStamp1);
        logDebug3("sendBoxSignreq       sTimeStamp2     :%s:",pBoxSignReq->pHeader.sTimeStamp2);
        logDebug3("sendBoxSignreq       sTimeStamp3     :%s:",pBoxSignReq->pHeader.sTimeStamp3);
        logDebug3("sendBoxSignreq       Error Code      :%d:",pBoxSignReq->pHeader.iErrorCode);
        logDebug3("sendBoxSignreq       Mesg Length     :%d:",pBoxSignReq->pHeader.iMsgLength);

        logDebug3("sendBoxSignreq       iBoxID          :%d:",pBoxSignReq->iBoxID);
	logDebug3("sendBoxSignreq       sBrokerID       :%s:",pBoxSignReq->sBrokerID);
        logDebug3("sendBoxSignreq       sSessionKey     :%s:",pBoxSignReq->sSessionKey);
        logInfo("*********************After Twiddle*********************");

        memcpy(sSendnnf,pBoxSignReq,sizeof(struct NNF_BOX_SIGNIN_REQUEST));
        free(pBoxSignReq);
        logTimestamp("Exit : fSendBoxSignreq");
        return TRUE;

}

BOOL    RecvBoxSignResp(CHAR *sTempData)
{
        logTimestamp("Entry : RecvBoxSignResp");

        LONG32  iDatasent;
        struct NNF_BOX_SIGNIN_RESPONSE  *pBoxResp;

        pBoxResp = (struct NNF_BOX_SIGNIN_RESPONSE *)malloc(sizeof(struct NNF_BOX_SIGNIN_RESPONSE));
        memset((CHAR *)pBoxResp,' ',sizeof(struct NNF_BOX_SIGNIN_RESPONSE));
        memcpy(pBoxResp,sTempData,sizeof(struct NNF_BOX_SIGNIN_RESPONSE));

        CHAR    sQuery [MAX_QUERY_SIZE];

        memset(sQuery,'\0',MAX_QUERY_SIZE);
	CHAR    sErrorStr[DB_REASON_DESC_LEN];
        memset(sErrorStr,'\0',DB_REASON_DESC_LEN);

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logInfo("RecvBoxSignResp Before Twiddle ");
        logDebug3("RecvBoxSignResp: iMsgCode         :%d: ",pBoxResp->pHeader.iMsgCode);
        logDebug3("RecvBoxSignResp: iLogTimeStamp    :%d: ",pBoxResp->pHeader.iLogTimeStamp);
        logDebug3("RecvBoxSignResp: sAlphaSplit      :%s: ",pBoxResp->pHeader.sAlphaSplit);
        logDebug3("RecvBoxSignResp: iTraderID        :%d: ",pBoxResp->pHeader.iTraderID);
        logDebug3("RecvBoxSignResp: iErrorCode       :%d: ",pBoxResp->pHeader.iErrorCode);
        logDebug3("RecvBoxSignResp: sTimeStamp1      :%s: ",pBoxResp->pHeader.sTimeStamp1);
        logDebug3("RecvBoxSignResp: sTimeStamp2      :%s: ",pBoxResp->pHeader.sTimeStamp2);
        logDebug3("RecvBoxSignResp: sTimeStamp3      :%s: ",pBoxResp->pHeader.sTimeStamp3);
        logDebug3("RecvBoxSignResp: iMsgLength       :%d: ",pBoxResp->pHeader.iMsgLength);

        logDebug3("RecvBoxSignResp: iBoxID                 :%d: ",pBoxResp->iBoxID);
	TWIDDLE( pBoxResp->pHeader.iLogTimeStamp);
        TWIDDLE( pBoxResp->pHeader.iMsgCode);
        TWIDDLE( pBoxResp->pHeader.iErrorCode);
        TWIDDLE( pBoxResp->pHeader.iMsgLength);

        TWIDDLE(pBoxResp->iBoxID);

        logInfo("RecvBoxSignResp Before Twiddle ");
        logDebug3("RecvBoxSignResp: iMsgCode         :%d: ",pBoxResp->pHeader.iMsgCode);
        logDebug3("RecvBoxSignResp: iLogTimeStamp    :%d: ",pBoxResp->pHeader.iLogTimeStamp);
        logDebug3("RecvBoxSignResp: sAlphaSplit      :%s: ",pBoxResp->pHeader.sAlphaSplit);
        logDebug3("RecvBoxSignResp: iTraderID        :%d: ",pBoxResp->pHeader.iTraderID);
        logDebug3("RecvBoxSignResp: iErrorCode       :%d: ",pBoxResp->pHeader.iErrorCode);
        logDebug3("RecvBoxSignResp: sTimeStamp1      :%s: ",pBoxResp->pHeader.sTimeStamp1);
        logDebug3("RecvBoxSignResp: sTimeStamp2      :%s: ",pBoxResp->pHeader.sTimeStamp2);
        logDebug3("RecvBoxSignResp: sTimeStamp3      :%s: ",pBoxResp->pHeader.sTimeStamp3);
        logDebug3("RecvBoxSignResp: iMsgLength       :%d: ",pBoxResp->pHeader.iMsgLength);

        logDebug3("RecvBoxSignResp: iBoxID                 :%d: ",pBoxResp->iBoxID);
	if(pBoxResp->pHeader.iErrorCode != 0)
        {
                logFatal(" BOX Sign On pBoxResp->pHeader.iErrorCode :%d:",pBoxResp->pHeader.iErrorCode);
                fFetchErrStr(pBoxResp->pHeader.iErrorCode,&sErrorStr);
		// Printing for monitoring purpose @NItish
                logTimestamp(":%s: BOX SIGNON RESPONSE RECEIVE FROM EXCHANGE WITH ERROR :%s:",KEY_WORD_MONITORING,sErrorStr);
                return FALSE;
        }

        logTimestamp("Exit : RecvBoxSignResp");

}
	
BOOL    fFetchErrStr(LONG32     iErrorID,CHAR *sErrString)
{

        logTimestamp("Entry : fFetchErrStr");
        MYSQL_RES               *Res;
        MYSQL_ROW               Row;
        INT16   iNumRow;


        CHAR SelQuery [MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

        logDebug2(" fFetchErrStr iErrorID :%d:",iErrorID);

        sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = \"%s\" AND RM_ERR_CODE = \"%d\" ;",NSE_EXCH,iErrorID);

        logDebug2("%s",SelQuery);
        if (mysql_query(DBConDrvNNF, SelQuery) != SUCCESS)
        {
                logSqlFatal("Error in Select Serial No Query [Equproc_progN].");
                sql_Error(DBConDrvNNF);
                return FALSE;
        }

        Res = mysql_store_result(DBConDrvNNF);
        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);


        if(iNumRow != 0)
        {

                if((Row = mysql_fetch_row(Res)))
                {
                        logDebug2("serial no  :%s: ",Row[0]);
                        sprintf(sErrString,"EXCH:%d:%s:",iErrorID,Row[0]);

                }
        }
        else
        {
                sprintf(sErrString,"EXCH:%d:Not Specified in DB",DB_REASON_DESC_LEN);
		logDebug2("Error ID not Found in DB :%s:",sErrString);
                return FALSE;
        }

        logTimestamp("Exit : fFetchErrStr");
        return TRUE;
}
/*----------------------------------------------------------------------------/
 * Below function Map the NNF_ORDER_ENTRY_REQ_TM into NNF_ORD_RESPONSE_TM when
 * Signal 15 is caught handling @Rohit
/----------------------------------------------------------------------------*/
BOOL fNseCMOrdEntErrResp(CHAR *sOrderPck , CHAR *pOrdEntTMRsp)
{
	logTimestamp("Entry  fNseCMOrdEntErrResp");
        struct  NNF_ORDER_ENTRY_REQ_TM  *pDrvNNFTM = (struct  NNF_ORDER_ENTRY_REQ_TM  *)sOrderPck;
	struct  NNF_ORD_RESPONSE_TM *pOrdEntConfTMRsp = ( struct  NNF_ORD_RESPONSE_TM *) pOrdEntTMRsp ;

	TWIDDLE(pDrvNNFTM->iTradeID);
	TWIDDLE(pDrvNNFTM->iTokenNo);
	TWIDDLE(pDrvNNFTM->pSecInfo.iExpiryDate);
	TWIDDLE(pDrvNNFTM->pSecInfo.iStrikePrice);
	TWIDDLE(pDrvNNFTM->iBookType);
	TWIDDLE(pDrvNNFTM->iBuyOrSell);
	TWIDDLE(pDrvNNFTM->iDiscQty);
	TWIDDLE(pDrvNNFTM->iTotalQty);
	TWIDDLE(pDrvNNFTM->iPrice);
	TWIDDLE(pDrvNNFTM->iGoodTillDate);
	TWIDDLE(pDrvNNFTM->iBranchId);
	TWIDDLE(pDrvNNFTM->iExcgUserId);
	TWIDDLE(pDrvNNFTM->iProCli);
	TWIDDLE(pDrvNNFTM->fUserInfo);
	TWIDDLE(pDrvNNFTM->iAlgoId);
	TWIDDLE(pDrvNNFTM->iReservFiller);
	logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
	logDebug3("iTransCode   :%d:",pDrvNNFTM->iTransCode);
	logDebug3("iTradeID     :%d:",pDrvNNFTM->iTradeID);
	logDebug3("iTokenNo     :%d:",pDrvNNFTM->iTokenNo);
	logDebug3("sInstrumentName      :%s:",pDrvNNFTM->pSecInfo.sInstrumentName);
	logDebug3("iExpiryDate  :%d:",pDrvNNFTM->pSecInfo.iExpiryDate);
	logDebug3("iStrikePrice :%d:",pDrvNNFTM->pSecInfo.iStrikePrice);
	logDebug3("sOptionType  :%s:",pDrvNNFTM->pSecInfo.sOptionType);
	logDebug3("sAccCode     :%s:",pDrvNNFTM->sAccCode);
	logDebug3("iBookType    :%d:",pDrvNNFTM->iBookType);
	logDebug3("iBuyOrSell   :%d:",pDrvNNFTM->iBuyOrSell);
	logDebug3("iDiscQty     :%d:",pDrvNNFTM->iDiscQty);
	logDebug3("iTotalQty    :%d:",pDrvNNFTM->iTotalQty);
	logDebug3("iPrice       :%d:",pDrvNNFTM->iPrice);
	logDebug3("iGoodTillDate        :%d:",pDrvNNFTM->iGoodTillDate);
	logDebug3("iBranchId    :%d:",pDrvNNFTM->iBranchId);
	logDebug3("iExcgUserId  :%d:",pDrvNNFTM->iExcgUserId);
	logDebug3("sBrokerCode  :%s:",pDrvNNFTM->sBrokerCode);
	logDebug3("cSecSuspInd  :%c:",pDrvNNFTM->cSecSuspInd);
	logDebug3("sSettlor     :%s:",pDrvNNFTM->sSettlor);
	logDebug3("iProCli      :%d:",pDrvNNFTM->iProCli);
	logDebug3("fUserInfo    :%lf:",pDrvNNFTM->fUserInfo);
	logDebug3("sPanId       :%s:",pDrvNNFTM->sPanId);
	logDebug3("iAlgoId      :%d:",pDrvNNFTM->iAlgoId);
	logDebug3("iReservFiller        :%d:",pDrvNNFTM->iReservFiller);
	logDebug3("MFTerm       :%d:",pDrvNNFTM->pOrderTerms.MFTerm);
	logDebug3("AONTerm      :%d:",pDrvNNFTM->pOrderTerms.AONTerm);
	logDebug3("IOCTerm      :%d:",pDrvNNFTM->pOrderTerms.IOCTerm);
	logDebug3("GTCTerm      :%d:",pDrvNNFTM->pOrderTerms.GTCTerm);
	logDebug3("DayTerm      :%d:",pDrvNNFTM->pOrderTerms.DayTerm);
	logDebug3("StopLossTerm :%d:",pDrvNNFTM->pOrderTerms.StopLossTerm);
	logDebug3("Market       :%d:",pDrvNNFTM->pOrderTerms.Market);
	logDebug3("ATO          :%d:",pDrvNNFTM->pOrderTerms.ATO);
	logDebug3("Frozen       :%d:",pDrvNNFTM->pOrderTerms.Frozen);
	logDebug3("Modified     :%d:",pDrvNNFTM->pOrderTerms.Modified);
	logDebug3("Traded       :%d:",pDrvNNFTM->pOrderTerms.Traded);
	logDebug3("MatchedInd   :%d:",pDrvNNFTM->pOrderTerms.MatchedInd);
	
	pOrdEntConfTMRsp->iTransCode    = TC_EQU_NSE_ORD_ENT_ERR_RSP_TM ;
	pOrdEntConfTMRsp->iLogTime      = 0; 
	pOrdEntConfTMRsp->iUserID 	= pDrvNNFTM->iExcgUserId ;
	pOrdEntConfTMRsp->iErrorCode    = EXCHANGE_DOWN_ERROR;
	pOrdEntConfTMRsp->fTimeStamp1= 0;
	pOrdEntConfTMRsp->cTimeStamp2= 0;
	pOrdEntConfTMRsp->cModCanBy= MOD_CAN_CODE_FOR_DEALER;
	pOrdEntConfTMRsp->iReasonCode	= EXCHANGE_DOWN_ERROR;
	pOrdEntConfTMRsp->iTokenNo	= pDrvNNFTM->iTokenNo;
	strncpy(pOrdEntConfTMRsp->pSecInfo.sInstrumentName,pDrvNNFTM->pSecInfo.sInstrumentName,INSTR_NAME_LEN);
	pOrdEntConfTMRsp->pSecInfo.iExpiryDate = pDrvNNFTM->pSecInfo.iExpiryDate;
	pOrdEntConfTMRsp->pSecInfo.iStrikePrice = pDrvNNFTM->pSecInfo.iStrikePrice ;
	strncpy(pOrdEntConfTMRsp->pSecInfo.sOptionType,pDrvNNFTM->pSecInfo.sOptionType,OPT_TYPE_LEN);
	pOrdEntConfTMRsp->fOrderNum = 0 ;
	strncpy(pOrdEntConfTMRsp->sAccCode,pDrvNNFTM->sAccCode,ACCOUNT_CODE_LEN);
	pOrdEntConfTMRsp->iBookType = pDrvNNFTM->iBookType ;
	pOrdEntConfTMRsp->iBuyOrSell = pDrvNNFTM->iBuyOrSell ;
	pOrdEntConfTMRsp->iDiscQty = pDrvNNFTM->iDiscQty ;
	pOrdEntConfTMRsp->iDiscQtyRemaining = pDrvNNFTM->iDiscQty ; 
	pOrdEntConfTMRsp->iTotalQtyRemaining = pDrvNNFTM->iTotalQty ;
	pOrdEntConfTMRsp->iTotalQty = pDrvNNFTM->iTotalQty ;
	pOrdEntConfTMRsp->iQtyFilledToday = 0 ;
	pOrdEntConfTMRsp->iPrice = pDrvNNFTM->iPrice ;
	pOrdEntConfTMRsp->iEntryTime= 1259513131;
	pOrdEntConfTMRsp->iLastModifiedTime= 1259513131;
	pOrdEntConfTMRsp->iGoodTillDate = pDrvNNFTM->iGoodTillDate ;
	pOrdEntConfTMRsp->pOrderTerms.ATO = pDrvNNFTM->pOrderTerms.ATO ;
	pOrdEntConfTMRsp->pOrderTerms.Market = pDrvNNFTM->pOrderTerms.Market ;
	pOrdEntConfTMRsp->pOrderTerms.StopLossTerm = pDrvNNFTM->pOrderTerms.StopLossTerm ;
	pOrdEntConfTMRsp->pOrderTerms.DayTerm = pDrvNNFTM->pOrderTerms.DayTerm ;
	pOrdEntConfTMRsp->pOrderTerms.GTCTerm = pDrvNNFTM->pOrderTerms.GTCTerm ;
	pOrdEntConfTMRsp->pOrderTerms.IOCTerm = pDrvNNFTM->pOrderTerms.IOCTerm ;
	pOrdEntConfTMRsp->pOrderTerms.AONTerm = pDrvNNFTM->pOrderTerms.AONTerm ;
	pOrdEntConfTMRsp->pOrderTerms.MFTerm = pDrvNNFTM->pOrderTerms.MFTerm ;
	pOrdEntConfTMRsp->pOrderTerms.MatchedInd = pDrvNNFTM->pOrderTerms.MatchedInd ;
	pOrdEntConfTMRsp->pOrderTerms.Traded = pDrvNNFTM->pOrderTerms.Traded ;
	pOrdEntConfTMRsp->pOrderTerms.Modified = pDrvNNFTM->pOrderTerms.Modified ;
	pOrdEntConfTMRsp->pOrderTerms.Frozen = pDrvNNFTM->pOrderTerms.Frozen ;
	pOrdEntConfTMRsp->iBranchId = pDrvNNFTM->iBranchId ;
	pOrdEntConfTMRsp->iExcgUserId = pDrvNNFTM->iExcgUserId ;
	strncpy(pOrdEntConfTMRsp->sBrokerCode,pDrvNNFTM->sBrokerCode,BROKER_CODE_LENGTH);
	pOrdEntConfTMRsp->cSecSuspInd= 'C';
	pOrdEntConfTMRsp->cSecSuspInd = pDrvNNFTM->cSecSuspInd ;
	strncpy(pOrdEntConfTMRsp->sSettlor,pDrvNNFTM->sSettlor,NNF_SETTLOR_LEN);
	pOrdEntConfTMRsp->iProCli = pDrvNNFTM->iProCli ;
	pOrdEntConfTMRsp->fUserInfo = pDrvNNFTM->fUserInfo ;
	pOrdEntConfTMRsp->sExchRsrvdFlds=pDrvNNFTM->sExchRsrvdFlds ;
	strncpy(pOrdEntConfTMRsp->sPanId,pDrvNNFTM->sPanId,NNF_PAN_NUM_LEN);
	pOrdEntConfTMRsp->iAlgoId = pDrvNNFTM->iAlgoId ;
	pOrdEntConfTMRsp->iReservedFill = pDrvNNFTM->iReservFiller ;
	pOrdEntConfTMRsp->iLastActiRef= 0;
	
	logDebug2(" Before twiddle pOrdEntConfTMRsp->iTransCode :%d:",pOrdEntConfTMRsp->iTransCode);
//	TWIDDLE(pOrdEntConfTMRsp->iTransCode);
//        TWIDDLE(pOrdEntConfTMRsp->iTokenNo);
	TWIDDLE(pOrdEntConfTMRsp->iErrorCode);  
	TWIDDLE(pOrdEntConfTMRsp->iReasonCode); 
        TWIDDLE(pOrdEntConfTMRsp->pSecInfo.iExpiryDate);
        TWIDDLE(pOrdEntConfTMRsp->pSecInfo.iStrikePrice);
        TWIDDLE(pOrdEntConfTMRsp->iBookType);
        TWIDDLE(pOrdEntConfTMRsp->iBuyOrSell);
        TWIDDLE(pOrdEntConfTMRsp->iDiscQty);
        TWIDDLE(pOrdEntConfTMRsp->iTotalQty);
	TWIDDLE(pOrdEntConfTMRsp->iTotalQtyRemaining);
        TWIDDLE(pOrdEntConfTMRsp->iPrice);
        TWIDDLE(pOrdEntConfTMRsp->iGoodTillDate);
        TWIDDLE(pOrdEntConfTMRsp->iBranchId);
        TWIDDLE(pOrdEntConfTMRsp->iExcgUserId);
        TWIDDLE(pOrdEntConfTMRsp->iProCli);
        TWIDDLE(pOrdEntConfTMRsp->fUserInfo);
        TWIDDLE(pOrdEntConfTMRsp->iAlgoId);
//        TWIDDLE(pOrdEntConfTMRsp->iReservedFill);

	logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
	logDebug3("iTransCode   :%d:",pOrdEntConfTMRsp->iTransCode);
	logDebug3("iTokenNo     :%d:",pOrdEntConfTMRsp->iTokenNo);
	logDebug3("sInstrumentName      :%s:",pOrdEntConfTMRsp->pSecInfo.sInstrumentName);
	logDebug3("iExpiryDate  :%d:",pOrdEntConfTMRsp->pSecInfo.iExpiryDate);
	logDebug3("iStrikePrice :%d:",pOrdEntConfTMRsp->pSecInfo.iStrikePrice);
	logDebug3("sOptionType  :%s:",pOrdEntConfTMRsp->pSecInfo.sOptionType);
	logDebug3("sAccCode     :%s:",pOrdEntConfTMRsp->sAccCode);
	logDebug3("iBookType    :%d:",pOrdEntConfTMRsp->iBookType);
	logDebug3("iBuyOrSell   :%d:",pOrdEntConfTMRsp->iBuyOrSell);
	logDebug3("iDiscQty     :%d:",pOrdEntConfTMRsp->iDiscQty);
	logDebug3("iTotalQty    :%d:",pOrdEntConfTMRsp->iTotalQty);
	logDebug3("iPrice       :%d:",pOrdEntConfTMRsp->iPrice);
	logDebug3("iGoodTillDate        :%d:",pOrdEntConfTMRsp->iGoodTillDate);
	logDebug3("iBranchId    :%d:",pOrdEntConfTMRsp->iBranchId);
	logDebug3("iExcgUserId  :%d:",pOrdEntConfTMRsp->iExcgUserId);
	logDebug3("sBrokerCode  :%s:",pOrdEntConfTMRsp->sBrokerCode);
	logDebug3("cSecSuspInd  :%c:",pOrdEntConfTMRsp->cSecSuspInd);
	logDebug3("sSettlor     :%s:",pOrdEntConfTMRsp->sSettlor);
	logDebug3("iProCli      :%d:",pOrdEntConfTMRsp->iProCli);
	logDebug3("fUserInfo    :%lf:",pOrdEntConfTMRsp->fUserInfo);
	logDebug3("sPanId       :%s:",pOrdEntConfTMRsp->sPanId);
	logDebug3("iAlgoId      :%d:",pOrdEntConfTMRsp->iAlgoId);
	logDebug3("iReservFiller        :%d:",pOrdEntConfTMRsp->iReservedFill);
	logDebug3("MFTerm       :%d:",pOrdEntConfTMRsp->pOrderTerms.MFTerm);
	logDebug3("AONTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.AONTerm);
	logDebug3("IOCTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.IOCTerm);
	logDebug3("GTCTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.GTCTerm);
	logDebug3("DayTerm      :%d:",pOrdEntConfTMRsp->pOrderTerms.DayTerm);
	logDebug3("StopLossTerm :%d:",pOrdEntConfTMRsp->pOrderTerms.StopLossTerm);
	logDebug3("Market       :%d:",pOrdEntConfTMRsp->pOrderTerms.Market);
	logDebug3("ATO          :%d:",pOrdEntConfTMRsp->pOrderTerms.ATO);
	logDebug3("Frozen       :%d:",pOrdEntConfTMRsp->pOrderTerms.Frozen);
	logDebug3("Modified     :%d:",pOrdEntConfTMRsp->pOrderTerms.Modified);
	logDebug3("Traded       :%d:",pOrdEntConfTMRsp->pOrderTerms.Traded);
	logDebug3("MatchedInd   :%d:",pOrdEntConfTMRsp->pOrderTerms.MatchedInd);	

	memcpy(pOrdEntTMRsp ,( CHAR *) pOrdEntConfTMRsp,sizeof(struct NNF_ORD_RESPONSE_TM));
	logTimestamp("Exit  fNseCMOrdEntErrResp");
}

BOOL fNseCMOrdModErrResp(CHAR *sOrderPck , CHAR *pOrdModTMRsp)
{
        logTimestamp("Entry  fNseCMOrdModErrResp");
        struct  NNF_ORD_MOD_CAN_REQ_TM *pDrvNNFTM = (struct  NNF_ORD_MOD_CAN_REQ_TM *)sOrderPck;
        struct  NNF_ORD_RESPONSE_TM *pOrdModConfTMRsp = ( struct  NNF_ORD_RESPONSE_TM *) pOrdModTMRsp ;

        TWIDDLE(pDrvNNFTM->iTokenNo);
        TWIDDLE(pDrvNNFTM->pSecInfo.iExpiryDate);
        TWIDDLE(pDrvNNFTM->pSecInfo.iStrikePrice);
        TWIDDLE(pDrvNNFTM->iBookType);
        TWIDDLE(pDrvNNFTM->iBuyOrSell);
        TWIDDLE(pDrvNNFTM->iDiscQty);
        TWIDDLE(pDrvNNFTM->iTotalQty);
        TWIDDLE(pDrvNNFTM->iPrice);
        TWIDDLE(pDrvNNFTM->iGoodTillDate);
        TWIDDLE(pDrvNNFTM->iBranchId);
        TWIDDLE(pDrvNNFTM->iExcgUserId);
        TWIDDLE(pDrvNNFTM->iProCli);
        TWIDDLE(pDrvNNFTM->fUserInfo);
        TWIDDLE(pDrvNNFTM->iAlgoId);
        TWIDDLE(pDrvNNFTM->iReservdFiller1);
	TWIDDLE(pDrvNNFTM->iEntryTime);
	TWIDDLE(pDrvNNFTM->iLastModifiedTime);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pDrvNNFTM->iTransCode);
        logDebug3("iTokenNo     :%d:",pDrvNNFTM->iTokenNo);
        logDebug3("sInstrumentName      :%s:",pDrvNNFTM->pSecInfo.sInstrumentName);
        logDebug3("iExpiryDate  :%d:",pDrvNNFTM->pSecInfo.iExpiryDate);
        logDebug3("iStrikePrice :%d:",pDrvNNFTM->pSecInfo.iStrikePrice);
        logDebug3("sOptionType  :%s:",pDrvNNFTM->pSecInfo.sOptionType);
        logDebug3("sAccCode     :%s:",pDrvNNFTM->sAccCode);
        logDebug3("iBookType    :%d:",pDrvNNFTM->iBookType);
        logDebug3("iBuyOrSell   :%d:",pDrvNNFTM->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pDrvNNFTM->iDiscQty);
        logDebug3("iTotalQty    :%d:",pDrvNNFTM->iTotalQty);
        logDebug3("iPrice       :%d:",pDrvNNFTM->iPrice);
        logDebug3("iGoodTillDate        :%d:",pDrvNNFTM->iGoodTillDate);
        logDebug3("iBranchId    :%d:",pDrvNNFTM->iBranchId);
        logDebug3("iExcgUserId  :%d:",pDrvNNFTM->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pDrvNNFTM->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pDrvNNFTM->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pDrvNNFTM->sSettlor);
        logDebug3("iProCli      :%d:",pDrvNNFTM->iProCli);
	logDebug3("fUserInfo    :%lf:",pDrvNNFTM->fUserInfo);
        logDebug3("sPanId       :%s:",pDrvNNFTM->sPanId);
        logDebug3("iAlgoId      :%d:",pDrvNNFTM->iAlgoId);
        logDebug3("iReservdFiller1:%d:",pDrvNNFTM->iReservdFiller1);
        logDebug3("MFTerm       :%d:",pDrvNNFTM->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pDrvNNFTM->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pDrvNNFTM->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pDrvNNFTM->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pDrvNNFTM->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pDrvNNFTM->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pDrvNNFTM->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pDrvNNFTM->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pDrvNNFTM->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pDrvNNFTM->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pDrvNNFTM->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pDrvNNFTM->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pDrvNNFTM->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pDrvNNFTM->iLastModifiedTime);

        pOrdModConfTMRsp->iTransCode    = TC_EQU_NSE_ORD_MOD_ERR_RSP_TM;
        pOrdModConfTMRsp->iLogTime      = 0;
	pOrdModConfTMRsp->iUserID       = pDrvNNFTM->iExcgUserId ;
        pOrdModConfTMRsp->iErrorCode    = EXCHANGE_DOWN_ERROR;
	pOrdModConfTMRsp->fTimeStamp1= 0;
        pOrdModConfTMRsp->cTimeStamp2= 0;
        pOrdModConfTMRsp->cModCanBy= MOD_CAN_CODE_FOR_DEALER;
        pOrdModConfTMRsp->iReasonCode   = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->iTokenNo      = pDrvNNFTM->iTokenNo;
        strncpy(pOrdModConfTMRsp->pSecInfo.sInstrumentName,pDrvNNFTM->pSecInfo.sInstrumentName,INSTR_NAME_LEN);
        pOrdModConfTMRsp->pSecInfo.iExpiryDate = pDrvNNFTM->pSecInfo.iExpiryDate;
        pOrdModConfTMRsp->pSecInfo.iStrikePrice = pDrvNNFTM->pSecInfo.iStrikePrice ;
        strncpy(pOrdModConfTMRsp->pSecInfo.sOptionType,pDrvNNFTM->pSecInfo.sOptionType,OPT_TYPE_LEN);
        pOrdModConfTMRsp->fOrderNum = 0 ;
        strncpy(pOrdModConfTMRsp->sAccCode,pDrvNNFTM->sAccCode,ACCOUNT_CODE_LEN);
        pOrdModConfTMRsp->iBookType = pDrvNNFTM->iBookType ;
        pOrdModConfTMRsp->iBuyOrSell = pDrvNNFTM->iBuyOrSell ;
        pOrdModConfTMRsp->iDiscQty = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iDiscQtyRemaining = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iTotalQtyRemaining = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iTotalQty = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iQtyFilledToday = 0 ;
        pOrdModConfTMRsp->iPrice = pDrvNNFTM->iPrice ;
	pOrdModConfTMRsp->iEntryTime= pDrvNNFTM->iEntryTime;
	pOrdModConfTMRsp->iLastModifiedTime= pDrvNNFTM->iLastModifiedTime;
        pOrdModConfTMRsp->iGoodTillDate = pDrvNNFTM->iGoodTillDate ;
	pOrdModConfTMRsp->pOrderTerms.ATO = pDrvNNFTM->pOrderTerms.ATO ;
        pOrdModConfTMRsp->pOrderTerms.Market = pDrvNNFTM->pOrderTerms.Market ;
        pOrdModConfTMRsp->pOrderTerms.StopLossTerm = pDrvNNFTM->pOrderTerms.StopLossTerm ;
        pOrdModConfTMRsp->pOrderTerms.DayTerm = pDrvNNFTM->pOrderTerms.DayTerm ;
        pOrdModConfTMRsp->pOrderTerms.GTCTerm = pDrvNNFTM->pOrderTerms.GTCTerm ;
        pOrdModConfTMRsp->pOrderTerms.IOCTerm = pDrvNNFTM->pOrderTerms.IOCTerm ;
        pOrdModConfTMRsp->pOrderTerms.AONTerm = pDrvNNFTM->pOrderTerms.AONTerm ;
        pOrdModConfTMRsp->pOrderTerms.MFTerm = pDrvNNFTM->pOrderTerms.MFTerm ;
        pOrdModConfTMRsp->pOrderTerms.MatchedInd = pDrvNNFTM->pOrderTerms.MatchedInd ;
        pOrdModConfTMRsp->pOrderTerms.Traded = pDrvNNFTM->pOrderTerms.Traded ;
        pOrdModConfTMRsp->pOrderTerms.Modified = pDrvNNFTM->pOrderTerms.Modified ;
        pOrdModConfTMRsp->pOrderTerms.Frozen = pDrvNNFTM->pOrderTerms.Frozen ;
        pOrdModConfTMRsp->iBranchId = pDrvNNFTM->iBranchId ;
        pOrdModConfTMRsp->iExcgUserId = pDrvNNFTM->iExcgUserId ;
        strncpy(pOrdModConfTMRsp->sBrokerCode,pDrvNNFTM->sBrokerCode,BROKER_CODE_LENGTH);
        pOrdModConfTMRsp->cSecSuspInd= 'C';
        pOrdModConfTMRsp->cSecSuspInd = pDrvNNFTM->cSecSuspInd ;
        strncpy(pOrdModConfTMRsp->sSettlor,pDrvNNFTM->sSettlor,NNF_SETTLOR_LEN);
        pOrdModConfTMRsp->iProCli = pDrvNNFTM->iProCli ;
        pOrdModConfTMRsp->fUserInfo = pDrvNNFTM->fUserInfo ;
        pOrdModConfTMRsp->sExchRsrvdFlds=pDrvNNFTM->sExchRsrvdFlds ;
        strncpy(pOrdModConfTMRsp->sPanId,pDrvNNFTM->sPanId,NNF_PAN_NUM_LEN);
        pOrdModConfTMRsp->iAlgoId = pDrvNNFTM->iAlgoId ;
        pOrdModConfTMRsp->iReservedFill = pDrvNNFTM->iReservdFiller1;
        pOrdModConfTMRsp->iLastActiRef= 0;

        logDebug2(" Before twiddle pOrdModConfTMRsp->iTransCode :%d:",pOrdModConfTMRsp->iTransCode);
//	TWIDDLE(pOrdModConfTMRsp->iTransCode);
	TWIDDLE(pOrdModConfTMRsp->iErrorCode);
        TWIDDLE(pOrdModConfTMRsp->iReasonCode);
        TWIDDLE(pOrdModConfTMRsp->pSecInfo.iExpiryDate);
        TWIDDLE(pOrdModConfTMRsp->pSecInfo.iStrikePrice);
        TWIDDLE(pOrdModConfTMRsp->iBookType);
        TWIDDLE(pOrdModConfTMRsp->iBuyOrSell);
        TWIDDLE(pOrdModConfTMRsp->iDiscQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQtyRemaining);
        TWIDDLE(pOrdModConfTMRsp->iPrice);
        TWIDDLE(pOrdModConfTMRsp->iGoodTillDate);
        TWIDDLE(pOrdModConfTMRsp->iBranchId);
        TWIDDLE(pOrdModConfTMRsp->iExcgUserId);
        TWIDDLE(pOrdModConfTMRsp->iProCli);
        TWIDDLE(pOrdModConfTMRsp->fUserInfo);
        TWIDDLE(pOrdModConfTMRsp->iAlgoId);
	TWIDDLE(pOrdModConfTMRsp->iEntryTime);
	TWIDDLE(pOrdModConfTMRsp->iLastModifiedTime);

        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pOrdModConfTMRsp->iTransCode);
        logDebug3("iTokenNo     :%d:",pOrdModConfTMRsp->iTokenNo);
        logDebug3("sInstrumentName      :%s:",pOrdModConfTMRsp->pSecInfo.sInstrumentName);
        logDebug3("iExpiryDate  :%d:",pOrdModConfTMRsp->pSecInfo.iExpiryDate);
        logDebug3("iStrikePrice :%d:",pOrdModConfTMRsp->pSecInfo.iStrikePrice);
        logDebug3("sOptionType  :%s:",pOrdModConfTMRsp->pSecInfo.sOptionType);
        logDebug3("sAccCode     :%s:",pOrdModConfTMRsp->sAccCode);
        logDebug3("iBookType    :%d:",pOrdModConfTMRsp->iBookType);
        logDebug3("iBuyOrSell   :%d:",pOrdModConfTMRsp->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pOrdModConfTMRsp->iDiscQty);
        logDebug3("iTotalQty    :%d:",pOrdModConfTMRsp->iTotalQty);
        logDebug3("iPrice       :%d:",pOrdModConfTMRsp->iPrice);
        logDebug3("iGoodTillDate        :%d:",pOrdModConfTMRsp->iGoodTillDate);
        logDebug3("iBranchId    :%d:",pOrdModConfTMRsp->iBranchId);
        logDebug3("iExcgUserId  :%d:",pOrdModConfTMRsp->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pOrdModConfTMRsp->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pOrdModConfTMRsp->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pOrdModConfTMRsp->sSettlor);
        logDebug3("iProCli      :%d:",pOrdModConfTMRsp->iProCli);
        logDebug3("fUserInfo    :%lf:",pOrdModConfTMRsp->fUserInfo);
        logDebug3("sPanId       :%s:",pOrdModConfTMRsp->sPanId);
        logDebug3("iAlgoId      :%d:",pOrdModConfTMRsp->iAlgoId);
        logDebug3("iReservdFiller1:%d:",pOrdModConfTMRsp->iReservedFill);
        logDebug3("MFTerm       :%d:",pOrdModConfTMRsp->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pOrdModConfTMRsp->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pOrdModConfTMRsp->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pOrdModConfTMRsp->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pOrdModConfTMRsp->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pOrdModConfTMRsp->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pOrdModConfTMRsp->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pOrdModConfTMRsp->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pOrdModConfTMRsp->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pOrdModConfTMRsp->iLastModifiedTime);

        memcpy(pOrdModTMRsp ,( CHAR *) pOrdModConfTMRsp,sizeof(struct NNF_ORD_RESPONSE_TM));
        logTimestamp("Exit  fNseCMOrdModErrResp");
}

BOOL fNseCMOrdCanErrResp(CHAR *sOrderPck , CHAR *pOrdModTMRsp)
{
        logTimestamp("Entry  fNseCMOrdCanErrResp");
        struct  NNF_ORD_MOD_CAN_REQ_TM *pDrvNNFTM = (struct  NNF_ORD_MOD_CAN_REQ_TM *)sOrderPck;
        struct  NNF_ORD_RESPONSE_TM *pOrdModConfTMRsp = ( struct  NNF_ORD_RESPONSE_TM *) pOrdModTMRsp ;

        TWIDDLE(pDrvNNFTM->iTokenNo);
        TWIDDLE(pDrvNNFTM->pSecInfo.iExpiryDate);
        TWIDDLE(pDrvNNFTM->pSecInfo.iStrikePrice);
        TWIDDLE(pDrvNNFTM->iBookType);
        TWIDDLE(pDrvNNFTM->iBuyOrSell);
        TWIDDLE(pDrvNNFTM->iDiscQty);
        TWIDDLE(pDrvNNFTM->iTotalQty);
        TWIDDLE(pDrvNNFTM->iPrice);
        TWIDDLE(pDrvNNFTM->iGoodTillDate);
        TWIDDLE(pDrvNNFTM->iBranchId);
        TWIDDLE(pDrvNNFTM->iExcgUserId);
        TWIDDLE(pDrvNNFTM->iProCli);
        TWIDDLE(pDrvNNFTM->fUserInfo);
        TWIDDLE(pDrvNNFTM->iAlgoId);
        TWIDDLE(pDrvNNFTM->iReservdFiller1);
	TWIDDLE(pDrvNNFTM->iEntryTime);
	TWIDDLE(pDrvNNFTM->iLastModifiedTime);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pDrvNNFTM->iTransCode);
        logDebug3("iTokenNo     :%d:",pDrvNNFTM->iTokenNo);
        logDebug3("sInstrumentName      :%s:",pDrvNNFTM->pSecInfo.sInstrumentName);
        logDebug3("iExpiryDate  :%d:",pDrvNNFTM->pSecInfo.iExpiryDate);
        logDebug3("iStrikePrice :%d:",pDrvNNFTM->pSecInfo.iStrikePrice);
        logDebug3("sOptionType  :%s:",pDrvNNFTM->pSecInfo.sOptionType);
        logDebug3("sAccCode     :%s:",pDrvNNFTM->sAccCode);
        logDebug3("iBookType    :%d:",pDrvNNFTM->iBookType);
        logDebug3("iBuyOrSell   :%d:",pDrvNNFTM->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pDrvNNFTM->iDiscQty);
        logDebug3("iTotalQty    :%d:",pDrvNNFTM->iTotalQty);
        logDebug3("iPrice       :%d:",pDrvNNFTM->iPrice);
        logDebug3("iGoodTillDate        :%d:",pDrvNNFTM->iGoodTillDate);
        logDebug3("iBranchId    :%d:",pDrvNNFTM->iBranchId);
        logDebug3("iExcgUserId  :%d:",pDrvNNFTM->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pDrvNNFTM->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pDrvNNFTM->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pDrvNNFTM->sSettlor);
        logDebug3("iProCli      :%d:",pDrvNNFTM->iProCli);
	logDebug3("fUserInfo    :%lf:",pDrvNNFTM->fUserInfo);
        logDebug3("sPanId       :%s:",pDrvNNFTM->sPanId);
        logDebug3("iAlgoId      :%d:",pDrvNNFTM->iAlgoId);
        logDebug3("iReservdFiller1 :%d:",pDrvNNFTM->iReservdFiller1);
        logDebug3("MFTerm       :%d:",pDrvNNFTM->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pDrvNNFTM->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pDrvNNFTM->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pDrvNNFTM->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pDrvNNFTM->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pDrvNNFTM->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pDrvNNFTM->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pDrvNNFTM->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pDrvNNFTM->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pDrvNNFTM->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pDrvNNFTM->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pDrvNNFTM->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pDrvNNFTM->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pDrvNNFTM->iLastModifiedTime);

        pOrdModConfTMRsp->iTransCode    = TC_EQU_NSE_ORD_CAN_ERR_RSP_TM;
        pOrdModConfTMRsp->iLogTime      = 0;
        pOrdModConfTMRsp->iUserID       = pDrvNNFTM->iExcgUserId ;
        pOrdModConfTMRsp->iErrorCode    = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->fTimeStamp1= 0;
        pOrdModConfTMRsp->cTimeStamp2= 0;
        pOrdModConfTMRsp->cModCanBy= MOD_CAN_CODE_FOR_DEALER;
        pOrdModConfTMRsp->iReasonCode   = EXCHANGE_DOWN_ERROR;
        pOrdModConfTMRsp->iTokenNo      = pDrvNNFTM->iTokenNo;
        strncpy(pOrdModConfTMRsp->pSecInfo.sInstrumentName,pDrvNNFTM->pSecInfo.sInstrumentName,INSTR_NAME_LEN);
        pOrdModConfTMRsp->pSecInfo.iExpiryDate = pDrvNNFTM->pSecInfo.iExpiryDate;
        pOrdModConfTMRsp->pSecInfo.iStrikePrice = pDrvNNFTM->pSecInfo.iStrikePrice ;
        strncpy(pOrdModConfTMRsp->pSecInfo.sOptionType,pDrvNNFTM->pSecInfo.sOptionType,OPT_TYPE_LEN);
        pOrdModConfTMRsp->fOrderNum = 0 ;
        strncpy(pOrdModConfTMRsp->sAccCode,pDrvNNFTM->sAccCode,ACCOUNT_CODE_LEN);
        pOrdModConfTMRsp->iBookType = pDrvNNFTM->iBookType ;
        pOrdModConfTMRsp->iBuyOrSell = pDrvNNFTM->iBuyOrSell ;
        pOrdModConfTMRsp->iDiscQty = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iDiscQtyRemaining = pDrvNNFTM->iDiscQty ;
        pOrdModConfTMRsp->iTotalQtyRemaining = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iTotalQty = pDrvNNFTM->iTotalQty ;
        pOrdModConfTMRsp->iQtyFilledToday = 0 ;
        pOrdModConfTMRsp->iPrice = pDrvNNFTM->iPrice ;
	pOrdModConfTMRsp->iEntryTime= pDrvNNFTM->iEntryTime;
	pOrdModConfTMRsp->iLastModifiedTime= pDrvNNFTM->iLastModifiedTime;
        pOrdModConfTMRsp->iGoodTillDate = pDrvNNFTM->iGoodTillDate ;
	pOrdModConfTMRsp->pOrderTerms.ATO = pDrvNNFTM->pOrderTerms.ATO ;
        pOrdModConfTMRsp->pOrderTerms.Market = pDrvNNFTM->pOrderTerms.Market ;
        pOrdModConfTMRsp->pOrderTerms.StopLossTerm = pDrvNNFTM->pOrderTerms.StopLossTerm ;
        pOrdModConfTMRsp->pOrderTerms.DayTerm = pDrvNNFTM->pOrderTerms.DayTerm ;
        pOrdModConfTMRsp->pOrderTerms.GTCTerm = pDrvNNFTM->pOrderTerms.GTCTerm ;
        pOrdModConfTMRsp->pOrderTerms.IOCTerm = pDrvNNFTM->pOrderTerms.IOCTerm ;
        pOrdModConfTMRsp->pOrderTerms.AONTerm = pDrvNNFTM->pOrderTerms.AONTerm ;
        pOrdModConfTMRsp->pOrderTerms.MFTerm = pDrvNNFTM->pOrderTerms.MFTerm ;
        pOrdModConfTMRsp->pOrderTerms.MatchedInd = pDrvNNFTM->pOrderTerms.MatchedInd ;
        pOrdModConfTMRsp->pOrderTerms.Traded = pDrvNNFTM->pOrderTerms.Traded ;
        pOrdModConfTMRsp->pOrderTerms.Modified = pDrvNNFTM->pOrderTerms.Modified ;
        pOrdModConfTMRsp->pOrderTerms.Frozen = pDrvNNFTM->pOrderTerms.Frozen ;
        pOrdModConfTMRsp->iBranchId = pDrvNNFTM->iBranchId ;
        pOrdModConfTMRsp->iExcgUserId = pDrvNNFTM->iExcgUserId ;
        strncpy(pOrdModConfTMRsp->sBrokerCode,pDrvNNFTM->sBrokerCode,BROKER_CODE_LENGTH);
        pOrdModConfTMRsp->cSecSuspInd= 'C';
        pOrdModConfTMRsp->cSecSuspInd = pDrvNNFTM->cSecSuspInd ;
        strncpy(pOrdModConfTMRsp->sSettlor,pDrvNNFTM->sSettlor,NNF_SETTLOR_LEN);
        pOrdModConfTMRsp->iProCli = pDrvNNFTM->iProCli ;
        pOrdModConfTMRsp->fUserInfo = pDrvNNFTM->fUserInfo ;
        pOrdModConfTMRsp->sExchRsrvdFlds=pDrvNNFTM->sExchRsrvdFlds ;
        strncpy(pOrdModConfTMRsp->sPanId,pDrvNNFTM->sPanId,NNF_PAN_NUM_LEN);
        pOrdModConfTMRsp->iAlgoId = pDrvNNFTM->iAlgoId ;
        pOrdModConfTMRsp->iReservedFill = pDrvNNFTM->iReservdFiller1;
        pOrdModConfTMRsp->iLastActiRef= 0;

        logDebug2(" Before twiddle pOrdModConfTMRsp->iTransCode :%d:",pOrdModConfTMRsp->iTransCode);
//        TWIDDLE(pOrdModConfTMRsp->iTransCode);
        TWIDDLE(pOrdModConfTMRsp->iErrorCode);
        TWIDDLE(pOrdModConfTMRsp->iReasonCode);
        TWIDDLE(pOrdModConfTMRsp->pSecInfo.iExpiryDate);
        TWIDDLE(pOrdModConfTMRsp->pSecInfo.iStrikePrice);
        TWIDDLE(pOrdModConfTMRsp->iBookType);
        TWIDDLE(pOrdModConfTMRsp->iBuyOrSell);
        TWIDDLE(pOrdModConfTMRsp->iDiscQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQty);
        TWIDDLE(pOrdModConfTMRsp->iTotalQtyRemaining);
        TWIDDLE(pOrdModConfTMRsp->iPrice);
        TWIDDLE(pOrdModConfTMRsp->iGoodTillDate);
        TWIDDLE(pOrdModConfTMRsp->iBranchId);
        TWIDDLE(pOrdModConfTMRsp->iExcgUserId);
        TWIDDLE(pOrdModConfTMRsp->iProCli);
        TWIDDLE(pOrdModConfTMRsp->fUserInfo);
	TWIDDLE(pOrdModConfTMRsp->iAlgoId);
	TWIDDLE(pOrdModConfTMRsp->iEntryTime);
	TWIDDLE(pOrdModConfTMRsp->iLastModifiedTime);
        logInfo("********************* After Twiddle Printfing All Exchange Parameter*********************");
        logDebug3("iTransCode   :%d:",pOrdModConfTMRsp->iTransCode);
        logDebug3("iTokenNo     :%d:",pOrdModConfTMRsp->iTokenNo);
        logDebug3("sInstrumentName      :%s:",pOrdModConfTMRsp->pSecInfo.sInstrumentName);
        logDebug3("iExpiryDate  :%d:",pOrdModConfTMRsp->pSecInfo.iExpiryDate);
        logDebug3("iStrikePrice :%d:",pOrdModConfTMRsp->pSecInfo.iStrikePrice);
        logDebug3("sOptionType  :%s:",pOrdModConfTMRsp->pSecInfo.sOptionType);
        logDebug3("sAccCode     :%s:",pOrdModConfTMRsp->sAccCode);
        logDebug3("iBookType    :%d:",pOrdModConfTMRsp->iBookType);
        logDebug3("iBuyOrSell   :%d:",pOrdModConfTMRsp->iBuyOrSell);
        logDebug3("iDiscQty     :%d:",pOrdModConfTMRsp->iDiscQty);
        logDebug3("iTotalQty    :%d:",pOrdModConfTMRsp->iTotalQty);
        logDebug3("iPrice       :%d:",pOrdModConfTMRsp->iPrice);
        logDebug3("iGoodTillDate        :%d:",pOrdModConfTMRsp->iGoodTillDate);
        logDebug3("iBranchId    :%d:",pOrdModConfTMRsp->iBranchId);
        logDebug3("iExcgUserId  :%d:",pOrdModConfTMRsp->iExcgUserId);
        logDebug3("sBrokerCode  :%s:",pOrdModConfTMRsp->sBrokerCode);
        logDebug3("cSecSuspInd  :%c:",pOrdModConfTMRsp->cSecSuspInd);
        logDebug3("sSettlor     :%s:",pOrdModConfTMRsp->sSettlor);
        logDebug3("iProCli      :%d:",pOrdModConfTMRsp->iProCli);
        logDebug3("fUserInfo    :%lf:",pOrdModConfTMRsp->fUserInfo);
        logDebug3("sPanId       :%s:",pOrdModConfTMRsp->sPanId);
        logDebug3("iAlgoId      :%d:",pOrdModConfTMRsp->iAlgoId);
        logDebug3("iReservdFiller1 :%d:",pOrdModConfTMRsp->iReservedFill);
        logDebug3("MFTerm       :%d:",pOrdModConfTMRsp->pOrderTerms.MFTerm);
        logDebug3("AONTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.AONTerm);
        logDebug3("IOCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.IOCTerm);
        logDebug3("GTCTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.GTCTerm);
        logDebug3("DayTerm      :%d:",pOrdModConfTMRsp->pOrderTerms.DayTerm);
        logDebug3("StopLossTerm :%d:",pOrdModConfTMRsp->pOrderTerms.StopLossTerm);
        logDebug3("Market       :%d:",pOrdModConfTMRsp->pOrderTerms.Market);
        logDebug3("ATO          :%d:",pOrdModConfTMRsp->pOrderTerms.ATO);
        logDebug3("Frozen       :%d:",pOrdModConfTMRsp->pOrderTerms.Frozen);
        logDebug3("Modified     :%d:",pOrdModConfTMRsp->pOrderTerms.Modified);
        logDebug3("Traded       :%d:",pOrdModConfTMRsp->pOrderTerms.Traded);
        logDebug3("MatchedInd   :%d:",pOrdModConfTMRsp->pOrderTerms.MatchedInd);
	logDebug3("iEntryTime   :%d:",pOrdModConfTMRsp->iEntryTime);
	logDebug3("iLastModifiedTime :%d:",pOrdModConfTMRsp->iLastModifiedTime);

        memcpy(pOrdModTMRsp ,( CHAR *) pOrdModConfTMRsp,sizeof(struct NNF_ORD_RESPONSE_TM));
        logTimestamp("Exit fNseCMOrdCanErrResp"); 
}

BOOL    fDMASendsysinfo(CHAR *NNF ,LONG32 iGroupid)
{
        logTimestamp("Entry : fDMASendsysinfo");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        CHAR    sQuery [MAX_QUERY_SIZE];
        memset(sQuery,'\0',MAX_QUERY_SIZE);
        struct  NNF_SYS_INFO_REQ        *pSys;
        pSys = (struct NNF_SYS_INFO_REQ *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
        memset((CHAR *)pSys,' ',sizeof(struct NNF_SYS_INFO_REQ));

        sprintf(sQuery,"SELECT EAM_EXCH_USER_ID FROM EXCH_ADMINISTRATION_MASTER \
                        WHERE EAM_GROUP_ID=%d  AND EAM_EXM_EXCH_ID = \"%s\" AND EAM_SEGMENT=\'%c\'; ",iGroupid,NSE_EXCH,CURRENCY_SEGMENT);

        logDebug2("sQuery :%s:",sQuery);
        if (mysql_query(DBConDrvNNF, sQuery) != SUCCESS)
        {
                sql_Error(DBConDrvNNF);
                return ERROR;
        }

        Res = mysql_store_result(DBConDrvNNF);
        if((Row = mysql_fetch_row(Res)))
        {

                pSys->sHeader.iMsgCode          = TC_NSE_SYS_INFO_REQ;
                pSys->sHeader.iLogTimeStamp     = 0 ;
                memcpy(pSys->sHeader.sAlphaSplit,"NT",2);
                pSys->sHeader.iTraderID         = atoi(Row[0]);
                pSys->sHeader.iErrorCode        = 0 ;
                memset(pSys->sHeader.sTimeStamp1,' ',NNF_DATE_TIME_LEN);
                memset(pSys->sHeader.sTimeStamp2,' ',NNF_DATE_TIME_LEN);
                memset(pSys->sHeader.sTimeStamp3,' ',NNF_DATE_TIME_LEN);
                pSys->sHeader.sTimeStamp2[0]    = '0';
                pSys->sHeader.iMsgLength        = sizeof(struct NNF_SYS_INFO_REQ) ;
                pSys->LastUpdateTimePortfolio   = 0;
        }
        mysql_free_result(Res);


#ifdef     DBG
        logDebug3("proc_progN.pc : sendSysinfo : THIS IS THE SYS INFO DOWNLOAD PROCESS ***");
        logDebug3("sendSysinfo: The transcode is %d ",pSys->sHeader.iMsgCode);
	logDebug3("sendSysinfo: The Msglength is %d ",pSys->sHeader.iMsgLength);
        #endif
        TWIDDLE(pSys->sHeader.iLogTimeStamp);
        TWIDDLE(pSys->sHeader.iMsgCode);
        TWIDDLE(pSys->sHeader.iErrorCode);
        TWIDDLE(pSys->sHeader.iTraderID);
        /*    TWIDDLE(pSys->sHeader.iMsgLength);        */
        TWIDDLE(pSys->LastUpdateTimePortfolio);
        memcpy(NNF,pSys,sizeof(struct NNF_SYS_INFO_REQ));
        free(pSys);
        logDebug3("########################### Exit sendSysinfo ###########################");

        logTimestamp("Exit : fDMASendsysinfo");
        return TRUE;

}
	
