//#include "md5.h"
#include "IPCS.h"
//#include "NNFDrvStruct.h"
#include "NNFCurrStruct.h"
#include <memory.h>
#include <time.h>
#include <netinet/tcp.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

void	fUpdateTimeStamp(struct  NNF_DOUBLE_INT                  *pTempTimeStamp,CHAR cStreamNum); 
void 	fExit(LONG32);
//BOOL fUpdateConnectStatus(SHORT,LONG32);
void 	fConvertSeqNO(CHAR *, CHAR *); 

void	fInitSharedMemory(LONG32);

//key_t	GlobQueueId;
LONG32 	iSockfd1;
LONG32  iGrSockFd;
LONG32 	iGlobGroupId;
SHORT 	iConnectionCounter = 0 ;
SHORT 	iCounterTotalInvite = 0 ;
CHAR 	sProgTime[40];
//LONG32   TMPSEQ = 2;
CHAR    cMulticastFlg = 'B'; 
//CHAR     exchange[EXCHANGE_LEN] = "NSE   "; 
MYSQL 	*DBConDrvNNF;
SHORT 	iTotalStream = 0;  
LONG32 	iTransmitSeq =0, iRecieveSeq =0 ; 
CHAR    sProgName[15] = "NseFOConnect";
CHAR	sKey[DB_KEY_LEN];
LONG32 	iConnectToExchange =1;
LONG32 	iSleepTime=0;
LONG32  iBusyTimer = 0;
LONG32  iJiffyTime = 0;

CHAR    sPrimTAPip[CALLING_LENS];
CHAR    sSecoTAPip[CALLING_LENS];
LONG32  iPrimTAPport;
LONG32  iSecoTAPport;
CHAR    sSessionKey[NNF_SESSION_KEY_LEN];
LONG32  iTmpTradeId = 0;


main( LONG32 argc, CHAR **argv )
{
	logTimestamp("Entry : [main]");

	LONG32	iRespchild,iTranschild,iInvitationchild,iStatus,iTranskill = -1,iHeartBeats;
	LONG32 	iSig1 = 0,iSig2 = 0; 
	LONG32 	iMainwait = -1;
	//	LONG32 	no_of_calladdresses ,count_call_addr , argument_pos;
	LONG32 	iGroupid;
	LONG32	iTapPort;    	
	LONG32 	iNSE_CONNECTED_STATUS = FALSE;
	//	CHAR 	calladdress[10][CALLING_LENS];
	//	CHAR 	calldata[CALLING_LENS];
	LONG32 	iPrimarySecondary = 0;
	CHAR 	*sError;
	CHAR 	sTapIp[2][CALLING_LENS];
	CHAR 	sConnectOption[5];   
	sigset_t SequenceSet;  		
	//	LONG32 	MaxPacketCount,iInvFlag = FALSE;  
	LONG32 	iFlag;
	LONG32 	iInvPacketCount;
	//	LONG32 	iDSeq_No = 0;
	memset(sPrimTAPip,'\0',CALLING_LENS);
        memset(sSecoTAPip,'\0',CALLING_LENS);
	memset(sSessionKey,'\0',NNF_SESSION_KEY_LEN);
	

	/*****
	  EXEC SQL BEGIN DECLARE SECTION;  
	  VARCHAR lvar_uid[30];
	  LONG32 seqval;
	  VARCHAR RetCode[50];
	  VARCHAR RetString[50];
	  VARCHAR exchId[EXCHANGE_LEN];
	  CHAR    drvFlg = 'Y';
	  EXEC SQL END DECLARE SECTION;  
	 ****/
	CHAR    sBusyTimer[10];
	CHAR    sJiffyTime[10];

	setbuf (stdout,NULL);
	setbuf (stderr,NULL);
	setvbuf(stdout,NULL,_IONBF,0);  	

	//    VMEMCPY(exchId,exchange,EXCHANGE_LEN);
	memset(sBusyTimer,'\0',10);
	memset(sJiffyTime,'\0',10);
	memset(sKey,'\0',DB_KEY_LEN);
	sError = (CHAR *)malloc(sizeof(CHAR)*SIZE);
	if ( argc < 8 )
	{
		fGetTime(sProgTime);

		logDebug2("[%s] IST Wrong number of Parameters Passed",sProgTime);
		exit(ERROR);			
	}

	logDebug2(" Before ConnectOption");
	strcpy(sConnectOption,argv[1]);
	iGroupid = atoi(argv[2]);

	strcpy(sPrimTAPip,argv[3]);
        iPrimTAPport = atoi ( argv[4]);
        strcpy(sSecoTAPip,argv[5]);
        iSecoTAPport = atoi ( argv[6]);

/**
	strcpy(sTapIp[0],argv[3]);
	iTapPort = atoi ( argv[4]);	

	strcpy(sTapIp[1],argv[5]);
***/
	//cMulticastFlg = argv[7][0]; 
	memset(sProgTime,'\0',40);
	logDebug2(" Before ProgTime");
	iSleepTime = atoi(argv[7]);

	if(getenv("NCD_SLEEP_TIME") == NULL)
        {
                logInfo("NCD_SLEEP_TIME not Define in ENV");
                iBusyTimer = 40000;
        }
        else
        {
                strncpy(sBusyTimer,getenv("NCD_SLEEP_TIME"),10);
                if(strlen(sBusyTimer) == 0)
                {
                        logInfo("NCD_SLEEP_TIME Define with srlen zero");
                        iBusyTimer = 40000;
                }
                else
                {
                        logInfo("NCD_SLEEP_TIME Define with value :%s:",sBusyTimer);
                        iBusyTimer = atoi(sBusyTimer);
                }
        }

	if(getenv("NCUR_JIFFIES_TIMEIN_MIN") == NULL)
        {
                logInfo("NCUR_JIFFIES_TIMEIN_MIN not Define in ENV default taking as a 5 min Prior download of orders from exchange");
                iJiffyTime = 5*60*65536 ;
		logTimestamp(":%s: TAKING 5 MIN PRIOR DOWNLOAD OF ORDERS FROM EXCHANGE",KEY_WORD_MONITORING);
        }
        else
        {
                strncpy(sJiffyTime,getenv("NCUR_JIFFIES_TIMEIN_MIN"),10);
                if(strlen(sJiffyTime) == 0)
                {
                        logInfo("NCUR_JIFFIES_TIMEIN_MIN Define with srlen zero");
                        iJiffyTime = 5*60*65536;
                }
                else
                {
                        logInfo("NCUR_JIFFIES_TIMEIN_MIN Define with value :%s:",sJiffyTime);
                        iJiffyTime = atoi(sJiffyTime)*60*65536;
			logTimestamp(":%s: TAKING %s MIN PRIOR DOWNLOAD OF ORDERS FROM EXCHANGE",KEY_WORD_MONITORING,sJiffyTime);

                }
        }
        logDebug3("iJiffyTime :%d:",iJiffyTime);


/***
	if(strncmp(sConnectOption,"EXCH", 4 )==0)
	{
		iConnectToExchange = 1;
	}
	else
	{
		iConnectToExchange = 0;
	}
****/
	iGlobGroupId = iGroupid ;

	/**if (( iGroupid <= 0 ) || (iGroupid > 4))
	{
		logDebug2("EquNseConnect.pc Wrong groupid ");
		exit(ERROR);
	}**/

	DBConDrvNNF = DB_Connect();

	logDebug2("PROGRAM CNseConAdap");
	logDebug2("******************************************************");

	fGetTime(sProgTime);

	logDebug2("ProgTime [%s]",sProgTime);
	logDebug2("------------------- PARAMETERS PASSED -------------------");
	logDebug2("ConnectOption  : [%s]", sConnectOption ) ;
	logDebug2("groupid is     : [%d] ",iGroupid);
	logDebug2("TapIp Primary  : [%s]", sPrimTAPip ) ;
	logDebug2("TapIp Failover : [%s]", sSecoTAPip ) ;
	logDebug2("TapPort        : [%d]", iPrimTAPport) ;
	logDebug2("TapPort FailOver:[%d]", iSecoTAPport) ;
	logDebug2("iSleepTime	  : [%d]", iSleepTime) ;
	logDebug2("---------------------------------------------------------");

	strcpy(sKey,getenv("DB_AES_KEYS"));
	/************
	  switch(iGroupid)
	  {
	  case 1 : GlobQueueId = DrvRmsnseToNse1;          
	  break;
	  case 2 : GlobQueueId = DrvRmsnseToNse2;          
	  break;
	  case 3 : GlobQueueId = DrvRmsnseToNse3;          
	  break;
	  case 4 : GlobQueueId = DrvRmsnseToNse4;          
	  break;
	  default : break;
	  };
	 ***********/	

	//GlobQueueId = MapperToConnNSEFO;
	/******	
	  logDebug2("\nDrvNseConnect: Selected Queue depending on GroupId");
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=strlen(lvar_uid.arr);
	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  logDebug2 ("\nEquNseConnect.pc Error in connecting to oracle %d",sqlca.sqlcode);
	  exit(ERROR);
	  }
#ifdef DBG
fGetTime(sProgTime);
logDebug2("\n[%s] IST Connecting to DataBase....",sProgTime);
logDebug2("\nDrvNseConnect.pc Connecting to database.......");
#endif
	 ****/
	for ( ; ; )								
	{
		iNSE_CONNECTED_STATUS = FALSE;
		signal(SIGPIPE,SIG_IGN);
		signal(SIGHUP,SIG_IGN);

		logDebug2("TAP PORT is [%d]", iTapPort);

		/*** Loop around Infinitely till u get a connection ***/
		for ( ; ; )
		{
			fInitSharedMemory(iGroupid);

			logDebug2(" Before Connect ");
			/*** iSockfd1 =CONNECT(TapPort, sTapIp[PrimarySecondary]);****/
			//iSockfd1 = fTcpConnect(iTapPort, sTapIp[iPrimarySecondary]);
			iSockfd1 = fTcpConnect(iPrimarySecondary);
			logDebug2("sockfd1  : [%d]",iSockfd1);
			if (iSockfd1 <= 0 ) 
			{
				iNSE_CONNECTED_STATUS = FALSE;
				memset(sError,NULL,SIZE);
				strcpy(sError,"FATAL ERROR .... NO SOCKET CONNECTION .... ");
				logFatal("EquNseConnect.pc %s",sError);

				fSend_exch_down_nse( iGroupid );

				sleep(5);
				iPrimarySecondary=(iPrimarySecondary==1)?0:1;
			}
			else
			{
				iFlag=102400;
				iNSE_CONNECTED_STATUS = TRUE;

				if (setsockopt( iSockfd1 ,SOL_SOCKET,SO_RCVBUF,(CHAR *)&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:SO_RCVBUF");
					return FALSE;
				}
				if (setsockopt( iSockfd1 ,SOL_SOCKET,SO_SNDBUF,(CHAR *)&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:SO_SNDBUF");
					return FALSE;
				}
				if (setsockopt( iSockfd1 ,IPPROTO_TCP, TCP_NODELAY,(CHAR *)&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:TCP_NODELAY");
					return FALSE;
				}

				/*** Commented TAP Reg Changes ***/
				/**logDebug2("\n  Storing Timestamp Before ...Connect...."); ** Added to send correct timestamp **
				  if(GetEAMTimeStamp(iGroupid)==TRUE)
				  {
				  logDebug2("\n Return Success....GetEAMTimeStamp....");
				  logDebug2("\n TimeStamp............");
				  logDebug2("\n EAM_TimeStamp.TimeStamp....%u",EAM_TimeStamp.TimeStamp);
				  logDebug2("\n EAM_TimeStamp.TimeStamp1....%u",EAM_TimeStamp.TimeStamp1);
				  }**/

				/*** TAP Reg Changes ***/
				iTransmitSeq =0; 
				logDebug2("Sequence Number Transmit is [%d]", iTransmitSeq);
				/*** TAP Reg Changes ***/
				
				//fReqForDCconnection(iGroupid);
				if(fReqForDCconnection(iGroupid,iPrimarySecondary) == FALSE)
                                {
                                        logInfo("Now Trying with %s BOX  ",(iPrimarySecondary==1)?"Primary":"Secondary");
                                        iPrimarySecondary=(iPrimarySecondary==1)?0:1;
                                        sleep(3);
                                        continue;
                                }
	
				if( ( iHeartBeats = fork() ) == 0 )
                                {
                                        iHeartBeats = getpid();
                                        logDebug2("iHeartBeats PID :%d:",iHeartBeats);
                                        logDebug2("Before Receive Packet at [%s] IST",sProgTime);
                                        fHeartBeatsReqPack();
                                        logInfo("Got return from Heart Beats");
                                        fConnectUpdt(NSE_CUR_DOWN, iGlobGroupId,0);
                                        return FALSE;

                                }


				if (fHandleSignon(iGroupid) == TRUE)
				{    
					if(strcmp(sConnectOption,"DMA" )==0)
					{
						fHandleSignon(2);
						fDMASendSysInfo(2);	
					}
					logDebug2("$$$$$$$$$$$$$$$$$$ HandleSignon Returned True $$$$$$$$$$$$$$$$$$");
					if ( (iRespchild = fork()) == 0 )
					{
						logDebug2("[%s] IST Before Receive Packet",sProgTime);	
						iRespchild = getpid();
						logDebug2("respchild :%d:"),iRespchild;

						fReceiveReplyPackets(iSockfd1,iGroupid);

					}
					else  if( ( iTranschild = fork() ) == 0 )
					{					
						logDebug2("[%s] IST Before Transmit Packet",sProgTime);
						iTranschild = getpid();
						logDebug2("Transchild :%d:"),iTranschild;

						fTransmitRequestPackets(iGroupid);

					}
					break;/*** break infinite for loop if signon true ***/

				} 
				else
				{
					close(iSockfd1);/*Added  for close socket fd if signon failed*/
					logDebug2("Reconnect Attempt---------------[%d]",iConnectionCounter); 

					fGetTime(sProgTime); 

					logDebug2("The Process Ended at [%s] IST",sProgTime); 
					if( iConnectionCounter ==  2 )
					{
						iConnectionCounter = 0;	
						iPrimarySecondary=(iPrimarySecondary==1)?0:1;
						sleep(10);  		
					}	
					sleep(15);
				}    
			} /**end of else **/
		} /** end of inner for loop **/

		sleep(1);/***THIS IS FOR ONE TIME RUN ON SUCCESS***/
		while( TRUE )
		{
			iTranskill = -1;
			iSig1 = 0;
			sigemptyset(&SequenceSet );
			sigaddset(&SequenceSet , SIGTERM);
			sigaddset(&SequenceSet , SIGIO);
			sigaddset(&SequenceSet , SIGUSR1);
			sigaddset(&SequenceSet , SIGUSR2);
			sigprocmask(SIG_BLOCK  , &SequenceSet, NULL);

			logDebug2("Waiting for signal, in loop.");
			iMainwait = sigwait( &SequenceSet, &iSig1);
			logDebug2("Recv Signal : %d, sig1:%d", iMainwait , iSig1 );

			if (iMainwait >= 0 && ( iSig1 == SIGUSR1 || iSig1 == SIGUSR2 ))
			{
				logDebug2("Got mainwait >= 0, sig1: %d Transchild :%d:", iSig1 ,iTranschild);

				iTranskill = kill(iTranschild,iSig1);

				logDebug2("Return value from KILL : %d", iTranskill );
				perror( "After kill to Transchild: ");

				if (iTranskill < 0)
				{
					logDebug2("CNseConAdap Fatal Error in sending signal %d",iTranskill);
					memset(sError,NULL,SIZE);
					strcpy(sError,strerror(errno));
					logFatal("CNseConAdap %s",sError);
					exit(ERROR);
				}
			}	
			else if ( iSig1 == SIGTERM || iSig1 == SIGIO )	
			{
				if(iSig1 == SIGTERM)
					logDebug2(" SIGTERM signal received");
				else
					logDebug2(" SIGIO signal received");

				sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
				logDebug2(" starting fall over mechanism ");
				logDebug2("  the group id is [%d] ", iGroupid );/*****
										  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
										  SET  EAM_LOGON_STATUS = 'N'
										  WHERE EAM_EXM_EXCH_ID = ltrim(rtrim(:exchId))
										  AND EAM_DRV_FLAG = :drvFlg
										  AND EAM_GROUP_ID = to_char(:iGroupid);

										  logDebug2("nError in Updating: %d", sqlca.sqlcode );
										  EXEC SQL COMMIT;
										 *****/
				//				fUpdateConnectStatus(NSE_CUR_DOWN, iGroupid );
				fConnectUpdt(NSE_CUR_DOWN, iGroupid,0 );

				fSend_exch_down_nse( iGroupid );

				logDebug2("Databse and shared memory updated and broadcast sent ");
				kill(iTranschild,SIGKILL);
				kill(iRespchild,SIGKILL);
				sleep(3);
				waitpid(iTranschild,&iStatus,WNOHANG);
				waitpid(iRespchild,&iStatus,WNOHANG);
				close(iSockfd1);
				exit(ERROR);
				//break;
			}
			else if(iSig1 == SIGCHLD)
			{
				logDebug2(" Killing Children ");
				kill(iTranschild,SIGKILL); 
				kill(iRespchild,SIGKILL);
				exit(ERROR);
			}
			else
			{
				logDebug2(" Alok and nitish testing ");
				kill(iTranschild,SIGKILL);
				kill(iRespchild,SIGKILL);
				exit(ERROR);
			}

		}	
	}/*** Infinite Main For Loop ***/
	logTimestamp("Exit : [main]");

}	/*** End of main function .... checked as of 15-4-2000 ***/


BOOL	fHandleSignon(LONG32 iGroupid)
{
	logTimestamp("Entry : fHandleSignon ");

	memset(sProgTime,'\0',40);
	fGetTime(sProgTime);
	logDebug2("[%s] IST HANDLE SIGN ON Called",sProgTime);

	CHAR	*cSendsign;
	CHAR  	sRecvsign[NSE_PACKET_SIZE];
	LONG32 	iSent_bytes,iRecv_bytes,iLog_result;
	struct  NNF_HEADER	*pHeader;
	struct	NNF_SIGNON_REQ	*pSIGNON_REQ;

	//	unsigned char	digest[16];
	UCHAR	sDigest[16];  
	struct 	TAP_WRAPPER 	*pTap_wrap;
	LONG32	iTemp_code,iTemp_size,iInvFlag;
	CHAR 	sError[SIZE];
	LONG32 	iSig1 = 0;
	LONG32 	iInvPacketCount;
	LONG32 	iInv_flag = FALSE;
	LONG32 	iSeq_No;
	CHAR 	*cBdata;
	LONG32 	iBlen;
	LONG32	iErrMsgCode = 0 ;
	LONG32	iUserID = 0;
	//   	SHORT 	InvCount;
	struct 	DRVInvitationCount	*pInvcount;
	CHAR 	*cSendsignTAP;
	/*****
	  EXEC SQL BEGIN DECLARE SECTION;
	  varchar lvar_uid[30];
	  VARCHAR sConErrMsg[128];
	  INT16   iErriMsgCode;
	  EXEC SQL END DECLARE SECTION;
	  memset(sConErrMsg.arr,'\0',128) ;
	  sConErrMsg.len=128;
	 ****/
	INT16 	iErriMsgCode;
	CHAR    sErrorStr[DB_REASON_DESC_LEN];
        memset(sErrorStr,'\0',DB_REASON_DESC_LEN);
	sigset_t SequenceSet;
	sigemptyset( &SequenceSet );
	sigaddset( &SequenceSet , SIGUSR1);
	sigaddset( &SequenceSet , SIGUSR2);                /* Signal function Initialization */
	sigprocmask( SIG_BLOCK, &SequenceSet, NULL);

	cSendsign =(CHAR *)malloc(sizeof(struct NNF_SIGNON_REQ));
	pTap_wrap =(struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
	memset(pTap_wrap,'\0',sizeof(struct TAP_WRAPPER));
	pHeader =(struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
	memset(pHeader,'\0',sizeof(struct NNF_HEADER));
	pSIGNON_REQ = (struct NNF_SIGNON_REQ *)malloc(sizeof(struct NNF_SIGNON_REQ ));
	memset(pSIGNON_REQ,'\0',sizeof(struct NNF_SIGNON_REQ));

	logDebug2("AFTER MEMSETTING");
	cSendsignTAP = (CHAR *)malloc(sizeof(struct NNF_SIGNON_REQ) + sizeof(struct TAP_WRAPPER));

	fGetTime(sProgTime);

	logDebug2("Before Calling ReceiveInvitationPacket at [%s] IST",sProgTime);

	/*****
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=sizeof(lvar_uid.arr);


	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  memset(sError,NULL,SIZE);
	  sprintf(sError,"EquNseConAdapter.pc Error in connecting to oracle ");
	  logFatal(&sProgName,sError);
	  exit(ERROR);
	  }****/
	logInfo("TRANSMIT CHILD Connction to Oracle SUCCESS......      ");


	if( !(fHandleInvitationPacket(iSockfd1,iGroupid))  )
	{
		iConnectionCounter++;
		logDebug2("Received <=0 byte:closing TAP BOX Connection..");
		free(cSendsign);
		free(pTap_wrap);
		free(pHeader);
		free(pSIGNON_REQ);
		free(cSendsignTAP);
		return FALSE;
	}

	iLog_result = fSendsignon(cSendsign,iGroupid);
	if( iLog_result == TRUE )
	{
		memcpy(pHeader,cSendsign,sizeof(struct NNF_HEADER));
		memcpy(pSIGNON_REQ,cSendsign,sizeof(struct NNF_SIGNON_REQ));
		logDebug2("UserId = %d",pSIGNON_REQ->iUserId);
		logDebug2("Password = %s",pSIGNON_REQ->sPassword);
		logDebug2("BrokerCode = %s",pSIGNON_REQ->sBrokerCode);
		logDebug2("VersionNumber = %d",pSIGNON_REQ->iVersionNumber);	
		logDebug2("iMsgCode = [%d]",pSIGNON_REQ->sHeader.iMsgCode);
		TWIDDLE(pHeader->iMsgLength);
		iTemp_size = pHeader->iMsgLength;
		iTemp_code = pHeader->iMsgCode;
		logDebug2(" pHeader->iMsgCode  : %d",pHeader->iMsgCode   );
		logDebug2(" Temp_code        : %d",iTemp_code         );
		logDebug2(" pHeader->iMsgLength : %d ", pHeader->iMsgLength )  ;
		logDebug2(" BEFORE SEND Temp_size : %d",iTemp_size )  ;

		fMD5_Digest(sDigest,cSendsign,iTemp_size )  ;

		iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);

		iTransmitSeq ++;
		pTap_wrap->Seq_No = iTransmitSeq ;

		memcpy(pTap_wrap->digest,sDigest,16);
		pTap_wrap->Message_Len = iTemp_size ; /* Changed here */
		TWIDDLE(pTap_wrap->Seq_No);
		TWIDDLE(pTap_wrap->Message_Len);
		logDebug2(" Message_Len = [%d] and Seq_No = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
		logDebug2("Twiddled Message_Len = [%d] and Twiddled Seq_No = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
		memcpy(cSendsignTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
		memcpy(cSendsignTAP + sizeof(struct TAP_WRAPPER),cSendsign ,sizeof(struct NNF_SIGNON_REQ));

		iSent_bytes = SEND(iSockfd1,cSendsignTAP,iTemp_size);

		logDebug2("Sent_bytes = [%d]",iSent_bytes);
		logDebug2("SIGNON REQUEST SENT TO EXCHANGE");
		// Printing for monitoring purpose @NItish
		logTimestamp(":%s: SIGNON REQUEST SENT TO EXCHANGE",KEY_WORD_MONITORING);
		logDebug2("groupid = [%d]",iGroupid);

		fReduceInvitationCount(iGroupid);

		logDebug2(" SIGN ON REQUEST Sent to exchange ....[%d]  ",iSent_bytes);
	}
	else
	{
		logDebug2("CNseConAdap Database Error :: cannot execute the select statement ");
	}

	/*------------------------------recv signon response-----------------------------------*/

	logDebug2("WAITING TO RECEIVE " ) ;
/****

	fGetInvitationPacketCount(&iInvPacketCount,iGroupid);

	logDebug2("HandleSignon :: InvPacketCount = [%d]",iInvPacketCount);
	if(iInvPacketCount == 0)
	{
		iRecv_bytes = RECV_INV(iSockfd1,sRecvsign,&iInv_flag);
		logDebug2("Inv_flag [%d]",iInv_flag);
		if( iRecv_bytes <= 0)
		{
			iConnectionCounter++;
			logDebug2("Received <=0 byted:closing TAP BOX Connection..");
			return FALSE;
		}
		if(iInv_flag == TRUE)
		{
			if(  !(fHandleInvitationPacket(iSockfd1,iGroupid))  )
			{
				iConnectionCounter++;
				logDebug2("Received <=0 byted:closing TAP BOX Connection..");
				return FALSE;
			}
		}
	}
***/
	iRecv_bytes = RECV(iSockfd1,sRecvsign);
	if( iRecv_bytes <= 0)
	{
		iConnectionCounter++;
		logDebug2("Received <=0 byted:closing TAP BOX Connection..");
		close(iSockfd1);
		return FALSE;
	}	

	memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);
	iBlen = pHeader->iMsgLength ;
	cBdata = (CHAR *)malloc(iBlen);
	memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER) ,iBlen);

	/**    	if (get_mesg_or_sError_nse(cBdata) == TRUE )
	  {
	  free(cSendsign);
	  return(FALSE);
	  }   **/  

	memcpy(pTap_wrap,sRecvsign,sizeof(struct TAP_WRAPPER));
	TWIDDLE(pTap_wrap->Seq_No);
	logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
	logDebug2("Received Seq_No = [%d]",pTap_wrap->Seq_No);

	/*** TAP Reg Changes ***/
	iSeq_No = 0;
	iRecieveSeq++;
	iSeq_No = iRecieveSeq ;
	/*** TAP Reg Changes ***/

	logDebug2("After Received Signon Packet Receive Seq No =[%d]",iSeq_No); 
/****
	if(iSeq_No != pTap_wrap->Seq_No)
	{
		logDebug2("FATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection..");

		memset(sError,NULL,SIZE);
		strcpy(sError,"ERROR::sequence no mismatch ");
		logFatal("EquNseConTAP.pc %s",sError);
		iSeq_No	= pTap_wrap->Seq_No; 
		iRecieveSeq = pTap_wrap->Seq_No; 

	}
****/
	logDebug2("Passed Seq No Check...");
	memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);
	iBlen = pHeader->iMsgLength ;
	cBdata = (CHAR *)malloc(iBlen);

	memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER) ,iBlen);
	logDebug2("Computing the digest ...");

	fMD5_Digest(sDigest,cBdata,iBlen)  ;

	logDebug2("Blen :%d:  digest :%s:  bdate :%s:", iBlen, sDigest, cBdata);

	if(strncmp(sDigest,pTap_wrap->digest,16) !=0)
	{
		logDebug2("FATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection..");
		memset(sError,NULL,SIZE);
		strcpy(sError,"ERROR::Mismatch in MD5 Checksum ");
		logFatal("EquNseConTAP.pc %s",sError);
		fExit(ERROR);
	}

	logDebug2("Passed MD5 Checksum Check...");

	memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
	TWIDDLE(pHeader->iMsgLength);
	TWIDDLE(pHeader->iErrorCode);
	iBlen = pHeader->iMsgLength;
	cBdata = (CHAR *)malloc(iBlen);
	memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER),iBlen);
	iLog_result = fRecvsignon(cBdata,iGroupid);
	logDebug2("CNseConAdap The log result for signon response recieved is %d ",iLog_result );

	fDeal_with_LogResult(iLog_result);

	logDebug2(" HEY I i am fter fDeal_with_LogResult ");

	if(pHeader->iErrorCode != 0)
	{
		logDebug2("HEY I am fter fDeal_with_LogResult1 ");
		iErrMsgCode = pHeader->iErrorCode;
                iUserID = ((struct NNF_SIGNON_RESP *)cBdata)->iUserId;
                TWIDDLE(iUserID);
                logDebug2("This is iUserID :%d: ",iUserID);
                fFetchErrStr(pHeader->iErrorCode,&sErrorStr);
		// Printing for monitoring purpose @NItish
                logTimestamp(":%s: SIGNON RESPONSE FROM EXCHANGE WITH ERROR :%s: FOR USERID :%d:",KEY_WORD_MONITORING,sErrorStr,iUserID);
                fConnectUpdt(NSE_CUR_DOWN,iGroupid,pHeader->iErrorCode);	
		free(cSendsign);
		exit(ERROR);

	}
	else
	{
		logDebug2(" Hey I am here ");
		sprintf(sError,"%s\t%s",getenv("NSE_FO_USERID"),"USER SUCCESSFULLY LOGIN FOR TRADING");
		logDebug2("Hey I am here after getenv ");
		iUserID = ((struct NNF_SIGNON_RESP *)cBdata)->iUserId;
		// Printing for monitoring purpose @NItish
                logTimestamp(":%s: SIGNON RESPONSE FROM EXCHANGE SUCCESS WITH USER ID :%d:",KEY_WORD_MONITORING,iUserID);


		// LogDRConFatal(sProgName,sError);
	}

	free(cSendsign);
	free(pTap_wrap);
	logTimestamp("Exit : fHandleSignon ");
	return(TRUE);

}

/***********
  Function Name:			TransmitRequestPackets
Arguments:			None
Return Values:			None		
Tables Used:			
Dependencies:		 	Queue.c
x25Comm.c

Functions Called By:	Main Program - DrvNseConnect.c
Comments:		- 	The function opens the RmsnseToNse Queue 
-   	waits on the RmsnseToNse queue
-	on receiving a request message, sends it to the server via the x25 connection
 **********/

void 	fTransmitRequestPackets( LONG32 iGroupid )
{
	logTimestamp("Entry : fTransmitRequestPackets ");

	LONG32	iMainwait = -1; /*** TAP Reg Changes ***/
	memset(sProgTime,'\0',40);
	fGetTime(sProgTime);
	logDebug2("[%s] IST TransmitRequestPackets",sProgTime);

	LONG32	iSig1 = 0;
	LONG32 	iSig2 = 0;
	LONG32 	iTranskill = -1,iRespkill = -1;
	LONG32 	iPid,iPPid;
	CHAR	cTempPortfolioFlag;
	SHORT	iTotStreamId = 0 ;
	LONG32 	j; /*** TAP Reg Changes ***/
	LONG32 	iRespchild,iTranschild;
	CHAR 	*sMsg		,
		*sError		,
		*cSendsign	,
		*sSendsys	,
		*sSendup		,
		*sSendmsg	,
		*sPortfolioReq	,
		*sRecvgen	;

	struct 	NNF_HEADER	*pHeader; 
	LONG32	iQid , iWait_status , iSent_bytes , iRecv_bytes  , iLog_result , iTemp_code , iTemp_size	;

	//  	unsigned char	digest[16];
	UCHAR	sDigest[16];  
	struct 	TAP_WRAPPER	*pTap_wrap;

	struct 	DRVInvitationCount	*pInvcount;

	CHAR 	*sMsgTAP		,
		*cSendsignTAP		,
		*sSendsysTAP		,
		*sSendupTAP		,	
		*sSendmsgTAP		,
		*sPortfolioReqTAP	;

	LONG32 	iInvPacketCount;
	LONG32 	iInv_flag = FALSE;
	LONG32	iInvWaitCounter = 0;
	/***

	  EXEC SQL BEGIN DECLARE SECTION;  
	  VARCHAR lvar_uid[30];
	  LONG32 sqlgroupid;***/
	//        SHORT MaxStream ; /*** TAP Reg Changes ***/
	//      VARCHAR exchId[EXCHANGE_LEN]; /*** TAP Reg Changes ***/
	//    CHAR drvFlg = 'Y'; /*** TAP Reg Changes ***/
	//	EXEC SQL END DECLARE SECTION;  

	//VMEMCPY(exchId,exchange,EXCHANGE_LEN); /*** TAP Reg Changes ***/ 

	sigset_t SequenceSet;
	signal(SIGPIPE,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	sigemptyset( &SequenceSet );
	sigaddset( &SequenceSet , SIGUSR1);
	sigaddset( &SequenceSet , SIGUSR2);				/* Signal function Initialization */
	sigprocmask( SIG_BLOCK, &SequenceSet, NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,'\0');
	setbuf(stderr,'\0');
	/***close(inv_pipe1[0]);***/
	iPid = getpid();
	iPPid = getppid();
	//sqlgroupid = iGroupid;

	sMsg 	= (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE); 
	pHeader = (struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER));
	sError 	= (CHAR *)malloc(sizeof(CHAR)*SIZE);
	sSendsys= (CHAR *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
	sSendup = (CHAR *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ));
	sSendmsg = (CHAR *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ));
	sPortfolioReq = (CHAR *)malloc(sizeof(struct NNF_PORTFOLIO_REQ));   
	sRecvgen = (CHAR *)malloc(NSE_PACKET_SIZE);

	sMsgTAP = (CHAR *)malloc((sizeof(CHAR)*NSE_PACKET_SIZE) + sizeof(struct TAP_WRAPPER));
	sSendsysTAP = (CHAR *)malloc(sizeof(struct NNF_SYS_INFO_REQ) + sizeof(struct TAP_WRAPPER));
	sSendupTAP = (CHAR *)malloc(sizeof(struct NNF_UPDATE_LDB_REQ) + sizeof(struct TAP_WRAPPER));
	sSendmsgTAP = (CHAR *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_REQ) + sizeof(struct TAP_WRAPPER));
	sPortfolioReqTAP = (CHAR *)malloc(sizeof(struct NNF_PORTFOLIO_REQ) + sizeof(struct TAP_WRAPPER));
	/***** 
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=strlen(lvar_uid.arr);


	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  logDebug2 ("\nCNseConAdap.pc Error in connecting to oracle ");	
	  exit(ERROR);
	  }
	 *****/
	logDebug2("TRANSMIT CHILD: Connction to Oracle SUCCESS......"); 
	logDebug2("CNseConAdap The socket to which data is sent is %d ",iSockfd1);

	/*-------------------------------sys info request-------------------------------------*/
	logDebug2("ConnectToExchange is 1");
	if(iConnectToExchange == 1)
	{
/***
		while(TRUE)
		{
			fGetInvitationPacketCount(&iInvPacketCount,iGroupid);

			logDebug2("InvPacketCount = [%d]",iInvPacketCount);
			if(iInvPacketCount != 0)
			{
				logDebug2("TRANSMIT CHILDInvPacketCount [%d]      ",iInvPacketCount);
				break;
			}
			sleep(5);
		}
		logDebug2("TRANSMIT CHAftre fGetInvitationPacketCount  InvPacketCount [%d]    ",iInvPacketCount);
***/
		logDebug2("TRANSMIT CHBefore sendsysinfo      ");

		fSendsysinfo(sSendsys);

		iTemp_size = ((struct NNF_HEADER *)(sSendsys ))->iMsgLength;
		TWIDDLE(((struct NNF_HEADER *)(sSendsys))->iMsgLength);
		fMD5_Digest(sDigest,sSendsys ,iTemp_size )  ;
		pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER)); 
		memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
		iTemp_size = iTemp_size + 22;
		pTap_wrap->Message_Len = iTemp_size;

		/*** TAP Reg Changes ***/
		iTransmitSeq++;
		pTap_wrap->Seq_No = iTransmitSeq ;
		TWIDDLE(pTap_wrap->Message_Len);
		TWIDDLE(pTap_wrap->Seq_No);
		/*** TAP Reg Changes ***/

		/***		 pTap_wrap->Seq_No = pTap_wrap->Seq_No + 1; **VEERA************/
		logDebug2(" Seq No :::::: sSendsysTAP ::::: [%d]",pTap_wrap->Seq_No);
		logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d]",pTap_wrap->Seq_No);
		memcpy(pTap_wrap->digest,sDigest,16);
		memcpy(sSendsysTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
		memcpy(sSendsysTAP + sizeof(struct TAP_WRAPPER),sSendsys,sizeof(struct NNF_SYS_INFO_REQ));
		logDebug2("TRANSMIT CHILD Bfore sending     ");
		iSent_bytes = SEND(iSockfd1, sSendsysTAP,iTemp_size );

		fDeal_with_SendRecv(iSent_bytes , iGroupid);

		logDebug2("TRANSMIT CHILD Before fReduceInvitationCount   ");

		fReduceInvitationCount(iGroupid);
		logDebug2("TRANSMIT CHILD SYS INFO REQ :: SENT TO EXCHANGE ... ");
		// Printing for monitoring purpose @NItish
		logTimestamp(":%s: SYS INFO REQUEST SEND TO EXCHANGE ",KEY_WORD_MONITORING);


		/*----------------------------update local database request--------------------------*/

		logDebug2("ALOKK HERE ");
		iSig1 = 0;
		//		LONG32	alok =0;
		/*** TAP Reg Changes ***/
		/*****/		iMainwait = sigwait( &SequenceSet, &iSig1);/******ALOKKK*****/
		logDebug2("ALOKK HERE ");
		logDebug2("SIGNAL 1:%d", iSig1);
		/*** TAP Reg Changes ***/
		logDebug2("TRANSMIT CHILD SYS INFO RESPONSE COMPLETED");


		if ( iSig1 == SIGUSR1 )
		{
/***
			while(TRUE)
			{
				fGetInvitationPacketCount(&iInvPacketCount,iGroupid);
				if(iInvPacketCount != 0)
				{
					logDebug2("TRANSMIT CHILDInvPacketCount [%d]      ",iInvPacketCount);
					break;
				}
			}
			logDebug2("TRANSMIT CHILDAfter fGetInvitationPacketCount InvPacketCount [%d]",iInvPacketCount);
****/
			logDebug2("TRANSMIT CHILDBefore sendupdate");

			fSendupdate( sSendup,iGroupid );

			iTemp_size = ((struct NNF_HEADER *)(sSendup ))->iMsgLength;
			TWIDDLE(((struct NNF_HEADER *)(sSendup))->iMsgLength);
			fMD5_Digest(sDigest,sSendup  ,iTemp_size )  ;
			memset(pTap_wrap,0,sizeof(struct TAP_WRAPPER));

			logDebug2("======== Before Send LDB Update Request %d======",iTemp_size);
			iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);
			pTap_wrap->Message_Len = iTemp_size;

			/*** TAP Reg Changes ***/
			iTransmitSeq ++;
			pTap_wrap->Seq_No = iTransmitSeq;
			/*** TAP Reg Changes ***/
			TWIDDLE(pTap_wrap->Message_Len);
			TWIDDLE(pTap_wrap->Seq_No);

			logDebug2("TRANSMIT CHILD:Transmit Seq No incremented to [%d]",pTap_wrap->Seq_No); 
			logDebug2("SEQ NO pTap_wrap->Seq_No = [%d]",pTap_wrap->Seq_No);

			memcpy(pTap_wrap->digest,sDigest,16);
			memcpy(sSendupTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(sSendupTAP + sizeof(struct TAP_WRAPPER),sSendup,sizeof(struct NNF_UPDATE_LDB_REQ));
			logDebug2("TRANSMIT CHILD Bfefore Sending");
			iSent_bytes = SEND(iSockfd1,sSendupTAP,iTemp_size);

			fDeal_with_SendRecv(iSent_bytes , iGroupid);
			// Printing for monitoring purpose @NItish
			logTimestamp(":%s: UPDATE LOCAL DB REQUEST SEND TO EXCHANGE ",KEY_WORD_MONITORING);
			logDebug2("TRANSMIT CHILD Before fReduceInvitationCount");

			fReduceInvitationCount(iGroupid);

			logDebug2("TRANSMIT CHILD Lock on ProcessDataLock1 ");
			//LockShm( ProcessDataLock1 );
			logDebug2("TRANSMIT CHILD UPDATE LDB REQUEST :: SENT TO EXCHANGE");
			logDebug2("CNseConAdap UPDATE LDB REQUEST :: SENT TO EXCHANGE ... ");

		}

		logDebug2("TRANSMIT CHILD WAITING FOR SIGNAL 2 ");
		iSig1 = 0;

		/***/		iMainwait = sigwait( &SequenceSet,&iSig1);/*****ALOKKKK***/
		logDebug2(" SIGNAL 2:%d", iSig1);

		if ( iSig1 == SIGUSR2 )
		{
/***
			while(TRUE)
			{
				fGetInvitationPacketCount(&iInvPacketCount,iGroupid);
				if(iInvPacketCount != 0)
				{
					logDebug2("TRANSMIT CHILDInvPacketCount [%d]      ",iInvPacketCount);
					break;
				}
			}
			logDebug2("TRANSMIT CHILD After fGetInvitationPacketCount InvPacketCount [%d] ",iInvPacketCount);
****/
			logDebug2("TRANSMIT CHILD Before sendupdate      ");

			fSendupdate( sSendup,iGroupid );

			iTemp_size = ((struct NNF_HEADER *)(sSendup ))->iMsgLength;
			TWIDDLE(((struct NNF_HEADER *)(sSendup))->iMsgLength);

			fMD5_Digest(sDigest,sSendup ,iTemp_size )  ;

			memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
			iTemp_size = iTemp_size + 22;
			pTap_wrap->Message_Len = iTemp_size;

			iTransmitSeq ++;
			pTap_wrap->Seq_No = iTransmitSeq;
			TWIDDLE(pTap_wrap->Seq_No);
			TWIDDLE(pTap_wrap->Message_Len);

			logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d] ",pTap_wrap->Seq_No);
			memcpy(pTap_wrap->digest,sDigest,16);
			memcpy(sSendupTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(sSendupTAP + sizeof(struct TAP_WRAPPER),sSendup,sizeof(struct NNF_UPDATE_LDB_REQ));
			logDebug2("TRANSMIT CHILD Before Sending     ");
			iSent_bytes =SEND(iSockfd1,sSendupTAP,iTemp_size);

			fDeal_with_SendRecv(iSent_bytes , iGroupid);
			logDebug2("TRANSMIT CHILD Before fReduceInvitationCount      ");

			fReduceInvitationCount(iGroupid);
			logDebug2("TRANSMIT CHILD AGAIN UPDATE LDB REQUEST :: SENT TO EXCHANGE      ");
		}
		else if ( iSig1 == SIGUSR1 )
		{
			logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD");

			/*** TAP Reg Changes ***//****
			EXEC SQL SELECT max(EDD_STREAM_ID)
				INTO :MaxStream
				FROM EXCH_DOWNLOAD_DIGITAL
				WHERE  EDD_EXCH_ID='NSE'
				AND EDD_DRV_FLAG='Y'
				AND EDD_GROUP_ID=:iGroupid; 

			if ( sqlca.sqlcode != 0)
			{
				logDebug2("\n Error in Selecting EDD for StreamId  is %d ", sqlca.sqlcode );
				exit(ERROR); 
			}
			******/
				//iTotalStream = 0;
				iTotStreamId= fGetTotalStream();
			logDebug2(" TOTAL No Of STREAM : [%d] ", iTotStreamId);

			for (j=1; j<= iTotStreamId; j++) 
			{
/****
				while(TRUE)
				{
					fGetInvitationPacketCount(&iInvPacketCount,iGroupid);
					if(iInvPacketCount != 0)
					{
						logDebug2("TRANSMIT CHILD InvPacketCount [%d]      ",iInvPacketCount);
						break;
					}
				}
				logDebug2("TRANSMIT CHILD After fGetInvitationPacketCount InvPacketCount [%d]    ",iInvPacketCount);
****/
				logDebug2("TRANSMIT CHILD Before sendmessage     ");

				fSendmessage( sSendmsg , iGroupid, j);
				memset((((struct NNF_HEADER *)(sSendmsg))->sAlphaSplit),'\0',2);
				sprintf((((struct NNF_HEADER *)(sSendmsg))->sAlphaSplit),"%d", j);
				logDebug2("Alpha Split value : [%s]", (((struct NNF_HEADER *)(sSendmsg))->sAlphaSplit));

				iTemp_size = ((struct NNF_HEADER *)(sSendmsg ))->iMsgLength;
				TWIDDLE(((struct NNF_HEADER *)(sSendmsg))->iMsgLength);

				fMD5_Digest(sDigest,sSendmsg  ,iTemp_size)  ;

				memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				iTemp_size = iTemp_size + 22;
				pTap_wrap->Message_Len = iTemp_size;
				logDebug2("GROUP ID CHECK::: [%d]",iGroupid);
				logDebug2("1>>>SEQ No SENT IS : [%d]",pTap_wrap->Seq_No);

				iTransmitSeq ++;
				pTap_wrap->Seq_No = iTransmitSeq;
				TWIDDLE(pTap_wrap->Seq_No);
				TWIDDLE(pTap_wrap->Message_Len);


				logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d]",pTap_wrap->Seq_No);
				logDebug2("1>>>SEQ No SENT IS : [%d]",pTap_wrap->Seq_No);

				memcpy(pTap_wrap->digest,sDigest,16);
				memcpy(sSendmsgTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(sSendmsgTAP + sizeof(struct TAP_WRAPPER) , sSendmsg,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
				logDebug2("TRANSMIT CHILDBefore Sending");
				iSent_bytes = SEND(iSockfd1,sSendmsgTAP ,iTemp_size);

				fDeal_with_SendRecv(iSent_bytes , iGroupid);
				// Printing for monitoring purpose @NItish
				logTimestamp(":%s: DOWNLOAD ORDER REQUEST SEND TO EXCHANGE ",KEY_WORD_MONITORING);
				logDebug2("TRANSMIT CHILD Before fReduceInvitationCount     ");

				fReduceInvitationCount(iGroupid);
				logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD REQUEST :: SENT TO EXCHANGE ..      ");
			}

		}
		iSig1 = 0;
		/****/		iMainwait = sigwait( &SequenceSet,&iSig1);/****ALOKKK ************/
		iMainwait = 0;

		iSig1 = iMainwait ;
		logDebug2("SIGNAL 3:%d", iSig1);

		if (iSig1 == SIGUSR1)
		{
			iTotStreamId= fGetTotalStream();
			logDebug2(" TOTAL No Of STREAM : [%d] ", iTotStreamId);
			for (j=1; j<= iTotStreamId; j++)
			{
				logDebug2("TRANSMIT CHILD Before fGetInvitationPacketCount     ");
/***
				fGetInvitationPacketCount(&iInvPacketCount,iGroupid);
				logDebug2("TRANSMIT CHILD After fGetInvitationPacketCount InvPacketCount [%d] ",iInvPacketCount);

				if(iInvPacketCount == 0)
				{
					iRecv_bytes  = RECV_INV(iSockfd1,sRecvgen,iInv_flag);
					if(iInv_flag == TRUE)
					{
						logDebug2("TRANSMIT CHILD Before fReceiveInvitationPacket ");
						fReceiveInvitationPacket(iSockfd1,iGroupid);
					}
				}
				logDebug2("TRANSMIT CHILD Before sendmessage ");
***/
				fSendmessage( sSendmsg , iGroupid, j );

				memset((((struct NNF_HEADER *)(sSendmsg))->sAlphaSplit),'\0',2);
				sprintf((((struct NNF_HEADER *)(sSendmsg))->sAlphaSplit),"%d", j);
				logDebug2("Alpha Split value : [%s] ", (((struct NNF_HEADER *)(sSendmsg))->sAlphaSplit));

				iTemp_size = ((struct NNF_HEADER *)(sSendmsg ))->iMsgLength;
				TWIDDLE(((struct NNF_HEADER *)(sSendmsg ))->iMsgLength);

				fMD5_Digest(sDigest,sSendmsg  ,iTemp_size )  ;

				memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
				iTemp_size = iTemp_size + 22;
				pTap_wrap->Message_Len = iTemp_size;

				iTransmitSeq ++;
				pTap_wrap->Seq_No = iTransmitSeq;
				TWIDDLE(pTap_wrap->Seq_No);
				TWIDDLE(pTap_wrap->Message_Len);

				logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d]",pTap_wrap->Seq_No);
				logDebug2("SEQ No SENT IS : [%d]",pTap_wrap->Seq_No);
				memcpy(pTap_wrap->digest,sDigest,16);
				memcpy(sSendmsgTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
				memcpy(sSendmsgTAP + sizeof(struct TAP_WRAPPER),sSendmsg,sizeof(struct NNF_MSG_DOWNLOAD_REQ));
				logDebug2("TRANSMIT CHILD Before Sending      ");
				iSent_bytes = SEND(iSockfd1,sSendmsgTAP,iTemp_size);
				if ( iSent_bytes < 0 )
				{
					fSend_exch_down_buf_nse( iGroupid ,sSendmsg );
				}
				fDeal_with_SendRecv(iSent_bytes , iGroupid);

				logDebug2("TRANSMIT CHILD Before fReduceInvitationCount ");
				// Printing for monitoring purpose @NItish
				logTimestamp(":%s: DOWNLOAD ORDER REQUEST SEND TO EXCHANGE ",KEY_WORD_MONITORING);

				fReduceInvitationCount(iGroupid);
				logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD REQUEST :: SENT TO EXCHANGE ...       ");
			}
		}
		else if ( iSig1 == SIGUSR2 )
		{
			logDebug2("TRANSMIT CHILD MESSAGE AREA DOWNLOAD COMPLETE NORMAL PROCESS STARTS");
		}

		/******
		  EXEC SQL SELECT EXM_DRV_PORTFOLIO_FLG
INTO :cTempPortfolioFlag
FROM EXCH_MASTER
WHERE EXM_EXCH_ID = 'NSE';

if (sqlca.sqlcode != 0)
{
logDebug2("\nTransmitRequestPackets :Error in Selecting EXM_DRV_PORTFOLIO_FLG is:%d",sqlca.sqlcode);
}
		 *****/
		cTempPortfolioFlag = 'N';

/*** Only if this flag is set during SysInfoResp will we send the portfolio req ***/
		if (cTempPortfolioFlag == 'Y')
		{
/***	
			while(TRUE)
			{
				fGetInvitationPacketCount(&iInvPacketCount,iGroupid);
				if(iInvPacketCount != 0)
				{
					logDebug2("TRANSMIT CHILD InvPacketCount [%d]      ",iInvPacketCount);
					break;
				}
			}
			logDebug2("TRANSMIT CHILD PORTFOLIO");
***/	
			fSendPortfolioReq(sPortfolioReq);

			iTemp_size = ((struct NNF_HEADER *)(sPortfolioReq ))->iMsgLength;
			TWIDDLE(((struct NNF_HEADER *)(sPortfolioReq ))->iMsgLength);
		
			fMD5_Digest(sDigest,sPortfolioReq  ,iTemp_size )  ;

			memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
			iTemp_size = iTemp_size + 22;
			pTap_wrap->Message_Len = iTemp_size;
			iTransmitSeq ++;
			pTap_wrap->Seq_No = iTransmitSeq;
			TWIDDLE(pTap_wrap->Seq_No);
			TWIDDLE(pTap_wrap->Message_Len);

			logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d]",pTap_wrap->Seq_No);

			memcpy(pTap_wrap->digest,sDigest,16);
			memcpy(sPortfolioReqTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(sPortfolioReqTAP + sizeof(struct TAP_WRAPPER),sPortfolioReq,sizeof(struct NNF_PORTFOLIO_REQ)); 

			iSent_bytes = SEND(iSockfd1,sPortfolioReqTAP, iTemp_size);
			if (iSent_bytes < 0)
			{
				fSend_exch_down_buf_nse(iGroupid,sPortfolioReq);
				free(sPortfolioReq);
			}
			fDeal_with_SendRecv(iSent_bytes,iGroupid);
			
			fReduceInvitationCount(iGroupid);
			// Printing for monitoring purpose @NItish
			logTimestamp(":%s: PORTFOLIO DOWNLOAD REQUEST SEND TO EXCHANGE ",KEY_WORD_MONITORING);
			logDebug2("CNseConAdap: PORTFOLIO DOWNLOAD REQUEST ");
			iSig1 = 0;

	//			iSig1 =0;
			logDebug2("SIGNAL 4:%d", iSig1);

			if (iSig1 == SIGUSR1)
			{
				logDebug2("Portfolio Download Complete. NORMAL PROCESS STARTS");
			}
			else
			{
				logDebug2("ERROR. Received a wrong signal when expecting SIGUSR1");
			}

		}
		else
		logDebug2("TransmitRequestPackets: DOWNLOAD COMLETE NORMAL PROCESS STARTS");
	}   /*if loop ends skip the code in if(), if we connect to simulatior*/


/*** 	RmsnseToNse queue opened for BFSL to Exchange communication ***/

	logDebug2("OPENING  GlobQueueId  %d",FwdMMapToConAdapNSECD) ;

	iQid = OpenMsgQ(FwdMMapToConAdapNSECD);
	if ( iQid < 0 )
	{
		strcpy(sError,"ERROR : in OpenMsgQ function ");
		logFatal("CNseConAdap %s",sError);
		fExit(ERROR);
	}

/*** This is to Indicate Front end users, that exch connection is estb. ***/ 
/*****
  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
  SET  EAM_LOGON_STATUS = 'R'
  WHERE EAM_EXM_EXCH_ID = 'NSE'
  AND EAM_GROUP_ID = to_char(:sqlgroupid)
  AND EAM_DRV_FLAG  = 'Y';

  if ( sqlca.sqlcode == -1036 )
  {
  logDebug2("\n Inside 1036 sError ************** ");
  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
  SET  EAM_LOGON_STATUS = 'R'
  WHERE EAM_EXM_EXCH_ID = 'NSE'
  AND EAM_GROUP_ID = to_char(:sqlgroupid)
  AND EAM_DRV_FLAG = 'Y';
  if ( sqlca.sqlcode == 0 )
  {
  logDebug2("\n No sError ");
  EXEC SQL COMMIT;
  }
  }
  else if (sqlca.sqlcode != 0)
  {
  logDebug2("UPDATE EXCH_ADMINISTRATION_MASTER sql sError : %d\n",sqlca.sqlcode);
  logDebug2("\n SqlGroupId for which this sError occurs is %d ", sqlgroupid );
  } 
  else
  {	
  EXEC SQL COMMIT;
  }****/
	logDebug2("TRANSMIT CHILD Before fUpdateConnectStatus     ");

//fUpdateConnectStatus(NSE_CUR_UP, iGroupid );
	fConnectUpdt(NSE_CUR_UP, iGroupid,0 );
	// Printing for monitoring purpose @NItish	
	logTimestamp(":%s: NSE CD CONNECTION IS UP ",KEY_WORD_MONITORING);
	logDebug2(" ******Here Before While Loop *****");
	logDebug2(" Read Q Id is %d ", iQid);
	while ( TRUE )
	{
		logDebug2("TRANSMIT CHILD At the start of the While Loop     ");
		iInvWaitCounter = 0;
		logDebug2("TRANSMIT CHILD InvPacketCount [%d]      ",iInvPacketCount);
// commenting this as sleep busy timer is move to CurrTAPComm.c while sending any packets to exchange on socket @Nitish	
//		usleep(iBusyTimer);
	/**
		if(iInvPacketCount >0)
		{
**/
		memset(sMsg,NULL,NSE_PACKET_SIZE);	
		memset(sError,NULL,SIZE);
		logDebug2("TRANSMIT CHILD ReadMsgQ id is %d",iQid);
		//iWait_status = ReadMsgQ( iQid , sMsg , NSE_PACKET_SIZE , iGroupid);
		iWait_status = ReadMsgQ( iQid , sMsg , NSE_PACKET_SIZE , 0);
		logDebug2("TRANSMIT CHILD After ReadMsgQ iWait_status : %d",iWait_status )  ;
		if (iWait_status == TRUE)
		{
			memcpy(pHeader,sMsg,sizeof(struct NNF_HEADER));	
			TWIDDLE(pHeader->iMsgLength);
			TWIDDLE(pHeader->iMsgCode);
			iTemp_size = pHeader->iMsgLength;
			iTemp_code = pHeader->iMsgCode;
			logDebug2("TRANSMIT CHILD pHeader->iMsgLength [%d]      ",pHeader->iMsgLength);
			logDebug2("TRANSMIT CHILD pHeader->iMsgCode [%d]      ",pHeader->iMsgCode);
			/*****		    logDebug2("\n --------------------PACKET DATA SENT-------------------------");
			  logDebug2("\n iMsgLength  [%d] ",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgLength);
			  logDebug2("\n OrderNum  [%.0lf",((struct NNF_ORDER_ENTRY *)sMsg)->OrderNum);
			  logDebug2("\n AccCode [%s",((struct NNF_ORDER_ENTRY *)sMsg)->AccCode);
			  logDebug2("\n Settlor [%s",((struct NNF_ORDER_ENTRY *)sMsg)->Settlor);
			  logDebug2("\n ReasonCode  [%d] ",((struct NNF_ORDER_ENTRY *)sMsg)->ReasonCode);
			  logDebug2("\n Price  [%d] ",((struct NNF_ORDER_ENTRY *)sMsg)->Price);
			  logDebug2("\n -------------------------------------------------------------");
			 ***/				logDebug2("TRANSMIT CHILD pHeader->iMsgLength [%d]      ",pHeader->iMsgLength);
			logDebug2("TRANSMIT CHILD pHeader->iMsgCode [%d]      ",pHeader->iMsgCode);
			switch(iTemp_code)
                        {
                        	case TC_EQU_NSE_ORD_ENTRY_REQ_TM:
                        		iTemp_size = sizeof(struct NNF_ORDER_ENTRY_REQ_TM);
                        		break;
                        	case TC_EQU_NSE_ORD_MOD_REQ_TM:
                        	case TC_EQU_NSE_ORD_CAN_REQ_TM:
                        		iTemp_size = sizeof(struct NNF_ORD_MOD_CAN_REQ_TM);

                        	break;

				default :
					iTemp_size = pHeader->iMsgLength;
				break;

                         };
			/***
			  logDebug2(" --------------------NITISH PACKET DATA SENT-------------------------");
			  logDebug2(" iMsgLength           [%d] ",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgLength);
			  logDebug2(" iLogTimeStamp        :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iLogTimeStamp);
			  logDebug2(" sAlphaSplit          :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.sAlphaSplit);
			  logDebug2(" iMsgCode             :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iMsgCode);
			  logDebug2(" iErrorCode           :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sHeader.iErrorCode);
			  logDebug2(" ParticipantType      :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cParticipantType);
			  logDebug2(" Reserved1            :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cReserved1);
			  logDebug2(" CompititorPeriod     :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iCompititorPeriod);
			  logDebug2(" SolicitorPeriod      :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iSolicitorPeriod);
			  logDebug2(" ModCanBy             :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cModCanBy);
			  logDebug2(" ReasonCode           :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iReasonCode);
			  logDebug2(" Token                :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iToken);
			  logDebug2(" InstrumentName       :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->ContractDesc.sInstrumentName);
			  logDebug2(" ExpiryDate           :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->ContractDesc.iExpiryDate);
			  logDebug2(" CALevel              :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->ContractDesc.iCALevel);
			  logDebug2(" Symbol               :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->ContractDesc.sSymbol);
			  logDebug2(" OptionType           :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->ContractDesc.sOptionType);
			  logDebug2(" StrikePrice          :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->ContractDesc.iStrikePrice);
			  logDebug2(" CPBrokerCode         :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sCPBrokerCode);
			  logDebug2(" CloseOutFlag         :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cCloseOutFlag);
			  logDebug2(" OrderType            :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iOrderType);
			  logDebug2(" OrderNum             :%lf:",((struct NNF_ORDER_ENTRY *)sMsg)->fOrderNum);
			  logDebug2(" AccCode              :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sAccCode);
			  logDebug2(" BookType             :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iBookType);
			  logDebug2(" BuyOrSell            :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iBuyOrSell);
			  logDebug2(" DiscQty              :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iDiscQty);
			  logDebug2(" DiscQtyRemaining     :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iDiscQtyRemaining);
			  logDebug2(" TotalQtyRemaining    :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iTotalQtyRemaining);
			  logDebug2(" TotalQty             :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iTotalQty);
			  logDebug2(" QtyFilledToday       :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iQtyFilledToday);
			  logDebug2(" Price                :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iPrice);
			  logDebug2(" TriggerPrice         :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iTriggerPrice);
			  logDebug2(" GoodTillDate         :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iGoodTillDate);
			  logDebug2(" EntryTime            :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iEntryTime);
			  logDebug2(" MinFillQty           :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iMinFillQty);
			  logDebug2(" LastModifiedTime     :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iLastModifiedTime);
			  logDebug2(" AONTerm              :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.AONTerm);
			  logDebug2(" IOCTerm              :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.IOCTerm);
			  logDebug2(" GTCTerm              :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.GTCTerm);
			  logDebug2(" DayTerm              :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.DayTerm);
			  logDebug2(" MIIT                 :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.MIIT);
			  logDebug2(" StopLossTerm         :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.StopLossTerm);
			  logDebug2(" Market               :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.Market);
			  logDebug2(" ATO                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.ATO);
			  logDebug2(" Frozen               :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.Frozen);
			  logDebug2(" Modified             :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.Modified);
			  logDebug2(" Traded               :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.Traded);
			  logDebug2(" MatchedInd           :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.MatchedInd);
			  logDebug2(" MFTerm               :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->OrderTerms.MFTerm);
			  logDebug2(" BranchId             :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iBranchId);
			  logDebug2(" ExcgUserId           :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iExcgUserId);
			  logDebug2(" BrokerCode           :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sBrokerCode);
			  logDebug2(" Remarks              :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sRemarks);
			  logDebug2(" OpenClose            :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cOpenClose);
			  logDebug2(" Settlor              :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sSettlor);
			  logDebug2(" ProCli               :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iProCli);
			  logDebug2(" SettlementDays       :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->iSettlementDays);
			  logDebug2(" CoverUncover         :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cCoverUncover);
			  logDebug2(" GiveupFlag           :%c:",((struct NNF_ORDER_ENTRY *)sMsg)->cGiveupFlag);
			  logDebug2("  b1                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b1);
			  logDebug2(" b2                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b2);
			  logDebug2(" b3                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b3);
			  logDebug2(" b4                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b4);
			  logDebug2(" b5                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b5);
			  logDebug2(" b6                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b6);
			  logDebug2(" b7                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b7);
			  logDebug2(" b8                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b8);
			  logDebug2(" b9                   :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b9);
			  logDebug2(" b10                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b10);
			logDebug2(" b11                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b11);
			logDebug2(" b12                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b12);
			logDebug2(" b13                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b13);
			logDebug2(" b14                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b14);
			logDebug2(" b15                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b15);
			logDebug2(" b16                  :%d:",((struct NNF_ORDER_ENTRY *)sMsg)->sExchRsrvdFlds.b16);
			logDebug2(" Seq                  :%s:",((struct NNF_ORDER_ENTRY *)sMsg)->sSeq);
			logDebug2(" dUserInfo            :%lf:",((struct NNF_ORDER_ENTRY *)sMsg)->fUserInfo);
			logDebug2(" dReservedPrgTrd      :%lf:",((struct NNF_ORDER_ENTRY *)sMsg)->fReservedPrgTrd);
			logDebug2(" ------------------END-------------------------------------------");
			***/
				fMD5_Digest(sDigest,sMsg ,iTemp_size)  ;

			pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
			memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
			iTemp_size = iTemp_size + 22;
			pTap_wrap->Message_Len = iTemp_size;
			/*** TAP Reg Changes ***/
			iTransmitSeq ++;
			pTap_wrap->Seq_No = iTransmitSeq;
			/*** TAP Reg Changes ***/
			logDebug2("TRANSMIT CHILD Seq No Sending Order Packet [%d] ---",pTap_wrap->Seq_No);
			logDebug2(" PACKET SENDING TO NSE WITH SEQ: [%d]",pTap_wrap->Seq_No);

			TWIDDLE(pTap_wrap->Seq_No);
			TWIDDLE(pTap_wrap->Message_Len);
			memcpy(pTap_wrap->digest,sDigest,16);
			memcpy(sMsgTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
			memcpy(sMsgTAP + sizeof(struct TAP_WRAPPER),sMsg ,iTemp_size - 22);

			logDebug2(" BEFORE SEND 1 Temp_size : %d",iTemp_size )  ;
			logDebug2("This is before sending the packet to exch");		

			fReduceInvitationCount(iGroupid); 
			iSent_bytes =SEND(iSockfd1,sMsgTAP,iTemp_size);
			logDebug2("This is after sending the packet");		

			if ( iSent_bytes <= 0 )
			{
				fSend_exch_down_buf_nse( iGroupid , sMsg );
			}
			logDebug2("CNseConAdap Message sent to socket : %d ",iSent_bytes);
			logDebug2("CNseConAdap Message code : %d ",iTemp_code);
			system("echo 'Date and Time is' ");
			system("date");
			logDebug2("TRANSMIT CHILD Before fDeal_with_SendRecv      ");

			fDeal_with_SendRecv(iSent_bytes , iGroupid);

			if(iSent_bytes > 0)
			{
				logDebug2(" inside if(Sent_bytes > 0) before Update_Offline_Status(sMsg) --- 1");
				logDebug2(" inside if(Sent_bytes > 0) after Update_Offline_Status(sMsg)--- 2");
			}	
		}
		else
		{
			memset(sError,NULL,SIZE);
			strcpy(sError,"CNseConAdap ERROR in ReadMsgQ function ");
			logDebug2("CNseConAdap ERROR in ReadMsgQ function " )  ;
			logFatal("CNseConAdap %s",sError);
			fExit(ERROR);
		}
	//}
	}
	fGetTime(sProgTime);
	logDebug2("[%s] IST TransmitRequestPackets ENDS",sProgTime);
	logTimestamp("Exit : fTransmitRequestPackets ");
}		/* End of TransmitRequestPackets ****/



void 	fReceiveReplyPackets( LONG32 iSockfd1 , LONG32 iLocalId)
{
	logTimestamp("Entry : fReceiveReplyPackets");

	memset(sProgTime,'\0',40);
	fGetTime(sProgTime);
	logDebug2("[%s] IST Recieve Reply packets function ---",sProgTime);
	LONG32	iQidnormal,
		iQidaucodd,
		iRecv_bytes,
		iWrite_status;

	//	LONG32 	clen3,
	LONG32  iQueue_bytes,
		iSent_bytes,
		iTemp_size,
		iTemp_code,
		iWait_status,
		iLog_result,
		iFlag=1,iPid,iPPid,
		iPut_in_queue=FALSE,
		iTimeStampUpdateFlag =FALSE, 
		iDownloadFlag = FALSE; /*** TAP Reg Changes ***/

	/**** TAP Reg Changes ****/
	SHORT 	j=0; 
	SHORT 	iStream = 0, iDowCounter = 0;
	LONG32 	iIndexrec = 1;
	LONG32	iUserID = 0;
	LONG32	iErrMsgCode = 0;	
	/**** TAP Reg Changes ****/

	CHAR    *sRecvgen1,
		*sWrite_mess,
		sError[SIZE];
	//	LONG32  FileFlag=FALSE;
	LONG32 	iInv_flag = FALSE;
	LONG32	iTempMsgCode;
	//	SHORT  	pInvcount;
	struct 	TAP_WRAPPER *pTap_wrap;
	LONG32  iSeq_No;
	CHAR    sErrorStr[DB_REASON_DESC_LEN];

	//	unsigned char digest[16];
	UCHAR	sDigest[16];
	CHAR 	*cBdata;
	LONG32 	iBlen;
	struct 	NNF_HEADER			*pHeader;
	struct 	NNF_UPDATE_LDB_DATA_RESP 	*pUdresponse;
	struct 	NNF_MSG_DOWNLOAD_DATA_RESP 	*pMdresponse;
	struct 	NNF_DOUBLE_INT 			pTempTimeStamp, pDowTime;
	struct 	NNF_PORTFOLIO_RESP           	*pPortfolioresp;
	struct NNF_ORD_RESPONSE_TM *pOrdRsp;
        struct NNF_TRADE_RESP_TM        *pTrdRsp;
	struct NNF_BOX_SIGN_OFF_TM      *pBoxSignOff;
	LONG32 	iSig1 = 0;
	LONG32 	iSig2 = 0;
	LONG32 	iTranskill = -1,iRespkill = -1,iDownkill = -1 ;
	LONG32 	iSpecial_id=0;
	LONG32 	iRespchild,iDownchild,iTranschild,iGroupid;

	LONG32 	iInvPacketCount;
	/****** 
	  EXEC SQL BEGIN DECLARE SECTION;  
	  VARCHAR lvar_uid[30];
	  ULONG32  iTempTime1 ;
	  ULONG32  iTempTime2 ;
	  LONG32 iSqlGroupId = 0;
	  EXEC SQL END DECLARE SECTION;  
	 ******/
	ULONG32	iTempTime1 ;
	ULONG32	iTempTime2 ;
	sigset_t SequenceSet;
	signal(SIGPIPE,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	sigemptyset( &SequenceSet );
	sigaddset( &SequenceSet , SIGUSR1);
	sigaddset( &SequenceSet , SIGUSR2);			/* Signal Initialization Functions */
	sigprocmask( SIG_BLOCK, &SequenceSet, NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf(stdout,'\0');
	setbuf(stderr,'\0');
	iPid = getpid();
	iPPid = getppid();
	logDebug2("Inside Function ReceiveReplyPackets Local Group Id : %d",iLocalId);
	iSpecial_id = iLocalId;
	/***	    iSqlGroupId = iSpecial_id;
	  logDebug2("\nInside Function ReceiveReplyPackets Sql Local Group Id : %d\n",iSqlGroupId);*****/

	pOrdRsp = (struct NNF_ORD_RESPONSE_TM *)malloc(sizeof(struct NNF_ORD_RESPONSE_TM));
        memset(pOrdRsp,'\0',sizeof(struct NNF_TRADE_RESP_TM));
        pTrdRsp= (struct NNF_TRADE_RESP_TM *)malloc(sizeof(struct NNF_TRADE_RESP_TM));
        memset(pTrdRsp,'\0',sizeof(struct NNF_TRADE_RESP_TM));
	sRecvgen1 = (CHAR *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	sWrite_mess = (CHAR *)malloc(sizeof(char)*NSE_PACKET_SIZE);
	pHeader = (CHAR *)malloc(sizeof(struct NNF_HEADER));
	pMdresponse = (struct  NNF_MSG_DOWNLOAD_DATA_RESP *)malloc(sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP));
	pBoxSignOff = (struct NNF_BOX_SIGN_OFF_TM *)malloc(sizeof(struct NNF_BOX_SIGN_OFF_TM));
        memset(pBoxSignOff,'\0',sizeof(struct NNF_BOX_SIGN_OFF_TM));
	/******
	  strcpy( lvar_uid.arr,  getenv("USER_PASS")  );
	  lvar_uid.len=strlen(lvar_uid.arr);

	  logDebug2("\nReceiveReplyPackets: connecting to database : %.*s......." ,lvar_uid.len , lvar_uid.arr);

	  EXEC SQL CONNECT :lvar_uid ;
	  if ( sqlca.sqlcode != 0 )
	  {
	  logDebug2 ("\nDrvNseConnect.pc Error in connecting to oracle ");	
	  exit(ERROR);		
	  }
	  logDebug2("\nReceiveReplyPackets: Connection to Oracle SUCCESS......"); 
	 **********/
	/**************************** normal packets + ldb , sMsg ****************************/
	/*** TAP Reg Changes ***/ 
	/***
	#ifdef MEMMAP
	iQidnormal = OpenMsgQ(DrvMmapToChild);
	logDebug2("\n Connect to MemMap Queue selected");
	#else
	iQidnormal = OpenMsgQ(DrvNseToRmsnse);
	logDebug2("\n Connect to Child Queue selected");
#endif
	 **/
	iQidnormal = OpenMsgQ(ConnToTrdMapNSECR);
	/*** TAP Reg Changes ***/

	if( iQidnormal < 0 )
	{
		memset(sError,NULL,SIZE);
		strcpy(sError,"ERROR : in OpenMsgQ function ");
		logFatal("CNSEAdptor %s",sError);
		fExit(ERROR);
	}
	else
	{
		logDebug2("CNseConAdap Queue opened and readyn");

	}

	cBdata = (CHAR *)malloc(NSE_PACKET_SIZE);
	pTap_wrap = ( struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER)); 
	while(TRUE)
	{
		memset(sRecvgen1,NULL,NSE_PACKET_SIZE);
		memset(pTap_wrap,'\0',sizeof(struct TAP_WRAPPER)); 
		memset(pHeader,'\0',sizeof(struct NNF_HEADER)); 
		iPut_in_queue = FALSE;
		logDebug2("ReceiveReplyPackets: Awaiting response from Exch");
		logDebug2(" Waiting on sockfd1 :%d",iSockfd1);
		iInv_flag = FALSE;
		logDebug2("--------------------------------- RECEIVE CHILD NEW PACKET --------------------------------------");
/****
		iRecv_bytes = RECV_INV(iSockfd1,sRecvgen1,&iInv_flag);
		fDeal_with_SendRecv(iRecv_bytes , iLocalId);
		logDebug2(" AFTER RECV_INV");
		if(iInv_flag == TRUE)
		{
			logDebug2("RECEIVE CHILD Receive child calling fReceiveInvitationPacket ");
			fReceiveInvitationPacket(iSockfd1,iLocalId);
		}
		else
		{
****/
			logDebug2("RECEIVE CHILD RECEVING NON INVITATION PACKET ");
			iRecv_bytes = RECV(iSockfd1,sRecvgen1);  

			fDeal_with_SendRecv(iRecv_bytes , iLocalId);
			logDebug2(" Returned from fDeal_with_SendRecv");

			memcpy(pHeader,sRecvgen1 + sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER)); 
			logDebug2(" CHK A");
			logDebug2(" CHK B1");

			memcpy(pTap_wrap,sRecvgen1,sizeof(struct TAP_WRAPPER));
			logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
			logDebug2("Received Seq_No = [%d]",pTap_wrap->Seq_No);
			logDebug2(" GROUPID = [%d]", iGroupid);
			logDebug2(" RECEIVED LOCALID = [%d]", iLocalId);  
			/** switch(iGroupid) **/ 

			TWIDDLE(pTap_wrap->Seq_No);

			/*** TAP Reg Changes ***/
			iRecieveSeq ++;
			iSeq_No =  iRecieveSeq ;
			/*** TAP Reg Changes ***/

			logDebug2(" RECEIVE CHILD Required Seq_No is =[%d]",iSeq_No);
/****
			if(iSeq_No != pTap_wrap->Seq_No)
			{
				logDebug2("FATAL::there is sequence no mismatch...Possibly packet drop closing TAP BOX Connection.");


				memset(sError,NULL,SIZE);
				strcpy(sError,"ERROR::sequence no mismatch ");
				logFatal("EquNseConTAP.pc %s",sError);
				fExit(ERROR);
			}
****/
			logDebug2("RECEIVE CHILD Passed Seq No Check...");

			TWIDDLE(pHeader->iMsgCode);
			TWIDDLE(pHeader->iMsgLength);
			
			if(pHeader->iMsgCode == TC_EQU_NSE_ORD_ENT_ERR_RSP_TM || pHeader->iMsgCode == TC_EQU_NSE_ORD_MOD_ERR_RSP_TM || pHeader->iMsgCode == TC_EQU_NSE_ORD_CAN_ERR_RSP_TM  || pHeader->iMsgCode == TC_EQU_NSE_ORD_ENT_CON_RSP_TM || pHeader->iMsgCode == TC_EQU_NSE_ORD_MOD_CON_RSP_TM || pHeader->iMsgCode == TC_EQU_NSE_ORD_CAN_CON_RSP_TM || pHeader->iMsgCode == TC_EQU_NSE_MKT_TO_LMT_RSP_TM )
                        {

                                iBlen = sizeof(struct NNF_ORD_RESPONSE_TM);
                        }
                        else if(pHeader->iMsgCode == TC_EQU_NSE_TRADE_RSP_TM)
                        {
                                iBlen = sizeof(struct NNF_TRADE_RESP_TM);
                        }
                        else
                        {
                                iBlen = pHeader->iMsgLength ;
                        }

			logDebug2("TWIDDLE iBlen :%d:",iBlen);
			memset(cBdata,'\0',iBlen);
			memcpy(cBdata,sRecvgen1+sizeof(struct TAP_WRAPPER) ,iBlen);
			memcpy(sRecvgen1,cBdata,iBlen);
			logDebug2("RECEIVE CHILD Computing the digest ...");
			memset(sDigest,'\0',sizeof(sDigest));

			fMD5_Digest(sDigest,cBdata,iBlen)  ;

			logDebug2("2. YK pTap_wrap->digest :%s:  YK Blen :%d: YK digest :%s: YK bdate :%s:", pTap_wrap->digest, iBlen, sDigest, cBdata);
			logDebug2("2. YK strlen(pTap_wrap->digest) :%d: YK strlen(digest) :%d:", strlen(pTap_wrap->digest), strlen(sDigest));
			if(strncmp(sDigest,pTap_wrap->digest,16) !=0)
			{
				logDebug2("FATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection.");
				memset(sError,NULL,SIZE);
				strcpy(sError,"ERROR::Mismatch in MD5 Checksum ");
				logFatal("EquNseConTAP.pc %s",sError);
				fExit(ERROR);
			}

			logDebug2("Passed MD5 Checksum Check...");
			logDebug2(" The transcode recvd 5555 is %d ",pHeader->iMsgCode);
			logDebug2(" The mesg length recvd 4444  is %d ",pHeader->iMsgLength);
			/******		if (get_mesg_or_sError_nse(sRecvgen1) == TRUE )
			  {
			  logDebug2("\n\n RETURN VALUE FROM GET_MESG IS TRUE ");
			  continue;
			  }		*****ALOKKK*/
			logDebug2("ReceiveReplyPacket:  Got the TransCode 6666 ALOK TESTING DOWNLOAD :%d",pHeader->iMsgCode);


			TWIDDLE(pHeader->iErrorCode);
			logDebug2("ReceiveReplyPacket:  Got the TransCode 6666 ALOK TESTING DOWNLOAD :%d",pHeader->iMsgCode);
			logDebug2("ReceiveReplyPacket:  Got the iErrorCode 6666 ALOK TESTING DOWNLOAD :%d",pHeader->iErrorCode);
			iTempMsgCode = pHeader->iMsgCode;
			memset(sErrorStr,'\0',DB_REASON_DESC_LEN);
			/**/
			TWIDDLE(pHeader->iMsgCode);
			TWIDDLE(pHeader->iMsgCode);
			TWIDDLE(pHeader->iErrorCode);
			/**/			
			//switch(pHeader->iMsgCode)
			switch(iTempMsgCode)
			{
				case TC_NSE_SYS_INFO_RESP: 

					logDebug2(" STREAM in SYSINFO :[%d] Transcode: [%d]",*(pHeader->sAlphaSplit),pHeader->iMsgCode);
					iTotalStream = *(pHeader->sAlphaSplit);
					logDebug2(" Total No of STREAMS  :[%d] ",iTotalStream );

					for(j=1; j<= iTotalStream ;j++)
					{
						Msg_Dow_Data[j].Stream_Id  = j ;
						Msg_Dow_Data[j].Stream_Flag= 1;
						Msg_Dow_Data[j].TimeStamp1 = 0;
						Msg_Dow_Data[j].TimeStamp2 = 0;
					}

					iLog_result = fRecvsysinfo( sRecvgen1 );

					fDeal_with_LogResult(iLog_result); 

					if ( iLog_result == TRUE )
					{
						logDebug2("RECEIVE CHILD  RAISING SIGNAL 1 AFTER SYS_INFO_RESP");
						iDownkill = -1;
						iDownkill = kill( iPPid , SIGUSR1 );

						if ( iDownkill < 0 )
						{
							memset(sError,NULL,SIZE);
							strcpy(sError,strerror(errno));
							logFatal("CNseConAdap %s",sError);
							exit(ERROR);
						}
					}
					break;
					/* */

				case TC_NSE_PARTIAL_SYS_INFO_RESP: 

					logDebug2("CNseConAdap MARKET STATUS MISMATCH ");

					iLog_result = fRecvsysinfo( sRecvgen1 ); 
					if ( iLog_result == TRUE )
					{
						logDebug2("RECEIVE CHILD  RAISING SIGNAL 2 AFTER PARTIAL_SYS_INFO_RESP");
						iDownkill = -1;
						iDownkill = kill( iPPid , SIGUSR1);
						if ( iDownkill < 0 )
						{
							memset(sError,NULL,SIZE);
							strcpy(sError,strerror(errno));
							logFatal("CNseConAdap.pc %s",sError);
							exit(ERROR);
						}
					}
					break;
					/**/

				case TC_NSE_UPDATE_LDB_HEADER_RESP: 

					logDebug2("CNseConAdap Update Database Header Messg :: recieved ");

					iTimeStampUpdateFlag =FALSE;
					break;


				case TC_NSE_UPDATE_LDB_DATA_RESP: 
					/***************
					 *			memcpy(udresponse,sRecvgen1,sizeof(struct NNF_UPDATE_LDB_DATA_RESP)); 
					 TWIDDLE(udresponse->sInnerHeader.iMsgLength);
					 TWIDDLE(udresponse->sInnerHeader.iMsgCode);   

					 logDebug2("\n iMsgCode of InnerTransCode is %d ",udresponse->sInnerHeader.iMsgCode);
					 iQueue_bytes = udresponse->sInnerHeader.iMsgLength;
					 sWrite_mess = sRecvgen1 + sizeof(NNF_HEADER);   
					 iPut_in_queue = TRUE; ********************/
					break;

				case TC_NSE_UPDATE_LDB_TRAILER_RESP: 
					logDebug2("RECEIVE CHILD  Un Lock on ProcessDataLock1 ");
					UnLockShm( ProcessDataLock1 );
					logDebug2("RECEIVE CHILD  Un Locked on ProcessDataLock1 ");
					logDebug2("CNseConAdap Update Database Trailer Messg :: recieved ");
					logDebug2("RECEIVE CHILD  RAISING SIGNAL 1 AFTER UPDATE_LDB_TRAILER");
					iDownkill = -1;
					iDownkill = kill( iPPid , SIGUSR1 );
					if ( iDownkill < 0 )
					{
						memset(sError,NULL,SIZE);
						strcpy(sError,strerror(errno));
						logFatal("CNseConAdap %s",sError);
						exit(ERROR);
					}
					break;

				case TC_NSE_MSG_DOWNLOAD_START_RESP: 

					logDebug2("CNseConAdap Message Area Header Messg :: recieved ");

					break;

				case TC_NSE_MSG_DOWNLOAD_DATA_RESP: 
					memcpy(pMdresponse,sRecvgen1,sizeof(struct NNF_MSG_DOWNLOAD_DATA_RESP)); 
					TWIDDLE(pMdresponse->pInnerHeader.iMsgLength);
					TWIDDLE(pMdresponse->pInnerHeader.iMsgCode); 
					//memcpy(&pTempTimeStamp,(pMdresponse->sInnerHeader.sTimeStamp2),DATE_TIME_LEN);

					logDebug2(" The inner transcode in message area download recvd is %d ",pMdresponse->pInnerHeader.iMsgCode);
					if (    pMdresponse->pInnerHeader.iMsgCode == 2073 || pMdresponse->pInnerHeader.iMsgCode == 2074 ||
							pMdresponse->pInnerHeader.iMsgCode == 2075 || pMdresponse->pInnerHeader.iMsgCode == 2072 ||
							pMdresponse->pInnerHeader.iMsgCode == 2231 || pMdresponse->pInnerHeader.iMsgCode == 2170 ||
							pMdresponse->pInnerHeader.iMsgCode == 2042 || pMdresponse->pInnerHeader.iMsgCode == 2222 ||
							pMdresponse->pInnerHeader.iMsgCode == 3034 || pMdresponse->pInnerHeader.iMsgCode == 3037 ||
							pMdresponse->pInnerHeader.iMsgCode == 3044 || pMdresponse->pInnerHeader.iMsgCode == 3047 ||
							pMdresponse->pInnerHeader.iMsgCode == 2012 || pMdresponse->pInnerHeader.iMsgCode == 2076 ||
							pMdresponse->pInnerHeader.iMsgCode == 2009 || pMdresponse->pInnerHeader.iMsgCode == 2008 ||
							pMdresponse->pInnerHeader.iMsgCode ==9002  )
					{
						logDebug2("----------PACKET DATA RECEIVED IN NORMAL Packet ------------");

						iPut_in_queue = TRUE;
						iQueue_bytes = pMdresponse->pInnerHeader.iMsgLength;
						sWrite_mess = sRecvgen1 + sizeof(struct NNF_HEADER);
						if(pMdresponse->pInnerHeader.iMsgCode != 2222 )
						{

							memset( ((struct NNF_ORDER_ENTRY *)sWrite_mess)->sRemarks ,' ',OE_REMARKS_LEN);
							strncpy( ((struct NNF_ORDER_ENTRY *)sWrite_mess)->sRemarks,"Exch Download",1);
						}
					}
					else
					{
						logDebug2("This is in else ");
						iPut_in_queue = FALSE;
						iTimeStampUpdateFlag = FALSE;
					}


					break;

				case TC_NSE_MSG_DOWNLOAD_END_RESP: 
					logDebug2("EquNseConnect.pc Message Area trailer Messg :: recieved ");
					iTimeStampUpdateFlag =TRUE;

					iDowCounter++ ;
					logDebug2(" MSG_DOWNLOAD Trailer Resp for STREAM :[%d] TotalStream :%d ",*(pHeader->sAlphaSplit), iTotalStream);

					if( iTotalStream == iDowCounter )
					{
						logDebug2("RECEIVE CHILD  RAISING SIGNAL 2 AFTER MSG_DOWNLOAD_END");
						iDownloadFlag = TRUE ; 

						iDownkill = -1;
						iDownkill = kill( iPPid , SIGUSR2 );
						if ( iDownkill < 0 )
						{ 
							memset(sError,NULL,SIZE);
							strcpy(sError,strerror(errno));
							logFatal("CNseConAdap %s",sError);
							exit(ERROR);
						}
					}
					break;

				case TC_DRV_NSE_PORTFOLIO_RESP :

					logDebug2("ReceiveReplyPackets :Received Portfolio Resp Packet");
					pPortfolioresp = (struct NNF_PORTFOLIO_RESP *)sRecvgen1;  
					if (pPortfolioresp->cMoreRecords == 'N')
					{
						iDownkill = -1;
						iDownkill = kill( iPPid,SIGUSR1);
						logDebug2("ReceiveReplyPackets: Sent the signal :%d",SIGUSR1);
						if ( iDownkill < 0 )
						{
							memset(sError,NULL,SIZE);
							strcpy(sError,strerror(errno));
							logFatal("CNseConAdap",sError);
							exit(ERROR);
						}
					}
					iPut_in_queue = TRUE;
					TWIDDLE(pPortfolioresp->sHeader.iMsgLength);  
					iQueue_bytes = pPortfolioresp->sHeader.iMsgLength;
					sWrite_mess = sRecvgen1;  
					break;

				case TC_EQU_NSE_ORD_ENT_ERR_RSP_TM:
                                case TC_EQU_NSE_ORD_MOD_ERR_RSP_TM:
                                case TC_EQU_NSE_ORD_CAN_ERR_RSP_TM:
                                case TC_EQU_NSE_ORD_ENT_CON_RSP_TM:
                                case TC_EQU_NSE_ORD_MOD_CON_RSP_TM:
                                case TC_EQU_NSE_ORD_CAN_CON_RSP_TM:
                                case TC_EQU_NSE_MKT_TO_LMT_RSP_TM:
                                        memcpy(pOrdRsp,sRecvgen1,sizeof(struct NNF_ORD_RESPONSE_TM));
		
					TWIDDLE(pOrdRsp->iTransCode);
                                        TWIDDLE(pOrdRsp->iErrorCode);
                                        TWIDDLE(pOrdRsp->fOrderNum);
					TWIDDLE(pOrdRsp->iLastActiRef);
					TWIDDLE(pOrdRsp->fTimeStamp1);


                                        logDebug2("iMsg Code :%d: ",pOrdRsp->iTransCode);
                                        logDebug2("iError Code e :%d: ",pOrdRsp->iErrorCode);
                                        logDebug2("iExchOrdNumer :%lf: ",pOrdRsp->fOrderNum);
					logDebug2("iLastActiRef :%d: ",pOrdRsp->iLastActiRef);
					logDebug2("fTimeStamp1 :%lf: ",pOrdRsp->fTimeStamp1);
                                        logDebug2("cTimeStamp2 :%c: ",pOrdRsp->cTimeStamp2);
                                        memcpy(&pDowTime,(CHAR *)&pOrdRsp->fTimeStamp1,NNF_DATE_TIME_LEN);
                                        logDebug2("Normal PKT STREAM = %c Time1= %u,Time2=%u ",pOrdRsp->cTimeStamp2, pDowTime.iLogTime1,pDowTime.iLogTime2);
                                        fUpdateTimeStamp(&pDowTime,pOrdRsp->cTimeStamp2);	
                                        TWIDDLE(((struct NNF_HEADER *)sRecvgen1)->iMsgCode);

                                        iWrite_status = WriteMsgQ(iQidnormal,sRecvgen1,sizeof(struct NNF_ORD_RESPONSE_TM),1);

                                        if ( iWrite_status == ERROR)
                                        {
						fExit(ERROR);
                                        }
				break;
                                case TC_EQU_NSE_TRADE_RSP_TM:
                                        logDebug1("This is trade Msg code :%d:",pHeader->iMsgCode);
                                        TWIDDLE(((struct NNF_HEADER *)sRecvgen1)->iMsgCode);

                                        iWrite_status = WriteMsgQ(iQidnormal,sRecvgen1,sizeof(struct NNF_TRADE_RESP_TM),1);

                                        if ( iWrite_status == ERROR)
                                        {
						fExit(ERROR);
                                        }
                                break;
				case    TC_EQU_NSE_BOX_SIGN_OFF_TM:
                                        memcpy(pBoxSignOff,sRecvgen1,sizeof(struct NNF_BOX_SIGN_OFF_TM));
                                        TWIDDLE(pBoxSignOff->pHeader.iErrorCode);
                                        TWIDDLE(pBoxSignOff->iBoxId);
                                        logInfo("Error Code in Box Sign Off server :%d: for Box :%d:",pBoxSignOff->pHeader.iErrorCode,pBoxSignOff->iBoxId);
                                        fFetchErrStr(pBoxSignOff->pHeader.iErrorCode,&sErrorStr);
					// Printing for monitoring purpose @NItish
                                        logTimestamp(":%s: BOX SIGNED OFF BY EXCHANGE WITH ERROR :%s: FOR BOX ID :%d:",KEY_WORD_MONITORING,sErrorStr,pBoxSignOff->iBoxId);
                                        fExit(ERROR);


                                        break;		

				default : 
					if ( pHeader->iMsgCode == 2073 || pHeader->iMsgCode == 2074 || pHeader->iMsgCode == 2075 || \
							pHeader->iMsgCode == 2072 || pHeader->iMsgCode == 2231 || pHeader->iMsgCode == 2170 || \
							pHeader->iMsgCode == 2042 || pHeader->iMsgCode == 9002 || pHeader->iMsgCode == 3034 || \
							pHeader->iMsgCode == 3037 || pHeader->iMsgCode == 3044 || pHeader->iMsgCode == 3047 || \
							pHeader->iMsgCode == 2012 || pHeader->iMsgCode == 2076 || pHeader->iMsgCode == 2009 || \
							pHeader->iMsgCode == 2008 || pHeader->iMsgCode == 2009 || pHeader->iMsgCode == 2222 || \
							pHeader->iMsgCode == 2212 || pHeader->iMsgCode == 2124 || pHeader->iMsgCode == 2136 || \
							pHeader->iMsgCode == 2130 || pHeader->iMsgCode == 2154 || pHeader->iMsgCode == 2133 || \
							pHeader->iMsgCode == 2127  \
					   )
					{
						logDebug2("----------PACKET DATA RECEIVED IN NORMAL Packet ------------");
						/****      ConvertSeqNO(sRecvgen1, Seq_No);
						  logDebug2("\n\t--------------TempSeqNo [%s]\n",Seq_No);***/
						/**memcpy ( ((struct NNF_ORDER_ENTRY *)sRecvgen)->Remarks ,';',DELTA_REMARKS);  Commented as Junk Values sending to TWS ****/
						if(pHeader->iMsgCode != 2222 || pHeader->iMsgCode != 2212 )
						{
							memset( ((struct NNF_ORDER_ENTRY *)sRecvgen1)->sRemarks ,' ',ORDER_REMARKS_LEN);
							strncpy( ((struct NNF_ORDER_ENTRY *)sRecvgen1)->sRemarks,";",1);
						}
						iPut_in_queue = TRUE;
						//                                memcpy ( ((struct NNF_ORDER_ENTRY *)sRecvgen1)->Remarks + DELTA_REMARKS,Seq_No, strlen(Seq_No));
					}

					memcpy(&pDowTime,(pHeader->sTimeStamp3),NNF_DATE_TIME_LEN);
					logDebug2 (" pDowTime :%u :%u", pDowTime.iLogTime1, pDowTime.iLogTime2);
					logDebug2(" Normal Order :[%d] , [%s]", *(pHeader->sTimeStamp3), pHeader->sTimeStamp3);
					logDebug2(" Value :%d", *(pHeader->sAlphaSplit));

					memcpy(&pTempTimeStamp,(pHeader->sTimeStamp2),NNF_DATE_TIME_LEN);
					iStream = pDowTime.iLogTime2;

					logDebug2(" Normal PKT STREAM = %d Time1= %u,Time2=%u  ",iStream, pTempTimeStamp.iLogTime1,pTempTimeStamp.iLogTime2);

					Msg_Dow_Data[iStream].Stream_Id  =iStream ;
					Msg_Dow_Data[iStream].TimeStamp1 = pTempTimeStamp.iLogTime1 ;
					Msg_Dow_Data[iStream].TimeStamp2 = pTempTimeStamp.iLogTime2 ;	
					/************
					  memcpy(&pDowTime,(pHeader->sTimeStamp3),DATE_TIME_LEN);
					  logDebug2 ("\n pDowTime :%u :%u", pDowTime.iLogTime1, pDowTime.iLogTime2);
					  logDebug2("\n Normal Order :[%d] , [%s]", *(pHeader->sTimeStamp3), pHeader->sTimeStamp3);
					  logDebug2("\n Value :%d", *(pHeader->sAlphaSplit));

					  memcpy(&pTempTimeStamp,(pHeader->sTimeStamp2),DATE_TIME_LEN);
					  Stream = pDowTime.iLogTime2;
					  logDebug2("\n Normal PKT STREAM = %d Time1= %u,Time2=%u \n",Stream, pTempTimeStamp.iLogTime1,pTempTimeStamp.iLogTime2);

					  Msg_Dow_Data[Stream].Stream_Id  =Stream ;
					  Msg_Dow_Data[Stream].TimeStamp1 = pTempTimeStamp.iLogTime1 ;
					  Msg_Dow_Data[Stream].sTimeStamp2 = pTempTimeStamp.iLogTime2 ;
					 **************/
					logDebug2(" Alok Packet number :[%d]::Value of DownloadFlag :[%d]",iIndexrec,iDownloadFlag);
					//					if ( iIndexrec % MAX_NO_UPDATE == 0  && iDownloadFlag == TRUE )
					fUpdateTimeStamp(&pDowTime,pHeader->sAlphaSplit[0]);


					sWrite_mess = sRecvgen1;  
					//iQueue_bytes = iRecv_bytes;
					iQueue_bytes = pHeader->iMsgLength;;
					logDebug2(" Alok here testing with nitish Queue_bytes :%d: Recv_bytes :%d: ",iQueue_bytes,iRecv_bytes);

					break;
			};
			if(iPut_in_queue == TRUE)
			{
				logDebug2(" Before Writing to the Queue") ;
				iIndexrec = iIndexrec +1;
				logDebug2(" Total No of Packets: counter %d ",iIndexrec);

				/***		iWrite_status = WriteMsgQ(iQidnormal,(CHAR *)&sWrite_mess,Queue_bytes,1);*****//**ALOK this is not working ***/

				//TWIDDLE(pHeader->iMsgCode);
				logDebug2("WriteCore 3");
				//TWIDDLE(pHeader->iMsgLength);
				logDebug2("WriteCore 4");
				TWIDDLE(((struct NNF_HEADER *)sWrite_mess)->iMsgCode);
				TWIDDLE(((struct NNF_HEADER *)sWrite_mess)->iMsgLength);

				logDebug2("pHeader->iMsgCode :%d:",((struct NNF_HEADER *)sWrite_mess)->iMsgCode);
				logDebug2("pHeader->iMsgLength	:%d:",((struct NNF_HEADER *)sWrite_mess)->iMsgLength);

				iWrite_status = WriteMsgQ(iQidnormal,sWrite_mess,iQueue_bytes,1);
				logDebug2("AfterWriting to the Queue........");
				if ( iWrite_status == ERROR)
				{
					memset(sError,NULL,SIZE);
					strcpy(sError,"ERROR in WriteMsgQ function ");
					logFatal("BGSEconnect.pc %s",sError);
					fExit(ERROR);
				}
				logDebug2(" Writing in queue %d Bytes: %d",iQidnormal , iQueue_bytes );
			}

			if (iTimeStampUpdateFlag == TRUE)  
			{
				iTempTime1 = pTempTimeStamp.iLogTime1;
				iTempTime2 = pTempTimeStamp.iLogTime2;
				logDebug2("***LastMesgTime1= %u,LastMesgTime2=%u",iTempTime1,iTempTime2 );
			}
		//} 
	}   /* ------- while loop ends -----------------------*/

	fGetTime(sProgTime);
	logDebug2("[%s] IST Recieve Reply packets function ENDS---",sProgTime);
	logTimestamp("Exit : fReceiveReplyPackets");	
}		/* -- Recieve Reply packets function --- checked on 15-4-2000 -- */


int 	fHandleInvitationPacket (LONG32 iSockfd1,LONG32 iGroupid)
{
	logTimestamp("Entry : fHandleInvitationPacket");
/***
	//	fd_set	ActiveSocketSet;
	//	fd_set	ReadSocketSet;
	//	LONG32 	MaxSocketId;
	CHAR  	sInvPacket[NSE_PACKET_SIZE];
	LONG32	iRecv_bytes;
	LONG32  iSeq_No;
	//	LONG32 	Retval;
	LONG32 	iLen;
	INT16 	iMsgCode;
	LONG32 	iPPid,iDownkill;
	SHORT 	iCount;
	LONG32 	iGid;
	CHAR 	sProgTime[40];
	memset(sProgTime,'\0',40);

	struct	DRVInvitationCount	*pInvcount;

	iGid = iGroupid -1;

	fGetTime(sProgTime);

	logDebug2("HandleInvitationPacket:Invitation Packet Called on [%s] IST",sProgTime);
	iRecv_bytes = RECV(iSockfd1,sInvPacket);
	if( iRecv_bytes <= 0 )
	{
		return FALSE;
	}
	else
	{
		logDebug2("fReceiveInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode);  	
		TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode);
		TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgLength);
		TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->invitation_count);

		logDebug2("fReceiveInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode);  	
		if(((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode == TC_DRV_NSE_INVITATION_REQ)
		{
			logDebug2("fReceiveInvitationPacket Invitation Packet Received");
		}
		iLen = ((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgLength;
		iMsgCode = ((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode;

		if(iMsgCode == TC_DRV_NSE_INVITATION_REQ)
		{
			iCount = ((struct INVITATION_PACKET *)sInvPacket)->invitation_count;
			logDebug2("fReceiveInvitationPacket iCount : [%d]",iCount);
			LockShm(CurrInvitatnCntShm);
			pInvcount = (struct DRVInvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

			if ( *( (LONG32 *) pInvcount) == ERROR )
			{
				logDebug2 (" Error in Creating Shm");
				exit(1);
			}
			pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount = pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount + iCount;
			logDebug2("pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount = [%d]",pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount);

			if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
			{
				logDebug2 (" Error in Closing Shm");
				exit(1);
			}
			UnLockShm(CurrInvitatnCntShm);

			iRecieveSeq ++;
			iSeq_No =  iRecieveSeq ;

			iCounterTotalInvite++;
			fGetTime(sProgTime);
****/
			/**                flogDebug2(fpOrderNum,"\niCounterTotalInvite [%d] tap_Seq [%d] tap_Mes_Len [%d] nnf_len [%d] sMsgcode[%d] iCount [%d] Time[%s]",iCounterTotalInvite,Seq_No,iRecv_bytes,iLen-2,iMsgCode,iCount,sProgTime);
			  fflush(fpOrderNum);
			 **/
/***
			logDebug2("Received Invitation Packet :- [%d] ",iSeq_No);
		}
		else
		{
			return FALSE;
		}
	}
	logTimestamp("Exit : fHandleInvitationPacket");
***/
	return TRUE;
}


void	fDeal_with_LogResult(LONG32 iLog_result)
{
	logTimestamp("Entry : fDeal_with_LogResult");

	if (iLog_result == TRUE )
	{
#ifdef DBG
		logDebug2(" CNseConAdap SUCCESS ");
#endif
	}
	else
	{
#ifdef DBG
		logDebug2(" CNseConAdap FAILED ");
#endif
	}
#ifdef DBG
	logDebug2(" CNseConAdap The Log_result is %d ",iLog_result);
#endif
	logTimestamp("Exit : fDeal_with_LogResult");
}


void	fDeal_with_Socket(LONG32 iSockfd)
{
	logTimestamp("Entry : fDeal_with_Socket");
	if (iSockfd < 0)
	{
#ifdef DBG
		logDebug2("CNseConAdap Fatal Socket Error :: closed ");
#endif
		exit(ERROR);
	}
	else
	{
#ifdef DBG
		logDebug2("CNseConAdap Socket connected :: socket id %d ",iSockfd);
#endif
	}
	logTimestamp("Exit : fDeal_with_Socket");
}

void	fDeal_with_SendRecv(LONG32 iRecv_bytes, LONG32 iGroupid)
{
	/*****
	  EXEC SQL BEGIN DECLARE SECTION;

	  VARCHAR exchId[EXCHANGE_LEN];
	  CHAR    drvFlg = 'Y';
	  EXEC SQL END DECLARE SECTION;
	 *****/
	logTimestamp("Entry : fDeal_with_SendRecv");	

	LONG32 iSql_groupid;
	iSql_groupid = iGroupid;

	//    VMEMCPY(exchId,exchange,EXCHANGE_LEN);


	if ( iRecv_bytes <= 0 )
	{

#ifdef DBG
		logDebug2("CNseConAdap Send / Recv Error or socket close requested....%d bytes recvd  ",iRecv_bytes);
		logDebug2("Group id Recvd in fDeal_with_SendRecv is %d ", iGroupid );
		logDebug2("Sql variable groupid is %d ", iSql_groupid );
#endif


		/* This To Indicate Front end users, that exch connection is lost. */ /* adarsh */
		/******   
		  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
		  SET  EAM_LOGON_STATUS = 'N'
		  WHERE EAM_EXM_EXCH_ID = 'NSE'
		  AND EAM_GROUP_ID = to_char(:iSql_groupid)
		  AND EAM_DRV_FLAG = 'Y';

		  if (sqlca.sqlcode == -1036)
		  {
		  logDebug2("\n Inside 1036 sError ************** ");
		  EXEC SQL UPDATE EXCH_ADMINISTRATION_MASTER
		  SET  EAM_LOGON_STATUS = 'N'
		  WHERE EAM_EXM_EXCH_ID = 'NSE'
		  AND EAM_GROUP_ID = to_char(:iSql_groupid)
		  AND EAM_DRV_FLAG = 'Y';

		  if ( sqlca.sqlcode == 0 )
		  {
		  logDebug2("\n&&&&&&&&&& Changed Exchange Status to N &&&&&&&&&&&&");
		  EXEC SQL COMMIT;
		  }

		  } 
		  else if (sqlca.sqlcode !=0) 
		  {	
		  logDebug2("EXCH_ADMINISTRATION_MASTER N update sql sError : %d\n",sqlca.sqlcode);
		  logDebug2("\nSql variable groupid is %d ", iSql_groupid );
		  }
		  else
		  {
		  EXEC SQL COMMIT; 
		  }*****/
		//		fUpdateConnectStatus(NSE_CUR_DOWN, iGroupid );
		fConnectUpdt(NSE_CUR_DOWN, iGroupid,0 );

		fSend_exch_down_nse( iGroupid );

		fExit(0);
	}


#ifdef DBG
	logDebug2("CNseConAdap the no.of bytes sent / recieved are %d ",iRecv_bytes);	
#endif
	logTimestamp("Exit : fDeal_with_SendRecv");
}

void	fExit( LONG32 iError)
{
	logTimestamp("Entry : fExit");

	logDebug2("CNseConAdap In exit Fun");
	kill (getppid(),SIGTERM);
	//exit(iError);

	logTimestamp("Exit : fExit");
}


void 	fReceiveInvitationPacket (LONG32 iSockfd1,LONG32 iGroupid)
{
	logTimestamp("Entry : fReceiveInvitationPacket");
/****
	//	fd_set	ActiveSocketSet;
	//	fd_set	ReadSocketSet;
	//	LONG32  MaxSocketId;
	CHAR   	sInvPacket[NSE_PACKET_SIZE];
	LONG32  iRecv_bytes;
	LONG32  iSeq_No;
	//	LONG32 	Retval;
	LONG32 	iLen;
	INT16 	iMsgCode;
	LONG32 	iPPid,iDownkill;
	SHORT 	iCount;
	LONG32 	iGid;

	struct 	DRVInvitationCount	*pInvcount;


	iGid = iGroupid -1;


	logDebug2("============================ Waiting for Invitation Packet ============================");
	iRecv_bytes = RECV(iSockfd1,sInvPacket);
	logDebug2("fReceiveInvitationPacket MSG_CODE : [%d]",((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode);
	TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode);
	TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgLength);
	TWIDDLE(((struct INVITATION_PACKET *)sInvPacket)->invitation_count);

	if(((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode == TC_DRV_NSE_INVITATION_REQ)
	{
		logDebug2("fReceiveInvitationPacket Invitation Packet Received");
	}

	fDeal_with_SendRecv( iRecv_bytes , iGroupid );

	iLen = ((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgLength;
	iMsgCode = ((struct INVITATION_PACKET *)sInvPacket)->sHeader.iMsgCode;

	if(iMsgCode == TC_DRV_NSE_INVITATION_REQ)
	{
		iCount = ((struct INVITATION_PACKET *)sInvPacket)->invitation_count;
		logDebug2("fReceiveInvitationPacket iCount : [%d]",iCount);
		logDebug2("Gid = [%d]",iGid); 

		LockShm(CurrInvitatnCntShm);
		pInvcount = (struct DRVInvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

		if ( *( (LONG32 *) pInvcount) == ERROR )
		{
			logDebug2 (" Error in Creating Shm ");
			exit(1);
		}
		pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount = pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount + iCount;
		logDebug2("pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount = [%d]",pInvcount->DRVInvCount_group[iGid].DRVInvPacketCount);

		if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
		{
			logDebug2 (" Error in Closing Shm");
			exit(1);
		}
		UnLockShm(CurrInvitatnCntShm);
		iRecieveSeq ++;
		iSeq_No =  iRecieveSeq ;


		logDebug2("============================ Received Invitation Packet : [%d] ============================",iSeq_No);

	}
****/
	logTimestamp("Exit : fReceiveInvitationPacket");
}


void	fReduceInvitationCount(LONG32 iGid)
{
	logTimestamp("Entry : fReduceInvitationCount");	
/***
	LONG32	iGroupid;
	struct 	DRVInvitationCount 	*pInvcount;
	iGroupid = iGid - 1;
	logDebug2("groupid = [%d] iGid = [%d]",iGroupid,iGid);
	LockShm(CurrInvitatnCntShm);
	pInvcount = (struct DRVInvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

	if ( *( (LONG32 *) pInvcount) == ERROR )
	{
		logDebug2 (" Error in Creating Shm ");
		perror(" shmdt:");
		exit(1);
	}
	logDebug2("Count Before #### %d ",pInvcount->DRVInvCount_group[iGroupid].DRVInvPacketCount);

	pInvcount->DRVInvCount_group[iGroupid].DRVInvPacketCount--;

	logDebug2(" Count After #### %d ",pInvcount->DRVInvCount_group[iGroupid].DRVInvPacketCount);

	if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
	{
		logDebug2 (" Error in Closing Shm ");
		exit(1);
	}
	UnLockShm(CurrInvitatnCntShm);
***/
	logTimestamp("Exit : fReduceInvitationCount");
}

void 	fGetInvitationPacketCount(LONG32 * iInvPacketCount,LONG32 iGid)
{
	logTimestamp("Entry : fGetInvitationPacketCount");
/***
	struct DRVInvitationCount 	*pInvcount;
	LONG32 iGroupid;
	iGroupid = iGid -1;

	LockShm(CurrInvitatnCntShm);
	pInvcount = (struct DRVInvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

	if ( *( (LONG32 *) pInvcount) == ERROR )
	{
		logDebug2 (" Error in Creating Shm ");
		exit(1);
	}

	*iInvPacketCount = pInvcount->DRVInvCount_group[iGroupid].DRVInvPacketCount;

	if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
	{
		logDebug2 (" Error in Closing Shm");
		exit(1);
	}
	UnLockShm(CurrInvitatnCntShm);
****/
	logTimestamp("Exit : fGetInvitationPacketCount");
}
/************************
  fGetTime(char *sProgTime)
  {
  time_t currentTime;
  struct tm *localTm;
  currentTime = time(NULL);
  localTm = localtime(&currentTime);
  memset(sProgTime,'\0',SYS_TIME_LEN);
  strftime(sProgTime,SYS_TIME_LEN,"SYSTEM TIME:-%D-%T",localTm);
  } **************************/
void 	fInitSharedMemory(LONG32 iGid )
{
	logTimestamp("Entry : fInitSharedMemory");
/****
	struct	DRVInvitationCount	*pInvcount;
	LONG32 	iGroupid;
	iGroupid = iGid -1;
	LockShm(CurrInvitatnCntShm);
	pInvcount = (struct DRVInvitationCount *)OpenSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE);

	if ( *( (LONG32 *) pInvcount) == ERROR )
	{
		logDebug2 (" Error in Creating Shm");
		perror("Creating Shm failed");
		//		CloseSharedMemory( (void *)ptr);
		logDebug2("Closing Shared Memory");
		CloseSharedMemory( (void *)pInvcount);
		UnLockShm( CurrInvitatnCntShm);
		exit(1);
	}

	pInvcount->DRVInvCount_group[iGroupid].DRVInvPacketCount=0;
	logDebug2(" $$$$$ SHARED MEMORY INITIAL VALUE %d $$$$ ",pInvcount->DRVInvCount_group[iGroupid].DRVInvPacketCount);

	if ( CloseSharedMemory( (void * ) pInvcount ) == ERROR )
	{
		logDebug2 (" Error in Closing Shm");
		exit(1);
	}
	UnLockShm(CurrInvitatnCntShm);
***/
	logTimestamp("Exit : fInitSharedMemory");
}



/**** ADDITION ENDS HERE ****/	

/**** TAP Reg Changes *****/

/*****
  void	fUpdateTimeStamp( )
  {
  logTimestamp("Entry : fUpdateTimeStamp ");

  SHORT	j;

  EXEC SQL BEGIN DECLARE SECTION;
  LONG32   iGroupid=0;
  SHORT    StreamId =0;
  ULONG32  Time1 =0;
  ULONG32  Time2 =0 ;
  VARCHAR  exchId[EXCHANGE_LEN];
  CHAR     drvFlg ='Y';
  EXEC SQL END DECLARE SECTION;

  VMEMCPY(exchId,exchange,EXCHANGE_LEN);

  ULONG32	iTime1 =0;
  ULONG32 iTime2 =0 ;
  SHORT	iStreamId =0;
  LONG32	iGroupid=0;
  logDebug2(" GlobGroupId : %d", iGlobGroupId);
  iGroupid = iGlobGroupId;
  logDebug2("Local groupid : %d", iGroupid);

  logDebug2("===========GlobGroupId [%d]====Updating  Timestamp \n",iGroupid);
  for ( j=1 ; j <= iTotalStream; j++)
  {
  iStreamId = Msg_Dow_Data[j].Stream_Id ;
  iTime1    = Msg_Dow_Data[j].TimeStamp1 ;
  iTime2    = Msg_Dow_Data[j].TimeStamp2 ;

  logDebug2("StreamId : %d Time1 :%u Time2 :%u ", iStreamId, iTime1, iTime2);
 ****/
/*****
  EXEC SQL UPDATE EXCH_DOWNLOAD_DIGITAL
  SET EDD_TIMESTAMP1 = :Time1 ,
  EDD_TIMESTAMP2 =:Time2
  WHERE EDD_STREAM_ID = :StreamId
  AND EDD_EXCH_ID='NSE'
  AND EDD_DRV_FLAG='Y'
  AND EDD_GROUP_ID=:iGroupid;

  if ( sqlca.sqlcode != 0 )
  {
  logDebug2("\n Error in updating EAM for iGlobGroupId %d is %d ",iGlobGroupId,sqlca.sqlcode );
  logDebug2 ("\n\tOracle sError : %s",sqlca.sqlerrm.sqlerrmc);
  EXEC SQL ROLLBACK;
  }
  else
  EXEC SQL COMMIT;


  }
  logTimestamp("Exit : fUpdateTimeStamp ");
  }
 ***********/

void	fConvertSeqNO(CHAR *sRecvgen, CHAR *TempSeqNo)
{
	logTimestamp("Entry : fConvertSeqNO");

	//	CHAR	SeqArr2[1],
	CHAR	sSeqArr1[2];
	SHORT 	iSeq1=0,iSeq2=0;
	SHORT 	i;
	SHORT 	iTemp = 0;
	SHORT 	*iRecv_temp;
	SHORT 	sProgTime[40];
	USHORT 	d[16];
	iRecv_temp = (CHAR *)malloc(sizeof(CHAR)*NSE_PACKET_SIZE);
	fGetTime(sProgTime);
	logDebug2(" ----------In ConvertSeqNO Function:  [%s] IST------------",sProgTime);
/**
	memset( sSeqArr1,'\0',2);

	iRecv_temp = sRecvgen;
	d[0]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b1 ;
	d[1]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b2 ;
	d[2]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b3 ;
	d[3]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b4 ;
	d[4]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b5 ;
	d[5]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b6 ;
	d[6]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b7 ;
	d[7]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b8 ;
	d[8]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b9 ;
	d[9]    =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b10 ;
	d[10]   =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b11 ;
	d[11]   =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b12 ;
	d[12]   =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b13 ;
	d[13]   =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b14 ;
	d[14]   =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b15 ;
	d[15]   =           ((struct NNF_ORDER_ENTRY *)iRecv_temp)->sExchRsrvdFlds.b16 ;
	logDebug2("------------------ Seq [%s]",((struct NNF_ORDER_ENTRY *)iRecv_temp)->sSeq);

	memcpy(sSeqArr1,((struct NNF_ORDER_ENTRY *)iRecv_temp)->sSeq,2);	
	iSeq1 = atoi(sSeqArr1);
	logDebug2("-- Seq1 [%d] iSeq2 [%d] ", iSeq1,iSeq2);

	for(i=0;i<=15;i++)
	{                     
		logDebug2(" [%d] ",d[i]);
	}
	i=15;
	iTemp = d[i];

	while(i>0)
	{
		iTemp = iTemp * 2 + d[i-1];
		i--;
	}
	logDebug2("-- Temp [%d]",iTemp);
	iTemp = iTemp + iSeq1*65535 ;
	logDebug2("--- temp [%d] ",iTemp);
	sprintf( TempSeqNo, "%d"    , iTemp);
	logDebug2(" In ConvertSeqNO function TempSeqNo is : [%s]",TempSeqNo);
**/

	logTimestamp("Exit : fConvertSeqNO");			   
} 
void    fConnectUpdt(SHORT iExchConnFlg,LONG32 iGroupID,LONG32 iErrorID)
{
	logTimestamp("Entry [fConnectUpdt]");

	logDebug1("iExchConnFlg :%d: iGroupID :%d: iErrorID :%d:",iExchConnFlg,iGroupID,iErrorID);

	fUpdateConnectStatus(iExchConnFlg,iGroupID);

	if(iExchConnFlg == NSE_CUR_DOWN)
	{
		NotifyMonTool(FALSE,iErrorID);
	}
	else
	{
		NotifyMonTool(TRUE,iErrorID);
	}


	logTimestamp("Exit [fConnectUpdt]");
}

BOOL fReqForDCconnection(LONG32 iGroupid,LONG32	iPrimarySecondary)
{
	logTimestamp("Entry [fReqForDCconnection]");

        CHAR    *cSendsign;
        CHAR    *cSendBoxsign;
        CHAR    sRecvsign[NSE_PACKET_SIZE];
        CHAR    sRecvBoxsign[NSE_PACKET_SIZE];
        LONG32  iSent_bytes,iRecv_bytes,iLog_result;
        struct  NNF_HEADER      *pHeader;
        struct  NNF_HEADER      *pBoxHdrOut;
        struct  NNF_HEADER      *pBoxHdr;

        struct NNF_GR_REQUEST   *pGReq;
        struct NNF_BOX_SIGNIN_REQUEST   *pBoxSignReq;

        UCHAR   sDigest[16];
        struct  TAP_WRAPPER     *pTap_wrap;
        LONG32  iTemp_code,iTemp_size,iInvFlag;
        CHAR    sError[SIZE];
        LONG32  iSig1 = 0;
        LONG32  iInvPacketCount;
        LONG32  iInv_flag = FALSE;
        LONG32  iSeq_No;
        CHAR    *cBdata;
        CHAR    *cBoxdata;
        LONG32  iBlen;

        CHAR    *cSendsignTAP;
        CHAR    *cSendBoxSignTap;

        cSendsign =(CHAR *)malloc(sizeof(struct NNF_GR_REQUEST));
        cSendBoxsign =(CHAR *)malloc(sizeof(struct NNF_BOX_SIGNIN_REQUEST));
        pTap_wrap =(struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
        memset(pTap_wrap,' ',sizeof(struct TAP_WRAPPER));
        pHeader =(struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
        pBoxHdr =(struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
        pBoxHdrOut =(struct NNF_HEADER *)malloc(sizeof(struct NNF_HEADER ));
        memset(pHeader,' ',sizeof(struct NNF_HEADER));
        memset(pBoxHdr,' ',sizeof(struct NNF_HEADER));
        memset(pBoxHdrOut,' ',sizeof(struct NNF_HEADER));
        pGReq= (struct NNF_GR_REQUEST *)malloc(sizeof(struct NNF_GR_REQUEST ));
        memset(pGReq,' ',sizeof(struct NNF_GR_REQUEST));
        pBoxSignReq= (struct NNF_BOX_SIGNIN_REQUEST *)malloc(sizeof(struct NNF_BOX_SIGNIN_REQUEST));
        memset(pBoxSignReq,' ',sizeof(struct NNF_BOX_SIGNIN_REQUEST));
	
	logDebug2("AFTER MEMSETTING");
        cSendsignTAP = (CHAR *)malloc(sizeof(struct NNF_GR_REQUEST) + sizeof(struct TAP_WRAPPER));
        cSendBoxSignTap = (CHAR *)malloc(sizeof(struct NNF_BOX_SIGNIN_REQUEST) + sizeof(struct TAP_WRAPPER));

        iLog_result = fSendGRrequest(cSendsign,iGroupid,iPrimarySecondary);

        if( iLog_result == TRUE )
        {
                memcpy(pHeader,cSendsign,sizeof(struct NNF_HEADER));
                memcpy(pGReq,cSendsign,sizeof(struct NNF_GR_REQUEST));
                logDebug2("iBoxID= %d",pGReq->iBoxID);
                logDebug2("BrokerCode = %s",pGReq->sBrokerID);
                logDebug2("iMsgCode = [%d]",pGReq->pHeader.iMsgCode);
                logDebug2("pHeader->iMsgLength = [%d]",pHeader->iMsgLength);
                TWIDDLE(pHeader->iMsgLength);
                iTemp_size = pHeader->iMsgLength;
                iTemp_code = pHeader->iMsgCode;
                logDebug2(" pHeader->iMsgCode  : %d",pHeader->iMsgCode   );
                logDebug2(" Temp_code        : %d",iTemp_code         );
                logDebug2(" pHeader->iMsgLength : %d ", pHeader->iMsgLength )  ;
                logDebug2(" BEFORE SEND Temp_size : %d",iTemp_size )  ;

                fMD5_Digest(sDigest,cSendsign,iTemp_size )  ;

                iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);

                iTransmitSeq ++;
                pTap_wrap->Seq_No = iTransmitSeq ;

                pTap_wrap->Message_Len = iTemp_size ; /* Changed here */
                memcpy(pTap_wrap->digest,sDigest,16);


                logDebug2("pTap_wrap->Seq_No :%i:",pTap_wrap->Seq_No);
                logDebug2("pTap_wrap->Message_Len :%d:",pTap_wrap->Message_Len);

                TWIDDLE(pTap_wrap->Seq_No);
                TWIDDLE(pTap_wrap->Message_Len);
                logDebug2(" Message_Len = [%d] and Seq_No = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
                logDebug2("Twiddled Message_Len = [%d] and Twiddled Seq_No = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
		memcpy(cSendsignTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
                memcpy(cSendsignTAP + sizeof(struct TAP_WRAPPER),cSendsign ,sizeof(struct NNF_GR_REQUEST));

                iSent_bytes = SEND(iSockfd1,cSendsignTAP,iTemp_size);

                logDebug2("Sent_bytes = [%d]",iSent_bytes);
                logDebug2("SIGNON REQUEST SENT TO EXCHANGE");
                logDebug2("groupid = [%d]",iGroupid);

                fReduceInvitationCount(iGroupid);

                logDebug2(" SIGN ON REQUEST Sent to exchange ....[%d]  ",iSent_bytes);
        }

        logDebug2("WAITING TO RECEIVE " ) ;

        iRecv_bytes = RECV(iSockfd1,sRecvsign);
        if( iRecv_bytes <= 0)
        {
                iConnectionCounter++;
                logDebug2("Received <=0 byted:closing TAP BOX Connection..");
                close(iSockfd1);
                return FALSE;
        }

        memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
        logDebug2("Non Twiddle resp pHeader->iMsgLength = [%d]",pHeader->iMsgLength);
        TWIDDLE(pHeader->iMsgLength);
        logDebug2(" Twiddle resp pHeader->iMsgLength = [%d]",pHeader->iMsgLength);
        iBlen = pHeader->iMsgLength ;
        cBdata = (CHAR *)malloc(iBlen);
        memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER) ,iBlen);


        memcpy(pTap_wrap,sRecvsign,sizeof(struct TAP_WRAPPER));
        logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
        logDebug2("Received Seq_No = [%d]",pTap_wrap->Seq_No);
        TWIDDLE(pTap_wrap->Seq_No);
        TWIDDLE(pTap_wrap->Message_Len);
        logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
        logDebug2("Received Seq_No = [%d]",pTap_wrap->Seq_No);
	logDebug2("Internal Seq Number  iRecieveSeq = [%d]",iRecieveSeq);

        iSeq_No = 0;
        iRecieveSeq++;
        iSeq_No = iRecieveSeq ;

        logDebug2("Passed Seq No Check...");
        memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
        TWIDDLE(pHeader->iMsgLength);
        iBlen = pHeader->iMsgLength ;
        cBdata = (CHAR *)malloc(iBlen);

        memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER) ,iBlen);
        logDebug2("Computing the digest ...");

        fMD5_Digest(sDigest,cBdata,iBlen)  ;

        logDebug2("Blen :%d:  digest :%s:  bdate :%s:", iBlen, sDigest, cBdata);

        if(strncmp(sDigest,pTap_wrap->digest,16) !=0)
        {
                logDebug2("FATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection..");
                memset(sError,NULL,SIZE);
                strcpy(sError,"ERROR::Mismatch in MD5 Checksum ");
                logFatal("EquNseConTAP.pc %s",sError);
                fExit(ERROR);
        }

        logDebug2("Passed MD5 Checksum Check...");

        memcpy(pHeader,sRecvsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
        TWIDDLE(pHeader->iMsgLength);
        TWIDDLE(pHeader->iErrorCode);
        iBlen = pHeader->iMsgLength;
        cBdata = (CHAR *)malloc(iBlen);
        memcpy(cBdata,sRecvsign+sizeof(struct TAP_WRAPPER),iBlen);

        iGrSockFd = RecvGRresp(cBdata);

        if(iGrSockFd >= 0)
        {
		logInfo("Closing GateRouter socket iSockfd1:%d:",iSockfd1);

                close(iSockfd1);

                iLog_result = fSendBoxSignreq(cSendBoxsign,iGroupid,iPrimarySecondary);

                if( iLog_result == TRUE )
                {
                        memcpy(pBoxHdrOut,cSendBoxsign,sizeof(struct NNF_HEADER));
                        memcpy(pGReq,cSendBoxsign,sizeof(struct NNF_BOX_SIGNIN_REQUEST));
                        logDebug2("iBoxID= %d",pGReq->iBoxID);
                        logDebug2("BrokerCode = %s",pGReq->sBrokerID);
                        logDebug2("iMsgCode = [%d]",pGReq->pHeader.iMsgCode);
                        logDebug2("Box sign on Sesssion Key :%s:",((struct NNF_BOX_SIGNIN_REQUEST *)cSendBoxsign)->sSessionKey);

                        TWIDDLE(pBoxHdrOut->iMsgLength);
                        iTemp_size = pBoxHdrOut->iMsgLength;
                        iTemp_code = pBoxHdrOut->iMsgCode;
                        logDebug2(" pBoxHdrOut->iMsgCode  : %d",pBoxHdrOut->iMsgCode   );
                        logDebug2(" Temp_code        : %d",iTemp_code         );
                        logDebug2(" pBoxHdrOut->iMsgLength : %d ", pBoxHdrOut->iMsgLength )  ;
                        logDebug2(" BEFORE SEND Temp_size : %d",iTemp_size )  ;

                        fMD5_Digest(sDigest,cSendBoxsign,iTemp_size )  ;

                        iTemp_size = iTemp_size + sizeof(struct TAP_WRAPPER);

                        iTransmitSeq ++;
                        pTap_wrap->Seq_No = iTransmitSeq ;

                        memcpy(pTap_wrap->digest,sDigest,16);
                        pTap_wrap->Message_Len = iTemp_size ; /* Changed here */
                        TWIDDLE(pTap_wrap->Seq_No);
                        TWIDDLE(pTap_wrap->Message_Len);
                        logDebug2(" Message_Len = [%d] and Seq_No = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
                        logDebug2("Twiddled Message_Len = [%d] and Twiddled Seq_No = [%d]",pTap_wrap->Message_Len,pTap_wrap->Seq_No);
                        memcpy(cSendBoxSignTap,pTap_wrap,sizeof(struct TAP_WRAPPER));
                        memcpy(cSendBoxSignTap+ sizeof(struct TAP_WRAPPER),cSendBoxsign,sizeof(struct NNF_BOX_SIGNIN_REQUEST));
                        logDebug2("iGrSockFd :%d:",iGrSockFd);
                        iSent_bytes = SEND(iGrSockFd,cSendBoxSignTap,iTemp_size);
			logDebug2("iGrSockFd :%d:",iGrSockFd);
                        logDebug2("Sent_bytes = [%d]",iSent_bytes);
                        logDebug2("BOX SIGNON REQUEST SENT TO EXCHANGE");
                        logDebug2("groupid = [%d]",iGroupid);

                        fReduceInvitationCount(iGroupid);

                        logDebug2("BOX SIGN ON REQUEST Sent to exchange ....[%d]  ",iSent_bytes);
                }

                logDebug2("WAITING TO RECEIVE " ) ;
                iRecv_bytes = RECV(iGrSockFd,sRecvBoxsign);
                if( iRecv_bytes <= 0)
                {
                        iConnectionCounter++;
                        logDebug2("Received <=0 byted:closing TAP BOX Connection..");
                        close(iSockfd1);
                        return FALSE;
                }

                memcpy(pBoxHdr,sRecvBoxsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
                logDebug2("Box Sign iMsgCode :%d:",pBoxHdr->iMsgCode);
                logDebug2("Box Sign iErrorCode :%d:",pBoxHdr->iErrorCode);
                logDebug2("Box Sign Lenght :%d:",pBoxHdr->iMsgLength);
                TWIDDLE(pBoxHdr->iMsgCode);
                TWIDDLE(pBoxHdr->iErrorCode);
                TWIDDLE(pBoxHdr->iMsgLength);
                logDebug2("Box Sign iMsgCode :%d:",pBoxHdr->iMsgCode);
                logDebug2("Box Sign iErrorCode :%d:",pBoxHdr->iErrorCode);
                logDebug2("Box Sign Lenght :%d:",pBoxHdr->iMsgLength);
                iBlen = pBoxHdr->iMsgLength ;
                cBoxdata= (CHAR *)malloc(iBlen);
                memcpy(cBoxdata,sRecvBoxsign+sizeof(struct TAP_WRAPPER) ,iBlen);

                memcpy(pTap_wrap,sRecvBoxsign,sizeof(struct TAP_WRAPPER));
                logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
                logDebug2("Received Seq_No = [%d]",pTap_wrap->Seq_No);
                TWIDDLE(pTap_wrap->Seq_No);
                TWIDDLE(pTap_wrap->Message_Len);
                logDebug2("Received message with total length = [%d]",pTap_wrap->Message_Len);
                logDebug2("Received Seq_No = [%d]",pTap_wrap->Seq_No);
		iSeq_No = 0;
                iRecieveSeq++;
                iSeq_No = iRecieveSeq ;

                logDebug2("Passed Seq No Check...");
                memcpy(pBoxHdr,sRecvBoxsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
                TWIDDLE(pBoxHdr->iMsgLength);
                iBlen = pBoxHdr->iMsgLength ;
                cBoxdata= (CHAR *)malloc(iBlen);

                memcpy(cBoxdata,sRecvBoxsign+sizeof(struct TAP_WRAPPER) ,iBlen);
                logDebug2("Computing the digest ...");

                fMD5_Digest(sDigest,cBoxdata,iBlen)  ;

                logDebug2("Blen :%d:  digest :%s:  bdate :%s:", iBlen, sDigest, cBoxdata);

                if(strncmp(sDigest,pTap_wrap->digest,16) !=0)
                {
                        logDebug2("FATAL::Mismatch in MD5 Checksum ....closing TAP BOX Connection..");
                        memset(sError,NULL,SIZE);
                        strcpy(sError,"ERROR::Mismatch in MD5 Checksum ");
                        logFatal("EquNseConTAP.pc %s",sError);
                        fExit(ERROR);
                }

                logDebug2("Passed MD5 Checksum Check...");

                memcpy(pBoxHdr,sRecvBoxsign+sizeof(struct TAP_WRAPPER),sizeof(struct NNF_HEADER));
                TWIDDLE(pBoxHdr->iMsgLength);
                TWIDDLE(pBoxHdr->iErrorCode);
                iBlen = pBoxHdr->iMsgLength;

                cBoxdata= (CHAR *)malloc(iBlen);
                memcpy(cBoxdata,sRecvBoxsign+sizeof(struct TAP_WRAPPER),iBlen);

                RecvBoxSignResp(cBoxdata);
                iSockfd1 = iGrSockFd;

	}
	else
        {
                logFatal("GATEWAY ROUTER REQUEST FAILS ");
                return FALSE;
        }


        logTimestamp("Exit [fReqForDCconnection]");

}

BOOL    fHeartBeatsReqPack()
{
        logTimestamp("Entry :fHeartBeatsReqPack:");

        struct  NNF_HEADER      *pHeartBts;
        struct  TAP_WRAPPER     *pTapWrp;
        UCHAR   sDigest[16];
        CHAR    *cSendHrtBeats;
        LONG32  iSent_bytes , iRecv_bytes;
        CHAR    sRecvHrtBeats[NSE_PACKET_SIZE];
        LONG32  iTotPackSize = 0;



        while (TRUE)
        {

                pHeartBts= (CHAR *)malloc(sizeof(struct NNF_HEADER) );
                memset(pHeartBts,' ',sizeof(struct NNF_HEADER));
                pTapWrp =(struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
                memset(pTapWrp,' ',sizeof(struct TAP_WRAPPER));

                cSendHrtBeats= (CHAR *)malloc(sizeof(struct NNF_HEADER) + sizeof(struct TAP_WRAPPER));
                iTotPackSize = 0;

                pHeartBts->iMsgCode = TC_EQU_NSE_HEART_BEATS;
                pHeartBts->iLogTimeStamp = 0 ;
                memset(pHeartBts->sAlphaSplit,' ',2);
                memcpy(pHeartBts->sAlphaSplit,"NT",2);
                pHeartBts->iTraderID= iTmpTradeId;
                pHeartBts->iErrorCode = 0 ;
                memset(pHeartBts->sTimeStamp1,'\0',NNF_DATE_TIME_LEN);
                memset(pHeartBts->sTimeStamp1,' ',NNF_DATE_TIME_LEN);
                memset(pHeartBts->sTimeStamp2,'\0',NNF_DATE_TIME_LEN);	
		memset(pHeartBts->sTimeStamp2,' ',NNF_DATE_TIME_LEN);
                memset(pHeartBts->sTimeStamp3,'\0',NNF_DATE_TIME_LEN);
                memset(pHeartBts->sTimeStamp3,' ',NNF_DATE_TIME_LEN);
                pHeartBts->sTimeStamp1[0]='0';
                pHeartBts->sTimeStamp2[0]='0';
                pHeartBts->sTimeStamp3[0]='0';

                pHeartBts->iMsgLength = sizeof(struct NNF_HEADER);

                iTotPackSize =  sizeof(struct NNF_HEADER) +  sizeof(struct TAP_WRAPPER);

                fMD5_Digest(sDigest,(CHAR *)&pHeartBts,sizeof(struct NNF_HEADER))  ;

                iTransmitSeq ++;
                pTapWrp->Seq_No = iTransmitSeq ;

                memcpy(pTapWrp->digest,sDigest,16);
                pTapWrp->Message_Len = sizeof(struct NNF_HEADER) + sizeof(struct TAP_WRAPPER); /* Changed here */
                TWIDDLE(pTapWrp->Seq_No);
                TWIDDLE(pTapWrp->Message_Len);

                memcpy(cSendHrtBeats,pTapWrp,sizeof(struct TAP_WRAPPER));
                memcpy(cSendHrtBeats+ sizeof(struct TAP_WRAPPER),pHeartBts,sizeof(struct NNF_HEADER));


                iSent_bytes = SEND(iSockfd1,cSendHrtBeats,iTotPackSize);
		// Printing for monitoring purpose @NItish
		logTimestamp(":%s: HEART BEATS SEND TO EXCHANGE ",KEY_WORD_MONITORING);
                sleep(10);
                free(cSendHrtBeats);
                free(pHeartBts);

        }


        logTimestamp("Exit :fHeartBeatsReqPack:");
}




BOOL    fDMASendSysInfo(LONG32 iGroupid)
{
        logTimestamp("Entry :fDMASendSysInfo:");
        LONG32  iInvPacketCount,iTemp_size,iSent_bytes;
        CHAR    *sSendsys, *sSendsysTAP;
        UCHAR   sDigest[16];
        struct  TAP_WRAPPER     *pTap_wrap;
        logDebug2("TRANSMIT CHAftre fGetInvitationPacketCount  InvPacketCount [%d]    ",iInvPacketCount);
        logDebug2("TRANSMIT CHBefore sendsysinfo      ");
        sSendsys= (CHAR *)malloc(sizeof(struct NNF_SYS_INFO_REQ));
        sSendsysTAP = (CHAR *)malloc(sizeof(struct NNF_SYS_INFO_REQ) + sizeof(struct TAP_WRAPPER));

        fDMASendsysinfo(sSendsys,iGroupid);



        iTemp_size = ((struct NNF_HEADER *)(sSendsys ))->iMsgLength;
        TWIDDLE(((struct NNF_HEADER *)(sSendsys))->iMsgLength);
        fMD5_Digest(sDigest,sSendsys ,iTemp_size )  ;
        pTap_wrap = (struct TAP_WRAPPER *)malloc(sizeof(struct TAP_WRAPPER));
        memset(pTap_wrap,NULL,sizeof(struct TAP_WRAPPER));
        iTemp_size = iTemp_size + 22;
        pTap_wrap->Message_Len = iTemp_size;

        iTransmitSeq++;
        logInfo("Nitish printing iTransmitSeq in fSendsysinfo :%d:",iTransmitSeq);
        pTap_wrap->Seq_No = iTransmitSeq ;
        TWIDDLE(pTap_wrap->Message_Len);
        TWIDDLE(pTap_wrap->Seq_No);

        logDebug2(" Seq No :::::: sSendsysTAP ::::: [%d]",pTap_wrap->Seq_No);
        logDebug2("TRANSMIT CHILD Transmit Seq No incremented to [%d]",pTap_wrap->Seq_No);
        memcpy(pTap_wrap->digest,sDigest,16);
        memcpy(sSendsysTAP,pTap_wrap,sizeof(struct TAP_WRAPPER));
        memcpy(sSendsysTAP + sizeof(struct TAP_WRAPPER),sSendsys,sizeof(struct NNF_SYS_INFO_REQ));
        logDebug2("TRANSMIT CHILD Bfore sending     ");
        iSent_bytes = SEND(iSockfd1, sSendsysTAP,iTemp_size );

        fDeal_with_SendRecv(iSent_bytes , iGroupid);

        logDebug2("TRANSMIT CHILD Before fReduceInvitationCount   ");

        sleep(1);
	logTimestamp("Exit :fDMASendSysInfo:");
}
