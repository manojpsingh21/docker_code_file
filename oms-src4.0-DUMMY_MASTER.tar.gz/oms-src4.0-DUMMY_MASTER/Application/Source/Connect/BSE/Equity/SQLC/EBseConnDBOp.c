#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>


extern	DB_BseConn;
extern iGlobGrpId;

BOOL	GetRegPackDetail(CHAR *sSendPack,INT16 iGrpId)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	struct OMB_EXCH_USER_REG_REQ *pUsrReg;
	BOOL	iCkeckFlg = FALSE;
	CHAR	sSelQry[MAX_QUERY_SIZE];	

	pUsrReg = (struct OMB_EXCH_USER_REG_REQ *) malloc(sizeof(struct OMB_EXCH_USER_REG_REQ));

	memset(sSendPack,' ',REGISTRATION_LEN);
	memset(pUsrReg,' ',sizeof(struct OMB_EXCH_USER_REG_REQ));
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	pUsrReg->pOmbHeader.iSlotNo = PROTOCOL_SLOT ;
	pUsrReg->pOmbHeader.iMsgLen = sizeof(struct OMB_EXCH_USER_REG_REQ) - sizeof(struct OMB_HEADER);

	sprintf(sSelQry,"SELECT EAM_EXCH_USER_ID , EAM_BROKER_ID FROM EXCH_ADMINISTRATION_MASTER \
			WHERE \
			EAM_EXM_EXCH_ID = \"%s\" 
			AND EAM_GROUP_ID = %d AND EAM_SEGMENT = \'%c\';",BSE_EXCH,iGrpId,EQUITY_SEGMENT);

	logDebug1("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_BseConn,sSelQry) != SUCCESS)
	{
		logFatal("Error in Qeury");
		sql_Error(DB_BseConn);
	}
	Res = mysql_store_result(DB_BseConn);	

	if((Row = mysql_fetch_row(Res)))
	{
		pUsrReg->iTraderId = atoi(Row[0]);
		pUsrReg->iMmbrId = atoi(Row[1]);
	}


	pUsrReg->iMsgType= 0;
	pUsrReg->iSlotNo = PROTOCOL_SLOT;

	logDebug3("iTraderId 	:%d:",pUsrReg->iTraderId);
	logDebug3("iMmbrId 	:%d:",pUsrReg->iMmbrId);
	logDebug3("iMsgType	:%d:",pUsrReg->iMsgType);
	logDebug3("iSlotNo	:%d:",pUsrReg->iSlotNo);
	logDebug3("pOmbHeader.iSlotNo:%d:",pUsrReg->pOmbHeader.iSlotNo);
	logDebug3("pOmbHeader.iMsgLen:%d:",pUsrReg->pOmbHeader.iMsgLen);

	TWIDDLE(pUsrReg->pOmbHeader.iSlotNo);
	TWIDDLE(pUsrReg->pOmbHeader.iMsgLen);
	TWIDDLE(pUsrReg->iTraderId);
	TWIDDLE(pUsrReg->iMmbrId);
	TWIDDLE(pUsrReg->iMsgType);
	TWIDDLE(pUsrReg->iSlotNo);

	memcpy(sSendPack,pUsrReg,sizeof(struct OMB_EXCH_USER_REG_REQ));
	free(pUsrReg);	
	return TRUE;


}


