#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "OMBBseStrcut.h"

extern iHours;
extern iMinutes;
extern iSec;
extern last_msg_time;
extern iSockfd;
extern iGlobUserGroupId;
extern TimeStamp[TIME_LENGTH];
extern	DB_BseCon;
extern iGlobGrpId;
/*
BOOL	GetRegPackDetail(CHAR *sSendPack,INT16 iGrpId)
{
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	struct OMB_EXCH_USER_REG_REQ *pUsrReg;
	BOOL	iCkeckFlg = FALSE;
	CHAR	sSelQry[MAX_QUERY_SIZE];	

	pUsrReg = (struct OMB_EXCH_USER_REG_REQ *) malloc(sizeof(struct OMB_EXCH_USER_REG_REQ));

	memset(sSendPack,' ',REGISTRATION_LEN);
	memset(pUsrReg,' ',sizeof(struct OMB_EXCH_USER_REG_REQ));
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	pUsrReg->pOmbHeader.iSlotNo = PROTOCOL_SLOT ;
	pUsrReg->pOmbHeader.iMsgLen = sizeof(struct OMB_EXCH_USER_REG_REQ) - sizeof(struct OMB_HEADER);

	sprintf(sSelQry,"SELECT EAM_EXCH_USER_ID , EAM_BROKER_ID FROM EXCH_ADMINISTRATION_MASTER \
			WHERE \
			EAM_EXM_EXCH_ID = \"%s\" 
			AND EAM_GROUP_ID = %d AND EAM_SEGMENT = \'%c\';",BSE_EXCH,iGrpId,EQUITY_SEGMENT);

	logDebug1("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_BseConn,sSelQry) != SUCCESS)
	{
		logFatal("Error in Qeury");
		sql_Error(DB_BseConn);
	}
	Res = mysql_store_result(DB_BseConn);	

	if((Row = mysql_fetch_row(Res)))
	{
		pUsrReg->iTraderId = atoi(Row[0]);
		pUsrReg->iMmbrId = atoi(Row[1]);
	}


	pUsrReg->iMsgType= 0;
	pUsrReg->iSlotNo = PROTOCOL_SLOT;

	logDebug3("iTraderId 	:%d:",pUsrReg->iTraderId);
	logDebug3("iMmbrId 	:%d:",pUsrReg->iMmbrId);
	logDebug3("iMsgType	:%d:",pUsrReg->iMsgType);
	logDebug3("iSlotNo	:%d:",pUsrReg->iSlotNo);
	logDebug3("pOmbHeader.iSlotNo:%d:",pUsrReg->pOmbHeader.iSlotNo);
	logDebug3("pOmbHeader.iMsgLen:%d:",pUsrReg->pOmbHeader.iMsgLen);

	TWIDDLE(pUsrReg->pOmbHeader.iSlotNo);
	TWIDDLE(pUsrReg->pOmbHeader.iMsgLen);
	TWIDDLE(pUsrReg->iTraderId);
	TWIDDLE(pUsrReg->iMmbrId);
	TWIDDLE(pUsrReg->iMsgType);
	TWIDDLE(pUsrReg->iSlotNo);

	memcpy(sSendPack,pUsrReg,sizeof(struct OMB_EXCH_USER_REG_REQ));
	free(pUsrReg);	
	return TRUE;


}
*/

void    GetTimeForDownload( )
{
	LONG64  TimeInSecs = 0;
	CHAR    RetTime[TIME_LENGTH];
	CHAR    Date[TIMESTAMP_LENGTH];
	LONG64    TimeOffset =  0 ;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	logDebug1("Inside GetTimeForDownload...");
	memset(TimeStamp, NULL,TIME_LENGTH);

	sprintf(sSelQry," SELECT EAM_LAST_MSG_TIME ,EAM_EXCH_OFFSET_TIME \
			FROM EXCH_ADMINISTRATION_MASTER\
			WHERE  EAM_GROUP_ID =  %d \
			AND EAM_SEGMENT = 'C'\
			AND EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_DRV_FLAG = 'N'; ",iGlobUserGroupId);

	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_BseCon,sSelQry) != SUCCESS)
	{
		sql_Error(DB_BseCon);
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		TimeInSecs = atol(Row[0]);
	}

	logDebug1("The Number of Seconds selected is %ld",TimeInSecs);


	if ( TimeInSecs == 0 )
	{
		logDebug1("SENDING REQUEST FOR FULL DOWNLOAD...");
		strcpy(TimeStamp,"00:00:00");
		return ;
	}

	logDebug1("SENDING REQUEST FOR INCREMENTAL DOWNLOAD...");

	logDebug1 (" Time :%ld   Offset :%ld " , TimeInSecs , TimeOffset ) ;
	TimeInSecs = TimeInSecs  + TimeOffset  ;
	Convert_Seconds_To_Time( TimeInSecs, RetTime);
	strcpy(TimeStamp,RetTime) ;
	logDebug1("The Time Going To Be Sent To Exchange Is :%s",RetTime) ;
	return;
}



void Convert_Seconds_To_Time( LONG64 seconds,CHAR *pTime)
{
	struct tm *tmr;
	time_t julian;

	tmr = (struct tm *) malloc (sizeof(struct tm )) ;
	julian = seconds + OFFSET - TIMEZONE_BSE;

	localtime_r(&julian,tmr);
	strftime(pTime,9,"%T",tmr);
	logDebug1("The Time To Be sent is :%s",pTime);
	free(tmr);
}


LONG32  PrepareRegistrationPacket (CHAR *UserRegReq ,LONG32 UserId )
{
	LONG32 RetVal;
	struct OMB_USER_REGISTRATION_REQ_PCOL  *pUserRegReq ;
	CHAR    *sSelectQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	pUserRegReq = (struct OMB_USER_REGISTRATION_REQ_PCOL *)malloc(sizeof(struct OMB_USER_REGISTRATION_REQ_PCOL));

	memset(UserRegReq,' ',REGISTRATION_LEN ) ;
	memset(pUserRegReq,' ',sizeof(struct OMB_USER_REGISTRATION_REQ_PCOL));

	pUserRegReq->pHeader.iSlotNo = PROTOCOL_SLOT ;
	pUserRegReq->pHeader.iMsgLen = sizeof(struct OMB_USER_REGISTRATION_REQ_PCOL) - sizeof(struct OMB_HEADER);
	logDebug1("In PrepareRegistrationPacket");
	logDebug1("The Group Id recvd is %d",UserId);

	sprintf(sSelectQ,"SELECT \
			EAM_EXCH_USER_ID ,\
			EAM_BROKER_ID \
			FROM    EXCH_ADMINISTRATION_MASTER \
			WHERE   EAM_EXM_EXCH_ID = 'BSE' AND\
			AND EAM_SEGMENT = 'C'\			
			EAM_GROUP_ID = %d \
			AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

	logDebug2("sSelectQ :%s:",sSelectQ);

	if ( mysql_query(DB_BseCon,sSelectQ) != SUCCESS)
	{
		free(sSelectQ);
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		pUserRegReq->iTraderId = atoi(Row[0]);
		pUserRegReq->iMmbrId = atoi(Row[1]);
	}
	else
	{
		logInfo("No Row Fetch for Registration");
		return FALSE;
	}


	pUserRegReq->iMsgType  = 0 ;
	pUserRegReq->iSlotNo   = PROTOCOL_SLOT ;


	logDebug1("Slot No      ==>     %d ",pUserRegReq->pHeader.iSlotNo );
	logDebug1("iMsgLength   ==>     %d ",pUserRegReq->pHeader.iMsgLen );
	logDebug1("Msg Type     ==>     %d ",pUserRegReq->iMsgType );
	logDebug1("iSlotNo inner ==>    %d ",pUserRegReq->iSlotNo );
	logDebug1("Trader Id    ==>     %d",pUserRegReq->iTraderId);
	logDebug1("Member Id    ==>     %d",pUserRegReq->iMmbrId);
	memcpy( UserRegReq, pUserRegReq, sizeof(struct OMB_USER_REGISTRATION_REQ_PCOL));
	free(pUserRegReq);
	return TRUE;
}

LONG32  ReceiveQueryIndexValue (CHAR *LogOnResp )
{
	LONG32  SentBytes = 0 ;
	LONG32  iRetVal = FALSE ;
	LONG32  count = 0 ;
	struct OMB_QUERY_INDEX_VALUES_REPLY *pBuffer;

	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR    IndexName[40] ;
	DOUBLE64 CurrIndexVal ;                 /*** PRECESION ***/
	DOUBLE64 OpenIndexVal ;                 /*** PRECESION ***/
	DOUBLE64 CloseIndexVal ;                /*** PRECESION ***/
	DOUBLE64 PctChange ;                    /*** PRECESION ***/
	DOUBLE64 High;                          /*** PRECESION ***/
	DOUBLE64 Low;                           /*** PRECESION ***/
	CHAR ChangeInd;


	pBuffer = (struct OMB_QUERY_INDEX_VALUES_REPLY * )malloc(sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY ) );
	memset( pBuffer , ' ',sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY ));

	logDebug1("In ReceiveQueryIndexValue ");

	memcpy( pBuffer, LogOnResp, sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY));

	/***BSETWIDDLE(pBuffer->iMsgType);
	  BSETWIDDLE(pBuffer->iRepCode);
	  BSETWIDDLE(pBuffer->iNoOfRecords);
	  BSETWIDDLE(pBuffer->iMsgTag);****/

	logDebug1("The Transcode  Received is %d",pBuffer->iMsgType ) ;

	if( pBuffer->iMsgType != TC_EQU_BSE_QUERY_INDEX_DETAILS_REPLY )
	{
		logDebug1("Received Packet is not of QueryIndexValue Reply..");
		return  RETRY ;
	}

	logDebug1("********************************************************");
	logDebug1("*    Q U E R Y   I N D E X   R E  P L Y             *");
	logDebug1("********************************************************");
	logDebug1("Transcode   Received : %d",  pBuffer->iMsgType   );
	logDebug1("Reply Code  Received : %d",  pBuffer->iRepCode   );
	logDebug1("iNoOfRecords Received : %d",  pBuffer->iNoOfRecords );
	logDebug1("iMsgTag      Received : %d",  pBuffer->iMsgTag );
	logDebug1("********************************************************");



	if( pBuffer->iRepCode == 0  )
	{
		for( count=0; count < pBuffer->iNoOfRecords; count++)
		{
			memset(IndexName ,' ',40);
			ChangeInd = ' ';

			memcpy(IndexName ,pBuffer->pDtls[count].sIndexId,INDEXID_LEN);

			/**8BSETWIDDLE(pBuffer->pDtls[count].iHigh);
			  BSETWIDDLE(pBuffer->pDtls[count].iLow);
			  BSETWIDDLE(pBuffer->pDtls[count].iOpen);
			  BSETWIDDLE(pBuffer->pDtls[count].iClose);
			  BSETWIDDLE(pBuffer->pDtls[count].iCurValue);***/

			logDebug1(" pBuffer->pDtls[%d].Open : %d",count,pBuffer->pDtls[count].iOpen);
			logDebug1(" pBuffer->pDtls[%d].Close : %d",count,pBuffer->pDtls[count].iClose);
			logDebug1(" pBuffer->pDtls[%d].CurValue : %d",count,pBuffer->pDtls[count].iCurValue);
			logDebug1(" IndexName : %.7s",pBuffer->pDtls[count].sIndexId);
			logDebug1(" pBuffer->pDtls[%d].High : %d",count,pBuffer->pDtls[count].iHigh);
			logDebug1(" pBuffer->pDtls[%d].Low : %d",count,pBuffer->pDtls[count].iLow);

			CurrIndexVal =  (DOUBLE64)(pBuffer->pDtls[count].iCurValue)/100.0 ;     /*** PRECESION ***/
			OpenIndexVal =  (DOUBLE64)(pBuffer->pDtls[count].iOpen)/100.0 ;         /*** PRECESION ***/
			CloseIndexVal = (DOUBLE64)(pBuffer->pDtls[count].iClose)/100.0;         /*** PRECESION ***/
			PctChange =  ((DOUBLE64)(CurrIndexVal - CloseIndexVal)/CloseIndexVal)*100.0;    /*** PRECESION ***/
			High      = (DOUBLE64)(pBuffer->pDtls[count].iHigh)/100.0 ;             /*** PRECESION ***/
			Low      = (DOUBLE64)(pBuffer->pDtls[count].iLow)/100.0 ;                       /*** PRECESION ***/

			logDebug1(" CurrIndexVal : %lf",CurrIndexVal);
			logDebug1(" OpenIndexVal : %lf",OpenIndexVal);
			logDebug1(" CloseIndexVal : %lf",CloseIndexVal);
			logDebug1(" PctChange : %lf",PctChange);
			logDebug1(" IndexName  : %s",IndexName );
			logDebug1(" count : %d",count);

			if( PctChange < 0 )
			{
				ChangeInd = '-' ;
			}
			else if(PctChange > 0)
			{
				ChangeInd = '+' ;
			}
			else
			{
				ChangeInd = ' ' ;
			}

			if( PctChange < 0 )
			{
				PctChange = 0 - PctChange ;
			}

			if( strncmp(pBuffer->pDtls[count].sIndexId,"SENSEX",6) == 0 )
			{
				sprintf(sUpdQry,"UPDATE MULTIPLE_INDEX_INQUIRY \
						SET     MII_INDEX_VAL =  :CurrIndexVal,\
						MII_OPENING_INDEX = :OpenIndexVal,\
						MII_CLOSING_INDEX = :CloseIndexVal,\
						MII_HIGH_INDEX_VAL=:High,\
						MII_LOW_INDEX_VAL =:Low,\
						MII_PCT_CHANGE = :PctChange,\
						MII_NET_CHANGE_IND = :ChangeInd,\
						MII_TIME = sysdate\
						WHERE   MII_INDEX_NAME = :IndexName");
				if(mysql_query(DB_BseCon,sUpdQry)!= SUCCESS)
				{
					logDebug1("\n Update MII sucessful ");
					logDebug1("\n IndexName  : %s",IndexName );
					iRetVal = TRUE ;
				}
				else if(TRUE)
				{
					sprintf(sInsQry,"INSERT INTO    MULTIPLE_INDEX_INQUIRY\
							( MII_INDEX_NAME,\
							  MII_EXCH_ID,\
							  MII_INDEX_VAL,\
							  MII_OPENING_INDEX,\
							  MII_CLOSING_INDEX,\
							  MII_HIGH_INDEX_VAL,\
							  MII_LOW_INDEX_VAL,\
							  MII_PCT_CHANGE,\
							  MII_NET_CHANGE_IND,\
							  MII_TIME\
							)\
							VALUES  ( :IndexName,\
								'BSE',\
								:CurrIndexVal,\
								:OpenIndexVal,\
								:CloseIndexVal,\
								:High,\
								:Low,\
								:PctChange,\
								:ChangeInd,\
								sysdate\
								) ;");

					if(mysql_query(DB_BseCon,sInsQry)!= SUCCESS)
					{
						logDebug1("  Insert LONG32o MII failed : sqlerr -  ");
						iRetVal = FALSE ;
						break ;
					}
					else
					{
						logDebug1("  Insert LONG32o MII Successful ");
						iRetVal = TRUE ;
					}
				}
				else
				{
					logDebug1(" Update MII failed : sqlerr - ");
					iRetVal = FALSE ;
					break ;
				}
				break ;
			}
			iRetVal = TRUE ;   /* Has to removed while putting in live */
		}

		if ( iRetVal == TRUE )
		{
			free( pBuffer );
			logDebug1("Query Index Value Successfull...");
			return TRUE;
		}
		else
		{
			free(pBuffer);
			BSEconnectLogFatal("Query Index Value Fail...");
			return FALSE;
		}
	}  /* end if( iRepCode == 0 ) */
	else
	{
		free(pBuffer);
		return FALSE;
	}
}


LONG32  PrepareLogOnPacket (CHAR *LogOnReq ,LONG32 UserId )
{
	CHAR    *PlainPassword  ;
	LONG32          iRetVal                 ;
	LONG32          iCntr                   ;

	CHAR tempPassWd[40]      ;
	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	struct OMB_LOG_ON_OFF_REQUEST *pSignOn;
	CHAR ecryptedPassword[75];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	pSignOn = (struct OMB_LOG_ON_OFF_REQUEST *)malloc(sizeof(struct OMB_LOG_ON_OFF_REQUEST ));

	logDebug1("In PrepareLogOnPacket.... ");

	memset(LogOnReq,' ',LOGIN_REQ_PACKET_SIZE ) ;
	bzero(pSignOn, sizeof(struct OMB_LOG_ON_OFF_REQUEST));
	memset(tempPassWd ,'\0',40) ;
	memset(ecryptedPassword ,'\0',75) ;

	pSignOn->pHeader.iSlotNo = 1;
	pSignOn->pHeader.iMsgLen = sizeof(struct OMB_LOG_ON_OFF_REQUEST) - sizeof(struct OMB_HEADER) ;
	pSignOn->iMsgType = TC_EQU_BSE_LOGON_REQUEST ;

	PlainPassword=(CHAR*)malloc(PASSWORD_LEN +1);
	memset(PlainPassword, '\0', PASSWORD_LEN +1);
	/***
	  EXEC SQL SELECT
	  EAM_OLD_PASSWORD
	  INTO
	  :ecryptedPassword
	  FROM    EXCH_ADMINISTRATION_MASTER
	  WHERE  EAM_EXM_EXCH_ID = 'BSE'
	  AND EAM_EXCH_USER_ID = to_CHAR(:iGlobUserGroupId )
	  AND EAM_DRV_FLAG = 'N';
	 ****/
	memset(pSignOn->sPasswd,'\0',BSE_PASSWORD_LEN ) ;
	sprintf(sSelQry,"SELECT \
			aes_decrypt(EAM_OLD_PASSWORD,'rupee123')\
			FROM    EXCH_ADMINISTRATION_MASTER\
			WHERE  EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_SEGMENT = 'C'\
			AND EAM_GROUP_ID = %d\
			AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

	logDebug2("sSelQry :%s:",sSelQry);

	if (mysql_query(DB_BseCon,sSelQry) != SUCCESS)
	{
		sql_Error(DB_BseCon);
		exit(0);
	}

	Res = mysql_store_result(DB_BseCon);
	if(Row = mysql_fetch_row(Res))
	{
		strcpy(pSignOn->sPasswd,Row[0]);
	}




	logDebug1(" PlaLONG32ext Password User");
	logDebug1(" NON - DISEC Encrypted Password is  : [%s] :",pSignOn->sPasswd);

	pSignOn->iMsgTag = 0;
	/***********Added in anagram *******************/
	/**     BSETWIDDLE(pSignOn->pHeader.iSlotNo);
	  BSETWIDDLE(pSignOn->pHeader.iMsgLen);
	  BSETWIDDLE(pSignOn->iMsgType);
	  BSETWIDDLE(pSignOn->iMsgTag);***/
	memcpy( LogOnReq, (CHAR*)pSignOn, sizeof(struct OMB_LOG_ON_OFF_REQUEST));
	free(pSignOn);free(PlainPassword);
	return  TRUE ;
}

LONG32  ReceiveLogOnResp (CHAR *LogOnResp,LONG32 UserId )
{
	LONG32 sockfd ;
	LONG32 Transcode,SentBytes = 0 ;
	CHAR    *SndMsg;
	CHAR    *Packet;
	LONG32  PacketSize;
	LONG32  Flag =FALSE ;
	LONG32  iRetVal = FALSE ;
	LONG32  RecvBytes = 0;
	struct OMB_LOG_ON_REPLY *pBuffer;
	BOOL result = ERROR;
	LONG32 Bse_julitime;
	LONG32 Sys_julitime;
	CHAR *exch_time;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


	CHAR  tempTraderID[30];
	CHAR tempErrMsg[ERROR_MSG_LEN];
	LONG32  Offset_julitime;
	LONG32  oracle_userid;
	CHAR    *sSelcQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug1("In ReceiveLogOnResp....");


	oracle_userid = UserId;

	exch_time = (CHAR *)malloc(sizeof(DATETIME_LEN+1));
	pBuffer = (struct OMB_LOG_ON_REPLY * )malloc(sizeof(struct OMB_LOG_ON_REPLY ) );
	memset( pBuffer , '\0',sizeof(struct OMB_LOG_ON_REPLY ));
	memset( tempTraderID ,' ',30);


	memcpy( pBuffer, LogOnResp, sizeof(struct OMB_LOG_ON_REPLY));
	/***************Added in anagram **********************/
	/**     BSETWIDDLE(pBuffer->iMsgType);
	  BSETWIDDLE(pBuffer->iRepCode);
	  BSETWIDDLE(pBuffer->iSession);
	  BSETWIDDLE(pBuffer->iMsgTag);
	 ***/
	logDebug1("The Transcode  Received is %d",pBuffer->iMsgType ) ;

	if( pBuffer->iMsgType == TC_EQU_BSE_LOGOFF_REPLY )
	{
		logDebug1("Received Packet for LogOff Reply..");
		return  RETRY ;
	}

	logDebug1("********************************************************");
	logDebug1("*    L O G O N       R E  P L Y                     *");
	logDebug1("********************************************************");
	logDebug1("Transcode  Received : %d",  pBuffer->iMsgType   );
	logDebug1("Reply Code Received : %d",  pBuffer->iRepCode   );
	//logDebug1("Current    Session  : %d",  pBuffer->iSession   );
	logDebug1("Login      Status   : %s",  pBuffer->sRepMsg          );
	logDebug1("Message    Of Day   : %s",  pBuffer->sMotd      );
	//logDebug1("Index      Received : %s",  pBuffer->sBcastIndexId);
	logDebug1("iTotPartitions      : %d",  pBuffer->iTotPartitions);
	logDebug1("iMsgTag             : %d",  pBuffer->iMsgTag);
	logDebug1("********************************************************");

	/************* added by appa in anagram ******************/
	memset(tempErrMsg ,' ',ERROR_MSG_LEN);
	memcpy(tempErrMsg ,pBuffer->sRepMsg,ERROR_MSG_LEN);



	if ( pBuffer->iRepCode == PASSWORD_EXPIRED )
	{
		Flag = HandleUpdPassword(iSockfd);
		if( Flag == FALSE )
		{
			logDebug1("BSEConnect.pc Password expiration failed");
			free(pBuffer);
			free(exch_time);
			return FALSE ;
		}
	}
	logDebug1(" BEFORE OPTIONAL PASSWD CHANGE " )  ;
	/****** Anurag Added 15-01-2003 : For Optional sPasswd Change ******/

	Flag = HandleUpdPassword(iSockfd);
	if( Flag == FALSE )
	{
		logDebug1("BSEConnect.pc Optional Password change");
		free(pBuffer);
		free(exch_time);
		return FALSE ;
	}

	/****** Anurag Added 15-01-2003 : For Optional sPasswd Change ******/

	if( pBuffer->iRepCode == 0 || pBuffer->iRepCode==LOGON_SUCCESSFUL || pBuffer->iRepCode==LOGON_SUCCESS || pBuffer->iRepCode == PASSWORD_EXPIRED )
	{

		/*      sprintf(sSelcQry,"SELECT EAM_EXCH_USER_ID \
			FROM    EXCH_ADMINISTRATION_MASTER\
			WHERE   EAM_EXM_EXCH_ID = 'BSE' AND\
			EAM_GROUP_ID = %d \
			AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

			logDebug2("sSelcQry :%s:",sSelcQry);


			if(mysql_query(DB_BseCon,sSelcQry) !=SUCCESS)
			{
			sql_Error(DB_BseCon);
			free(exch_time);
			return FALSE;
			}
			else
			{
			Res = mysql_store_result(DB_BseCon);
			if(Row = mysql_fetch_row(Res))
			{

			Offset_julitime=Bse_julitime-atol(Row[1]);

			}
			free(exch_time);
			}

			logDebug1(" Offset_julitime :%d,        Bsejulidate : %d, Sys_julidate :%d",Offset_julitime,Bse_julitime,Sys_julitime);

		 */
		/**************Baiju Added on 07-02-2001********************************/

		sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER \
				SET\
				EAM_EXCH_OFFSET_TIME = now() \
				EAM_REASON_DESC = Connected \
				WHERE EAM_EXM_EXCH_ID = 'BSE' \
				AND EAM_SEGMENT = 'C'\
				AND EAM_GROUP_ID = %d  AND \
				EAM_DRV_FLAG = 'N';",Offset_julitime,iGlobUserGroupId);

		if ( mysql_query(DB_BseCon,sUpdQry) !=SUCCESS )
		{
			logDebug1(" Error in updating Exch_administration_master ");
			sql_Error(DB_BseCon);
			return(FALSE);
		}

		/********
		  EXEC SQL UPDATE BSE_ADMINISTRATION_MASTER
		  SET   BAM_SCRIP_MASTER_VER     = ltrim(rtrim(:pBuffer->SecVersion)) ,
		  BAM_SCRIP_MASTER_RELEASE = ltrim(rtrim(:pBuffer->SecRelease))
		  WHERE    BAM_EAM_EXM_EXCH_ID = 'BSE' AND
		  BAM_EAM_EXCH_USER_ID= ltrim(rtrim(:tempTraderID)) ;

		  if (( iRetVal = SqlErrorFun( )) == TRUE )
		  EXEC SQL COMMIT;

		  if (( iRetVal = SqlErrorFun( )) == FALSE )
		  {
		  logDebug1("\nFailed in Update...");
		  free( pBuffer );
		  return FALSE;
		  }
		 *******/


		free( pBuffer );
		logDebug1("Login To Exchange Successfull...");
		return TRUE;
	}
	else if(pBuffer->iRepCode == USER_ALREADY_LOGGED_ON )
	{
		free( pBuffer );
		return FALSE;
	}
	else
	{
		free(pBuffer);
		return FALSE;
	}
}

LONG32  PrepareLogOffPacket (CHAR *LogOffReq ,LONG32 UserId)
{
	CHAR    *PlainPassword  ;
	LONG32     iRetVal      ;
	LONG32  iCntr           ;


	struct OMB_LOG_ON_OFF_REQUEST *pSignOn;
	CHAR tempPassWd[40]      ;
	CHAR ecryptedPassword[75];

	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("In PrepareLogOffReq ");

	pSignOn = (struct OMB_LOG_ON_OFF_REQUEST *)malloc(sizeof(struct OMB_LOG_ON_OFF_REQUEST ));


	memset( LogOffReq, '\0', LOG_OFF_REQ_LEN ) ;
	bzero(pSignOn, sizeof(struct OMB_LOG_ON_OFF_REQUEST ));
	memset(tempPassWd ,'\0',40) ;
	memset(ecryptedPassword ,'\0',75) ;

	PlainPassword=(CHAR*)malloc(PASSWORD_LEN +1);
	memset(PlainPassword, '\0', PASSWORD_LEN +1);

	pSignOn->pHeader.iSlotNo = REQUEST_SLOT ;
	pSignOn->pHeader.iMsgLen = sizeof(struct OMB_LOG_ON_OFF_REQUEST ) - sizeof(struct OMB_HEADER);
	logDebug1("The Message Length sent is %d",pSignOn->pHeader.iMsgLen);
	pSignOn->iMsgType = TC_EQU_BSE_LOGOFF_REQUEST ;

	memset(pSignOn->sPasswd,' ',BSE_PASSWORD_LEN ) ;
	sprintf(sSelQry,"SELECT EAM_OLD_PASSWORD \
			FROM    EXCH_ADMINISTRATION_MASTER\
			WHERE  EAM_EXM_EXCH_ID = 'BSE' \
			AND EAM_SEGMENT = 'C'\
			AND EAM_GROUP_ID = %d \
			AND EAM_DRV_FLAG = 'N' ;",iGlobUserGroupId);


	if (mysql_query(DB_BseCon,sSelQry) != SUCCESS )
	{
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		strcpy(pSignOn->sPasswd,Row[0]);
		logDebug1(" PlaLONG32ext Password User");
		logDebug1("Password = ::[%s]",pSignOn->sPasswd);
	}
	pSignOn->iMsgTag = 0;
	/**     BSETWIDDLE(pSignOn->pHeader.iSlotNo);
	  BSETWIDDLE(pSignOn->pHeader.iMsgLen);
	  BSETWIDDLE(pSignOn->iMsgType);
	  BSETWIDDLE(pSignOn->iMsgTag);
	 **/
	memcpy( LogOffReq,(CHAR*)pSignOn, sizeof(struct OMB_LOG_ON_OFF_REQUEST));

	free(pSignOn);
	free(PlainPassword);
	logDebug1(" End of PrepareLogOffReq");
	return  TRUE ;
}


LONG32 ReceiveLogOffResp (CHAR* LogOffResp ,LONG32 UserId )
{
	LONG32 RetVal ;
	CHAR  tempTraderID[30]  ;
	CHAR tempErrMsg[ERROR_MSG_LEN];
	struct OMB_LOG_OFF_REPLY *pUserLogOffResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	pUserLogOffResp = (struct OMB_LOG_OFF_REPLY * )malloc(sizeof(struct OMB_LOG_OFF_REPLY ) );
	memset( pUserLogOffResp,' ',sizeof(struct OMB_LOG_OFF_REPLY));

	CHAR    *sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	logDebug1("In ReceiveLogOffResp.... ");

	memcpy( pUserLogOffResp, (CHAR *)LogOffResp, sizeof(struct OMB_LOG_OFF_REPLY));

	/******** Added in anagram ************************/
	/**8    BSETWIDDLE(pUserLogOffResp->iMsgType);
	  BSETWIDDLE(pUserLogOffResp->iRepCode);
	  BSETWIDDLE(pUserLogOffResp->iFiller);
	  BSETWIDDLE(pUserLogOffResp->iMsgTag);
	  BSETWIDDLE(pUserLogOffResp->iCurSession);
	 ***/   /*******************************************************/

	logDebug1("*****************************************************");
	logDebug1("     L O G O F F   R E P L Y                        ");
	logDebug1("*****************************************************");
	logDebug1("Transcode Received : %d", pUserLogOffResp->iMsgType   );
	logDebug1("Reply CodeReceived : %d", pUserLogOffResp->iRepCode   );
	logDebug1("Current Session    : %d", pUserLogOffResp->iFiller1   );
	logDebug1("Reply Message      : %s", pUserLogOffResp->sRepMsg    );
	logDebug1("*****************************************************");

	/************* added by appa in anagram ******************/
	memset(tempErrMsg ,' ',ERROR_MSG_LEN);
	memcpy(tempErrMsg ,pUserLogOffResp->sRepMsg,ERROR_MSG_LEN);


	if(pUserLogOffResp->iRepCode == 0 ||pUserLogOffResp->iRepCode == USER_HAS_LOGGED_OFF ||pUserLogOffResp->iRepCode == LOGOFF_SUCCESS )
	{
		sprintf(sSelQry,"SELECT \
				EAM_EXCH_USER_ID\
				FROM    EXCH_ADMINISTRATION_MASTER\
				WHERE  EAM_GROUP_ID =   %d\
				AND EAM_SEGMENT = 'C'\
				AND EAM_EXM_EXCH_ID = 'BSE'\
				AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

		logDebug2("sSelQry :%s:",sSelQry);

		if ( mysql_query(DB_BseCon,sSelQry) != SUCCESS)
		{
			sql_Error(DB_BseCon);
			return FALSE;
		}



		free(pUserLogOffResp);
		return TRUE;
	}
	else if (pUserLogOffResp->iRepCode == SYS_DONOT_RECOGNIZE)
	{
		free(pUserLogOffResp);
		BSEconnectLogFatal("System Does Not Recongnise You");
		return FALSE;
	}
	else
	{
		free(pUserLogOffResp);
		BSEconnectLogFatal("Fatal Error Try Again ");
		return FALSE;
	}
}




BOOL HandleUpdPassword(LONG32 iSockfd)
{

	LONG32 RetVal;
	LONG32 SentBytes,RecvBytes;
	LONG32 PacketSize;
	LONG32 Flag=FALSE;
	LONG32 UserId;

	CHAR    *UpdsPasswd;
	CHAR    *UpdsPasswdResp;
	CHAR    *sSelQyr = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR OldPassword[8];
	CHAR NewPassword[8];

	UpdsPasswd=(CHAR *)malloc(sizeof(struct OMB_UPDATE_PASSWORD_REQ));
	UpdsPasswdResp=(CHAR *)malloc(sizeof(struct OMB_UPDATE_PASSWORD_RESP));

	memset(OldPassword ,' ',8);
	memset(NewPassword ,' ',8);

	UserId = iGlobUserGroupId ;

	sprintf(sSelQyr,"SELECT \
			IFNULL(aes_decrypt(EAM_NEW_PASSWORD,'rupee123'),'NOCHANGE')\
			FROM EXCH_ADMINISTRATION_MASTER\
			WHERE EAM_EXM_EXCH_ID = 'BSE' AND\
			AND EAM_SEGMENT = 'C'\
			EAM_GROUP_ID = %d AND\
			EAM_DRV_FLAG = 'N' ",iGlobUserGroupId);

	logDebug2("SelQyr :%s:",sSelQyr);

	if(mysql_query(DB_BseCon,sSelQyr) != SUCCESS)
	{
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(NewPassword ,Row[0],8);
	}

	logDebug2("NewPassword :%s:",NewPassword);

	if (strncmp(NewPassword,"NOCHANGE",8)==0)
	{
		logDebug1(" Password Change not Required ");
		free (UpdsPasswd);
		free (UpdsPasswdResp);
		return TRUE;
	}
	else //if(sqlca.sqlcode==0)
	{
		logDebug1("GOING TO PREPARE PACKET SOCKET ID is %d",iSockfd);

		if( (RetVal = PrepareChangePwdReq (UpdsPasswd, UserId)) == TRUE )
		{

			PacketSize = sizeof(struct OMB_UPDATE_PASSWORD_REQ);
			SentBytes = SendPacket (iSockfd, UpdsPasswd, PacketSize) ;
			if( SentBytes < 0)
			{
				free (UpdsPasswd);
				free (UpdsPasswdResp);
				return FALSE;
			}
		}
		else
		{
			free (UpdsPasswd);
			free (UpdsPasswdResp);
			return FALSE;
		}

		do
		{
			logDebug1(" Waiting to Receive A Response for Password Change ..");
			RecvBytes = RecvPacket (iSockfd, UpdsPasswdResp );
			logDebug1(" Received a packet from exchange ..");
			if( RecvBytes < 0 )
			{
				logDebug1(" Error in RecvPacket ");
				free(UpdsPasswd);
				free (UpdsPasswdResp);
				return FALSE;
			}
			if ( RecvBytes == 0 )
			{
				logDebug1(" Error in RecvPacket Recv Byte is zero");
				free(UpdsPasswd);
				free (UpdsPasswdResp);
				return FALSE;
			}

			if( ( Flag = ReceivesPasswdReply ( UpdsPasswdResp , UserId)) == TRUE )
			{
				logDebug1(" Reached here ..");
				free(UpdsPasswd);
				free(UpdsPasswdResp);
				return TRUE;
			}
			else if ( Flag == RETRY )
			{
				logDebug1(" Entered Retry eConart..");
				continue ;
			}
			else
			{
				free(UpdsPasswd);
				free(UpdsPasswdResp);
				return FALSE;
			}
		}while( Flag == RETRY );

	}
}



BOOL PrepareChangePwdReq(CHAR *UpdsPasswd , LONG32 UserId )
{
	CHAR    *PlainPassword  ;
	LONG32     iRetVal         ;
	LONG32  iCntr                   ;

	struct OMB_UPDATE_PASSWORD_REQ *UpdsPasswdReq;
	CHAR OldPassword[40];
	CHAR EncyptOldPassword[75];
	CHAR EncyptNewPassword[75];
	CHAR NewPassword[40];
	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	UpdsPasswdReq=(struct OMB_UPDATE_PASSWORD_REQ *)malloc(sizeof(struct OMB_UPDATE_PASSWORD_REQ));

	logDebug1(" In Prepare Password Update Packet ");

	memset(EncyptOldPassword,'\0',75);
	memset(EncyptNewPassword ,'\0',75);
	memset(NewPassword ,'\0',40);
	memset(OldPassword ,'\0',40);
	memset(UpdsPasswd,' ',sizeof(struct OMB_UPDATE_PASSWORD_REQ));
	bzero(UpdsPasswdReq,sizeof(struct OMB_UPDATE_PASSWORD_REQ));

	PlainPassword=(CHAR*)malloc(PASSWORD_LEN +1);
	memset(PlainPassword, '\0', PASSWORD_LEN +1);

	memset(UpdsPasswdReq->sOldPasswd,'\0',BSE_PASSWORD_LEN );
	memset(UpdsPasswdReq->sNewPasswd,'\0',BSE_PASSWORD_LEN );

	sprintf(sSelQry,"SELECT\
			aes_decrypt(EAM_NEW_PASSWORD,'rupee123'),\
			aes_decrypt(EAM_OLD_PASSWORD,'rupee123')\
			FROM       EXCH_ADMINISTRATION_MASTER\
			WHERE      EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_SEGMENT = 'C'\
			AND        EAM_GROUP_ID =%d \
			AND        EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

	logDebug2("sSelQry :%s:",sSelQry);

	if (mysql_query(DB_BseCon,sSelQry)!=SUCCESS)
	{
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{

		memcpy(UpdsPasswdReq->sOldPasswd,Row[1],BSE_PASSWORD_LEN);
		memcpy(UpdsPasswdReq->sNewPasswd,Row[0],BSE_PASSWORD_LEN);
	}
	logDebug1(" PlaLONG32ext Password User");


	UpdsPasswdReq->pHeader.iSlotNo = 3;
	UpdsPasswdReq->pHeader.iMsgLen=sizeof(struct OMB_UPDATE_PASSWORD_REQ)- sizeof(struct OMB_HEADER);

	UpdsPasswdReq->iMsgType=1134;


	UpdsPasswdReq->iMsgTag=0;
	/**       BSETWIDDLE(UpdsPasswdReq->pHeader.iSlotNo);
	  BSETWIDDLE(UpdsPasswdReq->pHeader.iMsgLen);
	  BSETWIDDLE(UpdsPasswdReq->iMsgType);
	  BSETWIDDLE(UpdsPasswdReq->iMsgTag);
	 **/
	memcpy(UpdsPasswd,UpdsPasswdReq,sizeof(struct OMB_UPDATE_PASSWORD_REQ));

	free(UpdsPasswdReq);
	free(PlainPassword);
	logDebug1(" ##### End of PasswordChangeRequest ");
	return TRUE;

}



BOOL ReceivesPasswdReply (CHAR *UpdsPasswdResp ,LONG32 UserId)
{
	LONG32  Transcode,SentBytes = 0;
	CHAR    *SndMsg ;
	CHAR    *Packet;
	LONG32  PacketSize;
	LONG32  Flag=FALSE;
	LONG32  RecvBytes = 0;

	struct  OMB_UPDATE_PASSWORD_RESP *UpdPasswdResponse;

	CHAR NewPassword[OBFS_LEN*2 + 1];
	CHAR    *sSeletQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sUdpQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug1(" In function ReceivesPasswdReply");

	UpdPasswdResponse=(struct OMB_UPDATE_PASSWORD_RESP *)UpdsPasswdResp;

	memset(NewPassword,'\0',OBFS_LEN*2 + 1);
	/**        BSETWIDDLE(UpdPasswdResponse->pHeader.iSlotNo);
	  BSETWIDDLE(UpdPasswdResponse->pHeader.iMsgLen);

	  BSETWIDDLE(UpdPasswdResponse->iMsgType);
	  BSETWIDDLE(UpdPasswdResponse->iMsgTag);
	  BSETWIDDLE(UpdPasswdResponse->iRepCode);
	 **/
	logDebug1("Reply code is %d",UpdPasswdResponse->iRepCode);


	if(UpdPasswdResponse->iRepCode==0)
	{
		logDebug1("Here");
		sprintf(sSeletQry,"SELECT \
				EAM_NEW_PASSWORD\
				FROM       EXCH_ADMINISTRATION_MASTER \
				WHERE      EAM_EXM_EXCH_ID = 'BSE'\
				AND        EAM_GROUP_ID = %d\
				AND EAM_SEGMENT = 'C'\
				AND        EAM_DRV_FLAG = 'N' ;",iGlobUserGroupId);

		if (mysql_query(DB_BseCon,sSeletQry) !=SUCCESS)
		{
			logDebug1("Error in select  password is ");
			sql_Error(DB_BseCon);
			return FALSE;
		}

		sprintf(sUdpQry,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
				EAM_OLD_PASSWORD=:NewPassword,\
				EAM_NEW_PASSWORD = '',\
				EAM_LAST_PASSWORD_CHANGE_DATE=trunc(sysdate),\
				EAM_UPDATE_BY = user,\
				EAM_UPDATE_DATE = trunc(sysdate)\
				WHERE           EAM_EXM_EXCH_ID = 'BSE' \
				AND EAM_SEGMENT = 'C'\
				AND                     EAM_GROUP_ID = %d \
				AND        EAM_DRV_FLAG = 'N' ;",iGlobUserGroupId);

		logDebug2("sUdpQry :%s:",sUdpQry);

		if (mysql_query(DB_BseCon,sUdpQry) !=SUCCESS)
		{
			logDebug1("Error in updation of password is ");
			sql_Error(DB_BseCon);
			return FALSE;
		}
		else
		{
			mysql_commit(DB_BseCon);
			logDebug1("The message in updation of password is %s",UpdPasswdResponse->sRepText);
			return TRUE;
		}
	}
	else
	{
		logDebug1("Reached here in else part");
		logDebug1("The error in updation of password is %s",UpdPasswdResponse->sRepText);
		BSEconnectLogFatal("The error in updation of password");
		return FALSE;
	}
}


void EAMtimestamp(SHORT SendRecv)  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
{

	LONG32   groupid=0;
	CHAR    *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1(" iGlobUserGroupId : %d", iGlobUserGroupId);
	groupid =iGlobUserGroupId;
	logDebug1("  Local groupid : %d", groupid);


	if ( SendRecv == 1 )
	{
		sprintf(sSelQry,"SELECT IFNULL(EAM_LAST_MSG_TIME,0)  \
				FROM   EXCH_ADMINISTRATION_MASTER\
				WHERE  EAM_EXM_EXCH_ID='BSE' \
				AND  EAM_GROUP_ID=%d\
				AND EAM_SEGMENT = 'C'\
				AND EAM_DRV_FLAG='N' ;",groupid);

		logDebug2("sSelQry :%s:",sSelQry);

		if ( mysql_query(DB_BseCon,sSelQry)!= SUCCESS )
		{
			logDebug1(" Error in updating EAM for iGlobUserGroupId " );
			sql_Error(DB_BseCon);
			exit(ERROR);
		}

		Res = mysql_store_result(DB_BseCon);

		if(Row = mysql_fetch_row(Res))
		{
			last_msg_time = atoi(Row[0]);
		}

		logDebug1("===========iGlobUserGroupId [%d]============= last_msg_time [%d] =================",groupid,last_msg_time);

		iSec= last_msg_time % 100;
		last_msg_time = last_msg_time / 100;
		iMinutes= last_msg_time % 100;
		iHours= last_msg_time / 100;
	}
	else
	{
		logDebug1("===========iGlobUserGroupId [%d]====Insrting New Timestamp ",groupid);

		sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER \
				SET \
				EAM_LAST_MSG_TIME=julidate(now()) \
				WHERE EAM_EXM_EXCH_ID='BSE' \
				AND EAM_DRV_FLAG='N' \
				AND EAM_SEGMENT = 'C'\
				AND EAM_GROUP_ID= %d;",groupid);
		logDebug2("sUpdQry :%s:",sUpdQry);

		if(mysql_query(DB_BseCon,sUpdQry) != SUCCESS)
		{
			sql_Error(DB_BseCon);
			mysql_rollback(DB_BseCon);

		}
		else
		{
			mysql_commit(DB_BseCon);
		}

	}



}

