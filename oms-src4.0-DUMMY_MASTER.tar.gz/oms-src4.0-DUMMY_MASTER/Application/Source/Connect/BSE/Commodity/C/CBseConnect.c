#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <time.h>
#include "OMBBseStrcut.h"


void ProcessArguments(LONG32 );
LONG32 last_msg_time; /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
SHORT iHours=0,iMinutes=0,iSec=0;
//#define	BSETWIDDLE(A)	BseTwiddle((char *) &A, sizeof(A))
pid_t	iMainPID = 0;
MYSQL	*DB_BseCon;
LONG32 iGlobUserGroupId;
LONG32	iSockfd;
LONG32	DloadQueue,WriteQueue,ReadQueue;
CHAR	sImlIPAddress [20];
LONG32	iImlPort ;
key_t   GlobShmKey;
char    TimeStamp[TIME_LENGTH];
struct  ForkProcess ForkProcess[MAX_NO_PROCESSES] ;
void ConnectToOracle();
void OpenMessageQueues();
main(LONG32 argc, CHAR **argv )
{
	LONG32	RetVal = FALSE ;
	//LONG32	ForkInd;
	pid_t	ForkInd;
	LONG32	Sig = 0,iMainWait;
	LONG32	MainWait;
	LONG32 	identifier;
	LONG32	iRetVal = FALSE ;
	struct OMB_HEADER *header ;
	sigset_t    MainSignalSet   ;

	setvbuf( stdout , NULL , _IONBF , 0 );
	setvbuf( stderr , NULL , _IONBF , 0 );
	setbuf( stdout , NULL );
	setbuf( stderr , NULL );

	DB_BseCon = DB_Connect();

	iGlobUserGroupId = atoi(argv[1]); 
	identifier = iGlobUserGroupId;
	logDebug1("iGlobUserGroupId is %d", iGlobUserGroupId);
	ProcessArguments (identifier);
	errno=0;


	for ( ; ; )  
	{
		signal(SIGTTOU,SIG_IGN);
		signal(SIGTTIN,SIG_IGN);
		signal( SIGHUP ,SIG_IGN);
		signal( SIGPIPE,SIG_IGN);
		signal( SIGBUS ,SIG_IGN);
		signal( SIGINT ,SIG_IGN);
		sigemptyset( &MainSignalSet );
		sigaddset ( &MainSignalSet , SIGTERM );
		sigaddset ( &MainSignalSet , SIGUSR1);

		GetParameters ( );
		InitSharedMemory();
		GetTimeForDownload ( );
		InitForkProcess ( );
		SlotInit( GlobShmKey );

		iSockfd = OpenPassiveSocket ( );
		logDebug1("iSockfd returned is %d ", iSockfd );

		if( iSockfd == ERROR )
		{
			logDebug1("Connection To BSE Failed...");
			exit(0);
		}

		OpenMessageQueues();

		RetVal = ProcessInitialConnection ();
		if ( RetVal == ERROR)
		{
			BSEconnectLogFatal ("Problem In ProcessInitialConnection");
			continue;
			exit(0);
		}

		EAMtimestamp(1); /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
		/**
		  PrintStatus ( 1 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_TRADERS_TRADES_REQUEST)==FALSE)
		  {
		  logDebug1("Unable To Process Members Trades Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 2 );

		 **/
		/**	if(QueryPersonalInfo( TC_EQU_BSE_QUERY_ORDERS_REQUEST)==FALSE)
		  {
		  logDebug1(" UNABLE TO PROCESS TC_QUERY_ORDERS_REQUEST");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }***/
		/**
		  PrintStatus ( 3 );
		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_RETURNED_ORDERS_REQUEST)==FALSE)
		  {	
		  logDebug1(" Unable to process Returned Orders Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 4 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_PERSONAL_STOPLOSS_ORDERS)==FALSE)
		  {
		  logDebug1(" Unable To Process Personal Stoploss Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 5 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_RETURNED_STOPLOSS_ORDERS_REQUEST)==FALSE)
		  {
		  logDebug1(" Unable To Process Returned Stoploss Orders Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  BSEconnectLogFatal("Returned StopLoss Order Download over");
		  PrintStatus ( 6 );
		 ***/
		/*****	if(QueryPersonalInfo( TC_EQU_BSE_QUERY_6A7A_REQUEST)==FALSE)
		  {
		  logDebug1("\n Unable To Process 6a7a Reports Download"); 
		  }  ***********/
		/**/
		if(DownloadEnd(TC_EQU_BSE_END_OF_DOWNLOAD)==FALSE)
		{
			logDebug1("DownloadEnd: Unable To Process End Of Download");
			close( iSockfd );
			exit(0);
		}

		BSEconnectLogFatal("Download Complete Normal Process Start");

		PrintStatus ( 7 );

		/*****************************--- To be uncommented in case News From BSe is to be provided****
		  if( QueryNewsCategory(TC_EQU_BSE_NEWS_CATEGORY_REQ)==FALSE)
		  {
		  logDebug1("\n Query News Category: Unable to process the Request ");
		  close ( iSockfd );
		  exit(0);
		  }
		 ****************************/
		logDebug1("Updating Shared Memory to UP for GrpId : %d",iGlobUserGroupId);
		iRetVal = UpdateExchStatus( iGlobUserGroupId,1 );
		if(iRetVal!=TRUE)
		{
			logDebug1("Unable To Update The Shared Memeory exit 1");
			BSEconnectLogFatal("Unable To Update The Shared Memeory exit");
			exit(1);
		}
		logDebug1("Forking Into Childs...");

		iMainPID = getpid();

		logDebug1(" Main Process ID :%d:",iMainPID);

		if ( ( ForkInd = fork( )) == 0 )
		{
			logDebug1("RECEIVE-CHILD Forked ...ProcessId Is :%d",getpid());
			ReceiveChild( );
		}

		if ( ForkInd != 0 )
		{
			UpdateForkProcess( RECVCHLD , ForkInd , RUNNING);
		}

		if ( ( ForkInd = fork( ) ) == 0 )
		{
			logDebug1("TRANSMIT-CHILD Forked ...ProcessId Is :%d",getpid());
			TransmitChild ( );
		}

		if (  ForkInd != 0 )
		{
			UpdateForkProcess( TRANSCHLD, ForkInd, RUNNING);
		}

		if ( ( ForkInd = fork( ) ) == 0 )
		{
			logDebug1("KEEPALIVE-CHILD Forked ...ProcessId Is :%d",getpid());
			KeepAliveChild ( );
		}

		if ( ForkInd != 0 )
		{
			UpdateForkProcess( KEEPALIVE, ForkInd, RUNNING);
		}
		/*********

		  if ( ( ForkInd = fork( ) ) == 0 )
		  {
		  logDebug1("\nClientChild  Forked ...ProcessId Is :%d",getpid());
		  ClientChild ( );
		  }
		  if ( ForkInd != 0 )
		  {
		  UpdateForkProcess( CLIENTREGREQ, ForkInd, RUNNING);
		  }
		 **********/
		if( ForkInd != 0)
		{
			sigprocmask ( SIG_BLOCK, &MainSignalSet, NULL);
			while( TRUE )
			{
				BSEconnectLogFatal("Successfully Connected To Exchange");
				iMainWait = 0 ;
				/**********
				  sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
				  sigemptyset( &MainSignalSet );
				//sigaddset (  &MainSignalSet , SIGCHLD);
				sigaddset (  &MainSignalSet , SIGUSR1);
				sigaddset (  &MainSignalSet , SIGTERM);
				sigprocmask ( SIG_BLOCK, &MainSignalSet, NULL);
				 ***********/
				logDebug1("Waiting for a Signal");
				iMainWait = sigwait( &MainSignalSet, &Sig);
				logDebug1("Got a Signal");
				sleep(1);

				logDebug1(" Process %d caught signal %d ",getpid(),Sig );	

				//if( Sig == SIGCHLD )
				if( Sig == SIGUSR1)
				{
					BSEconnectLogFatal("Connection Went Down");
					logDebug1("Connection Went Down");
					SignalHandlerSigChldMain ( ); 
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					break ;
				}
				if( Sig == SIGTERM )
				{
					logDebug1("Received a signal...");
					BSEconnectLogFatal("Application Close Requested");
					SignalHandlerSigTermMain ( Sig ); 
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					break ;
				}

			}
		}
	}/**FOR**/
}


void	ProcessArguments (LONG32 identifier) 
{
	LONG32 temp_identifier;
	CHAR		tempImpIp[ADDRESS_LEN];
	LONG32		tempImpPort;
	LONG32		tempUserId;
	logDebug1(" identifier is %d", identifier);
	temp_identifier = identifier;
	logDebug1(" temp_identifier is %d", temp_identifier);
	memset(sImlIPAddress,'NULL',20);
	logDebug1(" temp_identifier is %d", temp_identifier);
	strcpy(sImlIPAddress,getenv("IML_IP"));
	logDebug1(" IP ADDR 	= %s",sImlIPAddress);
	iImlPort = atoi(getenv("IML_PORT"));
	logDebug1(" PORT NO	= %d",iImlPort);
	logDebug1(" DETAILS OF DATA PICKED FROM EXCH_ADMINISTRATION_MASTER ");
	logDebug1(" __________________________________________________________ ");
	logDebug1(" IP ADDR 	= %s",sImlIPAddress);
	logDebug1(" PORT NO	= %d",iImlPort);
	logDebug1("Inside Function ProcessArguments...");
	logDebug1("The Iml ip address is %s ", sImlIPAddress );
	logDebug1("The Iml port is %d ", iImlPort );
	return ;
}



void	GetParameters ( )
{

	logDebug1("In function GetParameters");
	logDebug1("The iGlobUserGroupId is %d ", iGlobUserGroupId );
	logDebug1("iGlobUserGroupId [%d] ",iGlobUserGroupId);
	switch(iGlobUserGroupId)
	{
		case 1:	

			GlobShmKey   = Bse_CConn_Shm_1 ;
			logDebug1("Bse_CConn_Shm_1 [%d] ",Bse_CConn_Shm_1);
			break;
		case 2:	//GlobQueueKey = EquRmsbseToBse2 ;
			GlobShmKey   = Bse_CConn_Shm_2 ;
			logDebug1("	Bse_CConn_Shm_2 [%d] ",Bse_CConn_Shm_2);
			break;
		case 3:	//GlobQueueKey = EquRmsbseToBse3 ;
			GlobShmKey   = Bse_CConn_Shm_3 ;
			logDebug1("Bse_CConn_Shm_3 [%d] ",Bse_CConn_Shm_3);
			break;
		case 4:	//GlobQueueKey = EquRmsbseToBse4 ;
			GlobShmKey   = Bse_CConn_Shm_4 ;
			logDebug1("Bse_CConn_Shm_4 [%d] ",Bse_CConn_Shm_4);
			break;
		default :
			exit(1);
	}	
}


void    BSEconnectLogFatal( CHAR * message )
{
	CHAR    ProgName[10];
	CHAR	Message[100];
	memset( Message,' ',100);
	strcpy(Message,message);
	strcpy(ProgName,"BSEconnect");
	logFatal( "%s",Message );
	return;
}


void	OpenMessageQueues ( )
{
	logDebug1("Inside OpenMessageQueues...");

	if( ( WriteQueue =  OpenMsgQ( ConnToTrdMapBSECD)) == ERROR)
	{
		perror("OpenMsgQ :");
		close( iSockfd);
		sleep(10);
		exit( 1 );
	}
	logDebug1(" queue opened WriteQueue");

	/**************
	  if( ( DloadQueue = OpenMsgQ( BseToDnload )) == ERROR)
	  {
	  perror("OpenMsgQ :");
	  close( iSockfd);
	  sleep(10);
	  exit( 1 );
	  }	*****************/

	if( ( ReadQueue = OpenMsgQ( MapperToConnBSECD)) == ERROR)
	{
		perror("OpenMsgQ :");
		close( iSockfd);
		sleep(10);
		exit( 1 );
	} 


	logDebug1("The Q ids are WriteQueue=%d,ReadQueue=%d",WriteQueue,ReadQueue);
	return ;
}

LONG32 	ProcessInitialConnection ( )
{
	LONG32	RetVal = FALSE ;

	logDebug1("Inside ProcessInitialConnection...");

	logDebug1("Sending Registration Request...");

	if( HandleRegistration ( iSockfd ) == FALSE )
	{
		close( iSockfd );
		sleep(10);
		logDebug1("Error in HandleRegistration function Exiting...." ) ;
		logDebug1("Handle Registration BSEconnect - Terminating - RESTART ");
		return ERROR;
	}

	logDebug1("Sending Log-Off Request...");
	/**************************
	  if ( HandleLogOff( ) == FALSE)
	  {
	  logDebug1("\n\tLOG-OFF To Exchange Unsuccessfull...");
	  close( iSockfd );
	  sleep(10);
	  logDebug1("\n\tHandle LogOff BSEconnect - Terminating - RESTART ");
	  BSEconnectLogFatal("Handle LogOff BSEconnect - Terminating - RESTART ");
	  return	FATAL ;
	  } 

	  logDebug1("\n\tPlease Wait - Processing Going On........."); ********************/
	sleep(3);

	logDebug1("Sending LogOn Request....");

	if ( HandleLogOn( ) == FALSE)
	{
		logDebug1("Signon Problem...");
		close( iSockfd );
		sleep(10);
		logDebug1("Handle LogOn BSEconnect - Terminating - RESTART ");
		BSEconnectLogFatal("Handle LogOn BSEconnect - Terminating - RESTART ");
		return	ERROR;
	}
	return	TRUE;
}


void	TransmitChild( )
{
	struct 	OMB_ORDER_REQ *Packet	;
	//CHAR*	Buffer			;
	CHAR	Buffer	[RUPEE_MAX_PACKET_SIZE]		;
	LONG32	SentBytes		;
	LONG32	RecvBytes		;
	LONG32	iRetVal	= FALSE		;
	LONG32	PacketSize		;
	LONG32	SlotNumber		;
	LONG32	Flag			;
	LONG32	MaxTry = 0		;
	CHAR	Message[100]		;
	/*	CHAR	*pBseConnQryStat;*/
	/*	LONG32 	ShmUpdStat =TRUE;*/
	LONG32	Check = FALSE		;
	LONG32	ConnectionBreakCount = 0;
	LONG32	MsgQuery;
	struct  timeval TimePtr;
	/**
	  struct OMB_ADD_UPDATE_ORDER_REQ *BsePkt;
	  struct OMB_QUERY_MARKET_INFO_REQUEST                  *piMktInfo;
	  struct OMB_QUERY_MARKET_INFO_REQUEST                  IntMktInfo;
	  piMktInfo = &IntMktInfo;
	 **/

#ifdef OFFLINE
	/** Additions to avoid Update_Offline_Status for each packet **/
	struct PUMPER_FLAGS *PumperFlg;
	BOOL PumpFlg = TRUE;
#endif



	Packet  = (struct OMB_ORDER_REQ *)malloc( sizeof(struct OMB_ORDER_REQ));
	//	Buffer  = (CHAR *)malloc( sizeof(struct BSE_PACKET)); 
#ifdef OFFLINE
	PumperFlg = (struct PUMPER_FLAGS *)OpenSharedMemoryory(PumperFlgShm,PumperFlg_SIZE);
	if(PumperFlg == NULL)
	{
		logDebug1(" Error in Opening Shared Memory PumperFlgShm");
		/**	Exit(ERROR);	 **/
		exit(-1);     
	}
#endif
	//	logDebug1(" Updating Shared Memory to DOWN for %d",iGlobUserGroupId);
	//	UpdateExchStatus( iGlobUserGroupId,0 );

	/*	FOREVER*/
	for(;;)
	{
		memset( Packet 	,' ',sizeof(struct OMB_ORDER_REQ));	
		//memset( Buffer 	,' ',sizeof(struct BSE_PACKET));	
		memset( &Buffer 	,' ',RUPEE_MAX_PACKET_SIZE);	
		//	memset(piMktInfo,' ',sizeof(struct OMB_QUERY_MARKET_INFO_REQUEST ));

		do{
			logDebug1("-----------------------------------------------------");
			if(IsFreeSlot( GlobShmKey ))
			{

				ConnectionBreakCount = 0 ;
				MaxTry = 0; 
				logDebug1("TRANSMIT-CHILD :Waiting Before Read Queue..");

				//if((ReadMsgQ( ReadQueue , Buffer, sizeof(struct BSE_PACKET) , 0))!=TRUE)
				if((ReadMsgQ( ReadQueue , &Buffer, RUPEE_MAX_PACKET_SIZE , 0))!=TRUE)
				{
					logDebug1(" Error in ReadQ");
					exit ( 0 );	
				}	 

				//		memcpy( Packet,Buffer,sizeof(struct BSE_PACKET)) ;
				Packet = (struct OMB_ORDER_REQ *)&Buffer;
				//		memcpy(piMktInfo,Buffer,sizeof(struct OMB_QUERY_MARKET_INFO_REQUEST ));
				//		logDebug1("Security Id 	%d",piMktInfo->iScripCodes[0]);
				logDebug1("Packet->pHeader.iMsgLen = [%d]",Packet->pHeader.iMsgLen);
				logDebug1("sizeof(struct OMB_HEADER) = [%d]",sizeof(struct OMB_HEADER));
				//sleep(1);
				logDebug1("Transcode is %d",Packet->iMsgType);

				//	BSETWIDDLE(Packet->pHeader.iMsgLen);
				//	BSETWIDDLE(Packet->iMsgType);
				PacketSize = Packet->pHeader.iMsgLen + sizeof(struct OMB_HEADER) ;

				logDebug1("Packet Read From Queue...PacketSize is %d",PacketSize);	
				logDebug1("Transcode is %d",Packet->iMsgType);

				logDebug2("--------------Before Twiddle Printing Values----------------");

				logDebug2(" Packet->pHeader.iSlotNo        [%d]",Packet->pHeader.iSlotNo);
				logDebug2(" Packet->pHeader.iMsgLen       [%d]",Packet->pHeader.iMsgLen);

				logDebug2(" Packet->iMsgType       [%d]", Packet->iMsgType);
				logDebug2(" Packet.iScripCode     [%d]", Packet->iScripCode);
				logDebug2(" Packet.iMsgTag1       [%d]", Packet->iMsgTag1);
				logDebug2(" Packet.iQty           [%d]", Packet->iQty);
				logDebug2(" Packet.iRevealedQty   [%d]", Packet->iRevealedQty);
				logDebug2(" Packet.iRate          [%d]", Packet->iRate);
				logDebug2(" Packet.iTriggerRate   [%d]", Packet->iTriggerRate);
				logDebug2(" Packet.iReserved2     [%d]", Packet->iReserved2);
				logDebug2(" Packet.iReserved3     [%d]", Packet->iReserved3);
				logDebug2(" Packet.iFiller1       [%d]", Packet->iFiller1);
				logDebug2(" Packet.iFiller2       [%d]", Packet->iFiller2);

				logDebug2(" Packet.iMsgTag2       [%d]", Packet->iMsgTag2);
				logDebug2(" Packet.iOrderId       [%d]", Packet->iOrderId);
				logDebug2(" Packet.iLocationId    [%ld]",Packet->iLocationId);
				logDebug2(" Packet.iFiller3       [%d]", Packet->iFiller3);
				logDebug2(" Packet.iFiller4       [%d]", Packet->iFiller4);
				logDebug2(" Packet.iFiller5       [%d]", Packet->iFiller5);
				logDebug2(" Packet.sClientID      :%s:",Packet->sClientID);
				logDebug2(" Packet.sParticipantCode     :%s:",Packet->sParticipantCode);
				logDebug2(" Packet.sMsgTag3       :%s:",Packet->sMsgTag3);
				logDebug2(" Packet.sFiller6       :%s:",Packet->sFiller6);
				logDebug2(" Packet.cAUDCode       :%c:",Packet->cAUDCode);
				logDebug2(" Packet.cOrgBuySell    :%c:",Packet->cOrgBuySell);
				logDebug2(" Packet.cOrdType       :%c:",Packet->cOrdType);
				logDebug2(" Packet.cExecutionType       :%c:",Packet->cExecutionType);
				logDebug2(" Packet.iClientType    [%d]",Packet->iClientType);
				logDebug2(" Packet.iMktProtection [%d]",Packet->iMktProtection);
				logDebug2(" Packet.iRetention     [%d]",Packet->iRetention);


				logDebug2("--------------END-------------------");

				SlotNumber = GetFreeSlot ( GlobShmKey ) ;
				logDebug1("The Slot Number Received Is : %d",SlotNumber);

				Packet->pHeader.iSlotNo = SlotNumber ;


				logDebug1("805 SLOT NO is %d",Packet->pHeader.iSlotNo);
				logDebug1("805 SLOT NO is %d",SlotNumber);
				gettimeofday(&TimePtr,NULL);
				logDebug1("999SENDING--%d--%d--%d--%d",SlotNumber,Packet->iMsgType,TimePtr.tv_sec,TimePtr.tv_usec);

				/**	BSETWIDDLE(Packet->pHeader.iSlotNo);
				  BSETWIDDLE(Packet->pHeader.iMsgLen);
				  BSETWIDDLE(Packet->iMsgType);***/

				SentBytes = SendPacket( iSockfd, (CHAR*)Packet , PacketSize);

				if ( SentBytes < 0)
				{
					perror("Error While Sending :");
					logDebug1("Transmit Child :Exiting");
					BSEconnectLogFatal("Transmit Child :Exiting");
					free( Packet );
					free( Buffer );
					exit( 0 );
				}
				logDebug1("TRANSMIT-CHILD : Message Sent To Exchange ....");
				continue;
			}
			else
			{
				logDebug1("############# 4 After IsFreeSlot returning false ");
				Sleep(1000);
				MaxTry++;
				continue;
			}
		}while( MaxTry < MAX_TRY );

		if( MaxTry >=MAX_TRY && !IsFreeSlot( GlobShmKey ) )
		{
			logDebug1("Slot Found not free..");
			sprintf(Message,"Delay In Connection To Bombay Stock Exchange");
			SendPacketBackToUser( Message );
			BSEconnectLogFatal(Message);
			ConnectionBreakCount ++ ;
			continue ;
		}
		if( ConnectionBreakCount > MAX_CONNECT_BREAK )
		{
			BSEconnectLogFatal("Self Closing Connection Due To Unavailable Slot");
			logDebug1("Self Closing Connection Due To Unavailable Slot");
			free( Packet );
			free( Buffer );
			exit(-1);
		}
	}
	free( Packet );
	free( Buffer );
	/*	exit( 0 );*/
}


void ReceiveChild ( )
{
	CHAR* 	Packet ;
	LONG32	PacketSize;
	LONG32	RecvBytes;
	LONG32	TranScode;
	LONG32	iRetVal = FALSE ;
	LONG32 PacketNumber= 1;
	signal(SIGPIPE,SIG_IGN);
	struct timeval TimePtr;
	struct      OMB_QUERY_MKT_INF_RESP  pMktInqResp;
	struct 	OMB_HEADER_INT *pHeader;	

	Packet = (CHAR * )malloc(BSE_PACKET_SIZE); 
	logDebug1("Entered Receive Child...");

	for(;;)
	{
		memset( Packet ,NULL,BSE_PACKET_SIZE);	
		PacketSize = 0;

		logDebug1("RECVEIVE-CHILD : Waiting For Data From Exchange...");
		logDebug1("PACKET RECEIVED - Packet Number %d",PacketNumber);
		PacketNumber++;
		RecvBytes = RecvPacket (iSockfd, Packet );
		/****
		  memcpy(&pMktInqResp,Packet,sizeof(struct OMB_QUERY_MKT_INF_RESP));
		  logDebug1(" Twiddle ScripCode from EXCH is %d",pMktInqResp.pDtls[0].iScripCode);
		  gettimeofday(&TimePtr,NULL);
		 **/
		/**************** added in anagram *****************
		  BSETWIDDLE(((struct OMB_HEADER_INT *)Packet)->iMsgType);
		  BSETWIDDLE(((struct OMB_HEADER*)Packet)->iSlotNo);	
		  logDebug1("The TRANSCODE IS %d",((struct OMB_HEADER_INT *)Packet)->iMsgType);
		 **/
		/************ADDED FOR TAKING ROUND TRIP TIME**********/


		logDebug1("999RECEIVED--%d--%d--",((struct OMB_HEADER_INT *)Packet)->pHeader.iSlotNo,((struct OMB_HEADER_INT *)Packet)->iMsgType);
		logDebug1("iMsgType 	:%d:",((struct OMB_ADD_UP_DEL_ORD_RLY *)Packet)->iMsgType);
		logDebug1("iMsgTag1	:%d:",((struct OMB_ADD_UP_DEL_ORD_RLY *)Packet)->iMsgTag1);
		logDebug1("iRlyCode	:%d:",((struct OMB_ADD_UP_DEL_ORD_RLY *)Packet)->iRlyCode);
		logDebug1("sRelyText    :%s:",((struct OMB_ADD_UP_DEL_ORD_RLY *)Packet)->sRelyText);

		if (RecvBytes < 0)
		{
			logDebug1("Receive-Child : Error In Receive....");
			BSEconnectLogFatal("Receive-Child : Error In Receive....");
			free( Packet );
			close(iSockfd);
			exit(ERROR);
		}

		if (RecvBytes == 0)
		{
			logDebug1("Receive-Child : CONNECTION LOSS REQUESTED ");
			BSEconnectLogFatal("Receive-Child : CONNECTION LOSS REQUESTED ");
			/*****		free( Packet );
			  close(iSockfd);
			  exit(ERROR);*****/
			//logDebug1("Sending Signal to main process with pid :%d:",iMainPID);
			//kill(iMainPID,SIGCHLD);
			//kill(iMainPID,SIGUSR1);
			exit(ERROR);

		}
		/************** added in anagram ********************/
		BSETWIDDLE(((struct OMB_HEADER*)Packet)->iMsgLen);	
		/***BSETWIDDLE(((struct OMB_HEADER*)Packet)->iSlotNo);***/	
		PacketSize = ((struct OMB_HEADER*)Packet)->iMsgLen + sizeof(struct OMB_HEADER);


		SetSlotFree ( GlobShmKey ,((struct OMB_HEADER*)Packet)->iSlotNo );

		logDebug1("The Slot Number is %d",((struct OMB_HEADER*)Packet)->iSlotNo );

		if (((struct OMB_HEADER*)Packet)->iSlotNo == PROTOCOL_SLOT )
		{
			logDebug1("Reply-Child : Received A PROTOCOL Message Ignoring The Packet");
			TranScode = ((struct OMB_HEADER_INT *)Packet)->iMsgType ;
			logDebug1("Received a Packet with Transcode :%d",TranScode);
			continue;
		}
		else
		{
			TranScode = ((struct OMB_HEADER_INT *)Packet)->iMsgType ;
			logDebug1("Received a Packet with Transcode :%d Writing to BseRms Quueue...",TranScode);

			EAMtimestamp(0);  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/

			if(TranScode == TC_EQU_BSE_ORDER_REQ_RES || TranScode == TC_EQU_BSE_TRADE_CON_UMS || TranScode == TC_EQU_BSE_MKT_TO_LMT_CONVT || TranScode == TC_EQU_BSE_SP_OR_UMS || TranScode == TC_EQU_BSE_KILL_MIN_FILL_ORD )
			{
				WriteToBseRms( Packet, PacketSize);
			}
			if (TranScode == 1111)
			{
				logDebug1("Inside fCOMBInquiryResp ");
			}
			if (TranScode == 1521)
			{
				logDebug1("TRADE HAS ARRIVED");
				fTrade(Packet);

			}
			continue ;
		} 
	}/**FOR**/
	free( Packet );
	close(iSockfd);
}

/*
   LONG32  QueryPersonalInfo( LONG32 Transcode )
   {
   CHAR* 	RequestPacket 		;
   CHAR*	ReceivePacket  		;
   LONG32	PacketSize 		;
   LONG32	SentBytes  		;
   LONG32	RecvBytes  		;
   LONG32	iTranscode		;
   LONG32	Flag = FALSE		;
   LONG32 temp;  // *** ADDED FOR INCREAMENTAL DOWNLOAD **** /	



   logDebug1("In QueryPersonalInfo :...." ) ;
   if (Transcode == TC_EQU_BSE_QUERY_6A7A_REQUEST)
   {
   RequestPacket = (CHAR *)malloc( sizeof(struct OMB_QUERY_6A7A_INFO ));
   PacketSize = sizeof(struct OMB_QUERY_6A7A_INFO ) ;
   }
   else
   {
   RequestPacket 	= (CHAR *)malloc( sizeof(struct OMB_QUERY_PERSONAL_INFO) );
   PacketSize = sizeof(struct OMB_QUERY_PERSONAL_INFO) ;
   }
   RequestPacket 	= (CHAR *)malloc( sizeof(struct OMB_QUERY_PERSONAL_INFO) );
   ReceivePacket 	= (CHAR*)malloc( BSE_PACKET_SIZE );



   PrepareDownloadPacket ( Transcode , RequestPacket );

   logDebug2("RequestPacket iMsgType :%d:",((struct OMB_QUERY_PERSONAL_INFO *)RequestPacket)->iMsgType);

   SentBytes = SendPacket(iSockfd, RequestPacket, PacketSize );

   if (SentBytes < 0)
   {
   logDebug1("IN QueryPersonalInfo: Error in sent bytes");
   free( RequestPacket );
   free( ReceivePacket    );
   return	FALSE;	
   }

   do
   {
   logDebug1("Before Recv Func...........");
   RecvBytes = RecvPacket ( iSockfd , ReceivePacket );	

   if (RecvBytes < 0)
   {
   logDebug1("In QueryPersonalInfo : ERROR IN RECEIVING...");
   free( RequestPacket );
   free( ReceivePacket );
   return  FALSE;
   }

   if (RecvBytes == 0)
   {
   logDebug1("In QueryPersonalInfo : CONNECTION CLOSE REQUESTTED...");
   free( RequestPacket );
   free( ReceivePacket    );
   return  FALSE;
   }

   PacketSize = ((struct OMB_HEADER*)ReceivePacket)->iMsgLen + sizeof(struct OMB_HEADER) ;
   / ************ added in anagram ************************ /
//	BSETWIDDLE(((struct OMB_HEADER_INT*)ReceivePacket)->iMsgType);
iTranscode = ((struct OMB_HEADER_INT*)ReceivePacket)->iMsgType ;
logDebug1( "The Received Transcode is :%d: :%d: PacketSize: %d",iTranscode,Transcode , PacketSize );

if( iTranscode != Transcode)
{
	logDebug1(" Writing it LONG32o the BSetoRmsBse queue...");
	logDebug1("TEST1");
	WriteToBseRms( ReceivePacket , PacketSize );
	logDebug1("TEST1");
	Flag  = FALSE;
}	
else
{
	Flag = ReceiveQueryPersonalResponse ( ReceivePacket );
	logDebug1("The Flag Received is %d",Flag);

	if ( Flag == FALSE )
	{
		logDebug1("Error in QueryPersonalDownload ");
		BSEconnectLogFatal("Error in QueryPersonalDownload ");
		free( RequestPacket );
		free( ReceivePacket    );
		return(FALSE);
	}
}	
}while( Flag == FALSE );

	temp=0;  / *** ADDED FOR INCREAMENTAL DOWNLOAD **** /
while(TRUE)
{
	logDebug1("Entered While.....");
	memset( ReceivePacket , '\0',BSE_PACKET_SIZE );
	logDebug1("Waiting Before Receive ...");
	RecvBytes = RecvPacket ( iSockfd, ReceivePacket );	
	logDebug1(" Came out of wait on Socket ++++++++++++ %d ",RecvBytes);

	if ( RecvBytes < 0)
	{
		logDebug1("In QueryPersonalInfo : ERROR IN RECEIVING...");
		free( RequestPacket );
		free( ReceivePacket    );
		return(FALSE);
	}

	if ( RecvBytes == 0)
	{
		logDebug1("In QueryPersonalInfo : CONNECTION CLOSE REQUESTTED...");
		free( RequestPacket );
		free( ReceivePacket    );
		return(FALSE);
	}
	/ **************** added in anagram ************** /
		//	BSETWIDDLE(((struct OMB_HEADER*)ReceivePacket)->iMsgLen);
		//	BSETWIDDLE(((struct OMB_HEADER_INT *)ReceivePacket)->iMsgType);
		PacketSize = ((struct OMB_HEADER*)ReceivePacket)->iMsgLen + sizeof(struct OMB_HEADER) ;

	if( PacketSize > 10000)
		logDebug1("The packet is %100s",ReceivePacket);

	logDebug1("++++++++++ PacketSize is %d ",PacketSize );

	iTranscode = ((struct OMB_HEADER_INT *)ReceivePacket)->iMsgType;

	if( iTranscode == Transcode )
	{
		temp++;   / *** ADDED FOR INCREAMENTAL DOWNLOAD **** /
			logDebug1("Received A Download Packet [%d] --------",temp);
		WriteToDloadQ( ReceivePacket,PacketSize );
		continue;
	}
	else if( iTranscode == TC_EQU_BSE_END_OF_DOWNLOAD_1_UMS)
	{
		logDebug1(" ====================================");
		logDebug1(" RECEIVED THE END Of DOWNLOAD........");
		logDebug1(" ====================================");

		WriteToDloadQ( ReceivePacket, PacketSize );

		free( RequestPacket );
		free( ReceivePacket    );
		return TRUE	     ;
	}
	else if(iTranscode ==TC_EQU_BSE_END_OF_6A7A_DOWNLOAD)
	{
		logDebug1(" ====================================");
		logDebug1(" RECEIVED THE END Of 6A7A DOWNLOAD........");
		logDebug1(" ====================================");

		WriteToBseRms( ReceivePacket, PacketSize );

		free( RequestPacket );
		free( ReceivePacket    );
		return TRUE          ;
	}
	else 
	{
		logDebug1("TRANSCODE RECEIVED IS %d\n",iTranscode );
		WriteToBseRms( ReceivePacket,PacketSize );	
		logDebug1(" Written in queue and came out .. ++++++++++ ");
		continue;
	}
} / **WHILE** /
}

*/


/*
   void 	PrepareDownloadPacket (LONG32  Transcode,CHAR * Buffer)
   {
   LONG32 	iMsgTag;
   LONG32	PacketSize;
   LONG32	iMsgLen;
   struct  OMB_QUERY_PERSONAL_INFO *Packet;

   logDebug1("Inside PrepareDownloadPacket...");
   / * Added for IML version 42.0 by Bazid * /
   if(Transcode == TC_EQU_BSE_QUERY_6A7A_REQUEST)
   {
   Packet = (struct OMB_QUERY_6A7A_INFO*)malloc(sizeof(struct OMB_QUERY_6A7A_INFO));
   memset( Packet,' ', sizeof(struct OMB_QUERY_6A7A_INFO));
   }
   else
   {
   Packet = (struct OMB_QUERY_PERSONAL_INFO*)malloc(sizeof(struct OMB_QUERY_PERSONAL_INFO));
   memset( Packet,' ', sizeof(struct OMB_QUERY_PERSONAL_INFO));
   }
   switch( Transcode )
   {
   case 1091:
   Packet->iMsgType=TC_EQU_BSE_QUERY_QUOTES_REQUEST;
   break;
   case 1092:
   Packet->iMsgType=TC_EQU_BSE_QUERY_ORDERS_REQUEST;
   break;
   case 1095:
   Packet->iMsgType=TC_EQU_BSE_QUERY_TRADERS_TRADES_REQUEST;
   break;
   case 1096:
   Packet->iMsgType=TC_EQU_BSE_QUERY_MEMBERS_TRADES_REQUEST;
   break;
   case 1097:
   Packet->iMsgType=TC_EQU_BSE_QUERY_PERSONAL_STOPLOSS_ORDERS;
   logDebug1("The Transcode sent is %d",Packet->iMsgType);
   break;
   case 1098:
   Packet->iMsgType=TC_EQU_BSE_QUERY_CKT_LIMIT;
   break;
   case 1170:
   Packet->iMsgType=TC_EQU_BSE_QUERY_RETURNED_ORDERS_REQUEST;
   break;
   case 1171:
   Packet->iMsgType=TC_EQU_BSE_QUERY_RETURNED_QUOTES_REQUEST;
   break;
   case 1173:
   Packet->iMsgType=TC_EQU_BSE_QUERY_RETURNED_STOPLOSS_ORDERS_REQUEST;
   break;
   case 10004:
   Packet->iMsgType=TC_EQU_BSE_OWN_DEFAULT_IN_AUCTION_REQUEST;
   break;
   case 10008:
   Packet->iMsgType=TC_EQU_BSE_QUERY_AUCTION_OFFERS_REQUEST;
   break;
   case 10011:
   Packet->iMsgType=TC_EQU_BSE_AUC_SCRIP_DLOAD_UMS;
   break;
   case 21501:
   Packet->iMsgType=TC_EQU_BSE_QUERY_6A7A_REQUEST;
   break;
   }

   Packet->iMsgTag=0;
   if ( Transcode == TC_EQU_BSE_QUERY_6A7A_REQUEST)
   {
   Packet->pHeader.iMsgLen = sizeof(struct OMB_QUERY_6A7A_INFO) - sizeof(struct OMB_HEADER) ;
   logDebug1(" ++++++++++++++++ 6A7A Message Length = %d",Packet->pHeader.iMsgLen);
   }
   else	
{
	Packet->pHeader.iMsgLen= sizeof(struct OMB_QUERY_PERSONAL_INFO) - sizeof(struct OMB_HEADER) ;
}
Packet->pHeader.iSlotNo = 4; 
logDebug1("The Transcode sent is %d",Packet->iMsgType);
/ **********************
Packet->ombbsetime.Hour = GetHour( TimeStamp );
Packet->ombbsetime.Minute = GetMinute ( TimeStamp );
Packet->ombbsetime.Second = GetSeconds ( TimeStamp );
********************* /
memset(&Packet->ombbsetime,0,sizeof(struct OMB_BSE_TIME));
/ ********** added in angram ************************** /

Packet->iMsgTag = 4;

/ ***	BSETWIDDLE(Packet->iMsgTag);
BSETWIDDLE(Packet->pHeader.iMsgLen);
BSETWIDDLE(Packet->pHeader.iSlotNo);
BSETWIDDLE(Packet->iMsgType);**** /




//	Packet->ombbsetime.cSecond 	= iSec + '0';   / *** ADDED FOR INCREAMENTAL DOWNLOAD *** * /
//	Packet->ombbsetime.cMinute 	= iMinutes + '0';  / *** ADDED FOR INCREAMENTAL DOWNLOAD **** /
//	Packet->ombbsetime.cHour 	= iHours + '0';  / *** ADDED FOR INCREAMENTAL DOWNLOAD **** /

Packet->ombbsetime.cSecond      =  '0';   // *** ADDED FOR INCREAMENTAL DOWNLOAD *** * /
Packet->ombbsetime.cMinute      =  '0';  // *** ADDED FOR INCREAMENTAL DOWNLOAD **** /
Packet->ombbsetime.cHour        =  '0'; 

logDebug1("Incremental Download Time [%c:%c:%c]  The Transcode [%d]",Packet->ombbsetime.cHour,Packet->ombbsetime.cMinute,Packet->ombbsetime.cSecond,Packet->iMsgType);
logDebug2("iMsgTag 		:%d:",Packet->iMsgTag);
logDebug2("pHeader.iMsgLen	:%d:",Packet->pHeader.iMsgLen);
logDebug2("pHeader.iSlotNo	:%d:",Packet->pHeader.iSlotNo);
logDebug2("iMsgType		:%d:",Packet->iMsgType);

memcpy( Buffer,Packet,sizeof(struct OMB_QUERY_PERSONAL_INFO));
free(Packet);
return ;
}
*/
/*
   LONG32  ReceiveQueryPersonalResponse (CHAR * QueryPersonalResp)
   {
   struct OMB_QUERY_INFO_RESP * pQueryPersonalInfoResp;
   pQueryPersonalInfoResp=(struct OMB_QUERY_INFO_RESP *)malloc(sizeof(struct OMB_QUERY_INFO_RESP));

   memcpy(pQueryPersonalInfoResp,QueryPersonalResp,sizeof(struct OMB_QUERY_INFO_RESP));	
   logDebug1("The Reply Code is %d",pQueryPersonalInfoResp->iRepCode);

   if(pQueryPersonalInfoResp->iRepCode==0)
   {
   logDebug1("--------------------------------------");
   logDebug1("Download Request For Transcode %d Successfull",pQueryPersonalInfoResp->iMsgType);
   logDebug1("--------------------------------------");
   free(pQueryPersonalInfoResp);
   logDebug1("After Free...");
   return TRUE;
   }
   else
   {
   logDebug1("--------------------------------------");
   logDebug1("Download Request For Transcode %d Failed ...",pQueryPersonalInfoResp->iMsgType);
   logDebug1("--------------------------------------");
   free(pQueryPersonalInfoResp);
   return FALSE;
   }

   }
 */
LONG32  DownloadEnd( LONG32 Tcode )
{
	LONG32	PacketSize;

	struct END_DOWNLOAD *pEndDownload;

	logDebug1("Inside End of Download...");

	pEndDownload=(struct END_DOWNLOAD *)malloc(sizeof(struct END_DOWNLOAD));

	pEndDownload->pHeader.iSlotNo = 0 ;
	pEndDownload->pHeader.iMsgLen = sizeof(struct END_DOWNLOAD) - sizeof(struct OMB_HEADER);
	PacketSize = sizeof( struct END_DOWNLOAD) ;
	pEndDownload->iMsgType= TC_END_OF_DOWNLOADS ;
	pEndDownload->iMsgTag = 1 ;

	logDebug2("pEndDownload->pHeader.iSlotNo = %d",pEndDownload->pHeader.iSlotNo);
	logDebug2("pEndDownload->pHeader.iMsgLen = %d",pEndDownload->pHeader.iMsgLen);
	logDebug2("pEndDownload->iMsgType = %d",pEndDownload->iMsgType);
	logDebug2("pEndDownload->iGroupId = %d",pEndDownload->iMsgTag);

	//	WriteToDloadQ ( pEndDownload, PacketSize);

	free(pEndDownload);
	return TRUE;
}



LONG32 RecvPacket ( LONG32 sockfd, CHAR* packet ) 
{
	LONG32 RecvBytes , ErrorCount = 1,ReadBytes = 0,errorno;
	CHAR *  buffer ;
	LONG32	BreakCounter = 0;
	LONG32	BytesToRead  = 0;

	logDebug1("Inside Receive packet ");	
	buffer = (CHAR *) malloc( BYTES_TO_READ );
	memset(buffer ,' ',BYTES_TO_READ);
	logDebug1("*****");
	BytesToRead = sizeof(struct OMB_HEADER) ;

	for( ; ; )
	{
		RecvBytes = recv( sockfd ,buffer ,BytesToRead, MSG_PEEK );	
		logDebug1("The received Bytes is %d",RecvBytes);

		if( RecvBytes <= 0)
		{
			logDebug1("In PEEK Received Bytes Less Than Equal To Zero...");
			perror("Error is :");
			BSEconnectLogFatal("In PEEK Received Bytes Less Than Equal To Zero...");
			free(buffer);
			return RecvBytes ;
		}

		if( RecvBytes < BytesToRead )
		{
			logDebug1("Full Header not received");
			if (BreakCounter <= BREAKCOUNTER )
			{
				BreakCounter ++;
				Sleep(10);
				continue;
			}
			else
			{
				logDebug1("Inside Else Full Header not Received...");
				BytesToRead = ERROR ;
				free(buffer);
				BytesToRead ;
			}
		}
		else
		{
			BreakCounter = 0;
			/***************Added in anagram ***************/
			//	BSETWIDDLE(((struct OMB_HEADER *)buffer)->iMsgLen);
			//	BSETWIDDLE(((struct OMB_HEADER *)buffer)->iSlotNo);
			BytesToRead = ((struct OMB_HEADER *)buffer)->iMsgLen + sizeof(struct OMB_HEADER) ;
			logDebug1(" The Bytes to read from the exchange as given by the exchange are : %d ", BytesToRead );

			if ( (((struct OMB_HEADER *)buffer)->iMsgLen <= 0) || ( BytesToRead > BYTES_TO_READ)  )
			{
				logDebug1("Message Length received is Zero...Disconnecting");
				BytesToRead = ERROR ;
				free(buffer);
				return BytesToRead ;

			}
			for( ; ; )
			{
				RecvBytes = recv( sockfd ,buffer ,BytesToRead, MSG_PEEK );	
				if ( RecvBytes < BytesToRead )
				{
					if (BreakCounter <= BREAKCOUNTER )
					{
						BreakCounter ++ ;
						logDebug1("Sleeping for 100 MS");
						Sleep(100);
						continue;
					}
					else
					{
						logDebug1("Full Packet Not Received ...");		
						BytesToRead = ERROR ;
						free(buffer);
						return BytesToRead ;
					}
				}	
				else
				{
					break;
				}

			}/**FOR ENDS**/
		}/**ELSE ENDS**/
		break ;
	}/**FOR ENDS**/

	RecvBytes = recv( sockfd , packet,BytesToRead ,0) ;
	free(buffer);
	return RecvBytes ;
}


LONG32	SendPacket ( LONG32 sockfd ,CHAR * packet ,size_t size )
{
	signal(SIGPIPE,SIG_IGN);
	LONG32 SentBytes,ErrorCount = 1;
	logDebug1("Inside SendPacket... sockfd passed is %d", sockfd );
	logDebug1(" Size is %d ", size );
	do
	{
		SentBytes = send ( sockfd, packet, size , 0 );
		if (SentBytes < 0)
		{
			logDebug1("There is some error...");
			perror("TCP Send Problem :");
			BSEconnectLogFatal("TCP Send Problem :");
			ErrorCount ++;
		}
	}
	while((SentBytes < 0)&&(ErrorCount < BREAKCOUNTER));

	if( (SentBytes < 0) && (ErrorCount >= BREAKCOUNTER))
	{
		BSEconnectLogFatal("Found A Persistent Problem While Sending");
		exit(0) ;
	}
	return(SentBytes);
}


LONG32	QueryIndexValue (LONG32 Tcode )
{
	LONG32	RetVal ;
	LONG32	SentBytes,RecvBytes;
	LONG32	PacketSize ;
	LONG32	Flag = FALSE;

	CHAR	*QueryIndexReq ;
	CHAR	*LogOnResp ;

	QueryIndexReq  = (CHAR *)malloc( sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST)) ;
	LogOnResp = (CHAR *)malloc( sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY)) ;

	logDebug1("In QueryIndexValue ");

	if(  ( RetVal = PrepareQueryIndexValue (QueryIndexReq )) == TRUE )
	{
		//BSETWIDDLE(((struct OMB_HEADER*)QueryIndexReq)->iMsgLen);
		PacketSize = ((struct OMB_HEADER*)QueryIndexReq)->iMsgLen + sizeof(struct OMB_HEADER) ;
		//BSETWIDDLE(((struct OMB_HEADER*)QueryIndexReq)->iMsgLen);
		SentBytes = SendPacket (iSockfd, QueryIndexReq, PacketSize );
		if( SentBytes < 0)
		{
			free(QueryIndexReq);
			free(LogOnResp);
			BSEconnectLogFatal("Query Index Sentbytes Failed");
			return FALSE;
		}
	}
	else
	{
		free(QueryIndexReq);
		free(LogOnResp);
		BSEconnectLogFatal("Query Index Sentbytes Failed");
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, LogOnResp );	
		logDebug1("Received A packet from Exchange ...");
		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			free(QueryIndexReq);
			free(LogOnResp);
			return FALSE;
		}
		if( RecvBytes == 0)
		{
			free(QueryIndexReq);
			free(LogOnResp);
			return FALSE;
		}
		if ( (Flag = ReceiveQueryIndexValue (LogOnResp )) == TRUE )
		{
			free(LogOnResp) ;
			free(QueryIndexReq) ;
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			continue ;
		}
		else
		{
			free(LogOnResp) ;
			free(QueryIndexReq) ;
			return FALSE ;
		}
	}while( Flag == RETRY );
}


LONG32  PrepareQueryIndexValue (CHAR *QueryIndexReq  )
{

	struct OMB_QUERY_INDEX_VALUES_REQUEST *pQueryIndex;

	pQueryIndex = (struct OMB_QUERY_INDEX_VALUES_REQUEST *)malloc(sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST ));

	logDebug1("In PrepareQueryIndexValue ");

	memset(QueryIndexReq,' ',sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST) ) ;
	memset(pQueryIndex, ' ',sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST));

	pQueryIndex->pHeader.iSlotNo = 1;
	pQueryIndex->pHeader.iMsgLen = sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST) - sizeof(struct OMB_HEADER) ;
	pQueryIndex->iMsgType = TC_EQU_BSE_QUERY_INDEX_DETAILS_REQUEST  ;	
	pQueryIndex->iMsgTag = 1005;	
	pQueryIndex->iIndexCode = 2 ;              /*** to be confirmed **/	
	pQueryIndex->cDirection = 'P' ;              /*** to be confirmed **/	


	/**	BSETWIDDLE(pQueryIndex->pHeader.iSlotNo);
	  BSETWIDDLE(pQueryIndex->pHeader.iMsgLen);
	  BSETWIDDLE(pQueryIndex->iMsgType);
	  BSETWIDDLE(pQueryIndex->iIndexCode);
	  BSETWIDDLE(pQueryIndex->iMsgTag);***/

	memcpy( QueryIndexReq,(CHAR*)pQueryIndex, sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST ));

	free(pQueryIndex);
	return 	TRUE ; 
}




LONG32	HandleLogOn ( )
{
	LONG32	RetVal ;
	LONG32	SentBytes,RecvBytes;
	LONG32	PacketSize ;
	LONG32	Flag = FALSE;
	LONG32	UserId;

	CHAR	*LogOnReq ;
	CHAR	*LogOnResp ;

	LogOnReq  = (CHAR *)malloc( BSE_PACKET_SIZE ) ;
	LogOnResp = (CHAR *)malloc( BSE_PACKET_SIZE ) ;

	logDebug1("In HandleLogOn...");

	UserId = iGlobUserGroupId ;
	if(  ( RetVal = PrepareLogOnPacket (LogOnReq ,UserId )) == TRUE )
	{
		/*************** Added in anagram ***********************/
		//	BSETWIDDLE(((struct OMB_HEADER*)LogOnReq)->iMsgLen);
		PacketSize = ((struct OMB_HEADER*)LogOnReq)->iMsgLen + sizeof(struct OMB_HEADER) ;
		//	BSETWIDDLE(((struct OMB_HEADER*)LogOnReq)->iMsgLen);
		SentBytes = SendPacket (iSockfd, LogOnReq, PacketSize );

		if( SentBytes < 0)
		{
			free(LogOnReq);
			free(LogOnResp);
			BSEconnectLogFatal("SentBytes Failed 1");
			return FALSE;
		}
	}
	else
	{
		free(LogOnReq);
		free(LogOnResp);
		BSEconnectLogFatal("SentBytes Failed 2");
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, LogOnResp );	
		logDebug1("Received A packet from Exchange ...");

		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}

		if( RecvBytes == 0)
		{
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}

		if ( (Flag = ReceiveLogOnResp (LogOnResp ,UserId )) == TRUE )
		{
			free(LogOnResp) ;
			free(LogOnReq) ;
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			continue ;
		}
		else
		{
			free(LogOnResp) ;
			free(LogOnReq) ;
			return FALSE ;
		}
	}while( Flag == RETRY );
}




LONG32  HandleLogOff( )
{

	LONG32     RetVal ;
	LONG32     SentBytes,RecvBytes ;
	LONG32	PacketSize ;
	LONG32	Flag ;
	LONG32	UserId;

	CHAR   *LogOffReq ;
	CHAR   *LogOffResp ;

	LogOffReq  = ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
	LogOffResp = ( CHAR *)malloc( BSE_PACKET_SIZE ) ;

	logDebug1("In HandleLogOff ....");

	UserId = iGlobUserGroupId ;

	if( (RetVal = PrepareLogOffPacket(LogOffReq , UserId)) == TRUE )
	{
		logDebug1("This is before sending packet to exchange...");
		/**********Added in anagram **********************/	
		//		BSETWIDDLE(((struct OMB_HEADER*)LogOffReq)->iMsgLen);

		PacketSize = ((struct OMB_HEADER*)LogOffReq)->iMsgLen + sizeof(struct OMB_HEADER) ;	
		//		BSETWIDDLE(((struct OMB_HEADER*)LogOffReq)->iMsgLen);

		logDebug1("The Packet Size is %d",PacketSize);
		SentBytes = SendPacket (iSockfd,LogOffReq,PacketSize ); 

		if( SentBytes < 0)
		{
			free(LogOffReq);
			free(LogOffResp);
			BSEconnectLogFatal("Error in PrepareLogOffPacket.SendBytes less than 0");
			return FALSE ;
		}

	}
	else
	{
		free(LogOffReq);
		free(LogOffResp);
		BSEconnectLogFatal("Error in PrepareLogOffPacket.Failed");
		return FALSE ;
	}

	logDebug1("Waiting To Receive Logoff Response...");
	RecvBytes = RecvPacket ( iSockfd, LogOffResp );
	logDebug1("tReceived The Packet for Logoff...");

	if ( RecvBytes < 0 )
	{
		logDebug1("Error in RecvPacket ..");
		free( LogOffReq );
		free( LogOffResp );
		BSEconnectLogFatal("Error in RecvPacket ..");
		return( FALSE );
	}

	if ( RecvBytes == 0)
	{
		logDebug1("Connection close requested..");
		free( LogOffReq );
		free( LogOffResp );
		BSEconnectLogFatal("Connection close requested..");
		return( FALSE );
	}

	if ( (Flag = ReceiveLogOffResp( LogOffResp ,UserId )) == TRUE )
	{
		free(LogOffResp) ;
		free(LogOffReq) ;
		return TRUE;
	}
	else
	{
		free(LogOffResp) ;
		free(LogOffReq) ;
		BSEconnectLogFatal("Receive Log Off Failed..");
		return FALSE ;
	}

}



LONG32	HandleRegistration (LONG32 sockfd )
{
	LONG32 	RetVal,SentBytes,RecvBytes;
	LONG32	ErrorCount = 0;
	LONG32	PacketSize;

	CHAR	*UserRegReq,*UserRegResp;
	LONG32	UserId;

	UserRegReq   = (CHAR *)malloc(sizeof(CHAR)*REGISTRATION_LEN) ;
	UserRegResp  = (CHAR *)malloc(sizeof(CHAR)*REGISTRATION_LEN);

	UserId = iGlobUserGroupId ;
	logDebug1("In HandleRegistration ...");
	if( ( RetVal = PrepareRegistrationPacket ( UserRegReq ,UserId )) == TRUE  )
	{
		/*****************
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iMsgLen);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iSlotNo);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->iMsgType);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->iSlotNo);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->MmbrId);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->TraderId);

		 *******************/

		//	BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iMsgLen);

		PacketSize = ((struct OMB_HEADER*)UserRegReq)->iMsgLen + sizeof(struct OMB_HEADER);

		//	BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iMsgLen);
		SentBytes = SendPacket(sockfd,UserRegReq,PacketSize);
		if( SentBytes < 0)
		{
			free( UserRegResp );
			free( UserRegReq );
			return FALSE ;
		}
	}
	else
	{
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}

	RecvBytes = RecvPacket (sockfd, UserRegResp );	
	if ( RecvBytes < 0 )
	{
		logDebug1("Error in RecvPacket...");
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}
	if ( RecvBytes == 0)
	{
		logDebug1("Connection close requested..");
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}

	if ( ReceiveRegistrationResp ( UserRegResp ) == TRUE)
	{
		free( UserRegResp );
		free( UserRegReq );
		return( TRUE );
	}
	else
	{
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}
}



LONG32 	ReceiveRegistrationResp (CHAR *UserRegResp )
{

	struct OMB_REPLY_ERR_MSG_PCOL* pUserRegResp ;


	pUserRegResp = (struct OMB_REPLY_ERR_MSG_PCOL* )malloc \
		       (sizeof(struct OMB_REPLY_ERR_MSG_PCOL ));

	logDebug1("In ReceiveRegistrationResp");

	memcpy( pUserRegResp, UserRegResp, sizeof(struct OMB_REPLY_ERR_MSG_PCOL));
	/****************Added in anagram ****************/
	/**	BSETWIDDLE(pUserRegResp->iMsgType);
	  BSETWIDDLE(pUserRegResp->iMsgTag);
	  BSETWIDDLE(pUserRegResp->iErrorNo);
	 **/
	logDebug1(" pUserRegResp->iMsgType 	= %d", pUserRegResp->iMsgType);
	logDebug1(" pUserRegResp->iMsgTag 	= %d", pUserRegResp->iMsgTag);
	logDebug1(" pUserRegResp->iErrorNo 	= %d", pUserRegResp->iErrorNo);

	switch( pUserRegResp->iMsgType  )
	{
		case 0 :	
			logDebug1("Registration Successful..." )   ;
			break ;
		case 100 :
			logDebug1("Invalid Message Type ");
			return FALSE ;
			break;

		case 800 : 
			logDebug1("Refused Connection ");
			return FALSE ;
			break;

		case 801 :
			logDebug1("Slot Full ");
			return FALSE ;
			break;
		case 804 :
			logDebug1("Slot Full ");
			return FALSE ;
			break;
		case 802 :
			logDebug1("Application Error");
			return FALSE ;
			break;

		case 803 :
			logDebug1("Invalid Access");	
			return FALSE ;
			break;
		case 805 :
			logDebug1("Invalid Slot");	
			return FALSE ;
			break;
		default :
			logDebug1("Undefined Error");	
			return FALSE ;
			break;
	}

	return TRUE ;
}

void  	KeepAliveChild ( )
{
	LONG32 i,Counter;
	LONG32 RetVal;
	LONG32 processid;
	LONG32 iSlotNo,iMsgLen ;
	LONG32	iMsgType ;
	CHAR *  packet ;
	LONG32	packetsize;

	logDebug1("Inside KeepAliveChild..."); 


	packet = (struct OMB_KEEP_ALIVE_MSG_PCOL *)malloc(sizeof(struct OMB_KEEP_ALIVE_MSG_PCOL));


	for( ; ; )
	{
		/**for( Counter=0;Counter < 8;Counter ++)***/
		sleep(60);	
		memset( packet,' ',sizeof(struct OMB_KEEP_ALIVE_MSG_PCOL));

		((struct OMB_KEEP_ALIVE_MSG_PCOL*)packet)->pHeader.iSlotNo = PROTOCOL_SLOT ;
		((struct OMB_KEEP_ALIVE_MSG_PCOL*)packet)->pHeader.iMsgLen = sizeof(struct OMB_KEEP_ALIVE_MSG_PCOL) - sizeof(struct OMB_HEADER) ;
		((struct OMB_KEEP_ALIVE_MSG_PCOL*)packet)->iMsgType = TC_EQU_BSE_KEEP_ALIVE_MSG_PROT ;
		/***************** added in anagram *********************/
		/**		BSETWIDDLE(((struct OMB_KEEP_ALIVE_MSG_PCOL*)packet)->pHeader.iSlotNo);
		  BSETWIDDLE(((struct OMB_KEEP_ALIVE_MSG_PCOL*)packet)->pHeader.iMsgLen);
		  BSETWIDDLE(((struct OMB_KEEP_ALIVE_MSG_PCOL*)packet)->iMsgType);
		 **/
		packetsize = sizeof(struct OMB_KEEP_ALIVE_MSG_PCOL) ;

		logDebug1("Before Sending KeepAlive Packet..");
		RetVal = SendPacket ( iSockfd,packet,packetsize);
		logDebug1("Packet Sent For KeepAlive....");

		if( RetVal < 0)
		{
			free( packet );
			exit(1);
		}
		if( RetVal = 0)
		{
			logDebug1("Exiting from KeepAlive..");
			free( packet );
			exit(1);
		}
	}
	free( packet );
}

LONG32	OpenPassiveSocket( )
{
	LONG32 	sock = 0 ;
	struct	sockaddr_in ServAddr;
	LONG32	ErrorCount = 0;
	LONG32	RetVal = -1;
	LONG32	MaxTry = 0;

	logDebug1("Inside OpenPassiveSocket..");

	memset( ( CHAR * ) &ServAddr, 0, sizeof ( ServAddr ) );

	do
	{
		if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
		{
			perror("Trying to open Socket Failed :");
			BSEconnectLogFatal("Trying to open Socket Failed");
			sleep(1);
			ErrorCount ++;
			continue ;
		}

		if( sock > 0 )
		{	
			logDebug1("The IML address is %s ", sImlIPAddress );
			logDebug1("The IML port is %d ", iImlPort );
			ServAddr.sin_family = AF_INET ;
			ServAddr.sin_addr.s_addr = inet_addr(sImlIPAddress);	
			ServAddr.sin_port = htons(iImlPort); 

			do
			{
				RetVal = connect(sock,(struct sockaddr *) &ServAddr,sizeof(struct sockaddr));	
				logDebug1("The Return value is %d",RetVal );
				perror("Error Connecting IML ");

				if ( RetVal == ERROR)
				{
					MaxTry ++;
					sleep(10);
					perror("Connect Failed :");
					close(sock);
					Sleep(100);

					if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
					{
						perror("Trying to open Socket Failed :");
						sleep(1);
						ErrorCount ++;
						break;
					}
				}
			}while(RetVal < 0 && MaxTry <= MAX_TRY );
		}
	}while(ErrorCount <= MAX_TRY && sock < 0);

	if(ErrorCount >= MAX_TRY || sock < 0)
	{
		logDebug1("NO SOCKET CONNECTION.....IML NOT UP");
		logDebug1("PLEASE CONTACT SYSTEM ADMINISTRATOR");
		return ERROR;
	}
	return sock;
}


void    Sleep(LONG32  TimetoSleep )
{
	poll((struct pollfd **) NULL, 0,TimetoSleep  );
}

/***********
System  :EIBS
Module  :NETWORK
Prog    :
Date    :Mon Jan 10 11:07:40 GMT 2001
Author  :Diptaneal Roy
Argument:
Dependencies:
ProgType:
Comments:
 **********/

void SignalHandlerSigTermMain (LONG32 dummy)
{
	LONG32 i,RetVal;
	LONG32 UserId;
	CHAR Message[100];
	LONG32 Check= FALSE;
	LONG32 Status;
	sigset_t    MainSignalSet   ;

	logDebug1(" In SignalHandlerSigTermParent ");

	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	logDebug1("Closed The Socket Connection...");
	RetVal = UpdateExchStatus( iGlobUserGroupId,0 );

	if ( RetVal == TRUE )
		mysql_commit(DB_BseCon);
	close ( iSockfd );
	sleep(5);

	sprintf(Message,"Connection Closed To Bombay Stock Exchange");
	do{
		SendPacketBackToUser( Message );
		Check = CheckQueueForPendingPackets( );
	}while( Check == TRUE );

	for( i=0 ; i<MAX_NO_PROCESSES ;i++)
	{
		logDebug1("Killing the process with Id %d",ForkProcess [i].ProcessId);
		if (ForkProcess [i].ProcessId != UNUSED )
		{
			kill(ForkProcess [i] .ProcessId,SIGKILL);
		}
	}
	sleep(2);

	for( i=0 ; i<MAX_NO_PROCESSES ;i++)
	{
		waitpid(ForkProcess [i].ProcessId ,&Status,WNOHANG);
	}
	for( i=0 ; i<MAX_NO_PROCESSES ;i++)
	{
		ForkProcess [i].ProcessId = UNUSED ;	
	}

	BSEconnectLogFatal("SignalHandlerSigTermMain");
	exit (1);
}


void	InitForkProcess ( )
{
	LONG32	Index;
	logDebug1("Inside InitForkProcess...");
	for( Index =0; Index < MAX_NO_PROCESSES ;Index ++)
	{
		ForkProcess[Index].ProcessId = UNUSED;
		ForkProcess[Index].ProcessStatus = UNUSED;
	}
	return;
}


void	UpdateForkProcess ( LONG32 Index, LONG32 ProcessId, LONG32 Status)
{
	ForkProcess[Index].ProcessId = ProcessId ;
	ForkProcess[Index].ProcessStatus = Status ;
	return ;
}


void	SignalHandlerSigChldMain ( )
{
	LONG32 Check = FALSE ;
	LONG32 RetVal = FALSE;
	LONG32 Index ;
	CHAR Message[100];
	LONG32 Status;

	logDebug1("Entered SignalHandlerSigChldMain...");
	RetVal = UpdateExchStatus( iGlobUserGroupId, 0 );

	if (RetVal == TRUE )
		mysql_commit(DB_BseCon);	
	close( iSockfd );
	sleep(10);

	sprintf(Message,"Connection Closed To Bombay Stock Exchange");

	do{
		/*		SendPacketBackToUser( Message );*/
		Check = CheckQueueForPendingPackets( );
	}while( Check == TRUE );

	for ( Index = 0;Index < MAX_NO_PROCESSES;Index ++)
	{
		if( ForkProcess[Index].ProcessStatus != UNUSED )
		{
			logDebug1("Main Process Killed Child Pid :%d",ForkProcess[Index].ProcessId);
			kill( ForkProcess[Index].ProcessId, SIGKILL);
			sleep(5);
		}
	}

	system("date >>log32");

	for( Index=0 ; Index<MAX_NO_PROCESSES ;Index++)
	{
		waitpid(ForkProcess [Index].ProcessId ,&Status,WNOHANG);
	}
	for( Index=0 ; Index<MAX_NO_PROCESSES ;Index++)
	{
		ForkProcess [Index].ProcessId = UNUSED ;	
	}
	/****** Added to initialize the shared memory after the process gets killed *****/
	InitSharedMemory();
	return ;
}


LONG32	CheckQueueForPendingPackets ( )
{
	LONG32 Retval = FALSE ;
	struct msqid_ds *  buffer ;
	LONG32  Bytes;
	LONG32 i=0;
	buffer = (struct msqid_ds *)malloc(sizeof(struct msqid_ds));
	for( i =0 ;i < 2;i++)
	{
		//if( (Retval = msgctl(ReadQueue ,IPC_STAT,buffer) < 0))
		if( (Retval = msgctl(ReadQueue ,IPC_STAT,buffer)) < 0)
		{
			perror("Error in Reading CheckQueueForPendingPackets");
			free(buffer);
			return FALSE ;
		}
		Bytes = buffer->msg_cbytes ;
		if ( Bytes == 0 )
		{
			Sleep(50);
			continue ;
		}
		else
		{
			free(buffer);
			return TRUE ;
		}
	}
	free(buffer);
	return FALSE ;
}


void	SendPacketBackToUser ( CHAR* Message )
{
	CHAR* 	tempBuff;
	CHAR *	Packet ;
	LONG32	SeqNo;
	LONG32	iMsgLength ,iSlotNo;
	LONG32	PacketSize ,Transcode ;
	LONG32	RateDiff,ReplyCode;
	LONG32	ReadBytes;
	CHAR	TransId[ SIZE_OF_TRANS_ID ];
	CHAR	DateTime[ DATETIME_LEN ];
	CHAR	RepText [MESSAGE_LEN ] ;

	logDebug1("Inside SendPacketBackToUser...");

	tempBuff    = ( CHAR *)malloc( BSE_PACKET_SIZE );
	Packet      = (CHAR * )malloc( REJECTED_PACK_SIZE );

	if( (ReadBytes =ReadNBQ( ReadQueue, tempBuff ,BSE_PACKET_SIZE,0) )== ERROR)
	{
		free( Packet );
		free( tempBuff );
		return;
	}
	if ( ReadBytes == 0 )
	{
		free( Packet );
		free( tempBuff );
		return;
	}
	SeqNo 		= ((struct OMB_HEADER *)tempBuff)->iSlotNo ;
	iMsgLength 	= ((struct OMB_HEADER *)tempBuff)->iMsgLen ;


	PacketSize = iMsgLength + OMB_HEADER_LEN ;

	iSlotNo = 0;
	memcpy(Packet,&iSlotNo,sizeof(LONG32));
	memcpy(Packet + sizeof(LONG32),&iMsgLength,sizeof(LONG32));
	tempBuff = tempBuff + sizeof( struct OMB_HEADER ) ;

	sscanf( tempBuff ,"%d",&Transcode);

	memcpy( TransId,"0" ,SIZE_OF_TRANS_ID);
	memcpy( DateTime,"0",DATETIME_LEN);

	ReplyCode = 255 ;
	RateDiff  = 0 ;
	memset(RepText,' ',MESSAGE_LEN );
	memcpy(RepText ,Message,MESSAGE_LEN );

	sprintf(Packet + sizeof(struct OMB_HEADER) ,"%-10d|%-10d|%-5d|%-5d|%-19.19s|%-19.19s|%-40.40s|",
			Transcode,
			SeqNo,
			ReplyCode,
			RateDiff,
			TransId,
			DateTime,
			RepText);

	WriteToBseRms( Packet,PacketSize );
	free( tempBuff );
}


void    WriteToBseRms ( CHAR * Packet ,LONG32 Size )
{
	if(WriteMsgQ( WriteQueue , Packet ,Size ,1 )==FALSE)
	{
		logDebug1(" Error in writting to MsgRms");
	}
}

void    WriteToDloadQ ( CHAR * Packet ,LONG32 Size )
{
	if(WriteMsgQ( DloadQueue , Packet ,Size ,1 )==FALSE)
	{
		logDebug1(" Error in writting to DloadQ");
	}
}

void	PrintStatus ( LONG32 Type )
{
	switch (Type)
	{
		case 1:
			logDebug1("LOGGED ON SUCCESSFULLY DOWNLOAD STARTS HERE....");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST TRADES DOWNLOAD		       ");
			break;
		case 2:
			logDebug1("		TRADES DOWNLOAD COMPLETE		       ");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR ORDERS DOWNLOAD	       ");
			break;
		case 3:
			logDebug1("		ORDERS DOWNLOAD COMPLETED		       ");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR RETURNED ORDERS DOWNLOAD   ");
			break;
		case 4:
			logDebug1("		RETURNED ORDERS DOWNLOAD COMPLETED	       ");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR STOPLOSS DOWNLOAD ");
			break;
		case 5:
			logDebug1("		PERSONAL STOP LOSS DOWNLOAD COMPLETED");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR RETURNED STOPLOSS DOWNLOAD ");
			break;
		case 6:
			logDebug1("		RETURNED STOP LOSS DOWNLOAD COMPLETED	       ");
			logDebug1("*************************************************************");
			break;
		case 7:
			logDebug1("-------------------------------------------------------------");
			logDebug1("		DOWNLOAD COMPLETED NORMAL PROCESS STARTS       ");
			logDebug1("-------------------------------------------------------------");
			break;
		default :
			return;

	}
}


void SlotInit( key_t  ShmKey )
{
	LONG32 Index,Count ;
	struct Slot *Ptr;
	struct IML_INFO_SHM	*pImlQryShm;
	logDebug1("Inside SlotInit...");

	LockShm ( ShmKey );

	//pImlQryShm = ( struct IML_INFO_SHM *) OpenSharedMemory( ShmKey ,Bse_CConn_Shm_SIZE );

	//if ( *( (LONG32 *) pImlQryShm ) == ERROR )

	if((pImlQryShm = ( struct IML_INFO_SHM *) OpenSharedMemory( ShmKey ,Bse_CConn_Shm_SIZE )) == ( struct IML_INFO_SHM *) ERROR)
	{
		logDebug1 ("Error in Opening Shared memory");
		perror("Ashish SHM ::");
		UnLockShm( ShmKey );
		exit(1);
	}


	for ( Count =0; Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== UNUSED ; Count ++)
	{	
		logDebug1(" SlotInit Count :%d UserId :%d",Count,iGlobUserGroupId);
		pImlQryShm -> pImlInfo[Count].iImlUserId= iGlobUserGroupId ;	
		for ( Index =0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++)
		{
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus = UNUSED_SLOT;
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = UNUSED_SLOT ; 
		}
		break;
	}	

	if ( CloseSharedMemory((void * )pImlQryShm ) == ERROR )
	{
		logDebug1 ("Error in Closing Shm ");
		UnLockShm( ShmKey );
		exit(1);
	}

	UnLockShm( ShmKey );
	logDebug1("Inside SlotInit...");
}

LONG32 GetFreeSlot( key_t  ShmKey )
{
	LONG32  Index,Count ;
	struct Slot *Ptr ;
	struct IML_INFO_SHM	*pImlQryShm;

	logDebug1("Inside GetFreeSlot...");

	LockShm ( ShmKey ) ;

	logDebug1("Before OpenSharedMemoryory...");
	//	pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_CConn_Shm_SIZE);
	logDebug1("After OpenSharedMemoryory..");

	//if ( *( (LONG32 *) pImlQryShm ) == ERROR )
	if((pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_CConn_Shm_SIZE)) == (struct IML_INFO_SHM     *) ERROR )
	{
		logDebug1 (" Error in Opening Shared memory");
		perror("Ashish SHM :");
		UnLockShm( ShmKey );
		exit(0);
	}
	logDebug1("\nAfter PoLONG32er assignment...");

	for ( Count = 0; Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== iGlobUserGroupId ; Count ++)
	{
		for ( Index = 0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY); Index ++)
		{
			if ( pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus == UNUSED_SLOT )
			{
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus = USED_SLOT ;
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = Index + 1 ;
				break;
			}
		}
	}
	logDebug1("Before CloseSharedMemory...");
	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm");
		UnLockShm( ShmKey );
		exit(0);
	}
	logDebug1("After CloseSharedMemory...");

	UnLockShm( ShmKey );
	Index = Index + 1;
	logDebug1("Before returning....");
	return Index ;
}



LONG32  IsFreeSlot( key_t  ShmKey )
{
	LONG32    Index,Count ;
	struct Slot *tPtr;
	struct IML_INFO_SHM	*pImlQryShm;
	LONG32    RetVal = FALSE ;

	logDebug1("IsFreeSlot..");

	LockShm ( ShmKey );


	logDebug1(" OpenSharedMemory for IsFreeSlot  ################## 1");
	//	pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_CConn_Shm_SIZE);
	logDebug1(" OpenSharedMemory for IsFreeSlot  ################## 2");

	//if (*( (LONG32 *) pImlQryShm ) == (LONG32 *)ERROR )
	if((pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_CConn_Shm_SIZE)) == (struct IML_INFO_SHM     *) ERROR )
	{
		logDebug1 (" Error in Opening Shared memory");
		perror("Ashish SHM : ");
		UnLockShm( ShmKey );
		exit(0);
	}

	logDebug1(" OpenSharedMemory for IsFreeSlot  ################## 3");
	for ( Count = 0;Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== iGlobUserGroupId ; Count ++)
	{
		for ( Index =0; Index  < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
			logDebug1("In IsFreeSlot Slot [%d] Status [%d]",Index+1,pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus);

		for ( Index =0; Index  < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
		{
			if ( pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus == UNUSED_SLOT )
			{
				RetVal = TRUE ;
				logDebug1(" Got FreeSlot  ################## %d",RetVal);
				break ;
			}
			logDebug1(" After check for error for IsFreeSlot 6 ################## %d",RetVal);
		}
	}
	logDebug1(" After for loop for IsFreeSlot 4 !!!!!!!!!!!!!!!!!!!%d",RetVal);

	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm ");
		UnLockShm( ShmKey );
		exit(0);
	}
	logDebug1(" After CloseSharedMemory IsFreeSlot  ################## 8");

	UnLockShm( ShmKey );
	logDebug1("################ RETURNING FROM ISFREESLOT%d  ", RetVal );
	return RetVal ;
}





void  SetSlotFree ( key_t  ShmKey ,LONG32 iSlotNo )
{
	LONG32  Index,Count ;
	struct Slot *Ptr ;
	struct IML_INFO_SHM	*pImlQryShm;

	logDebug1("Inside SetSlotFree...");

	LockShm ( ShmKey );

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 1");
	pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_CConn_Shm_SIZE);
	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 2");

	if ( *( (LONG32 *) pImlQryShm ) == (LONG32 *)ERROR )
	{
		logDebug2("Ashish SHM :");
		logDebug1 (" Error in Opening Shared memory");
		perror("Ashish SHM :");
		exit(0);
	}

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 3");
	for ( Count =0 ; Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== iGlobUserGroupId; Count ++)
	{
		for (Index = 0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
		{
			if( pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot == iSlotNo )
			{
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus = UNUSED_SLOT ;
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = UNUSED_SLOT ;
			}
		}
	}

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 4");
	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm ");
		exit(0);
	}

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 5");
	UnLockShm( ShmKey );
	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 6");
	return ;
}

/*****
  void * OpenSharedMemory( CHAR *  KeyString , LONG32 SizeOfMem )
  {
  LONG32      shmidH;
  LONG32	 RetVal = ERROR ;
  void     * shmaddr;
  LONG32 	key;

  logDebug1("\n Before shmget #################### ");

  if((key = KeyGenarate(KeyString)) ==-1)
  {
  logDebug1("\n Could not able to generate the key values");
  }
#ifdef     DBG
logDebug1("Size = %d \t key = %d \n" , SizeOfMem , key );
#endif
if( ( shmidH = shmget( key , SizeOfMem , 0 ) ) < 0 )
{
logDebug1("\n SHMGET FUNCTION ############################ ");
perror("shmget() in OpenSharedMemoryory(): ");
return (void *)RetVal;
}

logDebug1("\n Before shmat #################### ");

shmaddr = shmat( shmidH , (CHAR * )0 , 0 );

logDebug1("\n The error code with shmat is %d ", errno );
logDebug1("\n The error is %s ",strerror ( errno ) );

if ( shmaddr == NULL )
{
logDebug1("\n Something else returned NULL ");
}

if(shmaddr == ((void *)-1))
{
logDebug1("\n SHMAT FUNCTION ############################ ");
logDebug1("\n The error code with shmat is %d ", errno );
logDebug1("\n The error is %s ",strerror ( errno ) );
perror("shmat :");
return (void *)RetVal;
}

else
{

logDebug1("\n Came here not NULL and not -1 ");
}

#ifdef     DBG
logDebug1("1 Shared memory attached at ID = %d\n", shmidH);
#endif
return (void *)shmaddr;
}
 *******/



LONG32	GetHour( CHAR *time)
{	
	CHAR  *pHour;
	LONG32   iHour;	
	memcpy(pHour,time,2);	
	iHour=atoi(pHour);	
	return(iHour);
}

LONG32	GetMinute( CHAR *time )
{
	CHAR *pMinute;
	LONG32  iMinute;

	memcpy(pMinute,time + 3,2);
	iMinute = atoi(pMinute);
	return( iMinute );
}

LONG32	GetSeconds ( CHAR *time )
{
	CHAR *pSeconds;
	LONG32  iSeconds;

	memcpy(pSeconds,time + 6,2);
	iSeconds = atoi(pSeconds);
	return( iSeconds );
}

/***************Added on 07-02-2001***************************
  void BseTwiddle(void *pVoid,short iLen)
  {
  logInfo("Really Inside BseTwiddle");
#ifdef  BIGENDIAN
logInfo("Inside BseTwiddle");
CHAR  * pStr = (CHAR  *)pVoid;
CHAR    cTemp[ 500 ];
short   i;

memcpy (cTemp,
pStr,
iLen);

for (i = 0; i < iLen; i++)
{
 *(pStr + i) = cTemp[iLen - i - 1];
 }
#endif
}
 **/



BOOL fTrade(CHAR *pMem)
{

	struct OMB_TRADE_CONFIRMATION_UMS  sMem;
	LONG32	NoOfRecs;
	LONG32	i;


	memcpy(&sMem,pMem,sizeof(struct OMB_TRADE_CONFIRMATION_UMS));

	//	BSETWIDDLE(sMem.iNoOfRecords);
	logDebug1("-------------------------------------------------");
	logDebug1("NO OF TRADES IN THIS PACKET IS %d",sMem.iNoOfRecords);

	NoOfRecs = sMem.iNoOfRecords;

	for(i=0;i<NoOfRecs;i++)
	{

		/**		BSETWIDDLE(sMem.pSubTraDetails[i].iTradeId);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iRate);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iQty);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iOrdId);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iMsgTag);
		 **/
		logDebug1(" PACKET NO %d",i);


		logDebug1("TradeId[%d] : %d",i,sMem.pSubTraDetails[i].iTradeId);
		logDebug1("Rate[%d]    : %d",i,sMem.pSubTraDetails[i].iRate);
		logDebug1("Qty[%d]     : %d",i,sMem.pSubTraDetails[i].iQty);
		logDebug1("iMsgTag[%d] : %d",i,sMem.pSubTraDetails[i].iMsgTag);
		logDebug1("TransId[%d] : %lld",i,sMem.pSubTraDetails[i].iOrdId);
		logDebug1("TransId[%d] : %ld",i,sMem.pSubTraDetails[i].iOrdId);
		logDebug1("Day[%d]     : %c",i,sMem.pSubTraDetails[i].pOmbYr.cDay);
		logDebug1("Month[%d]   : %c",i,sMem.pSubTraDetails[i].pOmbYr.cMonth);
		logDebug1("Year[%d]    : %c",i,sMem.pSubTraDetails[i].pOmbYr.cYear);

		logDebug1("Hour[%d]    : %c",i,sMem.pSubTraDetails[i].pOmbTime.cHour);
		logDebug1("Minute[%d]  : %c",i,sMem.pSubTraDetails[i].pOmbTime.cMinute);
		logDebug1("Second[%d]  : %c",i,sMem.pSubTraDetails[i].pOmbTime.cSecond);

	}	

	return TRUE;



}


LONG32	QueryNewsCategory (LONG32 Tcode )
{
	LONG32	RetVal ;
	LONG32	SentBytes,RecvBytes;
	LONG32	PacketSize ;
	LONG32	Flag = FALSE;

	struct OMB_NEWS_CATEGORY_REQ	NewCatReq ;
	struct OMB_NEWS_CATEGORY_RESP	NewsCatResp ;


	logDebug1("In QueryNewsCategory ");

	if(  ( RetVal = PrepareNewsCategory (&NewCatReq )) == TRUE )
	{
		//	BSETWIDDLE(NewCatReq.pHeader.iMsgLen);
		PacketSize = NewCatReq.pHeader.iMsgLen + sizeof(struct OMB_HEADER) ;
		//		BSETWIDDLE(NewCatReq.pHeader.iMsgLen);
		SentBytes = SendPacket (iSockfd, (CHAR *)&NewCatReq, PacketSize );
		if( SentBytes < 0)
		{
			BSEconnectLogFatal("In QueryNewsCategory bytes less than 0");
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, (CHAR *)&NewsCatResp );	
		logDebug1("Received A packet from Exchange ...");
		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			BSEconnectLogFatal("Error in RecvPacket  ");
			return FALSE;
		}
		if( RecvBytes == 0)
		{
			return FALSE;
		}
		if ( (Flag = RecvQueryNewsCategory (&NewsCatResp )) == TRUE )
		{
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			BSEconnectLogFatal("Entered Retry part..");
			continue ;
		}
		else
		{
			return FALSE ;
		}
	}while( Flag == RETRY );
}


LONG32  PrepareNewsCategory (struct  OMB_NEWS_CATEGORY_REQ *NewsCatReq  )
{

	logDebug1("In PrepareNewsCategor ");

	memset(NewsCatReq,' ',sizeof(struct OMB_NEWS_CATEGORY_REQ) ) ;

	NewsCatReq->pHeader.iSlotNo = 1;
	NewsCatReq->pHeader.iMsgLen = sizeof(struct OMB_NEWS_CATEGORY_REQ) - sizeof(struct OMB_HEADER) ;
	NewsCatReq->iMsgType = TC_EQU_BSE_NEWS_CATEGORY_REQ  ;	
	NewsCatReq->iMsgTag = 1005;	
	NewsCatReq->iCategory = 0 ;              /*** As is OMB to be confirmed **/	
	NewsCatReq->cDirection = 'N' ;              /*** to be confirmed **/	
	NewsCatReq->iNewsID = -1 ;              /*** As is OMB to be confirmed **/	


	/**	BSETWIDDLE(NewsCatReq->pHeader.iSlotNo);
	  BSETWIDDLE(NewsCatReq->pHeader.iMsgLen);
	  BSETWIDDLE(NewsCatReq->iMsgType);
	  BSETWIDDLE(NewsCatReq->iMsgTag);
	  BSETWIDDLE(NewsCatReq->iCategory);
	  BSETWIDDLE(NewsCatReq->iNewsID);
	 **/
	return TRUE;

}

LONG32  RecvQueryNewsCategory (struct OMB_NEWS_CATEGORY_RESP *NewsCatResp )
{
	/*************************************
	  LONG32 	SentBytes = 0 ;
	  LONG32	iRetVal = FALSE ;
	  LONG32	count = 0 ;



	  EXEC SQL BEGIN DECLARE SECTION ;
	  VARCHAR		vNewsTitle[NEWS_CATEGORY_TITLE_LEN] ;
	  LONG32 		vNewsCategory;
	  EXEC SQL END DECLARE SECTION ;



	  logDebug1("\nIn RecvQueryNewsCategory ");


	  BSETWIDDLE(NewsCatResp->iMsgType);
	  BSETWIDDLE(NewsCatResp->ReplyCode);
	  BSETWIDDLE(NewsCatResp->NoOfRec);
	  BSETWIDDLE(NewsCatResp->iMsgTag);

	  logDebug1("\n********************************************************");
	  logDebug1("\n*     QUERY   NEWS CATEGORY  REPLY         *");
	  logDebug1("\n********************************************************");
	  logDebug1("\nTranscode   Received : %d",  NewsCatResp->iMsgType   );
	  logDebug1("\nReply Code  Received : %d",  NewsCatResp->ReplyCode   );
	  logDebug1("\niNoOfRecords Received : %d",  NewsCatResp->NoOfRec );
	  logDebug1("\niMsgTag      Received : %d",  NewsCatResp->iMsgTag );
	  logDebug1("\n********************************************************");


	  if( NewsCatResp->iMsgType != TC_EQU_BSE_NEWS_CATEGORY_RESP )
	  {
	  logDebug1("\nReceived Packet is not of QueryIndexValue Reply..");
	  return  RETRY ;
	  }

	  logDebug1("\n********************************************************");
	  logDebug1("\n*     QUERY   NEWS CATEGORY  REPLY         *");
	  logDebug1("\n********************************************************");
	  logDebug1("\nTranscode   Received : %d",  NewsCatResp->iMsgType   );
	  logDebug1("\nReply Code  Received : %d",  NewsCatResp->ReplyCode   );
	  logDebug1("\niNoOfRecords Received : %d",  NewsCatResp->NoOfRec );
	  logDebug1("\niMsgTag      Received : %d",  NewsCatResp->iMsgTag );
	  logDebug1("\n********************************************************");

	  if( NewsCatResp->ReplyCode == 0  )
	  {
	  for( count=0; count < NewsCatResp->NoOfRec; count++)
	  {

	  logDebug1("\nNewsCategory Received : %d",  NewsCatResp->SubNewsCat[count].NewsCategory );
	  logDebug1("\nNewTitle      Received : %s",  NewsCatResp->SubNewsCat[count].NewTitle);
	  logDebug1("\n----------------------------------------------------------------");
	  vNewsCategory = NewsCatResp->SubNewsCat[count].NewsCategory;
	  memset(vNewsTitle ,'\0',NEWS_CATEGORY_TITLE_LEN);
	  memcpy(vNewsTitle ,NewsCatResp->SubNewsCat[count].NewTitle,st (NewsCatResp->SubNewsCat[count].NewTitle));
	  vNewsTitle  = st (NewsCatResp->SubNewsCat[count].NewTitle);

	  logDebug1("\nNewTitle      Received : %d",  vNewsTitle );
	  EXEC SQL UPDATE BSE_NEWS_CATEGORY_MASTER 
	  SET BNCM_NEWS_CAT_TITLE = :vNewsTitle
	  WHERE BNCM_NEWS_CAT_NUM = :vNewsCategory;

	  if (sqlca.sqlcode ==0)
	  {
	  logDebug1("\nRecord Updated");
	  EXEC SQL COMMIT;
	  }
	  else if(sqlca.sqlcode ==1403)
	{
		logDebug1("\n Record Does not Exixt .. Inserting Record");
		EXEC SQL INSERT INTO BSE_NEWS_CATEGORY_MASTER
			(
			 BNCM_NEWS_CAT_NUM, 
			 BNCM_NEWS_CAT_TITLE
			)
			VALUES
			(
			 :vNewsCategory,
			 :vNewsTitle
			);

		if (sqlca.sqlcode ==0)
		{
			logDebug1("\nRecord Inserted");
			EXEC SQL COMMIT;
		}
		else
		{
			logDebug1("\n ERROR in insertion");
			EXEC SQL ROLLBACK;
			return FALSE;
		}		
	}
	  else
	  {
		  logDebug1("\n ERROR in Updation");
		  EXEC SQL ROLLBACK;
		  return FALSE;
	  }
}
}
else
return FALSE;

logDebug1("\nReturn From Func ");
*************************************/

return TRUE;
}


void InitSharedMemory ()
{
	LONG32  Index,Count ;
	struct SLOT *Ptr ;
	struct IML_INFO_SHM *pImlQryShm;

	logDebug1("Inside InitSharedMemory...");
	logDebug1 ("HERE FOR %d " , GlobShmKey) ;
	LockShm ( GlobShmKey);

	logDebug1(" OpenSharedMemoryory for InitSharedMemory################## 1");
	//	pImlQryShm = ( struct IML_INFO_SHM *)OpenSharedMemory ( GlobShmKey, Bse_CConn_Shm_SIZE);
	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 2");

	//if ( *( (LONG32 *) pImlQryShm ) == ERROR )
	if ( (pImlQryShm = ( struct IML_INFO_SHM *)OpenSharedMemory ( GlobShmKey, Bse_CConn_Shm_SIZE)) == ( struct IML_INFO_SHM *) ERROR  )
	{
		logDebug1 (" Error in Opening Shared memory");
		perror("Ashish SHM :");
		UnLockShm( GlobShmKey);
		exit(0);
	}

	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 3");
	for ( Count =0 ; Count < NO_QRY_IML ; Count ++)
	{
		pImlQryShm -> pImlInfo[Count].iImlUserId= UNUSED;
		for (Index = 0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
		{
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus= UNUSED_SLOT ;
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = UNUSED_SLOT ;
		}
	}

	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 4");
	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm ");
		UnLockShm( GlobShmKey);
		exit(0);
	}

	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 5");
	UnLockShm( GlobShmKey);
	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 6");
	return ;
}

LONG32     UpdateExchStatus ( LONG32 GroupId ,LONG32 status )
{
        LONG32 RetVal ;
        CHAR    ExchStatus;
        CHAR    *sUpdQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

        if( status == 1 )
                ExchStatus = 'R' ;
        else
                ExchStatus = 'N' ;

        logDebug1("Updating the status for Group id %d to :%c",GroupId,ExchStatus);


        sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER \
                        SET\
                        EAM_LOGON_STATUS = \'%c\' \
                        WHERE EAM_EXM_EXCH_ID = 'BSE'\
                        AND EAM_GROUP_ID = %d\
                        AND EAM_DRV_FLAG = 'N' ;",ExchStatus,iGlobUserGroupId);

        logDebug2("sUpdQry :%s:",sUpdQry);

        if( mysql_query(DB_BseCon,sUpdQry) != SUCCESS )
        {
                logDebug1(" Updation failed ");
                sql_Error(DB_BseCon);
                mysql_rollback(DB_BseCon);
                return FALSE;
        }

        mysql_commit(DB_BseCon);

        logDebug1("ExchStatus   :%c:",ExchStatus);

        if( ExchStatus == 'R')
        {
                RetVal= fUpdateConnectStatus(BSE_CUR_UP,GroupId  );
        }
        else
        {
                RetVal= fUpdateConnectStatus(BSE_CUR_DOWN,GroupId);
        }
        if(RetVal==TRUE)
        {
                return TRUE ;
        }
        else
        {
                return FALSE;
        }

}

