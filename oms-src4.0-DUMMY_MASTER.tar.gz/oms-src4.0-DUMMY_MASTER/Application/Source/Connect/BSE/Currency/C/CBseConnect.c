#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <time.h>
#include "OMBBseStrcut.h"
#include "BseCDFIXStructures.h"


BOOL    fInsertExchDigital(SHORT iNoStreams );
void ProcessArguments(LONG32 );
LONG32 last_msg_time;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
SHORT iHours=0,iMinutes=0,iSec=0;
//#define	BSETWIDDLE(A)	BseTwiddle((char *) &A, sizeof(A))
pid_t	iMainPID = 0;
MYSQL	*DB_BseCon;
LONG32 iGlobUserGroupId;
LONG32	iSockfd;
LONG32	DloadQueue,WriteQueue,ReadQueue;
CHAR    sImlIPAddress[20];
LONG32  iImlPort ;
CHAR	sPrimIPAddress[20];
LONG32	iPrimPort ;
CHAR	sSecIPAddress[20];
LONG32	iSecPort ;
key_t   GlobShmKey;
char    TimeStamp[TIME_LENGTH];
struct  ForkProcess ForkProcess[MAX_NO_PROCESSES] ;
void ConnectToOracle();
void OpenMessageQueues();
CHAR    sGtwIP1[25];
CHAR    sGtwIP2[25];
BOOL fDCGateWayReq();	
CHAR            sFileName[FILE_NAME_LEN];
FILE            *fEQClOrdID;
static 	LONG32	iTempSendSeqNum = 0;
CHAR    sDate[DATE_LEN];	
LONG64	iSessionPartyId;
LONG32	iSleepBusyTimer;
BOOL	TradeRetransmistionReq();
BOOL	OrdersRetransmistionReq(CHAR    *sLastRefMsgId);
BOOL	PrintRetramissResp(CHAR *Packet);
main(LONG32 argc, CHAR **argv )
{
	logTimestamp("Entry :main:");	
	LONG32	RetVal = FALSE ;
	LONG32	ForkInd;
	LONG32	Sig = 0,iMainWait;
	LONG32	MainWait;
	LONG32 	identifier;
	LONG32	iRetVal = FALSE ;
	struct OMB_HEADER *header ;
	sigset_t    MainSignalSet   ;

	setvbuf( stdout , NULL , _IONBF , 0 );
	setvbuf( stderr , NULL , _IONBF , 0 );
	setbuf( stdout , NULL );
	setbuf( stderr , NULL );

	DB_BseCon = DB_Connect();

	iGlobUserGroupId = atoi(argv[1]); 
	identifier = iGlobUserGroupId;
	logDebug1("iGlobUserGroupId is %d", iGlobUserGroupId);
	memset(sImlIPAddress,'\0',20);

        strcpy(sImlIPAddress,getenv("IML_IP_CD"));
        iImlPort        = atoi(getenv("IML_PORT_CD"));

        logDebug1(" DETAILS OF DATA PICKED FROM EXCH_ADMINISTRATION_MASTER ");
        logDebug1(" __________________________________________________________ ");
        logDebug1(" IP ADDR     = %s",sImlIPAddress);
        logDebug1(" PORT NO     = %d",iImlPort);
	errno=0;
	memset(sDate, '\0',DATE_LEN);
	fSelectDate(&sDate);
	CHAR    sLastRefMsgId[16];

	

        sprintf(sFileName,"../File/BseAdapSeq_%s",sDate);
        if(access(sFileName,F_OK) == ERROR)
        {
                fEQClOrdID = fopen(sFileName,"wb+");

                if (fEQClOrdID == NULL)
                {
                        logFatal("Not able to Open File");
                        exit(0);
                }
                else
                {
                        fprintf(fEQClOrdID,"1");
                }
                fclose(fEQClOrdID);
        }
        else
        {
                logInfo(":%s: File Already Exists",sFileName);
        }	

	for ( ; ; )  
	{
		signal(SIGTTOU,SIG_IGN);
		signal(SIGTTIN,SIG_IGN);
		signal( SIGHUP ,SIG_IGN);
		signal( SIGPIPE,SIG_IGN);
		signal( SIGBUS ,SIG_IGN);
		signal( SIGINT ,SIG_IGN);
		sigemptyset( &MainSignalSet );
		sigaddset ( &MainSignalSet , SIGTERM );
		sigaddset ( &MainSignalSet , SIGUSR1);
		/****
		  sigprocmask ( SIG_BLOCK,&MainSignalSet,NULL);
		  signal(SIGTERM, SignalHandlerSigTermMain );
		 ****/


        	memset(sLastRefMsgId,'\0',16);
		GetParameters ( );
		InitSharedMemory();
		GetTimeForDownload ( );
		InitForkProcess ( );
		SlotInit( GlobShmKey );

		iSockfd = OpenGateWaySocket ( );
		logDebug1("iSockfd returned is %d ", iSockfd );

		if( iSockfd == ERROR )
		{
			BSEconnectLogFatal("Connection To BSE Failed...");
			exit(0);
		}


		OpenMessageQueues();
		RetVal = fDCGateWayReq();
		if ( RetVal == ERROR)
		{
			BSEconnectLogFatal ("Problem In ProcessInitialConnection");
			continue;
			exit(0);
		}
		
		ProcessArguments (identifier);
		iSockfd = OpenPassiveSocket ( );
                logDebug1("iSockfd returned is %d ", iSockfd );

                if( iSockfd == ERROR )
                {
                        BSEconnectLogFatal("Connection To BSE Failed...");
                        exit(0);
                }	
	

		
		RetVal = ProcessInitialConnection ();
		if ( RetVal == ERROR)
		{
			BSEconnectLogFatal ("Problem In ProcessInitialConnection");
			continue;
			exit(0);
		}
		

		if(fSubscribeReq(ETI_SUBSCRIBTION_TRADES) == FALSE)
		{
			logFatal("Subscribtion Request FAILED");
		}
		else
		{
			logInfo("Subscribtion Done Successfully");
		}

		//EAMtimestamp(1); /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
		/**
		  PrintStatus ( 1 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_TRADERS_TRADES_REQUEST)==FALSE)
		  {
		  logDebug1("Unable To Process Members Trades Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 2 );

		 **/
		/**	if(QueryPersonalInfo( TC_EQU_BSE_QUERY_ORDERS_REQUEST)==FALSE)
		  {
		  logDebug1(" UNABLE TO PROCESS TC_QUERY_ORDERS_REQUEST");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }***/
		/**
		  PrintStatus ( 3 );
		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_RETURNED_ORDERS_REQUEST)==FALSE)
		  {	
		  logDebug1(" Unable to process Returned Orders Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 4 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_PERSONAL_STOPLOSS_ORDERS)==FALSE)
		  {
		  logDebug1(" Unable To Process Personal Stoploss Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 5 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_RETURNED_STOPLOSS_ORDERS_REQUEST)==FALSE)
		  {
		  logDebug1(" Unable To Process Returned Stoploss Orders Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  BSEconnectLogFatal("Returned StopLoss Order Download over");
		  PrintStatus ( 6 );
		 ***/
		/*****	if(QueryPersonalInfo( TC_EQU_BSE_QUERY_6A7A_REQUEST)==FALSE)
		  {
		  logDebug1("\n Unable To Process 6a7a Reports Download"); 
		  }  ***********/
		/**/
		
		//TradeRetransmistionReq();

		OrdersRetransmistionReq(&sLastRefMsgId);

		if(DownloadEnd(TC_EQU_BSE_END_OF_DOWNLOAD)==FALSE)
		{
			logDebug1("DownloadEnd: Unable To Process End Of Download");
			close( iSockfd );
			exit(0);
		}

		BSEconnectLogFatal("Download Complete Normal Process Start");

		PrintStatus ( 7 );

		/*****************************--- To be uncommented in case News From BSe is to be provided****
		  if( QueryNewsCategory(TC_EQU_BSE_NEWS_CATEGORY_REQ)==FALSE)
		  {
		  logDebug1("\n Query News Category: Unable to process the Request ");
		  close ( iSockfd );
		  exit(0);
		  }
		 ****************************/
		logDebug1("Updating Shared Memory to UP for GrpId : %d",iGlobUserGroupId);
		iRetVal = UpdateExchStatus( iGlobUserGroupId,1 );
		if(iRetVal!=TRUE)
		{
			logDebug1("Unable To Update The Shared Memeory exit 1");
			BSEconnectLogFatal("Unable To Update The Shared Memeory exit");
			exit(1);
		}
		logTimestamp(":%s: BSE CD CONNECTION IS UP ",KEY_WORD_MONITORING);
		logDebug1("Forking Into Childs...");

		iMainPID = getpid();

		logDebug1(" Main Process ID :%d:",iMainPID);
		if ( ( ForkInd = fork( )) == 0 )
		{
			logDebug1("RECEIVE-CHILD Forked ...ProcessId Is :%d",getpid());
			ReceiveChild( );
		}

		if ( ForkInd != 0 )
		{
			UpdateForkProcess( RECVCHLD , ForkInd , RUNNING);
		}

		if ( ( ForkInd = fork( ) ) == 0 )
		{
			logDebug1("TRANSMIT-CHILD Forked ...ProcessId Is :%d",getpid());
			TransmitChild ( );
		}

		if (  ForkInd != 0 )
		{
			UpdateForkProcess( TRANSCHLD, ForkInd, RUNNING);
		}
		if ( ( ForkInd = fork( ) ) == 0 )
		{
			logDebug1("KEEPALIVE-CHILD Forked ...ProcessId Is :%d",getpid());
			KeepAliveChild ( );
		}

		if ( ForkInd != 0 )
		{
			UpdateForkProcess( KEEPALIVE, ForkInd, RUNNING);
		}
		/*********

		  if ( ( ForkInd = fork( ) ) == 0 )
		  {
		  logDebug1("\nClientChild  Forked ...ProcessId Is :%d",getpid());
		  ClientChild ( );
		  }
		  if ( ForkInd != 0 )
		  {
		  UpdateForkProcess( CLIENTREGREQ, ForkInd, RUNNING);
		  }
		 **********/
		if( ForkInd != 0)
		{
			sigprocmask ( SIG_BLOCK, &MainSignalSet, NULL);
			while( TRUE )
			{
				BSEconnectLogFatal("Successfully Connected To Exchange");
				iMainWait = 0 ;
				/**********
				  sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
				  sigemptyset( &MainSignalSet );
				//sigaddset (  &MainSignalSet , SIGCHLD);
				sigaddset (  &MainSignalSet , SIGUSR1);
				sigaddset (  &MainSignalSet , SIGTERM);
				sigprocmask ( SIG_BLOCK, &MainSignalSet, NULL);
				 ***********/
				logDebug1("Waiting for a Signal");
				iMainWait = sigwait( &MainSignalSet, &Sig);
				logDebug1("Got a Signal");
				sleep(1);

				logDebug1(" Process %d caught signal %d ",getpid(),Sig );	

				//if( Sig == SIGCHLD )
				if( Sig == SIGUSR1)
				{
					BSEconnectLogFatal("Connection Went Down");
					logDebug1("Connection Went Down");
					SignalHandlerSigChldMain ( ); 
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					break ;
				}
				if( Sig == SIGTERM )
				{
					logDebug1("Received a signal...");
					BSEconnectLogFatal("Application Close Requested");
					SignalHandlerSigTermMain ( Sig ); 
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					break ;
				}

			}
		}
	}/**FOR**/
}


void	ProcessArguments (LONG32 identifier) 
{
	logTimestamp("Entry :ProcessArguments:");
	LONG32 temp_identifier;
	CHAR		tempImpIp[ADDRESS_LEN];
	LONG32		tempImpPort;
	LONG32		tempUserId;
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;
	logDebug1(" identifier is %d", identifier);
	CHAR		sSelQery[MAX_QUERY_SIZE];
	memset(sSelQery,'\0',MAX_QUERY_SIZE);
	temp_identifier = identifier;
	memset(sPrimIPAddress,'\0',20);
	memset(sSecIPAddress,'\0',20);
	logDebug1(" temp_identifier is %d", temp_identifier);
	sprintf(sSelQery, "SELECT EAM_PRI_GATEWAY_IP,EAM_SEC_GATEWAY_IP,EAM_PRI_GATEWAY_PORT,EAM_SEC_GATEWAY_PORT FROM	EXCH_ADMINISTRATION_MASTER   WHERE	EAM_GROUP_ID	= %d 	  AND EAM_EXM_EXCH_ID = 'BSE'\ 
	  AND EAM_DRV_FLAG = 'N' AND EAM_SEGMENT = 'C';",temp_identifier);
	logDebug2("sSelQery :%s:",sSelQery);

	if(mysql_query(DB_BseCon,sSelQery) != SUCCESS)
	{
		logFatal("Error in getting exchange parameters from EXCH_ADMINISTRATION_MASTER ");
		sql_Error(DB_BseCon);
		exit(ERROR);
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		strcpy(sPrimIPAddress,Row[0]);
		strcpy(sSecIPAddress,Row[1]);
		iPrimPort	= atoi(Row[2]);
		iSecPort	= atoi(Row[3]);
	}




	logDebug1(" DETAILS OF DATA PICKED FROM EXCH_ADMINISTRATION_MASTER ");
	logDebug1(" __________________________________________________________ ");
	logDebug1(" PRIM IP ADDR 	= %s",sPrimIPAddress);
	logDebug1(" PRIM PORT NO	= %d",iPrimPort);
	logDebug1(" SEC IP ADDR 	= %s",sSecIPAddress);
	logDebug1(" SEC PORT NO	        = %d",iSecPort);
	logDebug1("Inside Function ProcessArguments...");

	logDebug1("The Iml ip address is %s ", sPrimIPAddress );
	logDebug1("The Iml port is %d ", iPrimPort );
	logTimestamp("Exit :ProcessArguments:");
	return ;
}



void	GetParameters ( )
{
	logTimestamp("Entry :GetParameters:");	

	logDebug1("In function GetParameters");
	logDebug1("The iGlobUserGroupId is %d ", iGlobUserGroupId );
	logDebug1("iGlobUserGroupId [%d] ",iGlobUserGroupId);
	switch(iGlobUserGroupId)
	{
		case 1:	

			GlobShmKey   = Bse_Conn_Shm_1 ;
			logDebug1("Bse_Conn_Shm_1 [%d] ",Bse_Conn_Shm_1);
			break;
		case 2:	//GlobQueueKey = EquRmsbseToBse2 ;
			GlobShmKey   = Bse_Conn_Shm_2 ;
			logDebug1("	Bse_Conn_Shm_2 [%d] ",Bse_Conn_Shm_2);
			break;
		case 3:	//GlobQueueKey = EquRmsbseToBse3 ;
			GlobShmKey   = Bse_Conn_Shm_3 ;
			logDebug1("Bse_Conn_Shm_3 [%d] ",Bse_Conn_Shm_3);
			break;
		case 4:	//GlobQueueKey = EquRmsbseToBse4 ;
			GlobShmKey   = Bse_Conn_Shm_4 ;
			logDebug1("Bse_Conn_Shm_4 [%d] ",Bse_Conn_Shm_4);
			break;
		default :
			exit(1);
	}	
}


void    BSEconnectLogFatal( CHAR * message )
{
	logTimestamp("Entry :BSEconnectLogFatal:");	
	CHAR    ProgName[10];
	CHAR	Message[100];
	memset( Message,' ',100);
	strcpy(Message,message);
	strcpy(ProgName,"BSEconnect");
	logFatal( "%s",Message );
	return;
}


void	OpenMessageQueues ( )
{
	logTimestamp("Entry :OpenMessageQueues:");	
	logDebug1("Inside OpenMessageQueues...");

	if( ( WriteQueue =  OpenMsgQ( ConnToTrdMapBSECD)) == ERROR)
	{
		perror("OpenMsgQ :");
		close( iSockfd);
		sleep(10);
		exit( 1 );
	}
	logDebug1(" queue opened WriteQueue");

	/**************
	  if( ( DloadQueue = OpenMsgQ( BseToDnload )) == ERROR)
	  {
	  perror("OpenMsgQ :");
	  close( iSockfd);
	  sleep(10);
	  exit( 1 );
	  }	*****************/

	if( ( ReadQueue = OpenMsgQ( MapperToConnBSECD)) == ERROR)
	{
		perror("OpenMsgQ :");
		close( iSockfd);
		sleep(10);
		exit( 1 );
	} 


	logDebug1("The Q ids are WriteQueue=%d,ReadQueue=%d",WriteQueue,ReadQueue);
	return ;
}

LONG32 	ProcessInitialConnection ( )
{
	logTimestamp("Entry :ProcessInitialConnection:");	
	LONG32	RetVal = FALSE ;

	logDebug1("Inside ProcessInitialConnection...");

	logDebug1("Sending Registration Request...");

	if( HandleRegistration ( iSockfd ) == FALSE )
	{
		close( iSockfd );
		sleep(10);
		logDebug1("Error in HandleRegistration function Exiting...." ) ;
		logDebug1("Handle Registration BSEconnect - Terminating - RESTART ");
		return ERROR;
	}

	logDebug1("Sending Log-Off Request...");
	/**************************
	  if ( HandleLogOff( ) == FALSE)
	  {
	  logDebug1("\n\tLOG-OFF To Exchange Unsuccessfull...");
	  close( iSockfd );
	  sleep(10);
	  logDebug1("\n\tHandle LogOff BSEconnect - Terminating - RESTART ");
	  BSEconnectLogFatal("Handle LogOff BSEconnect - Terminating - RESTART ");
	  return	FATAL ;
	  } 

	  logDebug1("\n\tPlease Wait - Processing Going On........."); ********************/
	sleep(3);

	logDebug1("Sending LogOn Request....");

	if ( HandleLogOn( ) == FALSE)
	{
		logDebug1("Signon Problem...");
		close( iSockfd );
		sleep(10);
		logDebug1("Handle LogOn BSEconnect - Terminating - RESTART ");
		BSEconnectLogFatal("Handle LogOn BSEconnect - Terminating - RESTART ");
		return	ERROR;
	}
	return	TRUE;
}


void	TransmitChild( )
{
	logTimestamp("Entry :TransmitChild:");	
	FIX_BSE_ORDER_REQUEST *Packet	;
	//CHAR*	Buffer			;
	CHAR	Buffer	[RUPEE_MAX_PACKET_SIZE]		;
	LONG32	SentBytes		;
	LONG32	RecvBytes		;
	LONG32	iRetVal	= FALSE		;
	LONG32	PacketSize		;
	LONG32	SlotNumber		;
	LONG32	Flag			;
	LONG32	MaxTry = 0		;
	CHAR	Message[100]		;
	/*	CHAR	*pBseConnQryStat;*/
	/*	LONG32 	ShmUpdStat =TRUE;*/
	CHAR    sInsertQuery[MAX_QUERY_SIZE];
        memset(sInsertQuery,'\0',MAX_QUERY_SIZE);
	LONG32	Check = FALSE		;
	LONG32	ConnectionBreakCount = 0;
	LONG32	MsgQuery;
	struct  timeval TimePtr;
	signal(SIGPIPE,SIG_IGN);

	/**
	  struct OMB_ADD_UPDATE_ORDER_REQ *BsePkt;
	  struct OMB_QUERY_MARKET_INFO_REQUEST                  *piMktInfo;
	  struct OMB_QUERY_MARKET_INFO_REQUEST                  IntMktInfo;
	  piMktInfo = &IntMktInfo;
	 **/

#ifdef OFFLINE
	/** Additions to avoid Update_Offline_Status for each packet **/
	struct PUMPER_FLAGS *PumperFlg;
	BOOL PumpFlg = TRUE;
#endif


	Packet  = (FIX_BSE_ORDER_REQUEST *)malloc( sizeof(FIX_BSE_ORDER_REQUEST));
	//	Buffer  = (CHAR *)malloc( sizeof(struct BSE_PACKET)); 
#ifdef OFFLINE
	PumperFlg = (struct PUMPER_FLAGS *)OpenSharedMemoryory(PumperFlgShm,PumperFlg_SIZE);
	if(PumperFlg == NULL)
	{
		logDebug1(" Error in Opening Shared Memory PumperFlgShm");
		/**	Exit(ERROR);	 **/
		exit(-1);     
	}
#endif
	//	logDebug1(" Updating Shared Memory to DOWN for %d",iGlobUserGroupId);
	//	UpdateExchStatus( iGlobUserGroupId,0 );
	sprintf(sInsertQuery,"DELETE FROM  BSE_SDRV_MAPPER ");

        logInfo("sInsertQuery :%s:",sInsertQuery);
        if(mysql_query(DB_BseCon, sInsertQuery) != SUCCESS)
        {
                logSqlFatal("Error in inserting BSE_SDRV_MAPPER ");
                sql_Error(DB_BseCon);
                return FALSE;
        }
        else
        {
                logDebug2("%d rows updated!!",mysql_affected_rows(DB_BseCon));
                mysql_commit(DB_BseCon);
        }
	/*	FOREVER*/

	for(;;)
	{
		memset( Packet 	,' ',sizeof(FIX_BSE_ORDER_REQUEST));	
		//memset( Buffer 	,' ',sizeof(struct BSE_PACKET));	
		memset( &Buffer 	,' ',RUPEE_MAX_PACKET_SIZE);	
		//	memset(piMktInfo,' ',sizeof(struct OMB_QUERY_MARKET_INFO_REQUEST ));

		//do{
			logDebug1("-----------------------------------------------------");
		//	if(IsFreeSlot( GlobShmKey ))
	//		{

				ConnectionBreakCount = 0 ;
				MaxTry = 0; 
				logDebug1("TRANSMIT-CHILD :Waiting Before Read Queue..");

				//if((ReadMsgQ( ReadQueue , Buffer, sizeof(struct BSE_PACKET) , 0))!=TRUE)
				if((ReadMsgQ( ReadQueue , &Buffer, RUPEE_MAX_PACKET_SIZE , 0))!=TRUE)
				{
					logDebug1(" Error in ReadQ");
					exit ( 0 );	
				}	 

				//		memcpy( Packet,Buffer,sizeof(struct BSE_PACKET)) ;
				Packet = (FIX_BSE_ORDER_REQUEST *)&Buffer;
				//		memcpy(piMktInfo,Buffer,sizeof(struct OMB_QUERY_MARKET_INFO_REQUEST ));
				//		logDebug1("Security Id 	%d",piMktInfo->iScripCodes[0]);
				logDebug1("Packet->pHeader.iMsgLength = [%d]",Packet->Header.iMsgLength);
				logDebug1("sizeof(struct OMB_HEADER) = [%d]",sizeof(struct OMB_HEADER));
				//sleep(1);
				logDebug1("Transcode is %d",Packet->Header.iMsgCode);

				//	BSETWIDDLE(Packet->pHeader.iMsgLength);
				//	BSETWIDDLE(Packet->iMsgType);
				PacketSize = Packet->Header.iMsgLength;
				iTempSendSeqNum++;
				
				Packet->FIXHeader.iMsgSeqNum = iTempSendSeqNum;	
				logDebug1("Packet Read From Queue...PacketSize is %d",PacketSize);	
				logDebug1("Transcode is %d",Packet->Header.iMsgCode );

				logDebug2("--------------Before Twiddle Printing Values----------------");

				logDebug2(" Packet->Header.iMsgCode [%d]",Packet->Header.iMsgCode );
				logDebug2(" Packet->Header.iMsgLength [%d]",Packet->Header.iMsgLength );
				/***
				logDebug2(" Packet->iMsgType       [%d]", Packet->iMsgType);
				logDebug2(" Packet.iScripCode     [%d]", Packet->iScripCode);
				logDebug2(" Packet.iMsgTag1       [%d]", Packet->iMsgTag1);
				logDebug2(" Packet.iQty           [%d]", Packet->iQty);
				logDebug2(" Packet.iRevealedQty   [%d]", Packet->iRevealedQty);
				logDebug2(" Packet.iRate          [%d]", Packet->iRate);
				logDebug2(" Packet.iTriggerRate   [%d]", Packet->iTriggerRate);
				logDebug2(" Packet.iReserved2     [%d]", Packet->iReserved2);
				logDebug2(" Packet.iReserved3     [%d]", Packet->iReserved3);
				logDebug2(" Packet.iFiller1       [%d]", Packet->iFiller1);
				logDebug2(" Packet.iFiller2       [%d]", Packet->iFiller2);

				logDebug2(" Packet.iMsgTag2       [%d]", Packet->iMsgTag2);
				logDebug2(" Packet.iOrderId       [%ld]", Packet->iOrderId);
				logDebug2(" Packet.iLocationId    [%ld]",Packet->iLocationId);
				logDebug2(" Packet.iFiller3       [%d]", Packet->iFiller3);
				logDebug2(" Packet.iFiller4       [%d]", Packet->iFiller4);
				logDebug2(" Packet.iFiller5       [%d]", Packet->iFiller5);
				logDebug2(" Packet.sClientID      :%s:",Packet->sClientID);
				logDebug2(" Packet.ParticipantCode:%s:",Packet->sParticipantCode);
				logDebug2(" Packet.sMsgTag3       :%s:",Packet->sMsgTag3);
				logDebug2(" Packet.sFiller6       :%s:",Packet->sFiller6);
				logDebug2(" Packet.cAUDCode       :%c:",Packet->cAUDCode);
				logDebug2(" Packet.cOrgBuySell    :%c:",Packet->cOrgBuySell);
				logDebug2(" Packet.cOrdType       :%c:",Packet->cOrdType);
				logDebug2(" Packet.cExecutionType :%c:",Packet->cExecutionType);
				logDebug2(" Packet.iClientType    [%d]",Packet->iClientType);
				logDebug2(" Packet.iMktProtection [%d]",Packet->iMktProtection);
				logDebug2(" Packet.iRetention     [%d]",Packet->iRetention);
				logDebug2(" Packet.iFiller8	  [%d]",Packet->iFiller8);
				logDebug2(" Packet.iReserved4     [%ld]",Packet->iReserved4);
				logDebug2(" Packet.iFiller9       [%ld]",Packet->iFiller9);
				logDebug2(" Packet.iFiller10	  [%d]",Packet->iFiller10);
				logDebug2(" Packet.iFiller11	  [%d]",Packet->iFiller11);
				logDebug2(" Packet.sAlgoId	  [%s]",Packet->sAlgoId);

				logDebug2("--------------END-------------------");

				SlotNumber = GetFreeSlot ( GlobShmKey ) ;
				logDebug1("The Slot Number Received Is : %d",SlotNumber);

				Packet->pHeader.iSlotNo = SlotNumber ;


				logDebug1("805 SLOT NO is %d",Packet->pHeader.iSlotNo);
				logDebug1("805 SLOT NO is %d",SlotNumber);
				gettimeofday(&TimePtr,NULL);
				logDebug1("999SENDING--%d--%d--%d--%d",SlotNumber,Packet->iMsgType,TimePtr.tv_sec,TimePtr.tv_usec);
				****/
				/**	BSETWIDDLE(Packet->pHeader.iSlotNo);
				  BSETWIDDLE(Packet->pHeader.iMsgLen);
				  BSETWIDDLE(Packet->iMsgType);***/
				fBseMsgSeqNum(Packet,Packet->FIXHeader.iMsgSeqNum);

				SentBytes = SendPacket( iSockfd, (CHAR*)Packet , PacketSize);

				if ( SentBytes < 0)
				{
					perror("Error While Sending :");
					logDebug1("Transmit Child :Exiting");
					BSEconnectLogFatal("Transmit Child :Exiting");
					free( Packet );
					free( Buffer );
					exit( 0 );
				}
				else
				{
					logInfo("As Packet Send to Exchange need to set In DB  ");

				}	
				logDebug1("TRANSMIT-CHILD : Message Sent To Exchange ....");
				usleep(iSleepBusyTimer);
				continue;
			//}
			/*else
			{
				logDebug1("############# 4 After IsFreeSlot returning false ");
				Sleep(1000);
				MaxTry++;
				continue;
			}
		}while( MaxTry < MAX_TRY );

		if( MaxTry >=MAX_TRY && !IsFreeSlot( GlobShmKey ) )
		{
			logDebug1("Slot Found not free..");
			sprintf(Message,"Delay In Connection To Bombay Stock Exchange");
			SendPacketBackToUser( Message );
			BSEconnectLogFatal(Message);
			ConnectionBreakCount ++ ;
			continue ;
		}*/
		if( ConnectionBreakCount > MAX_CONNECT_BREAK )
		{
			BSEconnectLogFatal("Self Closing Connection Due To Unavailable Slot");
			logDebug1("Self Closing Connection Due To Unavailable Slot");
			free( Packet );
			free( Buffer );
			exit(-1);
		}
	}
	free( Packet );
	free( Buffer );
	/*	exit( 0 );*/
}


void ReceiveChild ( )
{
	logTimestamp("Entry :ReceiveChild:");	
	CHAR* 	Packet ;
	LONG32	PacketSize;
	LONG32	RecvBytes;
	LONG32	TranScode;
	LONG32	iRetVal = FALSE ;
	LONG32 PacketNumber= 1;
	signal(SIGPIPE,SIG_IGN);
	struct timeval TimePtr;
	struct  OMB_QUERY_MKT_INF_RESP  pMktInqResp;
	INT_BSE_HEADER_OUT *pHeader;


	Packet = (CHAR * )malloc(BSE_PACKET_SIZE); 
	logDebug1("Entered Receive Child...");


	for(;;)
	{
		memset( Packet ,NULL,BSE_PACKET_SIZE);	
		PacketSize = 0;

		logDebug1("RECVEIVE-CHILD : Waiting For Data From Exchange...");
		logDebug1("PACKET RECEIVED - Packet Number %d",PacketNumber);
		PacketNumber++;
		RecvBytes = RecvPacket (iSockfd, Packet );

		if (((INT_BSE_HEADER_OUT *)Packet)->iMsgCode== 10018 || ((INT_BSE_HEADER_OUT *)Packet)->iMsgCode == 10011 || ((INT_BSE_HEADER_OUT *)Packet)->iMsgCode == 10012 )
		{
			

			logDebug1("RECEIVED----%d--",((INT_BSE_HEADER_OUT *)Packet)->iMsgCode );
			if(WriteMsgQ( WriteQueue , Packet ,BSE_PACKET_SIZE ,1 )==FALSE)
		        {
                		logDebug1(" Error in writting to MsgRms");
       			}
	
				
		}

		if(((INT_BSE_HEADER_OUT *)Packet)->iMsgCode == 10012)
		{
			logInfo("Prinft the rejection");
			SessionLogoutNotifnt(Packet);
		
		}	

		logDebug1("RECEIVED :%d:",((INT_BSE_HEADER_OUT *)Packet)->iMsgCode);
		if(((INT_BSE_HEADER_OUT *)Packet)->iMsgCode == 10023)
		{
			logDebug1("KeepAlive response ");
			continue;
		}
		/*if(((INT_BSE_HEADER_OUT *)Packet)->iMsgCode == 10027)
		{
			logDebug1("Printing Dwonload response ");
			RecvRetramissResp(Packet);
			continue;
		}*/
		/****
		if(((INT_BSE_HEADER_OUT *)Packet)->iMsgCode == 10010)
		{
			logDebug1("KeepAlive response ");
			RecvRejPacket(Packet);
			continue;
		}
		****/
		if (RecvBytes < 0)
		{
			logDebug1("Receive-Child : Error In Receive....");
			BSEconnectLogFatal("Receive-Child : Error In Receive....");
			free( Packet );
			close(iSockfd);
			exit(ERROR);
		}

		if (RecvBytes == 0)
		{
			logDebug1("Receive-Child : CONNECTION LOSS REQUESTED ");
			BSEconnectLogFatal("Receive-Child : CONNECTION LOSS REQUESTED ");
			/*****		free( Packet );
			  close(iSockfd);
			  exit(ERROR);*****/
			//logDebug1("Sending Signal to main process with pid :%d:",iMainPID);
			//kill(iMainPID,SIGCHLD);
			kill(iMainPID,SIGUSR1);
		//	exit(ERROR);

		}
		TranScode = ((INT_BSE_HEADER_OUT *)Packet)->iMsgCode;
		PacketSize = ((INT_BSE_HEADER_OUT *)Packet)->iMsgLength;
		if(TranScode == 10101 || TranScode == 10103 || TranScode == 10107 || TranScode == 10110 || TranScode == 10104  || TranScode == 10990 || TranScode == 10500  || TranScode == 10010 || TranScode ==  10117 || TranScode == 10122 || TranScode == 10033 || TranScode == 10049) 
                {
                	WriteToBseRms( Packet, PacketSize);
                }
	

		/************** added in anagram ********************/
		//BSETWIDDLE(((struct OMB_HEADER*)Packet)->iMsgLen);	
		/***BSETWIDDLE(((struct OMB_HEADER*)Packet)->iSlotNo);***/
		/****	
		PacketSize = ((struct OMB_HEADER*)Packet)->iMsgLen + sizeof(struct OMB_HEADER);

		SetSlotFree ( GlobShmKey ,((struct OMB_HEADER*)Packet)->iSlotNo );

		logDebug1("The Slot Number is %d",((struct OMB_HEADER*)Packet)->iSlotNo );

		if (((struct OMB_HEADER*)Packet)->iSlotNo == PROTOCOL_SLOT )
		{
			logDebug1("Reply-Child : Received A PROTOCOL Message Ignoring The Packet");
			TranScode = ((struct OMB_HEADER_INT *)Packet)->iMsgType ;
			logDebug1("Received a Packet with Transcode :%d",TranScode);
			continue;
		}
		else
		{
			TranScode = ((struct OMB_HEADER_INT *)Packet)->iMsgType ;
			logDebug1("Received a Packet with Transcode :%d Writing to BseRms Quueue...",TranScode);


			if(TranScode == TC_EQU_BSE_ORDER_REQ_RES || TranScode == TC_EQU_BSE_TRADE_CON_UMS || TranScode == TC_EQU_BSE_MKT_TO_LMT_CONVT || TranScode == TC_EQU_BSE_SP_OR_UMS || TranScode == TC_EQU_BSE_KILL_MIN_FILL_ORD  ||  TranScode == TC_EQU_BSE_UMS_MASS_CAN )
			{
				WriteToBseRms( Packet, PacketSize);
			}
			if (TranScode == 1111)
			{
				logDebug1("Inside fCOMBInquiryResp ");
			}
			if (TranScode == 1521)
			{
				logDebug1("TRADE HAS ARRIVED");
				fTrade(Packet);

			}
			continue ;
		}
		****/	 
	}/**FOR**/
	free( Packet );
	close(iSockfd);
}


LONG32  QueryPersonalInfo( LONG32 Transcode )
{
	logTimestamp("Entry :QueryPersonalInfo:");	
	CHAR* 	RequestPacket 		;
	CHAR*	ReceivePacket  		;
	LONG32	PacketSize 		;
	LONG32	SentBytes  		;
	LONG32	RecvBytes  		;
	LONG32	iTranscode		;
	LONG32	Flag = FALSE		;
	LONG32 temp;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/	



	logDebug1("In QueryPersonalInfo :...." ) ;
	if (Transcode == TC_EQU_BSE_QUERY_6A7A_REQUEST)
	{
		RequestPacket = (CHAR *)malloc( sizeof(struct OMB_QUERY_6A7A_INFO ));
		PacketSize = sizeof(struct OMB_QUERY_6A7A_INFO ) ;
	}
	else
	{
		RequestPacket 	= (CHAR *)malloc( sizeof(struct OMB_QUERY_PERSONAL_INFO) );
		PacketSize = sizeof(struct OMB_QUERY_PERSONAL_INFO) ;
	}
	RequestPacket 	= (CHAR *)malloc( sizeof(struct OMB_QUERY_PERSONAL_INFO) );
	ReceivePacket 	= (CHAR*)malloc( BSE_PACKET_SIZE );



	PrepareDownloadPacket ( Transcode , RequestPacket );

	logDebug2("RequestPacket iMsgType :%d:",((struct OMB_QUERY_PERSONAL_INFO *)RequestPacket)->iMsgType);

	SentBytes = SendPacket(iSockfd, RequestPacket, PacketSize );

	if (SentBytes < 0)
	{
		logDebug1("IN QueryPersonalInfo: Error in sent bytes");
		free( RequestPacket );
		free( ReceivePacket    );
		return	FALSE;	
	}

	do
	{
		logDebug1("Before Recv Func...........");
		RecvBytes = RecvPacket ( iSockfd , ReceivePacket );	

		if (RecvBytes < 0)
		{
			logDebug1("In QueryPersonalInfo : ERROR IN RECEIVING...");
			free( RequestPacket );
			free( ReceivePacket );
			return  FALSE;
		}

		if (RecvBytes == 0)
		{
			logDebug1("In QueryPersonalInfo : CONNECTION CLOSE REQUESTTED...");
			free( RequestPacket );
			free( ReceivePacket    );
			return  FALSE;
		}

		PacketSize = ((struct OMB_HEADER*)ReceivePacket)->iMsgLen + sizeof(struct OMB_HEADER) ;
		/************ added in anagram ************************/
		//	BSETWIDDLE(((struct OMB_HEADER_INT*)ReceivePacket)->iMsgType);
		iTranscode = ((struct OMB_HEADER_INT*)ReceivePacket)->iMsgType ;
		logDebug1( "The Received Transcode is :%d: :%d: PacketSize: %d",iTranscode,Transcode , PacketSize );

		if( iTranscode != Transcode)
		{
			logDebug1(" Writing it LONG32o the BSetoRmsBse queue...");
			logDebug1("TEST1");
			WriteToBseRms( ReceivePacket , PacketSize );
			logDebug1("TEST1");
			Flag  = FALSE;
		}	
		else
		{
			Flag = ReceiveQueryPersonalResponse ( ReceivePacket );
			logDebug1("The Flag Received is %d",Flag);

			if ( Flag == FALSE )
			{
				logDebug1("Error in QueryPersonalDownload ");
				BSEconnectLogFatal("Error in QueryPersonalDownload ");
				free( RequestPacket );
				free( ReceivePacket    );
				return(FALSE);
			}
		}	
	}while( Flag == FALSE );

	temp=0;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
	while(TRUE)
	{
		logDebug1("Entered While.....");
		memset( ReceivePacket , '\0',BSE_PACKET_SIZE );
		logDebug1("Waiting Before Receive ...");
		RecvBytes = RecvPacket ( iSockfd, ReceivePacket );	
		logDebug1(" Came out of wait on Socket ++++++++++++ %d ",RecvBytes);

		if ( RecvBytes < 0)
		{
			logDebug1("In QueryPersonalInfo : ERROR IN RECEIVING...");
			free( RequestPacket );
			free( ReceivePacket    );
			return(FALSE);
		}

		if ( RecvBytes == 0)
		{
			logDebug1("In QueryPersonalInfo : CONNECTION CLOSE REQUESTTED...");
			free( RequestPacket );
			free( ReceivePacket    );
			return(FALSE);
		}
		/**************** added in anagram **************/
		//	BSETWIDDLE(((struct OMB_HEADER*)ReceivePacket)->iMsgLen);
		//	BSETWIDDLE(((struct OMB_HEADER_INT *)ReceivePacket)->iMsgType);
		PacketSize = ((struct OMB_HEADER*)ReceivePacket)->iMsgLen + sizeof(struct OMB_HEADER) ;

		if( PacketSize > 10000)
			logDebug1("The packet is %100s",ReceivePacket);

		logDebug1("++++++++++ PacketSize is %d ",PacketSize );

		iTranscode = ((struct OMB_HEADER_INT *)ReceivePacket)->iMsgType;

		if( iTranscode == Transcode )
		{
			temp++;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
			logDebug1("Received A Download Packet [%d] --------",temp);
			WriteToDloadQ( ReceivePacket,PacketSize );
			continue;
		}
		else if( iTranscode == TC_EQU_BSE_END_OF_DOWNLOAD_1_UMS)
		{
			logDebug1(" ====================================");
			logDebug1(" RECEIVED THE END Of DOWNLOAD........");
			logDebug1(" ====================================");

			WriteToDloadQ( ReceivePacket, PacketSize );

			free( RequestPacket );
			free( ReceivePacket    );
			return TRUE	     ;
		}
		else if(iTranscode ==TC_EQU_BSE_END_OF_6A7A_DOWNLOAD)
		{
			logDebug1(" ====================================");
			logDebug1(" RECEIVED THE END Of 6A7A DOWNLOAD........");
			logDebug1(" ====================================");

			WriteToBseRms( ReceivePacket, PacketSize );

			free( RequestPacket );
			free( ReceivePacket    );
			return TRUE          ;
		}
		else 
		{
			logDebug1("TRANSCODE RECEIVED IS %d\n",iTranscode );
			WriteToBseRms( ReceivePacket,PacketSize );	
			logDebug1(" Written in queue and came out .. ++++++++++ ");
			continue;
		}
	}/**WHILE**/
}


void 	PrepareDownloadPacket (LONG32  Transcode,CHAR * Buffer)
{
	logTimestamp("Entry :PrepareDownloadPacket:");	
	LONG32 	iMsgTag;
	LONG32	PacketSize;
	LONG32	iMsgLen;
	struct  OMB_QUERY_PERSONAL_INFO *Packet;

	logDebug1("Inside PrepareDownloadPacket...");
	/* Added for IML version 42.0 by Bazid */
	if(Transcode == TC_EQU_BSE_QUERY_6A7A_REQUEST)
	{
		Packet = (struct OMB_QUERY_6A7A_INFO*)malloc(sizeof(struct OMB_QUERY_6A7A_INFO));
		memset( Packet,' ', sizeof(struct OMB_QUERY_6A7A_INFO));
	}
	else
	{
		Packet = (struct OMB_QUERY_PERSONAL_INFO*)malloc(sizeof(struct OMB_QUERY_PERSONAL_INFO));
		memset( Packet,' ', sizeof(struct OMB_QUERY_PERSONAL_INFO));
	}
	switch( Transcode )
	{
		case 1091:
			Packet->iMsgType=TC_EQU_BSE_QUERY_QUOTES_REQUEST;
			break;
		case 1092:
			Packet->iMsgType=TC_EQU_BSE_QUERY_ORDERS_REQUEST;
			break;
		case 1095:
			Packet->iMsgType=TC_EQU_BSE_QUERY_TRADERS_TRADES_REQUEST;
			break;
		case 1096:
			Packet->iMsgType=TC_EQU_BSE_QUERY_MEMBERS_TRADES_REQUEST;
			break;
		case 1097:
			Packet->iMsgType=TC_EQU_BSE_QUERY_PERSONAL_STOPLOSS_ORDERS;
			logDebug1("The Transcode sent is %d",Packet->iMsgType);
			break;
		case 1098:
			Packet->iMsgType=TC_EQU_BSE_QUERY_CKT_LIMIT;
			break;
		case 1170:
			Packet->iMsgType=TC_EQU_BSE_QUERY_RETURNED_ORDERS_REQUEST;
			break;
		case 1171:
			Packet->iMsgType=TC_EQU_BSE_QUERY_RETURNED_QUOTES_REQUEST;
			break;
		case 1173:
			Packet->iMsgType=TC_EQU_BSE_QUERY_RETURNED_STOPLOSS_ORDERS_REQUEST;
			break;
		case 10004:
			Packet->iMsgType=TC_EQU_BSE_OWN_DEFAULT_IN_AUCTION_REQUEST;
			break;
		case 10008:
			Packet->iMsgType=TC_EQU_BSE_QUERY_AUCTION_OFFERS_REQUEST;
			break;
		case 10011:
			Packet->iMsgType=TC_EQU_BSE_AUC_SCRIP_DLOAD_UMS;
			break;
		case 21501:
			Packet->iMsgType=TC_EQU_BSE_QUERY_6A7A_REQUEST;
			break;
	}

	Packet->iMsgTag=0;
	if ( Transcode == TC_EQU_BSE_QUERY_6A7A_REQUEST)
	{
		Packet->pHeader.iMsgLen = sizeof(struct OMB_QUERY_6A7A_INFO) - sizeof(struct OMB_HEADER) ;
		logDebug1(" ++++++++++++++++ 6A7A Message Length = %d",Packet->pHeader.iMsgLen);
	}
	else	
	{
		Packet->pHeader.iMsgLen= sizeof(struct OMB_QUERY_PERSONAL_INFO) - sizeof(struct OMB_HEADER) ;
	}
	Packet->pHeader.iSlotNo = 4; 
	logDebug1("The Transcode sent is %d",Packet->iMsgType);
	/**********************
	  Packet->ombbsetime.Hour = GetHour( TimeStamp );
	  Packet->ombbsetime.Minute = GetMinute ( TimeStamp );
	  Packet->ombbsetime.Second = GetSeconds ( TimeStamp );
	 *********************/
	memset(&Packet->ombbsetime,0,sizeof(struct OMB_BSE_TIME));
	/********** added in angram **************************/

	Packet->iMsgTag = 4;

	/***	BSETWIDDLE(Packet->iMsgTag);
	  BSETWIDDLE(Packet->pHeader.iMsgLen);
	  BSETWIDDLE(Packet->pHeader.iSlotNo);
	  BSETWIDDLE(Packet->iMsgType);****/




	//	Packet->ombbsetime.cSecond 	= iSec + '0';   /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
	//	Packet->ombbsetime.cMinute 	= iMinutes + '0';  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
	//	Packet->ombbsetime.cHour 	= iHours + '0';  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/

	Packet->ombbsetime.cSecond      =  '0';   /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
	Packet->ombbsetime.cMinute      =  '0';  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
	Packet->ombbsetime.cHour        =  '0'; 

	logDebug1("Incremental Download Time [%c:%c:%c]  The Transcode [%d]",Packet->ombbsetime.cHour,Packet->ombbsetime.cMinute,Packet->ombbsetime.cSecond,Packet->iMsgType);
	logDebug2("iMsgTag 		:%d:",Packet->iMsgTag);
	logDebug2("pHeader.iMsgLen	:%d:",Packet->pHeader.iMsgLen);
	logDebug2("pHeader.iSlotNo	:%d:",Packet->pHeader.iSlotNo);
	logDebug2("iMsgType		:%d:",Packet->iMsgType);

	memcpy( Buffer,Packet,sizeof(struct OMB_QUERY_PERSONAL_INFO));
	free(Packet);
	return ;
}


LONG32  ReceiveQueryPersonalResponse (CHAR * QueryPersonalResp)
{
	logTimestamp("Entry :ReceiveQueryPersonalResponse:");	
	struct OMB_QUERY_INFO_RESP * pQueryPersonalInfoResp;
	pQueryPersonalInfoResp=(struct OMB_QUERY_INFO_RESP *)malloc(sizeof(struct OMB_QUERY_INFO_RESP));

	memcpy(pQueryPersonalInfoResp,QueryPersonalResp,sizeof(struct OMB_QUERY_INFO_RESP));	
	logDebug1("The Reply Code is %d",pQueryPersonalInfoResp->iRepCode);

	if(pQueryPersonalInfoResp->iRepCode==0)
	{
		logDebug1("--------------------------------------");
		logDebug1("Download Request For Transcode %d Successfull",pQueryPersonalInfoResp->iMsgType);
		logDebug1("--------------------------------------");
		free(pQueryPersonalInfoResp);
		logDebug1("After Free...");
		return TRUE;
	}
	else
	{
		logDebug1("--------------------------------------");
		logDebug1("Download Request For Transcode %d Failed ...",pQueryPersonalInfoResp->iMsgType);
		logDebug1("--------------------------------------");
		free(pQueryPersonalInfoResp);
		return FALSE;
	}

}

LONG32  DownloadEnd( LONG32 Tcode )
{
	logTimestamp("Entry :DownloadEnd:");	
	LONG32	PacketSize;

	struct END_DOWNLOAD *pEndDownload;

	logDebug1("Inside End of Download...");

	pEndDownload=(struct END_DOWNLOAD *)malloc(sizeof(struct END_DOWNLOAD));

	pEndDownload->pHeader.iSlotNo = 0 ;
	pEndDownload->pHeader.iMsgLen = sizeof(struct END_DOWNLOAD) - sizeof(struct OMB_HEADER);
	PacketSize = sizeof( struct END_DOWNLOAD) ;
	pEndDownload->iMsgType= TC_END_OF_DOWNLOADS ;
	pEndDownload->iGroupId = 1 ;
	logTimestamp(":%s: DOWNLOAD REQUEST SENT TO EXCHANGE  ",KEY_WORD_MONITORING);
	WriteToDloadQ ( pEndDownload, PacketSize);

	free(pEndDownload);
	return TRUE;
}


void	GetTimeForDownload( )
{
	logTimestamp("Entry :GetTimeForDownload:");	
	LONG64	TimeInSecs = 0;
	CHAR    RetTime[TIME_LENGTH];
	CHAR    Date[TIMESTAMP_LENGTH];
	LONG64    TimeOffset =  0 ;	
	MYSQL_RES 	*Res;
	MYSQL_ROW	Row;

	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

//	CHAR	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	logDebug1("Inside GetTimeForDownload...");
	memset(TimeStamp, NULL,TIME_LENGTH);

	sprintf(sSelQry," SELECT EAM_LAST_MSG_TIME ,EAM_EXCH_OFFSET_TIME \
			FROM EXCH_ADMINISTRATION_MASTER\
			WHERE  EAM_GROUP_ID =  %d \
			AND EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_SEGMENT = 'C'\
			AND EAM_DRV_FLAG = 'N';	",iGlobUserGroupId);

	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_BseCon,sSelQry) != SUCCESS)
	{
		sql_Error(DB_BseCon);
	}	

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		TimeInSecs = atol(Row[0]);
	}

	logDebug1("The Number of Seconds selected is %ld",TimeInSecs);

	if ( TimeInSecs == 0 )
	{
		logDebug1("SENDING REQUEST FOR FULL DOWNLOAD...");
		strcpy(TimeStamp,"00:00:00");
		return ;
	}	

	logDebug1("SENDING REQUEST FOR INCREMENTAL DOWNLOAD...");

	logDebug1 (" Time :%ld   Offset :%ld " , TimeInSecs , TimeOffset ) ;
	TimeInSecs = TimeInSecs  + TimeOffset  ;
	Convert_Seconds_To_Time( TimeInSecs, RetTime);
	strcpy(TimeStamp,RetTime) ;
	logDebug1("The Time Going To Be Sent To Exchange Is :%s",RetTime) ;
	return;
}


void Convert_Seconds_To_Time( LONG64 seconds,CHAR *pTime)
{
	logTimestamp("Entry :Convert_Seconds_To_Time:");	
	struct tm *tmr;
	time_t julian;

	tmr = (struct tm *) malloc (sizeof(struct tm )) ;
	julian = seconds + OFFSET - TIMEZONE_BSE;

	localtime_r(&julian,tmr);
	strftime(pTime,9,"%T",tmr);
	logDebug1("The Time To Be sent is :%s",pTime);
	free(tmr);
}


LONG32 RecvPacket ( LONG32 sockfd, CHAR* packet ) 
{
	logTimestamp("Entry :RecvPacket:");	
	LONG32 RecvBytes , ErrorCount = 1,ReadBytes = 0,errorno;
	CHAR *  buffer ;
	LONG32	BreakCounter = 0;
	LONG32	BytesToRead  = 0;

	logDebug1("Inside Receive packet ");	
	buffer = (CHAR *) malloc( BYTES_TO_READ );
	memset(buffer ,' ',BYTES_TO_READ);
	logDebug1("*****");
	BytesToRead = sizeof(INT_BSE_HEADER) ;

	for( ; ; )
	{
		RecvBytes = recv( sockfd ,buffer ,BytesToRead, MSG_PEEK );	
		logDebug1("The received Bytes is %d",RecvBytes);

		if( RecvBytes <= 0)
		{
			logDebug1("In PEEK Received Bytes Less Than Equal To Zero...");
			perror("Error is :");
			BSEconnectLogFatal("In PEEK Received Bytes Less Than Equal To Zero...");
			SignalHandlerSigChldMain();	
			free(buffer);
			return RecvBytes ;
		}

		if( RecvBytes < BytesToRead )
		{
			logDebug1("Full Header not received");
			if (BreakCounter <= BREAKCOUNTER )
			{
				BreakCounter ++;
				Sleep(10);
				continue;
			}
			else
			{
				logDebug1("Inside Else Full Header not Received...");
				BytesToRead = ERROR ;
				free(buffer);
				BytesToRead ;
			}
		}
		else
		{
			BreakCounter = 0;
			/***************Added in anagram ***************/
			//	BSETWIDDLE(((struct OMB_HEADER *)buffer)->iMsgLen);
			//	BSETWIDDLE(((struct OMB_HEADER *)buffer)->iSlotNo);
			BytesToRead = ((INT_BSE_HEADER *)buffer)->iMsgLength;
			logDebug1(" The Bytes to read from the exchange as given by the exchange are : %d ", BytesToRead );

			if ( (((INT_BSE_HEADER *)buffer)->iMsgLength <= 0) || ( BytesToRead > BYTES_TO_READ)  )
			{
				logDebug1("Message Length received is Zero...Disconnecting");
				BytesToRead = ERROR ;
				free(buffer);
				return BytesToRead ;

			}
			for( ; ; )
			{
				RecvBytes = recv( sockfd ,buffer ,BytesToRead, MSG_PEEK );	
				if ( RecvBytes < BytesToRead )
				{
					if (BreakCounter <= BREAKCOUNTER )
					{
						BreakCounter ++ ;
						logDebug1("Sleeping for 100 MS");
						Sleep(100);
						continue;
					}
					else
					{
						logDebug1("Full Packet Not Received ...");		
						BytesToRead = ERROR ;
						free(buffer);
						return BytesToRead ;
					}
				}	
				else
				{
					break;
				}

			}/**FOR ENDS**/
		}/**ELSE ENDS**/
		break ;
	}/**FOR ENDS**/

	RecvBytes = recv( sockfd , packet,BytesToRead ,0) ;
	free(buffer);
	return RecvBytes ;
}


LONG32	SendPacket ( LONG32 sockfd ,CHAR * packet ,size_t size )
{
	logTimestamp("Entry :SendPacket:");	
	signal(SIGPIPE,SIG_IGN);
	LONG32 SentBytes,ErrorCount = 1;
	logDebug1("Inside SendPacket... sockfd passed is %d", sockfd );
	logDebug1(" Size is %d ", size );
	do
	{
		SentBytes = send ( sockfd, packet, size , 0 );
		if (SentBytes < 0)
		{
			logDebug1("There is some error...");
			perror("TCP Send Problem :");
			BSEconnectLogFatal("TCP Send Problem :");
			ErrorCount ++;
		}
	}
	while((SentBytes < 0)&&(ErrorCount < BREAKCOUNTER));

	if( (SentBytes < 0) && (ErrorCount >= BREAKCOUNTER))
	{
		BSEconnectLogFatal("Found A Persistent Problem While Sending");
	//	exit(0) ;
	}
	return(SentBytes);
}


LONG32	QueryIndexValue (LONG32 Tcode )
{
	logTimestamp("Entry :QueryIndexValue:");	
	LONG32	RetVal ;
	LONG32	SentBytes,RecvBytes;
	LONG32	PacketSize ;
	LONG32	Flag = FALSE;

	CHAR	*QueryIndexReq ;
	CHAR	*LogOnResp ;

	QueryIndexReq  = (CHAR *)malloc( sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST)) ;
	LogOnResp = (CHAR *)malloc( sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY)) ;

	logDebug1("In QueryIndexValue ");

	if(  ( RetVal = PrepareQueryIndexValue (QueryIndexReq )) == TRUE )
	{
		//BSETWIDDLE(((struct OMB_HEADER*)QueryIndexReq)->iMsgLen);
		PacketSize = ((struct OMB_HEADER*)QueryIndexReq)->iMsgLen + sizeof(struct OMB_HEADER) ;
		//BSETWIDDLE(((struct OMB_HEADER*)QueryIndexReq)->iMsgLen);
		SentBytes = SendPacket (iSockfd, QueryIndexReq, PacketSize );
		if( SentBytes < 0)
		{
			free(QueryIndexReq);
			free(LogOnResp);
			BSEconnectLogFatal("Query Index Sentbytes Failed");
			return FALSE;
		}
	}
	else
	{
		free(QueryIndexReq);
		free(LogOnResp);
		BSEconnectLogFatal("Query Index Sentbytes Failed");
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, LogOnResp );	
		logDebug1("Received A packet from Exchange ...");
		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			free(QueryIndexReq);
			free(LogOnResp);
			return FALSE;
		}
		if( RecvBytes == 0)
		{
			free(QueryIndexReq);
			free(LogOnResp);
			return FALSE;
		}
		if ( (Flag = ReceiveQueryIndexValue (LogOnResp )) == TRUE )
		{
			free(LogOnResp) ;
			free(QueryIndexReq) ;
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			continue ;
		}
		else
		{
			free(LogOnResp) ;
			free(QueryIndexReq) ;
			return FALSE ;
		}
	}while( Flag == RETRY );
}


LONG32  PrepareQueryIndexValue (CHAR *QueryIndexReq  )
{
	logTimestamp("Entry :PrepareQueryIndexValue:");	

	struct OMB_QUERY_INDEX_VALUES_REQUEST *pQueryIndex;

	pQueryIndex = (struct OMB_QUERY_INDEX_VALUES_REQUEST *)malloc(sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST ));

	logDebug1("In PrepareQueryIndexValue ");

	memset(QueryIndexReq,' ',sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST) ) ;
	memset(pQueryIndex, ' ',sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST));

	pQueryIndex->pHeader.iSlotNo = 1;
	pQueryIndex->pHeader.iMsgLen = sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST) - sizeof(struct OMB_HEADER) ;
	pQueryIndex->iMsgType = TC_EQU_BSE_QUERY_INDEX_DETAILS_REQUEST  ;	
	pQueryIndex->iMsgTag = 1005;	
	pQueryIndex->iIndexCode = 2 ;              /*** to be confirmed **/	
	pQueryIndex->cDirection = 'P' ;              /*** to be confirmed **/	


	/**	BSETWIDDLE(pQueryIndex->pHeader.iSlotNo);
	  BSETWIDDLE(pQueryIndex->pHeader.iMsgLen);
	  BSETWIDDLE(pQueryIndex->iMsgType);
	  BSETWIDDLE(pQueryIndex->iIndexCode);
	  BSETWIDDLE(pQueryIndex->iMsgTag);***/

	memcpy( QueryIndexReq,(CHAR*)pQueryIndex, sizeof(struct OMB_QUERY_INDEX_VALUES_REQUEST ));

	free(pQueryIndex);
	return 	TRUE ; 
}


LONG32  ReceiveQueryIndexValue (CHAR *LogOnResp )
{
	logTimestamp("Entry :ReceiveQueryIndexValue:");	
	LONG32 	SentBytes = 0 ;
	LONG32	iRetVal = FALSE ;
	LONG32	count = 0 ;
	struct OMB_QUERY_INDEX_VALUES_REPLY *pBuffer;
	
	CHAR    sUpdQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);

	CHAR    sInsQry[MAX_QUERY_SIZE];
	memset(sInsQry,'\0',MAX_QUERY_SIZE);

//	CHAR	*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR	*sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR	IndexName[40] ;
	DOUBLE64 CurrIndexVal ;			/*** PRECESION ***/
	DOUBLE64 OpenIndexVal ;			/*** PRECESION ***/
	DOUBLE64 CloseIndexVal ;		/*** PRECESION ***/
	DOUBLE64 PctChange ;			/*** PRECESION ***/
	DOUBLE64 High;				/*** PRECESION ***/
	DOUBLE64 Low;				/*** PRECESION ***/
	CHAR ChangeInd;


	pBuffer = (struct OMB_QUERY_INDEX_VALUES_REPLY * )malloc(sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY ) );
	memset( pBuffer , ' ',sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY ));

	logDebug1("In ReceiveQueryIndexValue ");

	memcpy( pBuffer, LogOnResp, sizeof(struct OMB_QUERY_INDEX_VALUES_REPLY));

	/***BSETWIDDLE(pBuffer->iMsgType);
	  BSETWIDDLE(pBuffer->iRepCode);
	  BSETWIDDLE(pBuffer->iNoOfRecords);
	  BSETWIDDLE(pBuffer->iMsgTag);****/

	logDebug1("The Transcode  Received is %d",pBuffer->iMsgType ) ;

	if( pBuffer->iMsgType != TC_EQU_BSE_QUERY_INDEX_DETAILS_REPLY )
	{
		logDebug1("Received Packet is not of QueryIndexValue Reply..");
		return  RETRY ;
	}

	logDebug1("********************************************************");
	logDebug1("* 	Q U E R Y   I N D E X  	R E  P L Y	       *");
	logDebug1("********************************************************");
	logDebug1("Transcode   Received : %d",  pBuffer->iMsgType   );
	logDebug1("Reply Code  Received : %d",  pBuffer->iRepCode   );
	logDebug1("iNoOfRecords Received : %d",  pBuffer->iNoOfRecords );
	logDebug1("iMsgTag      Received : %d",  pBuffer->iMsgTag );
	logDebug1("********************************************************");



	if( pBuffer->iRepCode == 0  )  
	{
		for( count=0; count < pBuffer->iNoOfRecords; count++)
		{
			memset(IndexName ,' ',40);
			ChangeInd = ' ';

			memcpy(IndexName ,pBuffer->pDtls[count].sIndexId,INDEXID_LEN);

			/**8BSETWIDDLE(pBuffer->pDtls[count].iHigh);
			  BSETWIDDLE(pBuffer->pDtls[count].iLow);
			  BSETWIDDLE(pBuffer->pDtls[count].iOpen);	
			  BSETWIDDLE(pBuffer->pDtls[count].iClose);	
			  BSETWIDDLE(pBuffer->pDtls[count].iCurValue);***/	

			logDebug1(" pBuffer->pDtls[%d].Open : %d",count,pBuffer->pDtls[count].iOpen);
			logDebug1(" pBuffer->pDtls[%d].Close : %d",count,pBuffer->pDtls[count].iClose);
			logDebug1(" pBuffer->pDtls[%d].CurValue : %d",count,pBuffer->pDtls[count].iCurValue);
			logDebug1(" IndexName : %.7s",pBuffer->pDtls[count].sIndexId);
			logDebug1(" pBuffer->pDtls[%d].High : %d",count,pBuffer->pDtls[count].iHigh);
			logDebug1(" pBuffer->pDtls[%d].Low : %d",count,pBuffer->pDtls[count].iLow);

			CurrIndexVal =  (DOUBLE64)(pBuffer->pDtls[count].iCurValue)/100.0 ;	/*** PRECESION ***/
			OpenIndexVal =  (DOUBLE64)(pBuffer->pDtls[count].iOpen)/100.0 ;		/*** PRECESION ***/
			CloseIndexVal = (DOUBLE64)(pBuffer->pDtls[count].iClose)/100.0;		/*** PRECESION ***/
			PctChange =  ((DOUBLE64)(CurrIndexVal - CloseIndexVal)/CloseIndexVal)*100.0;	/*** PRECESION ***/
			High      = (DOUBLE64)(pBuffer->pDtls[count].iHigh)/100.0 ;		/*** PRECESION ***/
			Low      = (DOUBLE64)(pBuffer->pDtls[count].iLow)/100.0 ;			/*** PRECESION ***/

			logDebug1(" CurrIndexVal : %lf",CurrIndexVal);
			logDebug1(" OpenIndexVal : %lf",OpenIndexVal);
			logDebug1(" CloseIndexVal : %lf",CloseIndexVal);
			logDebug1(" PctChange : %lf",PctChange);
			logDebug1(" IndexName  : %s",IndexName );
			logDebug1(" count : %d",count);

			if( PctChange < 0 )
			{
				ChangeInd = '-' ;
			}
			else if(PctChange > 0)
			{
				ChangeInd = '+' ;
			}
			else
			{
				ChangeInd = ' ' ;
			}

			if( PctChange < 0 )
			{
				PctChange = 0 - PctChange ;
			}	

			if( strncmp(pBuffer->pDtls[count].sIndexId,"SENSEX",6) == 0 )
			{
				sprintf(sUpdQry,"UPDATE MULTIPLE_INDEX_INQUIRY \
						SET	MII_INDEX_VAL =  :CurrIndexVal,\
						MII_OPENING_INDEX = :OpenIndexVal,\
						MII_CLOSING_INDEX = :CloseIndexVal,\
						MII_HIGH_INDEX_VAL=:High,\
						MII_LOW_INDEX_VAL =:Low,\
						MII_PCT_CHANGE = :PctChange,\
						MII_NET_CHANGE_IND = :ChangeInd,\
						MII_TIME = sysdate\
						WHERE	MII_INDEX_NAME = :IndexName"); 
					if(mysql_query(DB_BseCon,sUpdQry)!= SUCCESS)	
					{
						logDebug1("\n Update MII sucessful ");
						logDebug1("\n IndexName  : %s",IndexName );
						iRetVal = TRUE ;
					}
					else if(TRUE)  
					{
						sprintf(sInsQry,"INSERT INTO	MULTIPLE_INDEX_INQUIRY\
								( MII_INDEX_NAME,\
								  MII_EXCH_ID,\
								  MII_INDEX_VAL,\
								  MII_OPENING_INDEX,\
								  MII_CLOSING_INDEX,\
								  MII_HIGH_INDEX_VAL,\
								  MII_LOW_INDEX_VAL,\
								  MII_PCT_CHANGE,\
								  MII_NET_CHANGE_IND,\
								  MII_TIME\
								)\
								VALUES  ( :IndexName,\
									'BSE',\
									:CurrIndexVal,\
									:OpenIndexVal,\
									:CloseIndexVal,\
									:High,\
									:Low,\
									:PctChange,\
									:ChangeInd,\
									sysdate\
									) ;");

						if(mysql_query(DB_BseCon,sInsQry)!= SUCCESS)
						{
							logDebug1("  Insert LONG32o MII failed : sqlerr -  ");
							iRetVal = FALSE ;
							break ;
						}
						else
						{
							logDebug1("  Insert LONG32o MII Successful ");
							iRetVal = TRUE ;
						}
					}
					else 
					{
						logDebug1(" Update MII failed : sqlerr - ");
						iRetVal = FALSE ; 
						break ;
					}
				break ;
			}		
			iRetVal = TRUE ;   /* Has to removed while putting in live */
		}				

		if ( iRetVal == TRUE )
		{ 
			free( pBuffer );
			logDebug1("Query Index Value Successfull...");
			return TRUE;
		}
		else
		{
			free(pBuffer);
			BSEconnectLogFatal("Query Index Value Fail...");
			return FALSE;
		}
	}  /* end if( iRepCode == 0 ) */
	else 
	{
		free(pBuffer);
		return FALSE;
	}
}




LONG32	HandleLogOn ( )
{
	logTimestamp("Entry :HandleLogOn:");	
	LONG32	RetVal ;
	LONG32	SentBytes,RecvBytes;
	LONG32	PacketSize ;
	LONG32	Flag = FALSE;
	LONG32	UserId;

	CHAR	*LogOnReq ;
	CHAR	*LogOnResp ;

	LogOnReq  = (CHAR *)malloc( BSE_PACKET_SIZE ) ;
	LogOnResp = (CHAR *)malloc( BSE_PACKET_SIZE ) ;

	logDebug1("In HandleLogOn...");

	UserId = iGlobUserGroupId ;
	if(  ( RetVal = PrepareLogOnPacket (LogOnReq ,UserId )) == TRUE )
	{
		/*************** Added in anagram ***********************/
		//	BSETWIDDLE(((struct OMB_HEADER*)LogOnReq)->iMsgLen);
		PacketSize =  sizeof(struct FIX_BSE_USER_LOGON_REQ) ;
		//	BSETWIDDLE(((struct OMB_HEADER*)LogOnReq)->iMsgLen);
		SentBytes = SendPacket (iSockfd, LogOnReq, PacketSize );

		if( SentBytes < 0)
		{
			free(LogOnReq);
			free(LogOnResp);
			BSEconnectLogFatal("SentBytes Failed 1");
			return FALSE;
		}
	}
	else
	{
		free(LogOnReq);
		free(LogOnResp);
		BSEconnectLogFatal("SentBytes Failed 2");
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, LogOnResp );	
		logDebug1("Received A packet from Exchange ...");

		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}

		if( RecvBytes == 0)
		{
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}

		if ( (Flag = ReceiveLogOnResp (LogOnResp ,UserId )) == TRUE )
		{
			logDebug3("ReceiveLogOnResp response is true LogOnResp ");
			free(LogOnResp) ;
			logDebug3("ReceiveLogOnResp response is true LogOnReq");
			free(LogOnReq) ;
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			continue ;
		}
		else
		{
			free(LogOnResp) ;
			free(LogOnReq) ;
			return FALSE ;
		}
	}while( Flag == RETRY );
}


LONG32  PrepareLogOnPacket (CHAR *LogOnReq ,LONG32 UserId )
{
	logTimestamp("Entry :PrepareLogOnPacket:");	
	LONG32		iRetVal			;
	LONG32		iCntr			;


	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

//	CHAR	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	struct FIX_BSE_USER_LOGON_REQ *pSignOn;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	pSignOn = (struct FIX_BSE_USER_LOGON_REQ *)malloc(sizeof(struct FIX_BSE_USER_LOGON_REQ));

	logDebug1("In PrepareLogOnPacket.... ");

	memset(LogOnReq,' ',LOGIN_REQ_PACKET_SIZE ) ;


	pSignOn->pHeader.iMsgLength = sizeof(struct FIX_BSE_USER_LOGON_REQ )  ;
	pSignOn->pHeader.iMsgCode = 10018;
	strcpy(pSignOn->pHeader.sNetworkMsgID,"");
	strcpy(pSignOn->pHeader.sPad2,"");
	iTempSendSeqNum++;
	pSignOn->iMsgSeqNum = iTempSendSeqNum;
	pSignOn->iSendSubId= 0;

	/***
	  EXEC SQL SELECT 
	  EAM_OLD_PASSWORD
	  INTO    
	  :ecryptedPassword 
	  FROM    EXCH_ADMINISTRATION_MASTER
	  WHERE  EAM_EXM_EXCH_ID = 'BSE' 
	  AND EAM_EXCH_USER_ID = to_CHAR(:iGlobUserGroupId )
	  AND EAM_DRV_FLAG = 'N';
	 ****/
	memset(pSignOn->sBsePassword,'\0',BSE_ETI_PASSWORD_LEN ) ;
	sprintf(sSelQry,"SELECT \
			aes_decrypt(EAM_OLD_PASSWORD,'rupee123'),EAM_EXCH_USER_ID\
			FROM    EXCH_ADMINISTRATION_MASTER\
			WHERE  EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_GROUP_ID = %d\
			AND EAM_SEGMENT = 'C'\
			AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);	

		logDebug2("sSelQry :%s:",sSelQry);

	if (mysql_query(DB_BseCon,sSelQry) != SUCCESS)
	{
		sql_Error(DB_BseCon);
		exit(0);
	}

	Res = mysql_store_result(DB_BseCon);
	if(Row = mysql_fetch_row(Res))
	{
		pSignOn->iExchUserId= atol(Row[1]);;
		strcpy(pSignOn->sBsePassword,Row[0]);
	}

	logDebug1(" pSignOn->pHeader.iMsgLength    = %d", pSignOn->pHeader.iMsgLength);
        logDebug1(" pSignOn->pHeader.iMsgCode      = %d", pSignOn->pHeader.iMsgCode);
        logDebug1(" pSignOn->pHeader.sPad2 = :%s:", pSignOn->pHeader.sPad2);
	logDebug1(" pSignOn->iExchUserId = :%ld:",pSignOn->iExchUserId);
	logDebug1(" pSignOn->sBsePassword 	= :%s:",pSignOn->sBsePassword);
	

	logTimestamp(":%s:  SIGNON REQUEST WITH PASSWORD  :%s: ",KEY_WORD_MONITORING,pSignOn->sBsePassword);
	logDebug1(" PlaLONG32ext Password User");
	logDebug1(" NON - DISEC Encrypted Password is  : [%s] :",pSignOn->sBsePassword);

	memcpy( LogOnReq, (CHAR*)pSignOn, sizeof(struct FIX_BSE_USER_LOGON_REQ));
	free(pSignOn);
	return 	TRUE ; 
}


LONG32  ReceiveLogOnResp (CHAR *LogOnResp,LONG32 UserId )
{
	logTimestamp("Entry  :ReceiveLogOnResp:");
	if(((INT_BSE_HEADER_OUT *)LogOnResp)->iMsgCode == 10019)
	{
		struct FIX_BSE_USER_LOGON_RESP *pBuffer;
		pBuffer = (struct FIX_BSE_USER_LOGON_RESP *) malloc(sizeof(struct FIX_BSE_USER_LOGON_RESP));

		memcpy(pBuffer,LogOnResp,sizeof(struct FIX_BSE_USER_LOGON_RESP));
		logDebug1("The Transcode  Received is %d",pBuffer->pHeader.iMsgCode ) ;


		logDebug1("********************************************************");
		logDebug1("* 	L O G O N  	R E  P L Y		       *");
		logDebug1("********************************************************");
		logDebug1("Length  Received : %d",  pBuffer->pHeader.iMsgLength);
		logDebug1("Transcode  Received : %d",  pBuffer->pHeader.iMsgCode);
		logDebug1("iRequestTime	  : %ld",  pBuffer->iRequestTime);
		logDebug1("iSendTime		: %ld",  pBuffer->iSendTime);
		logDebug1("iMsgSeqNum	: %d",  pBuffer->iMsgSeqNum);
		logDebug1("iLastLoginTime	: %ld",  pBuffer->iLastLoginTime);
		logDebug1("cDayLeftForPasswdExpiry  : %d",  pBuffer->cDayLeftForPasswdExpiry);
		logDebug1("cGraceLoginLeft	: %d",  pBuffer->cGraceLoginLeft);
		logDebug1("********************************************************");
		logTimestamp("Exit  :ReceiveLogOnResp:");
		free(pBuffer);
		/************* added by appa in anagram ******************/
		return TRUE;
	}
	else if(((INT_BSE_HEADER_OUT *)LogOnResp)->iMsgCode == 10010)
        {
                struct FIX_BSE_SESSION_REJECT_RESP * pUserRejResp ;


                pUserRejResp= (struct FIX_BSE_SESSION_REJECT_RESP * )malloc \
                       (sizeof(struct FIX_BSE_SESSION_REJECT_RESP ));



                memcpy( pUserRejResp, LogOnResp, sizeof(struct FIX_SESSION_LOGON_RESP));
                logDebug1(" pUserRejResp->pHeader.iMsgLength    = %d", pUserRejResp->pHeader.iMsgLength);
                logDebug1(" pUserRejResp->pHeader.iMsgCode      = %d", pUserRejResp->pHeader.iMsgCode);
                logDebug1(" pUserRejResp->pHeader.sPad2 = :%s:", pUserRejResp->pHeader.sPad2);
                logDebug1(" pUserRejResp->iRequestTime  = %ld", pUserRejResp->iRequestTime);
                logDebug1(" pUserRejResp->iRequestOut   = %ld", pUserRejResp->iRequestOut);
                logDebug1(" pUserRejResp->iTradeRegTSTimeIn     = %ld", pUserRejResp->iTradeRegTSTimeIn);
                logDebug1(" pUserRejResp->iTradeRegTSTimeOut    = %ld", pUserRejResp->iTradeRegTSTimeOut);
                logDebug1(" pUserRejResp->iResponseIn   = %ld", pUserRejResp->iResponseIn       );
                logDebug1(" pUserRejResp->iSendingTime  = %ld", pUserRejResp->iSendingTime);
                logDebug1(" pUserRejResp->iMsgSeqNum    = %d", pUserRejResp->iMsgSeqNum);
                logDebug1(" pUserRejResp->cLastFragment = %d", pUserRejResp->cLastFragment);
                logDebug1(" pUserRejResp->sPad3         = %s", pUserRejResp->sPad3);
                logDebug1(" pUserRejResp->iRejectionReasonCode  = %d", pUserRejResp->iRejectionReasonCode);
                logDebug1(" pUserRejResp->iRejMsgLen    = %d", pUserRejResp->iRejMsgLen);
                logDebug1(" pUserRejResp->cSessionStatus        = %d", pUserRejResp->cSessionStatus);
                logDebug1(" pUserRejResp->sRejectionMsg = :%s:", pUserRejResp->sRejectionMsg);
                logDebug1("In ReceiveRegistrationResp");
		logTimestamp("Exit  :ReceiveLogOnResp:");
		//free(pUserRejResp);
		return FALSE;
        }	


}


LONG32  HandleLogOff( )
{
	logTimestamp("Entry :HandleLogOff:");	

	LONG32     RetVal ;
	LONG32     SentBytes,RecvBytes ;
	LONG32	PacketSize ;
	LONG32	Flag ;
	LONG32	UserId;

	CHAR   *LogOffReq ;
	CHAR   *LogOffResp ;

	LogOffReq  = ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
	LogOffResp = ( CHAR *)malloc( BSE_PACKET_SIZE ) ;

	logDebug1("In HandleLogOff ....");

	UserId = iGlobUserGroupId ;

	if( (RetVal = PrepareLogOffPacket(LogOffReq , UserId)) == TRUE )
	{
		logDebug1("This is before sending packet to exchange...");
		/**********Added in anagram **********************/	
		//		BSETWIDDLE(((struct OMB_HEADER*)LogOffReq)->iMsgLen);

		PacketSize = ((struct OMB_HEADER*)LogOffReq)->iMsgLen + sizeof(struct OMB_HEADER) ;	
		//		BSETWIDDLE(((struct OMB_HEADER*)LogOffReq)->iMsgLen);

		logDebug1("The Packet Size is %d",PacketSize);
		SentBytes = SendPacket (iSockfd,LogOffReq,PacketSize ); 

		if( SentBytes < 0)
		{
			free(LogOffReq);
			free(LogOffResp);
			BSEconnectLogFatal("Error in PrepareLogOffPacket.SendBytes less than 0");
			return FALSE ;
		}

	}
	else
	{
		free(LogOffReq);
		free(LogOffResp);
		BSEconnectLogFatal("Error in PrepareLogOffPacket.Failed");
		return FALSE ;
	}

	logDebug1("Waiting To Receive Logoff Response...");
	RecvBytes = RecvPacket ( iSockfd, LogOffResp );
	logDebug1("tReceived The Packet for Logoff...");

	if ( RecvBytes < 0 )
	{
		logDebug1("Error in RecvPacket ..");
		free( LogOffReq );
		free( LogOffResp );
		BSEconnectLogFatal("Error in RecvPacket ..");
		return( FALSE );
	}

	if ( RecvBytes == 0)
	{
		logDebug1("Connection close requested..");
		free( LogOffReq );
		free( LogOffResp );
		BSEconnectLogFatal("Connection close requested..");
		return( FALSE );
	}

	if ( (Flag = ReceiveLogOffResp( LogOffResp ,UserId )) == TRUE )
	{
		free(LogOffResp) ;
		free(LogOffReq) ;
		return TRUE;
	}
	else
	{
		free(LogOffResp) ;
		free(LogOffReq) ;
		BSEconnectLogFatal("Receive Log Off Failed..");
		return FALSE ;
	}

}


LONG32  PrepareLogOffPacket (CHAR *LogOffReq ,LONG32 UserId)
{
	logTimestamp("Entry :PrepareLogOffPacket:");	
	CHAR    *PlainPassword  ;
	LONG32     iRetVal      ;
	LONG32 	iCntr		;


	struct OMB_LOG_ON_OFF_REQUEST *pSignOn;
	CHAR tempPassWd[40]      ;
	CHAR ecryptedPassword[75];

	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

//	CHAR	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR	*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	logDebug1("In PrepareLogOffReq ");

	pSignOn = (struct OMB_LOG_ON_OFF_REQUEST *)malloc(sizeof(struct OMB_LOG_ON_OFF_REQUEST ));


	memset( LogOffReq, '\0', LOG_OFF_REQ_LEN ) ;
	bzero(pSignOn, sizeof(struct OMB_LOG_ON_OFF_REQUEST ));
	memset(tempPassWd ,'\0',40) ;
	memset(ecryptedPassword ,'\0',75) ;

	PlainPassword=(CHAR*)malloc(PASSWORD_LEN +1);
	memset(PlainPassword, '\0', PASSWORD_LEN +1);

	pSignOn->pHeader.iSlotNo = REQUEST_SLOT ;
	pSignOn->pHeader.iMsgLen = sizeof(struct OMB_LOG_ON_OFF_REQUEST ) - sizeof(struct OMB_HEADER);
	logDebug1("The Message Length sent is %d",pSignOn->pHeader.iMsgLen);
	pSignOn->iMsgType = TC_EQU_BSE_LOGOFF_REQUEST ;

	memset(pSignOn->sPasswd,' ',BSE_PASSWORD_LEN ) ;
	sprintf(sSelQry,"SELECT EAM_OLD_PASSWORD \
			FROM    EXCH_ADMINISTRATION_MASTER\
			WHERE  EAM_EXM_EXCH_ID = 'BSE' \
			AND EAM_GROUP_ID = %d \
			AND EAM_DRV_FLAG = 'N' ;",iGlobUserGroupId);


	if (mysql_query(DB_BseCon,sSelQry) != SUCCESS )
	{
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{	
		strcpy(pSignOn->sPasswd,Row[0]);
		logDebug1(" PlaLONG32ext Password User");
		logDebug1("Password = ::[%s]",pSignOn->sPasswd);
	}
	pSignOn->iMsgTag = 0;
	/**	BSETWIDDLE(pSignOn->pHeader.iSlotNo);
	  BSETWIDDLE(pSignOn->pHeader.iMsgLen);
	  BSETWIDDLE(pSignOn->iMsgType);
	  BSETWIDDLE(pSignOn->iMsgTag);
	 **/
	memcpy( LogOffReq,(CHAR*)pSignOn, sizeof(struct OMB_LOG_ON_OFF_REQUEST));

	free(pSignOn);
	free(PlainPassword);
	logDebug1(" End of PrepareLogOffReq");
	return  TRUE ;
}



LONG32 ReceiveLogOffResp (CHAR* LogOffResp ,LONG32 UserId )
{
	logTimestamp("Entry :ReceiveLogOffResp:");	
	LONG32 RetVal ;
	CHAR  tempTraderID[30]  ;
	CHAR tempErrMsg[ERROR_MSG_LEN];
	struct OMB_LOG_OFF_REPLY *pUserLogOffResp;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	pUserLogOffResp = (struct OMB_LOG_OFF_REPLY * )malloc(sizeof(struct OMB_LOG_OFF_REPLY ) );
	memset( pUserLogOffResp,' ',sizeof(struct OMB_LOG_OFF_REPLY));	

	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

//	CHAR	*sSelQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	logDebug1("In ReceiveLogOffResp.... ");

	memcpy( pUserLogOffResp, (CHAR *)LogOffResp, sizeof(struct OMB_LOG_OFF_REPLY));

	/******** Added in anagram ************************/
	/**8	BSETWIDDLE(pUserLogOffResp->iMsgType);
	  BSETWIDDLE(pUserLogOffResp->iRepCode);
	  BSETWIDDLE(pUserLogOffResp->iFiller);
	  BSETWIDDLE(pUserLogOffResp->iMsgTag);
	  BSETWIDDLE(pUserLogOffResp->iCurSession);
	 ***/	/*******************************************************/

	logDebug1("*****************************************************");
	logDebug1("   	L O G O F F   R E P L Y                        ");
	logDebug1("*****************************************************");
	logDebug1("Transcode Received : %d", pUserLogOffResp->iMsgType   );
	logDebug1("Reply CodeReceived : %d", pUserLogOffResp->iRepCode   );
	logDebug1("Current Session    : %d", pUserLogOffResp->iFiller    );
	logDebug1("Reply Message      : %s", pUserLogOffResp->sRepMsg    );
	logDebug1("*****************************************************");

	/************* added by appa in anagram ******************/
	memset(tempErrMsg ,' ',ERROR_MSG_LEN);
	memcpy(tempErrMsg ,pUserLogOffResp->sRepMsg,ERROR_MSG_LEN);


	if(pUserLogOffResp->iRepCode == 0 ||pUserLogOffResp->iRepCode == USER_HAS_LOGGED_OFF ||pUserLogOffResp->iRepCode == LOGOFF_SUCCESS )
	{
		sprintf(sSelQry,"SELECT \
				EAM_EXCH_USER_ID\
				FROM    EXCH_ADMINISTRATION_MASTER\
				WHERE  EAM_GROUP_ID =   %d\
				AND EAM_EXM_EXCH_ID = 'BSE'\
				AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);	

			logDebug2("sSelQry :%s:",sSelQry);

		if ( mysql_query(DB_BseCon,sSelQry) != SUCCESS)
		{
			sql_Error(DB_BseCon);
			return FALSE;
		}



		free(pUserLogOffResp);
		return TRUE;
	}
	else if (pUserLogOffResp->iRepCode == SYS_DONOT_RECOGNIZE)
	{
		free(pUserLogOffResp);
		BSEconnectLogFatal("System Does Not Recongnise You");
		return FALSE;
	}
	else
	{
		free(pUserLogOffResp);
		BSEconnectLogFatal("Fatal Error Try Again ");
		return FALSE;
	}
}

LONG32     UpdateExchStatus ( LONG32 GroupId ,LONG32 status )
{
	logTimestamp("Entry :UpdateExchStatus:");	
	LONG32 RetVal ;
	CHAR    ExchStatus;

	CHAR    sUpdQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
//	CHAR	*sUpdQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	if( status == 1 )
		ExchStatus = 'R' ;
	else
		ExchStatus = 'N' ;

	logDebug1("Updating the status for Group id %d to :%c",GroupId,ExchStatus);


	sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER \
			SET\
			EAM_LOGON_STATUS = \'%c\' \
			WHERE EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_SEGMENT = 'C'\
			AND EAM_GROUP_ID = %d\
			AND EAM_DRV_FLAG = 'N' ;",ExchStatus,iGlobUserGroupId);

	logDebug2("sUpdQry :%s:",sUpdQry);	

	if( mysql_query(DB_BseCon,sUpdQry) != SUCCESS )
	{
		logDebug1(" Updation failed ");
		sql_Error(DB_BseCon);
		mysql_rollback(DB_BseCon);
		return FALSE;
	}

	mysql_commit(DB_BseCon);

	logDebug1("ExchStatus	:%c:",ExchStatus);

	if( ExchStatus == 'R')
	{
		RetVal= fUpdateConnectStatus(BSE_CUR_UP,GroupId  );
	}
	else
	{
		RetVal= fUpdateConnectStatus(BSE_CUR_DOWN,GroupId);
	}
	if(RetVal==TRUE)
	{
		return TRUE ;
	}		
	else
	{
		return FALSE;
	}

}


LONG32	HandleRegistration (LONG32 sockfd )
{
	logTimestamp("Entry :HandleRegistration:");	
	LONG32 	RetVal,SentBytes,RecvBytes;
	LONG32	ErrorCount = 0;
	LONG32	PacketSize;

	CHAR	*UserRegReq,*UserRegResp;
	LONG32	UserId;

	UserRegReq   = (CHAR *)malloc(sizeof(struct FIX_BSE_SESSION_LOGON_REQ)) ;
	UserRegResp  = (CHAR *)malloc(sizeof(struct  FIX_SESSION_LOGON_RESP));

	UserId = iGlobUserGroupId ;
	logDebug1("In HandleRegistration ...");
	if( ( RetVal = PrepareRegistrationPacket ( UserRegReq ,UserId )) == TRUE  )
	{
		/*****************
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iMsgLen);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iSlotNo);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->iMsgType);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->iSlotNo);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->MmbrId);
		  BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->TraderId);

		 *******************/

		//	BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iMsgLen);

		//PacketSize = ((struct FIX_BSE_SESSION_LOGON_REQ *)UserRegReq)->iMsgLen + sizeof(struct OMB_HEADER);
		PacketSize = sizeof(struct FIX_BSE_SESSION_LOGON_REQ );

		//	BSETWIDDLE(((struct OMB_USER_REGISTRATION_REQ_PCOL*)UserRegReq)->pHeader.iMsgLen);
		SentBytes = SendPacket(sockfd,UserRegReq,PacketSize);
		if( SentBytes < 0)
		{
			free( UserRegResp );
			free( UserRegReq );
			return FALSE ;
		}
	}
	else
	{
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}

	RecvBytes = RecvPacket (sockfd, UserRegResp );	
	if ( RecvBytes < 0 )
	{
		logDebug1("Error in RecvPacket...");
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}
	if ( RecvBytes == 0)
	{
		logDebug1("Connection close requested..");
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}

	if ( ReceiveRegistrationResp ( UserRegResp ) == TRUE)
	{
		free( UserRegResp );
		free( UserRegReq );
		return( TRUE );
	}
	else
	{
		free( UserRegResp );
		free( UserRegReq );
		return( FALSE );
	}
}


LONG32 	PrepareRegistrationPacket (CHAR *UserRegReq ,LONG32 UserId )
{
	logTimestamp("Entry :PrepareRegistrationPacket:");	
	LONG32 RetVal;
	struct FIX_BSE_SESSION_LOGON_REQ *pUserRegReq ; 

	CHAR    sSelectQ[MAX_QUERY_SIZE];
	memset(sSelectQ,'\0',MAX_QUERY_SIZE);
//	CHAR	*sSelectQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	pUserRegReq = (struct FIX_BSE_SESSION_LOGON_REQ *)malloc(sizeof(struct FIX_BSE_SESSION_LOGON_REQ));  

	memset(UserRegReq,' ',REGISTRATION_LEN ) ;
	memset(pUserRegReq,' ',sizeof(struct FIX_BSE_SESSION_LOGON_REQ ));

	//pUserRegReq->pHeader.iSlotNo = PROTOCOL_SLOT ;
	//pUserRegReq->pHeader.iMsgLen = sizeof(struct FIX_BSE_SESSION_LOGON_REQ) - sizeof(struct OMB_HEADER);
	logDebug1("In PrepareRegistrationPacket");
	logDebug1("The Group Id recvd is %d",UserId);

	sprintf(sSelectQ,"SELECT \
			EAM_EXCH_USER_ID,EAM_WORKSTATION_ADDRESS ,\
			EAM_BROKER_ID,aes_decrypt(EAM_OLD_PASSWORD,'rupee123'),EAM_EXCH_SEQUENCE_NO \
			FROM    EXCH_ADMINISTRATION_MASTER \
			WHERE   EAM_EXM_EXCH_ID = 'BSE' AND\
			EAM_GROUP_ID = %d AND\
			EAM_SEGMENT = 'C'\
			AND EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

	logDebug2("sSelectQ :%s:",sSelectQ);

	if ( mysql_query(DB_BseCon,sSelectQ) != SUCCESS)
	{
		free(sSelectQ);
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		pUserRegReq->pHeader.iMsgLength = sizeof(struct FIX_BSE_SESSION_LOGON_REQ);
		pUserRegReq->pHeader.iMsgCode = 10000;
		strcpy(pUserRegReq->pHeader.sNetworkMsgID,"");
	        strcpy(pUserRegReq->pHeader.sPad2,"");
		iTempSendSeqNum++;
		pUserRegReq->iMsgSeqNum = iTempSendSeqNum;
		pUserRegReq->iSenderSubId = 0;
		pUserRegReq->iHeartBeats = 10000;
		pUserRegReq->iPartySessionId= atol(Row[1]);
		//strcpy(pUserRegReq->sDefCustAppVerId,"2.2");
		strcpy(pUserRegReq->sDefCustAppVerId,Row[4]);
		strcpy(pUserRegReq->sBsePassword,Row[3]);
		pUserRegReq->cAppUsageOrd='B';
		pUserRegReq->cAppUageQuotes= 'B';
		pUserRegReq->cOrderRoutiIndicator= 'Y';
		strcpy(pUserRegReq->sFixEngineName,"");
		strcpy(pUserRegReq->sFixEngineVersion,"");
		strcpy(pUserRegReq->sFixEngineVendor,"");
		strcpy(pUserRegReq->sFixAppSysName,"OMS");
		strcpy(pUserRegReq->sFixAppSysVersion,"1.1");
		strcpy(pUserRegReq->sFixAppSysVendor,"RUPEESEED");
		strcpy(pUserRegReq->sPag3,"");

	}
	else
	{
		logInfo("No Row Fetch for Registration");
		return FALSE;
	}			
	
	logDebug2("pUserRegReq->pHeader.iMsgLength  :%d:",pUserRegReq->pHeader.iMsgLength );	
	logDebug2("pUserRegReq->pHeader.iMsgCode	:%d:",pUserRegReq->pHeader.iMsgCode);	
	logDebug2("pUserRegReq->pHeader.sNetworkMsgID	:%s:",pUserRegReq->pHeader.sNetworkMsgID);	
	logDebug2("pUserRegReq->pHeader.sPad2	:%s:",pUserRegReq->pHeader.sPad2);

	logDebug2("pUserRegReq->iMsgSeqNum :%d:",pUserRegReq->iMsgSeqNum);	
	logDebug2("pUserRegReq->iSenderSubId	:%d:",pUserRegReq->iSenderSubId);	
	logDebug2("pUserRegReq->iHeartBeats	:%d:",pUserRegReq->iHeartBeats);	
	logDebug2("pUserRegReq->iPartySessionId	:%d:",pUserRegReq->iPartySessionId);	
	logDebug2("pUserRegReq->sDefCustAppVerId	:%s:",pUserRegReq->sDefCustAppVerId);	
	logDebug2("pUserRegReq->sBsePassword	:%s:",pUserRegReq->sBsePassword);	
	logDebug2("pUserRegReq->cAppUsageOrd	:%c:",pUserRegReq->cAppUsageOrd);	
	logDebug2("pUserRegReq->cAppUageQuotes	:%c:",pUserRegReq->cAppUageQuotes);	
	logDebug2("pUserRegReq->sFixEngineName	:%s:",pUserRegReq->sFixEngineName);	
	logDebug2("pUserRegReq->sFixEngineVersion	:%s:",pUserRegReq->sFixEngineVersion);	
	logDebug2("pUserRegReq->sFixEngineVendor	:%s:",pUserRegReq->sFixEngineVendor);	
	logDebug2("pUserRegReq->sFixAppSysName	:%s:",pUserRegReq->sFixAppSysName);	
	logDebug2("pUserRegReq->sFixAppSysVersion	:%s:",pUserRegReq->sFixAppSysVersion);	
	logDebug2("pUserRegReq->sFixAppSysVendor	:%s:",pUserRegReq->sFixAppSysVendor);	
	logDebug2("pUserRegReq->sPag3	:%s:",pUserRegReq->sPag3);	
	logDebug2("pUserRegReq->cOrderRoutiIndicator	:%c:",pUserRegReq->cOrderRoutiIndicator);	



	logTimestamp(":%s: REGISTRATION REQUEST SENT TO EXCHANGE",KEY_WORD_MONITORING);
	/***************Added in anagram *******************/
	memcpy( UserRegReq, pUserRegReq, sizeof(struct FIX_BSE_SESSION_LOGON_REQ));
	free(pUserRegReq);
	return TRUE;
}


LONG32 	ReceiveRegistrationResp (CHAR *UserRegResp )
{
	logTimestamp("Entry :ReceiveRegistrationResp:");
	logDebug3("MsgCode :%d:",((INT_BSE_HEADER_OUT *)UserRegResp)->iMsgCode);
	DOUBLE64 fTempTimer = 0.00;
	if(((INT_BSE_HEADER_OUT *)UserRegResp)->iMsgCode == 10001)
	{
		struct FIX_SESSION_LOGON_RESP * pUserRegResp ;


		pUserRegResp = (struct FIX_SESSION_LOGON_RESP * )malloc \
		       (sizeof(struct FIX_SESSION_LOGON_RESP));

		logDebug1("In ReceiveRegistrationResp");

		memcpy( pUserRegResp, UserRegResp, sizeof(struct FIX_SESSION_LOGON_RESP));
		logDebug1(" pUserRegResp->pHeader.iMsgLength	= %d", pUserRegResp->pHeader.iMsgLength);
		logDebug1(" pUserRegResp->pHeader.iMsgCode	= %d", pUserRegResp->pHeader.iMsgCode);
		logDebug1(" pUserRegResp->pHeader.sPad2	= :%s:", pUserRegResp->pHeader.sPad2);
		logDebug1(" pUserRegResp->iRequestTime	= %ld", pUserRegResp->iRequestTime);
		logDebug1(" pUserRegResp->iSendTime	= %ld", pUserRegResp->iSendTime);
		logDebug1(" pUserRegResp->ThrottleTimeInterval	= %ld", pUserRegResp->iThrottleTimeInterval);
		logDebug1(" pUserRegResp->iMsgSeqNum	= %d", pUserRegResp->iMsgSeqNum);
		logDebug1(" pUserRegResp->iLastLoginTime	= %ld", pUserRegResp->iLastLoginTime);
		logDebug1(" pUserRegResp->iLastLoginIp	= %d", pUserRegResp->iLastLoginIp);
		logDebug1(" pUserRegResp->iThrottleNumMsg	= %d", pUserRegResp->iThrottleNumMsg);
		logDebug1(" pUserRegResp->iThrottleDisconnLimit	= %d", pUserRegResp->iThrottleDisconnLimit);
		logDebug1(" pUserRegResp->iHeartBeats	= %d", pUserRegResp->iHeartBeats);
		logDebug1(" pUserRegResp->iSessionInstanceId	= %d", pUserRegResp->iSessionInstanceId);
		logDebug1(" pUserRegResp->cTradeSessMode	= :%d:", pUserRegResp->cTradeSessMode);
		logDebug1(" pUserRegResp->cNumOfPartition	= :%d:", pUserRegResp->cNumOfPartition);
		logDebug1(" pUserRegResp->cDayLeftPassExpiry	= :%d:", pUserRegResp->cDayLeftPassExpiry);
		logDebug1(" pUserRegResp->cGraceLoginLeft	= :%d:", pUserRegResp->cGraceLoginLeft);
		logDebug1(" pUserRegResp->sDefCustAppVerId	= :%s:", pUserRegResp->sDefCustAppVerId);
		logDebug1(" pUserRegResp->sPad2			= :%s:", pUserRegResp->sPad2);
		
		if(pUserRegResp->iThrottleTimeInterval != 0 && pUserRegResp->iThrottleNumMsg != 0)
		{
			fTempTimer = (DOUBLE64)((pUserRegResp->iThrottleTimeInterval * 1000)/(pUserRegResp->iThrottleNumMsg - 1));	
			iSleepBusyTimer = ceil(fTempTimer);	
			logDebug2("iSleepBusyTimer :%d:",iSleepBusyTimer);
		}

		fInsertExchDigital(pUserRegResp->cNumOfPartition);
	
	}
	else if(((INT_BSE_HEADER_OUT *)UserRegResp)->iMsgCode == 10010)
	{
		struct FIX_BSE_SESSION_REJECT_RESP * pUsrLogRejResp ;


                pUsrLogRejResp= (struct FIX_BSE_SESSION_REJECT_RESP * )malloc \
                       (sizeof(struct FIX_BSE_SESSION_REJECT_RESP ));

                logDebug1("In ReceiveRegistrationResp");

                memcpy( pUsrLogRejResp, UserRegResp, sizeof(struct FIX_SESSION_LOGON_RESP));
                logDebug1(" pUsrLogRejResp->pHeader.iMsgLength    = %d", pUsrLogRejResp->pHeader.iMsgLength);
                logDebug1(" pUsrLogRejResp->pHeader.iMsgCode      = %d", pUsrLogRejResp->pHeader.iMsgCode);
                logDebug1(" pUsrLogRejResp->pHeader.sPad2 = :%s:", pUsrLogRejResp->pHeader.sPad2);
		logDebug1(" pUsrLogRejResp->iRequestTime	= %ld", pUsrLogRejResp->iRequestTime);
		logDebug1(" pUsrLogRejResp->iRequestOut	= %ld", pUsrLogRejResp->iRequestOut);
		logDebug1(" pUsrLogRejResp->iTradeRegTSTimeIn	= %ld", pUsrLogRejResp->iTradeRegTSTimeIn);
		logDebug1(" pUsrLogRejResp->iTradeRegTSTimeOut	= %ld", pUsrLogRejResp->iTradeRegTSTimeOut);
		logDebug1(" pUsrLogRejResp->iResponseIn	= %ld", pUsrLogRejResp->iResponseIn	);
		logDebug1(" pUsrLogRejResp->iSendingTime	= %ld", pUsrLogRejResp->iSendingTime);
		logDebug1(" pUsrLogRejResp->iMsgSeqNum	= %d", pUsrLogRejResp->iMsgSeqNum);
		logDebug1(" pUsrLogRejResp->cLastFragment	= %d", pUsrLogRejResp->cLastFragment);
		logDebug1(" pUsrLogRejResp->sPad3		= %s", pUsrLogRejResp->sPad3);
		logDebug1(" pUsrLogRejResp->iRejectionReasonCode	= %d", pUsrLogRejResp->iRejectionReasonCode);
		logDebug1(" pUsrLogRejResp->iRejMsgLen	= %d", pUsrLogRejResp->iRejMsgLen);
		logDebug1(" pUsrLogRejResp->cSessionStatus	= %d", pUsrLogRejResp->cSessionStatus);
		logDebug1(" pUsrLogRejResp->sRejectionMsg	= :%s:", pUsrLogRejResp->sRejectionMsg);
		free(pUsrLogRejResp);
		return FALSE;	
	}

	logTimestamp("Exit :ReceiveRegistrationResp:");

	return TRUE ;
}

void  	KeepAliveChild ( )
{
	logTimestamp("Entry :KeepAliveChild:");	
	LONG32 i,Counter;
	LONG32 RetVal,RecvBytes;
	LONG32 processid;
	LONG32 iSlotNo,iMsgLen ;
	LONG32	iMsgType ;
	CHAR *  packet ;
	LONG32	packetsize;
	INT_BSE_HEADER *pKeepAlive;
	signal(SIGPIPE,SIG_IGN);

	logDebug1("Inside KeepAliveChild..."); 


	packet = (INT_BSE_HEADER *)malloc(sizeof(INT_BSE_HEADER));
	pKeepAlive = (CHAR *)malloc(sizeof(INT_BSE_HEADER));

	for( ; ; )
	{
		/**for( Counter=0;Counter < 8;Counter ++)***/

		memset( packet,' ',sizeof(INT_BSE_HEADER));
		memset( pKeepAlive,' ',sizeof(INT_BSE_HEADER));

		pKeepAlive->iMsgLength = sizeof(INT_BSE_HEADER)  ;
		pKeepAlive->iMsgCode = 10011 ;
		strcpy(pKeepAlive->sNetworkMsgID,"");
		strcpy(pKeepAlive->sPad2,"");

		logDebug3("pKeepAlive->iMsgLength :%d:",pKeepAlive->iMsgLength);
		logDebug3("pKeepAlive->iMsgCode	:%d:",pKeepAlive->iMsgCode);
		logDebug3("pKeepAlive->sNetworkMsgID :%s:",pKeepAlive->sNetworkMsgID);
		logDebug3("pKeepAlive->sPad2 :%s:",pKeepAlive->sPad2);

		/***************** added in anagram *********************/
		packetsize = sizeof(INT_BSE_HEADER) ;
		memcpy(packet,(CHAR *)pKeepAlive , sizeof(INT_BSE_HEADER_OUT) );

		logDebug1("Before Sending KeepAlive Packet..");
		RetVal = SendPacket ( iSockfd,packet,packetsize);
		logDebug1("Packet Sent For KeepAlive....");

		if( RetVal < 0)
		{
			free( packet );
			exit(1);
		}
		if( RetVal = 0)
		{
			logDebug1("Exiting from KeepAlive..");
			free( packet );
			exit(1);
		}

	
		sleep(10);	
	}
	free( packet );
}

LONG32	OpenPassiveSocket( )
{
	logTimestamp("Entry :OpenPassiveSocket:");	
	LONG32 	sock = 0 ;
	struct	sockaddr_in ServAddr;
	LONG32	ErrorCount = 0;
	LONG32	RetVal = -1;
	LONG32	MaxTry = 0;
	CHAR	sErrorStr[SIZE];
	CHAR	sExchIPAdd[20];
	LONG32	iExchPort = 0 ;
	BOOL	iPrimSecFlag = 0;

	logDebug1("Inside OpenPassiveSocket..");



	do
	{
		if(iPrimSecFlag == 1)
		{
			logInfo("Try Connecting to Secondary IP and Port ");
			strcpy(sExchIPAdd,sSecIPAddress);
			iExchPort = iSecPort;
		}
		else
		{
			logInfo("Try Connecting to Primary IP and Port ");
			strcpy(sExchIPAdd,sPrimIPAddress);
			iExchPort = iPrimPort;
		}

		if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
		{
			perror("Trying to open Socket Failed :");
			BSEconnectLogFatal("Trying to open Socket Failed");
			sleep(1);
			ErrorCount ++;
			continue ;
		}

		if( sock > 0 )
		{	


			do
			{
				if(iPrimSecFlag == 1)
                		{
                		        logInfo("Try Connecting to Secondary IP and Port ");
					logTimestamp(":%s: TRYING TO CONNNECT EXCHANGE SECONDARY IP :%s: PORT :%d:",KEY_WORD_MONITORING,sExchIPAdd,iExchPort);
                		        strcpy(sExchIPAdd,sSecIPAddress);
                		        iExchPort = iSecPort;
                		}
                		else
               	 		{
                        		logInfo("Try Connecting to Primary IP and Port ");
					logTimestamp(":%s: TRYING TO CONNNECT EXCHANGE PRIMARY IP :%s: PORT :%d:",KEY_WORD_MONITORING,sExchIPAdd,iExchPort);
                        		strcpy(sExchIPAdd,sPrimIPAddress);
                        		iExchPort = iPrimPort;
                		}
				logDebug1("The IML address is %s ", sExchIPAdd);
				logDebug1("The IML port is %d ", iExchPort);
				memset( ( CHAR * ) &ServAddr, 0, sizeof ( ServAddr ) );
				ServAddr.sin_family = AF_INET ;
				ServAddr.sin_addr.s_addr = inet_addr(sExchIPAdd);	
				ServAddr.sin_port = htons(iExchPort); 
				memset(sErrorStr,'\0',SIZE);

				RetVal = connect(sock,(struct sockaddr *) &ServAddr,sizeof(struct sockaddr));	
				logDebug1("The Return value is %d",RetVal );
				perror("Error Connecting IML ");
				strcpy(sErrorStr,strerror(errno));

				if ( RetVal == ERROR)
				{
					sleep(2);
					logInfo(" IML IS NOT GETTING CONNECTED IML IP :%s: IML PORT :%d:",sExchIPAdd,iExchPort);
					logTimestamp(":%s: GETTING DISCONNECTED FOR EXCHANGE IP :%s: PORT :%d: REASON :%s:",KEY_WORD_MONITORING,sExchIPAdd,iExchPort,sErrorStr);
					perror("Connect Failed :");
					close(sock);
					sleep(5);

					if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
					{
						perror("Trying to open Socket Failed :");
						sleep(1);
						ErrorCount ++;
						break;
					}
					iPrimSecFlag=(iPrimSecFlag==1)?0:1;
				}

			}while(RetVal < 0 );
			logTimestamp(":%s: CONNNECTION SUCCESSFULL TO  IML APP IP :%s: PORT :%d:",KEY_WORD_MONITORING,sExchIPAdd,iExchPort);
		}
		else
		{
			perror("Failed to  Connect reason : ");
			iPrimSecFlag=(iPrimSecFlag==1)?0:1;
			
		}
	}while( sock < 0);
	return sock;
}


void    Sleep(LONG32  TimetoSleep )
{
	logTimestamp("Entry :Sleep:");	
	poll((struct pollfd **) NULL, 0,TimetoSleep  );
}

/***********
System  :EIBS
Module  :NETWORK
Prog    :
Date    :Mon Jan 10 11:07:40 GMT 2001
Author  :Diptaneal Roy
Argument:
Dependencies:
ProgType:
Comments:
 **********/

void SignalHandlerSigTermMain (LONG32 dummy)
{
	logTimestamp("Entry :SignalHandlerSigTermMain:");	
	LONG32 i,RetVal;
	LONG32 UserId;
	CHAR Message[100];
	LONG32 Check= FALSE;
	LONG32 Status;
	sigset_t    MainSignalSet   ;

	logDebug1(" In SignalHandlerSigTermParent ");

	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	logDebug1("Closed The Socket Connection...");
	RetVal = UpdateExchStatus( iGlobUserGroupId,0 );

	if ( RetVal == TRUE )
		mysql_commit(DB_BseCon);
	close ( iSockfd );
	sleep(5);

	sprintf(Message,"Connection Closed To Bombay Stock Exchange");
	do{
		SendPacketBackToUser( Message );
		Check = CheckQueueForPendingPackets( );
	}while( Check == TRUE );

	for( i=0 ; i<MAX_NO_PROCESSES ;i++)
	{
		logDebug1("Killing the process with Id %d",ForkProcess [i].ProcessId);
		if (ForkProcess [i].ProcessId != UNUSED )
		{
			kill(ForkProcess [i] .ProcessId,SIGKILL);
		}
	}
	sleep(2);

	for( i=0 ; i<MAX_NO_PROCESSES ;i++)
	{
		waitpid(ForkProcess [i].ProcessId ,&Status,WNOHANG);
	}
	for( i=0 ; i<MAX_NO_PROCESSES ;i++)
	{
		ForkProcess [i].ProcessId = UNUSED ;	
	}

	BSEconnectLogFatal("SignalHandlerSigTermMain");
	exit (1);
}


void	InitForkProcess ( )
{
	logTimestamp("Entry :InitForkProcess:");	
	LONG32	Index;
	logDebug1("Inside InitForkProcess...");
	for( Index =0; Index < MAX_NO_PROCESSES ;Index ++)
	{
		ForkProcess[Index].ProcessId = UNUSED;
		ForkProcess[Index].ProcessStatus = UNUSED;
	}
	return;
}


void	UpdateForkProcess ( LONG32 Index, LONG32 ProcessId, LONG32 Status)
{
	logTimestamp("Entry :UpdateForkProcess:");	
	ForkProcess[Index].ProcessId = ProcessId ;
	ForkProcess[Index].ProcessStatus = Status ;
	return ;
}


void	SignalHandlerSigChldMain ( )
{
	logTimestamp("Entry :SignalHandlerSigChldMain:");	
	LONG32 Check = FALSE ;
	LONG32 RetVal = FALSE;
	LONG32 Index ;
	CHAR Message[100];
	LONG32 Status;

	logDebug1("Entered SignalHandlerSigChldMain...");
	RetVal = UpdateExchStatus( iGlobUserGroupId, 0 );

	if (RetVal == TRUE )
		mysql_commit(DB_BseCon);	
	close( iSockfd );
	sleep(10);

	sprintf(Message,"Connection Closed To Bombay Stock Exchange");

	do{
		/*		SendPacketBackToUser( Message );*/
		Check = CheckQueueForPendingPackets( );
	}while( Check == TRUE );

	for ( Index = 0;Index < MAX_NO_PROCESSES;Index ++)
	{
		if( ForkProcess[Index].ProcessStatus != UNUSED )
		{
			logDebug1("Main Process Killed Child Pid :%d",ForkProcess[Index].ProcessId);
			kill( ForkProcess[Index].ProcessId, SIGKILL);
			sleep(5);
		}
	}

	system("date >>log32");

	for( Index=0 ; Index<MAX_NO_PROCESSES ;Index++)
	{
		waitpid(ForkProcess [Index].ProcessId ,&Status,WNOHANG);
	}
	for( Index=0 ; Index<MAX_NO_PROCESSES ;Index++)
	{
		ForkProcess [Index].ProcessId = UNUSED ;	
	}
	/****** Added to initialize the shared memory after the process gets killed *****/
	InitSharedMemory();
	return ;
}


LONG32	CheckQueueForPendingPackets ( )
{
	logTimestamp("Entry :CheckQueueForPendingPackets:");	
	LONG32 Retval = FALSE ;
	struct msqid_ds *  buffer ;
	LONG32  Bytes;
	LONG32 i=0;
	buffer = (struct msqid_ds *)malloc(sizeof(struct msqid_ds));
	for( i =0 ;i < 2;i++)
	{
		//if( (Retval = msgctl(ReadQueue ,IPC_STAT,buffer) < 0))
		if( (Retval = msgctl(ReadQueue ,IPC_STAT,buffer)) < 0)
		{
			perror("Error in Reading CheckQueueForPendingPackets");
			free(buffer);
			return FALSE ;
		}
		Bytes = buffer->msg_cbytes ;
		if ( Bytes == 0 )
		{
			Sleep(50);
			continue ;
		}
		else
		{
			free(buffer);
			return TRUE ;
		}
	}
	free(buffer);
	return FALSE ;
}


void	SendPacketBackToUser ( CHAR* Message )
{
	logTimestamp("Entry :SendPacketBackToUser:");	
	CHAR* 	tempBuff;
	CHAR *	Packet ;
	LONG32	SeqNo;
	LONG32	iMsgLength ,iSlotNo;
	LONG32	PacketSize ,Transcode ;
	LONG32	RateDiff,ReplyCode;
	LONG32	ReadBytes;
	CHAR	TransId[ SIZE_OF_TRANS_ID ];
	CHAR	DateTime[ DATETIME_LEN ];
	CHAR	RepText [MESSAGE_LEN ] ;

	logDebug1("Inside SendPacketBackToUser...");

	tempBuff    = ( CHAR *)malloc( BSE_PACKET_SIZE );
	Packet      = (CHAR * )malloc( REJECTED_PACK_SIZE );

	if( (ReadBytes =ReadNBQ( ReadQueue, tempBuff ,BSE_PACKET_SIZE,0) )== ERROR)
	{
		free( Packet );
		free( tempBuff );
		return;
	}
	if ( ReadBytes == 0 )
	{
		free( Packet );
		free( tempBuff );
		return;
	}
	SeqNo 		= ((struct OMB_HEADER *)tempBuff)->iSlotNo ;
	iMsgLength 	= ((struct OMB_HEADER *)tempBuff)->iMsgLen ;


	PacketSize = iMsgLength + OMB_HEADER_LEN ;

	iSlotNo = 0;
	memcpy(Packet,&iSlotNo,sizeof(LONG32));
	memcpy(Packet + sizeof(LONG32),&iMsgLength,sizeof(LONG32));
	tempBuff = tempBuff + sizeof( struct OMB_HEADER ) ;

	sscanf( tempBuff ,"%d",&Transcode);

	memcpy( TransId,"0" ,SIZE_OF_TRANS_ID);
	memcpy( DateTime,"0",DATETIME_LEN);

	ReplyCode = 255 ;
	RateDiff  = 0 ;
	memset(RepText,' ',MESSAGE_LEN );
	memcpy(RepText ,Message,MESSAGE_LEN );

	sprintf(Packet + sizeof(struct OMB_HEADER) ,"%-10d|%-10d|%-5d|%-5d|%-19.19s|%-19.19s|%-40.40s|",
			Transcode,
			SeqNo,
			ReplyCode,
			RateDiff,
			TransId,
			DateTime,
			RepText);

	WriteToBseRms( Packet,PacketSize );
	free( tempBuff );
}


void    WriteToBseRms ( CHAR * Packet ,LONG32 Size )
{
	logTimestamp("Entry :WriteToBseRms:");	
	if(WriteMsgQ( WriteQueue , Packet ,Size ,1 )==FALSE)
	{
		logDebug1(" Error in writting to MsgRms");
	}
}

void    WriteToDloadQ ( CHAR * Packet ,LONG32 Size )
{
	logTimestamp("Entry :WriteToDloadQ:");	
	if(WriteMsgQ( DloadQueue , Packet ,Size ,1 )==FALSE)
	{
		logDebug1(" Error in writting to DloadQ");
	}
}

void	PrintStatus ( LONG32 Type )
{
	logTimestamp("Entry :PrintStatus:");	
	switch (Type)
	{
		case 1:
			logDebug1("LOGGED ON SUCCESSFULLY DOWNLOAD STARTS HERE....");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST TRADES DOWNLOAD		       ");
			break;
		case 2:
			logDebug1("		TRADES DOWNLOAD COMPLETE		       ");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR ORDERS DOWNLOAD	       ");
			break;
		case 3:
			logDebug1("		ORDERS DOWNLOAD COMPLETED		       ");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR RETURNED ORDERS DOWNLOAD   ");
			break;
		case 4:
			logDebug1("		RETURNED ORDERS DOWNLOAD COMPLETED	       ");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR STOPLOSS DOWNLOAD ");
			break;
		case 5:
			logDebug1("		PERSONAL STOP LOSS DOWNLOAD COMPLETED");
			logDebug1("*************************************************************");
			logDebug1("		SENDING REQUEST FOR RETURNED STOPLOSS DOWNLOAD ");
			break;
		case 6:
			logDebug1("		RETURNED STOP LOSS DOWNLOAD COMPLETED	       ");
			logDebug1("*************************************************************");
			break;
		case 7:
			logDebug1("-------------------------------------------------------------");
			logDebug1("		DOWNLOAD COMPLETED NORMAL PROCESS STARTS       ");
			logDebug1("-------------------------------------------------------------");
			break;
		default :
			return;

	}
}


void SlotInit( key_t  ShmKey )
{
	logTimestamp("Entry :SlotInit:");	
	LONG32 Index,Count ;
	struct Slot *Ptr;
	struct IML_INFO_SHM	*pImlQryShm;
	logDebug1("Inside SlotInit...");

	LockShm ( ShmKey );

	//pImlQryShm = ( struct IML_INFO_SHM *) OpenSharedMemory( ShmKey ,Bse_Conn_Shm_SIZE );

	//if ( *( (LONG32 *) pImlQryShm ) == ERROR )

	if((pImlQryShm = ( struct IML_INFO_SHM *) OpenSharedMemory( ShmKey ,Bse_Conn_Shm_SIZE )) == ( struct IML_INFO_SHM *) ERROR)
	{
		logDebug1 ("Error in Opening Shared memory");
		perror("SHM ::");
		UnLockShm( ShmKey );
		exit(1);
	}


	for ( Count =0; Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== UNUSED ; Count ++)
	{	
		logDebug1(" SlotInit Count :%d UserId :%d",Count,iGlobUserGroupId);
		pImlQryShm -> pImlInfo[Count].iImlUserId= iGlobUserGroupId ;	
		for ( Index =0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++)
		{
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus = UNUSED_SLOT;
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = UNUSED_SLOT ; 
		}
		break;
	}	

	if ( CloseSharedMemory((void * )pImlQryShm ) == ERROR )
	{
		logDebug1 ("Error in Closing Shm ");
		UnLockShm( ShmKey );
		exit(1);
	}

	UnLockShm( ShmKey );
	logDebug1("Inside SlotInit...");
}

LONG32 GetFreeSlot( key_t  ShmKey )
{
	logTimestamp("Entry :GetFreeSlot:");	
	LONG32  Index,Count ;
	struct Slot *Ptr ;
	struct IML_INFO_SHM	*pImlQryShm;

	logDebug1("Inside GetFreeSlot...");

	LockShm ( ShmKey ) ;

	logDebug1("Before OpenSharedMemoryory...");
	//	pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_Conn_Shm_SIZE);
	logDebug1("After OpenSharedMemoryory..");

	//if ( *( (LONG32 *) pImlQryShm ) == ERROR )
	if((pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_Conn_Shm_SIZE)) == (struct IML_INFO_SHM     *) ERROR )
	{
		logDebug1 (" Error in Opening Shared memory");
		perror("SHM.. :");
		UnLockShm( ShmKey );
		exit(0);
	}
	logDebug1("\nAfter PoLONG32er assignment...");

	for ( Count = 0; Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== iGlobUserGroupId ; Count ++)
	{
		for ( Index = 0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY); Index ++)
		{
			if ( pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus == UNUSED_SLOT )
			{
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus = USED_SLOT ;
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = Index + 1 ;
				break;
			}
		}
	}
	logDebug1("Before CloseSharedMemory...");
	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm");
		UnLockShm( ShmKey );
		exit(0);
	}
	logDebug1("After CloseSharedMemory...");

	UnLockShm( ShmKey );
	Index = Index + 1;
	logDebug1("Before returning....");
	return Index ;
}



LONG32  IsFreeSlot( key_t  ShmKey )
{
	logTimestamp("Entry :IsFreeSlot:");	
	LONG32    Index,Count ;
	struct Slot *tPtr;
	struct IML_INFO_SHM	*pImlQryShm;
	LONG32    RetVal = FALSE ;

	logDebug1("IsFreeSlot..");

	LockShm ( ShmKey );


	logDebug1(" OpenSharedMemory for IsFreeSlot  ################## 1");
	//	pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_Conn_Shm_SIZE);
	logDebug1(" OpenSharedMemory for IsFreeSlot  ################## 2");

	//if (*( (LONG32 *) pImlQryShm ) == (LONG32 *)ERROR )
	if((pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_Conn_Shm_SIZE)) == (struct IML_INFO_SHM     *) ERROR )
	{
		logDebug1 (" Error in Opening Shared memory");
		perror("SHM... : ");
		UnLockShm( ShmKey );
		exit(0);
	}

	logDebug1(" OpenSharedMemory for IsFreeSlot  ################## 3");
	for ( Count = 0;Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== iGlobUserGroupId ; Count ++)
	{
		for ( Index =0; Index  < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
			logDebug1("In IsFreeSlot Slot [%d] Status [%d]",Index+1,pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus);

		for ( Index =0; Index  < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
		{
			if ( pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus == UNUSED_SLOT )
			{
				RetVal = TRUE ;
				logDebug1(" Got FreeSlot  ################## %d",RetVal);
				break ;
			}
			logDebug1(" After check for error for IsFreeSlot 6 ################## %d",RetVal);
		}
	}
	logDebug1(" After for loop for IsFreeSlot 4 !!!!!!!!!!!!!!!!!!!%d",RetVal);

	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm ");
		UnLockShm( ShmKey );
		exit(0);
	}
	logDebug1(" After CloseSharedMemory IsFreeSlot  ################## 8");

	UnLockShm( ShmKey );
	logDebug1("################ RETURNING FROM ISFREESLOT%d  ", RetVal );
	return RetVal ;
}





void  SetSlotFree ( key_t  ShmKey ,LONG32 iSlotNo )
{
	logTimestamp("Entry :SetSlotFree:");	
	LONG32  Index,Count ;
	struct Slot *Ptr ;
	struct IML_INFO_SHM	*pImlQryShm;

	logDebug1("Inside SetSlotFree...");

	LockShm ( ShmKey );

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 1");
	pImlQryShm = (struct IML_INFO_SHM     *)OpenSharedMemory( ShmKey , Bse_Conn_Shm_SIZE);
	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 2");

	if ( *( (LONG32 *) pImlQryShm ) == (LONG32 *)ERROR )
	{
		logDebug2("SHM :");
		logDebug1 (" Error in Opening Shared memory");
		perror("SHM :");
		exit(0);
	}

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 3");
	for ( Count =0 ; Count < NO_QRY_IML && pImlQryShm -> pImlInfo[Count].iImlUserId== iGlobUserGroupId; Count ++)
	{
		for (Index = 0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
		{
			if( pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot == iSlotNo )
			{
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus = UNUSED_SLOT ;
				pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = UNUSED_SLOT ;
			}
		}
	}

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 4");
	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm ");
		exit(0);
	}

	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 5");
	UnLockShm( ShmKey );
	logDebug1(" OpenSharedMemory for SetSlotFree  ################## 6");
	return ;
}




LONG32	GetHour( CHAR *time)
{	
	CHAR  *pHour;
	LONG32   iHour;	
	memcpy(pHour,time,2);	
	iHour=atoi(pHour);	
	return(iHour);
}

LONG32	GetMinute( CHAR *time )
{
	CHAR *pMinute;
	LONG32  iMinute;

	memcpy(pMinute,time + 3,2);
	iMinute = atoi(pMinute);
	return( iMinute );
}

LONG32	GetSeconds ( CHAR *time )
{
	CHAR *pSeconds;
	LONG32  iSeconds;

	memcpy(pSeconds,time + 6,2);
	iSeconds = atoi(pSeconds);
	return( iSeconds );
}

BOOL HandleUpdPassword(LONG32 iSockfd)
{

	LONG32 RetVal;
	LONG32 SentBytes,RecvBytes;
	LONG32 PacketSize;
	LONG32 Flag=FALSE;
	LONG32 UserId;

	CHAR 	*UpdsPasswd;
	CHAR 	*UpdsPasswdResp;
	CHAR    sSelQyr[MAX_QUERY_SIZE];
	memset(sSelQyr,'\0',MAX_QUERY_SIZE);
//	CHAR	*sSelQyr = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	CHAR OldPassword[8];
	CHAR NewPassword[8];

	UpdsPasswd=(CHAR *)malloc(sizeof(struct OMB_UPDATE_PASSWORD_REQ));
	UpdsPasswdResp=(CHAR *)malloc(sizeof(struct OMB_UPDATE_PASSWORD_RESP));

	memset(OldPassword ,' ',8);
	memset(NewPassword ,' ',8);

	UserId = iGlobUserGroupId ;

	sprintf(sSelQyr,"SELECT \
			IFNULL(aes_decrypt(EAM_NEW_PASSWORD,'rupee123'),'NOCHANGE')\
			FROM EXCH_ADMINISTRATION_MASTER\
			WHERE EAM_EXM_EXCH_ID = 'BSE' AND\
			EAM_SEGMENT = 'C' AND\
			EAM_GROUP_ID = %d AND\
			EAM_DRV_FLAG = 'N' ",iGlobUserGroupId);

	logDebug2("SelQyr :%s:",sSelQyr);

	if(mysql_query(DB_BseCon,sSelQyr) != SUCCESS)
	{
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);	

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(NewPassword ,Row[0],8);
	}

	logDebug2("NewPassword :%s:",NewPassword);

	if (strncmp(NewPassword,"NOCHANGE",8)==0)
	{
		logDebug1(" Password Change not Required ");
		free (UpdsPasswd);
		free (UpdsPasswdResp);
		return TRUE;
	}
	else //if(sqlca.sqlcode==0)
	{
		logDebug1("GOING TO PREPARE PACKET SOCKET ID is %d",iSockfd);

		if( (RetVal = PrepareChangePwdReq (UpdsPasswd, UserId)) == TRUE )
		{

			PacketSize = sizeof(struct OMB_UPDATE_PASSWORD_REQ);
			SentBytes = SendPacket (iSockfd, UpdsPasswd, PacketSize) ;
			if( SentBytes < 0)
			{
				free (UpdsPasswd);
				free (UpdsPasswdResp);
				return FALSE;
			}
		}
		else
		{
			free (UpdsPasswd);
			free (UpdsPasswdResp);
			return FALSE;
		}

		do 
		{
			logDebug1(" Waiting to Receive A Response for Password Change ..");
			RecvBytes = RecvPacket (iSockfd, UpdsPasswdResp );
			logDebug1(" Received a packet from exchange ..");
			if( RecvBytes < 0 )
			{
				logDebug1(" Error in RecvPacket ");
				free(UpdsPasswd);
				free (UpdsPasswdResp);
				return FALSE;
			}
			if ( RecvBytes == 0 )
			{
				logDebug1(" Error in RecvPacket Recv Byte is zero");
				free(UpdsPasswd);
				free (UpdsPasswdResp);
				return FALSE;
			}

			if( ( Flag = ReceivesPasswdReply ( UpdsPasswdResp , UserId)) == TRUE )
			{
				logDebug1(" Reached here ..");
				free(UpdsPasswd);
				free(UpdsPasswdResp);
				return TRUE;
			}
			else if ( Flag == RETRY )
			{
				logDebug1(" Entered Retry eConart..");
				continue ;
			}        	
			else
			{
				free(UpdsPasswd);
				free(UpdsPasswdResp);
				return FALSE;
			}
		}while( Flag == RETRY );

	}
}

BOOL PrepareChangePwdReq(CHAR *UpdsPasswd , LONG32 UserId )
{
	CHAR    *PlainPassword  ;
	LONG32     iRetVal         ;
	LONG32 	iCntr			;

	struct OMB_UPDATE_PASSWORD_REQ *UpdsPasswdReq;
	CHAR OldPassword[40];
	CHAR EncyptOldPassword[75];
	CHAR EncyptNewPassword[75];
	CHAR NewPassword[40];
	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);
//	CHAR	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	UpdsPasswdReq=(struct OMB_UPDATE_PASSWORD_REQ *)malloc(sizeof(struct OMB_UPDATE_PASSWORD_REQ));

	logDebug1(" In Prepare Password Update Packet ");

	memset(EncyptOldPassword,'\0',75);
	memset(EncyptNewPassword ,'\0',75);
	memset(NewPassword ,'\0',40);
	memset(OldPassword ,'\0',40);
	memset(UpdsPasswd,' ',sizeof(struct OMB_UPDATE_PASSWORD_REQ));
	bzero(UpdsPasswdReq,sizeof(struct OMB_UPDATE_PASSWORD_REQ));

	PlainPassword=(CHAR*)malloc(PASSWORD_LEN +1);
	memset(PlainPassword, '\0', PASSWORD_LEN +1);

	memset(UpdsPasswdReq->sOldPasswd,'\0',BSE_PASSWORD_LEN );
	memset(UpdsPasswdReq->sNewPasswd,'\0',BSE_PASSWORD_LEN );

	sprintf(sSelQry,"SELECT\
			aes_decrypt(EAM_NEW_PASSWORD,'rupee123'),\
			aes_decrypt(EAM_OLD_PASSWORD,'rupee123')\
			FROM       EXCH_ADMINISTRATION_MASTER\
			WHERE      EAM_EXM_EXCH_ID = 'BSE'\
			AND	   EAM_SEGMENT = 'C'\	
			AND        EAM_GROUP_ID =%d \
			AND        EAM_DRV_FLAG = 'N';",iGlobUserGroupId);

	logDebug2("sSelQry :%s:",sSelQry);

	if (mysql_query(DB_BseCon,sSelQry)!=SUCCESS)
	{
		sql_Error(DB_BseCon);
		return FALSE;
	}

	Res = mysql_store_result(DB_BseCon);	

	if(Row = mysql_fetch_row(Res))
	{

		memcpy(UpdsPasswdReq->sOldPasswd,Row[1],BSE_PASSWORD_LEN);
		memcpy(UpdsPasswdReq->sNewPasswd,Row[0],BSE_PASSWORD_LEN);
	}
	logDebug1(" PlaLONG32ext Password User");


	UpdsPasswdReq->pHeader.iSlotNo = 3;
	UpdsPasswdReq->pHeader.iMsgLen=sizeof(struct OMB_UPDATE_PASSWORD_REQ)- sizeof(struct OMB_HEADER);

	UpdsPasswdReq->iMsgType=1134;


	UpdsPasswdReq->iMsgTag=0;
	/**       BSETWIDDLE(UpdsPasswdReq->pHeader.iSlotNo);
	  BSETWIDDLE(UpdsPasswdReq->pHeader.iMsgLen);
	  BSETWIDDLE(UpdsPasswdReq->iMsgType);
	  BSETWIDDLE(UpdsPasswdReq->iMsgTag);
	 **/
	memcpy(UpdsPasswd,UpdsPasswdReq,sizeof(struct OMB_UPDATE_PASSWORD_REQ));

	free(UpdsPasswdReq);
	free(PlainPassword);
	logDebug1(" ##### End of PasswordChangeRequest ");
	return TRUE;

}

BOOL ReceivesPasswdReply (CHAR *UpdsPasswdResp ,LONG32 UserId)
{
	LONG32  Transcode,SentBytes = 0;
	CHAR    *SndMsg ;
	CHAR    *Packet;
	LONG32  PacketSize;
	LONG32  Flag=FALSE;
	LONG32  RecvBytes = 0;

	struct  OMB_UPDATE_PASSWORD_RESP *UpdPasswdResponse;

	CHAR NewPassword[OBFS_LEN*2 + 1];

	CHAR    sSeletQry[MAX_QUERY_SIZE];
	memset(sSeletQry,'\0',MAX_QUERY_SIZE);

	CHAR    sUdpQry[MAX_QUERY_SIZE];
	memset(sUdpQry,'\0',MAX_QUERY_SIZE);
	
//	CHAR	*sSeletQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR	*sUdpQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug1(" In function ReceivesPasswdReply");

	UpdPasswdResponse=(struct OMB_UPDATE_PASSWORD_RESP *)UpdsPasswdResp;

	memset(NewPassword,'\0',OBFS_LEN*2 + 1);
	/**        BSETWIDDLE(UpdPasswdResponse->pHeader.iSlotNo);
	  BSETWIDDLE(UpdPasswdResponse->pHeader.iMsgLen);

	  BSETWIDDLE(UpdPasswdResponse->iMsgType);
	  BSETWIDDLE(UpdPasswdResponse->iMsgTag);
	  BSETWIDDLE(UpdPasswdResponse->iRepCode);
	 **/
	logDebug1("Reply code is %d",UpdPasswdResponse->iRepCode);


	if(UpdPasswdResponse->iRepCode==0)
	{
		logDebug1("Here");
		sprintf(sSeletQry,"SELECT \
				EAM_NEW_PASSWORD\
				FROM       EXCH_ADMINISTRATION_MASTER \
				WHERE      EAM_EXM_EXCH_ID = 'BSE'\
				AND        EAM_SEGMENT = 'C'\
				AND        EAM_GROUP_ID = %d\
				AND        EAM_DRV_FLAG = 'N' ;",iGlobUserGroupId);

		if (mysql_query(DB_BseCon,sSeletQry) !=SUCCESS)
		{
			logDebug1("Error in select  password is ");
			sql_Error(DB_BseCon);
			return FALSE;
		}

		sprintf(sUdpQry,"UPDATE EXCH_ADMINISTRATION_MASTER SET \
				EAM_OLD_PASSWORD=:NewPassword,\
				EAM_NEW_PASSWORD = '',\
				EAM_LAST_PASSWORD_CHANGE_DATE=trunc(sysdate),\
				EAM_UPDATE_BY = user,\
				EAM_UPDATE_DATE = trunc(sysdate)\
				WHERE 		EAM_EXM_EXCH_ID = 'BSE' \
				AND 		EAM_SEGMENT = 'C'\
				AND		 	EAM_GROUP_ID = %d \
				AND        EAM_DRV_FLAG = 'N' ;",iGlobUserGroupId);

		logDebug2("sUdpQry :%s:",sUdpQry);

		if (mysql_query(DB_BseCon,sUdpQry) !=SUCCESS)
		{
			logDebug1("Error in updation of password is ");
			sql_Error(DB_BseCon);
			return FALSE;
		}
		else
		{
			mysql_commit(DB_BseCon);
			logDebug1("The message in updation of password is %s",UpdPasswdResponse->sRepText);
			return TRUE;
		}
	}
	else
	{
		logDebug1("Reached here in else part");
		logDebug1("The error in updation of password is %s",UpdPasswdResponse->sRepText);
		BSEconnectLogFatal("The error in updation of password"); 
		return FALSE;
	}
}



BOOL fTrade(CHAR *pMem)
{

	struct OMB_TRADE_CONFIRMATION_UMS  sMem;
	LONG32	NoOfRecs;
	LONG32	i;


	memcpy(&sMem,pMem,sizeof(struct OMB_TRADE_CONFIRMATION_UMS));

	//	BSETWIDDLE(sMem.iNoOfRecords);
	logDebug1("-------------------------------------------------");
	logDebug1("NO OF TRADES IN THIS PACKET IS %d",sMem.iNoOfRecords);

	NoOfRecs = sMem.iNoOfRecords;

	for(i=0;i<NoOfRecs;i++)
	{

		/**		BSETWIDDLE(sMem.pSubTraDetails[i].iTradeId);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iRate);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iQty);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iOrdId);
		  BSETWIDDLE(sMem.pSubTraDetails[i].iMsgTag);
		 **/
		logDebug1(" PACKET NO %d",i);


		logDebug1("TradeId[%d] : %d",i,sMem.pSubTraDetails[i].iTradeId);
		logDebug1("Rate[%d]    : %d",i,sMem.pSubTraDetails[i].iRate);
		logDebug1("Qty[%d]     : %d",i,sMem.pSubTraDetails[i].iQty);
		logDebug1("iMsgTag[%d] : %d",i,sMem.pSubTraDetails[i].iMsgTag);
		logDebug1("TransId[%d] : %lld",i,sMem.pSubTraDetails[i].iOrdId);
		logDebug1("TransId[%d] : %ld",i,sMem.pSubTraDetails[i].iOrdId);
		logDebug1("Day[%d]     : %i",i,sMem.pSubTraDetails[i].pOmbYr.cDay);
		logDebug1("Month[%d]   : %i",i,sMem.pSubTraDetails[i].pOmbYr.cMonth);
		logDebug1("Year[%d]    : %i",i,(sMem.pSubTraDetails[i].pOmbYr.iYear+1900));

		logDebug1("Hour[%d]    : %i",i,sMem.pSubTraDetails[i].pOmbTime.cHour);
		logDebug1("Minute[%d]  : %i",i,sMem.pSubTraDetails[i].pOmbTime.cMinute);
		logDebug1("Second[%d]  : %i",i,sMem.pSubTraDetails[i].pOmbTime.cSecond);

	}	

	return TRUE;



}


LONG32	QueryNewsCategory (LONG32 Tcode )
{
	LONG32	RetVal ;
	LONG32	SentBytes,RecvBytes;
	LONG32	PacketSize ;
	LONG32	Flag = FALSE;

	struct OMB_NEWS_CATEGORY_REQ	NewCatReq ;
	struct OMB_NEWS_CATEGORY_RESP	NewsCatResp ;


	logDebug1("In QueryNewsCategory ");

	if(  ( RetVal = PrepareNewsCategory (&NewCatReq )) == TRUE )
	{
		//	BSETWIDDLE(NewCatReq.pHeader.iMsgLen);
		PacketSize = NewCatReq.pHeader.iMsgLen + sizeof(struct OMB_HEADER) ;
		//		BSETWIDDLE(NewCatReq.pHeader.iMsgLen);
		SentBytes = SendPacket (iSockfd, (CHAR *)&NewCatReq, PacketSize );
		if( SentBytes < 0)
		{
			BSEconnectLogFatal("In QueryNewsCategory bytes less than 0");
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, (CHAR *)&NewsCatResp );	
		logDebug1("Received A packet from Exchange ...");
		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			BSEconnectLogFatal("Error in RecvPacket  ");
			return FALSE;
		}
		if( RecvBytes == 0)
		{
			return FALSE;
		}
		if ( (Flag = RecvQueryNewsCategory (&NewsCatResp )) == TRUE )
		{
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			BSEconnectLogFatal("Entered Retry part..");
			continue ;
		}
		else
		{
			return FALSE ;
		}
	}while( Flag == RETRY );
}


LONG32  PrepareNewsCategory (struct  OMB_NEWS_CATEGORY_REQ *NewsCatReq  )
{

	logDebug1("In PrepareNewsCategor ");

	memset(NewsCatReq,' ',sizeof(struct OMB_NEWS_CATEGORY_REQ) ) ;

	NewsCatReq->pHeader.iSlotNo = 1;
	NewsCatReq->pHeader.iMsgLen = sizeof(struct OMB_NEWS_CATEGORY_REQ) - sizeof(struct OMB_HEADER) ;
	NewsCatReq->iMsgType = TC_EQU_BSE_NEWS_CATEGORY_REQ  ;	
	NewsCatReq->iMsgTag = 1005;	
	NewsCatReq->iCategory = 0 ;              /*** As is OMB to be confirmed **/	
	NewsCatReq->cDirection = 'N' ;              /*** to be confirmed **/	
	NewsCatReq->iNewsID = -1 ;              /*** As is OMB to be confirmed **/	


	/**	BSETWIDDLE(NewsCatReq->pHeader.iSlotNo);
	  BSETWIDDLE(NewsCatReq->pHeader.iMsgLen);
	  BSETWIDDLE(NewsCatReq->iMsgType);
	  BSETWIDDLE(NewsCatReq->iMsgTag);
	  BSETWIDDLE(NewsCatReq->iCategory);
	  BSETWIDDLE(NewsCatReq->iNewsID);
	 **/
	return TRUE;

}

LONG32  RecvQueryNewsCategory (struct OMB_NEWS_CATEGORY_RESP *NewsCatResp )
{
	/*************************************
	  LONG32 	SentBytes = 0 ;
	  LONG32	iRetVal = FALSE ;
	  LONG32	count = 0 ;



	  EXEC SQL BEGIN DECLARE SECTION ;
	  VARCHAR		vNewsTitle[NEWS_CATEGORY_TITLE_LEN] ;
	  LONG32 		vNewsCategory;
	  EXEC SQL END DECLARE SECTION ;



	  logDebug1("\nIn RecvQueryNewsCategory ");


	  BSETWIDDLE(NewsCatResp->iMsgType);
	  BSETWIDDLE(NewsCatResp->ReplyCode);
	  BSETWIDDLE(NewsCatResp->NoOfRec);
	  BSETWIDDLE(NewsCatResp->iMsgTag);

	  logDebug1("\n********************************************************");
	  logDebug1("\n*     QUERY   NEWS CATEGORY  REPLY         *");
	  logDebug1("\n********************************************************");
	  logDebug1("\nTranscode   Received : %d",  NewsCatResp->iMsgType   );
	  logDebug1("\nReply Code  Received : %d",  NewsCatResp->ReplyCode   );
	  logDebug1("\niNoOfRecords Received : %d",  NewsCatResp->NoOfRec );
	  logDebug1("\niMsgTag      Received : %d",  NewsCatResp->iMsgTag );
	  logDebug1("\n********************************************************");


	  if( NewsCatResp->iMsgType != TC_EQU_BSE_NEWS_CATEGORY_RESP )
	  {
	  logDebug1("\nReceived Packet is not of QueryIndexValue Reply..");
	  return  RETRY ;
	  }

	  logDebug1("\n********************************************************");
	  logDebug1("\n*     QUERY   NEWS CATEGORY  REPLY         *");
	  logDebug1("\n********************************************************");
	  logDebug1("\nTranscode   Received : %d",  NewsCatResp->iMsgType   );
	  logDebug1("\nReply Code  Received : %d",  NewsCatResp->ReplyCode   );
	  logDebug1("\niNoOfRecords Received : %d",  NewsCatResp->NoOfRec );
	  logDebug1("\niMsgTag      Received : %d",  NewsCatResp->iMsgTag );
	  logDebug1("\n********************************************************");

	  if( NewsCatResp->ReplyCode == 0  )
	  {
	  for( count=0; count < NewsCatResp->NoOfRec; count++)
	  {

	  logDebug1("\nNewsCategory Received : %d",  NewsCatResp->SubNewsCat[count].NewsCategory );
	  logDebug1("\nNewTitle      Received : %s",  NewsCatResp->SubNewsCat[count].NewTitle);
	  logDebug1("\n----------------------------------------------------------------");
	  vNewsCategory = NewsCatResp->SubNewsCat[count].NewsCategory;
	  memset(vNewsTitle ,'\0',NEWS_CATEGORY_TITLE_LEN);
	  memcpy(vNewsTitle ,NewsCatResp->SubNewsCat[count].NewTitle,st (NewsCatResp->SubNewsCat[count].NewTitle));
	  vNewsTitle  = st (NewsCatResp->SubNewsCat[count].NewTitle);

	  logDebug1("\nNewTitle      Received : %d",  vNewsTitle );
	  EXEC SQL UPDATE BSE_NEWS_CATEGORY_MASTER 
	  SET BNCM_NEWS_CAT_TITLE = :vNewsTitle
	  WHERE BNCM_NEWS_CAT_NUM = :vNewsCategory;

	  if (sqlca.sqlcode ==0)
	  {
	  logDebug1("\nRecord Updated");
	  EXEC SQL COMMIT;
	  }
	  else if(sqlca.sqlcode ==1403)
	{
		logDebug1("\n Record Does not Exixt .. Inserting Record");
		EXEC SQL INSERT INTO BSE_NEWS_CATEGORY_MASTER
			(
			 BNCM_NEWS_CAT_NUM, 
			 BNCM_NEWS_CAT_TITLE
			)
			VALUES
			(
			 :vNewsCategory,
			 :vNewsTitle
			);

		if (sqlca.sqlcode ==0)
		{
			logDebug1("\nRecord Inserted");
			EXEC SQL COMMIT;
		}
		else
		{
			logDebug1("\n ERROR in insertion");
			EXEC SQL ROLLBACK;
			return FALSE;
		}		
	}
	  else
	  {
		  logDebug1("\n ERROR in Updation");
		  EXEC SQL ROLLBACK;
		  return FALSE;
	  }
}
}
else
return FALSE;

logDebug1("\nReturn From Func ");
*************************************/

return TRUE;
}


void InitSharedMemory ()
{
	LONG32  Index,Count ;
	struct SLOT *Ptr ;
	struct IML_INFO_SHM *pImlQryShm;

	logDebug1("Inside InitSharedMemory...");
	logDebug1 ("HERE FOR %d " , GlobShmKey) ;
	LockShm ( GlobShmKey);

	logDebug1(" OpenSharedMemoryory for InitSharedMemory################## 1");
	//	pImlQryShm = ( struct IML_INFO_SHM *)OpenSharedMemory ( GlobShmKey, Bse_Conn_Shm_SIZE);
	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 2");

	//if ( *( (LONG32 *) pImlQryShm ) == ERROR )
	if ( (pImlQryShm = ( struct IML_INFO_SHM *)OpenSharedMemory ( GlobShmKey, Bse_Conn_Shm_SIZE)) == ( struct IML_INFO_SHM *) ERROR  )
	{
		logDebug1 (" Error in Opening Shared memory");
		perror("SHM :");
		UnLockShm( GlobShmKey);
		exit(0);
	}

	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 3");
	for ( Count =0 ; Count < NO_QRY_IML ; Count ++)
	{
		pImlQryShm -> pImlInfo[Count].iImlUserId= UNUSED;
		for (Index = 0; Index < (NO_OF_SLOTS-NO_OF_SLOTS_QRY) ; Index ++ )
		{
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iStatus= UNUSED_SLOT ;
			pImlQryShm -> pImlInfo[Count].pSlotInfo[Index].iSlot   = UNUSED_SLOT ;
		}
	}

	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 4");
	if ( CloseSharedMemory( (void * ) pImlQryShm ) == ERROR )
	{
		logDebug1 (" Error in Closing Shm ");
		UnLockShm( GlobShmKey);
		exit(0);
	}

	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 5");
	UnLockShm( GlobShmKey);
	logDebug1(" OpenSharedMemory for InitSharedMemory ################## 6");
	return ;
}

void EAMtimestamp(SHORT SendRecv)  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
{

	LONG32   groupid=0;
	
	CHAR    sUpdQry[MAX_QUERY_SIZE];
	memset(sUpdQry,'\0',MAX_QUERY_SIZE);
	
	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

//	CHAR	*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//	CHAR	*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	logDebug1(" iGlobUserGroupId : %d", iGlobUserGroupId);
	groupid =iGlobUserGroupId;
	logDebug1("  Local groupid : %d", groupid);        


	if ( SendRecv == 1 )
	{
		sprintf(sSelQry,"SELECT IFNULL(EAM_LAST_MSG_TIME,0)  \
				FROM   EXCH_ADMINISTRATION_MASTER\
				WHERE  EAM_EXM_EXCH_ID='BSE' \
				AND  EAM_GROUP_ID=%d\
				AND EAM_DRV_FLAG='N' ;",groupid);

		logDebug2("sSelQry :%s:",sSelQry);

		if ( mysql_query(DB_BseCon,sSelQry)!= SUCCESS )
		{
			logDebug1(" Error in updating EAM for iGlobUserGroupId " );
			sql_Error(DB_BseCon);
			exit(ERROR);
		}

		Res = mysql_store_result(DB_BseCon);			

		if(Row = mysql_fetch_row(Res))
		{
			last_msg_time = atoi(Row[0]);		
		}

		logDebug1("===========iGlobUserGroupId [%d]============= last_msg_time [%d] =================",groupid,last_msg_time);

		iSec= last_msg_time % 100;
		last_msg_time = last_msg_time / 100;
		iMinutes= last_msg_time % 100;
		iHours= last_msg_time / 100;
	}
	else
	{
		logDebug1("===========iGlobUserGroupId [%d]====Insrting New Timestamp ",groupid);

		sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER \
				SET \
				EAM_LAST_MSG_TIME=julidate(now()) \
				WHERE EAM_EXM_EXCH_ID='BSE' \
				AND EAM_DRV_FLAG='N' \
				AND EAM_GROUP_ID= %d;",groupid);
		logDebug2("sUpdQry :%s:",sUpdQry);			

		if(mysql_query(DB_BseCon,sUpdQry) != SUCCESS)
		{
			sql_Error(DB_BseCon);
			mysql_rollback(DB_BseCon);

		}	
		else
		{
			mysql_commit(DB_BseCon);
		}

	}



}


BOOL    fDCGateWayReq()
{
        logTimestamp("Entry :fDCGateWayReq:");

        struct  FIX_BSE_GATEWAY_REQUEST *GateWayReq;
        GateWayReq = (struct FIX_BSE_GATEWAY_REQUEST*)malloc(sizeof(struct FIX_BSE_GATEWAY_REQUEST));
        memset(GateWayReq,' ',sizeof(struct  FIX_BSE_GATEWAY_REQUEST));
	CHAR    sSelQry[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	INT16   SentBytes = 0;
        INT16   RecvBytes = 0;
        CHAR    *Packet ;
        LONG32  RetVal1 = FALSE;
        CHAR    *SendData;
        SendData =  ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
        Packet = ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
	sprintf(sSelQry,"SELECT   EAM_EXCH_USER_ID,aes_decrypt(EAM_OLD_PASSWORD,'rupee123'),EAM_VERSION_NO\
                                FROM   EXCH_ADMINISTRATION_MASTER\
                                WHERE  EAM_EXM_EXCH_ID='BSE' \
                                AND  EAM_GROUP_ID=%d\
                                AND EAM_SEGMENT ='C' ;",iGlobUserGroupId);

        logDebug2("sSelQry :%s:",sSelQry);

        if ( mysql_query(DB_BseCon,sSelQry)!= SUCCESS )
        {
        	logDebug1(" Error in updating EAM for iGlobUserGroupId " );
	        sql_Error(DB_BseCon);
	        exit(ERROR);
        }

        Res = mysql_store_result(DB_BseCon);

        if(Row = mysql_fetch_row(Res))
        {
        	GateWayReq->pHeader.iMsgLength = sizeof(struct  FIX_BSE_GATEWAY_REQUEST);
        	GateWayReq->pHeader.iMsgCode = 10020;
		strcpy(GateWayReq->pHeader.sNetworkMsgID,"");
	        strcpy(GateWayReq->pHeader.sPad2,"");
        	GateWayReq->pLoginHeader.iMsgSeqNum = 1;
        	GateWayReq->pLoginHeader.iSenderSubID =  0;
        	GateWayReq->iSessionPartyId = atoi(Row[0]);
		iSessionPartyId = atoi(Row[0]);
        	strncpy(GateWayReq->sDefCustAppVerId,Row[2],DEFAULT_CUST_APP_VER_ID_LEN);
        	strncpy(GateWayReq->sBsePassword,Row[1],    BSE_PASSWORD_LEN);
        	strcpy(GateWayReq->sPad6,"") ;

        }
        logDebug3("iMsgLength   :%d: ",GateWayReq->pHeader.iMsgLength);
        logDebug3("iMsgCode     :%d: ",GateWayReq->pHeader.iMsgCode);
        logDebug3("sNetworkMsgID        :%s: ",GateWayReq->pHeader.sNetworkMsgID);
        logDebug3("Filler2              :%s: ",GateWayReq->pHeader.sPad2);
        logDebug3("iMsgSeqNum           :%d: ",GateWayReq->pLoginHeader.iMsgSeqNum);
        logDebug3("iSenderSubID         :%d: ",GateWayReq->pLoginHeader.iSenderSubID);
        logDebug3("iSessionPartyId      :%d: ",GateWayReq->iSessionPartyId);
        logDebug3("sDefCustAppVerId     :%s: ",GateWayReq->sDefCustAppVerId);
        logDebug3("sBsePassword         :%s: ",GateWayReq->sBsePassword);
        logDebug3("Filler6              :%s: ",GateWayReq->sPad6);

        memcpy(SendData,(CHAR*)GateWayReq, GateWayReq->pHeader.iMsgLength);
        SentBytes = SendPacket( iSockfd, (CHAR*)SendData, GateWayReq->pHeader.iMsgLength);

        if ( SentBytes < 0)
        {
                perror("Error While Sending :");
                exit( 0 );
        }

        RecvBytes = RecvPacket (iSockfd, Packet );


        RetVal1 = fDCGateWayRes(Packet);
        if ( RetVal1 == ERROR)
        {
                BSEconnectLogFatal ("Problem In ProcessInitialConnection");
                exit(0);
        }

        logInfo(" RecvBytes :%d:",RecvBytes);
        close(iSockfd);
        logTimestamp("Exit :fDCGateWayReq:");
	return FALSE;


}

BOOL    fDCGateWayRes(CHAR *sTempData)
{
        logTimestamp("Entry :fDCGateWayReq: ");

        ULONG32  iPriGtwIP1 = 0;
        ULONG32  iSecGtwIP2 = 0;
        LONG32  iPriGtwPORT,iSecGtwPORT;

        CHAR    sUpdQry[MAX_QUERY_SIZE];
        memset(sUpdQry,'\0',MAX_QUERY_SIZE);

        struct FIX_BSE_GATEWAY_RESPONSE *pRecv;
	if(((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->pHeader.iMsgCode == 10010)
	{
		logInfo("Error while GATEWAY Request");
		RecvRejPacket(sTempData);
		return FALSE;
	}
	logDebug3("Recvresp: pHeader.iMsgLength :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->pHeader.iMsgLength);
        logDebug3("Recvresp: pHeader.iMsgCode   :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->pHeader.iMsgCode);
        logDebug3("Recvresp: iRequestTime       :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iRequestTime);
        logDebug3("Recvresp: iSendTime          :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iSendTime);
        logDebug3("Recvresp: iMsgSeqNum         :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iMsgSeqNum);
        logDebug3("Recvresp: iPriGateWayId      :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iPriGateWayId);
        logDebug3("Recvresp: iPriGateWaySubId   :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iPriGateWaySubId);
        logDebug3("Recvresp: iSecGayeWayId      :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iSecGayeWayId);
        logDebug3("Recvresp: iSecGayeWaySubId   :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iSecGayeWaySubId);
        logDebug3("Recvresp: iSessionMode       :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->cSessionMode);
        logDebug3("Recvresp: iTradeSessMode     :%d: ",((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->cTradeSessMode);

        iPriGtwIP1 = ((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iPriGateWayId;
        iSecGtwIP2 = ((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iSecGayeWayId;
        iPriGtwPORT = ((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iPriGateWaySubId;
        iSecGtwPORT = ((struct FIX_BSE_GATEWAY_RESPONSE *)sTempData)->iSecGayeWaySubId;
        logDebug3("iPriGtwIP1 = :%d:  iSecGtwIP2 = :%d:",iPriGtwIP1,iSecGtwIP2);

        fDecToIpCon(iPriGtwIP1,iSecGtwIP2);

        sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER SET EAM_PRI_GATEWAY_IP = \"%s\" , EAM_SEC_GATEWAY_IP= \"%s\",\
                        EAM_PRI_GATEWAY_PORT = %d, EAM_SEC_GATEWAY_PORT = %d WHERE EAM_EXM_EXCH_ID = 'BSE' AND EAM_SEGMENT = 'C' AND EAM_GROUP_ID = %d;", \
                        sGtwIP1,sGtwIP2,iPriGtwPORT,iSecGtwPORT,iGlobUserGroupId);
        logDebug2("sUpdQry :%s:",sUpdQry);
        if(mysql_query(DB_BseCon,sUpdQry)!= SUCCESS)
        {
                logDebug1(" Updation fails ");
                sql_Error(DB_BseCon);
                return FALSE;
        }
        else
        {
                logInfo("Updated successfully");
                mysql_commit(DB_BseCon);
        }

}

BOOL fDecToIpCon(ULONG32 iPriGtwIP1,LONG32 iPriGtwIP2)
{
        memset(sGtwIP1,'\0',25);
	memset(sGtwIP2,'\0',25);
	unsigned char bytes[4];
        unsigned char bytes2[4];

        bytes[0] = iPriGtwIP1 & 0xFF;
        bytes[1] = (iPriGtwIP1 >> 8) & 0xFF;
        bytes[2] = (iPriGtwIP1 >> 16) & 0xFF;
        bytes[3] = (iPriGtwIP1 >> 24) & 0xFF;

        bytes2[0] = iPriGtwIP2 & 0xFF;
        bytes2[1] = (iPriGtwIP2 >> 8) & 0xFF;
        bytes2[2] = (iPriGtwIP2 >> 16) & 0xFF;
        bytes2[3] = (iPriGtwIP2 >> 24) & 0xFF;

        sprintf(sGtwIP1,"%d.%d.%d.%d",bytes[3], bytes[2], bytes[1], bytes[0]);
        sprintf(sGtwIP2,"%d.%d.%d.%d",bytes2[3], bytes2[2], bytes2[1], bytes2[0]);
        logDebug3("sGtwIP1 = :%s:  iPriGtwIP2 = :%s:",sGtwIP1,sGtwIP2);

}

LONG32  OpenGateWaySocket( )
{
	logTimestamp("Entry :OpenGateWaySocket:");
        LONG32  sock = 0 ;
        struct  sockaddr_in ServAddr;
        LONG32  ErrorCount = 0;
        LONG32  RetVal = -1;
        LONG32  MaxTry = 0;
        CHAR    sErrorStr[SIZE];

        logDebug1("Inside OpenPassiveSocket..");

        memset( ( CHAR * ) &ServAddr, 0, sizeof ( ServAddr ) );

        do
        {

                if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
                {
                        perror("Trying to open Socket Failed :");
                        BSEconnectLogFatal("Trying to open Socket Failed");
                        sleep(1);
                        ErrorCount ++;
                        continue ;
                }

                if( sock > 0 )
                {
                        logDebug1("The IML address is %s ", sImlIPAddress );
                        logDebug1("The IML port is %d ", iImlPort );
                        ServAddr.sin_family = AF_INET ;
                        ServAddr.sin_addr.s_addr = inet_addr(sImlIPAddress);
                        ServAddr.sin_port = htons(iImlPort);

                        do
                        {
                                memset(sErrorStr,'\0',SIZE);
                                logTimestamp(":%s: TRYING TO CONNNECT IML APP IP :%s: PORT :%d:",KEY_WORD_MONITORING,sImlIPAddress,iImlPort);
                                RetVal = connect(sock,(struct sockaddr *) &ServAddr,sizeof(struct sockaddr));
                                logDebug1("The Return value is %d",RetVal );
                                perror("Error Connecting IML ");
                                strcpy(sErrorStr,strerror(errno));

                                if ( RetVal == ERROR)
				{
					sleep(10);
                                        logInfo(" IML IS NOT GETTING CONNECTED IML IP :%s: IML PORT :%d:",sImlIPAddress,iImlPort);
                                        logTimestamp(":%s: GETTING DISCONNECTED FOR IML APP IP :%s: PORT :%d: REASON :%s:",KEY_WORD_MONITORING,sImlIPAddress,iImlPort,sErrorStr);
                                        perror("Connect Failed :");
                                        close(sock);
                                        Sleep(100);

                                        if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
                                        {
                                                perror("Trying to open Socket Failed :");
                                                sleep(1);
                                                ErrorCount ++;
                                                break;
                                        }
                                }

                        }while(RetVal < 0 );
                        logTimestamp(":%s: CONNNECTION SUCCESSFULL TO  IML APP IP :%s: PORT :%d:",KEY_WORD_MONITORING,sImlIPAddress,iImlPort);
		}
	}while( sock < 0);
	logTimestamp("Exit :OpenGateWaySocket:");
	return sock;
}

void RecvRejPacket(CHAR	*RespPack)
{
	logTimestamp("Entry :RecvRejPacket:");
	struct FIX_BSE_SESSION_REJECT_RESP * pUserRejResp ;


                pUserRejResp= (struct FIX_BSE_SESSION_REJECT_RESP * )malloc \
                       (sizeof(struct FIX_BSE_SESSION_REJECT_RESP ));



                memcpy( pUserRejResp, RespPack, sizeof(struct FIX_SESSION_LOGON_RESP));
                logDebug1(" pUserRejResp->pHeader.iMsgLength    = %d", pUserRejResp->pHeader.iMsgLength);
                logDebug1(" pUserRejResp->pHeader.iMsgCode      = %d", pUserRejResp->pHeader.iMsgCode);
                logDebug1(" pUserRejResp->pHeader.sPad2 = :%s:", pUserRejResp->pHeader.sPad2);
                logDebug1(" pUserRejResp->iRequestTime  = %ld", pUserRejResp->iRequestTime);
                logDebug1(" pUserRejResp->iRequestOut   = %ld", pUserRejResp->iRequestOut);
                logDebug1(" pUserRejResp->iTradeRegTSTimeIn     = %ld", pUserRejResp->iTradeRegTSTimeIn);
                logDebug1(" pUserRejResp->iTradeRegTSTimeOut    = %ld", pUserRejResp->iTradeRegTSTimeOut);
                logDebug1(" pUserRejResp->iResponseIn   = %ld", pUserRejResp->iResponseIn       );
                logDebug1(" pUserRejResp->iSendingTime  = %ld", pUserRejResp->iSendingTime);
                logDebug1(" pUserRejResp->iMsgSeqNum    = %d", pUserRejResp->iMsgSeqNum);
                logDebug1(" pUserRejResp->cLastFragment = %d", pUserRejResp->cLastFragment);
                logDebug1(" pUserRejResp->sPad3         = %s", pUserRejResp->sPad3);
                logDebug1(" pUserRejResp->iRejectionReasonCode  = %d", pUserRejResp->iRejectionReasonCode);
                logDebug1(" pUserRejResp->iRejMsgLen    = %d", pUserRejResp->iRejMsgLen);
                logDebug1(" pUserRejResp->cSessionStatus        = %d", pUserRejResp->cSessionStatus);
                logDebug1(" pUserRejResp->sRejectionMsg = :%s:", pUserRejResp->sRejectionMsg);
                logDebug1("In ReceiveRegistrationResp");
                logTimestamp("Exit  :ReceiveLogOnResp:");
                free(pUserRejResp);
	logTimestamp("Exit :RecvRejPacket:");
                return FALSE;

}

BOOL fSelectDate(CHAR *sSeq)
{
	logTimestamp("Entry :fSelectDate:");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
	if (mysql_query(DB_BseCon, "SELECT SUBSTR(CONCAT(Date_format(CURDATE(),'%Y%m%d')),3,8);") != SUCCESS)
        {
                sql_Error(DB_BseCon);
                logSqlFatal("error in select Date [EQOrdSvr].");
                return FALSE;
        }

        Res = mysql_store_result(DB_BseCon);
        while((Row = mysql_fetch_row(Res)))
        {
                strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Date_format : %s", sSeq);
        }

        mysql_free_result(Res);
	logTimestamp("Exit :fSelectDate:");

        return TRUE;
}
	
BOOL	fSubscribeReq(LONG32	iRefAppId)
{
	logTimestamp("Entry :fSubscribeReq:");

	struct  ETI_SUBSCRIBE_REQ	*sSubscbReq	;
	sSubscbReq= (struct ETI_SUBSCRIBE_REQ *)malloc(sizeof(struct ETI_SUBSCRIBE_REQ));
        memset(sSubscbReq,'\0',sizeof(struct  ETI_SUBSCRIBE_REQ));		
	LONG32	SentBytes = 0,RecvBytes =0;
	BOOL	RetVal1 = FALSE;	
	CHAR    *SendData,*Packet;
        SendData =  ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
        Packet = ( CHAR *)malloc( BSE_PACKET_SIZE ) ;


	sSubscbReq->pHeader.iMsgLength = sizeof(struct  ETI_SUBSCRIBE_REQ);
        sSubscbReq->pHeader.iMsgCode = 10025;
        strcpy(sSubscbReq->pHeader.sNetworkMsgID,"");
        strcpy(sSubscbReq->pHeader.sPad2,"");
	iTempSendSeqNum++;
        sSubscbReq->FIXHeader.iMsgSeqNum = iTempSendSeqNum;
        sSubscbReq->FIXHeader.iSenderSubID =  0xFFFFFFFF;
        sSubscbReq->iSubscribScope = iSessionPartyId;
        sSubscbReq->iRefAppId = iRefAppId;

        strcpy(sSubscbReq->sPad3,"") ;

	logInfo("*************SUBSCRIBTION REQUEST TO EXCHNAGE**************");
	logDebug3("sSubscbReq->pHeader.iMsgLength :%d:",sSubscbReq->pHeader.iMsgLength);
	logDebug3("sSubscbReq->pHeader.iMsgCode :%d:",sSubscbReq->pHeader.iMsgCode);
	logDebug3("sSubscbReq->pHeader.sNetworkMsgID :%s:",sSubscbReq->pHeader.sNetworkMsgID);	
	logDebug3("sSubscbReq->pHeader.sPad2		:%s:",sSubscbReq->pHeader.sPad2);
	logDebug3("sSubscbReq->FIXHeader.iMsgSeqNum	:%d:",sSubscbReq->FIXHeader.iMsgSeqNum);	
	logDebug3("sSubscbReq->FIXHeader.iSenderSubID	:%d:",sSubscbReq->FIXHeader.iSenderSubID);
	logDebug3("sSubscbReq->iSubscribScope 	:%d:",sSubscbReq->iSubscribScope);
	logDebug3("sSubscbReq->iRefAppId	:%d:",sSubscbReq->iRefAppId);
	logDebug3("sSubscbReq->sPad3		:%s:",sSubscbReq->sPad3);
			

	memcpy(SendData,(CHAR*)sSubscbReq, sSubscbReq->pHeader.iMsgLength);
        SentBytes = SendPacket( iSockfd, (CHAR*)SendData, sSubscbReq->pHeader.iMsgLength);

        if ( SentBytes < 0)
        {
                perror("Error While Sending :");
                //exit( 0 );
                return FALSE;
        }

        RecvBytes = RecvPacket (iSockfd, Packet );


        RetVal1 = fSubScribtionResp(Packet);
        if ( RetVal1 == ERROR)
        {
                logFatal("Problem In fSubscribeReq ");
                //exit(0);
                return FALSE;
        }	

	logTimestamp("Exit :fSubscribeReq:");

}

BOOL	fSubScribtionResp(CHAR	*RespPack)
{
	logTimestamp("Entry :fSubScribtionResp:");
	struct  ETI_SUBSCRIBE_RESP	*SubscrResp;	
	SubscrResp= (struct ETI_SUBSCRIBE_RESP	* )malloc  (sizeof(struct ETI_SUBSCRIBE_RESP));

	memcpy( SubscrResp, RespPack, sizeof(struct ETI_SUBSCRIBE_RESP));
	if(((struct ETI_SUBSCRIBE_RESP *)RespPack)->Header.iMsgCode == 10010)
        {
                logInfo("Error while GATEWAY Request");
                RecvRejPacket(RespPack);
                return FALSE;
        }
	logInfo("********************SUBSCRIPTION RESPONSE FROM EXCHNAGE****************************");
	logDebug3("SubscrResp->Header.iMsgLength :%d:",SubscrResp->Header.iMsgLength);
	logDebug3("SubscrResp->Header.iMsgCode	:%d:",SubscrResp->Header.iMsgCode);
	logDebug3("SubscrResp->Header.sPad2	:%s:",SubscrResp->Header.sPad2);

	logDebug3("SubscrResp->iRequestTime 	:%ld:",SubscrResp->iRequestTime);
	logDebug3("SubscrResp->iSendTime	:%ld:",SubscrResp->iSendTime);
	logDebug3("SubscrResp->iMsgSeqNum	:%ld:",SubscrResp->iMsgSeqNum);
	logDebug3("SubscrResp->Pad4		:%s:",SubscrResp->Pad4);
	logDebug3("SubscrResp->iApplSubId	:%d:",SubscrResp->iApplSubId);
	logDebug3("SubscrResp->Pad5		:%s:",SubscrResp->Pad5);
		
	logTimestamp("Exit :fSubScribtionResp:");
	return TRUE;

}

BOOL	fBseMsgSeqNum(CHAR *Packet,ULONG32  iMsgSeqNum)
{
	logTimestamp("Entry :fBseMsgSeqNum:");
	CHAR	sInsertQuery[MAX_QUERY_SIZE];
	memset(sInsertQuery,'\0',MAX_QUERY_SIZE);
	INT_BSE_HEADER *pReqHeader;
	memset(&pReqHeader,'\0',sizeof(INT_BSE_HEADER));
	LONG64	iTempClOrdId = 0;	
	pReqHeader = (INT_BSE_HEADER *)Packet;	
	
	logInfo("pReqHeader->iMsgCode :%d:",pReqHeader->iMsgCode);
	logInfo("iMsgSeqNum  :%d:",iMsgSeqNum);

	if(pReqHeader->iMsgCode  == TC_BSE_ETI_NEW_ORDER_REQ)
	{
		iTempClOrdId = ((FIX_BSE_ORDER_REQUEST *)Packet)->iClOrdId;
	}
	else if(pReqHeader->iMsgCode  == TC_BSE_ETI_MOD_ORDER_REQ)
        {
		iTempClOrdId = ((FIX_BSE_ORD_MODIFICATION_REQ *)Packet)->iClOrdId;
        }
	else if(pReqHeader->iMsgCode  == TC_BSE_ETI_CAN_ORDER_REQ)
        {
		iTempClOrdId = ((FIX_BSE_ORDER_CANCEL_REQUEST *)Packet)->iClOrdId;

        }
	else
	{
		logInfo("Invalid MsgCode :%d:",pReqHeader->iMsgCode);
	}
	
	logInfo("iTempClOrdId :%ld:",iTempClOrdId);

	sprintf(sInsertQuery,"INSERT INTO BSE_SDRV_MAPPER (BSM_SDRV_NUM,BSM_CLORD_ID,BSM_MSG_CODE) VALUES (%d,\"%ld\",\"%d\")",iMsgSeqNum,iTempClOrdId,pReqHeader->iMsgCode);
	
	logInfo("sInsertQuery :%s:",sInsertQuery);
	if(mysql_query(DB_BseCon, sInsertQuery) != SUCCESS)
        {
                logSqlFatal("Error in inserting BSE_SEQ_MAPPER ");
                sql_Error(DB_BseCon);
                return FALSE;
        }
	else
	{
		logDebug2("%d rows updated!!",mysql_affected_rows(DB_BseCon));
                mysql_commit(DB_BseCon);
	}

	logTimestamp("Exit :fBseMsgSeqNum:");

}

BOOL    fInsertExchDigital(SHORT iNoStreams )
{
        logTimestamp("Entry : fInsertExchDigital");

        SHORT    j=0;
        SHORT   iStreamId =0;
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        LONG32  iNumRow;

        CHAR    sSelQry [MAX_QUERY_SIZE];
        CHAR    sInsQry [MAX_QUERY_SIZE];


        logDebug2("iGlobUserGroupId 	: %d iNoStreams :%d ", iGlobUserGroupId, iNoStreams);
	

        logDebug2("===========iGlobUserGroupId[%d]== iNoStreams[%d]==",iGlobUserGroupId, iNoStreams);
        for ( j=1 ; j <= iNoStreams; j++)
        {
		memset(sSelQry,'\0',MAX_QUERY_SIZE);
		memset(sInsQry,'\0',MAX_QUERY_SIZE);
                iStreamId = j;

                sprintf(sSelQry,"SELECT * FROM EXCH_DOWNLOAD_DATA\
                                WHERE EDD_STREAM_ID = %d \
                                AND EDD_EXCH_ID=\"%s\"\
                                AND EDD_SEGMENT=\'%c\'\
                                AND EDD_GROUP_ID=%d ;",iStreamId,BSE_EXCH,CURRENCY_SEGMENT,iGlobUserGroupId);
                logDebug2("sSelQry :%s:",sSelQry);

                if(mysql_query(DB_BseCon,sSelQry) != SUCCESS)
                {
                        sql_Error(DB_BseCon);
                        return FALSE;
                }

                Res = mysql_store_result(DB_BseCon);

                iNumRow = mysql_num_rows(Res);

                logDebug2("NumRow :%d: StreamId:%d:",iNumRow,iStreamId);

                if(iNumRow == 0)
                {
                        sprintf(sInsQry,"INSERT INTO  EXCH_DOWNLOAD_DATA(\
                                EDD_GROUP_ID,\
                                EDD_EXCH_ID,\
                                EDD_SEGMENT,\
                                EDD_STREAM_ID,\
                                EDD_TIMESTAMP1,\
                                EDD_TIMESTAMP2)\
                                VALUES (\
                                %d,\
                                \"%s\",\
                                \'%c\',\
                                %d,\
                                0,\
                                0 );",iGlobUserGroupId,BSE_EXCH,CURRENCY_SEGMENT,iStreamId);

                        logDebug2("sInsQry :%s:",sInsQry);
                        if(mysql_query(DB_BseCon,sInsQry) != SUCCESS)
                        {
                                sql_Error(DB_BseCon);
                                return FALSE;
                        }
			else
                        {
                                mysql_commit(DB_BseCon);
                        }
                }
                mysql_free_result(Res);

        }

        logTimestamp("Exit : fInsertExchDigital");
        return TRUE ;

}


BOOL	TradeRetransmistionReq()
{
	logTimestamp("Entry :TradeRetransmistionReq:");
	CHAR*   RequestPacket           ;
        CHAR*   ReceivePacket           ;
        LONG32  PacketSize              ;
        LONG32  SentBytes               ;
        LONG32  RecvBytes               ;
        LONG32  iTranscode              ;
        LONG32  iNumRow;
	struct  TRADES_RETRANSMISSION_REQ *pDownloadReq;
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;


	CHAR	sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);		
	sprintf(sSelQry,"SELECT EDD_STREAM_ID,EDD_TIMESTAMP1,EDD_TIMESTAMP2 FROM EXCH_DOWNLOAD_DATA\
               WHERE EDD_EXCH_ID=\"%s\"\
               AND EDD_SEGMENT=\'%c\'\
               AND EDD_GROUP_ID=%d ;",BSE_EXCH,CURRENCY_SEGMENT,iGlobUserGroupId);
        logDebug2("sSelQry :%s:",sSelQry);

        if(mysql_query(DB_BseCon,sSelQry) != SUCCESS)
        {
        	sql_Error(DB_BseCon);
        	return FALSE;
        }

        Res = mysql_store_result(DB_BseCon);

        iNumRow = mysql_num_rows(Res);

        logDebug2("NumRow :%d: ",iNumRow);

	while(Row = mysql_fetch_row(Res))
        {
		RequestPacket=  ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
		pDownloadReq= (struct TRADES_RETRANSMISSION_REQ *)malloc(sizeof(struct TRADES_RETRANSMISSION_REQ));
        	pDownloadReq->pHeader.iMsgLength = sizeof(struct TRADES_RETRANSMISSION_REQ)  ;
        	PacketSize = sizeof(struct TRADES_RETRANSMISSION_REQ)  ;
        	pDownloadReq->pHeader.iMsgCode = 10008;
        	strcpy(pDownloadReq->pHeader.sNetworkMsgID,"");
        	strcpy(pDownloadReq->pHeader.sPad2,"");
		logInfo("Before inscrement :%d:",iTempSendSeqNum);
       	 	iTempSendSeqNum++;
        	pDownloadReq->FIXHeader.iMsgSeqNum = iTempSendSeqNum;
		logInfo("After inscrement :%d:",iTempSendSeqNum);
        	pDownloadReq->FIXHeader.iSenderSubID= 0;
        	pDownloadReq->iApplBegSeqNum= 0xFFFFFFFFFFFFFFFF;
        	pDownloadReq->iApplEndSeqNum= 0xFFFFFFFFFFFFFFFF;
        	pDownloadReq->iSubscriptionScope= 0xFFFFFFFF;
        	pDownloadReq->iPartitionId= atoi(Row[0]);
        	pDownloadReq->iRefApplId= 1;
        	pDownloadReq->cPad3= 0x00;
		memcpy(RequestPacket,(CHAR*)pDownloadReq, PacketSize);
		SentBytes = SendPacket( iSockfd, (CHAR*)RequestPacket, PacketSize);

        	if ( SentBytes < 0)
        	{
        		perror("Error While Sending :");
        		logDebug1("Transmit Child :Exiting");
        		exit( 0 );
        	}
        	else
        	{
        		logInfo("As Packet Send to Exchange need to set In DB  ");
	
        	}	
		usleep(5000);	
		free(RequestPacket);				
		free(pDownloadReq);				
        }

	logTimestamp("Exit :TradeRetransmistionReq:");

}

BOOL    OrdersRetransmistionReq(CHAR    *sLastRefMsgId)
{
        logTimestamp("Entry :OrdersRetransmistionReq:");
        CHAR*   RequestPacket           ;
        CHAR*   ReceivePacket;
        BOOL    RetVal1 = FALSE;
        LONG32  PacketSize              ;
        LONG32  iRcvPacketSize              ;
        LONG32  SentBytes               ;
        LONG32  RecvBytes               ;
        LONG32  iTranscode              ;
        LONG32  iNumRow;

        struct  ORDERS_RETRANSMISSION_REQ       *pDownloadReq;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32  iPackCount = 0;
        LONG32  iTotCount = 0;

        CHAR    sSelQry[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
        sprintf(sSelQry,"SELECT EDD_STREAM_ID,EDD_TIMESTAMP1,EDD_TIMESTAMP2 FROM EXCH_DOWNLOAD_DATA\
               WHERE EDD_EXCH_ID=\"%s\"\
               AND EDD_SEGMENT=\'%c\'\
               AND EDD_GROUP_ID=%d ;",BSE_EXCH,CURRENCY_SEGMENT,iGlobUserGroupId);
        logDebug2("sSelQry :%s:",sSelQry);

        if(mysql_query(DB_BseCon,sSelQry) != SUCCESS)
        {
                sql_Error(DB_BseCon);
                return FALSE;
        }

        Res = mysql_store_result(DB_BseCon);

        iNumRow = mysql_num_rows(Res);

        logDebug2("NumRow :%d: ",iNumRow);
	while(Row = mysql_fetch_row(Res))
        {
                memset(sLastRefMsgId,'\0',strlen(sLastRefMsgId));
                do
                {
                        iPackCount = 0;
                        RequestPacket=  ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
                        pDownloadReq= (struct ORDERS_RETRANSMISSION_REQ *)malloc(sizeof(struct ORDERS_RETRANSMISSION_REQ));
                        pDownloadReq->pHeader.iMsgLength = sizeof(struct ORDERS_RETRANSMISSION_REQ)  ;
                        PacketSize = sizeof(struct ORDERS_RETRANSMISSION_REQ)  ;
                        pDownloadReq->pHeader.iMsgCode = 10026;
                        strcpy(pDownloadReq->pHeader.sNetworkMsgID,"");
                        strcpy(pDownloadReq->pHeader.sPad2,"");
                        iTempSendSeqNum++;
                        pDownloadReq->FIXHeader.iMsgSeqNum = iTempSendSeqNum;
                        pDownloadReq->FIXHeader.iSenderSubID= 0;

                        pDownloadReq->iSubscriptionScope= 0xFFFFFFFF;
                        pDownloadReq->iPartitionId= atoi(Row[0]);;
                        pDownloadReq->iRefApplId= 0x04;
                        if(strlen(sLastRefMsgId) == 0)
                        {
                                pDownloadReq->sApplBegSeqNum[0] = 0x00;
                                pDownloadReq->sApplBegSeqNum[1] = 0x00;
                                pDownloadReq->sApplBegSeqNum[2] = 0x00;
                                pDownloadReq->sApplBegSeqNum[3] = 0x00;
                                pDownloadReq->sApplBegSeqNum[4] = 0x00;
                                pDownloadReq->sApplBegSeqNum[5] = 0x00;
                                pDownloadReq->sApplBegSeqNum[6] = 0x00;
                                pDownloadReq->sApplBegSeqNum[7] = 0x00;
                                pDownloadReq->sApplBegSeqNum[8] = 0x00;
                                pDownloadReq->sApplBegSeqNum[9] = 0x00;
                                pDownloadReq->sApplBegSeqNum[10] = 0x00;
                                pDownloadReq->sApplBegSeqNum[11] = 0x00;
                                pDownloadReq->sApplBegSeqNum[12] = 0x00;
                                pDownloadReq->sApplBegSeqNum[13] = 0x00;
                                pDownloadReq->sApplBegSeqNum[14] = 0x00;
                                pDownloadReq->sApplBegSeqNum[15] = 0x00;
                        }
                        else
                        {
                                pDownloadReq->sApplBegSeqNum[0] = sLastRefMsgId[0];
                                pDownloadReq->sApplBegSeqNum[1] = sLastRefMsgId[1];
                                pDownloadReq->sApplBegSeqNum[2] = sLastRefMsgId[2];
                                pDownloadReq->sApplBegSeqNum[3] = sLastRefMsgId[3];
                                pDownloadReq->sApplBegSeqNum[4] = sLastRefMsgId[4];
                                pDownloadReq->sApplBegSeqNum[5] = sLastRefMsgId[5];
                                pDownloadReq->sApplBegSeqNum[6] = sLastRefMsgId[6];
                                pDownloadReq->sApplBegSeqNum[7] = sLastRefMsgId[7];
				pDownloadReq->sApplBegSeqNum[8] = sLastRefMsgId[8];
                                pDownloadReq->sApplBegSeqNum[9] = sLastRefMsgId[9];
                                pDownloadReq->sApplBegSeqNum[10] = sLastRefMsgId[10];
                                pDownloadReq->sApplBegSeqNum[11] = sLastRefMsgId[11];
                                pDownloadReq->sApplBegSeqNum[12] = sLastRefMsgId[12];
                                pDownloadReq->sApplBegSeqNum[13] = sLastRefMsgId[13];
                                pDownloadReq->sApplBegSeqNum[14] = sLastRefMsgId[14];
                                pDownloadReq->sApplBegSeqNum[15] = sLastRefMsgId[15];

                        }

                        pDownloadReq->sApplEndSeqNum[0] = 0x00;
                        pDownloadReq->sApplEndSeqNum[1] = 0x00;
                        pDownloadReq->sApplEndSeqNum[2] = 0x00;
                        pDownloadReq->sApplEndSeqNum[3] = 0x00;
                        pDownloadReq->sApplEndSeqNum[4] = 0x00;
                        pDownloadReq->sApplEndSeqNum[5] = 0x00;
                        pDownloadReq->sApplEndSeqNum[6] = 0x00;
                        pDownloadReq->sApplEndSeqNum[7] = 0x00;
                        pDownloadReq->sApplEndSeqNum[8] = 0x00;
                        pDownloadReq->sApplEndSeqNum[9] = 0x00;
                        pDownloadReq->sApplEndSeqNum[10] = 0x00;
                        pDownloadReq->sApplEndSeqNum[11] = 0x00;
                        pDownloadReq->sApplEndSeqNum[12] = 0x00;
                        pDownloadReq->sApplEndSeqNum[13] = 0x00;
                        pDownloadReq->sApplEndSeqNum[14] = 0x00;
                        pDownloadReq->sApplEndSeqNum[15] = 0x00;
                        pDownloadReq->cPad3= '\0';

                        logInfo("Download Request for partition id :%d:",pDownloadReq->iPartitionId);
                        logDebug2("pDownloadReq->pHeader.iMsgLength     :%d:",pDownloadReq->pHeader.iMsgLength);
                        logDebug2("pDownloadReq->pHeader.iMsgCode       :%d:",pDownloadReq->pHeader.iMsgCode);
                        logDebug2("pDownloadReq->pHeader.sNetworkMsgID  :%s:",pDownloadReq->pHeader.sNetworkMsgID);
                        logDebug2("pDownloadReq->pHeader.sPad2          :%s:",pDownloadReq->pHeader.sPad2);
                        logDebug2("pDownloadReq->FIXHeader.iMsgSeqNum   :%d:",pDownloadReq->FIXHeader.iMsgSeqNum);
                        logDebug2("pDownloadReq->FIXHeader.iSenderSubID :%d:",pDownloadReq->FIXHeader.iSenderSubID);
                        logDebug2("pDownloadReq->iSubscriptionScope     :%d:",pDownloadReq->iSubscriptionScope);
                        logDebug2("pDownloadReq->iPartitionId           :%d:",pDownloadReq->iPartitionId);
                        logDebug2("pDownloadReq->iRefApplId             :%d:",pDownloadReq->iRefApplId);
                        logDebug2("pDownloadReq->sApplBegSeqNum         :%s:",pDownloadReq->sApplBegSeqNum);
                        logDebug2("pDownloadReq->sApplEndSeqNum         :%s:",pDownloadReq->sApplEndSeqNum);
                        logDebug2("pDownloadReq->cPad3                  :%c:",pDownloadReq->cPad3);

                        memcpy(RequestPacket,(CHAR*)pDownloadReq, PacketSize);
                        SentBytes = SendPacket( iSockfd, (CHAR*)RequestPacket, PacketSize);

			if ( SentBytes < 0)
                        {
                                perror("Error While Sending :");
                                logDebug1("Transmit Child :Exiting");
                                exit( 0 );
                        }
                        else
                        {
                                logInfo("As Packet Send to Exchange need to set In DB  ");

                        }

                        logDebug1("Printing Dwonload response ");


                        while(TRUE)
                        {
                                iRcvPacketSize = 0;
                                ReceivePacket=  ( CHAR *)malloc( BSE_PACKET_SIZE ) ;
                                RecvBytes = RecvPacket (iSockfd, ReceivePacket);

                                if(((INT_BSE_HEADER_OUT *)ReceivePacket)->iMsgCode == 10027)
                                {
                                        RetVal1 =  RecvRetramissResp(ReceivePacket,sLastRefMsgId,&iTotCount);
                                        logInfo("iTotCount :%d:",iTotCount);
                                        if(iTotCount == 0)
                                        {
                                                logInfo("Count packet is zero");
                                                break;
                                        }
                                }
                                else
                                {
                                        iPackCount++;
                                        logInfo("dowload msg code paritiion id :%d: MsgCode :%d: Total Packet :%d: current count :%d:",pDownloadReq->iPartitionId,((INT_BSE_HEADER_OUT *)ReceivePacket)->iMsgCode,iTotCount,iPackCount);
                                        if((iTotCount == iPackCount) )
                                        {
                                                logInfo("All packet recieved ");
                                                iRcvPacketSize = ((INT_BSE_HEADER_OUT *)ReceivePacket)->iMsgLength;
                                                WriteToBseRms( ReceivePacket, iRcvPacketSize);
                                                free(ReceivePacket);
                                                break;
                                        }
                                        iRcvPacketSize = ((INT_BSE_HEADER_OUT *)ReceivePacket)->iMsgLength;
                                        WriteToBseRms( ReceivePacket, iRcvPacketSize);


				}

                                free(ReceivePacket);
                        }
                }
		while(RetVal1 == TRUE);
		usleep(iSleepBusyTimer);
                free(RequestPacket);
                free(pDownloadReq);
        }

        logTimestamp("Exit :OrdersRetransmistionReq:");

}


	
void	SessionLogoutNotifnt(CHAR *Packet)
{
	logTimestamp("Entry :SessionLogoutNotifnt:");
	struct  FIX_BSE_SESSION_LOGOUT_RESP *pSesLogout  = (struct  FIX_BSE_SESSION_LOGOUT_RESP *)Packet;

	logDebug1("pSesLogout->pHeader.iMsgLength :%d:",pSesLogout->pHeader.iMsgLength);	
	logDebug1("pSesLogout->pHeader.iMsgCode		:%d:",pSesLogout->pHeader.iMsgCode);	
	logDebug1("pSesLogout->pHeader.sPad2 		:%s:",pSesLogout->pHeader.sPad2);	

	logDebug1("pSesLogout->iSendingTime		:%ld:",pSesLogout->iSendingTime);	
	logDebug1("pSesLogout->iCounter			:%ld:",pSesLogout->iCounter);	
	logDebug1("pSesLogout->sPad2			:%s:",pSesLogout->sPad2);	
	logDebug1("pSesLogout->sErrorStrng		:%s:",pSesLogout->sErrorStrng);	

	logTimestamp("Exit :SessionLogoutNotifnt:");
}

BOOL	RecvRetramissResp(CHAR *Packet,CHAR *sLastRefMsgId,LONG32 *iPackCount)
{
	logTimestamp("Entry :RecvRetramissResp:");
	LONG32  RecvBytes;
	struct  ORDERS_RETRANSMISSION_RESP *DownldResp;
	DownldResp = (struct  ORDERS_RETRANSMISSION_RESP *)Packet;
	logDebug3("iPackCount :%d:",iPackCount);

	logDebug3("DownldResp->pHeader.iMsgLength 	:%d:",DownldResp->pHeader.iMsgLength);
	logDebug3("DownldResp->pHeader.iMsgCode		:%d:",DownldResp->pHeader.iMsgCode);
	logDebug3("DownldResp->pHeader.sPad2		:%s:",DownldResp->pHeader.sPad2);

	logDebug3("DownldResp->iRequestTime		:%ld:",DownldResp->iRequestTime);
	logDebug3("DownldResp->iSendingTime		:%ld:",DownldResp->iSendingTime);
	logDebug3("DownldResp->iMsgSeqNum		:%d:",DownldResp->iMsgSeqNum);
	logDebug3("DownldResp->sPad4			:%s:",DownldResp->sPad4);
	logDebug3("DownldResp->sApplEndSeqNum		:%s:",DownldResp->sApplEndSeqNum);
	logDebug3("DownldResp->sRefAppLastSeqNum	:%s:",DownldResp->sRefAppLastSeqNum);
	logDebug3("DownldResp->iTotalMsgCount		:%d:",DownldResp->iTotalMsgCount);
	
	*iPackCount = DownldResp->iTotalMsgCount;
        if((memcmp(DownldResp->sApplEndSeqNum,DownldResp->sRefAppLastSeqNum,16) == 0) || strlen(DownldResp->sApplEndSeqNum) == 0)
        {
                logInfo("No required to request again");
                return FALSE;
        }
        else
        {
                logInfo(" required to request again");
                memcpy(sLastRefMsgId,DownldResp->sApplEndSeqNum,16);
                return TRUE;
        }


	logTimestamp("Exit :RecvRetramissResp:");
}
