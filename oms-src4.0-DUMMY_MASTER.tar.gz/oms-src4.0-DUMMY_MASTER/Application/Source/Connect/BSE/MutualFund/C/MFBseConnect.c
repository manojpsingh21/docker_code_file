#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <time.h>
#include "BseMFStrcut.h"


void ProcessArguments(LONG32 );
LONG32 last_msg_time;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
SHORT iHours=0,iMinutes=0,iSec=0;
//#define	BSETWIDDLE(A)	BseTwiddle((char *) &A, sizeof(A))
pid_t	iMainPID = 0;
MYSQL	*DB_BseCon;
LONG32 iGlobUserGroupId;
LONG32	iSockfd;
LONG32	DloadQueue,WriteQueue,ReadQueue;
CHAR	sImlIPAddress[20];
LONG32	iImlPort ;
CHAR    sKey[DB_KEY_LEN];	
key_t   GlobShmKey;
char    TimeStamp[TIME_LENGTH];
struct  ForkProcess ForkProcess[MAX_NO_PROCESSES] ;
void ConnectToOracle();
void OpenMessageQueues();
main(LONG32 argc, CHAR **argv )
{
	LONG32	RetVal = FALSE ;
	LONG32	ForkInd;
	LONG32	Sig = 0,iMainWait;
	LONG32	MainWait;
	LONG32 	identifier;
	LONG32	iRetVal = FALSE ;
	//struct OMB_HEADER *header ;
	sigset_t    MainSignalSet   ;

	setvbuf( stdout , NULL , _IONBF , 0 );
	setvbuf( stderr , NULL , _IONBF , 0 );
	setbuf( stdout , NULL );
	setbuf( stderr , NULL );

	DB_BseCon = DB_Connect();

	memset(sKey,'\0',DB_KEY_LEN);

	iGlobUserGroupId = atoi(argv[1]); 
	identifier = iGlobUserGroupId;
	logDebug1("iGlobUserGroupId is %d", iGlobUserGroupId);
	ProcessArguments (identifier);
	errno=0;


	for ( ; ; )  
	{
		signal(SIGTTOU,SIG_IGN);
		signal(SIGTTIN,SIG_IGN);
		signal( SIGHUP ,SIG_IGN);
		signal( SIGPIPE,SIG_IGN);
		signal( SIGBUS ,SIG_IGN);
		signal( SIGINT ,SIG_IGN);
		sigemptyset( &MainSignalSet );
		sigaddset ( &MainSignalSet , SIGTERM );
		sigaddset ( &MainSignalSet , SIGUSR1);
		/****
		  sigprocmask ( SIG_BLOCK,&MainSignalSet,NULL);
		  signal(SIGTERM, SignalHandlerSigTermMain );
		 ****/


		//GetParameters ( );
		//InitSharedMemory();
		//GetTimeForDownload ( );
		InitForkProcess ( );
		//SlotInit( GlobShmKey );

		iSockfd = OpenPassiveSocket ( );
		logDebug1("iSockfd returned is %d ", iSockfd );

		strcpy(sKey,getenv("DB_AES_KEYS"));

		if( iSockfd == ERROR )
		{
			logDebug1("Connection To BSE Failed...");
			exit(0);
		}

		OpenMessageQueues();

		RetVal = HandleLogOn();
		if ( RetVal == ERROR)
		{
			logFatal ("Problem In HandleLogOn");
			continue;
			exit(0);
		}

		/*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
		/**
		  PrintStatus ( 1 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_TRADERS_TRADES_REQUEST)==FALSE)
		  {
		  logDebug1("Unable To Process Members Trades Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 2 );

		 **/
		/**	if(QueryPersonalInfo( TC_EQU_BSE_QUERY_ORDERS_REQUEST)==FALSE)
		  {
		  logDebug1(" UNABLE TO PROCESS TC_QUERY_ORDERS_REQUEST");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }***/
		/**
		  PrintStatus ( 3 );
		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_RETURNED_ORDERS_REQUEST)==FALSE)
		  {	
		  logDebug1(" Unable to process Returned Orders Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 4 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_PERSONAL_STOPLOSS_ORDERS)==FALSE)
		  {
		  logDebug1(" Unable To Process Personal Stoploss Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  PrintStatus ( 5 );

		  if(QueryPersonalInfo( TC_EQU_BSE_QUERY_RETURNED_STOPLOSS_ORDERS_REQUEST)==FALSE)
		  {
		  logDebug1(" Unable To Process Returned Stoploss Orders Download");
		  close( iSockfd );
		  logDebug1(" HandleDownload BSEconnect - Terminating - RESTART ");
		  exit(0);
		  }

		  logFatal("Returned StopLoss Order Download over");
		  PrintStatus ( 6 );
		 ***/
		/*****	if(QueryPersonalInfo( TC_EQU_BSE_QUERY_6A7A_REQUEST)==FALSE)
		  {
		  logDebug1("\n Unable To Process 6a7a Reports Download"); 
		  }  ***********/
		/**
		  if(DownloadEnd(TC_EQU_BSE_END_OF_DOWNLOAD)==FALSE)
		  {
		  logDebug1("DownloadEnd: Unable To Process End Of Download");
		  close( iSockfd );
		  exit(0);
		  }

		  logFatal("Download Complete Normal Process Start");

		  PrintStatus ( 7 );
		 ***/
		/*****************************--- To be uncommented in case News From BSe is to be provided****
		  if( QueryNewsCategory(TC_EQU_BSE_NEWS_CATEGORY_REQ)==FALSE)
		  {
		  logDebug1("\n Query News Category: Unable to process the Request ");
		  close ( iSockfd );
		  exit(0);
		  }
		 ****************************/
		logDebug1("Updating Shared Memory to UP for GrpId : %d",iGlobUserGroupId);
		iRetVal = UpdateExchStatus( iGlobUserGroupId,1 );
		if(iRetVal!=TRUE)
		{
			logDebug1("Unable To Update The Shared Memeory exit 1");
			logFatal("Unable To Update The Shared Memeory exit");
			exit(1);
		}
		logDebug1("Forking Into Childs...");

		iMainPID = getpid();

		logDebug1(" Main Process ID :%d:",iMainPID);

		if ( ( ForkInd = fork( )) == 0 )
		{
			logDebug1("RECEIVE-CHILD Forked ...ProcessId Is :%d",getpid());
			ReceiveChild( );
		}

		if ( ForkInd != 0 )
		{
			UpdateForkProcess( RECVCHLD , ForkInd , RUNNING);
		}

		if ( ( ForkInd = fork( ) ) == 0 )
		{
			logDebug1("TRANSMIT-CHILD Forked ...ProcessId Is :%d",getpid());
			TransmitChild ( );
		}

		if (  ForkInd != 0 )
		{
			UpdateForkProcess( TRANSCHLD, ForkInd, RUNNING);
		}

		if ( ( ForkInd = fork( ) ) == 0 )
		{
			logDebug1("KEEPALIVE-CHILD Forked ...ProcessId Is :%d",getpid());
			KeepAliveChild ( );
		}

		if ( ForkInd != 0 )
		{
			UpdateForkProcess( KEEPALIVE, ForkInd, RUNNING);
		}
		/*********

		  if ( ( ForkInd = fork( ) ) == 0 )
		  {
		  logDebug1("\nClientChild  Forked ...ProcessId Is :%d",getpid());
		  ClientChild ( );
		  }
		  if ( ForkInd != 0 )
		  {
		  UpdateForkProcess( CLIENTREGREQ, ForkInd, RUNNING);
		  }
		 **********/
		if( ForkInd != 0)
		{
			sigprocmask ( SIG_BLOCK, &MainSignalSet, NULL);
			while( TRUE )
			{
				logFatal("Successfully Connected To Exchange");
				iMainWait = 0 ;
				/**********
				  sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
				  sigemptyset( &MainSignalSet );
				//sigaddset (  &MainSignalSet , SIGCHLD);
				sigaddset (  &MainSignalSet , SIGUSR1);
				sigaddset (  &MainSignalSet , SIGTERM);
				sigprocmask ( SIG_BLOCK, &MainSignalSet, NULL);
				 ***********/
				logDebug1("Waiting for a Signal");
				iMainWait = sigwait( &MainSignalSet, &Sig);
				logDebug1("Got a Signal");
				sleep(1);

				logDebug1(" Process %d caught signal %d ",getpid(),Sig );	

				//if( Sig == SIGCHLD )
				if( Sig == SIGUSR1)
				{
					logFatal("Connection Went Down");
					logDebug1("Connection Went Down");
					SignalHandlerSigChldMain ( ); 
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					break ;
				}
				if( Sig == SIGTERM )
				{
					logDebug1("Received a signal...");
					logFatal("Application Close Requested");
					SignalHandlerSigTermMain ( Sig ); 
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					break ;
				}

			}
		}
	}/**FOR**/
}

LONG32  OpenPassiveSocket( )
{
	logTimestamp("Entry :OpenPassiveSocket:");
	LONG32  sock = 0 ;
	struct  sockaddr_in ServAddr;
	LONG32  ErrorCount = 0;
	LONG32  RetVal = -1;
	LONG32  MaxTry = 0;

	logDebug1("Inside OpenPassiveSocket..");

	memset( ( CHAR * ) &ServAddr, 0, sizeof ( ServAddr ) );

	do
	{
		if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
		{
			perror("Trying to open Socket Failed :");
			logFatal("Trying to open Socket Failed");
			sleep(1);
			ErrorCount ++;
			continue ;
		}

		if( sock > 0 )
		{
			logDebug1("The IML address is %s ", sImlIPAddress );
			logDebug1("The IML port is %d ", iImlPort );
			ServAddr.sin_family = AF_INET ;
			ServAddr.sin_addr.s_addr = inet_addr(sImlIPAddress);
			ServAddr.sin_port = htons(iImlPort);

			do
			{
				RetVal = connect(sock,(struct sockaddr *) &ServAddr,sizeof(struct sockaddr));
				logDebug1("The Return value is %d",RetVal );
				perror("Error Connecting IML ");

				if ( RetVal == ERROR)
				{
					MaxTry ++;
					sleep(10);
					perror("Connect Failed :");
					close(sock);
					sleep(100);

					if ( (sock = socket(AF_INET,SOCK_STREAM,0)) == ERROR)
					{
						perror("Trying to open Socket Failed :");
						sleep(1);
						ErrorCount ++;
						break;
					}
				}
			}while(RetVal < 0 && MaxTry <= MAX_TRY );
		}
	}while(ErrorCount <= MAX_TRY && sock < 0);

	if(ErrorCount >= MAX_TRY || sock < 0)
	{
		logDebug1("NO SOCKET CONNECTION.....IML NOT UP");
		logDebug1("PLEASE CONTACT SYSTEM ADMINISTRATOR");
		return ERROR;
	}
	logTimestamp("Exit :OpenPassiveSocket:");
	return sock;
}

void    OpenMessageQueues ( )
{
	logTimestamp("Entry  :OpenMessageQueues:");

	if( ( WriteQueue =  OpenMsgQ( ConnToTrdMapBSEEQ)) == ERROR)
	{
		perror("OpenMsgQ :");
		close( iSockfd);
		sleep(10);
		exit( 1 );
	}
	logDebug1(" queue opened WriteQueue");


	if( ( ReadQueue = OpenMsgQ( MapperToConnBSEEQ)) == ERROR)
	{
		perror("OpenMsgQ :");
		close( iSockfd);
		sleep(10);
		exit( 1 );
	}


	logDebug1("The Q ids are WriteQueue=%d,ReadQueue=%d",WriteQueue,ReadQueue);
	logTimestamp("Exit  :OpenMessageQueues:");
	return ;
}

void    PrintStatus ( LONG32 Type )
{
	logTimestamp("Entry :PrintStatus:");
	switch (Type)
	{
		case 1:
			logDebug1("LOGGED ON SUCCESSFULLY DOWNLOAD STARTS HERE....");
			logDebug1("*************************************************************");
			logDebug1("             SENDING REQUEST TRADES DOWNLOAD                ");
			break;
		case 2:
			logDebug1("             TRADES DOWNLOAD COMPLETE                       ");
			logDebug1("*************************************************************");
			logDebug1("             SENDING REQUEST FOR ORDERS DOWNLOAD            ");
			break;
		case 3:
			logDebug1("             ORDERS DOWNLOAD COMPLETED                      ");
			logDebug1("*************************************************************");
			logDebug1("             SENDING REQUEST FOR RETURNED ORDERS DOWNLOAD   ");
			break;
		case 4:
			logDebug1("             RETURNED ORDERS DOWNLOAD COMPLETED             ");
			logDebug1("*************************************************************");
			logDebug1("             SENDING REQUEST FOR STOPLOSS DOWNLOAD ");
			break;
		case 5:
			logDebug1("             PERSONAL STOP LOSS DOWNLOAD COMPLETED");
			logDebug1("*************************************************************");
			logDebug1("             SENDING REQUEST FOR RETURNED STOPLOSS DOWNLOAD ");
			break;
		case 6:
			logDebug1("             RETURNED STOP LOSS DOWNLOAD COMPLETED          ");
			logDebug1("*************************************************************");
			break;
		case 7:
			logDebug1("-------------------------------------------------------------");
			logDebug1("             DOWNLOAD COMPLETED NORMAL PROCESS STARTS       ");
			logDebug1("-------------------------------------------------------------");
			break;
		default :
			return;

	}
	logTimestamp("Exit :PrintStatus:");
}

void    ProcessArguments (LONG32 identifier)
{
	logTimestamp("Entry :ProcessArguments:");
	logTimestamp("Exit :ProcessArguments:");
}

void    InitForkProcess ( )
{
	LONG32  Index;
	logDebug1("Inside InitForkProcess...");
	for( Index =0; Index < MAX_NO_PROCESSES ;Index ++)
	{
		ForkProcess[Index].ProcessId = UNUSED;
		ForkProcess[Index].ProcessStatus = UNUSED;
	}
	return;
}

LONG32	PrepareLogOnPacket()
{
	logTimestamp("Entry :PrepareLogOnPacket:");

	CHAR	sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	struct BSE_MF_LOGIN_REQ *pLogNoReq;
	memset(pLogNoReq,'\0',sizeof(struct BSE_MF_LOGIN_REQ));

	sprintf(sSelQry,"SELECT EAM_EXCH_USER_ID,EAM_BROKER_ID,aes_decrypt(EAM_OLD_PASSWORD,\'%s\'),aes_decrypt(EAM_OLD_PASSWORD,\'%s\'),EAM_WORKSTATION_ADDRESS \
			FROM EXCH_ADMINISTRATION_MASTER WHERE EAM_EXM_EXCH_ID = \'%s\' AND \
			EAM_SEGMENT = \'%c\' AND EAM_GROUP_ID = %d ;",sKey,sKey,BSE_EXCH,MUTUALFUND_SEGMENT,iGlobUserGroupId);

	logDebug2("sSelQry :%s:",sSelQry);	

	if(mysql_query(DB_BseCon,sSelQry) != SUCCESSS)
	{
		logSqlFatal("Error in Select Qry EXCH_ADMINISTRATION_MASTER ");
		sql_Error(DB_BseCon);
		return FALSE;	
	}

	Res = mysql_store_result(DB_BseCon);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(pLogNoReq->sTransCode,"1130",TRANSCODE_LEN);
		strncpy(pLogNoReq->sLoginId,Row[0],LOGIN_ID_LEN);
		strncpy(pLogNoReq->sMemberId,Row[1],MEMBER_ID_LEN);
		strncpy(pLogNoReq->sPassword,Row[2],BSE_MF_PASSWORD_LEN);
		strncpy(pLogNoReq->sNewPassword,Row[3],BSE_MF_PASSWORD_LEN);
		strncpy(pLogNoReq->sStarMFId,Row[4],STAR_MFID_LEN);
	}



	logTimestamp("Exit :PrepareLogOnPacket:");
}
LONG32	HandleLogOn()
{
	logTimestamp("Entry :HandleLogOn:");
	CHAR    *LogOnReq ;
	CHAR    *LogOnResp ;
	LONG32	iPackSize = 0;
	LONG32  iSentBytes,iRecvBytes;


	LogOnReq  = (CHAR *)malloc( BSE_PACKET_SIZE ) ;
	LogOnResp = (CHAR *)malloc( BSE_PACKET_SIZE ) ;

	BOOL	iChkFlag = FALSE;

	if((iChkFlag = PrepareLogOnPacket (LogOnReq )) == TRUE)
	{
		iPackSize = sizeof(struct BSE_MF_LOGIN_REQ);
		iSentBytes = SendPacket(iSockfd,LogOnReq,iPackSize);	

		if(iSentBytes < 0)
		{	
			logFatal("Send Bytes < 0");
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}
	}
	else
	{
		logFatal("Error in PrepareLogOnPacket ");
		free(LogOnReq);
		free(LogOnResp);
		return FALSE;
	}

	do
	{
		logDebug1("Waiting To Receive A Response...");
		RecvBytes = RecvPacket  (iSockfd, LogOnResp );
		logDebug1("Received A packet from Exchange ...");

		if( RecvBytes < 0)
		{
			logDebug1("Error in RecvPacket  ");
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}

		if( RecvBytes == 0)
		{
			free(LogOnReq);
			free(LogOnResp);
			return FALSE;
		}

		if ( (Flag = ReceiveLogOnResp (LogOnResp ,UserId )) == TRUE )
		{
			free(LogOnResp) ;
			free(LogOnReq) ;
			return TRUE;
		}
		else if( Flag == RETRY )
		{
			logDebug1("Entered Retry part..");
			continue ;
		}
		else
		{
			free(LogOnResp) ;
			free(LogOnReq) ;
			return FALSE ;
		}
	}while( Flag == RETRY );

	logTimestamp("Exit :HandleLogOn:");

}

LONG32     UpdateExchStatus ( LONG32 GroupId ,LONG32 status )
{
	LONG32 RetVal ;
	CHAR    ExchStatus;
	CHAR    *sUpdQry = malloc(sizeof(CHAR) *MAX_QUERY_SIZE);

	if( status == 1 )
	{
		ExchStatus = 'R' ;
	}
	else
	{
		ExchStatus = 'N' ;
	}

	logDebug1("Updating the status for Group id %d to :%c",GroupId,ExchStatus);


	sprintf(sUpdQry,"UPDATE EXCH_ADMINISTRATION_MASTER \
			SET\
			EAM_LOGON_STATUS = \'%c\' \
			WHERE EAM_EXM_EXCH_ID = 'BSE'\
			AND EAM_GROUP_ID = %d\
			AND EAM_DRV_FLAG = 'N' ;",ExchStatus,iGlobUserGroupId);

	logDebug2("sUpdQry :%s:",sUpdQry);

	if( mysql_query(DB_BseCon,sUpdQry) != SUCCESS )
	{
		logDebug1(" Updation failed ");
		sql_Error(DB_BseCon);
		mysql_rollback(DB_BseCon);
		return FALSE;
	}

	mysql_commit(DB_BseCon);

	logDebug1("ExchStatus   :%c:",ExchStatus);

	if( ExchStatus == 'R')
	{
		RetVal= fUpdateConnectStatus(BSE_EQU_UP,GroupId  );
	}
	else
	{
		RetVal= fUpdateConnectStatus(BSE_EQU_DOWN,GroupId);
	}
	if(RetVal==TRUE)
	{
		return TRUE ;
	}
	else
	{
		return FALSE;
	}

}

void 	ReceiveChild()
{
	logTimestamp("Entry :ReceiveChild:");
	logTimestamp("Exit :ReceiveChild:");
}

void    UpdateForkProcess ( LONG32 Index, LONG32 ProcessId, LONG32 Status)
{
	logTimestamp("Entry :UpdateForkProcess:");
	ForkProcess[Index].ProcessId = ProcessId ;
	ForkProcess[Index].ProcessStatus = Status ;
	logTimestamp("Exit :UpdateForkProcess:");
	return ;
}
void 	TransmitChild()
{
	logTimestamp("Entry :TransmitChild:");
	logTimestamp("Exit :TransmitChild:");
}
void 	KeepAliveChild()
{
	logTimestamp("Entry :KeepAliveChild:");
	logTimestamp("Exit :KeepAliveChild:");
}


void 	SignalHandlerSigChldMain()
{
	logTimestamp("Entry :SignalHandlerSigChldMain:");
	logTimestamp("Exit :SignalHandlerSigChldMain:");
}
void 	SignalHandlerSigTermMain()
{
	logTimestamp("Entry :SignalHandlerSigTermMain:");
	logTimestamp("Exit :SignalHandlerSigTermMain:");
}

LONG32  SendPacket ( LONG32 sockfd ,CHAR * packet ,size_t size )
{
	logTimestamp("Entry :SendPacket:");
	LONG32 SentBytes,ErrorCount = 1;
	logDebug1("Inside SendPacket... sockfd passed is %d", sockfd );
	logDebug1(" Size is %d ", size );
	do
	{
		SentBytes = send ( sockfd, packet, size , 0 );
		if (SentBytes < 0)
		{
			logDebug1("There is some error...");
			perror("TCP Send Problem :");
			ErrorCount ++;
		}
	}
	while((SentBytes < 0)&&(ErrorCount < BREAKCOUNTER));

	if( (SentBytes < 0) && (ErrorCount >= BREAKCOUNTER))
	{
		logFatal("Found A Persistent Problem While Sending");
		exit(0) ;
	}
	logTimestamp("Exit :SendPacket:");
	return(SentBytes);
}

LONG32  ReceiveLogOnResp (CHAR *LogOnResp,LONG32 UserId )
{

	logTimestamp("Entry :ReceiveLogOnResp:");
	LONG32 sockfd ;
	LONG32 Transcode,SentBytes = 0 ;
	CHAR    *SndMsg;
	CHAR    *Packet;
	LONG32  iPacketSize;
	BOOL	iFlag =FALSE ;
	LONG32  iRetVal = FALSE ;
	LONG32  iRecvBytes = 0;
	BOOL 	iResult = ERROR;

	CHAR	sUpdtQry[MAX_QUERY_SIZE];

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	struct BSE_MF_LOGIN_RESP	*pLogOnResp;
	memset(pLogOnResp,'\0',sizeof(struct BSE_MF_LOGIN_RESP));
	memset(sUpdtQry,'\0',MAX_QUERY_SIZE);


	if(strcmp(pLogOnResp->sReply_Code,"0") == 0)
	{
		sprintf(sUpdtQry,"UPDATE EXCH_ADMINISTRATION_MASTER SET EAM_LOGON_STATUS = 'A',EAM_REASON_DESC='Connected' WHERE EAM_EXM_EXCH_ID = \"%s\" and EAM_SEGMENT = \'%c\' AND EAM_GROUP_ID = %d ;",BSE_EXCH,);	
	}	

	logTimestamp("Exit :ReceiveLogOnResp:");
}
