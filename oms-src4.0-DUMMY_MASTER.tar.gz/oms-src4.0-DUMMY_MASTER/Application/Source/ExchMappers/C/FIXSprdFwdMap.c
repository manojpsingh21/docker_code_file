#include <malloc.h>
#include <string.h>
#include <sys/time.h>
#include "IPCS.h"

EXCH_CFG_FILE_STRUCT ExchCfgStruct[CFG_STRUCT_LEN];

SHORT  fTrim( CHAR *string , SHORT MaxLen );
BOOL MapToFIXString(CHAR *pMemIn , CHAR *pMemOut );
BOOL MapToHeader(FIX_HEADER *fixHeader , CHAR *pMemOut );
BOOL NewOrderRequest( FIX_NEW_ORDER_REQUEST *fixNewOrderRequest, CHAR *pMemOut);
BOOL ModifyOrderRequest( FIX_ORDER_MODIFICATION_REQUEST *fixModOrderRequest, CHAR *pMemOut);
BOOL CancelOrderRequest( FIX_ORDER_CANCEL_REQUEST *fixCanOrderRequest, CHAR *pMemOut );

LONG32 main(LONG32 argc , CHAR **argv)
{
	logTimestamp("Entry : [main]");

	LONG32		iReadQID =0;
	LONG32		iSendQID =0;
	LONG32		iLoop = 1;
	CHAR		sRcvMsg[RUPEE_MAX_PACKET_SIZE] ;
	CHAR		fixString[RUPEE_MAX_PACKET_SIZE];
	CHAR		cChoice;
	INT16		iQMsgType;
	INT_HEADER *pHeaderIn  ;
	FIX_NEW_ORDER_REQUEST *fixNew;/**Delete this after option attribute is pasted***/
	LONG32		iSysdate=0;
	BOOL		iRetVal = TRUE;
	setbuf ( stdout, NULL);
	setbuf ( stdin , NULL);
	setvbuf( stdout, NULL, _IONBF, 0 );


	cChoice = argv[2][0];
	switch(cChoice)
	{
		case EQUITY_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToFwdMapNSEEQ )) == ERROR)
			{
				logFatal(" Leaving [Main] RE");
				exit(ERROR);
			}
			logInfo(" OrdSrvToFwdMapNSEEQ Queue Id = %d", iReadQID);

			logDebug1(" Opening Queue FwdMapToInterfaceNSEEQ");
			if((iSendQID = OpenMsgQ( FwdMapToInterfaceNSEEQ )) == ERROR)
			{
				logFatal(" Leaving [Main] SE");
				exit(ERROR);
			}
			logDebug1(" FwdMapToInterfaceNSEEQ Queue Id = %d", iSendQID);
			break;
		case DERIVATIVE_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToFwdMapNSEDR )) == ERROR)
			{
				logFatal(" Leaving [Main] RD");
				exit(ERROR);
			}
			logDebug1(" OrdSrvToFwdMapNSEDR Queue Id = %d", iReadQID);

			logInfo(" Opening Queue OrdSrvToFwdMapNSEDR");
			if((iSendQID = OpenMsgQ( FwdMapToInterfaceNSEDR )) == ERROR)
			{
				logFatal(" Leaving [Main] SD");
				exit(ERROR);
			}
			logDebug1(" FwdMapToInterfaceNSEDR Queue Id = %d", iSendQID);
			break;

		case CURRENCY_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToFwdMapNSECR )) == ERROR)
			{
				logFatal(" Leaving [Main] RC");
				exit(ERROR);
			}
			logDebug1(" OrdSrvToFwdMapNSECR Queue Id = %d", iReadQID);

			logInfo(" Opening Queue FwdMapToInterfaceNSECR");
			if((iSendQID = OpenMsgQ( FwdMapToInterfaceNSECR )) == ERROR)
			{
				logFatal(" Leaving [Main] SC");
				exit(ERROR);
			}
			logDebug1(" FwdMapToInterfaceNSECR Queue Id = %d", iSendQID);
			break;
		case COMMODITY_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToFwdMapMCX )) == ERROR)
			{
				logFatal(" Leaving [Main] RM");
				exit(ERROR);
			}
			logDebug1(" OrdSrvToFwdMapMCXCM Queue Id = %d", iReadQID);

			logInfo(" Opening Queue FwdMapToInterfaceMCXCM");
			if((iSendQID = OpenMsgQ( FwdMapToInterfaceMCX )) == ERROR)
			{
				logFatal(" Leaving [Main] SM");
				exit(ERROR);
			}
			logDebug1(" FwdMapToInterfaceMCXCM Queue Id = %d", iSendQID);
			break;
	}

	logDebug1 (" DP : %s",argv[1]);
	iRetVal = LoadFile (argv[1]);
	if ( iRetVal == FALSE )
	{
		logFatal(" File loading failed.");
		exit(ERROR);
	}
	Display();

	while(TRUE)
	{
		logDebug1(" ----------------- IN LOOP : %d -----------------", iLoop++);
		logDebug1(" Waiting on Queue %d",iReadQID);

		memset(fixString, 0, RUPEE_MAX_PACKET_SIZE);
		memset(sRcvMsg, 0, RUPEE_MAX_PACKET_SIZE);
		iQMsgType = 0;

		if((ReadMsgQ( iReadQID, (CHAR *) &sRcvMsg, RUPEE_MAX_PACKET_SIZE , 1)) != 1)
		{
			logFatal(" Leaving [Main]");
			exit(ERROR);
		}

		pHeaderIn = (INT_HEADER *)&sRcvMsg;
		fixNew 	  = (FIX_NEW_ORDER_REQUEST *)&sRcvMsg;
		iQMsgType = pHeaderIn->iQMsgType;

		logDebug1("**************Here OptAttribute [%c]********************",fixNew->cOptAttribute);
		logDebug1(" Mapping For MsgCode = %d", pHeaderIn->iMsgCode);


		if( MapToFIXString( (CHAR *)&sRcvMsg , (CHAR *)&fixString) == TRUE )
		{
			logInfo(" Mapping Complete");
			logDebug3(" Final String = :%s:", fixString);

			logDebug1(" Msg Queue Type iQMsgType :%d: pHeaderIn->iQMsgType :%d:",iQMsgType,pHeaderIn->iQMsgType );
			if(WriteMsgQ(iSendQID,&fixString, strlen(fixString),iQMsgType) != 1)
			{
				logFatal(" Leaving [Main]");
				exit(ERROR);
			}

			logInfo(" Sent to Interface");
		}
		else
		{
			logDebug2(" Mapping Failed");
		}

	}                                               /*** End of While Loop ***/
	logTimestamp("Exit : [main]");
}                                                   /*** End of main ***/

BOOL MapToFIXString(CHAR *pMemIn , CHAR *pMemOut )
{
	logTimestamp("Entry : [MapToFIXString]");	


	LONG32 iMsgCode = 0;
	INT_HEADER *pHeader = ( INT_HEADER *) pMemIn ;
	iMsgCode = pHeader->iMsgCode;
	logDebug3(" pHeader->iMsgCode is :%d:",pHeader->iMsgCode);
	logDebug3(" iMsgCode is :%i:",iMsgCode);

	if(iMsgCode == TC_INT_ORDER_ENTRY_REQ )
	{
		FIX_NEW_ORDER_REQUEST *fixNewOrderRequest = ( FIX_NEW_ORDER_REQUEST *) pMemIn ;
		logDebug3("fixNewOrderRequest->cOptAttribute [%c]",fixNewOrderRequest->cOptAttribute);
		if( NewOrderRequest( fixNewOrderRequest, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}
	else if(iMsgCode == TC_INT_ORDER_MODIFY )
	{

		FIX_ORDER_MODIFICATION_REQUEST *fixModOrderRequest = ( FIX_ORDER_MODIFICATION_REQUEST *) pMemIn ;
		logDebug2("Nitish in Drv Modification");

		if( ModifyOrderRequest( fixModOrderRequest, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}
	else if(iMsgCode == TC_INT_ORDER_CANCEL )
	{
		FIX_ORDER_CANCEL_REQUEST *fixCanOrderRequest = ( FIX_ORDER_CANCEL_REQUEST *) pMemIn ;

		if( CancelOrderRequest( fixCanOrderRequest, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}
	else if(iMsgCode == TC_INT_SPREAD_OE_REQ)
	{
		FIX_SPREAD_NEW_ORDER_REQUEST	*fixSprdNewOrdReq = (FIX_SPREAD_NEW_ORDER_REQUEST *)pMemIn;
		if( NewSpreadOrderRequest( fixSprdNewOrdReq , pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}
	else if(iMsgCode == TC_INT_SPREAD_OM_REQ || iMsgCode == TC_INT_SPREAD_OC_REQ)
	{
		FIX_SPREAD_MODCANCEL_ORDER_REQUEST *fixSprdModCanOrdReq = (FIX_SPREAD_MODCANCEL_ORDER_REQUEST *)pMemIn;	
		if(ModCanSpreadOrderRequest( fixSprdModCanOrdReq, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
		}       return FALSE;

	}
	else
	{
		logDebug3(" Unknown iMsgCode %d", iMsgCode);
		logDebug3(" Leaving [MapToFIXString]:<FALSE>");
		return FALSE;
	}

}/**** End of MapToFIXString ****/
BOOL MapToHeader(FIX_HEADER *fixHeader , CHAR *pMemOut )
{
	logTimestamp("Entry : [MapToHeader]");

	CHAR temp[RUPEE_MAX_PACKET_SIZE];
	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);

	sprintf(temp, "8=%s%c", fixHeader->sBeginString, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);

	fTrim(fixHeader->sMsgType, strlen(fixHeader->sMsgType));
	sprintf(temp, "35=%s%c", fixHeader->sMsgType, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);
	fTrim(fixHeader->sSenderCompID, strlen(fixHeader->sSenderCompID));
	sprintf(temp, "49=%s%c", fixHeader->sSenderCompID, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);
	logInfo("darshan : %s ",fixHeader->sTargetCompID);
	fTrim(fixHeader->sTargetCompID, strlen(fixHeader->sTargetCompID));
	sprintf(temp, "56=%s%c", fixHeader->sTargetCompID, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);

}/**** End of MapToHeader *****/

BOOL NewOrderRequest( FIX_NEW_ORDER_REQUEST *fixNewOrderRequest, CHAR *pMemOut)
{
	logTimestamp("Entry : [NewOrderRequest]");

	CHAR	temp[RUPEE_MAX_PACKET_SIZE];
	CHAR	temp1[RUPEE_MAX_PACKET_SIZE];

	LONG32	i,j ;
	CHAR	sSenderSubId[ENTITY_ID_LEN];

	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);
	memset(temp1, 0, RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId, 0, ENTITY_ID_LEN);


	if( MapToHeader( &(fixNewOrderRequest->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [NewOrderRequest]:<FALSE>");
		return FALSE;
	}

	strncpy(sSenderSubId,fixNewOrderRequest->FIXHeader.sSenderSubID,strlen(fixNewOrderRequest->FIXHeader.sSenderSubID));
	logDebug2(" SenderSub id = [%s]",sSenderSubId );
	logDebug2(" CFG_STRUCT_LEN = [%d]",CFG_STRUCT_LEN );
	printf("\n fixNewOrderRequest->cOptAttribute [%c]",fixNewOrderRequest->cOptAttribute);


	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'D' )
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{
				logDebug3(" The tag [%d]",ExchCfgStruct[i].iTagList[j]);

				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 11:
						fTrim(fixNewOrderRequest->sClOrdId, strlen(fixNewOrderRequest->sClOrdId));
						logDebug3(" DP ClOrdId Before: %s",fixNewOrderRequest->sClOrdId);
						sprintf(temp, "11=%s%c", fixNewOrderRequest->sClOrdId, FIX_FIELD_DELIMITER);
						logDebug3(" DP ClOrdId After: %s",temp);
						strcat(pMemOut, temp);
						break;

					case 1:
						fTrim(fixNewOrderRequest->sAccount, strlen(fixNewOrderRequest->sAccount));
						sprintf(temp, "1=%s%c", fixNewOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 21:
						logDebug3(" fixNewOrderRequest->cHandlInst :%c: :%c:",fixNewOrderRequest->cHandlInst,fixNewOrderRequest->cHandlInst);
						sprintf(temp, "21=%c%c", fixNewOrderRequest->cHandlInst, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 59:
						sprintf(temp, "59=%c%c", fixNewOrderRequest->cTimeInForce, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 110:
						if(fixNewOrderRequest->fMinQty != 0)
						{
							sprintf(temp, "110=%.0lf%c", fixNewOrderRequest->fMinQty, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 111:
						if(fixNewOrderRequest->fMaxFloor != 0)
						{
							sprintf(temp, "111=%.0lf%c", fixNewOrderRequest->fMaxFloor, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 55:
						logDebug3(" 55 : %s",fixNewOrderRequest->sSymbol);
						fTrim(fixNewOrderRequest->sSymbol, strlen(fixNewOrderRequest->sSymbol));
						logDebug3(" 55 : %s",fixNewOrderRequest->sSymbol);
						sprintf(temp, "55=%s%c", fixNewOrderRequest->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 65:
						fTrim(fixNewOrderRequest->sSymbolSfx, strlen(fixNewOrderRequest->sSymbolSfx));
						logDebug3(" 65 : %s",fixNewOrderRequest->sSymbolSfx);
						sprintf(temp, "65=%s%c", fixNewOrderRequest->sSymbolSfx, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 48:
						fTrim(fixNewOrderRequest->sSecurityId, strlen(fixNewOrderRequest->sSecurityId));
						logDebug2("Sec-Id is:%s:",fixNewOrderRequest->sSecurityId);
						sprintf(temp, "48=%s%c", fixNewOrderRequest->sSecurityId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 22:
						fTrim(fixNewOrderRequest->sIdSource,strlen(fixNewOrderRequest->sIdSource));
						sprintf(temp,"22=%s%c",fixNewOrderRequest->sIdSource,FIX_FIELD_DELIMITER);
						strcat(pMemOut,temp);
						break;

					case 54:
						sprintf(temp, "54=%c%c", fixNewOrderRequest->cSide, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 60:
						fTrim(fixNewOrderRequest->sTransactTime, strlen(fixNewOrderRequest->sTransactTime));
						sprintf(temp, "60=%s%c", fixNewOrderRequest->sTransactTime, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 38:
						sprintf(temp, "38=%.0lf%c", fixNewOrderRequest->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 40:
						sprintf(temp, "40=%c%c", fixNewOrderRequest->cOrderType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);

						if ( (fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_LIMIT) || (fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT) )
						{
							sprintf(temp, "44=%lf%c", fixNewOrderRequest->fPrice, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}

						if ( fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLOSS || fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT)
						{
							sprintf(temp,"99=%lf%c",fixNewOrderRequest->fStopPx,FIX_FIELD_DELIMITER);
							//							sprintf(temp,"99=%.0lf%c",fixNewOrderRequest->fStopPx,FIX_FIELD_DELIMITER);
							strcat(pMemOut,temp);
						}
						break;

					case 47:
						sprintf(temp, "47=A%c",  FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
						/** Tag 126 : ExpireDate : Not needed as ExpireDate is already there. ***/

					case 432:
						if ( fixNewOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{
							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
							strncpy(temp1,fixNewOrderRequest->sExpireDate,8);
							temp1[8] = 0;
							sprintf(temp, "432=%s%c", temp1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;

					case 126:
						if ( fixNewOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{
							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
							sprintf(temp, "432=%s%c", fixNewOrderRequest->sExpireDate, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 376:
						fTrim(fixNewOrderRequest->sComplianceID,strlen(fixNewOrderRequest->sComplianceID));
						sprintf(temp, "376=%s%c", fixNewOrderRequest->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 58:
						fTrim(fixNewOrderRequest->sText, TEXT_LEN);
						if( strcmp(fixNewOrderRequest->sText, "") != 0 )
						{
							sprintf(temp, "58=%s%c", fixNewOrderRequest->sText, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 204:
						sprintf(temp, "204=%d%c", fixNewOrderRequest->iCustomerOrFirm, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 440:
						sprintf(temp, "440=%s%c", fixNewOrderRequest->sClearingFirm, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 453:
						sprintf(temp, "453=1%c", FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 448:
						sprintf(temp, "448=%s%c", fixNewOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 452:
						sprintf(temp, "452=3%c", FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;


					case 9227:
						logDebug3(" fixNewOrderRequest->sTerminalInfo :%s:",fixNewOrderRequest->sTerminalInfo);
						sprintf(temp, "9227=%s%c", fixNewOrderRequest->sTerminalInfo, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 167:
						if((strncmp(fixNewOrderRequest->sSecurityType,OPTION,3)==0)||(strncmp(fixNewOrderRequest->sSecurityType,FUTURE,3)==0))
						{

							sprintf(temp, "200=%s%c",fixNewOrderRequest->sMaturityMonthYear,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "167=%s%c",fixNewOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "205=%s%c",fixNewOrderRequest->sMaturityDay,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							if(strncmp(fixNewOrderRequest->sSecurityType,OPTION,3) == 0)
							{
								logDebug2("fixNewOrderRequest->fStrikePrice :%lf: :%.0lf:",fixNewOrderRequest->fStrikePrice,fixNewOrderRequest->fStrikePrice);
								//sprintf(temp, "202=%lf%c",fixNewOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								sprintf(temp, "202=%lf%c",fixNewOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
								printf("\n fixNewOrderRequest->cOptAttribute [%c]",fixNewOrderRequest->cOptAttribute);
								sprintf(temp, "206=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "201=%d%c",fixNewOrderRequest->iPutOrCall,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);	

								sprintf(temp,"460=%d%c",fixNewOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);


							}
							else if(strncmp(fixNewOrderRequest->sSecurityType,FUTURE,3) == 0)
							{
								sprintf(temp,"460=%d%c",fixNewOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
							}


						}	
						else
						{
							sprintf(temp, "167=%s%c",fixNewOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;				
				}/**** End of Switch Case *****/
			}/**** End of for loop 2 ****/
			break;
		}/**** End of if Statement *****/
	}/***** End of for loop 1 ****/
	logDebug3(" Leaving [NewOrderRequest]:<TRUE>");
	return TRUE;
}/**** End of NewOrderRequest ****/

BOOL ModifyOrderRequest(FIX_ORDER_MODIFICATION_REQUEST *fixModOrderRequest, CHAR *pMemOut)
{
	logTimestamp("Entry : [ModifyOrderRequest]");


	CHAR temp[RUPEE_MAX_PACKET_SIZE];
	SHORT iNoTradingSessions =0;
	CHAR temp1[RUPEE_MAX_PACKET_SIZE];
	LONG32  i,j ;
	CHAR    sSenderSubId[ENTITY_ID_LEN];


	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);
	memset(temp1, 0, RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId, 0, ENTITY_ID_LEN);

	if( MapToHeader( &(fixModOrderRequest->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [ModifyOrderRequest]:<FALSE>");
		return FALSE;
	}

	strncpy(sSenderSubId,fixModOrderRequest->FIXHeader.sSenderSubID,strlen(fixModOrderRequest->FIXHeader.sSenderSubID));
	logDebug3(" SenderSub id = [%s]",sSenderSubId );	
	logDebug3(" MaturityDay_is = [%s]",fixModOrderRequest->sMaturityDay);
	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{

		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'G' )
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{

				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 37:
						fTrim(fixModOrderRequest->sOrderID, strlen(fixModOrderRequest->sOrderID));
						sprintf(temp, "37=%s%c", fixModOrderRequest->sOrderID, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 41:
						fTrim(fixModOrderRequest->sOrigClOrdId, strlen(fixModOrderRequest->sOrigClOrdId));
						sprintf(temp, "41=%s%c", fixModOrderRequest->sOrigClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 11:
						fTrim(fixModOrderRequest->sClOrdId, strlen(fixModOrderRequest->sClOrdId));
						sprintf(temp, "11=%s%c", fixModOrderRequest->sClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 1:
						fTrim(fixModOrderRequest->sAccount, strlen(fixModOrderRequest->sAccount));
						sprintf(temp, "1=%s%c", fixModOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 21:
						sprintf(temp, "21=%c%c", fixModOrderRequest->cHandlInst, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 110:
						if(fixModOrderRequest->fMinQty != 0)
						{
							sprintf(temp, "110=%.0lf%c", fixModOrderRequest->fMinQty, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 111:
						if(fixModOrderRequest->fMaxFloor != 0)
						{
							sprintf(temp, "111=%.0lf%c", fixModOrderRequest->fMaxFloor, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 55:
						fTrim(fixModOrderRequest->sSymbol, strlen(fixModOrderRequest->sSymbol));
						sprintf(temp, "55=%s%c", fixModOrderRequest->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 65:
						printf("\n In Here 65 : %s",fixModOrderRequest->sSymbolSfx);
						fTrim(fixModOrderRequest->sSymbolSfx, strlen(fixModOrderRequest->sSymbolSfx));
						sprintf(temp, "65=%s%c", fixModOrderRequest->sSymbolSfx, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 376:
						fTrim(fixModOrderRequest->sComplianceID,strlen(fixModOrderRequest->sComplianceID));
						sprintf(temp, "376=%s%c", fixModOrderRequest->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 204:
						sprintf(temp, "204=%d%c",fixModOrderRequest->iCustomerOrFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 440:
						fTrim(fixModOrderRequest->sClearingFirm,strlen(fixModOrderRequest->sClearingFirm));
						sprintf(temp, "440=%s%c", fixModOrderRequest->sClearingFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 6000:
						fTrim(fixModOrderRequest->sLastModTime,strlen(fixModOrderRequest->sLastModTime));
						sprintf(temp, "6000=%s%c", fixModOrderRequest->sLastModTime,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 14:
						sprintf(temp, "14=%d%c", fixModOrderRequest->dCumQty, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 48:
						fTrim(fixModOrderRequest->sSecurityId, strlen(fixModOrderRequest->sSecurityId));
						sprintf(temp, "48=%s%c", fixModOrderRequest->sSecurityId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 22:
						fTrim(fixModOrderRequest->sIdSource,strlen(fixModOrderRequest->sIdSource));
						sprintf(temp,"22=%s%c",fixModOrderRequest->sIdSource,FIX_FIELD_DELIMITER);
						strcat(pMemOut,temp);
						break;

					case 54:
						logDebug3(" In Here 54 : %c",fixModOrderRequest->cSide);
						sprintf(temp, "54=%c%c", fixModOrderRequest->cSide, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 60:
						fTrim(fixModOrderRequest->sTransactTime, strlen(fixModOrderRequest->sTransactTime));
						sprintf(temp, "60=%s%c", fixModOrderRequest->sTransactTime, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 38:
						sprintf(temp, "38=%.0lf%c", fixModOrderRequest->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 40:
						sprintf(temp, "40=%c%c", fixModOrderRequest->cOrderType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);

						logDebug3(" fixModOrderRequest->cOrderType :%c:",fixModOrderRequest->cOrderType);

						logDebug3(" FIX_ORD_TYPE_LIMIT:%c:,FIX_ORD_TYPE_STOPLIMIT:%c:,FIX_ORD_TYPE_STOPLOSS:%c:,FIX_ORD_TYPE_STOPLIMIT:%c:",FIX_ORD_TYPE_LIMIT,FIX_ORD_TYPE_STOPLIMIT,FIX_ORD_TYPE_STOPLOSS,FIX_ORD_TYPE_STOPLIMIT);

						if ( fixModOrderRequest->cOrderType == FIX_ORD_TYPE_LIMIT || fixModOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT )
						{
							sprintf(temp, "44=%lf%c", fixModOrderRequest->fPrice, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}

						if ( fixModOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLOSS || fixModOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT)
						{
							sprintf(temp,"99=%lf%c",fixModOrderRequest->fStopPx,FIX_FIELD_DELIMITER);
							strcat(pMemOut,temp);
						}
						break;

					case 59:
						sprintf(temp, "59=%c%c", fixModOrderRequest->cTimeInForce, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 47:
						sprintf(temp, "47=A%c",  FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 126:
						if ( fixModOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{

							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
							strcpy(temp,fixModOrderRequest->sExpireTime);
							sprintf(temp, "126=%s%c", fixModOrderRequest->sExpireTime, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
						}
						break;

					case 432:
						if ( fixModOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{

							strncpy(temp1,fixModOrderRequest->sExpireTime,8);
							temp1[8] = 0;
							sprintf(temp, "432=%s%c",temp1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 100:
						if( strcmp(fixModOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixModOrderRequest->sSecurityEx,strlen(fixModOrderRequest->sSecurityEx));
							sprintf(temp, "100=%s%c", fixModOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 207:
						if( strcmp(fixModOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixModOrderRequest->sSecurityEx,strlen(fixModOrderRequest->sSecurityEx));
							sprintf(temp, "207=%s%c", fixModOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 15:
						fTrim(fixModOrderRequest->sCurrency,strlen(fixModOrderRequest->sCurrency));
						sprintf(temp, "15=%s%c", fixModOrderRequest->sCurrency,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 453:
						sprintf(temp, "453=1%c", FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 448:
						sprintf(temp, "448=%s%c", fixModOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 452:
						sprintf(temp, "452=3%c", FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 167:
						if((strcmp(fixModOrderRequest->sSecurityType,OPTION)==0)||(strcmp(fixModOrderRequest->sSecurityType,FUTURE)==0))
						{
							/*	sprintf(temp, "203=%c%c",fixModOrderRequest->cCoverUncover,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);*/

							/*	sprintf(temp, "77=%c%c",fixModOrderRequest->cOpenCloseFlg,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);*/

							logDebug2("sMaturityMonthYear :%s: sSecurityType :%s: sMaturityDay :%s:",fixModOrderRequest->sMaturityMonthYear,fixModOrderRequest->sSecurityType,fixModOrderRequest->sMaturityDay);

							sprintf(temp, "200=%s%c",fixModOrderRequest->sMaturityMonthYear,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							logDebug2("This is halfstr 1:%s:",pMemOut);

							sprintf(temp, "167=%s%c",fixModOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
							logDebug2("This is halfstr 2:%s:",pMemOut);

							sprintf(temp, "205=%s%c",fixModOrderRequest->sMaturityDay,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							if(strcmp(fixModOrderRequest->sSecurityType,OPTION) == 0)
							{
								logDebug2("fixModOrderRequest->fStrikePrice :%.0lf:",fixModOrderRequest->fStrikePrice);
								sprintf(temp, "202=%lf%c",fixModOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "206=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "201=%d%c",fixModOrderRequest->iPutOrCall,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								/*		sprintf(temp, "204=1%c",FIX_FIELD_DELIMITER);

										strcat(pMemOut, temp);*/

								sprintf(temp,"460=%d%c",fixModOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "77=%c%c",fixModOrderRequest->cOpenCloseFlg,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);


							}
							else if(strncmp(fixModOrderRequest->sSecurityType,FUTURE,3)==0)
							{
								sprintf(temp,"460=%d%c",fixModOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
							}



						}
						else
						{
							sprintf(temp, "167=%s%c",fixModOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;


				}/*** End of switch ***/
			}/*** End of for loop 2 ****/
			break;
		}/*** End of if *****/
	}/*** End of for loop 1 ****/

	logDebug3(" Leaving [ModifyOrderRequest]:<TRUE>");
	return TRUE;

}/*** End of ModifyOrderRequest ****/

BOOL CancelOrderRequest( FIX_ORDER_CANCEL_REQUEST *fixCanOrderRequest, CHAR *pMemOut )
{
	logTimestamp("Entry : [CancelOrderRequest]");

	CHAR	temp[RUPEE_MAX_PACKET_SIZE];
	LONG32	i,j ;
	CHAR	sSenderSubId[ENV_VARIABLE_LEN];

	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId, 0, ENV_VARIABLE_LEN);


	if( MapToHeader (&( fixCanOrderRequest->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [CancelOrderRequest]:<FALSE>");
		return FALSE;
	}

	strncpy(sSenderSubId,fixCanOrderRequest->FIXHeader.sSenderSubID,ENV_VARIABLE_LEN);
	logInfo(" SenderSub id = [%s]",sSenderSubId );
	logInfo(" SenderSub id = [%s]",fixCanOrderRequest->FIXHeader.sSenderSubID );
	logInfo(" CFG_STRUCT_LEN = [%i]",CFG_STRUCT_LEN );

	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'F' )
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{
				logInfo(" Cancellation order Tags : [%d]",ExchCfgStruct[i].iTagList[j]);
				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 41:
						fTrim(fixCanOrderRequest->sOrigClOrdId, strlen(fixCanOrderRequest->sOrigClOrdId));
						logDebug1(" 41 : %s",fixCanOrderRequest->sOrigClOrdId);
						sprintf(temp, "41=%s%c", fixCanOrderRequest->sOrigClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 37:
						fTrim(fixCanOrderRequest->sOrderID, strlen(fixCanOrderRequest->sOrderID));
						logDebug1(" 37 : %s",fixCanOrderRequest->sOrderID);
						sprintf(temp, "37=%s%c", fixCanOrderRequest->sOrderID, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 11:
						fTrim(fixCanOrderRequest->sClOrdId, strlen(fixCanOrderRequest->sClOrdId));
						logDebug1(" 11 : %s",fixCanOrderRequest->sClOrdId);
						sprintf(temp, "11=%s%c", fixCanOrderRequest->sClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 1:
						fTrim(fixCanOrderRequest->sAccount, strlen(fixCanOrderRequest->sAccount));
						logDebug1(" 1 : %s",fixCanOrderRequest->sAccount);
						sprintf(temp, "1=%.12s%c", fixCanOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 22:
						fTrim(fixCanOrderRequest->sIdSource,strlen(fixCanOrderRequest->sIdSource));
						logDebug1(" 22 : %s",fixCanOrderRequest->sIdSource);
						sprintf(temp,"22=%s%c",fixCanOrderRequest->sIdSource,FIX_FIELD_DELIMITER);
						strcat(pMemOut,temp);
						break;

					case 48:
						fTrim(fixCanOrderRequest->sSecurityId, strlen(fixCanOrderRequest->sSecurityId));
						logDebug1(" 48 : %s",fixCanOrderRequest->sSecurityId);
						sprintf(temp, "48=%s%c", fixCanOrderRequest->sSecurityId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 55:
						fTrim(fixCanOrderRequest->sSymbol, strlen(fixCanOrderRequest->sSymbol));
						logDebug1(" 55 : %s",fixCanOrderRequest->sSymbol);
						sprintf(temp, "55=%s%c", fixCanOrderRequest->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 54:
						logDebug1(" 54 : %c",fixCanOrderRequest->cSide);
						sprintf(temp, "54=%c%c", fixCanOrderRequest->cSide, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 65:
						logDebug1(" In Here 65 : %s",fixCanOrderRequest->sSymbolSfx);
						fTrim(fixCanOrderRequest->sSymbolSfx, strlen(fixCanOrderRequest->sSymbolSfx));
						sprintf(temp, "65=%s%c", fixCanOrderRequest->sSymbolSfx, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 40:
						sprintf(temp, "40=%c%c", fixCanOrderRequest->cOrderType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 60:
						fTrim(fixCanOrderRequest->sTransactTime, FIX_DATE_TIME_LEN);
						logDebug1(" 60 : %s",fixCanOrderRequest->sTransactTime);
						sprintf(temp, "60=%s%c", fixCanOrderRequest->sTransactTime, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 38:
						logDebug1(" 38 : %f",fixCanOrderRequest->fQuantity);
						sprintf(temp, "38=%.0lf%c", fixCanOrderRequest->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 100:
						if( strcmp(fixCanOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixCanOrderRequest->sSecurityEx,strlen(fixCanOrderRequest->sSecurityEx));
							sprintf(temp, "100=%s%c", fixCanOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 207:
						if( strcmp(fixCanOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixCanOrderRequest->sSecurityEx,strlen(fixCanOrderRequest->sSecurityEx));
							sprintf(temp, "207=%s%c", fixCanOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 376:
						fTrim(fixCanOrderRequest->sComplianceID,strlen(fixCanOrderRequest->sComplianceID));
						sprintf(temp, "376=%s%c", fixCanOrderRequest->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 77:
						sprintf(temp, "77=%c%c",fixCanOrderRequest->cOpenCloseFlg,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break ;

					case 203:
						sprintf(temp, "203=%c%c",fixCanOrderRequest->cCoverUncover,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 167:
						if((strcmp(fixCanOrderRequest->sSecurityType,OPTION)==0)||(strcmp(fixCanOrderRequest->sSecurityType,FUTURE)==0))
						{

							sprintf(temp, "200=%s%c",fixCanOrderRequest->sMaturityMonthYear,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "167=%s%c",fixCanOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "205=%s%c",fixCanOrderRequest->sMaturityDay,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							if(strcmp(fixCanOrderRequest->sSecurityType,OPTION) == 0)
							{
								logDebug2("fixCanOrderRequest->fStrikePrice :%.0lf:",fixCanOrderRequest->fStrikePrice);
								sprintf(temp, "202=%lf%c",fixCanOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "206=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "201=%d%c",fixCanOrderRequest->iPutOrCall,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);


								sprintf(temp,"460=%d%c",fixCanOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

							}
							else if(strncmp(fixCanOrderRequest->sSecurityType,FUTURE,3)==0)
							{
								sprintf(temp,"460=%d%c",fixCanOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
							}							

						}
						else
						{
							sprintf(temp, "167=%s%c",fixCanOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;

					default :
						logDebug3("Invalid Tag");

				}/**** End of switch ****/
			}/***** for loop 2 ****/
			break;
		}
	}
	logTimestamp("Exit : [CancelOrderRequest]");
	return TRUE;

}/***** END of CancelOrderRequest *****/

BOOL NewSpreadOrderRequest( FIX_SPREAD_NEW_ORDER_REQUEST *fixSprdNewOrdReq , CHAR *pMemOut)
{
	logTimestamp("Entry : [NewSpreadOrderRequest]");
	CHAR    temp[RUPEE_MAX_PACKET_SIZE];
	//	CHAR    temp1[RUPEE_MAX_PACKET_SIZE];
	LONG32  i,j,iCount=0 ;
	CHAR    sSenderSubId[ENTITY_ID_LEN];

	memset(temp,'\0', RUPEE_MAX_PACKET_SIZE);
	//      memset(temp1,'\0', RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId,'\0',ENTITY_ID_LEN);

	if( MapToHeader( &(fixSprdNewOrdReq->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [NewOrderRequest]:<FALSE>");
		return FALSE;
	}
	strncpy(sSenderSubId,fixSprdNewOrdReq->FIXHeader.sSenderSubID,strlen(fixSprdNewOrdReq->FIXHeader.sSenderSubID));
	logDebug2(" SenderSub id = [%s]",sSenderSubId );
	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'X' )  /*here*/
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{
				logDebug2(" The tag [%d]",ExchCfgStruct[i].iTagList[j]);
				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 11:
						fTrim(fixSprdNewOrdReq->sClOrdId, strlen(fixSprdNewOrdReq->sClOrdId));
						sprintf(temp, "11=%s%c", fixSprdNewOrdReq->sClOrdId, FIX_FIELD_DELIMITER);
						logDebug3(" DP ClOrdId : %s",temp);
						strcat(pMemOut, temp);
						break;
					case 1:
						fTrim(fixSprdNewOrdReq->sAccount, strlen(fixSprdNewOrdReq->sAccount));
						sprintf(temp, "1=%s%c", fixSprdNewOrdReq->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 6008:
						sprintf(temp, "6008=%d%c", fixSprdNewOrdReq->iMultilegOrdType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;	
					case 555:
						sprintf(temp, "555=%d%c", fixSprdNewOrdReq->iNoLegs, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;	
					case 600:
						fTrim(fixSprdNewOrdReq->sSymbol, strlen(fixSprdNewOrdReq->sSymbol));
						sprintf(temp, "600=%s%c", fixSprdNewOrdReq->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						logDebug3(" 600 : %s",fixSprdNewOrdReq->sSymbol);
						iCount++;

						break;
					case 602:
						if(iCount==1)
						{
							fTrim(fixSprdNewOrdReq->sSecurityId_1, strlen(fixSprdNewOrdReq->sSecurityId_1));
							sprintf(temp, "602=%s%c", fixSprdNewOrdReq->sSecurityId_1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);	
						}
						else if(iCount==2)
						{
							fTrim(fixSprdNewOrdReq->sSecurityId_2, strlen(fixSprdNewOrdReq->sSecurityId_2));
							sprintf(temp, "602=%s%c", fixSprdNewOrdReq->sSecurityId_2, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}		
						break;
					case 607:
						sprintf(temp,"607=%d%c",fixSprdNewOrdReq->iProduct,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 609:
						sprintf(temp, "609=%s%c",fixSprdNewOrdReq->sSecurityType,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 611:
						if(iCount==1)
						{
							sprintf(temp, "611=%s%c",fixSprdNewOrdReq->sMaturityDate_1,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						else if(iCount==2)
						{
							sprintf(temp, "611=%s%c",fixSprdNewOrdReq->sMaturityDate_2,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 612:
						if((strncmp(fixSprdNewOrdReq->sSecurityType,OPTION,3)==0))
						{
							sprintf(temp, "612=%lf%c",fixSprdNewOrdReq->fStrikePrice,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 613:
						if((strncmp(fixSprdNewOrdReq->sSecurityType,OPTION,3)==0))
						{
							sprintf(temp, "613=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 6009:
						if((strncmp(fixSprdNewOrdReq->sSecurityType,OPTION,3)==0))
						{
							sprintf(temp, "6009=%d%c",fixSprdNewOrdReq->iPutOrCall,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 624:
						if(iCount==1)
						{
							sprintf(temp, "624=%c%c", fixSprdNewOrdReq->cSide_1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);							
						}
						else if(iCount==2)
						{
							sprintf(temp, "624=%c%c", fixSprdNewOrdReq->cSide_2, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 685:
						sprintf(temp, "685=%.0lf%c", fixSprdNewOrdReq->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 566:
						if(iCount==1)
						{
							sprintf(temp, "566=%lf%c", fixSprdNewOrdReq->fPrice, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						else if(iCount==2)
						{
							sprintf(temp, "566=0%c", FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 204:
						sprintf(temp, "204=%d%c",fixSprdNewOrdReq->iCustomerOrFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 440:
						fTrim(fixSprdNewOrdReq->sClearingFirm,strlen(fixSprdNewOrdReq->sClearingFirm));
						sprintf(temp, "440=%s%c", fixSprdNewOrdReq->sClearingFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 376:
						fTrim(fixSprdNewOrdReq->sComplianceID,strlen(fixSprdNewOrdReq->sComplianceID));
						sprintf(temp, "376=%s%c", fixSprdNewOrdReq->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
				}	
			}/*End of FOR loop 2*/
			break;
		}/*End of IF block*/
	}/*End of FOR Loop 1*/
	logTimestamp("Exit : [NewSpreadOrderRequest]");
	return TRUE;
}


BOOL ModCanSpreadOrderRequest(FIX_SPREAD_MODCANCEL_ORDER_REQUEST *fixSprdModCanOrdReq, CHAR *pMemOut)
{
	logTimestamp("Entry :[ModCanSpreadOrderRequest]");	
	CHAR temp[RUPEE_MAX_PACKET_SIZE];
	LONG32  i,j,iCount=0 ;
	CHAR    sSenderSubId[ENTITY_ID_LEN];
	memset(temp,'\0', RUPEE_MAX_PACKET_SIZE);
	//        memset(temp1,'\0', RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId,'\0', ENTITY_ID_LEN);
	if( MapToHeader(&(fixSprdModCanOrdReq->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [ModifyOrderRequest]:<FALSE>");
		return FALSE;
	}
	strncpy(sSenderSubId,fixSprdModCanOrdReq->FIXHeader.sSenderSubID,strlen(fixSprdModCanOrdReq->FIXHeader.sSenderSubID));	
	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'Y' )
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{
				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 11:
						fTrim(fixSprdModCanOrdReq->sClOrdId, strlen(fixSprdModCanOrdReq->sClOrdId));
						sprintf(temp, "11=%s%c", fixSprdModCanOrdReq->sClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 1:
						fTrim(fixSprdModCanOrdReq->sAccount, strlen(fixSprdModCanOrdReq->sAccount));
						sprintf(temp, "1=%s%c", fixSprdModCanOrdReq->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 37:
						fTrim(fixSprdModCanOrdReq->sOrderID, strlen(fixSprdModCanOrdReq->sOrderID));
						sprintf(temp, "37=%s%c", fixSprdModCanOrdReq->sOrderID, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 555:
						sprintf(temp, "555=%.0lf%c", fixSprdModCanOrdReq->iNoLegs, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;						
					case 600:
						fTrim(fixSprdModCanOrdReq->sSymbol, strlen(fixSprdModCanOrdReq->sSymbol));
						sprintf(temp, "600=%s%c", fixSprdModCanOrdReq->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						logDebug3(" 600 : %s",fixSprdModCanOrdReq->sSymbol);
						iCount++;

						break;
					case 602:
						if(iCount==1)
						{
							fTrim(fixSprdModCanOrdReq->sSecurityId_1, strlen(fixSprdModCanOrdReq->sSecurityId_1));
							sprintf(temp, "602=%s%c", fixSprdModCanOrdReq->sSecurityId_1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						else if(iCount==2)
						{
							fTrim(fixSprdModCanOrdReq->sSecurityId_2, strlen(fixSprdModCanOrdReq->sSecurityId_2));
							sprintf(temp, "602=%s%c", fixSprdModCanOrdReq->sSecurityId_2, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 607:
						sprintf(temp,"607=%d%c",fixSprdModCanOrdReq->iProduct,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 609:
						sprintf(temp, "609=%s%c",fixSprdModCanOrdReq->sSecurityType,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 611:
						if(iCount==1)
						{
							sprintf(temp, "611=%s%c",fixSprdModCanOrdReq->sMaturityDay_1,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						else if(iCount==2)
						{
							sprintf(temp, "611=%s%c",fixSprdModCanOrdReq->sMaturityDay_2,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;	
					case 624:
						if(iCount==1)
						{
							sprintf(temp, "624=%c%c", fixSprdModCanOrdReq->cSide_1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						else if(iCount==2)
						{
							sprintf(temp, "624=%c%c", fixSprdModCanOrdReq->cSide_2, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;
					case 685:
						sprintf(temp, "685=%.0lf%c", fixSprdModCanOrdReq->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 566:
						sprintf(temp, "566=%lf%c", fixSprdModCanOrdReq->fPrice, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 6011:
						sprintf(temp, "6011=%d%c", fixSprdModCanOrdReq->dCumQty, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 204:
						sprintf(temp, "204=%d%c",fixSprdModCanOrdReq->iCustomerOrFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 440:
						fTrim(fixSprdModCanOrdReq->sClearingFirm,strlen(fixSprdModCanOrdReq->sClearingFirm));
						sprintf(temp, "440=%s%c", fixSprdModCanOrdReq->sClearingFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 376:
						fTrim(fixSprdModCanOrdReq->sComplianceID,strlen(fixSprdModCanOrdReq->sComplianceID));
						sprintf(temp, "376=%s%c", fixSprdModCanOrdReq->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;		
					case 6000:
						fTrim(fixSprdModCanOrdReq->sLastModTime,strlen(fixSprdModCanOrdReq->sLastModTime));
						sprintf(temp, "6000=%s%c", fixSprdModCanOrdReq->sLastModTime,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 6013:
						sprintf(temp, "6013=%c%c", fixSprdModCanOrdReq->cCancelFlag, FIX_FIELD_DELIMITER);	
						strcat(pMemOut, temp);
						break;						
				}/*End Of Switch*/
			}/*End of FOR loop 2*/
			break;
		}/*End of IF Block*/
	}/*End of FOR loop 1*/
	logTimestamp("Exit :[ModCanSpreadOrderRequest]");
}							

SHORT  fTrim( CHAR *string , SHORT MaxLen )
{
	logTimestamp("Entry : [fTrim]");

	SHORT index=0;
	if ( MaxLen <= 0 )
		return 0 ;

	for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
		continue;

	string[index]='\0';
	logTimestamp("Exit : [fTrim]");
	return index ;                                  
}

