#include "FIXStructures.h"
#include "IPCS.h"

EXCH_CFG_FILE_STRUCT ExchCfgStruct[CFG_STRUCT_LEN];

BOOL FIXHeaderToStruct(FIX_Msg *msg, FIX_HEADER *fixHeader);
BOOL ExecutionReportToStruct(FIX_Msg *msg, struct FIX_EXECUTION_REPORT *FixExecutionReport);
BOOL GiveUpReportToStruct(FIX_Msg *msg, struct FIX_GIVE_REPORT *FixGiveUpReport);
BOOL OrderCancelRejectToStruct(FIX_Msg *msg, struct FIX_ORDER_CANCEL_REJECT *fixOrderCancelReject);
BOOL SessionRejectToStruct(FIX_Msg *msg, FIX_SESSION_REJECT *fixSessionReject);
CHAR	GOrderId[ORDER_ID_LEN+1];	
CHAR 	cMsgType;

int main(int argc, char *argv[])
{
	logTimestamp("Entry : [main]");
	CHAR    RcvMsg[FIX_MAX_STRING_LEN];
	LONG32  iReadQ, iWriteQ;
	LONG32  lcount =0 ;
	CHAR     CLORID = '0';
	CHAR	cExchType;
	LONG32  iretval;
	FIX_Msg                 msg;
	FIX_HEADER              fixHeader;
	struct FIX_EXECUTION_REPORT    fixExecutionReport;
	struct FIX_GIVE_REPORT 		fixGiveUpReport;
	struct FIX_ORDER_CANCEL_REJECT    fixOrderCancelReject;
	FIX_BUSINESS_MESSAGE_REJECT fixBusinessMessageReject;
	struct FIX_SECURITY_DEFINITION_RESPONSE fixsecuritydefinresp;
	struct FIX_SECURITY_TRADING_SESSION_RESPONSE fixtradesessstatus;

	struct timeval Time1,Time2;

	setvbuf( stdout, NULL, _IONBF, 0 );
	setbuf ( stdout, NULL);
	setbuf ( stdin, NULL);

	cMsgType = argv[1][0];
	cExchType = argv[2][0];

	switch(cExchType)
	{
		case EQUITY_SEGMENT:
			if(( iReadQ = OpenMsgQ( InterfaceToRevMapNSEEQ )) == ERROR)
			{
				return EXIT_FAILURE;
			}

			if(( iWriteQ = OpenMsgQ( RevMapToTrdSrvNSEEQ )) == ERROR)
			{
				return EXIT_FAILURE;
			}
			break;
		case DERIVATIVE_SEGMENT:
			if(( iReadQ = OpenMsgQ( InterfaceToRevMapNSEDR )) == ERROR)
			{
				return EXIT_FAILURE;
			}

			if(( iWriteQ = OpenMsgQ( RevMapToTrdSrvNSEDR )) == ERROR)
			{
				return EXIT_FAILURE;
			}
			break;

		case CURRENCY_SEGMENT:
			if(( iReadQ = OpenMsgQ( InterfaceToRevMapNSEDR )) == ERROR)
			{
				return EXIT_FAILURE;
			}

			if(( iWriteQ = OpenMsgQ( RevMapToTrdSrvNSEDR )) == ERROR)
			{
				return EXIT_FAILURE;
			}
			break;
		case COMMODITY_SEGMENT:
			if(( iReadQ = OpenMsgQ( InterfaceToRevMapMCX )) == ERROR)
			{
				return EXIT_FAILURE;
			}

			if(( iWriteQ = OpenMsgQ( RevMapToTrdSrvMCX)) == ERROR)
			{
				return EXIT_FAILURE;
			}
			break;
		default	:
			logInfo("Invalid Segment :%c:",cExchType);	
			exit(ERROR);

	}
	while ( TRUE )
	{
		memset ( &RcvMsg, 0, FIX_MAX_STRING_LEN );
		memset ( &msg, 0, sizeof(FIX_Msg) );

		logDebug2(" ================== LOOP %d ===================", ++lcount );

		logDebug2(" Waiting on ReadMsgQ : %d", iReadQ );
		if ((ReadMsgQ ( iReadQ, RcvMsg, FIX_MAX_STRING_LEN, 1 ) ) != TRUE )
		{
			logDebug3(" Error in readQ ");
			return EXIT_FAILURE;
		}
		gettimeofday ( &Time1,NULL);
		if ( FIXParse(& msg, RcvMsg, strlen(RcvMsg)) )
		{
			/**********************************
			 * First set the header as it is
			 * common for all messages
			 *********************************/
			memset(& fixHeader, 0, sizeof(FIX_HEADER) );
			if( ! FIXHeaderToStruct(&msg, &fixHeader) )
			{
				logDebug1(" Mapping for FIXHeaderToStruct Failed");	
				logDebug2(" Dropping Message %s", RcvMsg);
				logDebug1(" Dropped Exchange Response while Mapping for FIXHeaderToStruct");
				continue;
			}
			/**********************************
			 * Now check for type of message to
			 * call the correcponding function
			 *********************************/

			if( (strcmp(msg.msgType, FIX_MSG_EXECUTION_REPORT) == 0 ) || (strcmp(msg.msgType, FIX_MSG_BSE_TRADE_CONFRM) == 0 ))
			{
				memset(& fixExecutionReport, 0, sizeof(struct FIX_EXECUTION_REPORT) );
				memcpy(& fixExecutionReport.FIXHeader, &fixHeader, sizeof(FIX_HEADER) );
				logDebug1(" In here");
				if( ! ExecutionReportToStruct(&msg, &fixExecutionReport) )
				{
					logDebug2(" Mapping for ExecutionReportToStruct Failed");	
					logDebug2(" Dropping Message %s", RcvMsg);
					logDebug2(" Dropped Exchange Response while Mapping for ExecutionReportToStruct");
					continue;
				}
				else
				{
					iretval = 1;
					logDebug1(" GOrderId : %s ",GOrderId);
					if (strlen(GOrderId) != 0)
					{
						logInfo(" Over here");
						iretval = GetQMsgType(&(GOrderId));
					}
					logDebug1(" strlen : %d ",strlen(GOrderId));
					if(WriteMsgQ(iWriteQ,(CHAR *)&fixExecutionReport,sizeof(fixExecutionReport),iretval) != TRUE)
					{
						exit(ERROR);
					}
					logDebug1(" Sent to MCXTradeServer");
				}
			}
			else if( (strcmp(msg.msgType, FIX_SPREAD_GIVEUP_REPORT ) == 0 ) )
			{
				memset(& fixGiveUpReport, 0, sizeof(struct FIX_GIVE_REPORT) );
				memcpy(& fixGiveUpReport.FIXHeader, &fixHeader, sizeof(FIX_HEADER) );
				logDebug1(" In here");
				if( ! GiveUpReportToStruct(&msg, &fixGiveUpReport) )
				{
					logDebug2(" Mapping for GiveUpReportToStruct Failed");
					logDebug2(" Dropping Message %s", RcvMsg);
					logDebug2(" Dropped Exchange Response while Mapping for GiveUpReportToStruct");
					continue;
				}
				else
				{
					iretval = 1;
					logDebug1(" GOrderId : %s ",GOrderId);
					if (strlen(GOrderId) != 0)
					{
						logInfo(" Over here");
						iretval = GetQMsgType(&(GOrderId));
					}
					logDebug1(" strlen : %d ",strlen(GOrderId));
					if(WriteMsgQ(iWriteQ,(CHAR *)&fixGiveUpReport,sizeof(fixGiveUpReport),iretval) != TRUE)
					{
						exit(ERROR);
					}
					logDebug1(" Sent to MCXTradeServer");
				}
			}
			else if( strcmp(msg.msgType, FIX_MSG_ORDER_CANCEL_REJECT) == 0 )
			{
				memset(& fixOrderCancelReject, 0, sizeof(struct FIX_ORDER_CANCEL_REJECT) );
				memcpy(& fixOrderCancelReject.FIXHeader, &fixHeader, sizeof(FIX_HEADER) );

				if( ! OrderCancelRejectToStruct(& msg, & fixOrderCancelReject) )
				{
					logDebug1(" Mapping for OrderCancelRejectToStruct Failed");
					logDebug2(" Dropping Message %s", RcvMsg);
					continue;
				}
				else
				{
					iretval = GetQMsgType(&(fixOrderCancelReject.sOrderID));
					if(WriteMsgQ(iWriteQ,(CHAR *) & fixOrderCancelReject, sizeof(fixOrderCancelReject), iretval) != TRUE)
					{
						exit(ERROR);
					}
					logInfo(" Sent to MCXTradeServer");
				}
			}
			else if( strcmp(msg.msgType, FIX_MSG_BUSINESS_REJECT) == 0 )
			{
				memset(& fixBusinessMessageReject, 0, sizeof(FIX_BUSINESS_MESSAGE_REJECT) );
				memcpy(& fixBusinessMessageReject.FIXHeader, &fixHeader, sizeof(FIX_HEADER) );

				if( ! BusinessRejectToStruct(& msg, & fixBusinessMessageReject) )
				{
					logDebug1(" Mapping for BusinessRejectToStruct Failed");
					logDebug2(" Dropping Message %s", RcvMsg);
					continue;
				}
				else
				{
					iretval = 1;
					if (strlen (GOrderId) != 0)
					{
						iretval = GetQMsgType(&(GOrderId));
					}
					if(WriteMsgQ(iWriteQ,(CHAR *)&fixBusinessMessageReject,sizeof(fixBusinessMessageReject),iretval) != TRUE)
					{
						exit(ERROR);
					}
					logInfo(" Sent to MCXTradeServer");
				}
			}
			else if(strcmp(msg.msgType, FIX_SECURITY_DEFINITION_DOWNLOAD) == 0 )
			{
				memset(& fixsecuritydefinresp, 0, sizeof(struct FIX_SECURITY_DEFINITION_RESPONSE) );
				memcpy(& fixsecuritydefinresp.FIXHeader, &fixHeader, sizeof(FIX_HEADER) );

				if( ! SecurityDldDefinToStruct(& msg, & fixsecuritydefinresp) )
				{
					logDebug1(" Mapping for SecurityDldDefinToStruct Failed");
					logDebug2(" Dropping Message %s", RcvMsg);
					continue;
				}
				else
				{
					if(WriteMsgQ(iWriteQ,(CHAR *)&fixsecuritydefinresp,sizeof(fixsecuritydefinresp),1) != TRUE)
					{
						exit(ERROR);
					}
					logInfo(" Sent to MCXDOWNLOADServer");
				}
			}
			else if(strcmp(msg.msgType, FIX_TRADING_SESSION_STATUS) == 0 )
			{
				memset(& fixtradesessstatus, 0, sizeof(struct FIX_SECURITY_TRADING_SESSION_RESPONSE) );
				memcpy(& fixtradesessstatus.FIXHeader, &fixHeader, sizeof(FIX_HEADER) );

				if( ! ExchangeTradingStatus(& msg, & fixtradesessstatus) )
				{
					logDebug1(" Mapping for ExchangeTradingStatus Failed");
					logDebug2(" Dropping Message %s", RcvMsg);
					continue;
				}
				else
				{
					if(WriteMsgQ(iWriteQ,(CHAR *)&fixtradesessstatus,sizeof(fixtradesessstatus),1) != TRUE)
					{
						logFatal("Error in Writing on Queue");
						exit(ERROR);
					}
					logInfo(" Sent to MCXDOWNLOADServer");
				}
			}

			else
			{
				logInfo(" Massage Could Not Be Identified with Msg TYPE :%s:",msg.msgType);
			}
			logInfo(" Message Processed");
			gettimeofday ( &Time2,NULL);
			logInfo(" FixRevMapTime,%lf",((Time2.tv_sec-Time1.tv_sec)+((DOUBLE64)(Time2.tv_usec-Time1.tv_usec)/1000000)));
		}
		else
		{
			logInfo(" FIX Parsing Failed");
		}
	}
	logTimestamp("Exit : [main]");
}


BOOL FIXHeaderToStruct(FIX_Msg *msg, FIX_HEADER *fixHeader)
{
	LONG32 iCount = 0;
	LONG32 iTag = 0;
	CHAR cValue[MAX_TEXT_LEN+1];

	logInfo(" In FIXHeaderToStruct");
	for( ;iCount < msg->numtags; iCount++)
	{
		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 35 :
				strcpy(fixHeader->sMsgType, cValue);
				logDebug2(" MsgType = %s", fixHeader->sMsgType);
				break;

			case 50 :
				strcpy(fixHeader->sSenderSubID, cValue);
				logDebug2(" SenderSubID = %s", fixHeader->sSenderSubID);
				break;

			case 52 :
				/********** To remove milliseconds **********/
				strncpy(fixHeader->sSendingTime, cValue, TIME_TRUNC_LEN);
				fixHeader->sSendingTime[TIME_TRUNC_LEN] = '\0';
				logDebug2(" SendingTime = %s", fixHeader->sSendingTime);
				break;

			case 34 :
				fixHeader->dMsgSeqNum = atoi (cValue);
				logDebug2(" MsgSeqNum = %d", fixHeader->dMsgSeqNum);
				break;

			case 49 :
				strcpy(fixHeader->sSenderCompID, cValue);
				logDebug2(" SenderCompID = %s", fixHeader->sSenderCompID);
				break;

			case 56 :
				strcpy(fixHeader->sTargetCompID, cValue);
				logDebug2(" TargetCompID = %s", fixHeader->sTargetCompID);
				break;

			case 57 :
				strcpy(fixHeader->sTargetSubID, cValue);
				logDebug2(" TargetSubID = %s", fixHeader->sTargetSubID);
				break;

			case 43 :
				fixHeader->cPossDupFlag = cValue[0];
				logDebug2(" PossDupFlag = %c", fixHeader->cPossDupFlag);
				break;

			case 8 :
				logDebug2(" BeginString = %s", cValue);
				break;

			case 9 :
				logDebug2(" Message Length = %s", cValue);
				break;

			case 10 :
				logDebug2(" CheckSum = %s", cValue);
				break;

			default :
				continue;
		}
		msg->headertag[iCount] = 'Y';
	}
	logTimestamp("Exit : [FIXHeaderToStruct]");
	return TRUE;
}


BOOL ExecutionReportToStruct(FIX_Msg *msg, struct FIX_EXECUTION_REPORT *fixExecutionReport)
{
	logTimestamp("Entry : [ExecutionReportToStruct]");
	LONG32 iCount;
	LONG32 iTag = 0,iSeq = 0;
	CHAR cValue[MAX_TEXT_LEN+1];
	CHAR ExecType, OrdStatus, ExecTransType;
	LONG32 Transcode = 0;
	LONG32 ErrorCode;
	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )			
		{
			logDebug3(" Dropped Exchange Response while Mapping for ExecutionReportToStruct");
			continue;
		}

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 1 :
			case 448 :
				strcpy(fixExecutionReport->sAccount, cValue);
				logDebug3(" Account = %s", fixExecutionReport->sAccount);
				break;

			case 11 :
				strcpy(fixExecutionReport->sClOrdId, cValue);
				logDebug3(" ClOrdId = %s", fixExecutionReport->sClOrdId);
				break;
				/******
				  case 21 :
				  fixExecutionReport->cHandlInst=cValue[0];
				  printf("\n HandlInst = %c", fixExecutionReport->cHandlInst);
				  break;******/

			case 38 :
				fixExecutionReport->fQuantity=atoi(cValue);
				logDebug3(" Quantity = %lf", fixExecutionReport->fQuantity);
				break;

			case 40 :
				fixExecutionReport->cOrderType=cValue[0];
				logDebug3(" OrderType = %c", fixExecutionReport->cOrderType);
				break;

			case 44 :
				fixExecutionReport->fPrice=atof(cValue);
				logDebug3(" Price = %lf", fixExecutionReport->fPrice);
				break;

			case 54 :
				fixExecutionReport->cSide=cValue[0];
				logDebug3(" Side = %c", fixExecutionReport->cSide);
				break;

			case 55 :
				strcpy(fixExecutionReport->sSymbol, cValue);
				logDebug3(" Symbol = %s", fixExecutionReport->sSymbol);
				break;

			case 59 :
				fixExecutionReport->cTimeInForce = cValue[0];
				logDebug3(" TimeInForce = %c", fixExecutionReport->cTimeInForce);
				break;

			case 60 :
				/********** To remove milliseconds **********/
				strncpy(fixExecutionReport->sTransactTime, cValue, TIME_TRUNC_LEN);
				fixExecutionReport->sTransactTime[TIME_TRUNC_LEN] = '\0';
				logDebug3(" TransactTime = %s", fixExecutionReport->sTransactTime);
				break;

				/***************
				  case 110 :
				  fixExecutionReport->fMinQty=atoi(cValue);
				  printf("\n MinQty = %d", fixExecutionReport->fMinQty);
				  break;**************/
				/*************
				  case 126 :
				  strcpy(fixExecutionReport->sExpireTime, cValue);
				  printf("\n ExpireTime = %s", fixExecutionReport->sExpireTime);
				  break;*****************/

			case 41 :
				strcpy(fixExecutionReport->sOrigClOrdId, cValue);
				logDebug3(" OrigClOrdId = %s", fixExecutionReport->sOrigClOrdId);
				break;

			case 48 :
				strcpy(fixExecutionReport->sSecurityId, cValue);
				logDebug3(" sSecurityId = %s", fixExecutionReport->sSecurityId);
				break;

			case 58 :
				strcpy(fixExecutionReport->sText, cValue);
				logDebug3(" Text = %s", fixExecutionReport->sText);
				break;

			case 6 :
				fixExecutionReport->fAvgPx=atof(cValue);
				logDebug3(" AvgPx = %f", fixExecutionReport->fAvgPx);
				break;

			case 14 :
				fixExecutionReport->dCumQty=atoi(cValue);
				logDebug3(" CumQty = %d", fixExecutionReport->dCumQty);
				break;

			case 17 :
				strcpy(fixExecutionReport->sExecID, cValue);
				logDebug3(" ExecID = %s", fixExecutionReport->sExecID);
				break;
				/***********
				  case 18 :
				  strcpy(fixExecutionReport->sExecInst, cValue);
				  printf("\n ExecInst = %s", fixExecutionReport->sExecInst);
				  break;*************/

			case 20 :
				fixExecutionReport->cExecTransType=cValue[0];
				logDebug3(" ExecTransType = %c", fixExecutionReport->cExecTransType);
				break;

			case 31 :
				fixExecutionReport->fLastPx=atof(cValue);
				logDebug3(" LastPx = %f", fixExecutionReport->fLastPx);
				break;

			case 32 :
				fixExecutionReport->dLastShares=atoi(cValue);
				logDebug3(" LastShares = %d", fixExecutionReport->dLastShares);
				break;

			case 37 :
				strcpy(fixExecutionReport->sOrderID, cValue);
				logDebug3(" OrderID = %s", fixExecutionReport->sOrderID);
				strcpy(GOrderId,cValue);
				logDebug3(" GOrderId =[%s]",GOrderId);
				break;

			case 39 :
				fixExecutionReport->cOrdStatus=cValue[0];
				logDebug3(" OrdStatus = %c", fixExecutionReport->cOrdStatus);
				break;

			case 103 :
				fixExecutionReport->dOrdRejReason=atoi(cValue);
				logDebug3(" OrdRejReason = %d", fixExecutionReport->dOrdRejReason);
				break;

			case 150 :
				fixExecutionReport->cExecType=cValue[0];
				logDebug3(" ExecType = %c", fixExecutionReport->cExecType);
				break;

			case 151 :
				fixExecutionReport->dLeavesQty=atoi(cValue);
				logDebug3(" LeavesQty = %d", fixExecutionReport->dLeavesQty);
				break;

			case 336 :
				strcpy(fixExecutionReport->sTradingSessionID, cValue);
				logDebug3(" TradingSessionID = %s", fixExecutionReport->sTradingSessionID);
				break;

			case 378 :
				fixExecutionReport->dExecRestatementReason=atoi(cValue);
				logDebug3(" ExecRestatementReason = %d", fixExecutionReport->dExecRestatementReason);
				break;

			case 111 :
				fixExecutionReport->fMaxFloor = atof (cValue);
				logDebug3(" MaxFloor = %d", fixExecutionReport->fMaxFloor);
				break;

			case 432 :
				strcpy(fixExecutionReport->sExpireDate, cValue);
				logDebug3(" ExpireDate = %s", fixExecutionReport->sExpireDate);
				break;

				/****            case 47 :
				  fixExecutionReport->cOrderCapacity = cValue[0];
				  printf("\n OrderCapacity = %c", fixExecutionReport->cOrderCapacity);
				  break; ************/

				/****            case 9743 :
				  fixExecutionReport->iOrderFamily = atoi(cValue);
				  printf("\n OrderFamily = %d ", fixExecutionReport->iOrderFamily);
				  break;***************/

			case 15 :
				memset(fixExecutionReport->sCurrency,'\0',MAX_CURRENCY_LEN);
				strncpy(fixExecutionReport->sCurrency,cValue,strlen(cValue));
				logDebug3(" sCurrrency:%s",fixExecutionReport->sCurrency);
				break;

			case 99 :
				fixExecutionReport->fStopPx=atof(cValue);
				logDebug3(" fStopPx:%d",fixExecutionReport->fStopPx);
				break;

			case 198 :
				strncpy(fixExecutionReport->sSecondryOrderID,cValue,strlen(cValue));
				logDebug3(" sSecondryOrderID:%d",fixExecutionReport->sSecondryOrderID);
				break;

			case 204 :
				fixExecutionReport->iCustomerOrFirm=atoi(cValue);
				logDebug3(" iCustomerOrFirm:%d",fixExecutionReport->iCustomerOrFirm);
				break;

			case 6008:
				fixExecutionReport->iMultilegOrdType = atoi(cValue);
				logDebug3("iMultilegOrdType :%d",fixExecutionReport->iMultilegOrdType);
				break;
			case 555:
				fixExecutionReport->iNoLegs = atoi(cValue);
				logDebug3("iNoLegs : %d",fixExecutionReport->iNoLegs);
				break;

			case 600:
				strncpy(fixExecutionReport->sSymbol,cValue,strlen(cValue));
				logDebug3("sSymbol :%s",fixExecutionReport->sSymbol);
				iSeq++ ;
				break;

			case 602:

				if(iSeq == 1)
				{	
					strncpy(fixExecutionReport->sSecurityId_1,cValue,strlen(cValue));
					logDebug3("sSecurityId_1: %s",fixExecutionReport->sSecurityId_1);
				}
				else if(iSeq == 2)
				{
					strncpy(fixExecutionReport->sSecurityId_2,cValue,strlen(cValue));
					logDebug3("sSecurityId_2: %s",fixExecutionReport->sSecurityId_2);
				}
				break;

			case 607:
				fixExecutionReport->iProduct = atoi(cValue);
				logDebug3("iProduct :%d",fixExecutionReport->iProduct);
				break;

			case 609:
				strncpy(fixExecutionReport->sSecurityType,cValue,strlen(cValue));
				logDebug3("sSecurityType :%s",fixExecutionReport->sSecurityType);
				break;

			case 611:
				if(iSeq == 1)
				{
					strncpy(fixExecutionReport->sMaturityDay_1,cValue,strlen(cValue));
					logDebug3("sMaturityDay_1 :%s",fixExecutionReport->sMaturityDay_1);
				}
				else if(iSeq == 2)
				{
					strncpy(fixExecutionReport->sMaturityDay_2,cValue,strlen(cValue));
					logDebug3("sMaturityDay_2 :%s",fixExecutionReport->sMaturityDay_2);
				}
				break;

			case 624:
				if(iSeq == 1)
				{
					fixExecutionReport->cSide_1 = cValue[0];	
					logDebug3("cSide_1 :%c",fixExecutionReport->cSide_1);
				}
				else if(iSeq == 2)
				{
					fixExecutionReport->cSide_2 = cValue[0];	
					logDebug3("cSide_2 :%c",fixExecutionReport->cSide_2);
				}
				break;

			case 566:
				fixExecutionReport->fPrice = atof(cValue);
				logDebug3("fPrice :%lf",fixExecutionReport->fPrice);
				break;

			case 685:
				fixExecutionReport->fQuantity = atof(cValue);
				logDebug3("fQuantity :%lf",fixExecutionReport->fQuantity);
				break;

			case 6010:
				if(iSeq == 1)
				{
					fixExecutionReport->dLeavesQty_1 = atoi(cValue);
					logDebug3("dLeavesQty_1 :%d",fixExecutionReport->dLeavesQty_1);
				}		
				else if(iSeq == 2)
				{
					fixExecutionReport->dLeavesQty_2 = atoi(cValue);
					logDebug3("dLeavesQty_2 :%d",fixExecutionReport->dLeavesQty_2);
				}
				break;

			case 6011:
				if(iSeq == 1)
				{
					fixExecutionReport->dCumQty_1 = atoi(cValue);
					logDebug3("dCumQty_1 :%d",fixExecutionReport->dCumQty_1);
				}
				else if(iSeq == 2)
				{
					fixExecutionReport->dCumQty_2 = atoi(cValue);
					logDebug3("dCumQty_2 :%d",fixExecutionReport->dCumQty_2);
				}

				break;



				/***********
				  case 30 :
				  memset(fixExecutionReport->sExDest,'\0',MAX_EX_DESTINATION);
				  strncpy(fixExecutionReport->sExDest,cValue,strlen(cValue));
				  printf("\n sExDest:%s",fixExecutionReport->sExDest);
				  break; ************/

				/********	    case 9955:
				  fixExecutionReport->iError = atoi(cValue);
				  printf("\n iError:%d",fixExecutionReport->iError);
				  break; *****************/

				/**********		 case  9924 :
				  fixExecutionReport->dTransactID=atoi(cValue);
				  printf("EquFIXRevMap:dTransactID:%d",fixExecutionReport->dTransactID);
				  break;*****************/


			case 143 :
				break;
			default :
				logDebug3(" INVALID TAG %d = %s ", iTag, cValue);
		}
		/********** END of Switch ******/

	}
	/************ END of FOR LOOP ******/

	/**********************************
	 * Set the internal transcode
	 * from tags 150, 39, 20
	 *********************************/
	ExecType = fixExecutionReport -> cExecType;
	OrdStatus = fixExecutionReport -> cOrdStatus;
	ExecTransType = fixExecutionReport -> cExecTransType;
	/**    ErrorCode  = fixExecutionReport->iError;***/

	logDebug2(" ExecType = %c", ExecType);
	logDebug2(" OrdStatus = %c", OrdStatus);
	logDebug2(" ExecTransType = %c", ExecTransType);
	/*********
	  if( ExecTransType == FIX_EXEC_TRANS_TYPE_NEW )
	  {  
	  This check is comment bcoz tag 20(cExecTransType) in not in BSE 
	 ************/

	if( ExecType == FIX_EXEC_TYPE_NEW && OrdStatus == FIX_ORDER_STATUS_NEW )
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OE_CONF_RESP;
		else
			Transcode = TC_INT_OE_CONF_RESP;

	}

	if( ExecType == FIX_EXEC_TYPE_NEW && OrdStatus == FIX_ORDER_STATUS_PARTIAL_FILL )  
	{
		Transcode = TC_INT_OE_CONF_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_NEW && OrdStatus == FIX_ORDER_STATUS_FILLED )  
	{
		Transcode = TC_INT_OE_CONF_RESP;
	}


	if( ExecType == FIX_EXEC_TYPE_REJECTED && OrdStatus == FIX_ORDER_STATUS_REJECTED )  
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OE_ERR_RESP;
		else
			Transcode = TC_INT_OE_ERROR_RESP;

	}

	if( ExecType == FIX_EXEC_TYPE_REPLACE && OrdStatus == FIX_ORDER_STATUS_FILLED )  
	{
		Transcode = TC_INT_OM_CONF_RESP;
	}
	if( ExecType == FIX_EXEC_TYPE_REPLACE && OrdStatus == FIX_ORDER_STATUS_REPLACED )
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OM_CONF_RESP;
		else
			Transcode = TC_INT_OM_CONF_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_REPLACE && OrdStatus == FIX_ORDER_STATUS_PARTIAL_FILL )
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OM_CONF_RESP;
		else
			Transcode = TC_INT_OM_CONF_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_CANCELED && OrdStatus == FIX_ORDER_STATUS_CANCELED )
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OC_CONF_RESP;
		else
			Transcode = TC_INT_OC_CONF_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_CANCELED && OrdStatus == FIX_ORDER_STATUS_EXPIRED )
	{
		Transcode = TC_INT_OC_CONF_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_EXPIRED && OrdStatus == FIX_ORDER_STATUS_EXPIRED )
	{
		Transcode = TC_INT_OC_CONF_RESP;
	}

	if( ExecType == FIX_EXEC_DONE_FOR_DAY && OrdStatus == FIX_ORDER_STATUS_DONE_FOR_DAY )
	{
		Transcode = TC_INT_OC_CONF_RESP;
	}


	if( (ExecType == FIX_EXEC_TYPE_RESTATED && OrdStatus == FIX_ORDER_STATUS_NEW) && (fixExecutionReport->dExecRestatementReason == 3 || fixExecutionReport->dExecRestatementReason == 4 )) /************** Market to Limit Coversion ******/
	{
		Transcode = TC_INT_MKT_LMT_CONVT_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_RESTATED && OrdStatus == FIX_ORDER_STATUS_CANCELED )
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OC_CONF_RESP;
		else
			Transcode = TC_INT_OC_CONF_RESP;


	}

	if( (ExecType == FIX_EXEC_TYPE_RESTATED && OrdStatus == FIX_EXEC_TYPE_REPLACE) && (fixExecutionReport->dExecRestatementReason == 3 || fixExecutionReport->dExecRestatementReason == 4 ))
	{
		Transcode = TC_INT_MKT_LMT_CONVT_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_PARTIAL_FILL && OrdStatus == FIX_ORDER_STATUS_PARTIAL_FILL )
	{
		Transcode = TC_INT_TRADE_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_FILL && OrdStatus == FIX_ORDER_STATUS_FILLED )
	{
		Transcode = TC_INT_TRADE_RESP;
	}

	/**** if( ExecType == FIX_EXEC_TYPE_REJECTED && OrdStatus == FIX_ORDER_STATUS_REJECTED )
	  Transcode = TC_INT_OE_ERROR_RESP;****/

	/*****        if( ExecType == FIX_EXEC_TYPE_REJECTED && OrdStatus == FIX_ORDER_STATUS_REJECTED ) *****/
	if( ExecType == FIX_EXEC_TYPE_REJECTED  )   /****** For duplicate order becuase of same tag 11, Order status comes that of old order (tag 11) ********/
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OE_ERR_RESP;
		else
			Transcode = TC_INT_OE_ERROR_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_SUSPENDED && OrdStatus == FIX_ORDER_STATUS_SUSPENDED )
	{
		Transcode = TC_INT_OM_CONF_RESP;
	}
	if( ExecType == FIX_EXEC_TYPE_REPLACE && OrdStatus == FIX_ORDER_STATUS_SUSPENDED )
	{
		Transcode = TC_INT_OM_CONF_RESP;
	}
	if( (ExecType == FIX_EXEC_TYPE_RESTATED &&  OrdStatus == FIX_ORDER_STATUS_NEW) && fixExecutionReport->dExecRestatementReason == 1)
	{
		Transcode = TC_INT_SL_ORDER_TRIG_RESP;
	}
	if( ExecType == FIX_EXEC_TYPE_TRIGGERED && OrdStatus == FIX_ORDER_STATUS_NEW )
	{
		Transcode = TC_INT_SL_ORDER_TRIG_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_CANCELED && OrdStatus == FIX_EXEC_TYPE_REJECTED)
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OC_ERR_RESP;
		else
			Transcode = TC_INT_OC_ERROR_RESP;

	}

	if( ExecType == FIX_EXEC_TYPE_REPLACE && OrdStatus == FIX_EXEC_TYPE_REJECTED)
	{
		if(iSeq == 2)
			Transcode = TC_INT_SPREAD_OM_ERR_RESP;
		else
			Transcode = TC_INT_OM_ERROR_RESP;
	}

	if( ExecType == FIX_EXEC_TYPE_FREEZE && OrdStatus == FIX_ORDER_STATUS_FREEZE)
	{
		Transcode = TC_INT_OE_FREEZE_RESP;
	}
	//	}

	logDebug1(" Transcode = %d", Transcode);

	if( Transcode == 0 )
		return FALSE;

	fixExecutionReport -> Header.iMsgCode = Transcode;
	fixExecutionReport -> Header.iMsgLength = sizeof(struct FIX_EXECUTION_REPORT);

	logInfo(" Out ExecutionReportToStruct");
	return TRUE;
}


BOOL OrderCancelRejectToStruct(FIX_Msg *msg, struct FIX_ORDER_CANCEL_REJECT *fixOrderCancelReject)
{
	LONG32 iCount;
	LONG32 iTag = 0;
	CHAR cValue[MAX_TEXT_LEN+1];
	LONG32 Transcode = 0;
	CHAR CxlRejResponseTo;

	logInfo("\n In OrderCancelRejToStruct");
	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )
			continue;

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 37 :
				if( strcmp(cValue, "NONE") != 0 )
				{
					strcpy(fixOrderCancelReject->sOrderID, cValue);
					strcpy(GOrderId,cValue);
				}
				else
				{
					strcpy(fixOrderCancelReject->sOrderID, "0");
					strcpy(GOrderId,"0");
				}
				logDebug3(" OrderID = %s", fixOrderCancelReject->sOrderID);
				logDebug3(" GOrderId =[%s]",GOrderId);
				break;

			case 11 :
				strcpy(fixOrderCancelReject->sClOrdId, cValue);
				logDebug3(" ClOrdId = %s", fixOrderCancelReject->sClOrdId);
				break;

			case 41 :
				strcpy(fixOrderCancelReject->sOrigClOrdId, cValue);
				logDebug3(" OrigClOrdId = %s", fixOrderCancelReject->sOrigClOrdId);
				break;

			case 39 :
				fixOrderCancelReject->cOrdStatus=cValue[0];
				logDebug3(" OrdStatus = %c", fixOrderCancelReject->cOrdStatus);
				break;

			case 9743 :
				fixOrderCancelReject->iOrderFamily = atoi(cValue);
				logDebug3(" OrderFamily = %d ", fixOrderCancelReject->iOrderFamily);
				break;

			case 60 :
				/********** To remove milliseconds **********/
				strncpy(fixOrderCancelReject->sTransactTime, cValue, TIME_TRUNC_LEN);
				fixOrderCancelReject->sTransactTime[TIME_TRUNC_LEN] = '\0';
				logDebug3(" TransactTime = %s", fixOrderCancelReject->sTransactTime);
				break;

			case 434 :
				fixOrderCancelReject->cCxlRejResponseTo = cValue[0];
				logDebug3(" Reject Response To = %c", fixOrderCancelReject->cCxlRejResponseTo);
				break;

			case 102 :
				fixOrderCancelReject->cCxlRejReason = cValue[0];
				logDebug3(" Reject Reason = %c", fixOrderCancelReject->cCxlRejReason);
				break;

			case 58 :
				strcpy(fixOrderCancelReject->sText, cValue);
				(" Text = %s", fixOrderCancelReject->sText);
				break;

			default :
				logDebug3(" INVALID TAG %d = %s ", iTag, cValue);
		}
	}
	CxlRejResponseTo = fixOrderCancelReject -> cCxlRejResponseTo;

	if( CxlRejResponseTo == FIX_CXLREJ_TO_CANCEL_REQ )
		Transcode = TC_INT_OC_ERROR_RESP;
	else if( CxlRejResponseTo == FIX_CXLREJ_TO_REPLACE_REQ )
		Transcode = TC_INT_OM_ERROR_RESP;
	else return FALSE;

	logDebug1(" Transcode = %d", Transcode);

	fixOrderCancelReject -> Header.iMsgCode = Transcode;
	fixOrderCancelReject -> Header.iMsgLength = sizeof(struct FIX_ORDER_CANCEL_REJECT);

	logInfo(" Out OrderCancelRejectToStruct");
	return TRUE;
}


BOOL BusinessRejectToStruct(FIX_Msg *msg, FIX_BUSINESS_MESSAGE_REJECT *fixBusinessMessageReject)
{
	LONG32 iCount;
	LONG32 iTag = 0;
	CHAR cValue[MAX_TEXT_LEN+1];
	LONG32 Transcode = 0;

	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )
			continue;

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 45 :
				fixBusinessMessageReject->dRefSeqNum = atoi(cValue);
				logDebug3(" Reference Sequence Number = %d", fixBusinessMessageReject->dRefSeqNum);
				break;

			case 372 :
				strcpy(fixBusinessMessageReject->sRefMsgType, cValue);
				logDebug3(" Reference Message Type = %s", fixBusinessMessageReject->sRefMsgType);
				break;

			case 379 :
				memset(fixBusinessMessageReject->dBusinessRejectRefID,'\0',BUSS_REJ_LEN);
				strcpy(fixBusinessMessageReject->dBusinessRejectRefID, cValue);
				strcpy(fixBusinessMessageReject->sClOrdId, cValue);
				logDebug3(" Reference ID = %s", fixBusinessMessageReject->dBusinessRejectRefID);
				break;

			case 380 :
				fixBusinessMessageReject->dBusinessRejectReason = atoi(cValue);
				logDebug3(" Reject Reason = %d", fixBusinessMessageReject->dBusinessRejectReason);
				break;

			case 58 :
				strcpy(fixBusinessMessageReject->sText, cValue);
				logDebug3(" Text = %s", fixBusinessMessageReject->sText);
				break;
			case 37 :
				strcpy(GOrderId,cValue);
				logDebug3(" GOrderId =[%s]",GOrderId);
				break;
			case 11 :
				memset(fixBusinessMessageReject->dBusinessRejectRefID,'\0',BUSS_REJ_LEN);
				strcpy(fixBusinessMessageReject->dBusinessRejectRefID, cValue);
				strcpy(fixBusinessMessageReject->sClOrdId, cValue);
				logDebug3(" ClOrdId = %s", fixBusinessMessageReject->dBusinessRejectRefID);
				break;

			default :
				logDebug3(" INVALID TAG %d = %s ", iTag, cValue);
		}
	}

	/***** Transcode = TC_INT_OE_ERROR_RESP;                  *****/
	/**    Transcode = TC_DRV_NSE_OE_ERROR_RESP;        **** Business Reject Transcode ***/
	Transcode = TC_INT_BUSINESS_SESSION_REJ;        /**** Business Reject Transcode ***/

	logDebug3(" Transcode = %d", Transcode);

	fixBusinessMessageReject -> Header.iMsgCode = Transcode;
	fixBusinessMessageReject -> Header.iMsgLength = sizeof(FIX_BUSINESS_MESSAGE_REJECT);

	logDebug3(" Out BusinessRejectToStruct");
	return TRUE;
}


BOOL SessionRejectToStruct(FIX_Msg *msg, FIX_SESSION_REJECT *fixSessionReject)
{
	LONG32 iCount;
	LONG32 iTag = 0;
	CHAR cValue[MAX_TEXT_LEN+1];
	LONG32 Transcode = 0;

	logDebug3(" In SessionRejectToStruct");
	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )
			continue;

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 45 :
				fixSessionReject->dRefSeqNum = atoi(cValue);
				logDebug3(" Reference Sequence Number = %d", fixSessionReject->dRefSeqNum);
				break;

			case 371 :
				fixSessionReject->dRefTagID = atoi(cValue);
				logDebug3(" Reference Tag ID = %d", fixSessionReject->dRefTagID);

			case 372 :
				strcpy(fixSessionReject->sRefMsgType, cValue);
				logDebug3(" Reference Message Type = %s", fixSessionReject->sRefMsgType);
				break;

			case 373 :
				fixSessionReject->dSessionRejectReason = atoi(cValue);
				logDebug3(" Reject Reason = %d", fixSessionReject->dSessionRejectReason);
				break;

			case 58 :
				strcpy(fixSessionReject->sText, cValue);
				logDebug3(" Text = %s", fixSessionReject->sText);
				break;

			default :
				logDebug3(" INVALID TAG %d = %s ", iTag, cValue);
		}
	}

	/**    Transcode = TC_DRV_NSE_OC_ERROR_RESP;         **** Session Reject Transcode ***/
	Transcode = TC_INT_BUSINESS_SESSION_REJ;         /**** Session Reject Transcode ***/

	logDebug3(" Transcode = %d", Transcode);

	fixSessionReject -> Header.iMsgCode = Transcode;
	fixSessionReject -> Header.iMsgLength = sizeof(FIX_SESSION_REJECT);

	logDebug3(" Out SessionRejectToStruct");
	return TRUE;
}

LONG32 GetQMsgType( CHAR *sOrderID)
{
	logDebug3(" In [GetQueueId]");

	SHORT 		dSplit;
	SHORT      	Value;
	CHAR   		sTempStruct[TEMP_STRUCT_LEN];

	dSplit = cMsgType - '0';

	logDebug3(" sOrderID  = [%s]",sOrderID);
	logDebug3(" dSplit    = [%d]",dSplit);
	if ( dSplit > 1 && strcmp(sOrderID,"0") != 0) 
	{
		logDebug3(" Inside SplitFlag");

		memset(sTempStruct,'\0',TEMP_STRUCT_LEN);

		strcpy(sTempStruct,sOrderID+(strlen(sOrderID)-3));

		logDebug3(" sTempStruct = [%s]",sTempStruct);
		logDebug3(" sTempStruct = [%d]",atoi(sTempStruct));

		Value = (dSplit - (atoi(sTempStruct) % dSplit));
		logDebug3(" Value = [%d] ",Value);

		logDebug3(" Leaving [GetQueueId]");
		return Value;
	}
	else
	{
		logDebug3(" Leaving [GetQueueId]");
		return 1;
	}
}

BOOL ExchangeTradingStatus(FIX_Msg *msg, struct FIX_SECURITY_TRADING_SESSION_RESPONSE *fixtradesessstatus)
{
	LONG32 iCount;
	LONG32 iTag = 0;
	CHAR cValue[MAX_TEXT_LEN+1];
	LONG32 Transcode = 0;

	logDebug3(" In ExchangeTradingStatus");
	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )
			continue;

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 335 :
				strcpy(fixtradesessstatus->sTradSesReqId,cValue);
				logDebug3(" sTradSesReqId = %s", fixtradesessstatus->sTradSesReqId);
				break;

			case 336 :
				strcpy(fixtradesessstatus->sTradSessId,cValue);
				logDebug3(" sTradSessId = %s", fixtradesessstatus->sTradSessId);
				break;

			case 340 :
				fixtradesessstatus->iTradSesStatus = atoi(cValue);
				logDebug3(" iTradSesStatus = %d", fixtradesessstatus->iTradSesStatus);
				break;

			case 9268 :
				fixtradesessstatus->iGroupId = atoi(cValue);
				logDebug3(" iGroupId = %d", fixtradesessstatus->iGroupId);
				break;

			case 9272 :
				fixtradesessstatus->iGroupIdTradStat = atoi(cValue);
				logDebug3(" iGroupIdTradStat = %d", fixtradesessstatus->iGroupIdTradStat);
				break;
			default :
				logDebug3(" INVALID TAG %d = %s ", iTag, cValue);
		}/** End of switch ***/

	} /**** End of for loop ****/

	Transcode = TC_INT_FIX_TRADING_SESSION_RESP;         /**** Session Reject Transcode ***/

	logDebug1(" Transcode = %d", Transcode);

	fixtradesessstatus -> Header.iMsgCode = Transcode;
	fixtradesessstatus -> Header.iMsgLength = sizeof(struct FIX_SECURITY_TRADING_SESSION_RESPONSE);

	logDebug3(" Out ExchangeTradingStatus");
	return TRUE;
}/*** End of ExchangeTradingStatus ****/

BOOL SecurityDldDefinToStruct(FIX_Msg *msg, struct FIX_SECURITY_DEFINITION_RESPONSE *fixsecuritydefinresp)
{
	LONG32 iCount;
	LONG32 iTag = 0;
	CHAR cValue[MAX_TEXT_LEN+1];
	LONG32 Transcode = 0;

	logDebug3(" In SecurityDldDefinToStruct");
	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )
			continue;

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 320 :
				strcpy(fixsecuritydefinresp->sSecurityReqId,cValue);
				logDebug3(" sSecurityReqId = %s", fixsecuritydefinresp->sSecurityReqId);
				break;

			case 322 :
				strcpy(fixsecuritydefinresp->sSecurityRespId,cValue);
				logDebug3(" sSecurityRespId = %s", fixsecuritydefinresp->sSecurityRespId);
				break;

			case 323 :
				strcpy(fixsecuritydefinresp->sSecurityRespType,cValue);
				logDebug3(" sSecurityRespType = %s", fixsecuritydefinresp->sSecurityRespType);
				break;

			case 22 :
				strcpy(fixsecuritydefinresp->sIdSource,cValue);
				logDebug3(" sIdSource = %s", fixsecuritydefinresp->sIdSource);
				break;

			case 393 :
				fixsecuritydefinresp->iNoofSec = atoi(cValue);
				logDebug3(" iNoofSec = %d", fixsecuritydefinresp->iNoofSec);
				break;

			case 167 :
				strcpy(fixsecuritydefinresp->sSecurityType,cValue);
				logDebug3(" sSecurityType = %s", fixsecuritydefinresp->sSecurityType);
				break;

			case 55 :
				strcpy(fixsecuritydefinresp->sSymbol,cValue);
				logDebug3(" sSymbol = %s", fixsecuritydefinresp->sSymbol);
				break;

			case 65 :
				strcpy(fixsecuritydefinresp->sSymbolSfx,cValue);
				logDebug3(" sSymbolSfx = %s", fixsecuritydefinresp->sSymbolSfx);
				break;

			case 48 :
				strcpy(fixsecuritydefinresp->sSecurityId,cValue);
				logDebug3(" sSecurityId = %s", fixsecuritydefinresp->sSecurityId);
				break;

			case 200 :
				strcpy(fixsecuritydefinresp->sMaturityMonthYear,cValue);
				logDebug3(" sMaturityMonthYear = %s", fixsecuritydefinresp->sMaturityMonthYear);
				break;

			case 205 :
				strcpy(fixsecuritydefinresp->sMaturityDay,cValue);
				logDebug3(" sMaturityDay = %s", fixsecuritydefinresp->sMaturityDay);
				break;

			case 201 :
				fixsecuritydefinresp->iPutOrCall = atoi(cValue);
				logDebug3(" iPutOrCall = %d", fixsecuritydefinresp->iPutOrCall);
				break;

			case 206 :
				fixsecuritydefinresp->cOptAttribute = cValue[0];
				logDebug3(" cOptAttribute = %c", fixsecuritydefinresp->cOptAttribute);
				break;

			case 202 :
				fixsecuritydefinresp->fStrikePrice = atoi(cValue);
				logDebug3

					(" fStrikePrice = %lf", fixsecuritydefinresp->fStrikePrice);
				break;

			case 107 :
				strcpy(fixsecuritydefinresp->sSecurityDesc,cValue);
				logDebug3(" sSecurityDesc = %s", fixsecuritydefinresp->sSecurityDesc);
				break;

			case 9201 :
				fixsecuritydefinresp->iLotSize = atoi(cValue);
				logDebug3(" iLotSize = %d", fixsecuritydefinresp->iLotSize);
				break;

			case 58 :
				strcpy(fixsecuritydefinresp->sText,cValue);
				logDebug3(" sText = %s", fixsecuritydefinresp->sText);
				break;

			case 9246 :
				fixsecuritydefinresp->fTradingUnitFactor = atoi(cValue);
				logDebug3(" fTradingUnitFactor = %lf", fixsecuritydefinresp->fTradingUnitFactor);
				break;

			case 9247 :
				strcpy(fixsecuritydefinresp->sDeliveryUnit,cValue);
				logDebug3(" sDeliveryUnit = %s", fixsecuritydefinresp->sDeliveryUnit);
				break;

			case 9248 :
				fixsecuritydefinresp->fDeliveryUnitFactor = atoi(cValue);
				logDebug3(" fDeliveryUnitFactor = %lf", fixsecuritydefinresp->fDeliveryUnitFactor);
				break;

			case 9202 :
				strcpy(fixsecuritydefinresp->sTradingUnit,cValue);
				logDebug3(" sTradingUnit = %s", fixsecuritydefinresp->sTradingUnit);
				break;

			case 9203 :
				fixsecuritydefinresp->fPriceNumerator = atoi(cValue);
				logDebug3(" fPriceNumerator = %lf", fixsecuritydefinresp->fPriceNumerator);
				break;

			case 9204 :
				fixsecuritydefinresp->fPriceDemoninator = atoi(cValue);
				logDebug3(" fPriceDemoninator = %lf", fixsecuritydefinresp->fPriceDemoninator);
				break;

			case 9205 :
				fixsecuritydefinresp->fGenNumerator = atoi(cValue);
				logDebug3(" fGenNumerator = %lf", fixsecuritydefinresp->fGenNumerator);
				break;

			case 9206 :
				fixsecuritydefinresp->fGenDemoninator = atoi(cValue);
				logDebug3(" fGenDemoninator = %lf", fixsecuritydefinresp->fGenDemoninator);
				break;

			case 9210 :
				fixsecuritydefinresp->iPriceTick = atoi(cValue);
				logDebug3(" iPriceTick = %d", fixsecuritydefinresp->iPriceTick);
				break;

			case 9211 :
				fixsecuritydefinresp->fDecimalLocator = atoi(cValue);
				logDebug3(" fDecimalLocator = %lf", fixsecuritydefinresp->fDecimalLocator);
				break;

			case 15 :
				strcpy(fixsecuritydefinresp->sCurrency,cValue);
				logDebug3(" sCurrency = %s", fixsecuritydefinresp->sCurrency);
				break;

			case 120 :
				strcpy(fixsecuritydefinresp->sSettelmentCurrency ,cValue);
				logDebug3(" sSettelmentCurrency = %s", fixsecuritydefinresp->sSettelmentCurrency);
				break;

			case 9265 :
				strcpy(fixsecuritydefinresp->sProductMonth,cValue);
				logDebug3(" sProductMonth = %s", fixsecuritydefinresp->sProductMonth);
				break;

			case 9273 :
				strcpy(fixsecuritydefinresp->sUnderlyingSecurityId,cValue);
				logDebug3(" sUnderlyingSecurityId = %s", fixsecuritydefinresp->sUnderlyingSecurityId);
				break;

			case 332 :
				fixsecuritydefinresp->fHighPx = atoi(cValue);
				logDebug3(" fHighPx = %lf", fixsecuritydefinresp->fHighPx);
				break;

			case 333 :
				fixsecuritydefinresp->fLowPx = atoi(cValue);
				logDebug3(" fLowPx = %lf", fixsecuritydefinresp->fLowPx);
				break;

			case 9268 :
				fixsecuritydefinresp->iGroupId = atoi(cValue);
				logDebug3(" iGroupId = %d", fixsecuritydefinresp->iGroupId);
				break;
			default :
				logDebug3(" INVALID TAG %d = %s ", iTag, cValue);
		}
	}

	Transcode = TC_INT_FIX_SECURITY_DNLD_RESP;         /**** Session Reject Transcode ***/

	logDebug3(" Transcode = %d", Transcode);

	fixsecuritydefinresp -> Header.iMsgCode = Transcode;
	fixsecuritydefinresp -> Header.iMsgLength = sizeof(struct FIX_SECURITY_DEFINITION_RESPONSE);

	logDebug3(" Out SessionRejectToStruct");
	return TRUE;
}

BOOL GiveUpReportToStruct(FIX_Msg *msg, struct FIX_GIVE_REPORT *FixGiveUpReport)
{
	logTimestamp("Entry : [GiveUpReportToStruct]");
	LONG32 iCount;
	LONG32 iTag = 0,iGiveUpSts,iGiveUpTrans;
	CHAR cValue[MAX_TEXT_LEN+1];
	CHAR ExecType, OrdStatus, ExecTransType;
	LONG32 Transcode = 0;
	LONG32 ErrorCode;
	memset (GOrderId,'\0',ORDER_ID_LEN+1);
	for(iCount = 0; iCount < msg->numtags; iCount++)
	{
		if( msg->headertag[iCount] == 'Y' )
		{
			logDebug3(" Dropped Exchange Response while Mapping for GiveUpReportToStruct");
			continue;
		}

		iTag = atoi(msg->tags[iCount]);
		strcpy(cValue, msg->values[iCount]);

		switch(iTag)
		{
			case 37 :
				strcpy(FixGiveUpReport->sOrderID, cValue);
				logDebug3(" sOrderID = %s", FixGiveUpReport->sOrderID);
				break;		
			case 6007:
				FixGiveUpReport->iFillId = atoi(cValue);
				logDebug3("iFillId = %d",FixGiveUpReport->iFillId);
				break;
			case 6012:
				FixGiveUpReport->iGiveUpStat = atoi(cValue);
				logDebug3("iGiveUpStat = %d",FixGiveUpReport->iGiveUpStat);
				break;
			case 55:
				strcpy(FixGiveUpReport->sSymbol,cValue);
				logDebug3("sSymbol = %s",FixGiveUpReport->sSymbol);
				break;
			case 48:
				strcpy(FixGiveUpReport->sSecurityId,cValue);
				logDebug3("sSecurityId = %s",FixGiveUpReport->sSecurityId);
				break;
			case 167:
				strcpy(FixGiveUpReport->sSecurityType,cValue);
				logDebug3("sSecurityType = %s",FixGiveUpReport->sSecurityType);
				break;
			case 460:
				FixGiveUpReport->iProduct = atoi(cValue);
				logDebug3("iProduct = %s",FixGiveUpReport->iProduct);
				break;
			case 200 :
				strcpy(FixGiveUpReport->sMaturityMonthYear,cValue);
				logDebug3(" sMaturityMonthYear = %s", FixGiveUpReport->sMaturityMonthYear);
				break;					
			case 205 :
				strcpy(FixGiveUpReport->sMaturityDay,cValue);
				logDebug3(" sMaturityDay = %s", FixGiveUpReport->sMaturityDay);
				break;
			case 201 :
				FixGiveUpReport->iPutOrCall = atoi(cValue);
				logDebug3(" iPutOrCall = %d", FixGiveUpReport->iPutOrCall);
				break;
			case 202 :
				FixGiveUpReport->fStrikePrice = atoi(cValue);
				logDebug3(" fStrikePrice = %lf", FixGiveUpReport->fStrikePrice);
				break;
			case 206 :
				FixGiveUpReport->cOptAttribute = cValue[0];
				logDebug3(" cOptAttribute = %c", FixGiveUpReport->cOptAttribute);
				break;
			case 54:
				FixGiveUpReport->cSide = cValue[0];
				logDebug3("cSide =%c",FixGiveUpReport->cSide);
				break;
			case 31 :
				FixGiveUpReport->fLastPx=atof(cValue);
				logDebug3(" LastPx = %f", FixGiveUpReport->fLastPx);
				break;
			case 32 :
				FixGiveUpReport->dLastShares=atoi(cValue);
				logDebug3(" LastShares = %d", FixGiveUpReport->dLastShares);
				break;
			case 77:
				FixGiveUpReport->cOpenCloseFlg = cValue[0];
				logDebug3("cOpenCloseFlg = %c",FixGiveUpReport->cOpenCloseFlg);
				break;
			case 203:
				FixGiveUpReport->cCoverUncover = cValue[0];
				logDebug3("cCoverUncover = %c",FixGiveUpReport->cCoverUncover);
				break;
			case 6000:
				strcpy(FixGiveUpReport->sLastModTime,cValue);
				logDebug3("sLastModTime= %s",FixGiveUpReport->sLastModTime);
				break;
			case 440:
				strcpy(FixGiveUpReport->sClearingFirm, cValue);
				logDebug3("sClearingFirm = %s",FixGiveUpReport->sClearingFirm);
				break;	
			default:
				logDebug3("INVALID TAG %d= %s=",iTag,cValue);
		}
	}
	iGiveUpSts = FixGiveUpReport->iGiveUpStat;
	if(iGiveUpSts == 1)
	{
		iGiveUpTrans = TC_INT_GIVE_UP_CONF;
	}
	else if( iGiveUpSts == 2)
	{
		iGiveUpTrans = TC_INT_GIVE_UP_REJ;
	}	
	FixGiveUpReport->Header.iMsgCode = iGiveUpTrans;
	FixGiveUpReport->Header.iMsgLength = sizeof( struct FIX_GIVE_REPORT);
	logTimestamp("Exit : [GiveUpReportToStruct]");	 
	return TRUE;
}





