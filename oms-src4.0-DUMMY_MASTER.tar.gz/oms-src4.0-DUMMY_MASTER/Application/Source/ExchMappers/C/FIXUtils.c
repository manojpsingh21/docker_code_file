#include "FIXStructures.h"

LONG32 FIXParse(FIX_Msg* msg, const char* buffer, int len)
{
	logTimestamp("Entry : [FIXParse]");	

	int nullValue = FALSE;
	int n         = 0;
	char c        = 0;
	char* src     = NULL;
	char* dst     = NULL;

	if(msg == NULL)
	{
		logDebug3(" Cannot Parse: msg NULL");
		return FALSE;
	}

	memcpy(msg->inputmsg, buffer, len);
	msg->length = len;
	msg->inputmsg[len] = 0;

	msg->numtags = 0;
	msg->inputmsg[msg->length] = 0;

	src = msg->inputmsg;
	dst = msg->buf;
	msg->tags[n] = dst;

	while ( FIXGetNextTag(& src, & dst) )
	{
		/***** logDebug3("Tag[%s]", msg->tags[n]); *****/
		msg->values[n] = dst;

		if (! FIXGetNextValue(& src, & dst) )
			return FALSE;

		/***** logDebug3("Value[%s]", msg->values[n]); *****/

		++n;
		msg->tags[n] = dst;
	}
	msg->numtags = n;
	logDebug2(" Number of Tags = %d", msg->numtags);

	if( !FIXGetMessageType( msg) )
	{     
		logTimestamp("Exit : [FIXParse > FALSE]");   
		return FALSE;
	}
	logTimestamp("Exit : [FIXParse > TRUE]");
	return TRUE;
}


LONG32 FIXGetMessageType(FIX_Msg *msg)
{
	logTimestamp("Entry : [FIXGetMessageType]");

	int i;
	for(i=0; i < msg->numtags ; i++)
	{
		if( strcmp(msg->tags[i], FIX_TAG_MSG_TYPE ) == 0 )
		{
			strcpy(msg->msgType, msg->values[i]);
			logTimestamp("Exit : [FIXGetMessageType > TRUE]");
			return TRUE;
		}
	}
	logTimestamp("Exit : [FIXGetMessageType > FALSE]");
	return FALSE;
}

LONG32 FIXGetMessageTypeFromString(const char *string, char *result)
{
	logTimestamp("Entry : [FIXGetMessageTypeFromString]");

	char *messageTypeTagStart, *messageTypeValueStart;
	int index = 0;
	messageTypeTagStart = strstr(string,"\00135=");
	if (messageTypeTagStart == NULL)
	{
		return FALSE;
	}
	messageTypeValueStart = messageTypeTagStart + 4;
	while (messageTypeValueStart[index] != FIX_FIELD_DELIMITER)
	{
		if( messageTypeValueStart[index] == FIX_MESSAGE_DELIMITER
				|| messageTypeValueStart[index] == '\0' )
		{
			return FALSE;
		}
		result[index] = messageTypeValueStart[index];
		index ++;
	}
	if(index == 0)
	{
		logTimestamp("Entry : [FIXGetMessageTypeFromString > FALSE]");
		return FALSE;
	}
	result[index] = '\0';
	logTimestamp("Entry : [FIXGetMessageTypeFromString > TRUE]");
	return TRUE;
}
static LONG32 FIXGetNextTag(char** src, char** dst)
{
	logTimestamp("Entry : [FIXGetNextTag]");

	LONG32 rc = TRUE;
	char c     = 0;
	char* sptr = *src;
	char* dptr = *dst;

	while (TRUE)
	{
		c = *sptr++;

		/****
		  if ( isalpha(c))
		  {
		  logDebug1("Invalid character in tag. '%c'", c);
		  return FALSE;
		  }
		 ****/
		if (c == 0)
		{
			*sptr--;
			*dptr++ = 0;
			rc = 0;
			break;
		}

		if (c == FIX_TAG_DELIMITER)
		{
			*dptr++ = 0;
			break;
		}

		*dptr++ = c;
	}

	*src = sptr;
	*dst = dptr;
	logTimestamp("Exit : [FIXGetNextTag]");
	return rc;
}
static LONG32 FIXGetNextValue(char** src, char** dst)
{
	logTimestamp("Entry : [FIXGetNextValue]");

	char c     = 0;
	char* sptr = *src;
	char* dptr = *dst;
	while (TRUE)
	{
		c = *sptr++;

		if (c == FIX_FIELD_DELIMITER)
		{
			*dptr++ = 0;
			break;
		}
		if (c == 0)
		{
			*dptr++ = 0;
			*sptr--;
			break;
		}
		/***
		  if (c == FIX_ESCAPE)
		  {
		  c = *sptr++;
		  }
		 ***/

		*dptr++ = c;
	}

	*src = sptr;
	*dst = dptr;
	logTimestamp("Exit : [FIXGetNextValue > TRUE]");
	return TRUE;
}

BOOL formRejectString(CHAR *sIStr, CHAR *sOStr)
{
	logTimestamp("Entry : [formRejectString]");

	CHAR *token;

	CHAR    *Tokens_ap[FIX_MAX_TAGS];
	CHAR	*InputStrng;
	LONG32	iNoOfTokens=0;
	LONG32	init,end ,jcnt;
	LONG32	iRetval;
	LONG32	iCount;
	LONG32	iTag;
	CHAR    sMsgType[MESSAGE_TYPE_LEN];
	CHAR	sClOrdId[CLORDID_LEN];
	CHAR	cValue[MAX_TEXT_LEN];
	CHAR	sBeginStr[ENV_VARIABLE_LEN];
	CHAR	sSenderId[ENV_VARIABLE_LEN];
	CHAR	sTargetId[ENV_VARIABLE_LEN];
	CHAR	*sErrorMessage = "Application Not Available.";
	CHAR	*sStr = strdup(sIStr);
	BOOL 	ChkFlag = FALSE;


	InputStrng = (char *) malloc(sizeof(char) * FIX_MAX_STRING_LEN);
	memset(InputStrng,'\0',FIX_MAX_STRING_LEN);
	memcpy(InputStrng,sIStr,strlen(sIStr));

	iNoOfTokens =   0;
	init    =       0;
	end     =       0;

	for(jcnt=0;jcnt<strlen(InputStrng);jcnt++)
	{

		if(InputStrng[jcnt] == 1 )
		{

			end     =   jcnt;
			if(iNoOfTokens  != 0)
			{
				Tokens_ap[iNoOfTokens]  = (CHAR*)malloc(sizeof(CHAR)*(end-init+1));
				if(Tokens_ap[iNoOfTokens]   ==  NULL)
					memset(Tokens_ap[iNoOfTokens],'\0',end-init+1);
				memcpy(Tokens_ap[iNoOfTokens],&InputStrng[init],end-init);
			}
			iNoOfTokens++;

			init    =   jcnt+1;
		}
	}

	free(InputStrng);

	for(iRetval=TRUE,iCount=1;iCount<iNoOfTokens;iCount++)
	{
		memset(cValue,'\0',FIX_MAX_VALUE_LEN);
		sscanf(Tokens_ap[iCount],"%d=%[ -~]s",&iTag,cValue);
		logDebug3("Token [%d] = %d=%s",iCount,iTag,cValue);

		switch(iTag)
		{
			case 35:
				memset(sMsgType,'\0',MESSAGE_TYPE_LEN);
				strncpy(sMsgType,cValue,strlen(cValue));
				break ;

			case 11:
				memset(sClOrdId,'\0',CLORDID_LEN);
				strncpy(sClOrdId,cValue,strlen(cValue));
				ChkFlag = TRUE;
				break;

			case 49:
				break;
			case 56:
				break;
		}
	}




	if(ChkFlag == FALSE)
	{
		return FALSE;
	}
	else{
		sprintf(sOStr,"8=%s%c9=42%c35=j%c49=%s%c56=%s%c34=1%c58=%s%c11=%s%c380=0%c45=1%c",sBeginStr,\
				FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,sTargetId,FIX_FIELD_DELIMITER,\
				sSenderId,FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,sErrorMessage,FIX_FIELD_DELIMITER,sClOrdId,\
				FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER, sClOrdId,FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,\
				FIX_FIELD_DELIMITER);
		return TRUE;
	}
}
