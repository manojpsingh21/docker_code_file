#include <malloc.h>
#include <string.h>
#include <sys/time.h>
#include "IPCS.h"
#include "FIXStructures.h"

EXCH_CFG_FILE_STRUCT ExchCfgStruct[CFG_STRUCT_LEN];
CHAR            sSenderCompId   [ENV_VARIABLE_LEN];
SHORT  fTrim( CHAR *string , SHORT MaxLen );
BOOL MapToFIXString(CHAR *pMemIn , CHAR *pMemOut );
BOOL MapToHeader(FIX_HEADER *fixHeader , CHAR *pMemOut );
BOOL NewOrderRequest( FIX_NEW_ORDER_ICEX_REQUEST *fixNewOrderRequest, CHAR *pMemOut);
BOOL ModifyOrderRequest( FIX_ORDER_MODIFICATION_ICEX_REQUEST *fixModOrderRequest, CHAR *pMemOut);
BOOL CancelOrderRequest( FIX_ORDER_CANCEL_ICEX_REQUEST *fixCanOrderRequest, CHAR *pMemOut );

LONG32 main(LONG32 argc , CHAR **argv)
{
	logTimestamp("Entry : [main]");

	LONG32		iReadQID =0;
	LONG32		iSendQID =0;
	LONG32		iLoop = 1;
	CHAR		sRcvMsg[RUPEE_MAX_PACKET_SIZE] ;
	CHAR		fixString[RUPEE_MAX_PACKET_SIZE];
	CHAR		cChoice;
	INT16		iQMsgType;
	INT_HEADER *pHeaderIn  ;
	FIX_NEW_ORDER_ICEX_REQUEST *fixNew;/**Delete this after option attribute is pasted***/
	LONG32		iSysdate=0;
	BOOL		iRetVal = TRUE;
	setbuf ( stdout, NULL);
	setbuf ( stdin , NULL);
	setvbuf( stdout, NULL, _IONBF, 0 );
	memset(ExchCfgStruct,'\0',CFG_STRUCT_LEN * sizeof(EXCH_CFG_FILE_STRUCT));

	Loadenv();
	cChoice = argv[2][0];
	switch(cChoice)
	{
		case EQUITY_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToFwdMapNSEEQ )) == ERROR)
			{
				logFatal(" Leaving [Main] RE");
				exit(ERROR);
			}
			logInfo(" OrdSrvToFwdMapNSEEQ Queue Id = %d", iReadQID);

			logDebug1(" Opening Queue FwdMapToInterfaceNSEEQ");
			if((iSendQID = OpenMsgQ( FwdMapToInterfaceNSEEQ )) == ERROR)
			{
				logFatal(" Leaving [Main] SE");
				exit(ERROR);
			}
			logDebug1(" FwdMapToInterfaceNSEEQ Queue Id = %d", iSendQID);
			break;
		case DERIVATIVE_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToMapperNSEDR)) == ERROR)
			{
				logFatal(" Leaving [Main] RD");
				exit(ERROR);
			}
			logDebug1(" OrdSrvToMapperNSEDR Queue Id = %d", iReadQID);

			logInfo(" Opening Queue OrdSrvToMapperNSEDR");
			if((iSendQID = OpenMsgQ( MapperToConnNSEFO)) == ERROR)
			{
				logFatal(" Leaving [Main] SD");
				exit(ERROR);
			}
			logDebug1(" MapperToConnNSEFO Queue Id = %d", iSendQID);
			break;

		case CURRENCY_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToMapperNSECR)) == ERROR)
			{
				logFatal(" Leaving [Main] RC");
				exit(ERROR);
			}
			logDebug1(" OrdSrvToMapperNSECR Queue Id = %d", iReadQID);

			logInfo(" Opening Queue MapperToConnNSECD ");
			if((iSendQID = OpenMsgQ( MapperToConnNSECD)) == ERROR)
			{
				logFatal(" Leaving [Main] SC");
				exit(ERROR);
			}
			logDebug1(" MapperToConnNSECD Queue Id = %d", iSendQID);
			break;
		case COMMODITY_SEGMENT:
			if((iReadQID = OpenMsgQ( OrdSrvToFwdMapICEX)) == ERROR)
			{
				logFatal(" Leaving [Main] RM");
				exit(ERROR);
			}
			logDebug1(" OrdSrvToFwdMapICEX Queue Id = %d", iReadQID);

			logInfo(" Opening Queue FwdMapToInterfaceICEX ");
			if((iSendQID = OpenMsgQ( FwdMapToInterfaceICEX)) == ERROR)
			{
				logFatal(" Leaving [Main] SM");
				exit(ERROR);
			}
			logDebug1(" FwdMapToInterfaceICEX Queue Id = %d", iSendQID);
			break;
	}

	logDebug1 (" DP : %s",argv[1]);
	iRetVal = LoadFile (argv[1]);
	if ( iRetVal == FALSE )
	{
		logFatal(" File loading failed.");
		exit(ERROR);
	}
	Display();

	while(TRUE)
	{
		logDebug1(" ----------------- IN LOOP : %d -----------------", iLoop++);
		logDebug1(" Waiting on Queue %d",iReadQID);

		memset(fixString, 0, RUPEE_MAX_PACKET_SIZE);
		memset(sRcvMsg, 0, RUPEE_MAX_PACKET_SIZE);
		iQMsgType = 0;

		logTimestamp("ENTRY : [ReadMsgQ]");
		if((ReadMsgQ( iReadQID, (CHAR *) &sRcvMsg, RUPEE_MAX_PACKET_SIZE , 1)) != 1)
		{
			logFatal(" Leaving [Main]");
			exit(ERROR);
		}

		pHeaderIn = (INT_HEADER *)&sRcvMsg;
		fixNew 	  = (FIX_NEW_ORDER_ICEX_REQUEST *)&sRcvMsg;
		iQMsgType = pHeaderIn->iQMsgType;

		//	logDebug1("**************Here OptAttribute [%c]********************",fixNew->cOptAttribute);
		logDebug1(" Mapping For MsgCode = %d", pHeaderIn->iMsgCode);


		if( MapToFIXString( (CHAR *)&sRcvMsg , (CHAR *)&fixString) == TRUE )
		{
			logInfo(" Mapping Complete");
			logDebug3(" Final String = :%s:", fixString);


			logDebug1(" Msg Queue Type iQMsgType :%d: pHeaderIn->iQMsgType :%d:",iQMsgType,pHeaderIn->iQMsgType );
			logTimestamp("ENTRY : [WriteMsgQ]");
			if(WriteMsgQ(iSendQID,&fixString, strlen(fixString),iQMsgType) != 1)
			{
				logFatal(" Leaving [Main]");
				exit(ERROR);
			}

			logInfo(" Sent to Interface");
		}
		else
		{
			logDebug2(" Mapping Failed");
		}

	}                                               /*** End of While Loop ***/
	logTimestamp("Exit : [main]");
}                                                   /*** End of main ***/

BOOL MapToFIXString(CHAR *pMemIn , CHAR *pMemOut )
{
	logTimestamp("Entry : [MapToFIXString]");	


	LONG32 iMsgCode = 0;
	INT_HEADER *pHeader = ( INT_HEADER *) pMemIn ;
	iMsgCode = pHeader->iMsgCode;
	logDebug3(" pHeader->iMsgCode is :%d:",pHeader->iMsgCode);
	logDebug3(" iMsgCode is :%i:",iMsgCode);

	if((iMsgCode == TC_INT_ORDER_ENTRY_REQ)  || (iMsgCode == TC_INT_CO_ORDER_REQ) || (iMsgCode == TC_INT_BO_ORDER_REQ) || (iMsgCode == TC_INT_CO_REJ_SQROFF))
	{
		FIX_NEW_ORDER_ICEX_REQUEST *fixNewOrderRequest = ( FIX_NEW_ORDER_ICEX_REQUEST *) pMemIn ;
		//		logDebug3("fixNewOrderRequest->cOptAttribute [%c]",fixNewOrderRequest->cOptAttribute);
		if( NewOrderRequest( fixNewOrderRequest, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}
	else if((iMsgCode == TC_INT_ORDER_MODIFY) || (iMsgCode == TC_INT_CO_ORDER_MODIFY) || (iMsgCode == TC_INT_BO_ORDER_MODIFY))
	{

		FIX_ORDER_MODIFICATION_ICEX_REQUEST *fixModOrderRequest = ( FIX_ORDER_MODIFICATION_ICEX_REQUEST *) pMemIn ;
		logDebug2("Nitish in Drv Modification");

		if( ModifyOrderRequest( fixModOrderRequest, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}

	else if((iMsgCode == TC_INT_ORDER_CANCEL) || (iMsgCode == TC_INT_CO_ORDER_EXIT) || (iMsgCode == TC_INT_BO_ORDER_EXIT) )// || (iMsgCode == TC_INT_CO_REJ_SQROFF))
	{
		FIX_ORDER_CANCEL_ICEX_REQUEST *fixCanOrderRequest = ( FIX_ORDER_CANCEL_ICEX_REQUEST *) pMemIn ;

		if( CancelOrderRequest( fixCanOrderRequest, pMemOut) == TRUE )
		{
			logDebug3(" Leaving [MapToFIXString]:<TRUE>");
			return TRUE;
		}
		else
		{
			logDebug3(" Leaving [MapToFIXString]:<FALSE>");
			return FALSE;
		}
	}
	else if((iMsgCode == TC_INT_SPREAD_OE_REQ) || (iMsgCode == TC_INT_2L_OE_REQ) || (iMsgCode == TC_INT_3L_OE_REQ) )

	{
			FIX_SPREAD_NEW_ORDER_REQUEST	*fixSprdNewOrdReq = (FIX_SPREAD_NEW_ORDER_REQUEST *)pMemIn;
			if( NewSpreadOrderRequest( fixSprdNewOrdReq , pMemOut) == TRUE )
			{	
				logDebug3(" Leaving [MapToFIXString]:<TRUE>");
				return TRUE;
			}
			else
			{
				logDebug3(" Leaving [MapToFIXString]:<FALSE>");
				return FALSE;
			}
	}
	/*	else if(iMsgCode == TC_INT_SPREAD_OM_REQ || iMsgCode == TC_INT_SPREAD_OC_REQ)
		{
		FIX_SPREAD_MODCANCEL_ORDER_REQUEST *fixSprdModCanOrdReq = (FIX_SPREAD_MODCANCEL_ORDER_REQUEST *)pMemIn;	
		if(ModCanSpreadOrderRequest( fixSprdModCanOrdReq, pMemOut) == TRUE )
		{
		logDebug3(" Leaving [MapToFIXString]:<TRUE>");
		return TRUE;
		}
		else
		{
		logDebug3(" Leaving [MapToFIXString]:<FALSE>");
		}       return FALSE;

		}
	 **/
	else
	{
		logDebug3(" Unknown iMsgCode %d", iMsgCode);
		logDebug3(" Leaving [MapToFIXString]:<FALSE>");
		return FALSE;
	}
		logTimestamp("EXIT  : [MapToFIXString]");
}/**** End of MapToFIXString ****/
BOOL MapToHeader(FIX_HEADER *fixHeader , CHAR *pMemOut )
{
	logTimestamp("Entry : [MapToHeader]");

	CHAR temp[RUPEE_MAX_PACKET_SIZE];
	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);

	sprintf(temp, "8=%s%c", fixHeader->sBeginString, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);

	fTrim(fixHeader->sMsgType, strlen(fixHeader->sMsgType));
	sprintf(temp, "35=%s%c", fixHeader->sMsgType, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);
	fTrim(fixHeader->sSenderCompID, strlen(fixHeader->sSenderCompID));
	sprintf(temp, "49=%s%c", fixHeader->sSenderCompID, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);
	logInfo("darshan : %s ",fixHeader->sTargetCompID);
	fTrim(fixHeader->sTargetCompID, strlen(fixHeader->sTargetCompID));
	sprintf(temp, "56=%s%c", fixHeader->sTargetCompID, FIX_FIELD_DELIMITER);
	strcat(pMemOut, temp);

	logTimestamp("EXIT : [MapToHeader]");
}/**** End of MapToHeader *****/

BOOL NewOrderRequest( FIX_NEW_ORDER_ICEX_REQUEST *fixNewOrderRequest, CHAR *pMemOut)
{
	logTimestamp("Entry : [NewOrderRequest]");

	CHAR	temp[RUPEE_MAX_PACKET_SIZE];
	CHAR	temp1[RUPEE_MAX_PACKET_SIZE];

	LONG32	i,j,k ;
	CHAR	sSenderSubId[ENTITY_ID_LEN];
	//LONG32	iPrice=0;
	DOUBLE64 fPrice=0.00;
//	LONG32 	iStopPx=0;
	DOUBLE64 fStopPx=0.00;

	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);
	memset(temp1, 0, RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId, 0, ENTITY_ID_LEN);


	if( MapToHeader( &(fixNewOrderRequest->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [NewOrderRequest]:<FALSE>");
		return FALSE;
	}

	strncpy(sSenderSubId,fixNewOrderRequest->FIXHeader.sSenderSubID,strlen(fixNewOrderRequest->FIXHeader.sSenderSubID));
	logDebug2(" SenderSub id = [%s]",sSenderSubId );
	logDebug2(" CFG_STRUCT_LEN = [%d]",CFG_STRUCT_LEN );


	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{	
		logDebug2("..................................................................................");
		logDebug2("**************************************** id = [%s]",ExchCfgStruct[i].sDelToTargetComp );
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && strcmp(ExchCfgStruct[i].sMsgType , "D")==0 )
		{

			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{
				logDebug3(" The tag [%d]",ExchCfgStruct[i].iTagList[j]);

				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 11:
						fTrim(fixNewOrderRequest->sClOrdId, strlen(fixNewOrderRequest->sClOrdId));
						logDebug3(" DP ClOrdId Before: %s",fixNewOrderRequest->sClOrdId);
						sprintf(temp, "11=%s%c", fixNewOrderRequest->sClOrdId, FIX_FIELD_DELIMITER);
						logDebug3(" DP ClOrdId After: %s",temp);
						strcat(pMemOut, temp);
						break;

					case 1:
						fTrim(fixNewOrderRequest->sAccount, strlen(fixNewOrderRequest->sAccount));
						sprintf(temp, "1=%s%c", fixNewOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 21:
						logDebug3(" fixNewOrderRequest->cHandlInst :%c: :%c:",fixNewOrderRequest->cHandlInst,fixNewOrderRequest->cHandlInst);
						sprintf(temp, "21=%c%c", fixNewOrderRequest->cHandlInst, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 59:
						logDebug2("fixNewOrderRequest->cTimeInForce :%c:",fixNewOrderRequest->cTimeInForce);
						sprintf(temp, "59=%c%c", fixNewOrderRequest->cTimeInForce, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						logDebug2("temp :%c:",temp);
						break;

					case 110:
						if(fixNewOrderRequest->fMinQty != 0)
						{
							sprintf(temp, "110=%.0lf%c", fixNewOrderRequest->fMinQty, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 1138:
						if(fixNewOrderRequest->fMaxFloor != 0)
						{
							sprintf(temp, "1138=%.0lf%c", fixNewOrderRequest->fMaxFloor, FIX_FIELD_DELIMITER);
							logDebug2("DiscQty :%.0lf:",fixNewOrderRequest->fMaxFloor);
							strcat(pMemOut, temp);
						}
						break;

					case 55:
						logDebug3(" 55 : %s",fixNewOrderRequest->sSymbol);
						fTrim(fixNewOrderRequest->sSymbol, strlen(fixNewOrderRequest->sSymbol));
						logDebug3(" 55 : %s",fixNewOrderRequest->sSymbol);
						sprintf(temp, "55=%s%c", fixNewOrderRequest->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 65:
						fTrim(fixNewOrderRequest->sSymbolSfx, strlen(fixNewOrderRequest->sSymbolSfx));
						logDebug3(" 65 : %s",fixNewOrderRequest->sSymbolSfx);
						sprintf(temp, "65=%s%c", fixNewOrderRequest->sSymbolSfx, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 48:
						fTrim(fixNewOrderRequest->sSecurityId, strlen(fixNewOrderRequest->sSecurityId));
						logDebug2("Sec-Id is:%s:",fixNewOrderRequest->sSecurityId);
						sprintf(temp, "48=%s%c", fixNewOrderRequest->sSecurityId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 22:
						fTrim(fixNewOrderRequest->sIdSource,strlen(fixNewOrderRequest->sIdSource));
						sprintf(temp,"22=%s%c",fixNewOrderRequest->sIdSource,FIX_FIELD_DELIMITER);
						strcat(pMemOut,temp);
						break;

					case 54:
						sprintf(temp, "54=%c%c", fixNewOrderRequest->cSide, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 60:
						fTrim(fixNewOrderRequest->sTransactTime, strlen(fixNewOrderRequest->sTransactTime));
						sprintf(temp, "60=%s%c",fixNewOrderRequest->sTransactTime,FIX_FIELD_DELIMITER);
						logDebug2("fixNewOrderRequest->sTransactTime :%s:",fixNewOrderRequest->sTransactTime);
						strcat(pMemOut, temp);
						break;

					case 38:
						sprintf(temp, "38=%.0lf%c", fixNewOrderRequest->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 40:
						sprintf(temp, "40=%c%c", fixNewOrderRequest->cOrderType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);

						if ( (fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_LIMIT) || (fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT) )
						{	
							logDebug2("before mapping price :%lf:",fixNewOrderRequest->fPrice );
							//fPrice = fixNewOrderRequest->fPrice * ICEX_CONST_PRICE_FACTOR;
							fPrice = fixNewOrderRequest->fPrice;
							/*the order price which is coming from FE send to Exchange*/
							logDebug2("fPrice :%.02f:",fPrice);
							sprintf(temp, "44=%.02f%c", fPrice,FIX_FIELD_DELIMITER);//fixNewOrderRequest->fPrice, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}

						if ( fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLOSS || fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT						|| fixNewOrderRequest->cOrderType == FIX_ORD_TYPE_MKT_TOUCH)
						{

							//fStopPx= fixNewOrderRequest->fStopPx * ICEX_CONST_PRICE_FACTOR;
							fStopPx= fixNewOrderRequest->fStopPx ;
                                                        logDebug2("fStopPx:%.02f:",fStopPx);
		
							sprintf(temp,"99=%.02f%c",fStopPx,FIX_FIELD_DELIMITER);
							//							sprintf(temp,"99=%.0lf%c",fixNewOrderRequest->fStopPx,FIX_FIELD_DELIMITER);
							//		iStopPx = fixNewOrderRequest->fStopPx;
							//		logDebug2("iStopPx :%d:",iStopPx);
							strcat(pMemOut,temp);
						}
						break;

					case 47:
						sprintf(temp, "47=A%c",  FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
						/** Tag 126 : ExpireDate : Not needed as ExpireDate is already there. ***/

					case 432:
						if ( fixNewOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{
							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
							strncpy(temp1,fixNewOrderRequest->sExpireDate,8);
							sprintf(temp, "432=%s%c", temp1, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;

					case 126:
						if ( fixNewOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{
							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
							sprintf(temp, "432=%s%c", fixNewOrderRequest->sExpireDate, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 376:
						fTrim(fixNewOrderRequest->sComplianceID,strlen(fixNewOrderRequest->sComplianceID));
						sprintf(temp, "376=%s%c", fixNewOrderRequest->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 58:
						fTrim(fixNewOrderRequest->sText, TEXT_LEN);
						if( strcmp(fixNewOrderRequest->sText, "") != 0 )
						{
							sprintf(temp, "58=%s%c", fixNewOrderRequest->sText, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 581:
						sprintf(temp, "581=%d%c", fixNewOrderRequest->iCustomerOrFirm, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 440:
						sprintf(temp, "440=%s%c", fixNewOrderRequest->sClearingFirm, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
			
					case 453:
						sprintf(temp, "453=1%c", FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
						logDebug2("IN LOOP PARTY ID");
						for(k=0;k<1;k++)
						{
							logDebug2("fixNewOrderRequest->sPartycomp[%d].sPartyId :%s:",k,fixNewOrderRequest->sPartycomp[k].sPartyId);
							sprintf(temp, "448=%s%c", fixNewOrderRequest->sPartycomp[k].sPartyId, FIX_FIELD_DELIMITER);
							logDebug2("448 :%s:",temp);
                                                        strcat(pMemOut, temp);
							logDebug2("fixNewOrderRequest->sPartycomp[%d].cPartySrc :%c:",k,fixNewOrderRequest->sPartycomp[k].cPartySrc);
							sprintf(temp, "447=%c%c", fixNewOrderRequest->sPartycomp[k].cPartySrc, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
							logDebug2("447 :%c:",temp);
							logDebug2("fixNewOrderRequest->sPartycomp[%d].sPartyRole :%s:",k,fixNewOrderRequest->sPartycomp[k].sPartyRole);
							sprintf(temp, "452=%s%c", fixNewOrderRequest->sPartycomp[k].sPartyRole, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
							logDebug2("452 :%s:",temp);
						}

						break;

/*					case 448:
						logDebug3(" fixNewOrderRequest->sTerminalInfo :%s:",fixNewOrderRequest->sTerminalInfo);
						sprintf(temp, "448=%s%c",sSenderCompId, FIX_FIELD_DELIMITER);
						logDebug2("sSenderCompId :%s:",sSenderCompId);
						strcat(pMemOut, temp);
						break;
					case 447:
                                                sprintf(temp,"447=D%c", FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;

					case 452:
                                                sprintf(temp,"452=44%c", FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;*/

					case 9724:
						logDebug3(" fixNewOrderRequest->sTerminalInfo :%s:",fixNewOrderRequest->sTerminalInfo);
						sprintf(temp, "9724=1%c",  FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 167:
						if((strncmp(fixNewOrderRequest->sSecurityType,OPTION,3)==0)||(strncmp(fixNewOrderRequest->sSecurityType,FUTURE,3)==0))
						{

							sprintf(temp, "200=%s%c",fixNewOrderRequest->sMaturityMonthYear,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "167=%s%c",fixNewOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "205=%s%c",fixNewOrderRequest->sMaturityDay,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							if(strncmp(fixNewOrderRequest->sSecurityType,OPTION,3) == 0)
							{
								logDebug2("fixNewOrderRequest->fStrikePrice :%lf: :%.0lf:",fixNewOrderRequest->fStrikePrice,fixNewOrderRequest->fStrikePrice);
								sprintf(temp, "202=%lf%c",fixNewOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
								sprintf(temp, "206=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "201=%d%c",fixNewOrderRequest->iPutOrCall,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);	

								sprintf(temp,"460=%d%c",fixNewOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);


							}
							else if(strncmp(fixNewOrderRequest->sSecurityType,FUTURE,3) == 0)
							{
								sprintf(temp,"460=%d%c",fixNewOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
							}


						}	
						else
						{
							sprintf(temp, "167=%s%c",fixNewOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;				
				}/**** End of Switch Case *****/
			}/**** End of for loop 2 ****/
			break;
		}/**** End of if Statement *****/
	}/***** End of for loop 1 ****/
	logDebug3(" Leaving [NewOrderRequest]:<TRUE>");
	//		return TRUE;
	logTimestamp("EXIT : [NewOrderRequest]");
	return TRUE;
}/**** End of NewOrderRequest ****/

BOOL ModifyOrderRequest(FIX_ORDER_MODIFICATION_ICEX_REQUEST *fixModOrderRequest, CHAR *pMemOut)
{
	logTimestamp("Entry : [ModifyOrderRequest]");


	CHAR temp[RUPEE_MAX_PACKET_SIZE];
	SHORT iNoTradingSessions =0;
	CHAR temp1[RUPEE_MAX_PACKET_SIZE];
	LONG32  i,j,k ;
	CHAR    sSenderSubId[ENTITY_ID_LEN];
//	LONG32  iPrice=0;
	DOUBLE64 fPrice=0.00;
//	LONG32 	iStopPx=0;
	DOUBLE64 fStopPx=0.00;
	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);
	memset(temp1, 0, RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId, 0, ENTITY_ID_LEN);

	if( MapToHeader( &(fixModOrderRequest->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [ModifyOrderRequest]:<FALSE>");
		return FALSE;
	}

	strncpy(sSenderSubId,fixModOrderRequest->FIXHeader.sSenderSubID,strlen(fixModOrderRequest->FIXHeader.sSenderSubID));
	logDebug3(" SenderSub id = [%s]",sSenderSubId );	
	logDebug3(" MaturityDay_is = [%s]",fixModOrderRequest->sMaturityDay);
	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{

		//if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'G' )
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && strcmp(ExchCfgStruct[i].sMsgType ,"G") ==0 )
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{

				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 37:
						fTrim(fixModOrderRequest->sOrderID, strlen(fixModOrderRequest->sOrderID));
						sprintf(temp, "37=%s%c", fixModOrderRequest->sOrderID, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 41:
						fTrim(fixModOrderRequest->sOrigClOrdId, strlen(fixModOrderRequest->sOrigClOrdId));
						sprintf(temp, "41=%s%c", fixModOrderRequest->sOrigClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 11:
						fTrim(fixModOrderRequest->sClOrdId, strlen(fixModOrderRequest->sClOrdId));
						sprintf(temp, "11=%s%c", fixModOrderRequest->sClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 1:
						fTrim(fixModOrderRequest->sAccount, strlen(fixModOrderRequest->sAccount));
						sprintf(temp, "1=%s%c", fixModOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 21:
						sprintf(temp, "21=%c%c", fixModOrderRequest->cHandlInst, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 9724:
						logDebug3(" fixModOrderRequest->sTerminalInfo :%s:",fixModOrderRequest->sTerminalInfo);
						sprintf(temp, "9724=1%c",  FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 110:
						if(fixModOrderRequest->fMinQty != 0)
						{
							sprintf(temp, "110=%.0lf%c", fixModOrderRequest->fMinQty, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 1138:
						if(fixModOrderRequest->fMaxFloor != 0)
						{
							sprintf(temp, "1138=%.0lf%c", fixModOrderRequest->fMaxFloor, FIX_FIELD_DELIMITER);
							logDebug2("Modifying DiscQty :%.0lf:",fixModOrderRequest->fMaxFloor);
							strcat(pMemOut, temp);
						}
						break;

					case 55:
						logDebug3(" 55 : %s",fixModOrderRequest->sSymbol);
						fTrim(fixModOrderRequest->sSymbol, strlen(fixModOrderRequest->sSymbol));
						sprintf(temp, "55=%s%c", fixModOrderRequest->sSymbol, FIX_FIELD_DELIMITER);
						logDebug3(" 55 : %s",temp);
						strcat(pMemOut, temp);
						break;

					case 65:
						printf("\n In Here 65 : %s",fixModOrderRequest->sSymbolSfx);
						fTrim(fixModOrderRequest->sSymbolSfx, strlen(fixModOrderRequest->sSymbolSfx));
						sprintf(temp, "65=%s%c", fixModOrderRequest->sSymbolSfx, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 376:
						fTrim(fixModOrderRequest->sComplianceID,strlen(fixModOrderRequest->sComplianceID));
						sprintf(temp, "376=%s%c", fixModOrderRequest->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 204:
						sprintf(temp, "204=%d%c",fixModOrderRequest->iCustomerOrFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 440:
						fTrim(fixModOrderRequest->sClearingFirm,strlen(fixModOrderRequest->sClearingFirm));
						sprintf(temp, "440=%s%c", fixModOrderRequest->sClearingFirm,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 6000:
						fTrim(fixModOrderRequest->sLastModTime,strlen(fixModOrderRequest->sLastModTime));
						sprintf(temp, "6000=%s%c", fixModOrderRequest->sLastModTime,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 14:
						sprintf(temp, "14=%d%c", fixModOrderRequest->dCumQty, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 48:
						fTrim(fixModOrderRequest->sSecurityId, strlen(fixModOrderRequest->sSecurityId));
						sprintf(temp, "48=%s%c", fixModOrderRequest->sSecurityId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 22:
						fTrim(fixModOrderRequest->sIdSource,strlen(fixModOrderRequest->sIdSource));
						sprintf(temp,"22=%s%c",fixModOrderRequest->sIdSource,FIX_FIELD_DELIMITER);
						strcat(pMemOut,temp);
						break;

					case 54:
						logDebug3(" In Here 54 : %c",fixModOrderRequest->cSide);
						sprintf(temp, "54=%c%c", fixModOrderRequest->cSide, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 60:
						fTrim(fixModOrderRequest->sTransactTime, strlen(fixModOrderRequest->sTransactTime));
						sprintf(temp, "60=%s%c", fixModOrderRequest->sTransactTime, FIX_FIELD_DELIMITER);
						logDebug2("fixModOrderRequest->sTransactTime :%s:",fixModOrderRequest->sTransactTime);
						strcat(pMemOut, temp);
						break;

					case 38:
						fixModOrderRequest->fQuantity = fixModOrderRequest->fQuantity +	fixModOrderRequest->dCumQty ;
						sprintf(temp, "38=%.0lf%c", fixModOrderRequest->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 40:
						sprintf(temp, "40=%c%c", fixModOrderRequest->cOrderType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);

						logDebug3(" fixModOrderRequest->cOrderType :%c:",fixModOrderRequest->cOrderType);

						logDebug3(" FIX_ORD_TYPE_LIMIT:%c:,FIX_ORD_TYPE_STOPLIMIT:%c:,FIX_ORD_TYPE_STOPLOSS:%c:,FIX_ORD_TYPE_STOPLIMIT:%c:",FIX_ORD_TYPE_LIMIT,FIX_ORD_TYPE_STOPLIMIT,FIX_ORD_TYPE_STOPLOSS,FIX_ORD_TYPE_STOPLIMIT);

						if ( fixModOrderRequest->cOrderType == FIX_ORD_TYPE_LIMIT || fixModOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT )
						{
							fPrice = fixModOrderRequest->fPrice ;
							/*the order price which is coming from FE send to Exchange*/
                                                        logDebug2("fPrice :%.02f:",fPrice);
						
						/*	iPrice=fixModOrderRequest->fPrice*MCX_CONST_PRICE_FACTOR;
							logDebug2("iPrice :%d:",iPrice); */
							sprintf(temp, "44=%.02f%c", fPrice,FIX_FIELD_DELIMITER);//fixModOrderRequest->fPrice, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							//	sprintf(temp, "44=%lf%c", fixModOrderRequest->fPrice, FIX_FIELD_DELIMITER);
							//	strcat(pMemOut, temp);
						}

						if ( fixModOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLOSS || fixModOrderRequest->cOrderType == FIX_ORD_TYPE_STOPLIMIT)
						{
							fStopPx= fixModOrderRequest->fStopPx ;
                                                        logDebug2("fStopPx:%.02f:",fStopPx);

						/*	iStopPx = fixModOrderRequest->fStopPx * MCX_CONST_PRICE_FACTOR;
							logDebug2("iStopPx :%d:",iStopPx);*/
							sprintf(temp,"99=%.02f%c",fStopPx,FIX_FIELD_DELIMITER);
							//	iStopPx = fixModOrderRequest->fStopPx;
							//	logDebug2("iStopPx :%d:",iStopPx);
							strcat(pMemOut,temp);
						}
						break;

					case 59:
						sprintf(temp, "59=%c%c", fixModOrderRequest->cTimeInForce, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 47:
						sprintf(temp, "47=A%c",  FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 126:
						if ( fixModOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{

							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
							strcpy(temp,fixModOrderRequest->sExpireTime);
							sprintf(temp, "126=%s%c", fixModOrderRequest->sExpireTime, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
							memset (temp,'\0',RUPEE_MAX_PACKET_SIZE);
						}
						break;

					case 432:
						if ( fixModOrderRequest->cTimeInForce == FIX_TIME_IN_FORCE_GTD )
						{

							//strncpy(temp1,fixModOrderRequest->sExpireTime,8);
							strncpy(temp1,fixModOrderRequest->sExpireDate,8);
							//temp1[8] = 0;
							logDebug2("******temp1******:%s:",temp1);
							sprintf(temp, "432=%s%c",temp1, FIX_FIELD_DELIMITER);
							logDebug2("******temp******:%s:",temp);
							
							strcat(pMemOut, temp);
						}
						break;

					case 100:
						if( strcmp(fixModOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixModOrderRequest->sSecurityEx,strlen(fixModOrderRequest->sSecurityEx));
							sprintf(temp, "100=%s%c", fixModOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 207:
						if( strcmp(fixModOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixModOrderRequest->sSecurityEx,strlen(fixModOrderRequest->sSecurityEx));
							sprintf(temp, "207=%s%c", fixModOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 15:
						fTrim(fixModOrderRequest->sCurrency,strlen(fixModOrderRequest->sCurrency));
						sprintf(temp, "15=%s%c", fixModOrderRequest->sCurrency,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
/*
					case 453:
						sprintf(temp, "453=0%c", FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;*/
/*
					case 448:
						sprintf(temp, "448=%s%c", fixModOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;*/

/*					case 452:
						sprintf(temp, "452=3%c", FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;*/
					 case 453:
                                                sprintf(temp, "453=1%c", FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                logDebug2("IN LOOP PARTY ID");
                                                for(k=0;k<1;k++)
                                                {
                                                        logDebug2("fixModOrderRequest->sPartycomp[%d].sPartyId :%s:",k,fixModOrderRequest->sPartycomp[k].sPartyId);
                                                        sprintf(temp, "448=%s%c", fixModOrderRequest->sPartycomp[k].sPartyId, FIX_FIELD_DELIMITER);
                                                        logDebug2("448 :%s:",temp);
                                                        strcat(pMemOut, temp);
                                                        logDebug2("fixModOrderRequest->sPartycomp[%d].cPartySrc :%c:",k,fixModOrderRequest->sPartycomp[k].cPartySrc);
                                                        sprintf(temp, "447=%c%c", fixModOrderRequest->sPartycomp[k].cPartySrc, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                        logDebug2("447 :%c:",temp);
                                                        logDebug2("fixModOrderRequest->sPartycomp[%d].sPartyRole :%s:",k,fixModOrderRequest->sPartycomp[k].sPartyRole);
                                                        sprintf(temp, "452=%s%c", fixModOrderRequest->sPartycomp[k].sPartyRole, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                        logDebug2("452 :%s:",temp);
                                                }

                                                break;


					case 167:
						if((strcmp(fixModOrderRequest->sSecurityType,OPTION)==0)||(strcmp(fixModOrderRequest->sSecurityType,FUTURE)==0))
						{
							/*	sprintf(temp, "203=%c%c",fixModOrderRequest->cCoverUncover,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);*/

							/*	sprintf(temp, "77=%c%c",fixModOrderRequest->cOpenCloseFlg,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);*/

							logDebug2("sMaturityMonthYear :%s: sSecurityType :%s: sMaturityDay :%s:",fixModOrderRequest->sMaturityMonthYear,fixModOrderRequest->sSecurityType,fixModOrderRequest->sMaturityDay);

							sprintf(temp, "200=%s%c",fixModOrderRequest->sMaturityMonthYear,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							logDebug2("This is halfstr 1:%s:",pMemOut);

							sprintf(temp, "167=%s%c",fixModOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
							logDebug2("This is halfstr 2:%s:",pMemOut);

							sprintf(temp, "205=%s%c",fixModOrderRequest->sMaturityDay,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							if(strcmp(fixModOrderRequest->sSecurityType,OPTION) == 0)
							{
								logDebug2("fixModOrderRequest->fStrikePrice :%.0lf:",fixModOrderRequest->fStrikePrice);
								sprintf(temp, "202=%lf%c",fixModOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "206=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "201=%d%c",fixModOrderRequest->iPutOrCall,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								/*		sprintf(temp, "204=1%c",FIX_FIELD_DELIMITER);

										strcat(pMemOut, temp);*/

								sprintf(temp,"460=%d%c",fixModOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "77=%c%c",fixModOrderRequest->cOpenCloseFlg,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);


							}
							else if(strncmp(fixModOrderRequest->sSecurityType,FUTURE,3)==0)
							{
								sprintf(temp,"460=%d%c",fixModOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
							}



						}
						else
						{
							sprintf(temp, "167=%s%c",fixModOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;


				}/*** End of switch ***/
			}/*** End of for loop 2 ****/
			break;
		}/*** End of if *****/
	}/*** End of for loop 1 ****/

	logDebug3(" Leaving [ModifyOrderRequest]:<TRUE>");
	return TRUE;
	logTImestamp("EXIT : [ModifyOrderRequest]");
}/*** End of ModifyOrderRequest ****/

BOOL CancelOrderRequest( FIX_ORDER_CANCEL_ICEX_REQUEST *fixCanOrderRequest, CHAR *pMemOut )
{
	logTimestamp("Entry : [CancelOrderRequest]");

	CHAR	temp[RUPEE_MAX_PACKET_SIZE];
	LONG32	i,j,k ;
	CHAR	sSenderSubId[ENV_VARIABLE_LEN];

	memset(temp, 0, RUPEE_MAX_PACKET_SIZE);
	memset(sSenderSubId, 0, ENV_VARIABLE_LEN);


	if( MapToHeader (&( fixCanOrderRequest->FIXHeader), pMemOut) == FALSE )
	{
		logDebug3(" Leaving [CancelOrderRequest]:<FALSE>");
		return FALSE;
	}

	strncpy(sSenderSubId,fixCanOrderRequest->FIXHeader.sSenderSubID,ENV_VARIABLE_LEN);
	logInfo(" SenderSub id = [%s]",sSenderSubId );
	logInfo("ExchCfgStruct[i].sDelToTargetComp =[%s]",ExchCfgStruct[i].sDelToTargetComp);
	logInfo(" SenderSub id = [%s]",fixCanOrderRequest->FIXHeader.sSenderSubID );
	logInfo(" CFG_STRUCT_LEN = [%i]",CFG_STRUCT_LEN );

	for ( i = 0;i < CFG_STRUCT_LEN ; i++)
	{
		//if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && ExchCfgStruct[i].cMsgType == 'F' )
		if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && strcmp(ExchCfgStruct[i].sMsgType , "F")==0 )
		{
			for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
			{
				logInfo(" Cancellation order Tags : [%d]",ExchCfgStruct[i].iTagList[j]);
				switch(ExchCfgStruct[i].iTagList[j])
				{
					case 41:
						fTrim(fixCanOrderRequest->sOrigClOrdId, strlen(fixCanOrderRequest->sOrigClOrdId));
						logDebug1(" 41 : %s",fixCanOrderRequest->sOrigClOrdId);
						sprintf(temp, "41=%s%c", fixCanOrderRequest->sOrigClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 37:
						fTrim(fixCanOrderRequest->sOrderID, strlen(fixCanOrderRequest->sOrderID));
						logDebug1(" 37 : %s",fixCanOrderRequest->sOrderID);
						sprintf(temp, "37=%s%c", fixCanOrderRequest->sOrderID, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 11:
						fTrim(fixCanOrderRequest->sClOrdId, strlen(fixCanOrderRequest->sClOrdId));
						logDebug1(" 11 : %s",fixCanOrderRequest->sClOrdId);
						sprintf(temp, "11=%s%c", fixCanOrderRequest->sClOrdId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 1:
						fTrim(fixCanOrderRequest->sAccount, strlen(fixCanOrderRequest->sAccount));
						logDebug1(" 1 : %s",fixCanOrderRequest->sAccount);
						sprintf(temp, "1=%.12s%c", fixCanOrderRequest->sAccount, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 22:
						fTrim(fixCanOrderRequest->sIdSource,strlen(fixCanOrderRequest->sIdSource));
						logDebug1(" 22 : %s",fixCanOrderRequest->sIdSource);
						sprintf(temp,"22=%s%c",fixCanOrderRequest->sIdSource,FIX_FIELD_DELIMITER);
						strcat(pMemOut,temp);
						break;

					case 48:
						fTrim(fixCanOrderRequest->sSecurityId, strlen(fixCanOrderRequest->sSecurityId));
						logDebug1(" 48 : %s",fixCanOrderRequest->sSecurityId);
						sprintf(temp, "48=%s%c", fixCanOrderRequest->sSecurityId, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 55:
						fTrim(fixCanOrderRequest->sSymbol, strlen(fixCanOrderRequest->sSymbol));
						logDebug1(" 55 : %s",fixCanOrderRequest->sSymbol);
						sprintf(temp, "55=%s%c", fixCanOrderRequest->sSymbol, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 54:
						logDebug1(" 54 : %c",fixCanOrderRequest->cSide);
						sprintf(temp, "54=%c%c", fixCanOrderRequest->cSide, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 65:
						logDebug1(" In Here 65 : %s",fixCanOrderRequest->sSymbolSfx);
						fTrim(fixCanOrderRequest->sSymbolSfx, strlen(fixCanOrderRequest->sSymbolSfx));
						sprintf(temp, "65=%s%c", fixCanOrderRequest->sSymbolSfx, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 40:
						sprintf(temp, "40=%c%c", fixCanOrderRequest->cOrderType, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 60:
						fTrim(fixCanOrderRequest->sTransactTime, FIX_DATE_TIME_LEN);
						logDebug1(" 60 : %s",fixCanOrderRequest->sTransactTime);
						sprintf(temp, "60=%s%c", fixCanOrderRequest->sTransactTime, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 38:
						logDebug1(" 38 : %f",fixCanOrderRequest->fQuantity);
						sprintf(temp, "38=%.0lf%c", fixCanOrderRequest->fQuantity, FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 100:
						if( strcmp(fixCanOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixCanOrderRequest->sSecurityEx,strlen(fixCanOrderRequest->sSecurityEx));
							sprintf(temp, "100=%s%c", fixCanOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 207:
						if( strcmp(fixCanOrderRequest->sSecurityEx, "") != 0 )
						{
							fTrim(fixCanOrderRequest->sSecurityEx,strlen(fixCanOrderRequest->sSecurityEx));
							sprintf(temp, "207=%s%c", fixCanOrderRequest->sSecurityEx, FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);
						}
						break;

					case 376:
						fTrim(fixCanOrderRequest->sComplianceID,strlen(fixCanOrderRequest->sComplianceID));
						sprintf(temp, "376=%s%c", fixCanOrderRequest->sComplianceID,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;
					case 453:
                                                sprintf(temp, "453=1%c", FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                logDebug2("IN LOOP PARTY ID");
                                                for(k=0;k<1;k++)
                                                {
                                                        logDebug2("fixCanOrderRequest->sPartycomp[%d].sPartyId :%s:",k,fixCanOrderRequest->sPartycomp[k].sPartyId);
                                                        sprintf(temp, "448=%s%c", fixCanOrderRequest->sPartycomp[k].sPartyId, FIX_FIELD_DELIMITER);
                                                        logDebug2("448 :%s:",temp);
                                                        strcat(pMemOut, temp);
                                                        logDebug2("fixCanOrderRequest->sPartycomp[%d].cPartySrc :%c:",k,fixCanOrderRequest->sPartycomp[k].cPartySrc);
                                                        sprintf(temp, "447=%c%c", fixCanOrderRequest->sPartycomp[k].cPartySrc, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                        logDebug2("447 :%c:",temp);
                                                        logDebug2("fixCanOrderRequest->sPartycomp[%d].sPartyRole :%s:",k,fixCanOrderRequest->sPartycomp[k].sPartyRole);
                                                        sprintf(temp, "452=%s%c", fixCanOrderRequest->sPartycomp[k].sPartyRole, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                        logDebug2("452 :%s:",temp);
                                                }

                                                break;

					
					case 77:
						sprintf(temp, "77=%c%c",fixCanOrderRequest->cOpenCloseFlg,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break ;

					case 203:
						sprintf(temp, "203=%c%c",fixCanOrderRequest->cCoverUncover,FIX_FIELD_DELIMITER);
						strcat(pMemOut, temp);
						break;

					case 167:
						if((strcmp(fixCanOrderRequest->sSecurityType,OPTION)==0)||(strcmp(fixCanOrderRequest->sSecurityType,FUTURE)==0))
						{

							sprintf(temp, "200=%s%c",fixCanOrderRequest->sMaturityMonthYear,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "167=%s%c",fixCanOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							sprintf(temp, "205=%s%c",fixCanOrderRequest->sMaturityDay,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

							if(strcmp(fixCanOrderRequest->sSecurityType,OPTION) == 0)
							{
								logDebug2("fixCanOrderRequest->fStrikePrice :%.0lf:",fixCanOrderRequest->fStrikePrice);
								sprintf(temp, "202=%lf%c",fixCanOrderRequest->fStrikePrice,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "206=%c%c",EUROPEAN,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

								sprintf(temp, "201=%d%c",fixCanOrderRequest->iPutOrCall,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);


								sprintf(temp,"460=%d%c",fixCanOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);

							}
							else if(strncmp(fixCanOrderRequest->sSecurityType,FUTURE,3)==0)
							{
								sprintf(temp,"460=%d%c",fixCanOrderRequest->iProduct,FIX_FIELD_DELIMITER);
								strcat(pMemOut, temp);
							}							

						}
						else
						{
							sprintf(temp, "167=%s%c",fixCanOrderRequest->sSecurityType,FIX_FIELD_DELIMITER);
							strcat(pMemOut, temp);

						}
						break;

					default :
						logDebug3("Invalid Tag");

				}/**** End of switch ****/
			}/***** for loop 2 ****/
			break;
		}
	}
	logTimestamp("Exit : [CancelOrderRequest]");
	return TRUE;

}/***** END of CancelOrderRequest *****/

BOOL NewSpreadOrderRequest( FIX_SPREAD_NEW_ORDER_REQUEST *fixSprdNewOrdReq , CHAR *pMemOut)
{
        logTimestamp("Entry : [NewSpreadOrderRequest]");
        CHAR    temp[RUPEE_MAX_PACKET_SIZE];
        //      CHAR    temp1[RUPEE_MAX_PACKET_SIZE];
        LONG32  i,j,k,iCount=0 ;
        CHAR    sSenderSubId[ENTITY_ID_LEN];

        memset(temp,'\0', RUPEE_MAX_PACKET_SIZE);
        //      memset(temp1,'\0', RUPEE_MAX_PACKET_SIZE);
        memset(sSenderSubId,'\0',ENTITY_ID_LEN);

        if( MapToHeader( &(fixSprdNewOrdReq->FIXHeader), pMemOut) == FALSE )
        {
                logDebug3(" Leaving [NewOrderRequest]:<FALSE>");
                return FALSE;
        }
        strncpy(sSenderSubId,fixSprdNewOrdReq->FIXHeader.sSenderSubID,strlen(fixSprdNewOrdReq->FIXHeader.sSenderSubID));
        logDebug2(" SenderSub id = [%s]",sSenderSubId );
        for ( i = 0;i < CFG_STRUCT_LEN ; i++)
        {
                if ( strcmp(ExchCfgStruct[i].sDelToTargetComp,sSenderSubId ) == 0 && strcmp(ExchCfgStruct[i].sMsgType , "U14")==0 )  /*here*/
                {
                        for ( j = 0 ; j< ExchCfgStruct[i].iNoOfTags; j++ )
                        {
                                logDebug2(" The tag [%d]",ExchCfgStruct[i].iTagList[j]);
                                switch(ExchCfgStruct[i].iTagList[j])
                                {
                                        case 11:
                                                fTrim(fixSprdNewOrdReq->sClOrdId, strlen(fixSprdNewOrdReq->sClOrdId));
                                                sprintf(temp, "11=%s%c", fixSprdNewOrdReq->sClOrdId, FIX_FIELD_DELIMITER);
                                                logDebug3(" DP ClOrdId : %s",temp);
                                                strcat(pMemOut, temp);
                                                break;
                                        case 9233:
                                                sprintf(temp, "9233=%d%c", fixSprdNewOrdReq->iMLOrdAttrb, FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;
                                        case 146:
                                                sprintf(temp, "146=%d%c", fixSprdNewOrdReq->iNumOfSecurity, FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
						//iCount++;
						logDebug3("1");
						logDebug2("fixSprdNewOrdReq->iNumOfSecurity :%d:",fixSprdNewOrdReq->iNumOfSecurity);
                                             //   break;
						for(k=0;k<fixSprdNewOrdReq->iNumOfSecurity;k++)
						{
							logDebug3("2");
								//case 48:
	                                                        fTrim(fixSprdNewOrdReq->sSpreadLeg[k].sSecurityId, strlen(fixSprdNewOrdReq->sSpreadLeg[k].sSecurityId));
        	                                                sprintf(temp, "48=%s%c", fixSprdNewOrdReq->sSpreadLeg[k].sSecurityId, FIX_FIELD_DELIMITER);
                	                                        logDebug2("fixSprdNewOrdReq->sSecurityId:%s:",fixSprdNewOrdReq->sSpreadLeg[k].sSecurityId);
                        	                                strcat(pMemOut, temp);
								logDebug3("3");
							//break;
					//			case 54:
                                                	        sprintf(temp, "54=%c%c", fixSprdNewOrdReq->sSpreadLeg[k].cSide, FIX_FIELD_DELIMITER);
                                                        	strcat(pMemOut, temp);
								logDebug3("4");
					//		break;
					//			case 38:
                	                                        sprintf(temp, "38=%.0lf%c", fixSprdNewOrdReq->sSpreadLeg[k].fQuantity, FIX_FIELD_DELIMITER);
                        	                	        strcat(pMemOut, temp);
								logDebug3("5");
					//		break;
					//			case 40:
							/*the order price which is coming from FE send to Exchange*/
								sprintf(temp, "44=%.02f%c", fixSprdNewOrdReq->sSpreadLeg[k].fPrice, FIX_FIELD_DELIMITER);
        	                                                strcat(pMemOut, temp);
								logDebug2("fprice");
								logDebug2("temp :%.0lf:",temp);
	
                                                	        sprintf(temp, "40=%c%c",fixSprdNewOrdReq->sSpreadLeg[k].cOrderType,FIX_FIELD_DELIMITER);
                                                        	strcat(pMemOut, temp);	
								logDebug3("6");
					//		break;
                                                }	
						break;	

	/*
                                        case 48:
                                                if(iCount==1)
                                                {
                                                        fTrim(fixSprdNewOrdReq->sSecurityId_L1, strlen(fixSprdNewOrdReq->sSecurityId_L1));
                                                        sprintf(temp, "48=%s%c", fixSprdNewOrdReq->sSecurityId_L1, FIX_FIELD_DELIMITER);
							logDebug2("fixSprdNewOrdReq->sSecurityId_L1 :%s:",fixSprdNewOrdReq->sSecurityId_L1);
                                                        strcat(pMemOut, temp);
                                                }
                                                else if(iCount==2)
                                                {
                                                        fTrim(fixSprdNewOrdReq->sSecurityId_L2, strlen(fixSprdNewOrdReq->sSecurityId_L2));
                                                        sprintf(temp, "48=%s%c", fixSprdNewOrdReq->sSecurityId_L2, FIX_FIELD_DELIMITER);
							logDebug2("fixSprdNewOrdReq->sSecurityId_L2 :%s:",fixSprdNewOrdReq->sSecurityId_L2);
                                                        strcat(pMemOut, temp);
                                                }
                                                break;*/
	/*				case 54:
                                                if(iCount==1)
                                                {
                                                        sprintf(temp, "54=%c%c", fixSprdNewOrdReq->cSide_L1, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                else if(iCount==2)
                                                {
                                                        sprintf(temp, "54=%c%c", fixSprdNewOrdReq->cSide_L2, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                break;
					case 38:
                                                if(iCount==1)
                                                {
                                                        sprintf(temp, "38=%.0lf%c", fixSprdNewOrdReq->fQuantity_L1, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                else if(iCount==2)
                                                {
                                                        sprintf(temp, "38=%.0lf%c", fixSprdNewOrdReq->fQuantity_L2, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                break;*/
/*					case 44:
                                                if(iCount==1)
                                                {
                                                        sprintf(temp, "44=%lf%c", fixSprdNewOrdReq->sSpreadLeg[0].fPrice, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                else if(iCount==2)
                                                {
                                                        sprintf(temp, "44=%lf%c",fixSprdNewOrdReq->sSpreadLeg[1].fPrice,FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                break;*/
/*					case 40:
                                        	if(iCount==1)
                                                {
                                                        sprintf(temp, "40=%c%c",fixSprdNewOrdReq->cOrderType_L1,FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
							iCount++;
                                                }
                                                else if(iCount==2)
                                                {
                                                        sprintf(temp, "40=%c%c",fixSprdNewOrdReq->cOrderType_L1,FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                break;*/
                                       case 59:
                                                sprintf(temp, "59=%c%c", fixSprdNewOrdReq->cTimeInForce, FIX_FIELD_DELIMITER);
					        logDebug2("FixReq->cTimeInForce :%c:",fixSprdNewOrdReq->cTimeInForce);
                                                strcat(pMemOut, temp);
                                                break;
 
                                        case 204:
                                                sprintf(temp, "204=%d%c",fixSprdNewOrdReq->iCustomerOrFirm,FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;
					case 1:
                                                fTrim(fixSprdNewOrdReq->sAccount, strlen(fixSprdNewOrdReq->sAccount));
                                                sprintf(temp, "1=%s%c", fixSprdNewOrdReq->sAccount, FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;

                                        case 440:
                                                fTrim(fixSprdNewOrdReq->sClearingFirm,strlen(fixSprdNewOrdReq->sClearingFirm));
                                                sprintf(temp, "440=%s%c", fixSprdNewOrdReq->sClearingFirm,FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;
					case 9227:
                                                logDebug3(" fixSprdNewOrdReq->sTerminalInfo :%s:",fixSprdNewOrdReq->sTerminalInfo);
                                                sprintf(temp, "9227=%s%c", fixSprdNewOrdReq->sTerminalInfo, FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;
					case 58:
                                                fTrim(fixSprdNewOrdReq->sText, TEXT_LEN);
                                                if( strcmp(fixSprdNewOrdReq->sText, "") != 0 )
                                                {
                                                        sprintf(temp, "58=%s%c", fixSprdNewOrdReq->sText, FIX_FIELD_DELIMITER);
                                                        strcat(pMemOut, temp);
                                                }
                                                break;

                                       /* case 76:
                                                fTrim(fixSprdNewOrdReq->sComplianceID,strlen(fixSprdNewOrdReq->sComplianceID));
                                                sprintf(temp, "76=%s%c", fixSprdNewOrdReq->sComplianceID,FIX_FIELD_DELIMITER);
                                                strcat(pMemOut, temp);
                                                break;*/
						default :
                                                logDebug3("Invalid Tag");

						 }
                        }/*End of FOR loop 2*/
                        break;
                }/*End of IF block*/
        }/*End of FOR Loop 1*/
        logTimestamp("Exit : [NewSpreadOrderRequest]");
        return TRUE;
}


SHORT  fTrim( CHAR *string , SHORT MaxLen )
{
	logTimestamp("Entry : [fTrim]");

	SHORT index=0;
	if ( MaxLen <= 0 )
		return 0 ;

	for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
		continue;

	string[index]='\0';
	logTimestamp("Exit : [fTrim]");
	return index ;                                  
}

void Loadenv()
{
	if(getenv("ICEX_COM_SENDER_COMP_ID") == NULL)
        {
                logFatal("Error : Environment variables missing : ICEX_COM_SENDER_COMP_ID");
                exit(ERROR);
        }
        else
        {
                strncpy(sSenderCompId,getenv("ICEX_COM_SENDER_COMP_ID"),ENV_VARIABLE_LEN);
        }
        logDebug2("ICEX_COM_SENDER_COMP_ID :%s:",sSenderCompId);
}
