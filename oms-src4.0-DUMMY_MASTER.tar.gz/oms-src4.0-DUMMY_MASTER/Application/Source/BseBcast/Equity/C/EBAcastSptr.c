#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
/****
#include "Queue.h"
#include "Common.h"
#include "EquBseTCodes.h"
#include "EquBseAcast.h"
 *****/
#include "IPCS.h"
#include "BseBcastDefn.h"

LONG32	iBcasttoSplitterQ ;
LONG32	iSplittertoMbpQ ;
LONG32	iBcasttoIndex ;
LONG32	iBcasttoMktStatus ;


main (int argc, char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	OpenMessgQ();
	Splitter();

}/*** End of main***/

BOOL Splitter()
{

	CHAR	RcvMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    SndMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    BasicError[ERROR_MSG_LEN]	;
	struct DUMMY_OMB_HEADER		*pRespHeader;
	INT16	iMsgCode;
	INT16	iMsgLengh;



	while ( 1 )
	{
		memset( &RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &SndMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		iMsgCode = 0;


		printf("\n\n #########Waiting in while loop to get the data ################# %d",iBcasttoSplitterQ);

		if((ReadMsgQ( iBcasttoSplitterQ, &RcvMsg, LOCAL_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			printf("(ENBcastSplitteespHeaderead Q :Qid %d", iBcasttoSplitterQ);
			exit(ERROR);
		}
		
		pRespHeader =(struct DUMMY_OMB_HEADER *) &RcvMsg ;	
 		iMsgCode = pRespHeader->iMsgType;
 		if( ( iMsgLengh = GetPktSiz ( iMsgCode )) == FALSE )
		{
			printf("\nGetPktSiz Failed in finding the length of data to be sent on Q") ;
		}


					printf("\n iMsgCode :%d: iMsgLengh :%d:",iMsgCode,iMsgLengh);

					switch (iMsgCode)
					{	
					case TC_EQU_BSE_TOUCH_LINE_BROADCAST:
					case TC_EQU_BSE_MARKET_PIC_BROADCAST:

						if(( WriteMsgQ( iSplittertoMbpQ ,&RcvMsg,iMsgLengh ,1 ) != TRUE ))
						{
							perror("Error WriteMsgQ: ");
							printf("Write Q id %d", iSplittertoMbpQ);
							exit(ERROR);
						}

						break;

					case TC_EQU_BSE_INDEX_SENSEX_BROADCAST:
					case TC_EQU_BSE_INDEX_NEW_SENSEX_BROADCAST:
					case TC_EQU_BSE_DETAIL_INDEX_BROADCAST:
						/***
						  if(( WriteMsgQ( iBcasttoIndex ,&RcvMsg,iMsgLengh ,1 ) != TRUE ))
						  {
						  perror("Error WriteMsgQ: ");
						  printf("Write Q id %d", iBcasttoIndex);
						  exit(ERROR);
						  }
						 ***/
						break;

					case TC_EQU_BSE_NEWS_BROADCAST:
				//	case TC_EQU_BSE_OPENING_PRICE_BROADCAST:
				//	case TC_EQU_BSE_CLOSING_PRICE_BROADCAST:
					case TC_EQU_BSE_SESSION_CHANGED_BROADCAST:
					case TC_EQU_BSE_AUC_SESSION_CHANGED_BROADCAST:

						/**if(( WriteMsgQ( iBcasttoMktStatus ,&RcvMsg,iMsgLengh ,1 ) != TRUE ))
						{
							perror("Error WriteMsgQ: ");
							printf("Write Q id %d", iBcasttoMktStatus);
							exit(ERROR);
						}**/

						break;





					default:
						printf("\n Invalid Tcode %d",iMsgCode);
						break;

					}


	}/** End of While**/

}
BOOL OpenMessgQ()
{

	if( ( iBcasttoSplitterQ = OpenMsgQ( (EBAAdapToSpltr))) == ERROR )
	{
		perror("Open EQU_NSE_BCAST_QUEUE :");
		exit( 1 );
	}
	if( ( iSplittertoMbpQ = OpenMsgQ( (EBASpltrToMbpUpld))) == ERROR )
	{
		perror("Open BcasttoMbpMbo :");
		exit( 1 );
	}
	/*
	   if( ( iBcasttoIndex = OpenMsgQ( (EBABSpltrToIdxUpld))) == ERROR )
	   {
	   perror("Open iBcasttoIndex :");
	   exit( 1 );
	   }
	 */
	/*if( ( iBcasttoMktStatus = OpenMsgQ( (EBABSpltrToMktSts))) == ERROR )
	{
		perror("Open iBcasttoIndex :");
		exit( 1 );
	}**/
	return TRUE;

}

LONG32 GetPktSiz ( LONG32  MsgType )
{

	LONG32  RetVal  ;

	switch ( MsgType )
	{
		/***  case    TC_EQU_BSE_TOUCH_LINE_BROADCAST      :
		  RetVal  =   sizeof (struct  OMB_TOUCHLINE_INFORMATION );
		  break       ; ***/

		case    TC_EQU_BSE_NEWS_BROADCAST     :
			RetVal  =   sizeof (struct  OMB_NEWS_HEADLINE_BROADCAST );
			break       ;

		case    TC_EQU_BSE_OPENING_PRICE_BROADCAST     :
			RetVal  =   sizeof (struct OMB_OPEN_CLOSE_PRICE_BROADCAST );
			break       ;

		case    TC_EQU_BSE_CLOSING_PRICE_BROADCAST   :
			RetVal  =   sizeof (struct OMB_OPEN_CLOSE_PRICE_BROADCAST );
			break       ;

		case     TC_EQU_BSE_SESSION_CHANGED_BROADCAST  :
			RetVal  =   sizeof (struct OMB_SESSION_CHANGE_BROADCAST );
			break       ;

		case     TC_EQU_BSE_POST_CLOSE_INDEX_BROADCAST    :
			RetVal  =   sizeof (struct  OMB_POST_CLOSING_INDEX_BROADCAST );
			break       ;

		case     TC_EQU_BSE_MARKET_PIC_BROADCAST      :
			RetVal  =   sizeof (struct  OMB_MKT_PIC_DETAIL_BROADCAST );
			break       ;


			/**        case     TC_EQU_BSE_INDEX_SENSEX_BROADCAST    :
			  RetVal  =   sizeof (struct  OMB_INDEX_SENSEX_BCAST );
			  break       ;***/
		case     TC_EQU_BSE_INDEX_NEW_SENSEX_BROADCAST :   
			RetVal  =   sizeof (struct  OMB_NEW_SENSEX_BCAST );
			break       ;
		case    TC_EQU_BSE_DETAIL_INDEX_BROADCAST   :
			RetVal  = sizeof(OMB_NEW_INDICES_DETAIL_BROADCAST);
			break;


		default :
			return FALSE;
			break       ;

	}
	return RetVal;
}

