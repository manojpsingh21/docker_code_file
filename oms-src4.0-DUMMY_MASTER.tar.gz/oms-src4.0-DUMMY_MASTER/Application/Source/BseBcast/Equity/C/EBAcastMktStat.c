#include "IPCS.h"
#include "BseBcastDefn.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

MYSQL	*BEConDB;
LONG32	iRecvQ;
LONG64	iPostCloseMKTStatus = 0;
int main(int argc, char ** argv)
{
	logTimestamp("Entry : [main]");

	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	BEConDB = DB_Connect();	

	logDebug2("Connecting to database.......");

	if(mysql_autocommit(BEConDB,1))
	{
		sql_Error(BEConDB);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}	

	if((iRecvQ = OpenMsgQ(EBABSpltrToMktSts)) == ERROR)
	{
		logDebug2("Error in Opening EBABSpltrToMktSts");
		exit(ERROR);
	}

	LoadBseEnv();
	fBcastUpdMkt();

}

BOOL	fBcastUpdMkt()
{
	INT16   iTranscodeLocal,i;
	CHAR    sRcvMsg[LOCAL_MAX_PACKET_SIZE];


	struct  DUMMY_OMB_HEADER *pForRecTransCode;
	LONG32  iCount;
	BOOL    iRetVal = FALSE;

	while(TRUE)
	{
		memset(&sRcvMsg,' ',LOCAL_MAX_PACKET_SIZE);

		if((ReadMsgQ(iRecvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		pForRecTransCode = (struct DUMMY_OMB_HEADER *) sRcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgType;

		if(iTranscodeLocal == TC_EQU_BSE_NEWS_BROADCAST)
		{
			logDebug2("In TC_EQU_BSE_NEWS_BROADCAST");	
			fBseExhNews(sRcvMsg);
		}
		else if(iTranscodeLocal == TC_EQU_BSE_SESSION_CHANGED_BROADCAST)
		{
			logDebug2("In TC_EQU_BSE_SESSION_CHANGED_BROADCAST");	
			fSessChngBrdCast(sRcvMsg);
		}
		else if(iTranscodeLocal == TC_EQU_BSE_AUC_SESSION_CHANGED_BROADCAST)
                {
                        logDebug2("In TC_EQU_BSE_AUC_SESSION_CHANGED_BROADCAST");
                        fSessAucChngBrdCast(sRcvMsg);
                }
		else
		{
			logDebug3("Not handle By this process :%d:",iTranscodeLocal);
		}


	}	
}

BOOL	fBseExhNews(CHAR *pMemIn)
{
	logTimestamp("Entry : [fBseExhNews]");
	struct  OMB_NEWS_HEADLINE_BROADCAST *pExchMsg = (struct  OMB_NEWS_HEADLINE_BROADCAST *)pMemIn;	

	CHAR    sInsertQry[MAX_QUERY_SIZE];
	memset(sInsertQry,'\0',MAX_QUERY_SIZE);

	logDebug2("News received > :%s:",pExchMsg->sNewsH1);

	sprintf(sInsertQry,"INSERT INTO EXCH_MESGS(EXMS_MSG_SEQ_NO,EXMS_TIME,EXMS_EXM_EXCH_ID,EXMS_GENERAL_MESG) VALUES ( NextVal('GEN_MSG'),current_date(),\"%s\",\"%s\");",BSE_EXCH,pExchMsg->sNewsH1);

	logDebug2("sInsertQry :%s:",sInsertQry);

	if(mysql_query(BEConDB,sInsertQry) != SUCCESS)
	{
		sql_Error(BEConDB);	
	}
	else
	{
		mysql_commit(BEConDB);
	}

	logTimestamp("Exit : [fBseExhNews]");
}

BOOL	fSessChngBrdCast(CHAR *pMemIn)
{
	logTimestamp("Entry : [fSessChngBrdCast]");
	struct  OMB_SESSION_CHANGE_BROADCAST *pSessChg = (struct  OMB_SESSION_CHANGE_BROADCAST *)pMemIn;

	CHAR    sUpdtQry[MAX_QUERY_SIZE];
	memset(sUpdtQry,'\0',MAX_QUERY_SIZE);
	CHAR	cFlag = '\0';
	INT16	iStatus = 0;
		
	logDebug2("pSessChg->iCurSession :%d:",pSessChg->iCurSession);
	logDebug2("pSessChg->iMktType :%d:",pSessChg->iMktType);
	
	//if(pSessChg->iCurSession == 0 || pSessChg->iCurSession == 1 || pSessChg->iCurSession == 2 || pSessChg->iCurSession == 3 )

	if (pSessChg->iMktType == 0)
	{
		if( pSessChg->iCurSession == 3 || pSessChg->iCurSession == 10 || pSessChg->iCurSession == 12|| pSessChg->iCurSession == 13)
		{
			iStatus = 1;
		}
		else if (pSessChg->iCurSession == 0 || pSessChg->iCurSession == 4 || pSessChg->iCurSession == 7 || pSessChg->iCurSession == 2 )
		{
			iStatus = 2;
		}
		else if (pSessChg->iCurSession == 1 )
		{
			iStatus = 0;
		}
		else if (pSessChg->iCurSession == 5 )
		{
			iStatus = 3;
		}
		else 
		{
			return;
		}
	}
	else
	{
		return;	
	}
	
	if(pSessChg->iCurSession == 4 || pSessChg->iCurSession == 7)
	{
		if(pSessChg->iCurSession == 4)//After normal market close
		{
			cFlag = NO;	
		}
		else
		{	//After post session close
			cFlag = YES;
		}
		if (iPostCloseMKTStatus == 1)
		{
			sprintf(sUpdtQry,"UPDATE BATCH_PROCESS SET BP_OFF_MKT_STATUS = \'%c\' ,BP_UPDATED_BY = \"SYSTEM\" WHERE BP_EXCH_ID = \"%s\" \
		 		AND BP_BATCH_NAME = \"OFFMKT_PUMP\" AND BP_SEGMENT = \'%c\' ;",cFlag,BSE_EXCH,EQUITY_SEGMENT);

        		logDebug2("sUpdtQry :%s:",sUpdtQry);

        		if(mysql_query(BEConDB,sUpdtQry) != SUCCESS)
        		{
                		sql_Error(BEConDB);
        		}
        		else
        		{
                		mysql_commit(BEConDB);
        		}
		}

	}
	logDebug2("iStatus :%d:",iStatus);
	sprintf(sUpdtQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_MKT_TYPE = \"%s\" AND EMM_EXCH_SEG = '\%c\' ;",iStatus,BSE_EXCH,MKT_TYPE_NL,EQUITY_SEGMENT);	

	logDebug2("sUpdtQry :%s:",sUpdtQry);

	if(mysql_query(BEConDB,sUpdtQry) != SUCCESS)
	{
		sql_Error(BEConDB);
	}
	else
	{
		mysql_commit(BEConDB);
	}
	fUpdateMktStatus_InRedis(iStatus, EQUITY_SEGMENT, BSE_EXCH, NORMAL_MARKET);

	logTimestamp("Exit : [fSessChngBrdCast]");
}



BOOL    fSessAucChngBrdCast(CHAR *pMemIn)
{
	logTimestamp("Entry : [fSessAucChngBrdCast]");
        struct  OMB_AUC_SESSION_CHANGE_BROADCAST *pSessChg = (struct  OMB_AUC_SESSION_CHANGE_BROADCAST*)pMemIn;

	CHAR    sUpdtQry[MAX_QUERY_SIZE];
	memset(sUpdtQry,'\0',MAX_QUERY_SIZE);

        INT16   iStatus = 0;

        logDebug2("pSessChg->iCurSession :%d:",pSessChg->iCurSession);
        logDebug2("pSessChg->MsgType:%d:",pSessChg->MsgType);

/*	 if (pSessChg->iMktType == 0)
        {
                if(  pSessChg->iCurSession == 5 || pSessChg->iCurSession == 3 || pSessChg->iCurSession == 1 || pSessChg->iCurSession == 10 || pSessChg->iCurSession == 12|| pSessChg->iCurSession == 2 || pSessChg->iCurSession == 13)
                {
                        iStatus = 1;
                }
                else if (pSessChg->iCurSession == 0 || pSessChg->iCurSession == 4 ||pSessChg->iCurSession == 7 )
                {
                        iStatus = 2;
                }
                else
                {
                        return;
                }
        }
        else
        {
                return;
        }*/

	if (pSessChg->iCurSession == 42)
	{
		iStatus = 1;
	}
	else if (pSessChg->iCurSession == 43)
	{
		iStatus = 2;
	}

        logDebug2("iStatus :%d:",iStatus);
        sprintf(sUpdtQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d ,EMM_LUT = NOW(),EMM_UPDATE_BY = \"SYSTEM\" WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_MKT_TYPE = \"AU\" AND EMM_EXCH_SEG =\'E\' ;",iStatus,BSE_EXCH);

        logDebug2("sUpdtQry :%s:",sUpdtQry);

        if(mysql_query(BEConDB,sUpdtQry) != SUCCESS)
        {
                sql_Error(BEConDB);
        }
        else
        {
                mysql_commit(BEConDB);
        }

	fUpdateMktStatus_InRedis(iStatus, EQUITY_SEGMENT, BSE_EXCH, AUCTION_MARKET);

	logTimestamp("Exit : [fSessAucChngBrdCast]");
}

BOOL LoadBseEnv()
{
        logTimestamp("Entry : [LoadBseEnv]");
	
	CHAR	sPostCloseMKTStatus	[ENV_VARIABLE_LEN];
	memset(sPostCloseMKTStatus,'\0',ENV_VARIABLE_LEN);

        if (getenv("POST_CLOSE_MKT_STATUS")== NULL){

                logFatal("Error : Environment variables missing : POST_CLOSE_MKT_STATUS");
                iPostCloseMKTStatus = 1;

        }
        else{
                strncpy(sPostCloseMKTStatus,getenv("POST_CLOSE_MKT_STATUS"),ENV_VARIABLE_LEN);
                iPostCloseMKTStatus = atoi (sPostCloseMKTStatus);
        }
        logTimestamp("Exit : [LoadBseEnv]");
}
