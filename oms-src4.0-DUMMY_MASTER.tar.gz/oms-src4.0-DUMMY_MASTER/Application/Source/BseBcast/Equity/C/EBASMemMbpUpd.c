#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

//redisContext *c;
redisContext *RdConn;

MYSQL   *ENMbp_con;
LONG32	iSleepTime;
main(int argc,char **argv)
{
        setbuf(stdout,0);
        logTimestamp("ENTRY [Main]");
	//c = RDConnect();
//        RdConn = RDConnect();
        RdConn =  RDConnect(REDIS_TYPE_PRICE_BCAST);
        ENMbp_con=DB_Connect();

	iSleepTime = atoi(argv[2]);
        if ( argc != 3 )
        {
                logDebug2("Argument Mismstch ");
                logDebug2("USAGE : BseCMSMemMbpUpd iSubInstance iSleepTime BseCMSMemMbpUpd ");
                iSleepTime = 3 ;
        }
	
	if(iSleepTime <= 0)
	{
		iSleepTime = 1;
	}
	logInfo("iSleepTime:%d:",iSleepTime);
        ReceiveReplyPacketsBcast();
        return 0;
        logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
        logTimestamp("ENTRY [UPDATE LTP IN DB]");
        CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];
        BOOL iStatus;
        int iCount ,i =0 ;
	MYSQL_ROW 	Row;
	MYSQL_RES	*Res;	
        CHAR sKeyValue[RADIS_KEY_LEN];
        DOUBLE64   fTempLtp=0.00;
        DOUBLE64   fUpperCkt=0.00;
        DOUBLE64   fLowerCkt=0.00;
        LONG32          iTempScripCode =0 ,iMsgCode;
	LONG32	iBcastMonCountr = 0,iNoRecords = 0;
        CHAR    NormlMkt [MKT_TYPE_LEN];
        CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR    sUpdateQry[MAX_QUERY_SIZE];
        CHAR    supdate [MAX_QUERY_SIZE];
        CHAR    sBroadcastMon[COMMAND_LEN];
        CHAR    sRSRem[COMMAND_LEN];
	CHAR	cDprChngFlag=NO;
	CHAR 	sMemKey[COMMAND_LEN];
	redisReply *reply;
	redisReply *reply1;
	redisReply *reply2;
	redisReply *repRem;
/***	
        sprintf(sCommand,"SUBSCRIBE OMSBSECM");
        logDebug2("sCommand -> %s",sCommand);
        reply = redisCommand(c,sCommand);
        logDebug2("INCR counter: %lld", reply->integer);
        while(redisGetReply(c,(void**)&reply) == REDIS_OK)
***/
	while(TRUE)	
        {
		logTimestamp("Recive Publish Key");
                memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
                memset(&supdate,'\0',MAX_QUERY_SIZE);
                memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
                memset(&NormlMkt,'\0',MKT_TYPE_LEN);
		fUpperCkt=0.00;
		fLowerCkt=0.00;
		fTempLtp=0.00;
		iTempScripCode =0 ;
		iMsgCode = 0;
		iNoRecords = 0;
		/****
                if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3)
                {
                        logDebug2("Error:  Malformed subscribe response!");
			continue;
                        //exit(-1);
                }
		***/

		//sprintf(sCommand,"SUBSCRIBE OMSBSECM");
		sprintf(sCommand,"SMEMBERS BSE:E:BCAST");
	        //logDebug2("sCommand -> %s",sCommand);
	      

//                reply = redisCommand(RdConn,sCommand);


                reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_PRICE_BCAST);
                       
	        //logDebug2("Element counter: %d", reply->elements);
		iNoRecords = reply->elements;	

		/*****
                logDebug2("Channel: %s", reply->element[1]->str);
                logDebug2("Received message: %s", reply->element[2]->str);
                memset(&sKeyValue,'\0',RADIS_KEY_LEN);
                sprintf(sKeyValue,"%s",reply->element[2]->str);
                freeReplyObject(reply);

		memset(sCommand1,'\0',COMMAND_LEN);
                sprintf(sCommand1,"TTL %s",sKeyValue);
                logDebug2("sCommand1 -> %s",sCommand1);
                reply = redisCommand(RdConn,sCommand1);

                logDebug2("INCR counter: %lld", reply->integer);
		****/
		
		//if(reply->integer != 0 && reply->integer != -2)
		for(i = 0 ; i < iNoRecords; i++)
		{
			logTimestamp("INTIAL iBcastMonCountr :%d:",iBcastMonCountr);
                	memset(sMemKey,'\0',COMMAND_LEN);
                	memset(sCommand,'\0',COMMAND_LEN);
                	sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT HIGH_CKT  LOW_CKT DPR_CHN_FLAG ",reply->element[i]->str);
                	logDebug2("sCommand -> %s",sCommand);
			//strncpy(sMemKey,reply->element[i]->str,COMMAND_LEN);
                	//logDebug2("sMemKey =%s ",sMemKey);

                        reply1 = fRedisCommand(RdConn,sCommand,REDIS_TYPE_PRICE_BCAST);
                	iCount = reply1->elements;
                	logDebug2("ELEMENT COUNT =%d ",iCount);
                	logDebug2("Received message LTP : %s", reply1->element[0]->str);
                	logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
                	logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
                	logDebug2("Received message EXCH: %s", reply1->element[3]->str);
                	logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
                	logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
			if(reply1->element[0]->str != NULL)
                        {
                		fTempLtp = atof(reply1->element[0]->str);
                		iTempScripCode = atoi(reply1->element[1]->str);
                		iMsgCode = atoi(reply1->element[4]->str);
                		sprintf(NormlMkt,"%s",reply1->element[2]->str);
                		fUpperCkt = atof(reply1->element[6]->str);
                		fLowerCkt= atof(reply1->element[7]->str);
				cDprChngFlag = reply1->element[8]->str[0];
		
				sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
                                (L1_EXCHANGE ,\
                                L1_SEGMENT,\
                                L1_SCRIP_CODE,\
                                L1_EXCH_SCRIP_CODE,\
                                L1_MARKET_TYPE,\
                                L1_ENTRY_TIME,\
                                L1_LTP )\
                                VALUES(\"%s\",\'%c\',\"%d\",%d,\"%s\",NOW(),%lf)\
                                on duplicate key \
                                UPDATE \
                                L1_EXCHANGE = VALUES(L1_EXCHANGE) ,\
                                L1_SEGMENT = VALUES(L1_SEGMENT) ,\
                                L1_SCRIP_CODE = VALUES(L1_SCRIP_CODE) ,\
                                L1_EXCH_SCRIP_CODE = VALUES(L1_EXCH_SCRIP_CODE) ,\
                                L1_MARKET_TYPE = VALUES(L1_MARKET_TYPE) ,\
                                L1_ENTRY_TIME = NOW() ,\
                                L1_LTP  = VALUES(L1_LTP); ",BSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);

                                logDebug2(":%s:",sInsertQry);

                                if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
                                {
                                	sql_Error(ENMbp_con);
                                }
                                /**else
                                {
                                	mysql_commit(ENMbp_con);
					iBcastMonCountr ++;
	                        	logDebug3("iBcastMonCountr :%d:",iBcastMonCountr);
        	                	memset(sBroadcastMon,'\0',COMMAND_LEN);
                	        	sprintf(sBroadcastMon,"HMSET BCAST:MON BSE:E:COUNT %d ",iBcastMonCountr);
                        		logTimestamp("sCommand -> %s",sBroadcastMon);
       
                                        reply = fRedisCommand(RdConn,sBroadcastMon,REDIS_TYPE_PRICE_BCAST);
        	                	freeReplyObject(reply2);
                                }**/

                                sprintf(sUpdateQry,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f ,L1_LUT = NOW()  WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \"%d\" ;",fTempLtp,BSE_EXCH,EQUITY_SEGMENT,iTempScripCode);

                                logDebug2(":%s:",sUpdateQry);

                                if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
                                {
                                	sql_Error(ENMbp_con);
                                }
                                else
                                {
                                	mysql_commit(ENMbp_con);
                                }

				if(cDprChngFlag == YES)
				{
                			memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
				
					sprintf(sInsertQry,"CALL PR_CKT_LMT_UPDATE(\"%d\", \"%s\",\'%c\', %.2f, %.2f,@ZSTATUS); SELECT @ZSTATUS ;",iTempScripCode,BSE_EXCH,SEGMENT_EQUITY,fUpperCkt,fLowerCkt);
                                       	logDebug2("Query[%s]",sInsertQry);
                                       	if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
                                       	{
                               			logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
                                               	sql_Error (ENMbp_con);
                                       	}
                                       	else
                                       	{
                                       	        mysql_commit(ENMbp_con);
                                       	        logDebug2("------SUCCESS IN SM_FREEZE_PERCNT UPDATE-----");
							
                                       	}



                                       	do{
                                       	        Res = mysql_store_result(ENMbp_con);
                                       	        if(Res)
                                               	{
                                                       	if((Row = mysql_fetch_row(Res)))
                                                       	logInfo(" OUTPUT :%s:",Row[0]);
                                               	}
                                               	if((iStatus = mysql_next_result(ENMbp_con)) > 0)
                                               	{
                                               	        logDebug3("Could not execute statement");
                                               	}
						mysql_free_result(Res);
                                       	}while(iStatus == 0);
					sprintf(supdate,"HMSET %s DPR_CHN_FLAG %c ",sKeyValue,NO);
					logDebug2("supdate :%s:",supdate);
						
                                  
 				      	reply2 = fRedisCommand(RdConn,supdate,REDIS_TYPE_PRICE_BCAST);
                                        logDebug2("INCR counter: %lld", reply2->integer);	
					freeReplyObject(reply2);
				}

			}
			freeReplyObject(reply1);

			memset(&sRSRem,'\0',COMMAND_LEN);
                	//logDebug2("sMemKey =%s ",sMemKey);
                        sprintf(sRSRem,"SREM BSE:E:BCAST  %s",reply->element[i]->str);

                        logDebug2("sRSRem :%s:",sRSRem);
                        repRem = fRedisCommand(RdConn,sRSRem,REDIS_TYPE_PRICE_BCAST);
                        if(repRem->type == REDIS_REPLY_INTEGER)
                        {
                                logInfo("Added Success");
			}
                        else
                        {
                                logFatal("Error in adding values to CLIENT HASH. :%s:",repRem->str);
                        }
		}		
		freeReplyObject(reply);
                sleep(iSleepTime);
		logTimestamp("#####EXIT####");


        }
        logTimestamp("EXIT [UPDATE LTP IN DB]");
}
