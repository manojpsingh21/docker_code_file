#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

redisContext *c;
redisContext *c1;
redisReply *reply;
redisReply *reply1;
MYSQL   *ENMbp_con;

main(int argc,char **argv)
{
	setbuf(stdout,0);
	logTimestamp("ENTRY [Main]");
	c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	c1 = RDConnect(REDIS_TYPE_PRICE_BCAST);
	ENMbp_con=DB_Connect();
	ReceiveReplyPacketsBcast();
	return 0;
	logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
	logTimestamp("ENTRY [UPDATE LTP IN DB]");
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];
	BOOL flag;
	BOOL iStatus;
	int count=0;
	int iCount ;
	CHAR sKeyValue[RADIS_KEY_LEN];
	DOUBLE64   fTempLtp=0.00;
	DOUBLE64   fUpperCkt=0.00;
        DOUBLE64   fLowerCkt=0.00;

	LONG32          iTempScripCode =0 ,iMsgCode;
	CHAR    NormlMkt [MKT_TYPE_LEN];
	MYSQL_ROW       Row;
        MYSQL_RES       *Res;
	CHAR    sExch [10];
	CHAR    cSegment;
	CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sUpdateQry[MAX_QUERY_SIZE];
	CHAR    supdate [MAX_QUERY_SIZE];
	CHAR    cDprChngFlag=NO;
	redisReply *reply2;

	while(TRUE)
	{
		memset(sCommand,'\0',COMMAND_LEN);	
		sprintf(sCommand,"SUBSCRIBE OMSBSECM");
		logDebug2("sCommand -> %s",sCommand);
		reply = fRedisCommand(c,sCommand,REDIS_TYPE_PRICE_BCAST);
		logDebug2("INCR counter: %lld", reply->integer);
		while(redisGetReply(c,(void**)&reply) == REDIS_OK)
		{
			logTimestamp("Recive Publish Key");
			memset(sInsertQry,'\0',MAX_QUERY_SIZE);
			memset(supdate,'\0',MAX_QUERY_SIZE);
			memset(sUpdateQry,'\0',MAX_QUERY_SIZE);
			if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3)
			{
				logDebug2(stderr, "Error:  Malformed subscribe response!");
				exit(-1);
			}

			logDebug2("Channel: %s", reply->element[1]->str);
			logDebug2("Received message: %s", reply->element[2]->str);
			memset(sKeyValue,'\0',RADIS_KEY_LEN);
			sprintf(sKeyValue,"%s",reply->element[2]->str);
			freeReplyObject(reply);

			memset(sCommand1,'\0',COMMAND_LEN);
			sprintf(sCommand1,"TTL %s",sKeyValue);
			logDebug2("sCommand1 -> %s",sCommand1);
			reply = fRedisCommand(c1,sCommand1,REDIS_TYPE_PRICE_BCAST);
			logDebug2("INCR counter: %lld", reply->integer);

			if(reply->integer != 0 && reply->integer != -2)
			{
				memset(sCommand,'\0',COMMAND_LEN);
				sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT HIGH_CKT  LOW_CKT DPR_CHN_FLAG",sKeyValue);
				logDebug2("sCommand -> %s",sCommand);
				reply1 = fRedisCommand(c1,sCommand,REDIS_TYPE_PRICE_BCAST);
				iCount = reply1->elements;
				logDebug2("ELEMENT COUNT =%d ",iCount);
				logDebug2("Received message LTP : %s", reply1->element[0]->str);
				logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
				logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
				logDebug2("Received message EXCH: %s", reply1->element[3]->str);
				logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
				logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
				if(reply1->element[0]->str != NULL)
				{
					fTempLtp = atof(reply1->element[0]->str);
					iTempScripCode = atoi(reply1->element[1]->str);
					iMsgCode = atoi(reply1->element[4]->str);
					sprintf(NormlMkt,"%s",reply1->element[2]->str);
					fUpperCkt = atof(reply1->element[6]->str);
	                                fLowerCkt= atof(reply1->element[7]->str);
        	                        cDprChngFlag = reply1->element[8]->str[0];


					sprintf(sInsertQry,"INSERT INTO EQ_L1_WATCH \
							(L1_EXCHANGE ,\
							 L1_SEGMENT,\
							 L1_SCRIP_CODE,\
							 L1_EXCH_SCRIP_CODE,\
							 L1_MARKET_TYPE,\
							 L1_ENTRY_TIME,\
							 L1_LTP,\
							 L1_LUT )\
							VALUES(\"%s\",\'%c\',%d,%d,\"%s\",NOW(),%lf,NOW())\
							on duplicate key \
							UPDATE \
							L1_EXCHANGE = VALUES(L1_EXCHANGE) ,\
							L1_SEGMENT = VALUES(L1_SEGMENT) ,\
							L1_SCRIP_CODE = VALUES(L1_SCRIP_CODE) ,\
							L1_EXCH_SCRIP_CODE = VALUES(L1_EXCH_SCRIP_CODE) ,\
							L1_MARKET_TYPE = VALUES(L1_MARKET_TYPE) ,\
							L1_LUT = NOW() ,\
							L1_LTP  = VALUES(L1_LTP); ",BSE_EXCH,SEGMENT_EQUITY,iTempScripCode,iTempScripCode,NormlMkt,fTempLtp);

					logDebug2(":%s:",sInsertQry);

					if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
					{
						sql_Error(ENMbp_con);
					}
					else
					{
						mysql_commit(ENMbp_con);
					}

					sprintf(sUpdateQry,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f ,L1_LUT = NOW() WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",fTempLtp,BSE_EXCH,EQUITY_SEGMENT,iTempScripCode);

					logDebug2(":%s:",sUpdateQry);

					if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
					{
						sql_Error(ENMbp_con);
					}
					else
					{
						mysql_commit(ENMbp_con);
					}
					
					if(cDprChngFlag == YES)
                                        {
                                                memset(sInsertQry,'\0',MAX_QUERY_SIZE);

                                                sprintf(sInsertQry,"CALL PR_CKT_LMT_UPDATE(\"%d\", \"%s\",\'%c\', %.2f, %.2f,@ZSTATUS); SELECT @ZSTATUS ;",iTempScripCode,BSE_EXCH,SEGMENT_EQUITY,fUpperCkt,fLowerCkt);
                                                logDebug2("Query[%s]",sInsertQry);
                                                if(mysql_query(ENMbp_con,sInsertQry) != SUCCESS)
                                                {
                                                        logSqlFatal(" In Function [fTC_STOCK_DETAILS_CHANGE]-->ERROR In Updating SECURITY_MASTER[Circuit Limit]");
                                                        sql_Error (ENMbp_con);
                                                }
                                                else
                                                {
                                                        mysql_commit(ENMbp_con);
                                                        logDebug2("------SUCCESS IN SM_FREEZE_PERCNT UPDATE-----");

                                                }



                                                do{
                                                        Res = mysql_store_result(ENMbp_con);
                                                        if(Res)
                                                        {
                                                                if((Row = mysql_fetch_row(Res)))
                                                                logInfo(" OUTPUT :%s:",Row[0]);
                                                        }
                                                        if((iStatus = mysql_next_result(ENMbp_con)) > 0)
                                                        {
                                                                logDebug3("Could not execute statement");
                                                        }
                                                }while(iStatus == 0);
                                                sprintf(supdate,"HMSET %s DPR_CHN_FLAG %c ",sKeyValue,NO);
                                                logDebug2("supdate :%s:",supdate);

						reply2 = fRedisCommand(c1,supdate,REDIS_TYPE_PRICE_BCAST);
                                                //reply2 = redisCommand(c,supdate);
                                                logDebug2("CHANGE DPR FLAG TO N.");
                                                freeReplyObject(reply2);
                                        }
					

				}
				freeReplyObject(reply1);
			}		
			freeReplyObject(reply);
			logTimestamp("#####EXIT####");
		}
		logError("Redis connection dropped, trying to reconnnect again");
		sleep(5);
		c = RDConnect(REDIS_TYPE_PRICE_BCAST);
	}
	logTimestamp("EXIT [UPDATE LTP IN DB]");
}
