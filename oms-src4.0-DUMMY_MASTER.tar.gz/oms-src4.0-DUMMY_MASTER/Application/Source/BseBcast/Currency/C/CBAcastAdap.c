#include"IPCS.h"
#include"BseBcastDefn.h"
#include<errno.h>
#include<string.h>
#include<sys/time.h>



#define     	TWIDDLE(A)   Twiddle ((CHAR *) &A, sizeof(A))

BOOL 	OpenSocket(CHAR ServiceType,LONG32 *sockfd);  
BOOL 	MapBseBroad                    (CHAR *,CHAR *,LONG32 *,LONG32 *);
BOOL 	ReceiveReplyPackets(LONG32 iBcastRecv);
FILE 	*fpReadFile,*fpWriteFile;
CHAR 	ReadFlag,WriteFlag;
CHAR    ReadFileName[25],WriteFileName[20];
CHAR 	bcastaddress[CALLING_LENS];
CHAR 	bcastanalytic[CALLING_LENS];
CHAR 	bcastRupeeNext[CALLING_LENS];
LONG32 	portno;
LONG32 	sockfd1,sockfdBroad,sockfdMulti;
BOOL    SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *calladdress,LONG32 portno);

LONG32  MbpBcastPort;
LONG32	iRRNxtBEport;
LONG32	iITSBEport;
LONG32	iAnlyBCport;
LONG32	iRRNxtIDXport;
LONG32	iITSIDXport;
LONG32	iAnlyIDXport;

main(int argc, char ** argv)
{
	struct sockaddr_in cli_addr;

	CHAR  	service;
	CHAR 	temp[MAX_SIZE];
	LONG32  val;
	LONG32	iBcastRecv;
	LONG32 	RecvPort;
	CHAR 	mbpport[10];
	CHAR	sTempPort[10];
	
	setbuf(stdout  ,NULL);
        setbuf(stderr  ,NULL);
	
	logDebug2 ( " NO OF ARG :%d " , argc ) ;
	if ( argc != 9 )
	{
		logDebug2("Argument Mismstch ");
		logDebug2("USAGE : <CurBseBcast> <Send portno>  <Recv Port> <L LIVE/D DUMP> <ReadFile> <Y/N WriteDump> <WriteFile> <Service {M Multicast/B Broadcast}> <CurBseBcast> ");
		exit(0);
	}
//	strncpy(bcastaddress,getenv("BCAST_TO_VB"),CALLING_LENS);
	if(getenv("ANALYTIC_SERVER_IP")==NULL)
	{
		logFatal("Error : Environment variables missing : BACKOFF_NEQ_PORT");
                exit(ERROR);
	}
	else
	{
		strcpy ( bcastanalytic , getenv("ANALYTIC_SERVER_IP"));
		logDebug2(" bcastanalytic :%s:",bcastanalytic);
	}


	portno  = atoi(argv[1]);
	RecvPort = atoi(argv[2]);
	ReadFlag = argv[3][0];
	strcpy (ReadFileName , argv[4]);
	WriteFlag = argv[5][0];
	strcpy (WriteFileName , argv[6]);
	service	= argv[7][0];




	memset(sTempPort,'\0',10);
	strcpy(sTempPort,getenv("ANALY_BSE_CD_PORT"));
	iAnlyBCport = atoi(sTempPort);
	logDebug2("sTempPort [%s] iAnlyBCport [%d]",sTempPort ,iAnlyBCport);


	setbuf(stdout,0);

	logDebug2(" _________P A R A M E T E R E S____________ ");

	logDebug2("Bcastaddress is  : %s ",bcastaddress);
	logDebug2("Send Portno  is  : %d ",portno );
	logDebug2("Recv Portno  is  : %d ",RecvPort );
	logDebug2("ReadFile     is  : %s ",ReadFileName);
	logDebug2("WriteFile    is  : %s ",WriteFileName);
	logDebug2("ReadFlag     is  : %c ",ReadFlag);
	logDebug2("WriteFlag    is  : %c ",WriteFlag);
	logDebug2("Service type is  : %c ",service);

	logDebug2("__________________________________________ ");

	if ( ReadFlag =='D')
	{
		fpReadFile = fopen(ReadFileName,"rb+");
		if( fpReadFile == NULL)
		{
			logDebug2("Unable to Open the  Read File ");
			exit(1);
		}
	}

	if ( WriteFlag =='Y')
	{
		fpWriteFile = fopen(WriteFileName,"wb+");
		if( fpWriteFile == NULL)
		{
			logDebug2("Unable to Open the  Write File ");
			exit(1);
		}
	}


	cli_addr.sin_family 	= AF_INET;
	cli_addr.sin_addr.s_addr= INADDR_ANY;
	cli_addr.sin_port 	= htons(RecvPort);


	for( ; ; )
	{
		if ( ReadFlag =='L')
		{

			if(OpenSocket('B',&iBcastRecv))
			{
				if (val = (bind(iBcastRecv,(struct sockaddr *)&cli_addr,sizeof(struct sockaddr))) <0)
				{
					logDebug2("Client : Error in Binding...is:%d",errno);
					memcpy(temp,strerror(errno),100);
					exit(1);
				}
			}
		}


		logDebug2("Connection to BSE Broadcast Circuit successful\n");

		ReceiveReplyPackets(iBcastRecv);
	}

}

/***********************************************************************************************
  Function Name      :    ReceiveReplyPackets
Arguments          :    bcastaddress,portno,service,sfdBcastRecv 
Return Values      :    BOOL
Dependencies       :
Functions Called By:    Main In the same File.  
Comments           :    This Function Maps the data to the Internal Format And Sends to the 
Front End , And also Writes to the Queue for DataBase Updation.
 ************************************************************************************************/

BOOL ReceiveReplyPackets(LONG32 iBcastRecv)
{
	int 	fileCounter = 0;
	CHAR 	tempdata[MAX_PACKET_SIZE_COMPRESS];
	CHAR 	temp[MAX_PACKET_SIZE_COMPRESS];
	CHAR 	temp1[MAX_PACKET_SIZE_COMPRESS];
	CHAR temp2[4];
	CHAR temp3[MAX_PACKET_SIZE_COMPRESS]; 
	LONG32	sfdMultiBroad,qidnormal;
	LONG32	ReadByte,write_status,clilen;
	LONG32	iTranscode,flag,i,MsgLength=0,MsgLength1=0,iTemp = 0;
	LONG32	MinPackSize = 10,Count=0;
	LONG32	PacketCounter,szCompressed,szUncompressed,szPercentCompression;
	struct 	OMB_HEADER  ombHeader;
	struct  sockaddr_in serv_addr;
	struct INT_BSE_OPEN_CLOSE_PRICE_BCAST *openclose;
	USHORT	ErrorCode;
	USHORT  Len,complen;
	USHORT  LenSpeed ; /* Speed IML 46 */
	struct  BCAST_HEADER *bcastheader;
	struct     sockaddr_in cli_addr ;
	SHORT   TempLen;
	LONG32 ShmAddrsfd;	
	struct sockaddr_in Serv_Addr_Shm; 
	LONG32  status = TRUE   ;
	CHAR    tempflag= FALSE ;
	LONG32  counter = 0     ;
	LONG32 iBcasttoIndex;


	memset(temp2,0,4); /* IML 46 */


	if(!OpenBcastSocket())
	{
		perror("Error creating Shm  socket");
		exit(0);
	}


	qidnormal = OpenMsgQ(CBAAdapToSpltr);
	if ( qidnormal < 0 )
	{
		perror("\n Error in  Opening  Queue ");
		exit(0);
	}
	else
	{
		logDebug2("Normal Queue opened and ready.....");
		logDebug2("The QId is %d",qidnormal);
	}
	/*******	
	  if( ( iBcasttoIndex = OpenMsgQ( (EBBcasttoIndex))) == ERROR )
	  {
	  perror("Open iBcasttoIndex :");
	  exit( 1 );
	  }
	 *********/	

#ifdef  DBG
	logDebug2("The Queue Id is :%d",qidnormal);
	logDebug2("OPENING THE FILE " );
#endif

	while (TRUE)
	{
		memset (&ombHeader,' ',sizeof(struct OMB_HEADER));
		memset (&temp,' ',sizeof(CHAR)*MAX_PACKET_SIZE_COMPRESS);
		memset (&temp1,' ',sizeof(CHAR)*MAX_PACKET_SIZE_COMPRESS);




		/**************** To Get Data From Socket *******************/
		clilen = sizeof(struct sockaddr);

		if ( ReadFlag =='L')
		{
			logDebug2("***************** Loop %d *****************",++Count);
			if ((ReadByte = recvfrom(iBcastRecv,&temp,BSE_MAX_BCAST_MSG_LEN,0,(struct sockaddr *)&serv_addr,&clilen)) < 0 )
			{
				logDebug2("Unable to receive the data from iBcastRecv, id:%d",iBcastRecv);
				break;
			}
		}
		else
		{
			if (fread(&temp,BSE_MAX_BCAST_MSG_LEN,1,fpReadFile)<=0)
			{
				logDebug2("openning");
				fclose(fpReadFile);
				usleep(500);

				fpReadFile = fopen(ReadFileName,"rb+");
				fileCounter = 0;
				if( fpReadFile == NULL)
				{
					logDebug2("Unable to Open the File ");
					exit(1);
				}
				continue ;

			}
			else
			{
				fileCounter++ ;
			}
			/*******
			  if ( fileCounter <= 15000 )
			  continue;
			 *************/
			ReadByte =  BSE_MAX_BCAST_MSG_LEN;
		}
			SendBroadcast(temp,BSE_MAX_BCAST_MSG_LEN,bcastanalytic,iAnlyBCport);

		logDebug3("After Debug2 from read file");

		if ( WriteFlag =='Y')
		{
			logDebug2("In writefile");
			fwrite ( &temp,BSE_MAX_BCAST_MSG_LEN,1,fpWriteFile );
		}



		if (ReadByte < MinPackSize)
		{
			logDebug2("Junk Packet Received - SMALLER THAN MINIMUM SIZE!");
			break;
		}
		if (ReadByte >= MinPackSize)
		{

			iTranscode = ((struct DUMMY_OMB_HEADER *)&temp)->iMsgType;
			Len = ((struct DUMMY_OMB_HEADER *)&temp)->iMsgLen;
			logDebug2 ( "before twiddle iTranscode :%d " , iTranscode ) ;

			/******** WARNING TO BE REMOVED *****/
			if(!IsValidTranscode(iTranscode))
			{
				logDebug2("Transcode received from the Exch is incorrec %d",iTranscode);
				continue;
			}
			logDebug2("Transcode :%d Bytes :%d",iTranscode,ReadByte);
		}
		logDebug2("Before GetPktSiz ");
		if( ( MsgLength = GetPktSiz ( iTranscode )) == FALSE )
		{
			logDebug2("GetPktSiz Failed in finding the length of data to be sent on Q") ;
			continue;
		}

		if(iTranscode == TC_EQU_BSE_SESSION_CHANGED_BROADCAST)
		{
			ShowStatus(&temp);
		}



		memcpy(&ombHeader,&temp,sizeof(struct OMB_HEADER));
		logDebug2("Before MapBseBroad ...");
		logDebug2("Mesage Length is %d",MsgLength);


		status = GetQStatus (qidnormal );   /***CHNAGES FOR FCAST*****/
		if ( status == FALSE)
		{
			tempflag = TRUE;
			counter++;
			logDebug2(" QUEUE IS FULL");
			system("date");
		}
		else
		{

			/*********		if(iTranscode==TC_EQU_BSE_INDEX_SENSEX_BROADCAST || iTranscode==TC_EQU_BSE_INDEX_NEW_SENSEX_BROADCAST)
			  {
			  if(( WriteQ( iBcasttoIndex ,&temp,MsgLength ,1 ) != TRUE ))
			  {
			  perror("Error WriteQ: ");
			  logDebug2("Write Q id %d", iBcasttoIndex);
			  exit(ERROR);
			  }


			  }
			  else
			  {*********************/
			write_status = WriteMsgQ(qidnormal,&temp,MsgLength,1);
			logDebug2("Mesage Length is %d",MsgLength);
			if ( write_status == ERROR)
			{
				logDebug2("Error in writing to  BSE_BCAST_Q...");
				continue;
			}
			logDebug2("Written to Queue Properly");

			/**	}***/
		}


		if ( tempflag == TRUE )
		{
			system("date");
			logDebug2("Counter is %d",counter);
		} 

		MsgLength = 0;
		MsgLength1 = 0 ;
		TempLen = 4 ;
		/*****
		  if ((flag=MapBseBroad(&temp,&temp1,&MsgLength,&MsgLength1))!= FALSE)
		  {


		  }
		  else
		  {
		  logDebug2("\n  Mapping Failed \n");
		  }
		  (********/	
	}/* End of while */
	close(sfdMultiBroad);
	close(iBcastRecv);
	return;
}

/***********************************************************************************************
  Function Name      :    OpenSocket
Arguments          :    ServiceType,sockfd
Return Values      :    BOOL
Dependencies       :
Functions Called By:    Main And RecieveReplyPackets In the same File.  
Comments           :    This Function Opens a Socket and sets the option for the Socket.
 ************************************************************************************************/

BOOL OpenSocket(CHAR ServiceType,LONG32 *sockfd)
{
	LONG32 sfd;
	LONG32 optval=1;
	LONG32 val=1;
	CHAR ttl=254;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket");
		exit(0);
	}

	switch (ServiceType)
	{
		case	'B':
		case	'b':
			if((val =setsockopt(sfd,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval)))< 0)
				perror("OpenSocket: Error in setsockopt for Bcast Socket ");
			logDebug2(" In serivet type B");
			break;

		case	'M':
		case	'm':
			if (( val = setsockopt(sfd,IPPROTO_IP,IP_MULTICAST_TTL,&ttl,sizeof(ttl) ) ) < 0 )
				perror("OpenSocket: Error in setsockopt for Multicast socket");
			logDebug2("In serivet type M");
			break;

		default :
			if (ServiceType != 'N')
				logDebug2("OpenSocket: Received ServiceType id invalid :%c",ServiceType);
	}

	*sockfd = sfd;

	if (val < 0)		
		return FALSE;
	else
		return TRUE;
}

/***********************************************************************************************
  Function Name      :    IsValidTranscode
Arguments          :    Transcode
Return Values      :    BOOL
Dependencies       :
Functions Called By:    RecieveReplyPackets In the same File.  
Comments           :    This Function checks for the Validity of the Transcode 
Recieved from the Exchange.
 ************************************************************************************************/

BOOL IsValidTranscode(LONG32 Transcode)
{
	switch(Transcode)
	{
		case TC_EQU_BSE_TOUCH_LINE_BROADCAST		:
		case TC_EQU_BSE_NEWS_BROADCAST			:
		case TC_EQU_BSE_OPENING_PRICE_BROADCAST		:
		case TC_EQU_BSE_CLOSING_PRICE_BROADCAST		:
		case TC_EQU_BSE_SESSION_CHANGED_BROADCAST	:
		case TC_EQU_BSE_MARKET_PIC_BROADCAST		:
		case TC_EQU_BSE_POST_CLOSE_INDEX_BROADCAST	:
		case TC_EQU_BSE_INDEX_SENSEX_BROADCAST		:
		case TC_EQU_BSE_INDEX_NEW_SENSEX_BROADCAST 	:  /*** bse 2011 ***/
		case TC_EQU_BSE_DETAIL_INDEX_BROADCAST  	:
			return  TRUE;

		default:
			return FALSE;
	}
}

/***********************************************************************************************
  Function Name      :    GetPktSiz
Arguments          :    MsgType
Return Values      :    LONG32
Dependencies       :
Functions Called By:    RecieveReplyPackets In the same File.  
Comments           :    This Function finds the size of the Packet and Returns Back the same
 ************************************************************************************************/

LONG32 GetPktSiz ( LONG32  MsgType )
{

	LONG32  RetVal  ;

#ifdef DBG
	logDebug2("GetPktSiz: TC recieved is : %d",MsgType);
#endif
	switch ( MsgType )
	{
		/***/	case    TC_EQU_BSE_TOUCH_LINE_BROADCAST      :
			RetVal  =   sizeof (struct  OMB_TOUCHLINE_INFORMATION );
			break       ;/*****/

		case    TC_EQU_BSE_NEWS_BROADCAST     :
			RetVal  =   sizeof (struct  OMB_NEWS_HEADLINE_BROADCAST );
			break       ;

		case    TC_EQU_BSE_OPENING_PRICE_BROADCAST     :
			RetVal  =   sizeof (struct OMB_OPEN_CLOSE_PRICE_BROADCAST );
			break       ;

		case    TC_EQU_BSE_CLOSING_PRICE_BROADCAST   :
			RetVal  =   sizeof (struct OMB_OPEN_CLOSE_PRICE_BROADCAST );
			break       ;

		case     TC_EQU_BSE_SESSION_CHANGED_BROADCAST  :
			RetVal  =   sizeof (struct OMB_SESSION_CHANGE_BROADCAST );
			break       ;

		case     TC_EQU_BSE_MARKET_PIC_BROADCAST      :
			RetVal  =   sizeof (struct  OMB_MKT_PIC_DETAIL_BROADCAST );
			break       ;

		case     TC_EQU_BSE_POST_CLOSE_INDEX_BROADCAST    :
			RetVal  =   sizeof (struct  OMB_POST_CLOSING_INDEX_BROADCAST );
			break       ;
			/**
			  case     TC_EQU_BSE_INDEX_SENSEX_BROADCAST    :
			  RetVal  =   sizeof (struct  OMB_INDEX_SENSEX_BCAST );
			  break       ;
			 **/
		case     TC_EQU_BSE_INDEX_NEW_SENSEX_BROADCAST :   /*** bse 2011 ***/
			RetVal  =   sizeof (struct  OMB_NEW_SENSEX_BCAST );
			break       ;
		case    TC_EQU_BSE_DETAIL_INDEX_BROADCAST   :
			RetVal  = sizeof(OMB_NEW_INDICES_DETAIL_BROADCAST);
			break;


		default :
			return FALSE;
			break       ;

	}
	logDebug2("RetVal :%d: MsgType :%d:",RetVal,MsgType);
	return RetVal;
}


int GetQStatus( int MsgQuery)
{
	struct msqid_ds sStatQ;
	DOUBLE64        checkbytes = 0.0;

	if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
	{
		checkbytes      =       (sStatQ.msg_qbytes * 0.066);

		logDebug2("From MsgQueryQ TotalBytes            = %d, CurrentBytes=%d ", sStatQ.msg_qbytes,sStatQ.msg_cbytes);
		logDebug2("From MsgQueryQ Availablebytes        = %d", (sStatQ.msg_qbytes - sStatQ.msg_cbytes));
		logDebug2("From MsgQueryQ CheckPointBytes       = %lf", checkbytes );


		if ( (sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
		{
			logDebug2("Queue is 90 Percentage Full:%d", MsgQuery );
			return FALSE ;
		}
		else
		{
			logDebug2("Queue Check : Passed");
			return TRUE ;
		}
	}
}

BOOL  SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 portno)
{
	struct     sockaddr_in cli_addr ;
	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(bcastaddress);
	cli_addr.sin_port           = htons(portno);

	if(sendto(sockfdBroad,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr))< 0)
	{
		perror("Server : Error in Sending");
		return FALSE;
	}

	logDebug2(" SENDING BROADCAST IP [%s] PORT [%d]",bcastaddress,portno);
	return TRUE;
}

BOOL  OpenBcastSocket()
{
	LONG32 optval=1;
	LONG32  val;
	if ( (sockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}
	val = setsockopt(sockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval));
	if ( val < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	return TRUE;
}

BOOL  ShowStatus            (CHAR * OmbData)
{
	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	gettimeofday(&StartPoint1, &tzp);
	StartPoint1.tv_sec = StartPoint1.tv_sec +19800;

	struct  OMB_SESSION_CHANGE_BROADCAST *pSessionChangeDetail;
	pSessionChangeDetail = ( struct  OMB_SESSION_CHANGE_BROADCAST *) OmbData ;

	logDebug2("Checking Bcast for mktWatch MarketType:%d: CurSession :%d: TIME :%d:",pSessionChangeDetail->MsgType,pSessionChangeDetail->iCurSession,StartPoint1.tv_sec);


}

