

#include "IPCS.h"
#include "BseBcastDefn.h"
#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"
#include "RedisStruct.h"

SHORT fTrim( CHAR * Str_In ,SHORT MaxLen);
BOOL  fBcastUpdt();
BOOL dTC_MBP_BCAST	(char *NNFData,INT16 iTranscodeLocal);

SHORT fConvertBookToMkt(SHORT iBookType);
LONG32  rcvQ;
// inserted by @pratik
redisContext *c;
redisReply *reply;

INT16   iExpSec;

main(int argv, char *argc[])
{

    LONG32 iFlag;
    LONG32 i;

    setbuf(stdout, 0);

    pthread_t thread_id[5];



    c = RDConnect(REDIS_TYPE_PRICE_BCAST);
    // inserted by @pratik for fatching sec value from env
    if (getenv("RADIS_KEY_EXP_SEC") == NULL)
    {
        iExpSec = 10;
        logFatal("Error : Environment variables missing : RADIS_KEY_EXP_SEC ");
    }
    else { iExpSec = atoi(getenv("RADIS_KEY_EXP_SEC")); }

    LONG32 iSegment;


    if ((rcvQ = OpenMsgQ(DBASpltrToMbpUpld)) == ERROR)
    {
        perror("\n Error in Opening BcasttoMbpMbo....");
        exit(ERROR);
    }

    logDebug2("Message Queue opened BcasttoMbpMbo : %d:", DBASpltrToMbpUpld);


    // for(i=0;i<MAX_NO_OF_THREADS;i++)
    for (i = 0; i < 1; i++)
    {


        if ((pthread_create(&thread_id[i], NULL, fBcastUpdt, NULL)) != 0)
            logDebug2("Cant create thread %d", i);
        else logDebug2("Created");
    }

    logDebug2("ALOK HERE 1 ");

    // for(i=0;i<MAX_NO_OF_THREADS;i++)
    for (i = 0; i < 1; i++)
    {
        /*Wait for thread to end */
        logDebug2("Thread %d....", i);

        if (pthread_join(thread_id[i], NULL))
            logDebug2("Error when waiting for thread %d to terminate", i);
        else logDebug2("Stopped");

        logDebug2("Detach thread....");

        if (pthread_detach(&thread_id[i])) logDebug2("Error Detaching Thread!");
        else logDebug2("Detached!");

        logDebug2("Stop Session %d....", i);

        logDebug2("Logged Off");
    }
    logDebug2("ALOK HERE 2 ");
}

BOOL fBcastUpdt()
{
    INT16 i;
    CHAR sRcvMsg[LOCAL_MAX_PACKET_SIZE];
    INT16 iTranscodeLocal;


    struct DUMMY_OMB_HEADER *pForRecTransCode;
    LONG32 iCount;



    while (TRUE)
    {
        memset(&sRcvMsg, ' ', LOCAL_MAX_PACKET_SIZE);



        if ((ReadMsgQ(rcvQ, &sRcvMsg, LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
        {
            perror("Error Read Q ");
            exit(ERROR);
        }


        pForRecTransCode = (struct DUMMY_OMB_HEADER *)sRcvMsg;
        iTranscodeLocal  = pForRecTransCode->iMsgType;

        if (iTranscodeLocal == TC_EQU_BSE_MARKET_PIC_BROADCAST)
        {
            logDebug2("Printf in If");
            dTC_MBP_BCAST(sRcvMsg, iTranscodeLocal);
        }
        else { logDebug2("This is in else "); }
    }
}



BOOL dTC_MBP_BCAST(CHAR *NNFData, INT16 iTranscodeLocal)
{
    logTimestamp("ENTRY [dTC_MBP_BCAST]");
    struct OMB_MKT_PIC_DETAIL_BROADCAST *pMBP_Info
        = (struct OMB_MKT_PIC_DETAIL_BROADCAST *)NNFData;


    BOOL iLoopVar;
    BOOL i, iNoOfRecs, iRank;
    LONG32 k;


    DOUBLE64 iLtPrice, fLtpRedis;
    DOUBLE64 fUpprCkt = 0.00;
    DOUBLE64 fLowrCkt = 0.00;


    LONG32 iToken     = 0;
    SHORT iMkt        = 0;
    SHORT iNoOfBIDOrd = 0;
    SHORT iNoOfASKOrd;

    CHAR sMktType[5];
    CHAR cDprChangeFlag = YES;

    // insert by @pratik
    CHAR sCommand[COMMAND_LEN], sCommand1[COMMAND_LEN];
    CHAR sKeyValue[RADIS_KEY_LEN];
    memset(sKeyValue, '\0', RADIS_KEY_LEN);
    LONG32 iCount;


    iNoOfRecs = pMBP_Info->iNoOfRecords;

    k = 0;

    for (i = 0; i < iNoOfRecs; i++)
    {
        memset(sMktType, '\0', 5);
        fUpprCkt = 0.00;
        fLowrCkt = 0.00;
        iToken   = 0;
        iToken   = pMBP_Info->mktpicture[i].iScripCode;
        logDebug2(
            "pMBP_Info->mktpicture[i].ScripCode:%d: iToken :%d:",
            pMBP_Info->mktpicture[i].iScripCode, iToken);


        /***
          convert_seconds_to_date(pMBP_Info->mktpicture[i].iLastTradeTime,sLastTradeTime);
          convert_seconds_to_date(pMBP_Info->pHeader.iLogTimeStamp,sLogTime);	******/
        logDebug2(
            "pMBP_Info->mktpicture[i].iMktType :%i:", pMBP_Info->mktpicture[i].iMktType);


        iMkt = fConvertBookToMkt(pMBP_Info->mktpicture[i].iMktType);

        logDebug2("iToken :%i:", iToken);
        logDebug2("iMkt :%i:", iMkt);

        if (iMkt == 0) { return FALSE; }
        /**
                if(iMkt == NORMAL_MARKET)
                {
                    strncpy(sMktType,MKT_TYPE_NL,2);
                }
                else if(iMkt == ODDLOT_MARKET)
                {
                    strncpy(sMktType,MKT_TYPE_OL,2);
                }
                else if(iMkt == SPOT_MARKET)
                {
                    strncpy(sMktType,MKT_TYPE_SP,2);
                }
                else if(iMkt == AUCTION_MARKET)
                {
                    strncpy(sMktType,MKT_TYPE_AU,2);
                }
        **/
        switch (iMkt)
        {
        case NORMAL_MARKET: strncpy(sMktType, MKT_TYPE_NL, 2); break;
        case ODDLOT_MARKET: strncpy(sMktType, MKT_TYPE_OL, 2); break;
        case SPOT_MARKET: strncpy(sMktType, MKT_TYPE_SP, 2); break;
        case AUCTION_MARKET: strncpy(sMktType, MKT_TYPE_AU, 2); break;
        default: logDebug2("MktType received in Junk"); break;
        }
        logDebug2("sMktType :%s:", sMktType);
        // for(iLoopVar = 0,iRank = 1;iLoopVar < MBP_NO_OF_RECS/2;iLoopVar++,iRank++)
        for (iLoopVar = 0, iRank = 1; iLoopVar < 5; iLoopVar++, iRank++)
        {
            logDebug2("iLoopVar :%d:", iLoopVar);
            //	iNoOfOrders = pMBP_Info->mktpicture[i].MktBest[iLoopVar].iNoOfOrders;

            k++;
            logDebug2("iRank :%d:", iRank);

            if (iRank == 1)
            {
                logDebug2("I m In RANK 1 ");
                /**
                                iBuyPrice =
                (DOUBLE64)pMBP_Info->mktpicture[i].MktBest[iLoopVar].iBestBuyRate/
                CONST_PRICE_FACTOR	; iSellPrice =
                (DOUBLE64)pMBP_Info->mktpicture[i].MktBest[iLoopVar].iBestSellRate/
                CONST_PRICE_FACTOR; iAtPrice =
                (DOUBLE64)pMBP_Info->mktpicture[i].iWeightedAverage/ CONST_PRICE_FACTOR;
                                iClPrice = (DOUBLE64)pMBP_Info->mktpicture[i].iCloseRate/
                CONST_PRICE_FACTOR; iOpPrice =
                (DOUBLE64)pMBP_Info->mktpicture[i].iOpenRate/ CONST_PRICE_FACTOR; iHiPrice
                = (DOUBLE64)pMBP_Info->mktpicture[i].iHighRate/ CONST_PRICE_FACTOR;
                                iLoPrice = (DOUBLE64)pMBP_Info->mktpicture[i].iLowRate/
                CONST_PRICE_FACTOR;
                ***/

                logDebug2(
                    "pMBP_Info->mktpicture[i].iLastTradeRate :%d: ",
                    pMBP_Info->mktpicture[i].iLastTradeRate);
                iLtPrice = (DOUBLE64)pMBP_Info->mktpicture[i].iLastTradeRate
                         / CONST_PRICE_FACTOR;
                fUpprCkt = (DOUBLE64)pMBP_Info->mktpicture[i].iUpperCktLimit
                         / CONST_PRICE_FACTOR;
                fLowrCkt = (DOUBLE64)pMBP_Info->mktpicture[i].iLowerCktLimit
                         / CONST_PRICE_FACTOR;
                logInfo(
                    "Price Band Token :%d: fUpprCkt :%f: fLowrCkt :%f: ", iToken,
                    fUpprCkt, fLowrCkt);
                /**
                                iNetPriceChange =
                (DOUBLE64)(((iLtPrice-iClPrice))/iClPrice*CONST_PRICE_FACTOR);

                                if(iLtPrice > iClPrice)
                                    cNetChangeIndictr = '+';
                                else if(iClPrice > iLtPrice)
                                    cNetChangeIndictr = '-';
                                else
                                    cNetChangeIndictr = ' ';

                                iVolTradedToday = pMBP_Info->mktpicture[i].iVolume;
                                iLastTradeQty =  pMBP_Info->mktpicture[i].iLastTradeQty;
                                iTotalBuyQty = pMBP_Info->mktpicture[i].iTotBuyQty;
                                iTotalSellQty = pMBP_Info->mktpicture[i].iTotSellQty;
                ***/
                logDebug2("I m In RANK 1 ");
                /***
                                sprintf(sDelInsQ,"DELETE FROM EQ_L1_WATCH WHERE
                L1_SCRIP_CODE= \"%i\" AND L1_MARKET_TYPE= \"%s\" AND L1_EXCHANGE=
                \"%s\"",iToken,sMktType,sExchId);


                                if(mysql_query(ENMbp_con,sDelInsQ) != SUCCESS )
                                {
                                    sql_Error(ENMbp_con);
                                }
                ***/
                /**
                                sprintf(sInsrtQ,"INSERT INTO
                EQ_L1_WATCH(L1_BID_QTY,L1_BID_PRICE,L1_ASK_QTY,L1_ASK_PRICE,
                L1_LTP,L1_TRADING_STATUS,\
                                    L1_DAY_VOLUME,L1_LTQ,L1_TRADE_TIME,L1_ATP,\
                                    L1_CLOSE,L1_OPEN,L1_HIGH,L1_LOW,L1_TOTAL_BID_QTY,\
                                    L1_TOTAL_ASK_QTY,L1_ENTRY_TIME,L1_MARKET_TYPE,L1_SCRIP_CODE,L1_EXCHANGE,\
                                    L1_NET_CHANGE,L1_EXCH_SCRIP_CODE)\
                                        VALUES \
                                        (%i,%lf,%i,%lf,%lf,\'%c\',%i,%i,STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d
                %%H:%%i:%%S\'),%lf,%lf,%lf,%lf,%lf,%i,%i,NOW(),\"%s\",\
                                         \"%i\",\"%s\",%lf,%i)"\
                                        ,iBuyQty,iBuyPrice,iSellQty,iSellPrice,iLtPrice,cNetChangeIndictr,iVolTradedToday,iLastTradeQty,\
                                        sLastTradeTime,iAtPrice,iClPrice,iOpPrice,iHiPrice,iLoPrice,iTotalBuyQty,iTotalSellQty,\
                                        sMktType,iToken,sExchId,iNetPriceChange,iToken);
                ***/
                memset(sKeyValue, '\0', RADIS_KEY_LEN);
                sprintf(sKeyValue, "%s:%c:%d", BSE_EXCH, DERIVATIVE_SEGMENT, iToken);
                logDebug3("sKeyValue :%s:", sKeyValue);
                if (iLtPrice != 0) /***Change for LTP updating zero in DB ****/
                {
                    /*	sprintf(sInsrtQ,"INSERT INTO EQ_L1_WATCH \
                                            (L1_EXCHANGE ,\
                                            L1_SEGMENT,\
                                                L1_SCRIP_CODE,\
                                                L1_EXCH_SCRIP_CODE,\
                                                L1_MARKET_TYPE,\
                                            L1_ENTRY_TIME,\
                                            L1_LTP )\
                                            VALUES(\"%s\",\'%c\',%d,%d,\"%s\",NOW(),%lf)\
                                            on duplicate key \
                                            UPDATE \
                                            L1_EXCHANGE = VALUES(L1_EXCHANGE) ,\
                                            L1_SEGMENT = VALUES(L1_SEGMENT) ,\
                                            L1_SCRIP_CODE = VALUES(L1_SCRIP_CODE) ,\
                                            L1_EXCH_SCRIP_CODE =
                       VALUES(L1_EXCH_SCRIP_CODE) ,\
                                            L1_MARKET_TYPE = VALUES(L1_MARKET_TYPE) ,\
                                            L1_ENTRY_TIME = NOW() ,\
                                            L1_LTP  = VALUES(L1_LTP);
                       ",BSE_EXCH,SEGMENT_EQUITY,iToken,iToken,sMktType,iLtPrice);

                        logDebug2(":%s:",sInsrtQ);

                        if(mysql_query(ENMbp_con,sInsrtQ) != SUCCESS)
                        {
                            sql_Error(ENMbp_con);
                        }
                        else
                        {
                            mysql_commit(ENMbp_con);
                        }

                        sprintf(sUpdateQry,"UPDATE L1_WATCH_ACTIVE SET  L1_LTP = %f WHERE
                       L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d
                       ;",iLtPrice,BSE_EXCH,EQUITY_SEGMENT,iToken);

                        logDebug2(":%s:",sInsrtQ);

                                        if(mysql_query(ENMbp_con,sUpdateQry) != SUCCESS)
                                        {
                                              sql_Error(ENMbp_con);
                                        }
                                        else
                                        {
                                                mysql_commit(ENMbp_con);
                                        }*/

                    cDprChangeFlag = NO;
                    memset(sKeyValue, '\0', RADIS_KEY_LEN);
                    sprintf(sKeyValue, "%s:%c:%d", BSE_EXCH, DERIVATIVE_SEGMENT, iToken);
                    memset(sCommand, '\0', COMMAND_LEN);

                    sprintf(
                        sCommand, "HMGET %s LTP HIGH_CKT LOW_CKT DPR_CHN_FLAG ",
                        sKeyValue);

                    logDebug2("KEY VALUE %s", sKeyValue);

                    reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);

                    // reply = redisCommand(c, sCommand);
                    logDebug2("reply->len %d", reply->len);

                    if (reply->element[0]->str != NULL)
                    {
                    	logDebug2("Received message LTP : %s", reply->element[0]->str);
                        iCount = reply->elements;
                        logDebug2("ELEMENT COUNT =%d ", iCount);
                        logDebug2("Received message LTP : %s", reply->element[0]->str);
                        fLtpRedis = atof(reply->element[0]->str);
                        freeReplyObject(reply);

                        if (fUpprCkt != atof(reply->element[1]->str)
                            || fLowrCkt != atof(reply->element[2]->str))
                        {
                            cDprChangeFlag = YES;
                        }
                        else { cDprChangeFlag = reply->element[3]->str[0]; }

                        if (fLtpRedis == iLtPrice)
                        {
                            logDebug2("No Need To Update LTP in DB");
                        }
                        else
                        {

                            memset(sCommand, '\0', COMMAND_LEN);
                            sprintf(
                                sCommand,
                                "HMSET %s LTP %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d "
                                "SEGMENT %c HIGH_CKT %f LOW_CKT %f DPR_CHN_FLAG %c ",
                                sKeyValue, iLtPrice, iToken, sMktType, BSE_EXCH,
                                iTranscodeLocal, DERIVATIVE_SEGMENT, fUpprCkt, fLowrCkt,
                                cDprChangeFlag);
                            logDebug2("sCommand -> %s", sCommand);
                            reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                            // reply = redisCommand(c, sCommand);
                            freeReplyObject(reply);
                            /****
                                sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                                                logDebug2("sCommand1 -> %s",sCommand1);
                                                reply = redisCommand(c,sCommand1);
                                                freeReplyObject(reply);
                            ****/
                            memset(sCommand, '\0', COMMAND_LEN);
                            sprintf(
                                sCommand, "SADD %s:%c:BCAST  %s", BSE_EXCH,
                                DERIVATIVE_SEGMENT, sKeyValue);

                            logDebug2("sCommand -> %s", sCommand);
                            reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                            // reply = redisCommand(c, sCommand);
                            logDebug2("INCR counter: %lld", reply->integer);
                            freeReplyObject(reply);

                            memset(sCommand, '\0', COMMAND_LEN);
                            sprintf(
                                sCommand,
                                "HMSET %s:%s%c%d %s %f SCRIPT %d MKTTYPE %s EXCH %s "
                                "MSGCODE %d SEGMENT %c SM_UPPER_LIMIT %f SM_LOWER_LIMIT "
                                "%f",
                                SET_L1_WATCH, BSE_EXCH, DERIVATIVE_SEGMENT, iToken, SM_LTP,
                                iLtPrice, iToken, sMktType, BSE_EXCH, iTranscodeLocal,
                                DERIVATIVE_SEGMENT, fUpprCkt, fLowrCkt);

                            logTimestamp("sCommand -> %s", sCommand);
                            reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                            freeReplyObject(reply);
                        }
                    }
                    else
                    {

                        memset(sCommand, '\0', COMMAND_LEN);
                        sprintf(
                            sCommand,
                            "HMSET %s LTP %f SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d "
                            "SEGMENT %c HIGH_CKT %f LOW_CKT %f DPR_CHN_FLAG %c ",
                            sKeyValue, iLtPrice, iToken, sMktType, BSE_EXCH,
                            iTranscodeLocal, DERIVATIVE_SEGMENT, fUpprCkt, fLowrCkt,
                            cDprChangeFlag);
                        logDebug2("sCommand -> %s", sCommand);
                        reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                        // reply = redisCommand(c, sCommand);
                        freeReplyObject(reply);
                        /***
                            sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                                            logDebug2("sCommand1 -> %s",sCommand1);
                                            reply = redisCommand(c,sCommand1);
                                            freeReplyObject(reply);
                        ****/
                        memset(sCommand, '\0', COMMAND_LEN);
                        // sprintf(sCommand,"PUBLISH OMSBSECM %s",sKeyValue);
                        sprintf(
                            sCommand, "SADD %s:%c:BCAST  %s", BSE_EXCH,
                            DERIVATIVE_SEGMENT, sKeyValue);
                        logDebug2("sCommand -> %s", sCommand);
                        reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                        //                        reply = redisCommand(c, sCommand);
                        logDebug2("INCR counter: %lld", reply->integer);
                        freeReplyObject(reply);

                        memset(sCommand, '\0', COMMAND_LEN);
                        sprintf(
                            sCommand,
                            "HMSET %s:%s%c%d SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d "
                            "SEGMENT %c SM_UPPER_LIMIT %f SM_LOWER_LIMIT %f",
                            SET_L1_WATCH, BSE_EXCH, DERIVATIVE_SEGMENT, iToken, iToken,
                            sMktType, BSE_EXCH, iTranscodeLocal, DERIVATIVE_SEGMENT, fUpprCkt,
                            fLowrCkt);
                        logTimestamp("sCommand -> %s", sCommand);
                        reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                        freeReplyObject(reply);
                    }
                }
                else
                {
                    logDebug3("LTP IS 0 ");
                    memset(sCommand, '\0', COMMAND_LEN);
                    sprintf(
                        sCommand,
                        "HMSET %s SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c "
                        "HIGH_CKT %f LOW_CKT %f DPR_CHN_FLAG %c ",
                        sKeyValue, iToken, sMktType, BSE_EXCH, iTranscodeLocal,
                        DERIVATIVE_SEGMENT, fUpprCkt, fLowrCkt, cDprChangeFlag);
                    logDebug2("sCommand -> %s", sCommand);
                    reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                    //                    reply = redisCommand(c, sCommand);
                    freeReplyObject(reply);


                    memset(sCommand, '\0', COMMAND_LEN);
                    sprintf(
                        sCommand, "SADD %s:%c:BCAST  %s", BSE_EXCH, DERIVATIVE_SEGMENT,
                        sKeyValue);
                    logDebug2("sCommand -> %s", sCommand);
                    reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                    // reply = redisCommand(c, sCommand);

                    logDebug2("INCR counter: %lld", reply->integer);
                    freeReplyObject(reply);

                    memset(sCommand, '\0', COMMAND_LEN);
                    sprintf(
                        sCommand,
                        "HMSET %s:%s%c%d SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT "
                        "%c SM_UPPER_LIMIT %f SM_LOWER_LIMIT %f",
                        SET_L1_WATCH, BSE_EXCH, DERIVATIVE_SEGMENT, iToken, iToken, sMktType,
                        BSE_EXCH, iTranscodeLocal, DERIVATIVE_SEGMENT, fUpprCkt, fLowrCkt);

                    logTimestamp("sCommand ASHISH -> %s", sCommand);
                    reply = fRedisCommand(c, sCommand, REDIS_TYPE_PRICE_BCAST);
                    freeReplyObject(reply);
                }
            }

        } /*******End Of Inner For Looop*******/

    } /********ENde Of Outer For loop***************/
    logDebug2("Now Returning ");

    return TRUE;
}



/*******************************************************
  Function Name : fConvertBookToMkt

Parameters    : SHORT BookType

Functionality : Converts book type passed to into a mkt type

Return Values : True/False
 *******************************************************/

SHORT fConvertBookToMkt(SHORT iBookType)
{
    INT16 iMkt;

    switch (iBookType)
    {
    case REGULAR_LOT_BOOK:

    case SPECIAL_TERMS_BOOK:

    case STOP_LOSS_BOOK: iMkt = NORMAL_MARKET; break;

    case ODD_LOT_BOOK: iMkt = ODDLOT_MARKET; break;

    case SPOT_LOT_BOOK: iMkt = SPOT_MARKET; break;

    case AUCTION_BOOK: iMkt = AUCTION_MARKET; break;

    default: iMkt = NORMAL_MARKET;
    }
    return iMkt;
}


SHORT fTrim(CHAR *cStr_In, SHORT iMaxLen)
{
    SHORT iStrlen = 0;

    if (iMaxLen <= 0) { return FALSE; }

    for (; cStr_In[iStrlen] != ' ' && iStrlen < iMaxLen; iStrlen++) { continue; }
    cStr_In[iStrlen] = '\0';
    return iStrlen;
}
