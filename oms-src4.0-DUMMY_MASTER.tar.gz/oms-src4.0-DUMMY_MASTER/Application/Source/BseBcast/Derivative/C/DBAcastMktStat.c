#include "IPCS.h"
#include "BseBcastDefn.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

MYSQL	*BEConDB;
LONG32	iRecvQ;

int main(int argc, char ** argv)
{
	logTimestamp("Entry : [main]");

	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	BEConDB = DB_Connect();	

	logDebug2("Connecting to database.......");

	if(mysql_autocommit(BEConDB,1))
	{
		sql_Error(BEConDB);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}	

	if((iRecvQ = OpenMsgQ(DBABSpltrToMktSts)) == ERROR)
	{
		logDebug2("Error in Opening EBABSpltrToMktSts");
		exit(ERROR);
	}

	fBcastUpdMkt();

}

BOOL	fBcastUpdMkt()
{
	INT16   iTranscodeLocal,i;
	CHAR    sRcvMsg[LOCAL_MAX_PACKET_SIZE];


	struct  DUMMY_OMB_HEADER *pForRecTransCode;
	LONG32  iCount;
	BOOL    iRetVal = FALSE;

	while(TRUE)
	{
		memset(&sRcvMsg,' ',LOCAL_MAX_PACKET_SIZE);

		if((ReadMsgQ(iRecvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		pForRecTransCode = (struct DUMMY_OMB_HEADER *) sRcvMsg;
		iTranscodeLocal = pForRecTransCode->iMsgType;

		if(iTranscodeLocal == TC_EQU_BSE_NEWS_BROADCAST)
		{
			logDebug2("In TC_EQU_BSE_NEWS_BROADCAST");	
			fBseExhNews(sRcvMsg);
		}
		else if(iTranscodeLocal == TC_EQU_BSE_SESSION_CHANGED_BROADCAST)
		{
			logDebug2("In TC_EQU_BSE_SESSION_CHANGED_BROADCAST");	
			fSessChngBrdCast(sRcvMsg);
		}
		else if(iTranscodeLocal == TC_EQU_BSE_AUC_SESSION_CHANGED_BROADCAST)
                {
                        logTimestamp("In TC_EQU_BSE_AUC_SESSION_CHANGED_BROADCAST");
                        fSessAucChngBrdCast(sRcvMsg);
                }

		else
		{
			logDebug3("Not handle By this process :%d:",iTranscodeLocal);
		}


	}	
}

BOOL	fBseExhNews(CHAR *pMemIn)
{
	struct  OMB_NEWS_HEADLINE_BROADCAST *pExchMsg = (struct  OMB_NEWS_HEADLINE_BROADCAST *)pMemIn;	

	CHAR	*sInsertQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
        memset(sInsertQry,'\0',MAX_QUERY_SIZE);	
	sprintf(sInsertQry,"INSERT INTO EXCH_MESGS(EXMS_MSG_SEQ_NO,EXMS_TIME,EXMS_EXM_EXCH_ID,EXMS_GENERAL_MESG) VALUES (SELECT NextVal('GEN_MSG'),now(),\"%s\",\"%s\");",BSE_EXCH,pExchMsg->sNewsH1);

	logDebug2("sInsertQry :%s:",sInsertQry);
	logTimestamp("sInsertQry");

	if(mysql_query(BEConDB,sInsertQry) != SUCCESS)
	{
		sql_Error(BEConDB);	
	}
	else
	{
		mysql_commit(BEConDB);
	}


}

BOOL	fSessChngBrdCast(CHAR *pMemIn)
{
	struct  OMB_SESSION_CHANGE_BROADCAST *pSessChg = (struct  OMB_SESSION_CHANGE_BROADCAST *)pMemIn;

	/* CHAR    *sUpdtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);		 */
	CHAR    sUpdtQry[MAX_QUERY_SIZE];		
	memset(sUpdtQry,'\0',MAX_QUERY_SIZE);

	INT16	iStatus = 0;
		
	logDebug2("pSessChg->iCurSession :%d:",pSessChg->iCurSession);
	logDebug2("pSessChg->iMktType :%d:",pSessChg->iMktType);
	
	//if(pSessChg->iCurSession == 0 || pSessChg->iCurSession == 1 || pSessChg->iCurSession == 2 || pSessChg->iCurSession == 3 )

	if (pSessChg->iMktType == 0)
	{
	  /*	if(  pSessChg->iCurSession == 5 || pSessChg->iCurSession == 3 || pSessChg->iCurSession == 1 || pSessChg->iCurSession == 10 || pSessChg->iCurSession == 12|| pSessChg->iCurSession == 2 || pSessChg->iCurSession == 13)
		{
			iStatus = 1;
		}
		else if (pSessChg->iCurSession == 0 || pSessChg->iCurSession == 4 ||pSessChg->iCurSession == 7 )
		{
			iStatus = 2;
		}
		else 
		{
			return;
		}
	}
	else
	{
		return;	
	}
	  */
	  if( pSessChg->iCurSession == 3 || pSessChg->iCurSession == 10 || pSessChg->iCurSession == 12|| pSessChg->iCurSession == 13)
                {
                        iStatus = 1;
                }
                else if (pSessChg->iCurSession == 0 || pSessChg->iCurSession == 4 || pSessChg->iCurSession == 7 || pSessChg->iCurSession == 2 )
                {
                        iStatus = 2;
                }
                else if (pSessChg->iCurSession == 1 )
                {
                        iStatus = 0;
                }
                else if (pSessChg->iCurSession == 5 )
                {
			iStatus = 3;
                }
                else
                {
                        return;
                }
	}

	logDebug2("iStatus :%d:",iStatus);
	sprintf(sUpdtQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_MKT_TYPE = \"NL\" AND EMM_EXCH_SEG =\'D\' ;",iStatus,BSE_EXCH);	

	logDebug2("sUpdtQry :%s:",sUpdtQry);

	if(mysql_query(BEConDB,sUpdtQry) != SUCCESS)
	{
		sql_Error(BEConDB);
	}
	else
	{
		mysql_commit(BEConDB);
	}


}

BOOL    fSessAucChngBrdCast(CHAR *pMemIn)
{
        struct  OMB_AUC_SESSION_CHANGE_BROADCAST *pSessChg = (struct  OMB_AUC_SESSION_CHANGE_BROADCAST*)pMemIn;

        CHAR    sUpdtQry[MAX_QUERY_SIZE];
        memset(sUpdtQry,'\0',MAX_QUERY_SIZE);
        INT16   iStatus = 0;

        logDebug2("pSessChg->iCurSession :%d:",pSessChg->iCurSession);
        logDebug2("pSessChg->MsgType:%d:",pSessChg->MsgType);
	
/*	if (pSessChg->iMktType == 0)
        {
                if(  pSessChg->iCurSession == 5 || pSessChg->iCurSession == 3 || pSessChg->iCurSession == 1 || pSessChg->iCurSession == 10 || pSessChg->iCurSession == 12|| pSessChg->iCurSession == 2 || pSessChg->iCurSession == 13)
                {
                        iStatus = 1;
                }
                else if (pSessChg->iCurSession == 0 || pSessChg->iCurSession == 4 ||pSessChg->iCurSession == 7 ):
                {
                        iStatus = 2;
                }
                else
                {
                        return;
                }
        }
        else
        {
                return;
        }*/

	if (pSessChg->iCurSession == 42)
        {
                iStatus = 1;
        }
        else if (pSessChg->iCurSession == 43)
        {
                iStatus = 2;
        }

        logDebug2("iStatus :%d:",iStatus);
        sprintf(sUpdtQry,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = %d WHERE EMM_EXM_EXCH_ID = \"%s\" AND EMM_MKT_TYPE = \"AU\" AND EMM_EXCH_SEG =\'D\' ;",iStatus,BSE_EXCH);

        logDebug2("sUpdtQry :%s:",sUpdtQry);
        logTimestamp("sUpdtQry");

        if(mysql_query(BEConDB,sUpdtQry) != SUCCESS)
        {
                sql_Error(BEConDB);
        }
        else
        {
                mysql_commit(BEConDB);
        }


}


