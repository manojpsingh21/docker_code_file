#include "IPCS.h"
#include "BseBcastDefn.h"
#include <my_global.h>
#include <mysql.h>

INT16 iMbpCount = 0 ;
MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32 rcvQ;
//BOOL fBcastUpdt(MYSQL *ENMbp_con);
BOOL fBcastUpdt();
//BOOL	dTC_MULTIPLE_INDEX_BCAST(CHAR *NNFData,MYSQL *ENMbp_con);
BOOL	dTC_MULTIPLE_INDEX_BCAST(CHAR *NNFData);
MYSQL *ENMbp_con;

main()
{
	LONG32 	iFlag;
	LONG32 	i;

	pthread_t thread_id[MAX_NO_OF_THREADS];

	/**MYSQL *ENMbp_con[MAX_NO_OF_THREADS];    *******/
	ENMbp_con=DB_Connect();


	logDebug2("Connecting to database.......");

	if(mysql_autocommit(ENMbp_con,1))
	{
		sql_Error(ENMbp_con);
	}
	else
	{
		logDebug2("AutoCommit Enable");
	}



	if((rcvQ=OpenMsgQ(CNBSpltrToIndxUpld))==ERROR)
	{
		perror("\n Error in Opening ENBSpltrToIndxUpld....");
		exit(ERROR);
	}

	logDebug2("Message Queue opened BcasttoMbpMbo : %d:",ENBSpltrToIndxUpld);

	mysql_free_result(result);
	close(ENMbp_con);

	for(i=0;i<1;i++)
	{
		if((pthread_create(&thread_id[i],NULL,fBcastUpdt,NULL))!=0)
			logFatal("Cant create thread %d",i);
		else
			logDebug2("Created");

	}

	for(i=0;i<MAX_NO_OF_THREADS;i++)
	{
		/*Wait for thread to end */
		logDebug2("Thread %d....",i);

		if(pthread_join(thread_id[i],NULL))
			logFatal("Error when waiting for thread %d to terminate",i);
		else
			logDebug2("Stopped");

		logDebug2("Detach thread....");

		if(pthread_detach(&thread_id[i]))
			logFatal("Error Detaching Thread!");
		else
			logDebug2("Detached!");

		logDebug2("Stop Session %d....",i);

		logDebug2("Logged Off");

	}
	mysql_free_result(result);

}



BOOL fBcastUpdt()
{
	INT16 	iTransCodeLocal,i;
	CHAR	sRcvMsg[LOCAL_MAX_PACKET_SIZE];

	struct	NNF_HEADER *pForRectTransCode;

	LONG32	iCount;
	BOOL	iRetVal = FALSE;

	//	ENMbp_con=DB_Connect();		
	/****	
	  struct	TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] =
	  {
	  TC_MULTIPLE_INDEX_BCAST		,dTC_MULTIPLE_INDEX_BCAST
	  };
	 *******/


	while(TRUE)
	{
		memset(&sRcvMsg, ' ',LOCAL_MAX_PACKET_SIZE);

		if(ReadMsgQ(rcvQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE,1) != TRUE)
		{
			perror("Error Read Q");
			exit(ERROR);
		}

		mysql_commit(ENMbp_con);

		pForRectTransCode = (struct NNF_HEADER *)sRcvMsg;

		iTransCodeLocal = pForRectTransCode->iMsgCode;

		/**********
		  for(iCount=0;iCount < MAX_NO_OF_TRANSCODE_RECV;iCount++)
		  {
		  if(TransFunPair[iCount].Transcode == iTransCodeLocal)
		  {
		  if((iRetVal = (*(TransFunPair[iCount].pToFun))(&sRcvMsg)==TRUE))
		  {
		  mysql_commit(ENMbp_con);

		  }
		  else
		  {
		  logFatal("DATABASE NOT UDPATED...,BroadDataUpd returned FALSE %d",iTransCodeLocal);
		  }
		  break;

		  }

		  }
		 **********/
		if(iTransCodeLocal == )

	}	


}


BOOL	dTC_MULTIPLE_INDEX_BCAST(CHAR *NNFData)
{
	BOOL	iRetVal;
	struct NNF_MULTIPLE_INDEX_BCAST *pPacket = (struct NNF_MULTIPLE_INDEX_BCAST *) NNFData;
	CHAR	sExchId[5];
	strcpy(sExchId,"NSE");

	iRetVal = fUpdateMktmvmtBcast(pPacket,sExchId);

	return iRetVal;

}


BOOL  	fUpdateMktmvmtBcast(struct NNF_MULTIPLE_INDEX_BCAST *pMktMvmt,CHAR *sExchId)
{
	INT16 iLoopVar;
	CHAR	sLogTime[DATE_STRING_LENGTH];

	FLOAT32	iIndexVal;
	FLOAT32	iHighIndex;
	FLOAT32	iLowIndex;
	FLOAT32	iOpenIndex;
	FLOAT32	iCloseIndex;
	FLOAT32	iPctcChange;
	FLOAT32	iYearlyHigh;
	FLOAT32	iYearlyLow;

	INT16	iIndexChange;
	INT16	iIndexChangePos;
	INT16	iIndexChangeNeg;

	LONG32	iNoOfUpmoves;
	LONG32	iNoOfDownmoves;

	CHAR	cNetChangeIndictr;

	CHAR	sTempExchId[EXCHANGE_LEN];
	CHAR	sIndexName[INDEX_NAME_LEN];	

	LONG32	iRecCount;
	CHAR	*sUpdInsQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	*sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	strcpy(sTempExchId,sExchId);

	convert_seconds_to_date(pMktMvmt->pHeader.iLogTimeStamp,sLogTime);

	iRecCount = pMktMvmt->iNumberOfRecords;

	for(iLoopVar = 0;iLoopVar < pMktMvmt->iNumberOfRecords;iLoopVar++)
	{

		strcpy(sIndexName,pMktMvmt->pIndicesData[iLoopVar].sIndexName);
		iIndexVal= (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iIndexVal / CONST_PRICE_FACTOR;

		iHighIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iHighIndexVal /CONST_PRICE_FACTOR;
		iLowIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iLowIndexVal /CONST_PRICE_FACTOR;
		iOpenIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iOpeningIndex /CONST_PRICE_FACTOR;
		iCloseIndex = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iClosingIndex /CONST_PRICE_FACTOR;
		iPctcChange=(FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iPercentChange /CONST_PRICE_FACTOR;
		iYearlyHigh = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iYearlyHigh /CONST_PRICE_FACTOR;
		iYearlyLow = (FLOAT32)pMktMvmt->pIndicesData[iLoopVar].iYearlyLow /CONST_PRICE_FACTOR;
		iNoOfUpmoves= pMktMvmt->pIndicesData[iLoopVar].iNoOfUpMoves;
		iNoOfDownmoves= pMktMvmt->pIndicesData[iLoopVar].iNoOfDownMoves;

		cNetChangeIndictr= pMktMvmt->pIndicesData[iLoopVar].cNetChangeIndicator;
		iIndexChange = (int)(iIndexVal-iCloseIndex);

		if(iIndexChange == 0)
		{
			iCloseIndex = 0;
		}

		if(iIndexChange < 0)
		{
			iIndexChangeNeg = abs(iIndexChange);
			iIndexChangePos = NULL;	
		}		
		else
		{
			iIndexChangePos = iIndexChange;
			iIndexChangePos = NULL;
		}

		logDebug2("Record Count :%d:",iRecCount);
		//		printf("\n host_tempNetChangeIndicator :%s: len:%d:",cNetChangeIndictr,strlen());


		sprintf(sUpdInsQ,"UPDATE MULTIPLE_INDEX_INQUIRY SET MII_INDEX_VAL = %i ,MII_HIGH_INDEX_VAL = %i,MII_LOW_INDEX_VAL=%i,MII_OPENING_INDEX=%i,MII_CLOSING_INDEX=DECODE(%i,0,MII_CLOSING_INDEX,%i),MII_PCT_CHANGE=%i,MII_YEARLY_HIGH=%i,MII_YEARLY_LOW=%i,MII_NO_UPS=%i,MII_NO_DOWNS=%i,MII_TIME=STR_TO_DATE(\"%s\",'%%d%%m%%Y %%h%%i%%s') WHERE MII_INDEX_NAME = DECODE(LTRIM(RTRIM(\"%s\")),'CNX Nifty','S&P CNX Nifty',LTRIM(RTRIM(\"%S\"))) AND MII_EXCH_ID = \"%s\"",iIndexVal,iHighIndex,iLowIndex,iOpenIndex,iCloseIndex,iCloseIndex,iPctcChange,iYearlyHigh,iYearlyLow,iNoOfUpmoves,iNoOfDownmoves,sLogTime,sIndexName,sIndexName,sTempExchId);

		logDebug2("sUpdInsQ :%s:",sUpdInsQ);

		if(mysql_query(ENMbp_con,sUpdInsQ) != SUCCESS)
		{
			sql_Error(ENMbp_con);

			sprintf(sInsQry,"INSERT INTO MULTIPLE_INDEX_INQUIRY(MII_INDEX_NAME ,  MII_EXCH_ID ,MII_INDEX_VAL ,MII_HIGH_INDEX_VAL,MII_LOW_INDEX_VAL ,MII_OPENING_INDEX ,MII_CLOSING_INDEX ,MII_PCT_CHANGE,MII_YEARLY_HIGH ,MII_YEARLY_LOW,MII_NO_UPS,MII_NO_DOWNS,MII_TIME)VALUES(\"%s\",%i,%i,%i,%i,%i,%i,%i,%i,%i,%i)",sIndexName,sTempExchId,iIndexVal,iHighIndex,iLowIndex,iOpenIndex,iCloseIndex,iPctcChange,iYearlyHigh,iYearlyLow,iIndexChangePos,iIndexChangeNeg);

			logDebug2("sInsQry :%s:",sInsQry);

			if(mysql_query(ENMbp_con,sInsQry) != SUCCESS)
			{
				sql_Error(ENMbp_con);
			}
			else
			{
				mysql_commit(ENMbp_con);
			}	
		}
		else
		{
			mysql_commit(ENMbp_con);
		}	

	}	


	return TRUE;
}



