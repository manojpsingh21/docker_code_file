#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

//extern DBConNEQ;

BOOL GetMktType(CHAR *sMktType,LONG32 iMktType);

BOOL RMSValidation(struct  INT_SPREAD_ORDERS *pReq, CHAR *pRes,MYSQL *DBObj)
{
	MYSQL_RES       *Res;
		MYSQL_ROW       Row;
		INT16		iNumRow;
		CHAR *Pr_Query = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		INT16		iStatus;
		BOOL		iChkFlg = FALSE;
		
		CHAR 	sMktWatch[3];
		CHAR	sRMSStatus[15];
		LONG32		iQty;
		DOUBLE64 	fAmount;
		memset(sMktWatch,'\0',3);
		
		CHAR	cTypeofOrd;
		CHAR	sProcName[20];
		memset(sProcName,'\0',20);
		
		//if(mysql_set_server_option(DBConNEQ,MYSQL_OPTION_MULTI_STATEMENTS_ON) == 0)
		if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
		{
			logDebug2(" mysql_set_server_option SUCCESS");
		}
		else
		{
			logDebug2(" mysql_set_server_option FAILed");
				sprintf(pRes," mysql_set_server_option FAILS");
				return FALSE;
		}
	iChkFlg  = GetMktType(&sMktWatch,pReq->iMktType);
		
		if(iChkFlg == FALSE)
		{
			logDebug2("Invalid Mkt Type :%d:",pReq->iMktType);
				return INVALID_MKT_TYPE;
		}	
	
		switch(pReq->ReqHeader.iMsgCode)
		{
			case TC_INT_ORDER_ENTRY_REQ:
			case TC_INT_OFF_ORDER_ENTRY:
						    cTypeofOrd = 'N';
							    break;
			case TC_INT_ORDER_MODIFY:
			case TC_INT_OFF_ORDER_MODIFY:
						     cTypeofOrd = 'M';
							     break;
			case TC_INT_ORDER_CANCEL:
			case TC_INT_OFF_ORDER_CANCEL:
						     cTypeofOrd = 'C';
							     break;
			case TC_INT_CON_DEL_REQ:
						cTypeofOrd = 'T';
							break;
			default :
				 logDebug2("Invalid MsgCode");
					 sprintf(pRes,"Invalid MsgCode");
					 return FALSE;
					 break;
					 
		}
	
		
		
		logDebug2("sMktWatch :%s: iMktType :%d:",sMktWatch,pReq->iMktType);
		logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->ReqHeader.iMsgCode);
		
		if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
		{
			strncpy(sProcName,"RMS_VALIDATE_CUR",20);
		}
		else
		{
			strncpy(sProcName,"RMS_VALIDATE",20);
		}	
	
		sprintf(Pr_Query,"CALL  %s(\"%s\",\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\")),@ZSTATUS,@ZINSQTY,@ZINSAMT );\  			SELECT  @ZSTATUS, @ZINSQTY, @ZINSAMT ;",sProcName,pReq->sClientId,pReq->sSecId_1,pReq->sSecId_2,pReq->cBuySellInd,pReq->iTotalQty,pReq->fOrderPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrdNo,pReq->iSerialNo,cTypeofOrd,sMktWatch);	
		
		logDebug2(":%s:",Pr_Query);
		if(mysql_query(DBObj,Pr_Query) != SUCCESS)
		{
			sql_Error(DBObj);
				free(Pr_Query);
				logFatal("Error IN CALLING RMS_VALIDATE .");
				//                exit(ERROR);
		}
	
		do{
			
				Res = mysql_store_result(DBObj);			
				if(Res)
				{
					if((Row = mysql_fetch_row(Res)))
					{
						strncpy(sRMSStatus,Row[0],15);
							iQty = atoi(Row[1]);
							fAmount = atof(Row[2]);
							//	logDebug2("iQty is-%d",iQty);
							mysql_free_result(Res);
							logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
							
					}
				}
				else
				{
					logDebug2("No Result Set ");
				}
			
				if((iStatus =mysql_next_result(DBObj)) > 0)	
				{
					logDebug3("Could not execute statement");
				}
			//	logDebug2("iStatus is-%d",iStatus);
		}while(iStatus == 0);
	
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		logInfo(" pReq->sClientId :%s:",pReq->sClientId);	
		
		if(strncmp(sRMSStatus,"S",1) == 0)
		{
			logDebug1(" RMS_VALIDATE SUCCESS ");
				free(Pr_Query);
				return TRUE;
				
		}
	//	else if(strncmp(sRMSStatus,"S",1))
		else
		{
			logDebug1(" RMS_VALIDATE FAIL ");
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
				sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
				logInfo("%s",pRes);
				return FALSE;
				
		}
	/*	else if(strncmp(sRMSStatus,"E",1) == 0)
		{
		logDebug1("Return Nothing in RMS_VALIDATE");
		sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
		logInfo("%s",pRes);
		free(Pr_Query);
		return FALSE;	
		}
	 */
	
}

BOOL CncRevValidate(struct  ORDER_RESPONSE *pReq,MYSQL *DBconRMS)
{
	MYSQL_RES       *Res;
		MYSQL_ROW       Row;
		INT16           iNumRow;
		CHAR *Pr_Query = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		INT16           iStatus;
		CHAR            cOrdStatus;
		LONG32		iQuantity;
		
		CHAR    sMktWatch[3];
		CHAR    sRMSStatus[15];
		LONG32          iQty = 0;
		DOUBLE64        fAmount = 0.00;
		DOUBLE64        fPrice = 0.00;
		memset(sMktWatch,'\0',3);
		
		
		//GetMktType(&sMktWatch,pReq->iMktType);
		logDebug2("iMktType :%d:",pReq->iMktType);	
		GetMktType(&sMktWatch,pReq->iMktType);
		CHAR    cTypeofOrd;
		//if(mysql_set_server_option(DBconRMS ,MYSQL_OPTION_MULTI_STATEMENTS_ON) == 0)
		if(mysql_set_server_option(DBconRMS,CLIENT_MULTI_STATEMENTS) == 0)
		{
			logDebug2(" mysql_set_server_option SUCCESS");
		}
		else
		{
			logDebug2(" mysql_set_server_option FAILS");
		}
	
		switch(pReq->IntRespHeader.iMsgCode)
		{
			case TC_INT_OE_ERROR_RESP:
						  cTypeofOrd = 'N';
							  cOrdStatus = 'R';
							  iQuantity  = pReq->iTotalQty;
							  fPrice	   = pReq->fPrice;	
							  break;
			case TC_INT_OM_ERROR_RESP:
						  cTypeofOrd = 'M';
							  cOrdStatus = 'R';
							  fPrice	   = pReq->fPrice;	
							  iQuantity  = pReq->iTotalQty;
							  break;
			case TC_INT_OC_CONF_RESP:
			case TC_INT_OFF_ORDER_CANCEL_RSP:
							 cTypeofOrd = 'C';
								 cOrdStatus = 'T';
								 iQuantity  = pReq->iTotalQtyRem;
								 fPrice	   = pReq->fPrice;	
								 break;
			case TC_INT_TRADE_RESP:
					       cTypeofOrd = 'N';
						       cOrdStatus = 'T';
						       iQuantity  = pReq->iLastTradedQty;
						       fPrice	   = pReq->fTradePrice	;	
						       break;
			case TC_INT_MKT_LMT_CONVT_RESP:
						       cTypeofOrd = 'M';
							       cOrdStatus = 'L';
							       iQuantity  = pReq->iTotalQty;
							       fPrice	   = pReq->fPrice;	
							       break;
			default :
				 logDebug2("Invalid MsgCode");
					 break;
					 
		}
	
		
		
		logDebug2("sMktWatch :%s: iMktType ",sMktWatch);
		logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->IntRespHeader.iMsgCode);
		
		sprintf(Pr_Query,"CALL  RMS_VALIDATE(ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'%c\',now(),ltrim(rtrim(\"%s\")), @ZSTATUS, @ZINSQTY, @ZINSAMT );\  SELECT  @ZSTATUS, @ZINSQTY, @ZINSAMT ;",pReq->sClientId,pReq->sSecurityId,pReq->cBuyOrSell,iQuantity,fPrice,pReq->cProductId,pReq->IntRespHeader.cSegment,pReq->IntRespHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,cOrdStatus,sMktWatch);
		
		logDebug2(":%s:",Pr_Query);
		
		logDebug1("Nitish here 1 ");
		if(mysql_query(DBconRMS,Pr_Query) != SUCCESS)
		{
			sql_Error(DBconRMS);
				free(Pr_Query);
				logFatal("Error IN CALLING RMS_VALIDATE .");
		}
	logDebug1("Nitish here 2 ");
		
		//iNumRow = mysql_num_rows(Res);
		//logInfo("iNumRow :%d:",iNumRow);
		logDebug1("Nitish here 3 ");
		
		do{
			
				Res = mysql_store_result(DBconRMS);
				
				if(Res)
				{
					if((Row = mysql_fetch_row(Res)))
					{
						strncpy(sRMSStatus,Row[0],15);
							iQty = atoi(Row[1]);
							fAmount = atof(Row[2]);
							mysql_free_result(Res);
							logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
					}
				}
				else
				{
					logDebug2("No Result Set ");
				}
			
				if((iStatus =mysql_next_result(DBconRMS)) > 0)
				{
					logDebug3("Could not execute statement");
				}
		}while(iStatus == 0);
	
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		logInfo(" pReq->sClientId :%s:",pReq->sClientId);
		
		if(strncmp(sRMSStatus,"S",1) == 0)
		{
			logDebug1(" RMS_VALIDATE SUCCESS ");
				return TRUE;
				
		}
		else if (strncmp(sRMSStatus,"S",1))
		{
			logDebug1(" RMS_VALIDATE FAIL ");
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
				//sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
				//logInfo("%s",pRes);
				return FALSE;
				
		}
		else if(strncmp(sRMSStatus,"E",1) == 0)
		{
			logDebug1("Return Nothing in RMS_VALIDATE");
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
				//sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
				//logInfo("%s",pRes);
				return FALSE;
		}
	
		
}
