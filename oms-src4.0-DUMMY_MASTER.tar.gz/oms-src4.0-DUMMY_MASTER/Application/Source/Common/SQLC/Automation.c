#include<stdio.h>
#include<string.h>
#include<mysql.h>
#include <stdlib.h>
#define min 40
#define max 125


int DBConnect();
void Unscramble(char *sStr);
int flag;

main(int argc, char *argv[])
{
	//printf("argc :%d:",argc);

	if(argv[1] == NULL)
	{
	//	printf("No Option Set\n");
		flag = 3;
		//exit(1);
	}
	else
	{	
		flag = atoi(argv[1]);
	}

	int iReturnvalue;
	//	printf("Flag is = :%d:\n",flag);
	iReturnvalue = DBConnect();
	if(iReturnvalue != 1)
	{
		//		printf("Failed to Coonect DB \n");
		printf("FAILED\n");
	}
	//	printf("EXIT Main \n");
	exit(0);	
}


int DBConnect()
{
	//	printf("Entry : [DBConnect]\n");
	char sDbUser[20];
	char sDbPasswd[20];
	char sSchema[20];
	char sHostIP[75];

	char    Pr_Query [6000];
	char    sResult [6000];
	int iError;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	int iStatus =0;

	int Count;
	int EQ_COUNT;
	int DRV_COUNT;
	int COMM_COUNT; 
	char status[1500];
	memset(sDbUser,'\0',20);
	memset(sDbPasswd,'\0',20);
	memset(sSchema,'\0',20);
	memset(sHostIP,'\0',75);

	MYSQL *DB_Con = mysql_init(NULL);

	strncpy(sDbUser,getenv("MYSQL_USER"),20);
	strncpy(sDbPasswd,getenv("MYSQL_PASS"),20);
	strncpy(sSchema,getenv("MYSQL_DB"),20);
	strncpy(sHostIP,getenv("MYSQL_HOST"),75);

	if (DB_Con == NULL)
	{
		perror("Error Got Here = :");
		return 0;
	}

	my_bool reconnect = 1;

	if (mysql_options(DB_Con, MYSQL_OPT_RECONNECT, &reconnect)) 
	{
		printf("MYSQL_OPT_RECONNECT SET FAILED.\n");
		return 0;
	}
	else
	{
		//		printf("MYSQL_OPT_RECONNECT SET SUCCESS.\n");
	}

//	printf("sHostIP      :%s:\n",sHostIP);
//	printf("sDbUser      :%s:\n",sDbUser);
//	printf("sDbPasswd    :%s:\n",sDbPasswd);
//	printf("sSchema      :%s:\n",sSchema);

	Unscramble(sDbPasswd);
	Unscramble(sSchema);
//	printf("sSchema :%s: sDbPasswd :%s:\n",sSchema,sDbPasswd);
	//logDebug2("sSchema :%s: sDbPasswd :%s:",sSchema,sDbPasswd);

	//if (mysql_real_connect(DB_Con, "localhost", "root", "rupeesql", "rupeeSQLDB", 0, NULL, 0) == NULL){
	//	for(Count = 0; Count < NoofTry; Count++)

	while(flag>=0){
		if (mysql_real_connect(DB_Con, sHostIP, sDbUser, sDbPasswd, sSchema, 0, NULL, 0) == NULL)
		{
			//			perror("Error Got in mysql_real_connect = :");
			printf("Failed To Connect ");
			flag--;
			if(flag <0){
				return 0;
			}

		}
	//	printf("Connected");
		break;
	}


	if(mysql_set_server_option(DB_Con,CLIENT_MULTI_STATEMENTS) == 0)
	{
		//		printf("mysql_set_server_option SUCCESS\n");
	}
	else
	{
		//		printf("mysql_set_server_option FAILED\n");
		return 0;
	}


	sprintf(Pr_Query,"call ALL_PROCESS_TEST(@zstatus);\
			select @ZSTATUS;");

	//	printf("Pr_Query = %s\n",Pr_Query);

	if(mysql_query(DB_Con,Pr_Query) != 0)
	{
		//	perror("Error in Calling Procedure \n");
		iError  = mysql_errno(DB_Con);
		printf("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
		return 0;
	}
	do{
		Res = mysql_store_result(DB_Con);
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(status,Row[0],10);
				mysql_free_result(Res);
				printf("%s\n", status);

			}
		}
		else
		{
			//		printf("No Result Set \n");
		}

		if((iStatus =mysql_next_result(DB_Con)) > 0)
		{
			//		printf("Could not execute statement :%d:\n",iStatus);
		}


	}while(iStatus == 0);
	return 1;	

}
//	printf("Connected to Database.\n");

//	printf("Exit : [DB_Connect]\n");
//	return DB_Con;


void Unscramble(char *sStr)
{
	int i=0;
	for(i = strlen(sStr) - 1; i >= 0; i--)
	{
		//printf("%c\n",sStr[i]);
		if((sStr[i] - i) < min)
		{
			sStr[i] = max - (min - (sStr[i] - i));
		}
		else
		{
			sStr[i] = sStr[i] - i;
		}
	}
}
