#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

//extern DBConNEQ;

DOUBLE64        fLtp =0.00;
BOOL GetMktType(CHAR *sMktType,LONG32 iMktType);
BOOL fBoRMSValidation(struct  BO_ORDER_REQUEST *pReq,MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,DOUBLE64 *fLtp,CHAR *sAccCode,CHAR *sErrorMsg,CHAR *sPan,DOUBLE64 fRef_ltp,DOUBLE64 fNrSrptLTP,DOUBLE64 *fMppOrdPrice,DOUBLE64 *fSlMppOrdPrice,DOUBLE64 *fMppBlkPrice, DOUBLE64 *fSlMppBlkPrice);

BOOL fRMSValidation(struct  INT_ORDERS *pReq, MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,CHAR *sErrorMsg,DOUBLE64 fLTP,DOUBLE64 fNrSrptLTP,DOUBLE64 *fMppOrdPrice,DOUBLE64 *fSlMppOrdPrice,DOUBLE64 *fMppBlkPrice, DOUBLE64 *fSlMppBlkPrice)
{
	logTimestamp("Entry :fRMSValidation");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	INT16		iNumRow;
	CHAR 	Pr_Query [MAX_QUERY_SIZE];
	INT16		iStatus;
	BOOL		iChkFlg = FALSE;
	LONG32    iCmBranchId;

	struct timeval tv,cv;
	double iStartTime,iEndTime;

	//gettimeofday(&tv, NULL);

	CHAR 	sMktWatch[3];
	CHAR	sRMSStatus[15];
	memset	(sRMSStatus,'\0',15);
	LONG32		iQty;
	LONG32		iError;
	DOUBLE64 	fAmount;
	DOUBLE64 	fstart ;
	DOUBLE64 	fEnd;
	memset(sMktWatch,'\0',3);
	LONG32 iStart = 0;
	LONG32	iEnd = 0;

	CHAR	cTypeofOrd;
	CHAR	cOfflineFlag ;
	CHAR	sProcName[PROC_NAME_LEN];
	memset(sProcName,'\0',PROC_NAME_LEN);
	memset(Pr_Query,'\0',MAX_QUERY_SIZE);

	CHAR 	Pr_SelQry [MAX_QUERY_SIZE];
	memset(Pr_SelQry, '\0' ,MAX_QUERY_SIZE);
	
	logDebug2("************************");	
	logDebug2("pReq->iMktType = %d",pReq->iMktType);

	//if(mysql_set_server_option(DBConNEQ,MYSQL_OPTION_MULTI_STATEMENTS_ON) == 0)
	if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		return FALSE;
	}
	iChkFlg  = GetMktType(&sMktWatch,pReq->iMktType);

	if(iChkFlg == FALSE)
	{
		logDebug2("Invalid Mkt Type :%d:",pReq->iMktType);
		return INVALID_MKT_TYPE;
	}	

	switch(pReq->ReqHeader.iMsgCode)
	{
		case TC_INT_ORDER_ENTRY_REQ:
		case TC_INT_OFF_ORDER_ENTRY:
			cTypeofOrd = NEW_ORDER;
			break;
		case TC_INT_ORDER_MODIFY:
		case TC_INT_OFF_ORDER_MODIFY:
			cTypeofOrd = ORDER_MODIFY;
			break;
		case TC_INT_ORDER_CANCEL:
		case TC_INT_OFF_ORDER_CANCEL:
			cTypeofOrd = ORDER_CANCEL;
			break;
		default :
			logDebug2("Invalid MsgCode");
			return FALSE;
			break;

	}

	if(pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		cOfflineFlag = YES;
	}
	else
	{
		cOfflineFlag = NO;
	}

	logDebug2("cOfflineFlag = %c",cOfflineFlag );

	logDebug2("sMktWatch :%s: iMktType :%d:",sMktWatch,pReq->iMktType);
	logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->ReqHeader.iMsgCode);
	logDebug2("pReq->ReqHeader.cSegment :%c: ",pReq->ReqHeader.cSegment);

	/***/
	if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		strncpy(sProcName,RMS_CURR,PROC_NAME_LEN);
	}
	else
	{
		strncpy(sProcName,RMS_EQ_FO,PROC_NAME_LEN);
	}	
	/***/
	logDebug2("sProcName :%s:",sProcName);
	logDebug2("Enviorment Variable [%d]",iPEnv);
	logDebug2("sClientId:%s:",pReq->sClientId);
	logDebug2("sSecId:%s:",pReq->sSecId);
	logDebug2("cBuySellInd:%c:",pReq->cBuySellInd);
	logDebug2("iTotalQty:%d:",pReq->iTotalQty);
	logDebug2("pReq->fOrderPrice:%lf:",pReq->fOrderPrice);
	logDebug2("pReq->cProductId:%c:",pReq->cProductId);
	logDebug2("pReq->ReqHeader.sExcgId:%s:",pReq->ReqHeader.sExcgId);
	logDebug2("pReq->fOrdNo:%lf:",pReq->fOrdNo);
	logDebug2("pReq->iSerialNo:%d:",pReq->iSerialNo);
	logDebug2("cTypeofOrd:%c:",cTypeofOrd);
	logDebug2("sMktWatch:%s:",sMktWatch);
	logDebug2("pReq->Dealer_Id:%s:",pReq->sEntityId);
	logDebug2("pReq->cUserType:%c:",pReq->cUserType);
	logDebug2("pReq->fTriggerPrice:%lf:",pReq->fTriggerPrice);
	logDebug2("pReq->fAlgoOrderNo :%lf:",pReq->fAlgoOrderNo);
	logDebug2("iPEnv:%d:",iPEnv);
	logDebug2("pReq->ReqHeader.cSegment:%c:",pReq->ReqHeader.cSegment);
	logDebug2("pReq->cOrderOffOn :%c:",pReq->cOrderOffOn);
	logDebug2("pReq->fLtp:%lf:",pReq->fLtp);


	//MPP Changes 
	//logDebug2("fLtp = |%f|",fLTP);
	logDebug2("fNrSrptLTP = |%f|",fNrSrptLTP);
        logDebug2("pReq->iStratergyId |%d|",pReq->iStratergyId);


	/************************************
 		parameter pan is added in 
 		rms output of client.
 	************************************/
	if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		sprintf(Pr_Query,"CALL  RMS_VALIDATE_CUR(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\"))\
			,\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,0,'N',\'%c\',%lf,%lf,%d,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT ,@ZLTP,@ZACCNT,@ZERRSTR,\
			@UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI);\
			SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),\
			IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),\
			IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@MPPORDPRI,0.00),IFNULL(@SLMPPORDPRI,0.00),IFNULL(@MPPBLKPRI,0.00),\
			IFNULL(@SLMPPBLKPRI,0.00),IFNULL(@RMS_LOG,'NA')  ;",\
			pReq->sClientId,pReq->sSecId,pReq->cBuySellInd,pReq->iTotalQty,pReq->fOrderPrice,pReq->cProductId,pReq->ReqHeader.cSegment,\
			pReq->ReqHeader.sExcgId,pReq->fOrdNo,pReq->iSerialNo,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,\
			pReq->fTriggerPrice,pReq->iLegValue,cOfflineFlag,pReq->fAlgoOrderNo,pReq->cOrderOffOn,pReq->fLtp,fNrSrptLTP,pReq->iStratergyId);	
	}
	else
	{

	
		 sprintf(Pr_Query,"CALL  RMS_VALIDATE(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\"))\
                        ,\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N',\'%c\',%lf,%lf,%d,0.00,%lf,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP,@ZACCNT,@ZERRSTR,@MKT_TYPE,\
                        @UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI) ;\
                        SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00), IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),\
			IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),\
			IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@MPPORDPRI,0.00),IFNULL(@SLMPPORDPRI,0.00),IFNULL(@MPPBLKPRI,0.00),\
			IFNULL(@SLMPPBLKPRI,0.00),IFNULL(@RMS_LOG,'NA') ;",pReq->sClientId,pReq->sSecId,pReq->cBuySellInd,pReq->iTotalQty,pReq->fOrderPrice,\
			pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrdNo,pReq->iSerialNo,cTypeofOrd,sMktWatch,pReq->sEntityId,\
			pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->iLegValue,cOfflineFlag,pReq->fAlgoOrderNo,pReq->cOrderOffOn,pReq->fLtp,fNrSrptLTP,pReq->iStratergyId,pReq->fLtp);
	

	}

	logDebug2(":%s:",Pr_Query);
	if(mysql_query(DBObj,Pr_Query) != SUCCESS)
	{
		sql_Error(DBObj);
		iError  = mysql_errno(DBObj);
		logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);

		sprintf(Pr_SelQry, "SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00), IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA') ;");
	
		if (mysql_query(DBObj,Pr_SelQry) != SUCCESS)
		{
			sql_Error(DBObj);
			logFatal("ERROR Received While Calling RMS_VALIDATE ");
		}
		Res = mysql_store_result(DBObj);
		Row = mysql_fetch_row(Res);
		printf("\nRMS_LOG :%s:\n",Row[11]);
		mysql_free_result(Res);
		return ERROR;
	}
	/*	gettimeofday(&cv, NULL);
		iEndTime = (double) ((cv.tv_sec*1000000)+cv.tv_usec);
		logDebug2("iEndTime :%lf:",iEndTime);
	//fEnd = logGetTime();
	//	logDebug2("Successfuly RMS Executed EndTime :%lf:",fEnd);
	logDebug2(" FORWARD RMSTIMEDIFF :%lf: SEGMENT :%c: ",(iEndTime - iStartTime),pReq->ReqHeader.cSegment);
	 ***/
	do{
	
		Res = mysql_store_result(DBObj);			
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				printf("\nRMS_LOG :%s:\n",Row[15]);
				strncpy(sRMSStatus,Row[0],15);
				iQty = atoi(Row[1]);
				fAmount = atof(Row[2]);
				logDebug2("sRMSStatus :%s: Quantity :%d: Amount :%lf:",sRMSStatus,iQty,fAmount);	

				if(strlen(Row[4]) == 0)
				{
					logDebug2("******ACCOUNT ID RETURN FROM RMS**** :%d: ",strlen(Row[4]));
					return ERROR;
				}
				strncpy(pReq->sAccCode,Row[4],DB_ACC_CODE_LEN);
				strncpy(sErrorMsg,Row[5],DB_REASON_DESC_LEN);
				strncpy(pReq->sPanNo,Row[9],INT_PAN_LEN);
                                logDebug2("pReq->sAccCode :%s: sErrorMsg :%s: pReq->sPanNo :%s:",pReq->sAccCode,sErrorMsg,pReq->sPanNo);

				if(strcmp(Row[6],"NL")== 0)
                                {
                                        pReq->iMktType = NORMAL_MARKET;
                                }
                                else if(strcmp(Row[6],"OL") == 0)
                                {
                                        pReq->iMktType = ODDLOT_MARKET;
                                }
                                else if(strcmp(Row[6],"SP")== 0)
                                {
                                        pReq->iMktType = SPOT_MARKET;
                                }
                                else if(strcmp(Row[6],"AU") == 0)
                                {
                                        pReq->iMktType = AUCTION_MARKET;
                                }
                                else if(strcmp(Row[6],"A1") == 0)
                                {
                                        pReq->iMktType = CALL_AUCTION_MARKET1;
                                }
                                else if(strcmp(Row[6],"A2") == 0)
                                {
                                        pReq->iMktType = CALL_AUCTION_MARKET2;
                                }
                                else
                                {
                                        logDebug2("Invalid MktType :%s:",Row[6]);
                                }
				if(strcmp(sMktWatch,"AU")== 0)/*Auction handling*/
                                {
                                        pReq->iMktType = AUCTION_MARKET;
                                }
                                else
                                {
                                        logDebug2("pReq->iMktType :%d:",pReq->iMktType);
                                }
                                logDebug2("pReq->iMktType :%d:",pReq->iMktType);
                                if(pReq->ReqHeader.cSegment != EQUITY_SEGMENT)
                                {
                                        pReq->fUnderlyPrice = atof(Row[7]);
                                        pReq->fRmsBlockAmt = atof(Row[8]);
                                }



                                logDebug2("pReq->iMktType :%d:",pReq->iMktType);
				logDebug2("fUnderlyPrice :%lf:",pReq->fUnderlyPrice);

				*fMppOrdPrice = atof(Row[11]);
                                *fSlMppOrdPrice = atof(Row[12]);
                                *fMppBlkPrice = atof(Row[13]);
                                *fSlMppBlkPrice = atof(Row[14]);

				mysql_free_result(Res);
				logDebug2("fMppOrdPrice = %f",*fMppOrdPrice);
                                logDebug2("fSlMppOrdPrice = %f",*fSlMppOrdPrice);
                                logDebug2("fMppBlkPrice = %f",*fMppBlkPrice);
                                logDebug2("fSlMppBlkPrice = %f",*fSlMppBlkPrice);
		
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf: sAccCode :%s:",sRMSStatus,iQty,fAmount,pReq->sAccCode);
	
			}
		}
		else
		{
			logDebug2("No Result Set ");
		}
	
		if((iStatus =mysql_next_result(DBObj)) > 0)	
		{
			logDebug3("Could not execute statement :%d:",iStatus);
		}
	
		logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBObj));

	}while(iStatus == 0);

	logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
	logInfo(" pReq->sClientId :%s:",pReq->sClientId);	

	pReq->fMppOrdPrice = *fMppOrdPrice;
        pReq->fSlMppOrdPrice = *fSlMppOrdPrice;
        pReq->fMppBlkPrice = *fMppBlkPrice;
        pReq->fSlMppBlkPrice = *fSlMppBlkPrice;

        logDebug2("pReq->fMppOrdPrice = %f",pReq->fMppOrdPrice);
        logDebug2("pReq->fSlMppOrdPrice = %f",pReq->fSlMppOrdPrice);
        logDebug2("pReq->fMppBlkPrice = %f",pReq->fMppBlkPrice);
        logDebug2("pReq->fSlMppBlkPrice = %f",pReq->fSlMppBlkPrice);

	if(strncmp(sRMSStatus,"S",2)== 0)
	{
		logDebug2(" RMS_VALIDATE SUCCESS ");
		logTimestamp("Exit :fRMSValidation");
		return TRUE;

	}
	else if(strncmp(sRMSStatus,"F",2)== 0)
	{
		logDebug2("Returned Null value in sRMSStatus");
		logDebug2("##############ERROR IN CALLING RMS########################");
		*fAmnt = fAmount;
		*iQuantity = iQty;
		logInfo("%lf",*fAmnt);
		logInfo("%d",*iQuantity);
		logTimestamp("Exit :fRMSValidation");
		return FALSE;
	}
	//	else if(strncmp(sRMSStatus,"S",1))
	else
	{
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		strncpy(sErrorID,sRMSStatus,10);
		*fAmnt = fAmount;
		*iQuantity = iQty;
	//	strncpy(sErrorMsg,sRMSStatus,DB_REASON_DESC_LEN);
		//sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
		logDebug2("##############ERROR IN CALLING RMS########################");
		//logInfo("%s",pRes);
		logInfo("%s",sErrorID);
		logInfo("%lf",*fAmnt);
		logInfo("%d",*iQuantity);
		logTimestamp("Exit :fRMSValidation");
		return FALSE;

	}

}



BOOL fCoRMSValidation(struct  CO_ORDER_REQUEST *pReq,MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,CHAR *sAccCode,CHAR *sErrorMsg,CHAR *sPan ,DOUBLE64 fRef_ltp,DOUBLE64 fNrSrptLTP,DOUBLE64 *fMppOrdPrice,DOUBLE64 *fSlMppOrdPrice,DOUBLE64 *fMppBlkPrice, DOUBLE64 *fSlMppBlkPrice)
{
	logTimestamp("Entry :fCoRMSValidation for Cover Orderrrrr123");
	MYSQL_RES       *Res;	
	MYSQL_ROW       Row;
	INT16           iNumRow;
	CHAR    Pr_Query [MAX_QUERY_SIZE];
	INT16           iStatus;
	BOOL            iChkFlg = FALSE;
	LONG32    iCmBranchId;
	CHAR    sMktWatch[3];
	CHAR    sRMSStatus[15];
	memset  (sRMSStatus,'\0',15);
	LONG32          iQty;
	DOUBLE64        fAmount;
	memset(sMktWatch,'\0',3);

	CHAR    cTypeofOrd;
	CHAR	cOfflineFlag;
	CHAR    sProcName[PROC_NAME_LEN];
	memset(sProcName,'\0',PROC_NAME_LEN);
	memset(Pr_Query,'\0',MAX_QUERY_SIZE);

	LONG32          iError;
	CHAR    Pr_SelQry [MAX_QUERY_SIZE];
        memset(Pr_SelQry, '\0' ,MAX_QUERY_SIZE);

	logDebug2("************************");
	logDebug2("pReq->iMktType = %d",pReq->iMktType);
	logDebug2("fLTP = %lf",fRef_ltp);

	if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		//                sprintf(pRes," mysql_set_server_option FAILS");
		return FALSE;
	}
	iChkFlg  = GetMktType(&sMktWatch,pReq->iMktType);

	if(iChkFlg == FALSE)
	{
		logDebug2("Invalid Mkt Type :%d:",pReq->iMktType);
		return INVALID_MKT_TYPE;

	}
	logDebug2("pReq->ReqHeader.iMsgCode :%d:",pReq->ReqHeader.iMsgCode);

	switch(pReq->ReqHeader.iMsgCode)
	{
		case TC_INT_CO_ORDER_REQ:
		case TC_INT_OFF_ORDER_ENTRY:
		case TC_INT_CO_REJ_SQROFF :
			cTypeofOrd = NEW_ORDER;
			break;
		case TC_INT_CO_ORDER_MODIFY:
		case TC_INT_OFF_ORDER_MODIFY:
			cTypeofOrd = ORDER_MODIFY;
			break;
		case TC_INT_ORDER_CANCEL:
		case TC_INT_OFF_ORDER_CANCEL:
			cTypeofOrd = ORDER_CANCEL;
			break;
		default :
			logDebug2("Invalid MsgCode");
			//                      sprintf(pRes,"Invalid MsgCode");
			return FALSE;
			break;

	}

	if(pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		cOfflineFlag= YES;
	}
	else
	{
		cOfflineFlag= NO;
	}

	logDebug2("cOfflineFlag= %c",cOfflineFlag);

	logDebug2("sMktWatch :%s: iMktType :%d:",sMktWatch,pReq->iMktType);
	logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->ReqHeader.iMsgCode);
	logDebug2("pReq->ReqHeader.cSegment :%c: ",pReq->ReqHeader.cSegment);
	logDebug2("Enviorment Variable [%d]",iPEnv);
	logDebug2("sClientId:%s:",pReq->sClientId);
	logDebug2("sSecId:%s:",pReq->sSecurityId);
	logDebug2("cBuySellInd:%c:",pReq->CoArray[0].cBuySellInd);
	logDebug2("iTotalQty:%d:",pReq->iTotalQty);
	logDebug2("pReq->fPrice:%lf:",pReq->fPrice);
	logDebug2("pReq->cProductId:%c:",pReq->cProductId);
	logDebug2("pReq->ReqHeader.cSegment:%c:",pReq->ReqHeader.cSegment);
	logDebug2("pReq->ReqHeader.sExcgId:%s:",pReq->ReqHeader.sExcgId);
	logDebug2("pReq->fOrderNum:%lf:",pReq->fOrderNum);
	logDebug2("pReq->iSerialNo:%d:",pReq->iSerialNum);
	logDebug2("cTypeofOrd:%c:",cTypeofOrd);
	logDebug2("sMktWatch:%s:",sMktWatch);
	logDebug2("pReq->Dealer_Id:%s:",pReq->sEntityId);
	logDebug2("pReq->cUserType:%c:",pReq->cUserType);
	logDebug2("pReq->fAlgoOrderNo :%lf:",pReq->fAlgoOrderNo);
	logDebug2("pReq->CoArray[1].fTriggerPrice :%lf:",pReq->CoArray[1].fTriggerPrice);
	logDebug2("pReq->CoArray[0].iLegValue	    :%d:",pReq->CoArray[0].iLegValue);
	logDebug2("iPEnv:%d:",iPEnv);
	logDebug2("cOffMarketFlg :%c:",pReq->cOffMarketFlg);
	
	logDebug2("fLtp = |%f|",fRef_ltp);
        logDebug2("fNrSrptLTP = |%f|",fNrSrptLTP);
        logDebug2("pReq->iStratergyId |%d|",pReq->iStratergyId);

/***
	if(pReq->CoArray[0].iLegValue == LEG_2  && pReq->CoArray[1].fTriggerPrice == 0.00 && pReq->fPrice == 0.00)
	{
		logDebug2("RMSValidation Ignored for Order Exit case ");
		return TRUE;
	}
	This check is done in CNOrdSvr before RMS call

***/
	
	/************************************
                parameter pan is added in
		rms output of client.
 	************************************/
	logTimestamp("Calling Rms_rev_Validate [Start time]");

	if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{

		sprintf(Pr_Query,"CALL  RMS_VALIDATE_CUR(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\")),\
                        \"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,0,'N',\'%c\',%lf,%lf,%d,0.0,\
			@ZSTATUS, @ZINSQTY, @ZINSAMT ,@ZLTP ,@ZACCNT,@ZERRSTR ,\
			@UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI);\
                        SELECT   IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),\
			IFNULL(@ZERRSTR ,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),\
			IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@MPPORDPRI,0.00),IFNULL(@SLMPPORDPRI,0.00),IFNULL(@MPPBLKPRI,0.00),\
			IFNULL(@SLMPPBLKPRI,0.00),IFNULL(@RMS_LOG,'NA') ;",pReq->sClientId,pReq->sSecurityId,pReq->CoArray[0].cBuySellInd ,\
			pReq->iTotalQty,pReq->fPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,\
			cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->CoArray[1].fTriggerPrice,pReq->CoArray[0].iLegValue ,\
			cOfflineFlag,pReq->fAlgoOrderNo,pReq->cOffMarketFlg,fRef_ltp,fNrSrptLTP,pReq->iStratergyId);

	}
	else
	{
		//sprintf(Pr_Query,"CALL  RMS_VALIDATE(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N','','','','',0.00,%lf,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP ,@ZACCNT,@ZERRSTR,@ZPAN,@MKT_TYPE);SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR ,'Not Specified'),IFNULL(@ZPAN,'NA');",pReq->sClientId,pReq->sSecurityId,pReq->CoArray[0].cBuySellInd,pReq->iTotalQty,pReq->fPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->CoArray[1].fTriggerPrice,pReq->CoArray[0].iLegValue,cOfflineFlag,pReq->fAlgoOrderNo,fRef_ltp);

		sprintf(Pr_Query,"CALL  RMS_VALIDATE(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\")),\
				\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N',\'%c\',%lf,%lf,%d,0.00,0.00,\
				@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP ,@ZACCNT,@ZERRSTR,@MKT_TYPE,@UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,\
				@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI);\
				SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),\
				IFNULL(@ZERRSTR ,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),\
				IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@MPPORDPRI,0.00),IFNULL(@SLMPPORDPRI,0.00),IFNULL(@MPPBLKPRI,0.00),\
				IFNULL(@SLMPPBLKPRI,0.00),IFNULL(@RMS_LOG,'NA');",pReq->sClientId,pReq->sSecurityId,pReq->CoArray[0].cBuySellInd,pReq->iTotalQty,\
				pReq->fPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,sMktWatch,\
				pReq->sEntityId,pReq->cUserType,iPEnv,pReq->CoArray[1].fTriggerPrice,pReq->CoArray[0].iLegValue,cOfflineFlag,pReq->fAlgoOrderNo,\
				cOfflineFlag,fRef_ltp,fNrSrptLTP,pReq->iStratergyId);


	}
	
	logTimestamp("Calling Rms_rev_Validate [End time]");
	logDebug2(":%s:",Pr_Query);
	if(mysql_query(DBObj,Pr_Query) != SUCCESS)
	{
		sql_Error(DBObj);
		iError  = mysql_errno(DBObj);
                logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
		
		sprintf(Pr_SelQry, "SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00), IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA') ;");

                if (mysql_query(DBObj,Pr_SelQry) != SUCCESS)
                {
                        sql_Error(DBObj);
                        logFatal("ERROR Received While Calling RMS_VALIDATE ");
                }
                Res = mysql_store_result(DBObj);
                Row = mysql_fetch_row(Res);
                printf("\nRMS_LOG :%s:\n",Row[11]);
                mysql_free_result(Res);
		return ERROR;
	}
	do{
		Res = mysql_store_result(DBObj);
		if(Res)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				printf("\nRMS_LOG :%s:\n",Row[15]);

				logDebug2("Row[0] :%s:",Row[0]);
				logDebug2("Row[1] :%d:",atoi(Row[1]));
				logDebug2("Row[2] :%f:",atof(Row[2]));

				strncpy(sRMSStatus,Row[0],15);
				iQty = atoi(Row[1]);
				fAmount = atof(Row[2]);
				if(strlen(Row[4]) == 0)
                                {
                                        logDebug2("******ACCOUNT ID RETURN FROM RMS**** :%d: ",strlen(Row[4]));
                                        return ERROR;
                                }

				strncpy(sAccCode,Row[4],DB_ACC_CODE_LEN);
				strncpy(sErrorMsg,Row[5],DB_REASON_DESC_LEN);
				strncpy(sPan,Row[9],INT_PAN_LEN);
                                logDebug2("sPan  :%s:",sPan);

				*fMppOrdPrice = atof(Row[11]);
                                *fSlMppOrdPrice = atof(Row[12]);
                                *fMppBlkPrice = atof(Row[13]);
                                *fSlMppBlkPrice = atof(Row[14]);
                                logDebug2("fMppOrdPrice = %f",*fMppOrdPrice);
                                logDebug2("fSlMppOrdPrice = %f",*fSlMppOrdPrice);
                                logDebug2("fMppBlkPrice = %f",*fMppBlkPrice);
                                logDebug2("fSlMppBlkPrice = %f",*fSlMppBlkPrice);

				mysql_free_result(Res);
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);

			}
		}
		else
		{
			logDebug2(" 1st Loop Of Do While :No Result Set ");
		}
		if((iStatus =mysql_next_result(DBObj)) > 0)
		{
			logDebug3("Could not execute statement :%d:",iStatus);
		}

		logDebug2("iStatus :%d:  mysql_next_result(DBObj)  :%d:",iStatus,mysql_next_result(DBObj));

	}while(iStatus == 0);
	/*
	   if(pReq->ReqHeader.iMsgCode == TC_INT_CO_ORDER_MODIFY)
	   {
	   if (pReq->CoArray[0].iLegValue == LEG_1)
	   {
	   pReq->CoArray[0].fTriggerPrice = 0.00;		
	   pReq->iOrderType = ORD_TYPE_LIMIT ;
	   }
	   else
	   {
	   if(pReq->CoArray[1].fTriggerPrice != 0.00)
	   {
	   pReq->fPrice = 0.00;
	   pReq->iOrderType = ORD_TYPE_STOP_LOSS_MKT ;
	   }
	   else
	   {
	   pReq->iOrderType = ORD_TYPE_STOP_LOSS_LIMIT ;			
	   }

	   }

	   }
	 */

	logInfo(" pReq->sClientId :%s:",pReq->sClientId);

	if(strncmp(sRMSStatus,"S",2)== 0)
	{
		logDebug2(" RMS_VALIDATE SUCCESS ");
		logTimestamp("Exit :fCoRMSValidation");
		return TRUE;


	}
	else if(strncmp(sRMSStatus,"F",2)== 0)
	{
		logDebug2("Returned Null value in sRMSStatus");
		logDebug2("##############ERROR IN CALLING RMS########################");
		*fAmnt = fAmount;
		*iQuantity = iQty;
		logInfo("%lf",*fAmnt);
		logInfo("%d",*iQuantity);
		logTimestamp("Exit :fRMSValidation");
		return FALSE;
	}
	else
	{
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		strncpy(sErrorID,sRMSStatus,10);
		*fAmnt = fAmount;
		*iQuantity = iQty;
		//sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
		logDebug2("##############ERROR IN CALLING RMS########################");
		//logInfo("%s",pRes);
		logInfo("%s",sErrorID);
		logInfo("%lf",*fAmnt);
		logInfo("%d",*iQuantity);
		logDebug2("RMSValidation for Cover Order Failed");
		logTimestamp("Exit :fCoRMSValidation");
		return FALSE;

	}
}

BOOL fBoRMSValidation(struct  BO_ORDER_REQUEST *pReq,MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,DOUBLE64 *fLtp,CHAR *sAccCode,CHAR *sErrorMsg,CHAR *sPan,DOUBLE64 fRef_ltp,DOUBLE64 fNrSrptLTP,DOUBLE64 *fMppOrdPrice,DOUBLE64 *fSlMppOrdPrice,DOUBLE64 *fMppBlkPrice, DOUBLE64 *fSlMppBlkPrice)
{
	logTimestamp("Entry :fBoRMSValidation ");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	INT16           iNumRow;
	CHAR    Pr_Query [MAX_QUERY_SIZE];
	INT16           iStatus;
	BOOL            iChkFlg = FALSE;
	LONG32    iCmBranchId;
	CHAR    sMktWatch[3];
	CHAR    sRMSStatus[15];
	memset  (sRMSStatus,'\0',15);
	LONG32          iQty;
	DOUBLE64        fAmount;
//	DOUBLE64        fLtp =0.00;
	DOUBLE64        fProfitTrigger = 0.000;
	memset(sMktWatch,'\0',3);

	CHAR    cTypeofOrd;
	CHAR    cOfflineFlag;
	CHAR    sProcName[PROC_NAME_LEN];
	memset(sProcName,'\0',PROC_NAME_LEN);
	memset(Pr_Query,'\0',MAX_QUERY_SIZE);

	CHAR    Pr_SelQry [MAX_QUERY_SIZE];
        memset(Pr_SelQry, '\0' ,MAX_QUERY_SIZE);

	logDebug2("************************");
	logDebug2("pReq->iMktType = %d",pReq->iMktType);
	logDebug2("fLTP = %lf",fRef_ltp);

	if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		//        sprintf(pRes," mysql_set_server_option FAILS");
		return FALSE;
	}
	iChkFlg  = GetMktType(&sMktWatch,pReq->iMktType);
	if(iChkFlg == FALSE)
	{
		logDebug2("Invalid Mkt Type :%d:",pReq->iMktType);
		return INVALID_MKT_TYPE;

	}
	logDebug2("pReq->ReqHeader.iMsgCode :%d:",pReq->ReqHeader.iMsgCode);

	switch(pReq->ReqHeader.iMsgCode)
	{
		case TC_INT_OFF_ORDER_ENTRY:
		case TC_INT_BO_ORDER_REQ:
			cTypeofOrd = NEW_ORDER;
			break;
		case TC_INT_BO_ORDER_MODIFY:
		case TC_INT_BO_LEG_MODIFY :
		case TC_INT_BO_ORDER_EXIT :
		case TC_INT_OFF_ORDER_MODIFY:

			cTypeofOrd = ORDER_MODIFY;
			break;
		case TC_INT_ORDER_CANCEL:
		case TC_INT_OFF_ORDER_CANCEL:
			cTypeofOrd = ORDER_CANCEL;
			break;
		default :
			logDebug2("Invalid MsgCode");
			//        sprintf(pRes,"Invalid MsgCode");
			return FALSE;
			break;

	}

	if(pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		cOfflineFlag= YES;
	}
	else
	{
		cOfflineFlag= NO;
	}
	logDebug2("cOfflineFlag= %c",cOfflineFlag);
	
	if(pReq->iOrderType != ORD_TYPE_MKT )
	{
		if(pReq->BoArray[0].iLegValue == LEG_1 && pReq->BoArray[0].cBuySellInd == INT_BUY )
		{
        	        fProfitTrigger = (pReq->fPrice + pReq->fPBTikAbsValue);
		}
		else if(pReq->BoArray[0].iLegValue == LEG_1 && pReq->BoArray[0].cBuySellInd == INT_SELL)
		{
        	        fProfitTrigger = (pReq->fPrice - pReq->fPBTikAbsValue);
		}
	}
	else
	{
		fProfitTrigger = pReq->fPBTikAbsValue;
	}

	logDebug2("fProfitTrigger  = %lf",fProfitTrigger);
	logDebug2("sMktWatch :%s: iMktType :%d:",sMktWatch,pReq->iMktType);
	logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->ReqHeader.iMsgCode);
	logDebug2("pReq->ReqHeader.cSegment :%c: ",pReq->ReqHeader.cSegment);
	logDebug2("Enviorment Variable [%d]",iPEnv);
	logDebug2("sClientId:%s:",pReq->sClientId);
	logDebug2("sSecId:%s:",pReq->sSecurityId);
	logDebug2("cBuySellInd:%c:",pReq->BoArray[0].cBuySellInd);
	logDebug2("iTotalQty:%d:",pReq->iTotalQty);
	logDebug2("pReq->fPrice:%lf:",pReq->fPrice);
	logDebug2("pReq->cProductId:%c:",pReq->cProductId);
	logDebug2("pReq->ReqHeader.cSegment:%c:",pReq->ReqHeader.cSegment);
	logDebug2("pReq->ReqHeader.sExcgId:%s:",pReq->ReqHeader.sExcgId);
	logDebug2("pReq->fOrderNum:%lf:",pReq->fOrderNum);
	logDebug2("pReq->iSerialNum:%d:",pReq->iSerialNum);
	logDebug2("cTypeofOrd:%c:",cTypeofOrd);
	logDebug2("sMktWatch:%s:",sMktWatch);
	logDebug2("pReq->Dealer_Id:%s:",pReq->sEntityId);
	logDebug2("pReq->fAlgoOrderNo :%lf:",pReq->fAlgoOrderNo);
	logDebug2("pReq->cUserType:%c:",pReq->cUserType);
	logDebug2("pReq->BoArray[1].fTriggerPrice :%lf:",pReq->BoArray[1].fTriggerPrice);
	logDebug2("pReq->BoArray[0].iLegValue     :%d:",pReq->BoArray[0].iLegValue);
	logDebug2("iPEnv:%d:",iPEnv);
	logDebug2("cOffMarketFlg :%c:",pReq->cOffMarketFlg);

	logDebug2("fLtp = |%f|",fRef_ltp);
        logDebug2("fNrSrptLTP = |%f|",fNrSrptLTP);
        logDebug2("pReq->iStratergyId |%d|:",pReq->iStratergyId);

/***
	if(pReq->BoArray[0].iLegValue == LEG_2 && pReq->BoArray[1].fTriggerPrice == 0.00 && pReq->fPrice == 0.00)
	{
		logDebug2("RMSValidation Ignored for Order Exit case ");
		return TRUE;
	}
	This check is done in CNOrdSvr before RMS Call	
***/


	/************************************
		parameter pan is added in
		rms output of client.
 	************************************/


	if(pReq->BoArray[0].iLegValue != LEG_3)
	{

		if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
		{
			sprintf(Pr_Query,"CALL  RMS_VALIDATE_CUR(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),\
				ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,%lf,'N',\'%c\',%lf,%lf,%d,0.00,@ZSTATUS, @ZINSQTY,\
				@ZINSAMT,@ZLTP ,@ZACCNT,@ZERRSTR,@UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI);\
                                SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00) ,IFNULL(@ZACCNT,\"\"),\
				IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),\
				IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@MPPORDPRI,0.00),IFNULL(@SLMPPORDPRI,0.00),IFNULL(@MPPBLKPRI,0.00),\
				IFNULL(@SLMPPBLKPRI,0.00),IFNULL(@RMS_LOG,'NA') ;",pReq->sClientId,pReq->sSecurityId,pReq->BoArray[0].cBuySellInd ,pReq->iTotalQty,pReq->fPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,fabs(pReq->BoArray[1].fTriggerPrice),pReq->BoArray[0].iLegValue ,cOfflineFlag,pReq->fAlgoOrderNo,fabs(fProfitTrigger),pReq->cOffMarketFlg,fRef_ltp,fNrSrptLTP,pReq->iStratergyId);

	
		}
		else
		{

			 sprintf(Pr_Query,"CALL  RMS_VALIDATE(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),\
				ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N',\'%c\',%lf,%lf,%d,%lf,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT,\
				@ZLTP,@ZACCNT,@ZERRSTR,@MKT_TYPE,@UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI );\
                                SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00) ,IFNULL(@ZACCNT,\"\"),\
				IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),\
				IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@MPPORDPRI,0.00),IFNULL(@SLMPPORDPRI,0.00),IFNULL(@MPPBLKPRI,0.00),\
				IFNULL(@SLMPPBLKPRI,0.00),IFNULL(@RMS_LOG,'NA');",pReq->sClientId,pReq->sSecurityId,pReq->BoArray[0].cBuySellInd,\
				pReq->iTotalQty,pReq->fPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,\
				sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,fabs(pReq->BoArray[1].fTriggerPrice),pReq->BoArray[0].iLegValue,cOfflineFlag,\
				pReq->fAlgoOrderNo,pReq->cOffMarketFlg,fRef_ltp,fNrSrptLTP,pReq->iStratergyId,fabs(fProfitTrigger));			


		}
	
		
		logDebug2(":%s:",Pr_Query);
		if(mysql_query(DBObj,Pr_Query) != SUCCESS)
		{
			sql_Error(DBObj);
			logFatal("Error IN CALLING RMS_VALIDATE .");
	
			sprintf(Pr_SelQry, "SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00), IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA') ;");

                	if (mysql_query(DBObj,Pr_SelQry) != SUCCESS)
                	{
                        	sql_Error(DBObj);
                        	logFatal("ERROR Received While Calling RMS_VALIDATE ");
                	}
                	Res = mysql_store_result(DBObj);
                	Row = mysql_fetch_row(Res);
                	printf("\nRMS_LOG :%s:\n",Row[11]);
                	mysql_free_result(Res);
			return ERROR;
		}
		do{
			Res = mysql_store_result(DBObj);
			if(Res)
			{

				if((Row = mysql_fetch_row(Res)))
				{
/**
					if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
					{
						logDebug2("Row[0] :%s:",Row[0]);
						logDebug2("Row[1] :%d:",atoi(Row[1]));
						logDebug2("Row[2] :%f:",atof(Row[2]));

						strncpy(sRMSStatus,Row[0],15);
						iQty = atoi(Row[1]);
						fAmount = atof(Row[2]);

					}
					else
					{
***/
						printf("\nRMS_LOG :%s:\n",Row[15]);
						logDebug2("Row[0] :%s:",Row[0]);
                                                logDebug2("Row[1] :%d:",atoi(Row[1]));
                                                logDebug2("Row[2] :%f:",atof(Row[2]));
                                                logDebug2("Row[3] :%f:",atof(Row[3]));

                                                strncpy(sRMSStatus,Row[0],15);
                                                iQty = atoi(Row[1]);
                                                fAmount = atof(Row[2]);
                                                *fLtp = atof(Row[3]);
						if(strlen(Row[4]) == 0)
		                                {
                		                        logDebug2("******ACCOUNT ID RETURN FROM RMS**** :%d: ",strlen(Row[4]));
                                		        return ERROR;
		                                }

						strncpy(sAccCode,Row[4],DB_ACC_CODE_LEN);
						strncpy(sErrorMsg,Row[5],DB_REASON_DESC_LEN);
						strncpy(sPan,Row[9],INT_PAN_LEN);
                                                logDebug2("fLTP price :%f:",fLtp);
                                                logDebug2("sAccCode  :%s:",sAccCode);
                                                logDebug2("sPan  :%s:",sPan);
//					}
				//	mysql_free_result(Res);
					logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf: sAccCode :%s:" ,sRMSStatus,iQty,fAmount,sAccCode);

					*fMppOrdPrice = atof(Row[11]);
                                        *fSlMppOrdPrice = atof(Row[12]);
                                        *fMppBlkPrice = atof(Row[13]);
                                        *fSlMppBlkPrice = atof(Row[14]);
                                        logDebug2("fMppOrdPrice = %f",*fMppOrdPrice);
                                        logDebug2("fSlMppOrdPrice = %f",*fSlMppOrdPrice);
                                        logDebug2("fMppBlkPrice = %f",*fMppBlkPrice);
                                        logDebug2("fSlMppBlkPrice = %f",*fSlMppBlkPrice);

				}
				mysql_free_result(Res);
			}
			else
			{
				logDebug2(" 1st Loop Of Do While :No Result Set ");
			}
			if((iStatus =mysql_next_result(DBObj)) > 0)
			{
				logDebug3("Could not execute statement :%d:",iStatus);
			}

			logDebug2("iStatus :%d:  mysql_next_result(DBObj)  :%d:",iStatus,mysql_next_result(DBObj));

		}while(iStatus == 0);
		if(pReq->ReqHeader.iMsgCode == TC_INT_CO_ORDER_MODIFY)/*Please refer fChckOrderStatus function in case of TC_INT_CO_ORDER_MODIFY */
		{
			if (pReq->BoArray[0].iLegValue == LEG_1)
			{
				pReq->BoArray[0].fTriggerPrice = 0.00;
				pReq->iOrderType = ORD_TYPE_LIMIT ;
			}
			else
			{
				pReq->fPrice = 0.00;
				pReq->iOrderType = ORD_TYPE_STOP_LOSS_MKT ;

			}

		}

		if((pReq->ReqHeader.iMsgCode == TC_INT_BO_ORDER_REQ || pReq->ReqHeader.iMsgCode == TC_INT_BO_ORDER_MODIFY ) && (pReq->iOrderType == ORD_TYPE_STOP_LOSS_MKT || pReq->iOrderType == ORD_TYPE_MKT))
		{
			logDebug2("IN");
                        pReq->fPrice = *fLtp;
			logDebug2("FTP");
			logDebug2("pReq->fPrice :%f:",pReq->fPrice);
		}

		logInfo(" pReq->sClientId :%s:",pReq->sClientId);

		if(strncmp(sRMSStatus,"S",2)== 0)
		{
			logDebug2(" RMS_VALIDATE SUCCESS ");
			logTimestamp("Exit :fBoRMSValidation");
			return TRUE;

		}
		else if(strncmp(sRMSStatus,"F",2)== 0)
		{
			logDebug2("Returned Null value in sRMSStatus");
			logDebug2("##############ERROR IN CALLING RMS########################");
			*fAmnt = fAmount;
			*iQuantity = iQty;
			logInfo("%lf",*fAmnt);
			logInfo("%d",*iQuantity);
			logTimestamp("Exit :fBoRMSValidation");
			return FALSE;
		}
		else
		{
			/*
			   logDebug2(" RMS_VALIDATE FAIL ");
			   logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
			//	                sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
			//	                logInfo("%s",pRes);
			logTimestamp("Exit :fBoRMSValidation");
			return FALSE;
			 */

			logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
			strncpy(sErrorID,sRMSStatus,10);
			*fAmnt = fAmount;
			*iQuantity = iQty;
			//sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
			logDebug2("##############ERROR IN CALLING RMS########################");
			//logInfo("%s",pRes);
			logInfo("%s",sErrorID);
			logInfo("%lf",*fAmnt);
			logInfo("%d",*iQuantity);
			logDebug2("RMSValidation for Cover Order Failed");
			logTimestamp("Exit :fBoRMSValidation");
			return FALSE;
		}
	}
	else
	{
		logDebug2("No RMS Call for LEG 3 Order");
		return TRUE;
	}

}



BOOL 	CncRevValidate(struct  ORDER_RESPONSE *pReq,MYSQL *DBconRMS,LONG32 iPEnv)
{
	logTimestamp("ENTRY :CncRevValidate");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	INT16           iNumRow;
	CHAR *Pr_Query = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	INT16           iStatus;
	CHAR            cOrdStatus;
	LONG32		iQuantity;

	CHAR    sMktWatch[3];
	CHAR    sRMSStatus[15];
	memset  (sRMSStatus,'\0',15);
	LONG32          iQty = 0;
	DOUBLE64        fAmount = 0.00;
	DOUBLE64        fPrice = 0.00;
	memset(sMktWatch,'\0',3);

	CHAR    Pr_SelQry [MAX_QUERY_SIZE];
        memset(Pr_SelQry, '\0' ,MAX_QUERY_SIZE);

	//,pReq->iMktTypeGetMktType(&sMktWatch,pReq->iMktType);
	GetMktType(&sMktWatch,pReq->iMktType);
	CHAR    cTypeofOrd;
	CHAR	cOfflineFlag;
	//if(mysql_set_server_option(DBconRMS ,MYSQL_OPTION_MULTI_STATEMENTS_ON) == 0)
	if(mysql_set_server_option(DBconRMS,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILS");
	}

	switch(pReq->IntRespHeader.iMsgCode)
	{
		case TC_INT_OE_ERROR_RESP:
			cTypeofOrd = 'N';
			cOrdStatus = 'R';
			iQuantity  = pReq->iTotalQty;
			fPrice	   = pReq->fPrice;	
			break;
		case TC_INT_OM_ERROR_RESP:
			cTypeofOrd = 'M';
			cOrdStatus = 'R';
			fPrice	   = pReq->fPrice;	
			iQuantity  = pReq->iTotalQty;
			break;
		case TC_INT_OC_CONF_RESP:
		case TC_INT_OFF_ORDER_CANCEL_RSP:
			cTypeofOrd = 'C';
			cOrdStatus = 'T';
			iQuantity  = pReq->iTotalQtyRem;
			fPrice	   = pReq->fPrice;	
			break;
		case TC_INT_TRADE_RESP:
			cTypeofOrd = 'N';
			cOrdStatus = 'T';
			iQuantity  = pReq->iLastTradedQty;
			fPrice	   = pReq->fTradePrice	;	
			break;
		case TC_INT_MKT_LMT_CONVT_RESP:
			cTypeofOrd = 'M';
			cOrdStatus = 'L';
			iQuantity  = pReq->iTotalQty;
			fPrice	   = pReq->fPrice;	
			break;
		case TC_INT_ADMIN_EXPIRY_RESP:
			cTypeofOrd = 'N';
			cOrdStatus = 'R';
			iQuantity  = pReq->iTotalQty;
			fPrice     = pReq->fPrice;
			break;

		default :
			logDebug2("Invalid MsgCode");
			break;

	}

	if(pReq->IntRespHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL_RSP)
	{
		cOfflineFlag= YES;
	}	
	else
	{
		cOfflineFlag= NO;
	}

	logDebug2("cOfflineFlag= %c",cOfflineFlag);

	logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->IntRespHeader.iMsgCode);

	//        sprintf(Pr_Query,"CALL  RMS_VALIDATE(ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'%c\',now(),ltrim(rtrim(\"%s\")),\"%s\",\
	//			 \'%c\',%lf,%d,@ZSTATUS, @ZINSQTY, @ZINSAMT );\  
	//			 SELECT  @ZSTATUS, @ZINSQTY, @ZINSAMT ;",pReq->sClientId,pReq->sSecurityId,pReq->cBuyOrSell,iQuantity,fPrice,pReq->cProductId,
	//				pReq->IntRespHeader.cSegment,pReq->IntRespHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,cOrdStatus,sMktWatch,
	//				pReq->sEntityId,pReq->cUserType,pReq->fTriggerPrice,iPEnv);

	logDebug2("pReq->fTriggerPrice = :%f:",pReq->fTriggerPrice);
	logDebug2("iPEnv = :%d:",iPEnv);


	/************************************
 		parameter pan is added in
		rms output of client.
	************************************/

	logTimestamp("Calling RMS_VALIDATE [Start  time]");
	//sprintf(Pr_Query,"CALL  RMS_VALIDATE(ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'%c\',now(),ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N','','','','',0.00,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP,@ZACCNT,@ZERRSTR,@ZPAN,@MKT_TYPE);SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@ZPAN,'NA') ;",pReq->sClientId,pReq->sSecurityId,pReq->cBuyOrSell,iQuantity,fPrice,pReq->cProductId,pReq->IntRespHeader.cSegment,pReq->IntRespHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,cOrdStatus,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->iLegValue,cOfflineFlag,pReq->fAlgoOrderNo);

	 sprintf(Pr_Query,"CALL  RMS_VALIDATE(ltrim(rtrim(\"%s\")),\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'%c\',now(),ltrim(rtrim(\"%s\")),\
        \"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N','','','','',0.00,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP,@ZACCNT,@ZERRSTR,@MKT_TYPE,@UNDERLYING_PRICE,\
        @RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR);SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),\
        IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA') ;",pReq->sClientId,pReq->sSecurityId,pReq->cBuyOrSell,iQuantity,fPrice,pReq->cProductId,\
        pReq->IntRespHeader.cSegment,pReq->IntRespHeader.sExcgId,pReq->fOrderNum,pReq->iSerialNum,cTypeofOrd,cOrdStatus,sMktWatch,pReq->sEntityId,\
        pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->iLegValue,cOfflineFlag,pReq->fAlgoOrderNo);	
	

	logDebug2(":%s:",Pr_Query);

	if(mysql_query(DBconRMS,Pr_Query) != SUCCESS)
	{
		sql_Error(DBconRMS);
		logFatal("Error IN CALLING RMS_VALIDATE .");
		sprintf(Pr_SelQry, "SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00), IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA') ;");

                if (mysql_query(DBconRMS,Pr_SelQry) != SUCCESS)
                {
			sql_Error(DBconRMS);
                        logFatal("ERROR Received While Calling RMS_VALIDATE ");
                }
                Res = mysql_store_result(DBconRMS);
                Row = mysql_fetch_row(Res);
                printf("\nRMS_LOG :%s:\n",Row[11]);
                mysql_free_result(Res);
	}

	//iNumRow = mysql_num_rows(Res);
	//logInfo("iNumRow :%d:",iNumRow);
	logTimestamp("Calling RMS_VALIDATE [End  time]");

	do{

		Res = mysql_store_result(DBconRMS);

		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				printf("\nRMS_LOG :%s:\n",Row[11]);
				strncpy(sRMSStatus,Row[0],15);
				iQty = atoi(Row[1]);
				fAmount = atof(Row[2]);
				mysql_free_result(Res);
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
			}
		}
		else
		{
			logDebug2("No Result Set ");
		}

		if((iStatus =mysql_next_result(DBconRMS)) > 0)
		{
			logDebug3("Could not execute statement");
		}
	}while(iStatus == 0);

	logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
	logInfo(" pReq->sClientId :%s:",pReq->sClientId);

	if(strncmp(sRMSStatus,"S",1) == 0)
	{
		logDebug2(" RMS_VALIDATE SUCCESS ");
		return TRUE;

	}	
	else if(strncmp(sRMSStatus,"F",2)== 0)
	{
		logDebug2("Returned Null value in sRMSStatus");
		logDebug2("##############ERROR IN CALLING RMS########################");
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		logTimestamp("Exit :fRMSValidation");
		return FALSE;
	}
	else if(strncmp(sRMSStatus,"E",1) == 0)
	{
		logDebug2("Return Nothing in RMS_VALIDATE");
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		//sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
		//logInfo("%s",pRes);
		return FALSE;
	}


}

BOOL fRMSValidateSprd(struct  INT_SPREAD_ORDERS *pReq, MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,CHAR *sErrorMsg, CHAR *sPan)
{
	logTimestamp("Entry :fRMSValidateSprd");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	INT16           iNumRow;
	CHAR    Pr_Query [MAX_QUERY_SIZE];
	INT16           iStatus;
	BOOL            iChkFlg = FALSE;
	LONG32    iCmBranchId;

	struct timeval tv,cv;
	double iStartTime,iEndTime;

	//gettimeofday(&tv, NULL);

	CHAR    sMktWatch[3];
	CHAR    sRMSStatus[15];
	memset  (sRMSStatus,'\0',15);
	LONG32          iQty;
	DOUBLE64        fAmount;
	DOUBLE64        fstart ;
	DOUBLE64        fEnd;
	memset(sMktWatch,'\0',3);
	LONG32 iStart = 0;
	LONG32  iEnd = 0;

	CHAR    cTypeofOrd;
	CHAR    cOfflineFlag;
	CHAR    sProcName[PROC_NAME_LEN];
	memset(sProcName,'\0',PROC_NAME_LEN);
	memset(Pr_Query,'\0',MAX_QUERY_SIZE);

	logDebug2("************************");
	logDebug2("pReq->iMktType = %d",pReq->iMktType);

	//if(mysql_set_server_option(DBConNEQ,MYSQL_OPTION_MULTI_STATEMENTS_ON) == 0)
	if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		return ERROR;
	}
	iChkFlg  = GetMktType(&sMktWatch,pReq->iMktType);

	if(iChkFlg == FALSE)
	{
		logDebug2("Invalid Mkt Type :%d:",pReq->iMktType);
		return ERROR;
	}

	switch(pReq->ReqHeader.iMsgCode)
	{
		case TC_INT_SPREAD_OE_REQ:
		case TC_INT_OFF_ORDER_ENTRY:
			cTypeofOrd = NEW_ORDER;
			break;
		case TC_INT_SPREAD_OM_REQ:
		case TC_INT_OFF_ORDER_MODIFY:
			cTypeofOrd = ORDER_MODIFY;
			break;
		case TC_INT_SPREAD_OC_REQ:
		case TC_INT_OFF_ORDER_CANCEL:
			cTypeofOrd = ORDER_CANCEL;
			break;
		default :
			logDebug2("Invalid MsgCode");
			return ERROR;
			break;

	} 
	
	if(pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		cOfflineFlag= YES;
	}
	else
	{
		cOfflineFlag= NO;
	}
	  
	
	cOfflineFlag= NO;
	logDebug2("cOfflineFlag= %c",cOfflineFlag);

	logDebug2("sMktWatch :%s: iMktType :%d:",sMktWatch,pReq->iMktType);
	logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->ReqHeader.iMsgCode);
	logDebug2("pReq->ReqHeader.cSegment :%c: ",pReq->ReqHeader.cSegment);

	
	if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		strncpy(sProcName,RMS_CURR,PROC_NAME_LEN);
	}
	else
	{
		strncpy(sProcName,RMS_EQ_FO,PROC_NAME_LEN);
	}
	
	logDebug2("Enviorment Variable [%d]",iPEnv);
	logDebug2("sClientId:%s:",pReq->sClientId);
	logDebug2("sSecId:%s:",pReq->SpreadArray[0].sSecId);
	logDebug2("cBuySellInd:%c:",pReq->SpreadArray[0].cBuySellInd);
	logDebug2("iTotalQty:%d:",pReq->SpreadArray[0].iTotalQty);
	logDebug2("pReq->fOrderPrice:%lf:",pReq->fOrderPrice);
	logDebug2("pReq->cProductId:%c:",pReq->cProductId);
	logDebug2("pReq->ReqHeader.cSegment:%c:",pReq->ReqHeader.cSegment);
	logDebug2("pReq->ReqHeader.sExcgId:%s:",pReq->ReqHeader.sExcgId);
	logDebug2("pReq->fOrdNo:%lf:",pReq->fOrdNo);
	logDebug2("pReq->iSerialNo:%d:",pReq->iSerialNo);
	logDebug2("cTypeofOrd:%c:",cTypeofOrd);
	logDebug2("sMktWatch:%s:",sMktWatch);
	logDebug2("pReq->Dealer_Id:%s:",pReq->sEntityId);
	logDebug2("pReq->cUserType:%c:",pReq->cUserType);
	logDebug2("pReq->fTriggerPrice:%lf:",pReq->fTriggerPrice);
	logDebug2("pReq->fAlgoOrderNo 	:%lf:",pReq->fAlgoOrderNo);
	logDebug2("iPEnv:%d:",iPEnv);


	/************************************
		parameter pan is added in
		rms output of client.
        ************************************/
	//RMS Validation for Curency and other segment
	if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		sprintf(Pr_Query,"CALL  RMS_VALIDATE_CUR(\"%s\",\"%s-%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\"))\
		,\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'0.00','Y','Y','0.00','0.00',0.00,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP,@ZACCNT,@ZERRSTR,\
		@UNDERLYING_PRICE,@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI);\
		SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA');",pReq->sClientId,pReq->SpreadArray[0].sSecId,pReq->SpreadArray[1].sSecId,pReq->SpreadArray[0].cBuySellInd,\
		pReq->SpreadArray[0].iTotalQty,pReq->fOrderPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrdNo,\
		pReq->iSerialNo,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->SpreadArray[0].iLegNo,cOfflineFlag,pReq->fAlgoOrderNo);
	}
	else
	{
		sprintf(Pr_Query,"CALL  RMS_VALIDATE(\"%s\",\"%s-%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\"))\
                ,\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'Y','','0.00','0.00','0.00',0.00,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP ,@ZACCNT,@ZERRSTR,@MKT_TYPE,@UNDERLYING_PRICE,\
		@RMS_BLOCKED_AMT,@PAN_NUMBER,@SETTLOR,@MPPORDPRI,@SLMPPORDPRI,@MPPBLKPRI,@SLMPPBLKPRI);\
                SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),\
		IFNULL(@MKT_TYPE,'NL'),IFNULL(@UNDERLYING_PRICE,0.00),IFNULL(@RMS_BLOCKED_AMT,0.00),IFNULL(@PAN_NUMBER,'NA'),IFNULL(@SETTLOR,'NA'),IFNULL(@RMS_LOG,'NA');",pReq->sClientId,pReq->SpreadArray[0].sSecId,pReq->SpreadArray[1].sSecId,pReq->SpreadArray[0].cBuySellInd,\
                pReq->SpreadArray[0].iTotalQty,pReq->fOrderPrice,pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrdNo,\
                pReq->iSerialNo,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->SpreadArray[0].iLegNo,cOfflineFlag,pReq->fAlgoOrderNo);

	}
	logDebug2(":%s:",Pr_Query);

	if(mysql_query(DBObj,Pr_Query) != SUCCESS)
	{
		sql_Error(DBObj);
		logFatal("Error IN CALLING RMS_VALIDATE .");
		return ERROR;
	}

	do{

		Res = mysql_store_result(DBObj);
		if(Res)
		{
			logDebug2("hii");
			if((Row = mysql_fetch_row(Res)))
			{
				printf("\nRMS_LOG :%s:\n",Row[11]);
				strncpy(sRMSStatus,Row[0],15);
				logDebug2("hii");
				iQty = atoi(Row[1]);
				fAmount = atof(Row[2]);
				if(strlen(Row[4]) == 0)
	                        {
          	                      logDebug2("******ACCOUNT ID RETURN FROM RMS**** :%d: ",strlen(Row[4]));
                                      return ERROR;
                                }
				strncpy(pReq->sAccCode,Row[4],DB_ACC_CODE_LEN);
				//strncpy(sErrorMsg,Row[5],DB_REASON_DESC_LEN);
				//strncpy(sPan,Row[9],INT_PAN_LEN);
				strncpy(sErrorMsg,Row[5],DB_REASON_DESC_LEN);
				
				if( TC_INT_SPREAD_OE_REQ == pReq->ReqHeader.iMsgCode)
                                {
                                        if(strcmp(Row[10],"000000000000") != 0 && strcmp(Row[10],"NA") != 0  )
                                        {
                                                logInfo("Settlor :%s: assign to Client :%s: ",Row[10],pReq->sClientId);
                                                strncpy(pReq->sSettlor,Row[10],SETTLOR_LEN);
                                        }
                                }
				strncpy(sPan,Row[9],INT_PAN_LEN);
	
				pReq->fUnderlyPrice = atof(Row[7]);
                                pReq->fRmsBlockAmt = atof(Row[8]);
				mysql_free_result(Res);
				logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf: sAccCode:%s: sErrorMsg:%s: sPan:%s:",sRMSStatus,iQty,fAmount,pReq->sAccCode,sErrorMsg,sPan);

			}
		}
		else
		{
			logDebug2("No Result Set ");
		}

		if((iStatus =mysql_next_result(DBObj)) > 0)
		{
			logDebug3("Could not execute statement :%d:",iStatus);
		}

		logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBObj));

	}while(iStatus == 0);

	logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
	logInfo(" pReq->sClientId :%s:",pReq->sClientId);

	if(strncmp(sRMSStatus,"S",2)== 0)
	{
		logDebug2(" RMS_VALIDATE SUCCESS ");
		logTimestamp("Exit :fRMSValidateSprd");
		return TRUE;

	}
	else if(strncmp(sRMSStatus,"F",2)== 0)
	{
		logDebug2("Returned Null value in sRMSStatus");
		logDebug2("##############ERROR IN CALLING RMS########################");
		*fAmnt = fAmount;
		*iQuantity = iQty;
		logInfo("%lf",*fAmnt);
		logInfo("%d",*iQuantity);
		logTimestamp("Exit :fRMSValidation");
		return FALSE;
	}

	else
	{
		logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
		strncpy(sErrorID,sRMSStatus,10);
		*fAmnt = fAmount;
		*iQuantity = iQty;
		logDebug2("ERROR IN CALLING RMS");
		logInfo("%s",sErrorID);
		logInfo("%lf",*fAmnt);
		logInfo("%d",*iQuantity);
		logTimestamp("Exit :fRMSValidateSprd");
		return FALSE;

	}
}

/* BOOL fSIPValidation(struct SIP_INT_ORDERS *pReq, MYSQL *DBObj,CHAR *sErrorID)
   {
   logTimestamp("Entry : fSIPValidation");

   MYSQL_RES       *Res;
   MYSQL_ROW       Row;

   CHAR	Query[MAX_QUERY_SIZE];
   LONG32	iError;
   LONG32  iQty;
   INT16   iStatus;
   DOUBLE64 fAmount;	

   CHAR    sRMSStatus[2];
   memset(sRMSStatus,'\0',2);

   if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
   {
   logDebug2(" mysql_set_server_option SUCCESS");   
   }
   else
   {
   logDebug2(" mysql_set_server_option FAILed");
   return FALSE;
   }

   sprintf(Query,"	CALL  SIP_VALIDATE (\"%s\",\"%s\",\'%c\',\'%c\',\'%c\',\"%s\",@ZSTATUS, @ZINSQTY, @ZINSAMT); \
   SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00);",pReq->sClientId,pReq->sSecId,pReq->cBuySellInd,\
   pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId);

   logDebug2("Query = %s",Query);

   if(mysql_query(DBObj,Query) != SUCCESS)
   {
   sql_Error(DBObj);
   iError  = mysql_errno(DBObj);
   logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
   return ERROR;
   }	

   do{

   Res = mysql_store_result(DBObj);
   if(Res)
   {
   if((Row = mysql_fetch_row(Res)))
   {
   strncpy(sRMSStatus,Row[0],15);
   iQty = atoi(Row[1]);
   fAmount = atof(Row[2]);
   mysql_free_result(Res);
   logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);

   }
   }
   else
   {
   logDebug2("No Result Set ");
   }

   if((iStatus = mysql_next_result(DBObj)) > 0)
   {
   logDebug3("Could not execute statement :%d:",iStatus);
   }

   logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBObj));

   }while(iStatus == 0);

   if(strncmp(sRMSStatus,"S",2)== 0)
   {
logDebug2(" RMS_VALIDATE SUCCESS ");
logTimestamp("Exit :fRMSValidation");
return TRUE;

}
else if(strncmp(sRMSStatus,"F",2)== 0)
{
	logDebug2(" RMS_VALIDATE FAIL ");
	logTimestamp("Exit :fRMSValidation");
	return FALSE;
}	
else
{
	strncpy(sErrorID,sRMSStatus,10);
	logInfo("%s",sErrorID);
	logTimestamp("Exit :fRMSValidation");
	return FALSE;
}

logTimestamp("Exit : fSIPValidation");	

} */	


BOOL fRMSCommMLValidation(struct  INT_SPREAD_ORDERS *pReq, MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,LONG32 i,CHAR *sErrorMsg,CHAR *sPan)
{
        logTimestamp("Entry :fRMSCommValidation");
                MYSQL_RES       *Res;
                MYSQL_ROW       Row;
                INT16           iNumRow;
                CHAR    Pr_Query [MAX_QUERY_SIZE];
                INT16           iStatus;
                BOOL            iChkFlg = FALSE;
                LONG32    iCmBranchId;

                struct timeval tv,cv;
                double iStartTime,iEndTime;

                //gettimeofday(&tv, NULL);

                CHAR    sMktWatch[3];
                CHAR    sRMSStatus[15];
                memset  (sRMSStatus,'\0',15);
                LONG32          iQty;
                LONG32          iError;
                DOUBLE64        fAmount;
                DOUBLE64        fstart ;
                DOUBLE64        fEnd;
                memset(sMktWatch,'\0',3);
                LONG32 iStart = 0;
                LONG32  iEnd = 0;

                CHAR    cTypeofOrd;
                CHAR    cOfflineFlag ;
                CHAR    sProcName[PROC_NAME_LEN];
                memset(sProcName,'\0',PROC_NAME_LEN);
                memset(Pr_Query,'\0',MAX_QUERY_SIZE);

                logDebug2("************************");
                logDebug2("pReq->iMktType = %d",pReq->iMktType);

                //if(mysql_set_server_option(DBConNEQ,MYSQL_OPTION_MULTI_STATEMENTS_ON) == 0)
                logDebug2("Connected to my SQl Server.....");
                if(mysql_set_server_option(DBObj,CLIENT_MULTI_STATEMENTS) == 0)
                {
                        logDebug2(" mysql_set_server_option SUCCESS");
                }
 		else
                {
                        logDebug2(" mysql_set_server_option FAILed");
                                return FALSE;
                }
                iChkFlg  = GetMktType(&sMktWatch,pReq->iMktType);

                if(iChkFlg == FALSE)
                {
                        logDebug2("Invalid Mkt Type :%d:",pReq->iMktType);
                                return INVALID_MKT_TYPE;
                }

                switch(pReq->ReqHeader.iMsgCode)
                {
                        case TC_INT_ORDER_ENTRY_REQ:
                        case TC_INT_2L_OE_REQ:
                        case TC_INT_3L_OE_REQ:
                        case TC_INT_OFF_ORDER_ENTRY:
                                                    cTypeofOrd = NEW_ORDER;
                                                            break;
                        case TC_INT_ORDER_MODIFY:
                        case TC_INT_OFF_ORDER_MODIFY:
                                                     cTypeofOrd = ORDER_MODIFY;
                                                             break;
                        case TC_INT_ORDER_CANCEL:
                        case TC_INT_OFF_ORDER_CANCEL:
                                                     cTypeofOrd = ORDER_CANCEL;
                                                             break;
                        default :
                                 logDebug2("Invalid MsgCode");
                                         return FALSE;
                                         break;

                }

                if(pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY || pReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
                {
                        cOfflineFlag = YES;
                }
                else
                {
		cOfflineFlag = NO;
                }
                logDebug2("cOfflineFlag = %c",cOfflineFlag );

                logDebug2("sMktWatch :%s: iMktType :%d:",sMktWatch,pReq->iMktType);
                logDebug2("cTypeofOrd :%c: iMsgCode :%d:",cTypeofOrd,pReq->ReqHeader.iMsgCode);
                logDebug2("pReq->ReqHeader.cSegment :%c: ",pReq->ReqHeader.cSegment);


                if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
                {
                        strncpy(sProcName,RMS_CURR,PROC_NAME_LEN);
                }
                else
                {
                        strncpy(sProcName,RMS_EQ_FO,PROC_NAME_LEN);
                }

                logDebug2("sProcName :%s:",sProcName);
                logDebug2("Enviorment Variable [%d]",iPEnv);
                logDebug2("sClientId:%s:",pReq->sClientId);
                logDebug2("sSecId:%s:",pReq->SpreadArray[i].sSecId);
                logDebug2("cBuySellInd:%c:",pReq->SpreadArray[i].cBuySellInd);
                logDebug2("iTotalQty:%d:",pReq->SpreadArray[i].iTotalQty);
                logDebug2("pReq->fOrderPrice:%lf:",pReq->fOrderPrice);
                logDebug2("pReq->cProductId:%c:",pReq->cProductId);
                logDebug2("pReq->ReqHeader.sExcgId:%s:",pReq->ReqHeader.sExcgId);
                logDebug2("pReq->fOrdNo:%lf:",pReq->fOrdNo);
                logDebug2("pReq->iSerialNo:%d:",pReq->iSerialNo);
                logDebug2("cTypeofOrd:%c:",cTypeofOrd);
                logDebug2("sMktWatch:%s:",sMktWatch);
                logDebug2("pReq->Dealer_Id:%s:",pReq->sEntityId);
                logDebug2("pReq->cUserType:%c:",pReq->cUserType);
                logDebug2("pReq->fTriggerPrice:%lf:",pReq->fTriggerPrice);
                logDebug2("pReq->fAlgoOrderNo :%lf:",pReq->fAlgoOrderNo);
                logDebug2("iPEnv:%d:",iPEnv);
                logDebug2("pReq->ReqHeader.cSegment:%c:",pReq->ReqHeader.cSegment);


		/************************************
			parameter pan is added in
			rms output of client.
		************************************/
		
		if(pReq->ReqHeader.cSegment == CURRENCY_SEGMENT)
	        {
        	        sprintf(Pr_Query,"CALL  RMS_VALIDATE_CUR(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\"))\
                        ,\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,0,@ZSTATUS, @ZINSQTY, @ZINSAMT ,@ZLTP,@ZACCNT,@ZERRSTR,@ZPAN);\
                        SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00),IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@ZPAN,'NA') ;",pReq->sClientId,pReq->SpreadArray[i].sSecId,pReq->SpreadArray[i].cBuySellInd,pReq->SpreadArray[i].iTotalQty,pReq->fOrderPrice,
                                pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrdNo,pReq->iSerialNo,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->SpreadArray[i].iLegNo,cOfflineFlag,pReq->fAlgoOrderNo);
		}
	        else
	        {

        	        sprintf(Pr_Query,"CALL  RMS_VALIDATE(\"%s\",\"%s\",\'%c\',%d,%lf,\'%c\',\'%c\',\"%s\",%lf,%d,\'%c\',\'P\',now(),ltrim(rtrim(\"%s\"))\
                        ,\"%s\",\'%c\',%d,%lf,%d,\'%c\',%lf,'N','','','','',0.00,0.00,@ZSTATUS, @ZINSQTY, @ZINSAMT,@ZLTP ,@ZACCNT,@ZERRSTR,@ZPAN,@MKT_TYPE);\
                        SELECT  IFNULL(@ZSTATUS,'F'), IFNULL(@ZINSQTY,0), IFNULL(@ZINSAMT,0.00), IFNULL(@ZLTP,0.00),IFNULL(@ZACCNT,\"\"),IFNULL(@ZERRSTR,'Not Specified'),IFNULL(@ZPAN,'NA') ;",pReq->sClientId,pReq->SpreadArray[i].sSecId,pReq->SpreadArray[i].cBuySellInd,pReq->SpreadArray[i].iTotalQty,pReq->fOrderPrice,
                                pReq->cProductId,pReq->ReqHeader.cSegment,pReq->ReqHeader.sExcgId,pReq->fOrdNo,pReq->iSerialNo,cTypeofOrd,sMktWatch,pReq->sEntityId,pReq->cUserType,iPEnv,pReq->fTriggerPrice,pReq->SpreadArray[i].iLegNo,cOfflineFlag,pReq->fAlgoOrderNo);
		}
                logDebug2(":%s:",Pr_Query);
                if(mysql_query(DBObj,Pr_Query) != SUCCESS)
                {
                        sql_Error(DBObj);
                                iError  = mysql_errno(DBObj);
                                logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
                                return ERROR;
                }
                do{

                        Res = mysql_store_result(DBObj);
                        if(Res)
                        {
                                if((Row = mysql_fetch_row(Res)))
                                {
                                        strncpy(sRMSStatus,Row[0],15);
                                                iQty = atoi(Row[1]);
                                                fAmount = atof(Row[2]);
                                                if(strlen(Row[4]) == 0)
                                                {
                                                      logDebug2("******ACCOUNT ID RETURN FROM RMS**** :%d: ",strlen(Row[4]));
                                                      return ERROR;
                                                }
                                                strncpy(pReq->sAccCode,Row[4],DB_ACC_CODE_LEN);
                                                strncpy(sErrorMsg,Row[5],DB_REASON_DESC_LEN);
                                                strncpy(sPan,Row[6],INT_PAN_LEN);
                                                mysql_free_result(Res);
                                                logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf: pReq->sAccCode :%s: sErrorMsg:%s: sPan :%s:",sRMSStatus,iQty,fAmount,pReq->sAccCode,sErrorMsg,sPan);

                                }
                        }
                        else
                        {
                                logDebug2("No Result Set ");
                        }

                        if((iStatus =mysql_next_result(DBObj)) > 0)
			{
                                logDebug3("Could not execute statement :%d:",iStatus);
                        }

                        logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBObj));

        }while(iStatus == 0);

                logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
                logInfo(" pReq->sClientId :%s:",pReq->sClientId);

                if(strncmp(sRMSStatus,"S",2)== 0)
                {
                        logDebug2(" RMS_VALIDATE SUCCESS ");
                                logTimestamp("Exit :fRMSCommValidation");
                                return TRUE;

                }
                else if(strncmp(sRMSStatus,"F",2)== 0)
                {
                        logDebug2("Returned Null value in sRMSStatus");
                        logDebug2("##############ERROR IN CALLING RMS########################");
                        *fAmnt = fAmount;
                                *iQuantity = iQty;
                                logInfo("%lf",*fAmnt);
                                logInfo("%d",*iQuantity);
                                logTimestamp("Exit :fRMSCommValidation");
                                return FALSE;
                }
        //      else if(strncmp(sRMSStatus,"S",1))
                else
                {
                        logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);
                                strncpy(sErrorID,sRMSStatus,10);
                                *fAmnt = fAmount;
                                *iQuantity = iQty;
                                //sprintf(pRes,"%s^Q:%d^A:%lf^C:%s",sRMSStatus,iQty,fAmount,pReq->sClientId);
                                logDebug2("##############ERROR IN CALLING RMS########################");
                                //logInfo("%s",pRes);
                                logInfo("%s",sErrorID);
                                logInfo("%lf",*fAmnt);
                                logInfo("%d",*iQuantity);
				logTimestamp("Exit :fRMSCommMLValidation");
                                return FALSE;

                }

}


BOOL fDeleteLockClient(MYSQL *DBObj,DOUBLE64 fOrderNo)
{
	logTimestamp("Entry :fDeleteLockClient");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	INT16		iNumRow;
	LONG32		iError;
	CHAR 	Pr_Query [MAX_QUERY_SIZE];
	BOOL		iChkFlg = FALSE;

	CHAR	sProcName[PROC_NAME_LEN];
	memset(sProcName,'\0',PROC_NAME_LEN);
	memset(Pr_Query,'\0',MAX_QUERY_SIZE);

	logDebug2("************************%lf",fOrderNo);	

	sprintf(Pr_Query,"DELETE FROM RMS_CLIENT_LOCK WHERE V_ORDER_NO = %lf",fOrderNo);	
	
	logDebug2(":%s:",Pr_Query);
	logTimestamp(" SESSION START DELETING");
        if(mysql_query(DBObj,Pr_Query) != SUCCESS)
        {
                sql_Error(DBObj);
                iError  = mysql_errno(DBObj);
                logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
                return ERROR;
        }
	logTimestamp(" SESSION END DELETING");
	return TRUE;
	logTimestamp("Exit :fDeleteLockClient");

}
