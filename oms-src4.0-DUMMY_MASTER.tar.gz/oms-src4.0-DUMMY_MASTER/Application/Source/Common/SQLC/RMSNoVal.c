#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

//extern DBConNEQ;

BOOL GetMktType(CHAR *sMktType,LONG32 iMktType);
BOOL fRMSValidation(struct  INT_ORDERS *pReq, CHAR *pRes,MYSQL *DBObj,LONG32 iPEnv)
{
	logInfo("This is lib with no RMS Call...For Valicate please change the LIB");
	return TRUE;
}
BOOL CncRevValidate(pRmsReq,DBconRMS,iBranchId)
{
	logInfo("This is lib with no RMS Call...For Valicate please change the LIB");
	return TRUE;
}
BOOL fCBRMSValidation(struct  CO_BO_ORDERS_REQUEST *pReq, CHAR *pRes,MYSQL *DBObj,LONG32 iPEnv)
{
	logInfo("This is lib with no RMS Call...For Valicate please change the LIB");
	return TRUE;
}

BOOL fCoRMSValidation(struct  CO_ORDER_REQUEST *pReq, CHAR *pRes,MYSQL *DBObj,LONG32 iPEnv)
{
	logInfo("This is lib with no RMS Call...For Valicate please change the LIB ");
	return TRUE;
}

BOOL fBoRMSValidation(struct  BO_ORDER_REQUEST *pReq,MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt)
{

	logInfo("This is lib with no RMS Call...For Valicate please change the LIB ");
	return TRUE;
}
BOOL fRMSCommValidation(struct  INT_ORDERS *pReq, MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt)
{
	logInfo("This is lib with no RMS Call...For Valicate please change the LIB");
	return TRUE;
}
