#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

extern   *DBCon;
extern   DB_Con;

extern  LONG32          iNCmBranchId ;
extern  LONG32          iNFoBranchId ;
extern  LONG32          iNCurBranchId ;
extern  LONG32          iMcxBranchId ;
extern  CHAR            sSettler  [SETTLOR_LEN];
extern	CHAR            sMcxBrokerId [BROKER_CODE_LEN];
extern 	CHAR            sSettlor        [SETTLOR_LEN];
extern  LONG32          iMcxUsrId ;
extern 	CHAR    sNseSettler[SETTLOR_LEN];
extern  CHAR    sBseSettler[SETTLOR_LEN];
extern  CHAR    sMcxSettler[SETTLOR_LEN];
extern  FLOAT32 	fBcClosePrice;
 
extern CHAR	cGttType;
extern CHAR	sGTTExpiryDate[DB_DATETIME_LEN];
extern  redisContext *RdConn;

BOOL fLoadDBNseEnv()
{
	logTimestamp("Entry :[fLoadDBNseEnv]");
	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;

	CHAR    sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);
//	CHAR    *sQry = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	//        sprintf(sQry,"select EAM_BRANCH_ID,EAM_BROKER_ID,EAM_EXCH_USER_ID from EXCH_ADMINISTRATION_MASTER\
	where EAM_EXM_EXCH_ID = \"%s\" and EAM_SEGMENT = \'%c\';",NSE_EXCH,EQUITY_SEGMENT);

	sprintf(sQry,"select EAM_EXM_EXCH_ID , EAM_SEGMENT , EAM_EXCH_USER_ID , EAM_BROKER_ID , EAM_BRANCH_ID  from EXCH_ADMINISTRATION_MASTER a where a.EAM_EXM_EXCH_ID = 'NSE' AND a.EAM_SEGMENT = \"%c\" AND EAM_GROUP_ID = '1' ;",EQUITY_SEGMENT);

	logDebug2("Qry = %s",sQry);

	if (mysql_query(DB_Con, sQry) != SUCCESS)
	{
		logSqlFatal("Error in select Qry");
		sql_Error(DB_Con);
	}
	Res = mysql_store_result(DB_Con);

	if((Row = mysql_fetch_row(Res)))
	{
			iNCurBranchId = atoi(Row[4]);
			iNFoBranchId = atoi(Row[4]);
			iNCmBranchId = atoi(Row[4]);
			
			memset(sNseSettler,' ',SETTLOR_LEN);
                        strncpy(sNseSettler,Row[3],SETTLOR_LEN);
                        logDebug2("sNseSettler :%s:",sNseSettler);
	}

	mysql_free_result(Res);
//	free(sQry);
	logTimestamp("Exit :[fLoadDBNseEnv]");

}

BOOL fLoadDBMcxEnv()
{
        logTimestamp("fLoadDBMcxEnv [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;
	CHAR    sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);
//        CHAR    *sQry = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

        sprintf(sQry,"select EAM_BRANCH_ID,EAM_BROKER_ID,EAM_EXCH_USER_ID from EXCH_ADMINISTRATION_MASTER\
                        where EAM_EXM_EXCH_ID = \"%s\";",MCX_EXCH);

        logDebug2("Qry = %s",sQry);

        if (mysql_query(DB_Con, sQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
        }
        Res = mysql_store_result(DB_Con);

        while((Row = mysql_fetch_row(Res)))
        {
                iMcxBranchId= atoi(Row[0]);
                logDebug2("iMcxBranchId= %d",iMcxBranchId);

                strncpy(sMcxBrokerId,Row[1],BROKER_CODE_LENGTH);
                logDebug2("sMcxBrokerId= :%s:",sMcxBrokerId);

                iMcxUsrId= atoi(Row[2]);
                logDebug2("iMcxUsrId = %d",iMcxUsrId);

                memset(sMcxSettler,' ',SETTLOR_LEN);
                logDebug2("By NItish :%s: len:%d: ",Row[1],strlen(Row[1]));
                strncpy(sMcxSettler,Row[1],SETTLOR_LEN);
                logDebug2("sMcxSettler :%s:",sMcxSettler);

        }
        mysql_free_result(Res);
//        free(sQry);

        logTimestamp("fLoadDBMcxEnv [EXIT]");
}

BOOL fLoadDBBseEnv()
{
        logTimestamp("Entry :[fLoadDBNseEnv]");
        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;

        CHAR    sQry[MAX_QUERY_SIZE];
        memset(sQry,'\0',MAX_QUERY_SIZE);

        sprintf(sQry,"select EAM_EXM_EXCH_ID , EAM_SEGMENT , EAM_EXCH_USER_ID , EAM_BROKER_ID , EAM_BRANCH_ID  from EXCH_ADMINISTRATION_MASTER a where a.EAM_EXM_EXCH_ID = 'BSE' \
			AND a.EAM_SEGMENT = \"%c\" AND EAM_GROUP_ID = '1' ;",EQUITY_SEGMENT);

        logDebug2("Qry = %s",sQry);

        if (mysql_query(DB_Con, sQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
        }
        Res = mysql_store_result(DB_Con);

        if((Row = mysql_fetch_row(Res)))
        {
                        memset(sBseSettler,' ',SETTLOR_LEN);
                        strncpy(sBseSettler,Row[3],SETTLOR_LEN);
                        logDebug2("sNseSettler :%s:",sBseSettler);
        }

        mysql_free_result(Res);
        logTimestamp("Exit :[fLoadDBNseEnv]");

}

BOOL NSEEQInsert(struct INT_ORDERS *Ins_Req)
{
	logDebug3("Inside Insert NSEEQInsert");

	CHAR            sMktType[MKT_TYPE_LEN];
	memset(sMktType,'\0',MKT_TYPE_LEN);
	LONG32	iErrorCode = 0;
	CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);
	CHAR    InsQuery[MAX_QUERY_SIZE];
	memset(InsQuery,'\0',MAX_QUERY_SIZE);
	if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
	{
		logDebug2("Error in fetching iMktType");
		return FALSE;
	}

	strncpy(sTempSettlor,Ins_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));
	logDebug3("iSeqNo  	:%i:", Ins_Req->ReqHeader.iSeqNo);
	logDebug3("iMsgLength  	:%i:", Ins_Req->ReqHeader.iMsgLength);
	logDebug3("iMsgCode  	:%i:", Ins_Req->ReqHeader.iMsgCode);
	logDebug3("iLegValue  	:%i:", Ins_Req->iLegValue);
	logDebug3("sExcgId  	:%s:", Ins_Req->ReqHeader.sExcgId);
	logDebug3("iUserId  	:%llu:", Ins_Req->ReqHeader.iUserId);
	logDebug3("cSource  	:%c:", Ins_Req->ReqHeader.cSource);
	logDebug3("cSegment  	:%c:", Ins_Req->ReqHeader.cSegment);
	logDebug3("iOrdNo  	:%i:", Ins_Req->fOrdNo);
	logDebug3("iSerialNo  	:%i:", Ins_Req->iSerialNo);
	logDebug3("sSecId  	:%s:", Ins_Req->sSecId);
	logDebug3("sEntityId  	:%s:", Ins_Req->sEntityId);
	logDebug3("sExchOrdNo  	:%s:", Ins_Req->sExchOrdNo);
	logDebug3("sClientId  	:%s:", Ins_Req->sClientId);
	logDebug3("cBuySellInd  :%c:", Ins_Req->cBuySellInd);
	logDebug3("cOrdStatus  	:%c:", Ins_Req->cOrdStatus);
	logDebug3("sEntryDate  	:%s:", Ins_Req->sEntryDate);
	logDebug3("sOrderTime  	:%s:", Ins_Req->sOrderTime);
	logDebug3("iTotalQty  	:%i:", Ins_Req->iTotalQty);
	if(Ins_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)	
	{
		Ins_Req->iRemQty = 0;
	}	
	else
	{
		Ins_Req->iRemQty = Ins_Req->iTotalQty;
	}

	if(Ins_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_ENTRY)
	{
		sprintf(sGTTExpiryDate,"%s",Ins_Req->sEntryDate);
		logDebug3(" In Order Entry sGTTExpiryDate :%s:",sGTTExpiryDate);
	}
	else
	{
		logDebug3("sGTTExpiryDate :%s:",sGTTExpiryDate);
	}
	logDebug3("iRemQty - %i", Ins_Req->iRemQty);
	logDebug3("iDiscQty - %i", Ins_Req->iDiscQty);
	logDebug3("iDiscRemQty - %i", Ins_Req->iDiscRemQty);
	logDebug3("iTotalTradedQty - %i", Ins_Req->iTotalTradedQty);
	logDebug3("fOrderPrice - %f", Ins_Req->fOrderPrice);
	logDebug3("fTriggerPrice - %f", Ins_Req->fTriggerPrice);
	logDebug3("iValidity - %i", Ins_Req->iValidity);
	logDebug3("iOrderType - %i", Ins_Req->iOrderType);
	logDebug3("iGoodTillDaysFlg - %i", Ins_Req->iGoodTillDaysFlg);
	logDebug3("sGoodTillDaysDate - %s", Ins_Req->sGoodTillDaysDate);
	logDebug3("sAccCode - %s", Ins_Req->sAccCode);
	logDebug3("iMinFillQty - %i", Ins_Req->iMinFillQty);
	logDebug3("cProClient - %c", Ins_Req->cProClient);
	logDebug3("sRemarks - %s", Ins_Req->sRemarks);
	//logDebug3("iErrorCode - %i", Ins_Req->iErrorCode);
	logDebug3("cUserType - %c", Ins_Req->cUserType);
	logDebug3("cOrderOffOn - %c", Ins_Req->cOrderOffOn);
	logDebug3("cProductId - %c", Ins_Req->cProductId);
	logDebug3("sUserInfo - %s", Ins_Req->sUserInfo);
	logDebug3("iGrpId - %i", Ins_Req->iGrpId);
	logDebug3("iReasonCode - %i", Ins_Req->iReasonCode);
	logDebug3("sReasonDesc - %s", Ins_Req->sReasonDesc);
	logDebug3("iExchTrdNo - %i", Ins_Req->iExchTrdNo);
	logDebug3("iTrdSerialNo - %i", Ins_Req->iTrdSerialNo);
	logDebug3("iTrdTransCode - %i", Ins_Req->iTrdTransCode);
	logDebug3("cTrdStatus - %c", Ins_Req->cTrdStatus);
	logDebug3("iLstTrdQty - %i", Ins_Req->iLstTrdQty);
	logDebug3("fTrdPrice - %f", Ins_Req->fTrdPrice);
	logDebug3("sTrdTime - %s", Ins_Req->sTrdTime);
	logDebug3("iTrdSeqNo - %i", Ins_Req->iTrdSeqNo);
	logDebug3("cHandleInst - %c", Ins_Req->cHandleInst);
	logDebug3("fAlgoOrderNo - %f", Ins_Req->fAlgoOrderNo);
	logDebug3("iStratergyId - %i", Ins_Req->iStratergyId);
	logDebug3("sClOrdId - %s", Ins_Req->sClOrdId);
	logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
	logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
	logDebug3("sMktType- %s", sMktType);
	logDebug2("Ins_Req->sSettlor    :%s:",Ins_Req->sSettlor);
        logDebug2("sTempSettlor - :%s:",sTempSettlor);
	logDebug2("Ins_Req->sPanNo :%s:",Ins_Req->sPanNo);
        logDebug2("Ins_Req->iLegValue- %d", Ins_Req->iLegValue);
        logDebug2("Ins_Req->cMarkProFlag        :%c:",Ins_Req->cMarkProFlag);
        logDebug2("Ins_Req->fMarkProVal :%lf:",Ins_Req->fMarkProVal);
        logDebug2("Ins_Req->cParticipantType    :%c:",Ins_Req->cParticipantType);
        //logDebug2("Ins_Req->cGTCFlag    :%c:",Ins_Req->cGTCFlag);
        logDebug2("Ins_Req->cEncashFlag :%c:",Ins_Req->cEncashFlag);
        logDebug2("Ins_Req->fLotSize :%f:",Ins_Req->fLotSize);
        logDebug2("Ins_Req->fTickSize :%lf:",Ins_Req->fTickSize);
        logDebug2("Ins_Req->sPlatform:%s:",Ins_Req->sPlatform);
        logDebug2("Ins_Req->sChannel:%s:",Ins_Req->sChannel);
	logDebug2("Ins_Req->sCustomSym     :%s:",Ins_Req->sCustomSym)                 ;
        logDebug2("Ins_Req->sISINCode : %s",Ins_Req->sISINCode);
	logDebug2("Ins_Req->sInstrumentTyp :%s",Ins_Req->sInstrumentTyp);
	logDebug2("cGttType :%c:",cGttType);
	logDebug3("fOrdTriggerPrice - %f", Ins_Req->fOrdTriggerPrice);
	logDebug2("Ins_Req->cGTCFlag    :%c:",Ins_Req->cGTCFlag);
	logDebug3("END");


//	CHAR *InsQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(InsQuery,"INSERT INTO GTT_ORDERS \
			(GTT_ORDER_NO,GTT_SERIAL_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,\
			 GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,GTT_REM_QTY,GTT_DISC_QTY,\
			 GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY,GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,GTT_ORDER_TYPE,GTT_GOOD_TILL_DAYS,\
			 GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,\
			 GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,\
			 GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,GTT_TRD_TRADE_PRICE,GTT_TRD_SEQ_NO,GTT_HANDLE_INST,\
			 GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,GTT_CLORDID,GTT_ORIG_CLORDID,GTT_USER_TYPE,GTT_SYMBOL,GTT_MKT_TYPE,GTT_LEG_NO,\
			GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_GOOD_TILL_DATE,\
			GTT_MULTILEG_ORDER_TYPE,GTT_EXPIRY_DATE,GTT_TYPE,GTT_TICK_SIZE,GTT_LOT_SIZE,GTT_REMARKS1,GTT_REMARKS2,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,\
			GTT_ORD_TRIGGER_PRICE ) \
			VALUES \
			(%f,%i,\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',%s,%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\"%s\",%llu,%i,\
			 \'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\"%s\",%i,%i,%i,\'%c\',%i,%f,%i,\'%c\',%f,%i,\"%s\",\"%s\",\
			 \'%c\',\"%s\",\"%s\",%d,\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',NOW(),\"0\",( %s + INTERVAL 1 YEAR),\'%c\',%lf,%f,\"%s\",\"%s\" ,\"%s\",\"%s\",\"%s\",%f)",\
			Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
			Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
			Ins_Req->cOrdStatus,Ins_Req->sEntryDate,Ins_Req->iTotalQty,Ins_Req->iRemQty,Ins_Req->iDiscQty,\
			Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
			Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,\
			Ins_Req->cProClient,Ins_Req->sRemarks,iErrorCode,Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,\
			Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,Ins_Req->iReasonCode,Ins_Req->sReasonDesc,\
			Ins_Req->iExchTrdNo,(Ins_Req->iSerialNo * -1),Ins_Req->iTrdTransCode,Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,\
			Ins_Req->fTrdPrice,Ins_Req->iTrdSeqNo,Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,\
			Ins_Req->sClOrdId,Ins_Req->sOrigClOrdId,Ins_Req->cUserType,Ins_Req->sSymbol,sMktType,Ins_Req->iLegValue,\
			Ins_Req->sPanNo,Ins_Req->cParticipantType,\
                        sTempSettlor,Ins_Req->cMarkProFlag,Ins_Req->fMarkProVal,Ins_Req->cGTCFlag,Ins_Req->cEncashFlag,sGTTExpiryDate,cGttType,Ins_Req->fTickSize,\
			Ins_Req->fLotSize,Ins_Req->sPlatform,Ins_Req->sChannel,Ins_Req->sCustomSym,Ins_Req->sISINCode,Ins_Req->sInstrumentTyp,Ins_Req->fOrdTriggerPrice);

	logDebug2("%s",InsQuery);
	if(mysql_query(DB_Con, InsQuery) != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}
	else
	{
		logDebug3("Inserted");
		logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
		mysql_commit(DB_Con);
	}
	if(cGttType == OCO_ORDER && Ins_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
        {
	        logDebug3("It's a OCO Order Type");
                fOcoChkOrdStatus(Ins_Req);
        }
        else
        {
        	logDebug3("It's a GTT Order Type");
        }

	logDebug3("Exiting Insert  NSEEQInsert");
//	free(InsQuery);

	return TRUE;
}


BOOL NSEDRVInsert(struct INT_ORDERS *pInt_Req)
{
	logDebug3("Inside Insert NSEDRVInsert");
	CHAR            sMktType[MKT_TYPE_LEN];
	LONG32	iErrorCode = 0;
	memset(sMktType,'\0',MKT_TYPE_LEN);

	CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);

	strncpy(sTempSettlor,pInt_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));
	CHAR    InsQuery[MAX_QUERY_SIZE];
	memset(InsQuery,'\0',MAX_QUERY_SIZE);
	if(GetMktType(&sMktType,pInt_Req->iMktType)!=TRUE)
	{
		logDebug2("Error in fetching iMktType");
		return FALSE;
	}	

//	CHAR *InsQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	if(pInt_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		pInt_Req->iRemQty = 0;
	}
	else
	{
		pInt_Req->iRemQty = pInt_Req->iTotalQty;
	}
	logDebug2("We are in DRv right");
	logDebug2("pInt_Req->sPanNo :%s:",pInt_Req->sPanNo);
        logDebug2("pInt_Req->sSettlor    :%s:",pInt_Req->sSettlor);
        logDebug2("sTempSettlor - :%s:",sTempSettlor);
        logDebug2("pInt_Req->iLegValue- %d", pInt_Req->iLegValue);
        logDebug2("pInt_Req->cMarkProFlag        :%c:",pInt_Req->cMarkProFlag);
        logDebug2("pInt_Req->fMarkProVal :%lf:",pInt_Req->fMarkProVal);
        logDebug2("pInt_Req->cParticipantType    :%c:",pInt_Req->cParticipantType);
        logDebug2("pInt_Req->cGTCFlag    :%c:",pInt_Req->cGTCFlag);
        logDebug2("pInt_Req->cEncashFlag :%c:",pInt_Req->cEncashFlag);
	logDebug2("pIns_Req->fLotSize :%f:",pInt_Req->fLotSize);
        logDebug2("pIns_Req->fTickSize :%lf:",pInt_Req->fTickSize);
	logDebug2("pIns_Req->sPlatform:%s:",pInt_Req->sPlatform);
        logDebug2("pIns_Req->sChannel:%s:",pInt_Req->sChannel);
	logDebug2("pInt_Req->sCustomSym     :%s:",pInt_Req->sCustomSym)                 ;
	logDebug2("GTT_UNDERLINE_SCRIP %s",pInt_Req->sUnderlyingCode);
	logDebug2("GTT_TYPE  %c",cGttType);

        logDebug2("cGttType:%c:",cGttType);
	logDebug2("pInt_Req->sISINCode : %s",pInt_Req->sISINCode);
        logDebug2("pInt_Req->sInstrumentTyp :%s",pInt_Req->sInstrumentTyp);
	logDebug3("pInt_Req->fOrdTriggerPrice - %f", pInt_Req->fOrdTriggerPrice);

	logDebug2("Ins_Req->cGTCFlag    :%c:",pInt_Req->cGTCFlag);

	logDebug2("Ins_Req->sSmExpiryFlag    :%s:",pInt_Req->sSmExpiryFlag);
	sprintf(InsQuery,"INSERT INTO GTT_ORDERS \
			(GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
			 GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
			 GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
			 GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
			 GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
			 GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
			 GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
			 GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,GTT_OPTION_TYPE,GTT_MKT_TYPE,\
			GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,\
			GTT_TICK_SIZE,GTT_LOT_SIZE,GTT_REMARKS1,GTT_REMARKS2,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_ORD_TRIGGER_PRICE,GTT_EXPIRY_FLAG)\
			VALUES \
			(%f,%i,\"0\",%d,\"%s\",\"%s\",\'%c\',\"%s\",\
			 \"%s\",\"%s\",\'%c\',%i,\'%c\', NOW(),%i,\
			 %i,%i,%i,%i,%f,%f,%i,\
			 %i,%i,NOW(),\"%s\",%llu,%i,\'%c\',\
			 \"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
			 \"%s\",%i,%i,%i,\'%c\',%i,\
			 %f,\"%s\",%i,\'%c\',%f,%i,\
			 \"%s\",\"%s\",\"%s\",\'%c\',\"%s\",( %s + INTERVAL 1 YEAR),%f,\"%s\",\"%s\",\
			\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\",\'%c\',%lf,%f,\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%f,\"%s\")",\
			pInt_Req->fOrdNo,pInt_Req->iSerialNo,pInt_Req->iLegValue,pInt_Req->sSecId,pInt_Req->ReqHeader.sExcgId,pInt_Req->ReqHeader.cSegment,\
			pInt_Req->sEntityId,pInt_Req->sExchOrdNo,pInt_Req->sClientId,pInt_Req->cBuySellInd,pInt_Req->ReqHeader.iMsgCode,\
			pInt_Req->cOrdStatus,pInt_Req->iTotalQty,pInt_Req->iRemQty,pInt_Req->iDiscQty,\
			pInt_Req->iDiscRemQty,pInt_Req->iTotalTradedQty,pInt_Req->fOrderPrice,pInt_Req->fTriggerPrice,pInt_Req->iValidity,\
			pInt_Req->iOrderType,pInt_Req->iGoodTillDaysFlg,pInt_Req->sAccCode,\
			pInt_Req->ReqHeader.iUserId,pInt_Req->iMinFillQty,pInt_Req->cProClient,pInt_Req->sRemarks,iErrorCode,\
			pInt_Req->ReqHeader.cSource,pInt_Req->cOrderOffOn,pInt_Req->cProductId,pInt_Req->sLocCode,pInt_Req->iGrpId,\
			pInt_Req->iReasonCode,pInt_Req->sReasonDesc,pInt_Req->iExchTrdNo,(pInt_Req->iSerialNo * -1),pInt_Req->iTrdTransCode,\
			pInt_Req->cTrdStatus,pInt_Req->iLstTrdQty,pInt_Req->fTrdPrice,pInt_Req->sTrdTime,pInt_Req->iTrdSeqNo,\
			pInt_Req->cHandleInst,pInt_Req->fAlgoOrderNo,pInt_Req->iStratergyId,pInt_Req->sClOrdId, pInt_Req->sOrigClOrdId,\
			pInt_Req->sSymbolName,pInt_Req->cUserType,pInt_Req->sInstrumentType,pInt_Req->sEntryDate,pInt_Req->fStrikePrice,\
			pInt_Req->sOptType,sMktType,pInt_Req->sPanNo,pInt_Req->cParticipantType,sTempSettlor,pInt_Req->cMarkProFlag,\
			pInt_Req->fMarkProVal,pInt_Req->cGTCFlag,pInt_Req->cEncashFlag,pInt_Req->sUnderlyingCode,cGttType,pInt_Req->fTickSize,pInt_Req->fLotSize,\
			pInt_Req->sPlatform,pInt_Req->sChannel ,pInt_Req->sCustomSym,pInt_Req->sISINCode,pInt_Req->sInstrumentTyp,pInt_Req->fOrdTriggerPrice,pInt_Req->sSmExpiryFlag);

	logDebug3(" %s ",InsQuery);

	if(mysql_query(DB_Con,InsQuery) != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}
	else
	{
		logDebug3("Inserted ");
		logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
		mysql_commit(DB_Con);

	}

	if(cGttType == OCO_ORDER && pInt_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
        {
                logDebug3("It's a OCO Order Type");
                fOcoChkOrdStatus(pInt_Req);
        }
        else
        {
                logDebug3("It's a GTT Order Type");
        }


	logDebug3("Exit Insert NSEDRVInsert");
	return TRUE;


}

BOOL SelectClOrdId(CHAR *SeqNo)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	if (mysql_query(DB_Con, "SELECT NextVal('OFF_ORD');") != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	logDebug3("ClOrdId DP : %s", SeqNo);
	while((Row = mysql_fetch_row(Res)))
	{
		strncpy(SeqNo,Row[0],strlen(Row[0]));
		logDebug3("Generated ClOrdId No. : %s", SeqNo);
	}

	mysql_free_result(Res);

	return TRUE;
}
BOOL OrderNoGenerator(DOUBLE64  *OrdSeq)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	if (mysql_query(DB_Con, "SELECT GenOrderNo();") != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	while((Row = mysql_fetch_row(Res)))
	{
		*OrdSeq = atof(Row[0]);
		logDebug3("Generated Order No. : %lf", *OrdSeq);
	}

	mysql_free_result(Res);

	return TRUE;
}

BOOL fSelectDate(CHAR *sSeq)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	//      if (mysql_query(DBConNEQ, "SELECT CONCAT(Date_format(CURDATE(),'%Y%m%d'));") != SUCCESS)
	if (mysql_query(DB_Con, "SELECT SUBSTR(CONCAT(Date_format(CURDATE(),'%Y%m%d')),3,8);") != SUCCESS)
	{
		sql_Error(DB_Con);
		logSqlFatal("error in select Date [EQOrdSvr].");
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	while((Row = mysql_fetch_row(Res)))
	{
		strncpy(sSeq,Row[0],strlen(Row[0]));
		//              sprintf(SeqNo, "%s%d",Row[0],iMsgType);
		logDebug2("Date_format : %s", sSeq);
	}

	mysql_free_result(Res);

	return TRUE;
}

BOOL fFetchEQSerialNo(struct INT_ORDERS *Ins_Req)
{
	MYSQL_RES               *Res;
	MYSQL_ROW               Row;

	CHAR    FetchQuery[MAX_QUERY_SIZE];
	memset(FetchQuery,'\0',MAX_QUERY_SIZE);
//	CHAR *FetchQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug3("Before Fetch Serial no");

	sprintf(FetchQuery,"SELECT GTT_SERIAL_NO,GTT_EXCH_ORDER_NO,GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_REM_QTY,\
			GTT_ORD_STATUS,GTT_CLORDID,DATE_FORMAT(GTT_EXCH_ORDER_TIME,\'%%Y%%m%%d-%%H:%%i:%%S\'),GTT_TOTAL_TRADED_QTY,GTT_VALIDITY,GTT_PAN_NO,\
			(GTT_EXPIRY_DATE - INTERVAL 1 YEAR) ,GTT_REMARKS1,GTT_REMARKS2 \
			FROM GTT_ORDERS \
			WHERE GTT_SERIAL_NO = (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d ) AND GTT_ORDER_NO = %f AND GTT_LEG_NO = %d ;",\
			Ins_Req->fOrdNo,Ins_Req->iLegValue,Ins_Req->fOrdNo,Ins_Req->iLegValue);

	logDebug2("%s",FetchQuery);

	if (mysql_query(DB_Con, FetchQuery) != SUCCESS) {
		sql_Error(DB_Con);
		return ERROR;
	}

	Res = mysql_store_result(DB_Con);

//	free(FetchQuery);

	while((Row = mysql_fetch_row(Res)))
	{
		//printf("\n Before %d : %s", Ins_Req->iSerialNo,Row[0]);
		//printf("\n Before %d : %s : %d", Ins_Req->iSerialNo,Row[0],atoi(Row[0]));
		if(Ins_Req->iSerialNo == atoi(Row[0]) + 1)
		{
			logDebug3("Serial check OK");
			logDebug3("GTT_ORD_STATUS : %c",Row[5][0]);
			if(Row[5][0] == 'E')
			{
				logDebug3("Order Still in transit.");
				mysql_free_result(Res);
				return ORDER_IN_TRANSIT;
			}
			else
			{
				strncpy(Ins_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
				strncpy(Ins_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
				strncpy(Ins_Req->sPanNo,Row[10],INT_PAN_LEN);
				sprintf(sGTTExpiryDate,"\"%s\"",Row[11]);
				strncpy(Ins_Req->sPlatform,Row[12],PLATFORM_LEN);
                                strncpy(Ins_Req->sChannel,Row[13],CHANNEL_LEN);
				logDebug2("Ins_Req->sPlatform:%s:",Ins_Req->sPlatform);
        			logDebug2("Ins_Req->sChannel:%s:",Ins_Req->sChannel);
				logDebug3("sOrigClOrdId : %s",Ins_Req->sOrigClOrdId);
				logDebug3("sGTTExpiryDate: %s",sGTTExpiryDate);
				if(Ins_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
				{
					logDebug3("Modification Order");
					strncpy(Ins_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
					logDebug3("[6000] sLastModTime : %s",Ins_Req->sLastModTime);
					Ins_Req->iTotalTradedQty = atoi(Row[8]);
					if(Ins_Req->fOrderPrice != atof(Row[2])  || Ins_Req->fTriggerPrice != atof(Row[3]) || Ins_Req->iTotalQty != atoi(Row[4])||Ins_Req->iValidity != atoi(Row[7]))
					{
						logDebug3("Modify Success");
						/***            Ins_Req->iTotalQty = Ins_Req->iTotalQty + Ins_Req->iTotalTradedQty; ****/
						mysql_free_result(Res);
						return TRUE;
					}
					else
					{
						logDebug3("Nothing Modified");
						mysql_free_result(Res);
						//SendErrorToFE(Ins_Req, NO_PARAMETERS_CHANGED, Ins_Req->iTotalQty, Ins_Req->fOrderPrice);
						return NO_MODIFICATION;
					}
				}
				else
				{
					mysql_free_result(Res);
					Ins_Req->iTotalTradedQty = atoi(Row[8]);
					logDebug3("Cancellation Order");
					return TRUE;
				}
			}
		}
		else
		{
			logDebug3("Serial check Not OK");
			mysql_free_result(Res);
			return FALSE;
		}
	}
}

BOOL    fFetchDRVSerialNo(struct INT_ORDERS *Int_Req)
{
	logTimestamp("fFetchDRVSerialNo [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR    sSelSerQ[MAX_QUERY_SIZE];
	memset(sSelSerQ,'\0',MAX_QUERY_SIZE);
//	CHAR *sSelSerQ= malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug3("Before Fetch Serial No");

	sprintf(sSelSerQ,"SELECT GTT_SERIAL_NO,GTT_EXCH_ORDER_NO,GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_REM_QTY,\
			GTT_ORD_STATUS,GTT_CLORDID,DATE_FORMAT(GTT_EXCH_ORDER_TIME,\'%%Y%%m%%d-%%H:%%i:%%S\'),GTT_TOTAL_TRADED_QTY,GTT_VALIDITY,GTT_PAN_NO,GTT_REMARKS1,GTT_REMARKS2,\
			GTT_EXPIRY_FLAG \
			FROM GTT_ORDERS \
			WHERE GTT_SERIAL_NO = (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d) AND GTT_ORDER_NO = %f AND GTT_LEG_NO = %d ",Int_Req->fOrdNo,Int_Req->iLegValue,Int_Req->fOrdNo,Int_Req->iLegValue);

	logDebug2("\n%s\n",sSelSerQ);

	if(mysql_query(DB_Con,sSelSerQ) != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);

	while((Row = mysql_fetch_row(Res)))
	{
		strncpy(Int_Req->sPanNo,Row[10],INT_PAN_LEN);
		if(Int_Req->iSerialNo == atoi(Row[0]) + 1)
		{
			logDebug3("Serial Check OK");
			logDebug3("GTT_ORD_STATUS : %c",Row[5][0]);

			if(Row[5][0] == TRANSIT_STATUS)
			{
				logDebug3("Order Still in Transit");
				mysql_free_result(Res);
				return ORDER_IN_TRANSIT;
			}
			else
			{
				strncpy(Int_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
				strncpy(Int_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
				logDebug3("sOrigClOrdId : %s",Int_Req->sOrigClOrdId);

				strncpy(Int_Req->sPlatform,Row[11],PLATFORM_LEN);
                                strncpy(Int_Req->sChannel,Row[12],CHANNEL_LEN);
                                strncpy(Int_Req->sSmExpiryFlag,Row[13],DB_EXPIRY_FLAG_LEN);
                                logDebug2("Ins_Req->sPlatform:%s:",Int_Req->sPlatform);
                                logDebug2("Ins_Req->sChannel:%s:",Int_Req->sChannel);
                                logDebug2("Ins_Req->sSmExpiryFlag:%s:",Int_Req->sSmExpiryFlag);

				if(Int_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
				{
					logDebug3("Modification Order");
					/***                strncpy(Int_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
					  logDebug3("[6000] sLastModTime : %s",Int_Req->sLastModTime);
					 ****/
					Int_Req->iTotalTradedQty = atoi(Row[8]);
					if(Int_Req->fOrderPrice != atof(Row[2]) || Int_Req->fTriggerPrice != atof(Row[3]) || Int_Req->iTotalQty!= atoi(Row[4])||Int_Req->iValidity != atoi(Row[9]))
					{
						logDebug3("Modify Success");
						/****           Int_Req->iTotalQty = Int_Req->iTotalQty + Int_Req->iTotalTradedQty; ****/
						mysql_free_result(Res);

						logTimestamp("fFetchDRVSerialNo [EXIT]");
						return TRUE;
					}
					else
					{
						logDebug3("Nothing to Modify");
						mysql_free_result(Res);
						logTimestamp("fFetchDRVSerialNo [EXIT]");
						return NO_MODIFICATION;
					}
				}
				else
				{
					Int_Req->iTotalTradedQty = atoi(Row[8]);
					mysql_free_result(Res);
					logDebug3("Cancellation Order");
					logTimestamp("fFetchDRVSerialNo [EXIT]");
					return TRUE;
				}
			}

		}
		else
		{
			logDebug3("Serial check Not ok");
			mysql_free_result(Res);
			return FALSE;
		}
	}	
}
BOOL    fFetchErrStr(CHAR *sErrorID,CHAR *sErrString)
{

	logTimestamp("Entry : fFetchErrStr");
	MYSQL_RES               *Res;
	MYSQL_ROW               Row;
	INT16   iNumRow;


	CHAR SelQuery [MAX_QUERY_SIZE];
	memset(SelQuery,'\0',MAX_QUERY_SIZE);

	logDebug2(" fFetchErrStr sErrorID :%s:",sErrorID);

	sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = \'%s\' ;",sErrorID);

	logDebug2("%s",SelQuery);
	if (mysql_query(DB_Con, SelQuery) != SUCCESS)
	{
		logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	logDebug2("Rows : %i",mysql_num_rows(Res));

	iNumRow = mysql_num_rows(Res);


	if(iNumRow != 0)
	{

		if((Row = mysql_fetch_row(Res)))
		{
			logDebug2("serial no  :%s: ",Row[0]);
			strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

		}
	}
	else
	{
		logDebug2("Error ID not Found in DB :%s:",sErrorID);
		return FALSE;
	}

	logTimestamp("Exit : fFetchErrStr");
	return TRUE;
}


BOOL    fFetchMCXSerialNo(struct INT_ORDERS *Int_Req)
{
        logTimestamp("fFetchMCXSerialNo [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	CHAR    statement[MAX_QUERY_SIZE];
	memset(statement,'\0',MAX_QUERY_SIZE);
//        CHAR *statement = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

        logDebug3("Before Fetch Serial No");
        //logDebug2("Int_Req->fOrdNo:%lf",Int_Req->fOrdNo);
        //logDebug2("Int_Req->fOrdNo:%lf",Int_Req->fOrdNo);
        sprintf(statement,"SELECT GTT_SERIAL_NO,GTT_EXCH_ORDER_NO,GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_REM_QTY,\
                        GTT_ORD_STATUS,GTT_CLORDID,DATE_FORMAT(GTT_INTERNAL_ENTRY_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),GTT_LAST_TRADE_QTY,GTT_TOTAL_TRADED_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,\
			GTT_VALIDITY,GTT_TRD_TRADE_PRICE,GTT_PAN_NO,GTT_REMARKS1,GTT_REMARKS2,GTT_EXPIRY_FLAG \
                        FROM GTT_ORDERS \
                        WHERE GTT_SERIAL_NO = (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d ) AND GTT_ORDER_NO = %f AND GTT_LEG_NO = %d;",Int_Req->fOrdNo,Int_Req->iLegValue,Int_Req->fOrdNo,Int_Req->iLegValue);

        logDebug2("\n%s\n",statement);

        if(mysql_query(DB_Con,statement) != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);

        while((Row = mysql_fetch_row(Res)))
        {
                logDebug2("printing serial no Int_Req->iSerialNo :%d: atoi(Row[0]) :%d:",Int_Req->iSerialNo,atoi(Row[0]));
                strncpy(Int_Req->sPanNo,Row[14],INT_PAN_LEN);
                if(Int_Req->iSerialNo == atoi(Row[0]) + 1  )
                {
                        logDebug3("Serial Check OK");
                        logDebug3("CR_ORD_STATUS : %c",Row[5][0]);

                        //                        if(Row[5][0] == 'E')
                        if((Row[5][0] == EXCH_REJECT_STATUS) || (Row[5][0] == TRADED_STATUS) || (Row[5][0] == TRANSIT_STATUS) || \
                                        (Row[5][0] == EXCH_DELETE_STATUS) || (Row[5][0] == EXCH_FREEZE_STATUS) || (Row[5][0] == EXPIRED_STATUS) )
                        {
                                logDebug3("Order Still in Transit");
          			mysql_free_result(Res);
                                switch(Row[5][0])
                                {
                                        case TRANSIT_STATUS:
                                                return RET_TRANSIT_STAT;
                                        case TRADED_STATUS :
                                                return RET_TRADED_STAT;
                                        case EXCH_REJECT_STATUS:
                                        case EXCH_DELETE_STATUS:
                                        case EXPIRED_STATUS:
                                        case EXCH_FREEZE_STATUS:
                                                return RET_CANCEL_STAT;

                                }

                        }
                        else
                        {
                                strncpy(Int_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
                                strncpy(Int_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
                                logDebug3("sOrigClOrdId : %s",Int_Req->sOrigClOrdId);
			
				strncpy(Int_Req->sPlatform,Row[15],PLATFORM_LEN);
                                strncpy(Int_Req->sChannel,Row[16],CHANNEL_LEN);
                                strncpy(Int_Req->sSmExpiryFlag,Row[17],DB_EXPIRY_FLAG_LEN);
                                logDebug2("Ins_Req->sPlatform:%s:",Int_Req->sPlatform);
                                logDebug2("Ins_Req->sSmExpiryFlag:%s:",Int_Req->sSmExpiryFlag);

                                if(Int_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
                                {
                                        logDebug3("Modification Order");
                                        strncpy(Int_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
                                        logDebug3("[6000] sLastModTime : %s",Int_Req->sLastModTime);
                                        Int_Req->iTotalTradedQty = atoi(Row[9]);
                                        Int_Req->iLstTrdQty = atoi(Row[8]);
                                        Int_Req->fTrdPrice = atof(Row[13]);
                                        if(Int_Req->fOrderPrice != atof(Row[2]) || Int_Req->fTriggerPrice != atof(Row[3]) || Int_Req->iTotalQty != atoi(Row[4]) ||  \
                                                        Int_Req->iDiscQty != atoi(Row[10])  || Int_Req->iDiscRemQty != atoi(Row[11]) || Int_Req->iValidity != atoi(Row[12]))
                                        {
                                                logDebug3("Modify Success");
                                                mysql_free_result(Res);
                                                return TRUE;
                                        }
                                        else
                                        {
                                                logDebug3("Nothing to Modify");
                                                mysql_free_result(Res);
                                                fSendErrorToFE(Int_Req,NOTHING_TO_MODIFY,Int_Req->iTotalQty,Int_Req->fOrderPrice);
						return NO_MODIFICATION;
                                        }
                                }
                                else
                                {
                                        mysql_free_result(Res);
                                        Int_Req->iTotalTradedQty = atoi(Row[9]);
                                        Int_Req->fTrdPrice = atof(Row[13]);
                                        Int_Req->iLstTrdQty = atoi(Row[8]);
                                        Int_Req->iRemQty = atoi(Row[4]);
                                        Int_Req->iTotalQty = Int_Req->iRemQty;
                                        logDebug3("Cancellation Order");
                                        return TRUE;
                                }
                        }
                }
                else
                {
                        logDebug3("Serial check Not ok");
                        mysql_free_result(Res);
                        if(Row[5][0] == TRADED_STATUS)
                        {
                                logDebug2("Serial check Not OK.Order Is Traded");
                                return RET_TRADED_STAT;

                        }
                        else
                        {
                                Int_Req->iSerialNo = atoi(Row[0]) + 1;
                                logDebug2("Serial check Not OK");
                                return FALSE;
                        }

                }

        }
        logTimestamp(" EXIT [fFetchMCXSerialNo]");
}


BOOL MCXInsert(struct INT_ORDERS *Ins_Req)
{
        logTimestamp("MCXInsert[ENTRY]");
	CHAR    statement1[MAX_QUERY_SIZE];
	memset(statement1,'\0',MAX_QUERY_SIZE);
//        CHAR *statement1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR            sMktType[MKT_TYPE_LEN];
        CHAR symbolName [DB_SYM_LEN];
        memset(symbolName,'\0',DB_SYM_LEN);
        memset(sMktType,'\0',MKT_TYPE_LEN);
        CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);
        if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
        {
                logDebug2("Error in fetching iMktType");
                return FALSE;
        }
        strncpy(sTempSettlor,Ins_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));

        logDebug2("Ins_Req->sSymbolName:%s:",Ins_Req->sSymbolName);
        strncpy(symbolName,Ins_Req->sSymbolName,DB_SYM_LEN);
        logDebug2("Priyanka [%s]",symbolName);
        logDebug2("THIS is test");
        logDebug3("iSeqNo - %d", Ins_Req->ReqHeader.iSeqNo);
        logDebug3("iMsgLength - %d", Ins_Req->ReqHeader.iMsgLength);
        logDebug3("iMsgCode - %d", Ins_Req->ReqHeader.iMsgCode);
        logDebug3("sExcgId - %s", Ins_Req->ReqHeader.sExcgId);
        logDebug3("iUserId - %llu", Ins_Req->ReqHeader.iUserId);
        logDebug3("cSource - %c",Ins_Req->ReqHeader.cSource);
        logDebug3("cSegment - %c", Ins_Req->ReqHeader.cSegment);
        logDebug3("iOrdNo - %d", Ins_Req->fOrdNo);
        logDebug3("iSerialNo - %d", Ins_Req->iSerialNo);
        logDebug3("sSecId - %s", Ins_Req->sSecId);
        logDebug3("sEntityId - %s", Ins_Req->sEntityId);
        logDebug3("sExchOrdNo - %s", Ins_Req->sExchOrdNo);
        logDebug3("sClientId - %s", Ins_Req->sClientId);
        logDebug3("cBuySellInd - %c", Ins_Req->cBuySellInd);
        logDebug3("cOrdStatus - %c", Ins_Req->cOrdStatus);
        logDebug3("sEntryDate - %s", Ins_Req->sEntryDate);
        logDebug3("sOrderTime - %s", Ins_Req->sOrderTime);
        logDebug3("iTotalQty - %d", Ins_Req->iTotalQty);
        logDebug3("iRemQty - %d", Ins_Req->iRemQty);
        logDebug3("iDiscQty - %d", Ins_Req->iDiscQty);
 	logDebug3("iDiscRemQty - %d", Ins_Req->iDiscRemQty);
        logDebug3("iTotalTradedQty - %d", Ins_Req->iTotalTradedQty);
        logDebug3("fOrderPrice - %f", Ins_Req->fOrderPrice);
        logDebug3("fTriggerPrice - %f", Ins_Req->fTriggerPrice);
        logDebug3("iValidity - %d", Ins_Req->iValidity);
        logDebug3("iOrderType - %d", Ins_Req->iOrderType);
        logDebug3("iGoodTillDaysFlg - %d", Ins_Req->iGoodTillDaysFlg);
        logDebug3("sGoodTillDaysDate - %s", Ins_Req->sGoodTillDaysDate);
        logDebug3("sAccCode - %s",Ins_Req->sAccCode);
        logDebug3("iMinFillQty - %d", Ins_Req->iMinFillQty);
        logDebug3("cProClient - %c", Ins_Req->cProClient);
        logDebug3("sRemarks - %s", Ins_Req->sRemarks);
        logDebug3("iErrorCode - %d", Ins_Req->iErrorCode);
        logDebug3("cUserType - %c", Ins_Req->cUserType);
        logDebug3("cOrderOffOn - %c", Ins_Req->cOrderOffOn);
        logDebug3("cProductId - %c", Ins_Req->cProductId);
        logDebug3("sUserInfo - %s", Ins_Req->sUserInfo);
        logDebug3("iGrpId - %d", Ins_Req->iGrpId);
        logDebug3("iReasonCode - %d", Ins_Req->iReasonCode);
        logDebug3("sReasonDesc - %s", Ins_Req->sReasonDesc);
        logDebug3("iExchTrdNo - %d", Ins_Req->iExchTrdNo);
        logDebug3("iTrdSerialNo - %d", Ins_Req->iTrdSerialNo);
        logDebug3("iTrdTransCode - %d", Ins_Req->iTrdTransCode);
        logDebug3("cTrdStatus - %c", Ins_Req->cTrdStatus);
        logDebug3("iLstTrdQty - %d", Ins_Req->iLstTrdQty);
        logDebug3("fTrdPrice - %f", Ins_Req->fTrdPrice);
        logDebug3("sTrdTime - %s", Ins_Req->sTrdTime);
        logDebug3("iTrdSeqNo - %d", Ins_Req->iTrdSeqNo);
        logDebug3("cHandleInst - %c", Ins_Req->cHandleInst);
        logDebug3("fAlgoOrderNo - %f", Ins_Req->fAlgoOrderNo);
        logDebug3("iStratergyId - %d", Ins_Req->iStratergyId);
        logDebug3("sClOrdId - %s", Ins_Req->sClOrdId);
        logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
        logDebug3("sMaturityMonYr - %s", Ins_Req->sMaturityMonYr);
        logDebug3("sMktType:%s",sMktType);

        logDebug2("Ins_Req->sPanNo :%s:",Ins_Req->sPanNo);
        logDebug2("Ins_Req->sSettlor    :%s:",Ins_Req->sSettlor);
        logDebug2("sTempSettlor - :%s:",sTempSettlor);
        logDebug2("Ins_Req->iLegValue- %d", Ins_Req->iLegValue);
        logDebug2("Ins_Req->iAlgoID :%d:",Ins_Req->iAlgoID);
        logDebug2("Ins_Req->iAlgoCat    :%d:",Ins_Req->iAlgoCat);
	logDebug2("Ins_Req->cCrossCurFlag       :%c:",Ins_Req->cCrossCurFlag);
        logDebug2("Ins_Req->fRBIRefRate :%lf:",Ins_Req->fRBIRefRate);
        logDebug2("Ins_Req->cMarkProFlag        :%c:",Ins_Req->cMarkProFlag);
        logDebug2("Ins_Req->fMarkProVal :%lf:",Ins_Req->fMarkProVal);
        logDebug2("Ins_Req->cParticipantType    :%c:",Ins_Req->cParticipantType);
        logDebug2("Ins_Req->cGTCFlag    :%c:",Ins_Req->cGTCFlag);
        logDebug2("Ins_Req->cEncashFlag :%c:",Ins_Req->cEncashFlag);
        Ins_Req->iTrdSerialNo = (Ins_Req->iSerialNo * -1);
        logDebug2("Ins_Req->iTrdSerialNo :%d:",Ins_Req->iTrdSerialNo);
        logDebug2("sSeries - :%s:",Ins_Req->sSeries);
	logDebug2("Ins_Req->fLotSize :%f:",Ins_Req->fLotSize);
        logDebug2("Ins_Req->fTickSize :%lf:",Ins_Req->fTickSize);
	logDebug2("Ins_Req->sPlatform:%s:",Ins_Req->sPlatform);
        logDebug2("Ins_Req->sChannel:%s:",Ins_Req->sChannel);
	logDebug2("Ins_Req->sCustomSym     :%s:",Ins_Req->sCustomSym)                 ;
	logDebug2("Ins_Req->sISINCode : %s",Ins_Req->sISINCode);
        logDebug2("Ins_Req->sInstrumentTyp :%s",Ins_Req->sInstrumentTyp);
        logDebug2("cGttType - :%c:",cGttType);
	logDebug3("Ins_Req->fOrdTriggerPrice - %f", Ins_Req->fOrdTriggerPrice);

        logDebug2("Ins_Req->cGTCFlag    :%c:",Ins_Req->cGTCFlag);
	logDebug2("Ins_Req->sSmExpiryFlag    :%s:",Ins_Req->sSmExpiryFlag);
        logDebug3("END");

        sprintf(statement1,"INSERT INTO GTT_ORDERS \
                        (GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
                         GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
                         GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
                         GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
                         GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
                         GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
                         GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_OMS_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
                         GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
                         GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_MULTIPLIER,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,COM_MKT_PROTECT_FLG,\
                      	 GTT_MKT_PROTECT_VAL,GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_SERIES,GTT_TYPE,GTT_LOT_SIZE,GTT_TICK_SIZE,GTT_REMARKS1,GTT_REMARKS2,\
			 GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_ORD_TRIGGER_PRICE,GTT_EXPIRY_FLAG ) \
                         VALUES \
                        (%f,%i,\"0\",\"1\",\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',\
                         NOW(),%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\
                         NOW(),\"%s\",%llu,%i,\'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
                         \"%s\",%i,%i,%i,\'%c\',%i,%f,\"%s\",%i,\'%c\',%f,%i,\"%s\",\"%s\",\"%s\",\'%c\',\"%s\",\
			(\"%s\" + INTERVAL 1 YEAR),%f,\"%s\",\"%s\" ,%i,\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\",\'%c\',%f,%lf,\
			\"%s\",\"%s\", \"%s\" ,\"%s\", \"%s\",%f,\"%s\"\
                        )",\
                        Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
                        Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
                        Ins_Req->cOrdStatus,Ins_Req->iRemQty + Ins_Req->iTotalTradedQty,Ins_Req->iRemQty,Ins_Req->iDiscQty,\
                        Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
                        Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,\
                        Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,Ins_Req->cProClient,Ins_Req->sRemarks,Ins_Req->iErrorCode,\
                        Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,\
                        Ins_Req->iReasonCode,Ins_Req->sReasonDesc,Ins_Req->iExchTrdNo,Ins_Req->iTrdSerialNo,Ins_Req->iTrdTransCode,\
                        Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,Ins_Req->fTrdPrice,Ins_Req->sTrdTime,Ins_Req->iTrdSeqNo,\
                        Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,Ins_Req->sClOrdId, Ins_Req->sOrigClOrdId ,\
                        Ins_Req->sSymbolName,Ins_Req->cUserType,Ins_Req->sInstrumentType,Ins_Req->sEntryDate,Ins_Req->fStrikePrice,Ins_Req->sOptType,sMktType,\
                        Ins_Req->iAuctionNum,Ins_Req->sPanNo,Ins_Req->cParticipantType,sTempSettlor,Ins_Req->cMarkProFlag,Ins_Req->fMarkProVal,Ins_Req->cGTCFlag,\
                        Ins_Req->cEncashFlag,Ins_Req->sSeries,cGttType,Ins_Req->fLotSize,Ins_Req->fTickSize,Ins_Req->sPlatform,Ins_Req->sChannel,Ins_Req->sCustomSym,\
			Ins_Req->sISINCode,Ins_Req->sInstrumentTyp,Ins_Req->fOrdTriggerPrice,Ins_Req->sSmExpiryFlag);
			logDebug3("Insert Query->%s ",statement1);
        if(mysql_query(DB_Con,statement1) != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }
        else
        {
                logDebug3("Inserted ");
                logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
                mysql_commit(DB_Con);
        }

	if(cGttType == OCO_ORDER && Ins_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
        {
                logDebug3("It's a OCO Order Type");
                fOcoChkOrdStatus(Ins_Req);
        }
        else
        {
                logDebug3("It's a GTT Order Type");
        }

        logTimestamp("Exit : [MCXInsert]");
//        free(statement1);

        return TRUE;
}

BOOL    fFetchOMSErrStr(LONG32 *iErrorID,CHAR *sErrString)
{

        logTimestamp("Entry : fFetchOMSErrStr");
        MYSQL_RES               *Res;
        MYSQL_ROW               Row;
        INT16   iNumRow;


        CHAR SelQuery [MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

        logDebug2(" fFetchOMSErrStr iErrorID :%d:",iErrorID);

        sprintf(SelQuery,"SELECT RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = %d ;",iErrorID);

        logDebug2("%s",SelQuery);
        if (mysql_query(DB_Con, SelQuery) != SUCCESS)
        {
                logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);
        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);


        if(iNumRow != 0)
        {

                if((Row = mysql_fetch_row(Res)))
                {
                        logDebug2("serial no  :%s: ",Row[0]);
                        strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

                }
        }
        else
        {
                logDebug2("Error ID not Found in DB :%d:",iErrorID);
                return FALSE;
        }
         logTimestamp("Exit : fFetchOMSErrStr");
                return TRUE;
}

fOcoChkOrdStatus(struct  INT_ORDERS *pEOrdReq)
{
	logTimestamp("ENTRY :fOcoChkOrdStatus:");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32 i = 0;
        LONG32  iStatus[3] ;
        DOUBLE64 fTriggerPrice [3];
        DOUBLE64 fPrice [3];
        LONG32  iLegNo[3];
        LONG32  iGttMsgCode [3];
        LONG32  iRemQty = 0;

        CHAR    Query[MAX_QUERY_SIZE];
        memset(Query,'\0',MAX_QUERY_SIZE);
        CHAR    InsQuery[MAX_QUERY_SIZE];
        memset(InsQuery,'\0',MAX_QUERY_SIZE);
        logDebug3("pEOrdReq.fOrdNo:%lf:",pEOrdReq->fOrdNo);
        sprintf(Query,"SELECT GTT_TRIGGER_PRICE,GTT_ORDER_PRICE,GTT_ORD_STATUS , GTT_BUY_SELL_IND , GTT_LEG_NO,GTT_MSG_CODE FROM GTT_ORDERS A WHERE GTT_ORDER_NO = %lf AND GTT_SERIAL_NO = (SELECT MAX(ORD1.GTT_SERIAL_NO) FROM GTT_ORDERS ORD1 WHERE ORD1.GTT_ORDER_NO = %lf  AND A.GTT_LEG_NO = ORD1.GTT_LEG_NO) order by GTT_LEG_NO asc;",pEOrdReq->fOrdNo,pEOrdReq->fOrdNo);

        logTimestamp("Query [ %s]",Query);
        if (mysql_query(DB_Con, Query) != SUCCESS)
        {
                logSqlFatal(" Error in Select Query EQ_ORDERS in function fCoChckOrderStatus ");
                sql_Error(DB_Con);
                return ERROR ;
        }
        i  =0 ;
        Res = mysql_store_result(DB_Con);
        while((Row = mysql_fetch_row(Res)))
        {
                fTriggerPrice[i] = atof(Row[0]);
                fPrice[i] = atof(Row[1]);
                iStatus[i] = Row[2][0] ;
                iLegNo[i] = atoi(Row[4]);
                iGttMsgCode[i] = atoi(Row[5]) ;
                logDebug2("fTriggerPrice[%d]= [%f]",i,fTriggerPrice[i]);
                logDebug2("fPrice[%d]= [%f]",i,fPrice[i]);
                logDebug2("cStatus[%d] = [%c]",i,iStatus[i]);
                logDebug2("iLegNo[%d] = [%d]",i,iLegNo[i]);
                logDebug2("iGttMsgCode[%d] = [%d]",i,iGttMsgCode[i]);
                i ++ ;
        }
	if(iGttMsgCode[0] == TC_INT_GTT_ORDER_CANCEL)
        {
        memset(InsQuery,'\0',MAX_QUERY_SIZE);
                sprintf(InsQuery,"INSERT INTO GTT_ORDERS (GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,\
                        GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
                                GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
                                GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
                                GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
                                GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
                                GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
                                GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
                                GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
                                GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
                                GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_LOT_SIZE,GTT_TICK_SIZE,GTT_REMARKS1,GTT_REMARKS2,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG)\
                        SELECT \
                        GTT_ORDER_NO,(GTT_SERIAL_NO + 1),GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
                        GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,%d,\'%c\',GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
                        %d,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
                        GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
                        GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
                        GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
                        GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
                        GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
                        GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
                        GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_LOT_SIZE,GTT_TICK_SIZE ,GTT_REMARKS1,GTT_REMARKS2,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG \
                        FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f  AND GTT_SERIAL_NO = \
                        (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d) AND GTT_LEG_NO = %d;",\
                        TC_INT_GTT_ORDER_CANCEL,EXCH_DELETE_STATUS,iRemQty,pEOrdReq->fOrdNo,pEOrdReq->fOrdNo,iLegNo[1],iLegNo[1]);
                logTimestamp("InsQuery:%s:",InsQuery);

                if(mysql_query(DB_Con,InsQuery) != SUCCESS)
                {
                        sql_Error(DB_Con);
                        logSqlFatal("Error in SELECT INSERT Query.");
                }
                else
                {
                        mysql_commit(DB_Con);
                        logDebug2("------SUCCESS IN  SELECT INSERT QUERY-----");
                }
		
	}
	else if(iGttMsgCode[1] == TC_INT_GTT_ORDER_CANCEL)
        {
        memset(InsQuery,'\0',MAX_QUERY_SIZE);
                sprintf(InsQuery,"INSERT INTO GTT_ORDERS (GTT_ORDER_NO,GTT_SERIAL_NO,GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,\
                        GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
                                GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,GTT_MSG_CODE,GTT_ORD_STATUS,GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
                                GTT_REM_QTY,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
                                GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
                                GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
                                GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
                                GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
                                GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
                                GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
                                GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_LOT_SIZE,GTT_TICK_SIZE,GTT_REMARKS1,GTT_REMARKS2,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE,GTT_EXPIRY_FLAG)\
                        SELECT \
                        GTT_ORDER_NO,(GTT_SERIAL_NO + 1),GTT_MULTILEG_ORDER_TYPE,GTT_LEG_NO,GTT_SCRIP_CODE,GTT_EXCH_ID,GTT_SEGMENT,GTT_ENTITY_ID,\
                        GTT_EXCH_ORDER_NO,GTT_CLIENT_ID,GTT_BUY_SELL_IND,%d,\'%c\',GTT_INTERNAL_ENTRY_DATE,GTT_TOTAL_QTY,\
                        %d,GTT_DISC_QTY,GTT_DISC_REM_QTY,GTT_TOTAL_TRADED_QTY, GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_VALIDITY,\
                        GTT_ORDER_TYPE, GTT_GOOD_TILL_DAYS,GTT_GOOD_TILL_DATE,GTT_ACC_CODE,GTT_USER_ID,GTT_MIN_FILL_QTY,GTT_PRO_CLIENT,\
                        GTT_REMARKS,GTT_ERROR_CODE,GTT_SOURCE_FLG,GTT_ORDER_OFFON,GTT_PRODUCT_ID,GTT_LOC_CODE,GTT_GROUP_ID,GTT_REASON_CODE,\
                        GTT_REASON_DESCRIPTION,GTT_TRD_EXCH_TRADE_NO,GTT_TRD_SERIAL_NO,GTT_TRD_TRANS_CODE,GTT_TRD_STATUS,GTT_LAST_TRADE_QTY,\
                        GTT_TRD_TRADE_PRICE,GTT_TRD_TRADE_TIME,GTT_TRD_SDRV_NO, GTT_HANDLE_INST,GTT_ALGO_ORDER_NO,GTT_STRATEGY_ID,\
                        GTT_CLORDID,GTT_ORIG_CLORDID,GTT_SYMBOL,GTT_USER_TYPE,GTT_INSTRUMENT_NAME,GTT_EXPIRY_DATE,GTT_STRIKE_PRICE,\
                        GTT_OPTION_TYPE,GTT_MKT_TYPE,GTT_PAN_NO,GTT_PARTICIPANT_TYPE,GTT_SETTLOR,GTT_MKT_PROTECT_FLG,GTT_MKT_PROTECT_VAL,\
                        GTT_GTC_FLG,GTT_ENCASH_FLG,GTT_UNDERLINE_SCRIP,GTT_TYPE,GTT_LOT_SIZE,GTT_TICK_SIZE,GTT_REMARKS1,GTT_REMARKS2,GTT_CUSTOM_SYMBOL,GTT_ISIN_CODE,GTT_EXCH_INSTRUMENT_TYPE ,GTT_EXPIRY_FLAG \
                        FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f  AND GTT_SERIAL_NO = \
                        (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO = %f AND GTT_LEG_NO = %d) AND GTT_LEG_NO = %d;",\
                        TC_INT_GTT_ORDER_CANCEL,EXCH_DELETE_STATUS,iRemQty,pEOrdReq->fOrdNo,pEOrdReq->fOrdNo,iLegNo[0],iLegNo[0]);
                logTimestamp("InsQuery:%s:",InsQuery);

                if(mysql_query(DB_Con,InsQuery) != SUCCESS)
                {
                        sql_Error(DB_Con);
                        logSqlFatal("Error in SELECT INSERT Query.");
                }
                else
                {
                        mysql_commit(DB_Con);
                        logDebug2("------SUCCESS IN  SELECT INSERT QUERY-----");
                }


        }

	logTimestamp("EXIT :fOcoChkOrdStatus:");
	return TRUE;
}

BOOL    fFetchData(struct FOREVER_ORDER_REQUEST *Ord_Req,CHAR    *sPan,CHAR  *sAccCode)
{
        logTimestamp("Entry : [fFetchClientData]");

        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;
        INT16   iNumRow;

        CHAR    sSeleQry [MAX_QUERY_SIZE];
        memset(sSeleQry,'\0',MAX_QUERY_SIZE);
	logDebug2("CLIENT ID %s",Ord_Req->sClientId);

        if(Ord_Req->ReqHeader.cSegment == COMMODITY_SEGMENT){
                sprintf(sSeleQry,"SELECT ENTITY_MCX_CODE,ENTITY_PAN FROM ENTITY_MASTER WHERE ENTITY_CODE = \"%s\" ;",Ord_Req->sClientId);
        }
        else{
                sprintf(sSeleQry,"SELECT ENTITY_NSE_CODE,ENTITY_PAN FROM ENTITY_MASTER WHERE ENTITY_CODE = \"%s\" ;",Ord_Req->sClientId);
        }
        if (mysql_query(DB_Con, sSeleQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
                return FALSE;
        }
        Res = mysql_store_result(DB_Con);

        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);

        if(iNumRow != 0)
        {
                if((Row = mysql_fetch_row(Res)))
                {
                        strcpy(sAccCode,Row[0]);
                        strcpy(sPan,Row[1]);
                        logDebug2("sAccCode :%s:",sAccCode);
                        logDebug2("sPan:%s:",sPan);
                }
        }
        else
        {
                logDebug2("Not a valid client id .");
                return INVALID_CLIENT_ID;

        }



        logTimestamp("Exit : [fFetchNextSchDate]");
        return TRUE;

}

BOOL    fCheckLtpPrice(struct INT_ORDERS *Ins_Req)
{
        logTimestamp("Entry :fCheckLtpPrice:");
	
	struct  INT_ORDERS pEQOrd_Req;

        CHAR sKeyValue[RADIS_KEY_LEN];
        CHAR sCommand[COMMAND_LEN];
        redisReply *reply1;
        DOUBLE64 fTempLtp = 0.00;
	BOOL            ChkFlag = FALSE;	

        memset(sKeyValue,'\0',RADIS_KEY_LEN);
        sprintf(sKeyValue,"%s:%c:%s",Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,Ins_Req->sSecId);
        memset(sCommand,'\0',COMMAND_LEN);
        sprintf(sCommand,"HMGET %s LTP ",sKeyValue);
        logTimestamp("sCommand -> %s",sCommand);
        reply1 = redisCommand(RdConn,sCommand);
	if(reply1->element[0]->str != NULL)
        {
                fTempLtp = atof(reply1->element[0]->str);
                logDebug3("fTempLtp :%f: of sSecId :%s:",fTempLtp,Ins_Req->sSecId);
        }
        else
        {
		logFatal("LTP FOR KEY :%s: NOT PRESENT IN REDIS..",sKeyValue);
		logTimestamp("************************************");
		Ins_Req->fLtp = 0.00;

		/*  If LTP not present in Redis.. We will take LTP from BHAVCOPY table by using function fGetLTPBhvCp  */
		logDebug2("=>GET LTP FROM BHAVCOPY TABLE");
		ChkFlag = fGetLTPBhvCp(Ins_Req->sSecId,Ins_Req->ReqHeader.cSegment,Ins_Req->ReqHeader.sExcgId,&fTempLtp);
		if(ChkFlag == FALSE)
		{
			logDebug2("LTP NOT FOUND IN DB.");
			logTimestamp("************************************");
			logTimestamp("EXIT :fCheckLtpPrice:");
			return FALSE;
		}
		logDebug3("fTempLtp :%f: of sSecId :%s:",fTempLtp,Ins_Req->sSecId);
		Ins_Req->fLtp = fTempLtp;
		
	}
	
        if(fTempLtp >= Ins_Req->fTriggerPrice)
        {
                Ins_Req->cGTCFlag = CHECK_LOWER_SIDE    ;
        }

        if(fTempLtp <= Ins_Req->fTriggerPrice)
        {
                Ins_Req->cGTCFlag =     CHECK_UPPLER_SIDE;
        }


        freeReplyObject(reply1);


        logTimestamp("EXIT :fCheckLtpPrice:");
        return TRUE;

}

BOOL fGetLTPBhvCp(CHAR *sSecId,CHAR *cSegment,CHAR *sExchId,DOUBLE64 *fBcClosePrice)
{
	struct  INT_ORDERS *Ins_Req;

        logTimestamp("Entry :[fGetLTPBhvCp]");
        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;

	LONG32          iRow, iRow2;

        CHAR    sQry[MAX_QUERY_SIZE];
        memset(sQry,'\0',MAX_QUERY_SIZE);


	logDebug2("%s:%c:%s",sExchId,cSegment,sSecId);

	if (cSegment == EQUITY_SEGMENT)
	{	
		sprintf(sQry,"SELECT s.BC_CLOSE_PRICE  from BHAV_COPY  s \
		where BC_EXCHANGE= \"%s\" and BC_SEGMENT= \"%c\" and BC_SCRIP_CODE= \"%s\";",\
		sExchId,cSegment,sSecId);
	}
	else
	{
		sprintf(sQry,"SELECT s.DBC_CLOSE_PRICE  from DRV_BHAV_COPY  s \
                where DBC_EXCHANGE= \"%s\" and DBC_SEGMENT= \"%c\" and DBC_SCRIP_CODE= \"%s\";",\
                sExchId,cSegment,sSecId);
	}	

        logDebug2("Qry = %s",sQry);

        if (mysql_query(DB_Con, sQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
	}
	Res = mysql_store_result(DB_Con);
        iRow = mysql_num_rows(Res);
        if (iRow == 0)
        {
		logDebug2("No result Set");
		return FALSE;
	}


        if((Row = mysql_fetch_row(Res)))
        {

                *fBcClosePrice = atof(Row[0]);
		logDebug2("fBcClosePrice is = %f",*fBcClosePrice);
        }

        mysql_free_result(Res);
//--      free(sQry);
        logTimestamp("Exit :[fGetLTPBhvCp]");
        }
