#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

extern   DB_Con;

extern  LONG32          iNCmBranchId ;
extern  LONG32          iNFoBranchId ;
extern  LONG32          iNCurBranchId ;
extern  LONG32          iMcxBranchId ;
extern  CHAR            sSettler  [SETTLOR_LEN];
extern	CHAR            sMcxBrokerId [BROKER_CODE_LEN];
extern 	CHAR            sSettlor        [SETTLOR_LEN];
extern  LONG32          iMcxUsrId ;

BOOL fLoadDBNseEnv()
{
	logTimestamp("Entry :[fLoadDBNseEnv]");
	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;

	CHAR    *sQry = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	//        sprintf(sQry,"select EAM_BRANCH_ID,EAM_BROKER_ID,EAM_EXCH_USER_ID from EXCH_ADMINISTRATION_MASTER\
	where EAM_EXM_EXCH_ID = \"%s\" and EAM_SEGMENT = \'%c\';",NSE_EXCH,EQUITY_SEGMENT);

	sprintf(sQry,"select EAM_EXM_EXCH_ID , EAM_SEGMENT , EAM_EXCH_USER_ID , EAM_BROKER_ID , EAM_BRANCH_ID  from EXCH_ADMINISTRATION_MASTER a where a.EAM_EXM_EXCH_ID = 'NSE' AND a.EAM_SEGMENT IN(\'%c\',\'%c\',\'%c\') ORDER BY a.EAM_SEGMENT;",EQUITY_SEGMENT,DERIVATIVE_SEGMENT,CURRENCY_SEGMENT);

	logDebug2("Qry = %s",sQry);

	if (mysql_query(DB_Con, sQry) != SUCCESS)
	{
		logSqlFatal("Error in select Qry");
		sql_Error(DB_Con);
	}
	Res = mysql_store_result(DB_Con);

	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Here 1");
		logDebug2("Row[1][0] = :%c:",Row[1][0]);
		if( Row[1][0] == CURRENCY_SEGMENT)
		{
			logDebug2("Here 2");
			iNCurBranchId = atoi(Row[4]);
			memset(sSettler,' ',SETTLOR_LEN);
			strncpy(sSettler,Row[3],strlen(Row[1]));
	                logDebug2("sSettler :%s:",sSettler);

			logDebug2("Currency Branch Id= %d",iNCurBranchId);
		}
		else if (Row[1][0] == DERIVATIVE_SEGMENT)
		{
			logDebug2("Here 3");
			iNFoBranchId = atoi(Row[4]);
			memset(sSettler,' ',SETTLOR_LEN);
                        strncpy(sSettler,Row[3],strlen(Row[1]));
                        logDebug2("sSettler :%s:",sSettler);

			logDebug2("Derivative Branch Id = %d",iNFoBranchId);
		}
		else if (Row[1][0] == EQUITY_SEGMENT)
		{
			logDebug2("Here 4");
			iNCmBranchId = atoi(Row[4]);
			memset(sSettler,' ',SETTLOR_LEN);
                        strncpy(sSettler,Row[3],strlen(Row[1]));
                        logDebug2("sSettler :%s:",sSettler);

			logDebug2("Equity Branch Id = %d",iNCmBranchId);
		}
	}

	mysql_free_result(Res);
	free(sQry);
	logTimestamp("Exit :[fLoadDBNseEnv]");

}

BOOL fLoadDBMcxEnv()
{
        logTimestamp("fLoadDBMcxEnv [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;

        CHAR    *sQry = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

        sprintf(sQry,"select EAM_BRANCH_ID,EAM_BROKER_ID,EAM_EXCH_USER_ID from EXCH_ADMINISTRATION_MASTER\
                        where EAM_EXM_EXCH_ID = \"%s\";",MCX_EXCH);

        logDebug2("Qry = %s",sQry);

        if (mysql_query(DB_Con, sQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
        }
        Res = mysql_store_result(DB_Con);

        while((Row = mysql_fetch_row(Res)))
        {
                iMcxBranchId= atoi(Row[0]);
                logDebug2("iMcxBranchId= %d",iMcxBranchId);
                //strncpy(sNBrokerId,Row[1],strlen(Row[1]));
                strncpy(sMcxBrokerId,Row[1],BROKER_CODE_LENGTH);
                logDebug2("sMcxBrokerId= :%s:",sMcxBrokerId);
                iMcxUsrId= atoi(Row[2]);
                logDebug2("iMcxUsrId = %d",iMcxUsrId);
                memset(sSettlor,' ',SETTLOR_LEN);
                //strncpy(sSettler,Row[1],ENV_VARIABLE_LEN);
                //strncpy(sSettler,Row[1],strlen(Row[1]));
                logDebug2("By NItish :%s: len:%d: ",Row[1],strlen(Row[1]));
                strncpy(sSettlor,Row[1],BROKER_CODE_LENGTH);
                //              memset(sSettler+5,' ',12);
                logDebug2("sSettler :%s:",sSettlor);

        }
        mysql_free_result(Res);
        free(sQry);

        logTimestamp("fLoadDBMcxEnv [EXIT]");
}


BOOL NSEEQInsert(struct INT_ORDERS *Ins_Req)
{
	logDebug3("Inside Insert");

	CHAR            sMktType[MKT_TYPE_LEN];
	memset(sMktType,'\0',MKT_TYPE_LEN);
	LONG32	iErrorCode = 0;
	CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);

	if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
	{
		logDebug2("Error in fetching iMktType");
		return FALSE;
	}

	strncpy(sTempSettlor,Ins_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));
	logDebug3("iSeqNo  	:%i:", Ins_Req->ReqHeader.iSeqNo);
	logDebug3("iMsgLength  	:%i:", Ins_Req->ReqHeader.iMsgLength);
	logDebug3("iMsgCode  	:%i:", Ins_Req->ReqHeader.iMsgCode);
	logDebug3("iLegValue  	:%i:", Ins_Req->iLegValue);
	logDebug3("sExcgId  	:%s:", Ins_Req->ReqHeader.sExcgId);
	logDebug3("iUserId  	:%i:", Ins_Req->ReqHeader.iUserId);
	logDebug3("cSource  	:%c:", Ins_Req->ReqHeader.cSource);
	logDebug3("cSegment  	:%c:", Ins_Req->ReqHeader.cSegment);
	logDebug3("iOrdNo  	:%i:", Ins_Req->fOrdNo);
	logDebug3("iSerialNo  	:%i:", Ins_Req->iSerialNo);
	logDebug3("sSecId  	:%s:", Ins_Req->sSecId);
	logDebug3("sEntityId  	:%s:", Ins_Req->sEntityId);
	logDebug3("sExchOrdNo  	:%s:", Ins_Req->sExchOrdNo);
	logDebug3("sClientId  	:%s:", Ins_Req->sClientId);
	logDebug3("cBuySellInd  :%c:", Ins_Req->cBuySellInd);
	logDebug3("cOrdStatus  	:%c:", Ins_Req->cOrdStatus);
	logDebug3("sEntryDate  	:%s:", Ins_Req->sEntryDate);
	logDebug3("sOrderTime  	:%s:", Ins_Req->sOrderTime);
	logDebug3("iTotalQty  	:%i:", Ins_Req->iTotalQty);
	if(Ins_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)	
	{
		Ins_Req->iRemQty = 0;
	}	
	else
	{
		Ins_Req->iRemQty = Ins_Req->iTotalQty;
	}
	logDebug3("iRemQty - %i", Ins_Req->iRemQty);
	logDebug3("iDiscQty - %i", Ins_Req->iDiscQty);
	logDebug3("iDiscRemQty - %i", Ins_Req->iDiscRemQty);
	logDebug3("iTotalTradedQty - %i", Ins_Req->iTotalTradedQty);
	logDebug3("fOrderPrice - %f", Ins_Req->fOrderPrice);
	logDebug3("fTriggerPrice - %f", Ins_Req->fTriggerPrice);
	logDebug3("iValidity - %i", Ins_Req->iValidity);
	logDebug3("iOrderType - %i", Ins_Req->iOrderType);
	logDebug3("iGoodTillDaysFlg - %i", Ins_Req->iGoodTillDaysFlg);
	logDebug3("sGoodTillDaysDate - %s", Ins_Req->sGoodTillDaysDate);
	logDebug3("sAccCode - %s", Ins_Req->sAccCode);
	logDebug3("iMinFillQty - %i", Ins_Req->iMinFillQty);
	logDebug3("cProClient - %c", Ins_Req->cProClient);
	logDebug3("sRemarks - %s", Ins_Req->sRemarks);
	//logDebug3("iErrorCode - %i", Ins_Req->iErrorCode);
	logDebug3("cUserType - %c", Ins_Req->cUserType);
	logDebug3("cOrderOffOn - %c", Ins_Req->cOrderOffOn);
	logDebug3("cProductId - %c", Ins_Req->cProductId);
	logDebug3("sUserInfo - %s", Ins_Req->sUserInfo);
	logDebug3("iGrpId - %i", Ins_Req->iGrpId);
	logDebug3("iReasonCode - %i", Ins_Req->iReasonCode);
	logDebug3("sReasonDesc - %s", Ins_Req->sReasonDesc);
	logDebug3("iExchTrdNo - %i", Ins_Req->iExchTrdNo);
	logDebug3("iTrdSerialNo - %i", Ins_Req->iTrdSerialNo);
	logDebug3("iTrdTransCode - %i", Ins_Req->iTrdTransCode);
	logDebug3("cTrdStatus - %c", Ins_Req->cTrdStatus);
	logDebug3("iLstTrdQty - %i", Ins_Req->iLstTrdQty);
	logDebug3("fTrdPrice - %f", Ins_Req->fTrdPrice);
	logDebug3("sTrdTime - %s", Ins_Req->sTrdTime);
	logDebug3("iTrdSeqNo - %i", Ins_Req->iTrdSeqNo);
	logDebug3("cHandleInst - %c", Ins_Req->cHandleInst);
	logDebug3("fAlgoOrderNo - %f", Ins_Req->fAlgoOrderNo);
	logDebug3("iStratergyId - %i", Ins_Req->iStratergyId);
	logDebug3("sClOrdId - %s", Ins_Req->sClOrdId);
	logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
	logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
	logDebug3("sMktType- %s", sMktType);
	logDebug2("Ins_Req->sSettlor    :%s:",Ins_Req->sSettlor);
        logDebug2("sTempSettlor - :%s:",sTempSettlor);
	logDebug2("Ins_Req->sPanNo :%s:",Ins_Req->sPanNo);
        logDebug2("Ins_Req->iLegValue- %d", Ins_Req->iLegValue);
        logDebug2("Ins_Req->cMarkProFlag        :%c:",Ins_Req->cMarkProFlag);
        logDebug2("Ins_Req->fMarkProVal :%lf:",Ins_Req->fMarkProVal);
        logDebug2("Ins_Req->cParticipantType    :%c:",Ins_Req->cParticipantType);
        logDebug2("Ins_Req->cGTCFlag    :%c:",Ins_Req->cGTCFlag);
        logDebug2("Ins_Req->cEncashFlag :%c:",Ins_Req->cEncashFlag);
	logDebug2("sCustomSym   :%s:",Ins_Req->sCustomSym);
        logDebug2("sISINCode    :%s:",Ins_Req->sISINCode);
        logDebug2("Ins_Req->fLotSize :%f:",Ins_Req->fLotSize);
        logDebug2("Ins_Req->fTickSize:%f:",Ins_Req->fTickSize);
	logDebug2("sInstrumentTyp :%s:",Ins_Req->sInstrumentTyp);


	logDebug3("END");


	CHAR *InsQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(InsQuery,"INSERT INTO EQ_ORDERS \
			(EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,\
			 EQ_BUY_SELL_IND,EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
			 EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,\
			 EQ_ACC_CODE,EQ_USER_ID,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
			 EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
			 EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,\
			 EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,EQ_USER_TYPE,EQ_SYMBOL,EQ_MKT_TYPE,EQ_LEG_NO,\
			 EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_GOOD_TILL_DATE,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_SERIES,EQ_LOT_SIZE,EQ_EXCH_INSTRUMENT_TYPE,EQ_REF_LTP,EQ_TICK_SIZE,EQ_REMARKS1,EQ_REMARKS2) \
			VALUES \
			(%f,%i,\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',%s,%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\"%s\",%i,%i,\
			 \'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\"%s\",%i,%i,%i,\'%c\',%i,%f,%i,\'%c\',%f,%i,\"%s\",\"%s\",\
			 \'%c\',\"%s\",\"%s\",%d,\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\",\"%s\",\"%s\",\"%s\",%f,\"%s\",%f,%f,\"%s\",\"%s\")",\
			Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
			Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
			Ins_Req->cOrdStatus,Ins_Req->sEntryDate,Ins_Req->iTotalQty,Ins_Req->iRemQty,Ins_Req->iDiscQty,\
			Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
			Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,\
			Ins_Req->cProClient,Ins_Req->sRemarks,iErrorCode,Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,\
			Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,Ins_Req->iReasonCode,Ins_Req->sReasonDesc,\
			Ins_Req->iExchTrdNo,(Ins_Req->iSerialNo * -1),Ins_Req->iTrdTransCode,Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,\
			Ins_Req->fTrdPrice,Ins_Req->iTrdSeqNo,Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,\
			Ins_Req->sClOrdId,Ins_Req->sOrigClOrdId,Ins_Req->cUserType,Ins_Req->sSymbol,sMktType,Ins_Req->iLegValue,\
			Ins_Req->sPanNo,Ins_Req->cParticipantType,\
                        sTempSettlor,Ins_Req->cMarkProFlag,Ins_Req->fMarkProVal,Ins_Req->cGTCFlag,Ins_Req->cEncashFlag,Ins_Req->sGoodTillDaysDate,Ins_Req->sCustomSym,Ins_Req->sISINCode,Ins_Req->sSeries,Ins_Req->fLotSize,Ins_Req->sInstrumentTyp,Ins_Req->fLtp,Ins_Req->fTickSize,Ins_Req->sPlatform,Ins_Req->sChannel);

	logDebug2("%s",InsQuery);
	if(mysql_query(DB_Con, InsQuery) != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}
	else
	{
		logDebug3("Inserted");
		logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
		mysql_commit(DB_Con);
	}

	logDebug3("Exiting Insert ");
	free(InsQuery);

	return TRUE;
}


BOOL NSEDRVInsert(struct INT_ORDERS *pInt_Req)
{
	logDebug3("Inside Insert");
	CHAR            sMktType[MKT_TYPE_LEN];
	LONG32	iErrorCode = 0;
	memset(sMktType,'\0',MKT_TYPE_LEN);

	CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);

	strncpy(sTempSettlor,pInt_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));

	if(GetMktType(&sMktType,pInt_Req->iMktType)!=TRUE)
	{
		logDebug2("Error in fetching iMktType");
		return FALSE;
	}	

	CHAR *InsQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	if(pInt_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		pInt_Req->iRemQty = 0;
	}
	else
	{
		pInt_Req->iRemQty = pInt_Req->iTotalQty;
	}

	logDebug2("pInt_Req->sPanNo :%s:",pInt_Req->sPanNo);
        logDebug2("pInt_Req->sSettlor    :%s:",pInt_Req->sSettlor);
        logDebug2("sTempSettlor - :%s:",sTempSettlor);
        logDebug2("pInt_Req->iLegValue- %d", pInt_Req->iLegValue);
        logDebug2("pInt_Req->cMarkProFlag        :%c:",pInt_Req->cMarkProFlag);
        logDebug2("pInt_Req->fMarkProVal :%lf:",pInt_Req->fMarkProVal);
        logDebug2("pInt_Req->cParticipantType    :%c:",pInt_Req->cParticipantType);
        logDebug2("pInt_Req->cGTCFlag    :%c:",pInt_Req->cGTCFlag);
        logDebug2("pInt_Req->cEncashFlag :%c:",pInt_Req->cEncashFlag);
	logDebug2("pInt_Req->sSmExpiryFlag :%s:",pInt_Req->sSmExpiryFlag);	

	sprintf(InsQuery,"INSERT INTO DRV_ORDERS \
			(DRV_ORDER_NO,DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,DRV_LEG_NO,DRV_SCRIP_CODE,DRV_EXCH_ID,DRV_SEGMENT,DRV_ENTITY_ID,\
			 DRV_EXCH_ORDER_NO,DRV_CLIENT_ID,DRV_BUY_SELL_IND,DRV_MSG_CODE,DRV_STATUS,DRV_INTERNAL_ENTRY_DATE,DRV_TOTAL_QTY,\
			 DRV_REM_QTY,DRV_DISC_QTY,DRV_DISC_REM_QTY,DRV_TOTAL_TRADED_QTY, DRV_ORDER_PRICE,DRV_TRIGGER_PRICE,DRV_VALIDITY,\
			 DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS,DRV_GOOD_TILL_DATE,DRV_ACC_CODE,DRV_USER_ID,DRV_MIN_FILL_QTY,DRV_PRO_CLIENT,\
			 DRV_REMARKS,DRV_ERROR_CODE,DRV_SOURCE_FLG,DRV_ORDER_OFFON,DRV_PRODUCT_ID,DRV_LOC_CODE,DRV_GROUP_ID,DRV_REASON_CODE,\
			 DRV_REASON_DESCRIPTION,DRV_TRD_EXCH_TRADE_NO,DRV_TRD_SERIAL_NO,DRV_TRD_TRANS_CODE,DRV_TRD_STATUS,DRV_TRD_TRADE_QTY,\
			 DRV_TRD_TRADE_PRICE,DRV_TRD_TRADE_TIME,DRV_TRD_SDRV_NO, DRV_HANDLE_INST,DRV_OMS_ALGO_ORD_NO,DRV_STRATEGY_ID,\
			 DRV_CLORDID,DRV_ORIG_CLORDID,DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,DRV_MKT_TYPE,\
			 DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_REF_LTP,\
			 DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LOT_SIZE,DRV_REMARKS1,DRV_REMARKS2,DRV_EXPIRY_FLAG) \
			VALUES \
			(%f,%i,\"0\",%d,\"%s\",\"%s\",\'%c\',\"%s\",\
			 \"%s\",\"%s\",\'%c\',%i,\'%c\', NOW(),%i,\
			 %i,%i,%i,%i,%f,%f,%i,\
			 %i,%i,\"%s\",\"%s\",%i,%i,\'%c\',\
			 \"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
			 \"%s\",%i,%i,%i,\'%c\',%i,\
			 %f,\"%s\",%i,\'%c\',%f,%i,\
			 \"%s\",\"%s\",\"%s\",\'%c\',\"%s\",STR_TO_DATE(\"%s\",\'%%Y%%m%%d'),%f,\"%s\",\"%s\",\
			\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\
			%f,\"%s\",%d,\"%s\",%d,%f,%f,\"%s\",\"%s\" ,\"%s\"\
			)",\
			pInt_Req->fOrdNo,pInt_Req->iSerialNo,pInt_Req->iLegValue,pInt_Req->sSecId,pInt_Req->ReqHeader.sExcgId,pInt_Req->ReqHeader.cSegment,\
			pInt_Req->sEntityId,pInt_Req->sExchOrdNo,pInt_Req->sClientId,pInt_Req->cBuySellInd,pInt_Req->ReqHeader.iMsgCode,\
			pInt_Req->cOrdStatus,pInt_Req->iTotalQty,pInt_Req->iRemQty,pInt_Req->iDiscQty,\
			pInt_Req->iDiscRemQty,pInt_Req->iTotalTradedQty,pInt_Req->fOrderPrice,pInt_Req->fTriggerPrice,pInt_Req->iValidity,\
			pInt_Req->iOrderType,pInt_Req->iGoodTillDaysFlg,pInt_Req->sGoodTillDaysDate,pInt_Req->sAccCode,\
			pInt_Req->ReqHeader.iUserId,pInt_Req->iMinFillQty,pInt_Req->cProClient,pInt_Req->sRemarks,iErrorCode,\
			pInt_Req->ReqHeader.cSource,pInt_Req->cOrderOffOn,pInt_Req->cProductId,pInt_Req->sLocCode,pInt_Req->iGrpId,\
			pInt_Req->iReasonCode,pInt_Req->sReasonDesc,pInt_Req->iExchTrdNo,(pInt_Req->iSerialNo * -1),pInt_Req->iTrdTransCode,\
			pInt_Req->cTrdStatus,pInt_Req->iLstTrdQty,pInt_Req->fTrdPrice,pInt_Req->sTrdTime,pInt_Req->iTrdSeqNo,\
			pInt_Req->cHandleInst,pInt_Req->fAlgoOrderNo,pInt_Req->iStratergyId,pInt_Req->sClOrdId, pInt_Req->sOrigClOrdId,\
			pInt_Req->sSymbolName,pInt_Req->cUserType,pInt_Req->sInstrumentType,pInt_Req->sMaturityMonYr,pInt_Req->fStrikePrice,\
			pInt_Req->sOptType,sMktType,pInt_Req->sPanNo,pInt_Req->cParticipantType,sTempSettlor,pInt_Req->cMarkProFlag,\
			pInt_Req->fMarkProVal,pInt_Req->cGTCFlag,pInt_Req->cEncashFlag,pInt_Req->fLtp,pInt_Req->sUndScripCode,\
			pInt_Req->iFreezeQty,pInt_Req->sCustomSym,pInt_Req->iAlgoID,pInt_Req->fTickSize,pInt_Req->fLotSize,pInt_Req->sPlatform,pInt_Req->sChannel,\
			pInt_Req->sSmExpiryFlag \
			);

	logDebug3(" %s ",InsQuery);

	if(mysql_query(DB_Con,InsQuery) != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}
	else
	{
		logDebug3("Inserted ");
		logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
		mysql_commit(DB_Con);

	}


	return TRUE;


}

BOOL SelectClOrdId(CHAR *SeqNo)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	if (mysql_query(DB_Con, "SELECT NextVal('OFF_ORD');") != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	logDebug3("ClOrdId DP : %s", SeqNo);
	while((Row = mysql_fetch_row(Res)))
	{
		strncpy(SeqNo,Row[0],strlen(Row[0]));
		logDebug3("Generated ClOrdId No. : %s", SeqNo);
	}

	mysql_free_result(Res);

	return TRUE;
}
BOOL OrderNoGenerator(DOUBLE64  *OrdSeq)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	if (mysql_query(DB_Con, "SELECT GenOrderNo();") != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	while((Row = mysql_fetch_row(Res)))
	{
		*OrdSeq = atof(Row[0]);
		logDebug3("Generated Order No. : %lf", *OrdSeq);
	}

	mysql_free_result(Res);

	return TRUE;
}

BOOL fSelectDate(CHAR *sSeq)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	//      if (mysql_query(DBConNEQ, "SELECT CONCAT(Date_format(CURDATE(),'%Y%m%d'));") != SUCCESS)
	if (mysql_query(DB_Con, "SELECT SUBSTR(CONCAT(Date_format(CURDATE(),'%Y%m%d')),3,8);") != SUCCESS)
	{
		sql_Error(DB_Con);
		logSqlFatal("error in select Date [EQOrdSvr].");
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	while((Row = mysql_fetch_row(Res)))
	{
		strncpy(sSeq,Row[0],strlen(Row[0]));
		//              sprintf(SeqNo, "%s%d",Row[0],iMsgType);
		logDebug2("Date_format : %s", sSeq);
	}

	mysql_free_result(Res);

	return TRUE;
}

BOOL fFetchEQSerialNo(struct INT_ORDERS *Ins_Req)
{
	MYSQL_RES               *Res;
	MYSQL_ROW               Row;

	CHAR *FetchQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug3("Before Fetch Serial no");

	sprintf(FetchQuery,"SELECT EQ_SERIAL_NO,EQ_EXCH_ORDER_NO,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_REM_QTY,\
			EQ_ORD_STATUS,EQ_CLORDID,DATE_FORMAT(EQ_EXCH_ORDER_TIME,\'%%Y%%m%%d-%%H:%%i:%%S\'),EQ_TOTAL_TRADED_QTY,EQ_VALIDITY,EQ_PAN_NO,EQ_REMARKS1,EQ_REMARKS2,EQ_MSG_CODE \
			FROM EQ_ORDERS \
			WHERE EQ_SERIAL_NO = (SELECT MAX(EQ_SERIAL_NO) FROM EQ_ORDERS WHERE EQ_ORDER_NO = %f) AND EQ_ORDER_NO = %f;",\
			Ins_Req->fOrdNo,Ins_Req->fOrdNo);

	logDebug2("%s",FetchQuery);

	if (mysql_query(DB_Con, FetchQuery) != SUCCESS) {
		sql_Error(DB_Con);
		return ERROR;
	}

	Res = mysql_store_result(DB_Con);

	free(FetchQuery);

	while((Row = mysql_fetch_row(Res)))
	{
		//printf("\n Before %d : %s", Ins_Req->iSerialNo,Row[0]);
		//printf("\n Before %d : %s : %d", Ins_Req->iSerialNo,Row[0],atoi(Row[0]));
		if(Ins_Req->iSerialNo == atoi(Row[0]) + 1)
		{
			logDebug3("Serial check OK");
			logDebug3("EQ_ORD_STATUS : %c",Row[5][0]);

			if(atoi(Row[13]) == TC_INT_OE_CONF_RESP || atoi(Row[13]) == TC_INT_OM_CONF_RESP || atoi(Row[13]) == TC_INT_OC_CONF_RESP)
                        {
                                logFatal("This order %f is Offline Order and trying to cancel or Modify as Normal order.Error from source :%c:",Ins_Req->fOrdNo,Ins_Req->ReqHeader.cSource);
                                return ONLINE_INVALID_STATUS;
                        }

			if(atoi(Row[1]) != 0)
			{
				logDebug3("Not an OfflineOrder.");
                                mysql_free_result(Res);
                                return NO_OFFLINE_ORDER;
			}
		
			if(Row[5][0] == 'E')
			{
				logDebug3("Order Still in transit.");
				mysql_free_result(Res);
				return ORDER_IN_TRANSIT;
			}
			else
			{
				strncpy(Ins_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
				strncpy(Ins_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
				strncpy(Ins_Req->sPanNo,Row[10],INT_PAN_LEN);
				strncpy(Ins_Req->sPlatform,Row[11],PLATFORM_LEN);
				strncpy(Ins_Req->sChannel,Row[12],CHANNEL_LEN);
				logDebug3("sOrigClOrdId : %s",Ins_Req->sOrigClOrdId);
				if(Ins_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
				{
					logDebug3("Modification Order");
					strncpy(Ins_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
					logDebug3("[6000] sLastModTime : %s",Ins_Req->sLastModTime);
					Ins_Req->iTotalTradedQty = atoi(Row[8]);
					if(Ins_Req->fOrderPrice != atof(Row[2])  || Ins_Req->fTriggerPrice != atof(Row[3]) || Ins_Req->iTotalQty != atoi(Row[4])||Ins_Req->iValidity != atoi(Row[7]))
					{
						logDebug3("Modify Success");
						/***            Ins_Req->iTotalQty = Ins_Req->iTotalQty + Ins_Req->iTotalTradedQty; ****/
						mysql_free_result(Res);
						return TRUE;
					}
					else
					{
						logDebug3("Nothing Modified");
						mysql_free_result(Res);
						//SendErrorToFE(Ins_Req, NO_PARAMETERS_CHANGED, Ins_Req->iTotalQty, Ins_Req->fOrderPrice);
						return NO_MODIFICATION;
					}
				}
				else
				{
					mysql_free_result(Res);
					Ins_Req->iTotalTradedQty = atoi(Row[8]);
					logDebug3("Cancellation Order");
					return TRUE;
				}
			}
		}
		else
		{
			logDebug3("Serial check Not OK");
			mysql_free_result(Res);
			return FALSE;
		}
	}
}

BOOL    fFetchDRVSerialNo(struct INT_ORDERS *Int_Req)
{
	logTimestamp("fFetchDRVSerialNo [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR *sSelSerQ= malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug3("Before Fetch Serial No");

	sprintf(sSelSerQ,"SELECT DRV_SERIAL_NO,DRV_EXCH_ORDER_NO,DRV_ORDER_PRICE,DRV_TRIGGER_PRICE,DRV_REM_QTY,\
			DRV_STATUS,DRV_CLORDID,DATE_FORMAT(DRV_EXCH_ORDER_TIME,\'%%Y%%m%%d-%%H:%%i:%%S\'),DRV_TOTAL_TRADED_QTY,DRV_VALIDITY,DRV_PAN_NO,\
			DRV_REMARKS1,DRV_REMARKS2,DRV_EXPIRY_FLAG,DRV_MSG_CODE\
			FROM DRV_ORDERS \
			WHERE DRV_SERIAL_NO = (SELECT MAX(DRV_SERIAL_NO) FROM DRV_ORDERS WHERE DRV_ORDER_NO = %lf) AND DRV_ORDER_NO = %lf",Int_Req->fOrdNo,Int_Req->fOrdNo);

	logDebug2("\n%s\n",sSelSerQ);

	if(mysql_query(DB_Con,sSelSerQ) != SUCCESS)
	{
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);

	while((Row = mysql_fetch_row(Res)))
	{
		strncpy(Int_Req->sPanNo,Row[10],INT_PAN_LEN);
		strncpy(Int_Req->sPlatform,Row[11],PLATFORM_LEN);
		strncpy(Int_Req->sChannel,Row[12],CHANNEL_LEN);
		strncpy(Int_Req->sSmExpiryFlag,Row[13],DB_EXPIRY_FLAG_LEN);
		if(Int_Req->iSerialNo == atoi(Row[0]) + 1)
		{
			logDebug3("Serial Check OK");
			logDebug3("DRV_ORD_STATUS : %c",Row[5][0]);

			if(atoi(Row[14]) == TC_INT_OE_CONF_RESP || atoi(Row[14]) == TC_INT_OM_CONF_RESP || atoi(Row[14]) == TC_INT_OC_CONF_RESP)
                        {
                                logFatal("This order %f  is Offline Order and trying to cancel or Modify as Normal order.Error from source :%c:",Int_Req->fOrdNo,Int_Req->ReqHeader.cSource);
                                return ONLINE_INVALID_STATUS;
                        }

			if(Row[5][0] == TRANSIT_STATUS)
			{
				logDebug3("Order Still in Transit");
				mysql_free_result(Res);
				return ORDER_IN_TRANSIT;
			}
			else
			{
				strncpy(Int_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
				strncpy(Int_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
				logDebug3("sOrigClOrdId : %s",Int_Req->sOrigClOrdId);

				if(Int_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
				{
					logDebug3("Modification Order");
					/***                strncpy(Int_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
					  logDebug3("[6000] sLastModTime : %s",Int_Req->sLastModTime);
					 ****/
					Int_Req->iTotalTradedQty = atoi(Row[8]);
					if(Int_Req->fOrderPrice != atof(Row[2]) || Int_Req->fTriggerPrice != atof(Row[3]) || Int_Req->iTotalQty!= atoi(Row[4])||Int_Req->iValidity != atoi(Row[9]))
					{
						logDebug3("Modify Success");
						/****           Int_Req->iTotalQty = Int_Req->iTotalQty + Int_Req->iTotalTradedQty; ****/
						mysql_free_result(Res);

						logTimestamp("fFetchDRVSerialNo [EXIT]");
						return TRUE;
					}
					else
					{
						logDebug3("Nothing to Modify");
						mysql_free_result(Res);
						logTimestamp("fFetchDRVSerialNo [EXIT]");
						return NO_MODIFICATION;
					}
				}
				else
				{
					Int_Req->iTotalTradedQty = atoi(Row[8]);
					mysql_free_result(Res);
					logDebug3("Cancellation Order");
					logTimestamp("fFetchDRVSerialNo [EXIT]");
					return TRUE;
				}
			}

		}
		else
		{
			logDebug3("Serial check Not ok");
			mysql_free_result(Res);
			return FALSE;
		}
	}	
}
BOOL    fFetchErrStr(CHAR *sErrorID,CHAR *sErrString)
{

	logTimestamp("Entry : fFetchErrStr");
	MYSQL_RES               *Res;
	MYSQL_ROW               Row;
	INT16   iNumRow;


	CHAR SelQuery [MAX_QUERY_SIZE];
	memset(SelQuery,'\0',MAX_QUERY_SIZE);

	logDebug2(" fFetchErrStr sErrorID :%s:",sErrorID);

	sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = \'%s\' ;",sErrorID);

	logDebug2("%s",SelQuery);
	if (mysql_query(DB_Con, SelQuery) != SUCCESS)
	{
		logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
		sql_Error(DB_Con);
		return FALSE;
	}

	Res = mysql_store_result(DB_Con);
	logDebug2("Rows : %i",mysql_num_rows(Res));

	iNumRow = mysql_num_rows(Res);


	if(iNumRow != 0)
	{

		if((Row = mysql_fetch_row(Res)))
		{
			logDebug2("serial no  :%s: ",Row[0]);
			strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

		}
	}
	else
	{
		logDebug2("Error ID not Found in DB :%s:",sErrorID);
		return FALSE;
	}

	logTimestamp("Exit : fFetchErrStr");
	return TRUE;
}


BOOL    fNseEQRMSRejInsert(struct INT_ORDERS *Ins_Req,struct ORDER_RESPONSE *pResp,CHAR *sErrorID)
{
	logTimestamp("ENTRY [fNseEQRMSRejInsert]");
	CHAR            sMktType[MKT_TYPE_LEN];
	memset(sMktType,'\0',MKT_TYPE_LEN);
	LONG32  iErrorCode = 0;
	CHAR *InsQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    SelQry[MAX_QUERY_SIZE];
	BOOL    ChkFlag =FALSE;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	BOOL    iReqFlag = FALSE;

	LONG32  tmpOrdSerialNo = 0;
	LONG32  iTempOrdSerialNo = 0;
	DOUBLE64 fTriggerPrice = 0.00;
	LONG32  iTempMsgCode = 0,iNoOfRec;
	LONG32 iTotlQty = 0;
	LONG32 iRemQty = 0;
	LONG32 iDisQty = 0;
	LONG32 iDiscQtyRemaning = 0;
	LONG32 itotalTrdQty = 0;
	LONG32 iValidity = 0;
	LONG32 iOrdType = 0;
	LONG32 iGoodTilDays = 0;
	LONG32 iMinFilQty = 0;
	LONG32 iGrpId = 0;
	LONG32 iReasonCode = 0;
	LONG32 iTrdExchtrdNo = 0;
	LONG32 itrdSerialNo = 0;
	LONG32 iTrdTrnsCode = 0;
	LONG32 iLstTrdQty = 0;
	LONG32 iTrdSeqNo = 0;
	LONG32 iStratergyId = 0;
	LONG32 iUserId = 0;
	LONG32 iLeg = 0;
	LONG32 iMsgCode = 0;
	CHAR    cSegmnt =       '\0';
	CHAR    cBuySell=       '\0';
	CHAR    cProCil =       '\0';
	CHAR    cSourceFlag     =       '\0';
	CHAR    cOrdOfOn        =       '\0';
	CHAR    cProdId         =       '\0';
	CHAR    cTrdStatus      =       '\0';
	CHAR    cOrdStatus      =       '\0';
	CHAR    cHndleInst      =       '\0';
	CHAR    cUserType       =       '\0';
	CHAR    cTempStatus     =       '\0';
	CHAR    cParticipantType=       '\0';
        CHAR    cGTCFlag        =       '\0';
        CHAR    cEncashFlag     =       '\0';
        CHAR    cCrossCurFlag   =       '\0';
        CHAR    cMarkProFlag    =       '\0';
	CHAR    sPanNo          [INT_PAN_LEN];
	CHAR  sSettlor[SETTLOR_LEN];

	DOUBLE64 fOrdNo = 0.00 ;
	DOUBLE64 fOrdPrice = 0.00 ;
	DOUBLE64 fTradePrice = 0.00 ;
	DOUBLE64 fSelectClOrdId = 0.00 ;
	DOUBLE64        fTrigerPrice = 0.00 ;
	DOUBLE64        fMarkProVal =0.00;
	DOUBLE64        fLotSize =0.00;
	DOUBLE64        fLtp=0.00;

	LONG64 lAlgoOrderNo = 0.00;

	CHAR    sSecId          [DB_SECURITY_ID_LEN];
	CHAR    sSymbol         [DB_SYM_LEN];
	CHAR    sEntityId       [DB_ENTITY_ID_LEN];
	CHAR    sExchOrdNo      [DB_EXCH_ORD_NO_LEN];
	CHAR    sClientId       [DB_CLIENT_ID_LEN];
	CHAR    sEntryDate      [DB_DATETIME_LEN];
	CHAR    sExchOrdTime    [DB_DATETIME_LEN];
	CHAR    sGoodTillDate   [DB_DATETIME_LEN];
	CHAR    sAccCode        [DB_ACC_CODE_LEN];
	CHAR    sRemarks        [DB_REMARKS_LEN];
	CHAR    sLocCode        [LOC_CODE_LEN];
	CHAR    sTrdTime        [DB_DATETIME_LEN];
	CHAR    sClOrdId        [CLORDID_LEN];
	CHAR    sOriClordId     [CLORDID_LEN];
	CHAR    sExchId         [EXCHANGE_LEN];
	CHAR    sInstruName[INSTRU_CODE_LEN];
	CHAR    sCustomSym      [CUSTOM_SYM_LEN];
        CHAR    sISINCode       [DB_ISIN_CODE_LEN];
        CHAR    sSeries         [DB_SERIES_LEN];
        CHAR    sInstrumentTyp  [INSTRUMENT_TYPE];


	memset(sSecId,'\0',DB_SECURITY_ID_LEN);
	memset(sSymbol,'\0',DB_SYM_LEN);
	memset(sEntityId,'\0',DB_ENTITY_ID_LEN);
	memset(sExchOrdNo,'\0',DB_EXCH_ORD_NO_LEN);
	memset(sClientId,'\0',DB_CLIENT_ID_LEN);
	memset(sEntryDate,'\0',DB_DATETIME_LEN);
	memset(sExchOrdTime,'\0',DB_DATETIME_LEN);
	memset(sGoodTillDate,'\0',DB_DATETIME_LEN);
	memset(sAccCode,'\0',DB_ACC_CODE_LEN);
	memset(sRemarks,'\0',DB_REMARKS_LEN);
	memset(sLocCode,'\0',LOC_CODE_LEN);
	memset(sTrdTime,'\0',DB_DATETIME_LEN);
	memset(sClOrdId,'\0',CLORDID_LEN);
	memset(sOriClordId,'\0',CLORDID_LEN);
	memset(sExchId,'\0',EXCHANGE_LEN);
	memset(sInstruName,'\0',INSTRU_CODE_LEN);
	memset(sPanNo,'\0',INT_PAN_LEN);
        memset(sSettlor,'\0',SETTLOR_LEN);
	memset(sCustomSym,'\0',CUSTOM_SYM_LEN);
        memset(sISINCode,'\0',DB_ISIN_CODE_LEN);
        memset(sSeries,'\0',DB_SERIES_LEN);
        memset(sInstrumentTyp,'\0',INSTRUMENT_TYPE);


	 CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);

        strncpy(sTempSettlor,Ins_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));


	if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
	{
		logDebug2("Error in fetching iMktType");
		return FALSE;
	}
	logDebug2("Inside sErrorID :%s:",sErrorID);
	if(strncmp(ORDER_IN_TRANSIT,sErrorID,10) == 0)
	{
		cTempStatus = TRANSIT_STATUS;
	}
	else
	{
		cTempStatus = EXCH_CONFIRM_STATUS;
	}

	logDebug3("pResp->sReasonDesc :%s:",pResp->sReasonDesc);

	sprintf(InsQuery,"INSERT INTO EQ_ORDERS \
			(EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,\
			 EQ_BUY_SELL_IND,EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
			 EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,\
			 EQ_ACC_CODE,EQ_USER_ID,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
			 EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
			 EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,\
			 EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,EQ_USER_TYPE,EQ_SYMBOL,EQ_MKT_TYPE,\
			EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_SERIES,EQ_LOT_SIZE,EQ_EXCH_INSTRUMENT_TYPE,EQ_REF_LTP,EQ_TICK_SIZE) \
			VALUES \
			(%f,%i,\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',%s,%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\"%s\",%i,%i,\
			 \'%c\',\"%s\",\"%s\",\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\"%s\",%i,%i,%i,\'%c\',%i,%f,%i,\'%c\',%f,%i,\"%s\",\"%s\",\
			 \'%c\',\"%s\",\"%s\",\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\",\"%s\",\"%s\",%f,\"%s\",%f,%f)",\
			Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
			Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
			EXCH_REJECT_STATUS,Ins_Req->sEntryDate,Ins_Req->iRemQty + Ins_Req->iTotalTradedQty ,Ins_Req->iRemQty,Ins_Req->iDiscQty,\
			Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
			Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,\
			Ins_Req->cProClient,Ins_Req->sRemarks,Ins_Req->sReasonDesc,Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,\
			Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,Ins_Req->iReasonCode,pResp->sReasonDesc,\
			Ins_Req->iExchTrdNo,(Ins_Req->iSerialNo * -1),Ins_Req->iTrdTransCode,Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,\
			Ins_Req->fTrdPrice,Ins_Req->iTrdSeqNo,Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,\
			Ins_Req->sClOrdId,Ins_Req->sOrigClOrdId,Ins_Req->cUserType,Ins_Req->sSymbol,sMktType,Ins_Req->sPanNo,Ins_Req->cParticipantType,\
                        sTempSettlor,Ins_Req->cMarkProFlag,Ins_Req->fMarkProVal,Ins_Req->cGTCFlag,Ins_Req->cEncashFlag,Ins_Req->sCustomSym,Ins_Req->sISINCode,Ins_Req->sSeries,Ins_Req->fLotSize,Ins_Req->sInstrumentTyp,Ins_Req->fLtp,Ins_Req->fTickSize);

	logDebug2("Query [%s]",InsQuery);
	if(mysql_query(DB_Con, InsQuery) != SUCCESS)
	{
		logSqlFatal("Error in inserting EQ_ORDERS_TABLE");
		sql_Error(DB_Con);
		return FALSE;
	}
	else
	{
		logDebug2(" Sucessfully Inserted into EQ_ORDERS Table");
		logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
		mysql_commit(DB_Con);

	}

	if (Ins_Req->ReqHeader.iMsgCode != TC_INT_RMS_OE_REJECTION && Ins_Req->ReqHeader.iMsgCode != TC_INT_OE_REJECTION)
	{
		memset( SelQry, '\0',  MAX_QUERY_SIZE);
		sprintf(SelQry,"SELECT \
				EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,\
				EQ_CLIENT_ID,EQ_BUY_SELL_IND,EQ_MSG_CODE,EQ_ORD_STATUS,\
				EQ_INTERNAL_ENTRY_DATE,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
				EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
				EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,IFNULL(EQ_GOOD_TILL_DATE,now()),EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
				EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
				EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,\
				EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
				EQ_TRD_TRADE_PRICE,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
				EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,EQ_LEG_NO,EQ_EXCH_ORDER_NO,EQ_EXCH_ORDER_TIME,\
				EQ_PAN_NO,EQ_PARTICIPANT_TYPE,\
                                EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_SERIES,EQ_LOT_SIZE,EQ_EXCH_INSTRUMENT_TYPE,EQ_REF_LTP FROM EQ_ORDERS \
				WHERE \
				EQ_ORDER_NO = \'%f\' AND EQ_SERIAL_NO = (SELECT MAX(EQ_SERIAL_NO) - 1 FROM EQ_ORDERS WHERE EQ_ORDER_NO = \'%f\' \
					AND EQ_LEG_NO = %d )  AND EQ_LEG_NO = %d ;",\
				Ins_Req->fOrdNo,Ins_Req->fOrdNo,Ins_Req->iLegValue,Ins_Req->iLegValue);

		//                EQ_ORDER_NO = \'%f\' AND EQ_SERIAL_NO = (SELECT MAX(EQ_SERIAL_NO)  FROM EQ_ORDERS WHERE EQ_ORDER_NO = \'%f\' \
		AND EQ_ORD_STATUS = \'%c\')  AND EQ_LEG_NO = %d AND EQ_ORD_STATUS = \'%c\';",\
			Ins_Req->fOrdNo,Ins_Req->fOrdNo,cTempStatus,Ins_Req->iLegValue ,cTempStatus);


		logDebug2("Query [%s]",SelQry);
		if(mysql_query(DB_Con, SelQry) != SUCCESS)
		{
			logSqlFatal("Error in Selecting EQ_ORDERS_TABLE");
			sql_Error(DB_Con);
			return FALSE;
		}

		Res = mysql_store_result(DB_Con);	

		if(Row = mysql_fetch_row(Res))
		{
			fOrdNo = atof(Row[0]);
			iTempOrdSerialNo = atoi(Row[1]);
			strncpy(sSecId,Row[2],DB_SECURITY_ID_LEN);
			strncpy(sSymbol,Row[3],DB_SYM_LEN);
			strncpy(sExchId,Row[4],EXCHANGE_LEN);
			cSegmnt = Row[5][0];
			strncpy(sEntityId,Row[6],DB_ENTITY_ID_LEN);
			strncpy(sClientId,Row[7],DB_CLIENT_ID_LEN);
			cBuySell = Row[8][0];
			iMsgCode = atoi(Row[9]);
			cOrdStatus = Row[10][0];
			strncpy(sEntryDate,Row[11],DB_DATETIME_LEN);
			iTotlQty  = atoi(Row[12]);
			iRemQty = atoi(Row[13]);
			iDisQty  = atoi(Row[14]);
			iDiscQtyRemaning  = atoi(Row[15]);
			itotalTrdQty  = atoi(Row[16]);
			fOrdPrice  = atof(Row[17]);
			fTrigerPrice  = atof(Row[18]);
			iValidity = atoi(Row[19]);
			iOrdType = atoi(Row[20]);
			iGoodTilDays    = atoi(Row[21]);
			strncpy(sGoodTillDate,Row[22],DB_DATETIME_LEN);
			strncpy(sAccCode,Row[23],DB_ACC_CODE_LEN);
			iUserId= atoi(Row[24]);
			cUserType = Row[25][0];
			iMinFilQty = atoi(Row[26]);
			cProCil = Row[27][0];
			strncpy(sRemarks,Row[28],DB_REMARKS_LEN);
			cSourceFlag  = Row[29][0];
			cOrdOfOn = Row[30][0];
			cProdId = Row[31][0];
			strncpy(sLocCode,Row[32],LOC_CODE_LEN);
			iGrpId  = atoi(Row[33]);
			iReasonCode = atoi(Row[34]);
			iTrdExchtrdNo = atoi(Row[35]);
			itrdSerialNo = iTempOrdSerialNo * -1;//atoi(Row[36]);
			iTrdTrnsCode = atoi(Row[37]);
			cTrdStatus = Row[38][0];
			iLstTrdQty = atoi(Row[39]);
			fTradePrice = atof(Row[40]);

			iTrdSeqNo = atoi(Row[41]);
			cHndleInst = Row[42][0];
			lAlgoOrderNo = atol(Row[43]);
			iStratergyId = atoi(Row[44]);
			strncpy(sClOrdId,Row[45],CLORDID_LEN);
			strncpy(sOriClordId,Row[46],CLORDID_LEN);
			iLeg = atoi(Row[47]);
			strncpy(sExchOrdNo,Row[48],DB_EXCH_ORD_NO_LEN);
			strncpy(sPanNo,Row[50],INT_PAN_LEN);
			logDebug2("sPanNo +++ :%s:",sPanNo);
                        cParticipantType =  Row[51][0];
			logDebug2("cParticipantType +++ :%c:",cParticipantType);
                        strncpy(sTempSettlor,Row[52],SETTLOR_LEN);
			logDebug2("sTempSettlor+++ :%s:",sTempSettlor);
                        cMarkProFlag = Row[53][0];
			logDebug2("cMarkProFlag+++ :%c:",cMarkProFlag);
                        fMarkProVal  = atof(Row[54]);
			logDebug2("fMarkProVal +++ :%f:",fMarkProVal);
                        cGTCFlag  = Row[55][0];
			logDebug2("cGTCFlag +++ :%c:",cGTCFlag);
                        cEncashFlag = Row[56][0];
			logDebug2("cEncashFlag +++ :%c:",cEncashFlag);
			strncpy(sCustomSym,Row[57],CUSTOM_SYM_LEN);
                        strncpy(sISINCode,Row[58],DB_ISIN_CODE_LEN);
                        strncpy(sSeries,Row[59],DB_SERIES_LEN);
                        fLotSize = atof(Row[60]);
                        strncpy(sInstrumentTyp,Row[61],INSTRUMENT_TYPE);
                        fLtp = atof(Row[62]);


			//                        strncpy(sExchOrdTime,Row[49],DB_DATETIME_LEN);
		}
		iTempOrdSerialNo = Ins_Req->iSerialNo + 1;//iTempOrdSerialNo+2;
		memset( SelQry, '\0',  MAX_QUERY_SIZE);

		sprintf(SelQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
			EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
			EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_TOTAL_QTY,\
			EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
			EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
			EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
			EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
			EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,\
			EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,EQ_LEG_NO,EQ_EXCH_ORDER_NO,EQ_EXCH_ORDER_TIME,\
			EQ_PAN_NO,EQ_PARTICIPANT_TYPE,\
                        EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_SERIES,EQ_LOT_SIZE,EQ_EXCH_INSTRUMENT_TYPE,EQ_REF_LTP) \
				VALUES \
				(\'%f\',%i,\"%s\",\"%s\",\"%s\",\'%c\',\"%s\",\
				 \"%s\",\'%c\',%i,\'%c\',\
				 \"%s\",%i,%i,%i,\
				 %i,%i,%f,%f,%i,\
				 %i,%i,\"%s\",\"%s\",%d,\'%c\',\
				 %i,\'%c\',\"%s\",\"%d\",\'%c\',\'%c\',\
				 \'%c\',\"%s\",%d,%d,\"%s\",\
				 %d,%d,%d,\'%c\',%d,\
				 %f,%d,\'%c\',%ld,\
				 %d,\"%s\",\"%s\" , %d,\"%s\",now(),\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\",\"%s\",\"%s\",%f,\"%s\",%f)",\
				fOrdNo,iTempOrdSerialNo,sSecId,sSymbol,sExchId,cSegmnt,sEntityId,\
				sClientId,cBuySell,iMsgCode,cOrdStatus,\
				sEntryDate,iTotlQty,iRemQty,iDisQty,\
				iDiscQtyRemaning,itotalTrdQty,fOrdPrice,fTrigerPrice,iValidity,\
				iOrdType,iGoodTilDays,sGoodTillDate,sAccCode,iUserId,cUserType,\
				iMinFilQty,cProCil,sRemarks,Ins_Req->ResHeader.iErrorId,cSourceFlag,cOrdOfOn,\
				cProdId,sLocCode,iGrpId,iReasonCode,Ins_Req->sReasonDesc,\
				iTrdExchtrdNo,(iTempOrdSerialNo * -1),iTrdTrnsCode,cTrdStatus,iLstTrdQty,\
				fTradePrice,iTrdSeqNo,cHndleInst,lAlgoOrderNo,\
				iStratergyId,sClOrdId,sOriClordId,iLeg,sExchOrdNo,sPanNo,cParticipantType,sTempSettlor,cMarkProFlag,fMarkProVal,cGTCFlag,cEncashFlag,sCustomSym,sISINCode,sSeries,fLotSize,sInstrumentTyp,fLtp);
		logDebug2("Query [%s]",SelQry);
		if(mysql_query(DB_Con, SelQry) != SUCCESS)
		{
			logSqlFatal("Error in inserting EQ_ORDERS_TABLE");
			sql_Error(DB_Con);
			return FALSE;
		}
		else
		{
			logDebug2(" Sucessfully Inserted into EQ_ORDERS Table");
			logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
			mysql_commit(DB_Con);
		}

		pResp->iOrderType = iOrdType;
		pResp->iOrderValidity = iValidity;
		pResp->iDiscQty= iDisQty;
		pResp->iDiscQtyRem= iDiscQtyRemaning;
		pResp->iTotalQtyRem= iRemQty;
		pResp->iTotalQty= iTotlQty;
		pResp->iLastTradedQty= iOrdType;
		pResp->iTotalTradedQty= itotalTrdQty;
		pResp->iMinFillQty= iMinFilQty;
		pResp->fPrice= fOrdPrice;
		pResp->fTriggerPrice= fTrigerPrice;
		pResp->fTradePrice= fTradePrice;
		pResp->iSerialNum = iTempOrdSerialNo;
	}

	logTimestamp("Exit [fNseEQRMSRejInsert]");
	return TRUE;
}
BOOL    fNseDrRMSRejInsert(struct INT_ORDERS *pInt_Req,struct ORDER_RESPONSE *pResp,CHAR *sErrorID)
{
	logTimestamp("ENTRY [fNseDrRMSRejInsert]");
	CHAR            sMktType[MKT_TYPE_LEN];
	memset(sMktType,'\0',MKT_TYPE_LEN);
	LONG32  iErrorCode = 0;
	CHAR sInsQuery [MAX_QUERY_SIZE];
	CHAR    SelQry[MAX_QUERY_SIZE];
	BOOL    ChkFlag =FALSE;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	memset(sInsQuery,'\0',MAX_QUERY_SIZE);
	
	CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);

        strncpy(sTempSettlor,pInt_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));



	LONG32  tmpOrdSerialNo = 0;
	LONG32  iTempOrdSerialNo = 0;
	LONG32  iMultiOrdtype = 0;
	LONG32  iLegno = 0;
	BOOL    iReqFlag = FALSE;

	DOUBLE64 fTriggerPrice = 0.00;
	LONG32  iTempMsgCode = 0,iNoOfRec;
	LONG32 iTotlQty = 0;
	LONG32 iRemQty = 0;
	LONG32 iDisQty = 0;
	LONG32 iDiscQtyRemaning = 0;
	LONG32 itotalTrdQty = 0;
	LONG32 iValidity = 0;
	LONG32 iOrdType = 0;
	LONG32 iGoodTilDays = 0;
	LONG32 iMinFilQty = 0;
	LONG32 iGrpId = 0;
	LONG32 iReasonCode = 0;
	LONG32 iTrdExchtrdNo = 0;
	LONG32 itrdSerialNo = 0;
	LONG32 iTrdTrnsCode = 0;
	LONG32 iLstTrdQty = 0;
	LONG32 iTrdSeqNo = 0;
	LONG32 iStratergyId = 0;
	LONG32 iUserId = 0;
	LONG32 iMsgCode = 0;
	CHAR    cSegmnt =       '\0';
	CHAR    cBuySell=       '\0';
	CHAR    cProCil =       '\0';
	CHAR    cSourceFlag     =       '\0';
	CHAR    cOrdOfOn        =       '\0';
	CHAR    cProdId         =       '\0';
	CHAR    cTrdStatus      =       '\0';
	CHAR    cOrdStatus      =       '\0';
	CHAR    cHndleInst      =       '\0';
	CHAR    cUserType       =       '\0';
	CHAR    cTempStatus     =       '\0';
	CHAR    cParticipantType=       '\0';
        CHAR    cGTCFlag        =       '\0';
        CHAR    cEncashFlag     =       '\0';
        CHAR    cCrossCurFlag   =       '\0';
        CHAR    cMarkProFlag    =       '\0';

	 DOUBLE64        fMarkProVal =0.00;
        DOUBLE64        fRBIRefRate =0.00;

	DOUBLE64 fOrdNo = 0.00 ;
	DOUBLE64 fOrdPrice = 0.00 ;
	DOUBLE64 fTradePrice = 0.00 ;
	DOUBLE64 fSelectClOrdId = 0.00 ;
	DOUBLE64        fTrigerPrice = 0.00 ;
	DOUBLE64        fStrikePrice =0.00;

	LONG64 lAlgoOrderNo ;

	CHAR    sSecId          [DB_SECURITY_ID_LEN];
	CHAR    sSymbol         [DB_SYM_LEN];
	CHAR    sEntityId       [DB_ENTITY_ID_LEN];
	CHAR    sExchOrdNo      [DB_EXCH_ORD_NO_LEN];
	CHAR    sClientId       [DB_CLIENT_ID_LEN];
	CHAR    sEntryDate      [DB_DATETIME_LEN];
	CHAR    sExchOrdTime    [DB_DATETIME_LEN];
	CHAR    sGoodTillDate   [DB_DATETIME_LEN];
	CHAR    sAccCode        [DB_ACC_CODE_LEN];
	CHAR    sRemarks        [DB_REMARKS_LEN];
	CHAR    sLocCode        [LOC_CODE_LEN];
	CHAR    sTrdTime        [DB_DATETIME_LEN];
	CHAR    sClOrdId        [CLORDID_LEN];
	CHAR    sOriClordId     [CLORDID_LEN];
	CHAR    sExchId         [EXCHANGE_LEN];
	CHAR    sInsrtuName     [DB_INSTRU_LEN];
	CHAR    sExpiry         [DB_DATETIME_LEN];
	CHAR    sOptionType     [DB_OPT_TYPE_LEN];
	CHAR    sReasonDesc     [DB_REASON_DESC_LEN];
	 CHAR    sPanNo          [INT_PAN_LEN];
        CHAR    sSettlor        [SETTLOR_LEN];
	CHAR    sSmExpiryFlag        [DB_EXPIRY_FLAG_LEN];

	memset(sSecId,'\0',DB_SECURITY_ID_LEN);
	memset(sSymbol,'\0',DB_SYM_LEN);
	memset(sEntityId,'\0',DB_ENTITY_ID_LEN);
	memset(sExchOrdNo,'\0',DB_EXCH_ORD_NO_LEN);
	memset(sClientId,'\0',DB_CLIENT_ID_LEN);
	memset(sEntryDate,'\0',DB_DATETIME_LEN);
	memset(sExchOrdTime,'\0',DB_DATETIME_LEN);
	memset(sGoodTillDate,'\0',DB_DATETIME_LEN);
	memset(sAccCode,'\0',DB_ACC_CODE_LEN);
	memset(sRemarks,'\0',DB_REMARKS_LEN);
	memset(sLocCode,'\0',LOC_CODE_LEN);
	memset(sTrdTime,'\0',DB_DATETIME_LEN);
	memset(sReasonDesc,'\0',DB_REASON_DESC_LEN);
	memset(sClOrdId,'\0',CLORDID_LEN);
	memset(sOriClordId,'\0',CLORDID_LEN);
	memset(sExchId,'\0',EXCHANGE_LEN);
	memset(sInsrtuName,'\0',DB_INSTRU_LEN);
	memset(sExpiry ,'\0',DB_DATETIME_LEN);
	memset(sOptionType,'\0',DB_OPT_TYPE_LEN);
	memset(sPanNo,'\0',INT_PAN_LEN);
        memset(sSettlor,'\0',SETTLOR_LEN);
	memset(sSmExpiryFlag,'\0',DB_EXPIRY_FLAG_LEN);


	if(GetMktType(&sMktType,pInt_Req->iMktType)!=TRUE)
	{
		logDebug2("Error in fetching iMktType");
		return FALSE;
	}

	logDebug2("Inside sErrorID :%s:",sErrorID);
	if(strncmp(ORDER_IN_TRANSIT,sErrorID,10) == 0)
	{
		cTempStatus = TRANSIT_STATUS;
	}
	else
	{
		cTempStatus = EXCH_CONFIRM_STATUS;
	}

	logDebug3("pResp->sReasonDesc :%s:",pResp->sReasonDesc);

	sprintf(sInsQuery,"INSERT INTO DRV_ORDERS \
			(DRV_ORDER_NO,DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,DRV_SCRIP_CODE,DRV_EXCH_ID,DRV_SEGMENT,DRV_ENTITY_ID,\
			 DRV_EXCH_ORDER_NO,DRV_CLIENT_ID,DRV_BUY_SELL_IND,DRV_MSG_CODE,DRV_STATUS,DRV_INTERNAL_ENTRY_DATE,DRV_TOTAL_QTY,\
			 DRV_REM_QTY,DRV_DISC_QTY,DRV_DISC_REM_QTY,DRV_TOTAL_TRADED_QTY, DRV_ORDER_PRICE,DRV_TRIGGER_PRICE,DRV_VALIDITY,\
			 DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS,DRV_GOOD_TILL_DATE,DRV_ACC_CODE,DRV_USER_ID,DRV_MIN_FILL_QTY,DRV_PRO_CLIENT,\
			 DRV_REMARKS,DRV_ERROR_CODE,DRV_SOURCE_FLG,DRV_ORDER_OFFON,DRV_PRODUCT_ID,DRV_LOC_CODE,DRV_GROUP_ID,DRV_REASON_CODE,\
			 DRV_REASON_DESCRIPTION,DRV_TRD_EXCH_TRADE_NO,DRV_TRD_SERIAL_NO,DRV_TRD_TRANS_CODE,DRV_TRD_STATUS,DRV_TRD_TRADE_QTY,\
			 DRV_TRD_TRADE_PRICE,DRV_TRD_TRADE_TIME,DRV_TRD_SDRV_NO, DRV_HANDLE_INST,DRV_OMS_ALGO_ORD_NO,DRV_STRATEGY_ID,\
			 DRV_CLORDID,DRV_ORIG_CLORDID,DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,DRV_MKT_TYPE,\
			DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_EXPIRY_FLAG) \
			VALUES \
			(%f,%i,\"0\",\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',\
			 NOW(),%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\
			 \"%s\",\"%s\",%i,%i,\'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
			 \"%s\",%i,%i,%i,\'%c\',%i,%f,\"%s\",%i,\'%c\',%f,%i,\"%s\",\"%s\"\,\"%s\"\,\'%c\',\"%s\",\
			 STR_TO_DATE(\"%s\",\'%%Y%%m%%d'),%f,\"%s\",\"%s\",\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\"\
			)",\
			pInt_Req->fOrdNo,pInt_Req->iSerialNo,pInt_Req->sSecId,pInt_Req->ReqHeader.sExcgId,pInt_Req->ReqHeader.cSegment,\
			pInt_Req->sEntityId,pInt_Req->sExchOrdNo,pInt_Req->sClientId,pInt_Req->cBuySellInd,pInt_Req->ReqHeader.iMsgCode,\
			EXCH_REJECT_STATUS,pInt_Req->iRemQty + pInt_Req->iTotalTradedQty ,pInt_Req->iRemQty,pInt_Req->iDiscQty,\
			pInt_Req->iDiscRemQty,pInt_Req->iTotalTradedQty,pInt_Req->fOrderPrice,pInt_Req->fTriggerPrice,pInt_Req->iValidity,\
			pInt_Req->iOrderType,pInt_Req->iGoodTillDaysFlg,pInt_Req->sGoodTillDaysDate,pInt_Req->sAccCode,\
			pInt_Req->ReqHeader.iUserId,pInt_Req->iMinFillQty,pInt_Req->cProClient,pInt_Req->sRemarks,iErrorCode,\
			pInt_Req->ReqHeader.cSource,pInt_Req->cOrderOffOn,pInt_Req->cProductId,pInt_Req->sLocCode,pInt_Req->iGrpId,\
			pInt_Req->iReasonCode,pResp->sReasonDesc,pInt_Req->iExchTrdNo,(pInt_Req->iSerialNo * -1),pInt_Req->iTrdTransCode,\
			pInt_Req->cTrdStatus,pInt_Req->iLstTrdQty,pInt_Req->fTrdPrice,pInt_Req->sTrdTime,pInt_Req->iTrdSeqNo,\
			pInt_Req->cHandleInst,pInt_Req->fAlgoOrderNo,pInt_Req->iStratergyId,pInt_Req->sClOrdId, pInt_Req->sOrigClOrdId,\
			pInt_Req->sSymbolName,pInt_Req->cUserType,pInt_Req->sInstrumentType,pInt_Req->sMaturityMonYr,pInt_Req->fStrikePrice,\
			pInt_Req->sOptType,sMktType,pInt_Req->sPanNo,pInt_Req->cParticipantType,sTempSettlor,pInt_Req->cMarkProFlag,pInt_Req->fMarkProVal,\
			pInt_Req->cGTCFlag,pInt_Req->cEncashFlag,pInt_Req->sSmExpiryFlag);
	logDebug2("InsQuery :%s: ",sInsQuery);

	if(mysql_query(DB_Con,sInsQuery) != SUCCESS)
	{
		sql_Error(DB_Con);
		logSqlFatal("Error in inserting DRV_ORDERS_TABLE [DROrdDBOp] ");
		return FALSE;
	}
	else
	{
		logDebug2("Inserted ");
		logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
		mysql_commit(DB_Con);
	}


	if (pInt_Req->ReqHeader.iMsgCode != TC_INT_RMS_OE_REJECTION && pInt_Req->ReqHeader.iMsgCode != TC_INT_OE_REJECTION)
	{
		memset( SelQry, '\0',  MAX_QUERY_SIZE);
		sprintf(SelQry,"SELECT \
				DRV_ORDER_NO,DRV_MULTILEG_ORD_TYPE,\
				DRV_LEG_NO, DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
				DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,DRV_INTERNAL_ENTRY_DATE ,\
				DRV_TOTAL_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
				DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
				DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
				DRV_REMARKS, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
				DRV_GROUP_ID, DRV_REASON_CODE, DRV_TRD_EXCH_TRADE_NO,\
				DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
				DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
				DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_SYMBOL,\
				DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,DRV_STATUS,DRV_MSG_CODE,DRV_REM_QTY, \
				DRV_REASON_DESCRIPTION ,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG,\
				DRV_EXPIRY_FLAG \
				FROM DRV_ORDERS WHERE \
				DRV_ORDER_NO = \'%f\' AND DRV_SERIAL_NO = (SELECT MAX(DRV_SERIAL_NO) -1  FROM DRV_ORDERS WHERE DRV_ORDER_NO = \'%f\' \
					AND DRV_LEG_NO = %d)  AND DRV_LEG_NO = %d ;",pInt_Req->fOrdNo,pInt_Req->fOrdNo,pInt_Req->iLegValue,pInt_Req->iLegValue);

		//                DRV_ORDER_NO = \'%f\' AND DRV_SERIAL_NO = %i AND DRV_LEG_NO = %d ;",pInt_Req->fOrdNo,pInt_Req->iSerialNo - 1,pInt_Req->iLegValue);
		logDebug2("SelQry :%s:",SelQry);
		if(mysql_query(DB_Con,SelQry) != SUCCESS)
		{
			logSqlFatal("----ERROR IN  SUCCESS QUERY [fDBSelectOrd] -----");
			sql_Error(DB_Con);
		}
		else
		{
			mysql_commit(DB_Con);
			logDebug2("------SUCCESS IN  SUCCESS QUERY-----");
		}
		Res = mysql_store_result(DB_Con);

		iNoOfRec = mysql_num_rows(Res);
		if (iNoOfRec !=0)
		{
			if(Row=mysql_fetch_row(Res))
			{
				fOrdNo = atof(Row[0]);
				iMultiOrdtype = atoi(Row[1]);
				iLegno = atoi(Row[2]);
				strncpy(sSecId,Row[3],DB_SECURITY_ID_LEN);
				strncpy(sExchId,Row[4],DB_EXCH_ID_LEN);
				cSegmnt = Row[5][0];

				strncpy(sEntityId,Row[6],DB_ENTITY_ID_LEN);
				strncpy(sExchOrdNo,Row[7],DB_EXCH_ORD_NO_LEN);
				strncpy(sClientId,Row[8],DB_CLIENT_ID_LEN);
				cBuySell = Row[9][0];

				strncpy(sEntryDate,Row[10],DB_DATETIME_LEN);
				iTotlQty  = atoi(Row[11]);
				iDisQty  = atoi(Row[12]);
				iDiscQtyRemaning  = atoi(Row[13]);
				itotalTrdQty  = atoi(Row[14]);
				fOrdPrice  = atof(Row[15]);
				fTrigerPrice  = atof(Row[16]);
				iValidity = atoi(Row[17]);
				iOrdType = atoi(Row[18]);
				iGoodTilDays    = atoi(Row[19]);
				strncpy(sGoodTillDate,Row[20],DB_DATETIME_LEN);
				strncpy(sAccCode,Row[21],DB_ACC_CODE_LEN);
				//strncpy(sUserId,Row[22],DB_USER_CODE_LEN);
				iUserId = atoi(Row[22]);
				iMinFilQty = atoi(Row[23]);
				cProCil = Row[24][0];
				strncpy(sRemarks,Row[25],DB_REMARKS_LEN);
				cSourceFlag  = Row[26][0];
				cOrdOfOn = Row[27][0];
				cProdId = Row[28][0];
				strncpy(sLocCode,Row[29],DB_LOC_LEN);
				iGrpId  = atoi(Row[30]);
				iReasonCode = atoi(Row[31]);
				iTrdExchtrdNo = atoi(Row[32]);
				itrdSerialNo = iTempOrdSerialNo * -1;//atoi(Row[33]);
				iTrdTrnsCode = atoi(Row[34]);
				cTrdStatus = Row[35][0];
				iLstTrdQty = atoi(Row[36]);
				fTradePrice = atof(Row[37]);
				strncpy(sTrdTime,Row[38],DB_DATETIME_LEN);
				iTrdSeqNo = atoi(Row[39]);
				cHndleInst = Row[40][0];
				lAlgoOrderNo = atol(Row[41]);
				iStratergyId = atoi(Row[42]);
				strncpy(sClOrdId,Row[43],DB_CLORDID_LEN);
				strncpy(sOriClordId,Row[44],DB_CLORDID_LEN);
				strncpy(sSymbol,Row[45],DB_SYM_LEN);
				cUserType = Row[46][0];
				strncpy(sInsrtuName,Row[47],DB_INSTRU_LEN);
				strncpy(sExpiry,Row[48],DB_DATETIME_LEN);
				fStrikePrice = atof(Row[49]);
				strncpy(sOptionType,Row[50],DB_OPT_TYPE_LEN);
				//                              fLotSiz = atof(Row[51]);
				//                                strncpy(sExchOrdTime,Row[51],DB_DATETIME_LEN);
				cOrdStatus = Row[51][0];
				iMsgCode = atoi(Row[52]);
				iRemQty = atoi(Row[53]);
				iTempOrdSerialNo= pInt_Req->iSerialNo + 1;
				strncpy(sReasonDesc,Row[54],DB_DATETIME_LEN);

				strncpy(sPanNo,Row[55],INT_PAN_LEN);
	                        cParticipantType= Row[56][0];
        	                strncpy(sSettlor,Row[57],SETTLOR_LEN);
	                        cMarkProFlag= Row[58][0];
	                        fMarkProVal= atoi(Row[59]);

	                        cGTCFlag= Row[60][0];
	                        cEncashFlag= Row[61][0];
				strncpy(sSmExpiryFlag,Row[62],DB_EXPIRY_FLAG_LEN);
			}

			memset(sInsQuery,'\0',MAX_QUERY_SIZE);
			logDebug2("cSegmnt = :%c:",cSegmnt);
			logDebug2("cBuySell = :%c:",cBuySell);

			sprintf(sInsQuery,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
				DRV_LEG_NO, DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
				DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
				DRV_TOTAL_QTY ,  DRV_REM_QTY ,  DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
				DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
				DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
				DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
				DRV_GROUP_ID, DRV_REASON_CODE,  DRV_TRD_EXCH_TRADE_NO,\
				DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
				DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
				DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_SYMBOL,\
				DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,DRV_EXCH_ORDER_TIME,DRV_REASON_DESCRIPTION,\
				DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_EXPIRY_FLAG)\
					VALUES \
					(%f,%i,%i,%d,\"%s\",\"%s\" ,\
					 \'%c\',\"%s\",\"%s\",\"%s\" ,\
					 \'%c\',%i,\'%c\',\"%s\",%i,%i,%i,%i,%i,%f,%f,\
					 %i,%i,%i,\"%s\",\"%s\",%i ,%i,\'%c\',\"%s\",\
					 %i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,%i,%i,%i,\'%c\',%i,%f,\
					 \"%s\",%i,\'%c\',%ld,%i,\"%s\",\"%s\",\"%s\" ,\'%c\',\"%s\" , \"%s\" ,%f,\
					 \"%s\" ,now(),\"%s\",\"%s\",\'%c\',\"%s\",\'%c\',%f,\'%c\',\'%c\',\"%s\")",fOrdNo,iTempOrdSerialNo,iMultiOrdtype,iLegno,sSecId,sExchId, \
					cSegmnt,sEntityId,sExchOrdNo,sClientId,\
					cBuySell,iMsgCode,cOrdStatus,sEntryDate,iTotlQty,iRemQty,iDisQty,iDiscQtyRemaning,itotalTrdQty,fOrdPrice,fTrigerPrice,\
					iValidity,iOrdType,iGoodTilDays,sGoodTillDate,sAccCode,iUserId,iMinFilQty,cProCil,sRemarks,\
					iErrorCode,cSourceFlag,cOrdOfOn,cProdId,sLocCode,iGrpId,iReasonCode,iTrdExchtrdNo,(iTempOrdSerialNo * -1),iTrdTrnsCode,cTrdStatus,iLstTrdQty,fTradePrice,\
					sTrdTime,iTrdSeqNo,cHndleInst,lAlgoOrderNo,iStratergyId,sClOrdId,sOriClordId,sSymbol,cUserType,sInsrtuName,sExpiry,fStrikePrice,\
					sOptionType,sReasonDesc,sPanNo,cParticipantType,sSettlor,cMarkProFlag,fMarkProVal,cGTCFlag,cEncashFlag,sSmExpiryFlag);

			logDebug2("InsQuery :%s: ",sInsQuery);

			if(mysql_query(DB_Con,sInsQuery) != SUCCESS)
			{
				sql_Error(DB_Con);
				logSqlFatal("Error in inserting DRV_ORDERS_TABLE [DROrdDBOp] ");
				return FALSE;
			}
			else
			{
				logDebug2("Inserted ");
				logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
				mysql_commit(DB_Con);
			}
			pResp->iOrderType = iOrdType;
			pResp->iOrderValidity = iValidity;
			pResp->iDiscQty= iDisQty;
			pResp->iDiscQtyRem= iDiscQtyRemaning;
			pResp->iTotalQtyRem= iRemQty;
			pResp->iTotalQty= iTotlQty;
			pResp->iLastTradedQty= iOrdType;
			pResp->iTotalTradedQty= itotalTrdQty;
			pResp->iMinFillQty= iMinFilQty;
			pResp->fPrice= fOrdPrice;
			pResp->fTriggerPrice= fTrigerPrice;
			pResp->fTradePrice= fTradePrice;
			pResp->iSerialNum = iTempOrdSerialNo;
		}
	}
	return TRUE;
}


BOOL    fNseMCXRMSRejInsert(struct INT_ORDERS *pInt_Req,struct ORDER_RESPONSE *pResp,CHAR *sErrorID)
{
        logTimestamp("ENTRY [fNseMCXRMSRejInsert]");
        CHAR            sMktType[MKT_TYPE_LEN];
        memset(sMktType,'\0',MKT_TYPE_LEN);
        LONG32  iErrorCode = 0;
        CHAR sInsQuery [MAX_QUERY_SIZE];
        CHAR    SelQry[MAX_QUERY_SIZE];
        BOOL    ChkFlag =FALSE;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        memset(sInsQuery,'\0',MAX_QUERY_SIZE);

        CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);

        strncpy(sTempSettlor,pInt_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));



        LONG32  tmpOrdSerialNo = 0;
        LONG32  iTempOrdSerialNo = 0;
        LONG32  iMultiOrdtype = 0;
        LONG32  iLegno = 0;
        BOOL    iReqFlag = FALSE;

        DOUBLE64 fTriggerPrice = 0.00;
        LONG32  iTempMsgCode = 0,iNoOfRec;
        LONG32 iTotlQty = 0;
        LONG32 iRemQty = 0;
        LONG32 iDisQty = 0;
        LONG32 iDiscQtyRemaning = 0;
        LONG32 itotalTrdQty = 0;
        LONG32 iValidity = 0;
        LONG32 iOrdType = 0;
        LONG32 iGoodTilDays = 0;
        LONG32 iMinFilQty = 0;
        LONG32 iGrpId = 0;
        LONG32 iReasonCode = 0;
        LONG32 iTrdExchtrdNo = 0;
        LONG32 itrdSerialNo = 0;
	LONG32 iTrdTrnsCode = 0;
        LONG32 iLstTrdQty = 0;
        LONG32 iTrdSeqNo = 0;
        LONG32 iStratergyId = 0;
        LONG32 iUserId = 0;
        LONG32 iMsgCode = 0;
        CHAR    cSegmnt =       '\0';
        CHAR    cBuySell=       '\0';
        CHAR    cProCil =       '\0';
        CHAR    cSourceFlag     =       '\0';
        CHAR    cOrdOfOn        =       '\0';
        CHAR    cProdId         =       '\0';
        CHAR    cTrdStatus      =       '\0';
        CHAR    cOrdStatus      =       '\0';
        CHAR    cHndleInst      =       '\0';
        CHAR    cUserType       =       '\0';
        CHAR    cTempStatus     =       '\0';
        CHAR    cParticipantType=       '\0';
        CHAR    cGTCFlag        =       '\0';
        CHAR    cEncashFlag     =       '\0';
        CHAR    cCrossCurFlag   =       '\0';
        CHAR    cMarkProFlag    =       '\0';

         DOUBLE64        fMarkProVal =0.00;
        DOUBLE64        fRBIRefRate =0.00;

        DOUBLE64 fOrdNo = 0.00 ;
        DOUBLE64 fOrdPrice = 0.00 ;
        DOUBLE64 fTradePrice = 0.00 ;
        DOUBLE64 fSelectClOrdId = 0.00 ;
        DOUBLE64        fTrigerPrice = 0.00 ;
        DOUBLE64        fStrikePrice =0.00;

        LONG64 lAlgoOrderNo ;

        CHAR    sSecId          [DB_SECURITY_ID_LEN];
        CHAR    sSymbol         [DB_SYM_LEN];
        CHAR    sEntityId       [DB_ENTITY_ID_LEN];
        CHAR    sExchOrdNo      [DB_EXCH_ORD_NO_LEN];
        CHAR    sClientId       [DB_CLIENT_ID_LEN];
        CHAR    sEntryDate      [DB_DATETIME_LEN];
        CHAR    sExchOrdTime    [DB_DATETIME_LEN];
	CHAR    sGoodTillDate   [DB_DATETIME_LEN];
        CHAR    sAccCode        [DB_ACC_CODE_LEN];
        CHAR    sRemarks        [DB_REMARKS_LEN];
        CHAR    sLocCode        [LOC_CODE_LEN];
        CHAR    sTrdTime        [DB_DATETIME_LEN];
        CHAR    sClOrdId        [CLORDID_LEN];
        CHAR    sOriClordId     [CLORDID_LEN];
        CHAR    sExchId         [EXCHANGE_LEN];
        CHAR    sInsrtuName     [DB_INSTRU_LEN];
        CHAR    sExpiry         [DB_DATETIME_LEN];
        CHAR    sOptionType     [DB_OPT_TYPE_LEN];
        CHAR    sReasonDesc     [DB_REASON_DESC_LEN];
        CHAR    sPanNo          [INT_PAN_LEN];
        CHAR    sSettlor        [SETTLOR_LEN];
	CHAR	sSeries		[DB_SERIES_LEN];
	CHAR    sSmExpiryFlag        [DB_EXPIRY_FLAG_LEN];

        memset(sSecId,'\0',DB_SECURITY_ID_LEN);
        memset(sSymbol,'\0',DB_SYM_LEN);
        memset(sEntityId,'\0',DB_ENTITY_ID_LEN);
        memset(sExchOrdNo,'\0',DB_EXCH_ORD_NO_LEN);
        memset(sClientId,'\0',DB_CLIENT_ID_LEN);
        memset(sEntryDate,'\0',DB_DATETIME_LEN);
        memset(sExchOrdTime,'\0',DB_DATETIME_LEN);
        memset(sGoodTillDate,'\0',DB_DATETIME_LEN);
        memset(sAccCode,'\0',DB_ACC_CODE_LEN);
        memset(sRemarks,'\0',DB_REMARKS_LEN);
        memset(sLocCode,'\0',LOC_CODE_LEN);
        memset(sTrdTime,'\0',DB_DATETIME_LEN);
        memset(sReasonDesc,'\0',DB_REASON_DESC_LEN);
        memset(sClOrdId,'\0',CLORDID_LEN);
        memset(sOriClordId,'\0',CLORDID_LEN);
        memset(sExchId,'\0',EXCHANGE_LEN);
        memset(sInsrtuName,'\0',DB_INSTRU_LEN);
        memset(sExpiry ,'\0',DB_DATETIME_LEN);
        memset(sOptionType,'\0',DB_OPT_TYPE_LEN);
        memset(sPanNo,'\0',INT_PAN_LEN);
        memset(sSettlor,'\0',SETTLOR_LEN);
	memset(sSeries,'\0',DB_SERIES_LEN);
	memset(sSmExpiryFlag,'\0',DB_EXPIRY_FLAG_LEN);

        if(GetMktType(&sMktType,pInt_Req->iMktType)!=TRUE)
        {
                logDebug2("Error in fetching iMktType");
                return FALSE;
        }
	logDebug2("Inside sErrorID :%s:",sErrorID);
        if(strncmp(ORDER_IN_TRANSIT,sErrorID,10) == 0)
        {
                cTempStatus = TRANSIT_STATUS;
        }
        else
        {
                cTempStatus = EXCH_CONFIRM_STATUS;
        }

        logDebug3("pResp->sReasonDesc :%s:",pResp->sReasonDesc);

        sprintf(sInsQuery,"INSERT INTO COMM_ORDERS \
                        (COMM_ORDER_NO,COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,COMM_SCRIP_CODE,COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,\
                         COMM_EXCH_ORDER_NO,COMM_CLIENT_ID,COMM_BUY_SELL_IND,COMM_MSG_CODE,COMM_STATUS,COMM_INTERNAL_ENTRY_DATE,COMM_TOTAL_QTY,\
                         COMM_REM_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY, COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_VALIDITY,\
                         COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS,COMM_GOOD_TILL_DATE,COMM_ACC_CODE,COMM_USER_ID,COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,\
                         COMM_REMARKS,COMM_ERROR_CODE,COMM_SOURCE_FLG,COMM_ORDER_OFFON,COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,COMM_REASON_CODE,\
                         COMM_REASON_DESCRIPTION,COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,\
                         COMM_TRD_TRADE_PRICE,COMM_TRD_TRADE_TIME,COMM_TRD_SEQ_NO, COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,COMM_STRATEGY_ID,\
                         COMM_CLORDID,COMM_ORIG_CLORDID,COMM_SYMBOL,COMM_USER_TYPE,COMM_INSTRUMENT_NAME,COMM_EXPIRY_DATE,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MKT_TYPE,\
                        COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_EXPIRY_FLAG) \
                        VALUES \
                        (%f,%i,\"0\",\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',\
                         NOW(),%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\
                         \"%s\",\"%s\",%i,%i,\'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
                         \"%s\",%i,%i,%i,\'%c\',%i,%f,\"%s\",%i,\'%c\',%f,%i,\"%s\",\"%s\"\,\"%s\"\,\'%c\',\"%s\",\
                         STR_TO_DATE(\"%s\",\'%%Y%%m%%d'),%f,\"%s\",\"%s\",\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\" ,\"%s\"\
                        )",\
                        pInt_Req->fOrdNo,pInt_Req->iSerialNo,pInt_Req->sSecId,pInt_Req->ReqHeader.sExcgId,pInt_Req->ReqHeader.cSegment,\
                        pInt_Req->sEntityId,pInt_Req->sExchOrdNo,pInt_Req->sClientId,pInt_Req->cBuySellInd,pInt_Req->ReqHeader.iMsgCode,\
                        EXCH_REJECT_STATUS,pInt_Req->iRemQty + pInt_Req->iTotalTradedQty ,pInt_Req->iRemQty,pInt_Req->iDiscQty,\
                        pInt_Req->iDiscRemQty,pInt_Req->iTotalTradedQty,pInt_Req->fOrderPrice,pInt_Req->fTriggerPrice,pInt_Req->iValidity,\
                        pInt_Req->iOrderType,pInt_Req->iGoodTillDaysFlg,pInt_Req->sGoodTillDaysDate,pInt_Req->sAccCode,\
                        pInt_Req->ReqHeader.iUserId,pInt_Req->iMinFillQty,pInt_Req->cProClient,pInt_Req->sRemarks,iErrorCode,\
                        pInt_Req->ReqHeader.cSource,pInt_Req->cOrderOffOn,pInt_Req->cProductId,pInt_Req->sLocCode,pInt_Req->iGrpId,\
                        pInt_Req->iReasonCode,pResp->sReasonDesc,pInt_Req->iExchTrdNo,(pInt_Req->iSerialNo * -1),pInt_Req->iTrdTransCode,\
                        pInt_Req->cTrdStatus,pInt_Req->iLstTrdQty,pInt_Req->fTrdPrice,pInt_Req->sTrdTime,pInt_Req->iTrdSeqNo,\
                        pInt_Req->cHandleInst,pInt_Req->fAlgoOrderNo,pInt_Req->iStratergyId,pInt_Req->sClOrdId, pInt_Req->sOrigClOrdId,\
                        pInt_Req->sSymbolName,pInt_Req->cUserType,pInt_Req->sInstrumentType,pInt_Req->sMaturityMonYr,pInt_Req->fStrikePrice,\
                        pInt_Req->sOptType,sMktType,pInt_Req->sPanNo,pInt_Req->cParticipantType,sTempSettlor,pInt_Req->cMarkProFlag,pInt_Req->fMarkProVal,\
                        pInt_Req->cGTCFlag,pInt_Req->cEncashFlag,pInt_Req->sSeries ,pInt_Req->sSmExpiryFlag);
        logDebug2("InsQuery :%s: ",sInsQuery);
	
	if(mysql_query(DB_Con,sInsQuery) != SUCCESS)
        {
                sql_Error(DB_Con);
                logSqlFatal("Error in inserting COMM_ORDERS_TABLE [COMMOrdDBOp] ");
                return FALSE;
        }
        else
        {
                logDebug2("Inserted ");
                logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
                mysql_commit(DB_Con);
        }


        if (pInt_Req->ReqHeader.iMsgCode != TC_INT_RMS_OE_REJECTION && pInt_Req->ReqHeader.iMsgCode != TC_INT_OE_REJECTION)
        {
                memset( SelQry, '\0',  MAX_QUERY_SIZE);
                sprintf(SelQry,"SELECT \
                                COMM_ORDER_NO,COMM_MULTILEG_ORD_TYPE,\
                                COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
                                COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,COMM_INTERNAL_ENTRY_DATE ,\
                               	COMM_TOTAL_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
                                COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
                                COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
                                COMM_REMARKS, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
                                COMM_GROUP_ID, COMM_REASON_CODE, COMM_TRD_EXCH_TRADE_NO,\
                                COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
                                COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME, COMM_TRD_SEQ_NO, COMM_HANDLE_INST, \
                                COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,COMM_SYMBOL,\
                                COMM_USER_TYPE,COMM_INSTRUMENT_NAME,COMM_EXPIRY_DATE,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_STATUS,COMM_MSG_CODE,COMM_REM_QTY, \
                                COMM_REASON_DESCRIPTION ,COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_EXPIRY_FLAG\
                                FROM COMM_ORDERS WHERE \
                                COMM_ORDER_NO = \'%f\' AND COMM_SERIAL_NO = (SELECT MAX(COMM_SERIAL_NO) -1  FROM COMM_ORDERS WHERE COMM_ORDER_NO = \'%f\' \
                                        AND COMM_LEG_NO = %d)  AND COMM_LEG_NO = %d ;",pInt_Req->fOrdNo,pInt_Req->fOrdNo,pInt_Req->iLegValue,pInt_Req->iLegValue);

                //                DRV_ORDER_NO = \'%f\' AND DRV_SERIAL_NO = %i AND DRV_LEG_NO = %d ;",pInt_Req->fOrdNo,pInt_Req->iSerialNo - 1,pInt_Req->iLegValue);
                logDebug2("SelQry :%s:",SelQry);
                if(mysql_query(DB_Con,SelQry) != SUCCESS)
                {
                        logSqlFatal("----ERROR IN  SUCCESS QUERY [fDBSelectOrd] -----");
                        sql_Error(DB_Con);
                }
		else
                {
                        mysql_commit(DB_Con);
                        logDebug2("------SUCCESS IN  SUCCESS QUERY-----");
                }
                Res = mysql_store_result(DB_Con);

                iNoOfRec = mysql_num_rows(Res);
                if (iNoOfRec !=0)
                {
                        if(Row=mysql_fetch_row(Res))
                        {
                                fOrdNo = atof(Row[0]);
                                iMultiOrdtype = atoi(Row[1]);
                                iLegno = atoi(Row[2]);
                                strncpy(sSecId,Row[3],DB_SECURITY_ID_LEN);
                                strncpy(sExchId,Row[4],DB_EXCH_ID_LEN);
                                cSegmnt = Row[5][0];

                                strncpy(sEntityId,Row[6],DB_ENTITY_ID_LEN);
                                strncpy(sExchOrdNo,Row[7],DB_EXCH_ORD_NO_LEN);
                                strncpy(sClientId,Row[8],DB_CLIENT_ID_LEN);
                                cBuySell = Row[9][0];

                                strncpy(sEntryDate,Row[10],DB_DATETIME_LEN);
                                iTotlQty  = atoi(Row[11]);
                                iDisQty  = atoi(Row[12]);
                                iDiscQtyRemaning  = atoi(Row[13]);
                                itotalTrdQty  = atoi(Row[14]);
                                fOrdPrice  = atof(Row[15]);
                                fTrigerPrice  = atof(Row[16]);
                                iValidity = atoi(Row[17]);
                                iOrdType = atoi(Row[18]);
                                iGoodTilDays    = atoi(Row[19]);
                                strncpy(sGoodTillDate,Row[20],DB_DATETIME_LEN);
                                strncpy(sAccCode,Row[21],DB_ACC_CODE_LEN);
                                //strncpy(sUserId,Row[22],DB_USER_CODE_LEN);
                                iUserId = atoi(Row[22]);
                                iMinFilQty = atoi(Row[23]);
                                cProCil = Row[24][0];
                                strncpy(sRemarks,Row[25],DB_REMARKS_LEN);
                                cSourceFlag  = Row[26][0];
                                cOrdOfOn = Row[27][0];
				cProdId = Row[28][0];
                                strncpy(sLocCode,Row[29],DB_LOC_LEN);
                                iGrpId  = atoi(Row[30]);
                                iReasonCode = atoi(Row[31]);
                                iTrdExchtrdNo = atoi(Row[32]);
                                itrdSerialNo = iTempOrdSerialNo * -1;//atoi(Row[33]);
                                iTrdTrnsCode = atoi(Row[34]);
                                cTrdStatus = Row[35][0];
                                iLstTrdQty = atoi(Row[36]);
                                fTradePrice = atof(Row[37]);
                                strncpy(sTrdTime,Row[38],DB_DATETIME_LEN);
                                iTrdSeqNo = atoi(Row[39]);
                                cHndleInst = Row[40][0];
                                lAlgoOrderNo = atol(Row[41]);
                                iStratergyId = atoi(Row[42]);
                                strncpy(sClOrdId,Row[43],DB_CLORDID_LEN);
                                strncpy(sOriClordId,Row[44],DB_CLORDID_LEN);
                                strncpy(sSymbol,Row[45],DB_SYM_LEN);
                                cUserType = Row[46][0];
                                strncpy(sInsrtuName,Row[47],DB_INSTRU_LEN);
                                strncpy(sExpiry,Row[48],DB_DATETIME_LEN);
                                fStrikePrice = atof(Row[49]);
                                strncpy(sOptionType,Row[50],DB_OPT_TYPE_LEN);
                                //                              fLotSiz = atof(Row[51]);
                                //                                strncpy(sExchOrdTime,Row[51],DB_DATETIME_LEN);
                                cOrdStatus = Row[51][0];
                                iMsgCode = atoi(Row[52]);
                                iRemQty = atoi(Row[53]);
                                iTempOrdSerialNo= pInt_Req->iSerialNo + 1;
                                strncpy(sReasonDesc,Row[54],DB_DATETIME_LEN);

                                strncpy(sPanNo,Row[55],INT_PAN_LEN);
                                cParticipantType= Row[56][0];
                                strncpy(sSettlor,Row[57],SETTLOR_LEN);
                                cMarkProFlag= Row[58][0];
                                fMarkProVal= atoi(Row[59]);

                                cGTCFlag= Row[60][0];
                                cEncashFlag= Row[61][0];
                                strncpy(sSeries,Row[62],DB_SERIES_LEN);
				strncpy(sSmExpiryFlag,Row[63],DB_EXPIRY_FLAG_LEN);
				
                        }

                        memset(sInsQuery,'\0',MAX_QUERY_SIZE);
                        logDebug2("cSegmnt = :%c:",cSegmnt);
			logDebug2("cBuySell = :%c:",cBuySell);

                        sprintf(sInsQuery,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
                                COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
                                COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
                                COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
                                COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
                                COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
                                COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
                                COMM_GROUP_ID, COMM_REASON_CODE,  COMM_TRD_EXCH_TRADE_NO,\
                                COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
                                COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME, COMM_TRD_SEQ_NO, COMM_HANDLE_INST, \
                                COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,COMM_SYMBOL,\
                                COMM_USER_TYPE,COMM_INSTRUMENT_NAME,COMM_EXPIRY_DATE,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_EXCH_ORDER_TIME,COMM_REASON_DESCRIPTION,\
                                COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_EXPIRY_FLAG)\
                                        VALUES \
                                        (%f,%i,%i,%d,\"%s\",\"%s\" ,\
                                         \'%c\',\"%s\",\"%s\",\"%s\" ,\
                                         \'%c\',%i,\'%c\',\"%s\",%i,%i,%i,%i,%i,%f,%f,\
                                         %i,%i,%i,\"%s\",\"%s\",%i ,%i,\'%c\',\"%s\",\
                                         %i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,%i,%i,%i,\'%c\',%i,%f,\
                                         \"%s\",%i,\'%c\',%ld,%i,\"%s\",\"%s\",\"%s\" ,\'%c\',\"%s\" , \"%s\" ,%f,\
                                         \"%s\" ,now(),\"%s\",\"%s\",\'%c\',\"%s\",\'%c\',%f,\'%c\',\'%c\',\"%s\",\"%s\")",fOrdNo,iTempOrdSerialNo,iMultiOrdtype,iLegno,sSecId,sExchId, \
                                        cSegmnt,sEntityId,sExchOrdNo,sClientId,\
                                        cBuySell,iMsgCode,cOrdStatus,sEntryDate,iTotlQty,iRemQty,iDisQty,iDiscQtyRemaning,itotalTrdQty,fOrdPrice,fTrigerPrice,\
                                        iValidity,iOrdType,iGoodTilDays,sGoodTillDate,sAccCode,iUserId,iMinFilQty,cProCil,sRemarks,\
                                        iErrorCode,cSourceFlag,cOrdOfOn,cProdId,sLocCode,iGrpId,iReasonCode,iTrdExchtrdNo,(iTempOrdSerialNo * -1),iTrdTrnsCode,cTrdStatus,iLstTrdQty,fTradePrice,\
                                        sTrdTime,iTrdSeqNo,cHndleInst,lAlgoOrderNo,iStratergyId,sClOrdId,sOriClordId,sSymbol,cUserType,sInsrtuName,sExpiry,fStrikePrice,\
                                        sOptionType,sReasonDesc,sPanNo,cParticipantType,sSettlor,cMarkProFlag,fMarkProVal,cGTCFlag,cEncashFlag,sSeries,sSmExpiryFlag);

                        logDebug2("InsQuery :%s: ",sInsQuery);

                        if(mysql_query(DB_Con,sInsQuery) != SUCCESS)
                        {
                                sql_Error(DB_Con);
                                logSqlFatal("Error in inserting COMM_ORDERS_TABLE [COMMOrdDBOp] ");
                                return FALSE;
                        }
                        else
                        {
				logDebug2("Inserted ");
                                logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
                                mysql_commit(DB_Con);
                        }
                        pResp->iOrderType = iOrdType;
                        pResp->iOrderValidity = iValidity;
                        pResp->iDiscQty= iDisQty;
                        pResp->iDiscQtyRem= iDiscQtyRemaning;
                        pResp->iTotalQtyRem= iRemQty;
                        pResp->iTotalQty= iTotlQty;
                        pResp->iLastTradedQty= iOrdType;
                        pResp->iTotalTradedQty= itotalTrdQty;
                        pResp->iMinFillQty= iMinFilQty;
                        pResp->fPrice= fOrdPrice;
                        pResp->fTriggerPrice= fTrigerPrice;
                        pResp->fTradePrice= fTradePrice;
                        pResp->iSerialNum = iTempOrdSerialNo;
                }
        }
        return TRUE;

}

BOOL    fFetchMCXSerialNo(struct INT_ORDERS *Int_Req)
{
        logTimestamp("fFetchMCXSerialNo [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        CHAR *statement = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

        logDebug3("Before Fetch Serial No");
        //logDebug2("Int_Req->fOrdNo:%lf",Int_Req->fOrdNo);
        //logDebug2("Int_Req->fOrdNo:%lf",Int_Req->fOrdNo);
        sprintf(statement,"SELECT COMM_SERIAL_NO,COMM_EXCH_ORDER_NO,COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_REM_QTY,\
                        COMM_STATUS,COMM_CLORDID,DATE_FORMAT(COMM_INTERNAL_ENTRY_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),COMM_TRD_TRADE_QTY,COMM_TOTAL_TRADED_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_VALIDITY,COMM_TRD_TRADE_PRICE,COMM_PAN_NO, COMM_EXPIRY_FLAG,COMM_MSG_CODE \
                        FROM COMM_ORDERS \
                        WHERE COMM_SERIAL_NO = (SELECT MAX(COMM_SERIAL_NO) FROM COMM_ORDERS WHERE COMM_ORDER_NO = %lf) AND COMM_ORDER_NO = %lf;",Int_Req->fOrdNo,Int_Req->fOrdNo);

        logDebug2("\n%s\n",statement);

        if(mysql_query(DB_Con,statement) != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);

        while((Row = mysql_fetch_row(Res)))
        {
                logDebug2("printing serial no Int_Req->iSerialNo :%d: atoi(Row[0]) :%d:",Int_Req->iSerialNo,atoi(Row[0]));
		strncpy(Int_Req->sSmExpiryFlag,Row[15],DB_EXPIRY_FLAG_LEN);
                strncpy(Int_Req->sPanNo,Row[14],INT_PAN_LEN);
                if(Int_Req->iSerialNo == atoi(Row[0]) + 1  )
                {
                        logDebug3("Serial Check OK");
                        logDebug3("CR_ORD_STATUS : %c",Row[5][0]);

			if(atoi(Row[16]) == TC_INT_OE_CONF_RESP || atoi(Row[16]) == TC_INT_OM_CONF_RESP || atoi(Row[16]) == TC_INT_OC_CONF_RESP)
                        {
                                logFatal("This order %f  is Offline Order and trying to cancel or Modify as normal order.Error from source :%c:",Int_Req->fOrdNo,Int_Req->ReqHeader.cSource);
                                return ONLINE_INVALID_STATUS ;
                        }



                        //                        if(Row[5][0] == 'E')
                        if((Row[5][0] == EXCH_REJECT_STATUS) || (Row[5][0] == TRADED_STATUS) || (Row[5][0] == TRANSIT_STATUS) || \
                                        (Row[5][0] == EXCH_DELETE_STATUS) || (Row[5][0] == EXCH_FREEZE_STATUS) || (Row[5][0] == EXPIRED_STATUS) )
                        {
                                logDebug3("Order Still in Transit");
          			mysql_free_result(Res);
                                switch(Row[5][0])
                                {
                                        case TRANSIT_STATUS:
                                                return RET_TRANSIT_STAT;
                                        case TRADED_STATUS :
                                                return RET_TRADED_STAT;
                                        case EXCH_REJECT_STATUS:
                                        case EXCH_DELETE_STATUS:
                                        case EXPIRED_STATUS:
                                        case EXCH_FREEZE_STATUS:
                                                return RET_CANCEL_STAT;

                                }

                        }
                        else
                        {
                                strncpy(Int_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
                                strncpy(Int_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
                                logDebug3("sOrigClOrdId : %s",Int_Req->sOrigClOrdId);

                                if(Int_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
                                {
                                        logDebug3("Modification Order");
                                        strncpy(Int_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
                                        logDebug3("[6000] sLastModTime : %s",Int_Req->sLastModTime);
                                        Int_Req->iTotalTradedQty = atoi(Row[9]);
                                        Int_Req->iLstTrdQty = atoi(Row[8]);
                                        Int_Req->fTrdPrice = atof(Row[13]);
                                        if(Int_Req->fOrderPrice != atof(Row[2]) || Int_Req->fTriggerPrice != atof(Row[3]) || Int_Req->iTotalQty != atoi(Row[4]) ||  \
                                                        Int_Req->iDiscQty != atoi(Row[10])  || Int_Req->iDiscRemQty != atoi(Row[11]) || Int_Req->iValidity != atoi(Row[12]))
                                        {
                                                logDebug3("Modify Success");
                                                mysql_free_result(Res);
                                                return TRUE;
                                        }
                                        else
                                        {
                                                logDebug3("Nothing to Modify");
                                                mysql_free_result(Res);
                                                fSendErrorToFE(Int_Req,NOTHING_TO_MODIFY,Int_Req->iTotalQty,Int_Req->fOrderPrice);
						return NO_MODIFICATION;
                                        }
                                }
                                else
                                {
                                        mysql_free_result(Res);
                                        Int_Req->iTotalTradedQty = atoi(Row[9]);
                                        Int_Req->fTrdPrice = atof(Row[13]);
                                        Int_Req->iLstTrdQty = atoi(Row[8]);
                                        Int_Req->iRemQty = atoi(Row[4]);
                                        Int_Req->iTotalQty = Int_Req->iRemQty;
                                        logDebug3("Cancellation Order");
                                        return TRUE;
                                }
                        }
                }
                else
                {
                        logDebug3("Serial check Not ok");
                        mysql_free_result(Res);
                        if(Row[5][0] == TRADED_STATUS)
                        {
                                logDebug2("Serial check Not OK.Order Is Traded");
                                return RET_TRADED_STAT;

                        }
                        else
                        {
                                Int_Req->iSerialNo = atoi(Row[0]) + 1;
                                logDebug2("Serial check Not OK");
                                return FALSE;
                        }

                }

        }
        logTimestamp(" EXIT [fFetchMCXSerialNo]");
}


BOOL NSEMCXInsert(struct INT_ORDERS *Ins_Req)
{
        logTimestamp("NSEMCXInsert[ENTRY]");
        CHAR *statement1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR            sMktType[MKT_TYPE_LEN];
        CHAR symbolName [DB_SYM_LEN];
        memset(symbolName,'\0',DB_SYM_LEN);
        memset(sMktType,'\0',MKT_TYPE_LEN);
        CHAR            sTempSettlor[SETTLOR_LEN];
        memset(sTempSettlor,'\0',SETTLOR_LEN);
        if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
        {
                logDebug2("Error in fetching iMktType");
                return FALSE;
        }
        strncpy(sTempSettlor,Ins_Req->sSettlor,SETTLOR_LEN);

        fTrim(sTempSettlor,strlen(sTempSettlor));

        logDebug2("Ins_Req->sSymbolName:%s:",Ins_Req->sSymbolName);
        strncpy(symbolName,Ins_Req->sSymbolName,DB_SYM_LEN);
        logDebug2("Priyanka [%s]",symbolName);
        logDebug2("THIS is test");
        logDebug3("iSeqNo - %d", Ins_Req->ReqHeader.iSeqNo);
        logDebug3("iMsgLength - %d", Ins_Req->ReqHeader.iMsgLength);
        logDebug3("iMsgCode - %d", Ins_Req->ReqHeader.iMsgCode);
        logDebug3("sExcgId - %s", Ins_Req->ReqHeader.sExcgId);
        logDebug3("iUserId - %d", Ins_Req->ReqHeader.iUserId);
        logDebug3("cSource - %c",Ins_Req->ReqHeader.cSource);
        logDebug3("cSegment - %c", Ins_Req->ReqHeader.cSegment);
        logDebug3("iOrdNo - %d", Ins_Req->fOrdNo);
        logDebug3("iSerialNo - %d", Ins_Req->iSerialNo);
        logDebug3("sSecId - %s", Ins_Req->sSecId);
        logDebug3("sEntityId - %s", Ins_Req->sEntityId);
        logDebug3("sExchOrdNo - %s", Ins_Req->sExchOrdNo);
        logDebug3("sClientId - %s", Ins_Req->sClientId);
        logDebug3("cBuySellInd - %c", Ins_Req->cBuySellInd);
        logDebug3("cOrdStatus - %c", Ins_Req->cOrdStatus);
        logDebug3("sEntryDate - %s", Ins_Req->sEntryDate);
        logDebug3("sOrderTime - %s", Ins_Req->sOrderTime);
        logDebug3("iTotalQty - %d", Ins_Req->iTotalQty);
        logDebug3("iRemQty - %d", Ins_Req->iRemQty);
        logDebug3("iDiscQty - %d", Ins_Req->iDiscQty);
 	logDebug3("iDiscRemQty - %d", Ins_Req->iDiscRemQty);
        logDebug3("iTotalTradedQty - %d", Ins_Req->iTotalTradedQty);
        logDebug3("fOrderPrice - %f", Ins_Req->fOrderPrice);
        logDebug3("fTriggerPrice - %f", Ins_Req->fTriggerPrice);
        logDebug3("iValidity - %d", Ins_Req->iValidity);
        logDebug3("iOrderType - %d", Ins_Req->iOrderType);
        logDebug3("iGoodTillDaysFlg - %d", Ins_Req->iGoodTillDaysFlg);
        logDebug3("sGoodTillDaysDate - %s", Ins_Req->sGoodTillDaysDate);
        logDebug3("sAccCode - %s",Ins_Req->sAccCode);
        logDebug3("iMinFillQty - %d", Ins_Req->iMinFillQty);
        logDebug3("cProClient - %c", Ins_Req->cProClient);
        logDebug3("sRemarks - %s", Ins_Req->sRemarks);
        logDebug3("iErrorCode - %d", Ins_Req->iErrorCode);
        logDebug3("cUserType - %c", Ins_Req->cUserType);
        logDebug3("cOrderOffOn - %c", Ins_Req->cOrderOffOn);
        logDebug3("cProductId - %c", Ins_Req->cProductId);
        logDebug3("sUserInfo - %s", Ins_Req->sUserInfo);
        logDebug3("iGrpId - %d", Ins_Req->iGrpId);
        logDebug3("iReasonCode - %d", Ins_Req->iReasonCode);
        logDebug3("sReasonDesc - %s", Ins_Req->sReasonDesc);
        logDebug3("iExchTrdNo - %d", Ins_Req->iExchTrdNo);
        logDebug3("iTrdSerialNo - %d", Ins_Req->iTrdSerialNo);
        logDebug3("iTrdTransCode - %d", Ins_Req->iTrdTransCode);
        logDebug3("cTrdStatus - %c", Ins_Req->cTrdStatus);
        logDebug3("iLstTrdQty - %d", Ins_Req->iLstTrdQty);
        logDebug3("fTrdPrice - %f", Ins_Req->fTrdPrice);
        logDebug3("sTrdTime - %s", Ins_Req->sTrdTime);
        logDebug3("iTrdSeqNo - %d", Ins_Req->iTrdSeqNo);
        logDebug3("cHandleInst - %c", Ins_Req->cHandleInst);
        logDebug3("fAlgoOrderNo - %f", Ins_Req->fAlgoOrderNo);
        logDebug3("iStratergyId - %d", Ins_Req->iStratergyId);
        logDebug3("sClOrdId - %s", Ins_Req->sClOrdId);
        logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
        logDebug3("sMaturityMonYr - %s", Ins_Req->sMaturityMonYr);
        logDebug3("sMktType:%s",sMktType);

        logDebug2("Ins_Req->sPanNo :%s:",Ins_Req->sPanNo);
        logDebug2("Ins_Req->sSettlor    :%s:",Ins_Req->sSettlor);
        logDebug2("sTempSettlor - :%s:",sTempSettlor);
        logDebug2("Ins_Req->iLegValue- %d", Ins_Req->iLegValue);
        logDebug2("Ins_Req->iAlgoID :%d:",Ins_Req->iAlgoID);
        logDebug2("Ins_Req->iAlgoCat    :%d:",Ins_Req->iAlgoCat);
	logDebug2("Ins_Req->cCrossCurFlag       :%c:",Ins_Req->cCrossCurFlag);
        logDebug2("Ins_Req->fRBIRefRate :%lf:",Ins_Req->fRBIRefRate);
        logDebug2("Ins_Req->cMarkProFlag        :%c:",Ins_Req->cMarkProFlag);
        logDebug2("Ins_Req->fMarkProVal :%lf:",Ins_Req->fMarkProVal);
        logDebug2("Ins_Req->cParticipantType    :%c:",Ins_Req->cParticipantType);
        logDebug2("Ins_Req->cGTCFlag    :%c:",Ins_Req->cGTCFlag);
        logDebug2("Ins_Req->cEncashFlag :%c:",Ins_Req->cEncashFlag);
        Ins_Req->iTrdSerialNo = (Ins_Req->iSerialNo * -1);
        logDebug2("Ins_Req->iTrdSerialNo :%d:",Ins_Req->iTrdSerialNo);
        logDebug2("sSeries - :%s:",Ins_Req->sSeries);
	logDebug3("sCustomSym :%s:",Ins_Req->sCustomSym);
	logDebug3("fLotSize :%f:",Ins_Req->fLotSize);
	logDebug3("fTickSize :%f:",Ins_Req->fTickSize);
	logDebug3("sInstrumentTyp :%s:",Ins_Req->sInstrumentTyp);
	logDebug3("fLTP :%s:",Ins_Req->fLtp);
	logDebug2("Ins_Req->sSmExpiryFlag   :%s:",Ins_Req->sSmExpiryFlag)                 ;
        logDebug3("END");

        sprintf(statement1,"INSERT INTO COMM_ORDERS \
                        (COMM_ORDER_NO,COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,COMM_LEG_NO,COMM_SCRIP_CODE,COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,\
                         COMM_EXCH_ORDER_NO,COMM_CLIENT_ID,COMM_BUY_SELL_IND,COMM_MSG_CODE,COMM_STATUS,COMM_INTERNAL_ENTRY_DATE,COMM_TOTAL_QTY,\
                         COMM_REM_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY, COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_VALIDITY,\
                         COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS,COMM_GOOD_TILL_DATE,COMM_ACC_CODE,COMM_USER_ID,COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,\
                         COMM_REMARKS,COMM_ERROR_CODE,COMM_SOURCE_FLG,COMM_ORDER_OFFON,COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,COMM_REASON_CODE,\
                         COMM_REASON_DESCRIPTION,COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,\
                         COMM_TRD_TRADE_PRICE,COMM_TRD_TRADE_TIME,COMM_TRD_SEQ_NO, COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,COMM_STRATEGY_ID,\
                         COMM_CLORDID,COMM_ORIG_CLORDID,COMM_SYMBOL,COMM_USER_TYPE,COMM_INSTRUMENT_NAME,COMM_EXPIRY_DATE,COMM_STRIKE_PRICE,\
                         COMM_OPTION_TYPE,COMM_MKT_TYPE,COMM_MULTIPLIER,COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
                         COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_EXCH_INSTRUMENT_TYPE,\
			 COMM_TICK_SIZE,COMM_ALGO_ID,COMM_REMARKS1,COMM_REMARKS2,COMM_REF_LTP,COMM_EXPIRY_FLAG) \
                         VALUES \
                        (%f,%i,\"0\",\"1\",\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',\
                         NOW(),%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\
                         NOW(),\"%s\",%i,%i,\'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
                         \"%s\",%i,%i,%i,\'%c\',%i,%f,\"%s\",%i,\'%c\',%f,%i,\"%s\",\"%s\",\"%s\",\'%c\',\"%s\",\
                         STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),%f,\"%s\",\"%s\" ,%i,\"%s\",\'%c\',LTRIM(RTRIM(\"%s\")),\'%c\',%f,\'%c\',\'%c\',\"%s\",\
			\"%s\",%f,\"%s\",%f,\"%d\",\"%s\",\"%s\",%f,\"%s\"\
                        )",\
                        Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
                        Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
                        Ins_Req->cOrdStatus,Ins_Req->iRemQty + Ins_Req->iTotalTradedQty,Ins_Req->iRemQty,Ins_Req->iDiscQty,\
                        Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
                        Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,\
                        Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,Ins_Req->cProClient,Ins_Req->sRemarks,Ins_Req->iErrorCode,\
                        Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,\
                        Ins_Req->iReasonCode,Ins_Req->sReasonDesc,Ins_Req->iExchTrdNo,Ins_Req->iTrdSerialNo,Ins_Req->iTrdTransCode,\
                        Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,Ins_Req->fTrdPrice,Ins_Req->sTrdTime,Ins_Req->iTrdSeqNo,\
                        Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,Ins_Req->sClOrdId, Ins_Req->sOrigClOrdId ,\
                        Ins_Req->sSymbolName,Ins_Req->cUserType,Ins_Req->sInstrumentType,Ins_Req->sEntryDate,Ins_Req->fStrikePrice,Ins_Req->sOptType,sMktType,\
                        Ins_Req->iAuctionNum,Ins_Req->sPanNo,Ins_Req->cParticipantType,sTempSettlor,Ins_Req->cMarkProFlag,Ins_Req->fMarkProVal,Ins_Req->cGTCFlag,\
                        Ins_Req->cEncashFlag,Ins_Req->sSeries,Ins_Req->sCustomSym,Ins_Req->fLotSize,\
                        Ins_Req->sInstrumentTyp,Ins_Req->fTickSize,Ins_Req->iAlgoID,Ins_Req->sPlatform,Ins_Req->sChannel,Ins_Req->fLtp,Ins_Req->sSmExpiryFlag);

			logDebug3("Insert Query->%s ",statement1);
        if(mysql_query(DB_Con,statement1) != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }
        else
        {
                logDebug3("Inserted ");
                logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
                mysql_commit(DB_Con);
        }

        logTimestamp("Exit : [NSEMCXInsert]");
        free(statement1);

        return TRUE;
}

BOOL    fFetchNextSchDate(struct ORDER_REQUEST *Ord_Req,CHAR    *sGoodTillDate)
{
        logTimestamp("Entry : [fFetchNextSchDate]");

        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;

        CHAR    sSeleQry [MAX_QUERY_SIZE];
        memset(sSeleQry,'\0',MAX_QUERY_SIZE);

        sprintf(sSeleQry,"SELECT BP_NEXT_SCHEDULE_DATE FROM BATCH_PROCESS WHERE BP_BATCH_NAME = \"OFFMKT_PUMP\" AND BP_MKT_TYPE_NO =1  AND BP_EXCH_ID = \"%s\" AND BP_SEGMENT = \'%c\' ;",Ord_Req->ReqHeader.sExcgId,Ord_Req->ReqHeader.cSegment);

        logDebug2("sSeleQry = :%s:",sSeleQry);

        if (mysql_query(DB_Con, sSeleQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
                return FALSE;
        }
        Res = mysql_store_result(DB_Con);

        if((Row = mysql_fetch_row(Res)))
        {
                strcpy(sGoodTillDate,Row[0]);
                logDebug2("sGoodTillDate :%s:",sGoodTillDate);
        }



        logTimestamp("Exit : [fFetchNextSchDate]");
        return TRUE;

}

BOOL    fFetchData(struct ORDER_REQUEST *Ord_Req,CHAR    *sPan,CHAR  *sAccCode)
{
        logTimestamp("Entry : [fFetchNextSchDate]");

        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;
        INT16   iNumRow;

        CHAR    sSeleQry [MAX_QUERY_SIZE];
        memset(sSeleQry,'\0',MAX_QUERY_SIZE);

        if(Ord_Req->ReqHeader.cSegment == COMMODITY_SEGMENT){
		sprintf(sSeleQry,"SELECT ENTITY_MCX_CODE,ENTITY_PAN FROM ENTITY_MASTER WHERE ENTITY_CODE = \"%s\" ;",Ord_Req->sClientId);
	}
        else{
		sprintf(sSeleQry,"SELECT ENTITY_NSE_CODE,ENTITY_PAN FROM ENTITY_MASTER WHERE ENTITY_CODE = \"%s\" ;",Ord_Req->sClientId);
	}
        if (mysql_query(DB_Con, sSeleQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
                return FALSE;
        }
        Res = mysql_store_result(DB_Con);
	
	logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);
	
	if(iNumRow != 0)
	{	
        	if((Row = mysql_fetch_row(Res)))
        	{	
                	strcpy(sAccCode,Row[0]);
                	strcpy(sPan,Row[1]);
                	logDebug2("sAccCode :%s:",sAccCode);
                	logDebug2("sPan:%s:",sPan);
		}
        }
	else
	{
		logDebug2("Not a valid client id .");
                return INVALID_CLIENT_ID;
		
	}



        logTimestamp("Exit : [fFetchNextSchDate]");
        return TRUE;

}

BOOL    fFetchOMSErrStr(LONG32 *iErrorID,CHAR *sErrString)
{

        logTimestamp("Entry : fFetchOMSErrStr");
        MYSQL_RES               *Res;
        MYSQL_ROW               Row;
        INT16   iNumRow;


        CHAR SelQuery [MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

        logDebug2(" fFetchOMSErrStr iErrorID :%d:",iErrorID);

        sprintf(SelQuery,"SELECT RM_CUSTOM_REASON FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = %d ;",iErrorID);

        logDebug2("%s",SelQuery);
        if (mysql_query(DB_Con, SelQuery) != SUCCESS)
        {
                logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);
        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);
	 if(iNumRow != 0)
        {

                if((Row = mysql_fetch_row(Res)))
                {
                        logDebug2("serial no  :%s: ",Row[0]);
                        strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

                }
        }
        else
        {
                logDebug2("Error ID not Found in DB :%d:",iErrorID);
                strncpy(sErrString,"Error Id Not Specified",DB_REASON_DESC_LEN);
                return TRUE;
        }

                logTimestamp("Exit : fFetchOMSErrStr");
                return TRUE;
}

