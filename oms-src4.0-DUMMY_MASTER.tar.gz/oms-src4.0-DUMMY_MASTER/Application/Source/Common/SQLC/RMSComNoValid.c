#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

//extern DBConNEQ;

BOOL GetMktType(CHAR *sMktType,LONG32 iMktType);

BOOL fRMSCommValidation(struct  INT_ORDERS *pReq, MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt)
{
	logTimestamp("Entry :fRMSCommValidation");
	logDebug2(" RMS_VALIDATE SUCCESS ");
	logTimestamp("Exit :fRMSCommValidation");
	return TRUE;
				
}



BOOL fCoCommRMSValidation(struct  CO_ORDER_REQUEST *pReq,MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt)
{
	logTimestamp("Entry :fCoCommRMSValidation for Cover Order ");
	logDebug2(" RMS_VALIDATE SUCCESS ");
	logTimestamp("Exit :fCoRMSValidation");
	return TRUE;
}

BOOL fBoCommRMSValidation(struct  BO_ORDER_REQUEST *pReq,MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt)
{
	logTimestamp("Entry :fBoCommRMSValidation ");
	logDebug2(" RMS_VALIDATE SUCCESS ");
	logTimestamp("Exit :fBoRMSValidation");
	return TRUE;
}

BOOL fRMSValidateSprd(struct  INT_SPREAD_ORDERS *pReq, MYSQL *DBObj,LONG32 iPEnv,CHAR *sErrorID,LONG32 *iQuantity,DOUBLE64 *fAmnt,CHAR *sErrorMsg)
{
        logTimestamp("Entry :fRMSValidateSprd");
	logDebug2(" RMS_VALIDATE SUCCESS ");
        logTimestamp("Exit :fRMSValidateSprd");
        return TRUE;
}

