#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

extern   DB_Con;

extern  LONG32          iMcxBranchId ;

BOOL fLoadDBNseEnv()
{
        logTimestamp("Entry :[fLoadDBNseEnv]");
        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;

        CHAR    *sQry = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	sprintf(sQry,"select EAM_EXM_EXCH_ID , EAM_SEGMENT , EAM_EXCH_USER_ID , EAM_BROKER_ID , EAM_BRANCH_ID  from EXCH_ADMINISTRATION_MASTER a where a.EAM_EXM_EXCH_ID = 'NSE' AND a.EAM_SEGMENT IN(\'%c\') ORDER BY a.EAM_SEGMENT;",COMMODITY_SEGMENT);

        logDebug2("Qry = %s",sQry);

        if (mysql_query(DB_Con, sQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DB_Con);
        }
        Res = mysql_store_result(DB_Con);
	
	while((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Here 1");
                logDebug2("Row[1][0] = :%c:",Row[1][0]);
                if( Row[1][0] == COMMODITY_SEGMENT)
                {
                        logDebug2("Here 2");
                        iMcxBranchId = atoi(Row[4]);
                        logDebug2("Currency Branch Id= %d",iMcxBranchId);
                }
		else
		{
			logDebug2("errror occured...");
		}
	}
	
	mysql_free_result(Res);
        free(sQry);
        logTimestamp("Exit :[fLoadDBNseEnv]");

}

BOOL fMCXInsert(struct INT_ORDERS *Ins_Req)
{
        logTimestamp("MCXInsert [ENTRY]");
        CHAR *statement1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR            sMktType[MKT_TYPE_LEN];
        CHAR symbolName [DB_SYM_LEN];
        memset(symbolName,'\0',DB_SYM_LEN);
        memset(sMktType,'\0',MKT_TYPE_LEN);
        if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
        {
                logDebug2("Error in fetching iMktType");
                return FALSE;
        }
        logDebug2("Ins_Req->sSymbolName:%s:",Ins_Req->sSymbolName);
        strncpy(symbolName,Ins_Req->sSymbolName,DB_SYM_LEN);
        logDebug2("rohit [%s]",symbolName);
        logDebug2("THIS is test");
        logDebug3("iSeqNo - %d", Ins_Req->ReqHeader.iSeqNo);
        logDebug3("iMsgLength - %d", Ins_Req->ReqHeader.iMsgLength);
        logDebug3("iMsgCode - %d", Ins_Req->ReqHeader.iMsgCode);
        logDebug3("sExcgId - %s", Ins_Req->ReqHeader.sExcgId);
        logDebug3("iUserId - %d", Ins_Req->ReqHeader.iUserId);
        logDebug3("cSource - %c",Ins_Req->ReqHeader.cSource);
        logDebug3("cSegment - %c", Ins_Req->ReqHeader.cSegment);
        logDebug3("iOrdNo - %d", Ins_Req->fOrdNo);
        logDebug3("iSerialNo - %d", Ins_Req->iSerialNo);
        logDebug3("sSecId - %s", Ins_Req->sSecId);
        logDebug3("sEntityId - %s", Ins_Req->sEntityId);
        logDebug3("sExchOrdNo - %s", Ins_Req->sExchOrdNo);
        logDebug3("sClientId - %s", Ins_Req->sClientId);
        logDebug3("cBuySellInd - %c", Ins_Req->cBuySellInd);
        logDebug3("cOrdStatus - %c", Ins_Req->cOrdStatus);
        logDebug3("sEntryDate - %s", Ins_Req->sEntryDate);
        logDebug3("sOrderTime - %s", Ins_Req->sOrderTime);
        logDebug3("iTotalQty - %d", Ins_Req->iTotalQty);
        logDebug3("iRemQty - %d", Ins_Req->iRemQty);
        logDebug3("iDiscQty - %d", Ins_Req->iDiscQty);
        logDebug3("iDiscRemQty - %d", Ins_Req->iDiscRemQty);
        logDebug3("iTotalTradedQty - %d", Ins_Req->iTotalTradedQty);
        logDebug3("fOrderPrice - %f", Ins_Req->fOrderPrice);
        logDebug3("fTriggerPrice - %f", Ins_Req->fTriggerPrice);
        logDebug3("iValidity - %d", Ins_Req->iValidity);
        logDebug3("iOrderType - %d", Ins_Req->iOrderType);
 	logDebug3("iGoodTillDaysFlg - %d", Ins_Req->iGoodTillDaysFlg);
        logDebug3("sGoodTillDaysDate - %s", Ins_Req->sGoodTillDaysDate);
        logDebug3("sAccCode - %s",Ins_Req->sAccCode);
        logDebug3("iMinFillQty - %d", Ins_Req->iMinFillQty);
        logDebug3("cProClient - %c", Ins_Req->cProClient);
        logDebug3("sRemarks - %s", Ins_Req->sRemarks);
        logDebug3("iErrorCode - %d", Ins_Req->iErrorCode);
        logDebug3("cUserType - %c", Ins_Req->cUserType);
        logDebug3("cOrderOffOn - %c", Ins_Req->cOrderOffOn);
        logDebug3("cProductId - %c", Ins_Req->cProductId);
        logDebug3("sUserInfo - %s", Ins_Req->sUserInfo);
        logDebug3("iGrpId - %d", Ins_Req->iGrpId);
        logDebug3("iReasonCode - %d", Ins_Req->iReasonCode);
        logDebug3("sReasonDesc - %s", Ins_Req->sReasonDesc);
        logDebug3("iExchTrdNo - %d", Ins_Req->iExchTrdNo);
        logDebug3("iTrdSerialNo - %d", Ins_Req->iTrdSerialNo);
        logDebug3("iTrdTransCode - %d", Ins_Req->iTrdTransCode);
        logDebug3("cTrdStatus - %c", Ins_Req->cTrdStatus);
        logDebug3("iLstTrdQty - %d", Ins_Req->iLstTrdQty);
        logDebug3("fTrdPrice - %f", Ins_Req->fTrdPrice);
        logDebug3("sTrdTime - %s", Ins_Req->sTrdTime);
        logDebug3("iTrdSeqNo - %d", Ins_Req->iTrdSeqNo);
        logDebug3("cHandleInst - %c", Ins_Req->cHandleInst);
        logDebug3("fAlgoOrderNo - %f", Ins_Req->fAlgoOrderNo);
        logDebug3("iStratergyId - %d", Ins_Req->iStratergyId);
        logDebug3("sClOrdId - %s", Ins_Req->sClOrdId);
        logDebug3("sOrigClOrdId - %s", Ins_Req->sOrigClOrdId);
        logDebug3("sMaturityMonYr - %s", Ins_Req->sMaturityMonYr);
        logDebug3("sMktType:%s",sMktType);
        logDebug3("END");

	sprintf(statement1,"INSERT INTO COMM_ORDERS \
                        (COMM_ORDER_NO,COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,COMM_LEG_NO,COMM_SCRIP_CODE,COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,\
                         COMM_EXCH_ORDER_NO,COMM_CLIENT_ID,COMM_BUY_SELL_IND,COMM_MSG_CODE,COMM_STATUS,COMM_INTERNAL_ENTRY_DATE,COMM_TOTAL_QTY,\
                         COMM_REM_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY, COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_VALIDITY,\
                         COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS,COMM_GOOD_TILL_DATE,COMM_ACC_CODE,COMM_USER_ID,COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,\
                         COMM_REMARKS,COMM_ERROR_CODE,COMM_SOURCE_FLG,COMM_ORDER_OFFON,COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,COMM_REASON_CODE,\
                         COMM_REASON_DESCRIPTION,COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,\
                         COMM_TRD_TRADE_PRICE,COMM_TRD_TRADE_TIME,COMM_TRD_SEQ_NO, COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,COMM_STRATEGY_ID,\
                         COMM_CLORDID,COMM_ORIG_CLORDID,COMM_SYMBOL,COMM_USER_TYPE,COMM_INSTRUMENT_NAME,COMM_EXPIRY_DATE,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MKT_TYPE,COMM_MULTIPLIER) \
                        VALUES \
                        (%f,%i,\"0\",\"1\",\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',\
                         NOW(),%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\
                         NOW(),\"%s\",%i,%i,\'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
                         \"%s\",%i,%i,%i,\'%c\',%i,%f,\"%s\",%i,\'%c\',%f,%i,\"%s\",\"%s\",\"%s\",\'%c\',\"%s\",\
                         STR_TO_DATE(\"%s\",\'%%Y%%m%%d'),%f,\"%s\",\"%s\" ,%i\
                        )",\
                        Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
                        Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
                        Ins_Req->cOrdStatus,Ins_Req->iRemQty + Ins_Req->iTotalTradedQty,Ins_Req->iRemQty,Ins_Req->iDiscQty,\
                        Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
                        Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,\
                        Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,Ins_Req->cProClient,Ins_Req->sRemarks,Ins_Req->iErrorCode,\
                        Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,\
                        Ins_Req->iReasonCode,Ins_Req->sReasonDesc,Ins_Req->iExchTrdNo,Ins_Req->iTrdSerialNo,Ins_Req->iTrdTransCode,\
                        Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,Ins_Req->fTrdPrice,Ins_Req->sTrdTime,Ins_Req->iTrdSeqNo,\
                        Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,Ins_Req->sClOrdId, Ins_Req->sOrigClOrdId ,\
                        Ins_Req->sSymbolName,Ins_Req->cUserType,Ins_Req->sInstrumentType,Ins_Req->sMaturityMonYr,Ins_Req->fStrikePrice,Ins_Req->sOptType,sMktType,\
                        Ins_Req->iAuctionNum);

        logDebug3("Insert Query->%s ",statement1);
        if(mysql_query(DB_Con,statement1) != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }
        else
        {
                logDebug3("Inserted ");
                logDebug3("%d rows updated!!",mysql_affected_rows(DB_Con));
                mysql_commit(DB_Con);
        }
	logTimestamp("Exit : [MCXInsert]");
        free(statement1);

        return TRUE;
}

BOOL SelectClOrdId(CHAR *SeqNo)
{
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        if (mysql_query(DB_Con, "SELECT NextVal('OFF_ORD');") != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);
        logDebug3("ClOrdId DP : %s", SeqNo);
        while((Row = mysql_fetch_row(Res)))
        {
                strncpy(SeqNo,Row[0],strlen(Row[0]));
                logDebug3("Generated ClOrdId No. : %s", SeqNo);
        }

        mysql_free_result(Res);

        return TRUE;
}

BOOL OrderNoGenerator(DOUBLE64  *OrdSeq)
{
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        if (mysql_query(DB_Con, "SELECT GenOrderNo();") != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);
        while((Row = mysql_fetch_row(Res)))
        {
                *OrdSeq = atof(Row[0]);
                logDebug3("Generated Order No. : %lf", *OrdSeq);
        }

        mysql_free_result(Res);

        return TRUE;
}

BOOL fSelectDate(CHAR *sSeq)
{
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        //      if (mysql_query(DBConNEQ, "SELECT CONCAT(Date_format(CURDATE(),'%Y%m%d'));") != SUCCESS)
        if (mysql_query(DB_Con, "SELECT SUBSTR(CONCAT(Date_format(CURDATE(),'%Y%m%d')),3,8);") != SUCCESS)
        {
                sql_Error(DB_Con);
                logSqlFatal("error in select Date [EQOrdSvr].");
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);
        while((Row = mysql_fetch_row(Res)))
        {
                strncpy(sSeq,Row[0],strlen(Row[0]));
                //              sprintf(SeqNo, "%s%d",Row[0],iMsgType);
                logDebug2("Date_format : %s", sSeq);
        }

        mysql_free_result(Res);

        return TRUE;
}


BOOL    fFetchErrStr(CHAR *sErrorID,CHAR *sErrString)
{

        logTimestamp("Entry : fFetchErrStr");
        MYSQL_RES               *Res;
        MYSQL_ROW               Row;
        INT16   iNumRow;


        CHAR SelQuery [MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

        logDebug2(" fFetchErrStr sErrorID :%s:",sErrorID);

        sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = \'%s\' ;",sErrorID);

        logDebug2("%s",SelQuery);
        if (mysql_query(DB_Con, SelQuery) != SUCCESS)
        {
                logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);
        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);


        if(iNumRow != 0)
        {

                if((Row = mysql_fetch_row(Res)))
                {
                        logDebug2("serial no  :%s: ",Row[0]);
                        strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

                }
        }
        else
        {
                logDebug2("Error ID not Found in DB :%s:",sErrorID);
 		return FALSE;
        }

        logTimestamp("Exit : fFetchErrStr");
        return TRUE;
}


BOOL    fRMSRejInsert(struct INT_ORDERS *Ins_Req,struct ORDER_RESPONSE *pResp,CHAR *sErrorID)
{
        logTimestamp("ENTRY [fRMSRejInsert]");
        CHAR            sMktType[MKT_TYPE_LEN];
        memset(sMktType,'\0',MKT_TYPE_LEN);
        LONG32  iErrorCode = 0;
        CHAR *InsQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR    SelQry[MAX_QUERY_SIZE];
        BOOL    ChkFlag =FALSE;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        BOOL    iReqFlag = FALSE;

        LONG32  tmpOrdSerialNo = 0;
        LONG32  iTempOrdSerialNo = 0;
        DOUBLE64 fTriggerPrice = 0.00;
        LONG32  iTempMsgCode = 0,iNoOfRec;
        LONG32 iTotlQty = 0;
        LONG32 iRemQty = 0;
        LONG32 iDisQty = 0;
        LONG32 iDiscQtyRemaning = 0;
        LONG32 itotalTrdQty = 0;
        LONG32 iValidity = 0;
        LONG32 iOrdType = 0;
        LONG32 iGoodTilDays = 0;
        LONG32 iMinFilQty = 0;
        LONG32 iGrpId = 0;
        LONG32 iReasonCode = 0;
        LONG32 iTrdExchtrdNo = 0;
        LONG32 itrdSerialNo = 0;
        LONG32 iTrdTrnsCode = 0;
        LONG32 iLstTrdQty = 0;
        LONG32 iTrdSeqNo = 0;
        LONG32 iStratergyId = 0;
        LONG32 iUserId = 0;
        LONG32 iLeg = 0;
        LONG32 iMsgCode = 0;
        LONG32 iAuctionNum =0;
        CHAR    cSegmnt =       '\0';
        CHAR    cBuySell=       '\0';
        CHAR    cProCil =       '\0';
        CHAR    cSourceFlag     =       '\0';
        CHAR    cOrdOfOn        =       '\0';
  	CHAR    cProdId         =       '\0';
        CHAR    cTrdStatus      =       '\0';
        CHAR    cOrdStatus      =       '\0';
        CHAR    cHndleInst      =       '\0';
        CHAR    cUserType       =       '\0';
        CHAR    cTempStatus     =       '\0';

        DOUBLE64 fOrdNo = 0.00 ;
        DOUBLE64 fOrdPrice = 0.00 ;
        DOUBLE64 fTradePrice = 0.00 ;
        DOUBLE64 fSelectClOrdId = 0.00 ;
        DOUBLE64        fTrigerPrice = 0.00 ;

        LONG64 lAlgoOrderNo ;

        CHAR    sSecId          [DB_SECURITY_ID_LEN];
        CHAR    sSymbol         [DB_SYM_LEN];
        CHAR    sEntityId       [DB_ENTITY_ID_LEN];
        CHAR    sExchOrdNo      [DB_EXCH_ORD_NO_LEN];
        CHAR    sClientId       [DB_CLIENT_ID_LEN];
        CHAR    sEntryDate      [DB_DATETIME_LEN];
        CHAR    sExchOrdTime    [DB_DATETIME_LEN];
        CHAR    sGoodTillDate   [DB_DATETIME_LEN];
        CHAR    sAccCode        [DB_ACC_CODE_LEN];
        CHAR    sRemarks        [DB_REMARKS_LEN];
        CHAR    sLocCode        [LOC_CODE_LEN];
        CHAR    sTrdTime        [DB_DATETIME_LEN];
        CHAR    sClOrdId        [CLORDID_LEN];
        CHAR    sOriClordId     [CLORDID_LEN];
        CHAR    sExchId         [EXCHANGE_LEN];
        CHAR    sInstruName     [INSTRU_CODE_LEN];
        CHAR    sInstrumentType [DB_INSTRU_LEN];

        memset(sSecId,'\0',DB_SECURITY_ID_LEN);
        memset(sSymbol,'\0',DB_SYM_LEN);
        memset(sEntityId,'\0',DB_ENTITY_ID_LEN);
        memset(sExchOrdNo,'\0',DB_EXCH_ORD_NO_LEN);
        memset(sClientId,'\0',DB_CLIENT_ID_LEN);
        memset(sEntryDate,'\0',DB_DATETIME_LEN);
        memset(sExchOrdTime,'\0',DB_DATETIME_LEN);
        memset(sGoodTillDate,'\0',DB_DATETIME_LEN);
        memset(sAccCode,'\0',DB_ACC_CODE_LEN);
        memset(sRemarks,'\0',DB_REMARKS_LEN);
	 memset(sLocCode,'\0',LOC_CODE_LEN);
        memset(sTrdTime,'\0',DB_DATETIME_LEN);
        memset(sClOrdId,'\0',CLORDID_LEN);
        memset(sOriClordId,'\0',CLORDID_LEN);
        memset(sExchId,'\0',EXCHANGE_LEN);
        memset(sInstruName,'\0',INSTRU_CODE_LEN);

        if(GetMktType(&sMktType,Ins_Req->iMktType)!=TRUE)
        {
                logDebug2("Error in fetching iMktType");
                return FALSE;
        }
        logDebug2("Inside sErrorID :%s:",sErrorID);
	
	logDebug3("pResp->sReasonDesc :%s:",pResp->sReasonDesc);
        strncpy(Ins_Req->sReasonDesc,pResp->sReasonDesc,DB_REASON_DESC_LEN);

	sprintf(InsQuery,"INSERT INTO COMM_ORDERS \
                        (COMM_ORDER_NO,COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,COMM_LEG_NO,COMM_SCRIP_CODE,COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,\
                         COMM_EXCH_ORDER_NO,COMM_CLIENT_ID,COMM_BUY_SELL_IND,COMM_MSG_CODE,COMM_STATUS,COMM_INTERNAL_ENTRY_DATE,COMM_TOTAL_QTY,\
                         COMM_REM_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY, COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_VALIDITY,\
                         COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS,COMM_GOOD_TILL_DATE,COMM_ACC_CODE,COMM_USER_ID,COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,\
                         COMM_REMARKS,COMM_ERROR_CODE,COMM_SOURCE_FLG,COMM_ORDER_OFFON,COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,COMM_REASON_CODE,\
                         COMM_REASON_DESCRIPTION,COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,\
                         COMM_TRD_TRADE_PRICE,COMM_TRD_TRADE_TIME,COMM_TRD_SEQ_NO, COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,COMM_STRATEGY_ID,\
                         COMM_CLORDID,COMM_ORIG_CLORDID,COMM_SYMBOL,COMM_USER_TYPE,COMM_INSTRUMENT_NAME,COMM_EXPIRY_DATE,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MKT_TYPE,\
                         COMM_MULTIPLIER)\
                         VALUES \
                         (%f,%i,\"0\",\"1\",\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',%i,\'%c\',\
                          NOW(),%i,%i,%i,%i,%i,%f,%f,%i,%i,%i,\
                          NOW(),\"%s\",%i,%i,\'%c\',\"%s\",%i,\'%c\',\'%c\',\'%c\',\"%s\",%i,%i,\
                          \"%s\",%i,%i,%i,\'%c\',%i,%f,\"%s\",%i,\'%c\',%f,%i,\"%s\",\"%s\",\"%s\",\'%c\',\"%s\",\
                          STR_TO_DATE(\"%s\",\'%%Y%%m%%d\'),%f,\"%s\",\"%s\",%d \
                         )",\
                         Ins_Req->fOrdNo,Ins_Req->iSerialNo,Ins_Req->sSecId,Ins_Req->ReqHeader.sExcgId,Ins_Req->ReqHeader.cSegment,\
                         Ins_Req->sEntityId,Ins_Req->sExchOrdNo,Ins_Req->sClientId,Ins_Req->cBuySellInd,Ins_Req->ReqHeader.iMsgCode,\
                         EXCH_REJECT_STATUS,Ins_Req->iTotalQty,Ins_Req->iRemQty + Ins_Req->iTotalTradedQty ,Ins_Req->iDiscQty,\
                         Ins_Req->iDiscRemQty,Ins_Req->iTotalTradedQty,Ins_Req->fOrderPrice,Ins_Req->fTriggerPrice,Ins_Req->iValidity,\
                         Ins_Req->iOrderType,Ins_Req->iGoodTillDaysFlg,Ins_Req->sAccCode,\
                         Ins_Req->ReqHeader.iUserId,Ins_Req->iMinFillQty,Ins_Req->cProClient,Ins_Req->sRemarks,Ins_Req->iErrorCode,\
                         Ins_Req->ReqHeader.cSource,Ins_Req->cOrderOffOn,Ins_Req->cProductId,Ins_Req->sLocCode,Ins_Req->iGrpId,\
                         Ins_Req->iReasonCode,Ins_Req->sReasonDesc,Ins_Req->iExchTrdNo,Ins_Req->iTrdSerialNo,Ins_Req->iTrdTransCode,\
                         Ins_Req->cTrdStatus,Ins_Req->iLstTrdQty,Ins_Req->fTrdPrice,Ins_Req->sTrdTime,Ins_Req->iTrdSeqNo,\
                         Ins_Req->cHandleInst,Ins_Req->fAlgoOrderNo,Ins_Req->iStratergyId,Ins_Req->sClOrdId, Ins_Req->sOrigClOrdId ,\
                         Ins_Req->sSymbolName,Ins_Req->cUserType,Ins_Req->sInstrumentType,Ins_Req->sMaturityMonYr,Ins_Req->fStrikePrice,Ins_Req->sOptType,sMktType,Ins_Req->iAuctionNum);

        logDebug2("InsQuery [%s]",InsQuery);
        if(mysql_query(DB_Con, InsQuery) != SUCCESS)
        {
                logSqlFatal("Error in inserting COMM_ORDERS_TABLE");
                sql_Error(DB_Con);
                return FALSE;
        }
        else
        {
                logDebug2(" Sucessfully Inserted into COMM_ORDERS Table");
                logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
        	mysql_commit(DB_Con);

        }

        if (Ins_Req->ReqHeader.iMsgCode != TC_INT_RMS_OE_REJECTION && Ins_Req->ReqHeader.iMsgCode != TC_INT_OE_REJECTION)
        {
                logDebug2(" 1 Comparing Here ");
                logDebug2("sErrorID :%s:",sErrorID);
                logDebug2("2 Comparing Here ");

                if((strncmp(ORDER_IN_TRANSIT,sErrorID,10) == 0) || (strncmp(ORDER_STATUS_CHANGED,sErrorID,10) == 0))
                {
                        logDebug2("Inside if ");
                        //      cTempStatus = TRANSIT_STATUS;
                        logInfo("Order Is in Transit Status");
                        iReqFlag = TRUE;
                }
                else
                {
                        //      cTempStatus = EXCH_CONFIRM_STATUS;
                        logInfo("Order Is not in Transit Status");
                        iReqFlag = FALSE;
                }

                memset( SelQry, '\0',  MAX_QUERY_SIZE);

		sprintf(SelQry,"SELECT \
                                COMM_ORDER_NO,COMM_SERIAL_NO,COMM_SCRIP_CODE,COMM_SYMBOL,COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,\
                                COMM_CLIENT_ID,COMM_BUY_SELL_IND,COMM_MSG_CODE,COMM_STATUS,\
                                COMM_INTERNAL_ENTRY_DATE,COMM_TOTAL_QTY,COMM_REM_QTY,COMM_DISC_QTY,\
                                COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY,COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_VALIDITY,\
                                COMM_ORDER_TYPE,COMM_GOOD_TILL_DAYS,IFNULL(COMM_GOOD_TILL_DATE,now()),COMM_ACC_CODE,COMM_USER_ID,COMM_USER_TYPE,\
                                COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,COMM_REMARKS,COMM_SOURCE_FLG,COMM_ORDER_OFFON,\
                                COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,COMM_REASON_CODE,\
                                COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,\
                                COMM_TRD_TRADE_PRICE,COMM_TRD_SEQ_NO,COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,\
                                COMM_STRATEGY_ID,COMM_CLORDID,COMM_ORIG_CLORDID,COMM_LEG_NO,COMM_EXCH_ORDER_NO,IFNULL(COMM_EXCH_ORDER_TIME,now()),COMM_MULTIPLIER,\
                                COMM_INSTRUMENT_NAME FROM COMM_ORDERS \
                                WHERE \
                                COMM_ORDER_NO = \'%f\' AND COMM_SERIAL_NO = (SELECT MAX(COMM_SERIAL_NO) -1  FROM COMM_ORDERS WHERE COMM_ORDER_NO = \'%f\' \
                                        AND COMM_LEG_NO = %d )  AND COMM_LEG_NO = %d ;",\
                                Ins_Req->fOrdNo,Ins_Req->fOrdNo,Ins_Req->iLegValue,Ins_Req->iLegValue);

                logDebug2("SelQry :%s:",SelQry);

                if(mysql_query(DB_Con, SelQry) != SUCCESS)
                {
                        logSqlFatal("Error in Selecting COMM_ORDERS_TABLE");
                        sql_Error(DB_Con);
                        return FALSE;
                }

                Res = mysql_store_result(DB_Con);


                if(Row = mysql_fetch_row(Res))
                {
                        fOrdNo = atof(Row[0]);
                        iTempOrdSerialNo = atoi(Row[1]);
                        strncpy(sSecId,Row[2],DB_SECURITY_ID_LEN);
                        strncpy(sSymbol,Row[3],DB_SYM_LEN);
                        strncpy(sExchId,Row[4],EXCHANGE_LEN);
                        cSegmnt = Row[5][0];
                        strncpy(sEntityId,Row[6],DB_ENTITY_ID_LEN);
                        strncpy(sClientId,Row[7],DB_CLIENT_ID_LEN);
                        cBuySell = Row[8][0];
                        iMsgCode = atoi(Row[9]);
                        cOrdStatus = Row[10][0];
                        strncpy(sEntryDate,Row[11],DB_DATETIME_LEN);
			iTotlQty  = atoi(Row[12]);
                        iRemQty = atoi(Row[13]);
                        iDisQty  = atoi(Row[14]);
                        iDiscQtyRemaning  = atoi(Row[15]);
                        itotalTrdQty  = atoi(Row[16]);
                        fOrdPrice  = atof(Row[17]);
                        fTrigerPrice  = atof(Row[18]);
                        iValidity = atoi(Row[19]);
                        iOrdType = atoi(Row[20]);
                        iGoodTilDays    = atoi(Row[21]);
                        strncpy(sGoodTillDate,Row[22],DB_DATETIME_LEN);
                        strncpy(sAccCode,Row[23],DB_ACC_CODE_LEN);
                        iUserId= atoi(Row[24]);
                        cUserType = Row[25][0];
                        iMinFilQty = atoi(Row[26]);
                        cProCil = Row[27][0];
                        strncpy(sRemarks,Row[28],DB_REMARKS_LEN);
                        cSourceFlag  = Row[29][0];
                        cOrdOfOn = Row[30][0];
                        cProdId = Row[31][0];
                        strncpy(sLocCode,Row[32],LOC_CODE_LEN);
                        iGrpId  = atoi(Row[33]);
                        iReasonCode = atoi(Row[34]);
                        iTrdExchtrdNo = atoi(Row[35]);
                        itrdSerialNo = atoi(Row[36]);
                        iTrdTrnsCode = atoi(Row[37]);
                        cTrdStatus = Row[38][0];
                        iLstTrdQty = atoi(Row[39]);
                        fTradePrice = atof(Row[40]);
                        iTrdSeqNo = atoi(Row[41]);
                        cHndleInst = Row[42][0];
                        lAlgoOrderNo = atol(Row[43]);
                        iStratergyId = atoi(Row[44]);
                        strncpy(sClOrdId,Row[45],CLORDID_LEN);
                        strncpy(sOriClordId,Row[46],CLORDID_LEN);
                        iLeg = atoi(Row[47]);
                        strncpy(sExchOrdNo,Row[48],DB_EXCH_ORD_NO_LEN);
                        strncpy(sExchOrdTime,Row[49],DB_DATETIME_LEN);
                        iAuctionNum = atoi(Row[50]);
                        strncpy(sInstrumentType,Row[51],DB_INSTRU_LEN);
                }
                iTempOrdSerialNo = Ins_Req->iSerialNo + 1;
		memset( SelQry, '\0',  MAX_QUERY_SIZE);

                sprintf(SelQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO,COMM_SERIAL_NO,COMM_SCRIP_CODE,COMM_SYMBOL,\
                        COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,COMM_CLIENT_ID,COMM_BUY_SELL_IND,\
                        COMM_MSG_CODE,COMM_STATUS,COMM_INTERNAL_ENTRY_DATE,COMM_TOTAL_QTY,\
                        COMM_REM_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY,COMM_ORDER_PRICE,\
                        COMM_TRIGGER_PRICE,COMM_VALIDITY,COMM_ORDER_TYPE,COMM_GOOD_TILL_DAYS,COMM_GOOD_TILL_DATE,\
                        COMM_ACC_CODE,COMM_USER_ID,COMM_USER_TYPE,COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,COMM_REMARKS,\
                        COMM_ERROR_CODE,COMM_SOURCE_FLG,COMM_ORDER_OFFON,COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,\
                        COMM_REASON_CODE,COMM_REASON_DESCRIPTION,COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,\
                        COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,COMM_TRD_TRADE_PRICE,\
                        COMM_TRD_SEQ_NO,COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,COMM_STRATEGY_ID,COMM_CLORDID,COMM_ORIG_CLORDID,COMM_LEG_NO,COMM_EXCH_ORDER_NO,COMM_EXCH_ORDER_TIME,COMM_MKT_TYPE,COMM_MULTIPLIER,COMM_MULTILEG_ORD_TYPE,COMM_INSTRUMENT_NAME) \
                                VALUES \
                                (\'%f\',%i,\"%s\",\"%s\",\"%s\",\'%c\',\"%s\",\
                                 \"%s\",\'%c\',%i,\'%c\',\
                                 \"%s\",%i,%i,%i,\
                                 %i,%i,%f,%f,%i,\
                                 %i,%i,\"%s\",\"%s\",%d,\'%c\',\
                                 %i,\'%c\',\"%s\",\"%d\",\'%c\',\'%c\',\
                                 \'%c\',\"%s\",%d,%d,\"%s\",\
                                 %d,%d,%d,\'%c\',%d,\
                                 %f,%d,\'%c\',%ld,\
                                 %d,\"%s\",\"%s\" , %d,\"%s\",\"%s\",\"%s\",%d,\"0\",\"%s\")",\
                                fOrdNo,iTempOrdSerialNo,sSecId,sSymbol,sExchId,cSegmnt,sEntityId,\
                                sClientId,cBuySell,iMsgCode,cOrdStatus,\
                                sEntryDate,iTotlQty,iRemQty,iDisQty,\
                                iDiscQtyRemaning,itotalTrdQty,fOrdPrice,fTrigerPrice,iValidity,\
                                iOrdType,iGoodTilDays,sGoodTillDate,sAccCode,iUserId,cUserType,\
                                iMinFilQty,cProCil,sRemarks,Ins_Req->ResHeader.iErrorId,cSourceFlag,cOrdOfOn,\
                                cProdId,sLocCode,iGrpId,iReasonCode,pResp->sReasonDesc,\
                                iTrdExchtrdNo,itrdSerialNo,iTrdTrnsCode,cTrdStatus,iLstTrdQty,\
                                fTradePrice,iTrdSeqNo,cHndleInst,lAlgoOrderNo,\
                                iStratergyId,sClOrdId,sOriClordId,iLeg,sExchOrdNo,sExchOrdTime,sMktType,iAuctionNum,sInstrumentType);
                logDebug2("SelQry 1 [%s]",SelQry);
                if(mysql_query(DB_Con, SelQry) != SUCCESS)
                {
                        logSqlFatal("Error in inserting COMM_ORDERS_TABLE");
                        sql_Error(DB_Con);
                        return FALSE;
                }
                else
                {
                	logDebug2(" Sucessfully Inserted into COMM_ORDERS Table");
                        logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
                        mysql_commit(DB_Con);
                }

                if(iReqFlag == TRUE)
                {
			logDebug2(" Sucessfully Update RCOMMUEST_QUEUE Table");
                        logDebug2("%d rows updated!!",mysql_affected_rows(DB_Con));
                        mysql_commit(DB_Con);
		}

		
                pResp->iOrderType = iOrdType;
                pResp->iOrderValidity = iValidity;
                pResp->iDiscQty= iDisQty;
                pResp->iDiscQtyRem= iDiscQtyRemaning;
                pResp->iTotalQtyRem= iRemQty;
                pResp->iTotalQty= iTotlQty;
                pResp->iLastTradedQty= iOrdType;
                pResp->iTotalTradedQty= itotalTrdQty;
                pResp->iMinFillQty= iMinFilQty;
                pResp->fPrice= fOrdPrice;
                pResp->fTriggerPrice= fTrigerPrice;
                pResp->fTradePrice= fTradePrice;
                pResp->iSerialNum = iTempOrdSerialNo;
        	
	}
		
        logTimestamp("Exit [fRMSRejInsert]");
        return TRUE;
}

BOOL    fFetchSerialNo(struct INT_ORDERS *Int_Req)
{
        logTimestamp("fFetchSerialNo [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        CHAR *statement = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

        logDebug3("Before Fetch Serial No");
 	sprintf(statement,"SELECT COMM_SERIAL_NO,COMM_EXCH_ORDER_NO,COMM_ORDER_PRICE,COMM_TRIGGER_PRICE,COMM_REM_QTY,\
                        COMM_STATUS,COMM_CLORDID,DATE_FORMAT(COMM_INTERNAL_ENTRY_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),COMM_TRD_TRADE_QTY,COMM_TOTAL_TRADED_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_VALIDITY,COMM_TRD_TRADE_PRICE \
                        FROM COMM_ORDERS \
                        WHERE COMM_SERIAL_NO = (SELECT MAX(COMM_SERIAL_NO) FROM COMM_ORDERS WHERE COMM_ORDER_NO = %lf) AND COMM_ORDER_NO = %lf;",Int_Req->fOrdNo,Int_Req->fOrdNo);

        logDebug2("\n%s\n",statement);

        if(mysql_query(DB_Con,statement) != SUCCESS)
        {
                sql_Error(DB_Con);
                return FALSE;
        }

        Res = mysql_store_result(DB_Con);

        while((Row = mysql_fetch_row(Res)))
        {
                if(Int_Req->iSerialNo == atoi(Row[0]) + 1  )
                {
                        logDebug3("Serial Check OK");
                        logDebug3("CR_ORD_STATUS : %c",Row[5][0]);

                        //                        if(Row[5][0] == 'E')
                        if((Row[5][0] == EXCH_REJECT_STATUS) || (Row[5][0] == TRADED_STATUS) || (Row[5][0] == TRANSIT_STATUS) || \
                                        (Row[5][0] == EXCH_DELETE_STATUS) || (Row[5][0] == EXCH_FREEZE_STATUS) || (Row[5][0] == EXPIRED_STATUS) )
                        {
                                logDebug3("Order Still in Transit");
                                mysql_free_result(Res);
                                switch(Row[5][0])
                                {
                                        case TRANSIT_STATUS:
                                                return RET_TRANSIT_STAT;
                                        case TRADED_STATUS :
                                                return RET_TRADED_STAT;
                                        case EXCH_REJECT_STATUS:
                                        case EXCH_DELETE_STATUS:
                                        case EXPIRED_STATUS:
                                        case EXCH_FREEZE_STATUS:
                                                return RET_CANCEL_STAT;

                                }
			}
			else
                        {
                                strncpy(Int_Req->sOrigClOrdId,Row[6],CLORDID_LEN);
                                strncpy(Int_Req->sExchOrdNo,Row[1],DB_EXCH_ORD_NO_LEN);
                                logDebug3("sOrigClOrdId : %s",Int_Req->sOrigClOrdId);

                                if(Int_Req->ReqHeader.iMsgCode == TC_INT_ORDER_MODIFY)
                                {
                                        logDebug3("Modification Order");
                                        strncpy(Int_Req->sLastModTime,Row[7],DB_DATETIME_LEN);
                                        logDebug3("[6000] sLastModTime : %s",Int_Req->sLastModTime);
                                        Int_Req->iTotalTradedQty = atoi(Row[9]);
                                        Int_Req->iLstTrdQty = atoi(Row[8]);
                                        Int_Req->fTrdPrice = atof(Row[13]);
                                        if(Int_Req->fOrderPrice != atof(Row[2]) || Int_Req->fTriggerPrice != atof(Row[3]) || Int_Req->iTotalQty != atoi(Row[4]) ||  \
                                                        Int_Req->iDiscQty != atoi(Row[10])  || Int_Req->iDiscRemQty != atoi(Row[11]) || Int_Req->iValidity != atoi(Row[12]))
                                        {
                                                logDebug3("Modify Success");
                                                mysql_free_result(Res);
                                                return TRUE;
                                        }
                                        else
                                        {
                                                logDebug3("Nothing to Modify");
                                                mysql_free_result(Res);
                                                fSendErrorToFE(Int_Req,NOTHING_TO_MODIFY,Int_Req->iTotalQty,Int_Req->fOrderPrice);
                                                return NO_MODIFICATION;
                                        }
                                }
                                else
                                {
                                        mysql_free_result(Res);
                                        Int_Req->iTotalTradedQty = atoi(Row[9]);
                                        Int_Req->fTrdPrice = atof(Row[13]);
                                        Int_Req->iLstTrdQty = atoi(Row[8]);
                                        Int_Req->iRemQty = atoi(Row[4]);
                                        Int_Req->iTotalQty = Int_Req->iRemQty;
                                        logDebug3("Cancellation Order");
                                        return TRUE;
                                }
                        }
                }
		else
                {
                        logDebug3("Serial check Not ok");
                        mysql_free_result(Res);
                        if(Row[5][0] == TRADED_STATUS)
                        {
                                logDebug2("Serial check Not OK.Order Is Traded");
                                return RET_TRADED_STAT;

                        }
                        else
                        {
                                Int_Req->iSerialNo = atoi(Row[0]) + 1;
                                logDebug2("Serial check Not OK");
                                return FALSE;
                        }

                }

        }
        logTimestamp(" EXIT [fFetchSerialNo]");
}
 
	
          
