#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include <stdio.h>
#include "IPCS.h"

MYSQL    *DB_Conn;

void main(LONG32 argc, char *argv[]) 
{

	logDebug2("entry [ Etest]");

	CHAR sExchID [5];
	CHAR cSegment;
	CHAR execute [30];
	INT16 iStatus;
	INT16 iExchOption;

	MYSQL_RES      *Res;
	MYSQL_ROW       Row;

	CHAR *sSelQury = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR *sProdCal = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	setbuf(stdin,0);
	setbuf(stdout,0);

	DB_Conn = DB_Connect();

	logDebug2("Here we are :%d:",argc);
	iExchOption = atoi(argv[1]);
	logDebug1("iExchOption = %d ",iExchOption);

	if(mysql_set_server_option(DB_Conn,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
	}

	switch(iExchOption)
	{
		case 1:
			strcpy(sExchID,NSE_EXCH);
			cSegment = SEGMENT_EQUITY;
			break;
		case 2:
			strcpy(sExchID,NSE_EXCH);
			cSegment = SEGMENT_FNO;
			break;
		case 3:
			strcpy(sExchID,NSE_EXCH);
			cSegment = SEGMENT_CURRENCY;
			break;
		case 4:
			strcpy(sExchID,BSE_EXCH);
			cSegment = SEGMENT_EQUITY;
			break;
		case 5:
			strcpy(sExchID,MCX_EXCH);
			cSegment = SEGMENT_COMMODITY;
			break;
		default :
			printf("Invalid Option : = %d ",iExchOption);

			return;

	};

	sprintf(sSelQury,"SELECT BP_NEXT_SCHEDULE_DATE as DATE_NOW \
			FROM BATCH_PROCESS \
			WHERE BP_EXCH_ID = \'%s\' AND BP_SEGMENT=\'%c\'  AND BP_BATCH_NAME = 'EOD_BOD'; ",sExchID,cSegment);

	logDebug3("sSelQury :%s:",sSelQury);

	if(mysql_query(DB_Conn,sSelQury) != SUCCESS)
	{
		sql_Error(DB_Conn);
	}	

	Res = mysql_store_result(DB_Conn);

	Row = mysql_fetch_row(Res);

	logDebug2("DATE_NOW :%s:",Row[0]);

	mysql_free_result(Res);

	sprintf(sProdCal,"call PR_EOD_BOD(STR_TO_DATE((\'%s\'),'%%Y-%%m-%%d %%H:%%i:%%S'),\'EOD_BOD\',\'%c\',\'%s\',@ZSTATUS);\									 SELECT @ZSTATUS ;",Row[0],cSegment,sExchID);

	logDebug2("sProdCal :%s:",sProdCal);		

	if(mysql_query(DB_Conn,sProdCal) != SUCCESS)
	{        
		sql_Error(DB_Conn);		
	}

	do{

		Res = mysql_store_result(DB_Conn);

		if(Res)
		{	
			if((Row = mysql_fetch_row(Res)));
			{	
				strncpy(execute,Row[0],30);
				logDebug2("STATUS :%s:",execute);
				mysql_free_result(Res);
			}	
		}	
		else
		{
			logDebug2("No Result Set ");
		}	

		if((iStatus =mysql_next_result(DB_Conn)) > 0)
		{
			logDebug3("Could not execute statement");
		}
	}while(iStatus == 0);

	if(strncmp(execute,"S",1) == 0)
	{
		logDebug1(" SUCCESS ");
		return TRUE;

	}	

	else 
	{
		logDebug1(" FAIL ");
	}

}









