#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include "hiredis.h"

MYSQL 	*DBconRMS;
LONG32	iTrdRtrToRms;
LONG32	iMmapToNotifyFE;
LONG32	iBCmBranchId;
LONG32	iNCmBranchId;
LONG32	iMsgType = 0;
CHAR	cMessageType;

LONG32  iThreshold ;
BOOL    iTrdNofyFlag = FALSE;
CHAR    sTradeNotfUrl[100];

MYSQL_RES       *Res;
MYSQL_ROW       Row;
CHAR flag[1];
redisContext *c;
redisReply *reply;
LONG64	iSleepSec =1000;
main(int argc ,char *argv[])
{
	logTimestamp("Entry : [main]");

	DBconRMS = DB_Connect();

	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);

	//cMessageType = argv[1][0];	
	iMsgType = atoi(argv[1]);
	logInfo("Sleep time iSleepSec :%s:",argv[2]);
	iSleepSec = atol(argv[2]); 
	logInfo("Sleep time iSleepSec :%s:",argv[2]);
	//	fLoadEnv();
	logInfo("Sleep time iSleepSec :%d:",iSleepSec);
	if(iSleepSec <= 0)
	{
		logInfo("iSleepSec Sleep time cannot be 0 . So setting sleep to default value 3 sec");
		//iSleepSec = 3 ;
		iSleepSec = 1000*1000;
	}
	else 
	{
		logInfo("iSleepSec taken from argument");
		iSleepSec = iSleepSec*1000;
	}
	
	fLoadEnvVar();
	//fLoadTrdEnv();
/*	if(getenv("NOTIFY_FE")==NULL)
	{
		logFatal("Error : Environment variables missing : NOTIFY_FE");
		exit(ERROR);
	}

	else
	{
		strcpy(flag,getenv("NOTIFY_FE"));
		logDebug2("flag   :%s:",flag);
	}*/
	c = RDConnect(REDIS_TYPE_RMS_VALIDATION);


//	logTimestamp("Entry : [OpenMsgQue]");

	//        if((iTrdRtrToRms = OpenMsgQ(MmapToRevRmsVal)) == ERROR)
	//        if((iTrdRtrToRms = OpenMsgQ(TrdRtrToRevRmsVal)) == ERROR)
/*	if((iTrdRtrToRms = OpenMsgQ(CatalystToRmsVal)) == ERROR)
	{
		logFatal("OpenMsgQ ...TrdRtrToRevRmsVal");
		exit(ERROR);
	}
	logInfo("TrdRtrToRevRmsVal opened successfully with id = %d", iTrdRtrToRms);*/

/*	if((iMmapToNotifyFE = OpenMsgQ(MmapToNotifyFE)) == ERROR)
	{
		printf("\nOpenMsgQ : Error in opening MmapToD2C1");
		exit(ERROR);
	}

*/
	ProcessRMS(iTrdRtrToRms);	
	logTimestamp("Exit : [main]");	
}

void	ProcessRMS(LONG32 iRcvQue)
{
	logTimestamp("Entry : [ProcessRMS]");


	INT16           iNumRow;
	int		i;
	LONG32		iMsgCode;
	CHAR    	RcvMsg[ RUPEE_MAX_PACKET_SIZE ] ;
	INT16           iStatus;
	DOUBLE64 	fMargin,fRealzPro;
	CHAR		sDescriptor [DESCRIPTOR_LEN];
	struct  	ORDER_RESPONSE	pRmsReq;
	INT16		iCount= 0;
	LONG32		iBranchId;
	DOUBLE64	fstart;
	DOUBLE64        fEnd;
	LONG32          iRetVal;
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];
        CHAR sSmemKey[RADIS_KEY_LEN];
        CHAR sKeyValue[50];
	redisReply *reply1;
	logDebug2("iMsgType = %d",iMsgType);
	CHAR Pr_Query[MAX_QUERY_SIZE];

	/**if(mysql_set_server_option(DBconRMS,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILS");
	}**/

	while(TRUE)
	{
		memset(&RcvMsg,        '\0' ,RUPEE_MAX_PACKET_SIZE);
		memset ( &pRmsReq,      '\0' ,sizeof(struct ORDER_RESPONSE));
		memset(sSmemKey,'\0',RADIS_KEY_LEN);

		memset(Pr_Query, '\0',MAX_QUERY_SIZE);
		memset(sDescriptor, '\0',DESCRIPTOR_LEN);
		memset(sKeyValue, '\0',50);

		sprintf(sSmemKey,"SET:REV:%d:%d",iMsgType,GROUPID);
                memset(sCommand,'\0',COMMAND_LEN);
                sprintf(sCommand,"SMEMBERS %s ",sSmemKey);
		reply = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);

		for(i=0 ; i<reply->elements ;i++)
		{
			memset ( &pRmsReq,      '\0' ,sizeof(struct ORDER_RESPONSE));
			memset(sKeyValue,'\0',RADIS_KEY_LEN);
			logDebug2("reply->element[%d]->str %s",i,reply->element[i]->str);
			logDebug2("reply->len :%d:",reply->len);
			
			if(reply->element[i]->str != NULL)
			{
		
				sprintf(sKeyValue,"%s",reply->element[i]->str);
				memset(sCommand,'\0',COMMAND_LEN);
				sprintf(sCommand,"EXISTS %s ",sKeyValue);
				logDebug2("KEY VALUE %s",sKeyValue);
				//reply1= redisCommand(c,sCommand);
				reply1 = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);

				if(reply1->integer == TRUE)
				{
				
					memset(sCommand,'\0',COMMAND_LEN);
					sprintf(sCommand,"HMGET %s CALLFLAG CLIENTID PRODUCTID EXCH SEGMENT SECURITYID ORDERNO MSGCODE MKT_TYPE ",sKeyValue);
					logDebug2("KEY VALUE %s",sKeyValue);
					//reply1= redisCommand(c,sCommand);
					reply1 = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);
					logDebug2("reply->len %d",reply1->len);				
					logDebug2("CALLFLAG %s",reply1->element[0]->str);				
					logDebug2("CLIENTID %s",reply1->element[1]->str);				
					logDebug2("PRODUCTID %s",reply1->element[2]->str);				
					logDebug2("EXCH %s",reply1->element[3]->str);				
					logDebug2("SEGMENT %s",reply1->element[4]->str);				
					logDebug2("SECURITYID %s",reply1->element[5]->str);				
					logDebug2("ORDERNO %s",reply1->element[6]->str);				
					logDebug2("MSGCODE %s",reply1->element[7]->str);				
					logDebug2("MKT_TYPE %s",reply1->element[8]->str);				
					pRmsReq.IntRespHeader.iMsgCode = atoi(reply1->element[7]->str);
					pRmsReq.IntRespHeader.cSegment = reply1->element[4]->str[0];
					sprintf(pRmsReq.IntRespHeader.sExcgId,"%s",reply1->element[3]->str);
					strcpy(pRmsReq.sSecurityId,reply1->element[5]->str);
					sprintf(pRmsReq.sClientId,"%s",reply1->element[1]->str);
					pRmsReq.cProductId = reply1->element[2]->str[0];

			
					freeReplyObject(reply1);
					memset(sCommand,'\0',COMMAND_LEN);
					sprintf(sCommand,"SREM SET:REV:%d:%d %s",iMsgType,GROUPID,sKeyValue);
					logTimestamp("sCommand -> %s",sCommand);
					//reply1 = redisCommand(c,sCommand);
					reply1 = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);
					freeReplyObject(reply1);
			
					logDebug2("pRmsReq.sClientId :%s:",pRmsReq.sClientId);
					logDebug2("pRmsReq.cProductId :%c:",pRmsReq.cProductId);
					logDebug2("pRmsReq.IntRespHeader.iMsgCode:%d:",pRmsReq.IntRespHeader.iMsgCode);
					logDebug2("pRmsReq.IntRespHeader.cSegment:%c:",pRmsReq.IntRespHeader.cSegment);
					logDebug2("pRmsReq.IntRespHeader.sExcgId:%s:",pRmsReq.IntRespHeader.sExcgId);
					logDebug2("pRmsReq.cProductId :%c:",pRmsReq.cProductId);

					if(pRmsReq.cProductId != PROD_CNC && pRmsReq.cProductId != PROD_MTF)
					{
			
						sprintf(Pr_Query,"CALL REVERSE_VALIDATE_COMBINED(LTRIM(RTRIM(\"%s\")),LTRIM(RTRIM(\"%s\")),\'%c\',\'%c\',LTRIM(RTRIM(\"%s\")),@NUMMARGIN,@V_RELZ_PNL_ORGINAL, @V_DESCRIPTOR); SELECT IFNULL(@NUMMARGIN,0), IFNULL(@V_RELZ_PNL_ORGINAL,0),IFNULL(@V_DESCRIPTOR,\'Returns NULL VALUES\');",pRmsReq.sClientId,pRmsReq.IntRespHeader.sExcgId,pRmsReq.IntRespHeader.cSegment,pRmsReq.cProductId,pRmsReq.sSecurityId);
		
						logDebug2("Pr_Query = %s",Pr_Query);
		
						logDebug2("RMS REVERSE_VALIDATE Executing Here Starttime :%lf:",fstart);
						logTimestamp("Calling Rms_rev_Validate [Start time]");
						if(mysql_query(DBconRMS,Pr_Query) != SUCCESS)
						{
							sql_Error(DBconRMS);
							logFatal("Error IN CALLING RMS_VALIDATE .");
							continue;
						}
						logTimestamp("Calling Rms_rev_Validate [END time]");
		
						do{
							Res = mysql_store_result(DBconRMS);
							if(Res)
							{
								if((Row = mysql_fetch_row(Res)))
								{
									fMargin = atof(Row[0]);
									fRealzPro = atof(Row[1]);
									strncpy(sDescriptor,Row[2],DESCRIPTOR_LEN);
									mysql_free_result(Res);
									logInfo("Client:%s: fMargin :%lf: fRealzPro:%lf:",pRmsReq.sClientId,fMargin,fRealzPro);
									logDebug3("DESCRIPTOR STRING ===> :%s:<===",sDescriptor);
								}
							}
							else
							{
								logDebug2("No Result Set ");
							}	
			
							logDebug2(" Before mysql_next_result");
							if((iStatus = mysql_next_result(DBconRMS)) > 0)
							{
								logDebug3("Could not execute statement");
							}
	
						}while(iStatus == 0);

					}
					else if(pRmsReq.cProductId == PROD_CNC || pRmsReq.cProductId == PROD_MTF)
					{
						logDebug2("iMktype :%d:",pRmsReq.iMktType);
	
						sprintf(Pr_Query,"CALL REVERSE_VALIDATE_CNC(LTRIM(RTRIM(\"%s\")),LTRIM(RTRIM(\"%s\")),LTRIM(RTRIM(\"%s\")),\'%c\'); ",pRmsReq.sClientId,pRmsReq.IntRespHeader.sExcgId,pRmsReq.sSecurityId,pRmsReq.cProductId);

						logDebug2("Pr_Query = %s",Pr_Query);

						logDebug2("REVERSE_VALIDATE_CNC REVERSE_VALIDATE Executing Here Starttime :%lf:",fstart);
						logTimestamp("Calling Rms_rev_Validate [Start time]");
						if(mysql_query(DBconRMS,Pr_Query) != SUCCESS)
						{
							sql_Error(DBconRMS);
							logFatal("Error IN CALLING RMS_VALIDATE .");
							continue;
						}
						logTimestamp("Calling Rms_rev_Validate [END time]");
					}
                                        if (pRmsReq.IntRespHeader.iMsgCode == TC_INT_TRADE_RESP)
                                        {
                                                memset(sCommand,'\0',COMMAND_LEN);
                                                sprintf(sCommand," SADD FUND_ALLOCATION_CLIENT '%s' ",pRmsReq.sClientId);
                                                logTimestamp("sCommand -> %s",sCommand);
                                                reply1 = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);
                                                freeReplyObject(reply1);
                                        }
				//usleep(300000);
				}
				else
				{	
					freeReplyObject(reply1);
					memset(sCommand,'\0',COMMAND_LEN);
					sprintf(sCommand,"SREM SET:REV:%d:%d %s",iMsgType,GROUPID,sKeyValue);
					logTimestamp("sCommand -> %s",sCommand);
					reply1 = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);
					freeReplyObject(reply1);
				}
			}
		}
		freeReplyObject(reply);
		usleep(iSleepSec);



	}	

	logTimestamp("Exit : [ProcessRMS]");
}

BOOL fDlrBrchLmt(struct ORDER_RESPONSE *oRes)
{
	logTimestamp("Entry : fDlrBrchLmt:");

	CHAR sLmtQry[MAX_QUERY_SIZE];
	CHAR  sLmtClientId[CLIENT_ID_LEN];
	memset(sLmtQry,'\0',MAX_QUERY_SIZE);
	memset(sLmtClientId,'\0',CLIENT_ID_LEN);

	logDebug2("oRes->sEntityId :%s:", oRes->sEntityId);
	strncpy(sLmtClientId ,oRes->sEntityId,ENTITY_ID_LEN);

	sprintf(sLmtQry,"CALL PR_DL_BR_LIMIT (\"%s\");",sLmtClientId);
	logDebug2(":%s:",sLmtQry);

	if (mysql_query(DBconRMS,sLmtQry) != SUCCESS)
	{
		sql_Error(DBconRMS);
		logFatal("Error IN CALLING Procedure Query .");
		return FALSE;
	}

	logTimestamp("Exit : [fDlrBrchLmt]");
	return TRUE;


}



BOOL fSprdRevValid(CHAR *sSprdPck)
{
	logTimestamp("Entry :fSprdRevValid:");

	CHAR	sPrdCall[MAX_QUERY_SIZE];
	CHAR            sDescriptor [DESCRIPTOR_LEN];
	CHAR            sClientID[CLIENT_ID_LEN];
	memset(sPrdCall,'\0',MAX_QUERY_SIZE);
	memset(sDescriptor,'\0',DESCRIPTOR_LEN);
	memset(sClientID,'\0',CLIENT_ID_LEN);
	INT16           iStatus= 0;
	DOUBLE64        fMargin=0.00,fRealzPro=0.0;

	struct	ORDER_SPREAD_RESPONSE	*pSpredRes;
	pSpredRes = (struct ORDER_SPREAD_RESPONSE *)sSprdPck;

	//	struct ORDER_SPREAD_RESPONSE *pSprdResp = (struct ORDER_SPREAD_RESPONSE *) sSprdPck;	
	//	logDebug2("(struct ORDER_SPREAD_RESPONSE *)sSprdPck->sClientId :%s:",((struct ORDER_SPREAD_RESPONSE *)sSprdPck)->sClientId);
	//	strncpy(sClientID,((struct ORDER_SPREAD_RESPONSE *)sSprdPck)->sClientId,CLIENT_ID_LEN);	

	logDebug2("pSpredRes->sClientId = %s",pSpredRes->sClientId);
	logDebug2("pSpredRes->IntRespHeader.sExcgId = %s",pSpredRes->IntRespHeader.sExcgId);
	logDebug2("pSpredRes->IntRespHeader.cSegment = %c",pSpredRes->IntRespHeader.cSegment);		

	/**sprintf(sPrdCall,"CALL REVERSE_VALIDATE (LTRIM(RTRIM(\"%s\")),\"%s\",\'%c\','','','','',0.00,0.00,@NUMMARGIN, @V_RELZ_PNL_ORGINAL, @V_DESCRIPTOR);\
			SELECT @NUMMARGIN, @V_RELZ_PNL_ORGINAL, IFNULL(@V_DESCRIPTOR,'Returns NULL VALUES');",pSpredRes->sClientId,pSpredRes->IntRespHeader.sExcgId,\
			pSpredRes->IntRespHeader.cSegment);**/

	
	sprintf(sPrdCall,"CALL REVERSE_VALIDATE_COMBINED(LTRIM(RTRIM(\"%s\")),LTRIM(RTRIM(\"%s\")),\'%c\',\'\',\"\",\
                        @NUMMARGIN,@V_RELZ_PNL_ORGINAL, @V_DESCRIPTOR); SELECT IFNULL(@NUMMARGIN,0), IFNULL(@V_RELZ_PNL_ORGINAL,0),\
                        IFNULL(@V_DESCRIPTOR,\'Returns NULL VALUES\');",pSpredRes->sClientId,pSpredRes->IntRespHeader.sExcgId,pSpredRes->IntRespHeader.cSegment);
	logDebug2(":%s:",sPrdCall);

	if(mysql_query(DBconRMS,sPrdCall) != SUCCESS)
	{
		sql_Error(DBconRMS);
		logFatal("Error IN CALLING RMS_VALIDATE .");
		return FALSE;
		//exit(ERROR);
	}

	do{
		Res = mysql_store_result(DBconRMS);
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{	
				fMargin = atof(Row[0]);
				fRealzPro = atof(Row[1]);
				strncpy(sDescriptor,Row[2],DESCRIPTOR_LEN);
				mysql_free_result(Res);
				logInfo("Client:%s: fMargin :%lf: fRealzPro:%lf:",pSpredRes->sClientId,fMargin,fRealzPro);
				logDebug3("DESCRIPTOR STRING ===> :%s:<===",sDescriptor);
			}
		}
		else
		{
			logDebug2("No Result Set ");
		}
		logDebug2(" Before mysql_next_result");
		if((iStatus = mysql_next_result(DBconRMS)) > 0)
		{
			logDebug3("Could not execute statement");
		}
	}while(iStatus == 0);


	logTimestamp("Exit : [fSprdRevValid]");
	return TRUE;

}
BOOL	fLoadEnvVar()
{
	logTimestamp("fLoadEnvVar [entry]");

	CHAR    sQry [MAX_QUERY_SIZE];
	CHAR	sExch[EXCHANGE_LEN];	
	memset(sQry,'\0',MAX_QUERY_SIZE);
	sprintf(sQry,"select EAM_EXM_EXCH_ID,EAM_BRANCH_ID from EXCH_ADMINISTRATION_MASTER\
			where EAM_SEGMENT = \'%c\';",EQUITY_SEGMENT);

	logDebug2("Qry = %s",sQry);

	if (mysql_query(DBconRMS,sQry) != SUCCESS)
	{
		logSqlFatal("Error in select Qry");
		sql_Error(DBconRMS);
	}
	Res = mysql_store_result(DBconRMS);

	logDebug2("****************");
	while(Row = mysql_fetch_row(Res))
	{      

		memset(sExch,'\0',EXCHANGE_LEN);
		strncpy(sExch,Row[0],EXCHANGE_LEN);
		logDebug2("sExch = %s",sExch);

		if(strcmp(sExch,NSE_EXCH) == 0)
		{
			iNCmBranchId= atoi(Row[1]);
			logDebug2("iNCmBranchId= %d",iNCmBranchId);
		}
		else
		{	
			iBCmBranchId = atoi(Row[1]);
			logDebug2("iBCmBranchId= %d",iBCmBranchId);

		}
	}        
	mysql_free_result(Res);
	logTimestamp("fLoadEnvVar [exit]");
	//        free(sQry);
}



void    fLoadTrdEnv()
{
	logTimestamp("Entry :fLoadTrdEnv:");


	if(getenv("THRESHOLD_TRADE_NOTIFICATION") != NULL)
	{
		iThreshold = atoi(getenv("THRESHOLD_TRADE_NOTIFICATION"));
	}
	else
	{
		logInfo("Setting it as default :70:");
		iThreshold = 70;
	}

	if(getenv("TRADE_RESPONSE_NOTIFICATION") != NULL)
	{
		iTrdNofyFlag = atoi(getenv("TRADE_RESPONSE_NOTIFICATION"));
	}
	else
	{
		logInfo("TRADE_RESPONSE_NOTIFICATION as default :FALSE:");
		iTrdNofyFlag = FALSE;
	}

	if(getenv("NOTIFY_TRADE_URL") != NULL)
	{
		//              iTrdNofyFlag = atoi(getenv("TRADE_RESPONSE_NOTIFICATION"));
		memset(&sTradeNotfUrl,'\0',100);
		strncpy(sTradeNotfUrl,getenv("NOTIFY_TRADE_URL"),100);
	}
	else
	{
		logFatal("NOTIFY_TRADE_URL is NULL ");
		exit(ERROR);
	}
	logTimestamp("Exit :fLoadTrdEnv:");
}

BOOL fSendTradesToFE(struct ORDER_RESPONSE *OrdResp)
{
	logTimestamp("fSendTradesToFE [ENTRY]");

	CHAR sTradeNum [TRADE_NO_LEN];
	CHAR sFileName[FILE_NAME_LEN];

	memset(sFileName,'\0',FILE_NAME_LEN);
	memset(sTradeNum,'\0',TRADE_NO_LEN);

	if(OrdResp->iTotalTradedQty >= OrdResp->iTotalQty*iThreshold/100 || OrdResp->iTotalTradedQty == OrdResp->iTotalQty)
	{
		fNotifyTradesToFE(iTrdNofyFlag,OrdResp,&sTradeNotfUrl);

	}
	else
	{
		logInfo("Trade : But less than threshold. So not sending notification.");

	}
}

BOOL fNotifyTradeToFE(struct ORDER_RESPONSE *Ord_Res)
{
	logTimestamp("fNotifyTradesToFE [ENTRY]");
	//LONG32 iFlag = 0 ;

	//iFlag =       atoi(getenv("TRADE_RESPONSE_NOTIFICATION"));

	logDebug2("Sending Trade Notifications");
	CHAR sCmd[COMMAND_LEN];
	memset(sCmd,'\0',COMMAND_LEN);
	//sprintf(sCmd,"%s/SendTradeToFE.py >> %s/log.TradeNotification &",getenv("PYTHON_PATH"),getenv("LOGDIR"));
	sprintf(sCmd,"%d | %d | %d | %s | %d | %d | %c | %d | %c | %s | %s | %s | %s | %c | %c | %d | %d | %d | %d | %d | %d | %d | %d | %d | %f | %f | %f | %d | %s |\
			%f | %c | %f | %d | %c | %c | %c | %s | %s | %s | %d | %s | %s | %d | %s | %c | %f | %c | %s | %c | %c | %s ",Ord_Res->IntRespHeader.iSeqNo,Ord_Res->IntRespHeader.iMsgLength,Ord_Res->IntRespHeader.iMsgCode,Ord_Res->IntRespHeader.sExcgId,Ord_Res->IntRespHeader.iErrorId,Ord_Res->IntRespHeader.iUserId,Ord_Res->IntRespHeader.cSource,Ord_Res->IntRespHeader.iTimeStamp,Ord_Res->IntRespHeader.cSegment,Ord_Res->sSecurityId, Ord_Res->sEntityId , Ord_Res->sClientId , Ord_Res->sExchOrderID, Ord_Res->cProductId, Ord_Res->cBuyOrSell, Ord_Res->iOrderType, Ord_Res->iOrderValidity, Ord_Res->iDiscQty, Ord_Res->iDiscQtyRem, Ord_Res->iTotalQtyRem,  Ord_Res->iTotalQty , Ord_Res->iLastTradedQty,  Ord_Res->iTotalTradedQty, Ord_Res->iMinFillQty, Ord_Res->fPrice, Ord_Res->fTriggerPrice, Ord_Res->fOrderNum , Ord_Res->iSerialNum , Ord_Res->sTradeNo, Ord_Res->fTradePrice, Ord_Res->cHandleInst, Ord_Res->fAlgoOrderNo, Ord_Res->iStratergyId, Ord_Res->cOffMarketFlg, Ord_Res->cProCli, Ord_Res->cUserType, Ord_Res->sOrdEntryTime, Ord_Res->sTransacTime, Ord_Res->sRemarks,  Ord_Res->iMktType, Ord_Res->sReasonDesc, Ord_Res->sGoodTillDaysDate, Ord_Res->iLegValue, Ord_Res->sTradeNum, Ord_Res->cMarkProFlag, Ord_Res->fMarkProVal, Ord_Res->cParticipantType, Ord_Res->sSettlor, Ord_Res->cGTCFlag, Ord_Res->cEncashFlag, Ord_Res->sPanID);
	logDebug2("Command -> %s",sCmd);
	system(sCmd);
	logTimestamp("fNotifyTradesToFE [EXIT]");
	return TRUE ;


}

