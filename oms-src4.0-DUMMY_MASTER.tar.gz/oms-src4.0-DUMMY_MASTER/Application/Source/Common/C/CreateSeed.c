# include    <stdio.h>
# include    <memory.h>
# include    <malloc.h>
# include    <string.h>
# include    <sys/types.h>
# include    <sys/ipc.h>
# include    <sys/sem.h>
# include    <sys/errno.h>
# include    <sys/stat.h>
# include    <sys/wait.h>
# include    <sys/msg.h>
# include    <sys/ipc.h>
# include    "IPCS.h"
CHAR    sLicPath [100];
CHAR    sFilePath[100];
BOOL	CheckLicense();
void Unscramble(char *sStr);

main()
{
	//logTimestamp("Entry : [main]");
	int             test;
	int             md;
	int             i,j;
	struct          user_relay_array   	*DirRelShm_mem		;
	struct          user_relay_array   	*AdmRelShm_mem		;
	struct          ProcessMonitorArray   	*ProcessMonitor_mem	;
	struct          PMonitor_array          *PMonitorShm_mem    	; 

	struct 		ADMIN_ADAPTER_USER_ARRAY *AdminRelayUserShm_mem	;
	struct 		ADMIN_ADAPTER_USER_ARRAY *AdminQueryUserShm_mem;
	struct		USER_DETAIL_ARRAY	*Equ_User_Dtl_Shm_mem	;

	struct		SEC_MASTER_ARRAY 	*Hash_ByID;
	struct 		DWS_ADAPTER_USER_ARRAY		*DWSRelayUserShm_mem;	
	struct 		DWS_ADAPTER_USER_ARRAY		*DWSD2C1UserShm_mem;	
	int             * LockVar;
	int             ShmSize;
	struct 		EXCH_CONNECT_STATUS *ConnStatusShm_mem;
	struct 		InvitationCount		*NseEquInvMem	;
	struct 		InvitationCount		*NseDrvInvMem	;
	struct 		InvitationCount		*NseCurrInvMem	;
	struct 		InvitationCount		*NseMFInvMem	;
	struct 		InvitationCount		*NCMInvMem	;
	struct		ADMIN_ADAPTER_USER_ARRAY	*AdminD2C1UserShm_mem;
	BOOL		iChkFlag = FALSE;
	Loadenv();
	iChkFlag = CheckLicense();	

	if(iChkFlag == TRUE)
	{
		printf("Your License Is Active\n");
	}
	else
	{
		printf("Your Licence Is Expired.!!! Kindly Update Your Licence\n");
		exit(ERROR);
	}

	printf("This is log Debug1\n ");	

	if(CreateSharedMemory( LogLevelShm, LogLevelShm_SIZE) == ERROR )
	{
		perror("LogLevelShm failed ");
		exit(1);
	}
	printf("This is log Debug2\n ");	
	/*********/
	if(CreateSharedMemory( LockSystem, LockSystem_SIZE) == ERROR )
	{
		logFatal("LockSystem failed ");
		exit(1);
	}
	else
	{
		if((LockVar = (int *)OpenSharedMemory(LockSystem,LockSystem_SIZE)) == (int *)ERROR)
		{
			logFatal("LockSystem:Open error");
			exit(1);
		}
		//		if ( (*LockVar) == 87654324 )
		if ( (*LockVar) == 88654327 )
		{
			logInfo( "System is Already running, Stop it and run again");
			exit (2);
		} 
		else
		{
			(*LockVar) = 88654327;
		}
		if ( CloseSharedMemory( (void * ) LockVar ) == ERROR )
		{
			logFatal("Error in Closing LockSystem ");
			exit(1);
		}

	}
	/*********/

	printf("This is log Debug3\n ");	
	if (CreateSharedMemory(DirRelShm,DirRelShm_SIZE) == ERROR)
	{
		printf("\nDirRelShm Failed");
		exit(1);
	}
	else
	{
		if((DirRelShm_mem = (struct user_relay_array *)OpenSharedMemory(DirRelShm,DirRelShm_SIZE)) == (struct user_relay_array *)ERROR)
		{
			perror("DirRelShm:Open error");
			exit(1);
		}

		for(i=0; i < MAX_DWS_USERS ; i ++)
		{
			DirRelShm_mem->user_relay[i].iRelayId = UNUSED;
			DirRelShm_mem->user_relay[i].iUserId = UNUSED;
			DirRelShm_mem->user_relay[i].iCheck = UNUSED;
			DirRelShm_mem->user_relay[i].iProcessId = UNUSED;
			memset( DirRelShm_mem->user_relay[i].sClientId , ' ' , CLIENT_ID_LEN) ;
			DirRelShm_mem->user_relay[i].cUserType = ' ';
		}
		if ( CloseSharedMemory( (void * ) DirRelShm_mem ) == ERROR )
		{
			perror("Error in Closing DirRelShm_mem");
			exit(1);
		}
	}

	printf("This is log Debug3\n ");
        if (CreateSharedMemory(AdmRelShm,AdmRelShm_SIZE) == ERROR)
        {
                printf("\nAdmRelShm Failed");
                exit(1);
        }
        else
        {
                if((AdmRelShm_mem = (struct user_relay_array *)OpenSharedMemory(AdmRelShm,AdmRelShm_SIZE)) == (struct user_relay_array *)ERROR)
                {
                        perror("AdmRelShm :Open error");
                        exit(1);
                }

                for(i=0; i < MAX_DWS_USERS ; i ++)
                {
                        AdmRelShm_mem->user_relay[i].iRelayId = UNUSED;
                        AdmRelShm_mem->user_relay[i].iUserId = UNUSED;
                        AdmRelShm_mem->user_relay[i].iCheck = UNUSED;
                        AdmRelShm_mem->user_relay[i].iProcessId = UNUSED;
                        memset( AdmRelShm_mem->user_relay[i].sClientId , ' ' , CLIENT_ID_LEN) ;
                        AdmRelShm_mem->user_relay[i].cUserType = ' ';
                }
                if ( CloseSharedMemory( (void * ) AdmRelShm_mem ) == ERROR )
                {
                        perror("Error in Closing AdmRelShm_mem ");
                        exit(1);
                }
        }

	printf("This is log Debug4\n ");	
	if((CreateSharedMemory(InvitationCountShm,InvitationCountShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of InvitationCountShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseEquInvMem = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for InvitationCountShm Status\n");
			exit(1);
		}

		NseEquInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseEquInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseEquInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseEquInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseEquInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseEquInvMem");
			exit(1);
		}
	}	

	printf("This is log Debug5\n ");	

	if((CreateSharedMemory(DrvInvitatnCntShm,DrvInvitatnCntShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of DrvInvitatnCntShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseDrvInvMem = (struct InvitationCount *)OpenSharedMemory(DrvInvitatnCntShm ,DrvInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for DrvInvitatnCntShm Status\n");
			exit(1);
		}

		NseDrvInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseDrvInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseDrvInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseDrvInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseDrvInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseDrvInvMem");
			exit(1);
		}
	}
	printf("This is log Debug6\n ");	

	if((CreateSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of CurrInvitatnCntShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseCurrInvMem = (struct InvitationCount *)OpenSharedMemory(CurrInvitatnCntShm ,CurrInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for CurrInvitatnCntShm Status\n");
			exit(1);
		}

		NseCurrInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseCurrInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseCurrInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseCurrInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseCurrInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseCurrInvMem");
			exit(1);
		}
	}
	printf("This is log Debug7\n ");	

	if((CreateSharedMemory( Bse_Conn_Shm_1 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_1 Failed");
		exit(1);
	}

	if((CreateSharedMemory( Bse_Conn_Shm_2 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_2 Failed");
		exit(1);
	}
	if((CreateSharedMemory( Bse_Conn_Shm_3 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_3 Failed");
		exit(1);
	}

	if((CreateSharedMemory( Bse_Conn_Shm_4 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_4 Failed");
		exit(1);
	}

        if((CreateSharedMemory( Bse_CConn_Shm_1 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_1 Failed");
                exit(1);
        }

        if((CreateSharedMemory( Bse_CConn_Shm_2 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_2 Failed");
                exit(1);
        }
        if((CreateSharedMemory( Bse_CConn_Shm_3 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_3 Failed");
                exit(1);
        }

        if((CreateSharedMemory( Bse_CConn_Shm_4 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_4 Failed");
                exit(1);
        }

	if((CreateSharedMemory(MfssInvitatnCntShm,MfssInvitatnCntShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of MfssInvitatnCntShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseMFInvMem= (struct InvitationCount *)OpenSharedMemory(MfssInvitatnCntShm ,MfssInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for MfssInvitatnCntShm Status\n");
			exit(1);
		}

		NseMFInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseMFInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseMFInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseMFInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseMFInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseMFInvMem");
			exit(1);
		}
	}
	/***********
	  if(CreateSharedMemory(Equ_User_Dtl_Shm,Equ_User_Dtl_Shm_SIZE) == ERROR)
	  {
	  logFatal("Shared Memory Creation Failed for EQU_USER_MASTER");
	  exit(1);
	  }
	  else
	  {
	  if((Equ_User_Dtl_Shm_mem = (struct USER_DETAIL_ARRAY *)OpenSharedMemory(Equ_User_Dtl_Shm,Equ_User_Dtl_Shm_SIZE)) == ERROR)
	  {
	  logFatal("Failed in Opening Shared Memory EQU_USER_MASTER_ARRAY" );
	  }
	  else
	  {
	  for(i = 0 ;i < MAX_NO_OF_USERS_SHM ;i++)
	  {
	  Equ_User_Dtl_Shm_mem -> User_Dtl[i].iUserId = 0;
	  Equ_User_Dtl_Shm_mem -> User_Dtl[i].iUserGrpId = 0;
	  strncpy(Equ_User_Dtl_Shm_mem -> User_Dtl[i].sLocationCode,"0.0",LOC_CODE_LEN);
	  }
	  Equ_User_Dtl_Shm_mem -> iNoOfUsers = 0;

	  if ( CloseSharedMemory( (void * ) Equ_User_Dtl_Shm_mem ) == ERROR )
	  {
	  logFatal("Error in Closing Equ_User_Master_mem");
	  exit(1);
	  }

	  }
	  }
	 **********/	
	printf("This is log Debug8\n ");	

	if (SemophoreCreate(LogFatalShm) == ERROR)
	{
		perror("LogFatalShm Failed");
		exit(1);
	}

	printf("This is log Debug9\n ");	
	/*****/
	if (SemophoreCreate(ProcessDataLock1) == ERROR)
	{
		logFatal("ProcessDataLock Failed");
		exit(1);
	}
	/********/
	if (CreateSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)==ERROR)
	{
		perror("Shared memory creation for ConnStatusShm failed");
		exit(1);
	}
	else
	{
		if((ConnStatusShm_mem = (struct EXCH_CONNECT_STATUS *)OpenSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)) == (struct EXCH_CONNECT_STATUS *)ERROR)
		{
			perror("ConnStatusShm:Open error");
			exit(1);
		}
		memset( ConnStatusShm_mem ,'0', ConnStatusShm_SIZE);
		if ( CloseSharedMemory( (void * ) ConnStatusShm_mem ) == ERROR )
		{
			perror("Error in Closing ConnStatusShm_mem");
			exit(1);
		}
	}

	printf("This is log Debug10\n ");	

	if (CreateSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE)==ERROR)
	{
		perror("Failed To Create Shared Memory For STWRelay :DWSAdapterUserShm");
		printf("\nError Id = [%d]",errno);
		exit(1);
	}
	else
	{
		if((DWSRelayUserShm_mem= (struct DWS_ADAPTER_USER_ARRAY *)OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE)) == ( struct DWS_ADAPTER_USER_ARRAY *)ERROR)
		{
			perror("DWSAdapterUserShm Error");
			exit(1);
		}
		for ( i=0; i<MAX_DWS_USERS ; i++ )
		{
			DWSRelayUserShm_mem->dws_adapter_user[i].iRelayId		=	UNUSED	;
			DWSRelayUserShm_mem->dws_adapter_user[i].ProcessId	=	UNUSED	;
			//	DWSRelayUserShm_mem->dws_adapter_user[i].iUser	=	UNUSED	;
			memset(&(DWSRelayUserShm_mem->dws_adapter_user[i].sUser),'\0',USER_ID_LEN);//changed data type of user from int to char @Suraj

		}	
		if ((CloseSharedMemory(DWSRelayUserShm_mem)) == ERROR )
		{
			perror("Error In Closing DWSRelayUserShm_mem");
			exit(1);
		}
	}
	printf("This is log Debug11\n ");	

	if (CreateSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE)==ERROR)
	{
		perror("Failed To Create Shared Memory For AdminRelay :AdminAdapterUserShm");
		printf("\nError Id = [%d]",errno);
		exit(1);
	}
	else
	{
		if((AdminRelayUserShm_mem= (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE)) == ( struct ADMIN_ADAPTER_USER_ARRAY *)ERROR)
		{
			perror("AdminAdapterUserShm Error");
			exit(1);
		}
		for ( i=0; i<MAX_DWS_USERS ; i++ )
		{
			AdminRelayUserShm_mem->admin_adap_user[i].iRelayId               =       UNUSED  ;
			AdminRelayUserShm_mem->admin_adap_user[i].ProcessId      =       UNUSED  ;
			memset(&(AdminRelayUserShm_mem->admin_adap_user[i].sUser),' ',USER_ID_LEN);

                }
                if ((CloseSharedMemory(AdminRelayUserShm_mem)) == ERROR )
                {
                        perror("Error In Closing AdminRelayUserShm_mem");
                        exit(1);
                }
        }




	printf("This is log Debug12\n ");


	
	if (CreateSharedMemory1(ProcessMonitorShm,ProcessMonitor_SIZE) == ERROR)
	{
		perror("ProcessMonitorShm Failed");
		exit(1);
	}
	else
	{
		if((ProcessMonitor_mem = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE)) == (struct ProcessMonitorArray *)ERROR)
		{
			perror("ProcessMonitorArray:Open error");
			exit(1);
		}
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			memset(ProcessMonitor_mem->ProcessMonitor[i].sProcessName,' ',50);
			memset(ProcessMonitor_mem->ProcessMonitor[i].sMainProcessName,' ',50);
			ProcessMonitor_mem->ProcessMonitor[i].iProcessId = UNUSED;
		}
		if ( CloseSharedMemory( (void * ) ProcessMonitor_mem ) == ERROR )
		{
			perror("Error in Closing ProcessMonitor_mem");
			exit(1);
		}
	}

	printf("This is log Debug13\n ");
	

        if((CreateSharedMemory(NCMInvitatnCntShm,NCMInvitatnCntShm_SIZE))==ERROR)
        {
                printf("Shared Memory Creation for status of NCMInvitatnCntShm Failed\n");
                exit(1);
        }
        else
        {


                if((NCMInvMem = (struct InvitationCount *)OpenSharedMemory(NCMInvitatnCntShm ,NCMInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
                {
                        printf("Error in Opening Shared Memory Created for DrvInvitatnCntShm Status\n");
                        exit(1);
                }

                NCMInvMem->InvCount_group[0].iInvPacketCount = 0;
                NCMInvMem->InvCount_group[1].iInvPacketCount = 0;
                NCMInvMem->InvCount_group[2].iInvPacketCount = 0;
                NCMInvMem->InvCount_group[3].iInvPacketCount = 0;

                if ((CloseSharedMemory((void *)NCMInvMem)) == ERROR )
                {
                        printf("\n Error In Closing NCMInvMem");
                        exit(1);
                }
        }

	if (CreateSharedMemory(AdminQueriesAdapterUserShm,AdminQueriesAdapterUserShm_SIZE)==ERROR)
        {
                perror("Failed To Create Shared Memory For AdminRelay :AdminQueriesAdapterUserShm");
                printf("\nError Id = [%d]",errno);
                exit(1);
        }
        else
        {
                if((AdminQueryUserShm_mem = (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminQueriesAdapterUserShm,AdminQueriesAdapterUserShm_SIZE)) == ( struct ADMIN_ADAPTER_USER_ARRAY *)ERROR)
                {
                        perror("AdminAdapterUserShm Error");
                        exit(1);
                }
                for ( i=0; i<MAX_DWS_USERS ; i++ )
                {
                        AdminQueryUserShm_mem->admin_adap_user[i].iRelayId               =       UNUSED  ;
                        AdminQueryUserShm_mem->admin_adap_user[i].ProcessId      =       UNUSED  ;
                        memset(&(AdminQueryUserShm_mem->admin_adap_user[i].sUser),' ',USER_ID_LEN);

                }
                if ((CloseSharedMemory(AdminQueryUserShm_mem)) == ERROR )
                {
                        perror("Error In Closing AdminQueryUserShm_mem");
                        exit(1);
                }
        }

	
	if (CreateSharedMemory(AdminD2C1AdapterUserShm,AdminD2C1AdapterUserShm_SIZE)==ERROR)
        {
                perror("Failed To Create Shared Memory For AdminRelay :AdminD2C1AdapterUserShm");
                printf("\nError Id = [%d]",errno);
                exit(1);
        }
        else
        {
                if((AdminD2C1UserShm_mem = (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminD2C1AdapterUserShm,AdminD2C1AdapterUserShm_SIZE)) == ( struct ADMIN_ADAPTER_USER_ARRAY *)ERROR)
                {
                        perror("AdminAdapterUserShm Error");
                        exit(1);
                }
                for ( i=0; i<MAX_DWS_USERS ; i++ )
                {
                        AdminD2C1UserShm_mem->admin_adap_user[i].iRelayId               =       UNUSED  ;
                        AdminD2C1UserShm_mem->admin_adap_user[i].ProcessId      =       UNUSED  ;
                        memset(&(AdminD2C1UserShm_mem->admin_adap_user[i].sUser),' ',USER_ID_LEN);

                }
                if ((CloseSharedMemory(AdminD2C1UserShm_mem)) == ERROR )
                {
                        perror("Error In Closing AdminD2C1UserShm_mem");
                        exit(1);
                }
        }
	if (CreateSharedMemory(DWSD2C1UserShm,DWSD2C1UserShm_SIZE)==ERROR)
        {
                perror("Failed To Create Shared Memory For STWRelay :DWSD2C1UserShm");
                printf("\nError Id = [%d]",errno);
                exit(1);
        }
        else
        {
                if((DWSD2C1UserShm_mem= (struct DWS_ADAPTER_USER_ARRAY *)OpenSharedMemory(DWSD2C1UserShm,DWSD2C1UserShm_SIZE)) == ( struct DWS_ADAPTER_USER_ARRAY *)ERROR)
                {
                        perror("DWSD2C1UserShm Error");
                        exit(1);
                }
                for ( i=0; i<MAX_DWS_USERS ; i++ )
                {
                        DWSD2C1UserShm_mem->dws_adapter_user[i].iRelayId               =       UNUSED  ;
                        DWSD2C1UserShm_mem->dws_adapter_user[i].ProcessId      =       UNUSED  ;
                        memset(&(DWSD2C1UserShm_mem->dws_adapter_user[i].sUser),'\0',USER_ID_LEN);

                }
                if ((CloseSharedMemory(DWSD2C1UserShm_mem)) == ERROR )
                {
                        perror("Error In Closing DWSD2C1UserShm_mem");
                        exit(1);
                }
        }
        printf("This is log Debug31\n ");
	
	/*****/	
	/**	if (CreateSharedMemory(EQ_SEC_MASTER_Shm,EQ_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  perror("Failed To Create Shared Memory For EQ_SEC_MASTER_Shm");
	  logFatal("Error Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {
	 ****
	 if((Hash_ByID = (struct SEC_MASTER_ARRAY *)OpenSharedMemory(EQ_SEC_MASTER_Shm,EQ_SEC_MASTER_Shm_SIZE)) == (struct SEC_MASTER_ARRAY *)ERROR)
	 {
	 logFatal("EQ_SEC_MASTER_Shm:Open error");
	 exit(1);
	 }

	//Hash_ByID = NULL;	

	if ( CloseSharedMemory( (void * ) Hash_ByID) == ERROR )
	{
	logFatal("Error in Closing Hash_ByID");
	exit(1);
	}	

	printf("\n Shared Memory For EQ_SEC_MASTER_Shm Created.");
	}
	 *******/

	/**	
	  if (CreateSharedMemory(DR_SEC_MASTER_Shm,DR_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  perror("Failed To Create Shared Memory For DR_SEC_MASTER_Shm");
	  printf("\nError Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\n Shared Memory For DR_SEC_MASTER_Shm Created.");
	  }

	  if (CreateSharedMemory(Temp_Shm,Temp_Shm_SIZE)==ERROR)
	  {
	  perror("Failed To Create Shared Memory For DR_SEC_MASTER_Shm");
	  printf("\nError Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\n Shared Memory For DR_SEC_MASTER_Shm Created.");
	  }

	  if (CreateSharedMemory(CR_SEC_MASTER_Shm,CR_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  logFatal("Failed To Create Shared Memory For CR_SEC_MASTER_Shm");
	  logFatal("Error Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\nShared Memory For CR_SEC_MASTER_Shm Created.");
	  }

	  if (CreateSharedMemory(CM_SEC_MASTER_Shm,CM_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  logFatal("Failed To Create Shared Memory For CM_SEC_MASTER_Shm");
	  logFatal("Error Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\nShared Memory For CM_SEC_MASTER_Shm Created.");
	  }
	 **/
	/*********/
	printf("\n-------------------------- Start Creating Queues ------------------------------");

	printf("\n1. RelToOrdRtr : ");
	if (CreateMsgQueue( RelToOrdRtr , RelToOrdRtr_SIZE ) == ERROR )
	{
		logFatal("RelToOrdRtr failed......");
		exit(1);
	} 

	printf("\n2. DWSRelayToDWSQueries :");
	if (CreateMsgQueue(RelToQuery , RelToQuery_SIZE) == ERROR )
	{
		logFatal("DWSRelayToDWSQueries failed : ");
		exit(1);
	}

	printf("\n3. DWSQueriesToDWSRelay : ");
	if (CreateMsgQueue(QueryToRel , QueryToRel_SIZE) == ERROR )
	{
		logFatal("DWSQueriesToDWSRelay failed : ");
		exit(1);
	}
	printf("\n4. OrderRouterToOrderServerBSEEQ Is Removed Due Merging of NSE AND BSE EQ OrderSever : ");
	/****/        
	printf("4. OrderRouterToOrderServerBSEEQ : ");
	if (CreateMsgQueue(OrdRtrToOrdSrvBSEEQ , OrdRtrToOrdSrvBSEEQ_SIZE) == ERROR )
	{
		logFatal("OrderRouterToOrderServerBSEEQ failed : ");
		exit(1);
	}
	/*****/        
	printf("\n5. OrderRouterToCatalystNSEEQ : ");
	if (CreateMsgQueue(OrdRtrToCatalystNSEEQ , OrdRtrToCatalystNSEEQ_SIZE) == ERROR )
	{
		logFatal("OrderRouterToCatalystNSEEQ failed : ");
		exit(1);
	}

	printf("\n6. CatalystToOrderServerNSEEQ : ");
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ , CatalystToOrdSrvNSEEQ_SIZE) == ERROR )
	{
		logFatal("CatalystToOrderServerNSEEQ failed : ");
		exit(1);
	}

	printf("\n7. OrderRouterToCatalystDR : ");
	if (CreateMsgQueue(OrdRtrToCatalystDR, OrdRtrToCatalystDR_SIZE) == ERROR )
	{
		logFatal("OrderRouterToCatalystDR failed : ");
		exit(1);
	}

	printf("\n8. OrderRouterToOrderServerNSECR : ");
	if (CreateMsgQueue(OrdRtrToOrdSrvNSECR , OrdRtrToOrdSrvNSECR_SIZE) == ERROR )
	{
		logFatal("OrderRouterToOrderServerNSECR failed : ");
		exit(1);
	}       
	printf("\n9. OrderRouterToOrderServerMCX : ");
	if (CreateMsgQueue(OrdRtrToOrdSrvMCX , OrdRtrToOrdSrvMCX_SIZE) == ERROR )
	{
		logFatal("OrderRouterToOrderServerMCX failed : ");
		exit(1);
	}

	printf("\n10. OrderServerToTradeRouter : ");
	if (CreateMsgQueue(OrdSrvToTrdRtr , OrdSrvToTrdRtr_SIZE) == ERROR )
	{
		logFatal("OrderServerToTradeRouter failed : ");
		exit(1);
	}

	printf("\n11. OrderServerToFwdMapBSEEQ Is Removed Due Merging of NSE AND BSE EQ OrderSever : ");
	/******
	  printf("11. OrderServerToFwdMapBSEEQ : ");
	  if (CreateMsgQueue(OrdSrvToFwdMapBSEEQ , OrdSrvToFwdMapBSEEQ_SIZE) == ERROR )
	  {
	  logFatal("OrderServerToFwdMapBSEEQ failed : ");
	  exit(1);
	  }
	 *******/      
	printf("\n12. OrdSrvToMapperNSEEQ: ");
	if (CreateMsgQueue(OrdSrvToMapperNSEEQ, OrdSrvToMapperNSEEQ_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperNSEEQ failed : ");
		exit(1);
	}

	printf("\n13. OrdSrvToMapperNSEDR: ");
	if (CreateMsgQueue(OrdSrvToMapperNSEDR, OrdSrvToMapperNSEDR_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperNSEDR failed : ");
		exit(1);
	}

	//        printf("\n14. OrderServerToFwdMapNSECR Is Removed Due Merging of NSE AND BSE EQ OrderSever : ");
	printf("14. OrdSrvToMapperNSECR : ");
	if (CreateMsgQueue(OrdSrvToMapperNSECR  , OrdSrvToMapperNSECR_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperNSECR failed : ");
		exit(1);
	}
	printf("\n15. OrderServerToFwdMapMCX : ");
	if (CreateMsgQueue(OrdSrvToFwdMapMCX , OrdSrvToFwdMapMCX_SIZE) == ERROR )
	{
		logFatal("OrderServerToFwdMapMCX failed : ");
		exit(1);
	}

	printf("\n16. OrdSrvToMapperBSEEQ: ");
	if (CreateMsgQueue(OrdSrvToMapperBSEEQ, OrdSrvToMapperBSEEQ_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperBSEEQ failed : ");
		exit(1);
	}


	printf("\n17. FwdMapToInterfaceNSEEQ : ");
	if (CreateMsgQueue(ConnToInterfaceNSEEQ, ConnToInterfaceNSEEQ_SIZE) == ERROR )
	{
		logFatal("FwdMapToInterfaceNSEEQ failed : ");
		exit(1);
	}
	/**

	  printf("\n18. ConnToInterfaceNSEDR: ");
	  if (CreateMsgQueue(ConnToInterfaceNSEDR, ConnToInterfaceNSEDR_SIZE) == ERROR )
	  {
	  logFatal("ConnToInterfaceNSEDR failed : ");
	  exit(1);
	  }

	  printf("\n19. ConnToInterfaceNSECR : ");
	  if (CreateMsgQueue(ConnToInterfaceNSECR, ConnToInterfaceNSECR_SIZE) == ERROR )
	  {
	  logFatal("failed : ");
	  exit(1);
	  }
	 ***/

	printf("\n20. FwdMapToInterfaceMCX : ");
	if (CreateMsgQueue(FwdMapToInterfaceMCX , FwdMapToInterfaceMCX_SIZE) == ERROR )
	{
		logFatal("FwdMapToInterfaceMCX failed : ");
		exit(1);
	}

	printf("\n21. ConnToTrdMapBSEEQ: ");
	if (CreateMsgQueue(ConnToTrdMapBSEEQ, ConnToTrdMapBSEEQ_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapBSEEQ failed : ");
		exit(1);
	}

	printf("\n22. ConnToTrdMapNSEEQ : ");
	if (CreateMsgQueue(ConnToTrdMapNSEEQ , ConnToTrdMapNSEEQ_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapNSEEQ failed : ");
		exit(1);
	}

	printf("\n23. ConnToTrdMapNSEDR : ");
	if (CreateMsgQueue(ConnToTrdMapNSEDR , ConnToTrdMapNSEDR_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapNSEDR failed : ");
		exit(1);
	}

	printf("\n24. ConnToTrdMapNSECR : ");
	if (CreateMsgQueue(ConnToTrdMapNSECR , ConnToTrdMapNSECR_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapNSECR failed : ");
		exit(1);
	}

	printf("\n25. InterfaceToRevMapMCX : ");
	if (CreateMsgQueue(InterfaceToRevMapMCX , InterfaceToRevMapMCX_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapMCX failed : ");
		exit(1);
	}

	printf("\n26. RevMapToTradeServerBSEEQ Is Removed due to Merging of NSE AND BSE TradeServer : ");
	/*********/
	printf("26. RevMapToTradeServerBSEEQ : ");
	if (CreateMsgQueue(RevMapToTrdSrvBSEEQ , RevMapToTrdSrvBSEEQ_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerBSEEQ failed : ");
		exit(1);
	}
	/********/
	printf("\n27. RevMapToTradeServerNSEEQ : ");
	if (CreateMsgQueue(RevMapToTrdSrvNSEEQ , RevMapToTrdSrvNSEEQ_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerNSEEQ failed : ");
		exit(1);
	}

	printf("\n28. RevMapToTradeServerNSEDR : ");
	if (CreateMsgQueue(RevMapToTrdSrvNSEDR , RevMapToTrdSrvNSEDR_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerNSEDR failed : ");
		exit(1);
	}


	printf("\n29. RevMapToTradeServerNSECR : ");
	if (CreateMsgQueue(RevMapToTrdSrvNSECR , RevMapToTrdSrvNSECR_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerNSECR failed : ");
		exit(1);
	}      
	printf("\n30. RevMapToTradeServerMCX : ");
	if (CreateMsgQueue(RevMapToTrdSrvMCX , RevMapToTrdSrvMCX_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerMCX failed : ");
		exit(1);
	}

	printf("\n31. TradeServerToRMS : ");
	if (CreateMsgQueue(TrdSrvToRMS , TrdSrvToRMS_SIZE) == ERROR )
	{
		logFatal("TradeServerToRMS failed : ");
		exit(1);
	}

	printf("\n32. TradeServerToTradeRouter : ");
	if (CreateMsgQueue(TrdSrvToTrdRtr , TrdSrvToTrdRtr_SIZE) == ERROR )
	{
		logFatal("TradeServerToTradeRouter failed : ");
		exit(1);
	}

	printf("\n33. TrdRtrToDWSMMap: ");
	if (CreateMsgQueue(TrdRtrToDWSMMap, TrdRtrToDWSMMap_SIZE) == ERROR )
	{
		logFatal("TrdRtrToRel failed : ");
		exit(1);
	}

	printf("\n34. TradeRouterToWebAdapter : ");
	if (CreateMsgQueue(TrdRtrToWebAdap , TrdRtrToWebAdap_SIZE) == ERROR )
	{
		logFatal("TradeRouterToWebAdapter failed : ");
		exit(1);
	}

	printf("\n35. ENBAdapToSpltr: ");
	if (CreateMsgQueue(ENBAdapToSpltr, ENBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("ENBAdapToSpltr failed: ");
		exit(1);
	}

	printf("\n39. TrdRtrToRevRmsVal: ");
	if (CreateMsgQueue(TrdRtrToRevRmsVal, TrdRtrToRevRmsVal_SIZE) == ERROR )
	{
		logFatal("TrdRtrToRevRmsVal failed : ");
		exit(1);
	}


	printf("\n40. RDaemonToSqoff: ");
	if (CreateMsgQueue(RDaemonToSqoff, RDaemonToSqoff_SIZE) == ERROR )
	{
		logFatal("RDaemonToSqoff failed : ");
		exit(1);
	}


	printf("\n41.RDaemonToOffPump is removed due to Merging of SqrOff & OffPump: ");
	/********
	  printf("41.RDaemonToOffPump: ");
	  if (CreateMsgQueue(RDaemonToOffPump, RDaemonToOffPump_SIZE) == ERROR)
	  {
	  logFatal("RDaemonToOffPump failed : ");
	  exit(1);
	  }
	 ********/
	
	  printf("42.D2C1ToAdminAdap: ");
	  if (CreateMsgQueue(D2C1ToAdminAdap, D2C1ToAdminAdap_SIZE) == ERROR )
	  {
	  	logFatal("D2C1ToAdminAdap failed : ");
	  	exit(1);
	  }
	 
	printf("\n43.TrdRtrToD2C1MMap: ");
	if (CreateMsgQueue(TrdRtrToD2C1MMap, TrdRtrToD2C1MMap_SIZE) == ERROR )
	{
		logFatal("TrdRtrToD2C1MMap failed : ");
		exit(1);
	}

	printf("\n44. OffPumperToOrdRtr: ");
	if (CreateMsgQueue(OffPumperToOrdRtr,OffPumperToOrdRtr_SIZE) == ERROR )
	{
		logFatal("OffPumperToOrdRtr failed : ");
		exit(1);
	}

	printf("\n45.OrdRtrToOffOrd: ");
	if (CreateMsgQueue(OrdRtrToOffOrd, OrdRtrToOffOrd_SIZE) == ERROR )
	{
		logFatal("OrdRtrToOffOrd failed : ");
		exit(1);
	}


	printf("\n46.OffOrdToTrdRtr: ");
	if (CreateMsgQueue(OffOrdToTrdRtr, OffOrdToTrdRtr_SIZE) == ERROR )
	{
		logFatal("OffOrdToTrdRtr failed: ");
		exit(1);
	}

	printf("\n47.DWSQryToAdap: ");
	if (CreateMsgQueue(DWSQryToAdap, DWSQryToAdap_SIZE) == ERROR )
	{
		logFatal("DWSQryToAdap failed: ");
		exit(1);
	}

	printf("\n48. TrdRtrToAdminMMap: ");
	if (CreateMsgQueue(TrdRtrToAdminMMap, TrdRtrToAdminMMap_SIZE) == ERROR )
	{
		logFatal("TrdRtrToAdminMMap failed: ");
		exit(1);
	}

	printf("\n49. D2C1ToDWSAdap: ");
	if (CreateMsgQueue(D2C1ToDWSAdap, D2C1ToDWSAdap_SIZE) == ERROR )
	{
		logFatal("D2C1ToDWSAdap failed: ");
		exit(1);
	}

	printf("\n50. DNBAdapToSpltr: ");
	if (CreateMsgQueue(DNBAdapToSpltr, DNBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("DNBAdapToSpltr failed: ");
		exit(1);
	}

	printf("\n51. CNBAdapToSpltr: ");
	if (CreateMsgQueue(CNBAdapToSpltr, CNBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("CNBAdapToSpltr failed: ");
		exit(1);
	}

	printf("\n52. CNBSpltrToMbpUpld: ");
	if (CreateMsgQueue(CNBSpltrToMbpUpld, CNBSpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("CNBSpltrToMbpUpld failed: ");
		exit(1);
	}


	printf("\n53. DNBSpltrToMbpUpld: ");
	if (CreateMsgQueue(DNBSpltrToMbpUpld, DNBSpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("DNBSpltrToMbpUpld failed: ");
		exit(1);
	}
	printf("\n58. DNBcasttoMktStatus: ");
	if (CreateMsgQueue(DNBcasttoMktStatus, DNBcasttoMktStatus_SIZE) == ERROR )
	{
		logFatal("DNBcasttoMktStatus failed: ");
		exit(1);
	}
	printf("\n59. OrdRtrToCon2Del: ");
	if (CreateMsgQueue(OrdRtrToCon2Del, OrdRtrToCon2Del_SIZE) == ERROR )
	{
		logFatal("OrdRtrToCon2Del failed: ");
		exit(1);
	}
	printf("\n60. CurSpltrToMktStatus: ");
	if (CreateMsgQueue(CurSpltrToMktSts, CurSpltrToMktSts_SIZE) == ERROR )
	{
		logFatal("CurSpltrToMktSts failed: ");
		exit(1);
	}
	printf("\n61. MCXAdapToUpdtr: ");
	if (CreateMsgQueue(MCXAdapToUpdtr, MCXAdapToUpdtr_SIZE) == ERROR )
	{
		logFatal("MCXAdapToUpdtr failed: ");
		exit(1);
	}
	printf("\n62. CatalystToOrdSrvDRV: ");
	if (CreateMsgQueue(CatalystToOrdSrvDRV, CatalystToOrdSrvDRV_SIZE) == ERROR )
	{
		logFatal("CatalystToOrdSrvDRV failed: ");
		exit(1);
	}
	if (CreateMsgQueue(TrdRtrToSysMsg, TrdRtrToSysMsg_SIZE) == ERROR )
	{
		logFatal("TrdRtrToSysMsg failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBAAdapToSpltr, EBAAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("EBAAdapToSpltr failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBASpltrToMbpUpld, EBASpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("EBASpltrToMbpUpld failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBABSpltrToIdxUpld, EBABSpltrToIdxUpld_SIZE) == ERROR )
	{
		logFatal("EBASpltrToMbpUpld failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBABSpltrToMktSts, EBABSpltrToMktSts_SIZE) == ERROR )
	{
		logFatal("EBASpltrToMbpUpld failed: ");
		exit(1);
	}

	printf("\n64. OrdRtrToOrdSrvSIP: ");
	if(CreateMsgQueue(OrdRtrToOrdSrvSIP, OrdRtrToOrdSrvSIP_SIZE) == ERROR )
	{
		logFatal(" OrdRtrToOrdSrvSIP failed : ");
		exit(1);
	}

	printf("\n65. OrdSrvSIPToTrdRtr: ");
	if(CreateMsgQueue(OrdSrvSIPToTrdRtr, OrdSrvSIPToTrdRtr_SIZE) == ERROR )
	{
		logFatal(" OrdSrvSIPToTrdRtr failed : ");
		exit(1);
	}

	printf("\n66. OrdRtrToCatalystSIP_EQ:");
	if(CreateMsgQueue(OrdRtrToCatalystSIP_EQ, OrdRtrToCatalystSIP_EQ_SIZE) == ERROR )
	{
		logFatal(" OrdRtrToCatalystSIP_EQ failed : ");
		exit(1);
	}

	printf("\n67. EquNSEToRmsNse:");
	if(CreateMsgQueue(EquNSEToRmsNse, EquNSEToRmsNse_SIZE) == ERROR )
	{
		logFatal(" EquNSEToRmsNse : ");
		exit(1);
	}

	printf("\n68. DrvNseToRmsnse:");
	if (CreateMsgQueue (DrvNseToRmsnse, DrvNseToRmsnse_SIZE) == ERROR )
	{
		logFatal(" DrvNseToRmsnse : ");
		exit(1);
	}

	printf("\n69. CurrNseToRmsnse :");
	if (CreateMsgQueue (CurrNseToRmsnse , CurrNseToRmsnse_SIZE) == ERROR )
	{
		logFatal ("CurrNseToRmsnse :");
		exit(1);
	}

	printf("\n72. MapperToConnBSEEQ:");
	if (CreateMsgQueue (MapperToConnBSEEQ, MapperToConnBSEEQ_SIZE) == ERROR )
	{
		logFatal ("MapperToConnBSEEQ:");
		exit(1);
	}

	printf("\n77. MapperToConnNSEEQ : ");
	if (CreateMsgQueue(MapperToConnNSEEQ , MapperToConnNSEEQ_SIZE) == ERROR )
	{
		logFatal("MapperToConnNSEEQ failed : ");
		exit(1);
	}

	printf("\n78. MapperToConnNSEFO: ");
	if (CreateMsgQueue(MapperToConnNSEFO, MapperToConnNSEFO_SIZE) == ERROR )
	{
		logFatal("MapperToConnNSEFO failed : ");
		exit(1);
	}

	printf("\n79. MapperToConnNSECD: ");
	if (CreateMsgQueue(MapperToConnNSECD, MapperToConnNSECD_SIZE) == ERROR )
	{
		logFatal("MapperToConnNSECD failed : ");
		exit(1);
	}

	printf("\n80. OrdRtrToDeaNotify: ");
	if (CreateMsgQueue(OrdRtrToDeaNotify, OrdRtrToDeaNotify_SIZE) == ERROR )
	{
		logFatal("OrdRtrToDeaNotify failed : ");
		exit(1);
	}
	printf("\n81. MmapToENMapTrd: ");
	if (CreateMsgQueue(MmapToENMapTrd, MmapToENMapTrd_SIZE) == ERROR )
	{
		logFatal("MmapToENMapTrd failed : ");
		exit(1);
	}
	printf("\n82. MmapToRevRmsVal: ");
	if (CreateMsgQueue(MmapToRevRmsVal , MmapToRevRmsVal_SIZE) == ERROR )
	{
		logFatal("MmapToRevRmsVal failed : ");
		exit(1);
	}
	printf("\n83. BOTradeSvrToPumper : ");
	if (CreateMsgQueue(BOTradeSvrToPumper , BOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("BOTradeSvrToPumper failed : ");
		exit(1);
	}
	printf("\n84. DrBOTradeSvrToPumper : ");
	if (CreateMsgQueue(DrBOTradeSvrToPumper , DrBOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("DrBOTradeSvrToPumper failed : ");
		exit(1);
	}

	printf("\n85. ENMbpToLTPUpd: ");
	if (CreateMsgQueue(ENMbpToLTPUpd, ENMbpToLTPUpd_SIZE) == ERROR )
	{
		logFatal("ENMbpToLTPUpd failed : ");
		exit(1);
	}
	printf("\n86. CurBOTradeSvrToPumper: ");
	if (CreateMsgQueue(CurBOTradeSvrToPumper, CurBOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("CurBOTradeSvrToPumper failed : ");
		exit(1);
	}
	printf("\n87. CatalystToRmsVal: ");
	if (CreateMsgQueue(CatalystToRmsVal, CatalystToRmsVal_SIZE) == ERROR)
	{
		logFatal("CatalystToRmsVal failed:");
		exit(1);
	}

	printf("\n88. RDaemonToMtmSqoff : ");
	if (CreateMsgQueue(RDaemonToMtmSqoff , RDaemonToMtmSqoff_SIZE) == ERROR)
	{
		logFatal("RDaemonToMtmSqoff failed:");
		exit(1);
	}

	printf("\n89. AdaptorToQuery : ");
	if(CreateMsgQueue(AdaptorToQuery ,AdaptorToQuery_SIZE) == ERROR)
	{
		logFatal("AdaptorToQuery failed:");
		exit(1);
	}

	printf("\n90. AdminQueriesToAdaptor :");
	if(CreateMsgQueue(AdminQueriesToAdaptor , AdminQueriesToAdaptor_SIZE) == ERROR)
	{
		logFatal("AdminQueriesToAdaptor failed");
		exit(1);
	}
	printf("\n93 . OrdRtrToAdminMsg :");
	if(CreateMsgQueue(OrdRtrToAdminMsg , OrdRtrToAdminMsg_SIZE) == ERROR)
	{
		logFatal("OrdRtrToAdminMsg failed");
		exit(1);
	}

	printf("\n90. AdaptorToAdminQry : ");
	if(CreateMsgQueue(AdaptorToAdminQry,AdaptorToAdminQry_SIZE) == ERROR)
	{
		logFatal("AdaptorToAdminQry failed:");
		exit(1);
	}

	printf("\n91. BEBOTradeSvrToPumper : ");
	if (CreateMsgQueue(BEBOTradeSvrToPumper ,BEBOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("BEBOTradeSvrToPumper failed : ");
		exit(1);
	}

	printf("\n94.  AdapToRangeQry :");
	if (CreateMsgQueue(AdapToRangeQry,AdapToRangeQry) == ERROR )
	{
		logFatal("AdapToRangeQry failed : ");
		exit(1);
	}

	printf("\n95.  RangeQryToAdap  :");
	if (CreateMsgQueue(RangeQryToAdap,RangeQryToAdap) == ERROR )
	{
		logFatal("RangeQryToAdap failed : ");
		exit(1);
	}

	printf("\n96.  InterfaceToRevMapNSEEQ  :");
	if (CreateMsgQueue(InterfaceToRevMapNSEEQ,InterfaceToRevMapNSEEQ_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEEQ failed : ");
		exit(1);
	}

	printf("\n97.  InterfaceToRevMapNSEDR  :");
	if (CreateMsgQueue(InterfaceToRevMapNSEDR,InterfaceToRevMapNSEDR_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}

	printf("\n98.  OrdSrvToFwdMapNSEEQ  :");
	if (CreateMsgQueue(OrdSrvToFwdMapNSEEQ,OrdSrvToFwdMapNSEEQ_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}

	printf("\n99.  FwdMapToInterfaceNSEEQ  :");
	if (CreateMsgQueue(FwdMapToInterfaceNSEEQ,FwdMapToInterfaceNSEEQ_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}

	printf("\n99.  TrdSvrEQToBoTrailer:");
	if (CreateMsgQueue(TrdSvrEQToBoTrailer,TrdSvrEQToBoTrailer_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}
	printf("\n100.  EQCOTradeSvrToPumper:");
	if (CreateMsgQueue(EQCOTradeSvrToPumper,EQCOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("EQCOTradeSvrToPumper_SIZE failed : ");
		exit(1);
	}
	printf("\n101.  FoCrCOTradeSvrToPumper:");
	if (CreateMsgQueue(FoCrCOTradeSvrToPumper,FoCrCOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("FoCrCOTradeSvrToPumper failed : ");
		exit(1);
	}

	printf("\n105.  OrderRtrToCalMrg:");
	if (CreateMsgQueue(OrderRtrToCalMrg,OrderRtrToCalMrg_SIZE) == ERROR )
	{
		logFatal("OrderRtrToCalMrg failed : ");
		exit(1);
	}
	printf("\n106.  OrderRtrToCalMrgCat:");
        if (CreateMsgQueue(OrderRtrToCalMrgCat,OrderRtrToCalMrgCat_SIZE) == ERROR )
        {
                logFatal("OrderRtrToCalMrgCat failed : ");
                exit(1);
        }

	printf("\n108.  MCXCOTradeSvrToPumper:");
        if (CreateMsgQueue(MCXCOTradeSvrToPumper,MCXCOTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("MCXCOTradeSvrToPumper failed : ");
                exit(1);
        }

	printf("\n107.  BEqBoTradeSvrToPumper:");
        if (CreateMsgQueue(BEqBoTradeSvrToPumper,BEqBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BEqBoTradeSvrToPumper failed : ");
                exit(1);
        }

	printf("\n109.  CatalystToOrdSrvCOMM:");
        if (CreateMsgQueue(CatalystToOrdSrvCOMM,CatalystToOrdSrvCOMM_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvCOMM failed : ");
                exit(1);
        }

	printf("\n110.  DWSQryToAdap:");
        if (CreateMsgQueue(DWSQryToAdap,DWSQryToAdap_SIZE) == ERROR )
        {
                logFatal("DWSQryToAdapfailed : ");
                exit(1);
        }
	
	printf("\n111.  MmapToAdmnTrdRtr:");
        if (CreateMsgQueue(MmapToAdmnTrdRtr,MmapToAdmnTrdRtr_SIZE) == ERROR )
        {
                logFatal("MmapToTrdRtrAdmn failed : ");
                exit(1);
        }
        printf("\n112.  MmapToD2C1:");
        if (CreateMsgQueue(MmapToD2C1,MmapToD2C1_SIZE) == ERROR )
        {
                logFatal("MmapToD2C1 failed : ");
                exit(1);
        }
        printf("\n113.  AdmTrdRtrToAdmAdap:");
        if (CreateMsgQueue(AdmTrdRtrToAdmAdap,AdmTrdRtrToAdmAdap_SIZE) == ERROR )
        {
                logFatal("AdmTrdRtrToAdmAdap failed : ");
                exit(1);
        }

	printf("\n114.  MmapToDWSTrdRtr:");
        if (CreateMsgQueue(MmapToDWSTrdRtr,MmapToDWSTrdRtr_SIZE) == ERROR )
        {
                logFatal("MmapToDWSTrdRtr failed : ");
                exit(1);
        }

        printf("\n115.  DWSTrdRtrToDWSAdp:");
        if (CreateMsgQueue(DWSTrdRtrToDWSAdp,DWSTrdRtrToDWSAdp_SIZE) == ERROR )
        {
                logFatal("DWSTrdRtrToDWSAdp failed : ");
                exit(1);
        }
	
	if (CreateMsgQueue(OrdRtrToOrdSrvBSECD , OrdRtrToOrdSrvBSECD_SIZE) == ERROR )
        {
                logFatal("OrderRouterToOrderServerBSECD failed : ");
                exit(1);
        }
        /*****/
        printf("\n116. OrderRouterToOrderServerBSECD : ");

        if (CreateMsgQueue(OrdSrvToMapperBSECD , OrdSrvToMapperBSECD_SIZE) == ERROR )
        {
                logFatal("OrdSrvToMapperBSECD failed : ");
                exit(1);
        }
        /*****/
        printf("\n117. OrdSrvToMapperBSECD : ");

        if (CreateMsgQueue(MapperToConnBSECD , MapperToConnBSECD_SIZE) == ERROR )
        {
                logFatal("MapperToConnBSECD failed : ");
                exit(1);
        }
        /*****/
        printf("\n118. ConnToTrdMapBSECD : ");

        if (CreateMsgQueue(ConnToTrdMapBSECD , ConnToTrdMapBSECD_SIZE) == ERROR )
        {
                logFatal("ConnToTrdMapBSECD failed : ");
                exit(1);
        }
        /*****/
        printf("\n119. ConnToTrdMapBSECD : ");

        if (CreateMsgQueue(RevMapToTrdSrvBSECD , RevMapToTrdSrvBSECD_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSECD failed : ");
                exit(1);
        }
        /*****/
        printf("\n120. RevMapToTrdSrvBSECD : ");

        if (CreateMsgQueue(BCdBoTradeSvrToPumper , BCdBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BCdBoTradeSvrToPumper failed : ");
                exit(1);
        }
        /*****/
        printf("\n121. BCdBoTradeSvrToPumper : ");



        if (CreateMsgQueue(TrdSvrCDToBoTrailer , TrdSvrCDToBoTrailer_SIZE) == ERROR )
        {
                logFatal("TrdSvrCDToBoTrailer failed : ");
                exit(1);
        }
        /*****/
        printf("\n122. TrdSvrCDToBoTrailer : ");

        if (CreateMsgQueue(DNMbpToLtpUdr, DNMbpToLtpUdr_SIZE) == ERROR )
        {
                logFatal("DNMbpToLtpUdr failed : ");
                exit(1);
        }
        /*****/
        printf("\n128. DNMbpToLtpUdr: ");

        if (CreateMsgQueue(CNMbpToLtpUdr, CNMbpToLtpUdr_SIZE) == ERROR )
        {
                logFatal("CNMbpToLtpUdr failed : ");
                exit(1);
        }
        /*****/
        printf("\n129. CNMbpToLtpUdr : ");

        if (CreateMsgQueue(ComMbpToLtpUdr, ComMbpToLtpUdr_SIZE) == ERROR )
        {
                logFatal("ComMbpToLtpUdr failed : ");
                exit(1);
        }
        /*****/
        printf("\n130. ComMbpToLtpUdr : ");

//======================================================================================//
        if (CreateMsgQueue(OrdRtrToBComOrderSvr, OrdRtrToBComOrderSvr_SIZE) == ERROR )
        {
                logFatal("OrdRtrToBComOrderSvr failed : ");
                exit(1);
        }
        /*****/
        printf("\n131. OrdRtrToBComOrderSvr : ");


        if (CreateMsgQueue(BComOrdSrvToMapper, BComOrdSrvToMapper_SIZE) == ERROR )
        {
                logFatal("BComOrdSrvToMapper failed : ");
                exit(1);
        }
        /*****/
        printf("\n132. BComOrdSrvToMapper : ");


        if (CreateMsgQueue(BComMapToConn, BComMapToConn_SIZE) == ERROR )
        {
                logFatal("BComMapToConn failed : ");
                exit(1);
        }
        /*****/
        printf("\n133. BComMapToConn : ");


        if (CreateMsgQueue(BComConToRevMap, BComConToRevMap_SIZE) == ERROR )
        {
                logFatal("BComConToRevMap failed : ");
                exit(1);
        }
        /*****/
        printf("\n134. BComConToRevMap : ");

	
        if (CreateMsgQueue(BComRevMapToTrdSvr, BComRevMapToTrdSvr_SIZE) == ERROR )
        {
                logFatal("BComRevMapToTrdSvr failed : ");
                exit(1);
        }
        /*****/
        printf("\n135. BComRevMapToTrdSvr : ");


        if (CreateMsgQueue(BComTrdSvrToTrdRtr, BComTrdSvrToTrdRtr_SIZE) == ERROR )
        {
                logFatal("BComTrdSvrToTrdRtr failed : ");
                exit(1);
        }
        /*****/
        printf("\n136. BComTrdSvrToTrdRtr : ");


        if (CreateMsgQueue(BComOrdSvrToTrdRtr, BComOrdSvrToTrdRtr_SIZE) == ERROR )
        {
                logFatal("BComOrdSvrToTrdRtr failed : ");
                exit(1);
        }
        /*****/
        printf("\n137. BComOrdSvrToTrdRtr : ");

//=================================================================================

	if (CreateMsgQueue(OrdRtrToCatalystNseCM, OrdRtrToCatalystNseCM_SIZE) == ERROR )
	{
		logFatal("OrdRtrToCatalystNseCM Failed : ");
		exit(1);
	}
	printf("\n138. OrdRtrToCatalystNseCM : ");

	if (CreateMsgQueue(CatalystToOrdSvrNseCM, CatalystToOrdSvrNseCM_SIZE) == ERROR)
	{
		logFatal("CatalystToOrdSvrNseCM Failed : ");
		exit(1);
	}
	printf("\n139. CatalystToOrdSvrNseCM : ");

	if (CreateMsgQueue(OrdSvrCMToTrdRtrCM, OrdSvrCMToTrdRtrCM_SIZE) == ERROR)
	{
		logFatal("OrdSvrCMToTrdRtrCM Failed : ");
		exit(1);
	}
	printf("\n140. OrdSvrCMToTrdRtrCM : ");

	if (CreateMsgQueue(OrdSvrCMToMapperNseCM, OrdSvrCMToMapperNseCM_SIZE) == ERROR)
	{
		logFatal("OrdSvrCMToMapperNseCM Failed : ");
		exit(1);
	}
	printf("\n141. OrdSvrCMToMapperNseCM : ");

	if (CreateMsgQueue(MapperNseCMToConNseCM, MapperNseCMToConNseCM_SIZE) == ERROR)
	{
		logFatal("MapperNseCMToConNseCM Failed : ");
		exit(1);
	}
	printf("\n142. MapperNseCMToConNseCM : ");

	if (CreateMsgQueue(ConNseCMToTrdMapNseCM, ConNseCMToTrdMapNseCM_SIZE) == ERROR)
	{
		logFatal("ConNseCMToTrdMapNseCM Failed : ");
		exit(1);
	}
	printf("\n143. ConNseCMToTrdMapNseCM : ");

	if (CreateMsgQueue(RevMapNseCMToTrdSvrCM, RevMapNseCMToTrdSvrCM_SIZE) == ERROR)
	{
		logFatal("RevMapNseCMToTrdSvrCM Failed : ");
		exit(1);
	}
	printf("\n144. RevMapNseCMToTrdSvrCM : ");

	if (CreateMsgQueue(TrdSvrCMToTrdRtrCM, TrdSvrCMToTrdRtrCM_SIZE ) == ERROR)
	{
		logFatal("TrdSvrCMToTrdRtrCM Failed : ");
		exit(1);
	}
	printf("\n145. TrdSvrCMToTrdRtrCM : ");


	if (CreateMsgQueue(TrdRtrToTradeMobMMap, TrdRtrToTradeMobMMap_SIZE ) == ERROR)
	{
		logFatal("TrdRtrToTradeMobMMap Failed : ");
		exit(1);
	}
	printf("\n146. TrdRtrToTradeMobMMap : ");


	if (CreateMsgQueue(MmapToNotifyFE, MmapToNotifyFE_SIZE ) == ERROR)
	{
		logFatal("MmapToNotifyFE Failed : ");
		exit(1);
	}
	printf("\n146. MmapToNotifyFE : ");

        printf("\n147. CMCOBOTradeSvrToPumper : ");
        if (CreateMsgQueue(ComCOBOTradeSvrToPumper , ComCOBOTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("ComCOBOTradeSvrToPumper failed : ");
                exit(1);
        }

	if (CreateMsgQueue(OrdSrvToMapperBSEDR, OrdSrvToMapperBSEDR_SIZE ) == ERROR)
        {
                logFatal("OrdSrvToMapperBSEDR Failed : ");
                exit(1);
        }
        printf("\n150. OrdSrvToMapperBSEDR : ");


 	if (CreateMsgQueue(OrdRtrToOrdSrvBSEDR, OrdRtrToOrdSrvBSEDR_SIZE ) == ERROR)
        {
                logFatal("OrdRtrToOrdSrvBSEDR Failed : ");
                exit(1);
        }
        printf("\n151. OrdRtrToOrdSrvBSEDR : ");

	if (CreateMsgQueue(MapperToConnBSEDR, MapperToConnBSEDR_SIZE) == ERROR )
        {
                logFatal("MapperToConnBSEDR failed : ");
                exit(1);
        }

	printf("\n152. MapperToConnBSEDR : ");

	if (CreateMsgQueue(ConnToTrdMapBSEDR , ConnToTrdMapBSEDR_SIZE) == ERROR )
        {
                logFatal("ConnToTrdMapBSEDR failed : ");
                exit(1);
        }
        /*****/
        printf("\n153. ConnToTrdMapBSEDR : ");





	if (CreateMsgQueue(RevMapToTrdSrvBSEDR , RevMapToTrdSrvBSEDR_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSEDR failed : ");
                exit(1);
        }
        /*****/
        printf("\n154. RevMapToTrdSrvBSEDR : ");

	if (CreateMsgQueue(RevMapToTrdSrvBSEDR , RevMapToTrdSrvBSEDR_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSEDR failed : ");
                exit(1);
        }
        /*****/
        printf("\n155. RevMapToTrdSrvBSEDR : ");


	if (CreateMsgQueue(BDrBoTradeSvrToPumper , BDrBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BDrBoTradeSvrToPumper failed : ");
                exit(1);
        }
        /*****/
        printf("\n156. BDrBoTradeSvrToPumper : ");


	if (CreateMsgQueue(TrdSvrDRToBoTrailer , TrdSvrDRToBoTrailer_SIZE) == ERROR )
        {
                logFatal("TrdSvrDRToBoTrailer failed : ");
                exit(1);
        }
        /*****/
        printf("\n157. TrdSvrDRToBoTrailer : ");


	if (CreateMsgQueue(CBAAdapToSpltr, CBAAdapToSpltr_SIZE) == ERROR)
        {
                logFatal("CBAAdapToSpltr Failed : ");
                exit(1);
        }
        printf("\n158. CBAAdapToSpltr: ");

        if (CreateMsgQueue(CBASpltrToMbpUpld, CBASpltrToMbpUpld_SIZE) == ERROR)
        {
                logFatal("CBASpltrToMbpUpld Failed : ");
                exit(1);
        }
        printf("\n159. CBASpltrToMbpUpld : ");

        if (CreateMsgQueue(CBABSpltrToMktSts, CBABSpltrToMktSts_SIZE) == ERROR)
        {
                logFatal("CBABSpltrToMktSts Failed : ");
                exit(1);
        }
        printf("\n160. CBABSpltrToMktSts : ");

        if (CreateMsgQueue(CBABSpltrToIdxUpld, CBABSpltrToIdxUpld_SIZE) == ERROR)
        {
                logFatal("CBABSpltrToIdxUpld Failed : ");
                exit(1);
        }
        printf("\n161. CBABSpltrToIdxUpld: ");

	if (CreateMsgQueue(DBAAdapToSpltr, DBAAdapToSpltr_SIZE) == ERROR)
        {
                logFatal("DBAAdapToSpltr Failed : ");
                exit(1);
        }
        printf("\n162. DBAAdapToSpltr: ");

        if (CreateMsgQueue(DBASpltrToMbpUpld, DBASpltrToMbpUpld_SIZE) == ERROR)
        {
                logFatal("DBASpltrToMbpUpld Failed : ");
                exit(1);
        }
        printf("\n163. DBASpltrToMbpUpld : ");

        if (CreateMsgQueue(DBABSpltrToMktSts, DBABSpltrToMktSts_SIZE) == ERROR)
        {
                logFatal("DBABSpltrToMktSts Failed : ");
                exit(1);
        }
        printf("\n164. DBABSpltrToMktSts : ");

        if (CreateMsgQueue(DBABSpltrToIdxUpld, DBABSpltrToIdxUpld_SIZE) == ERROR)
        {
                logFatal("DBABSpltrToIdxUpld Failed : ");
                exit(1);
        }
        printf("\n165. DBABSpltrToIdxUpld: ");

	if (CreateMsgQueue(BComBoTradeSvrToPumper , BComBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BComBoTradeSvrToPumper failed : ");
                exit(1);
        }
        printf("\n166. BComBoTradeSvrToPumper : ");

	if (CreateMsgQueue(COMBAdapToSpltr, COMBAdapToSpltr_SIZE) == ERROR )
        {
                logFatal("COMBAdapToSpltr failed : ");
                exit(1);
        }
        printf("\n167. COMBAdapToSpltr: ");

	if (CreateMsgQueue(COMBSpltrToMbpUpld, COMBSpltrToMbpUpld_SIZE) == ERROR )
        {
                logFatal("COMBSpltrToMbpUpld failed : ");
                exit(1);
        }
        printf("\n168. COMBSpltrToMbpUpld: ");

	if (CreateMsgQueue(COMBcasttoMktStatus, COMBcasttoMktStatus_SIZE) == ERROR )
        {
                logFatal("COMBcasttoMktStatus failed : ");
                exit(1);
        }
        printf("\n169. COMBcasttoMktStatus: ");

        if (CreateMsgQueue(TrdSvrNEQToTrdMMap, TrdSvrNEQToTrdMMap_SIZE) == ERROR)
        {
                logFatal("TrdSvrNEQToTrdMMap Failed : ");
                exit(1);
        }
        printf("\n170. TrdSvrNEQToTrdMMap: ");

        if (CreateMsgQueue(TrdSvrNEQToTrdMMap, TrdSvrNEQToTrdMMap_SIZE) == ERROR)
        {
                logFatal("TrdSvrNEQToTrdMMap Failed : ");
                exit(1);
        }
        printf("\n167. TrdSvrNEQToTrdMMap: ");

        if (CreateMsgQueue(TrdSvrNFOToTrdMMap, TrdSvrNFOToTrdMMap_SIZE) == ERROR)
        {
                logFatal("TrdSvrNFOToTrdMMap Failed : ");
                exit(1);
        }
        printf("\n168. TrdSvrNFOToTrdMMap : ");

        if (CreateMsgQueue(TrdSvrNCDToTrdMMap, TrdSvrNCDToTrdMMap_SIZE) == ERROR)
        {
                logFatal("TrdSvrNCDToTrdMMap Failed : ");
                exit(1);
        }
        printf("\n169. TrdSvrNCDToTrdMMap : ");

        if (CreateMsgQueue(TrdSvrBEQToTrdMMap, TrdSvrBEQToTrdMMap_SIZE) == ERROR)
        {
                logFatal("TrdSvrBEQToTrdMMap Failed : ");
                exit(1);
        }
        printf("\n172. TrdSvrEQToTrdMMap : ");

        if (CreateMsgQueue(TrdSvrMCXToTrdMMap, TrdSvrMCXToTrdMMap_SIZE) == ERROR)
        {
                logFatal("TrdSvrMCXToTrdMMap Failed : ");
                exit(1);
        }

        printf("\n171. TrdSvrMCXToTrdMMap : ");

	if (CreateMsgQueue(COMBAAdapToSpltr, COMBAAdapToSpltr_SIZE) == ERROR)
        {
                logFatal("COMBAAdapToSpltr Failed : ");
                exit(1);
        }
        printf("\n175. COMBAAdapToSpltr: ");

        if (CreateMsgQueue(COMBASpltrToMbpUpld, COMBASpltrToMbpUpld_SIZE) == ERROR)
        {
                logFatal("COMBASpltrToMbpUpld Failed : ");
                exit(1);
        }
        printf("\n176. COMBASpltrToMbpUpld : ");

        if (CreateMsgQueue(COMBABSpltrToMktSts, COMBABSpltrToMktSts_SIZE) == ERROR)
        {
                logFatal("COMBABSpltrToMktSts Failed : ");
                exit(1);
        }
        printf("\n177. COMBABSpltrToMktSts : ");

        if (CreateMsgQueue(COMBABSpltrToIdxUpld, COMBABSpltrToIdxUpld_SIZE) == ERROR)
        {
                logFatal("COMBABSpltrToIdxUpld Failed : ");
                exit(1);
        }
        printf("\n178. COMBABSpltrToIdxUpld: ");


	printf("4. OrderRouterToOrderServerBSECOM : ");
        if (CreateMsgQueue(OrdRtrToOrdSrvBSECOM ,OrdRtrToOrdSrvBSECOM_SIZE) == ERROR )
        {
                logFatal("OrderRouterToOrderServerBSECOM failed : ");
                exit(1);
        }
        printf("\n179. COMBABSpltrToIdxUpld: ");

	if (CreateMsgQueue(CatalystToOrdSrvBSEEQ,CatalystToOrdSrvBSEEQ_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ failed : ");
                exit(1);
        }
        printf("\n180. CatalystToOrdSrvBSEEQ: ");
	
	if (CreateMsgQueue(MMAPToConnBSEEQ,MMAPToConnBSEEQ_SIZE) == ERROR )
        {
                logFatal("MMAPToConnBSEEQ failed: ");
                exit(1);
        }
        printf("\n181.MMAPToConnBSEEQ : ");
	
	if (CreateMsgQueue(ConnBSEEQToRevMMap,ConnBSEEQToRevMMap_SIZE) == ERROR )
        {
                logFatal("ConnBSEEQToRevMMap failed : ");
                exit(1);
        }
        printf("\n182. ConnBSEEQToRevMMap: ");
	
	if (CreateMsgQueue(OrdRtrToCatalystBSEEQ,OrdRtrToCatalystBSEEQ_SIZE) == ERROR )
        {
                logFatal("OrdRtrToCatalystBSEEQ failed : ");
                exit(1);
        }
        printf("\n183. OrdRtrToCatalystBSEEQ: ");


        /*------------------START New Queue created for Nse Bcast MMap @nitish----------------*/
	printf("\n183. ENBcastMemToSpltr: ");
	if (CreateMsgQueue(ENBcastMemToSpltr, ENBcastMemToSpltr_SIZE) == ERROR )
	{
		logFatal("ENBcastMemToSpltr failed: ");
		exit(1);
	}
	
	printf("\n184. ENSptrMemToMbpUpdt: ");
        if (CreateMsgQueue(ENSptrMemToMbpUpdt , ENSptrMemToMbpUpdt_SIZE) == ERROR )
        {
                logFatal("ENSptrMemToMbpUpdt failed: ");
                exit(1);
        }

	printf("\n185. DNBcastMemToSpltr: ");
        if (CreateMsgQueue(DNBcastMemToSpltr, DNBcastMemToSpltr_SIZE) == ERROR )
        {
                logFatal("DNBcastMemToSpltr failed: ");
                exit(1);
        }

	printf("\n186. DNSptrMemToMbpUpdt: ");
        if (CreateMsgQueue(DNSptrMemToMbpUpdt, DNSptrMemToMbpUpdt_SIZE) == ERROR )
        {
                logFatal("DNSptrMemToMbpUpdt failed: ");
                exit(1);
        }

	printf("\n187. CNBcastMemToSpltr: ");
        if (CreateMsgQueue(CNBcastMemToSpltr, CNBcastMemToSpltr_SIZE) == ERROR )
        {
                logFatal("CNBcastMemToSpltr failed: ");
                exit(1);
        }
	printf("\n188. CNSptrMemToMbpUpdt: ");
	if (CreateMsgQueue(CNSptrMemToMbpUpdt,CNSptrMemToMbpUpdt_SIZE) == ERROR)
        {
                logFatal("CNSptrMemToMbpUpdt failed: ");
                exit(1);
        }
/*------------------END New Queue created for Nse Bcast MMap @nitish----------------*/
	printf("189. FwdMMapToConAdapNSECM: ");
	if (CreateMsgQueue(FwdMMapToConAdapNSECM ,FwdMMapToConAdapNSECM_SIZE) == ERROR )
	{
		logFatal("FwdMMapToConAdapNSECM failed : ");
		exit(1);
	}

	printf("190. FwdMMapToConAdapNSEFO : ");
	if (CreateMsgQueue(FwdMMapToConAdapNSEFO,FwdMMapToConAdapNSEFO_SIZE) == ERROR )
	{
		logFatal("FwdMMapToConAdapNSEFO failed : ");
		exit(1);
	}
	
	printf("191. FwdMMapToConAdapNSECD : ");
	if (CreateMsgQueue(FwdMMapToConAdapNSECD,FwdMMapToConAdapNSECD_SIZE) == ERROR )
	{
		logFatal("FwdMMapToConAdapNSECD failed : ");
		exit(1);
	}

	printf("\n192. OrdRtrToOrdSrvICEX : ");
        if(CreateMsgQueue(OrdRtrToOrdSrvICEX , OrdRtrToOrdSrvICEX_SIZE) == ERROR )
        {
                logFatal("OrdRtrToOrdSrvICEX Failed :");
                exit(1);
        }
        printf("\n193. OrdRtrToOrdSrvICEX : ");

        if (CreateMsgQueue(OrdSrvToFwdMapICEX , OrdSrvToFwdMapICEX_SIZE) == ERROR )
        {
                logFatal("OrdSrvToFwdMapICEX Failed :");
                exit(1);
        }
        printf("\n194. OrdSrvToFwdMapICEX : ");

        if (CreateMsgQueue(FwdMapToInterfaceICEX , FwdMapToInterfaceICEX_SIZE) == ERROR )
        {
                logFatal("FwdMapToInterfaceICEX Failed :");
                exit(1);
        }
        printf("\n195. FwdMapToInterfaceICEX : ");

        if (CreateMsgQueue(InterfaceToRevMapICEX , InterfaceToRevMapICEX_SIZE) == ERROR )
        {
                logFatal("InterfaceToRevMapICEX Failed :");
                exit(1);
        }
        printf("\n196. InterfaceToRevMapICEX : ");

        if (CreateMsgQueue(RevMapToTrdSrvICEX , RevMapToTrdSrvICEX_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvICEX Failed :");
                exit(1);
        }
        printf("\n197. RevMapToTrdSrvICEX : ");

        if (CreateMsgQueue(ICEXAdapToUpdtr , ICEXAdapToUpdtr_SIZE) == ERROR )
        {
                logFatal("ICEXAdapToUpdtr Failed :");
                exit(1);
        }
        printf("\n198. ICEXAdapToUpdtr : ");

        if (CreateMsgQueue(ICEXCOTradeSvrToPumper , ICEXCOTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("ICEXCOTradeSvrToPumper Failed :");
                exit(1);
        }
        printf("\n199. ICEXCOTradeSvrToPumper : ");

        if (CreateMsgQueue(TrdSvrICEXToTrdMMap , TrdSvrICEXToTrdMMap_SIZE) == ERROR )
        {
                logFatal("TrdSvrICEXToTrdMMap Failed :");
                exit(1);
        }
        printf("\n200. TrdSvrICEXToTrdMMap : ");

	if (CreateMsgQueue(MemMaptoNotifyCatalyst, MemMaptoNotifyCatalyst_SIZE) == ERROR )
        {
                logFatal("MemMaptoNotifyCatalyst Failed :");
                exit(1);
        }
        printf("\n200. MemMaptoNotifyCatalyst : ");

	if (CreateMsgQueue(MemMaptoServerDaemon, MemMaptoServerDaemon_SIZE) == ERROR )
        {
                logFatal("MemMaptoServerDaemon Failed :");
                exit(1);
        }
        printf("\n209. MemMaptoServerDaemon: ");

	if (CreateMsgQueue(ClientDaemonToMemMap, ClientDaemonToMemMap_SIZE) == ERROR )
        {
                logFatal("ClientDaemonToMemMap Failed :");
                exit(1);
        }
        printf("\n210. ClientDaemonToMemMap: ");

	if (CreateMsgQueue(IntSqrOffToMemMap, IntSqrOffToMemMap_SIZE) == ERROR )
        {
                logFatal("IntSqrOffToMemMap Failed :");
                exit(1);
        }
        printf("\n211. IntSqrOffToMemMap: ");
	
	if (CreateMsgQueue(OrdRtrToGTTOrd, OrdRtrToGTTOrd_SIZE) == ERROR )
        {
                logFatal("OrdRtrToGTTOrd failed : ");
                exit(1);
        }
        printf("\n212.OrdRtrToGTTOrd: ");

	  if (CreateMsgQueue(TrdCatalystToRevMMap_1, TrdCatalystToRevMMap_1_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_1 Failed :");
                exit(1);
        }
        printf("\n197. TrdCatalystToRevMMap_1: ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_2, TrdCatalystToRevMMap_2_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_2 Failed :");
                exit(1);
        }
        printf("\n198. TrdCatalystToRevMMap_2 : ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_3 , TrdCatalystToRevMMap_3_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_3 Failed :");
                exit(1);
        }
        printf("\n199. TrdCatalystToRevMMap_3 : ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_4, TrdCatalystToRevMMap_4_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_4 Failed :");
                exit(1);
        }
        printf("\n200. TrdCatalystToRevMMap_4 : ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_5, TrdCatalystToRevMMap_5_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_5 Failed :");
                exit(1);
        }
        printf("\n201. TrdCatalystToRevMMap_5 : ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_6 , TrdCatalystToRevMMap_6_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_6 Failed :");
                exit(1);
        }
        printf("\n202. TrdCatalystToRevMMap_6 : ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_7 , TrdCatalystToRevMMap_7_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_7 Failed :");
                exit(1);
        }
        printf("\n203. TrdCatalystToRevMMap_7 : ");

	  if (CreateMsgQueue(TrdCatalystToRevMMap_8 , TrdCatalystToRevMMap_8_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_8 Failed :");
                exit(1);
        }
        printf("\n204. TrdCatalystToRevMMap_8 : ");

        if (CreateMsgQueue(TrdCatalystToRevMMap_9 , TrdCatalystToRevMMap_9_SIZE) == ERROR )
        {
                logFatal("TrdCatalystToRevMMap_9 Failed :");
                exit(1);
        }
        printf("\n205. TrdCatalystToRevMMap_9 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_1, RevMapToTrdSrvNSEEQ_1_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_1 Failed :");
                exit(1);
        }
        printf("\n206. RevMapToTrdSrvNSEEQ_1: ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_2, RevMapToTrdSrvNSEEQ_2_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_2 Failed :");
                exit(1);
        }
        printf("\n207. RevMapToTrdSrvNSEEQ_2 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_3 , RevMapToTrdSrvNSEEQ_3_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_3 Failed :");
                exit(1);
        }
        printf("\n208. RevMapToTrdSrvNSEEQ_3 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_4, RevMapToTrdSrvNSEEQ_4_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_4 Failed :");
                exit(1);
        }
        printf("\n209. RevMapToTrdSrvNSEEQ_4 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_5, RevMapToTrdSrvNSEEQ_5_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_5 Failed :");
                exit(1);
        }
        printf("\n210. RevMapToTrdSrvNSEEQ_5 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_6 , RevMapToTrdSrvNSEEQ_6_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_6 Failed :");
                exit(1);
        }
	
	 printf("\n211. RevMapToTrdSrvNSEEQ_6 : ");

                if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_7 , RevMapToTrdSrvNSEEQ_7_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_7 Failed :");
                exit(1);
        }
        printf("\n212. RevMapToTrdSrvNSEEQ_7 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_8 , RevMapToTrdSrvNSEEQ_8_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_8 Failed :");
                exit(1);
        }
        printf("\n213. RevMapToTrdSrvNSEEQ_8 : ");

        if (CreateMsgQueue(RevMapToTrdSrvNSEEQ_9 , RevMapToTrdSrvNSEEQ_9_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvNSEEQ_9 Failed :");
                exit(1);
        }
        printf("\n214. RevMapToTrdSrvNSEEQ_9 : ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_1, RevMMapToRevMapNSEEQ_1_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_1 Failed :");
                exit(1);
        }
        printf("\n215. RevMMapToRevMapNSEEQ_1: ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_2, RevMMapToRevMapNSEEQ_2_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_2 Failed :");
                exit(1);
        }
        printf("\n216. RevMMapToRevMapNSEEQ_2 : ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_3 , RevMMapToRevMapNSEEQ_3_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_3 Failed :");
                exit(1);
        }
        printf("\n217. RevMMapToRevMapNSEEQ_3 : ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_4, RevMMapToRevMapNSEEQ_4_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_4 Failed :");
                exit(1);
        }
        printf("\n218. RevMMapToRevMapNSEEQ_4 : ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_5, RevMMapToRevMapNSEEQ_5_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_5 Failed :");
                exit(1);
        }
        printf("\n219. RevMMapToRevMapNSEEQ_5 : ");
		
	 if (CreateMsgQueue(RevMMapToRevMapNSEEQ_6 , RevMMapToRevMapNSEEQ_6_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_6 Failed :");
                exit(1);
        }
        printf("\n220. RevMMapToRevMapNSEEQ_6 : ");

                if (CreateMsgQueue(RevMMapToRevMapNSEEQ_7 , RevMMapToRevMapNSEEQ_7_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_7 Failed :");
                exit(1);
        }
        printf("\n221. RevMMapToRevMapNSEEQ_7 : ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_8 , RevMMapToRevMapNSEEQ_8_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_8 Failed :");
                exit(1);
        }
        printf("\n222. RevMMapToRevMapNSEEQ_8 : ");

        if (CreateMsgQueue(RevMMapToRevMapNSEEQ_9 , RevMMapToRevMapNSEEQ_9_SIZE) == ERROR )
        {
                logFatal("RevMMapToRevMapNSEEQ_9 Failed :");
                exit(1);
        }
        printf("\n223. RevMMapToRevMapNSEEQ_9 : ");

        if (CreateMsgQueue(ENBSpltrToSAddMStatUpld, ENBSpltrToSAddMStatUpld_SIZE) == ERROR )
        {
                logFatal("ENBSpltrToSAddMStatUpld failed : ");
                exit(1);
        }
        printf("\n224.ENBSpltrToSAddMStatUpld : ");

	if (CreateMsgQueue(DNBcasttoSAddMktStatus, DNBcasttoSAddMktStatus_SIZE) == ERROR )
        {
                logFatal("DNBcasttoSAddMktStatus failed : ");
                exit(1);
        }
        printf("\n225.DNBcasttoSAddMktStatus : ");

	
	if (CreateMsgQueue(RevMapToMemMapBSEEQ_1, RevMapToMemMapBSEEQ_1_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_1 failed : ");
                exit(1);
        }
        printf("\n226.RevMapToMemMapBSEEQ_1 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_2, RevMapToMemMapBSEEQ_2_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_2 failed : ");
                exit(1);
        }
        printf("\n227.RevMapToMemMapBSEEQ_2 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_3, RevMapToMemMapBSEEQ_3_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_3 failed : ");
                exit(1);
        }
        printf("\n228.RevMapToMemMapBSEEQ_3 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_4, RevMapToMemMapBSEEQ_4_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_4 failed : ");
                exit(1);
        }
        printf("\n229.RevMapToMemMapBSEEQ_4 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_5, RevMapToMemMapBSEEQ_5_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_5 failed : ");
                exit(1);
        }
        printf("\n230.RevMapToMemMapBSEEQ_5 : ");
	
	 if (CreateMsgQueue(RevMapToMemMapBSEEQ_6, RevMapToMemMapBSEEQ_6_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_6 failed : ");
                exit(1);
        }
        printf("\n231.RevMapToMemMapBSEEQ_6 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_7, RevMapToMemMapBSEEQ_7_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_7 failed : ");
                exit(1);
        }
        printf("\n232.RevMapToMemMapBSEEQ_7 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_8, RevMapToMemMapBSEEQ_8_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_8 failed : ");
                exit(1);
        }
        printf("\n233.RevMapToMemMapBSEEQ_8 : ");

        if (CreateMsgQueue(RevMapToMemMapBSEEQ_9, RevMapToMemMapBSEEQ_9_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSEEQ_9 failed : ");
                exit(1);
        }
        printf("\n234.RevMapToMemMapBSEEQ_9 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_1, MemMapToTrdSvrBSEEQ_1_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_1 failed : ");
                exit(1);
        }
        printf("\n235.MemMapToTrdSvrBSEEQ_1 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_2, MemMapToTrdSvrBSEEQ_2_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_2 failed : ");
                exit(1);
        }
        printf("\n236.MemMapToTrdSvrBSEEQ_2 : ");
	
	 if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_3, MemMapToTrdSvrBSEEQ_3_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_3 failed : ");
                exit(1);
        }
        printf("\n237.MemMapToTrdSvrBSEEQ_3 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_4, MemMapToTrdSvrBSEEQ_4_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_4 failed : ");
                exit(1);
        }
        printf("\n238.MemMapToTrdSvrBSEEQ_4 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_5, MemMapToTrdSvrBSEEQ_5_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_5 failed : ");
                exit(1);
        }
        printf("\n239.MemMapToTrdSvrBSEEQ_5 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_6, MemMapToTrdSvrBSEEQ_6_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_6 failed : ");
                exit(1);
        }
        printf("\n240.MemMapToTrdSvrBSEEQ_6 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_7, MemMapToTrdSvrBSEEQ_7_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_7 failed : ");
                exit(1);
        }
        printf("\n241.MemMapToTrdSvrBSEEQ_7 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_8, MemMapToTrdSvrBSEEQ_8_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_8 failed : ");
                exit(1);
        }
        printf("\n242.MemMapToTrdSvrBSEEQ_8 : ");
	
	if (CreateMsgQueue(MemMapToTrdSvrBSEEQ_9, MemMapToTrdSvrBSEEQ_9_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSEEQ_9 failed : ");
                exit(1);
        }
        printf("\n243.MemMapToTrdSvrBSEEQ_9 : ");

        if (CreateMsgQueue(CurSpltrToSAddMktSts, CurSpltrToSAddMktSts_SIZE) == ERROR )
        {
                logFatal("CurSpltrToSAddMktSts failed : ");
                exit(1);
        }
        printf("\n244.CurSpltrToSAddMktSts : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX, CatalystToOrdSrvMCX_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX failed : ");
                exit(1);
        }
        printf("\n245.CatalystToOrdSrvMCX : ");
        
        if (CreateMsgQueue(CatalystToOrdSrvNCr, CatalystToOrdSrvNCr_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr failed : ");
                exit(1);
        }
        printf("\n246.CatalystToOrdSrvNCr : ");

	if (CreateMsgQueue(CatalystToOrdSrvBSECD_1, CatalystToOrdSrvBSECD_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_1 failed : ");
                exit(1);
        }
        printf("\n247.CatalystToOrdSrvBSECD_1 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvBSECD_2, CatalystToOrdSrvBSECD_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_2 failed : ");
                exit(1);
        }
        printf("\n248.CatalystToOrdSrvBSECD_2 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_3, CatalystToOrdSrvBSECD_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_3 failed : ");
                exit(1);
        }
        printf("\n249.CatalystToOrdSrvBSECD_3 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_4, CatalystToOrdSrvBSECD_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_4 failed : ");
                exit(1);
        }
        printf("\n250.CatalystToOrdSrvBSECD_4 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_5, CatalystToOrdSrvBSECD_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_5 failed : ");
                exit(1);
        }
        printf("\n251.CatalystToOrdSrvBSECD_5 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_6, CatalystToOrdSrvBSECD_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_6 failed : ");
                exit(1);
        }
        printf("\n252.CatalystToOrdSrvBSECD_6 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_7, CatalystToOrdSrvBSECD_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_7 failed : ");
                exit(1);
        }
        printf("\n253.CatalystToOrdSrvBSECD_7 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_8, CatalystToOrdSrvBSECD_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_8 failed : ");
                exit(1);
        }
        printf("\n254.CatalystToOrdSrvBSECD_8 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSECD_9, CatalystToOrdSrvBSECD_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSECD_9 failed : ");
                exit(1);
        }
        printf("\n255.CatalystToOrdSrvBSECD_9 : ");
	
	if (CreateMsgQueue(RevMapToMemMapBSECD_1, RevMapToMemMapBSECD_1_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_1 failed : ");
                exit(1);
        }
        printf("\n256.RevMapToMemMapBSECD_1 : ");

        if (CreateMsgQueue(RevMapToMemMapBSECD_2, RevMapToMemMapBSECD_2_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_2 failed : ");
                exit(1);
        }
        printf("\n257.RevMapToMemMapBSECD_2 : ");

        if (CreateMsgQueue(RevMapToMemMapBSECD_3, RevMapToMemMapBSECD_3_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_3 failed : ");
                exit(1);
        }
        printf("\n258.RevMapToMemMapBSECD_3 : ");

        if (CreateMsgQueue(RevMapToMemMapBSECD_4, RevMapToMemMapBSECD_4_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_4 failed : ");
                exit(1);
        }
        printf("\n259.RevMapToMemMapBSECD_4 : ");
		
        if (CreateMsgQueue(RevMapToMemMapBSECD_5, RevMapToMemMapBSECD_5_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_5 failed : ");
                exit(1);
        }
        printf("\n260.RevMapToMemMapBSECD_5 : ");

        if (CreateMsgQueue(RevMapToMemMapBSECD_6, RevMapToMemMapBSECD_6_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_6 failed : ");
                exit(1);
        }
        printf("\n261.RevMapToMemMapBSECD_6 : ");
		
        if (CreateMsgQueue(RevMapToMemMapBSECD_7, RevMapToMemMapBSECD_7_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_7 failed : ");
                exit(1);
        }
        printf("\n262.RevMapToMemMapBSECD_7 : ");

        if (CreateMsgQueue(RevMapToMemMapBSECD_8, RevMapToMemMapBSECD_8_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_8 failed : ");
                exit(1);
        }
        printf("\n263.RevMapToMemMapBSECD_8 : ");

        if (CreateMsgQueue(RevMapToMemMapBSECD_9, RevMapToMemMapBSECD_9_SIZE) == ERROR )
        {
                logFatal("RevMapToMemMapBSECD_9 failed : ");
                exit(1);
        }
        printf("\n264.RevMapToMemMapBSECD_9 : ");

	if (CreateMsgQueue(MemMapToTrdSvrBSECD_1, MemMapToTrdSvrBSECD_1_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_1 failed : ");
                exit(1);
        }
        printf("\n265.MemMapToTrdSvrBSECD_1 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSECD_2, MemMapToTrdSvrBSECD_2_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_2 failed : ");
                exit(1);
        }
        printf("\n266.MemMapToTrdSvrBSECD_2 : ");

         if (CreateMsgQueue(MemMapToTrdSvrBSECD_3, MemMapToTrdSvrBSECD_3_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_3 failed : ");
                exit(1);
        }
        printf("\n267.MemMapToTrdSvrBSECD_3 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSECD_4, MemMapToTrdSvrBSECD_4_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_4 failed : ");
                exit(1);
        }
        printf("\n268.MemMapToTrdSvrBSECD_4 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSECD_5, MemMapToTrdSvrBSECD_5_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_5 failed : ");
                exit(1);
        }
        printf("\n269.MemMapToTrdSvrBSECD_5 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSECD_6, MemMapToTrdSvrBSECD_6_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_6 failed : ");
                exit(1);
        }
        printf("\n270.MemMapToTrdSvrBSECD_6 : ");
	if (CreateMsgQueue(MemMapToTrdSvrBSECD_7, MemMapToTrdSvrBSECD_7_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_7 failed : ");
                exit(1);
        }
        printf("\n271.MemMapToTrdSvrBSECD_7 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSECD_8, MemMapToTrdSvrBSECD_8_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_8 failed : ");
                exit(1);
        }
        printf("\n272.MemMapToTrdSvrBSECD_8 : ");

        if (CreateMsgQueue(MemMapToTrdSvrBSECD_9, MemMapToTrdSvrBSECD_9_SIZE) == ERROR )
        {
                logFatal("MemMapToTrdSvrBSECD_9 failed : ");
                exit(1);
        }
        printf("\n273.MemMapToTrdSvrBSECD_9 : ");

	if (CreateMsgQueue(D2C1ToDWSD2C1Adap, D2C1ToDWSD2C1Adap_SIZE) == ERROR )
        {
                logFatal("D2C1ToDWSD2C1Adap failed : ");
                exit(1);
        }
	printf("\n274.D2C1ToDWSD2C1Adap : ");

	if (CreateMsgQueue(D2C1ToAdminD2C1Adap, D2C1ToAdminD2C1Adap_SIZE) == ERROR )
        {
                logFatal("D2C1ToAdminD2C1Adap failed : ");
                exit(1);
        }
        printf("\n275 D2C1ToAdminD2C1Adap : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_1, CatalystToOrdSrvNSEEQ_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_1 failed : ");
                exit(1);
        }
        printf("\n276.CatalystToOrdSrvNSEEQ_1 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_2, CatalystToOrdSrvNSEEQ_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_2 failed : ");
                exit(1);
        }
        printf("\n277.CatalystToOrdSrvNSEEQ_2 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_3, CatalystToOrdSrvNSEEQ_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_3 failed : ");
                exit(1);
        }
        printf("\n278.CatalystToOrdSrvNSEEQ_3 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_4, CatalystToOrdSrvNSEEQ_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_4 failed : ");
                exit(1);
        }
        printf("\n279.CatalystToOrdSrvNSEEQ_4 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_5, CatalystToOrdSrvNSEEQ_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_5 failed : ");
                exit(1);
        }
        printf("\n280.CatalystToOrdSrvNSEEQ_5 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_6, CatalystToOrdSrvNSEEQ_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_6 failed : ");
                exit(1);
        }
        printf("\n281.CatalystToOrdSrvNSEEQ_6 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_7, CatalystToOrdSrvNSEEQ_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_7 failed : ");
                exit(1);
        }
        printf("\n282.CatalystToOrdSrvNSEEQ_7 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_8, CatalystToOrdSrvNSEEQ_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_8 failed : ");
                exit(1);
        }
        printf("\n283.CatalystToOrdSrvNSEEQ_8 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_9, CatalystToOrdSrvNSEEQ_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_9 failed : ");
                exit(1);
        }
        printf("\n284.CatalystToOrdSrvNSEEQ_9 : ");
		
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_10, CatalystToOrdSrvNSEEQ_10_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_10 failed : ");
                exit(1);
        }
        printf("\n285.CatalystToOrdSrvNSEEQ_10 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_11, CatalystToOrdSrvNSEEQ_11_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_11 failed : ");
                exit(1);
        }
        printf("\n286.CatalystToOrdSrvNSEEQ_11 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_12, CatalystToOrdSrvNSEEQ_12_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_12 failed : ");
                exit(1);
        }
        printf("\n287.CatalystToOrdSrvNSEEQ_12 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_13, CatalystToOrdSrvNSEEQ_13_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_13 failed : ");
                exit(1);
        }
        printf("\n288.CatalystToOrdSrvNSEEQ_13 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_14, CatalystToOrdSrvNSEEQ_14_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_14 failed : ");
                exit(1);
        }
        printf("\n289.CatalystToOrdSrvNSEEQ_14 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_15, CatalystToOrdSrvNSEEQ_15_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_15 failed : ");
                exit(1);
        }
        printf("\n290.CatalystToOrdSrvNSEEQ_15 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_16, CatalystToOrdSrvNSEEQ_16_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_16 failed : ");
                exit(1);
        }
        printf("\n291.CatalystToOrdSrvNSEEQ_16 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_17, CatalystToOrdSrvNSEEQ_17_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_17 failed : ");
                exit(1);
        }
        printf("\n292.CatalystToOrdSrvNSEEQ_17 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_18, CatalystToOrdSrvNSEEQ_18_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_18 failed : ");
                exit(1);
        }
        printf("\n293.CatalystToOrdSrvNSEEQ_18 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_19, CatalystToOrdSrvNSEEQ_19_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_19 failed : ");
                exit(1);
        }
        printf("\n294.CatalystToOrdSrvNSEEQ_19 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_20, CatalystToOrdSrvNSEEQ_20_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_20 failed : ");
                exit(1);
        }
        printf("\n295.CatalystToOrdSrvNSEEQ_20 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_21, CatalystToOrdSrvNSEEQ_21_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_21 failed : ");
                exit(1);
        }
        printf("\n296.CatalystToOrdSrvNSEEQ_21 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_22, CatalystToOrdSrvNSEEQ_22_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_22 failed : ");
                exit(1);
        }
        printf("\n297.CatalystToOrdSrvNSEEQ_22 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_23, CatalystToOrdSrvNSEEQ_23_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_23 failed : ");
                exit(1);
        }
        printf("\n298.CatalystToOrdSrvNSEEQ_23 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_24, CatalystToOrdSrvNSEEQ_24_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_24 failed : ");
                exit(1);
        }
        printf("\n299.CatalystToOrdSrvNSEEQ_24 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_25, CatalystToOrdSrvNSEEQ_25_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_25 failed : ");
                exit(1);
        }
        printf("\n300.CatalystToOrdSrvNSEEQ_25 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_26, CatalystToOrdSrvNSEEQ_26_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_26 failed : ");
                exit(1);
        }
        printf("\n301.CatalystToOrdSrvNSEEQ_26 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_27, CatalystToOrdSrvNSEEQ_27_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_27 failed : ");
                exit(1);
        }
        printf("\n302.CatalystToOrdSrvNSEEQ_27 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_28, CatalystToOrdSrvNSEEQ_28_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_28 failed : ");
                exit(1);
        }
        printf("\n303.CatalystToOrdSrvNSEEQ_28 : ");

	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_29, CatalystToOrdSrvNSEEQ_29_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_29 failed : ");
                exit(1);
        }
        printf("\n304.CatalystToOrdSrvNSEEQ_29 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ_30, CatalystToOrdSrvNSEEQ_30_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNSEEQ_30 failed : ");
                exit(1);
        }
        printf("\n305.CatalystToOrdSrvNSEEQ_30 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvDRV_1, CatalystToOrdSrvDRV_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_1 failed : ");
                exit(1);
        }
        printf("\n306.CatalystToOrdSrvDRV_1 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_2, CatalystToOrdSrvDRV_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_2 failed : ");
                exit(1);
        }
        printf("\n307.CatalystToOrdSrvDRV_2 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_3, CatalystToOrdSrvDRV_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_3 failed : ");
                exit(1);
        }
        printf("\n308.CatalystToOrdSrvDRV_3 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_4, CatalystToOrdSrvDRV_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_4 failed : ");
                exit(1);
        }
        printf("\n309.CatalystToOrdSrvDRV_4 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_5, CatalystToOrdSrvDRV_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_5 failed : ");
                exit(1);
        }
        printf("\n310.CatalystToOrdSrvDRV_5 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_6, CatalystToOrdSrvDRV_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_6 failed : ");
                exit(1);
        }
        printf("\n311.CatalystToOrdSrvDRV_6 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_7, CatalystToOrdSrvDRV_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_7 failed : ");
                exit(1);
        }
        printf("\n312.CatalystToOrdSrvDRV_7 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_8, CatalystToOrdSrvDRV_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_8 failed : ");
                exit(1);
        }
        printf("\n313.CatalystToOrdSrvDRV_8 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_9, CatalystToOrdSrvDRV_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_9 failed : ");
                exit(1);
        }
        printf("\n314.CatalystToOrdSrvDRV_9 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_10, CatalystToOrdSrvDRV_10_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_10 failed : ");
                exit(1);
        }
        printf("\n315.CatalystToOrdSrvDRV_10 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_11, CatalystToOrdSrvDRV_11_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_11 failed : ");
                exit(1);
        }
        printf("\n316.CatalystToOrdSrvDRV_11 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_12, CatalystToOrdSrvDRV_12_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_12 failed : ");
                exit(1);
        }
        printf("\n317.CatalystToOrdSrvDRV_12 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_13, CatalystToOrdSrvDRV_13_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_13 failed : ");
                exit(1);
        }
        printf("\n318.CatalystToOrdSrvDRV_13 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_14, CatalystToOrdSrvDRV_14_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_14 failed : ");
                exit(1);
        }
        printf("\n319.CatalystToOrdSrvDRV_14 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_15, CatalystToOrdSrvDRV_15_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_15 failed : ");
                exit(1);
        }
        printf("\n320.CatalystToOrdSrvDRV_15 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_16, CatalystToOrdSrvDRV_16_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_16 failed : ");
                exit(1);
        }
        printf("\n321.CatalystToOrdSrvDRV_16 : ");
		
	if (CreateMsgQueue(CatalystToOrdSrvDRV_17, CatalystToOrdSrvDRV_17_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_17 failed : ");
                exit(1);
        }
        printf("\n322.CatalystToOrdSrvDRV_17 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_18, CatalystToOrdSrvDRV_18_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_18 failed : ");
                exit(1);
        }
        printf("\n323.CatalystToOrdSrvDRV_18 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_19, CatalystToOrdSrvDRV_19_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_19 failed : ");
                exit(1);
        }
        printf("\n324.CatalystToOrdSrvDRV_19 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_20, CatalystToOrdSrvDRV_20_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_20 failed : ");
                exit(1);
        }
        printf("\n325.CatalystToOrdSrvDRV_20 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_21, CatalystToOrdSrvDRV_21_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_21 failed : ");
                exit(1);
        }
        printf("\n326.CatalystToOrdSrvDRV_21 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_22, CatalystToOrdSrvDRV_22_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_22 failed : ");
                exit(1);
        }
        printf("\n327.CatalystToOrdSrvDRV_22 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_23, CatalystToOrdSrvDRV_23_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_23 failed : ");
                exit(1);
        }
        printf("\n328.CatalystToOrdSrvDRV_23 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_24, CatalystToOrdSrvDRV_24_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_24 failed : ");
                exit(1);
        }
        printf("\n329.CatalystToOrdSrvDRV_24 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_25, CatalystToOrdSrvDRV_25_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_25 failed : ");
                exit(1);
        }
        printf("\n330.CatalystToOrdSrvDRV_25 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_26, CatalystToOrdSrvDRV_26_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_26 failed : ");
                exit(1);
        }
        printf("\n331.CatalystToOrdSrvDRV_26 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_27, CatalystToOrdSrvDRV_27_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_27 failed : ");
                exit(1);
        }
        printf("\n332.CatalystToOrdSrvDRV_27 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_28, CatalystToOrdSrvDRV_28_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_28 failed : ");
                exit(1);
        }
        printf("\n333.CatalystToOrdSrvDRV_28 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_29, CatalystToOrdSrvDRV_29_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_29 failed : ");
                exit(1);
        }
        printf("\n334.CatalystToOrdSrvDRV_29 : ");

        if (CreateMsgQueue(CatalystToOrdSrvDRV_30, CatalystToOrdSrvDRV_30_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvDRV_30 failed : ");
                exit(1);
        }
        printf("\n335.CatalystToOrdSrvDRV_30 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_1, CatalystToOrdSrvBSEEQ_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_1 failed : ");
                exit(1);
        }
        printf("\n336.CatalystToOrdSrvBSEEQ_1 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_2, CatalystToOrdSrvBSEEQ_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_2 failed : ");
                exit(1);
        }
        printf("\n337.CatalystToOrdSrvBSEEQ_2 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_3, CatalystToOrdSrvBSEEQ_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_3 failed : ");
                exit(1);
        }
        printf("\n338.CatalystToOrdSrvBSEEQ_3 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_4, CatalystToOrdSrvBSEEQ_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_4 failed : ");
                exit(1);
        }
        printf("\n339.CatalystToOrdSrvBSEEQ_4 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_5, CatalystToOrdSrvBSEEQ_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_5 failed : ");
                exit(1);
        }
        printf("\n340.CatalystToOrdSrvBSEEQ_5 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_6, CatalystToOrdSrvBSEEQ_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_6 failed : ");
                exit(1);
        }
        printf("\n341.CatalystToOrdSrvBSEEQ_6 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_7, CatalystToOrdSrvBSEEQ_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_7 failed : ");
                exit(1);
        }
        printf("\n342.CatalystToOrdSrvBSEEQ_7 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_8, CatalystToOrdSrvBSEEQ_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_8 failed : ");
                exit(1);
        }
        printf("\n343.CatalystToOrdSrvBSEEQ_8 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_9, CatalystToOrdSrvBSEEQ_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_9 failed : ");
                exit(1);
        }
        printf("\n344.CatalystToOrdSrvBSEEQ_9 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_10, CatalystToOrdSrvBSEEQ_10_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_10 failed : ");
                exit(1);
        }
        printf("\n345.CatalystToOrdSrvBSEEQ_10 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_11, CatalystToOrdSrvBSEEQ_11_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_11 failed : ");
                exit(1);
        }
        printf("\n346.CatalystToOrdSrvBSEEQ_11 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_12, CatalystToOrdSrvBSEEQ_12_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_12 failed : ");
                exit(1);
        }
        printf("\n347.CatalystToOrdSrvBSEEQ_12 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_13, CatalystToOrdSrvBSEEQ_13_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_13 failed : ");
                exit(1);
        }
        printf("\n348.CatalystToOrdSrvBSEEQ_13 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_14, CatalystToOrdSrvBSEEQ_14_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_14 failed : ");
                exit(1);
        }
        printf("\n349.CatalystToOrdSrvBSEEQ_14 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_15, CatalystToOrdSrvBSEEQ_15_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_15 failed : ");
                exit(1);
        }
        printf("\n340.CatalystToOrdSrvBSEEQ_15 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_16, CatalystToOrdSrvBSEEQ_16_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_16 failed : ");
                exit(1);
        }
        printf("\n341.CatalystToOrdSrvBSEEQ_16 : ");
		if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_17, CatalystToOrdSrvBSEEQ_17_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_17 failed : ");
                exit(1);
        }
        printf("\n342.CatalystToOrdSrvBSEEQ_17 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_18, CatalystToOrdSrvBSEEQ_18_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_18 failed : ");
                exit(1);
        }
        printf("\n343.CatalystToOrdSrvBSEEQ_18 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_19, CatalystToOrdSrvBSEEQ_19_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_19 failed : ");
                exit(1);
        }
        printf("\n344.CatalystToOrdSrvBSEEQ_19 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_20, CatalystToOrdSrvBSEEQ_20_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_20 failed : ");
                exit(1);
        }
        printf("\n345.CatalystToOrdSrvBSEEQ_20 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_21, CatalystToOrdSrvBSEEQ_21_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_21 failed : ");
                exit(1);
        }
        printf("\n346.CatalystToOrdSrvBSEEQ_21 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_22, CatalystToOrdSrvBSEEQ_22_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_22 failed : ");
                exit(1);
        }
        printf("\n347.CatalystToOrdSrvBSEEQ_22 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_23, CatalystToOrdSrvBSEEQ_23_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_23 failed : ");
                exit(1);
        }
        printf("\n348.CatalystToOrdSrvBSEEQ_23 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_24, CatalystToOrdSrvBSEEQ_24_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_24 failed : ");
                exit(1);
        }
        printf("\n349.CatalystToOrdSrvBSEEQ_24 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_25, CatalystToOrdSrvBSEEQ_25_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_25 failed : ");
                exit(1);
        }
        printf("\n350.CatalystToOrdSrvBSEEQ_25 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_26, CatalystToOrdSrvBSEEQ_26_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_26 failed : ");
                exit(1);
        }
        printf("\n351.CatalystToOrdSrvBSEEQ_26 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_27, CatalystToOrdSrvBSEEQ_27_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_27 failed : ");
                exit(1);
        }
        printf("\n352.CatalystToOrdSrvBSEEQ_27 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_28, CatalystToOrdSrvBSEEQ_28_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_28 failed : ");
                exit(1);
        }
        printf("\n353.CatalystToOrdSrvBSEEQ_28 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_29, CatalystToOrdSrvBSEEQ_29_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_29 failed : ");
                exit(1);
        }
        printf("\n354.CatalystToOrdSrvBSEEQ_29 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEEQ_30, CatalystToOrdSrvBSEEQ_30_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEEQ_30 failed : ");
                exit(1);
        }
        printf("\n355.CatalystToOrdSrvBSEEQ_30 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvNCr_1, CatalystToOrdSrvNCr_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_1 failed : ");
                exit(1);
        }
        printf("\n356.CatalystToOrdSrvNCr_1 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_2, CatalystToOrdSrvNCr_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_2 failed : ");
                exit(1);
        }
        printf("\n357.CatalystToOrdSrvNCr_2 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_3, CatalystToOrdSrvNCr_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_3 failed : ");
                exit(1);
        }
        printf("\n358.CatalystToOrdSrvNCr_3 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_4, CatalystToOrdSrvNCr_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_4 failed : ");
                exit(1);
        }
        printf("\n359.CatalystToOrdSrvNCr_4 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_5, CatalystToOrdSrvNCr_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_5 failed : ");
                exit(1);
        }
        printf("\n360.CatalystToOrdSrvNCr_5 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_6, CatalystToOrdSrvNCr_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_6 failed : ");
                exit(1);
        }
        printf("\n361.CatalystToOrdSrvNCr_6 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_7, CatalystToOrdSrvNCr_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_7 failed : ");
                exit(1);
        }
        printf("\n362.CatalystToOrdSrvNCr_7 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_8, CatalystToOrdSrvNCr_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_8 failed : ");
                exit(1);
        }
        printf("\n363.CatalystToOrdSrvNCr_8 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_9, CatalystToOrdSrvNCr_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_9 failed : ");
                exit(1);
        }
        printf("\n364.CatalystToOrdSrvNCr_9 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_10, CatalystToOrdSrvNCr_10_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_10 failed : ");
                exit(1);
        }
        printf("\n365.CatalystToOrdSrvNCr_10 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_11, CatalystToOrdSrvNCr_11_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_11 failed : ");
                exit(1);
        }
        printf("\n366.CatalystToOrdSrvNCr_11 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_12, CatalystToOrdSrvNCr_12_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_12 failed : ");
                exit(1);
        }
        printf("\n367.CatalystToOrdSrvNCr_12 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_13, CatalystToOrdSrvNCr_13_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_13 failed : ");
                exit(1);
        }
        printf("\n368.CatalystToOrdSrvNCr_13 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_14, CatalystToOrdSrvNCr_14_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_14 failed : ");
                exit(1);
        }
        printf("\n369.CatalystToOrdSrvNCr_14 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_15, CatalystToOrdSrvNCr_15_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_15 failed : ");
                exit(1);
        }
        printf("\n370.CatalystToOrdSrvNCr_15 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_16, CatalystToOrdSrvNCr_16_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_16 failed : ");
                exit(1);
        }
        printf("\n371.CatalystToOrdSrvNCr_16 : ");
		if (CreateMsgQueue(CatalystToOrdSrvNCr_17, CatalystToOrdSrvNCr_17_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_17 failed : ");
                exit(1);
        }
        printf("\n372.CatalystToOrdSrvNCr_17 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_18, CatalystToOrdSrvNCr_18_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_18 failed : ");
                exit(1);
        }
        printf("\n373.CatalystToOrdSrvNCr_18 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_19, CatalystToOrdSrvNCr_19_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_19 failed : ");
                exit(1);
        }
        printf("\n374.CatalystToOrdSrvNCr_19 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_20, CatalystToOrdSrvNCr_20_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_20 failed : ");
                exit(1);
        }
        printf("\n375.CatalystToOrdSrvNCr_20 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_21, CatalystToOrdSrvNCr_21_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_21 failed : ");
                exit(1);
        }
        printf("\n376.CatalystToOrdSrvNCr_21 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_22, CatalystToOrdSrvNCr_22_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_22 failed : ");
                exit(1);
        }
        printf("\n377.CatalystToOrdSrvNCr_22 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_23, CatalystToOrdSrvNCr_23_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_23 failed : ");
                exit(1);
        }
        printf("\n378.CatalystToOrdSrvNCr_23 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_24, CatalystToOrdSrvNCr_24_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_24 failed : ");
                exit(1);
        }
        printf("\n379.CatalystToOrdSrvNCr_24 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_25, CatalystToOrdSrvNCr_25_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_25 failed : ");
                exit(1);
        }
        printf("\n380.CatalystToOrdSrvNCr_25 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_26, CatalystToOrdSrvNCr_26_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_26 failed : ");
                exit(1);
        }
        printf("\n381.CatalystToOrdSrvNCr_26 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_27, CatalystToOrdSrvNCr_27_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_27 failed : ");
                exit(1);
        }
        printf("\n382.CatalystToOrdSrvNCr_27 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_28, CatalystToOrdSrvNCr_28_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_28 failed : ");
                exit(1);
        }
        printf("\n383.CatalystToOrdSrvNCr_28 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_29, CatalystToOrdSrvNCr_29_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_29 failed : ");
                exit(1);
        }
        printf("\n384.CatalystToOrdSrvNCr_29 : ");

        if (CreateMsgQueue(CatalystToOrdSrvNCr_30, CatalystToOrdSrvNCr_30_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvNCr_30 failed : ");
                exit(1);
        }
        printf("\n385.CatalystToOrdSrvNCr_30 : ");
	
	if (CreateMsgQueue(CatalystToOrdSrvMCX_1, CatalystToOrdSrvMCX_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_1 failed : ");
                exit(1);
        }
        printf("\n386.CatalystToOrdSrvMCX_1 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_2, CatalystToOrdSrvMCX_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_2 failed : ");
                exit(1);
        }
        printf("\n387.CatalystToOrdSrvMCX_2 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_3, CatalystToOrdSrvMCX_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_3 failed : ");
                exit(1);
        }
        printf("\n388.CatalystToOrdSrvMCX_3 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_4, CatalystToOrdSrvMCX_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_4 failed : ");
                exit(1);
        }
        printf("\n389.CatalystToOrdSrvMCX_4 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_5, CatalystToOrdSrvMCX_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_5 failed : ");
                exit(1);
        }
        printf("\n390.CatalystToOrdSrvMCX_5 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_6, CatalystToOrdSrvMCX_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_6 failed : ");
                exit(1);
        }
        printf("\n391.CatalystToOrdSrvMCX_6 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_7, CatalystToOrdSrvMCX_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_7 failed : ");
                exit(1);
        }
        printf("\n392.CatalystToOrdSrvMCX_7 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_8, CatalystToOrdSrvMCX_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_8 failed : ");
                exit(1);
        }
        printf("\n393.CatalystToOrdSrvMCX_8 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_9, CatalystToOrdSrvMCX_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_9 failed : ");
                exit(1);
        }
        printf("\n394.CatalystToOrdSrvMCX_9 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_10, CatalystToOrdSrvMCX_10_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_10 failed : ");
                exit(1);
        }
        printf("\n395.CatalystToOrdSrvMCX_10 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_11, CatalystToOrdSrvMCX_11_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_11 failed : ");
                exit(1);
        }
        printf("\n396.CatalystToOrdSrvMCX_11 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_12, CatalystToOrdSrvMCX_12_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_12 failed : ");
                exit(1);
        }
        printf("\n397.CatalystToOrdSrvMCX_12 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_13, CatalystToOrdSrvMCX_13_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_13 failed : ");
                exit(1);
        }
        printf("\n398.CatalystToOrdSrvMCX_13 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_14, CatalystToOrdSrvMCX_14_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_14 failed : ");
                exit(1);
        }
        printf("\n399.CatalystToOrdSrvMCX_14 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_15, CatalystToOrdSrvMCX_15_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_15 failed : ");
                exit(1);
        }
        printf("\n400.CatalystToOrdSrvMCX_15 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_16, CatalystToOrdSrvMCX_16_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_16 failed : ");
                exit(1);
        }
        printf("\n401.CatalystToOrdSrvMCX_16 : ");
		if (CreateMsgQueue(CatalystToOrdSrvMCX_17, CatalystToOrdSrvMCX_17_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_17 failed : ");
                exit(1);
        }
        printf("\n402.CatalystToOrdSrvMCX_17 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_18, CatalystToOrdSrvMCX_18_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_18 failed : ");
                exit(1);
        }
        printf("\n403.CatalystToOrdSrvMCX_18 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_19, CatalystToOrdSrvMCX_19_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_19 failed : ");
                exit(1);
        }
        printf("\n404.CatalystToOrdSrvMCX_19 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_20, CatalystToOrdSrvMCX_20_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_20 failed : ");
                exit(1);
        }
        printf("\n405.CatalystToOrdSrvMCX_20 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_21, CatalystToOrdSrvMCX_21_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_21 failed : ");
                exit(1);
        }
        printf("\n406.CatalystToOrdSrvMCX_21 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_22, CatalystToOrdSrvMCX_22_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_22 failed : ");
                exit(1);
        }
        printf("\n407.CatalystToOrdSrvMCX_22 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_23, CatalystToOrdSrvMCX_23_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_23 failed : ");
                exit(1);
        }
        printf("\n408.CatalystToOrdSrvMCX_23 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_24, CatalystToOrdSrvMCX_24_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_24 failed : ");
                exit(1);
        }
        printf("\n409.CatalystToOrdSrvMCX_24 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_25, CatalystToOrdSrvMCX_25_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_25 failed : ");
                exit(1);
        }
        printf("\n410.CatalystToOrdSrvMCX_25 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_26, CatalystToOrdSrvMCX_26_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_26 failed : ");
                exit(1);
        }
        printf("\n411.CatalystToOrdSrvMCX_26 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_27, CatalystToOrdSrvMCX_27_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_27 failed : ");
                exit(1);
        }
        printf("\n412.CatalystToOrdSrvMCX_27 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_28, CatalystToOrdSrvMCX_28_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_28 failed : ");
                exit(1);
        }
        printf("\n413.CatalystToOrdSrvMCX_28 : ");

        if (CreateMsgQueue(CatalystToOrdSrvMCX_29, CatalystToOrdSrvMCX_29_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_29 failed : ");
                exit(1);
        }
        printf("\n414.CatalystToOrdSrvMCX_29 : ");


	if (CreateMsgQueue(CatalystToOrdSrvMCX_30, CatalystToOrdSrvMCX_30_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvMCX_30 failed : ");
                exit(1);
        }
        printf("\n415.CatalystToOrdSrvMCX_30 : ");

	if (CreateMsgQueue(CatalystToOrdProNEQ, CatalystToOrdProNEQ_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdProNEQ failed : ");
                exit(1);
        }
        printf("\n416.CatalystToOrdProNEQ : ");

	if (CreateMsgQueue(CatalystToOrdProNFO, CatalystToOrdProNFO_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdProNFO_30 failed : ");
                exit(1);
        }
        printf("\n417.CatalystToOrdProNFO : ");

	if (CreateMsgQueue(CatalystToOrdProNCD, CatalystToOrdProNCD_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdProNCD failed : ");
                exit(1);
        }
        printf("\n418.CatalystToOrdProNCD : ");

	if (CreateMsgQueue(CatalystToOrdProBEQ, CatalystToOrdProBEQ_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdProBEQ failed : ");
                exit(1);
        }
        printf("\n419.CatalystToOrdProBEQ : ");
	
	if (CreateMsgQueue(CatalystToOrdProMCX, CatalystToOrdProMCX_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdProMCX failed : ");
                exit(1);
        }
        printf("\n420.CatalystToOrdProMCX : ");				

	if (CreateMsgQueue(KafkaToNotify, KafkaToNotify_SIZE) == ERROR )
        {
                logFatal("KafkaToNotify failed : ");
                exit(1);
        }
        printf("\n421.KafkaToNotify: ");



	//// = = = = == = = = = = = = = = = = /////

	if (CreateMsgQueue(OrdRtrToOrdSrvBSEDRV , OrdRtrToOrdSrvBSEDRV_SIZE) == ERROR )
        {
                logFatal("OrdRtrToOrdSrvBSEDRV failed : ");
                exit(1);
        }
        printf("\n393. OrdRtrToOrdSrvBSEDRV  : ");

	if (CreateMsgQueue(OrdSrvToMapperBSEDRV , OrdSrvToMapperBSEDRV_SIZE) == ERROR )
        {
                logFatal("OrdSrvToMapperBSEDRV failed : ");
                exit(1);
        }
        printf("\n394. OrdSrvToMapperBSEDRV  : ");

	if (CreateMsgQueue(MapperToConnBSEDRV , MapperToConnBSEDRV_SIZE) == ERROR )
        {
                logFatal("MapperToConnBSEDRV failed : ");
                exit(1);
        }
        printf("\n395. MapperToConnBSEDRV  : ");

	if (CreateMsgQueue(ConnToTrdMapBSEDRV , ConnToTrdMapBSEDRV_SIZE) == ERROR )
        {
                logFatal("ConnToTrdMapBSEDRV failed : ");
                exit(1);
        }
        printf("\n396. ConnToTrdMapBSEDRV  : ");

        if (CreateMsgQueue(RevMapToTrdSrvBSEDRV , RevMapToTrdSrvBSEDRV_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSEDRV failed : ");
                exit(1);
        }
        printf("\n397. RevMapToTrdSrvBSEDRV  : ");

        if (CreateMsgQueue(OrdRtrToCatalystBSEDRV , OrdRtrToCatalystBSEDRV_SIZE) == ERROR )
        {
                logFatal("OrdRtrToCatalystBSEDRV failed : ");
                exit(1);
        }
        printf("\n398. OrdRtrToCatalystBSEDRV  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_1 , CatalystToOrdSrvBSEDRV_1_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_1 failed : ");
                exit(1);
        }
        printf("\n399. CatalystToOrdSrvBSEDRV_1  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_2 , CatalystToOrdSrvBSEDRV_2_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_2 failed : ");
                exit(1);
        }
        printf("\n400. CatalystToOrdSrvBSEDRV_2  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_3 , CatalystToOrdSrvBSEDRV_3_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_3 failed : ");
                exit(1);
        }
        printf("\n401. CatalystToOrdSrvBSEDRV_3  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_4 , CatalystToOrdSrvBSEDRV_4_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_4 failed : ");
                exit(1);
        }
        printf("\n402. CatalystToOrdSrvBSEDRV_4  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_5 , CatalystToOrdSrvBSEDRV_5_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_5 failed : ");
                exit(1);
        }
        printf("\n403. CatalystToOrdSrvBSEDRV_5  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_6 , CatalystToOrdSrvBSEDRV_6_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_6 failed : ");
                exit(1);
        }
        printf("\n404. CatalystToOrdSrvBSEDRV_6  : ");
	
        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_7 , CatalystToOrdSrvBSEDRV_7_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_7 failed : ");
                exit(1);
        }
        printf("\n405. CatalystToOrdSrvBSEDRV_7  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_8 , CatalystToOrdSrvBSEDRV_8_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_8 failed : ");
                exit(1);
        }
        printf("\n406. CatalystToOrdSrvBSEDRV_8  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_9 , CatalystToOrdSrvBSEDRV_9_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_9 failed : ");
                exit(1);
        }
        printf("\n407. CatalystToOrdSrvBSEDRV_9  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_10 , CatalystToOrdSrvBSEDRV_10_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_10 failed : ");
                exit(1);
        }
        printf("\n408. CatalystToOrdSrvBSEDRV_10  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_11 , CatalystToOrdSrvBSEDRV_11_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_11 failed : ");
                exit(1);
        }
        printf("\n409. CatalystToOrdSrvBSEDRV_11  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_12 , CatalystToOrdSrvBSEDRV_12_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_12 failed : ");
                exit(1);
        }
        printf("\n410. CatalystToOrdSrvBSEDRV_12  : ");

	if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_13 , CatalystToOrdSrvBSEDRV_13_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_13 failed : ");
                exit(1);
        }
        printf("\n411. CatalystToOrdSrvBSEDRV_13  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_14 , CatalystToOrdSrvBSEDRV_14_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_14 failed : ");
                exit(1);
        }
        printf("\n412. CatalystToOrdSrvBSEDRV_14  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_15 , CatalystToOrdSrvBSEDRV_15_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_15 failed : ");
                exit(1);
        }
        printf("\n413. CatalystToOrdSrvBSEDRV_15  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_16 , CatalystToOrdSrvBSEDRV_16_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_16 failed : ");
                exit(1);
        }
        printf("\n414. CatalystToOrdSrvBSEDRV_16  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_17 , CatalystToOrdSrvBSEDRV_17_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_17 failed : ");
                exit(1);
        }
        printf("\n415. CatalystToOrdSrvBSEDRV_17  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_18 , CatalystToOrdSrvBSEDRV_18_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_18 failed : ");
                exit(1);
        }
        printf("\n416. CatalystToOrdSrvBSEDRV_18  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_19 , CatalystToOrdSrvBSEDRV_19_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_19 failed : ");
                exit(1);
        }
        printf("\n417. CatalystToOrdSrvBSEDRV_19  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_20 , CatalystToOrdSrvBSEDRV_20_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_20 failed : ");
                exit(1);
        }
        printf("\n418. CatalystToOrdSrvBSEDRV_20  : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_21 , CatalystToOrdSrvBSEDRV_21_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_21 failed : ");
                exit(1);
        }
        printf("\n419. CatalystToOrdSrvBSEDRV_21 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_22 , CatalystToOrdSrvBSEDRV_22_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_22 failed : ");
                exit(1);
        }
        printf("\n420. CatalystToOrdSrvBSEDRV_22 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_23 , CatalystToOrdSrvBSEDRV_23_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_23 failed : ");
                exit(1);
        }
        printf("\n421. CatalystToOrdSrvBSEDRV_23 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_24 ,CatalystToOrdSrvBSEDRV_24_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_24 failed : ");
                exit(1);
        }
        printf("\n422. CatalystToOrdSrvBSEDRV_24 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_25 , CatalystToOrdSrvBSEDRV_25_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_25 failed : ");
                exit(1);
        }
        printf("\n423. CatalystToOrdSrvBSEDRV_25 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_26 , CatalystToOrdSrvBSEDRV_26_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_26 failed : ");
                exit(1);
        }
        printf("\n424. CatalystToOrdSrvBSEDRV_26 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_27 , CatalystToOrdSrvBSEDRV_27_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_27 failed : ");
                exit(1);
        }
        printf("\n425. CatalystToOrdSrvBSEDRV_27 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_28 , CatalystToOrdSrvBSEDRV_28_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_28 failed : ");
                exit(1);
        }
        printf("\n426. CatalystToOrdSrvBSEDRV_28 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_29 , CatalystToOrdSrvBSEDRV_29_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_29 failed : ");
                exit(1);
        }
        printf("\n427. CatalystToOrdSrvBSEDRV_29 : ");

        if (CreateMsgQueue(CatalystToOrdSrvBSEDRV_30 , CatalystToOrdSrvBSEDRV_30_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvBSEDRV_30 failed : ");
                exit(1);
        }
        printf("\n428. CatalystToOrdSrvBSEDRV_30 : ");

	if (CreateMsgQueue(RevMapToMMapBSEDRV_1, RevMapToMMapBSEDRV_1_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_1 failed : ");
                exit(1);
        }
        printf("\n429. RevMapToMMapBSEDRV_1 : ");

        if (CreateMsgQueue( RevMapToMMapBSEDRV_2, RevMapToMMapBSEDRV_2_SIZE) == ERROR )
        {
                logFatal("RevMapToMMapBSEDRV_2 failed : ");
                exit(1);
        }
        printf("\n430. RevMapToMMapBSEDRV_2 : ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_3 , RevMapToMMapBSEDRV_3_SIZE) == ERROR )
        {
                logFatal("RevMapToMMapBSEDRV_3 failed : ");
                exit(1);
        }
        printf("\n431. RevMapToMMapBSEDRV_3 : ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_4 ,RevMapToMMapBSEDRV_4_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_4 failed : ");
                exit(1);
        }
        printf("\n432. RevMapToMMapBSEDRV_4 : ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_5 , RevMapToMMapBSEDRV_5_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_5 failed : ");
                exit(1);
        }
        printf("\n433. RevMapToMMapBSEDRV_5 : ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_6 , RevMapToMMapBSEDRV_6_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_6 failed : ");
                exit(1);
        }
        printf("\n434. RevMapToMMapBSEDRV_6 : ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_7 , RevMapToMMapBSEDRV_7_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_7 failed : ");
                exit(1);
        }
        printf("\n435. RevMapToMMapBSEDRV_7: ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_8 , RevMapToMMapBSEDRV_8_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_8 failed : ");
                exit(1);
        }
        printf("\n436. RevMapToMMapBSEDRV_8 : ");

        if (CreateMsgQueue(RevMapToMMapBSEDRV_9 , RevMapToMMapBSEDRV_9_SIZE) == ERROR )
        {
                logFatal(" RevMapToMMapBSEDRV_9 failed : ");
                exit(1);
        }
        printf("\n437. RevMapToMMapBSEDRV_9 : ");

	if (CreateMsgQueue(MMapToTrdSvrBSEDRV_1 , MMapToTrdSvrBSEDRV_1_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_1 failed : ");
                exit(1);
        }
        printf("\n438. MMapToTrdSvrBSEDRV_1 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_2 , MMapToTrdSvrBSEDRV_2_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_2 failed : ");
                exit(1);
        }
        printf("\n439. MMapToTrdSvrBSEDRV_2 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_3 , MMapToTrdSvrBSEDRV_3_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_3 failed : ");
                exit(1);
        }
        printf("\n440. MMapToTrdSvrBSEDRV_3 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_4 , MMapToTrdSvrBSEDRV_4_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_4 failed : ");
                exit(1);
        }
        printf("\n441. MMapToTrdSvrBSEDRV_4 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_5 , MMapToTrdSvrBSEDRV_5_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_5 failed : ");
                exit(1);
        }
        printf("\n442. MMapToTrdSvrBSEDRV_5 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_6 , MMapToTrdSvrBSEDRV_6_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_6 failed : ");
                exit(1);
        }
        printf("\n443. MMapToTrdSvrBSEDRV_6 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_7 , MMapToTrdSvrBSEDRV_7_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_7 failed : ");
                exit(1);
        }
        printf("\n444. MMapToTrdSvrBSEDRV_7 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_8 , MMapToTrdSvrBSEDRV_8_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_8 failed : ");
                exit(1);
        }
        printf("\n445. MMapToTrdSvrBSEDRV_8 : ");

        if (CreateMsgQueue(MMapToTrdSvrBSEDRV_9 , MMapToTrdSvrBSEDRV_9_SIZE) == ERROR )
        {
                logFatal(" MMapToTrdSvrBSEDRV_9 failed : ");
                exit(1);
        }
        printf("\n446. MMapToTrdSvrBSEDRV_9 : ");
	
	printf("\n-------------------------- END Creating Queues ------------------------------");
		
		
		
	logTimestamp("Exit  CreateSeed: [main]");
	exit(0);
}/*END OF MAIN*/


BOOL	CheckLicense()
{
	FILE	*fPointer,*Open;
	CHAR	sReadBuf[50];
	CHAR	sUnixDate[20];
	LONG64	iLicendate,iTodaydate;

	memset(sReadBuf,'\0',50);
	//memset(sUnixDate,'\0',20);
	sprintf(sFilePath,"%s",sLicPath);
	printf("sFilePath :%s:\n",sFilePath);
//	fPointer = fopen("License.ini","rb");		
	fPointer = fopen(sFilePath,"rb");		

	if(fPointer == NULL)
	{
		logFatal("Error in Opening File");
		perror("");
		return FALSE;
	}

	fread(sReadBuf,sizeof(sReadBuf),1,fPointer);	

	//	printf("Encrypted sReadBuf :%s:\n",sReadBuf);

	Unscramble(sReadBuf);		

	//	printf("Dencrypted sReadBuf :%s:\n",sReadBuf);

	Open = popen("date '+%s'","r");

	if(fgets(sUnixDate, sizeof(sUnixDate), Open) == NULL)
	{
		printf("Some Error Occured\n");
		exit(1);
	}
	//        printf("sUnixDate :%s:\n",sUnixDate);

	iLicendate = atol(sReadBuf);
	iTodaydate = atol(sUnixDate);

	printf("iLicendate :%ld:\n",iLicendate);
	printf("iTodaydate :%ld:\n",iTodaydate);

	if(iLicendate > iTodaydate)
	{
		return TRUE;	
	}
	else
	{
		return FALSE;
	}	

}

void Unscramble(char *sStr)
{
	int i =0 ;
	for(i = strlen(sStr) - 1; i >= 0; i--)
	{
		//printf("%c\n",sStr[i]);
		if((sStr[i] - i) < min)
		{
			sStr[i] = max - (min - (sStr[i] - i));
		}
		else
		{
			sStr[i] = sStr[i] - i;
		}
	}
}
/* License file is moved to home directory for that LICENSE_PATH is added in env@Rohit*/
void Loadenv()
{
        if(getenv("LICENSE_PATH") == NULL)
        {
                logFatal("Error : Environment variables missing : LICENSE_PATH");
                exit(ERROR);
        }
        else
        {
                strncpy(sLicPath,getenv("LICENSE_PATH"),100);
        }
	printf("sLicPath :%s:\n",sLicPath);
}

