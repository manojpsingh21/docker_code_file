#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "IPCS.h"

main ()
{

	int	iFunc1 = 0,iFunc2 = 0;
	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	if ((iFunc1=fork())==0)
	{
		logTimestamp("iFunc1 Created");
		fFunc1();
	}
	if ((iFunc2=fork())==0)
	{
		logTimestamp("iFunc2 Created");
		fFunc2();
	}
	fConnectionUP();

}

void fFunc1()
{
	logDebug2("Nishant 1");
	return TRUE ;
}

void fFunc2()
{
	logDebug2("Nishant 2");
	return TRUE ;

}

void fConnectionUP()
{
	int iGroupId =1;
	logTimestamp("Entry : [fConnectionUP]");
	fUpdateConnectStatus(NSE_EQU_UP, iGroupId);
	logInfo("fUpdateConnectStatus UP");
	logTimestamp("Exit : [fConnectionUP]");
	return ;
}
