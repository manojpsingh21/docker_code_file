#include "HashTable.h"
#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

extern DBConNEQ;
struct  SEC_MASTER_ARRAY	*Hash_ByID = NULL;
struct  SEC_MASTER_ARRAY	*Hash_DrvID = NULL;
struct  SEC_MASTER_ARRAY	*Hash_McxID = NULL;
struct  SEC_MASTER_ARRAY	*Hash_BComID = NULL;
struct  SPRD_SEC_MASTER_ARRAY        *HashSprByID = NULL;
struct  SPRD_SEC_MASTER_ARRAY        *HashSprDrvID = NULL;
struct	ENTITY_SETTLOR_MASTER_ARRAY	*Hash_ByID1 = NULL;
struct  ENTITY_SETTLOR_MASTER_ARRAY     *Hash_DrvID1 = NULL;
struct  ENTITY_SETTLOR_MASTER_ARRAY     *Hash_CurrID1 = NULL;

DOUBLE64        fstart ;
DOUBLE64        fEnd;


BOOL fGetSecDetails(struct INT_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetSecDetails]");

	MYSQL	*DBConSec;
	struct  	SEC_MASTER_ARRAY	*pSec,*pHashAdd	;
	LONG32		iCnt		=	0	;
	CHAR		sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR		*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY)); 
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY)); 

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);


	HASH_FIND(hSecHndlr,Hash_ByID, &sTempSecID,strlen(sTempSecID),pSec);

	if(pSec != NULL)
	{
		strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN) 				;	

		strncpy(pRes->sSymbolSfx,pSec->sSeries,DB_SERIES_LEN)			;
		strncpy(pRes->sInstrumentType,pSec->sSeries,DB_SERIES_LEN)		;
		strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN)			;
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN)		;
		strncpy(pRes->sISINCode,pSec->sISINCode,DB_ISIN_CODE_LEN)		;
		strncpy(pRes->sInstrumentTyp,pSec->sInstrumentTyp,INSTRUMENT_TYPE)	;
		strncpy(pRes->ReqHeader.sExcgId,pSec->sExch,DB_EXCH_ID_LEN)		;
		pRes->fLotSize = pSec->fLotSize 					;
		pRes->fTickSize = pSec->fTickSize 					;
		//INTEROPS CHANGES
                strncpy(pRes->sIntropScripCode,pSec->sIntropScripCode,DB_SECURITY_ID_LEN);
                strncpy(pRes->sIntropSymbol,pSec->sIntropSymbol,DB_SYM_LEN)          	;
                strncpy(pRes->sNseScripCode,pSec->sNseScripCode,DB_SECURITY_ID_LEN)     ;
                strncpy(pRes->sBseScripCode,pSec->sBseScripCode,DB_SECURITY_ID_LEN)     ;
		strncpy(pRes->sSmExpiryFlag,pSec->sSmExpiryFlag,DB_EXPIRY_FLAG_LEN)	;			;

		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol)				;
		logDebug2("pRes->sInstrumentTyp	:%s:",pRes->sInstrumentType)		;
		logDebug2("pRes->sSeries	:%s:",pRes->sSeries)			;
		logDebug2("pRes->sSymbolSfx	:%s:",pRes->sSymbolSfx)			;
		logDebug2("pRes->sCustomSym	:%s:",pRes->sCustomSym)			;
		logDebug2("pRes->fLotSize	:%f:",pRes->fLotSize)			;
		logDebug2("pRes->fTickSize	:%f:",pRes->fTickSize)			;
		logDebug2("pRes->sISINCode	:%s:",pRes->sISINCode)			;
		logDebug2("pRes->sInstrumentTyp:%s:",pRes->sInstrumentTyp)		;
		logDebug2("pRes->ReqHeader.sExcgId:%s:",pRes->ReqHeader.sExcgId)	;
		//INTEROPS CHANGES
                logDebug2("pRes->sIntropScripCode:%s:",pRes->sIntropScripCode)          ;
                logDebug2("pRes->sIntropSymbol   :%s:",pRes->sIntropSymbol)             ;
                logDebug2("pRes->sNseScripCode   :%s:",pRes->sNseScripCode)             ;
                logDebug2("pRes->sBseScripCode   :%s:",pRes->sBseScripCode)             ;
		logDebug2("pRes->sSmExpiryFlag   :%s:",pRes->sSmExpiryFlag)             ;
		
	}
	else
	{
		DBConSec = DB_Connect();

		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
				ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_CUSTOM_SYMBOL,ifnull(SM_EXCH_INSTRUMENT_TYPE,'NA'),\
				SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP,SM_EXPIRY_FLAG \
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'E\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);

		fstart = logGetTime();

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}
		fEnd = logGetTime();

		printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));


		Res = mysql_store_result(DBConSec);

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN)			;
			strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN)		;
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN)	;

			logDebug2("STRLEN :%d:",strlen(Row[4]))			;

			strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN)	;
			strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN)		;
			strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN)	;
			strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN)		;
			strncpy(pHashAdd->sSeries,Row[8],DB_SERIES_LEN)		;

			pHashAdd->cStatus = Row[9][0]		;
			pHashAdd->cExchStatus= Row[10][0]	;
			pHashAdd->cPreOpenFlag= Row[11][0]	;
			pHashAdd->cPreOpenExchFlag= Row[12][0]	;
			pHashAdd->cITSFlag= Row[13][0]		;
			pHashAdd->cAlgoFlag= Row[14][0]		;
			pHashAdd->cCAFlag= Row[15][0]		;
			pHashAdd->iFaceValue= atoi(Row[16])	;
			pHashAdd->fTickSize= atof(Row[17])	;
			pHashAdd->fLotSize= atof(Row[18])	;
			//strncpy(EqSecHsh[i]->SecMaster.sLotUnits,Row[19],DB_LOT_UNITS_LEN);
			pHashAdd->fUpperLimit= atof(Row[20])	;
			pHashAdd->fLowerLimit= atof(Row[21])	;
			strncpy(pHashAdd->sCustomSym,Row[22],CUSTOM_SYM_LEN)		;				
			strncpy(pHashAdd->sInstrumentTyp,Row[23],INSTRUMENT_TYPE)		;		
			//@ashish added for mapping in case not getting scrip code from in memory.		
			strncpy(pRes->sSymbolSfx,Row[8],DB_SERIES_LEN)	;
			strncpy(pRes->sInstrumentType,Row[8],DB_SERIES_LEN)	;
			strncpy(pRes->sSeries,Row[8],DB_SERIES_LEN)	;
			strncpy(pRes->sCustomSym,Row[22],CUSTOM_SYM_LEN)	;
			strncpy(pRes->sISINCode,Row[4],DB_ISIN_CODE_LEN)	;
			strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN) 		;	
			pRes->fLotSize =  atof(Row[18]);
			pRes->fTickSize = atof(Row[17]) ;

			//INTEROPS CHANGES 
	                strncpy(pHashAdd->sIntropScripCode,Row[24],DB_SECURITY_ID_LEN);
        	        strncpy(pHashAdd->sIntropSymbol,Row[25],DB_SYM_LEN)             ;
			strncpy(pHashAdd->sNseScripCode,Row[26],DB_SECURITY_ID_LEN)     ;
                	strncpy(pHashAdd->sBseScripCode,Row[27],DB_SECURITY_ID_LEN)     ;
			//Mandar added Mapping in Memory
			strncpy(pRes->sIntropScripCode,Row[24],DB_SECURITY_ID_LEN);
                	strncpy(pRes->sIntropSymbol,Row[25],DB_SYM_LEN)             ;
        	        strncpy(pRes->sNseScripCode,Row[26],DB_SECURITY_ID_LEN)     ;
	                strncpy(pRes->sBseScripCode,Row[27],DB_SECURITY_ID_LEN)     ;

			strncpy(pHashAdd->sSmExpiryFlag,Row[28],DB_EXPIRY_FLAG_LEN);
			strncpy(pRes->sSmExpiryFlag,Row[28],DB_EXPIRY_FLAG_LEN);

			HASH_ADD(hSecHndlr,Hash_ByID, sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);	

			mysql_close(DBConSec);
		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}

	}
	logTimestamp("EXIT [fGetSecDetails]");
	return TRUE;

}

BOOL fGetSIPSecDetails(struct SIP_INT_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetSIPSecDetails]");

	MYSQL   *DBConSec;
	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          iCnt            =       0       ;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);


	HASH_FIND(hSecHndlr,Hash_ByID, &sTempSecID,strlen(sTempSecID),pSec);

	if(pSec != NULL)
	{
		strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN)            ;

		strncpy(pRes->sSymbolSfx,pSec->sSeries,DB_SERIES_LEN)   ;
		strncpy(pRes->sInstrumentType,pSec->sSeries,DB_SERIES_LEN)      ;
                strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN)      ;
                strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN)       ;
                strncpy(pRes->sISINCode,pSec->sISINCode,DB_ISIN_CODE_LEN)       ;
                strncpy(pRes->sInstrumentTyp,pSec->sInstrumentTyp,INSTRUMENT_TYPE)      ;
                strncpy(pRes->ReqHeader.sExcgId,pSec->sExch,DB_EXCH_ID_LEN)     ;
                pRes->fLotSize = pSec->fLotSize ;
                pRes->fTickSize = pSec->fTickSize ;

		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol)                           ;
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType)    ;
		logDebug2("pRes->sSeries        :%s:",pRes->sSeries)                    ;
		logDebug2("pRes->sSymbolSfx     :%s:",pRes->sSymbolSfx)                 ;

	}
	else
	{
		DBConSec = DB_Connect();

		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
				ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_CUSTOM_SYMBOL,ifnull(SM_EXCH_INSTRUMENT_TYPE,'NA')\
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'E\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}

		Res = mysql_store_result(DBConSec);

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN)                  ;
			strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN)          ;
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN)      ;

			logDebug2("STRLEN :%d:",strlen(Row[4]))                 ;

			strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN)    ;
			strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN)               ;
			strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN)      ;
			strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN)           ;
			strncpy(pHashAdd->sSeries,Row[8],DB_SERIES_LEN)         ;

			pHashAdd->cStatus = Row[9][0]           ;
			pHashAdd->cExchStatus= Row[10][0]       ;
			pHashAdd->cPreOpenFlag= Row[11][0]      ;
			pHashAdd->cPreOpenExchFlag= Row[12][0]  ;
			pHashAdd->cITSFlag= Row[13][0]          ;
			pHashAdd->cAlgoFlag= Row[14][0]         ;
			pHashAdd->cCAFlag= Row[15][0]           ;
			pHashAdd->iFaceValue= atoi(Row[16])     ;
			pHashAdd->fTickSize= atof(Row[17])      ;
			pHashAdd->fLotSize= atof(Row[18])       ;
			pHashAdd->fUpperLimit= atof(Row[20])    ;
			pHashAdd->fLowerLimit= atof(Row[21])    ;
			strncpy(pHashAdd->sCustomSym,Row[22],CUSTOM_SYM_LEN)            ;
                        strncpy(pHashAdd->sInstrumentTyp,Row[23],INSTRUMENT_TYPE)               ;
			
			strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
			strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN)        ;
			strncpy(pRes->sSeries,Row[8],DB_SERIES_LEN)             ;
			strncpy(pRes->sSymbolSfx,Row[8],DB_SERIES_LEN)          ;
			strncpy(pRes->sInstrumentType,Row[8],DB_SERIES_LEN)     ;
                        strncpy(pRes->sSeries,Row[8],DB_SERIES_LEN)     ;
                        strncpy(pRes->sCustomSym,Row[22],CUSTOM_SYM_LEN)        ;
                        strncpy(pRes->sISINCode,Row[4],DB_ISIN_CODE_LEN)        ;
                        strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN)                ;
                        pRes->fLotSize =  atof(Row[18]);
                        pRes->fTickSize = atof(Row[17]) ;

			HASH_ADD(hSecHndlr,Hash_ByID, sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);

			mysql_close(DBConSec);
		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}

	}
	logTimestamp("EXIT [fGetSIPSecDetails]");
	return TRUE;

}


BOOL fGetCBSecDetails(struct INT_COBO_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetCBSecDetails ]");

	MYSQL   *DBConSec;
	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          iCnt            =       0       ;
	LONG32	iNumRows = 0;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);


	HASH_FIND(hSecHndlr,Hash_ByID, &sTempSecID,strlen(sTempSecID),pSec);

	if(pSec != NULL)
	{
		logDebug2("pSec->sSym :%s:",pSec->sSym);
		strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN)            ;

		strncpy(pRes->sSymbolSfx,pSec->sSeries,DB_SERIES_LEN)   ;
		strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN)	;
		strncpy(pRes->sISINCode,pSec->sISINCode,DB_ISIN_CODE_LEN)	;
		pRes->fLotSize = pSec->fLotSize ;
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN)	;
		strncpy(pRes->sInstrumentTyp,pSec->sInstrumentTyp,INSTRUMENT_TYPE)	;
		strncpy(pRes->ReqHeader.sExcgId,pSec->sExch,DB_EXCH_ID_LEN)     ;
		pRes->fTickSize = pSec->fTickSize ;

                //INTEROPS CHANGES
                strncpy(pRes->sIntropScripCode,pSec->sIntropScripCode,DB_SECURITY_ID_LEN);
                strncpy(pRes->sIntropSymbol,pSec->sIntropSymbol,DB_SYM_LEN)             ;
                strncpy(pRes->sNseScripCode,pSec->sNseScripCode,DB_SECURITY_ID_LEN)     ;
                strncpy(pRes->sBseScripCode,pSec->sBseScripCode,DB_SECURITY_ID_LEN)     ;
                strncpy(pRes->sSmExpiryFlag,pSec->sSmExpiryFlag,DB_EXPIRY_FLAG_LEN)     ; 

		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol)                           ;
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType)    ;
		logDebug2("pRes->sSymbolSfx     :%s:",pRes->sSymbolSfx)                 ;
		logDebug2("pRes->sSeries	:%s:",pRes->sSeries)			;
		logDebug2("pRes->sSymbolSfx	:%s:",pRes->sSymbolSfx)			;
		logDebug2("pRes->sCustomSym	:%s:",pRes->sCustomSym)			;
		logDebug2("pRes->fLotSize	:%f:",pRes->fLotSize)			;
		logDebug2("pRes->fTickSize	:%f:",pRes->fTickSize)			;
		logDebug2("pRes->sISINCode	:%s:",pRes->sISINCode)			;
		logDebug2("pRes->sInstrumentTyp:%s:",pRes->sInstrumentTyp)		;
		//INTEROPS CHANGES
                logDebug2("pRes->sIntropScripCode:%s:",pRes->sIntropScripCode)          ;
                logDebug2("pRes->sIntropSymbol   :%s:",pRes->sIntropSymbol)             ;
                logDebug2("pRes->sNseScripCode   :%s:",pRes->sNseScripCode)             ;
                logDebug2("pRes->sBseScripCode   :%s:",pRes->sBseScripCode)             ;
		logDebug2("pRes->sSmExpiryFlag   :%s:",pRes->sSmExpiryFlag)             ;	

	}
	else
	{
		DBConSec = DB_Connect();
		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
				ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_CUSTOM_SYMBOL,SM_EXCH_INSTRUMENT_TYPE,\
				SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP,SM_EXPIRY_FLAG\
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);

		fstart = logGetTime();

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}
		fEnd = logGetTime();

		printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));


		Res = mysql_store_result(DBConSec);

		iNumRows = mysql_num_rows(Res);

		logDebug2("iNumRows = :%d:",iNumRows);

		if(iNumRows != 0 )
		{	

			if(Row = mysql_fetch_row(Res))
			{
				strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN)                  ;
				strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN)          ;
				strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN)      ;

				logDebug2("STRLEN :%d:",strlen(Row[4]))                 ;

				strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN)    ;
				strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN)               ;
				strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN)      ;
				strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN)           ;
				strncpy(pHashAdd->sSeries,Row[8],DB_SERIES_LEN)         ;

				pHashAdd->cStatus = Row[9][0]           ;
				pHashAdd->cExchStatus= Row[10][0]       ;
				pHashAdd->cPreOpenFlag= Row[11][0]      ;
				pHashAdd->cPreOpenExchFlag= Row[12][0]  ;
				pHashAdd->cITSFlag= Row[13][0]          ;
				pHashAdd->cAlgoFlag= Row[14][0]         ;
				pHashAdd->cCAFlag= Row[15][0]           ;
				pHashAdd->iFaceValue= atoi(Row[16])     ;
				pHashAdd->fTickSize= atof(Row[17])      ;
				pHashAdd->fLotSize= atof(Row[18])       ;
				//strncpy(EqSecHsh[i]->SecMaster.sLotUnits,Row[19],DB_LOT_UNITS_LEN);
				pHashAdd->fUpperLimit= atof(Row[20])    ;
				pHashAdd->fLowerLimit= atof(Row[21])    ;
				strncpy(pHashAdd->sCustomSym,Row[22],CUSTOM_SYM_LEN)		;				
				strncpy(pHashAdd->sInstrumentTyp,Row[23],INSTRUMENT_TYPE)		;				
				//@ashish added for mapping in case not getting scrip code from in memory.
				strncpy(pRes->sSymbolSfx,Row[8],DB_SERIES_LEN)	;
				strncpy(pRes->sInstrumentType,Row[8],DB_SERIES_LEN)	;
				strncpy(pRes->sSeries,Row[8],DB_SERIES_LEN)	;
				strncpy(pRes->sCustomSym,Row[22],CUSTOM_SYM_LEN)	;
				strncpy(pRes->sISINCode,Row[4],DB_ISIN_CODE_LEN)	;
				strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN) 		;	
				strncpy(pRes->ReqHeader.sExcgId,Row[0],DB_EXCH_ID_LEN)     ;
				pRes->fLotSize =  atof(Row[18]);
				pRes->fTickSize = atof(Row[17]) ;
				
				//INTEROPS CHANGES
	                        strncpy(pHashAdd->sIntropScripCode,Row[24],DB_SECURITY_ID_LEN)  ;
        	                strncpy(pHashAdd->sIntropSymbol,Row[25],DB_SYM_LEN)             ;
                	        strncpy(pHashAdd->sNseScripCode,Row[26],DB_SECURITY_ID_LEN)     ;
                        	strncpy(pHashAdd->sBseScripCode,Row[27],DB_SECURITY_ID_LEN)     ;
				
				//Mandar added for Mapping
				strncpy(pRes->sIntropScripCode,Row[24],DB_SECURITY_ID_LEN);
                        	strncpy(pRes->sIntropSymbol,Row[25],DB_SYM_LEN)             ;
                        	strncpy(pRes->sNseScripCode,Row[26],DB_SECURITY_ID_LEN)     ;
                        	strncpy(pRes->sBseScripCode,Row[27],DB_SECURITY_ID_LEN)     ;
				
				strncpy(pHashAdd->sSmExpiryFlag,Row[28],DB_EXPIRY_FLAG_LEN);
                	        strncpy(pRes->sSmExpiryFlag,Row[28],DB_EXPIRY_FLAG_LEN);
		
				HASH_ADD(hSecHndlr,Hash_ByID, sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);

				mysql_close(DBConSec);
			}
		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}

	}
	logTimestamp("EXIT [fGetCBSecDetails ]");
	return TRUE;
}



BOOL GetSymbolDetails(struct INT_ORDERS *pRes)
{
	logTimestamp("Entry : [GetSymbolDetails]");

	MYSQL	*DBConSec;
	CHAR		*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
	logDebug2("pRes->sSymbolSfx	:%s:",pRes->sSymbolSfx);

	DBConSec = DB_Connect();
	/*****
	  sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_ISIN_CODE,SM_EXCH_SYMBOL,\
	  SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
	  SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,SM_CA_FLAG,SM_FACE_VALUE,SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
	  ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT\
	  FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'E\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,sTempSecID);
	 ********/
	sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
			SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
			SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
			ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT\
			FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'E\' AND SM_SYMBOL = \"%s\" AND SM_SERIES = \"%s\";",\
			pRes->ReqHeader.sExcgId,pRes->sSymbol,pRes->sSymbolSfx);


	logDebug1("sSelQry :%s:",sSelQry);

	if(mysql_query(DBConSec,sSelQry) != SUCCESS)
	{
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [GetSymbolDetails]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}

	Res = mysql_store_result(DBConSec);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
		strncpy(pRes->sSecId,Row[2],DB_SECURITY_ID_LEN);
		mysql_close(DBConSec);
	}
	else
	{
		logDebug1("Symbol is not in DB :%s: :%s:",pRes->sSymbol,pRes->sSymbolSfx);
		mysql_close(DBConSec);
		return FALSE;
	}
	logTimestamp("Exit : [GetSymbolDetails]");

	return TRUE;
}

BOOL	fAddEQSecHash()
{
	logTimestamp("Entry : [fAddEQSecHash]");
	MYSQL		*DBConSec;
	MYSQL_RES 	*Res;
	MYSQL_ROW	Row;
	LONG32 		iNumRow,i=0;
	CHAR		*sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
	CHAR		sTempSecID[DB_SCRIP_CODE_LEN];

	DBConSec = DB_Connect();

	sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
			SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
			SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
			ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_CUSTOM_SYMBOL,ifnull(SM_EXCH_INSTRUMENT_TYPE,'N'),\
			SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP,SM_EXPIRY_FLAG\
			FROM SECURITY_MASTER WHERE SM_STATUS = 'A' AND SM_SEGMENT = \'E\';");

	logDebug1("sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
	{	
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddEQSecHash]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}		

	Res = mysql_store_result(DBConSec);

	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%d:",iNumRow);
	if(iNumRow == 0)
	{
		logFatal("Num Of Row Fetched :%d:",iNumRow);
		return FALSE;

	}

	struct SEC_MASTER_ARRAY	*EqSecHsh[iNumRow],*TempSec;

	while(Row = mysql_fetch_row(Res))
	{
		EqSecHsh[i] = (struct SEC_MASTER_ARRAY	*)malloc(sizeof(struct SEC_MASTER_ARRAY));
		TempSec     = (struct SEC_MASTER_ARRAY	*)malloc(sizeof(struct SEC_MASTER_ARRAY));	

		strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);	
		//	logDebug1("sTempSecID :%s:",sTempSecID);
		HASH_FIND(hSecHndlr,Hash_ByID, &sTempSecID,strlen(sTempSecID),TempSec);		

		if(TempSec == NULL)
		{

			strncpy(EqSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(EqSecHsh[i]->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(EqSecHsh[i]->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
			strncpy(EqSecHsh[i]->sISINCode,Row[4],DB_ISIN_CODE_LEN);
			strncpy(EqSecHsh[i]->sSym,Row[5],DB_SYM_LEN);
			strncpy(EqSecHsh[i]->sSymName,Row[6],DB_SYM_NAME_LEN);
			strncpy(EqSecHsh[i]->sInsName,Row[7],DB_INS_LEN);
			strncpy(EqSecHsh[i]->sSeries,Row[8],DB_SERIES_LEN);
			EqSecHsh[i]->cPreOpenFlag= Row[11][0];
			EqSecHsh[i]->cPreOpenExchFlag= Row[12][0];
			EqSecHsh[i]->cITSFlag= Row[13][0];
			EqSecHsh[i]->cAlgoFlag= Row[14][0];
			EqSecHsh[i]->cCAFlag= Row[15][0];
			EqSecHsh[i]->iFaceValue= atoi(Row[16]);
			EqSecHsh[i]->fTickSize= atof(Row[17]);
			EqSecHsh[i]->fLotSize= atof(Row[18]);
			//strncpy(EqSecHsh[i]->SecMaster.sLotUnits,Row[19],DB_LOT_UNITS_LEN);
			EqSecHsh[i]->fUpperLimit= atof(Row[20]);
			EqSecHsh[i]->fLowerLimit= atof(Row[21]);
			strncpy(EqSecHsh[i]->sCustomSym,Row[22],CUSTOM_SYM_LEN);
			strncpy(EqSecHsh[i]->sInstrumentTyp,Row[23],INSTRUMENT_TYPE);
			
			//INTEROPS CHANGES
			strncpy(EqSecHsh[i]->sIntropScripCode,Row[24],DB_SECURITY_ID_LEN)  ;
                        strncpy(EqSecHsh[i]->sIntropSymbol,Row[25],DB_SYM_LEN)             ;
                        strncpy(EqSecHsh[i]->sNseScripCode,Row[26],DB_SECURITY_ID_LEN)     ;
                        strncpy(EqSecHsh[i]->sBseScripCode,Row[27],DB_SECURITY_ID_LEN)     ;
			strncpy(EqSecHsh[i]->sSmExpiryFlag,Row[28],DB_EXPIRY_FLAG_LEN);

			HASH_ADD(hSecHndlr,Hash_ByID,sScripCode,strlen(EqSecHsh[i]->sScripCode),EqSecHsh[i]);
			//logDebug1("EqSecHsh[%d]->sScripCode = %s %s",i,EqSecHsh[i]->sScripCode,EqSecHsh[i]->sSym);
			i++;	

		}	



	}
	logTimestamp("Exit : [fAddEQSecHash]");

	mysql_close(DBConSec);
	return TRUE;


}
BOOL fGetDrvSecDetails(struct INT_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetDrvSecDetails]");

	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          i = 0 ;
	key_t           ShmType;
	LONG32          ShmSize;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL		*DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


	memset(sTempSecID,'\0',DB_SCRIP_CODE_LEN);

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);

	HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

	if(pSec != NULL)
	{
		strncpy(pRes->sSymbol,pSec->sSym,DB_SYM_LEN);
		strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
		//strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
		strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INSTRU_LEN);
		strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
		pRes->iExpiryDate  = pSec->iExpiryDate; 
		strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN);
		strncpy(pRes->sISINCode,pSec->sISINCode,DB_ISIN_CODE_LEN)       ;
                strncpy(pRes->sInstrumentTyp,pSec->sInstrumentTyp,INSTRUMENT_TYPE)      ;
                strncpy(pRes->ReqHeader.sExcgId,pSec->sExch,DB_EXCH_ID_LEN)     ;
		pRes->fTickSize = pSec->fTickSize ;
		pRes->fStrikePrice = pSec->fStrikePrice;
		pRes->fLotSize = pSec->fLotSize;
		pRes->cCrossCurFlag= pSec->cITSFlag; 
		logDebug2("pRes->cCrossCurFlag = %c",pRes->cCrossCurFlag);
		strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
		// This was added bcoz of cross currnecy handling drvOrd using segment check
		if(pRes->ReqHeader.cSegment == DERIVATIVE_SEGMENT)
                {
                        pRes->fRBIRefRate = 1.00;
                }
                else
                {
                        pRes->fTrdPrice = 0.00;
                        pRes->fRBIRefRate = pSec->fMcxLot;
                }
                strncpy(pRes->sUndScripCode,pSec->sUndScripCode,DB_SCRIP_CODE_LEN);
                pRes->iFreezeQty = pSec->iFaceValue;
                pRes->iAuctionNum = pSec->fMcxMutliplier ;
		//INTEROPS CHANGES
                strncpy(pRes->sIntropScripCode,pSec->sIntropScripCode,DB_SECURITY_ID_LEN);
                strncpy(pRes->sIntropSymbol,pSec->sIntropSymbol,DB_SYM_LEN)             ;
                strncpy(pRes->sNseScripCode,pSec->sNseScripCode,DB_SECURITY_ID_LEN)     ;
                strncpy(pRes->sBseScripCode,pSec->sBseScripCode,DB_SECURITY_ID_LEN)     ;
		strncpy(pRes->sSmExpiryFlag,pSec->sSmExpiryFlag,DB_EXPIRY_FLAG_LEN)     ;   		


		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
		logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
		logDebug2("pRes->sMaturityMonYr	     :%s:",pRes->sMaturityMonYr);
		logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
		logDebug2("pRes->cPreOpenFlag	:%c: ",pRes->cPreOpenFlag);
		logDebug2("pRes->fTrdPrice :%f: ",pRes->fTrdPrice);
		logDebug2("pRes->fLotSize :%f: ",pRes->fLotSize);
		logDebug2("pRes->iFreezeQty :%f: ",pRes->iFreezeQty);
		logDebug2("pRes->iFaceValue :%f: ",pSec->iFaceValue);
		logDebug2("pRes->sOptType :%s: ",pRes->sOptType);
		logDebug2("pRes->sCustomSym:%s: ",pRes->sCustomSym);
		logDebug2("pRes->fTickSize      :%f:",pRes->fTickSize)                  ;
                logDebug2("pRes->sInstrumentTyp:%s:",pRes->sInstrumentTyp)                      ;
                logDebug2("pRes->ReqHeader.sExcgId:%s:",pRes->ReqHeader.sExcgId)                        ;
			
		//INTEROPS CHANGES
                logDebug2("pRes->sIntropScripCode:%s:",pRes->sIntropScripCode)                 ;
                logDebug2("pRes->sIntropSymbol   :%s:",pRes->sIntropSymbol)                 ;
                logDebug2("pRes->sNseScripCode   :%s:",pRes->sNseScripCode)                 ;
                logDebug2("pRes->sBseScripCode   :%s:",pRes->sBseScripCode)                 ;
		logDebug2("pRes->sSmExpiryFlag   :%s:",pRes->sSmExpiryFlag)                 ;


	}
	else
	{
		DBConSec = DB_Connect();

		logDebug2("sTempSecID :%s:",sTempSecID);
		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
				IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
				IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE),\
				SM_CUSTOM_SYMBOL,ifnull(SM_EXCH_INSTRUMENT_TYPE,'NA'),SM_FREEZE_QTY,IFNULL(SM_CURRENCY_MULTIPLIER,'1') ,\
				SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP,SM_EXPIRY_FLAG\
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);
		logDebug1("This is not one 1");

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetDrvSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}
		logDebug1("This is not one 1");

		Res = mysql_store_result(DBConSec);
		logDebug1("This is not one 1");

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
			strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
			pHashAdd->cStatus = Row[9][0];
			pHashAdd->cExchStatus= Row[10][0];
			pHashAdd->cPreOpenFlag= Row[11][0];
			pHashAdd->cPreOpenExchFlag= Row[12][0];
			pHashAdd->cITSFlag= Row[13][0];
			pHashAdd->cAlgoFlag= Row[14][0];
			pHashAdd->cCAFlag= Row[15][0];
			pHashAdd->fTickSize= atof(Row[17]);
			pHashAdd->fLotSize= atof(Row[18]);
			pHashAdd->fStrikePrice = atof(Row[22]);
			pHashAdd->iExpiryDate=atoi(Row[27]);
			strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pHashAdd->sUndScripCode,Row[24],DB_SCRIP_CODE_LEN);
                        strncpy(pRes->sUndScripCode,pHashAdd->sUndScripCode,DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
		//	strncpy(pHashAdd->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
			//strncpy(pHashAdd->sMaturityMonYr,Row[26],MAT_MONYR);
			strncpy(pRes->sSymbol,Row[5],DB_SYM_LEN);
			strncpy(pRes->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pRes->sInstrumentType,Row[7],DB_INSTRU_LEN);
			strncpy(pRes->sMaturityDay,Row[25],MAT_DAY);
			strncpy(pRes->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
			logDebug2("*** pRes->sMaturityMonYr   ***   %s",pRes->sMaturityMonYr);
                        strcpy(pHashAdd->sMaturityMonYr,pRes->sMaturityMonYr);
                        logDebug2("After String Copy pHashAdd->sMaturityMonYr   %s",pHashAdd->sMaturityMonYr);
			pRes->fStrikePrice = atof(Row[22]);
			pRes->iExpiryDate = atoi(Row[27]);
		//	strncpy(pHashAdd->sMaturityMonYr,Row[27],DB_DATETIME_LEN);
			strncpy(pRes->sCustomSym,Row[28],CUSTOM_SYM_LEN);
			strncpy(pHashAdd->sCustomSym,Row[28],CUSTOM_SYM_LEN);
			strncpy(pRes->sISINCode,Row[4],DB_ISIN_CODE_LEN)        ;
                        strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN)                ;
                        pRes->fLotSize =  atof(Row[18]);
                        pRes->fTickSize = atof(Row[17]) ;
		  	pHashAdd->iFaceValue= atoi(Row[30]);
			pRes->iFreezeQty = pHashAdd->iFaceValue;
                        pHashAdd->fMcxMutliplier = atof(Row[31]);
                        pRes->iAuctionNum = pHashAdd->fMcxMutliplier ;
			//INTEROPS CHANGES
                        strncpy(pHashAdd->sIntropScripCode,Row[32],DB_SECURITY_ID_LEN)  ;
                        strncpy(pHashAdd->sIntropSymbol,Row[33],DB_SYM_LEN)             ;
                        strncpy(pHashAdd->sNseScripCode,Row[34],DB_SECURITY_ID_LEN)     ;
                        strncpy(pHashAdd->sBseScripCode,Row[35],DB_SECURITY_ID_LEN)     ;
			
			//Mandar added for Mapping in Memory
			strncpy(pRes->sIntropScripCode,Row[32],DB_SECURITY_ID_LEN)  ;
                        strncpy(pRes->sIntropSymbol,Row[33],DB_SYM_LEN)             ;
                        strncpy(pRes->sNseScripCode,Row[34],DB_SECURITY_ID_LEN)     ;
                        strncpy(pRes->sBseScripCode,Row[35],DB_SECURITY_ID_LEN)     ;
			
			strncpy(pHashAdd->sSmExpiryFlag,Row[36],DB_EXPIRY_FLAG_LEN)  ;
			strncpy(pRes->sSmExpiryFlag,Row[36],DB_EXPIRY_FLAG_LEN);
			
			logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
			logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
			logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
			logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
			logDebug2("pRes->sMaturityMonYr 	:%s:",pRes->sMaturityMonYr);
			logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
			logDebug2(" pRes->:sOptType   %s:", Row[23]);
			logDebug2(" pRes->sCustomSym %s:",pRes->sCustomSym); 
			//INTEROPS CHANGES
                        logDebug2("pRes->sIntropScripCode:%s:",pRes->sIntropScripCode)               ;
                        logDebug2("pRes->sIntropSymbol   :%s:",pRes->sIntropSymbol)                 ;
                        logDebug2("pRes->sNseScripCode   :%s:",pRes->sNseScripCode)                 ;
                        logDebug2("pRes->sBseScripCode   :%s:",pRes->sBseScripCode)                 ;

			logDebug2("pRes->sSmSxpiryFlag   :%s:",pRes->sSmExpiryFlag);	
			HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
			mysql_close(DBConSec);

		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}	
	}

	return TRUE;


}

BOOL fGetDrvCBSecDetails (struct INT_COBO_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetDrvCBSecDetails]");

	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          i = 0 ;
	key_t           ShmType;
	LONG32          ShmSize;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL           *DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);


	HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

	if(pSec != NULL)
	{
		strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN);
		strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
		strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
		strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
		pRes->iExpiryDate  = pSec->iExpiryDate;
		strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
		strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
		pRes->fStrikePrice = pSec->fStrikePrice;
		pRes->fLotSize = pSec->fLotSize ;
		pRes->fTickSize = pSec->fTickSize ;
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN)	;
		strncpy(pRes->sISINCode,pSec->sISINCode,DB_ISIN_CODE_LEN)       ;
                strncpy(pRes->sInstrumentTyp,pSec->sInstrumentTyp,INSTRUMENT_TYPE)      ;
                strncpy(pRes->ReqHeader.sExcgId,pSec->sExch,DB_EXCH_ID_LEN)     ;
		strncpy(pRes->sUndScripCode,pSec->sUndScripCode,DB_SCRIP_CODE_LEN);
                pRes->iFreezeQty = pSec->iFaceValue;
                pRes->iAuctionNum = pSec->fMcxMutliplier;
		//INTEROPS CHANGES
                strncpy(pRes->sIntropScripCode,pSec->sIntropScripCode,DB_SECURITY_ID_LEN);
                strncpy(pRes->sIntropSymbol,pSec->sIntropSymbol,DB_SYM_LEN)             ;
                strncpy(pRes->sNseScripCode,pSec->sNseScripCode,DB_SECURITY_ID_LEN)     ;
                strncpy(pRes->sBseScripCode,pSec->sBseScripCode,DB_SECURITY_ID_LEN)     ;
		strncpy(pRes->sSmExpiryFlag,pSec->sSmExpiryFlag,DB_EXPIRY_FLAG_LEN)     ;

		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
		logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
		logDebug2("pRes->sMaturityMonYr      :%s:",pRes->sMaturityMonYr);
		logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
		logDebug2("pRes->fLotSize : %f ",pRes->fLotSize);
		logDebug2("pRes->fTickSize: %f ",pRes->fTickSize);
		logDebug2("pRes->sCustomSym: %s ",pRes->sCustomSym);
		logDebug2("pRes->sISINCode      :%s:",pRes->sISINCode)                  ;
                logDebug2("pRes->sInstrumentTyp:%s:",pRes->sInstrumentTyp)                      ;
                logDebug2("pRes->ReqHeader.sExcgId:%s:",pRes->ReqHeader.sExcgId)                        ;
		logDebug2("pRes->sUndScripCode :%s:",pRes->sUndScripCode);
                logDebug2("pRes->iFreezeQty :%d:",pRes->iFreezeQty);
                logDebug2("pRes->iAuctionNum :%d:",pRes->iAuctionNum);

		//INTEROPS CHANGES
                logDebug2("pRes->sIntropScripCode:%s:",pRes->sIntropScripCode)               ;
                logDebug2("pRes->sIntropSymbol   :%s:",pRes->sIntropSymbol)                 ;
                logDebug2("pRes->sNseScripCode   :%s:",pRes->sNseScripCode)                 ;
                logDebug2("pRes->sBseScripCode   :%s:",pRes->sBseScripCode)                 ;

		logDebug2("pRes->sSmExpiryFlag   :%s:",pRes->sSmExpiryFlag)                 ;

	}
	else
	{
		DBConSec = DB_Connect();
		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
				IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
				IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE) ,\
				SM_CUSTOM_SYMBOL,SM_FREEZE_QTY,IFNULL(SM_CURRENCY_MULTIPLIER,'1'),\
				SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP,SM_EXPIRY_FLAG\
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment, \
				sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);
		logDebug1("This is not one 1");

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetDrvCBSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}
		logDebug1("This is not one 1");

		Res = mysql_store_result(DBConSec);
		logDebug1("This is not one 1");

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
			strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
			pHashAdd->cStatus = Row[9][0];
			pHashAdd->cExchStatus= Row[10][0];
			pHashAdd->cPreOpenFlag= Row[11][0];
			pHashAdd->cPreOpenExchFlag= Row[12][0];
			pHashAdd->cITSFlag= Row[13][0];
			pHashAdd->cAlgoFlag= Row[14][0];
			pHashAdd->cCAFlag= Row[15][0];
			pHashAdd->fTickSize= atof(Row[17]);
			pHashAdd->fLotSize= atof(Row[18]);
			pRes->fLotSize= atof(Row[18]);
			pHashAdd->fStrikePrice = atof(Row[22]);
			strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
			strncpy(pHashAdd->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
			//strncpy(EqSecHsh[i]->SecMaster.sLotUnits,Row[19],DB_LOT_UNITS_LEN);
			strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
			strncpy(pRes->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
			strncpy(pRes->sMaturityDay,Row[25],MAT_DAY);
			strncpy(pRes->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
			pRes->fStrikePrice = atof(Row[22]);
			pRes->iExpiryDate = atoi(Row[27]);
			strncpy(pRes->sCustomSym,Row[28],CUSTOM_SYM_LEN);
			strncpy(pHashAdd->sCustomSym,Row[28],CUSTOM_SYM_LEN);
			pHashAdd->fTickSize= atof(Row[29]);
			pRes->iFreezeQty = pHashAdd->iFaceValue;
                        pHashAdd->fMcxMutliplier = atof(Row[30]);
                        pRes->iAuctionNum = pHashAdd->fMcxMutliplier;
			//INTEROPS CHANGES
			strncpy(pHashAdd->sIntropScripCode,Row[31],DB_SECURITY_ID_LEN)  ;
                        strncpy(pHashAdd->sIntropSymbol,Row[32],DB_SYM_LEN)             ;
                        strncpy(pHashAdd->sNseScripCode,Row[33],DB_SECURITY_ID_LEN)     ;
                        strncpy(pHashAdd->sBseScripCode,Row[34],DB_SECURITY_ID_LEN)     ;
	
			//Mandar addedfor mapping in memory
			strncpy(pRes->sIntropScripCode,Row[31],DB_SECURITY_ID_LEN);
                        strncpy(pRes->sIntropSymbol,Row[32],DB_SYM_LEN)             ;
                        strncpy(pRes->sNseScripCode,Row[33],DB_SECURITY_ID_LEN)     ;
                        strncpy(pRes->sBseScripCode,Row[34],DB_SECURITY_ID_LEN)     ;	
		
			strncpy(pHashAdd->sSmExpiryFlag,Row[36],DB_EXPIRY_FLAG_LEN)  ;
                        strncpy(pRes->sSmExpiryFlag,Row[36],DB_EXPIRY_FLAG_LEN);
		

			logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
			logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
			logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
			logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
			logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
			logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
			
			//INTEROPS CHANGES
			logDebug2("pRes->sIntropScripCode:%s:",pRes->sIntropScripCode)               ;
                        logDebug2("pRes->sIntropSymbol   :%s:",pRes->sIntropSymbol)                 ;
                        logDebug2("pRes->sNseScripCode   :%s:",pRes->sNseScripCode)                 ;
                        logDebug2("pRes->sBseScripCode   :%s:",pRes->sBseScripCode)                 ;
			
			logDebug2("pRes->sSmSxpiryFlag   :%s:",pRes->sSmExpiryFlag);	
			HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
			mysql_close(DBConSec);

		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}




	}

	return TRUE;
}	

BOOL fGetMCXCBSecDetails (struct INT_COBO_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetMCXCBSecDetails]");

        struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 ;
        key_t           ShmType;
        LONG32          ShmSize;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


        pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
        pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

        strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
        logDebug2("sTempSecID :%s:",sTempSecID);


        HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

        if(pSec != NULL)
        {
                strncpy(pRes->sSymbol,pSec->sSym,DB_SYM_LEN);
                strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
                strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INSTRU_LEN);
                strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
                pRes->iExpiryDate  = pSec->iExpiryDate;
                strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,MAT_MONYR);
                strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
                pRes->fStrikePrice = pSec->fStrikePrice;
		pRes->iAuctionNum  = pSec->fMcxMutliplier;
		strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
		strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);
		pRes->fStrikePrice = pSec->fStrikePrice;
		pRes->fLotSize = pSec->fLotSize ;
		pRes->fTickSize = pSec->fTickSize;
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN)	;
		strncpy(pRes->sSmExpiryFlag,pSec->sSmExpiryFlag,DB_EXPIRY_FLAG_LEN);

		strncpy(pRes->sUndScripCode,pSec->sUndScripCode,DB_SCRIP_CODE_LEN);
		logDebug2("pRes->sUndScripCode :%s:",pRes->sUndScripCode);
	
		logDebug2("pRes->sSymName :%s:",pRes->sSymbolName);
      		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                logDebug2("pRes->sSymbolSfx :%s:",pRes->sSymbolSfx);
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
		logDebug2("pRes->sSeries        :%s:",pRes->sSeries);
                logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                logDebug2("pRes->sMaturityMonYr      :%s:",pRes->sMaturityMonYr);
                logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
		logDebug2("pRes->iAuctionNum  :%d:",pRes->iAuctionNum);
		logDebug2("pRes->sOptType :%s:",pRes->sOptType);
		logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
		logDebug2("pRes->sCustomSym:%s:",pRes->sCustomSym);
		logDebug2("pRes->fLotSize:%f:",pRes->fLotSize);
		logDebug2("pRes->fTickSize :%f:",pRes->fTickSize);
		logDebug2("pRes->sSmExpiryFlag:%s:",pRes->sSmExpiryFlag);
        }
        else
        {
                DBConSec = DB_Connect();
                sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
                                SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                                SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
                                IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),ifNULL(SM_STRIKE_PRICE,-0.0100),SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
                                IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE),SM_MCX_MULTIPLIER,SM_EXPIRY_DATE,SM_CUSTOM_SYMBOL ,SM_EXPIRY_FLAG\
                                FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" AND SM_INSTRUMENT_NAME in(\"FUTCOM\",\"OPTFUT\",\"OPTCOM\",\"FUTIDX\");",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment, \
                                sTempSecID);

                logDebug1("sSelQry :%s:",sSelQry);

                if(mysql_query(DBConSec,sSelQry) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetDrvCBSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
			free(sSelQry);
                        return FALSE;
                }

                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
			//strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
			strncpy(pRes->sSymbol,Row[5],DB_SYM_LEN);
                        strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
			strncpy(pRes->sInstrumentType,Row[7],DB_INSTRU_LEN);
                        strncpy(pHashAdd->sSeries,Row[8],DB_SERIES_LEN);
			strncpy(pRes->sSeries,Row[8],DB_SERIES_LEN);
                        pHashAdd->cStatus = Row[9][0];
                        pHashAdd->cExchStatus= Row[10][0];
                        pHashAdd->cPreOpenFlag= Row[11][0];
                        pHashAdd->cPreOpenExchFlag= Row[12][0];
                        pHashAdd->cITSFlag= Row[13][0];
                        pHashAdd->cAlgoFlag= Row[14][0];
                        pHashAdd->cCAFlag= Row[15][0];
                        pHashAdd->iFaceValue =atoi(Row[16]);
                        pHashAdd->fTickSize= atof(Row[17]);
                        pRes->fTickSize = atof(Row[17]);
                        pHashAdd->fLotSize= atof(Row[18]);
                        pRes->fLotSize= atof(Row[18]);
                        strncpy(pHashAdd->sLotUnits,Row[19],DB_LOT_UNITS_LEN);
                        pHashAdd->fUpperLimit =atof(Row[20]);
                        pHashAdd->fLowerLimit = atof(Row[21]);
                        pHashAdd->fStrikePrice = atof(Row[22]);
                        strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pRes->sOptType,pHashAdd->sOptType,DB_OPT_TYPE_LEN);


			strncpy(pHashAdd->sUndScripCode,Row[24],DB_SCRIP_CODE_LEN);
			strncpy(pRes->sUndScripCode,pHashAdd->sUndScripCode,DB_SCRIP_CODE_LEN);
			logDebug2("pRes->UndScripCode :%s:",pHashAdd->sUndScripCode);

                        //strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
                        strncpy(pHashAdd->sMaturityMonYr,Row[26],MAT_MONYR);
			pHashAdd->iExpiryDate = atoi(Row[27]);
                        pHashAdd->fMcxMutliplier = atof(Row[28]);
			//strncpy(pRes->sSeries,Row[29],DB_SERIES_LEN);
			pRes->iAuctionNum = atof(Row[28]);
                        pRes->iAuctionNum = pHashAdd->fMcxMutliplier;
			strncpy(pRes->sMaturityMonYr,pHashAdd->sMaturityMonYr,DB_DATETIME_LEN);
			strncpy(pHashAdd->sExpiryDate,Row[29],DB_DATETIME_LEN);
                        strncpy(pRes->sEntryDate,pHashAdd->sExpiryDate,DB_DATETIME_LEN);
			strncpy(pHashAdd->sCustomSym,Row[30],CUSTOM_SYM_LEN);
			strncpy(pRes->sCustomSym,pHashAdd->sCustomSym,CUSTOM_SYM_LEN);
	                strncpy(pHashAdd->sSmExpiryFlag,Row[31],DB_EXPIRY_FLAG_LEN);
                        strncpy(pRes->sSmExpiryFlag,Row[31],DB_EXPIRY_FLAG_LEN);



                        logDebug2("pRes->sSymbol :%s:",pHashAdd->sSym);
                        logDebug2("pRes->sInstrumentType        :%s:",pHashAdd->sInsName);
			logDebug2("pRes->sInstrumentType :%s:",pRes->sInstrumentType);
                        logDebug2("pRes->sMaturityDay        :%s:",pHashAdd->sMaturityDay);
                        logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
                        logDebug2("pRes->sMaturityMonYr         :%s:",pHashAdd->sMaturityMonYr);
			logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
                        logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
			logDebug2(" pRes->iExpiryDate   :%d:",pRes->iExpiryDate);
			logDebug2("atof(Row[28]) :%f:",atof(Row[28]));
			logDebug2("atof(Row[28]) :%f:",atof(Row[28]));	
                        logDebug2("pRes->iAuctionNum :%f:",pHashAdd->fMcxMutliplier);
			logDebug2("pRes->sSeries         :%s:",pHashAdd->sSeries);
			logDebug2("pRes->sOptType :%s:",pRes->sOptType);			
			logDebug2("pHashAdd->sExpiryDate :%s:",pHashAdd->sExpiryDate);
                        logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
			logDebug2("pRes->sCustomSym :%s:",pRes->sCustomSym);
			logDebug2("pRes->fLotSize :%f:",pRes->fLotSize);
			logDebug2("pRes->fTickSize :%f:",pRes->fTickSize);

                        HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
                        mysql_close(DBConSec);

                }
                else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
                        mysql_close(DBConSec);
			free(sSelQry);
                        return FALSE;
                }
		}
			free(sSelQry);
			logTimestamp("EXIT [fGetMCXCBSecDetails]");
		        return TRUE;
}



		




BOOL    fAddDrvSecHash()
{
	logTimestamp("Entry : [fAddDrvSecHash]");
	MYSQL		*DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32           iNumRow,i=0;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];

	DBConSec = DB_Connect();

	sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_EXCH_SYMBOL,\
			SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
			SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,0),ifnull(SM_TICK_SIZE,0),ifnull(SM_LOT_SIZE,1),\
			ifnull(SM_LOT_UNITS,1),IFNULL(SM_UPPER_LIMIT,0),IFNULL(SM_LOWER_LIMIT,0),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
			IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\'),NULL),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),ifnull(SM_SYMBOL,'xyz'), \
			JULIDATE(SM_EXPIRY_DATE),SM_CROSS_CUR_FLAG,SM_RBI_REFERENCE_RATE,IFNULL(SM_CUSTOM_SYMBOL,'NA'),ifnull(SM_EXCH_INSTRUMENT_TYPE,'N'),\
			SM_FREEZE_QTY,IFNULL(SM_CURRENCY_MULTIPLIER,1),SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP ,SM_EXPIRY_FLAG FROM SECURITY_MASTER WHERE SM_STATUS = 'A'\
			AND  (SM_SEGMENT = \"%c\" OR SM_SEGMENT = \'%c\') AND SM_EXCHANGE = \"%s\" ;",CURRENCY_SEGMENT,DERIVATIVE_SEGMENT,NSE_EXCH);

	logDebug1("sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
	{
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddDrvSecHash]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}

	Res = mysql_store_result(DBConSec);

	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	if(iNumRow == 0)
	{
		logFatal("Num Of Row Fetched :%d:",iNumRow);
		return FALSE;

	}

	struct SEC_MASTER_ARRAY *DrvSecHsh[iNumRow],*TempSec;

	while(Row = mysql_fetch_row(Res))
	{
		DrvSecHsh[i] = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
		TempSec     = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

		strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);
		//logDebug1("sTempSecID :%s:",sTempSecID);

		HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),TempSec);

		if(TempSec == NULL)
		{
			strncpy(DrvSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(DrvSecHsh[i]->sScripCode,Row[1],DB_SCRIP_CODE_LEN);
			strncpy(DrvSecHsh[i]->sExchScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(DrvSecHsh[i]->sSym,Row[3],DB_SYM_LEN);
			strncpy(DrvSecHsh[i]->sInsName,Row[4],DB_INS_LEN);
			DrvSecHsh[i]->cStatus = Row[5][0];
			DrvSecHsh[i]->cExchStatus= Row[6][0];
			DrvSecHsh[i]->cPreOpenFlag= Row[7][0];
			DrvSecHsh[i]->cPreOpenExchFlag= Row[8][0];
			DrvSecHsh[i]->cAlgoFlag= Row[10][0];
			DrvSecHsh[i]->cCAFlag= Row[11][0];
			strncpy(DrvSecHsh[i]->sLotUnits,Row[14],DB_LOT_UNITS_LEN);
			DrvSecHsh[i]->fUpperLimit= atof(Row[15]);
			DrvSecHsh[i]->fLowerLimit= atof(Row[16]);
			DrvSecHsh[i]->fStrikePrice = atof(Row[17]);
			strncpy(DrvSecHsh[i]->sOptType,Row[18],DB_SERIES_LEN);
			strncpy(DrvSecHsh[i]->sUndScripCode,Row[19],DB_SCRIP_CODE_LEN);
			strncpy(DrvSecHsh[i]->sMaturityDay,Row[20],MAT_DAY);
			strncpy(DrvSecHsh[i]->sMaturityMonYr,Row[21],DB_DATETIME_LEN);
			strncpy(DrvSecHsh[i]->sSymName,Row[22],DB_SYM_NAME_LEN);
			DrvSecHsh[i]->fTickSize= atof(Row[12]);
			DrvSecHsh[i]->fLotSize= atof(Row[13]);
			DrvSecHsh[i]->iExpiryDate = atol(Row[23]);
			DrvSecHsh[i]->cITSFlag= Row[24][0];
			DrvSecHsh[i]->fMcxLot = atof(Row[25]);
			strncpy(DrvSecHsh[i]->sCustomSym,Row[26],CUSTOM_SYM_LEN);
			DrvSecHsh[i]->iFaceValue= atof(Row[28]);
                        DrvSecHsh[i]->fMcxMutliplier = atof(Row[29]);
			//INTEROPS CHANGES
                        strncpy(DrvSecHsh[i]->sIntropScripCode,Row[30],DB_SECURITY_ID_LEN)  ;
                        strncpy(DrvSecHsh[i]->sIntropSymbol,Row[31],DB_SYM_LEN)             ;
                        strncpy(DrvSecHsh[i]->sNseScripCode,Row[32],DB_SECURITY_ID_LEN)     ;
                        strncpy(DrvSecHsh[i]->sBseScripCode,Row[33],DB_SECURITY_ID_LEN)     ;
		
			strncpy(DrvSecHsh[i]->sSmExpiryFlag,Row[34],DB_EXPIRY_FLAG_LEN);

			//			logDebug2("DrvSecHsh[i]->sMaturityMonYr:%s: Row[21] :%s:",DrvSecHsh[i]->sMaturityMonYr,Row[21]);

			//			logDebug2("sScripCode :%s: iExpiryDate :%s:",DrvSecHsh[i]->sScripCode,Row[23]);

			//			logDebug2(" CC Flag  :%s: :%c: :%d:",Row[1],Row[24][0],atoi(Row[25]));	
			//			logDebug2(" CC Flag 2:%s: :%c: :%d: | :%s: :%c: :%d:",DrvSecHsh[i]->sScripCode,DrvSecHsh[i]->cITSFlag,DrvSecHsh[i]->iFaceValue,Row[1],Row[24][0],atoi(Row[25]));	
			HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(DrvSecHsh[i]->sScripCode),DrvSecHsh[i]);
			//logDebug1("DrvSecHsh[%d]->sScripCode = %s %s",i,DrvSecHsh[i]->sScripCode,DrvSecHsh[i]->sSym);
			i++;

		}



	}
	logTimestamp("Exit : [fAddDrvSecHash]");

	mysql_close(DBConSec);
	return TRUE;
}


BOOL fGetMcxSecDetails(struct INT_ORDERS *pRes)
{
	logTimestamp("Entry : [GetMcxSecDetails]");
	MYSQL   *DBConSec;
	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          iCnt            =       0       ;
	key_t           ShmType;
	LONG32          ShmSize;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);
	HASH_FIND(hMcxSecHndlr,Hash_McxID, &sTempSecID,strlen(sTempSecID),pSec);
	/**	logDebug2("pSec->sSymolSfx :%s:",pSec->sSymName);
	  strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
	  logDebug2("pRes->sSymolSfx :%s:",pRes->sSymbolName);  **/

	if(pSec != NULL)
	{

		strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN);
		
		strncpy(pRes->sSymbolSfx,pSec->sSymName,DB_SYM_NAME_LEN);
		strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
		strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
		pRes->iExpiryDate  = pSec->iExpiryDate; 
		strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
		strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
		pRes->fStrikePrice = pSec->fStrikePrice;
		strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
		pRes->iAuctionNum  = pSec->fMcxMutliplier;
		strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
		strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);
		
		logDebug2("pRes->sCustomSym:%s:",pSec->sCustomSym);
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN);	
		logDebug2("pRes->sCustomSym:%s:",pRes->sCustomSym);

		pRes->fLotSize = pSec->fLotSize;
		logDebug2("pRes->fLotSize: %f:",pRes->fLotSize);
		pRes->fTickSize = pSec->fTickSize;
		strncpy(pRes->sSmExpiryFlag,pSec->sSmExpiryFlag,DB_EXPIRY_FLAG_LEN);
	
		strncpy(pRes->sUndScripCode,pSec->sUndScripCode,DB_SCRIP_CODE_LEN);
		logDebug2("pRes->sUndScripCode :%s:",pRes->sUndScripCode);	
	
		logDebug2("pRes->sSymName :%s:",pRes->sSymbolName);
		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
		logDebug2("pRes->sSymbolSfx :%s:",pRes->sSymbolSfx);
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
		logDebug2("pRes->sSeries        :%s:",pRes->sSeries);
		logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
		logDebug2("pRes->sMaturityMonYr	     :%s:",pRes->sMaturityMonYr);
		logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
		logDebug2("pRes->iAuctionNum :%d:",pRes->iAuctionNum);
		logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
		logDebug2("pRes->sCustomSym:%s:",pRes->sCustomSym);
		logDebug2("pRes->fLotSize:%f:",pRes->fLotSize);
		logDebug2("pRes->fTickSize:%f:",pRes->fTickSize);
		logDebug2("pRes->sSmExpiryFlag:%s:",pRes->sSmExpiryFlag);		
		
		/**strncpy(pRes->sSymbol,pSec->sSym,DB_SYM_LEN);
		  strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
		  strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
		  strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
		  strncpy(pRes->sSymbolSfx,pSec->sSeries,DB_SERIES_LEN);
		  logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
		  logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
		  logDebug2("pRes->sSeries        :%s:",pRes->sSeries);
		  logDebug2("pRes->sSymbolSfx     :%s:",pRes->sSymbolSfx);
		  logDebug2("pRes->sSymbolName :%s:",pRes->sSymbolName);**/

	}
	else
	{
		DBConSec = DB_Connect();
		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL,SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
				IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),ifNULL(SM_STRIKE_PRICE,-0.0100),SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
				IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE),IFNULL(SM_SERIES,'0'),SM_EXPIRY_DATE,SM_MCX_MULTIPLIER,SM_CUSTOM_SYMBOL,SM_EXPIRY_FLAG\
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'M\' AND SM_SCRIP_CODE =\"%s\" AND SM_INSTRUMENT_NAME in(\"FUTCOM\",\"OPTFUT\",\"OPTCOM\",\"FUTIDX\");",pRes->ReqHeader.sExcgId,sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);
		logDebug1("This is not one 1");

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [GetMcxSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}
		logDebug1("This is not one 1");

		Res = mysql_store_result(DBConSec);
		logDebug1("This is not one 1");

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
			strncpy(pRes->sSymbol,pHashAdd->sSym,SYMBOL_LEN);
			strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pRes->sSymbolSfx,pHashAdd->sSymName,DB_SYM_NAME_LEN);
			strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
			pHashAdd->cStatus = Row[8][0];
			pHashAdd->cExchStatus= Row[9][0];
			pHashAdd->cPreOpenFlag= Row[10][0];
			pHashAdd->cPreOpenExchFlag= Row[11][0];
			pHashAdd->cITSFlag= Row[12][0];
			pHashAdd->cAlgoFlag= Row[13][0];
			pHashAdd->cCAFlag= Row[14][0];
			//  pHashAdd->iFaceValue= atoi(Row[16]);
			pHashAdd->fTickSize= atof(Row[16]);
			pHashAdd->fLotSize= atof(Row[17]);
			
			pHashAdd->fStrikePrice = atof(Row[21]);
			strncpy(pHashAdd->sOptType,Row[22],DB_OPT_TYPE_LEN);
			
			strncpy(pHashAdd->sUndScripCode,Row[23],DB_SCRIP_CODE_LEN);
			strncpy(pRes->sUndScripCode,Row[23],DB_SCRIP_CODE_LEN);			
			logDebug2("pRes->sUndScripCode :%s:",pRes->sUndScripCode);
	
			//strncpy(pHashAdd->sISINCode,Row[23],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sMaturityDay,Row[24],MAT_DAY);
			strncpy(pHashAdd->sMaturityMonYr,Row[26],MAT_MONYR);
			//strncpy(EqSecHsh[i]->SecMaster.sLotUnits,Row[19],DB_LOT_UNITS_LEN);
			strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
			strncpy(pRes->sOptType,Row[22],DB_OPT_TYPE_LEN);
			strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
			strncpy(pRes->sMaturityDay,Row[24],MAT_DAY);
			strncpy(pRes->sMaturityMonYr,Row[25],DB_DATETIME_LEN);
			pRes->fStrikePrice = atof(Row[21]);
			strncpy(pRes->sSeries,Row[27],DB_SERIES_LEN);
			strncpy(pHashAdd->sSeries,Row[27],DB_SERIES_LEN);
			strncpy(pHashAdd->sExpiryDate,Row[28],DB_DATETIME_LEN);
                        strncpy(pRes->sEntryDate,pHashAdd->sExpiryDate,DB_DATETIME_LEN);
			pHashAdd->fMcxMutliplier = atof(Row[29]);
                        pRes->iAuctionNum = atof(Row[29]);
                        pRes->iAuctionNum = pHashAdd->fMcxMutliplier;
			strncpy(pRes->sCustomSym,Row[30],CUSTOM_SYM_LEN);
			strncpy(pHashAdd->sCustomSym,Row[30],CUSTOM_SYM_LEN);
			pRes->fTickSize = pHashAdd->fTickSize;
			pRes->fLotSize = pHashAdd->fLotSize;
		
			strncpy(pHashAdd->sSmExpiryFlag,Row[31],DB_EXPIRY_FLAG_LEN);
			strncpy(pRes->sSmExpiryFlag,Row[31],DB_EXPIRY_FLAG_LEN);
			logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
			logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
			logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
			logDebug2("sMaturityMonYr Row[26] :%s:",Row[25]);
			logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
			logDebug2("pRes->sSeries         :%s:",pRes->sSeries);
			logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
			logDebug2("pRes->iAuctionNum :%d:",pRes->iAuctionNum);
			logDebug2("pRes->sCustomSym:%s:",pRes->sCustomSym);
			logDebug2("pRes->fTickSize :%lf:",pRes->fTickSize);
			logDebug2("pRes->fLotSize :%lf:",pRes->fLotSize);

			HASH_ADD(hMcxSecHndlr,Hash_McxID, sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
			mysql_close(DBConSec);
		}
		else if(mysql_num_rows(Res) == 0)
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE ;
		}
		else
		{
			logDebug1("FALSE Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}	

	}
	logTimestamp("Exit : [GetMcxSecDetails]");

	return TRUE;
}

BOOL    fAddMCXSecHash()
{
	logDebug2("Entry [fAddMCXSecHash]");
	MYSQL           *DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32           iNumRow,i=0;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];

	DBConSec = DB_Connect();
	/*
	   sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_EXCH_SYMBOL,\
	   SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
	   SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,SM_CA_FLAG,ifnull(SM_TICK_SIZE,0),ifnull(SM_LOT_SIZE,1),\
	   ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
	   IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\'),NULL),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),ifnull(SM_SYMBOL,'xyz'),\
	   JULIDATE(SM_EXPIRY_DATE)FROM SECURITY_MASTER WHERE  SM_SEGMENT = \'M\'  ;");
	 */
	sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_EXCH_SYMBOL,\
			SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
			SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,SM_CA_FLAG,ifnull(SM_TICK_SIZE,0),ifnull(SM_LOT_SIZE,1),\
			ifnull(SM_LOT_UNITS,'1'),ifnull(SM_UPPER_LIMIT,'0'),ifnull(SM_LOWER_LIMIT,'0'),ifNULL(SM_STRIKE_PRICE,-0.0100),ifnull(nullif(SM_OPTION_TYPE,''),'XX'),\
			SM_UNDERLAYING_SCRIP_CODE,\
			IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,'%%d'),'NA'),IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,'%%Y%%m%%d'),'NA'),ifnull(SM_SYMBOL,'xyz'),\
			ifNULL(  JULIDATE(SM_EXPIRY_DATE),'NA'),SM_MCX_MULTIPLIER,ifnull(SM_SERIES,'0'),SM_EXPIRY_DATE,SM_CUSTOM_SYMBOL ,SM_EXPIRY_FLAG FROM SECURITY_MASTER WHERE  SM_STATUS = 'A' AND SM_SEGMENT = 'M'  AND SM_EXCHANGE = 'MCX' AND SM_INSTRUMENT_NAME like \"FUTCOM\" OR SM_INSTRUMENT_NAME like \"OPTFUT\" ;");

/*	SM_INSTRUMENT_NAME like \"FUTCOM\" */
	
	logDebug1("sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
	{
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddMCXSecHash]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}

	Res = mysql_store_result(DBConSec);

	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);

	if(iNumRow == 0)
	{
		logFatal("Num Of Row Fetched :%d:",iNumRow);
		return FALSE;

	}

	struct SEC_MASTER_ARRAY *ComSecHsh[iNumRow],*TempSec;

	while(Row = mysql_fetch_row(Res))
	{
		ComSecHsh[i] = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
		TempSec     = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

		strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);

		HASH_FIND(hMcxSecHndlr,Hash_McxID, &sTempSecID,strlen(sTempSecID),TempSec);

		if(TempSec == NULL)
		{
			logDebug3("------------------------------- Start Printing in AddMcxSec -----------------------------");

			strncpy(ComSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
			logDebug3("sExch = %s",ComSecHsh[i]->sExch);
			strncpy(ComSecHsh[i]->sScripCode,Row[1],DB_SCRIP_CODE_LEN);
			logDebug3("sScripCode = %s",ComSecHsh[i]->sScripCode);
			strncpy(ComSecHsh[i]->sExchScripCode,Row[2],DB_SCRIP_CODE_LEN);
			logDebug3("sExchScripCode = %s",ComSecHsh[i]->sExchScripCode);

			logDebug3("....%s",Row[3]);
			strncpy(ComSecHsh[i]->sSym,Row[3],DB_SYM_LEN);
			logDebug3("....%s",Row[4]);
			logDebug3("sSym = %s",ComSecHsh[i]->sSym);
			strncpy(ComSecHsh[i]->sInsName,Row[4],DB_INS_LEN);
			logDebug3("sInsName = %s",ComSecHsh[i]->sInsName);

			ComSecHsh[i]->cStatus = Row[5][0];
			logDebug3("cStatus = %c",ComSecHsh[i]->cStatus);
			ComSecHsh[i]->cExchStatus= Row[6][0];
			logDebug3("cExchStatus = %c",ComSecHsh[i]->cExchStatus);
			ComSecHsh[i]->cPreOpenFlag= Row[7][0];
			logDebug3("cPreOpenFlag = %c",ComSecHsh[i]->cPreOpenFlag);
			ComSecHsh[i]->cPreOpenExchFlag= Row[8][0];
			logDebug3("cPreOpenExchFlag = %c",ComSecHsh[i]->cPreOpenExchFlag);
			ComSecHsh[i]->cITSFlag= Row[9][0];
			logDebug3("cITSFlag = %c",ComSecHsh[i]->cITSFlag);
			ComSecHsh[i]->cAlgoFlag= Row[10][0];
			logDebug3("cAlgoFlag = %c",ComSecHsh[i]->cAlgoFlag);
			ComSecHsh[i]->cCAFlag= Row[11][0];
			logDebug3("cCAFlag = %c",ComSecHsh[i]->cCAFlag);
			ComSecHsh[i]->fTickSize= atof(Row[12]);
			logDebug3("fTickSize = %f",ComSecHsh[i]->fTickSize);
			//ComSecHsh[i]->fLotSize= atof(Row[13]);
			//logDebug3("fLotSize = %f",ComSecHsh[i]->fLotSize);

			strncpy(ComSecHsh[i]->sLotUnits,Row[14],DB_LOT_UNITS_LEN);
			logDebug3("sLotUnits = %s",ComSecHsh[i]->sLotUnits);
		
			ComSecHsh[i]->fUpperLimit= atof(Row[15]);
			logDebug3("fUpperLimit = %lf",ComSecHsh[i]->fUpperLimit);

			ComSecHsh[i]->fLowerLimit= atof(Row[16]);
			logDebug3("fLowerLimit = %lf",ComSecHsh[i]->fLowerLimit);
	
			ComSecHsh[i]->fStrikePrice = atof(Row[17]);
			logDebug3("fStrikePrice = %lf",ComSecHsh[i]->fStrikePrice);

			strncpy(ComSecHsh[i]->sOptType,Row[18],DB_SERIES_LEN);
			logDebug3("sOptType = %s",ComSecHsh[i]->sOptType);

			strncpy(ComSecHsh[i]->sUndScripCode,Row[19],DB_SCRIP_CODE_LEN);
			logDebug3("sUndScripCode = %s",ComSecHsh[i]->sUndScripCode);
			strncpy(ComSecHsh[i]->sMaturityDay,Row[20],MAT_DAY);
			logDebug3("sMaturityDay = %s",ComSecHsh[i]->sMaturityDay);
			strncpy(ComSecHsh[i]->sMaturityMonYr,Row[21],DB_DATETIME_LEN);
			logDebug3("sMaturityMonYr = %s",ComSecHsh[i]->sMaturityMonYr);
			ComSecHsh[i]->fLotSize= atof(Row[13]);
			logDebug3("fLotSize = %f",ComSecHsh[i]->fLotSize);
			strncpy(ComSecHsh[i]->sSymName,Row[22],DB_SYM_NAME_LEN);
			logDebug3("sSymName = %s",ComSecHsh[i]->sSymName);
			ComSecHsh[i]->fMcxMutliplier= atof(Row[24]);
			logDebug3("fMcxMutliplier = :%lf:",ComSecHsh[i]->fMcxMutliplier);
			strncpy(ComSecHsh[i]->sSeries,Row[25],DB_SERIES_LEN);
			logDebug3("sSeries = :%s:",ComSecHsh[i]->sSeries);
			strncpy(ComSecHsh[i]->sExpiryDate,Row[26],DB_DATETIME_LEN);
                        logDebug3("ComSecHsh[i]->sExpiryDate :%s:",ComSecHsh[i]->sExpiryDate);
			strncpy(ComSecHsh[i]->sCustomSym,Row[27],CUSTOM_SYM_LEN);
                        logDebug3("ComSecHsh[i]->sCustomSym :%s:",ComSecHsh[i]->sCustomSym);
			strncpy(ComSecHsh[i]->sSmExpiryFlag,Row[28],DB_EXPIRY_FLAG_LEN);

			HASH_ADD(hMcxSecHndlr,Hash_McxID,sScripCode,strlen(ComSecHsh[i]->sScripCode),ComSecHsh[i]);
			i++;
			
			logDebug3("------------------------------- End Printing in AddMcxSec -----------------------------");

		}



	}
	logDebug2("Exit [fAddMCXSecHash]");
	mysql_close(DBConSec);
	return TRUE;


}


BOOL    fAddDrvSpreadSecHash()
{
	logTimestamp("Entry fAddDrvSpreadSecHash ");
	MYSQL           *DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32          iNumRow,i=0,j=0;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sTempSecID1[DB_SCRIP_CODE_LEN];
	CHAR            sTempSecID2[DB_SCRIP_CODE_LEN];
	LONG32          n =0;

	DBConSec = DB_Connect();
	sprintf(sSelQuery,"SELECT SPD_TOKEN1,SPD_INSTRUNAME1 ,SPD_SYMBOL1 ,JULIDATE(SPD_EXPIRYDATE1),SPD_EXPIRYDATE1,SPD_OPTIONTYPE1 ,SPD_TOKEN2,SPD_INSTRUNAME2,SPD_SYMBOL2,JULIDATE(SPD_EXPIRYDATE2),SPD_EXPIRYDATE2 ,SPD_OPTIONTYPE2,SPD_REFERENCEPRICE ,SPD_UNDERLYING_SCRIPCODE ,SPD_UNDERLYING_SYM ,SPD_TRADING_SYM1 ,SPD_TRADING_SYM2 ,SPD_UNDERLAYIN_STATUS ,SPD_EXCH ,SPD_SEG   FROM SECURITY_MASTER_SPREAD WHERE (SPD_SEG = \"%c\" OR SPD_SEG = \'%c\') ;",CURRENCY_SEGMENT,DERIVATIVE_SEGMENT); 

	logDebug1(" sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
	{
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddDrvSpreadSecHash]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}
	Res = mysql_store_result(DBConSec);
	iNumRow = mysql_num_rows(Res);

	if (iNumRow == 0)
	{
		logDebug2("No result Set");

	}
	else
	{
		logDebug1("iNumRow :%d:",iNumRow);

		struct SPRD_SEC_MASTER_ARRAY *DrvSprdSecHsh[iNumRow],*TempSec ;
		while(Row = mysql_fetch_row(Res))
		{
			n = 0;

			DrvSprdSecHsh[i] = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));
			TempSec         = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

			sprintf(DrvSprdSecHsh[i]->sKey,"%s%s",Row[0],Row[6]);

			HASH_FIND(hDrvSecHndlr,HashSprDrvID, &DrvSprdSecHsh[i]->sKey,strlen(DrvSprdSecHsh[i]->sKey),TempSec);

			if(TempSec == NULL)
			{

				for ( j = 0; j< 2; j++ )
				{
					/**/                       
					logDebug2(" new n :%d:",n); 
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[j].sScripCode,Row[n+0],DB_SCRIP_CODE_LEN);
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[j].sInsName,Row[n+1],DB_INS_LEN);
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[j].sSymbol,Row[n+2],SYMBOL_LEN);
					DrvSprdSecHsh[i]->SprdSecMstr[j].iExpiryDate    = atoi(Row[n+3]);
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[j].sExpiryDate,Row[n+4],DB_DATETIME_LEN);
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[j].sOptionType,Row[n+5],DB_OPT_TYPE_LEN);
					/**/
					logDebug2("SprdSecMstr[%i].sScripCode :%s:",j,Row[n+0]);
					logDebug2("SprdSecMstr[%i].sInsName   :%s:",j,Row[n+1]);
					logDebug2("SprdSecMstr[%i].sSymbol    :%s:",j,Row[n+2]);
					logDebug2("SprdSecMstr[%i].iExpiryDate:%s:",j,Row[n+3]);
					logDebug2("SprdSecMstr[%i].sExpiryDate:%s:",j,Row[n+4]);
					logDebug2("SprdSecMstr[%i].sOptionType:%s:",j,Row[n+5]);

					n = 6;
				}


				DrvSprdSecHsh[i]->fReferencePrice       = atof(Row[12]);
				// DrvSprdSecHsh[i]->iUnderlyingScripCode  = atoi(Row[11]);

				//strncpy(DrvSprdSecHsh[i]->sUnderlyingSym,Row[12],45);
				//strncpy(DrvSprdSecHsh[i]->sSpdTradingSym1,Row[13],50);
				//strncpy(DrvSprdSecHsh[i]->sSpdTradingSym2,Row[14],50);

				DrvSprdSecHsh[i]->cUnderlyingStatus     = (Row[17][0]);
				strncpy(DrvSprdSecHsh[i]->sExch,Row[18],DB_EXCH_ID_LEN);
				DrvSprdSecHsh[i]->cSeg                  =  (Row[19][0]);

				HASH_ADD(hDrvSecHndlr,HashSprDrvID,sKey,strlen(DrvSprdSecHsh[i]->sKey), DrvSprdSecHsh[i]);
				logDebug2("sKeys :%s:",DrvSprdSecHsh[i]->sKey);
				i++;
			}

		}
		mysql_close(DBConSec);

		logTimestamp("Exit fAddDrvSpreadSecHash ");
		return TRUE;
	}
}

BOOL fGetSpreadSecDetails(struct INT_SPREAD_ORDERS *pRes)
{
	logTimestamp("Entry : [GetSpreadSecDetails]");
	struct          SPRD_SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          i = 0 , n =0,j = 0;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            sTempSecID_L1[DB_SCRIP_CODE_LEN];
	CHAR            sTempSecID_L2[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL           *DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 iNoOfLegs  = 0 ;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	memset(sTempSecID_L1,'\0',DB_SCRIP_CODE_LEN);
	memset(sTempSecID_L2,'\0',DB_SCRIP_CODE_LEN);

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	for(i = 0;i <pRes->iNoOfLeg;i++ )
	{
		logDebug1("DP : SCRIPT_CODE 1: %s",pRes->SpreadArray[i].sSecId);
	}

	pSec = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

	pHashAdd = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

	strncpy(sTempSecID_L1,pRes->SpreadArray[0].sSecId,DB_SECURITY_ID_LEN);
	strncpy(sTempSecID_L2,pRes->SpreadArray[1].sSecId,DB_SECURITY_ID_LEN);

	logDebug2("sTempSecID_L1 :%s: sTempSecID_L2 :%s:",sTempSecID_L1,sTempSecID_L2);

	sprintf(sTempSecID,"%s%s",sTempSecID_L1,sTempSecID_L2);
	logDebug2("sTempSecID  :%s:",sTempSecID);

	HASH_FIND(hDrvSecHndlr,HashSprDrvID, &sTempSecID,strlen(sTempSecID),pSec);

	logDebug2("pRes->iNoOfLeg %d ",pRes->iNoOfLeg);

	if(pSec != NULL)
	{

		for (  iNoOfLegs  = 0 ; iNoOfLegs <  pRes->iNoOfLeg ; iNoOfLegs ++)
		{
			logDebug2("pSec->SprdSecMstr[iNoOfLegs].sScripCode :%s:",pSec->SprdSecMstr[iNoOfLegs].sScripCode);
			strncpy(pRes->SpreadArray[iNoOfLegs].sSymbol,pSec->SprdSecMstr[iNoOfLegs].sSymbol,SYMBOL_LEN);
			strncpy(pRes->SpreadArray[iNoOfLegs].sInstrumentType,pSec->SprdSecMstr[iNoOfLegs].sInsName,DB_INS_LEN);
			strncpy(pRes->SpreadArray[iNoOfLegs].sSecId,pSec->SprdSecMstr[iNoOfLegs].sScripCode,DB_SECURITY_ID_LEN);
			strncpy(pRes->SpreadArray[iNoOfLegs].sMaturityDate,pSec->SprdSecMstr[iNoOfLegs].sExpiryDate,DB_DATETIME_LEN);
			strncpy(pRes->SpreadArray[iNoOfLegs].sOptionType,pSec->SprdSecMstr[iNoOfLegs].sOptionType,OPT_TYPE_LEN);
			pRes->SpreadArray[iNoOfLegs].iMaturityDate = pSec->SprdSecMstr[iNoOfLegs].iExpiryDate;

			logDebug2("pRes->SpreadArray[iNoOfLegs]sSymbol:%s:",pRes->SpreadArray[iNoOfLegs].sSymbol);
			logDebug2("pRes->SpreadArray[iNoOfLegs]MaturityDate:%ld:",pRes->SpreadArray[iNoOfLegs].iMaturityDate);
			logDebug2("pRes->SpreadArray[iNoOfLegs]sInstrumentType :%s:",pRes->SpreadArray[iNoOfLegs].sInstrumentType);
			logDebug2("pRes->SpreadArray[iNoOfLegs]sSecId:%s:",pRes->SpreadArray[iNoOfLegs].sSecId);

		}
	}
	else
	{
		sprintf(pHashAdd->sKey,"%s%s",sTempSecID_L1,sTempSecID_L2);
		DBConSec = DB_Connect();

		sprintf(sSelQuery,"SELECT SPD_TOKEN1,SPD_INSTRUNAME1 ,SPD_SYMBOL1 ,JULIDATE(SPD_EXPIRYDATE1),SPD_EXPIRYDATE1 ,SPD_TOKEN2,SPD_INSTRUNAME2,SPD_SYMBOL2,JULIDATE(SPD_EXPIRYDATE2),SPD_EXPIRYDATE2 ,SPD_REFERENCEPRICE ,SPD_UNDERLYING_SCRIPCODE ,SPD_UNDERLYING_SYM ,SPD_TRADING_SYM1 ,SPD_TRADING_SYM2 ,SPD_UNDERLAYIN_STATUS ,SPD_EXCH ,SPD_SEG   FROM SECURITY_MASTER_SPREAD WHERE (SPD_SEG = \'%c\'or SPD_SEG = \'%c\') AND SPD_TOKEN1 = \"%s\" AND SPD_TOKEN2  = \"%s\";",DERIVATIVE_SEGMENT,CURRENCY_SEGMENT,sTempSecID_L1,sTempSecID_L2);

		logDebug1("sSelQry :%s:",sSelQuery);

		if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSpreadSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}

		Res = mysql_store_result(DBConSec);
		if(Row = mysql_fetch_row(Res))
		{

			for ( i = 0; i<= pRes->iNoOfLeg ; i++ )
			{
				//                              strncpy(pHashAdd[i]->SprdSecMstr[i].sScripCode,Row[n],DB_SCRIP_CODE_LEN);
				strncpy(pHashAdd->SprdSecMstr[i].sInsName,Row[n+1],DB_INS_LEN);
				strncpy(pHashAdd->SprdSecMstr[i].sSymbol,Row[n+2],SYMBOL_LEN);
				pHashAdd->SprdSecMstr[i].iExpiryDate    = atol(Row[n+3]);/*Julian Date */
				strncpy(pHashAdd->SprdSecMstr[i].sExpiryDate,Row[n+4],15);
				n = 5;
			}
			pHashAdd->fReferencePrice       = atof(Row[10]);
			pHashAdd->iUnderlyingScripCode  = atoi(Row[11]);

			strncpy(pHashAdd->sUnderlyingSym,Row[12],45);
			strncpy(pHashAdd->sSpdTradingSym1,Row[13],50);
			strncpy(pHashAdd->sSpdTradingSym2,Row[14],50);

			pHashAdd->cUnderlyingStatus     = (Row[15][0]);
			strncpy(pHashAdd->sExch,Row[16],DB_EXCH_ID_LEN);
			pHashAdd->cSeg                  =  (Row[17][0]);
			HASH_ADD(hDrvSecHndlr,HashSprDrvID,sKey,strlen(pHashAdd->sKey),pHashAdd);
			mysql_close(DBConSec);

		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sKey);
			mysql_close(DBConSec);	
			free(sSelQuery);
			return FALSE;
		}
	}
	logTimestamp("Exit : [GetSpreadSecDetails]");
	free(sSelQuery);
	return TRUE;
}

/**BOOL fGetMCXCBSecDetails (struct INT_COBO_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetMCXCBSecDetails]");

        struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 ;
        key_t           ShmType;
        LONG32          ShmSize;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


        pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
        pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

        strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
        logDebug2("sTempSecID :%s:",sTempSecID);


        HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

        if(pSec != NULL)
        {
                strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN);
                strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
                strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
                strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
                pRes->iExpiryDate  = pSec->iExpiryDate;
                strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
                strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
                pRes->fStrikePrice = pSec->fStrikePrice;
                logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                logDebug2("pRes->sMaturityMonYr      :%s:",pRes->sMaturityMonYr);
                logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
   	 }
        else
        {
                DBConSec = DB_Connect();
                sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
                                SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                                SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
                                IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
                                IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE) \
                                FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment, \
                                sTempSecID);

                logDebug1("sSelQry :%s:",sSelQry);
                logDebug1("This is not one 1");

                if(mysql_query(DBConSec,sSelQry) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetMCXCBSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                logDebug1("This is not one 1");

                Res = mysql_store_result(DBConSec);
                logDebug1("This is not one 1");

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
                        strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
                        pHashAdd->cStatus = Row[9][0];
                        pHashAdd->cExchStatus= Row[10][0];
                        pHashAdd->cPreOpenFlag= Row[11][0];
                    	 pHashAdd->cPreOpenExchFlag= Row[12][0];
                        pHashAdd->cITSFlag= Row[13][0];
                        pHashAdd->cAlgoFlag= Row[14][0];
                        pHashAdd->cCAFlag= Row[15][0];
                        pHashAdd->fTickSize= atof(Row[17]);
                        pHashAdd->fLotSize= atof(Row[18]);
                        pHashAdd->fStrikePrice = atof(Row[22]);
                        strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
                        strncpy(pHashAdd->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
                        //strncpy(EqSecHsh[i]->SecMaster.sLotUnits,Row[19],DB_LOT_UNITS_LEN);
                        strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
                        strncpy(pRes->sOptType,Row[23],DB_OPT_TYPE_LEN);
                        strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
                        strncpy(pRes->sMaturityDay,Row[25],MAT_DAY);
                        strncpy(pRes->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
                        pRes->fStrikePrice = atof(Row[22]);
                        pRes->iExpiryDate = atoi(Row[27]);
                        logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                        logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                        logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                        logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
                        logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
                        logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
                        HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
                        mysql_close(DBConSec);

                }
                else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }




        }
	logTimestamp("EXIT [fGetMCXCBSecDetails]")
        return TRUE;
}**/

BOOL    fAddEQEntityHash()
{
        logDebug2("Entry [fAddEQEntityHash]");
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32           iNumRow,i=0;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//CHAR		sTempEntityID[DB_SCRIP_CODE_LEN];
	CHAR		sTempClientId[CLIENT_ID_LEN];

        DBConSec = DB_Connect();

	sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
			ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR\
			FROM ENTITY_MASTER WHERE ENTITY_TYPE = 'C' AND ENTITY_SETTLOR <> '000000000000';");

	logDebug1("sSelQry :%s:",sSelQuery);
	
	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
        {
                logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddEQEntityHash]");
                sql_Error(DBConSec);
                mysql_close(DBConSec);
                return FALSE;
        }

        Res = mysql_store_result(DBConSec);

        iNumRow = mysql_num_rows(Res);
        logDebug1("iNumRow :%d:",iNumRow);
        if(iNumRow == 0)
        {
                logFatal("Num Of Row Fetched :%d:",iNumRow);
                return FALSE;

        }
	
	struct ENTITY_SETTLOR_MASTER_ARRAY*EqEntityHsh[iNumRow],*TempEntity;

	while(Row = mysql_fetch_row(Res))
        {
                EqEntityHsh[i] = (struct ENTITY_SETTLOR_MASTER_ARRAY*)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));
                TempEntity     = (struct ENTITY_SETTLOR_MASTER_ARRAY*)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));
		
		memset(sTempClientId,'\0',CLIENT_ID_LEN);
                strncpy(sTempClientId,Row[4],CLIENT_ID_LEN);
	
		logDebug2("sTempClientId :%s:",sTempClientId);
	
                HASH_FIND(hSecHndlr,Hash_ByID1, &sTempClientId,strlen(sTempClientId),TempEntity);
		logDebug2("___________________________________________");
		
                if(TempEntity == NULL)
                {
			strncpy(EqEntityHsh[i]->sCode,Row[0],DB_ENTITY_CODE_LEN);
			strncpy(EqEntityHsh[i]->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
			strncpy(EqEntityHsh[i]->sType,Row[2],DB_ENTITY_TYPE_LEN);
			strncpy(EqEntityHsh[i]->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
			strncpy(EqEntityHsh[i]->sParticipantCodeEQ,Row[4],DB_ENITY_SETTLOREQ_LEN);
			logDebug2("EqEntityHsh[i]->sCode :%s:",EqEntityHsh[i]->sCode);
			logDebug2("EqEntityHsh[i]->sNseCode:%s:",EqEntityHsh[i]->sNseCode);
			logDebug2("EqEntityHsh[i]->sType:%s:",EqEntityHsh[i]->sType);
			logDebug2("EqEntityHsh[i]->sSubType:%s:",EqEntityHsh[i]->sSubType);
			logDebug2("EqEntityHsh[i]->sParticipantCodeEQ:%s:",EqEntityHsh[i]->sParticipantCodeEQ);

			HASH_ADD(hSecHndlr,Hash_ByID1,sCode,strlen(EqEntityHsh[i]->sCode),EqEntityHsh[i]);
			i++;

                }
		
		logDebug2("****************************************");
        }
    	logTimestamp("Exit : [fAddEQEntityHash]");
        mysql_close(DBConSec);
      	return TRUE;
}


BOOL fGetEntityDetails(struct INT_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetEntityDetails]");

//        MYSQL   	*DBConSec;
        struct          ENTITY_SETTLOR_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          iCnt            =       0       ;
        CHAR            sTempClientId[CLIENT_ID_LEN];
 //       CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  //      MYSQL_RES       *Res;
    //    MYSQL_ROW       Row;
//        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : sClientId: %s",pRes->sClientId);

        pSec = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));
	
        pHashAdd = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

	strncpy(sTempClientId,pRes->sClientId,CLIENT_ID_LEN);
	
	logDebug2("sTempClientId :%s:",sTempClientId);

        HASH_FIND(hSecHndlr,Hash_ByID1, &sTempClientId,strlen(sTempClientId),pSec);

        if(pSec != NULL)
        {
                //strncpy(pRes->sEntityId,pSec->sCode,DB_ENTITY_ID_LEN)            ;
                logDebug2("pSec->sParticipantCodeEQ:%s:",pSec->sParticipantCodeEQ)                 ;
                
		strncpy(pRes->sSettlor,pSec->sParticipantCodeEQ,DB_ENTITY_ID_LEN)            ;
		
               // logDebug2("pRes->sEntityId     :%s:",pRes->sEntityId)                 ;
                logDebug2("pRes->sParticipantCodeEQ     :%s:",pRes->sSettlor)                 ;

        }
        else
        {
/**
                DBConSec = DB_Connect();
		
		sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR\
                        FROM ENTITY_MASTER WHERE ENTITY_SETTLOR <> '000000000000'  AND ENTITY_CODE = \"%s\";",pRes->sClientId);
                logDebug1("sSelQry :%s:",sSelQuery);

                fstart = logGetTime();

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                fEnd = logGetTime();

                printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));


                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
			strncpy(pHashAdd->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(pHashAdd->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(pHashAdd->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(pHashAdd->sParticipantCodeEQ,Row[4],DB_ENITY_SETTLOREQ_LEN);
                        strncpy(pRes->sSettlor,pHashAdd->sParticipantCodeEQ,DB_ENITY_SETTLOREQ_LEN);
		
				
		//	logDebug2("pHashAdd->sCode :%s:",pHashAdd->sCode);
		//	logDebug2("pHashAdd->sNseCode:%s:",pHashAdd->sNseCode);
		//	logDebug2("pHashAdd->sType:%s:",pHashAdd->sType);
		//	logDebug2("pHashAdd->sSubType :%s:",pHashAdd->sSubType);
		//	logDebug2("pHashAdd->sParticipantCodeEQ :%s:",pHashAdd->sParticipantCodeEQ);
			logDebug2("pRes->sSettlor :%s:",pRes->sSettlor);
			

			HASH_ADD(hSecHndlr,Hash_ByID1,sCode,strlen(pHashAdd->sCode),pHashAdd);


                        mysql_close(DBConSec);
                }
                else
                {
                        logDebug1("Entities ID is not in Hash & in DB :%s:",pHashAdd->sCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }
	***/
                logDebug1("Entities ID is not in Hash & in DB :%s:",pHashAdd->sCode);
                //mysql_close(DBConSec);
                return FALSE;

        }
        logTimestamp("EXIT [fGetSecDetails]");
        return TRUE;

}

BOOL    fAddDRVEntityHash()
{
        logDebug2("Entry [fAddDRVEntityHash]");
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32           iNumRow,i=0;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        //CHAR          sTempEntityID[DB_SCRIP_CODE_LEN];
        CHAR           sTempClientId[CLIENT_ID_LEN]; 

        DBConSec = DB_Connect();

        sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR_DRV\
                        FROM ENTITY_MASTER WHERE ENTITY_TYPE = 'C' AND ENTITY_SETTLOR_DRV <> '000000000000';");

        logDebug1("sSelQry :%s:",sSelQuery);

        if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
        {
                logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddEQEntityHash]");
                sql_Error(DBConSec);
                mysql_close(DBConSec);
                return FALSE;
        }

        Res = mysql_store_result(DBConSec);

        iNumRow = mysql_num_rows(Res);
        logDebug1("iNumRow :%d:",iNumRow);
        if(iNumRow == 0)
        {
                logFatal("Num Of Row Fetched :%d:",iNumRow);
                return FALSE;

        }

        struct ENTITY_SETTLOR_MASTER_ARRAY*EqEntityHsh[iNumRow],*TempEntity;

        while(Row = mysql_fetch_row(Res))
        {
		EqEntityHsh[i] = (struct ENTITY_SETTLOR_MASTER_ARRAY*)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));
                TempEntity     = (struct ENTITY_SETTLOR_MASTER_ARRAY*)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

                memset(sTempClientId,'\0',CLIENT_ID_LEN);
                strncpy(sTempClientId,Row[4],CLIENT_ID_LEN);

                logDebug2("sTempClientId:%s:",sTempClientId);

                HASH_FIND(hDrvSecHndlr,Hash_DrvID1, &sTempClientId,strlen(sTempClientId),TempEntity);
                logDebug2("___________________________________________");

                if(TempEntity == NULL)
                {
			strncpy(EqEntityHsh[i]->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(EqEntityHsh[i]->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(EqEntityHsh[i]->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(EqEntityHsh[i]->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(EqEntityHsh[i]->sParticipantCodeDRV,Row[4],DB_ENITY_SETTLOREQ_LEN);
			HASH_ADD(hDrvSecHndlr,Hash_DrvID1,sCode,strlen(EqEntityHsh[i]->sCode),EqEntityHsh[i]);
                        i++;

                }

                logDebug2("****************************************");
        }
        logTimestamp("Exit : [fAddDRVEntityHash]");
        mysql_close(DBConSec);
        return TRUE;
}
BOOL fGetDRVEntityDetails(struct INT_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetDRVEntityDetails]");

        MYSQL           *DBConSec;
        struct          ENTITY_SETTLOR_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          iCnt            =       0       ;
	CHAR            sTempClientId[CLIENT_ID_LEN];
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
//        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : sClientId: %s",pRes->sClientId);

        pSec = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

        pHashAdd = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

	strncpy(sTempClientId,pRes->sClientId,CLIENT_ID_LEN);

        logDebug2("sTempClientId :%s:",sTempClientId);

        HASH_FIND(hDrvSecHndlr,Hash_DrvID1, &sTempClientId,strlen(sTempClientId),pSec);

        if(pSec != NULL)
        {
                //strncpy(pRes->sEntityId,pSec->sCode,DB_ENTITY_ID_LEN)            ;
                logDebug2("pSec->sParticipantCodeDRV:%s:",pSec->sParticipantCodeDRV)                 ;

                strncpy(pRes->sSettlor,pSec->sParticipantCodeDRV,DB_ENTITY_ID_LEN)            ;

               // logDebug2("pRes->sEntityId     :%s:",pRes->sEntityId)                 ;
                logDebug2("pRes->sParticipantCodeEQ     :%s:",pRes->sSettlor)                 ;

        }
        else
        {
                DBConSec = DB_Connect();

                sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR_DRV\
                        FROM ENTITY_MASTER WHERE ENTITY_SETTLOR_DRV <> '000000000000'  AND ENTITY_CODE = \"%s\";",pRes->sClientId);
                logDebug1("sSelQry :%s:",sSelQuery);

                fstart = logGetTime();

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                fEnd = logGetTime();

                printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));


                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(pHashAdd->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(pHashAdd->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(pHashAdd->sParticipantCodeDRV,Row[4],DB_ENITY_SETTLORDRV_LEN);
                        strncpy(pRes->sSettlor,pHashAdd->sParticipantCodeDRV,DB_ENITY_SETTLORDRV_LEN);


                //      logDebug2("pHashAdd->sCode :%s:",pHashAdd->sCode);
                //      logDebug2("pHashAdd->sNseCode:%s:",pHashAdd->sNseCode);
                //      logDebug2("pHashAdd->sType:%s:",pHashAdd->sType);
                //      logDebug2("pHashAdd->sSubType :%s:",pHashAdd->sSubType);
                //      logDebug2("pHashAdd->sParticipantCodeEQ :%s:",pHashAdd->sParticipantCodeEQ);
                        logDebug2("pRes->sSettlor :%s:",pRes->sSettlor);


                        HASH_ADD(hDrvSecHndlr,Hash_DrvID1,sCode ,strlen(pHashAdd->sCode),pHashAdd);


                        mysql_close(DBConSec);
                }
                else
                {
                        logDebug1("Entities ID is not in Hash & in DB :%s:",pHashAdd->sCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }	
	}

        logTimestamp("EXIT [fGetDRVEntityDetails]");
        return TRUE;

}

BOOL    fAddCURREntityHash()
{
        logDebug2("Entry [fAddCURREntityHash]");
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32           iNumRow,i=0;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        //CHAR          sTempEntityID[DB_SCRIP_CODE_LEN];
	CHAR            sTempClientId[CLIENT_ID_LEN];
        DBConSec = DB_Connect();

        sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR_CURR\
                        FROM ENTITY_MASTER WHERE ENTITY_TYPE = 'C' AND ENTITY_SETTLOR_CURR <> '000000000000';");

        logDebug1("sSelQry :%s:",sSelQuery);

        if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
        {
                logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddEQEntityHash]");
                sql_Error(DBConSec);
                mysql_close(DBConSec);
                return FALSE;
        }

        Res = mysql_store_result(DBConSec);

        iNumRow = mysql_num_rows(Res);
        logDebug1("iNumRow :%d:",iNumRow);
        if(iNumRow == 0)
        {
                logFatal("Num Of Row Fetched :%d:",iNumRow);
                return FALSE;

        }

        struct ENTITY_SETTLOR_MASTER_ARRAY *CurrEntityHsh[iNumRow],*TempEntity;

        while(Row = mysql_fetch_row(Res))
        {
		CurrEntityHsh[i] = (struct ENTITY_SETTLOR_MASTER_ARRAY*)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));
                TempEntity     = (struct ENTITY_SETTLOR_MASTER_ARRAY*)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

                memset(sTempClientId,'\0',CLIENT_ID_LEN);
                strncpy(sTempClientId,Row[0],CLIENT_ID_LEN);

                logDebug2("sTempClientId :%s:",sTempClientId);

                HASH_FIND(hCurrSecHndlr,Hash_CurrID1, &sTempClientId,strlen(sTempClientId),TempEntity);
                logDebug2("___________________________________________");

                if(TempEntity == NULL)
                {
                        strncpy(CurrEntityHsh[i]->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(CurrEntityHsh[i]->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(CurrEntityHsh[i]->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(CurrEntityHsh[i]->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(CurrEntityHsh[i]->sParticipantCodeCURR,Row[4],DB_ENITY_SETTLORCURR_LEN);
                        HASH_ADD(hCurrSecHndlr,Hash_CurrID1,sCode,strlen(CurrEntityHsh[i]->sCode),CurrEntityHsh[i]);
                        i++;

                }

                logDebug2("****************************************");
        }
        logTimestamp("Exit : [fAddCURREntityHash]");
        mysql_close(DBConSec);
        return TRUE;
}

BOOL fGetCURREntityDetails(struct INT_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetCURREntityDetails]");

        MYSQL           *DBConSec;
        struct          ENTITY_SETTLOR_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          iCnt            =       0       ;
	CHAR            sTempClientId[CLIENT_ID_LEN];
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
//        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : sClientId: %s",pRes->sClientId);

        pSec = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

        pHashAdd = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

	strncpy(sTempClientId,pRes->sClientId,CLIENT_ID_LEN);

        logDebug2("sTempClientId :%s:",sTempClientId);

        HASH_FIND(hCurrSecHndlr,Hash_CurrID1, &sTempClientId,strlen(sTempClientId),pSec);


        if(pSec != NULL)
        {
                logDebug2("pSec->sParticipantCodeCURR:%s:",pSec->sParticipantCodeCURR)                 ;

                strncpy(pRes->sSettlor,pSec->sParticipantCodeCURR,DB_ENTITY_ID_LEN)            ;

                logDebug2("pRes->sParticipantCodeCURR     :%s:",pRes->sSettlor)                 ;

        }
        else
        {
                DBConSec = DB_Connect();

                sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR_CURR\
                        FROM ENTITY_MASTER WHERE ENTITY_SETTLOR_CURR <> '000000000000'  AND ENTITY_CODE = \"%s\";",pRes->sClientId);
                logDebug1("sSelQry :%s:",sSelQuery);

                fstart = logGetTime();

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
 		{
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                fEnd = logGetTime();

                printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));


                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(pHashAdd->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(pHashAdd->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(pHashAdd->sParticipantCodeCURR,Row[4],DB_ENITY_SETTLORCURR_LEN);
                //        strncpy(pRes->sSettlor,pHashAdd->sParticipantCodeCURR,DB_ENITY_SETTLORCURR_LEN);


                //      logDebug2("pHashAdd->sCode :%s:",pHashAdd->sCode);
                //      logDebug2("pHashAdd->sNseCode:%s:",pHashAdd->sNseCode);
                //      logDebug2("pHashAdd->sType:%s:",pHashAdd->sType);
                //      logDebug2("pHashAdd->sSubType :%s:",pHashAdd->sSubType);
//                        logDebug2("pHashAdd->sParticipantCodeEQ :%s:",pHashAdd->sParticipantCodeEQ);
                  //      logDebug2("pRes->sSettlor :%s:",pRes->sSettlor);


                        HASH_ADD(hCurrSecHndlr,Hash_CurrID1,sCode,strlen(pHashAdd->sCode),pHashAdd);


                        mysql_close(DBConSec);
                }
                else
                {
                        logDebug1("Entities ID is not in Hash & in DB :%s:",pHashAdd->sCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }
        }
	logTimestamp("EXIT [fGetCURREntityDetails]");
        return TRUE;

}

BOOL fGetSpreadEntityDetails(struct INT_SPREAD_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetSpreadEntityDetails]");

        MYSQL           *DBConSec;
        struct          ENTITY_SETTLOR_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          iCnt            =       0       ;
        CHAR            sTempClientId[CLIENT_ID_LEN];
//        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		sSelQuery[MAX_QUERY_SIZE];
	memset(sSelQuery,'\0',MAX_QUERY_SIZE);
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug1("DP : sClientId: %s",pRes->sClientId);

        pSec = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

        pHashAdd = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

        strncpy(sTempClientId,pRes->sClientId,CLIENT_ID_LEN);

        logDebug2("sTempClientId :%s:",sTempClientId);

        HASH_FIND(hDrvSecHndlr,Hash_DrvID1, &sTempClientId,strlen(sTempClientId),pSec);

        if(pSec != NULL)
        {                
                logDebug2("pSec->sParticipantCodeDRV:%s:",pSec->sParticipantCodeDRV)                 ;
                strncpy(pRes->sSettlor,pSec->sParticipantCodeDRV,DB_ENTITY_ID_LEN)            ;             
                logDebug2("ParticipantCodeEQ     :%s:",pRes->sSettlor)                 ;
        }
        else
        {
                DBConSec = DB_Connect();

                sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR_DRV\
                        FROM ENTITY_MASTER WHERE ENTITY_SETTLOR_DRV <> '000000000000'  AND ENTITY_CODE = \"%s\";",pRes->sClientId);
                logDebug1("sSelQry :%s:",sSelQuery);
				fstart = logGetTime();

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                fEnd = logGetTime();
                printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));

                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(pHashAdd->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(pHashAdd->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(pHashAdd->sParticipantCodeDRV,Row[4],DB_ENITY_SETTLORDRV_LEN);
                        strncpy(pRes->sSettlor,pHashAdd->sParticipantCodeDRV,DB_ENITY_SETTLORDRV_LEN);
               
                        logDebug2("pRes->sSettlor :%s:",pRes->sSettlor);

                        HASH_ADD(hDrvSecHndlr,Hash_DrvID1,sCode ,strlen(pHashAdd->sCode),pHashAdd);

                        mysql_close(DBConSec);
                }
                else
				{
                        logDebug1("Entities ID is not in Hash & in DB :%s:",pHashAdd->sCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }
        }
        logTimestamp("EXIT [fGetSpreadEntityDetails]");
        return TRUE;
}
		

	
BOOL fGetMulDRVEntityDetails(struct INT_MUL_LEG_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetDRVEntityDetails]");

        MYSQL           *DBConSec;
        struct          ENTITY_SETTLOR_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          iCnt            =       0       ;
	CHAR            sTempClientId[CLIENT_ID_LEN];
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
//        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : sClientId: %s",pRes->sClientId);

        pSec = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

        pHashAdd = (struct ENTITY_SETTLOR_MASTER_ARRAY  *)malloc(sizeof(struct ENTITY_SETTLOR_MASTER_ARRAY));

	strncpy(sTempClientId,pRes->sClientId,CLIENT_ID_LEN);

        logDebug2("sTempClientId :%s:",sTempClientId);

        HASH_FIND(hDrvSecHndlr,Hash_DrvID1, &sTempClientId,strlen(sTempClientId),pSec);

        if(pSec != NULL)
        {
                //strncpy(pRes->sEntityId,pSec->sCode,DB_ENTITY_ID_LEN)            ;
                logDebug2("pSec->sParticipantCodeDRV:%s:",pSec->sParticipantCodeDRV)                 ;

                strncpy(pRes->sSettlor,pSec->sParticipantCodeDRV,SETTLOR_LEN)            ;

               // logDebug2("pRes->sEntityId     :%s:",pRes->sEntityId)                 ;
                logDebug2("pRes->sParticipantCodeEQ     :%s:",pRes->sSettlor)                 ;

        }
        else
        {
                DBConSec = DB_Connect();

                sprintf(sSelQuery,"SELECT ENTITY_CODE,ENTITY_NSE_CODE,\
                        ENTITY_TYPE,ENTITY_SUB_TYPE,ENTITY_SETTLOR_DRV\
                        FROM ENTITY_MASTER WHERE ENTITY_SETTLOR_DRV <> '000000000000'  AND ENTITY_CODE = \"%s\";",pRes->sClientId);
                logDebug1("sSelQry :%s:",sSelQuery);

                fstart = logGetTime();

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                fEnd = logGetTime();

                printf("FETCHSECDETAILS :%lf:",(fEnd - fstart));


                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sCode,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sNseCode,Row[1],DB_ENTITY_NSE_CODE_LEN);
                        strncpy(pHashAdd->sType,Row[2],DB_ENTITY_TYPE_LEN);
                        strncpy(pHashAdd->sSubType,Row[3],DB_ENTITY_SUB_TYPE_LEN);
                        strncpy(pHashAdd->sParticipantCodeDRV,Row[4],DB_ENITY_SETTLORDRV_LEN);
                        strncpy(pRes->sSettlor,pHashAdd->sParticipantCodeDRV,SETTLOR_LEN);


                //      logDebug2("pHashAdd->sCode :%s:",pHashAdd->sCode);
                //      logDebug2("pHashAdd->sNseCode:%s:",pHashAdd->sNseCode);
                //      logDebug2("pHashAdd->sType:%s:",pHashAdd->sType);
                //      logDebug2("pHashAdd->sSubType :%s:",pHashAdd->sSubType);
                //      logDebug2("pHashAdd->sParticipantCodeEQ :%s:",pHashAdd->sParticipantCodeEQ);
                        logDebug2("pRes->sSettlor :%s:",pRes->sSettlor);


                        HASH_ADD(hDrvSecHndlr,Hash_DrvID1,sCode ,strlen(pHashAdd->sCode),pHashAdd);


			mysql_close(DBConSec);
		}
		else
		{
			logDebug1("Entities ID is not in Hash & in DB :%s:",pHashAdd->sCode);
			mysql_close(DBConSec);
			return FALSE;
		}	
	}

	logTimestamp("EXIT [fGetDRVEntityDetails]");
	return TRUE;
}


BOOL fGetMulLegSecDetails(struct INT_MUL_LEG_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetMulLegSecDetails]");

	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          i = 0 ;
	LONG32          iCount = 0 ;
	key_t           ShmType;
	LONG32          ShmSize;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL		*DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	for(iCount = 0; iCount < pRes->iNoOfLeg; iCount++)
	{
		logDebug1("DP : SCRIPT_CODE: %s",pRes->SecDetails[iCount].sSecId);
		strncpy(sTempSecID,pRes->SecDetails[iCount].sSecId,DB_SECURITY_ID_LEN);
		logDebug2("sTempSecID :%s:",sTempSecID);


		HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

		if(pSec != NULL)
		{
			strncpy(pRes->SecDetails[iCount].sSymbol,pSec->sSym,SYMBOL_LEN);
			strncpy(pRes->SecDetails[iCount].sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
			strncpy(pRes->SecDetails[iCount].sInstrumentType,pSec->sInsName,DB_INS_LEN);
			strncpy(pRes->SecDetails[iCount].sMaturityDay,pSec->sMaturityDay,MAT_DAY);
			pRes->SecDetails[iCount].iExpiryDate  = pSec->iExpiryDate; 
			strncpy(pRes->SecDetails[iCount].sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
			strncpy(pRes->SecDetails[iCount].sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
			pRes->SecDetails[iCount].fStrikePrice = pSec->fStrikePrice;
			pRes->SecDetails[iCount].cCrossCurFlag= pSec->cITSFlag; 
			// This was added bcoz of cross currnecy handling drvOrd using segment check
			pRes->SecDetails[iCount].fTrdPrice = 0.00;
			logDebug2("pRes->SecDetails[iCount].sSymbol :%s:",pRes->SecDetails[iCount].sSymbol);
			logDebug2("pRes->SecDetails[iCount].sInstrumentType        :%s:",pRes->SecDetails[iCount].sInstrumentType);
			logDebug2("pRes->SecDetails[iCount].sMaturityDay        :%s:",pRes->SecDetails[iCount].sMaturityDay);
			logDebug2("pRes->SecDetails[iCount].sMaturityMonYr	     :%s:",pRes->SecDetails[iCount].sMaturityMonYr);
			logDebug2("Julian Format pRes->SecDetails[iCount].iExpiryDate = %d ",pRes->SecDetails[iCount].iExpiryDate);
			logDebug2("pRes->SecDetails[iCount].cPreOpenFlag	:%c: ",pRes->SecDetails[iCount].cPreOpenFlag);
			logDebug2("pRes->SecDetails[iCount].fTrdPrice :%c: ",pRes->SecDetails[iCount].fTrdPrice);
			logDebug2("pRes->SecDetails[iCount].sOptType :%s: ",pRes->SecDetails[iCount].sOptType);

		}
		else
		{
			DBConSec = DB_Connect();
			sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
					SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
					SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
					IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
					IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE) SM_CUSTOM_SYMBOL\
					FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment, \
					sTempSecID);

			logDebug1("sSelQry :%s:",sSelQry);
			logDebug1("This is not one 1");

			if(mysql_query(DBConSec,sSelQry) != SUCCESS)
			{
				logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetMulLegSecDetails]");
				sql_Error(DBConSec);
				mysql_close(DBConSec);
				return FALSE;
			}
			logDebug1("This is not one 1");

			Res = mysql_store_result(DBConSec);
			logDebug1("This is not one 1");

			if(Row = mysql_fetch_row(Res))
			{
				strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
				strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
				strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
				strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
				strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
				strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
				strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
				pHashAdd->cStatus = Row[9][0];
				pHashAdd->cExchStatus= Row[10][0];
				pHashAdd->cPreOpenFlag= Row[11][0];
				pHashAdd->cPreOpenExchFlag= Row[12][0];
				pHashAdd->cITSFlag= Row[13][0];
				pHashAdd->cAlgoFlag= Row[14][0];
				pHashAdd->cCAFlag= Row[15][0];
				pHashAdd->iFaceValue= atoi(Row[16]);
				pHashAdd->fTickSize= atof(Row[17]);
				pHashAdd->fLotSize= atof(Row[18]);
				pHashAdd->fStrikePrice = atof(Row[22]);
				pHashAdd->iExpiryDate=atoi(Row[27]);
				strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
				strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
				strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
				strncpy(pHashAdd->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
				strncpy(pRes->SecDetails[iCount].sSymbol,Row[5],SYMBOL_LEN);
				strncpy(pRes->SecDetails[iCount].sOptType,Row[23],DB_OPT_TYPE_LEN);
				strncpy(pRes->SecDetails[iCount].sSymbolName,Row[6],DB_SYM_NAME_LEN);
				strncpy(pRes->SecDetails[iCount].sInstrumentType,Row[7],DB_INS_LEN);
				strncpy(pRes->SecDetails[iCount].sMaturityDay,Row[25],MAT_DAY);
				strncpy(pRes->SecDetails[iCount].sMaturityMonYr,Row[26],MAT_DATE);
				pRes->SecDetails[iCount].fStrikePrice = atof(Row[22]);
				pRes->SecDetails[iCount].iExpiryDate = atoi(Row[27]);
				strncpy(pRes->SecDetails[iCount].sCustomSym,Row[28],CUSTOM_SYM_LEN);
				logDebug2("pRes->sSymbol :%s:",pRes->SecDetails[iCount].sSymbol);
				logDebug2("pRes->sInstrumentType        :%s:",pRes->SecDetails[iCount].sInstrumentType);
				logDebug2("pRes->sMaturityDay        :%s:",pRes->SecDetails[iCount].sMaturityDay);
				logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
				logDebug2("pRes->sMaturityMonYr 	:%s:",pRes->SecDetails[iCount].sMaturityMonYr);
				logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
				logDebug2(" pRes->:sOptType   %s:", Row[23]);

				HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
				mysql_close(DBConSec);

			}
			else
			{
				logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
				mysql_close(DBConSec);
				return FALSE;
			}	



		}
	}

	return TRUE;

}



BOOL    fAddBComSecHash()
{
	logTimestamp("Entry : [fAddBComSecHash]");
	MYSQL		*DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32           iNumRow,i=0;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];

	DBConSec = DB_Connect();

	sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_EXCH_SYMBOL,\
			SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
			SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,SM_CA_FLAG,ifnull(SM_TICK_SIZE,0),ifnull(SM_LOT_SIZE,1),\
			ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
			IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%d\'),NULL),IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\'),'0000-00-00-'),ifnull(SM_SYMBOL,'xyz'), \
			JULIDATE(SM_EXPIRY_DATE))SM_CROSS_CUR_FLAG,SM_RBI_REFERENCE_RATE,SM_CUSTOM_SYMBOL FROM SECURITY_MASTER WHERE SM_STATUS = 'A'\
			AND  (SM_SEGMENT = \"%c\" OR SM_SEGMENT = \'%c\') ;",COMMODITY_SEGMENT,DERIVATIVE_SEGMENT);


	logDebug1("sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
	{
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddBComSecHash]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}

	Res = mysql_store_result(DBConSec);

	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	if(iNumRow == 0)
	{
		logFatal("Num Of Row Fetched :%d:",iNumRow);
		return FALSE;

	}

	struct SEC_MASTER_ARRAY *BComSecHsh[iNumRow],*TempSec;

	while(Row = mysql_fetch_row(Res))
	{
		BComSecHsh[i] = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
		TempSec     = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

		strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);
		//logDebug1("sTempSecID :%s:",sTempSecID);

		HASH_FIND(hMcxSecHndlr,Hash_BComID, &sTempSecID,strlen(sTempSecID),TempSec);

		if(TempSec == NULL)
		{
			strncpy(BComSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(BComSecHsh[i]->sScripCode,Row[1],DB_SCRIP_CODE_LEN);
			strncpy(BComSecHsh[i]->sExchScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(BComSecHsh[i]->sSym,Row[3],DB_SYM_LEN);
			strncpy(BComSecHsh[i]->sInsName,Row[4],DB_INS_LEN);
			BComSecHsh[i]->cStatus = Row[5][0];
			BComSecHsh[i]->cExchStatus= Row[6][0];
			BComSecHsh[i]->cPreOpenFlag= Row[7][0];
			BComSecHsh[i]->cPreOpenExchFlag= Row[8][0];
			BComSecHsh[i]->cAlgoFlag= Row[10][0];
			BComSecHsh[i]->cCAFlag= Row[11][0];
			BComSecHsh[i]->fTickSize= atof(Row[12]);
			BComSecHsh[i]->fLotSize= atof(Row[13]);
			strncpy(BComSecHsh[i]->sLotUnits,Row[14],DB_LOT_UNITS_LEN);
			BComSecHsh[i]->fUpperLimit= atof(Row[15]);
			BComSecHsh[i]->fLowerLimit= atof(Row[16]);
			BComSecHsh[i]->fStrikePrice = atof(Row[17]);
			strncpy(BComSecHsh[i]->sOptType,Row[18],DB_SERIES_LEN);
			strncpy(BComSecHsh[i]->sUndScripCode,Row[19],DB_SCRIP_CODE_LEN);
			strncpy(BComSecHsh[i]->sMaturityDay,Row[20],MAT_DAY);
			strncpy(BComSecHsh[i]->sMaturityMonYr,Row[21],DB_DATETIME_LEN);
			strncpy(BComSecHsh[i]->sSymName,Row[22],DB_SYM_NAME_LEN);
			BComSecHsh[i]->iExpiryDate = atol(Row[23]);
			BComSecHsh[i]->cITSFlag= Row[24][0];
			BComSecHsh[i]->fMcxLot = atof(Row[25]);
			strncpy(BComSecHsh[i]->sCustomSym,Row[26],CUSTOM_SYM_LEN);
			
			HASH_ADD(hMcxSecHndlr,Hash_BComID,sScripCode,strlen(BComSecHsh[i]->sScripCode),BComSecHsh[i]);
			i++;

		}



	}
	logTimestamp("Exit : [fAddBComSecHash]");

	mysql_close(DBConSec);
	return TRUE;

}



BOOL fGetComSecDetails(struct INT_ORDERS *pRes)
{
	logTimestamp("Entry : [fGetDrvSecDetails]");

	struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          i = 0 ;
	key_t           ShmType;
	LONG32          ShmSize;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL		*DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


	pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
	pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

	strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
	logDebug2("sTempSecID :%s:",sTempSecID);


	HASH_FIND(hMcxSecHndlr,Hash_BComID, &sTempSecID,strlen(sTempSecID),pSec);

	if(pSec != NULL)
	{
		strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN);
		strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
		strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
		strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
		pRes->iExpiryDate  = pSec->iExpiryDate; 
		strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
		strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
		pRes->fStrikePrice = pSec->fStrikePrice;
		pRes->cCrossCurFlag= pSec->cITSFlag;
		strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);
		strncpy(pRes->sCustomSym,pSec->sCustomSym,CUSTOM_SYM_LEN);
		pRes->fLotSize = pSec->fLotSize;
		// This was added bcoz of cross currnecy handling drvOrd using segment check
		if(pRes->ReqHeader.cSegment == CURRENCY_SEGMENT)
		{
			pRes->fRBIRefRate = pSec->fMcxLot; 
		}
		else
		{
			pRes->fTrdPrice = 0.00;
		}	
		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
		logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
		logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
		logDebug2("pRes->sMaturityMonYr	     :%s:",pRes->sMaturityMonYr);
		logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
		logDebug2("pRes->cPreOpenFlag	:%c: ",pRes->cPreOpenFlag);
		logDebug2("pRes->fTrdPrice :%f: ",pRes->fTrdPrice);
		logDebug2("pRes->sOptType :%s: ",pRes->sOptType);
		logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
		logDebug2("pRes->sCustomSym :%s:",pRes->sCustomSym);
		logDebug2("pRes->fLotSize :%s:",pRes->fLotSize);
	}
	else
	{
		DBConSec = DB_Connect();
		sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
				SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
				SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
				IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
				IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE) \
				FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,sTempSecID);

		logDebug1("sSelQry :%s:",sSelQry);
		logDebug1("This is not one 1");

		if(mysql_query(DBConSec,sSelQry) != SUCCESS)
		{
			logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetDrvSecDetails]");
			sql_Error(DBConSec);
			mysql_close(DBConSec);
			return FALSE;
		}
		logDebug1("This is not one 1");

		Res = mysql_store_result(DBConSec);
		logDebug1("This is not one 1");

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
			strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
			strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
			pHashAdd->cStatus = Row[9][0];
			pHashAdd->cExchStatus= Row[10][0];
			pHashAdd->cPreOpenFlag= Row[11][0];
			pHashAdd->cPreOpenExchFlag= Row[12][0];
			pHashAdd->cITSFlag= Row[13][0];
			pHashAdd->cAlgoFlag= Row[14][0];
			pHashAdd->cCAFlag= Row[15][0];
		  	pHashAdd->iFaceValue= atoi(Row[16]);
			pHashAdd->fTickSize= atof(Row[17]);
			pHashAdd->fLotSize= atof(Row[18]);
			pHashAdd->fStrikePrice = atof(Row[22]);
			pHashAdd->iExpiryDate=atoi(Row[27]);
			strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
			strncpy(pHashAdd->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
			strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
			strncpy(pRes->sOptType,Row[23],DB_OPT_TYPE_LEN);
			strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
			strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
			strncpy(pRes->sMaturityDay,Row[25],MAT_DAY);
			strncpy(pRes->sMaturityMonYr,Row[26],MAT_DATE);
			pRes->fStrikePrice = atof(Row[22]);
			pRes->iExpiryDate = atoi(Row[27]);
			strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);
			logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
			logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
			logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
			logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
			logDebug2("pRes->sMaturityMonYr 	:%s:",pRes->sMaturityMonYr);
			logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
			logDebug2(" pRes->:sOptType   %s:", Row[23]);
			logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
	
			HASH_ADD(hMcxSecHndlr,Hash_BComID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
			mysql_close(DBConSec);

		}
		else
		{
			logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
			mysql_close(DBConSec);
			return FALSE;
		}	




	}

	return TRUE;


}

BOOL    fAddNCMSecHash()
{
        logTimestamp("Entry : [fAddNCMSecHash]");
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32           iNumRow,i=0;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];

        DBConSec = DB_Connect();

        sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_EXCH_SYMBOL,\
                        SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                        SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,SM_CA_FLAG,ifnull(SM_TICK_SIZE,0),ifnull(SM_LOT_SIZE,1),\
                        ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT,SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
                        IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\'),NULL),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),ifnull(SM_SYMBOL,'xyz'), \
                        JULIDATE(SM_EXPIRY_DATE),SM_CROSS_CUR_FLAG,SM_RBI_REFERENCE_RATE,SM_EXPIRY_DATE,IFNULL(SM_SERIES,'1') FROM SECURITY_MASTER WHERE SM_STATUS = 'A'\
                        AND  SM_SEGMENT = \"%c\" AND SM_EXCHANGE =\"%s\" ;",COMMODITY_SEGMENT,NSE_EXCH);

        logDebug1("sSelQuery :%s:",sSelQuery);

        if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
        {
                logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddNCMSecHash]");
                sql_Error(DBConSec);
                mysql_close(DBConSec);
                return FALSE;
        }

        Res = mysql_store_result(DBConSec);

        iNumRow = mysql_num_rows(Res);
        logDebug1("iNumRow :%i:",iNumRow);
        if(iNumRow == 0)
        {
                logFatal("Num Of Row Fetched :%d:",iNumRow);
                return FALSE;

        }

        struct SEC_MASTER_ARRAY *DrvSecHsh[iNumRow],*TempSec;
	while(Row = mysql_fetch_row(Res))
        {
                DrvSecHsh[i] = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
                TempSec     = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

                strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);
                //logDebug1("sTempSecID :%s:",sTempSecID);

                HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),TempSec);

                if(TempSec == NULL)
                {
                        strncpy(DrvSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(DrvSecHsh[i]->sScripCode,Row[1],DB_SCRIP_CODE_LEN);
                        strncpy(DrvSecHsh[i]->sExchScripCode,Row[2],DB_SCRIP_CODE_LEN);
                        strncpy(DrvSecHsh[i]->sSym,Row[3],DB_SYM_LEN);
                        strncpy(DrvSecHsh[i]->sInsName,Row[4],DB_INS_LEN);
                        DrvSecHsh[i]->cStatus = Row[5][0];
                        DrvSecHsh[i]->cExchStatus= Row[6][0];
                        DrvSecHsh[i]->cPreOpenFlag= Row[7][0];
                        DrvSecHsh[i]->cPreOpenExchFlag= Row[8][0];
                        DrvSecHsh[i]->cAlgoFlag= Row[10][0];
                        DrvSecHsh[i]->cCAFlag= Row[11][0];
                        DrvSecHsh[i]->fTickSize= atof(Row[12]);
                        DrvSecHsh[i]->fLotSize= atof(Row[13]);
                        strncpy(DrvSecHsh[i]->sLotUnits,Row[14],DB_LOT_UNITS_LEN);
                        DrvSecHsh[i]->fUpperLimit= atof(Row[15]);
                        DrvSecHsh[i]->fLowerLimit= atof(Row[16]);
                        DrvSecHsh[i]->fStrikePrice = atof(Row[17]);
                        strncpy(DrvSecHsh[i]->sOptType,Row[18],DB_SERIES_LEN);
                        strncpy(DrvSecHsh[i]->sUndScripCode,Row[19],DB_SCRIP_CODE_LEN);
                        strncpy(DrvSecHsh[i]->sMaturityDay,Row[20],MAT_DAY);
                        strncpy(DrvSecHsh[i]->sMaturityMonYr,Row[21],DB_DATETIME_LEN);
                        strncpy(DrvSecHsh[i]->sSymName,Row[22],DB_SYM_NAME_LEN);
                        DrvSecHsh[i]->iExpiryDate = atol(Row[23]);
                        DrvSecHsh[i]->cITSFlag= Row[24][0];
                        DrvSecHsh[i]->fMcxLot = atof(Row[25]);
			strncpy(DrvSecHsh[i]->sExpiryDate,Row[26],DB_DATETIME_LEN);
                        logDebug3("DrvSecHsh[i]->sExpiryDate :%s:",DrvSecHsh[i]->sExpiryDate);
			strncpy(DrvSecHsh[i]->sSeries,Row[27],DB_SERIES_LEN);
                        logDebug3("sSeries = :%s:",DrvSecHsh[i]->sSeries);

			HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(DrvSecHsh[i]->sScripCode),DrvSecHsh[i]);
                        //logDebug1("DrvSecHsh[%d]->sScripCode = %s %s",i,DrvSecHsh[i]->sScripCode,DrvSecHsh[i]->sSym);
                        i++;

                }



        }
        logTimestamp("Exit : [fAddNCMSecHash]");

        mysql_close(DBConSec);
        return TRUE;
}

BOOL fGetNCMSecDetails(struct INT_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetNCMSecDetails]");

        struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 ;
        key_t           ShmType;
        LONG32          ShmSize;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


        pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
        pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

        strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
        logDebug2("sTempSecID :%s:",sTempSecID);


        HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

        if(pSec != NULL)
        {
                strncpy(pRes->sSymbol,pSec->sSym,SYMBOL_LEN);
                strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
                strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
                strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
                pRes->iExpiryDate  = pSec->iExpiryDate;
                strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
                strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
                pRes->fStrikePrice = pSec->fStrikePrice;
                pRes->cCrossCurFlag= pSec->cITSFlag;
		//strncpy(pRes->sEntryDate,pSec->sMaturityMonYr,DB_DATETIME_LEN);
                // This was added bcoz of cross currnecy handling drvOrd using segment check
		strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);
		strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
                if(pRes->ReqHeader.cSegment == CURRENCY_SEGMENT)
                {
                        pRes->fRBIRefRate = pSec->fMcxLot;
                }
   		else
                {
                        pRes->fTrdPrice = 0.00;
                }
                logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                logDebug2("pRes->sMaturityMonYr      :%s:",pRes->sMaturityMonYr);
                logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
                logDebug2("pRes->cPreOpenFlag   :%c: ",pRes->cPreOpenFlag);
                logDebug2("pRes->fTrdPrice :%c: ",pRes->fTrdPrice);
                logDebug2("pRes->sOptType :%s: ",pRes->sOptType);
		logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
		logDebug2("pRes->sSeries        :%s:",pRes->sSeries);

        }
        else
        {
                DBConSec = DB_Connect();
                sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
                                SM_SYMBOL,SM_INSTRUMENT_NAME,SM_SERIES,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                                SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
                                IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
                                IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE) ,\
				SM_EXPIRY_DATE,IFNULL(SM_SERIES,'1')\
                                FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\" ;",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment, \
                                sTempSecID);

                logDebug1("sSelQry :%s:",sSelQry);
                logDebug1("This is not one 1");

                if(mysql_query(DBConSec,sSelQry) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetNCMSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                logDebug1("This is not one 1");

                Res = mysql_store_result(DBConSec);
                logDebug1("This is not one 1");
		if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
                        strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
                        pHashAdd->cStatus = Row[9][0];
                        pHashAdd->cExchStatus= Row[10][0];
                        pHashAdd->cPreOpenFlag= Row[11][0];
                        pHashAdd->cPreOpenExchFlag= Row[12][0];
                        pHashAdd->cITSFlag= Row[13][0];
                        pHashAdd->cAlgoFlag= Row[14][0];
                        pHashAdd->cCAFlag= Row[15][0];
                        pHashAdd->iFaceValue= atoi(Row[16]);
                        pHashAdd->fTickSize= atof(Row[17]);
                        pHashAdd->fLotSize= atof(Row[18]);
                        pHashAdd->fStrikePrice = atof(Row[22]);
                        pHashAdd->iExpiryDate=atoi(Row[27]);
                        strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
                        strncpy(pHashAdd->sMaturityMonYr,Row[26],DB_DATETIME_LEN);
                        strncpy(pRes->sSymbol,Row[5],SYMBOL_LEN);
                        strncpy(pRes->sOptType,Row[23],DB_OPT_TYPE_LEN);
                        strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
                        strncpy(pRes->sMaturityDay,Row[25],MAT_DAY);
                        strncpy(pRes->sMaturityMonYr,Row[26],MAT_DATE);
                        pRes->fStrikePrice = atof(Row[22]);
                        pRes->iExpiryDate = atoi(Row[27]);
			strncpy(pHashAdd->sExpiryDate,Row[28],DB_DATETIME_LEN);
			strncpy(pRes->sEntryDate,pHashAdd->sExpiryDate,DB_DATETIME_LEN);
			strncpy(pHashAdd->sSeries,Row[29],DB_SERIES_LEN);
			strncpy(pRes->sSeries,Row[29],DB_SERIES_LEN);
//			strncpy(pRes->sEntryDate,pSec->sMaturityMonYr,DB_DATETIME_LEN);
                        logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                        logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                        logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                        logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
                        logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
                        logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
                        logDebug2(" pRes->:sOptType   %s:", Row[23]);
//			logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
			logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
			logDebug2("pRes->sSeries         :%s:",pRes->sSeries);

                        HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
                        mysql_close(DBConSec);
//			HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
  //                      mysql_close(DBConSec);

                }
                else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }




        }
	logTimestamp("Exit : [fGetNCMSecDetails]");
        return TRUE;


}

BOOL fGetMCXSpreadSecDetails(struct INT_SPREAD_ORDERS *pRes)
{
        logTimestamp("Entry : [GetMCXSpreadSecDetails]");
	
	struct          SPRD_SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 , n =0,j = 0;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            sTempSecID_L1[DB_SCRIP_CODE_LEN];
        CHAR            sTempSecID_L2[DB_SCRIP_CODE_LEN];
        CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32 iNoOfLegs  = 0 ;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	memset(sSelQuery,'\0',MAX_QUERY_SIZE);

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);

        pSec = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

        pHashAdd = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));
	logDebug2("pRes->iNoOfLeg :%d:",pRes->iNoOfLeg);	
	for(i = 0;i <pRes->iNoOfLeg;i++ )
        {
        	logDebug1("RP : SCRIPT_CODE[%d] 1: %s",i,pRes->SpreadArray[i].sSecId);
		strncpy(sTempSecID,pRes->SpreadArray[i].sSecId,DB_SCRIP_CODE_LEN);
                logDebug2("sTempSecID :%s:",sTempSecID);

	        HASH_FIND(hDrvSecHndlr,HashSprDrvID, &sTempSecID,strlen(sTempSecID),pSec);

        	if(pSec != NULL)
        	{

                        //logDebug2("pSec->SprdSecMstr[0].sScripCode :%s:",pSec->SprdSecMstr[0].sScripCode);
//			logDebug2("pSec->SprdSecMstr[1].sScripCode :%s:",pSec->SprdSecMstr[1].sScripCode);
                        //strncpy(pRes->SpreadArray[i].sSymbol,pSec->SprdSecMstr[i].sSymbol,SYMBOL_LEN);
                        strncpy(pRes->SpreadArray[i].sSymbol,pSec->SprdSecMstr[i].sSymbol,SYMBOL_LEN);
                        strncpy(pRes->SpreadArray[i].sInstrumentType,pSec->SprdSecMstr[i].sInsName,DB_INS_LEN);
                        strncpy(pRes->SpreadArray[i].sSecId,pSec->SprdSecMstr[i].sScripCode,DB_SECURITY_ID_LEN);
                        strncpy(pRes->SpreadArray[i].sMaturityDate,pSec->SprdSecMstr[i].sExpiryDate,DB_DATETIME_LEN);
                        strncpy(pRes->SpreadArray[i].sOptionType,pSec->SprdSecMstr[i].sOptionType,OPT_TYPE_LEN);
                        pRes->SpreadArray[i].iMaturityDate = pSec->SprdSecMstr[i].iExpiryDate;
                        
			logDebug2("pSec->SprdSecMstr[i].sScripCode :%s:",pSec->SprdSecMstr[i].sScripCode);
                        logDebug2("pRes->SpreadArray[i]sSymbol:%s:",pRes->SpreadArray[i].sSymbol);
                        logDebug2("pRes->SpreadArray[i]MaturityDate:%ld:",pRes->SpreadArray[i].iMaturityDate);
                        logDebug2("pRes->SpreadArray[i]sInstrumentType :%s:",pRes->SpreadArray[i].sInstrumentType);
                        logDebug2("pRes->SpreadArray[i]sSecId:%s:",pRes->SpreadArray[i].sSecId);
			
                
        	}
        
	        else
        	{
			sprintf(pHashAdd->sKey,"%s%s",pRes->SpreadArray[i].sSecId,pRes->SpreadArray[i].sSecId);
			logDebug2(":%s:AND:%s:",pRes->SpreadArray[i].sSecId,pRes->SpreadArray[i].sSecId);
                	DBConSec = DB_Connect();
	
                	sprintf(sSelQuery,"SELECT SM_SCRIP_CODE,SM_INSTRUMENT_NAME ,SM_SYMBOL ,JULIDATE(SM_EXPIRY_DATE),SM_EXPIRY_DATE ,SM_EXCHANGE ,SM_SEGMENT,\
					IFNULL(SM_OPTION_TYPE,'XX')   FROM SECURITY_MASTER WHERE SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE  = \"%s\" AND SM_INSTRUMENT_NAME in(\"FUTCOM\",\"OPTFUT\");;",COMMODITY_SEGMENT,sTempSecID);

                logDebug1("sSelQry :%s:",sSelQuery);

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetMCXSpreadSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }

                Res = mysql_store_result(DBConSec);
                if(Row = mysql_fetch_row(Res))
                {

                                strncpy(pHashAdd->SprdSecMstr[i].sScripCode,Row[0],DB_SCRIP_CODE_LEN);
				//strncpy(pRes->SpreadArray[i].sSecId,pSec->SprdSecMstr[0].sScripCode,DB_SECURITY_ID_LEN);
				strncpy(pHashAdd->SprdSecMstr[i].sInsName,Row[1],DB_INS_LEN);
                                strncpy(pRes->SpreadArray[i].sInstrumentType,Row[1],DB_INS_LEN);
                                strncpy(pHashAdd->SprdSecMstr[i].sSymbol,Row[2],SYMBOL_LEN);
                                strncpy(pRes->SpreadArray[i].sSymbol,Row[2],SYMBOL_LEN);
                                pHashAdd->SprdSecMstr[i].iExpiryDate    = atol(Row[3]);/*Julian Date */
                                pRes->SpreadArray[i].iMaturityDate = pHashAdd->SprdSecMstr[0].iExpiryDate;
                                strncpy(pHashAdd->SprdSecMstr[i].sExpiryDate,Row[4],15);
                                strncpy(pRes->SpreadArray[i].sMaturityDate,Row[4],DB_DATETIME_LEN);
                                strncpy(pHashAdd->sExch,Row[5],DB_EXCH_ID_LEN);
                                pHashAdd->cSeg                  =  (Row[6][0]);
                                strncpy(pHashAdd->SprdSecMstr[i].sOptionType,Row[7],DB_OPT_TYPE_LEN);	
				strncpy(pRes->SpreadArray[i].sOptionType,Row[7],OPT_TYPE_LEN);
                        	HASH_ADD(hDrvSecHndlr,HashSprDrvID,sKey,strlen(pHashAdd->sKey),pHashAdd);
	                        mysql_close(DBConSec);

                }
		else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",sTempSecID);
                        mysql_close(DBConSec);
                        return FALSE;
                }

		}
	}
        logTimestamp("Exit : [fGetMCXSpreadSecDetails]");

        return TRUE;
}



BOOL fGetMLSpreadSecDetails(struct INT_SPREAD_ORDERS *pRes)
{
        logTimestamp("Entry : [GetMLSpreadSecDetails]");

        struct          SPRD_SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 , n =0,j = 0;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            sTempSecID_L1[DB_SCRIP_CODE_LEN];
        CHAR            sTempSecID_L2[DB_SCRIP_CODE_LEN];
      //  CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32 iNoOfLegs  = 0 ;
//        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sSelQuery[MAX_QUERY_SIZE];
        memset(sSelQuery,'\0',MAX_QUERY_SIZE);

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);

        pSec = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

        pHashAdd = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));
        logDebug2("pRes->iNoOfLeg :%d:",pRes->iNoOfLeg);
        for(i = 0;i <pRes->iNoOfLeg;i++ )
        {
                logDebug1("RP : SCRIPT_CODE[%d] 1: %s",i,pRes->SpreadArray[i].sSecId);
                strncpy(sTempSecID,pRes->SpreadArray[i].sSecId,DB_SCRIP_CODE_LEN);
                logDebug2("sTempSecID :%s:",sTempSecID);

                HASH_FIND(hDrvSecHndlr,HashSprDrvID, &sTempSecID,strlen(sTempSecID),pSec);

                if(pSec != NULL)
                {

                        //logDebug2("pSec->SprdSecMstr[0].sScripCode :%s:",pSec->SprdSecMstr[0].sScripCode);
//                      logDebug2("pSec->SprdSecMstr[1].sScripCode :%s:",pSec->SprdSecMstr[1].sScripCode);
                        //strncpy(pRes->SpreadArray[i].sSymbol,pSec->SprdSecMstr[i].sSymbol,SYMBOL_LEN);
                        strncpy(pRes->SpreadArray[i].sSymbol,pSec->SprdSecMstr[i].sSymbol,SYMBOL_LEN);
                        strncpy(pRes->SpreadArray[i].sInstrumentType,pSec->SprdSecMstr[i].sInsName,DB_INS_LEN);
                        strncpy(pRes->SpreadArray[i].sSecId,pSec->SprdSecMstr[i].sScripCode,DB_SECURITY_ID_LEN);
                        strncpy(pRes->SpreadArray[i].sMaturityDate,pSec->SprdSecMstr[i].sExpiryDate,DB_DATETIME_LEN);
                        strncpy(pRes->SpreadArray[i].sOptionType,pSec->SprdSecMstr[i].sOptionType,OPT_TYPE_LEN);
                        pRes->SpreadArray[i].iMaturityDate = pSec->SprdSecMstr[i].iExpiryDate;
			logDebug2("pSec->SprdSecMstr[i].sScripCode :%s:",pSec->SprdSecMstr[i].sScripCode);
                        logDebug2("pRes->SpreadArray[i]sSymbol:%s:",pRes->SpreadArray[i].sSymbol);
                        logDebug2("pRes->SpreadArray[i]MaturityDate:%ld:",pRes->SpreadArray[i].iMaturityDate);
                        logDebug2("pRes->SpreadArray[i]sInstrumentType :%s:",pRes->SpreadArray[i].sInstrumentType);
                        logDebug2("pRes->SpreadArray[i]sSecId:%s:",pRes->SpreadArray[i].sSecId);


                }

                else
                {
                        sprintf(pHashAdd->sKey,"%s%s",pRes->SpreadArray[i].sSecId,pRes->SpreadArray[i].sSecId);
                        logDebug2(":%s:AND:%s:",pRes->SpreadArray[i].sSecId,pRes->SpreadArray[i].sSecId);
                        DBConSec = DB_Connect();

                        sprintf(sSelQuery,"SELECT SM_SCRIP_CODE,SM_INSTRUMENT_NAME ,SM_EXCH_SYMBOL,JULIDATE(SM_EXPIRY_DATE),SM_EXPIRY_DATE ,SM_EXCHANGE ,SM_SEGMENT,\
                                        IFNULL(SM_OPTION_TYPE,'XX')   FROM SECURITY_MASTER WHERE SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE  = \"%s\";",DERIVATIVE_SEGMENT,sTempSecID);

                logDebug1("sSelQry :%s:",sSelQuery);

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetMCXSpreadSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }

                Res = mysql_store_result(DBConSec);
                if(Row = mysql_fetch_row(Res))
                {

                                strncpy(pHashAdd->SprdSecMstr[i].sScripCode,Row[0],DB_SCRIP_CODE_LEN);
                                //strncpy(pRes->SpreadArray[i].sSecId,pSec->SprdSecMstr[0].sScripCode,DB_SECURITY_ID_LEN);
                                strncpy(pHashAdd->SprdSecMstr[i].sInsName,Row[1],DB_INS_LEN);
                                strncpy(pRes->SpreadArray[i].sInstrumentType,Row[1],DB_INS_LEN);
                                strncpy(pHashAdd->SprdSecMstr[i].sSymbol,Row[2],SYMBOL_LEN);
                                strncpy(pRes->SpreadArray[i].sSymbol,Row[2],SYMBOL_LEN);
                                pHashAdd->SprdSecMstr[i].iExpiryDate    = atol(Row[3]);/*Julian Date */
                                pRes->SpreadArray[i].iMaturityDate = pHashAdd->SprdSecMstr[0].iExpiryDate;
                                strncpy(pHashAdd->SprdSecMstr[i].sExpiryDate,Row[4],15);
                                strncpy(pRes->SpreadArray[i].sMaturityDate,Row[4],DB_DATETIME_LEN);
                                pHashAdd->cSeg                  =  (Row[6][0]);
                                strncpy(pHashAdd->SprdSecMstr[i].sOptionType,Row[7],DB_OPT_TYPE_LEN);
                                strncpy(pRes->SpreadArray[i].sOptionType,Row[7],OPT_TYPE_LEN);
                                HASH_ADD(hDrvSecHndlr,HashSprDrvID,sKey,strlen(pHashAdd->sKey),pHashAdd);
                                mysql_close(DBConSec);

                }
                else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",sTempSecID);
                        mysql_close(DBConSec);
                        return FALSE;
                }

                }
        }
        logTimestamp("Exit : [fGetMLSpreadSecDetails]");

        return TRUE;
}

BOOL fGetICEXSecDetails(struct INT_ORDERS *pRes)
{
        logTimestamp("Entry : [GetICEXSecDetails]");
        MYSQL   *DBConSec;
        struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          iCnt            =       0       ;
        key_t           ShmType;
        LONG32          ShmSize;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            sSelQry[MAX_QUERY_SIZE];
	memset(&sSelQry,'\0',MAX_QUERY_SIZE);
	memset(&sTempSecID,'\0',DB_SCRIP_CODE_LEN);
        MYSQL_RES      *Res;
        MYSQL_ROW       Row;

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


        pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
        pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

        strncpy(sTempSecID,pRes->sSecId,DB_SCRIP_CODE_LEN);
        logDebug2("sTempSecID :%s:",sTempSecID);
        HASH_FIND(hMcxSecHndlr,Hash_McxID, &sTempSecID,strlen(sTempSecID),pSec);
	if(pSec != NULL)
        {

                strncpy(pRes->sSymbol,pSec->sSym,DB_SYM_LEN);
                strncpy(pRes->sSymbolSfx,pSec->sSymName,DB_SERIES_LEN);
                strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INSTRU_LEN);
                strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
                pRes->iExpiryDate  = pSec->iExpiryDate;
                strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
                strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
                pRes->fStrikePrice = pSec->fStrikePrice;
                strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
                pRes->iAuctionNum  = pSec->fMcxMutliplier;
                strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
                strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);

                logDebug2("pRes->sSymName :%s:",pRes->sSymbolName);
                logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                logDebug2("pRes->sSymbolSfx :%s:",pRes->sSymbolSfx);
                logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                logDebug2("pRes->sSeries        :%s:",pRes->sSeries);
                logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                logDebug2("pRes->sMaturityMonYr      :%s:",pRes->sMaturityMonYr);
                logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
                logDebug2("pRes->iAuctionNum :%d:",pRes->iAuctionNum);
                logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
		
	}
        else
        {
                DBConSec = DB_Connect();
                sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_SYMBOL,\
                                SM_EXCH_SYMBOL,SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                                SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),\
				IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
                                IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),\
				ifNULL(SM_STRIKE_PRICE,-0.0100),IFNULL(SM_OPTION_TYPE,'XX'),IFNULL(SM_UNDERLAYING_SCRIP_CODE,'1'),\
                                IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),\
				JULIDATE(SM_EXPIRY_DATE),IFNULL(SM_SERIES,'0'),SM_EXPIRY_DATE,SM_MCX_MULTIPLIER\
                                FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'M\' AND SM_SCRIP_CODE =\"%s\" AND \
				SM_INSTRUMENT_NAME in(\"FUTCOM\",\"OPTFUT\");",pRes->ReqHeader.sExcgId,sTempSecID);

                logDebug1("sSelQry :%s:",sSelQry);
                logDebug1("This is not one 1");

                if(mysql_query(DBConSec,sSelQry) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [GetMcxSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }
                logDebug1("This is not one 2");

                Res = mysql_store_result(DBConSec);
                logDebug1("This is not one 3");
		logDebug2("Res :%d:",Res);
		logDebug2("Row :%d:",Row);

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
                        strncpy(pRes->sSymbolName,pHashAdd->sSym,DB_SYM_LEN);
                        strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pRes->sSymbolSfx,pHashAdd->sSymName,DB_SERIES_LEN);
                        strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
			pHashAdd->cStatus = Row[8][0];
                        pHashAdd->cExchStatus= Row[9][0];
                        pHashAdd->cPreOpenFlag= Row[10][0];
                        pHashAdd->cPreOpenExchFlag= Row[11][0];
                        pHashAdd->cITSFlag= Row[12][0];
                        pHashAdd->cAlgoFlag= Row[13][0];
                        pHashAdd->cCAFlag= Row[14][0];
			pHashAdd->fTickSize= atof(Row[16]);
                        pHashAdd->fLotSize= atof(Row[17]);

                        pHashAdd->fStrikePrice = atof(Row[21]);
                        strncpy(pHashAdd->sOptType,Row[22],DB_OPT_TYPE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[23],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sMaturityDay,Row[24],MAT_DAY);
                        strncpy(pHashAdd->sMaturityMonYr,Row[26],MAT_MONYR);	
			strncpy(pRes->sSymbol,Row[5],DB_SYM_LEN);
                        strncpy(pRes->sOptType,Row[22],DB_OPT_TYPE_LEN);
                        strncpy(pRes->sSymbolName,Row[5],DB_SYM_NAME_LEN);
                        strncpy(pRes->sInstrumentType,Row[7],DB_INSTRU_LEN);
                        strncpy(pRes->sMaturityDay,Row[24],MAT_DAY);
                        strncpy(pRes->sMaturityMonYr,Row[25],DB_DATETIME_LEN);
                        pRes->fStrikePrice = atof(Row[21]);
                        strncpy(pRes->sSeries,Row[27],DB_SERIES_LEN);
                        strncpy(pHashAdd->sSeries,Row[27],DB_SERIES_LEN);
                        strncpy(pHashAdd->sExpiryDate,Row[28],DB_DATETIME_LEN);
                        strncpy(pRes->sEntryDate,pHashAdd->sExpiryDate,DB_DATETIME_LEN);
                        pHashAdd->fMcxMutliplier = atof(Row[29]);
                        pRes->iAuctionNum = atof(Row[29]);
                        pRes->iAuctionNum = pHashAdd->fMcxMutliplier;
                        logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                        logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                        logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                        logDebug2("sMaturityMonYr Row[26] :%s:",Row[25]);
                        logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
                        logDebug2("pRes->sSeries         :%s:",pRes->sSeries);
                        logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
                        logDebug2("pRes->iAuctionNum :%d:",pRes->iAuctionNum);

                        HASH_ADD(hMcxSecHndlr,Hash_McxID, sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
                        mysql_close(DBConSec);
                }
                else if(mysql_num_rows(Res) == 0)
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
                        mysql_close(DBConSec);
                        return FALSE ;
                }
                else
                {
                        logDebug1("FALSE Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
                        mysql_close(DBConSec);
                        return FALSE;
                }
		
	}
        logTimestamp("Exit : [GetICEXSecDetails]");

        return TRUE;
}

BOOL fGetICEXCBSecDetails (struct INT_COBO_ORDERS *pRes)
{
        logTimestamp("Entry : [fGetICEXCBSecDetails]");

        struct          SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 ;
        key_t           ShmType;
        LONG32          ShmSize;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
        logDebug1("DP : SCRIPT_CODE: %s",pRes->sSecId);


        pSec = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
        pHashAdd = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

        strncpy(sTempSecID,pRes->sSecId,DB_SECURITY_ID_LEN);
        logDebug2("sTempSecID :%s:",sTempSecID);


        HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),pSec);

        if(pSec != NULL)
        {
                strncpy(pRes->sSymbol,pSec->sSym,DB_SYM_LEN);
                strncpy(pRes->sSymbolName,pSec->sSymName,DB_SYM_NAME_LEN);
                strncpy(pRes->sInstrumentType,pSec->sInsName,DB_INS_LEN);
                strncpy(pRes->sMaturityDay,pSec->sMaturityDay,MAT_DAY);
                pRes->iExpiryDate  = pSec->iExpiryDate;
                strncpy(pRes->sMaturityMonYr,pSec->sMaturityMonYr,DB_DATETIME_LEN);
                strncpy(pRes->sOptType,pSec->sOptType,DB_OPT_TYPE_LEN);
                pRes->fStrikePrice = pSec->fStrikePrice;
                pRes->iAuctionNum  = pSec->fMcxMutliplier;
                strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
                strncpy(pRes->sEntryDate,pSec->sExpiryDate,DB_DATETIME_LEN);

                logDebug2("pRes->sSymName :%s:",pRes->sSymbolName);
		logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                logDebug2("pRes->sSymbolSfx :%s:",pRes->sSymbolSfx);
                logDebug2("pRes->sInstrumentType        :%s:",pRes->sInstrumentType);
                logDebug2("pRes->sSeries        :%s:",pRes->sSeries);
                logDebug2("pRes->sMaturityDay        :%s:",pRes->sMaturityDay);
                logDebug2("pRes->sMaturityMonYr      :%s:",pRes->sMaturityMonYr);
                logDebug2("Julian Format pRes->iExpiryDate = %d ",pRes->iExpiryDate);
                logDebug2("pRes->iAuctionNum  :%d:",pRes->iAuctionNum);
                logDebug2("pRes->sOptType :%s:",pRes->sOptType);
                logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);
        }
        else
        {
                DBConSec = DB_Connect();
                sprintf(sSelQry,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_SYMBOL,\
                                SM_EXCH_SYMBOL,SM_INSTRUMENT_NAME,IFNULL(SM_SERIES,1),SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                                SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(SM_CA_FLAG,\"Y\"),IFNULL(SM_FACE_VALUE,\"1\"),IFNULL(SM_TICK_SIZE,'1'),IFNULL(SM_LOT_SIZE,'1'),\
                                IFNULL(SM_LOT_UNITS,'1'),IFNULL(SM_UPPER_LIMIT,'0.00'),IFNULL(SM_LOWER_LIMIT,'0.00'),ifNULL(SM_STRIKE_PRICE,-0.0100),SM_OPTION_TYPE,IFNULL(SM_UNDERLAYING_SCRIP_CODE,'1'),\
                                IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\')),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),JULIDATE(SM_EXPIRY_DATE),SM_MCX_MULTIPLIER,SM_EXPIRY_DATE \
                                FROM SECURITY_MASTER WHERE SM_EXCHANGE =\"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE =\"%s\"; ",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment, \
                                sTempSecID);

                logDebug1("sSelQry :%s:",sSelQry);

                if(mysql_query(DBConSec,sSelQry) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetDrvCBSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        free(sSelQry);
                        return FALSE;
                }

                Res = mysql_store_result(DBConSec);

                if(Row = mysql_fetch_row(Res))
                {
                        strncpy(pHashAdd->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(pHashAdd->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
			strncpy(pHashAdd->sExchScripCode,Row[3],DB_SCRIP_CODE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[4],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sSym,Row[5],DB_SYM_LEN);
                        strncpy(pRes->sSymbol,Row[5],DB_SYM_LEN);
                        strncpy(pHashAdd->sSymName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pRes->sSymbolName,Row[6],DB_SYM_NAME_LEN);
                        strncpy(pHashAdd->sInsName,Row[7],DB_INS_LEN);
                        strncpy(pRes->sInstrumentType,Row[7],DB_INS_LEN);
                        strncpy(pHashAdd->sSeries,Row[8],DB_SERIES_LEN);
                        strncpy(pRes->sSeries,Row[8],DB_SERIES_LEN);
                        pHashAdd->cStatus = Row[9][0];
                        pHashAdd->cExchStatus= Row[10][0];
                        pHashAdd->cPreOpenFlag= Row[11][0];
                        pHashAdd->cPreOpenExchFlag= Row[12][0];
                        pHashAdd->cITSFlag= Row[13][0];
                        pHashAdd->cAlgoFlag= Row[14][0];
                        pHashAdd->cCAFlag= Row[15][0];
                        pHashAdd->iFaceValue =atoi(Row[16]);
                        pHashAdd->fTickSize= atof(Row[17]);
                        pHashAdd->fLotSize= atof(Row[18]);
                        strncpy(pHashAdd->sLotUnits,Row[19],DB_LOT_UNITS_LEN);
                        pHashAdd->fUpperLimit =atof(Row[20]);
                        pHashAdd->fLowerLimit = atof(Row[21]);
                        pHashAdd->fStrikePrice = atof(Row[22]);
                        strncpy(pHashAdd->sOptType,Row[23],DB_OPT_TYPE_LEN);
                        strncpy(pRes->sOptType,pHashAdd->sOptType,DB_OPT_TYPE_LEN);
                        strncpy(pHashAdd->sISINCode,Row[24],DB_ISIN_CODE_LEN);
                        strncpy(pHashAdd->sMaturityDay,Row[25],MAT_DAY);
                        strncpy(pHashAdd->sMaturityMonYr,Row[26],MAT_MONYR);
                        pHashAdd->iExpiryDate = atoi(Row[27]);
                        pHashAdd->fMcxMutliplier = atof(Row[28]);
			pRes->iAuctionNum = atof(Row[28]);
                        pRes->iAuctionNum = pHashAdd->fMcxMutliplier;
                        strncpy(pRes->sMaturityMonYr,pHashAdd->sMaturityMonYr,DB_DATETIME_LEN);
                        strncpy(pHashAdd->sExpiryDate,Row[29],DB_DATETIME_LEN);
                        strncpy(pRes->sEntryDate,pHashAdd->sExpiryDate,DB_DATETIME_LEN);

                        logDebug2("pRes->sSym :%s:",pHashAdd->sSym);
                        logDebug2("pRes->sSymbol :%s:",pRes->sSymbol);
                        logDebug2("pRes->sInstrumentType        :%s:",pHashAdd->sInsName);
                        logDebug2("pRes->sInstrumentType :%s:",pRes->sInstrumentType);
                        logDebug2("pRes->sMaturityDay        :%s:",pHashAdd->sMaturityDay);
                        logDebug2("sMaturityMonYr Row[26] :%s:",Row[26]);
                        logDebug2("pRes->sMaturityMonYr         :%s:",pHashAdd->sMaturityMonYr);
                        logDebug2("pRes->sMaturityMonYr         :%s:",pRes->sMaturityMonYr);
                        logDebug2(" pRes->iExpiryDate   :%s:", Row[27]);
                        logDebug2(" pRes->iExpiryDate   :%d:",pRes->iExpiryDate);
                        logDebug2("atof(Row[28]) :%f:",atof(Row[28]));
                        logDebug2("atof(Row[28]) :%f:",atof(Row[28]));
                        logDebug2("pRes->iAuctionNum :%f:",pHashAdd->fMcxMutliplier);
                        logDebug2("pRes->sSeries         :%s:",pHashAdd->sSeries);
                        logDebug2("pRes->sOptType :%s:",pRes->sOptType);
                        logDebug2("pHashAdd->sExpiryDate :%s:",pHashAdd->sExpiryDate);
                        logDebug2("pRes->sEntryDate :%s:",pRes->sEntryDate);

                        HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
                        mysql_close(DBConSec);

                }
                else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
                        mysql_close(DBConSec);
                        free(sSelQry);
                        return FALSE;
                }
        }
                        free(sSelQry);
                        logTimestamp("EXIT [fGetICEXCBSecDetails]");
                        return TRUE;
}

BOOL fGetICEXSpreadSecDetails(struct INT_SPREAD_ORDERS *pRes)
{
        logTimestamp("Entry : [GetICEXSpreadSecDetails]");

        struct          SPRD_SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
        LONG32          i = 0 , n =0,j = 0;
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
        CHAR            sTempSecID_L1[DB_SCRIP_CODE_LEN];
        CHAR            sTempSecID_L2[DB_SCRIP_CODE_LEN];
        CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32 iNoOfLegs  = 0 ;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        memset(sSelQuery,'\0',MAX_QUERY_SIZE);

        logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);

        pSec = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

        pHashAdd = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));
        logDebug2("pRes->iNoOfLeg :%d:",pRes->iNoOfLeg);
        for(i = 0;i <pRes->iNoOfLeg;i++ )
        {
                logDebug1("RP : SCRIPT_CODE[%d] 1: %s",i,pRes->SpreadArray[i].sSecId);
                strncpy(sTempSecID,pRes->SpreadArray[i].sSecId,DB_SCRIP_CODE_LEN);
                logDebug2("sTempSecID :%s:",sTempSecID);

                HASH_FIND(hDrvSecHndlr,HashSprDrvID, &sTempSecID,strlen(sTempSecID),pSec);

                if(pSec != NULL)
                {
			strncpy(pRes->SpreadArray[i].sSymbol,pSec->SprdSecMstr[i].sSymbol,SYMBOL_LEN);
                        strncpy(pRes->SpreadArray[i].sInstrumentType,pSec->SprdSecMstr[i].sInsName,DB_INS_LEN);
                        strncpy(pRes->SpreadArray[i].sSecId,pSec->SprdSecMstr[i].sScripCode,DB_SECURITY_ID_LEN);
                        strncpy(pRes->SpreadArray[i].sMaturityDate,pSec->SprdSecMstr[i].sExpiryDate,DB_DATETIME_LEN);
                        strncpy(pRes->SpreadArray[i].sOptionType,pSec->SprdSecMstr[i].sOptionType,OPT_TYPE_LEN);
                        pRes->SpreadArray[i].iMaturityDate = pSec->SprdSecMstr[i].iExpiryDate;

                        logDebug2("pSec->SprdSecMstr[i].sScripCode :%s:",pSec->SprdSecMstr[i].sScripCode);
                        logDebug2("pRes->SpreadArray[i]sSymbol:%s:",pRes->SpreadArray[i].sSymbol);
                        logDebug2("pRes->SpreadArray[i]MaturityDate:%ld:",pRes->SpreadArray[i].iMaturityDate);
                        logDebug2("pRes->SpreadArray[i]sInstrumentType :%s:",pRes->SpreadArray[i].sInstrumentType);
                        logDebug2("pRes->SpreadArray[i]sSecId:%s:",pRes->SpreadArray[i].sSecId);


                }

                else
                {
                        sprintf(pHashAdd->sKey,"%s%s",pRes->SpreadArray[i].sSecId,pRes->SpreadArray[i].sSecId);
                        logDebug2(":%s:AND:%s:",pRes->SpreadArray[i].sSecId,pRes->SpreadArray[i].sSecId);
                        DBConSec = DB_Connect();

                        sprintf(sSelQuery,"SELECT SM_SCRIP_CODE,SM_INSTRUMENT_NAME ,SM_SYMBOL ,JULIDATE(SM_EXPIRY_DATE),SM_EXPIRY_DATE ,SM_EXCHANGE ,SM_SEGMENT,\
                                        IFNULL(SM_OPTION_TYPE,'XX')   FROM SECURITY_MASTER WHERE SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE  = \"%s\" ;",COMMODITY_SEGMENT,sTempSecID);

                logDebug1("sSelQry :%s:",sSelQuery);

                if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
                {
                        logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetICEXSpreadSecDetails]");
                        sql_Error(DBConSec);
                        mysql_close(DBConSec);
                        return FALSE;
                }

                Res = mysql_store_result(DBConSec);
                if(Row = mysql_fetch_row(Res))
                {
				strncpy(pHashAdd->SprdSecMstr[i].sScripCode,Row[0],DB_SCRIP_CODE_LEN);
				strncpy(pHashAdd->SprdSecMstr[i].sInsName,Row[1],DB_INS_LEN);
                                strncpy(pRes->SpreadArray[i].sInstrumentType,Row[1],DB_INS_LEN);
                                strncpy(pHashAdd->SprdSecMstr[i].sSymbol,Row[2],SYMBOL_LEN);
                                strncpy(pRes->SpreadArray[i].sSymbol,Row[2],SYMBOL_LEN);
                                pHashAdd->SprdSecMstr[i].iExpiryDate    = atol(Row[3]);/*Julian Date */
                                pRes->SpreadArray[i].iMaturityDate = pHashAdd->SprdSecMstr[0].iExpiryDate;
                                strncpy(pHashAdd->SprdSecMstr[i].sExpiryDate,Row[4],15);
                                strncpy(pRes->SpreadArray[i].sMaturityDate,Row[4],DB_DATETIME_LEN);
                                strncpy(pHashAdd->sExch,Row[5],DB_EXCH_ID_LEN);
                                pHashAdd->cSeg                  =  (Row[6][0]);
                                strncpy(pHashAdd->SprdSecMstr[i].sOptionType,Row[7],DB_OPT_TYPE_LEN);
                                strncpy(pRes->SpreadArray[i].sOptionType,Row[7],OPT_TYPE_LEN);
                                HASH_ADD(hDrvSecHndlr,HashSprDrvID,sKey,strlen(pHashAdd->sKey),pHashAdd);
                                mysql_close(DBConSec);

                }
                else
                {
                        logDebug1("Security ID is not in Hash & in DB :%s:",sTempSecID);
                        mysql_close(DBConSec);
                        return FALSE;
                }

                }
        }
        logTimestamp("Exit : [fGetICEXSpreadSecDetails]");

        return TRUE;
}

BOOL    fAddDRVSecHash()
{
        logTimestamp("Entry : [fAddDRVSecHash]");
        MYSQL           *DBConSec;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32           iNumRow,i=0;
        CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR            sTempSecID[DB_SCRIP_CODE_LEN];

        DBConSec = DB_Connect();

        sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,SM_EXCH_SYMBOL,\
                        SM_INSTRUMENT_NAME,SM_STATUS,SM_EXCH_STATUS,SM_PREOPEN_FLAG,\
                        SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,0),ifnull(SM_TICK_SIZE,0),ifnull(SM_LOT_SIZE,1),\
                        ifnull(SM_LOT_UNITS,1),IFNULL(SM_UPPER_LIMIT,0),IFNULL(SM_LOWER_LIMIT,0),SM_STRIKE_PRICE,SM_OPTION_TYPE,SM_UNDERLAYING_SCRIP_CODE,\
                        IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\'),NULL),IFNULL(NULL,DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m%%d\')),ifnull(SM_SYMBOL,'xyz'), \
                        JULIDATE(SM_EXPIRY_DATE),SM_CROSS_CUR_FLAG,SM_RBI_REFERENCE_RATE,IFNULL(SM_CUSTOM_SYMBOL,'NA'),ifnull(SM_EXCH_INSTRUMENT_TYPE,'N'),\
                        SM_FREEZE_QTY,IFNULL(SM_CURRENCY_MULTIPLIER,1),SM_INTEROPS_SCRIP,SM_INTEROPS_EXCH_SYMBOL,SM_NSE_SCRIP,SM_BSE_SCRIP ,SM_EXPIRY_FLAG FROM SECURITY_MASTER WHERE SM_STATUS = 'A'\
                        AND  (SM_SEGMENT = \"%c\" ) AND SM_EXCHANGE = \"%s\" ;",CURRENCY_SEGMENT,BSE_EXCH);

        logDebug1("sSelQuery :%s:",sSelQuery);

        if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
        {
                logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddDrvSecHash]");
                sql_Error(DBConSec);
                mysql_close(DBConSec);
                return FALSE;
        }

        Res = mysql_store_result(DBConSec);

        iNumRow = mysql_num_rows(Res);
        logDebug1("iNumRow :%i:",iNumRow);
        if(iNumRow == 0)
        {
                logFatal("Num Of Row Fetched :%d:",iNumRow);
                return FALSE;

        }

        struct SEC_MASTER_ARRAY *DrvSecHsh[iNumRow],*TempSec;

        while(Row = mysql_fetch_row(Res))
        {
		DrvSecHsh[i] = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));
                TempSec     = (struct SEC_MASTER_ARRAY  *)malloc(sizeof(struct SEC_MASTER_ARRAY));

                strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);


                HASH_FIND(hDrvSecHndlr,Hash_DrvID, &sTempSecID,strlen(sTempSecID),TempSec);

                if(TempSec == NULL)
                {
                        strncpy(DrvSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
                        strncpy(DrvSecHsh[i]->sScripCode,Row[1],DB_SCRIP_CODE_LEN);
                        strncpy(DrvSecHsh[i]->sExchScripCode,Row[2],DB_SCRIP_CODE_LEN);
                        strncpy(DrvSecHsh[i]->sSym,Row[3],DB_SYM_LEN);
                        strncpy(DrvSecHsh[i]->sInsName,Row[4],DB_INS_LEN);
                        DrvSecHsh[i]->cStatus = Row[5][0];
                        DrvSecHsh[i]->cExchStatus= Row[6][0];
                        DrvSecHsh[i]->cPreOpenFlag= Row[7][0];
                        DrvSecHsh[i]->cPreOpenExchFlag= Row[8][0];
                        DrvSecHsh[i]->cAlgoFlag= Row[10][0];
                        DrvSecHsh[i]->cCAFlag= Row[11][0];
                        strncpy(DrvSecHsh[i]->sLotUnits,Row[14],DB_LOT_UNITS_LEN);
                        DrvSecHsh[i]->fUpperLimit= atof(Row[15]);
                        DrvSecHsh[i]->fLowerLimit= atof(Row[16]);
                        DrvSecHsh[i]->fStrikePrice = atof(Row[17]);
                        strncpy(DrvSecHsh[i]->sOptType,Row[18],DB_SERIES_LEN);
                        strncpy(DrvSecHsh[i]->sUndScripCode,Row[19],DB_SCRIP_CODE_LEN);
                        strncpy(DrvSecHsh[i]->sMaturityDay,Row[20],MAT_DAY);
                        strncpy(DrvSecHsh[i]->sMaturityMonYr,Row[21],DB_DATETIME_LEN);
                        strncpy(DrvSecHsh[i]->sSymName,Row[22],DB_SYM_NAME_LEN);
                        DrvSecHsh[i]->fTickSize= atof(Row[12]);
                        DrvSecHsh[i]->fLotSize= atof(Row[13]);
                        DrvSecHsh[i]->iExpiryDate = atol(Row[23]);
                        DrvSecHsh[i]->cITSFlag= Row[24][0];
                        DrvSecHsh[i]->fMcxLot = atof(Row[25]);
                        strncpy(DrvSecHsh[i]->sCustomSym,Row[26],CUSTOM_SYM_LEN);
                        DrvSecHsh[i]->iFaceValue= atof(Row[28]);
                        DrvSecHsh[i]->fMcxMutliplier = atof(Row[29]);

                        strncpy(DrvSecHsh[i]->sIntropScripCode,Row[30],DB_SECURITY_ID_LEN)  ;
                        strncpy(DrvSecHsh[i]->sIntropSymbol,Row[31],DB_SYM_LEN)             ;
                        strncpy(DrvSecHsh[i]->sNseScripCode,Row[32],DB_SECURITY_ID_LEN)     ;
                        strncpy(DrvSecHsh[i]->sBseScripCode,Row[33],DB_SECURITY_ID_LEN)     ;

                        strncpy(DrvSecHsh[i]->sSmExpiryFlag,Row[34],DB_EXPIRY_FLAG_LEN);

                        HASH_ADD(hDrvSecHndlr,Hash_DrvID,sScripCode,strlen(DrvSecHsh[i]->sScripCode),DrvSecHsh[i]);
                        i++;	
		 }



        }
        logTimestamp("Exit : [fAddDRVSecHash]");

        mysql_close(DBConSec);
        return TRUE;
}
