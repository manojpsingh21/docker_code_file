#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"


LONG32	iRDaemonToOffPump;
LONG32	iOffPumpToOrdRtr;

MYSQL	*DBOffConn;
LONG32   iCount = 0;
main (LONG32 argc,CHAR *argv)
{
	setbuf(stdout,0);
	setbuf(stdin,0);

	DBOffConn = DB_Connect();

	OpenMsgQue();

	PumpOffOrd();	

}

BOOL	PumpOffOrd()
{
	logTimestamp("Entry : [PumpOffOrd]");

	CHAR	sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	struct  INT_COMMON_REQUEST_HDR *pIntHeadr;		
	CHAR	cSegment;

	while(TRUE)	
	{
		memset(&sRcvMsg,'\0',RUPEE_MAX_PACKET_SIZE);
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if(ReadMsgQ(iRDaemonToOffPump,&sRcvMsg,RUPEE_MAX_PACKET_SIZE,1) == ERROR)
		{
			logFatal("Error : MsgID is %d ",iRDaemonToOffPump);
			perror("This is error ");
			exit(ERROR);
		}	

		pIntHeadr = (struct  INT_COMMON_REQUEST_HDR *)&sRcvMsg;

		cSegment = pIntHeadr->cSegment;
		logDebug2("cSegment :%c:",cSegment);		

		if(cSegment == EQUITY_SEGMENT)
		{
			logDebug1("THIS IS EQUITY ");
			if(DisableOffMkt(pIntHeadr) == FALSE)
			{
				logFatal("Error : DisableOffMkt Equity");
				return FALSE;
			} 		
			logDebug3("Success : DisableOffMkt Equity");

			if(EquPumpOffOrd(pIntHeadr) == FALSE)	
			{
				logFatal("Error : EquPumpOffOrd Equity");
				return FALSE;
			}	
			logDebug3("Success : EquPumpOffOrd Equity");

			if(UpdtOffMktBP(pIntHeadr) == FALSE)	
			{
				logFatal("Error : UpdtOffMktBP Equity");
				return FALSE;
			}	
			logDebug3("Success : UpdtOffMktBP Equity");
			sleep(1);
			if(EnableOffMkt(pIntHeadr) == FALSE)	
			{
				logFatal("Error : EnableOffMkt Equity");
				return FALSE;
			}	
			logDebug3("Success : EnableOffMkt Equity");

		}
		else if((cSegment == DERIVATIVE_SEGMENT) || (cSegment == CURRENCY_SEGMENT))
		{
			logDebug1("THIS IS DERIVATIVE ");
			if(DisableOffMkt(pIntHeadr) == FALSE)
			{
				logFatal("Error : DisableOffMkt Derivative");
				return FALSE;
			}
			logDebug3("Success : DisableOffMkt Derivative");

			if(DrvPumpOffOrd(pIntHeadr) == FALSE)
			{
				logFatal("Error : DrvPumpOffOrd Derivative");
				return FALSE;
			}
			logDebug3("Success : EquPumpOffOrd Derivative");

			if(UpdtOffMktBP(pIntHeadr) == FALSE)
			{
				logFatal("Error : UpdtOffMktBP Derivative");
				return FALSE;
			}
			logDebug3("Success : UpdtOffMktBP Derivative");
			sleep(1);
			if(EnableOffMkt(pIntHeadr) == FALSE)
			{
				logFatal("Error : EnableOffMkt Derivative");
				return FALSE;
			}
			logDebug3("Success : EnableOffMkt Derivative");

		}
		else if(cSegment == COMMODITY_SEGMENT)
		{

			logDebug1("THIS IS COMMODITY");
			if(DisableOffMkt(pIntHeadr) == FALSE)
			{
				logFatal("Error : DisableOffMkt Commodity");
				return FALSE;
			}
			logDebug3("Success : DisableOffMkt Commodity");

			if(CommPumpOffOrd(pIntHeadr) == FALSE)
			{
				logFatal("Error : CommPumpOffOrd Commodity");
				return FALSE;
			}
			logDebug3("Success : CommPumpOffOrd Commodity");

			if(UpdtOffMktBP(pIntHeadr) == FALSE)
			{
				logFatal("Error : UpdtOffMktBP Commodity");
				return FALSE;
			}
			logDebug3("Success : UpdtOffMktBP Commodity");

			if(EnableOffMkt(pIntHeadr) == FALSE)
			{
				logFatal("Error : EnableOffMkt Commodity");
				return FALSE;
			}
			logDebug3("Success : EnableOffMkt Commodity");

		}	
		else
		{
			logFatal("Invalid Segment :%c:",cSegment);
			return FALSE;
		}


	}
	logTimestamp("Exit : [PumpOffOrd]");		
}

BOOL	UpdtOffMktBP(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR	*sFnQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32          iSeqNo, iStatus;
	iSeqNo = 1;
	sprintf(sFnQuery,"SELECT BP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\"OFFMKT_PUMP\",%d);",pOrdReq->sExcgId,pOrdReq->cSegment,iSeqNo);	

	logDebug2("sFnQuery :%s:",sFnQuery);

	if(mysql_query(DBOffConn,sFnQuery) != SUCCESS)
	{
		sql_Error(DBOffConn);
		return FALSE;
	}
	else
	{
		Res = mysql_store_result(DBOffConn);
		Row = mysql_fetch_row(Res);
		iStatus = atoi(Row[0]);	
		logDebug2("BP_UPDATE Response :%d:",iStatus);
		mysql_commit(DBOffConn);
		return TRUE;
	}		

}	

BOOL	DisableOffMkt(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{
	CHAR	*sUpDtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	INT16	iMktNo =1;

	sprintf(sUpDtQry,"UPDATE BATCH_PROCESS b \
			SET b.BP_OFF_MKT_STATUS = \'N\' \
			WHERE 	b.BP_EXCH_ID = LTRIM(RTRIM(\"%s\"))\
			AND	b.BP_SEGMENT = \'%c\' \
			AND	b.BP_MKT_TYPE_NO = %d \
			AND	b.BP_BATCH_NAME = \'OFFMKT_PUMP\';",pOrdReq->sExcgId,pOrdReq->cSegment,iMktNo);	

		logDebug3("sUpDtQry :%s:",sUpDtQry);

	if(mysql_query(DBOffConn,sUpDtQry) != SUCCESS)
	{
		sql_Error(DBOffConn);
		return FALSE;	
	}
	else
	{
		mysql_commit(DBOffConn);	
		return TRUE;	
	}
}	

BOOL    EnableOffMkt(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{
	CHAR    *sUpDtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	INT16   iMktNo =1;
	logDebug2("Enabling Off market");
	sprintf(sUpDtQry,"UPDATE BATCH_PROCESS  \
			SET BP_OFF_MKT_STATUS = \'Y\' \
			WHERE   BP_EXCH_ID = LTRIM(RTRIM(\"%s\"))\
			AND     BP_SEGMENT = \'%c\' \
			AND     BP_MKT_TYPE_NO = %d \
			AND     BP_BATCH_NAME = \'OFFMKT_PUMP\';",pOrdReq->sExcgId,pOrdReq->cSegment,iMktNo);

	logDebug3("sUpDtQry :%s:",sUpDtQry);

	if(mysql_query(DBOffConn,sUpDtQry) != SUCCESS)
	{
		sql_Error(DBOffConn);
		return FALSE;
	}
	else
	{
		mysql_commit(DBOffConn);
		return TRUE;
	}
}

BOOL EquPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pEOrdReq;


	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\	
			EQ_STRATEGY_ID \
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS = \'C\'\
			AND     A.EQ_MSG_CODE IN (5112,5113)\
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO)\
			AND     A.EQ_EXCH_ID = \"%s\" ;",pCnlEOrd->sExcgId);
	logDebug2("sSelQry :%s:",sSelQry);
	if(mysql_query(DBOffConn,sSelQry) != SUCCESS)
	{
		sql_Error(DBOffConn);
		exit(ERROR);
	}

	Res = mysql_store_result(DBOffConn);

	while(Row = mysql_fetch_row(Res))
	{
		memset(&pEOrdReq , '\0',sizeof(struct ORDER_REQUEST)); 
		strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
		logDebug2("pEOrdReq.ReqHeader.sExcgId :%s:",pEOrdReq.ReqHeader.sExcgId);
		pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
		pEOrdReq.ReqHeader.cSource= Row[22][0];
		pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
		pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
		strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
		strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
		strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
		pEOrdReq.cProductId= Row[23][0];
		pEOrdReq.cBuyOrSell = Row[7][0];
		pEOrdReq.iOrderType = atoi(Row[16]);
		pEOrdReq.iOrderValidity = atof(Row[15]);
		pEOrdReq.iTotalQty = atoi(Row[8]);
		pEOrdReq.iTotalQtyRem = atoi(Row[9]);
		pEOrdReq.iDiscQty = atoi(Row[10]);
		pEOrdReq.iDiscQtyRem = atoi(Row[11]);
		pEOrdReq.iTotalTradedQty = atoi(Row[12]);
		pEOrdReq.fPrice = atof(Row[13]);
		pEOrdReq.fTriggerPrice = atof(Row[14]);
		pEOrdReq.fOrderNum = atof(Row[0]);
		pEOrdReq.iSerialNum = atoi(Row[1])+1;
		pEOrdReq.cHandleInst ='1';
		pEOrdReq.iStratergyId= atoi(Row[26]);
		pEOrdReq.cOffMarketFlg = 'N';
		pEOrdReq.cProCli = Row[19][0];
		pEOrdReq.cUserType = Row[20][0];
		strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
		pEOrdReq.ReqHeader.cSegment = Row[25][0];

		if(strcmp(Row[3],"NL")== 0)
		{
			pEOrdReq.iMktType = NORMAL_MARKET;
		}
		else if(strcmp(Row[3],"OL") == 0)
		{
			pEOrdReq.iMktType = ODDLOT_MARKET;
		}
		else if(strcmp(Row[3],"SP")== 0)
		{
			pEOrdReq.iMktType = SPOT_MARKET;
		}
		else if(strcmp(Row[3],"AU") == 0)
		{
			pEOrdReq.iMktType = AUCTION_MARKET;
		}
		else
		{
			logDebug2(" %s ",Row[3]);
		}
		logDebug2("Writing to Queue for Order Number :%f:",pEOrdReq.fOrderNum);
		if(WriteMsgQ(iOffPumpToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
		{
			perror("Error WriteMsgQ");
			mysql_free_result(Res);
			mysql_close(DBOffConn);
			exit(ERROR);
		}


	}
	return TRUE;


}

BOOL DrvPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pDOrdReq;


	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE, \
			DRV_STRATEGY_ID ,\				
			DRV_SEGMENT , \
			DRV_ORDER_OFFON \
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'C\'\
			AND     A.DRV_MSG_CODE IN (5112,5113)\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
			AND     A.DRV_EXCH_ID = \"%s\" ;",pCnlEOrd->sExcgId);
	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DBOffConn,sSelQry) != SUCCESS)
	{
		sql_Error(DBOffConn);
		exit(ERROR);
	}

	Res = mysql_store_result(DBOffConn);

	while(Row = mysql_fetch_row(Res))
	{
		memset(&pDOrdReq, '\0', sizeof(struct ORDER_REQUEST));
		pDOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
		pDOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
		strncpy(pDOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
		pDOrdReq.ReqHeader.iUserId = atoi(Row[17]);
		pDOrdReq.ReqHeader.cSource= Row[22][0];
		pDOrdReq.ReqHeader.cSegment = Row[26][0];

		strncpy(pDOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
		strncpy(pDOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
		logDebug2("Entity Id is :%s: ",pDOrdReq.sEntityId);	
		strncpy(pDOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


		pDOrdReq.cProductId= Row[23][0];
		pDOrdReq.cBuyOrSell = Row[7][0];
		pDOrdReq.iOrderType = atoi(Row[16]);
		pDOrdReq.iOrderValidity = atof(Row[15]);
		pDOrdReq.iTotalQty = atoi(Row[8]);
		pDOrdReq.iTotalQtyRem = atoi(Row[9]);
		pDOrdReq.iDiscQty = atoi(Row[10]);
		pDOrdReq.iDiscQtyRem = atoi(Row[11]);
		pDOrdReq.iTotalTradedQty = atoi(Row[12]);
		pDOrdReq.fPrice = atof(Row[13]);
		pDOrdReq.fTriggerPrice = atof(Row[14]);
		pDOrdReq.fOrderNum = atof(Row[0]);
		pDOrdReq.iSerialNum = atoi(Row[1])+1;
		pDOrdReq.cHandleInst = '1';
		pDOrdReq.iStratergyId= atoi(Row[25]);
		pDOrdReq.cOffMarketFlg= Row[27][0];

		pDOrdReq.cProCli = Row[19][0];
		pDOrdReq.cUserType = Row[20][0];
		strncpy(pDOrdReq.sRemarks ,Row[21],REMARKS_LEN);

		if(strcmp(Row[3],"NL")== 0)
		{
			pDOrdReq.iMktType = NORMAL_MARKET;
		}
		else if(strcmp(Row[3],"OL") == 0)
		{
			pDOrdReq.iMktType = ODDLOT_MARKET;
		}
		else if(strcmp(Row[3],"SP")== 0)
		{
			pDOrdReq.iMktType = SPOT_MARKET;
		}
		else if(strcmp(Row[3],"AU") == 0)
		{
			pDOrdReq.iMktType = AUCTION_MARKET;
		}
		else
		{
			logDebug2(" %s ",Row[3]);
			return FALSE;
		}

		logDebug2("Writing to Queue for Order Number :%f:",pDOrdReq.fOrderNum);
		logDebug2("Market Type is :%d:",pDOrdReq.iMktType);
		if(WriteMsgQ(iOffPumpToOrdRtr,(CHAR *)&pDOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
		{
			perror("Error WriteMsgQ");
			mysql_free_result(Res);
			mysql_close(DBOffConn);
			exit(ERROR);
		}


	}
	return TRUE;

}


BOOL CommPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pEOrdReq;


	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE ,\
			COMM_STRATEGY_ID ,\
			COMM_SEGMENT ,\
			COMM_ORDER_OFFON ,\
			COMM_MKT_TYPE ,\
			COMM_USER_TYPE \
			FROM    COMM_ORDERS A\
			WHERE   A.COMM_STATUS = \'C\'\
			AND     A.COMM_MSG_CODE IN (5112,5113)\
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO)\
			AND     A.COMM_EXCH_ID = \"%s\" ;",pCnlEOrd->sExcgId);
	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DBOffConn,sSelQry) != SUCCESS)
	{
		sql_Error(DBOffConn);
		exit(ERROR);
	}

	Res = mysql_store_result(DBOffConn);

	while(Row = mysql_fetch_row(Res))
	{
		memset(&pEOrdReq, '\0',sizeof(struct ORDER_REQUEST));
		pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
		pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
		strncpy(pEOrdReq.ReqHeader.sExcgId,Row[3],EXCHANGE_LEN);
		pEOrdReq.ReqHeader.iUserId = atoi(Row[16]);
		pEOrdReq.ReqHeader.cSource= Row[20][0];
		pEOrdReq.ReqHeader.cSegment = Row[24][0];

		strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
		strncpy(pEOrdReq.sEntityId,Row[4],ENTITY_ID_LEN);
		strncpy(pEOrdReq.sClientId,Row[5],CLIENT_ID_LEN);


		pEOrdReq.cProductId= Row[21][0];
		pEOrdReq.cBuyOrSell = Row[6][0];
		pEOrdReq.iOrderType = atoi(Row[15]);
		pEOrdReq.iOrderValidity = atof(Row[14]);
		pEOrdReq.iTotalQty = atoi(Row[7]);
		pEOrdReq.iTotalQtyRem = atoi(Row[8]);
		pEOrdReq.iDiscQty = atoi(Row[9]);
		pEOrdReq.iDiscQtyRem = atoi(Row[10]);
		pEOrdReq.iTotalTradedQty = atoi(Row[11]);
		pEOrdReq.fPrice = atof(Row[12]);
		pEOrdReq.fTriggerPrice = atof(Row[13]);
		pEOrdReq.fOrderNum = atof(Row[0]);
		pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
		pEOrdReq.cHandleInst = '1';
		pEOrdReq.iStratergyId= atoi(Row[23]);
		pEOrdReq.cOffMarketFlg= Row[25][0];
		pEOrdReq.cProCli = Row[18][0];
		pEOrdReq.cUserType = Row[27][0];
		strncpy(pEOrdReq.sRemarks ,Row[19],REMARKS_LEN);

		if(strcmp(Row[26],"NL")== 0)
		{
			pEOrdReq.iMktType = NORMAL_MARKET;
		}
		else if(strcmp(Row[26],"OL") == 0)
		{
			pEOrdReq.iMktType = ODDLOT_MARKET;
		}
		else if(strcmp(Row[26],"SP")== 0)
		{
			pEOrdReq.iMktType = SPOT_MARKET;
		}
		else if(strcmp(Row[26],"AU") == 0)
		{
			pEOrdReq.iMktType = AUCTION_MARKET;
		}
		else
		{
			logDebug2(" %s ",Row[26]);
			return FALSE;
		}

		if(WriteMsgQ(iOffPumpToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
		{
			perror("Error WriteMsgQ");
			mysql_free_result(Res);
			mysql_close(DBOffConn);
			exit(ERROR);
		}


	}
	return TRUE;

}




void 	OpenMsgQue()
{
	logTimestamp("Entry : [OpenMsgQue]");

	if((iOffPumpToOrdRtr= OpenMsgQ(RelToOrdRtr)) == ERROR)
	{
		logFatal("OpenMsgQ ...OffPumperToOrdRtr");
		exit(ERROR);
	}
	logInfo("OffPumperToOrdRtr opened successfully with id = %d", iOffPumpToOrdRtr);

	if((iRDaemonToOffPump= OpenMsgQ(RDaemonToOffPump)) == ERROR)
	{
		logFatal("OpenMsgQ ...RDaemonToOffPump");
		exit(ERROR);
	}
	logInfo("RDaemonToOffPump opened successfully with id = %d", iRDaemonToOffPump);

	logTimestamp("Exit : [OpenMsgQue]");
}

