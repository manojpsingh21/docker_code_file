#include "IPCS.h"


BOOL fNotifyExchStatus(SHORT iFlag)
{
	logTimestamp("fNotifyExchStatus [ENTRY]");
	LONG32 	iStatus = 0 ;
	
	CHAR	sUrl[100];
	CHAR	sMsg[100];
	CHAR	sBrokerId[ENV_VARIABLE_LEN];
	
	memset(sUrl,'\0',100);
	memset(sMsg,'\0',100);
	strncpy(sUrl,getenv("GM_IP"),100);
	strncpy(sBrokerId,getenv("BROKER_ID"),ENV_VARIABLE_LEN);

	CHAR sCmd[COMMAND_LEN];
	memset(sCmd,'\0',COMMAND_LEN);
	
	CHAR sBody[COMMAND_LEN];
	memset(sBody,'\0',COMMAND_LEN);

	switch(iFlag)
        {
		case NSE_EQU_UP:
			iStatus = 1;
			strncpy(sMsg,"NSE-E",100);
			break;
		case NSE_EQU_DOWN:
			iStatus = 0;
			strncpy(sMsg,"NSE-E",100);
			break;
		case NSE_DRV_UP:
			iStatus = 1;
			strncpy(sMsg,"NSE-D",100);
			break;
		case NSE_DRV_DOWN:
			iStatus = 0;
			strncpy(sMsg,"NSE-D",100);
			break;
		case BSE_EQU_UP:
			iStatus = 1;
			strncpy(sMsg,"BSE-E",100);
			break;
		case BSE_EQU_DOWN:
			iStatus = 0;
			strncpy(sMsg,"BSE-E",100);
			break;
		case BSE_DRV_UP:
			iStatus = 1;
			strncpy(sMsg,"BSE-D",100);
			break;
		case BSE_DRV_DOWN:
			iStatus = 0;
			strncpy(sMsg,"BSE-D",100);
			break;
		case BSE_CUR_UP:
			iStatus = 1;
			strncpy(sMsg,"BSE-C",100);
			break;
		case BSE_CUR_DOWN:
			iStatus = 0;
			strncpy(sMsg,"BSE-C",100);
			break;
		case NSE_CUR_UP:
			iStatus = 1;
			strncpy(sMsg,"NSE-C",100);
			break;
		case NSE_CUR_DOWN:
			iStatus = 0;
			strncpy(sMsg,"NSE-C",100);
			break;
		case MCX_UP:
			iStatus = 1;
			strncpy(sMsg,"MCX-M",100);
			break;
		case MCX_DOWN:
			iStatus = 0;
			strncpy(sMsg,"MCX-M",100);
			break;
		case NSE_CM_UP:
                        iStatus = 1;
                        strncpy(sMsg,"NSE-CM",100);
                        break;
                case NSE_CM_DOWN:
                        iStatus = 0;
                        strncpy(sMsg,"NSE-CM",100);
                        break;
		default:
			logDebug2("\nWrong transcode supplied");
			return FALSE;
			break;
	}

	
	sprintf(sBody,"?id=%s&msg=%s&type=2&status=%d&val=",sBrokerId,sMsg,iStatus);

	sprintf(sCmd,"curl -i  \"%s%s\"",sUrl,sBody);
	logDebug2("Command -> %s",sCmd);
	system(sCmd);
	logTimestamp("fNotifyExchStatus [EXIT]");
	return TRUE;
}

void NotifyProcMonTool(struct  ProcessMonitor *ProcessMonitor, BOOL Status)
{
	logTimestamp("NotifyProcMonTool [ENTRY]");
	CHAR sCmd[200];
	memset(sCmd,'\0',200);
	CHAR sBody[100];
	memset(sBody,'\0',100);
	CHAR sVal[50];
	memset(sVal,'\0',50);
	LONG32	MaxSelfRetry = atoi(getenv("MAX_AUTO_RETRY"));
	CHAR	sUrl[100];
	CHAR	sBrokerId[ENV_VARIABLE_LEN];
	memset(sUrl,'\0',100);
	strncpy(sUrl,getenv("GM_IP"),100);
	strncpy(sBrokerId,getenv("BROKER_ID"),ENV_VARIABLE_LEN);

	sprintf(sVal,"%d~%d",MaxSelfRetry,ProcessMonitor->iAttempts);
	sprintf(sBody,"?id=%s&msg=%s&type=1&status=%d&val=%s",sBrokerId,ProcessMonitor->sProcessName,Status,sVal);

	sprintf(sCmd,"curl -i \"%s%s\"",sUrl,sBody);
	logDebug2("Command -> %s",sCmd);
	system(sCmd);
	logTimestamp("NotifyProcMonTool [EXIT]");
	return TRUE;
}


