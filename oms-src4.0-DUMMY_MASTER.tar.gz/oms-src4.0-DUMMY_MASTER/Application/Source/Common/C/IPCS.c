# include "IPCS.h"
# include <string.h>
# include <errno.h>
# include <sys/ipc.h>
# include <sys/msg.h>
# include <stdio.h>
# include <sys/types.h>


struct my_msg {
	long   msg_type;
	char  msg[MAX_MESSAGE_SIZE];
}; 

int ReadMsgQ(int md,char *MemBuf ,int MsgLength,long MsgType)
{
	struct            my_msg my_msg1;
	int               test;

	if (MemBuf == NULL )
	{
		return(ERROR);
	}
	memset(my_msg1.msg,NULL,MAX_MESSAGE_SIZE);

	my_msg1.msg_type = MsgType;

	logDebug2("In Read MsgQueueue MessageType  == %d,   md == %d   RUPEE_MAX_PACKET_SIZE = %d MAX_MESSAGE_SIZE = %d   ", MsgType, md, RUPEE_MAX_PACKET_SIZE,MAX_MESSAGE_SIZE);
	
	
	test = msgrcv(md, (void *)&my_msg1,MsgLength,MsgType,!IPC_NOWAIT);
	if ( test < 0)
	{
		perror(" msgrcv in ReadMsgQ failed :");
		return(ERROR);
	}

	
	memcpy(MemBuf,my_msg1.msg,MsgLength);
	return(TRUE);
}

int WriteMsgQ(int md , char *MemBuf,int MsgLength,long MsgType)
{
	struct          my_msg my_msg1;
	int             test;

	if (MemBuf == NULL )
	{
		return(ERROR);
	}
	memset(my_msg1.msg,NULL,MAX_MESSAGE_SIZE);
	memcpy(my_msg1.msg,MemBuf,MsgLength);
	my_msg1.msg_type = MsgType;
	test = msgsnd(md,(void *) &my_msg1,MsgLength,!IPC_NOWAIT);
	printf("\n\n---Written succesfully to the Q = %d msgtype=%d MsgLength=%d\n",md,MsgType,MsgLength);
	if(test < 0)
	{
		perror("msgsnd in WriteMsgQ failed : ");
		return(ERROR);
	}
	return(TRUE);
}

int CreateMsgQueue(key_t key ,int SizeOfMem )
{
	int                       md;
	struct msqid_ds           str_ds;

	str_ds.msg_perm.uid = getuid();
	str_ds.msg_perm.gid = getgid();
	str_ds.msg_perm.mode = 0666;
	str_ds.msg_qbytes = SizeOfMem;
	md = msgget(key,IPC_CREAT);
	msgctl(md,IPC_SET,&str_ds);
	if(md < 0 )
	{
		logPError ("CreateMsgQueue:msgctl:%d:",md);	
		return(ERROR);
	}
	return(md);
} 


int OpenMsgQ( key_t key)
{
	int              md;

	md = msgget(key,!IPC_CREAT);
	if( md < 0 )
	{
		perror( "OpenMsgQ : ");
		printf("md  = %d",md);
		return(ERROR);
	}
	return(md);
}


int CreateSharedMemory( key_t key , size_t SizeOfMem )
{
	int shmidH;

	if( ( shmidH = shmget( key, SizeOfMem , PERMS| IPC_CREAT ) ) < 0 )
	{
		perror("shmget() in ShamemCreate(): ");
		return(ERROR);
	}
	if( semget( key , 1 , IPC_CREAT | PERMS )< 0)
	{
		perror("semget:");
		return(ERROR);
	}
	return TRUE;
}

int CreateSharedMemory1( key_t key , int SizeOfMem )
{
	int shmidH;

	if( ( shmidH = shmget( key, SizeOfMem , PERMS1 | IPC_CREAT ) ) < 0 )
	{
		perror("shmget() in ShamemCreate(): ");
		return(ERROR);
	}
	if( semget( key , 1 , IPC_CREAT | PERMS1 )< 0)
	{
		perror("semget:");
		return(ERROR);
	}
	return TRUE;
}

int SemophoreCreate( key_t key )
{
	int shmidH;

	if( semget( key , 1 , IPC_CREAT | PERMS )< 0)
	{
		perror("semget:");
		return(ERROR);
	}
	return TRUE;
}

void *OpenSharedMemory( key_t key , int SizeOfMem  )
{
	int          shmidH;
	char       * shmaddr;
	/*	int        * ret_val;*/
	int         ret_val;

	/*	ret_val = (int *)malloc(sizeof(int));*/
	ret_val = ERROR;
	if( ( shmidH = shmget( key , SizeOfMem , 0 ) ) < 0 )
	{
		perror("shmget() in OpenSharedMemory(): ");
		printf("%d \n",errno);
		return((void *)&ret_val);
	}

	//printf("\n shmidH :%d:",shmidH);
	shmaddr =  shmat( shmidH , (char * )0 , 0 );
	if(shmaddr==(char *)-1) 
	{
		perror("shmat :");
		return((void *)&ret_val);
	}
	return (void *) shmaddr;
}

int CloseSharedMemory( void * shmaddr )
{
	if( shmdt( shmaddr) < 0 )
	{
		perror("shdt :");
		return(ERROR);
	}

	return TRUE;
}

int LockShm( key_t key )
{
	int            fd;
	/*	FILE *fp;*/
	static  struct sembuf op_lock[2] =
	{
		0 , 0 , 0 ,
		0 , 1 , SEM_UNDO 
	};

	fd = semget( key , 1 , 0 );
	if (fd < 0)
	{
		printf("\n Error ");
		perror("semget:");
		return(ERROR);
	}
	if( semop( fd , &op_lock[0] , 2 ) < 0 )
	{
		printf("\n Error ");
		perror("\n semop lock  error \n");
		return(ERROR);
	}
	/***
	  fp = fopen("LockChecckStatus","a+");
	  if(fp==NULL)
	  {
	  printf("\nCannot Open The file LockChecckStatus");
	  exit(1);
	  }
	  else
	  {
	  fprintf(fp,"\n Key == %d,process == %d",key,getpid());	
	  fclose(fp);
	  }
	 *****/	
}



int UnLockShm( key_t key )
{
	int             fd;
	static struct sembuf op_ulock[1] =
	{
		0 , -1 , ( IPC_NOWAIT  | SEM_UNDO )
	};

	fd = semget( key , 1 , 0 );
	if (fd < 0)
	{
		printf("\n UnLockShm:semget error");
		perror("semget:");
		return(ERROR);
	}
	if( semop( fd , &op_ulock[0] , 1 ) < 0 )
	{
		printf("\n semop:Error " );
		perror("\n semop unlock error \n");
		return(ERROR);
	}
}

int DeleteLockShm( key_t key )
{
	int fd;

	fd = semget( key , 1 , 0 );
	if (fd < 0)
	{
		perror("semget:");
		return(ERROR);
	}
	fd =  semctl( fd , 1 , IPC_RMID  );
	if (fd < 0)
	{
		perror("semctl:");
		return(ERROR);
	}
}

int WaitShm( key_t key )    /** Will act as a read lock **/
{
	int fd;
	struct sembuf options ; 

	options.sem_num = 0 ;
	options.sem_op = 0 ;
	options.sem_flg = 0 ;

	fd = semget( key , 1 , 0 );
	if(fd < 0)
	{
		perror("semctl:");
		return(ERROR);
	}

	if( semop( fd , &options , 1 ) < 0 )
	{
		printf("\n semop:Error " );
		perror("\n semop wait error \n");
		return(ERROR);
	}

}

int DeleteMsgQ( key_t key )
{
	int fd;

	fd = msgget( key , !IPC_CREAT );
	if (fd < 0)
	{
		perror("Msgget:");
		return(ERROR);
	}
	fd =  msgctl( fd , IPC_RMID ,NULL );
	if (fd < 0)
	{
		perror("Msgctl:");
		return(ERROR);
	}
}



int DeleteShmMem( key_t key )
{
	int fd;

	fd = shmget( key , 0 , 0 );
	if (fd < 0)
	{
		perror("shmget:");
		return(ERROR);
	}
	fd =  shmctl( fd ,IPC_RMID ,NULL );
	if (fd < 0)
	{
		perror("shmctl:");
		return(ERROR);
	}
}

int ClearQ( int md,int key)
{
	struct            my_msg my_msg1;
	int               test;

	/**/

	FILE 		 *fpt ;
	char		 *filename;
	char		 *dirName="../QueueCache/Queue_Id." ;




	filename = (char *) malloc ( 100 );
	sprintf(filename,"%s%d",dirName, key);
	fpt = fopen (filename , "ab" );

	/**/

	for (;;)
	{

		memset(my_msg1.msg,NULL,MAX_MESSAGE_SIZE);
		my_msg1.msg_type = 0;

		test = msgrcv(md, (void *)&my_msg1,MAX_MESSAGE_SIZE,1,IPC_NOWAIT);

		if ( test < 0 && errno != ENOMSG)
		{
			perror(" msgrcv in ReadMsgQ failed :");
			return(ERROR);
		}
		if ( errno == ENOMSG )
		{
			break;
		}

		/**/

/*		else 
		{
			fwrite(my_msg1.msg ,MAX_MESSAGE_SIZE ,0 , fpt ); 
		}
	
*/	}
	/**/
	free (filename);
	fflush(fpt);
	fclose(fpt);
	/**/
	return(TRUE);
}

int ReadNBQ(int md,char *MemBuf ,int MsgLength,long MsgType)
{
	struct            my_msg my_msg1;
	int               test;

	if (MemBuf == NULL )
	{
		return(ERROR);
	}
	memset(my_msg1.msg,NULL,MAX_MESSAGE_SIZE);
	my_msg1.msg_type = MsgType;
	test = msgrcv(md, (void *)&my_msg1,MsgLength,MsgType,IPC_NOWAIT);


	if ( test < 0 &&  errno != ENOMSG )
	{
		perror(" msgrcv in ReadMsgQ failed :");
		return(ERROR);
	}

	if ( errno == ENOMSG )
	{
		perror("\nReadNBQ::No Mesg of desired type on mesg Q...\n");
		return(ERROR);
	}
	/**************
#ifdef     DBG
printf("ReadQ: RecvBuf:- %s",my_msg1.msg); 
#endif
	 *************/
	memcpy(MemBuf,my_msg1.msg,MsgLength);
	return(TRUE);
}

int AddProcessMem (char * ProgName,int ProcessId,char * MainProgName )
{
	struct ProcessMonitorArray * MemArray;
	int i;
	LONG32	UpdFlg = FALSE ;
	LockShm(ProcessMonitorShm);
	MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
	if( *((int *)MemArray) == ERROR )
	{
		perror ("\n AddProcessMem");
		UnLockShm(ProcessMonitorShm);
		return(ERROR);
	}
	for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
	{
		if (strcmp(MemArray->ProcessMonitor[i].sProcessName,ProgName) == 0 )
		{
			MemArray->ProcessMonitor[i].iProcessId = ProcessId;
			UpdFlg = TRUE ;
			break;
		}
	}
	if ( UpdFlg == FALSE )
	{
		printf("\n Process not in memory so inserting");
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			if (MemArray->ProcessMonitor[i].iProcessId == UNUSED)
			{
				printf("\n  MainProgName :%s:",MainProgName );
				printf("\n ProgName :%s:",ProgName );
				strcpy(MemArray->ProcessMonitor[i].sMainProcessName,MainProgName);
				strcpy(MemArray->ProcessMonitor[i].sProcessName,ProgName);
				MemArray->ProcessMonitor[i].iProcessId = ProcessId;
				MemArray->ProcessMonitor[i].iAttempts = 0 ;
				MemArray->ProcessMonitor[i].cRecoveryFlag = 'X';
				MemArray->ProcessMonitor[i].iStartTime = 0;
				MemArray->ProcessMonitor[i].iEndTime = 235959 ;		
				break;
			}
		}
	}
	if ((CloseSharedMemory(MemArray)) == ERROR )
	{
		logPError ("CloseSharedMemory:");
		exit(1);
	}
	UnLockShm(ProcessMonitorShm);
	return(TRUE);
}

int DeleteProcessMem ( int ProcessId, struct ProcessMonitorArray * MemArray )
{
	int i;
	for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
	{
		if (MemArray->ProcessMonitor[i].iProcessId == ProcessId )
		{
			MemArray->ProcessMonitor[i].iProcessId = UNUSED;
			break;
		}
	}
	return(TRUE);
}
int CheckProcessMem ( char * ProgName )
{
	struct ProcessMonitorArray * MemArray;
	int i;
	LockShm(ProcessMonitorShm);
	MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
	if( *((int *)MemArray) == ERROR )
	{
		logPError ("CheckProcessMem:");
		UnLockShm(ProcessMonitorShm);
		return(ERROR);
	}
	for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
	{
		if ((strcmp(MemArray->ProcessMonitor[i].sProcessName,ProgName) == 0 ) && MemArray->ProcessMonitor[i].iProcessId != UNUSED)
		{
			if ((CloseSharedMemory(MemArray)) == ERROR )
			{
				logPError ("CloseSharedMemory:");
				exit(1);
			}
			UnLockShm(ProcessMonitorShm);
			return (0);
		}
	}
	if ((CloseSharedMemory(MemArray)) == ERROR )
	{
		logPError ("CloseSharedMemory:");
		exit(1);
	}
	UnLockShm(ProcessMonitorShm);
	return(1);
}

