#include <stdio.h>
#include <stdlib.h>
#include "IPCS.h"

#define EXCH_NSE        "NSE"
#define EXCH_BSE        "BSE"
#define EXCH_MCX        "MCX"
#define	 NO_OF_SEG     5


LONG32	iRDaemonToSqoff,iRDaemonToOffPump;
void    OpenMsgQue();
void main()
{
	struct  ORDER_REQUEST      pReq_SqOff;
	CHAR    sOMSExch[EXCHANGE_LEN];
	INT16	i,iMsgType,iChoice;
	LONG32  iSndId;
	CHAR    cMkt_Seg;
	OpenMsgQue();	
	printf("\n");
	printf("\nEnter 1 for Pumping SqOff and 2 for Pumping Offline\n");
	printf("\n->");
	scanf("%d",&iChoice);


	for(i=0;i<NO_OF_SEG;i++)
	{
		memset(&pReq_SqOff,'\0',sizeof(struct  ORDER_REQUEST));
		memset(sOMSExch,'\0',EXCHANGE_LEN);
		if(i == 0)
		{
			cMkt_Seg = SEGMENT_EQUITY;
			strncpy(sOMSExch,EXCH_BSE,EXCHANGE_LEN);
			iMsgType = 1;
		}
		else if(i == 1)
		{
			cMkt_Seg = SEGMENT_EQUITY;
			strncpy(sOMSExch,EXCH_NSE,EXCHANGE_LEN);
			iMsgType = 2;
		}
		else if(i == 2)
		{
			cMkt_Seg = SEGMENT_FNO;
			strncpy(sOMSExch,EXCH_NSE,EXCHANGE_LEN);
			iMsgType = 3;
		}
		else if( i == 3)
		{
			cMkt_Seg = SEGMENT_CURRENCY;
			strncpy(sOMSExch,EXCH_NSE,EXCHANGE_LEN);
			iMsgType = 1;
		}
		else if (i == 4)
		{
			cMkt_Seg = SEGMENT_COMMODITY;
			strncpy(sOMSExch,EXCH_MCX,EXCHANGE_LEN);
			iMsgType = 4;
		}
		if(iChoice == 1)
		{
			iSndId = iRDaemonToSqoff ;
			pReq_SqOff.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_INTRADAY_REQ;
		}
		else if(iChoice == 2)
		{
			iSndId = iRDaemonToOffPump;
			pReq_SqOff.ReqHeader.iMsgCode = TC_INT_PUMPOFFLINE_REQ;
			iMsgType =1;
		}
		else
		{
			printf("\n Invalid Input");
		}
		pReq_SqOff.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_SqOff.ReqHeader.cSegment = cMkt_Seg;
		pReq_SqOff.cUserType = 'A';

		strncpy(pReq_SqOff.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		logDebug2("[Id:%d] Triggering Offline Orders for :%s:%c:",i,sOMSExch,cMkt_Seg);
		if(WriteMsgQ(iSndId,(CHAR *)&pReq_SqOff,sizeof(struct ORDER_REQUEST),iMsgType )!= TRUE)  /*---Defined in Queue.c at coc---*/
		{	
			logFatal("Error WriteQ ");
			logDebug2("Write Q id %d",iSndId);
			exit(ERROR);
		}
	}
}	


void    OpenMsgQue()
{
	if((iRDaemonToOffPump = OpenMsgQ(RDaemonToOffPump)) == ERROR)
	{
		perror("\n OpenMsgQ ...RDaemonToOffPump");
		exit(ERROR);
	}

	if((iRDaemonToSqoff = OpenMsgQ(RDaemonToSqoff)) == ERROR)
	{
		perror("\n OpenMsgQ ...RDaemonToSqoff");
		exit(ERROR);
	}

}




