#include <stdio.h>
#include <stdlib.h>
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>
#include "DWSAdapter.h"

MYSQL           *DB_Conn;
MYSQL_RES       *Res;
MYSQL_ROW       Row;

LONG32  iAdminMsgsToRelDirQ;
LONG32  iOrdRtrToAdminMsg ;

main(int argc, char *argv[])
{
	logTimestamp("Entry in main");
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	fOpenMsgQue();

	DB_Conn = DB_Connect();

	fAdminBcastMsg(iOrdRtrToAdminMsg);
}

BOOL fAdminBcastMsg (LONG32 iRecvQ)
{
	logTimestamp("Entry [fAdminBcastMsg]");
	struct ADMIN_TO_USER_MSG_REQ *pReq;

	struct ADMIN_TO_USER_MSG_RES pRes;

	CHAR    RecBuff[RUPEE_MAX_PACKET_SIZE];

	LONG32 iRetVal = 0 ;

	while(TRUE)
	{
		memset(RecBuff , '\0', RUPEE_MAX_PACKET_SIZE);
		memset(pReq , '\0', sizeof(struct ADMIN_TO_USER_MSG_REQ));

		if((ReadMsgQ(iRecvQ,&RecBuff,RUPEE_MAX_PACKET_SIZE, 0)) != TRUE)
		{
			logFatal("Error : MsgQId is %d",iRecvQ);
			exit(ERROR);
		}

		pReq = (struct ADMIN_TO_USER_MSG_REQ *) &RecBuff;

		logDebug2("pReq->sClientId	:%s:",pReq->sClientId);
		logDebug2("pReq->sMsg		:%s:",pReq->sMsg);



		//		if(!strcmp(pReq->sClientId,SELECT_ALL))
		if(pReq->cMsgType == ALL )
		{
			logDebug2("Sending Message to All Clients & Dealers");
			fSendToAllUsers(pReq);

		}
		else
		{
			logDebug2("Sending to Selected users");
			fSendToSelctedUsers (pReq);	
		}
	}
}


BOOL    fSendToSelctedUsers (struct ADMIN_TO_USER_MSG_REQ *pReq)
{
	logTimestamp("ENTRY [fSendToSelctedUsers]");

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32		iNoOfCli = 0 ;
	LONG32		iRelayID = 0 ;
	LONG32		iUsercode = 0 ;

	CHAR   sSelQry [MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	struct ADMIN_TO_USER_MSG_RES pRes;

	logDebug2("pReq->iNoOfRecvClients :%d:",pReq->iNoOfRecvClients);
	strncpy(pRes.sMsg,pReq->sMsg,SEND_MSG_LEN);

	for(iNoOfCli = 0 ; iNoOfCli < pReq->iNoOfRecvClients ; iNoOfCli ++)
	{	


		logDebug2("pReq->iMaxNoOfClient[%d].sClientId :%d:",iNoOfCli,pReq->iMaxNoOfClient[iNoOfCli].sClientId);	
		sprintf(sSelQry,"SELECT USER_CODE from USER_MASTER  where USER_ENTITY_CODE = \"%s\" ; ",pReq->iMaxNoOfClient[iNoOfCli].sClientId);

		logDebug1("sSelQry :%s:",sSelQry);

		if(mysql_query(DB_Conn,sSelQry) != SUCCESS)
		{
			logSqlFatal("Err in select User Code Qyery");
			mysql_close(DB_Conn);
			return FALSE;
		}

		Res = mysql_store_result(DB_Conn);

		if(Row = mysql_fetch_row(Res))
		{
			if(Row[0] != NULL)
				iUsercode = atoi(Row[0]);
			else
				return FALSE;
		}
		iRelayID = find_user_adapter(iRelayID);
		logDebug2("iRelayID = %d",iRelayID);

		if((WriteMsgQ(iAdminMsgsToRelDirQ ,(CHAR *)&pRes, sizeof(struct ADMIN_TO_USER_MSG_RES),iRelayID)) != TRUE  )
		{
			logFatal("Error : failed while sending to Queue iOrdSrvToMapperNSEEQ");
			exit(ERROR);
		}
	}
	logTimestamp("EXIT [fSendToSelctedUsers]");
	return TRUE;

}	

BOOL fSendToAllUsers (struct ADMIN_TO_USER_MSG_REQ *pReq)
{
	logTimestamp("ENTRY [fSendToAllUsers]");

	struct ADMIN_ADAPTER_USER_ARRAY *Ptr ;

	struct ADMIN_TO_USER_MSG_RES pRes;
	LONG32  iCnt  = 0 ;

	strncpy(pRes.sMsg,pReq->sMsg,SEND_MSG_LEN);

	LockShm(AdminAdapterUserShm);

	Ptr     =       (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE);

	if (*((int *)Ptr) == ERROR )
	{
		logDebug2 (" Error in Opening Memory ");
		exit(ERROR);
	}

	for(iCnt =0;iCnt < MAX_STW_USERS;iCnt++)
	{
		if ((Ptr->admin_adap_user[iCnt].iRelayId !=UNUSED) && (Ptr->admin_adap_user[iCnt].ProcessId != UNUSED))
		{
			logDebug2(" UserId	:%.12",Ptr->admin_adap_user[iCnt].sUser);
			logDebug2(" RelayId	:%d:",Ptr->admin_adap_user[iCnt].iRelayId);
			logDebug2(" ProcessId	:%d:",Ptr->admin_adap_user[iCnt].ProcessId);
			logDebug2(" ClientId	:%s:",Ptr->admin_adap_user[iCnt].sClientId);
			logDebug2(" iCnt	:%d",iCnt);

			if((WriteMsgQ(iAdminMsgsToRelDirQ ,(CHAR *)&pRes, sizeof(struct ADMIN_TO_USER_MSG_RES), Ptr->admin_adap_user[iCnt].iRelayId)) != TRUE  )
			{
				logFatal("Error : failed while sending to Queue iOrdSrvToMapperNSEEQ");
				exit(ERROR);
			}

		}
	}

	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		logDebug2("Error In Closing SharedMemory ");
		exit(ERROR);
	}
	UnLockShm(AdminAdapterUserShm);
}

BOOL fOpenMsgQue ()
{

	if( ( iOrdRtrToAdminMsg  = OpenMsgQ( (OrdRtrToAdminMsg))) == ERROR )
	{
		perror("Open RelToQuery :");
		exit( 1 );
	}
	if( (  iAdminMsgsToRelDirQ = OpenMsgQ( (TrdRtrToRel))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	return TRUE;

}
