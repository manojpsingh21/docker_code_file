#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include "rdkafka.h"
#include "Defination.h"

#define LOCAL_MAX_PACKET_SIZE   2048
MYSQL	*DBConvDel;


//BOOL DBSelSerNo(CHAR cSegment,DOUBLE64 *fOrdNo,LONG32 *SrNo);

LONG32 	iOrderRoute2ConDel;
LONG32	iOrdSrvToTrdRtr;
SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen );
LONG32	iBranchId;
LONG32  iQty;

BOOL	FetchPostnSend(CHAR *sExchId,CHAR cSegment,CHAR cProd, CHAR *sClientID,CHAR *sSecId,struct CON_TO_DELIVERY_RESPONSE *pReq,BOOL iPositionType);
BOOL GetMktType(CHAR *sMktType,LONG32 iMktType);
CHAR    cRmsRejFlag = '\0';

BOOL    fLoadSysParam();
BOOL    fFetchErrStr(CHAR *sErrorID,CHAR *sErrString);
BOOL          iKafkaMsgFlag=FALSE;
rd_kafka_t *KfConn;
rd_kafka_t *KfConn1;
CHAR    sKafkaTopic[100];

main (int argc, char **argv)
{

	struct  INT_REQUEST_HEADER      *pReqHeader;
	memset(sKafkaTopic,'\0',100);

	setvbuf(stdout,NULL,_IONBF, 0 );
	setbuf(stdout,NULL);
	setbuf(stdin,NULL);
	DBConvDel = DB_Connect();
	
	if(getenv("KAFKA_NOTIFIER_FLAG")== NULL)
        {
                logFatal("Error : Environment variables missing : KAFKA_NOTIFIER_FLAG : setting as 0 ");
                iKafkaMsgFlag = FALSE;
        }
        else
        {
                iKafkaMsgFlag = atoi(getenv("KAFKA_NOTIFIER_FLAG"));
        }

	if(iKafkaMsgFlag == TRUE)
        {
                if((getenv("KAFKA_NOTIFY_TOPIC") != NULL ) && strlen(getenv("KAFKA_NOTIFY_TOPIC") ) != 0)
                {
                        strcpy(sKafkaTopic,getenv("KAFKA_NOTIFY_TOPIC") );
                        KfConn = KafkaConProducer(getenv("KAFKA_NOTIFY_TOPIC"));
                        KfConn1= KafkaConProducer(KF_OMS_COOKED_DATA);
                }
                else
                {
                        iKafkaMsgFlag = FALSE;
                }
        }

	fLoadSysParam();

	OpenMessageQueue();

	ReadMessage();
	

}/** END of main()***/

OpenMessageQueue()
{

	if((iOrderRoute2ConDel=OpenMsgQ(OrdRtrToCon2Del)) == ERROR)
	{
		perror("OpenMsgQ2 ...OrderRouterToConDel");
		exit(ERROR);
	}
	logDebug2("SucessFully Created OrdRtrToCon2Del key = %d iOrdRtrToCon2Del:%d:",OrdRtrToCon2Del,iOrderRoute2ConDel);
	if (( iOrdSrvToTrdRtr = OpenMsgQ ( OrdSrvToTrdRtr)) == ERROR)
	{
		perror("OpenMsgQ2 ...ParentToRelDirIORQ failed ");
		exit(ERROR);
	}
	logDebug2("SucessFully Created OrdSrvToTrdRtr key = %d iOrdSrvToTrdRtr:%d:",OrdSrvToTrdRtr,iOrdSrvToTrdRtr);

}/** END of OpenMessageQueue**/

BOOL ReadMessage()
{

	struct		CON_TO_DELIVERY_REQUEST *pCTDReq;
	struct		ORDER_REQUEST *pExpReq;
	struct		BO_ORDER_REQUEST *pBoExpReq;
	//struct		CO_ORDER_REQUEST *pCoExpReq;
	//struct		ORDER_REQUEST	*pCoExpReq;
	struct		SPAN_CALC_REQUEST *pSPCReq;
	struct		INT_COMMON_REQUEST_HDR	*pReqHeader;
	struct 		INT_COMMON_RESP_HDR 	pIntRespHdr;
	CHAR		sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	CHAR        	sErrMsg[ERROR_MESSAGE_LEN];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
//	CHAR 		sCnvtQuery[MAX_QUERY_SIZE+10]; //= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//CHAR 		*Pr_Query= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR 		sExpUpdQry[MAX_QUERY_SIZE]; //= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    	sRMSStatus[15];
	LONG32          iQty;
	LONG32          iError = 0;
	DOUBLE64        fAmount;
	DOUBLE64        fStart = 0.00;
	DOUBLE64        fEnd = 0.00;
	DOUBLE64        fTriggerPrice = 0.00;
	INT16 		iStatus = 0;
	CHAR		sMarketType[MARKET_LEN];
	CHAR		cProductId;
	CHAR		cSegment;
	CHAR		cBuyOrSell ;
	CHAR		cToProductId;
	LONG32		iMsgCode;
	CHAR		cTypeofOrd;
	LONG32		iTempOrdSerialNo;
	BOOL		iChkFlg;
	DOUBLE64	fTempOrdNo;
	LONG32		iTotal;
	LONG32		iLeg;
	CHAR		cFlag;
	CHAR		sEXCH[3];
	DOUBLE64	fsum;
	CHAR		sSpanCal[MAX_QUERY_SIZE];
	LONG32		iTempLeg = 0;
	CHAR		sErrorStrg[DB_REASON_DESC_LEN];
	LONG32		iTransCode;
	CHAR            sSecurityId[SECURITY_ID_LEN];
        CHAR            cBuySell = '\0';
        LONG32          iMkt = 0 ;


	while(1)
	{
		CHAR 		sCnvtQuery[MAX_QUERY_SIZE]; //= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		memset (&sRcvMsg,'\0' ,LOCAL_MAX_PACKET_SIZE);
		memset (sErrMsg,'\0' ,ERROR_MESSAGE_LEN);
		memset (sCnvtQuery,'\0' ,MAX_QUERY_SIZE);
		memset (sExpUpdQry,'\0' ,MAX_QUERY_SIZE);
		memset (sErrorStrg,'\0' ,DB_REASON_DESC_LEN);

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count :  =================---------");
		logInfo("---------==================|||||||||||||||||||||||=================---------");
        	

		if((ReadMsgQ(iOrderRoute2ConDel,&sRcvMsg,RUPEE_MAX_PACKET_SIZE, 0)) != 1)
		{
			perror("Error Read Q");
			exit(ERROR);
		}

		if(mysql_set_server_option(DBConvDel,CLIENT_MULTI_STATEMENTS) == 0)
                {
                        logDebug2(" mysql_set_server_option SUCCESS");
                }
                else
                {
                        logDebug2(" mysql_set_server_option FAILS");
                }		


		iMsgCode = ((struct INT_COMMON_REQUEST_HDR *) sRcvMsg)->iMsgCode;


		logDebug2("iMsgCode [%d]",iMsgCode);	

		/*------------------------------------------------------------------------
END :	MAPPING Structure to local variables
------------------------------------------------------------------------*/
		switch(iMsgCode)
		{
			case TC_INT_CON_DEL_REQ:	

				pCTDReq=(struct CON_TO_DELIVERY_REQUEST *) &sRcvMsg;

				logDebug3("****** printing value *********");
				logDebug3("iSeqNo = %d",pCTDReq->ReqHeader.iSeqNo);
				logDebug3("iMsgLength = %d",pCTDReq->ReqHeader.iMsgLength);
				logDebug3("iMsgCode = %d",pCTDReq->ReqHeader.iMsgCode);
				logDebug3("sExcgId = %s",pCTDReq->ReqHeader.sExcgId);
				logDebug3("iUserId = %llu",pCTDReq->ReqHeader.iUserId);
				logDebug3("cSource = %c",pCTDReq->ReqHeader.cSource);
				logDebug3("cSegment = %c",pCTDReq->ReqHeader.cSegment);
				logDebug3("sSecurityId = %s",pCTDReq->sSecurityId);
				logDebug3("sEntityId = %s",pCTDReq->sEntityId);
				logDebug3("sClientId = %s",pCTDReq->sClientId);
				logDebug3("cBuyOrSell = %c",pCTDReq->cBuyOrSell);
				logDebug3("cProdIdFrom = %c",pCTDReq->cProdIdFrom);
				logDebug3("cProdIdTo = %c",pCTDReq->cProdIdTo);
				logDebug3("cUserType = %c",pCTDReq->cUserType);
				logDebug3("iQty= %d",pCTDReq->iQty);
				logDebug3("iMktType = %d",pCTDReq->iMktType);
				logDebug3("****** printing value *********");

				if(pCTDReq->cProdIdFrom == PROD_COVER || pCTDReq->cProdIdFrom == PROD_BRACKET)
				{
					strncpy(sErrMsg,PROD_NOT_ALLOWED_TO_CONVERT,strlen(PROD_NOT_ALLOWED_TO_CONVERT));
					logDebug2("%s",sErrMsg);
					fSendConvtToDelErrToFE(&sErrMsg,pCTDReq,0,0.0,"Covert to delivery is not allowed for  Product selected");
					continue ;
				}

				memset(sMarketType,'\0',MARKET_LEN);

				logDebug2("pCTDReq->iMktType = %d",pCTDReq->iMktType);				


				GetMktType(&sMarketType,pCTDReq->iMktType);

				logDebug2("pCTDReq->cProdIdFrom = %c",pCTDReq->cProdIdFrom);
				cProductId=pCTDReq->cProdIdFrom;
				logDebug2("cProductId = %c",cProductId);


				logDebug2("pCTDReq->cProdIdTo = %c",pCTDReq->cProdIdTo);
				cToProductId = pCTDReq->cProdIdTo;
				logDebug2("cToProductId = %c",cToProductId);

				logDebug2("pCTDReq->ReqHeader.cSegment = %c",pCTDReq->ReqHeader.cSegment);
				cSegment = pCTDReq->ReqHeader.cSegment;
				logDebug2("cSegment = %c",cSegment);

				logDebug2(" Calling PRCNVTTODEL_COMBINED With Vaules in Function (Convert2Del) for :  ClientId [%s],SecurityId [%s],BuyOrSell[%c],Qty[%d],ExchId[%s],MktType[%s],cProductId[%c] cSegment:%c: cToProductId[%c]",pCTDReq->sClientId,pCTDReq->sSecurityId,pCTDReq->cBuyOrSell,pCTDReq->iQty,pCTDReq->ReqHeader.sExcgId,sMarketType,cProductId,cSegment,cToProductId);

/*
				if (cSegment != 'M')
				{
					sprintf(sCnvtQuery,"CALL PRCNVTTODEL_COMBINED(\"%s\",\"%s\",\'%c\',%d,\"%s\",\'%c\',\'%c\',now(),\'%c\',\"%s\",\
					@ZCODERMS,@ZQTY,@ZPRICE);\
					SELECT @ZCODERMS,@ZQTY,@ZPRICE;",pCTDReq->sClientId,pCTDReq->sSecurityId,\
					pCTDReq->cBuyOrSell,pCTDReq->iQty,\
					pCTDReq->ReqHeader.sExcgId,cProductId,cToProductId,cSegment,sMarketType);
					logDebug2("sCnvtQuery :%s:",sCnvtQuery);			
				}
				else
				{
					sprintf(sCnvtQuery,"CALL PRCNVTTODEL_COM(\"%s\",\"%s\",\'%c\',%d,\"%s\",\'%c\',\'%c\',now(),\'%c\',\"%s\",\
                                        @ZCODERMS,@ZQTY,@ZPRICE);\
                                        SELECT @ZCODERMS,@ZQTY,@ZPRICE;",pCTDReq->sClientId,pCTDReq->sSecurityId,\
                                        pCTDReq->cBuyOrSell,pCTDReq->iQty,\
                                        pCTDReq->ReqHeader.sExcgId,cProductId,cToProductId,cSegment,sMarketType);
                                        logDebug2("sCnvtQuery :%s:",sCnvtQuery);
				}
				//fStart = logGetTime();

*/
				if (cSegment != 'M')
                                {
                                        sprintf(sCnvtQuery,"CALL PRCNVTTODEL_COMBINED(\"%s\",\"%s\",\'%c\',%d,\"%s\",\'%c\',\'%c\',now(),\'%c\',\"%s\",\"%s\",\'%c\',\
						@ZCODERMS,@ZQTY,@ZPRICE,@ZREJREASON);SELECT @ZCODERMS,@ZQTY,@ZPRICE,IFNULL(@ZREJREASON,'Not Specified');",\
						pCTDReq->sClientId,pCTDReq->sSecurityId,pCTDReq->cBuyOrSell,pCTDReq->iQty,pCTDReq->ReqHeader.sExcgId,\
						cProductId,cToProductId,cSegment,sMarketType,pCTDReq->sEntityId,pCTDReq->ReqHeader.cSource);
                                        logDebug2("sCnvtQuery :%s:",sCnvtQuery);
                                }
                                else
                                {
                                        sprintf(sCnvtQuery,"CALL PRCNVTTODEL_COM(\"%s\",\"%s\",\'%c\',%d,\"%s\",\'%c\',\'%c\',now(),\'%c\',\"%s\",\"%s\",\'%c\',\
					@ZCODERMS,@ZQTY,@ZPRICE,@ZREJREASON); SELECT @ZCODERMS,@ZQTY,@ZPRICE,IFNULL(@ZREJREASON,'Not Specified');",pCTDReq->sClientId,pCTDReq->sSecurityId,pCTDReq->cBuyOrSell,pCTDReq->iQty,pCTDReq->ReqHeader.sExcgId,cProductId,cToProductId,cSegment,sMarketType,pCTDReq->sEntityId,pCTDReq->ReqHeader.cSource);
                                        logDebug2("sCnvtQuery :%s:",sCnvtQuery);
                                }
	
				if(mysql_query(DBConvDel,sCnvtQuery) != SUCCESS)
				{
					sql_Error(DBConvDel);
					//free(sCnvtQuery);
					logSqlFatal("Error IN CALLING PRCNVTTODEL_COMBINED.");
					fSendConvtToDelErrToFE (TRANSACTION_FAILED,pCTDReq,0,0.00,"Transaction Fails");
					continue;
				}
				//fEnd = logGetTime();
				//logDebug2(" PRCNVTTODEL_COMBINED Execution Time :%lf:: ",(fEnd - fStart));
				logDebug2("********************");

				do{
					logDebug2("##############");

					Res = mysql_store_result(DBConvDel);
					//					iTotal = mysql_num_rows(Res);
					//					logDebug2("Total = %d",iTotal);

					if(Res)
					{
						iTotal = mysql_num_rows(Res);
						logDebug2("Total = %d",iTotal);

						if((Row = mysql_fetch_row(Res)))
						{
							if(Row[0][0] == 'F')
							{
								logDebug2("GOT NULL :%s:",PROD_GOT_NULL_CONV_TO_DEL);
								fSendConvtToDelErrToFE(PROD_GOT_NULL_CONV_TO_DEL,pCTDReq,"Transaction Fails");
								continue ;
							}	

							logDebug2("Row[0] :%s: Row[1] :%s: Row[2] :%s: ",Row[0],Row[1],Row[2]);	
							strncpy(sRMSStatus,Row[0],15);
							iQty = atoi(Row[1]);
							fAmount = atof(Row[2]);
							strncpy(sErrorStrg,Row[3],DB_REASON_DESC_LEN);
							mysql_free_result(Res);
							logInfo("sRMSStatus:%s: iQty :%d: fAmount:%lf:",sRMSStatus,iQty,fAmount);

							if( iQty < 0 || fAmount < 0 || (strncmp(sRMSStatus," ",3) == 0 ))
							{
								logDebug2("Error in calling PRCNVTTODEL_COMBINED ");
								fSendConvtToDelErrToFE (TRANSACTION_FAILED,pCTDReq,0,0.00,"Transaction Fails");
								continue;		
							}
						}

					}
					else
					{
						logDebug2("No Result Set ");

					}

					if((iStatus = mysql_next_result(DBConvDel)) > 0)
					{
						logDebug3("Could not execute statement");
					}
					logDebug2("After print 1 :%d:",iStatus);
					logDebug2("After print 2");
				}while(iStatus == 0);

				logDebug2("sRMSStatus :%s:",sRMSStatus);			

				if(strncmp(sRMSStatus,"S",1) == 0)
				{
					logDebug1(" PRCNVTTODEL SUCCESS ");
					SendC2DSucessRespToFE(pCTDReq);

				}
				//else if(strncmp(sRMSStatus,"E",1) == 0)
				else 
				{
					logDebug1("Return Nothing in PRCNVTTODEL");
					sprintf(sErrMsg,"%s",sRMSStatus);
					logInfo("ErrorMsg :%s;",sErrMsg);
					fSendConvtToDelErrToFE (&sErrMsg,pCTDReq,iQty,fAmount,&sErrorStrg);
				}	

				break;

				/************/
			case TC_INT_ADMIN_EXPIRY_REQ:

				pExpReq=(struct ORDER_REQUEST *) &sRcvMsg;
				pBoExpReq=(struct BO_ORDER_REQUEST *) &sRcvMsg;

				fTrim(pExpReq->sSecurityId,strlen(pExpReq->sSecurityId));
				fTrim(pExpReq->sEntityId,strlen(pExpReq->sEntityId));
				fTrim(pExpReq->sClientId,strlen(pExpReq->sClientId));
				cSegment = pExpReq->ReqHeader.cSegment;
				fTempOrdNo = pExpReq->fOrderNum;
				//iChkFlg = fDBSelSerNo(cSegment,fTempOrdNo,&iTempOrdSerialNo,&iTransCode);
				if(pBoExpReq->cProductId == PROD_BRACKET)
                                {
                                        fTempOrdNo = pBoExpReq->fOrderNum ;
                                        logDebug3("pBoExpReq.BoArray[0]->cBuySellInd :%c:",pBoExpReq->BoArray[0].cBuySellInd);
                                        logDebug3("pBoExpReq.BoArray[1]->cBuySellInd :%c:",pBoExpReq->BoArray[1].cBuySellInd);
                                        logDebug3("pBoExpReq.BoArray[2]->cBuySellInd :%c:",pBoExpReq->BoArray[2].cBuySellInd);
					PrintAll(pBoExpReq);
                                        iChkFlg = fDBSelSerNo(cSegment,fTempOrdNo,&iTempOrdSerialNo,&iTransCode,&iLeg,&cBuySell,&iMkt);
                                        logDebug3("cBuySell :%c:",cBuySell);
                                        logDebug3("iMkt:%d:",iMkt);
                                        pBoExpReq->iMktType = iMkt ;
                                        pBoExpReq->BoArray[0].cBuySellInd = cBuySell ;
                                        logDebug3("pBoExpReq->iMktType :%d:",pBoExpReq->iMktType);
                                        logDebug3("pBoExpReq.BoArray[0]->cBuySellInd :%c:",pBoExpReq->BoArray[0].cBuySellInd);
                                }
                                else
                                {
					PrintAll(pExpReq);
                                        iChkFlg = fDBSelSerNo(cSegment,fTempOrdNo,&iTempOrdSerialNo,&iTransCode,&iLeg,&cBuySell,&iMkt);
                                        pExpReq->iMktType = iMkt;
                                }
				
				logDebug3("iChkFlg :%d:",iChkFlg);
                                logDebug3("iTransCode :%d:",iTransCode);
                                logDebug3("iLeg :%d:",iLeg);
                                logDebug3("pExpReq->cProductId :%c:",pExpReq->cProductId);
                                logDebug3("pExpReq->iAuctionNum :%d:",pExpReq->iAuctionNum);

				logDebug1("Serial No received,%d",pExpReq->iSerialNum);
				//iLeg = 1;
				if(pExpReq->cProductId == PROD_INTRADAY || pExpReq->cProductId == PROD_CNC || pExpReq->cProductId == PROD_MARGIN)
				{
					if(iTransCode == TC_INT_ORDER_ENTRY_REQ)
                                        {

						if((cSegment == EQUITY_SEGMENT))
						{
							sprintf(sExpUpdQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
								EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
									EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,\
									EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
									EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
									EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
									EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
									EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
									EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,\
									EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,\
									EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,\
									EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2,EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP) \
								SELECT \
								EQ_ORDER_NO,%i,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,\"%s\",\
								EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,%i,\'%c\',\
								EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
								EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
								EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
								EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
								EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,\"EXPIRED BY ADMIN\",\
								EQ_TRD_EXCH_TRADE_NO,%d,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
								EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
								EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID ,EQ_PAN_NO,EQ_PARTICIPANT_TYPE,ifnull(EQ_SETTLOR,'NA'),\
								EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,\
								EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP FROM EQ_ORDERS \
								WHERE \
								EQ_ORDER_NO = \"%f\" AND EQ_SERIAL_NO = %i ;",\
								pExpReq->iSerialNum,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pExpReq->iSerialNum * -1),fTempOrdNo,iTempOrdSerialNo);
							logDebug2("sExpUpdQry:%s:",sExpUpdQry);

						}
						else if(cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
						{
							sprintf(sExpUpdQry,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
								       DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
									DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
									DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
									DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
									DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
									DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
									DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
									DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
									DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
									DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
									DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,\
									DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
									DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP)\
								SELECT \
								DRV_ORDER_NO,%i,DRV_MULTILEG_ORD_TYPE,\
								DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, \"%s\", DRV_EXCH_ORDER_NO,\
								DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  %i ,  \'%c\' ,  DRV_INTERNAL_ENTRY_DATE ,\
								DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
								DRV_ORDER_PRICE, DRV_TRIGGER_PRICE , DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
								DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
								DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
								DRV_GROUP_ID, DRV_REASON_CODE, \"EXPIRED BY ADMIN\", DRV_TRD_EXCH_TRADE_NO,\
								%d, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
								DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
								DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
								DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,\
								DRV_OPTION_TYPE,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
								DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP FROM DRV_ORDERS \
								WHERE DRV_ORDER_NO = \"%f\" AND DRV_SERIAL_NO = %i",\
								pExpReq->iSerialNum,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pExpReq->iSerialNum * -1),fTempOrdNo,iTempOrdSerialNo);
							logDebug2("sExpUpdQry :%s:",sExpUpdQry);
						}
						else if(cSegment == COMMODITY_SEGMENT)
						{
							sprintf(sExpUpdQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
								COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
									COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
									COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
									COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
									COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
									COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
									COMM_GROUP_ID, COMM_REASON_CODE, COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
									COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
									COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
									COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
									COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
									COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_LEG_NO,\
                                                                        COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_MULTIPLIER,\
                                 					COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                 					COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2)\
								SELECT \
								COMM_ORDER_NO,%i,COMM_MULTILEG_ORD_TYPE,\
								COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, \"%s\", COMM_EXCH_ORDER_NO,\
								COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  %i ,  \'%c\' ,  COMM_INTERNAL_ENTRY_DATE ,\
								COMM_TOTAL_QTY ,  COMM_REM_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
								COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
								COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
								COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
								COMM_GROUP_ID, COMM_REASON_CODE, \"EXPIRED BY ADMIN\", COMM_TRD_EXCH_TRADE_NO,\
								%d, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
								COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
								COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
								COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
							COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_LEG_NO, \
                                                                COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_MULTIPLIER,\
                                 				COMM_REF_LTP,\
                                                                COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                 				COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID, COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2\
							FROM COMM_ORDERS WHERE \
							COMM_ORDER_NO = \"%f\" AND COMM_SERIAL_NO = %i",\
							pExpReq->iSerialNum,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pExpReq->iSerialNum * -1),pExpReq->fOrderNum,iTempOrdSerialNo);		
							logDebug2("sExpUpdQry :%s:",sExpUpdQry);
						}
						else
						{
							logDebug2("Invalid Segment :%c:",pExpReq->ReqHeader.cSegment);	
							break;
						}

						if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
						{
							sql_Error(DBConvDel);
							logSqlFatal("Error in insert query.");
							break;
						}
						else
						{
							logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
							mysql_commit(DBConvDel);
							fSendOrdExpRespToFE (pExpReq,iLeg);	
						}
					}
					else if(iTransCode == TC_INT_ORDER_MODIFY || iTransCode == TC_INT_ORDER_CANCEL )
                                        {
						if((cSegment == EQUITY_SEGMENT))
                                                {
                                                        sprintf(sExpUpdQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
                                                                EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
                                                                        EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,\
                                                                        EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
                                                                        EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
                                                                        EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
                                                                        EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
                                                                        EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
                                                                        EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,\
                                                                        EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,\
                                                                        EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,\
									EQ_ENCASH_FLG,EQ_EXCH_SEC,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2,EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP) \
                                                                SELECT \
                                                                EQ_ORDER_NO,%i,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,\
                                                                EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,EQ_MSG_CODE,\'%c\',\
                                                                EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
                                                                EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
                                                                EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
                                                                EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
                                                                EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,EQ_REASON_DESCRIPTION,\
                                                                EQ_TRD_EXCH_TRADE_NO,%d,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
                                                                EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
                                                                EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID ,EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,\
                                                                EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_EXCH_SEC,EQ_CUSTOM_SYMBOL,\
								EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP FROM EQ_ORDERS \
                                                                WHERE \
                                                                EQ_ORDER_NO = \"%f\" AND EQ_SERIAL_NO = %i - 1 ;",\
                                                                pExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pExpReq->iSerialNum  * -1),pExpReq->fOrderNum,iTempOrdSerialNo);
                                                        logDebug2("sExpUpdQry:%s:",sExpUpdQry);

                                                }
						else if(cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
                                                {
                                                        sprintf(sExpUpdQry,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
                                                                       DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
                                                                        DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
                                                                        DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
                                                                        DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
                                                                        DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
                                                                        DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
                                                                        DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
                                                                        DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
                                                                        DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
                                                                        DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
                                                                        DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,\
                                                                        DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
									DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
									DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP)\
                                                                SELECT \
                                                                DRV_ORDER_NO,%i,DRV_MULTILEG_ORD_TYPE,\
                                                                DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
                                                                DRV_CLIENT_ID,  DRV_BUY_SELL_IND , DRV_MSG_CODE , \'%c\' ,  DRV_INTERNAL_ENTRY_DATE ,\
                                                                DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
                                                                DRV_ORDER_PRICE, DRV_TRIGGER_PRICE , DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
                                                                DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
                                                                DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
                                                                DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
                                                                %d, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
                                                                DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
                                                                DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
                                                                DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,\
                                                                DRV_OPTION_TYPE,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
                                                                DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
								DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP FROM DRV_ORDERS \
                                                                WHERE DRV_ORDER_NO = \"%f\" AND DRV_SERIAL_NO = %i - 1",\
                                                                pExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pExpReq->iSerialNum * -1),pExpReq->fOrderNum,iTempOrdSerialNo);
                                                        logDebug2("sExpUpdQry :%s:",sExpUpdQry);
                                                }
						else if(cSegment == COMMODITY_SEGMENT)
                                                {
                                                        sprintf(sExpUpdQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
                                                                COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
                                                                        COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
                                                                        COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
                                                                        COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
                                                                        COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
                                                                        COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
                                                                        COMM_GROUP_ID, COMM_REASON_CODE, COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
                                                                        COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
                                                                        COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
                                                                        COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
                                                                        COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
                                                                        COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,\
                                                                        COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_MULTIPLIER,\
                                                                        COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                        COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID, COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2)\
                                                                SELECT \
                                                                COMM_ORDER_NO,%i,COMM_MULTILEG_ORD_TYPE,\
                                                                COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT,COMM_ENTITY_ID , COMM_EXCH_ORDER_NO,\
                                                                COMM_CLIENT_ID,  COMM_BUY_SELL_IND , COMM_MSG_CODE , COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
                                                                COMM_TOTAL_QTY ,  COMM_REM_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
                                                                COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
                                                                COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
                                                                COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
                                                                COMM_GROUP_ID, COMM_REASON_CODE,COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
                                                                %d, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
                                                                COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
                                                                COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
                                                                COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
                                                                COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES, \
                                                                COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_MULTIPLIER,\
                                                                        COMM_REF_LTP,\
                                                                COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                        COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2\
                                                                FROM COMM_ORDERS WHERE \
                                                                COMM_ORDER_NO = \"%f\" AND COMM_SERIAL_NO = %i - 1 ",\
                                                                pExpReq->iSerialNum,(pExpReq->iSerialNum * -1),pExpReq->fOrderNum,iTempOrdSerialNo);
                                                        logDebug2("sExpUpdQry :%s:",sExpUpdQry);
                                                }
                                                else
                                                {
                                                        logDebug2("Invalid Segment :%c:",pExpReq->ReqHeader.cSegment);
                                                        break;
                                                }
						
						if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
                                                {
                                                        sql_Error(DBConvDel);
                                                        logSqlFatal("Error in insert query.");
                                                        break;
                                                }
                                                else
                                                {
                                                        logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
                                                        mysql_commit(DBConvDel);
                                                        fSendOrdExpRespToFE (pExpReq);
                                                }


					}	
										
				}
				else if(pExpReq->cProductId == PROD_COVER)
				{
					if(iTransCode == TC_INT_ORDER_ENTRY_REQ)
					{
						if((cSegment == EQUITY_SEGMENT))
						{
							//for(iTempLeg = 1;iTempLeg<=2;iTempLeg++)
							//{
							sprintf(sExpUpdQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_LEG_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
								EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
								EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,\
								EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
								EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
								EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
								EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
								EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
								EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,\
								EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,\
								EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,\
								EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_REMARKS1,EQ_REMARKS2,EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP) \
								SELECT \
								EQ_ORDER_NO,%i,%i,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,\"%s\",\
								EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,%i,\'%c\',\
								EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
								EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
								EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
								EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
								EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,\"EXPIRED BY ADMIN\",\
								EQ_TRD_EXCH_TRADE_NO,%d,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
								EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
								EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,EQ_PAN_NO,EQ_PARTICIPANT_TYPE,ifnull(EQ_SETTLOR,'NA'),\
								EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP FROM EQ_ORDERS \
								WHERE \
								EQ_ORDER_NO = \"%f\" AND EQ_SERIAL_NO = %i  AND EQ_LEG_NO = %i;",\
								pExpReq->iSerialNum,iLeg,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,\
								EXPIRED_STATUS,(pExpReq->iSerialNum * -1),pExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
								logDebug2("sExpUpdQry:%s:",sExpUpdQry);

								if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
								{
									sql_Error(DBConvDel);
									logSqlFatal("Error in insert query.");
									break;
								}
								else
								{
									logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
									mysql_commit(DBConvDel);
									//fCoSendOrdExpRespToFE (pCoExpReq);
									fSendOrdExpRespToFE(pExpReq,iLeg);
								}
							//}

						}
						else if(cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
						{
							//for(iTempLeg = 1;iTempLeg<=2;iTempLeg++)
							//{
								sprintf(sExpUpdQry,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
									DRV_LEG_NO, DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
									DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
									DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
									DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
									DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
									DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
									DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
									DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
									DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
									DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
									DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,\
									DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
									DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                	DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP)\
									SELECT \
									DRV_ORDER_NO,%i,DRV_MULTILEG_ORD_TYPE,\
									%i, DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, \"%s\", DRV_EXCH_ORDER_NO,\
									DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  %i ,  \'%c\' ,  DRV_INTERNAL_ENTRY_DATE ,\
									DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
									DRV_ORDER_PRICE, DRV_TRIGGER_PRICE , DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
									DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
									DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
									DRV_GROUP_ID, DRV_REASON_CODE, \"EXPIRED BY ADMIN\", DRV_TRD_EXCH_TRADE_NO,\
									%d, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
									DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
									DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
									DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,\
									DRV_OPTION_TYPE ,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,\
									DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                	DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP FROM DRV_ORDERS \
									WHERE DRV_ORDER_NO = \"%f\" AND DRV_SERIAL_NO = %i AND DRV_LEG_NO =%i",\
									pExpReq->iSerialNum,iLeg,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,\
									(pExpReq->iSerialNum * -1),EXPIRED_STATUS,pExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
								logDebug2("sExpUpdQry :%s:",sExpUpdQry);

								if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
								{
									sql_Error(DBConvDel);
									logSqlFatal("Error in insert query.");
									break;
								}
								else
								{
									logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
									mysql_commit(DBConvDel);
									//fCoSendOrdExpRespToFE (pExpReq);
									fSendOrdExpRespToFE(pExpReq);

								}
							//}
						}
						else if(cSegment == COMMODITY_SEGMENT)
						{
							sprintf(sExpUpdQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
								COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
									COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
									COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
									COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
									COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
									COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
									COMM_GROUP_ID, COMM_REASON_CODE, COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
									COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
									COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
									COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
									COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
									COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,\
                                                                        COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_MULTIPLIER,\
                                                                COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID, COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2)\
								SELECT \
								COMM_ORDER_NO,%i,COMM_MULTILEG_ORD_TYPE,\
								COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
								COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  %i ,  \'%c\' ,  COMM_INTERNAL_ENTRY_DATE ,\
								COMM_TOTAL_QTY ,  COMM_REM_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
								COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
								COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
								COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
								COMM_GROUP_ID, COMM_REASON_CODE, \"EXPIRED BY ADMIN\", COMM_TRD_EXCH_TRADE_NO,\
								%d, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
								COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
								COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
								COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
								COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES, \
                                                                COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_MULTIPLIER,\
                                                                COMM_REF_LTP,\
                                                                COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID, COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2\
								FROM COMM_ORDERS WHERE \
								COMM_ORDER_NO = \"%f\" AND COMM_SERIAL_NO = %i",\
								pExpReq->iSerialNum,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pExpReq->iSerialNum * -1),pExpReq->fOrderNum,iTempOrdSerialNo);
							logDebug2("sExpUpdQry :%s:",sExpUpdQry);

							if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
							{
								sql_Error(DBConvDel);
								logSqlFatal("Error in insert query.");
								break;
							}
							else
							{
								logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
								mysql_commit(DBConvDel);
								//fCoSendOrdExpRespToFE (pExpReq);
								fSendOrdExpRespToFE(pExpReq);
							}
						}
						else
						{
							logDebug2("Invalid Segment :%c:",pExpReq->ReqHeader.cSegment);
							break;
						}
				
					}
					else if(iTransCode == TC_INT_ORDER_MODIFY || iTransCode == TC_INT_ORDER_CANCEL )
					{
						if((cSegment == EQUITY_SEGMENT))
						{

							sprintf(sExpUpdQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
								EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
								EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,\
								EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
								EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
								EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
								EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
								EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
								EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,\
								EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,\
								EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,\
								EQ_ENCASH_FLG,EQ_EXCH_SEC,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2 ,EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP) \
								SELECT \
								EQ_ORDER_NO,%i,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,\
								EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,EQ_MSG_CODE,\'%c\',\
								EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
								EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
								EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
								EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
								EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,EQ_REASON_DESCRIPTION,\
								EQ_TRD_EXCH_TRADE_NO,%d,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
								EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
								EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID ,EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,\
								EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_EXCH_SEC,EQ_CUSTOM_SYMBOL,\
								EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,%d,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP FROM EQ_ORDERS \
								WHERE \
								EQ_ORDER_NO = \"%f\" AND EQ_SERIAL_NO = %i - 1 AND EQ_LEG_NO = %i;",\
								pExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pExpReq->iSerialNum  * -1),iLeg,pExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
								logDebug2("sExpUpdQry:%s:",sExpUpdQry);
								if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
								{
									sql_Error(DBConvDel);
									logSqlFatal("Error in insert query.");
									break;
								}
								else
								{
									logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
									mysql_commit(DBConvDel);
									fSendOrdExpRespToFE (pExpReq);
								}

                                                }
						else if(cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
                                                {

							sprintf(sExpUpdQry,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
								DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
								DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
								DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
								DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
								DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
								DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
								DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
								DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
								DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
								DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
								DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,\
								DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
								DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP)\
								SELECT \
								DRV_ORDER_NO,%i,DRV_MULTILEG_ORD_TYPE,\
								DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
								DRV_CLIENT_ID,  DRV_BUY_SELL_IND , DRV_MSG_CODE , \'%c\',  DRV_INTERNAL_ENTRY_DATE ,\
								DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
								DRV_ORDER_PRICE, DRV_TRIGGER_PRICE , DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
								DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
								DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
								DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
								%d, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
								DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
								DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
								DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,\
								DRV_OPTION_TYPE,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
								DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,%d,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP FROM DRV_ORDERS \
								WHERE DRV_ORDER_NO = \"%f\" AND DRV_SERIAL_NO = %i - 1 AND DRV_LEG_NO =%i",\
								pExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pExpReq->iSerialNum * -1),iLeg,pExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
								logDebug2("sExpUpdQry :%s:",sExpUpdQry);
								if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
								{
									sql_Error(DBConvDel);
									logSqlFatal("Error in insert query.");
									break;
								}
								else
								{
									logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
									mysql_commit(DBConvDel);
									fSendOrdExpRespToFE (pExpReq);
                                                                }

                                                }
						else if(cSegment == COMMODITY_SEGMENT)
                                                {

							sprintf(sExpUpdQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
							COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
							COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
							COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
							COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
							COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
							COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
							COMM_GROUP_ID, COMM_REASON_CODE, COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
							COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
							COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
							COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
							COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
							COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_TRD_SEQ_NO,COMM_SYMBOL,COMM_INSTRUMENT_NAME,\
							COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MULTIPLIER,COMM_ICEX_EXCH_ORDER_TIME,\
							COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_EXCH_ORDER_TIME,COMM_USER_TYPE,COMM_MKT_TYPE,\
                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                        COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_REF_LTP,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,\
                                 			COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2)\
							SELECT \
							COMM_ORDER_NO,%i,COMM_MULTILEG_ORD_TYPE,\
							COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT,COMM_ENTITY_ID , COMM_EXCH_ORDER_NO,\
							COMM_CLIENT_ID,  COMM_BUY_SELL_IND , COMM_MSG_CODE , \'%c\',  COMM_INTERNAL_ENTRY_DATE ,\
							COMM_TOTAL_QTY ,  COMM_REM_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
							COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
							COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
							COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
							COMM_GROUP_ID, COMM_REASON_CODE,COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
							%d, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
							COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
							COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
							COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
							COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_TRD_SEQ_NO,COMM_SYMBOL,COMM_INSTRUMENT_NAME,\
							COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MULTIPLIER,COMM_ICEX_EXCH_ORDER_TIME,\
							COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_EXCH_ORDER_TIME,COMM_USER_TYPE,COMM_MKT_TYPE,%d, \
                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                        COMM_CHILD_LEG_UNQ_ID,COMM_TRAILING_SL_VALUE,COMM_REF_LTP,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,\
                                 			COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2\
							FROM COMM_ORDERS WHERE \
							COMM_ORDER_NO = \"%f\" AND COMM_SERIAL_NO = %i - 1 AND COMM_LEG_NO = %i",\
							pExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pExpReq->iSerialNum * -1),iLeg,pExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
							logDebug2("sExpUpdQry :%s:",sExpUpdQry);

							if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
							{
								sql_Error(DBConvDel);
								logSqlFatal("Error in insert query.");
								break;
							}
							else
							{
								logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
								mysql_commit(DBConvDel);
								fSendOrdExpRespToFE (pExpReq);
							}

                                               }
							
					}
				}
				if(pBoExpReq->cProductId == PROD_BRACKET)
				{
					fTrim(pBoExpReq->sSecurityId,strlen(pBoExpReq->sSecurityId));
					fTrim(pBoExpReq->sEntityId,strlen(pBoExpReq->sEntityId));
					fTrim(pBoExpReq->sClientId,strlen(pBoExpReq->sClientId));
					logDebug1("BOLeg No received,%d",pBoExpReq->iNoOfLeg);
					logDebug1("Order-no,%lf",pBoExpReq->fOrderNum);
					if(iTransCode == TC_INT_ORDER_ENTRY_REQ)
					{
						if((cSegment == EQUITY_SEGMENT))
						{
							sprintf(sExpUpdQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
								EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
									EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,\
									EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
									EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
									EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
									EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
									EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
									EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,\
									EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,\
									EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,\
									EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP) \
								SELECT \
								EQ_ORDER_NO,%i,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,\"%s\",\
								EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,%i,\'%c\',\
								EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
								EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
								EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
								EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
								EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,\"EXPIRED BY ADMIN\",\
								EQ_TRD_EXCH_TRADE_NO,%d,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
								EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
								EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID ,EQ_PAN_NO,EQ_PARTICIPANT_TYPE,ifnull(EQ_SETTLOR,'NA'),\
								EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,\
								EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,%d,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP  FROM EQ_ORDERS \
								WHERE \
								EQ_ORDER_NO = \"%f\" AND EQ_LEG_NO = %d AND EQ_SERIAL_NO = (SELECT MAX(EQ_SERIAL_NO) FROM EQ_ORDERS WHERE EQ_ORDER_NO = %f);",\
								pBoExpReq->iSerialNum,pBoExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pBoExpReq->iSerialNum * -1),iLeg,pBoExpReq->fOrderNum,iLeg,pBoExpReq->fOrderNum);
							logDebug2("sExpUpdQry:%s:",sExpUpdQry);
							

						}
						else if(cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
						{
							sprintf(sExpUpdQry,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
								DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
								DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
								DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
								DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
								DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
								DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
								DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
								DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
								DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
								DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
								DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,\
								DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,\
								DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP)\
								SELECT \
								DRV_ORDER_NO,%i,DRV_MULTILEG_ORD_TYPE,\
								DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, \"%s\", DRV_EXCH_ORDER_NO,\
								DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  %i ,  \'%c\' ,  DRV_INTERNAL_ENTRY_DATE ,\
								DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
								DRV_ORDER_PRICE, DRV_TRIGGER_PRICE , DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
								DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
								DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
								DRV_GROUP_ID, DRV_REASON_CODE, \"EXPIRED BY ADMIN\", DRV_TRD_EXCH_TRADE_NO,\
								%d, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
								DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
								DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
								DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,\
								DRV_OPTION_TYPE,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
								DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP FROM DRV_ORDERS \
								WHERE DRV_ORDER_NO = \"%lf\" AND DRV_LEG_NO = %d AND \
								DRV_SERIAL_NO = (SELECT MAX(DRV_SERIAL_NO) FROM DRV_ORDERS WHERE DRV_ORDER_NO = %f)",\
								pExpReq->iSerialNum,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pExpReq->iSerialNum * -1),pBoExpReq->fOrderNum,iLeg,pBoExpReq->fOrderNum);
							logDebug2("sExpUpdQry :%s:",sExpUpdQry);
						}
						else if(cSegment == COMMODITY_SEGMENT)
						{
							sprintf(sExpUpdQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
								COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
									COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
									COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
									COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
									COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
									COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
									COMM_GROUP_ID, COMM_REASON_CODE, COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
									COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
									COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
									COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
									COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
									COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,\
                                                                        COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                 					COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,\
                                 					COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2)\
								SELECT \
								COMM_ORDER_NO,%i,COMM_MULTILEG_ORD_TYPE,\
								COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, \"%s\", COMM_EXCH_ORDER_NO,\
								COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  %i ,  \'%c\' ,  COMM_INTERNAL_ENTRY_DATE ,\
								COMM_TOTAL_QTY ,  COMM_REM_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
								COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
								COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
								COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
								COMM_GROUP_ID, COMM_REASON_CODE, \"EXPIRED BY ADMIN\", COMM_TRD_EXCH_TRADE_NO,\
								%d, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
								COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
								COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
								COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
								COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES ,\
                                                                COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                        COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,\
                                                                        COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2\
								FROM COMM_ORDERS WHERE \
								COMM_ORDER_NO = \"%f\" AND COMM_SERIAL_NO = %i",\
								pExpReq->iSerialNum,pExpReq->sEntityId,TC_INT_BATCH_CANCEL_REQ,EXPIRED_STATUS,(pExpReq->iSerialNum * -1),pExpReq->fOrderNum,iTempOrdSerialNo);		
							logDebug2("sExpUpdQry :%s:",sExpUpdQry);
						}
						else
						{
							logDebug2("Invalid Segment :%c:",pExpReq->ReqHeader.cSegment);	
							break;
						}

						if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
						{
							sql_Error(DBConvDel);
							logSqlFatal("Error in insert query.");
							break;
						}
						else
						{
							logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
							mysql_commit(DBConvDel);
							//fSendOrdExpRespToFE (pExpReq);	
							fSendBoOrdExpRespToFE (pExpReq,iLeg);	
						}
					
					}
					else if(iTransCode == TC_INT_ORDER_MODIFY || iTransCode == TC_INT_ORDER_CANCEL )
                                        {
						
							if((cSegment == EQUITY_SEGMENT))
                                                        {

                                                                        sprintf(sExpUpdQry,"INSERT INTO EQ_ORDERS (EQ_ORDER_NO,EQ_SERIAL_NO,EQ_SCRIP_CODE,EQ_SYMBOL,\
                                                                                EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,\
                                                                                EQ_MSG_CODE,EQ_ORD_STATUS,EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,\
                                                                                EQ_REM_QTY,EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,\
                                                                                EQ_TRIGGER_PRICE,EQ_VALIDITY,EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,\
                                                                                EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,\
                                                                                EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,\
                                                                                EQ_REASON_CODE,EQ_REASON_DESCRIPTION,EQ_TRD_EXCH_TRADE_NO,EQ_TRD_SERIAL_NO,\
                                                                                EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,\
                                                                                EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID,\
                                                                                EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,\
										EQ_ENCASH_FLG,EQ_EXCH_SEC,EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,EQ_LEG_NO,EQ_REMARKS1,EQ_REMARKS2, EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP) \
                                                                                SELECT \
                                                                                EQ_ORDER_NO,%i,EQ_SCRIP_CODE,EQ_SYMBOL,EQ_EXCH_ID,EQ_SEGMENT,EQ_ENTITY_ID,\
                                                                                EQ_EXCH_ORDER_NO,EQ_CLIENT_ID,EQ_BUY_SELL_IND,EQ_MSG_CODE,\'%c\',\
                                                                                EQ_INTERNAL_ENTRY_DATE,EQ_EXCH_ORDER_TIME,EQ_TOTAL_QTY,EQ_REM_QTY,EQ_DISC_QTY,\
                                                                                EQ_DISC_REM_QTY,EQ_TOTAL_TRADED_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_VALIDITY,\
                                                                                EQ_ORDER_TYPE,EQ_GOOD_TILL_DAYS,EQ_GOOD_TILL_DATE,EQ_ACC_CODE,EQ_USER_ID,EQ_USER_TYPE,\
                                                                                EQ_MIN_FILL_QTY,EQ_PRO_CLIENT,EQ_REMARKS,EQ_ERROR_CODE,EQ_SOURCE_FLG,EQ_ORDER_OFFON,\
                                                                                EQ_PRODUCT_ID,EQ_LOC_CODE,EQ_GROUP_ID,EQ_REASON_CODE,EQ_REASON_DESCRIPTION,\
                                                                                EQ_TRD_EXCH_TRADE_NO,%d,EQ_TRD_TRANS_CODE,EQ_TRD_STATUS,EQ_LAST_TRADE_QTY,\
                                                                                EQ_TRD_TRADE_PRICE,EQ_TRD_TRADE_TIME,EQ_TRD_SEQ_NO,EQ_HANDLE_INST,EQ_ALGO_ORDER_NO,\
                                                                                EQ_STRATEGY_ID,EQ_CLORDID,EQ_ORIG_CLORDID ,EQ_PAN_NO,EQ_PARTICIPANT_TYPE,EQ_SETTLOR,\
                                                                                EQ_MKT_PROTECT_FLG,EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG,EQ_EXCH_SEC,\
										EQ_CUSTOM_SYMBOL,EQ_ISIN_CODE,EQ_EXCH_INSTRUMENT_TYPE,EQ_LOT_SIZE,%d,EQ_REMARKS1,EQ_REMARKS2,EQ_INTEROPS_SCRIP,EQ_INTEROPS_EXCH_SYMBOL,EQ_NSE_SCRIP,EQ_BSE_SCRIP  FROM EQ_ORDERS \
                                                                                WHERE \
                                                                                EQ_ORDER_NO = \"%f\" AND EQ_SERIAL_NO = %i - 1 AND EQ_LEG_NO = %i;",\
                                                                                pBoExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pBoExpReq->iSerialNum  * -1),iLeg,pBoExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
                                                                                logDebug2("sExpUpdQry:%s:",sExpUpdQry);
                                                                                if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
                                                                                {
                                                                                        sql_Error(DBConvDel);
                                                                                        logSqlFatal("Error in insert query.");
                                                                                        break;
                                                                                }
                                                                                else
                                                                                {
                                                                                        logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
                                                                                        mysql_commit(DBConvDel);
                                                                                        fSendBoOrdExpRespToFE(pBoExpReq);
                                                                                }

                                                        }
							 else if(cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
                                                        {

                                                                        sprintf(sExpUpdQry,"INSERT INTO DRV_ORDERS (DRV_ORDER_NO, DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,\
                                                                                DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
                                                                                DRV_CLIENT_ID,  DRV_BUY_SELL_IND ,  DRV_MSG_CODE ,  DRV_STATUS ,  DRV_INTERNAL_ENTRY_DATE ,\
                                                                                DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
                                                                                DRV_ORDER_PRICE, DRV_TRIGGER_PRICE, DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
                                                                                DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
                                                                                DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
                                                                                DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
                                                                                DRV_TRD_SERIAL_NO, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
                                                                                DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
                                                                                DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
                                                                                DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,\
                                                                                DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
										DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                		DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,DRV_LEG_NO,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP)\
                                                                                SELECT \
                                                                                DRV_ORDER_NO,%i,DRV_MULTILEG_ORD_TYPE,\
                                                                                DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT, DRV_ENTITY_ID, DRV_EXCH_ORDER_NO,\
                                                                                DRV_CLIENT_ID,  DRV_BUY_SELL_IND , DRV_MSG_CODE , \'%c\',  DRV_INTERNAL_ENTRY_DATE ,\
                                                                                DRV_TOTAL_QTY ,  DRV_REM_QTY , DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, \
                                                                                DRV_ORDER_PRICE, DRV_TRIGGER_PRICE , DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, \
                                                                                DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
                                                                                DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_PRODUCT_ID, DRV_LOC_CODE,\
                                                                                DRV_GROUP_ID, DRV_REASON_CODE, DRV_REASON_DESCRIPTION, DRV_TRD_EXCH_TRADE_NO,\
                                                                                %d, DRV_TRD_TRANS_CODE, DRV_TRD_STATUS, DRV_TRD_TRADE_QTY,\
                                                                                DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, \
                                                                                DRV_OMS_ALGO_ORD_NO, DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID,DRV_EXCH_ORDER_TIME,\
                                                                                DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,\
                                                                                DRV_OPTION_TYPE,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,\
                                                                                DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_UNDERLINE_SCRIP,DRV_FREEZE_QTY,DRV_CUSTOM_SYMBOL,DRV_REF_LTP,\
                                                                		DRV_LOT_SIZE,DRV_ALGO_ID,DRV_TICK_SIZE,%d,DRV_REMARKS1,DRV_REMARKS2,DRV_INTEROPS_SCRIP,DRV_INTEROPS_EXCH_SYMBOL,DRV_NSE_SCRIP,DRV_BSE_SCRIP FROM DRV_ORDERS \
                                                                                WHERE DRV_ORDER_NO = \"%f\" AND DRV_SERIAL_NO = %i - 1 AND DRV_LEG_NO =%i",\
                                                                                pBoExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pBoExpReq->iSerialNum * -1),iLeg,pBoExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
                                                                                logDebug2("sExpUpdQry :%s:",sExpUpdQry);
                                                                                if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
                                                                                {
                                                                                        sql_Error(DBConvDel);
                                                                                        logSqlFatal("Error in insert query.");
                                                                                        break;
                                                                                }
                                                                                else
                                                                                {
                                                                                        logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
                                                                                        mysql_commit(DBConvDel);
                                                                                        fSendBoOrdExpRespToFE(pBoExpReq);
                                                                                }

                                                        }
							else if(cSegment == COMMODITY_SEGMENT)
                                                        {

                                                                        sprintf(sExpUpdQry,"INSERT INTO COMM_ORDERS (COMM_ORDER_NO, COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,\
                                                                        COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, COMM_ENTITY_ID, COMM_EXCH_ORDER_NO,\
                                                                        COMM_CLIENT_ID,  COMM_BUY_SELL_IND ,  COMM_MSG_CODE ,  COMM_STATUS ,  COMM_INTERNAL_ENTRY_DATE ,\
                                                                        COMM_TOTAL_QTY ,  COMM_REM_QTY ,  COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
                                                                        COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
                                                                        COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
                                                                        COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
                                                                        COMM_GROUP_ID, COMM_REASON_CODE, COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
                                                                        COMM_TRD_SERIAL_NO, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
                                                                        COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
                                                                        COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
                                                                        COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
                                                                        COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_TRD_SEQ_NO,COMM_SYMBOL,COMM_INSTRUMENT_NAME,\
                                                                        COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MULTIPLIER,COMM_ICEX_EXCH_ORDER_TIME,COMM_UNDERLINE_SCRIP,\
                                                                        COMM_FREEZE_QTY,COMM_EXCH_ORDER_TIME,COMM_USER_TYPE,COMM_MKT_TYPE,COMM_LEG_NO,\
                                                                        COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                        COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,\
                                                                        COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2)\
                                                                        SELECT \
                                                                        COMM_ORDER_NO,%i,COMM_MULTILEG_ORD_TYPE,\
                                                                        COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT,COMM_ENTITY_ID , COMM_EXCH_ORDER_NO,\
                                                                        COMM_CLIENT_ID,  COMM_BUY_SELL_IND , COMM_MSG_CODE , \'%c\',  COMM_INTERNAL_ENTRY_DATE ,\
                                                                        COMM_TOTAL_QTY ,  COMM_REM_QTY , COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, \
                                                                        COMM_ORDER_PRICE, COMM_TRIGGER_PRICE, COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, \
                                                                        COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
                                                                        COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_PRODUCT_ID, COMM_LOC_CODE,\
                                                                        COMM_GROUP_ID, COMM_REASON_CODE,COMM_REASON_DESCRIPTION, COMM_TRD_EXCH_TRADE_NO,\
                                                                        %d, COMM_TRD_TRANS_CODE, COMM_TRD_STATUS, COMM_TRD_TRADE_QTY,\
                                                                        COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME,  COMM_HANDLE_INST, \
                                                                        COMM_OMS_ALGO_ORDER_NO, COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID,\
                                                                        COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,\
                                                                        COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_SERIES,COMM_TRD_SEQ_NO,COMM_SYMBOL,\
                                                                        COMM_INSTRUMENT_NAME,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_MULTIPLIER,COMM_ICEX_EXCH_ORDER_TIME,\
                                                                        COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_EXCH_ORDER_TIME,COMM_USER_TYPE,COMM_MKT_TYPE,%d ,\
                                                                        COMM_REF_LTP,\
                                                                        COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,\
                                                                        COMM_UNDERLINE_SCRIP,COMM_FREEZE_QTY,COMM_CUSTOM_SYMBOL,COMM_LOT_SIZE,COMM_ALGO_ID,\
                                                                        COMM_TICK_SIZE,COMM_REMARKS1,COMM_REMARKS2\
                                                                        FROM COMM_ORDERS WHERE \
                                                                        COMM_ORDER_NO = \"%f\" AND COMM_SERIAL_NO = %i - 1 AND COMM_LEG_NO = %i",\
                                                                        pBoExpReq->iSerialNum,EXCH_CONFIRM_STATUS,(pBoExpReq->iSerialNum * -1),iLeg,pBoExpReq->fOrderNum,iTempOrdSerialNo,iLeg);
                                                                        logDebug2("sExpUpdQry :%s:",sExpUpdQry);

                                                                        if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
                                                                        {
                                                                                sql_Error(DBConvDel);
                                                                                logSqlFatal("Error in insert query.");
                                                                                break;
                                                                        }
                                                                        else
                                                                        {
                                                                                logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
                                                                                mysql_commit(DBConvDel);
                                                                                fSendBoOrdExpRespToFE(pBoExpReq);
                                                                        }

                                                        }
							else
                                                        {
                                                                logDebug2("Invalid Segment :%c:",pExpReq->ReqHeader.cSegment);
                                                                break;
                                                        }
							
							if(iLeg == LEG_1 && iTransCode == TC_INT_ORDER_ENTRY_REQ)
	                                                {
        	                                                memset (sExpUpdQry,'\0' ,MAX_QUERY_SIZE);
                	                                        if(cSegment == EQUITY_SEGMENT)
                        	                                {
                                	                                sprintf(sExpUpdQry,"UPDATE EQ_ORDERS SET EQ_REM_QTY = 0  WHERE  EQ_ORDER_NO = \'%lf\' AND EQ_ALGO_ORDER_NO = -1 AND EQ_LEG_NO NOT IN (%d) ",pBoExpReq->fOrderNum,LEG_1);
                                        	                }
                                                	        else if (cSegment == DERIVATIVE_SEGMENT || cSegment ==CURRENCY_SEGMENT)
                                                        	{

                                                                	sprintf(sExpUpdQry,"UPDATE DRV_ORDERS SET DRV_REM_QTY = 0  WHERE  DRV_ORDER_NO = \'%lf\' AND DRV_OMS_ALGO_ORD_NO = -1 AND DRV_LEG_NO NOT IN (%d) ",pBoExpReq->fOrderNum,LEG_1);
                                                        	}
                                                        	else if (cSegment == COMMODITY_SEGMENT)
                                                        	{
                                                                	sprintf(sExpUpdQry,"UPDATE COMM_ORDERS SET COMM_REM_QTY = 0  WHERE  COMM_ORDER_NO = \'%lf\' AND COMM_OMS_ALGO_ORDER_NO = -1 AND COMM_LEG_NO NOT IN (%d) ",pBoExpReq->fOrderNum,LEG_1);
                                                        	}
                                                        	else
                                                        	{
                                                                	logDebug2("Invalid Segment :%c:",pExpReq->ReqHeader.cSegment);
                                                                	break;
                                                        	}
                                                        	logDebug3("sExpUpdQry :%s:",sExpUpdQry);
                                                        	if(mysql_query(DBConvDel,sExpUpdQry) != SUCCESS)
                                                        	{
                                                                	sql_Error(DBConvDel);
                                                                	logSqlFatal("Error in insert query.");
                                                                	break;
                                                        	}
                                                        	else
                                                        	{
                                                                	logDebug2("Row Updated :%d:",mysql_affected_rows(DBConvDel));
                                                                	mysql_commit(DBConvDel);
                                                                	/*fSendOrdExpRespToFE (pExpReq);*/
                                                        	}
                                                	}
                                                	else
                                                	{
                                                        	logDebug3("NOT A MAIN LEG");
                                                	}


					}

				}
				break;

		case TC_INT_SPAN_CALC_REQ:

				pSPCReq=(struct SPAN_CALC_REQUEST *) &sRcvMsg;

				logDebug3("****** printing value *********");
				logDebug3("iSeqNo = :%d:",pSPCReq->ReqHeader.iSeqNo);
				logDebug3("iMsgCode = :%d:",pSPCReq->ReqHeader.iMsgCode);
				logDebug3("sExcgId = :%s:",pSPCReq->ReqHeader.sExcgId);
				logDebug3("iUserId = :%llu:",pSPCReq->ReqHeader.iUserId);
				logDebug3("cSegment = :%c:",pSPCReq->ReqHeader.cSegment);
				logDebug3("sSymbol = :%s:",pSPCReq->sSymbol);
				logDebug3("sEntityId = :%s:",pSPCReq->sEntityId);
				logDebug3("sClientId = :%s:",pSPCReq->sClientId);
				logDebug3("cBuyOrSell = :%c:",pSPCReq->cBuyOrSell);
				logDebug3("iQty = :%d:",pSPCReq->iLotSize);
				logDebug3("****** printing value *********");

				sprintf(sSpanCal,"select SM_SCRIP_CODE from SECURITY_MASTER where SM_SYMBOL_NAME = \"%s\" ;",pSPCReq->sSymbol);								logDebug2("%s",sSpanCal);	
	
				if (mysql_query(DBConvDel, sSpanCal) != SUCCESS)
				{
					logSqlFatal("Error in Select scripcode no Quesry." );
					sql_Error(DBConvDel);
					free(sSpanCal);
				}	
				Res = mysql_store_result(DBConvDel);
			
				Row = mysql_fetch_row(Res);
				strncpy(pSPCReq->sSecurityId,Row[0],SECURITY_ID_LEN);  
				logDebug3("sSecurityId = :%s:",pSPCReq->sSecurityId);
				mysql_free_result(Res);
				free(sSpanCal);	
			
				sprintf(sSpanCal,"Call PR_SPANCALC(\"%s\",\"%s\",\"%s\",\"%s\",'%d',\"%s\",@ZSTATUS,@MARGIN,@SPAN_MARGIN,@EXPO_MARGIN);\
				select @ZSTATUS,@MARGIN,@SPAN_MARGIN,@EXPO_MARGIN;",pSPCReq->sClientId,pSPCReq->sSecurityId,pSPCReq->ReqHeader.cSegment,pSPCReq->ReqHeader.sExcgId,pSPCReq->iLotSize);
		
				logDebug2("sSpanCal  :%s:",sSpanCal);
	
				if(mysql_query(DBConvDel, sSpanCal) != SUCCESS)
				{
					logSqlFatal("Error while Calling pr_spancalc");
					sql_Error(DBConvDel);
					free(sSpanCal);
				} 
				Res = mysql_store_result(DBConvDel);
		
				if((Row = mysql_fetch_row(Res)))
				{
					strncpy(sRMSStatus,Row[0],15);
					pSPCReq->fSmargin = atof(Row[2]);
					logDebug2("fSmargin :%lf",pSPCReq->fSmargin);
					pSPCReq->fEmargin = atof(Row[3]);
					logDebug2("fEmargin :%lf",pSPCReq->fEmargin);	
					fsum = pSPCReq->fSmargin + pSPCReq->fEmargin ;
					pSPCReq->fMargin = fsum;	
						//sendSPCSucessRespToFE(pSPCReq);
				}
				else
				{
					logDebug2("There is some error while fetching the data :");
				}
				mysql_free_result(Res);
				free(sSpanCal); 
		
				if(strncmp(sRMSStatus,"S",1) == 0)
				{
					logDebug1(" SPANCALC SUCCESS ");
					SendSPCSucessRespToFE(pSPCReq);
				
				}
				else if(strncmp(sRMSStatus,"E",1) == 0)
				{
					logDebug1(" Nothing in SPANCALC");
					sprintf(sErrMsg,"%s",sRMSStatus);
					logInfo("ErrorMsg :%s;",sErrMsg);
					fSendSPCErrToFE(&sErrMsg,pSPCReq);
				}
	
			default:
				logDebug2("Invalid :%d:",iMsgCode);

		}
	} /*** END of Switch****/


}/**END of for(;;)***/



/*****END of Con2Del*****/



SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen )
{
	SHORT Strlen=0;

	if ( MaxLen <= 0 )
	{
		return FALSE ;
	}

	for( ; Str_In[Strlen] != ' ' && Strlen < MaxLen ; Strlen++ )
	{
		continue;
	}

	Str_In[Strlen]='\0';

	return Strlen  ;
}

BOOL fAdminExpErrRespToFE(CHAR *sErrMsg, struct ORDER_REQUEST *pResp)
{
	logTimestamp("fAdminExpErrRespToFE [Entry]");
	struct INT_ERROR_FE_RESP pErrResp;
	memset(&pErrResp,'\0',sizeof(struct INT_ERROR_FE_RESP));
	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( &sErrString,     '\0' ,DB_REASON_DESC_LEN);
	DOUBLE64	fAmnt;
	logDebug2("pResp->ReqHeader.iSeqNo :%d:",pResp->ReqHeader.iSeqNo);
	pErrResp.IntRespHeader.iSeqNo= pResp->ReqHeader.iSeqNo;
	pErrResp.IntRespHeader.iMsgLength=	sizeof(struct INT_ERROR_FE_RESP);
	strncpy(pErrResp.IntRespHeader.sExcgId,pResp->ReqHeader.sExcgId,EXCHANGE_LEN);
	pErrResp.IntRespHeader.iErrorId= 1;
	pErrResp.IntRespHeader.iUserId= pResp->ReqHeader.iUserId;
	//	pErrResp.cUserType = pReq->cUserType;
	if(pResp->ReqHeader.iMsgCode == TC_INT_ADMIN_EXPIRY_REQ)
	{
		pErrResp.IntRespHeader.iMsgCode= TC_INT_ADMIN_EXPIRY_ERR_RESP;
	}
	pErrResp.IntRespHeader.cSource = pResp->ReqHeader.cSource;
	pErrResp.IntRespHeader.cSegment = pResp->ReqHeader.cSegment;
	logDebug2("ErrorMsg :%s:",sErrMsg);
	if(fFetchErrStr(sErrMsg,&sErrString) == TRUE )
	{
		logDebug2("ErrorMsg :%s:",sErrMsg);
		logDebug2("Reason is :%s:",sErrString);
		if((strncmp(sErrMsg,"E0001",5) == 0))
		{
			sprintf(sErrString,"%s %.2lf",sErrString,fAmnt);
		}
		else if((strncmp(sErrMsg,"E0002",5) == 0))
		{
			sprintf(sErrString,"%s %d",sErrString,iQty);
		}
		else
		{
			logDebug2("Reason is :%s:",sErrString);
		}
	}
	else
	{
		strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);
	}

	strncpy(pErrResp.sErrorMsg,sErrString,ERROR_MESSAGE_LEN);
	strncpy(pErrResp.sErrorCode,sErrMsg,ERROR_CODE_LEN);

	logDebug2("pErrResp.sErrorMsg[%s]",pErrResp.sErrorMsg);

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrResp, sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in fSendRMSErrToFE.");
		exit(ERROR);
	}
	logTimestamp("fAdminExpErrRespToFE [EXIT]");
}

BOOL fCoAdminExpErrRespToFE(CHAR *sErrMsg, struct CO_ORDER_REQUEST *pResp)
{
	logTimestamp("fCoAdminExpErrRespToFE [Entry]");
	struct INT_ERROR_FE_RESP pErrResp;
	memset(&pErrResp,'\0',sizeof(struct INT_ERROR_FE_RESP));
	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( &sErrString,     '\0' ,DB_REASON_DESC_LEN);
	DOUBLE64        fAmnt;
	logDebug2("pResp->ReqHeader.iSeqNo :%d:",pResp->ReqHeader.iSeqNo);
	pErrResp.IntRespHeader.iSeqNo= pResp->ReqHeader.iSeqNo;
	pErrResp.IntRespHeader.iMsgLength=      sizeof(struct INT_ERROR_FE_RESP);
	strncpy(pErrResp.IntRespHeader.sExcgId,pResp->ReqHeader.sExcgId,EXCHANGE_LEN);
	pErrResp.IntRespHeader.iErrorId= 1;
	pErrResp.IntRespHeader.iUserId= pResp->ReqHeader.iUserId;
	//      pErrResp.cUserType = pReq->cUserType;
	if(pResp->ReqHeader.iMsgCode == TC_INT_ADMIN_EXPIRY_REQ)
	{
		pErrResp.IntRespHeader.iMsgCode= TC_INT_ADMIN_EXPIRY_ERR_RESP;
	}
	pErrResp.IntRespHeader.cSource = pResp->ReqHeader.cSource;
	pErrResp.IntRespHeader.cSegment = pResp->ReqHeader.cSegment;
	logDebug2("ErrorMsg :%s:",sErrMsg);
	if(fFetchErrStr(sErrMsg,&sErrString) == TRUE )
	{
		logDebug2("ErrorMsg :%s:",sErrMsg);
		logDebug2("Reason is :%s:",sErrString);
		if((strncmp(sErrMsg,"E0001",5) == 0))
		{
			sprintf(sErrString,"%s %.2lf",sErrString,fAmnt);
		}
		else if((strncmp(sErrMsg,"E0002",5) == 0))
		{
			sprintf(sErrString,"%s %d",sErrString,iQty);
		}
		else
		{
			logDebug2("Reason is :%s:",sErrString);
		}
	}
	else
	{
		strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);
	}

	strncpy(pErrResp.sErrorMsg,sErrString,ERROR_MESSAGE_LEN);
	strncpy(pErrResp.sErrorCode,sErrMsg,ERROR_CODE_LEN);

	logDebug2("pErrResp.sErrorMsg[%s]",pErrResp.sErrorMsg);

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrResp, sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in fSendRMSErrToFE.");
		exit(ERROR);
	}
	logTimestamp("fCoAdminExpErrRespToFE [EXIT]");
}


BOOL fSendConvtToDelErrToFE (CHAR *sErrMsg, struct CON_TO_DELIVERY_REQUEST *pResp,LONG32 iQty,DOUBLE64 fAmount,CHAR *sMsgString)
{
	logTimestamp("fSendConvtToDelErrToFE [Entry]");
	struct INT_ERROR_FE_RESP pErrResp;
	memset(&pErrResp,'\0',sizeof(struct INT_ERROR_FE_RESP));
	logDebug2("pResp->ReqHeader.iSeqNo :%d:",pResp->ReqHeader.iSeqNo);
	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( &sErrString,     '\0' ,DB_REASON_DESC_LEN);
	logDebug2("pResp->ReqHeader.iSeqNo :%d:",pResp->ReqHeader.iSeqNo);
	pErrResp.IntRespHeader.iSeqNo= pResp->ReqHeader.iSeqNo;
	pErrResp.IntRespHeader.iMsgLength=      sizeof(struct INT_ERROR_FE_RESP);
	strncpy(pErrResp.IntRespHeader.sExcgId,pResp->ReqHeader.sExcgId,EXCHANGE_LEN);
	pErrResp.IntRespHeader.iErrorId= 1;
	pErrResp.IntRespHeader.iUserId= pResp->ReqHeader.iUserId;
	//      pErrResp.cUserType = pReq->cUserType;
	if(pResp->ReqHeader.iMsgCode == TC_INT_CON_DEL_REQ)
	{
		pErrResp.IntRespHeader.iMsgCode= TC_INT_CON_DEL_ERR_RESP;
	}
	pErrResp.IntRespHeader.cSource = pResp->ReqHeader.cSource;
	pErrResp.IntRespHeader.cSegment = pResp->ReqHeader.cSegment;
	logDebug2("pErrResp.IntRespHeader.iMsgCode :%d:",pErrResp.IntRespHeader.iMsgCode);
	logDebug2("ErrorMsg :%s:",sErrMsg);

	if(cRmsRejFlag == NO)
	{
		if(fFetchErrStr(sErrMsg,&sErrString) == TRUE )
		{
			logDebug2("ErrorMsg :%s:",sErrMsg);
			logDebug2("Reason is :%s:",sErrString);
			if((strncmp(sErrMsg,"E0001",5) == 0))
			{
				sprintf(sErrString,"%s %.2lf",sErrString,fAmount);
			}
			else if((strncmp(sErrMsg,"E0002",5) == 0))
			{
				sprintf(sErrString,"%s %d",sErrString,iQty);
			}
			else
			{
				logDebug2("Reason is :%s:",sErrString);
			}
		}
		else
		{
			strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);
		}
	}
	else
	{
		logInfo("This is from RMS sErrMsg :%s:",sErrMsg);
                if(strncmp(sErrMsg,"ER",2) != 0)
                {
                        logInfo("This is non ER msg from RMS");
                        strncpy(sErrString,sMsgString,DB_REASON_DESC_LEN);
                }
                else
                {
                        logInfo("This is ER msg from RMS :%s:",sErrMsg);
                        strncpy(sErrString,"Error Occured Please Contact System Administrator",DB_REASON_DESC_LEN);
                }
	}

	strncpy(pErrResp.sErrorMsg,sErrString,DB_REASON_DESC_LEN);
	strncpy(pErrResp.sErrorCode,sErrMsg,ERROR_CODE_LEN);

	logDebug2("pErrResp.sErrorMsg[%s]",pErrResp.sErrorMsg);

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrResp, sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in iOrdSrvToTrdRtr .");
		exit(ERROR);
	}
	logTimestamp("fSendConvtToDelErrToFE [Exit]");
}

BOOL fSendSPCErrToFE (CHAR *sErrMsg, struct SPAN_CALC_REQUEST *pResp)
{
	logTimestamp("fSendSPCErrToFE [Entry]");
	struct INT_ERROR_FE_RESP  pErrResp;
	memset(&pErrResp,'\0',sizeof(struct INT_ERROR_FE_RESP));
	logDebug2("pResp->ReqHeader.iSeqNo :%d:",pResp->ReqHeader.iSeqNo);
	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( &sErrString,     '\0' ,DB_REASON_DESC_LEN);

	logDebug2("pResp->ReqHeader.iSeqNo :%d:",pResp->ReqHeader.iSeqNo);
	pErrResp.IntRespHeader.iSeqNo= pResp->ReqHeader.iSeqNo;
	pErrResp.IntRespHeader.iMsgLength=      sizeof(struct INT_ERROR_FE_RESP);
	strncpy(pErrResp.IntRespHeader.sExcgId,pResp->ReqHeader.sExcgId,EXCHANGE_LEN);
	pErrResp.IntRespHeader.iErrorId= 1;
	pErrResp.IntRespHeader.iUserId= pResp->ReqHeader.iUserId;
	//      pErrResp.cUserType = pReq->cUserType;
	pErrResp.IntRespHeader.iMsgCode= TC_INT_SPAN_CALC_ERR_RESP;
	pErrResp.IntRespHeader.cSegment = pResp->ReqHeader.cSegment;
	logDebug2("pErrResp.IntRespHeader.iMsgCode :%d:",pErrResp.IntRespHeader.iMsgCode);
	logDebug2("ErrorMsg :%s:",sErrMsg);
	if(fFetchErrStr(sErrMsg,&sErrString) == TRUE )
	{
		logDebug2("ErrorMsg :%s:",sErrMsg);
		logDebug2("Reason is :%s:",sErrString);

		if((strncmp(sErrMsg,"E0002",5) == 0))
		{
			sprintf(sErrString,"%s %d",sErrString,iQty);
		}
		else
		{
			logDebug2("Reason is :%s:",sErrString);
		}
	}
	else
	{
		strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);
	}

	strncpy(pErrResp.sErrorMsg,sErrString,ERROR_MESSAGE_LEN);
	strncpy(pErrResp.sErrorCode,sErrMsg,ERROR_CODE_LEN);

	logDebug2("pErrResp.sErrorMsg[%s]",pErrResp.sErrorMsg);

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrResp, sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in iOrdSrvToTrdRtr .");
		exit(ERROR);
	}
	logTimestamp("fSendSPCErrToFE [Exit]");
}


BOOL SendC2DSucessRespToFE(struct CON_TO_DELIVERY_REQUEST *pReq)
{
	logTimestamp(" ENTRY [SendC2DSucessRespToFE]");
	struct  CON_TO_DELIVERY_RESPONSE pResp;
	memset(&pResp,'\0',sizeof(struct CON_TO_DELIVERY_RESPONSE));

	pResp.RespHeader.iSeqNo= pReq->ReqHeader.iSeqNo;
	pResp.RespHeader.iMsgLength= sizeof(struct CON_TO_DELIVERY_RESPONSE);
	pResp.RespHeader.iErrorId= 0;
	pResp.RespHeader.iUserId= pReq->ReqHeader.iUserId;
	pResp.RespHeader.cSegment= pReq->ReqHeader.cSegment;
	pResp.RespHeader.cSource = pReq->ReqHeader.cSource;

	strncpy(pResp.RespHeader.sExcgId,pReq->ReqHeader.sExcgId,EXCHANGE_LEN);
	pResp.RespHeader.iMsgCode = TC_INT_CON_DEL_RESP;

	strncpy(pResp.sSecurityId,pReq->sSecurityId,strlen(pReq->sSecurityId));
	strncpy(pResp.sEntityId,pReq->sEntityId,strlen(pReq->sEntityId));
	strncpy(pResp.sClientId,pReq->sClientId,strlen(pReq->sClientId));

	pResp.iQty =  pReq->iQty;
	pResp.iMktType = pReq->iMktType;
	pResp.cProdIdFrom = pReq->cProdIdFrom;
	pResp.cProdIdTo = pReq->cProdIdTo;
	pResp.cBuyOrSell = pReq->cBuyOrSell;
	pResp.cUserType = pReq->cUserType;

	logDebug2("%c to %c convert sucessfully",pResp.cProdIdFrom,pResp.cProdIdTo);	

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pResp,sizeof(struct CON_TO_DELIVERY_RESPONSE), 1)) != 1)
	{
		perror("Error Rms error sent failed ... ");
		exit(1);
	}
	
	if(iKafkaMsgFlag == TRUE)
	{
		FetchPostnSend(pResp.RespHeader.sExcgId,pResp.RespHeader.cSegment,pResp.cProdIdFrom,pResp.sClientId,pResp.sSecurityId,&pResp,0);
		FetchPostnSend(pResp.RespHeader.sExcgId,pResp.RespHeader.cSegment,pResp.cProdIdTo,pResp.sClientId,pResp.sSecurityId,&pResp,0);
		FetchPostnSend(pResp.RespHeader.sExcgId,pResp.RespHeader.cSegment,pResp.cProdIdFrom,pResp.sClientId,pResp.sSecurityId,&pResp,1);
		FetchPostnSend(pResp.RespHeader.sExcgId,pResp.RespHeader.cSegment,pResp.cProdIdTo,pResp.sClientId,pResp.sSecurityId,&pResp,1);
	}
//	FetchPostnSend(pResp.RespHeader.sExcgId,pResp.RespHeader.cSegment,pResp.cProdIdTo,pResp.sClientId,pResp.sSecurityId,&pResp);

	logTimestamp("EXIT [SendC2DSucessRespToFE]");
}

BOOL fSendOrdExpRespToFE(struct ORDER_REQUEST *pReq,LONG32 iLeg)
{
	logTimestamp("fSendOrdExpRespToFE[Entry]");
	struct  ORDER_RESPONSE pResp;
	memset(&pResp,'\0',sizeof(struct ORDER_RESPONSE));


	pResp.IntRespHeader.iSeqNo= pReq->ReqHeader.iSeqNo;
	pResp.IntRespHeader.iMsgLength= sizeof(struct  ORDER_RESPONSE);
	pResp.IntRespHeader.iErrorId= 0;
	pResp.IntRespHeader.iUserId= pReq->ReqHeader.iUserId;
	pResp.cUserType= pReq->cUserType;
	pResp.IntRespHeader.cSource = pReq->ReqHeader.cSource;
	pResp.IntRespHeader.cSegment= pReq->ReqHeader.cSegment;

	strncpy(pResp.IntRespHeader.sExcgId,pReq->ReqHeader.sExcgId,EXCHANGE_LEN);
	if( pReq->ReqHeader.iMsgCode == TC_INT_ADMIN_EXPIRY_REQ)
	{
		pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EXPIRY_RESP;

	}
	logDebug2("pReq->sSecurityId            :%s:",pReq->sSecurityId);
	strncpy(pResp.sSecurityId,pReq->sSecurityId,strlen(pReq->sSecurityId));
	strncpy(pResp.sEntityId,pReq->sEntityId,strlen(pReq->sEntityId));
	//	strncpy(pResp.sClientId,pReq->sClientId,strlen(pReq->sClientId));
	strncpy(pResp.sClientId,pReq->sClientId,CLIENT_ID_LEN);
	pResp.fOrderNum= pReq->fOrderNum;
	pResp.iOrderValidity= pReq->iOrderValidity;
	pResp.iOrderType= pReq->iOrderType;
	pResp.iTotalQty= pReq->iTotalQty;
	pResp.fPrice= pReq->fPrice;
	pResp.cProductId= pReq->cProductId;
	pResp.cBuyOrSell = pReq->cBuyOrSell;
	pResp.cProCli=pReq->cProCli;
	pResp.iLegValue=iLeg;
        pResp.cOffMarketFlg = pReq->cOffMarketFlg;

/*
	logDebug2("--------------Printing Responce Struct---------------");
	logDebug2("MsgCode                      :%d:",pReq->ReqHeader.iMsgCode);
	logDebug2("pResp.IntRespHeader.iSeqNo   :%d:",pResp.IntRespHeader.iSeqNo);
	logDebug2("pResp.IntRespHeader.iMsgLength :%d:",pResp.IntRespHeader.iMsgLength);
	logDebug2("pResp.IntRespHeader.iUserId    :%llu:",pResp.IntRespHeader.iUserId);
	logDebug2("pResp.IntRespHeader.cSource  :%c:",pResp.IntRespHeader.cSource);
	logDebug2("pResp.IntRespHeader.cSegment :%c:",pResp.IntRespHeader.cSegment);
	logDebug2("pResp.IntRespHeader.sExcgId  :%s:",pResp.IntRespHeader.sExcgId);
	logDebug2("pResp.IntRespHeader.iMsgCode :%d:",pResp.IntRespHeader.iMsgCode);
	logDebug2("pResp.fOrderNum              :%lf:",pResp.fOrderNum);
	logDebug2("pResp.iTotalQty              :%d:",pResp.iTotalQty);
	logDebug2("pResp.fPrice                 :%f:",pResp.fPrice);
	logDebug2("pResp.cProductId             :%c:",pResp.cProductId);
	logDebug2("pResp.cBuyOrSell             :%c:",pResp.cBuyOrSell);
	logDebug2("pResp.cUserType              :%c:",pResp.cUserType);
	logDebug2("pResp.sSecurityId            :%s:",pResp.sSecurityId);
	logDebug2("pResp.sEntityId              :%s:",pResp.sEntityId);
	logDebug2("pResp.sClientId              :%s:",pResp.sClientId);
	logDebug2("pResp.fOrderNum              :%lf:",pResp.fOrderNum);
	logDebug2("pResp.iOrderValidity         :%d:",pResp.iOrderValidity);
	logDebug2("pResp.iOrderType             :%d:",pResp.iOrderType);
	logDebug2("pReq->fPrice:%lf pReq->iTotalQty:%d:",pReq->fPrice,pReq->iTotalQty);
        logDebug2("pResp.cOffMarketFlg         :%c:",pResp.cOffMarketFlg);
	logDebug2("pResp.iLegValue         :%d:",pResp.iLegValue);
	logDebug2("----------------------END------------------------------");
*/

	//Printing full structure
        logDebug2("--------------Printing ORDER RESPONSE--------------------");

        logDebug2("pResp.IntRespHeader.iMsgLength   :%d:",pResp.IntRespHeader.iMsgLength);
        logDebug2("pResp.IntRespHeader.iMsgCode     :%d:",pResp.IntRespHeader.iMsgCode);
        logDebug2("pResp.IntRespHeader.sExcgId      :%s:",pResp.IntRespHeader.sExcgId);
        logDebug2("pResp.IntRespHeader.iErrorId     :%d:",pResp.IntRespHeader.iErrorId);
        logDebug2("pResp.IntRespHeader.iUserId      :%llu:",pResp.IntRespHeader.iUserId);
        logDebug2("pResp.IntRespHeader.cSource      :%c:",pResp.IntRespHeader.cSource);
        logDebug2("pResp.IntRespHeader.iTimeStamp   :%d:",pResp.IntRespHeader.iTimeStamp);
        logDebug2("pResp.IntRespHeader.cSegment     :%c:",pResp.IntRespHeader.cSegment);
	logDebug2("pResp.IntRespHeader.iSeqNo   :%d:",pResp.IntRespHeader.iSeqNo);

        logDebug2("pResp.iLegValue          :%d:",pResp.iLegValue);
        logDebug2("pResp.sSecurityId        :%s:",pResp.sSecurityId);
        logDebug2("pResp.sEntityId          :%s:",pResp.sEntityId);
        logDebug2("pResp.sClientId          :%s:",pResp.sClientId);
        logDebug2("pResp.sExchOrderID       :%s:",pResp.sExchOrderID);
        logDebug2("pResp.cProductId         :%c:",pResp.cProductId);
        logDebug2("pResp.cBuyOrSell         :%c:",pResp.cBuyOrSell);
        logDebug2("pResp.iOrderType         :%d:",pResp.iOrderType);
        logDebug2("pResp.iOrderValidity     :%d:",pResp.iOrderValidity);
        logDebug2("pResp.iDiscQty           :%d:",pResp.iDiscQty);
        logDebug2("pResp.iDiscQtyRem        :%d:",pResp.iDiscQtyRem);
        logDebug2("pResp.iTotalQtyRem       :%d:",pResp.iTotalQtyRem);
        logDebug2("pResp.iTotalQty          :%d:",pResp.iTotalQty);
        logDebug2("pResp.iLastTradedQty     :%d:",pResp.iLastTradedQty);
        logDebug2("pResp.iTotalTradedQty    :%d:",pResp.iTotalTradedQty);
        logDebug2("pResp.iMinFillQty        :%d:",pResp.iMinFillQty);
        logDebug2("pResp.fPrice             :%f:",pResp.fPrice);
        logDebug2("pResp.fTriggerPrice      :%f:",pResp.fTriggerPrice);
        logDebug2("pResp.fOrderNum          :%f:",pResp.fOrderNum);
        logDebug2("pResp.iSerialNum         :%d:",pResp.iSerialNum);
        logDebug2("pResp.sTradeNo           :%s:",pResp.sTradeNo);
        logDebug2("pResp.fTradePrice        :%f:",pResp.fTradePrice);
        logDebug2("pResp.cHandleInst        :%c:",pResp.cHandleInst);
        logDebug2("pResp.fAlgoOrderNo       :%f:",pResp.fAlgoOrderNo);
        logDebug2("pResp.iStratergyId       :%d:",pResp.iStratergyId);
        logDebug2("pResp.cOffMarketFlg      :%c:",pResp.cOffMarketFlg);
        logDebug2("pResp.cProCli            :%c:",pResp.cProCli);
        logDebug2("pResp.cUserType          :%c:",pResp.cUserType);
        logDebug2("pResp.sOrdEntryTime      :%s:",pResp.sOrdEntryTime);
        logDebug2("pResp.sTransacTime       :%s:",pResp.sTransacTime);
        logDebug2("pResp.sRemarks           :%s:",pResp.sRemarks);
        logDebug2("pResp.iMktType           :%d:",pResp.iMktType);
        logDebug2("pResp.sReasDesc          :%s:",pResp.sReasonDesc);
        logDebug2("pResp.cMarkProFlag       :%c:",pResp.cMarkProFlag);
        logDebug2("pResp.fMarkProVal        :%f:",pResp.fMarkProVal);
        logDebug2("pResp.cParticipantType   :%c:",pResp.cParticipantType);
        logDebug2("pResp.sSettlor           :%s:",pResp.sSettlor);
        logDebug2("pResp.cGTCFlag           :%c:",pResp.cGTCFlag);
        logDebug2("pResp.cEncashFlag        :%c:",pResp.cEncashFlag);
        logDebug2("pResp.sPanID             :%s:",pResp.sPanID);
        logDebug2("pResp.iGrpId             :%d:",pResp.iGrpId);
		
        logDebug2("--------------------END----------------------------");





	if(iKafkaMsgFlag)
 	{
         	logDebug2(" C2D positions writing to Kafa ");
         	if(KafkaProducer(KfConn,sKafkaTopic,(char *)&pResp,sizeof(struct ORDER_RESPONSE)) != TRUE)
         	{
                	printf("\nError while message wrting\n");
         	}
 	}
	else
	{
		if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pResp,sizeof(struct ORDER_RESPONSE), 1)) != 1)
		{
			perror("Error Rms error sent failed ... ");
			exit(1);
		}
	
	}

	logTimestamp("fSendOrdExpRespToFE[EXIT]");
}
/***
  BOOL fCoSendOrdExpRespToFE(struct CO_ORDER_REQUEST *pReq)
  {

  logTimestamp("fCoSendOrdExpRespToFE[Entry]");
  struct  ORDER_RESPONSE pResp;


  pResp.IntRespHeader.iSeqNo= pReq->ReqHeader.iSeqNo;
  pResp.IntRespHeader.iMsgLength= sizeof(struct  ORDER_RESPONSE);
  pResp.IntRespHeader.iErrorId= 0;
  pResp.IntRespHeader.iUserId= pReq->ReqHeader.iUserId;
  pResp.cUserType= pReq->cUserType;
  pResp.IntRespHeader.cSource = pReq->ReqHeader.cSource;
  pResp.IntRespHeader.cSegment= pReq->ReqHeader.cSegment;

  strncpy(pResp.IntRespHeader.sExcgId,pReq->ReqHeader.sExcgId,EXCHANGE_LEN);
  if( pReq->ReqHeader.iMsgCode == TC_INT_ADMIN_EXPIRY_REQ)
  {
  pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EXPIRY_RESP;

  }
  strncpy(pResp.sSecurityId,pReq->sSecurityId,strlen(pReq->sSecurityId));
  strncpy(pResp.sEntityId,pReq->sEntityId,strlen(pReq->sEntityId));
//      strncpy(pResp.sClientId,pReq->sClientId,strlen(pReq->sClientId));
strncpy(pResp.sClientId,pReq->sClientId,CLIENT_ID_LEN);
pResp.fOrderNum= pReq->fOrderNum;
pResp.iOrderValidity= pReq->iOrderValidity;
pResp.iOrderType= pReq->iOrderType;
pResp.iTotalQty= pReq->iTotalQty;
pResp.fPrice= pReq->fPrice;
pResp.cProductId= pReq->cProductId;
pResp.cBuyOrSell = pReq->CoArray[0].cBuySellInd;
pResp.cProCli=pReq->cProCli;
logDebug2("--------------Printing Responce Struct---------------");
logDebug2("MsgCode                      :%d:",pReq->ReqHeader.iMsgCode);
logDebug2("pResp.IntRespHeader.iSeqNo   :%d:",pResp.IntRespHeader.iSeqNo);
logDebug2("pResp.IntRespHeader.iMsgLength :%d:",pResp.IntRespHeader.iMsgLength);
logDebug2("pResp.IntRespHeader.iUserId    :%d:",pResp.IntRespHeader.iUserId);
logDebug2("pResp.IntRespHeader.cSource  :%c:",pResp.IntRespHeader.cSource);
logDebug2("pResp.IntRespHeader.cSegment :%c:",pResp.IntRespHeader.cSegment);
logDebug2("pResp.IntRespHeader.sExcgId  :%s:",pResp.IntRespHeader.sExcgId);
logDebug2("pResp.IntRespHeader.iMsgCode :%d:",pResp.IntRespHeader.iMsgCode);
logDebug2("pResp.fOrderNum		:%lf:",pResp.fOrderNum);
logDebug2("pResp.iTotalQty		:%d:",pResp.iTotalQty);
logDebug2("pResp.fPrice			:%f:",pResp.fPrice);
logDebug2("pResp.cProductId		:%c:",pResp.cProductId);
logDebug2("pResp.cBuyOrSell		:%c:",pResp.cBuyOrSell);
logDebug2("pResp.cUserType              :%c:",pResp.cUserType);
logDebug2("pResp.sSecurityId            :%s:",pResp.sSecurityId);
logDebug2("pResp.sEntityId              :%s:",pResp.sEntityId);
logDebug2("pResp.sClientId              :%s:",pResp.sClientId);
logDebug2("pResp.fOrderNum              :%lf:",pResp.fOrderNum);
logDebug2("pResp.iOrderValidity         :%d:",pResp.iOrderValidity);
logDebug2("pResp.iOrderType             :%d:",pResp.iOrderType);
logDebug2("pReq->fPrice:%lf pReq->iTotalQty:%d:",pReq->fPrice,pReq->iTotalQty);
logDebug2("----------------------END------------------------------");

if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pResp,sizeof(struct ORDER_RESPONSE), 1)) != 1)
{
perror("Error Rms error sent failed ... ");
exit(1);
}
logTimestamp("fCoSendOrdExpRespToFE[EXIT]");
}
 ****/

BOOL SendSPCSucessRespToFE(struct SPAN_CALC_REQUEST *pSPCReq)
{
	struct  SPAN_CALC_RESPONSE  pResp;

	logDebug2("pReq->ReqHeader.iSeqNo = %d",pSPCReq->ReqHeader.iSeqNo);
	pResp.RespHeader.iSeqNo= pSPCReq->ReqHeader.iSeqNo;
	logDebug2("pResp.IntRespHeader.iSeqNo = %d",pResp.RespHeader.iSeqNo);

	pResp.RespHeader.iMsgLength= sizeof(struct SPAN_CALC_RESPONSE);
	logDebug2("pResp.IntRespHeader.iMsgLength = %d",pResp.RespHeader.iMsgLength);

	pResp.RespHeader.iErrorId= 0;
	logDebug2("pReq->ReqHeader.cSegment = %c",pSPCReq->ReqHeader.cSegment);

	pResp.RespHeader.cSegment= pSPCReq->ReqHeader.cSegment;
	logDebug2("pResp.IntRespHeader.cSegment = %c",pResp.RespHeader.cSegment);

	strncpy(pResp.RespHeader.sExcgId,pSPCReq->ReqHeader.sExcgId,EXCHANGE_LEN);
	logDebug2("pResp.IntRespHeader.sExcgId = %s",pResp.RespHeader.sExcgId);

	logDebug2("MsgCode = %d",pSPCReq->ReqHeader.iMsgCode);
	pResp.RespHeader.iMsgCode = TC_INT_SPAN_CALC_RESP;
	logDebug2("iMsgCode = %d",pResp.RespHeader.iMsgCode);

	strncpy(pResp.sSecurityId,pSPCReq->sSecurityId,strlen(pSPCReq->sSecurityId));
	logDebug2("pResp.sSecurityId = %s",pResp.sSecurityId);

	strncpy(pResp.sEntityId,pSPCReq->sEntityId,strlen(pSPCReq->sEntityId));
	logDebug2("pResp.sEntityId = %s",pResp.sEntityId);

	strncpy(pResp.sClientId,pSPCReq->sClientId,strlen(pSPCReq->sClientId));
	logDebug2("pResp.sClientId = %s",pResp.sClientId);
	pResp.cBuyOrSell = pSPCReq->cBuyOrSell;
	pResp.fSmargin = pSPCReq->fSmargin;
	pResp.fEmargin = pSPCReq->fEmargin;
	pResp.fMargin  = pSPCReq->fMargin;

	logDebug2("pResp.fSmargin :%lf:",pResp.fSmargin);
	logDebug2("pResp.fEmargin :%lf:",pResp.fEmargin);
	logDebug2("pResp.fMargin :%lf:",pResp.fMargin);

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pResp,sizeof(struct SPAN_CALC_RESPONSE), 1)) != 1)
	{
		perror("Error Rms error sent failed ... ");
		exit(1);
	}
}

BOOL fDBSelSerNo(CHAR   *cSegment,DOUBLE64 fOrdNo,LONG32 *SrNo,LONG32 *iTrCode,LONG32 *iLegNo,CHAR *cBuySellInd,LONG32 *iMktType)
{
	logTimestamp("Entry : [fDBSelSerNo]");

	MYSQL_RES               *Res;
	MYSQL_ROW               Row;

	CHAR    SelQuery[MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

	logDebug2("cSegment :%c:",cSegment);

	/**if(cSegment == EQUITY_SEGMENT)
	{
		sprintf(SelQuery,"SELECT MAX(EQ_SERIAL_NO),EQ_MSG_CODE FROM EQ_ORDERS WHERE EQ_ORDER_NO = %lf AND EQ_SERIAL_NO = (SELECT MAX(EQ_SERIAL_NO) FROM EQ_ORDERS where EQ_ORDER_NO = %lf AND EQ_ORD_STATUS = \'%c\' ) AND EQ_ORD_STATUS = \'%c\' ",fOrdNo,fOrdNo,TRANSIT_STATUS,TRANSIT_STATUS);
		

	}
	else if((cSegment ==  DERIVATIVE_SEGMENT ) || (cSegment == CURRENCY_SEGMENT))
	{
		sprintf(SelQuery,"SELECT MAX(DRV_SERIAL_NO),DRV_MSG_CODE FROM DRV_ORDERS WHERE DRV_ORDER_NO = \'%lf\' AND DRV_SERIAL_NO = (SELECT MAX(DRV_SERIAL_NO) FROM DRV_ORDERS where DRV_ORDER_NO = %lf AND DRV_STATUS = \'%c\' ) AND DRV_STATUS = \'%c\' ",fOrdNo,fOrdNo,TRANSIT_STATUS,TRANSIT_STATUS);

	}
	else if(cSegment ==  COMMODITY_SEGMENT)
	{
		sprintf(SelQuery,"SELECT MAX(COMM_SERIAL_NO),COMM_MSG_CODE FROM COMM_ORDERS WHERE COMM_ORDER_NO = \'%lf\' AND COMM_SERIAL_NO = (SELECT MAX(COMM_SERIAL_NO) FROM COMM_ORDERS where COMM_ORDER_NO = %lf AND COMM_STATUS = \'%c\') AND COMM_STATUS = \'%c\'  ",fOrdNo,fOrdNo,TRANSIT_STATUS,TRANSIT_STATUS);
	}
	else
	{
		logDebug2("Wrong Segment received");
		return FALSE;
	}**/

	if(cSegment == EQUITY_SEGMENT)
        {
                sprintf(SelQuery,"SELECT EQ_SERIAL_NO, EQ_MSG_CODE,EQ_LEG_NO,EQ_BUY_SELL_IND,EQ_MKT_TYPE FROM (SELECT MAX(EQ_SERIAL_NO) AS SERIAL, EQ_ORDER_NO AS ORD_NO, EQ_LEG_NO AS LEG_NO FROM EQ_ORDERS WHERE EQ_ORDER_NO = %lf GROUP BY EQ_ORDER_NO, EQ_LEG_NO) X, EQ_ORDERS WHERE EQ_ORDER_NO = X.ORD_NO AND EQ_SERIAL_NO = X.SERIAL AND EQ_LEG_NO = X.LEG_NO  AND EQ_ORD_STATUS = \'%c\' AND EQ_ORDER_NO = %lf ",fOrdNo,TRANSIT_STATUS,fOrdNo);
        }
        else if((cSegment ==  DERIVATIVE_SEGMENT ) || (cSegment == CURRENCY_SEGMENT))
        {
                sprintf(SelQuery,"SELECT DRV_SERIAL_NO, DRV_MSG_CODE,DRV_LEG_NO,DRV_BUY_SELL_IND,DRV_MKT_TYPE FROM (SELECT MAX(DRV_SERIAL_NO) AS SERIAL, DRV_ORDER_NO AS ORD_NO, DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS WHERE DRV_ORDER_NO = %lf GROUP BY DRV_ORDER_NO, DRV_LEG_NO) X, DRV_ORDERS WHERE DRV_ORDER_NO = X.ORD_NO AND DRV_SERIAL_NO = X.SERIAL AND DRV_LEG_NO = X.LEG_NO  AND DRV_STATUS = \'%c\' AND DRV_ORDER_NO = %lf ",fOrdNo,TRANSIT_STATUS,fOrdNo);

        }
        else if(cSegment ==  COMMODITY_SEGMENT)
        {
                sprintf(SelQuery,"SELECT COMM_SERIAL_NO, COMM_MSG_CODE,COMM_LEG_NO,COMM_BUY_SELL_IND,COMM_MKT_TYPE FROM (SELECT MAX(COMM_SERIAL_NO) AS SERIAL, COMM_ORDER_NO AS ORD_NO, COMM_LEG_NO AS LEG_NO FROM COMM_ORDERS WHERE COMM_ORDER_NO = %lf GROUP BY COMM_ORDER_NO, COMM_LEG_NO) X, COMM_ORDERS WHERE COMM_ORDER_NO = X.ORD_NO AND COMM_SERIAL_NO = X.SERIAL AND COMM_LEG_NO = X.LEG_NO  AND COMM_STATUS = \'%c\' AND COMM_ORDER_NO = %lf ",fOrdNo,TRANSIT_STATUS,fOrdNo);

        }
        else
        {
                logDebug2("Wrong Segment received");
                return FALSE;
        }

	logDebug3("%s",SelQuery);
	if (mysql_query(DBConvDel, SelQuery) != SUCCESS) {
		sql_Error(DBConvDel);
		free(SelQuery);
		logSqlFatal("Error in DBSelSerNo function Query.");
		return FALSE;
	}

	Res = mysql_store_result(DBConvDel);
	logDebug3("Rows : %i",mysql_num_rows(Res));

	if((Row = mysql_fetch_row(Res)))
	{
		if(Row[0] == NULL)
		{
			logDebug3("1");
			return NO_ROW;
		}
		else
		{
			*SrNo = atoi(Row[0]);
			*iTrCode = atoi(Row[1]);
			*iLegNo = atoi(Row[2]);
                        *cBuySellInd = Row[3][0];
                        if(strcmp(Row[4],"NL")== 0)
                        {
                                *iMktType = NORMAL_MARKET;
                        }
                        else if(strcmp(Row[4],"OL") == 0)
                        {
                                *iMktType = ODDLOT_MARKET;
                        }
                        else if(strcmp(Row[4],"SP")== 0)
                        {
                                *iMktType = SPOT_MARKET;
                        }
                        else if(strcmp(Row[4],"AU") == 0)
                        {
                                *iMktType = AUCTION_MARKET;
                        }
                        else
                        {
                                logDebug2("Invalid MktType :%s:",Row[4]);
                                *iMktType = 1;
                        }

			logDebug3("SrNo = %d",*SrNo);
			logDebug3("iTrCode = %d",*iTrCode);
			logDebug3("iLegNo = %d",*iLegNo);
                        logDebug3("cBuySellInd = %c",*cBuySellInd);
                        logDebug3("iMktType = %d",*iMktType);
		}
	}
	mysql_free_result(Res);
	return TRUE;
}


BOOL	fLoadSysParam()
{
	logTimestamp("Entry fLoadSysParam");
	//	logDebug2("sExch_ID = %s",sExch_ID);
	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;

	//	CHAR	sExch[3];
	CHAR    *sQry = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sQry,"select PARAM_VALUE  from SYS_PARAMETERS where  PARAM_NAME = 'CODE_REA_FLAG';");
	logDebug2("Qry = %s",sQry);

	if (mysql_query(DBConvDel, sQry) != SUCCESS)
	{
		logSqlFatal("Error in select Qry");
		sql_Error(DBConvDel);
	}
	Res = mysql_store_result(DBConvDel);

	if((Row = mysql_fetch_row(Res)))
        {
                logInfo("Fetch row from sysparameter");
                cRmsRejFlag = Row[0][0];
                logDebug2("cRmsRejFlag :%c:",cRmsRejFlag);
        }
        else
        {
                logInfo("no row fetch  from sysparameter");
                cRmsRejFlag = NO;
                logDebug2("cRmsRejFlag :%c:",cRmsRejFlag);
        }

	mysql_free_result(Res);
	free(sQry);
	logTimestamp("Exit fLoadSysParam");

}

BOOL   fFetchErrStr(CHAR *sErrMsg,CHAR *sErrString)
{

	logTimestamp("Entry : fFetchErrStr");
	MYSQL_RES               *Res;
	MYSQL_ROW               Row;
	INT16   iNumRow;

	CHAR SelQuery [MAX_QUERY_SIZE];
	memset(SelQuery,'\0',MAX_QUERY_SIZE);

	logDebug2(" fFetchErrStr sErrorID :%s:",sErrMsg);

	sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = \'%s\' ;",sErrMsg);

	logDebug2("%s",SelQuery);
	if (mysql_query(DBConvDel, SelQuery) != SUCCESS)
	{
		logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
		sql_Error(DBConvDel);
		return FALSE;
	}

	Res = mysql_store_result(DBConvDel);
	logDebug2("Rows : %i",mysql_num_rows(Res));

	iNumRow = mysql_num_rows(Res);
	if(iNumRow != 0)
	{

		if((Row = mysql_fetch_row(Res)))
		{
			logDebug2("serial no  :%s: ",Row[0]);
			strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

		}
	}
	else
	{
		logDebug2("Error ID not Found in DB :%s:",sErrMsg);
		return FALSE;
	}

	logTimestamp("Exit : fFetchErrStr");
	return TRUE;
}


BOOL	FetchPostnSend(CHAR *sExchId,CHAR cSegment,CHAR cProd,CHAR *sClientID,CHAR *sSecId,struct CON_TO_DELIVERY_RESPONSE *pReq,BOOL iPositionType)
{

	logTimestamp("Entry : FetchPostnSend");

	struct C2D_VIEW_NET_POSITION pC2DPos;
	CHAR	sSelQry [ULTRA_DOUBLE_MAX_QUERY_SIZE];
	CHAR    sWhere_Clause[MAX_QUERY_SIZE];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	memset(sSelQry,'\0',ULTRA_DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',MAX_QUERY_SIZE);
	memset(&pC2DPos,'\0',sizeof(struct C2D_VIEW_NET_POSITION));
	
	logDebug2("sExchId :%s:",sExchId);
	logDebug2("cSegment	:%c:",cSegment);
	logDebug2("sSecId 	:%s:",sSecId);
	logDebug2("cProd 	:%c:",cProd);
	logDebug2("pReq->RespHeader.iUserId :%llu:",pReq->RespHeader.iUserId);
	logDebug2("pReq->RespHeader.cSegment:%c:",pReq->RespHeader.cSegment);
	logDebug2("pReq->RespHeader.cSource :%c:",pReq->RespHeader.cSource);

	logDebug2("iPositionType :%d:",iPositionType);
        if(iPositionType == 0)
        {
                sprintf(sWhere_Clause,"SELECT FN_QRY_NET_POSITION(\"%s\",\"%\",\"%s\",\'%c\',\"%\",\"%\",\"%\",\'%c\',\'%\','C',\"%s\");",sClientID,sExchId,cSegment,cProd,sSecId);
        }
        else
        {
                sprintf(sWhere_Clause,"SELECT FN_QRY_NET_POSITION(\"%s\",\"%\",\"%s\",\'%c\',\"%s\",\"%\",\"%\",\'%c\',\'%\','C',\"%s\");",sClientID,sExchId,cSegment,INTEROPS_POSITION,cProd,sSecId);
        }
	

	if(mysql_query(DBConvDel,sWhere_Clause) != SUCCESS)
        {
                logSqlFatal("ERROR in ViewLimit.");
                sql_Error(DBConvDel);
                return FALSE;
        }
        Res = mysql_store_result(DBConvDel);

        if(Row = mysql_fetch_row(Res) )
        {
                sprintf(sSelQry,"%s",Row[0]);
        }
        else
        {
                logInfo("No Output from Fund Limit Function ");
        }
        mysql_free_result(Res);

        printf("sSelQry :%s:\n",sSelQry);

        if (mysql_query(DBConvDel, sSelQry) != SUCCESS)
        {
                logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
                sql_Error(DBConvDel);
                return FALSE;
        }

        Res = mysql_store_result(DBConvDel);
        logDebug2("Rows : %i",mysql_num_rows(Res));

	if((Row = mysql_fetch_row(Res)))
	{

		pC2DPos.RespHeader.iSeqNo= 0;
		pC2DPos.RespHeader.iMsgLength= sizeof(struct C2D_VIEW_NET_POSITION);
		pC2DPos.RespHeader.iErrorId= 0;
		pC2DPos.RespHeader.iUserId= pReq->RespHeader.iUserId;
		pC2DPos.RespHeader.cSegment= pReq->RespHeader.cSegment;
		pC2DPos.RespHeader.cSource = pReq->RespHeader.cSource;

		//strncpy(pC2DPos.RespHeader.sExcgId,pReq->RespHeader.sExcgId,EXCHANGE_LEN);
		//pC2DPos.RespHeader.iMsgCode = TC_INT_CON_DEL_POS_RESP;
	
	//	logDebug2("pReq->sSecurityId :%s:",pReq->sSecurityId);
	//	logDebug2("pReq->sClientId :%s:",pReq->sClientId);

		strncpy(pC2DPos.RespHeader.sExcgId,pReq->RespHeader.sExcgId,EXCHANGE_LEN);
                logInfo("iPositionType :%d:",iPositionType);
                if(iPositionType == 0)
                {
                        pC2DPos.RespHeader.iMsgCode = TC_INT_CON_DEL_POS_RESP;
                }
                else
                {
                        pC2DPos.RespHeader.iMsgCode = TC_INT_CON_DEL_IP_POS_RESP;
                }
                //logDebug2("pReq->sSecurityId :%s:",pReq->sSecurityId);
                //logDebug2("pReq->sClientId :%s:",pReq->sClientId);

                strncpy(pC2DPos.sSecurityID,Row[1],SECURITY_ID_LEN);


		/*strncpy(pC2DPos.sSecurityID,pReq->sSecurityId,strlen(pReq->sSecurityId));
		strncpy(pC2DPos.sClientId,pReq->sClientId,strlen(pReq->sClientId));
		strncpy(pC2DPos.sExchId,Row[2],EXCHANGE_LEN);
		strncpy(pC2DPos.cMktType,Row[3],MARKET_LEN);
		pC2DPos.iBuyQty = atoi(Row[7]);
		pC2DPos.iBuyQtyCF = atoi(Row[8]);
		pC2DPos.iBuyQtyDay = atoi(Row[9]);
		pC2DPos.fBuyVal = atof(Row[10]);
		pC2DPos.fBuyValCF = atof(Row[11]);
		pC2DPos.fBuyValDay = atof(Row[12]);
		pC2DPos.fBuyAvg = atof(Row[13]);
		pC2DPos.iSellQty = atoi(Row[14]);
		pC2DPos.iSellQtyCF = atoi(Row[15]);
		pC2DPos.iSellQtyDay = atoi(Row[16]);
		pC2DPos.fSellVal = atof(Row[17]);
		pC2DPos.fSellValCF = atof(Row[18]);
		pC2DPos.fSellValDay = atof(Row[19]);
		pC2DPos.fSellAvg = atof(Row[20]);
		pC2DPos.iNetQty = atoi(Row[21]);
		pC2DPos.fNetVal = atof(Row[22]);
		pC2DPos.fNetAvg = atof(Row[23]);
		pC2DPos.fGrossQty = atof(Row[24]);
		pC2DPos.fGrossVal = atof(Row[25]);
		pC2DPos.cSegment = Row[26][0];
		pC2DPos.cProductId = Row[27][0];
		pC2DPos.fRelaisedProfit = atof(Row[28]);
		pC2DPos.iRef_ID = atoi(Row[29]);*/


		strncpy(pC2DPos.sExchId,Row[2],EXCHANGE_LEN);



                pC2DPos.iBuyQty = atoi(Row[4]);
                pC2DPos.iBuyQtyCF = atoi(Row[5]);
                pC2DPos.iBuyQtyDay = atoi(Row[6]);
                pC2DPos.fBuyVal = atof(Row[7]);
                pC2DPos.fBuyValCF = atof(Row[8]);
                pC2DPos.fBuyValDay = atof(Row[9]);
                pC2DPos.fBuyAvg = atof(Row[10]);
                pC2DPos.iSellQty = atoi(Row[11]);
                pC2DPos.iSellQtyCF = atoi(Row[12]);
                pC2DPos.iSellQtyDay = atoi(Row[13]);
                pC2DPos.fSellVal = atof(Row[14]);
                pC2DPos.fSellValCF = atof(Row[15]);
                pC2DPos.fSellValDay = atof(Row[16]);
                pC2DPos.fSellAvg = atof(Row[17]);
                pC2DPos.iNetQty = atoi(Row[18]);
                pC2DPos.fNetVal = atof(Row[19]);
                pC2DPos.fNetAvg = atof(Row[20]);
                pC2DPos.fGrossQty = atof(Row[21]);
                pC2DPos.fGrossVal = atof(Row[22]);
                strncpy(pC2DPos.cMktType,Row[3],MARKET_LEN);
                pC2DPos.cProductId = Row[24][0];
                pC2DPos.fRelaisedProfit = atof(Row[25]);
                strncpy(pC2DPos.sClientId,Row[0],CLIENT_ID_LEN);
                pC2DPos.cSegment = Row[23][0];
                pC2DPos.iRef_ID = atoi(Row[26]);
	
		logDebug2("pC2DPos.sClientId :%s:",pC2DPos.sClientId);
                logDebug2("pC2DPos.sSecurityID:%s:",pC2DPos.sSecurityID);
                logDebug2("pC2DPos.sExchId :%s:",pC2DPos.sExchId);
                logDebug2("pC2DPos.cMktType :%s:",pC2DPos.cMktType);
                logDebug2("pC2DPos.iBuyQty :%d:",pC2DPos.iBuyQty);
                logDebug2("pC2DPos.iBuyQtyCF :%d:",pC2DPos.iBuyQtyCF);
                logDebug2("pC2DPos.iBuyQtyDay :%d:",pC2DPos.iBuyQtyDay);
                logDebug2("pC2DPos.fBuyVal :%lf:",pC2DPos.fBuyVal);
                logDebug2("pC2DPos.fBuyValCF :%lf:",pC2DPos.fBuyValCF);
                logDebug2("pC2DPos.fBuyValDay :%lf:",pC2DPos.fBuyValDay);
                logDebug2("pC2DPos.fBuyAvg :%lf:",pC2DPos.fBuyAvg);
                logDebug2("pC2DPos.iSellQty :%d:",pC2DPos.iSellQty);
                logDebug2("pC2DPos.iSellQtyCF :%d:",pC2DPos.iSellQtyCF);
                logDebug2("pC2DPos.iSellQtyDay :%d:",pC2DPos.iSellQtyDay);
                logDebug2("pC2DPos.fSellVal :%lf:",pC2DPos.fSellVal);
                logDebug2("pC2DPos.fSellValCF :%lf:",pC2DPos.fSellValCF);
                logDebug2("pC2DPos.fSellValDay :%lf:",pC2DPos.fSellValDay);
                logDebug2("pC2DPos.fSellAvg :%lf:",pC2DPos.fSellAvg);
                logDebug2("pC2DPos.iNetQty :%d:",pC2DPos.iNetQty);
                logDebug2("pC2DPos.fNetVal:%lf:",pC2DPos.fNetVal);
                logDebug2("pC2DPos.fNetAvg :%lf:",pC2DPos.fNetAvg);
                logDebug2("pC2DPos.fGrossQty :%lf:",pC2DPos.fGrossQty);
                logDebug2("pC2DPos.fGrossVal :%lf:",pC2DPos.fGrossVal);
                logDebug2("pC2DPos.cSegment:%c:",pC2DPos.cSegment);
                logDebug2("pC2DPos.cProductIdy :%c:",pC2DPos.cProductId);
                logDebug2("pC2DPos.fRelaisedProfit:%lf:",pC2DPos.fRelaisedProfit);
                logDebug2("pC2DPos.iRef_ID :%d:",pC2DPos.iRef_ID);
		

		if(iKafkaMsgFlag)
		{
			logDebug2(" C2D positions writing to Kafa ");
			if(KafkaProducer(KfConn,sKafkaTopic,(char *)&pC2DPos,sizeof(struct C2D_VIEW_NET_POSITION)) != TRUE)
			{
				printf("\nError while message wrting\n");
			}
		}


		/*if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pC2DPos,sizeof(struct C2D_VIEW_NET_POSITION), 1)) != 1)
		{
			perror("Error Rms error sent failed ... ");
			exit(1);
		}*/		

	}
	mysql_free_result(Res);
	logTimestamp("Exit : FetchPostnSend");

}

BOOL fSendBoOrdExpRespToFE(struct BO_ORDER_REQUEST *pReq,LONG32 iLeg)
{
        logTimestamp("fSendBoOrdExpRespToFE[Entry]");
        struct  ORDER_RESPONSE pResp;

	memset(&pResp,'\0',sizeof(struct ORDER_RESPONSE));
        pResp.IntRespHeader.iSeqNo= pReq->ReqHeader.iSeqNo;
        pResp.IntRespHeader.iMsgLength= sizeof(struct  ORDER_RESPONSE);
        pResp.IntRespHeader.iErrorId= 0;
        pResp.IntRespHeader.iUserId= pReq->ReqHeader.iUserId;
        pResp.cUserType= pReq->cUserType;
        pResp.IntRespHeader.cSource = pReq->ReqHeader.cSource;
        pResp.IntRespHeader.cSegment= pReq->ReqHeader.cSegment;

        strncpy(pResp.IntRespHeader.sExcgId,pReq->ReqHeader.sExcgId,EXCHANGE_LEN);
        if( pReq->ReqHeader.iMsgCode == TC_INT_ADMIN_EXPIRY_REQ)
        {
                pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EXPIRY_RESP;

        }
        strncpy(pResp.sSecurityId,pReq->sSecurityId,strlen(pReq->sSecurityId));
        strncpy(pResp.sEntityId,pReq->sEntityId,strlen(pReq->sEntityId));

        strncpy(pResp.sClientId,pReq->sClientId,CLIENT_ID_LEN);
        pResp.fOrderNum= pReq->fOrderNum;
        pResp.iOrderValidity= pReq->iOrderValidity;
        pResp.iOrderType= pReq->iOrderType;
        pResp.iTotalQty= pReq->iTotalQty;
        pResp.fPrice= pReq->fPrice;
        pResp.cProductId= pReq->cProductId;
        pResp.cBuyOrSell = pReq->BoArray[0].cBuySellInd;
        pResp.cProCli=pReq->cProCli;
        pResp.iMktType = pReq->iMktType;
	pResp.iLegValue=iLeg;

	
        logDebug2("--------------Printing Responce Struct---------------");
        logDebug2("MsgCode                      :%d:",pReq->ReqHeader.iMsgCode);
        logDebug2("pResp.IntRespHeader.iSeqNo   :%d:",pResp.IntRespHeader.iSeqNo);
        logDebug2("pResp.IntRespHeader.iMsgLength :%d:",pResp.IntRespHeader.iMsgLength);
        logDebug2("pResp.IntRespHeader.iUserId    :%d:",pResp.IntRespHeader.iUserId);
        logDebug2("pResp.IntRespHeader.cSource  :%c:",pResp.IntRespHeader.cSource);
        logDebug2("pResp.IntRespHeader.cSegment :%c:",pResp.IntRespHeader.cSegment);
        logDebug2("pResp.IntRespHeader.sExcgId  :%s:",pResp.IntRespHeader.sExcgId);
        logDebug2("pResp.IntRespHeader.iMsgCode :%d:",pResp.IntRespHeader.iMsgCode);
        logDebug2("pResp.fOrderNum              :%lf:",pResp.fOrderNum);
        logDebug2("pResp.iTotalQty              :%d:",pResp.iTotalQty);
        logDebug2("pResp.fPrice                 :%f:",pResp.fPrice);
        logDebug2("pResp.cProductId             :%c:",pResp.cProductId);
        logDebug2("pResp.cBuyOrSell             :%c:",pResp.cBuyOrSell);
        logDebug2("pResp.cUserType              :%c:",pResp.cUserType);
        logDebug2("pResp.sSecurityId            :%s:",pResp.sSecurityId);
        logDebug2("pResp.sEntityId              :%s:",pResp.sEntityId);
        logDebug2("pResp.sClientId              :%s:",pResp.sClientId);
        logDebug2("pResp.fOrderNum              :%lf:",pResp.fOrderNum);
        logDebug2("pResp.iOrderValidity         :%d:",pResp.iOrderValidity);
        logDebug2("pResp.iOrderType             :%d:",pResp.iOrderType);
        logDebug2("pResp.iMktType               :%d:",pResp.iMktType);
        logDebug2("pReq->fPrice:%lf pReq->iTotalQty:%d:",pReq->fPrice,pReq->iTotalQty);
        logDebug2("pResp.iLegValue               :%d:",pResp.iLegValue);
        logDebug2("----------------------END------------------------------");

        if(iKafkaMsgFlag)
        {
                logDebug2(" C2D positions writing to Kafa ");
                if(KafkaProducer(KfConn,sKafkaTopic,(char *)&pResp,sizeof(struct ORDER_RESPONSE)) != TRUE)
                {
                        printf("\nError while message wrting\n");
                }
        }
        else
        {
                if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pResp,sizeof(struct ORDER_RESPONSE), 1)) != 1)
                {
                        perror("Error Rms error sent failed ... ");
                        exit(1);
                }

        }


/*

        if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pResp,sizeof(struct ORDER_RESPONSE), 1)) != 1)
        {
                perror("Error Rms error sent failed ... ");
                exit(1);
        }
*/
        logTimestamp("fSendBoOrdExpRespToFE[EXIT]");
}

BOOL GetMktType(CHAR *sMktType,LONG32 iMktType)
{

        switch(iMktType)
        {
                case NORMAL_MARKET:
                        strncpy(sMktType,"NL",2);
                        break;
                case ODDLOT_MARKET:
                        strncpy(sMktType,"OL",2);
                        break;
                case SPOT_MARKET:
                        strncpy(sMktType,"SP",2);
                        break;
                case AUCTION_MARKET:
                        strncpy(sMktType,"AU",2);
                        break;
                case CALL_AUCTION_MARKET1:
                        strncpy(sMktType,"A1",2);
                        break;
                case CALL_AUCTION_MARKET2:
                        strncpy(sMktType,"A2",2);
                        break;
                default :
                        logInfo("Invalid Mkt Type  :%d:",iMktType);
                        return FALSE;
                        break;
        }
        logDebug2("Nishant_sMktType :%s:",sMktType);

        return TRUE;


}


void PrintAll(struct  ORDER_REQUEST           *pOE_Req)
{
        logTimestamp("-------------------Start Printing-------------------");

        logDebug3("iSeqNo :%d:",pOE_Req->ReqHeader.iSeqNo);
        logDebug3("iMsgLength   :%d:",pOE_Req->ReqHeader.iMsgLength);
        logDebug3("iMsgCode     :%d:",pOE_Req->ReqHeader.iMsgCode);
        logDebug3("sExcgId      :%s:",pOE_Req->ReqHeader.sExcgId);
        logDebug3("iUserId      :%d:",pOE_Req->ReqHeader.iUserId);
        logDebug3("cSource      :%c:",pOE_Req->ReqHeader.cSource);
        logDebug3("cSegment     :%c:",pOE_Req->ReqHeader.cSegment);
        logDebug3("sSecurityId  :%s:",pOE_Req->sSecurityId);
        logDebug3("sEntityId    :%s:",pOE_Req->sEntityId);
        logDebug3("sClientId    :%s:",pOE_Req->sClientId);
        logDebug3("cProductId   :%c:",pOE_Req->cProductId);
        logDebug3("cBuyOrSell   :%c:",pOE_Req->cBuyOrSell);
        logDebug3("iOrderType   :%d:",pOE_Req->iOrderType);
        logDebug3("iOrderValidity       :%d:",pOE_Req->iOrderValidity);
        logDebug3("iDiscQty     :%d:",pOE_Req->iDiscQty);
        logDebug3("iDiscQtyRem  :%d:",pOE_Req->iDiscQtyRem);
        logDebug3("iTotalQtyRem :%d:",pOE_Req->iTotalQtyRem);
        logDebug3("iTotalQty    :%d:",pOE_Req->iTotalQty);
        logDebug3("iTotalTradedQty      :%d:",pOE_Req->iTotalTradedQty);
        logDebug3("iMinFillQty  :%d:",pOE_Req->iMinFillQty);
        logDebug3("fPrice       :%f:",pOE_Req->fPrice);
        logDebug3("fTriggerPrice        :%f:",pOE_Req->fTriggerPrice);
        logDebug3("fOrderNum    :%f:",pOE_Req->fOrderNum);
        logDebug3("iSerialNum   :%d:",pOE_Req->iSerialNum);
        logDebug3("cHandleInst  :%c:",pOE_Req->cHandleInst);
        logDebug3("fAlgoOrderNo :%f:",pOE_Req->fAlgoOrderNo);
        logDebug3("iStratergyId :%d:",pOE_Req->iStratergyId);
        logDebug3("cOffMarketFlg        :%c:",pOE_Req->cOffMarketFlg);
        logDebug3("cProCli      :%c:",pOE_Req->cProCli);
        logDebug3("cUserType    :%c:",pOE_Req->cUserType);
        logDebug3("sRemarks     :%s:",pOE_Req->sRemarks);
        logDebug3("iMktType     :%d:",pOE_Req->iMktType);
        logDebug3("iAuctionNum  :%d:",pOE_Req->iAuctionNum);
        logDebug3("sGoodTillDaysDate    :%s:",pOE_Req->sGoodTillDaysDate);
        logDebug3("cMarkProFlag :%c:",pOE_Req->cMarkProFlag);
        logDebug3("fMarkProVal  :%f:",pOE_Req->fMarkProVal);
        logDebug3("cParticipantType     :%c:",pOE_Req->cParticipantType);
        logDebug3("sSettlor     :%s:",pOE_Req->sSettlor);
        logDebug3("cGTCFlag     :%c:",pOE_Req->cGTCFlag);
        logDebug3("cEncashFlag  :%c:",pOE_Req->cEncashFlag);
        logDebug3("sPanID       :%s:",pOE_Req->sPanID);
        logDebug2("pOE_Req->iGrpId              :%d:",pOE_Req->iGrpId);
        logDebug2("pOE_Req->splatform:%s:",pOE_Req->sPlatform);
        logDebug2("pOE_Req->sChannel:%s:",pOE_Req->sChannel);

        logTimestamp("-------------------End Printing-------------------");
}
