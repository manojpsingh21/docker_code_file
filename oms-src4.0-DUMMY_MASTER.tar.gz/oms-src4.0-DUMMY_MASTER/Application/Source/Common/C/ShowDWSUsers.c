#include        <stdio.h>
#include        "IPCS.h"

#define UNUSED -1

int main()
{
	struct DWS_ADAPTER_USER_ARRAY *Ptr        ;
	LONG32  lCnt                                            ;

	LockShm(DWSAdapterUserShm);

	Ptr     =       (struct DWS_ADAPTER_USER_ARRAY *)OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE);

	if ( *( (int *) Ptr) == ERROR )
	{
//		printf ("\n Error in Opening Memory \n");
		exit(1);
	}

	for(lCnt=0;lCnt < MAX_DWS_USERS;lCnt++)
	{
		if ((Ptr->dws_adapter_user[lCnt].iRelayId !=UNUSED) && (Ptr->dws_adapter_user[lCnt].ProcessId != UNUSED))
		{
			printf("\n UserId:%.12s\t RelayId:%d\t ProcessId:%d\t ClientId:%s lCnt:%d",Ptr->dws_adapter_user[lCnt].sUser,\
					Ptr->dws_adapter_user[lCnt].iRelayId,Ptr->dws_adapter_user[lCnt].ProcessId,Ptr->dws_adapter_user[lCnt].sClientId,lCnt);
		}
	}

	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		printf("\n Error In Closing SharedMemory ");
		exit(1);
	}
	UnLockShm(DWSAdapterUserShm);
/*

	struct  ADMIN_ADAPTER_USER_ARRAY        *Ptr    ;
	struct  ADMIN_ADAPTER_USER_ARRAY        *Tempptr;

	LONG32  lCnt= 0       ;
	LONG32  iRetVal = ERROR   ;


	printf("Going For Opening \n ");
	LockShm(AdminAdapterUserShm);

	Ptr     =       (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE);
	Tempptr =       Ptr;
	printf("Going For Searching \n");

	for(lCnt=0;lCnt< MAX_DWS_USERS;lCnt++)
	{
		if(Tempptr->admin_adap_user[lCnt].iRelayId != UNUSED)
		{

			printf(" UserId:%s\t RelayId:%d\t ProcessId:%d\t lCnt:%d\n",Tempptr->admin_adap_user[lCnt].sUser,\
					Tempptr->admin_adap_user[lCnt].iRelayId,Tempptr->admin_adap_user[lCnt].ProcessId , lCnt);
		}
	}	

	if ( (CloseSharedMemory((void *)Ptr)) == ERROR )
	{
		logFatal("Error In Closing SharedMemory : AdminAdapterUserShm");
		UnLockShm(AdminAdapterUserShm);
		exit(1);
	}
	UnLockShm(AdminAdapterUserShm);

	logDebug3("iRetVal :%d:",iRetVal);
*/

}

