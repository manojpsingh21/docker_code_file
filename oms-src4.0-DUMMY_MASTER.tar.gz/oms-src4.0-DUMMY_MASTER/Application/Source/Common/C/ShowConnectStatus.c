#include <stdio.h>
//#include <my_global.h>
#include <stdlib.h>
//#include <mysql.h>
#include "IPCS.h"
#include <unistd.h>


//MYSQL           *DBCon;
void main()
{
	CHAR    iRetFlag ;
	LONG32  i;
	LONG32  iRetval;
	struct  EXCH_CONNECT_STATUS ConnectStatus[MAX_GROUPS];
//	DBCon = DB_Connect();


//	while(1)
//	{
		iRetval = fReadConnStat(ConnectStatus);
		if(iRetval == FALSE)
		{
			logFatal("\n Error in Reading Connection Status Shared Memory ");
			exit(0);
		}
	
	
		logPrintf("\n ***************DISPLAYING STATUS OF EXCHANGES *****************");

		logPrintf("\n\n Group Id\tNseEqu\tNseDrv\tBseEqu\tBseCur\tNSECur\tMCXCOM\tBseDRV");
		logPrintf("\n--------\t------\t------\t------\t------\t------\t------\t------");
		
		for(i=0;i<MAX_GROUPS;i++)
		{
			logPrintf("\n\t%d",i+1);
			if(ConnectStatus[i].cNseEqu == '1')
				logPrintf("\tUP");
			else
				logPrintf("\tDOWN");
	
			if(ConnectStatus[i].cNseDrv == '1')
				logPrintf("\tUP");
			else
				logPrintf("\tDOWN");
	
			if(ConnectStatus[i].cBseEqu == '1')
				logPrintf("\tUP");
			else
				logPrintf("\tDOWN");
	
			if(ConnectStatus[i].cBseCur == '1')
				logPrintf("\tUP");
			else
				logPrintf("\tDOWN");
	
			if(ConnectStatus[i].cNseCur == '1')
				logPrintf("\tUP");
			else
				logPrintf("\tDOWN");
	
			if(ConnectStatus[i].cMCXComm == '1')
				logPrintf("\tUP");
			else
				logPrintf("\tDOWN");
			if(ConnectStatus[i].cBseDrv == '1')
                                logPrintf("\tUP");
                        else
                                logPrintf("\tDOWN");
						
/*			if(ConnectStatus[i].cBseComm == '1')
                                logPrintf("\tUP");
                        else
                                logPrintf("\tDOWN");*/
			
		//	if(ConnectStatus[i].cNseCM == '1')
                  //              logPrintf("\tUP");
                    //    else
                      //          logPrintf("\tDOWN");
		
			logPrintf("\n");
		}
	
	
//	}
}
