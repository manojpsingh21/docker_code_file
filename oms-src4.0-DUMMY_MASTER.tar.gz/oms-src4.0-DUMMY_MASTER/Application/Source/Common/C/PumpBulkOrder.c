#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"


LONG32 iOrdRtrToCatalystNSEEQ;

MYSQL *OdrConn;


main(int argc, char *argv[])
{
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;
	DOUBLE64 fPrice ;
	LONG32	i = 0,n =100, pause = 0;
	BOOL            ChkFlag = FALSE;
	CHAR    sErrorMsg[DB_REASON_DESC_LEN];
	LONG32  iQty = 0;
        DOUBLE64 fAmnt = 0.00;
        DOUBLE64 fLtp = 0.00;
	CHAR    sErrorID[10];
	CHAR    Pr_Query [DOUBLE_MAX_QUERY_SIZE];
	LONG32          iError;
	INT16           iStatus;
	LONG32 orderNo = 1;
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);


	OdrConn=DB_Connect();
	struct ORDER_REQUEST  pOrdReq;
	memset(&pOrdReq,'\0',sizeof(struct ORDER_REQUEST));
	//if((iOrdRtrToCatalystNSEEQ = OpenMsgQ(OrdRtrToCatalystNSEEQ)) == ERROR)
	if((iOrdRtrToCatalystNSEEQ = OpenMsgQ(OrdRtrToCatalystBSEEQ)) == ERROR)
	{
		perror("OpenMsgQ ...OrdRtrToCatalystNSEEQ");
		exit(ERROR);
	}
	printf("\n OrdRtrToCatalystNSEEQ opened successfully with id = %d", iOrdRtrToCatalystNSEEQ);


	fPrice = atof(argv[1]);
	n = atoi(argv[1]);
	orderNo = atoi(argv[2]);
	pause = atoi(argv[3]);
	logDebug2 ("fPrice  :%f:",fPrice);

	for(i = 0 ; i < n ; i++)
	{
		usleep(1000);
		if(i == pause) {
			sleep(15);
		}
		orderNo = orderNo + 1;
		logDebug2 ("counter  :%i:",i);
		pOrdReq.ReqHeader.iMsgCode=TC_INT_ORDER_ENTRY_REQ;
		pOrdReq.ReqHeader.iSeqNo = 11  ;
		pOrdReq.ReqHeader.iMsgLength = 760;
		strncpy(pOrdReq.ReqHeader.sExcgId,"BSE",EXCHANGE_LEN);
		pOrdReq.ReqHeader.iUserId = 9223;
		pOrdReq.ReqHeader.cSource = 'M';
		pOrdReq.ReqHeader.cSegment = 'E';
		strncpy(pOrdReq.sSecurityId,"50003",DB_SECURITY_ID_LEN);
		strncpy(pOrdReq.sEntityId,"12345",DB_ENTITY_ID_LEN);
		strncpy(pOrdReq.sClientId,"12345",DB_CLIENT_ID_LEN);
		pOrdReq.iTotalQty = 10;
		pOrdReq.iTotalQtyRem = 1;
		pOrdReq.iDiscQty = 0;
		pOrdReq.iDiscQtyRem = 0;
		pOrdReq.iStratergyId = 5;
		pOrdReq.iTotalTradedQty = 0;
		pOrdReq.cBuyOrSell = 'B' ;
		pOrdReq.iMktType = 1;
		pOrdReq.iOrderType      = 1;
		pOrdReq.fTriggerPrice =0.00 ;           /* 0.00*/
		pOrdReq.iOrderValidity = 0;
		pOrdReq.iMinFillQty = 0;
		pOrdReq.cProCli = 'C';
		pOrdReq.cUserType = 'C';
		pOrdReq.cOffMarketFlg = 'N';
		pOrdReq.cProductId = 'I';
		pOrdReq.cHandleInst = '1';
		pOrdReq.cMarkProFlag= 'C';
	        pOrdReq.fMarkProVal= 0.00;
        	pOrdReq.cParticipantType= 'B';
        	pOrdReq.cGTCFlag= 'N';
        	pOrdReq.cEncashFlag= 'N';
        	pOrdReq.iGrpId = 2;
		logDebug2("Ord_Req->iMktType = %d",pOrdReq.iMktType);


		if(WriteMsgQ( iOrdRtrToCatalystNSEEQ ,(CHAR *) &pOrdReq, sizeof(struct ORDER_REQUEST),1) != 1)
		{
			perror("write to Q failed : ");
			exit(ERROR);
		}
	}

}


