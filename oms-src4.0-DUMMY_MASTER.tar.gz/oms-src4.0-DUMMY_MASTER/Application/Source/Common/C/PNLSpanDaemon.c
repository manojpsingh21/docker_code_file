#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"

MYSQL   *DB_Con;
redisContext *RdConn1;
redisReply *reply1;
redisReply *reply2;

LONG32  iSleepTime = 0;

main(int argc,char *argv[])
{
        logTimestamp("ENTRY [Main]");

	iSleepTime = atoi(argv[1]);
	logDebug3("iSleepTime :%d:",iSleepTime);
	
	DB_Con=DB_Connect();

        RdConn1 = RDConnect();

	fPNLSpanCal();
	return 0;
        logTimestamp("EXIT [Main]");
}
	
BOOL fPNLSpanCal()
{
	logTimestamp("ENTRY [fPNLSpanCal]");
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	CHAR 	sClientId[12];
	memset(sClientId,'\0',12);

	DOUBLE64 fMtm = 0.00;
	DOUBLE64 fHigh = 0.00;
	DOUBLE64 fLow = 0.00;

	CHAR    sSelectQry[MAX_QUERY_SIZE];
	CHAR    sQry[MAX_QUERY_SIZE];
	CHAR 	sCommand[COMMAND_LEN];
	
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	memset(sQry,'\0',MAX_QUERY_SIZE);
	memset(sCommand,'\0',COMMAND_LEN);	

	while(TRUE)
	{
		sleep(iSleepTime);
		memset(sSelectQry,'\0',MAX_QUERY_SIZE);
		sprintf(sSelectQry,"SELECT CLIENT_ID, SUM(MTM)FROM    (SELECT NPT_CLIENT_ID AS CLIENT_ID,    NPT_SECURITY_ID AS SECURITY_ID,    NPT_INSTRUMENT AS INSTRUMENT,    NPT_SYMBOL AS SYMB_SECID,    NPT_EXCH_ID AS EXCH_ID,    NPT_NET_QTY AS NET_QTY,    (CASE    WHEN    NPT.NPT_SEGMENT = 'E'    THEN    (CASE    WHEN    NPT.NPT_NET_QTY > 0    THEN    (CASE    WHEN    RPM.RPM_EXCLUDE_CNC_BUY = 'Y'    AND NPT.NPT_PROD_ID = 'C'    THEN    NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    END)    ELSE (CASE    WHEN    RPM.RPM_EXCLUDE_CNC_SELL = 'Y'    AND NPT.NPT_PROD_ID IN ('C' , 'F')    THEN    NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)    END)    END)    WHEN    NPT.NPT_SEGMENT = 'D'    THEN    (CASE    WHEN    NPT.NPT_NET_QTY > 0    THEN    (CASE    WHEN    NPT.NPT_PROD_ID NOT IN ('I' , 'V', 'B')    AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'    THEN    (CASE    WHEN    RPM.RPM_EXCLUDE_OPT_BUY = 'N'    AND (NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY) > 0    THEN    (NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE 0    END) + (CASE    WHEN    RPM.RPM_EXCLUDE_OPT_CF_BUY = 'N'    AND NPT_TOT_BUY_QTY_CF > 0    THEN    (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) < 0, NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY, 0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE 0    END)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    END)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)    END)    WHEN    NPT.NPT_SEGMENT = 'C'    THEN    (CASE    WHEN    NPT.NPT_NET_QTY > 0    THEN    (CASE    WHEN    NPT.NPT_PROD_ID NOT IN ('I' , 'V', 'B')    AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'    THEN    (CASE    WHEN    RPM.RPM_EXCLUDE_OPT_BUY = 'N'    AND (NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY) > 0    THEN    (NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE 0    END) + (CASE    WHEN    RPM.RPM_EXCLUDE_OPT_CF_BUY = 'N'    AND NPT_TOT_BUY_QTY_CF > 0    THEN    (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) < 0, NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY, 0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE 0    END)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    END)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)    END) * NPT.NPT_CURRENCY_MULTIPLIER    WHEN    NPT.NPT_SEGMENT = 'M'    THEN    (CASE    WHEN    NPT.NPT_NET_QTY > 0    THEN    (CASE    WHEN    NPT.NPT_PROD_ID NOT IN ('I' , 'V', 'B')    AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'    THEN    (CASE    WHEN    RPM.RPM_EXCLUDE_OPT_BUY = 'N'    AND (NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY) > 0    THEN    (NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE 0    END) + (CASE    WHEN    RPM.RPM_EXCLUDE_OPT_CF_BUY = 'N'    AND NPT_TOT_BUY_QTY_CF > 0    THEN    (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) < 0, NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY, 0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    ELSE 0    END)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    END)    ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)    END) * NPT.NPT_MCX_MULTIPLIER    ELSE 0    END) AS MTM    FROM    NET_POSITION_TABLE NPT    LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE    AND NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE    AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT)    LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE)    WHERE    NPT_NET_QTY <> 0) X WHERE    EXCH_ID LIKE '%%'GROUP BY CLIENT_ID;");

		logTimestamp("Query[%s]",sSelectQry);
                if(mysql_query(DB_Con,sSelectQry) != SUCCESS)
                {
                        logSqlFatal("ERROR IN SELECT QUERY");
                        sql_Error(DB_Con);
                }
                Res = mysql_store_result(DB_Con);
                if(mysql_num_rows(Res) == 0)
                {
                        logFatal(".....Zero row returned.......");
                //        mysql_free_result(Res);
                }
                logDebug3("No Of Row :%d",mysql_num_rows(Res));
                while((Row = mysql_fetch_row(Res)))
                {
			memset(sClientId,'\0',12);
			fMtm = 0.00;
			fHigh = 0.00;
			fLow = 0.00;
			
			strncpy(sClientId,Row[0],12);
			fMtm = atof(Row[1]);
			
			logDebug3("sClientId :%s:",sClientId);
			logDebug3("fMtm :%f:",fMtm);

			memset(sCommand,'\0',COMMAND_LEN);
			sprintf(sCommand,"EXISTS PNLSPAN:%s ",sClientId);
	        	logTimestamp("sCommand -> %s",sCommand);
        		reply1 = redisCommand(RdConn1,sCommand);
	        	logDebug3("reply1->integer :%d:",reply1->integer);
			if(reply1->integer == TRUE)
		        {
				memset(sQry,'\0',MAX_QUERY_SIZE);
				sprintf(sQry,"HMGET PNLSPAN:%s HIGH LOW",sClientId);
				logTimestamp("sQry-> %s",sQry);
                		reply2 = redisCommand(RdConn1,sQry);
				fHigh = atof(reply2->element[0]->str);
				fLow = atof(reply2->element[1]->str);
				logDebug3("fHigh:%f:",fHigh);
				logDebug3("fLow:%f:",fLow);
				if(fMtm < fLow)
				{
					memset(sQry,'\0',MAX_QUERY_SIZE);
					sprintf(sQry,"HMSET PNLSPAN:%s LOW %f",sClientId,fMtm);
					logDebug2("sQry:%s:",sQry);
                       			reply2 = redisCommand(RdConn1,sQry);
					
					freeReplyObject(reply2);			
				}
				else if(fMtm > fHigh)
				{
					memset(sQry,'\0',MAX_QUERY_SIZE);
					sprintf(sQry,"HMSET PNLSPAN:%s HIGH %f",sClientId,fMtm);
					logDebug2("sQry:%s:",sQry);
					reply2 = redisCommand(RdConn1,sQry);
					
					freeReplyObject(reply2);			
				}
				else
				{
					freeReplyObject(reply2);
					logDebug3("NOT LOW NOT HIGH MEANS EQUAL");
				}
				//freeReplyObject(reply2);	
			}
			else
			{
				memset(sQry,'\0',MAX_QUERY_SIZE);
                                sprintf(sQry,"HMSET PNLSPAN:%s HIGH %f LOW %f",sClientId,fMtm,fMtm);
                                logTimestamp("sQry-> %s",sQry);
                                reply2 = redisCommand(RdConn1,sQry);
				freeReplyObject(reply2);
			}
			freeReplyObject(reply1);			
		}
		mysql_free_result(Res);
	}

	logTimestamp("EXIT [fPNLSpanCal]");
}
