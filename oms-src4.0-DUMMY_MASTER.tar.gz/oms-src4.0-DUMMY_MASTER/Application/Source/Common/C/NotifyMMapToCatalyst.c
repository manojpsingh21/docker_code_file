#include "IPCS.h"

LONG32	iMemMaptoNotifyCatalyst;
LONG32	iCatalystToRmsVal;
CHAR    cValue;

main(int argc, char *argv[])
{
	logTimestamp("Entry : Main");
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);

	cValue = argv[1][0];

	fOpenMsgQue();
	fRmsProcess(iMemMaptoNotifyCatalyst,iCatalystToRmsVal);

	logTimestamp("Exit : Main");
}

void	fRmsProcess(LONG32 iMemMaptoNotifyCatalyst,LONG32 iCatalystToRmsVal)
{
	logTimestamp("Entry : fRmsProcess");

	CHAR    RcvMsg[RUPEE_MAX_PACKET_SIZE] ;
	LONG32	iCount = 0;
	LONG32	iVal;
	LONG32	iMsgCode;
	LONG32	iMsgLen;
	ULONG64	iUserCode = 0;
	LONG32	iMsgType = 0;

	//	struct 	INT_COMMON_RESP_HDR *Resp;	

	iVal = cValue - '0';
	logDebug2("iVal = %d",iVal);

	while ( TRUE )
	{
		memset(&RcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		//		memset(Resp, '\0', sizeof(struct INT_COMMON_RESP_HDR));

		logInfo("---------================== WHILE LOOP -> RMS Order Count : %d=================---------",iCount++);

		if((ReadMsgQ(iMemMaptoNotifyCatalyst,&RcvMsg,RUPEE_MAX_PACKET_SIZE, 1)) == ERROR)
		{
			logFatal("Error in RcvMsgQ Id = %d",iMemMaptoNotifyCatalyst);
			exit(ERROR);
		}

		//		Resp = (struct INT_COMMON_RESP_HDR)RcvMsg;

		iUserCode = ((struct ORDER_RESPONSE *)RcvMsg)->fOrderNum;
		iMsgCode = ((struct INT_COMMON_RESP_HDR *) RcvMsg )->iMsgCode;
		iMsgLen = ((struct INT_COMMON_RESP_HDR *) RcvMsg )->iMsgLength;
		logDebug2("iUserCode = %llu",iUserCode);
		logDebug2("iUserCode = %d",iMsgCode);
		logDebug2("iMsgLen = %d",iMsgLen);

		iMsgType = (iUserCode % iVal) + 1 ;
		logDebug2("iMsgType = %d",iMsgType);


		//if((WriteMsgQ(iCatalystToRmsVal,RcvMsg,RUPEE_MAX_PACKET_SIZE,iMsgType)) == ERROR)
		if((WriteMsgQ(iCatalystToRmsVal,RcvMsg,iMsgLen,iMsgType)) == ERROR)
		{
			logFatal("Error in WriteMsgQ Id = %d",iCatalystToRmsVal);
			exit(ERROR);
		}

	}

	logTimestamp("Exit : fRmsProcess");

}

void	fOpenMsgQue()
{
	logTimestamp("Entry : fOpenMsgQue");

	if((iMemMaptoNotifyCatalyst = OpenMsgQ(MemMaptoNotifyCatalyst) ) == ERROR)
	{
		logDebug2("Error in OpenMsgQ (MmapToRevRmsVal)");
		exit(ERROR);
	}
	logDebug2("MmapToRevRmsVal open Successfully = %d",iMemMaptoNotifyCatalyst);	

	if ((iCatalystToRmsVal = OpenMsgQ(MmapToNotifyFE)) == ERROR)
	{
		logDebug2("Error in OpenMsgQ (iCatalystToRmsVal)");
		exit(ERROR);
	}
	logDebug2("iCatalystToRmsVal open suceessfully = %d",iCatalystToRmsVal);

	logTimestamp("Exit : fOpenMsgQue");
}
