#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

#define MAX_QUEUES  30

main (int argc, char ** argv)
{
	int LogQId;
	LONG32 iRecvQ;
	int iMsgType ;
	int iCounter= 0 ;

	CHAR sRecv[20000];

	if(argc != 3)
	{
		printf ("\n Wrong call \n");
		exit(1);
	}

	iRecvQ =  atoi(argv[1]);
	iMsgType =  atoi(argv[2]);

	printf("\nTrying to Clear %d",iRecvQ);
	printf("\nMsg Type  %d",iMsgType);

	/*     if (ClearQ(LogQId,Key)==ERROR)*/
	while(TRUE)
	{
		memset(&sRecv,'\0',20000);


		logInfo("-----------------------+++Ready To Recv+++------------------------- ");
		if((ReadMsgQ(iRecvQ,&sRecv,20000, iMsgType)) != 1)
                {
                        logFatal("Error : MsgQId is %d",iRecvQ);
                        exit(ERROR);
                }
		++iCounter;
		logInfo("Read Success :%d:",iCounter);
	}
}

