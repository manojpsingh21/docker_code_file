#include <memory.h>
#include <sys/time.h>
#include <time.h>
#include "IPCS.h"
//#include "NseEQNNFStruct.h"
#include <stdlib.h>


void Twiddle(void *pVoid,short iLen)
{

	char  * pStr = (char  *)pVoid;
	char    cTemp[ 500 ];
	short   i;
	memcpy (cTemp,
			pStr,
			iLen);

	for (i = 0; i < iLen; i++)
	{
		*(pStr + i) = cTemp[iLen - i - 1];
	}
}

void convert_seconds_to_date(long seconds,char *pDateTime)
{
	struct tm *tmr;
	time_t julian;
	tmr = (struct tm *) malloc(sizeof(struct tm )) ;
	julian = seconds + OFFSET - TIMEZONE;
	localtime_r(&julian,tmr);
	sprintf(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_year+1900,tmr->tm_mon+1,tmr->tm_mday,tmr->tm_hour,tmr->tm_min  ,tmr->tm_sec );
	free(tmr);

}


SHORT  fTrim( CHAR *string , SHORT MaxLen )
{
	//        logTimestamp("Entry : [fTrim]");
	SHORT index=0;
	if ( MaxLen <= 0 )
		return 0 ;
	for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
		continue;
	string[index]='\0';
	//        logTimestamp("Exit : [fTrim]");
	return index ;
}

/*
   SHORT fTrim( CHAR  *string , SHORT  MaxLen )
   {
   logTimestamp("Entry : [fTrim]");

   SHORT index=0;
   if ( MaxLen <= 0 )
   return 0 ;
   for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
   continue;
   while(index<MaxLen)
   {
   string[index]=' ';
   index++;
   }
   string[index-1]='\0';
   logTimestamp("Exit : [fTrim]");

   }

 */

void BseTwiddle(void *pVoid,short iLen)
{
	logInfo("Really Inside BseTwiddle");
#ifdef  BIGENDIAN
	logInfo("Inside BseTwiddle");
	CHAR  * pStr = (CHAR  *)pVoid;
	CHAR    cTemp[ 500 ];
	short   i;

	memcpy (cTemp,
			pStr,
			iLen);

	for (i = 0; i < iLen; i++)
	{
		*(pStr + i) = cTemp[iLen - i - 1];
	}
#endif
}
