#include <my_global.h> 
#include <mysql.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "IPCS.h"

#define FIND_USER_RELAY_ERROR          -1
#define Max_Num_Threads                 2
#define OMS_RAWDATA                     1024

void	Process_Request();

LONG32  iTrdRtrToRel= 0;
LONG32  iAdminQueriesToAdaptor = 0;
LONG32  iMmapToD2C1= 0;
SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen );

FILE    *client_rfp;

MYSQL   *DB_Conn;
FILE    *client_fp;
CHAR    sDealrID[50];
CHAR    sSysAdminID [50];
//CHAR    sBAdminID[30];
CHAR    sAllDlrUserId[300];
CHAR    sAllAdmUserId[300];
CHAR    sAdmin2[300];

struct  BRACH_ADMIN
{
	CHAR    sBranchID[30];
	CHAR    sAdminUserId[300];
};

main()
{
	logTimestamp("Entry : [Main]");

	setbuf(stdout , NULL);
	setbuf(stderr , NULL);

	MYSQL_RES      *Res;
	MYSQL_ROW       Row;

	CHAR	*sDealr = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	*SelAdmin = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR    sTempDlrID[50];
	CHAR    sTempAdmin [50];
	memset(sSysAdminID ,'\0',50);
	//        memset(sBAdminID,'\0',50);
	memset(sTempDlrID,'\0',50);
	memset(sTempAdmin,'\0',50);
	memset(sAllAdmUserId,'\0',300);
	memset(sAllAdmUserId,'\0',300);

	DB_Conn = DB_Connect();

	fMsgQue();

	//sprintf(SelAdmin,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE S.ENTITY_TYPE = 'S' AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");
	sprintf(sDealr,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE  ((S.ENTITY_MANAGER_TYPE = 'B' AND S.ENTITY_TYPE = 'D')) AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");


	logDebug2("sDealr :%s:",sDealr);

	if(mysql_query(DB_Conn,sDealr) != SUCCESS)
	{
		sql_Error(DB_Conn);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_Conn);

	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("S.ENTITY_CODE :%s:",Row[1]);
		//      strcat
		strcpy(sDealrID,Row[0]);
		if(strcmp(sTempDlrID,sDealrID) != 0)
		{
			strcpy(sTempDlrID,sDealrID);
			logDebug2("sTempDlrID= %s",sTempDlrID);
			//                      logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			strcat(sAllDlrUserId,sTempDlrID);
			logDebug2("sAllDlrUserId = :%s:",sAllDlrUserId);
			//logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			memset(sDealrID,'\0',50);
		}

	}

	sprintf(SelAdmin,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE  ((S.ENTITY_MANAGER_TYPE = 'B' AND S.ENTITY_TYPE = 'S')) AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");

	logDebug2("SelAdmin:%s:",SelAdmin);

	if(mysql_query(DB_Conn,SelAdmin) != SUCCESS)
	{
		sql_Error(DB_Conn);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_Conn);

	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("S.ENTITY_CODE :%s:",Row[1]);
		//      strcat
		strcpy(sSysAdminID,Row[0]);
		if(strcmp(sTempAdmin,sSysAdminID) != 0)
		{
			strcpy(sTempAdmin,sSysAdminID);
			logDebug2("TempAdmin  :%s:",sTempAdmin);
			//                      logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			strcat(sAllAdmUserId,sTempAdmin);
			logDebug2("sAllAdmUserId= :%s:",sAllAdmUserId);
			//logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			memset(sSysAdminID,'\0',50);
		}

	}

	/**/
	logDebug2(" sAllAdmUserId = :%s:",sAllAdmUserId);
	logDebug2("sAdminID..... = %s",sAllDlrUserId);
	CreateFile();
	free(sDealr);
	Process_Request();		

	logTimestamp("Exit : [Main]");

}

void fMsgQue()
{
	logTimestamp("Entry : fMsgQue");

	if((iTrdRtrToRel= OpenMsgQ(D2C1ToDWSAdap)) == ERROR)
	{
		logFatal("Error in Opening D2C1ToDWSAdap ");
		exit(ERROR);
	}
//	if((iTrdRtrToD2C =  OpenMsgQ(TrdRtrToD2C)) == ERROR)
	if((iMmapToD2C1=  OpenMsgQ(MmapToD2C1)) == ERROR)
	{
		logFatal("Error in Opening MmapToD2C1");
		exit(ERROR);
	}
//	if ((iAdminQueriesToAdaptor = OpenMsgQ(D2C1ToAdminAdap)) == ERROR)
	if ((iAdminQueriesToAdaptor = OpenMsgQ(AdminQueriesToAdaptor)) == ERROR)
	{
		logFatal("Error in Opening MmapToD2C1");
		exit(ERROR);
	}
	logTimestamp("Exit : fMsgQue");
	

}

BOOL CreateFile()
{
	logDebug2("......sAllDlrUserId = :%s:",sAllDlrUserId);
	MYSQL_RES      *Res;
	MYSQL_ROW       Row;
	CHAR            sDealer[ENTITY_ID_LEN];
	CHAR            sClient[CLIENT_ID_LEN];
	CHAR            sTempClient[CLIENT_ID_LEN];

	memset(sTempClient,'\0',CLIENT_ID_LEN);
	memset(sDealer,'\0',ENTITY_ID_LEN);
	memset(sClient,'\0',CLIENT_ID_LEN);

	logDebug2("FILE_PATH :%s:",FILE_PATH);

	client_fp = fopen(FILE_PATH,"w");

	CHAR *Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR *selBrnch = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(Sel,"Select x.clientid AS ClientID, u.USER_CODE AS DealerId\
			from (\
				SELECT ENTITY_MANAGER_CODE AS DealerId, ENTITY_CODE as ClientID\
				FROM ENTITY_MASTER\
				WHERE ENTITY_MANAGER_CODE is not null\
				and ENTITY_TYPE = 'C'\
				UNION\
				SELECT EDM_DEALER_ID as DealerId, EDM_CLIENT_ID as ClientID\
				FROM ENTITY_DEALER_MAPPING) AS x,\
			USER_MASTER AS u\
			where x.DealerId = u.USER_ENTITY_CODE\
			UNION\
			SELECT ENTITY_CODE as ClientID, USER_CODE as DealerId\
			FROM ENTITY_MASTER, USER_MASTER\
			where ENTITY_CODE = USER_ENTITY_CODE and ENTITY_TYPE = 'C'\
			order by 1;");

	logDebug2("Sel :%s:",Sel);

	if (mysql_query(DB_Conn, Sel) != SUCCESS)
	{
		logSqlFatal("Error in selecting Query [CreateFile]");
		free(Sel);
		mysql_close(DB_Conn);
		return ERROR;
	}

	Res = mysql_store_result(DB_Conn);

	if(mysql_num_rows(Res) == 0)
	{
		printf("Zero rows selected");
	}
	else
	{
		printf("Rows selected");

		while((Row = mysql_fetch_row(Res)))
		{
			//                      logDebug2("sAdminID = %s",sAdminID);
			strncpy(sClient,Row[0],CLIENT_ID_LEN);
			strncpy(sDealer,Row[1],ENTITY_ID_LEN);
			//                      	logDebug2("sClient = %s",sClient);
			//                      	logDebug2("sDealer = %s",sDealer);

			if(strncmp(sTempClient,sClient,CLIENT_ID_LEN))
			{
				fprintf(client_fp,"\n%s:%s%s",sClient,sAllDlrUserId,sDealer);
			}
			else
			{
				fprintf(client_fp,",%s",sDealer);

			}

			memset(sTempClient,'\0',CLIENT_ID_LEN);
			strncpy(sTempClient,sClient,CLIENT_ID_LEN);
		}
		fprintf(client_fp,"\n*");

	}
	fclose(client_fp);
	return(0);
}

void Process_Request()
{
	logTimestamp("Entry : [Process_Request]");

	struct  ORDER_RESPONSE    *pOE_REQUEST;
	struct  ORDER_RESPONSE    *pTrade,*pORDER_RESP;


	CHAR	*sPtr;
	CHAR    sCpMsgBuf[RUPEE_MAX_PACKET_SIZE];
	CHAR    sExchId[EXCHANGE_LEN];
	CHAR   *sRetValu;	
	CHAR    sFileString[OMS_RAWDATA];
	CHAR    sTempValue[10];
	CHAR    cSegment;
	CHAR    c_userType;
	CHAR    sfilename[12];
	CHAR    sD2C1DealerId[CLIENT_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sEntityId[CLIENT_ID_LEN];	
	LONG32  iTranscode       =       0;
	LONG32  ilSeqNo          =       0;
	LONG32  imsglength       =       0;
	LONG32  iSndQid          =       0;
	LONG32  iRet_Val         =       0;
	LONG32  iuserid          =       0;
	LONG32  irelayid         =       0;
	LONG32  irelayid1         =       0;
	LONG32  iAlgorelayid     =       0;
	LONG32  iPktCount        =       0;
	LONG32  itempuserid	=       0;
	LONG32  iOrigUserid;
	LONG32  iD2C1DealerUserid;
	LONG32  iD2C1ClientUserid;


	logDebug2("FILE_PATH :%s:",FILE_PATH);

	client_rfp = fopen(FILE_PATH,"r");

	if(client_rfp == NULL)
	{
		logFatal("Error in file open");
		exit(ERROR);
	}
	else
	{
		logDebug2("Open Successful");
	}
	iOrigUserid = 0 ;
	while(TRUE)
	{
		iPktCount++ ;
		memset(sFileString,'\0',OMS_RAWDATA);
		memset(sTempValue,'\0',10);
		memset(sExchId  ,'\0',EXCHANGE_LEN);
		memset( &sCpMsgBuf,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(sD2C1DealerId,'\0',CLIENT_ID_LEN);
		memset(sEntityId,'\0',CLIENT_ID_LEN);
		memset(sClientId,'\0',CLIENT_ID_LEN);
		iD2C1DealerUserid = 0;
		iD2C1ClientUserid = 0;
		memset(sAdmin2,'\0',300);


		logDebug2("===================== No Of Pkts : %d =================",iPktCount);
		if(ReadMsgQ(iMmapToD2C1,&sCpMsgBuf,RUPEE_MAX_PACKET_SIZE,1) ==  ERROR)
		{
			logFatal("Error has occured while reading from Queue = %d ",iMmapToD2C1);
			logFatal("Error in reading the Packet ");
			exit(ERROR);
		}
		else
		{
			logDebug2("Successfully Read From %d Q,",iMmapToD2C1);
		}

		//		logDebug2("c_userType: %c",((struct ORDER_RESPONSE *)sCpMsgBuf )->cUserType);

		iuserid  = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId;
		iOrigUserid = ((struct INT_COMMON_RESP_HDR*) sCpMsgBuf )->iUserId;

		logDebug2("User Id Received in RelayDir is  : %d",iuserid);

		cSegment = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->cSegment ;

		logDebug2("Segment : %c",cSegment);

		imsglength = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iMsgLength;

		logDebug2("msglength : %d", imsglength);

		iTranscode = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iMsgCode;

		logDebug2("Transcode : %d",iTranscode );

		ilSeqNo   =   ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iSeqNo ;

		logDebug2("lSeqNo: %d",ilSeqNo);

		memcpy(sExchId ,((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->sExcgId, EXCHANGE_LEN);

		rewind(client_rfp);
		switch(iTranscode)
		{
			case TC_INT_ORDER_ENTRY_RSP:
			case TC_INT_ORDER_MODIFY_RSP:
			case TC_INT_ORDER_CANCEL_RSP:
			case TC_INT_TRADE_RESP:
			case TC_INT_OE_CONF_RESP:
			case TC_INT_OM_CONF_RESP:
			case TC_INT_OC_CONF_RESP:
			case TC_INT_OE_ERROR_RESP:
			case TC_INT_OM_ERROR_RESP:
			case TC_INT_OC_ERROR_RESP:
			case TC_INT_OE_FREEZE_RESP:
			case TC_INT_SL_ORDER_TRIG_RESP:
				//			case TC_INT_CON_DEL_RESP:
			case TC_INT_MKT_LMT_CONVT_RESP:
			case TC_INT_OFF_ORDER_ENTRY:
			case TC_INT_OFF_ORDER_MODIFY:
			case TC_INT_OFF_ORDER_CANCEL:	
			case TC_INT_OFF_ORDER_ENTRY_RSP:
			case TC_INT_OFF_ORDER_MODIFY_RSP:
			case TC_INT_OFF_ORDER_CANCEL_RSP:
			case TC_INT_OE_REJECTION                        :
			case TC_INT_OM_REJECTION                        :
			case TC_INT_OC_REJECTION                        :
			case TC_INT_RMS_OE_REJECTION                    :
			case TC_INT_RMS_OM_REJECTION                    :
			case TC_INT_RMS_OC_REJECTION                    :

				/*	pORDER_RESP=(struct ORDER_RESPONSE *) sCpMsgBuf ;
					strncpy(sClientId,pORDER_RESP->sClientId,CLIENT_ID_LEN);
					strncpy(sTempValue,pORDER_RESP->sClientId,CLIENT_ID_LEN);				
					Changed By Darshan 16th Feb 2017	*/	

				strncpy(sClientId,((struct ORDER_RESPONSE *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct ORDER_RESPONSE *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);				

				break;

			case TC_INT_MTM_BREACH_RSP:
				strncpy(sClientId,((struct INT_MTM_BREACH_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct INT_MTM_BREACH_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);				
				break;
			//case TC_INT_ORDER_REJECTION:
			case TC_INT_RMS_ORD_REJECTION:
				strncpy(sClientId,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);	
				break;
				/**	
				  case TC_INT_CON_DEL_RESP:
				  strncpy(sClientId,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				  strncpy(sTempValue,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				  break;
				 **/
			case TC_INT_CON_DEL_POS_RESP:
				strncpy(sClientId,((struct C2D_VIEW_NET_POSITION *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct C2D_VIEW_NET_POSITION *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				break;	


			default :
				logFatal("Invalid Transcode :%d:",iTranscode);
				continue;
				//  break;

		}
		fTrim(sTempValue,strlen(sTempValue));
		logDebug2("sTempValue [%s]",sTempValue);
		logDebug2("iOrigUserid [%d]",iOrigUserid);

		while(fgets(sFileString,OMS_RAWDATA,client_rfp) != NULL)
		{
			//	logDebug2("sFileString -> :%s: sTempValue -> :%s:",sFileString,sTempValue);

			if(strncmp(sFileString,sTempValue,strlen(sTempValue)) == 0)
			{
				logDebug2("sFileString[%s]",sFileString);
				sRetValu = strtok(sFileString,":");
				logDebug2("Molu sRetValu[%s]",sRetValu);		
				if(strcmp(sRetValu,sTempValue) == 0)
				{
					while(sRetValu != NULL)
					{
						sRetValu = strtok(NULL,",");
						logDebug2("sRetValu [%s]",sRetValu);
						if(sRetValu == NULL)
						{
							break;
						}
						logDebug2("sRetValu [%s] sTempValue [%s]",sRetValu,sTempValue);

						if(atoi(sRetValu) != iOrigUserid) 
						{
							((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId = atoi(sRetValu);
							((struct ORDER_RESPONSE *) sCpMsgBuf )->cUserType = 'C';

							iuserid = 0;
							iuserid = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId;
							irelayid = find_user_adapter(iuserid);

							if (irelayid == FIND_USER_RELAY_ERROR)
							{
								logInfo("Relay No for this particular userid is not found :%d:",iuserid);
							}

							else
							{
								iRet_Val = WriteMsgQ(iTrdRtrToRel,sCpMsgBuf,imsglength,irelayid);
								if(iRet_Val == ERROR)
								{
									logFatal(" No Data is  present in the Packet ");
									fclose(client_rfp);
									exit(1);
								}
							}

						}
					}
				}
			}

		}
		logDebug2("sAllAdmUserId :%s:",sAllAdmUserId);
		while(sAllAdmUserId!= NULL)
		{
			strncpy(sAdmin2,sAllAdmUserId,strlen(sAllAdmUserId));
			sPtr = strtok(sAdmin2,",");
			logDebug2("sAdminval [%s]",sAdmin2);

			while(sPtr != NULL)
			{
				logDebug2("sPtr :%s:",sPtr);
				itempuserid = atoi(sPtr);
				logDebug2("itempuserid :%d:",itempuserid);
				logDebug2("atoi(itempuserid ) :%d:",itempuserid);
				logDebug2("iOrigUserid ) :%d:",iOrigUserid);
				if (itempuserid == iOrigUserid )
				{
					logDebug2("Dropping packet");
					sPtr = strtok(NULL,",");
					continue;
				}

				((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId = itempuserid;

				irelayid1 = find_admin_adapter (((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId);
				if (irelayid1 == FIND_USER_RELAY_ERROR)
				{
					logInfo(" Admin Relay No for this particular userid is not found :%d:",((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId);
				}
				else
				{
					logDebug2("Writing to AdminAdaptor");
					iRet_Val = WriteMsgQ(iAdminQueriesToAdaptor,sCpMsgBuf,imsglength,irelayid1);
					if (iRet_Val == ERROR)
					{
						logFatal(" No Data is  present in the Packet ");
						exit(1);
					}
				}
				sPtr = strtok(NULL,",");
			}


			logInfo("Need to Check is order is placed by Controller ");
			if(sPtr == NULL)
			{
				logDebug2("Here 1");
				break;
			}


		}
	}/** End of while loop **/
	fclose(client_rfp);


}


SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen )
{
	logTimestamp("Entry : [fTrim]");

	SHORT Strlen=0;

	if ( MaxLen <= 0 )
	{
		return FALSE ;
	}

	for( ; Str_In[Strlen] != ' ' && Strlen < MaxLen ; Strlen++ )
	{
		continue;
	}
	Str_In[Strlen]='\0';

	logTimestamp("Exit : [fTrim]");
	return Strlen;
}


