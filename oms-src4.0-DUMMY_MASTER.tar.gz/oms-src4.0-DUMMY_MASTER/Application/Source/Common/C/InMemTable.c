#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "RedisStruct.h"
#include "hiredis.h"
//#include "Defination.h"

MYSQL           *DBCon;
MYSQL_RES       *Res;
MYSQL_ROW       Row;
redisContext	*RDCon,*RDConM ;

int main(int argc,char *argv[])
{
	char	sArgs[10];
	int	iChoice;
	RDCon = RDConnect(REDIS_TYPE_PRICE_BCAST);
	DBCon = DB_Connect();
	setbuf(stdout,NULL);
	setbuf(stderr,NULL);
	if(argc == 2)
	{
		switch(atoi(argv[1]))
		{
			case 98:
				CleanUpMain();
				CleanUpStatic();
			case 99:
				SecMaster();
				BhavCopy();
				// ErrorMaster();
				EQVarElm();
				// RMSFundLimit();
				// RMSProdMaster();
				// RMSScripBlock();
				// RMSProfileMaster();
				// RMSSecLimitPrio();
				// EntityMasters();
				//SysParameters();
				RMSFnoExpMargin();
				RMSFnoSpanMargin();
				//RmsBlockLog();
				//Holdings();
				//BatchProcess();
				// Entity_Bank_Details();
				//CF_Position();
				exit(ERROR);
				break;
				//	case 1 :
				//		ErrorMaster();
				//	break;
			case 1 :
				EQVarElm();
				break;
				//        case 3 :
				//      	RMSFundLimit();
				//        break;
				//    case 4 :
				//              RMSProdMaster();
				//  break;
				//case 5:
				//	RMSProfileMaster();
				// break;
				// case 6:
				//       RMSSecLimitPrio();
				//break;
				// case 7:
				//       EntityMasters();
				// break;
			case 2:
				SecMaster();
				break;
			case 3:
				BhavCopy();
				break;
				// case 10:
				//       SysParameters();
				//  break;
			case 4:
				RMSFnoExpMargin();
				break;
			case 5:
				RMSFnoSpanMargin();
				break;
				//  case 13:
				//	RmsBlockLog();
				//  break;
				// case 14:
				//        RMSScripBlock();
				// break;
				//case 15:
				//      Holdings();
				// break;
				//case 16:
				//      BatchProcess();
				// break;
				//              case 17:
				//                      AttributeMaster();
				//              break;
				//	case 18:
				//     		Entity_Bank_Details();
				//    break;
				//  case 19:
				//	CF_Position();
				// break;
			case 20 : 
				DPRCM();
				break;
			
			case 21 :
				RevKeyClear();
				break;

			case 69:
				AMOExpiryCheck(atoi(argv[1]));
				break;

			default:
				logFatal("Invalid Choice");
		}
	}
	else
	{
		while(TRUE)
		{

			logInfo("Enter Choice :");
			logInfo("1  => ERROR_MASTER ");
			logInfo("2  => RMS_EQ_VAR_ELM ");
			logInfo("3  => RMS_FUND_LIMIT ");
			logInfo("4  => RMS_PRODUCT_MASTER");
			logInfo("5  => RMS_RISK_PROFILE_MASTER");
			logInfo("6  => RMS_SECURITY_LIMIT_PRIORITY");
			logInfo("7  => ENTITY_MASTER + USER_MASTER");
			logInfo("8  => SECUIRTY_MASTER");
			logInfo("9  => BHAV_COPY");
			logInfo("10 => SYS_PARAMETERS");
			logInfo("11 => RMS_FNO_EXP_MARGIN");
			logInfo("12 => RMS_FNO_SPAN_MARGIN");
			logInfo("13 => RMS_BLOCK_LOG");
			logInfo("14 => RMS_SCRIP_BLOCK");
			logInfo("15 => RMS_CLIENT_SECURITY_LIMIT");
			logInfo("16 => BATCH_PROCESS");
			logInfo("17 => ATTRIBUTE_MASTER");
			logInfo("18 => ENTITY_BANK_DETAILS");
			logInfo("19 => CF_POSITION");
			logInfo("0  => Exit");
			logInfo("  :=>");
			scanf("%d",&iChoice);
			switch(iChoice)
			{
				case 0:
					exit(ERROR);
					break;

					//	case 1 : 
					//		ErrorMaster();
					//	break;
				case 1 : 
					EQVarElm(); 		
					break;
					//	case 3 :
					//		RMSFundLimit();
					//	break;
					//	case 4 :
					//		RMSProdMaster();
					//	break;
					//	case 5: 		
					//		RMSProfileMaster();
					//	break;
					//	case 6:
					//		RMSSecLimitPrio();
					//	break;
					//	case 7:
					//		EntityMasters();
					//	break;
				case 2:
					SecMaster();
					break;
				case 3:
					BhavCopy();
					break;
					//	case 10:
					//		SysParameters();
					//	break;
				case 4:
					RMSFnoExpMargin();
					break;
				case 5:
					RMSFnoSpanMargin();
					break;
					//	case 13:
					//		RmsBlockLog();
					//	break;
					//	case 14:
					//		RMSScripBlock();

					//	break;
					//	case 15:
					//		Holdings();
					//	break;

					//	case 16:
					//             BatchProcess();
					//    break;

					//		case 17:
					//			AttributeMaster();
					//		break;
					//	case 18:
					//		Entity_Bank_Details();
					//	break;

					//	case 19:
					//		CF_Position();
					//	break;

				default:	
					logFatal("Invalid Choice");
			}	
		}
	}	
}

int CleanUpMain()
{
	redisReply *reply,*replyCnt;
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	int		i = 0;
	sprintf(sRedQuery,"DEL %s",CLORDID_EQ);
	reply = redisCommand(RDConM,sRedQuery);
	freeReplyObject(reply);
	sprintf(sRedQuery,"DEL %s",CLORDID_FO);
	reply = redisCommand(RDConM,sRedQuery);
	freeReplyObject(reply);
	sprintf(sRedQuery,"DEL %s",CLORDID_MX);
	reply = redisCommand(RDConM,sRedQuery);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS *%s:*",SET_ORDERS);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"HMGET %s %s",reply->element[i]->str,ORD_ORDER_OFFON);
		replyCnt = redisCommand(RDConM,sRedQuery);
		if(replyCnt->element[0]->str[0] == 'Y')
		{
			freeReplyObject(replyCnt);
			continue;
		}
		freeReplyObject(replyCnt);

		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_POS);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_EQ_EXCH_NO);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_FO_EXCH_NO);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_MX_EXCH_NO);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_REQ_SEQ_EQ);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_REQ_SEQ_FO);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s*",SET_REQ_SEQ_MX);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s:*",SET_CLIENT);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	sprintf(sRedQuery,"KEYS %s:*",SET_CLIENT_POS);
	reply = redisCommand(RDConM,sRedQuery);
	for(i = 0; i < reply->elements; i++)
	{
		sprintf(sRedQuery,"DEL %s",reply->element[i]->str);
		replyCnt = redisCommand(RDConM,sRedQuery);
		freeReplyObject(replyCnt);
	}
	logDebug2("Keys Deleted -> %d",reply->elements);
	freeReplyObject(reply);

	return 0;
}

int CleanUpStatic()
{
	redisReply *reply;
	reply = redisCommand(RDCon,"FLUSHDB");
	if(!strcasecmp(reply->str,"OK"))
	{
		logDebug2("Redis DB 1 is flushed");
	}
	else if(reply->type == REDIS_REPLY_ERROR)
	{
		logFatal("Error in cleaning DB :%s:",reply->str);
	}
	freeReplyObject(reply);
	return 0;
}

int     BhavCopy()
{
	logTimestamp("Entry:[BhavCopy]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT BC_EXCHANGE,BC_SEGMENT,BC_SCRIP_CODE,BC_CLOSE_PRICE FROM BHAV_COPY");
	logDebug1("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s%s%s %s %s",SET_SM,Row[0],Row[1],Row[2],SM_LTP,Row[3]);

		logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery); 	
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security ID[%s]",Row[2]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}		
		freeReplyObject(reply);
	}
	logTimestamp("Exit:[BhavCopy]");
	return 0;
}


/***int	ErrorMaster()
  {
  logTimestamp("Entry:[ErrorMaster]");
  redisReply *reply;
  INT16   iNumRow;
  CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

  sprintf(sSelQuery," SELECT ERROR_ID,ERROR_CODE FROM ERROR_MASTER");
  logDebug1("sSelQuery :%s:",sSelQuery);
  if(mysql_query(DBCon,sSelQuery) != 0)
  {
  logFatal("Some thing wrong with sSelQuery query Pls check");
  sql_Error(DBCon);
  mysql_close(DBCon);
  return (-1);
  }
  Res = mysql_store_result(DBCon);
  iNumRow = mysql_num_rows(Res);
  logDebug1("iNumRow :%i:",iNumRow);
  while(Row = mysql_fetch_row(Res))
  {		
  sprintf(sRedQuery,"HMSET %s:%s %s %s",SET_ERR_MASTER,Row[0],ERROR_CODE,Row[1]);
  logDebug2("sRedQry :%s:",sRedQuery);
  reply = redisCommand(RDCon,sRedQuery);
  if(!strcasecmp(reply->str,"OK"))
  {
  logDebug2("Values added to the hash for ID[%s]",Row[0]);
  }
  else if(reply->type == REDIS_REPLY_ERROR)
  {
  logFatal("Error in adding values to hash :%s:",reply->str);
  }
  freeReplyObject(reply);
  }
  logTimestamp("Exit:[ErrorMaster]");
  return 0;
  }***/

int	EQVarElm()
{
	logTimestamp("Entry:[EQVarElm]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT SEC_SYMBOL,SEC_SERIES_GRP,SCRIP_ID,ISIN,SECURITY_VAR,INDEX_VAR,VAR_MARGIN,EXTREME_LOSS_RATE,ADHOC_MARGIN, \
			APPLICABLE_MARGIN_RATE,EXCH_ID,SEM_MCX_LOT FROM	RMS_EQ_VAR_ELM;");// WHERE SCRIP_ID = 11536");
	logDebug1("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_VAR,Row[2],VE_SEC_SYMBOL,Row[0],VE_SEC_SERIES_GRP,\
				Row[1],VE_SCRIP_ID,Row[2],VE_ISIN,Row[3],VE_SECURITY_VAR,Row[4],VE_INDEX_VAR,Row[5],VE_VAR_MARGIN,Row[6],VE_EXTREME_LOSS_RATE,Row[7],VE_ADHOC_MARGIN,Row[8],\
				VE_APPLICABLE_MARGIN_RATE,Row[9],VE_EXCH_ID,Row[10],VE_SEM_MCX_LOT,Row[11]);
		logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security ID[%s]",Row[2]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[EQVarElm]");
	return 0;
}		
/***
  int     RMSFundLimit()
  {
  logTimestamp("Entry:[RMSFundLimit]");
  redisReply *reply;
  INT16   iNumRow;
  CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  sprintf(sSelQuery,"SELECT CLIENT_ID,C_CASH_BALANCE,C_BANK_HOLD,C_ADHOC_LIMIT,NC_NSE_RECEIVABLES,NC_BSE_RECEIVABLES,NC_COLLATERALS, \
  NC_REALISED_PROFIT,TOTAL_CASH_UTILIZED FROM RMS_FUND_LIMIT");
  logDebug1("sSelQuery :%s:",sSelQuery);
  if(mysql_query(DBCon,sSelQuery) != 0)
  {
  logFatal("Some thing wrong with sSelQuery query Pls check");
  sql_Error(DBCon);
  mysql_close(DBCon);
  return (-1);
  }
  Res = mysql_store_result(DBCon);
  iNumRow = mysql_num_rows(Res);
  logDebug1("iNumRow :%i:",iNumRow);
  while(Row = mysql_fetch_row(Res))
  {
  sprintf(sRedQuery,"HMSET %s:%s:CAP %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_FUND_LIMIT,Row[0],FL_CASH_BALANCE,Row[1],FL_BANK_HOLD,Row[2],FL_ADHOC_LIMIT,Row[3],FL_NSE_RECEIVABLES,Row[4],FL_BSE_RECEIVABLES,Row[5],FL_COLLATERALS,Row[6],FL_REALISED_PROFIT,Row[7],FL_CASH_UTILIZED,Row[8],FL_TYPE,"CAP");
  logDebug2("sRedQry :%s:",sRedQuery);
  reply = redisCommand(RDCon,sRedQuery);
  if(!strcasecmp(reply->str,"OK"))
  {
  logDebug2("Values added to the hash for ID[%s]",Row[2]);
  }
  else if(reply->type == REDIS_REPLY_ERROR)
  {
  logFatal("Error in adding values to hash :%s:",reply->str);
  }			
  freeReplyObject(reply);
  }
  logTimestamp("Exit:[RMSFundLimit]");
  return 0;
  }

  int     RMSProdMaster()
  {
  logTimestamp("Entry:[RMSProdMaster]");
  redisReply *reply;
  INT16   iNumRow;
  CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  sprintf(sSelQuery,"SELECT EXCH_ID,SEGMENT,PRODUCT_CODE,PRODUCT_STATUS,TRADING_GROUP FROM RMS_PRODUCT_MASTER;");
  logDebug1("sSelQuery :%s:",sSelQuery);
  if(mysql_query(DBCon,sSelQuery) != 0)
  {
  logFatal("Some thing wrong with sSelQuery query Pls check");
  sql_Error(DBCon);
  mysql_close(DBCon);
  return (-1);
  }
  Res = mysql_store_result(DBCon);
  iNumRow = mysql_num_rows(Res);
  logDebug1("iNumRow :%i:",iNumRow);
  while(Row = mysql_fetch_row(Res))
  {
  sprintf(sRedQuery,"HMSET %s:%s:%s:%s:%s %s %s",SET_PROD_MASTER,Row[0],Row[1],Row[2],Row[4], \
  RMS_PROD_MS_STATUS,Row[3]);
  logDebug2("sRedQry :%s:",sRedQuery);
  reply = redisCommand(RDCon,sRedQuery);
  if(!strcasecmp(reply->str,"OK"))
  {
  logDebug2("Values added to the hash for Security ID[%s:%s:%s:%s]",Row[0],Row[1],Row[2],Row[4]);
  }
  else if(reply->type == REDIS_REPLY_ERROR)
  {
logFatal("Error in adding values to hash :%s:",reply->str);
}

freeReplyObject(reply);			
}
logTimestamp("Exit:[RMSProdMaster]");
return 0;
}

int     RMSScripBlock()
{
	logTimestamp("Entry:[RMSProdMaster]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT EXCH_ID,SEGMENT,SCRIP_CODE,CONCAT(ORDERBUYSELL,PRODUCT),PROFILE_ID FROM rupeeSQLDB.SECURITY_RMS_BLOCK_DETAIL;");
	logDebug1("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s:%s:%s %s %s %s %s",SET_SCRIP_BLOCK,Row[0],Row[1],Row[2],RMS_SB_STATUS,Row[3],RMS_SB_PROFILE_ID,Row[4]);
		logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security ID[%s:%s:%s]",Row[0],Row[1],Row[2]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[RMSProdMaster]");
	return 0;
}

int     RMSProfileMaster()
{
	logTimestamp("Entry:[RMSProfileMaster]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
	sprintf(sSelQuery,"SELECT RPM_CODE,RPM_NAME,RPM_ACTIVE,RPM_VALIDATE,RPM_MAX_ORD_QTY,RPM_MAX_LOT,RPM_MAX_ORD_VALUE,RPM_MTM_LOSSPER,RPM_CNC_SELL_BEN_PER,\				RPM_EXPO_MAR,RPM_REALIZE_PROFIT,RPM_COLL_FO,RPM_FUNDLIMITTYPE,RPM_MTOMSQOFFPER,RPM_MRGN_METHOD_EQ,RPM_MRGN_METHOD_FO,RPM_GEN_MULT, \
			RPM_EQ_MAR_TYPE,RPM_DR_MAR_TYPE,RPM_CD_MAR_TYPE,RPM_COM_MAR_TYPE,RPM_DR_MARGIN,RPM_CD_MARGIN,RPM_COM_MARGIN,RPM_EQ_MARGIN,\
			IFNULL(RPM_EQ_FACTOR,0),RPM_DR_FACTOR,RPM_CD_FACTOR,RPM_COM_FACTOR,MRGFACTCOM,MRGFACTEQ,MRGFACTDR,INTFACTCOM,INTFACTEQ,INTFACTDR,RPM_EQ_BASKET,\		RPM_DR_BASKET, RPM_CREATED_BY,DATE_FORMAT(RPM_CREATED_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),INTFACTCD,MRGFACTCD,RPM_PROD_CON_FLG,RPM_ELM_STATUS FROM RMS_RISK_PROFILE_MAST;");// WHERE RPM_CODE = 'HR';");
	logDebug1("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", \
				SET_PROFILE_MASTER,Row[0],RPM_CODE,Row[0],RPM_NAME,Row[1],RPM_ACTIVE,Row[2],RPM_VALIDATE,Row[3],RPM_MAX_ORD_QTY,Row[4],RPM_MAX_LOT,Row[5],\
				RPM_MAX_ORD_VALUE,Row[6], \
				RPM_MTM_LOSSPER,Row[7],RPM_CNC_SELL_BEN_PER,Row[8],RPM_EXPO_MAR,Row[9],RPM_REALIZE_PROFIT,Row[10],RPM_COLL_FO,Row[11],RPM_FUNDLIMITTYPE, \
				Row[12],RPM_MTOMSQOFFPER,Row[13],RPM_MRGN_METHOD_EQ,Row[14],RPM_MRGN_METHOD_FO,Row[15],RPM_GEN_MULT,Row[16],RPM_EQ_MAR_TYPE,Row[17], \
				RPM_DR_MAR_TYPE,Row[18],RPM_CD_MAR_TYPE,Row[19],RPM_COM_MAR_TYPE,Row[20],RPM_DR_MARGIN,Row[21],RPM_CD_MARGIN,Row[22],RPM_COM_MARGIN,Row[23],\
				RPM_EQ_MARGIN,Row[24],RPM_EQ_FACTOR,Row[25],RPM_DR_FACTOR,Row[26],RPM_CD_FACTOR,Row[27],RPM_COM_FACTOR,Row[28],MRGFACTCOM,Row[29], \
				MRGFACTEQ,Row[30],MRGFACTDR,Row[31],INTFACTCOM,Row[32],INTFACTEQ,Row[33],INTFACTDR,Row[34],RPM_EQ_BASKET,Row[35],RPM_DR_BASKET,Row[36], \
				RPM_CREATED_BY,Row[37],RPM_CREATED_DATE,Row[38],INTFACTCD,Row[39],MRGFACTCD,Row[40],RPM_PROD_CON_FLG,Row[41],RPM_ELM_STATUS,Row[42]);
		logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security ID[%s]",Row[2]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[RMSProfileMaster]");
	return 0;
}

int     RMSSecLimitPrio()
{
	logTimestamp("Entry:[RMSSecLimitPrio]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT SECURITY_SOURCE_TYPE,SECURITY_SOURCE_FROM,PRIORITY FROM RMS_SECURITY_LIMIT_PRIORITY;");
	logDebug1("sSelQry :%s:",sSelQuery);
	if (mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return(-1);
	}

	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s",SET_SEC_LIMIT,Row[0],SECURITY_SOURCE_TYPE,Row[0],SECURITY_SOURCE_FROM,Row[1],PRIORITY,Row[2]);
		logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security source type[%s]",Row[0]);
		}
		else
		{
			logFatal("Error in adding value to hash[%s]",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[RMSSecLimitPrio]");
	return 0;
}

int EntityMasters()
{
	logTimestamp("Entry:[EntityMasters]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR    sSubKeyExp[25];
	CHAR 	sLog_off_time[30],sLog_in_time[30],sPass_cng_date[30];
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT	b.USER_CODE,a.ENTITY_TYPE,b.USER_ENTITY_CODE,\
			a.ENTITY_TYPE,\
			a.ENTITY_NAME,\
			b.USER_UP_PROFILE_ID,\
			b.USER_LOGIN_CODE,\
			a.ENTITY_PAN,\
			COALESCE(b.USER_STATUS, \'I\'),\
			IFNULL(DATE_FORMAT(a.ENTITY_DOB, \'%%d-%%m-%%Y\'),\'-\'),\
			IFNULL(DATE_FORMAT(b.USER_LOGOFF_TIME, \'%%d-%%m-%%Y %%H:%%i:%%s\'),\'-\'),\
			a.ENTITY_STATUS,\
			IFNULL(a.ENTITY_EMAIL,\'-\'),\
			IFNULL(DATE_FORMAT(b.USER_LOGIN_TIME, \'%%d-%%m-%%Y %%H:%%i:%%s\'),\'-\'),\
			IFNULL(DATE_FORMAT(b.USER_PASSWORD_CNG_DATE,\'%%d-%%m-%%Y %%H:%%i:%%s\'),\'-\'),\
			a.ENTITY_NSE_CODE,\
			IFNULL(NULLIF(b.USER_STATIC_IP,\'\'),\'-\'),\
			a.ENTITY_RISK_PROFILE,\
			IFNULL(b.USER_STATUS,\'d\'),\
			b.USER_EXCH_ALLOWED,\
			b.USER_INV_PSWD_CHNG_REQ_CNTR,\
			b.USER_VAL_PSWD_CHNG_REQ_CNTR,\
			b.USER_UNLOCK_PWD_COUNTER,\
			b.USER_INVALID_LOGIN_CTR,\
			b.USER_FORGOT_PWD_CTR,\
			b.USER_UNLOCK_PWD_CTR,\
			IFNULL(NULLIF(b.USER_OLD_PASSWORD,\'\'),\'-\'),\
			IFNULL(NULLIF(b.USER_NEW_PASSWORD,\'\'),\'-\'),\
			IFNULL(NULLIF(b.USER_TRANS_PASSWORD,\'\'),\'-\'),\
			IFNULL(NULLIF(b.USER_TOKEN_ID,\'\'),\'-\'),\
			b.USER_PRODUCT_ALLOWED,	\
			a.ENTITY_SUBSCRIPTION_STATUS,\
			a.ENTITY_SUBSCRIPTION_EXPIRY,\
			datediff(a.ENTITY_SUBSCRIPTION_EXPIRY,now())\
			FROM ENTITY_MASTER a,USER_MASTER b\
			where a.ENTITY_CODE = b.USER_ENTITY_CODE;");
	//sprintf(sSelQuery,"SELECT a.ENTITY_CODE,a.ENTITY_TYPE,a.ENTITY_STATUS,a.ENTITY_RISK_PROFILE,IFNULL(b.USER_STATUS,\'D\'),b.USER_PRODUCT_ALLOWED, \
	b.USER_EXCH_ALLOWED  FROM ENTITY_MASTER a JOIN USER_MASTER b on a.ENTITY_CODE = 'DL005' AND b.USER_ENTITY_CODE = 'SD010';");
	logDebug1("sSelQry :%s:",sSelQuery);
	if (mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return(-1);
	}

	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);

	while(Row = mysql_fetch_row(Res))
	{	
		memset(sSubKeyExp,'\0',25);
		memset(sRedQuery,'\0',MAX_QUERY_SIZE);
		strncpy(sSubKeyExp,Row[32],25);
		fStrTrim(sSubKeyExp,strlen(sSubKeyExp));

		memset(sLog_off_time,'\0',30);
		memset(sLog_in_time,'\0',30);
		memset(sPass_cng_date,'\0',30);

		strncpy(sLog_off_time,Row[10],30);
		strncpy(sLog_in_time,Row[13],30);
		strncpy(sPass_cng_date,Row[14],30);
		fStrTrim(sLog_off_time,strlen(sLog_off_time));
		fStrTrim(sLog_in_time,strlen(sLog_in_time));
		fStrTrim(sPass_cng_date,strlen(sPass_cng_date));

		if(!strncmp(Row[1],"C",1))
		{
			sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_ENT_MASTER,Row[2],USER_CODE,Row[0],ENTITY_TYPE,Row[1],USER_ENTITY_CODE,Row[2],ENTITY_TYPE,Row[3],ENTITY_NAME,Row[4],USER_UP_PROFILE_ID,Row[5],USER_LOGIN_CODE,Row[6],ENTITY_PAN,Row[7],USER_STATUS,Row[8],ENTITY_DOB,Row[9],USER_LOGOFF_TIME,sLog_off_time,ENTITY_STATUS,Row[11],ENTITY_EMAIL,Row[12],USER_LOGIN_TIME,sLog_in_time,USER_PASSWORD_CNG_DATE,sPass_cng_date,ENTITY_NSE_CODE,Row[15],USER_STATIC_IP,Row[16],ENTITY_RISK_PROFILE,Row[17],USER_STATUS,Row[18],USER_EXCH_ALLOWED,Row[19],USER_INV_PSWD_CHNG_REQ_CNTR,Row[20],USER_VAL_PSWD_CHNG_REQ_CNTR,Row[21],USER_UNLOCK_PWD_COUNTER,Row[22],USER_INVALID_LOGIN_CTR,Row[23],USER_FORGOT_PWD_CTR,Row[24],USER_UNLOCK_PWD_CTR,Row[25],USER_OLD_PASSWORD,Row[26],USER_NEW_PASSWORD,Row[27],USER_TRANS_PASSWORD,Row[28],USER_TOKEN_ID,Row[29],USER_PRODUCT_ALLOWED,Row[30],ENTITY_SUBSCRIPTION_STATUS,Row[31],ENTITY_SUBSCRIPTION_EXPIRY,sSubKeyExp,ENTITY_DATE_DIFF,Row[33]);

			logDebug2("Client sRedQry :%s:",sRedQuery);
		}
		else if((!strncmp(Row[1],"D",1)) || (!strncmp(Row[1],"A",1)))
		{	
			sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_ENT_MASTER,Row[2],USER_CODE,Row[0],ENTITY_TYPE,Row[1],USER_ENTITY_CODE,Row[2],ENTITY_TYPE,Row[3],ENTITY_NAME,Row[4],USER_UP_PROFILE_ID,Row[5],USER_LOGIN_CODE,Row[6],ENTITY_PAN,Row[7],USER_STATUS,Row[8],ENTITY_DOB,Row[9],USER_LOGOFF_TIME,sLog_off_time,ENTITY_STATUS,Row[11],ENTITY_EMAIL,Row[12],USER_LOGIN_TIME,sLog_in_time,USER_PASSWORD_CNG_DATE,sPass_cng_date,ENTITY_NSE_CODE,Row[15],USER_STATIC_IP,Row[16],ENTITY_RISK_PROFILE,Row[17],USER_STATUS,Row[18],USER_EXCH_ALLOWED,Row[19],USER_INV_PSWD_CHNG_REQ_CNTR,Row[20],USER_VAL_PSWD_CHNG_REQ_CNTR,Row[21],USER_UNLOCK_PWD_COUNTER,Row[22],USER_INVALID_LOGIN_CTR,Row[23],USER_FORGOT_PWD_CTR,Row[24],USER_UNLOCK_PWD_CTR,Row[25],USER_TOKEN_ID,Row[29],USER_PRODUCT_ALLOWED,Row[30],ENTITY_SUBSCRIPTION_STATUS,Row[31],ENTITY_SUBSCRIPTION_EXPIRY,sSubKeyExp,ENTITY_DATE_DIFF,Row[33]);

			logDebug2("Dealer sRedQry :%s:",sRedQuery);
		}
		else
		{
			logDebug2("Invalid User Type");

		}

		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security source type[%s:%s]",SET_ENT_MASTER,Row[0]);
		}
		else
		{
			logFatal("Error in adding value to hash[%s]",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[EntityMasters]");
	return 0;
} ****/

int SecMaster()
{
	logTimestamp("Entry:[SecMaster]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,IFNULL(NULLIF(SM_ISIN_CODE,''),1),SM_EXCH_SYMBOL,SM_SYMBOL,\
			SM_INSTRUMENT_NAME,IFNULL(NULLIF(SM_SERIES,''),'XX'),SM_STATUS,IFNULL(NULLIF(SM_EXCH_STATUS,''),'D'),SM_PREOPEN_FLAG,SM_PREOPEN_EXCH_FLAG,\
			SM_ITS_FLAG,SM_ALGO_FLAG,IFNULL(NULLIF(SM_CA_FLAG,''),1),IFNULL(NULLIF(SM_FACE_VALUE,''),1),SM_TICK_SIZE,IFNULL(NULLIF(SM_LOT_SIZE,''),1),SM_UPPER_LIMIT,\
			SM_LOWER_LIMIT,SM_STRIKE_PRICE,IFNULL(NULLIF(SM_OPTION_TYPE,''),'XX'),IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%d\'),'-'),IFNULL(DATE_FORMAT(SM_EXPIRY_DATE,\'%%Y%%m\'),'-'),IFNULL(NULLIF(SM_UNDERLAYING_SCRIP_CODE,''),'-') \
			FROM SECURITY_MASTER;");
	//SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
	SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
		SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
		ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT\
		FROM SECURITY_MASTER;");
	logDebug1("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{	
		sprintf(sRedQuery,"HMSET %s:%s%s%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_SM,Row[0],Row[1],Row[2],SM_EXCHANGE,Row[0],SM_SEGMENT,Row[1],SM_SCRIP_CODE,Row[2],SM_EXCH_SCRIP_CODE,Row[3],SM_ISIN_CODE,Row[4],SM_EXCH_SYMBOL,Row[5],SM_SYMBOL_NAME,Row[6],SM_INSTRUMENT,Row[7],SM_SERIES,Row[8],SM_STATUS,Row[9],SM_EXCH_STATUS,Row[10],SM_PREOPEN_FLAG,Row[11],SM_PREOPEN_EXCH_FLAG,Row[12],SM_ITS_FLAG,Row[13],SM_ALGO_FLAG,Row[14],SM_CA_FLAG,"1",SM_FACE_VALUE,Row[16],SM_TICK_SIZE, Row[17],SM_LOT_SIZE,Row[18],SM_UPPER_LIMIT,Row[19],SM_LOWER_LIMIT,Row[20],SM_STRIKE_PRICE,Row[21],SM_OPTION_TYPE,Row[22],SM_MATURITY_DAY,Row[23],SM_MATURITY_MONYR,Row[24],SM_UND_SCRIP,Row[25],SM_LTP,"0");

		//logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);

		//      if(reply->type == REDIS_REPLY_ARRAY)
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Security ID[%s:%s%s%s]",SET_SM,Row[0],Row[1],Row[2]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logDebug2("sRedQry :%s:",sRedQuery);
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[SecMaster]");
	return 0;
}

/***int SysParameters()
  {
  logTimestamp("Entry:[SysParameters]");
  redisReply *reply;
  INT16   iNumRow;
  CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
  sprintf(sSelQuery, "SELECT PARAM_NAME,PARAM_VALUE,DELETED FROM SYS_PARAMETERS;");
  logDebug1("sSelQuery :%s:",sSelQuery);
  if(mysql_query(DBCon,sSelQuery) != 0)
  {
  logFatal("Some thing wrong with sSelQuery query Pls check");
  sql_Error(DBCon);
  mysql_close(DBCon);
  return (-1);
  }
  Res = mysql_store_result(DBCon);
  iNumRow = mysql_num_rows(Res);
  logDebug1("iNumRow :%i:",iNumRow);
  while(Row = mysql_fetch_row(Res))
  {		
  sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s",SET_SYS_PARAM,Row[0],SYS_PARAM_NAME,Row[0],SYS_PARAM_VALUE,Row[1],SYS_DELETED,Row[2]);
  logDebug2("sRedQry :%s:",sRedQuery);
  reply = redisCommand(RDCon,sRedQuery);		
  if(!strcasecmp(reply->str,"OK"))
  {
  logDebug2("Values added to the hash for ID[%s:%s]",SET_SYS_PARAM,Row[0]);
  }
  else if(reply->type == REDIS_REPLY_ERROR)
  {
  logFatal("Error in adding values to hash :%s:",reply->str);
  }

  freeReplyObject(reply);
  }
  logTimestamp("Exit:[SysParameters]");
  return 0;
  }***/

int RMSFnoExpMargin()
{
	logTimestamp("Entry:[RMSFnoExpMargin]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery, "SELECT  RFEM_SECURITY_ID, RFEM_SYMBOL_NAME, RFEM_EFF_EXP_LIMIT, DATE_FORMAT(RFEM_UPDATED_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\' ),RFEM_SEGMENT \
			FROM RMS_FNO_EXP_MARGIN;");
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s",SET_FNO_EXP_MAR,Row[0],FNOEX_MAR_RFEM_SECURITY_ID,Row[0],FNOEX_MAR_RFEM_SYMBOL_NAME,\
				Row[1],FNOEX_MAR_RFEM_EFF_EXP_LIMIT,Row[2],FNOEX_MAR_RFEM_UPDATED_DATE,Row[3],FNOEX_MAR_RFEM_SEGMENT,Row[4]);

		//logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for ID[%s:%s]",SET_SYS_PARAM,Row[0]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[RMSFnoExpMargin]");
	return 0;
} 

int RMSFnoSpanMargin()
{
	logTimestamp("Entry:[RMSFnoSpanMargin]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery,"SELECT RSM_SECURITY_ID , RSM_SYMBOL_NAME , RSM_SPAN_1 , RSM_SPAN_2, RSM_SPAN_3,RSM_SPAN_4,RSM_SPAN_5,RSM_SPAN_6,RSM_SPAN_7,RSM_SPAN_8,\
			RSM_SPAN_9,RSM_SPAN_10,RSM_SPAN_11,RSM_SPAN_12,RSM_SPAN_13,RSM_SPAN_14,RSM_SPAN_15,RSM_SPAN_16,RSM_DELTA,RSM_OPTION_PREMIUM,\
			DATE_FORMAT(RSP_UPDATED_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),IFNULL(RSM_SPAN_MARGIN,0),IFNULL(RSM_EXPO_MARGIN,0),RSM_INSTRUMENT,\
			DATE_FORMAT(RSM_EXPIRY_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),RSM_STRIKE_PRICE,RSM_OPTION_TYPE,RSM_SOM,RSM_UNDERLYING_SEC_ID,RSM_UNDERLYING_SYMBOL,\
			RSM_SEGMENT,RSM_EXCHANGE,RSM_DELTA_SPREAD, GREATEST(RSM_SPAN_1,RSM_SPAN_2,RSM_SPAN_3,RSM_SPAN_4,RSM_SPAN_5,RSM_SPAN_6,RSM_SPAN_7,RSM_SPAN_8,\
				RSM_SPAN_9,RSM_SPAN_10,RSM_SPAN_11,RSM_SPAN_12,RSM_SPAN_13,RSM_SPAN_14,RSM_SPAN_15,RSM_SPAN_16),LEAST(RSM_SPAN_1,RSM_SPAN_2,RSM_SPAN_3, \
					RSM_SPAN_4,RSM_SPAN_5,RSM_SPAN_6,RSM_SPAN_7,RSM_SPAN_8,RSM_SPAN_9,RSM_SPAN_10,RSM_SPAN_11,RSM_SPAN_12,RSM_SPAN_13,RSM_SPAN_14,RSM_SPAN_15,\
					RSM_SPAN_16) FROM RMS_FNO_SPAN_MARGIN;");
	logDebug2("Query=> [%s]",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{			
		sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_FNO_SPAN_MAR,Row[0],FNOSP_RSM_SECURITY_ID,Row[0],FNOSP_RSM_SYMBOL_NAME,Row[1],FNOSP_RSM_SPAN_1,Row[2],FNOSP_RSM_SPAN_2,Row[3],FNOSP_RSM_SPAN_3,Row[4],FNOSP_RSM_SPAN_4,Row[5],FNOSP_RSM_SPAN_5,Row[6],FNOSP_RSM_SPAN_6,Row[7],FNOSP_RSM_SPAN_7,Row[8],FNOSP_RSM_SPAN_8,Row[9],FNOSP_RSM_SPAN_9,Row[10],FNOSP_RSM_SPAN_10,Row[11],FNOSP_RSM_SPAN_11,Row[12],FNOSP_RSM_SPAN_12,Row[13],FNOSP_RSM_SPAN_13,Row[14],FNOSP_RSM_SPAN_14,Row[15],FNOSP_RSM_SPAN_15,Row[16],FNOSP_RSM_SPAN_16,Row[17],FNOSP_RSM_DELTA,Row[18],FNOSP_RSM_OPTION_PREMIUM,Row[19],FNOSP_RSP_UPDATED_DATE,Row[20],FNOSP_RSM_SPAN_MARGIN,Row[21],FNOSP_RSM_EXPO_MARGIN,Row[22],FNOSP_RSM_INSTRUMENT,Row[23],FNOSP_RSM_EXPIRY_DATE,Row[24],FNOSP_RSM_STRIKE_PRICE,Row[25],FNOSP_RSM_OPTION_TYPE,Row[26],FNOSP_RSM_SOM,Row[27],FNOSP_RSM_UNDERLYING_SEC_ID,Row[28],FNOSP_RSM_UNDERLYING_SYMBOL,Row[29],FNOSP_RSM_SEGMENT,Row[30],FNOSP_RSM_EXCHANGE,Row[31],FNOSP_RSM_DELTA_SPREAD,Row[32],FNOSP_GREATEST,Row[33],FNOSP_SMALLEST,Row[34]);

		//logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for ID[%s:%s]",SET_FNO_SPAN_MAR,Row[0]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[RMSFnoSpanMargin]");
	return 0;
}	


/***int RmsBlockLog()
  {
  logTimestamp("Entry :[RmsBlockLog]");
  redisReply *reply;
  INT16   iNumRow;
  CHAR    *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//CHAR    *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
CHAR    sRedQuery [MAX_QUERY_SIZE];
CHAR    sDesc[200];
sprintf(sSelQuery, "SELECT CLIENT_ID,SCRIP_CODE,ORDBUYSELL,ORDQTY,ORDERRATE,PRODUCTCODE,SEGMENT,EXCH_ID,ORDNO,ORDVERSIONNO,\
ORDERTYPE,ORDEXECUTIONSTATUS,TRADE_DATE,MKT_TYPE,RMS_STATUS,AMOUNT_BLOCKED,INSUFFICIENT_QTY,INSUFFICIENT_AMT,ORDER_TIMESTAMP,MKT_ORDER,\
ORD_TRANS_CODE,DESCRIPTOR FROM RMS_BLOCK_LOG;");
logDebug2("sSelQuery :%s:",sSelQuery);
if(mysql_query(DBCon,sSelQuery) != 0)
{
logFatal("Some thing wrong with sSelQuery query Pls check");
sql_Error(DBCon);
mysql_close(DBCon);
return (-1);
}
Res = mysql_store_result(DBCon);

iNumRow = mysql_num_rows(Res);
logDebug1("iNumRow :%i:",iNumRow);
while((Row = mysql_fetch_row(Res)))
{
memset(sDesc,'\0',200);
memset(&sRedQuery,'\0',MAX_QUERY_SIZE);
strncpy(sDesc,Row[21],200);
fStrTrim(sDesc,strlen(sDesc));	
logDebug2("String is [%s]",sDesc);

sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_RMS_BLCK_LOG,Row[0],RBL_CLIENT_ID,Row[0],RBL_SCRIP_CODE,Row[1],RBL_ORDBUYSELL,Row[2],RBL_ORDQTY,Row[3],RBL_ORDERRATE,Row[4],RBL_PRODUCTCODE,Row[5],RBL_SEGMENT,Row[6],RBL_EXCH_ID,Row[7],RBL_ORDNO,Row[8],RBL_ORDVERSIONNO,Row[9],RBL_ORDERTYPE,Row[10],RBL_ORDEXECUTIONSTATUS,Row[11],RBL_TRADE_DATE,Row[12],RBL_MKT_TYPE,Row[13],RBL_RMS_STATUS,Row[14],RBL_AMOUNT_BLOCKED,Row[15],RBL_INSUFFICIENT_QTY,Row[16],RBL_INSUFFICIENT_AMT,Row[17],RBL_ORDER_TIMESTAMP,Row[18],RBL_MKT_ORDER,Row[19],RBL_ORD_TRANS_CODE,Row[20],RBL_DESCRIPTOR,sDesc);

logDebug2("sRedQuery :%s:",sRedQuery);
reply = redisCommand(RDCon,sRedQuery);
if(!strcasecmp(reply->str,"OK"))
{
logDebug2("Values added for ID[%s]",Row[0]);
}
else if(reply->type == REDIS_REPLY_ERROR)
{
logFatal("Error in adding values :%s:",reply->str);
}
freeReplyObject(reply);
}
return 0;
}


LONG32	Holdings()
{
logTimestamp("Entry :[RmsBlockLog]");
redisReply *reply;
INT16   iNumRow;
CHAR    *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
//CHAR    *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
CHAR    sRedQuery [MAX_QUERY_SIZE];
CHAR    sDesc[200];
sprintf(sSelQuery,"SELECT ISIN_CODE,EXCH_ID,SECURITY_SOURCE_TYPE,QTY,QTY_UTILIZED,CLIENT_ID FROM RMS_CLIENT_SECURITY_LIMIT;");

logDebug2("sSelQuery [%s]",sSelQuery);

if(mysql_query(DBCon,sSelQuery) != SUCCESS)
{
logFatal("Some thing wrong with sSelQuery query Pls check");
sql_Error(DBCon);
mysql_close(DBCon);
return (ERROR);
}

Res = mysql_store_result(DBCon);

iNumRow = mysql_num_rows(Res);
logDebug1("iNumRow :%i:",iNumRow);
while((Row = mysql_fetch_row(Res)))
{
	memset(&sRedQuery,'\0',MAX_QUERY_SIZE);

	sprintf(sRedQuery,"HMSET %s:%s:%s:%s %s %s %s %s %s %s %s %s %s %s %s %s",SET_HOLDING,Row[5],Row[0],Row[2],HLD_ISIN_CODE,Row[0],HLD_EXCH_ID,Row[1],HLD_SECURITY_SOURCE_TYPE,Row[2],HLD_QTY,Row[3],HLD_QTY_UTILIZED,Row[4],HLD_CLIENT_ID,Row[5] );

	logDebug2("sRedQuery :%s:",sRedQuery);
	reply = redisCommand(RDCon,sRedQuery);
	if(!strcasecmp(reply->str,C_REDIS_OK))
	{
		logDebug2("Values added for ID[%s]",Row[0]);
	}
	else if(reply->type == REDIS_REPLY_ERROR)
	{
		logFatal("Error in adding values :%s:",reply->str);
	}
	freeReplyObject(reply);			

}

return TRUE;	
}


int BatchProcess()
{
	logTimestamp("Entry:[BatchProcess]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sDate1[30];
	CHAR    sDate2[30];
	CHAR    sDate3[30];
	CHAR    sDate4[30];



	sprintf(sSelQuery,"SELECT BP_EXCH_ID,BP_SEGMENT,BP_BATCH_NAME,BP_MKT_TYPE_NO, BP_MODE ,DATE_FORMAT(BP_SCHEDULE_TIME,\'%%Y%%m%%d-%%H:%%i:%%S\'),date_format(BP_LAST_RUN_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\') ,date_format(BP_NEXT_SCHEDULE_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'), BP_STATUS ,BP_REMARKS,date_format(BP_DATE,\'%%Y%%m%%d-%%H:%%i:%%S\'),BP_OFF_MKT_STATUS,BP_UPDATED_BY FROM BATCH_PROCESS;");

	logDebug1("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{	
		memset(sDate1,'\0',30);
		memset(sDate2,'\0',30);
		memset(sDate3,'\0',30);
		memset(sDate4,'\0',30);
		memset(&sRedQuery,'\0',MAX_QUERY_SIZE);
		strncpy(sDate1,Row[5],30);
		logDebug3("%s %d",sDate1,strlen(sDate1));
		strncpy(sDate2,Row[6],30);
		logDebug3("%s",sDate2);
		strncpy(sDate3,Row[7],30);
		logDebug3("%s",sDate3);
		strncpy(sDate4,Row[10],30);
		logDebug3("%s",sDate4);
		fStrTrim(sDate1,strlen(sDate1));
		fStrTrim(sDate2,strlen(sDate2));
		fStrTrim(sDate3,strlen(sDate3));
		fStrTrim(sDate4,strlen(sDate4));


		sprintf(sRedQuery,"HMSET %s:%s:%s:%s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_BATCH_PROCESS,Row[0],Row[1],Row[2],Row[3],BP_MODE,Row[4],BP_SCHEDULE_TIME,sDate1,BP_LAST_RUN_DATE,sDate2,BP_NEXT_SCHEDULE_DATE,sDate3,BP_STATUS,Row[8],BP_REMARKS,Row[9],BP_DATE,sDate4,BP_OFF_MKT_STATUS,Row[11],BP_UPDATED_BY,Row[12]);

		reply = redisCommand(RDCon,sRedQuery);
		logDebug3("Query[%s]",sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for BatchProcess[%s:%s:%s:%s:%d]",SET_BATCH_PROCESS,Row[0],Row[1],Row[2],Row[3]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logDebug2("sRedQry :%s:",sRedQuery);
			logFatal("Error in adding values to hash :%s:",reply->str);
		}

		freeReplyObject(reply);
	}
	logTimestamp("Exit:[BatchProcess]");
	return 0;
}

int Entity_Bank_Details()
{

	logTimestamp("Entry:[Entity_bank_master]");
	redisReply *reply;
	INT16  iNumRow;
	CHAR  sName[20];

	CHAR     *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR     *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	sprintf(sSelQuery,"SELECT\ 
			(SELECT \
			 AM_ATRB_NAME\
			 FROM\
			 ATTRIBUTE_MASTER\
			 WHERE\
			 AM_ATRB_CODE = e.EBD_ACCT_TYPE) AS ACCT_TYPE,\
			e.EBD_BANK_ACC_NO AS AccNo,\
			e.EBD_ENTITY_ID ,\
			a.AM_ATRB_CODE AS BankId,\
			a.am_atrb_name AS BankName,\
			e.EBD_BANK_IFSC AS IfscCode\
			FROM\
			ENTITY_BANK_DETAIL e,\
			ATTRIBUTE_MASTER a\
			WHERE\
			AM_ATRB_TYPE = 'BANK_ID'\
			AND e.ebd_bank_id = a.am_atrb_desc");

	if(mysql_query(DBCon,sSelQuery) !=0)
	{
		logFatal("some thing wrong with sSelQuery query ");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return(-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);	
	logDebug2("iNumRow :%d:",iNumRow);
	logDebug2("here1");
	while ( Row = mysql_fetch_row(Res))
	{
		logDebug2("here2");
		memset(sRedQuery,'\0',MAX_QUERY_SIZE);
		logDebug2("here2");
		memset(sName,'\0',20);
		memset(sRedQuery,'\0',MAX_QUERY_SIZE);
		strncpy(sName,Row[4],20);
		fStrTrim(sName,strlen(sName));
		sprintf(sRedQuery,"HMSET %s:%s:%s:%s:%s %s %s %s %s %s %s %s %s %s %s %s %s",ENTITY_BANK_DETAIL,Row[2],Row[3],Row[1],Row[0],ACCT_TYPE,Row[0],ACC_NO,Row[1],EBD_ENTITY_ID,Row[2],BANK_ID,Row[3],BANK_NAME,sName,IFSC_CODE,Row[5]);

		logDebug2("sRedQry :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added to the hash for Bank ID[%s]",Row[3]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values to hash :%s:",reply->str);
		}
		freeReplyObject(reply);
	}
	logTimestamp("Exit:[ENTITY_BANK_DETAIL]");
	return 0;
}


int CF_Position()
{

	logTimestamp("Entry:[CF_Position]");
	redisReply *reply;
	INT16  iNumRow;
	CHAR  sName[20];
	LONG32   ret;	
	FLOAT32  Avgbuy,Avgsell,Netval ,Netqty;
	CHAR     *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR     *sReqQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sSymbol [DB_SYM_NAME_LEN];
	CHAR    sUndScrip[SECURITY_ID_LEN];
	CHAR    sInstrumentType[DB_INS_LEN];
	memset ( sSymbol,     '\0' ,DB_SYM_NAME_LEN);
	memset ( sUndScrip,     '\0' ,SECURITY_ID_LEN);
	memset ( sInstrumentType, '\0' ,DB_INS_LEN);

	sprintf(sSelQuery,"SELECT CLIENT_ID,\
			SECURITY_ID,\
			EXCH_ID,\
			BUY_QTY,\
			BUY_VAL,\
			SELL_QTY,\
			SELL_VAL,\
			EXCH_SEGMENT,\
			PRODUCT,\
			INT_REF_ID\
			FROM NET_POSITION_ADMIN;");
	if(mysql_query(DBCon,sSelQuery) !=0)
	{
		logFatal("some thing wrong with sSelQuery query ");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return(-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug2("iNumRow :%d:",iNumRow);
	while ( Row = mysql_fetch_row(Res))
	{
		logDebug3("here 5 - :%s:",Row[9]);
		if (strcmp(Row[9],"-1")==0)
		{
			sprintf(sReqQry,"SADD %s:%s %s:%s:%s:%s:%s:%s:%d", SET_CLIENT_POS, Row[0], SET_POS,Row[0],Row[2],Row[7],Row[1],Row[8],1);
			logDebug2("INSERTING Position into CLIENT_POS HASH ->  %s",sReqQry);
			reply = redisCommand(RDCon,sReqQry);

			if(reply->type == REDIS_REPLY_INTEGER) 
			{
				logDebug2("STATUS ->  %d",reply->integer);
			}
			else
			{
				logFatal("Error in adding values to CLIENT_POS HASH. :%s:",reply->str);
			}

			memset ( sReqQry,'\0',MAX_QUERY_SIZE);
			freeReplyObject(reply);
			sprintf(sReqQry,"HMGET %s:%s%s%s %s %s %s",SET_SM,Row[2],Row[7],Row[1],SM_SYMBOL_NAME,SM_UND_SCRIP,SM_INSTRUMENT);
			reply = redisCommand(RDCon,sReqQry);

			if(reply->type == REDIS_REPLY_ARRAY)
			{
				strcpy(sSymbol,reply->element[0]->str);
				strcpy(sUndScrip,reply->element[1]->str);
				strcpy(sInstrumentType,reply->element[2]->str);
			}

			else
			{
				logFatal("Fetching Sec Data %s:%s%s%s",SET_SM,Row[2],Row[7],Row[1]);
				return FALSE;
			}
			freeReplyObject(reply);
			memset ( sReqQry,'\0',MAX_QUERY_SIZE);

			Netqty = atoi(Row[3])-atoi(Row[5]);
			Netval = atof(Row[4])-atof(Row[6]);
			Avgbuy = atof(Row[4]) / atoi (Row[3]);
			Avgsell = atof (Row[6]) / atoi(Row[5]);

			sprintf(sReqQry,"HMSET %s:%s:%s:%s:%s:%s:%d %s %f %s %f %s %s %s %s %s %s %s %s %s %f %s %f %s %s %s %s %s %s %s %s %s %s %s %s %s %s",SET_POS,Row[0],Row[2],Row[7],Row[1],Row[8],1, POS_NET_QTY,Netqty, POS_NET_VAL,Netval ,POS_BUY_QTY,Row[3], POS_BUY_VAL,Row[4], POS_SELL_QTY,Row[5], POS_SELL_VAL,Row[6], POS_AVG_BUY, Avgbuy, POS_AVG_SELL, Avgsell, POS_CFBUY_QTY,Row[3], POS_CFBUY_VAL,Row[4], POS_CFSELL_QTY,Row[5], POS_CFSELL_VAL,Row[6], POS_CFAVG_BUY, Avgbuy, POS_CFAVG_SELL, Avgsell, POS_SEC_EXCH,Row[2], POS_SEC_SEG,Row[7], POS_SEC_CODE, Row[1], POS_PRODUCT, Row[8],SM_SYMBOL_NAME,sSymbol,SM_UND_SCRIP,sUndScrip,POS_INS_NAME,sInstrumentType);

			logDebug2("Initializing Position  -> %s",sReqQry);
			reply = redisCommand(RDCon,sReqQry);
			if(!strcasecmp(reply->str,C_REDIS_OK))
			{
				logInfo("Initialized Successfully");
			}
			else
			{
				logFatal("Error in Initializing Position. :%s:",reply->str);
			}
			freeReplyObject(reply);
		}

		logDebug3("here 777");

	}
	//free(sReqQry);

}



int AttributeMaster()
{
	logTimestamp("Entry:[Attribute Master]");
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	sprintf(sSelQuery"SELECT AM_ATRB_ID, AM_ATRB_NAME, AM_ATRB_TYPE, AM_ATRB_DESC, AM_ATRB_REMARKS, AM_ATRB_CODE, AM_ATTRB_LANG1, AM_ATTRB_LANG2, AM_ATTRB_LANG3, AM_ATTRB_LANG4, AM_IDENTIFICATION_CODE FROM ATTRIBUTE_MASTER");

	logDebug1("sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		logFatal("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}

	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);	
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))

} **/
int 	DPRCM()
{
	logTimestamp("Entry:[DPRCM]");
        redisReply *reply,*reply1,*replyCnt;
        LONG32   iNumRow;
        CHAR    sSelQuery 	[MAX_QUERY_SIZE];
        CHAR    sRedQuery 	[MAX_QUERY_SIZE];
     //   CHAR    *sRedQuery1 	[MAX_QUERY_SIZE];
        int             i = 0;
	memset(sSelQuery,'\0',MAX_QUERY_SIZE);
       //// memset(sRedQuery1,'\0',MAX_QUERY_SIZE);

/*     	logDebug2("....Clearing SET_L1_WATCH key ....");
    	sprintf(sRedQuery1,"DEL %s",SET_L1_WATCH);
        reply = redisCommand(RDCon,sRedQuery1);
        freeReplyObject(reply);

    	sprintf(sRedQuery1,"KEYS %s*",SET_L1_WATCH);
       	logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        for(i = 0; i < reply->elements; i++)
        {
        	sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
               	replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing SET_L1_WATCH****");
        freeReplyObject(reply);
      
	

	logDebug2("....Started Clearing REV key ....");
	
	sprintf(sRedQuery1,"KEYS REV*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
	logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);	
	logDebug2("Going in for Loop For Deleting the REV keys ");
        for(i = 0; i < reply->elements; i++)
        {	
		logDebug2("****In For loop  [%d]*****",i);
		logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
		logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing REV Keys\n****");
        freeReplyObject(reply);

	
	logDebug2("....Started Clearing NSE:E key ....");
	sprintf(sRedQuery1,"KEYS NSE:E*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the NSE:E keys ");
        for(i = 0; i < reply->elements; i++)
	{
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing NSE:E Keys\n****");
        freeReplyObject(reply);
	
	logDebug2("....Started Clearing NSE:D key ....");
        sprintf(sRedQuery1,"KEYS NSE:D*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the NSE:D keys ");
        for(i = 0; i < reply->elements; i++)
        {
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing NSE:D Keys\n****");
        freeReplyObject(reply);

	logDebug2("....Started Clearing NSE:C key ....");
        sprintf(sRedQuery1,"KEYS NSE:C*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the NSE:C keys ");
        for(i = 0; i < reply->elements; i++)
        {
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing NSE:C Keys\n****");
        freeReplyObject(reply);

	logDebug2("....Started Clearing MCX:M key ....");
        sprintf(sRedQuery1,"KEYS MCX:M*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the MCX:M keys ");
        for(i = 0; i < reply->elements; i++)
        {
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing MCX:M Keys\n****");
        freeReplyObject(reply);

	logDebug2("....Started Clearing BSE:E key ....");
        sprintf(sRedQuery1,"KEYS BSE:E*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the BSE:E keys ");
        for(i = 0; i < reply->elements; i++)
        {
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing BSE:E Keys\n****");
        freeReplyObject(reply);

	logDebug2("....Started Clearing BSE:D key ....");
        sprintf(sRedQuery1,"KEYS BSE:D*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the BSE:D keys ");
        for(i = 0; i < reply->elements; i++)
        {
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing BSE:D Keys\n****");
        freeReplyObject(reply);

	logDebug2("....Started Clearing BSE:C key ....");
        sprintf(sRedQuery1,"KEYS BSE:C*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
        logDebug2("Going in for Loop For Deleting the BSE:C keys ");
        for(i = 0; i < reply->elements; i++)
        {
                logDebug2("****In For loop  [%d]*****",i);
                logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("Keys Deleted -> %d",reply->elements);
        logDebug2("****Done Clearing BSE:C Keys\n****");
        freeReplyObject(reply);
*/
 
	sprintf(sSelQuery,"SELECT 	SM_EXCHANGE, SM_SEGMENT, SM_SCRIP_CODE, SM_UPPER_LIMIT, SM_LOWER_LIMIT, SM_TICK_SIZE, IFNULL(BC_CLOSE_PRICE, ROUND((ROUND(((SM_UPPER_LIMIT + SM_LOWER_LIMIT) / 2) * 100) - ROUND(((SM_UPPER_LIMIT + SM_LOWER_LIMIT) / 2) * 100) %% SM_TICK_SIZE) / 100, 2)) FROM SECURITY_MASTER SM LEFT JOIN 	(SELECT 		BC_SCRIP_CODE, 		BC_EXCHANGE, 		BC_SEGMENT, BC_CLOSE_PRICE 	FROM 		BHAV_COPY b 	UNION 	SELECT 		DBC_SCRIP_CODE, 		DBC_EXCHANGE, 	DBC_SEGMENT, DBC_CLOSE_PRICE FROM DRV_BHAV_COPY db) AS BHAV ON (SM.SM_EXCHANGE = BHAV.BC_EXCHANGE AND SM.SM_SEGMENT = BHAV.BC_SEGMENT AND SM.SM_SCRIP_CODE = BHAV.BC_SCRIP_CODE) WHERE 	NOT (SM.SM_EXCHANGE = 'BSE' AND SM.SM_SEGMENT = 'D'); ");
        logDebug1("sSelQuery :%s:",sSelQuery);
        if(mysql_query(DBCon,sSelQuery) != 0)
        {
                logFatal("Some thing wrong with sSelQuery query Pls check");
                sql_Error(DBCon);
                mysql_close(DBCon);
                return (-1);
        }
        Res = mysql_store_result(DBCon);
        iNumRow = mysql_num_rows(Res);
        logDebug1("iNumRow :%ld:",iNumRow);
        while(Row = mysql_fetch_row(Res))
        {
		memset(sRedQuery,'\0',MAX_QUERY_SIZE);
                sprintf(sRedQuery,"HMSET %s:%s%s%s %s %s %s %s %s %s %s %s",SET_L1_WATCH,Row[0],Row[1],Row[2],SM_UPPER_LIMIT,Row[3],SM_LOWER_LIMIT,Row[4],SM_TICK_SIZE,Row[5],SM_LTP,Row[6]);

                logDebug2("sRedQry :%s:",sRedQuery);
                reply = fRedisCommand(RDCon,sRedQuery,REDIS_TYPE_PRICE_BCAST);
                if(!strcasecmp(reply->str,"OK"))
                {
                        logDebug2("Values added to the hash for Security ID[%s]",Row[2]);
                }
                else if(reply->type == REDIS_REPLY_ERROR)
                {
                        logFatal("Error in adding values to hash :%s:",reply->str);
                }
                freeReplyObject(reply);
        }
        logTimestamp("Exit:[DPRCM]");
        return 0;

}

int RevKeyClear()
{
	logTimestamp("Entry:[RevKeyClear]");
	redisReply *reply,*replyCnt;
        CHAR    *sRedQuery1     [MAX_QUERY_SIZE];
        int             i = 0;

	memset(sRedQuery1,'\0',MAX_QUERY_SIZE);
	
	logDebug2("....Clearing SET_L1_WATCH key ....");
        sprintf(sRedQuery1,"DEL %s",SET_L1_WATCH);
	logDebug2("DELETING sRedQuery1 is -----> [%s]",sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        freeReplyObject(reply);

	logDebug2(".... [0] Now Started Clearing SET_L1_WATCH key ....");
        sprintf(sRedQuery1,"KEYS %s*",SET_L1_WATCH);
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
	logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
     //   logDebug2("Going in for Loop For Deleting the SET_L1_WATCH keys ");
        for(i = 0; i < reply->elements; i++)
        {
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
                //logDebug2("[Deleting]--> %s",sRedQuery1);
		replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted -------> %d",reply->elements);
        logDebug2("****Done Clearing SET_L1_WATCH****\n");
        freeReplyObject(reply);
	

	logDebug2(".... [1] Now Started Clearing REV key ....");
        sprintf(sRedQuery1,"KEYS REV*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
   //     logDebug2("Going in for Loop For Deleting the REV keys ");
	
	for(i = 0; i < reply->elements; i++)
        {
                //logDebug2("****In For loop  [%d]*****",i);
               // logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
              //  logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing REV Keys\n****");
        freeReplyObject(reply);

        logDebug2(".... [2] Now Started Clearing NSE:E key ....");
        sprintf(sRedQuery1,"KEYS NSE:E*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
      //  logDebug2("Going in for Loop For Deleting the NSE:E keys ");
        for(i = 0; i < reply->elements; i++)
        {
       //         logDebug2("****In For loop  [%d]*****",i);
         //       logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
           //     logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing NSE:E Keys****\n");
        freeReplyObject(reply);

        logDebug2(".... [3] Now Started Clearing NSE:D key ....");
        sprintf(sRedQuery1,"KEYS NSE:D*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
  //      logDebug2("Going in for Loop For Deleting the NSE:D keys ");
	for(i = 0; i < reply->elements; i++)
        {
     //           logDebug2("****In For loop  [%d]*****",i);
       //         logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
         //       logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing NSE:D Keys****\n");
        freeReplyObject(reply);

        logDebug2(".... [4] Now Started Clearing NSE:C key ....");
        sprintf(sRedQuery1,"KEYS NSE:C*");
        logDebug2(" sRedQuery1 is %s\n", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
 //       logDebug2("Going in for Loop For Deleting the NSE:C keys ");
        for(i = 0; i < reply->elements; i++)
        {
  //              logDebug2("****In For loop  [%d]*****",i);
    //            logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
      //          logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing NSE:C Keys****\n");
        freeReplyObject(reply);

        logDebug2(".... [5] Now Started Clearing MCX:M key ....");
        sprintf(sRedQuery1,"KEYS MCX:M*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
//        logDebug2("Going in for Loop For Deleting the MCX:M keys ");
        for(i = 0; i < reply->elements; i++)
        {
 //               logDebug2("****In For loop  [%d]*****",i);
   //             logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
     //           logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
	logDebug2("****Done Clearing MCX:M Keys****\n");
        freeReplyObject(reply);

        logDebug2(".... [6] Now Started Clearing BSE:E key ....");
        sprintf(sRedQuery1,"KEYS BSE:E*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
       // logDebug2("Going in for Loop For Deleting the BSE:E keys ");
        for(i = 0; i < reply->elements; i++)
        {
        //        logDebug2("****In For loop  [%d]*****",i);
          //      logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
            //    logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing BSE:E Keys****\n");
        freeReplyObject(reply);

        logDebug2(".... [7] Now Started Clearing BSE:D key ....");
        sprintf(sRedQuery1,"KEYS BSE:D*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
 //       logDebug2("Going in for Loop For Deleting the BSE:D keys ");
        for(i = 0; i < reply->elements; i++)
        {
   //             logDebug2("****In For loop  [%d]*****",i);
     //           logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
       //         logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing BSE:D Keys****\n");
        freeReplyObject(reply);

        logDebug2(".... [8] Now Started Clearing BSE:C key ....");
        sprintf(sRedQuery1,"KEYS BSE:C*");
        logDebug2(" sRedQuery1 is %s", sRedQuery1);
        reply = redisCommand(RDCon,sRedQuery1);
        logDebug2("TOTAL ELEMENTS TO BE DELETED -------> :%d:",reply->elements);
       // logDebug2("Going in for Loop For Deleting the BSE:C keys ");
	for(i = 0; i < reply->elements; i++)
        {
         //       logDebug2("****In For loop  [%d]*****",i);
           //     logDebug2("reply->element[%d]->str   :%s:",i,reply->element[i]->str);
                sprintf(sRedQuery1,"DEL %s",reply->element[i]->str);
             //   logDebug2("[Deleting]--> %s",sRedQuery1);
                replyCnt = redisCommand(RDCon,sRedQuery1);
                freeReplyObject(replyCnt);
        }
        logDebug2("TOTAL Number of Keys Deleted  -------> %d",reply->elements);
        logDebug2("****Done Clearing BSE:C Keys****\n");
        freeReplyObject(reply);
	
	logDebug2("=========================||||||||--We have Done Clearing all the keys--||||||||=========================");
	DPRCM();

	logTimestamp("EXIT : [RevKeyClear]");
}


int AMOExpiryCheck (int arg)
{
	
	logTimestamp("Entry : AMOExpiryCheck");
	logDebug2("From Command Line Argument --> |%d|",arg);
	CHAR SelectQry [MAX_QUERY_SIZE];
	memset(SelectQry ,'\0' ,MAX_QUERY_SIZE);	
	
	char sEntityId [100];
	char sMsgCode [50];
	char sReasonDescription [200];
	memset(sMsgCode,'\0' ,50);
	memset(sEntityId ,'\0',100);
	memset(sReasonDescription,'\0',200);
	
	strncpy(sEntityId,"SYSADMIN1",100);
        strncpy(sMsgCode,"4444",50);
        strncpy(sReasonDescription,"RMS:Contract is Expired ",200);

	sprintf(SelectQry,"INSERT INTO DRV_ORDERS \
			SELECT DRV_ORDER_NO, DRV_SERIAL_NO +1, DRV_MULTILEG_ORD_TYPE, DRV_LEG_NO, DRV_SCRIP_CODE, DRV_EXCH_ID, DRV_SEGMENT,\"%s\",\
			DRV_EXCH_ORDER_NO, DRV_CLIENT_ID, DRV_BUY_SELL_IND, \"%s\", 'R', NOW(), DRV_EXCH_ORDER_TIME, DRV_TOTAL_QTY, DRV_REM_QTY, \
			DRV_DISC_QTY, DRV_DISC_REM_QTY, DRV_TOTAL_TRADED_QTY, DRV_ORDER_PRICE, DRV_REF_LTP, DRV_TRIGGER_PRICE, DRV_SPREAD_PRICE_DIFF, \
			DRV_VALIDITY, DRV_ORDER_TYPE, DRV_GOOD_TILL_DAYS, DRV_GOOD_TILL_DATE, DRV_ACC_CODE, DRV_USER_ID, DRV_MIN_FILL_QTY, DRV_PRO_CLIENT,\
			DRV_REMARKS, DRV_ERROR_CODE, DRV_SOURCE_FLG, DRV_ORDER_OFFON, DRV_OPEN_CLOSE, DRV_COVER_UNCOVER, DRV_PRODUCT_ID, DRV_LOC_CODE,\
			DRV_GROUP_ID, DRV_REASON_CODE, \"%s\", DRV_TRD_EXCH_TRADE_NO, -1*(ABS(DRV_TRD_SERIAL_NO)+1), DRV_TRD_TRANS_CODE,\
			DRV_TRD_STATUS, DRV_TRD_TRADE_QTY, DRV_TRD_TRADE_PRICE, DRV_TRD_TRADE_TIME, DRV_TRD_SDRV_NO, DRV_HANDLE_INST, DRV_OMS_ALGO_ORD_NO,\
			DRV_STRATEGY_ID, DRV_CLORDID, DRV_ORIG_CLORDID, DRV_ORIGINAL_PRICE, DRV_SETTLE_PRICE, DRV_SYMBOL, DRV_USER_TYPE, DRV_INSTRUMENT_NAME,\
			DRV_EXPIRY_DATE, DRV_STRIKE_PRICE, DRV_OPTION_TYPE, DRV_LOT_SIZE, DRV_BOOKTYPE, DRV_MKT_TYPE, DRV_SL_ABSTICK_VALUE, DRV_PR_ABSTICK_VALUE,\
			DRV_SL_AT_FLAG, DRV_PR_ST_FLAG, DRV_CF_FLAG, DRV_CHILD_LEG_UNQ_ID, DRV_TRAILING_SL_VALUE, DRV_CURRENCY_MULTIPLIER, DRV_RBI_REFERENCE_RATE,\
			DRV_CROSS_CUR_FLAG, DRV_PAN_NO, DRV_PARTICIPANT_TYPE, DRV_SETTLOR, DRV_MKT_PROTECT_FLG, DRV_MKT_PROTECT_VAL, DRV_GTC_FLG, DRV_ENCASH_FLG,\
			DRV_SQROFF_FLAG, DRV_EXCH_SEC, DRV_UNDERLINE_SCRIP, DRV_FREEZE_QTY, DRV_LUT, DRV_CUSTOM_SYMBOL, DRV_EXCH_INSTRUMENT_TYPE, DRV_ALGO_ID,\
			DRV_TICK_SIZE, DRV_BLOCKED_AMT, DRV_COST_PRICE, DRV_REMARKS1, DRV_REMARKS2, DRV_INTEROPS_SCRIP, DRV_INTEROPS_EXCH_SYMBOL, DRV_NSE_SCRIP,\
			DRV_BSE_SCRIP, DRV_EXPIRY_FLAG, DRV_MPP_EXCH_PRICE, DRV_MPP_SL_EXCH_PRICE, DRV_MPP_BLOCK_PRICE, DRV_MPP_SL_BLOCK_PRICE \
			FROM (SELECT Z.DRV_ORDER_NO AS ORD,Z.DRV_LEG_NO AS LEG,MAX(Z.DRV_SERIAL_NO)AS SER FROM DRV_ORDERS Z GROUP BY Z.DRV_ORDER_NO,Z.DRV_LEG_NO)AS X,\
			DRV_ORDERS DRV WHERE DRV_ORDER_NO=X.ORD AND DRV_LEG_NO=X.LEG AND DRV_SERIAL_NO = X.SER AND DRV_EXPIRY_DATE < CURDATE() AND DRV_MSG_CODE IN (5112,5113)\
            		AND DRV_CF_FLAG <> -1;",sEntityId,sMsgCode,sReasonDescription);
	
	logDebug2("Select Query --> |%s|", SelectQry);
	if (mysql_query(DBCon,SelectQry) != SUCCESS)
        {
		sql_Error(DBCon);
		logSqlFatal("Bhai Query Failed Yaar");
		mysql_close(DBCon);
		return ERROR;
        }
	logDebug2("Query Fired Successfully");
	Res = mysql_affected_rows(DBCon);
        logDebug1("Number of Rows Affected :%i:",Res);
	mysql_commit(DBCon);	
	mysql_free_result(Res);
	
	memset(SelectQry ,'\0' ,MAX_QUERY_SIZE);
	sprintf(SelectQry,"INSERT INTO COMM_ORDERS \
			SELECT COMM_ORDER_NO, COMM_SERIAL_NO+1, COMM_MULTILEG_ORD_TYPE, COMM_LEG_NO, COMM_SCRIP_CODE, COMM_EXCH_ID, COMM_SEGMENT, \"%s\",\
			COMM_EXCH_ORDER_NO, COMM_CLIENT_ID, COMM_BUY_SELL_IND, \"%s\", 'R', COMM_INTERNAL_ENTRY_DATE, COMM_EXCH_ORDER_TIME, COMM_TOTAL_QTY, \
			COMM_REM_QTY, COMM_DISC_QTY, COMM_DISC_REM_QTY, COMM_TOTAL_TRADED_QTY, COMM_ORDER_PRICE, COMM_REF_LTP, COMM_TRIGGER_PRICE, COMM_SPREAD_PRICE_DIFF,\
			COMM_VALIDITY, COMM_ORDER_TYPE, COMM_GOOD_TILL_DAYS, COMM_GOOD_TILL_DATE, COMM_ACC_CODE, COMM_USER_ID, COMM_MIN_FILL_QTY, COMM_PRO_CLIENT,\
			COMM_REMARKS, COMM_ERROR_CODE, COMM_SOURCE_FLG, COMM_ORDER_OFFON, COMM_OPEN_CLOSE, COMM_COVER_UNCOVER, COMM_PRODUCT_ID, COMM_LOC_CODE,\
			COMM_GROUP_ID, COMM_REASON_CODE, \"%s\", COMM_TRD_EXCH_TRADE_NO,  -1*(ABS(COMM_TRD_SERIAL_NO)+1), COMM_TRD_TRANS_CODE, \
			COMM_TRD_STATUS, COMM_TRD_TRADE_QTY, COMM_TRD_TRADE_PRICE, COMM_TRD_TRADE_TIME, COMM_TRD_SEQ_NO, COMM_HANDLE_INST, COMM_OMS_ALGO_ORDER_NO,\
		 	COMM_STRATEGY_ID, COMM_CLORDID, COMM_ORIG_CLORDID, COMM_SYMBOL, COMM_INSTRUMENT_NAME, COMM_STRIKE_PRICE, COMM_OPTION_TYPE, COMM_LOT_SIZE,\
			COMM_USER_TYPE, COMM_MKT_TYPE, COMM_ARCHIVE_DATE, COMM_SEM_SYMBOL, COMM_CF_FLAG, COMM_EXPIRY_DATE, COMM_MULTIPLIER, COMM_ORIGINAL_PRICE,\
			COMM_SETTLE_PRICE, COMM_SL_ABSTICK_VALUE, COMM_PR_ABSTICK_VALUE, COMM_SL_AT_FLAG, COMM_PR_ST_FLAG, COMM_CHILD_LEG_UNQ_ID, COMM_PAN_NO, \
			COMM_PARTICIPANT_TYPE, COMM_SETTLOR, COM_MKT_PROTECT_FLG, COMM_MKT_PROTECT_VAL, COMM_GTC_FLG, COMM_ENCASH_FLG, COMM_TRAILING_SL_VALUE,\
		 	COMM_SERIES, COMM_ICEX_EXCH_ORDER_TIME, COMM_UNDERLINE_SCRIP, COMM_FREEZE_QTY, COMM_BLOCKED_AMT, COMM_LUT, COMM_CUSTOM_SYMBOL, \
			COMM_EXCH_INSTRUMENT_TYPE, COMM_ALGO_ID, COMM_TICK_SIZE, COMM_COST_PRICE, COMM_REMARKS1, COMM_REMARKS2, COMM_INTEROPS_SCRIP,\
			COMM_INTEROPS_EXCH_SYMBOL, COMM_NSE_SCRIP, COMM_BSE_SCRIP, COMM_EXPIRY_FLAG, COMM_MPP_EXCH_PRICE, COMM_MPP_SL_EXCH_PRICE, COMM_MPP_BLOCK_PRICE,\
			COMM_MPP_SL_BLOCK_PRICE FROM(SELECT Z.COMM_ORDER_NO AS ORD,MAX(Z.COMM_SERIAL_NO)AS SER,Z.COMM_LEG_NO  AS LEG FROM COMM_ORDERS Z GROUP BY \
			Z.COMM_ORDER_NO,Z.COMM_LEG_NO) AS X,COMM_ORDERS M WHERE COMM_LEG_NO = X.LEG AND COMM_SERIAL_NO = X.SER AND COMM_ORDER_NO =X.ORD AND \
			COMM_EXPIRY_DATE < CURDATE() AND COMM_MSG_CODE IN (5112,5113) AND COMM_CF_FLAG <> -1;",sEntityId,sMsgCode,sReasonDescription);
	
	logDebug2("Select Query --> |%s|", SelectQry);
        if (mysql_query(DBCon,SelectQry) != SUCCESS)
        {
                sql_Error(DBCon);
                logSqlFatal("Bhai Query Failed Yaar");
                mysql_close(DBCon);
                return ERROR;
        }
        logDebug2("Query Fired Successfully");
        Res = mysql_affected_rows(DBCon);
        logDebug1("Number of Rows Affected :%i:",Res);
        mysql_commit(DBCon);	
	logTimestamp("Exit : AMOExpiryCheck ");
	return 0;	
}
