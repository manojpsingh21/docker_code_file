/************************************* FILE AFTER PRECESION CHANGES ****************************/
/**************************************HISTORY OF CHANGES***************************************
Function : MemmapConnectChild

IMPORTANT NOTES.
1.PACKET SIZE AT ANY POINT OF TIME SHOULD NOT EXCEED 512 BYTES.
2.Fn PipeCheck is used to increament or decrement pipecount variable which is used 
while both writing to & reading from memmap by two threads. 
3.Indicator Variable is used to avoid writing to pipe all the times .It also avoid 
OS level max count of pipe.
 ***********************************************************************************************/
#include    "MemMapConfig.h"
#include    "MemMapqueue.h"
#include    "MemMapCommon.h"
#include    "IntStruct.h"
//#include    "NseEQNNFStruct.h"
#include    "NNFStruct.h"
#include    <pthread.h>
#include    <sys/time.h>

#define	    MAX_PACKET_SIZE 1024
#define	    FILE_MODE       (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
#define	    INDICATOR		1			

#define         TWIDDLEMMAP(A)              TwiddleMMAP((char *) &A, sizeof(A))

void MemMapFunc();
void ReadFrmFile();
BOOL PipeCheck(int);

LONG32                      DummyPipe[2];
typedef struct mymq_info    *ReadFileInfo;
ReadFileInfo 		    lmqd; 
typedef struct mymq_info    *Memorymq_d;
Memorymq_d  	            Memory_Mmap ;
pthread_mutex_t             MaxPacketMutex;
long MaxPackets;
CHAR       		    DummyChar;
LONG32 SACFLAG = 0;
LONG32 SACOUNT =0;
int pipecount = 0;
pthread_mutex_t Pipelock;
pthread_mutexattr_t attrPipe;
key_t RcvQ, SndQ;

void    signal_handler(LONG32 );
BOOL    exit_handler();

CHAR	ADAPT2_MMAP_FILE_PATH[200];
main ( LONG32 argc, CHAR **argv )
{
	int 			iRetVal=0;
	pthread_t               thread_id1; 
	pthread_t               thread_id2; 

	struct mymq_attr    	attr, info;
	int i=0;
	int 	                ForkInd=0;
	CHAR    sMemMapPath[100];
        memset(sMemMapPath,'\0',100);


	setvbuf( stdout , NULL , _IONBF , 0 );
	setbuf ( stdout , NULL );
	setbuf ( stdin  , NULL );

	signal(SIGINT,signal_handler);
	signal(SIGHUP,SIG_IGN);
	signal(SIGSEGV,signal_handler);
	signal(SIGTERM,signal_handler);
	atexit(exit_handler);

	//	Input = atoi (argv[1]);
	//        logDebug2("\n Input [%d]",Input);

	if(getenv("MEM_MAP_PATH") == NULL)
        {
                logInfo("ENV variable MEM_MAP_PATH not define .Please give $HOME/Application/Exec/MemMapFiles as values and restart");
                exit(ERROR);
        }
        else
        {
                strncpy(sMemMapPath,getenv("MEM_MAP_PATH"),100);
                logDebug2("sMemMapPath :%s:",sMemMapPath);
        }
	

	memset(ADAPT2_MMAP_FILE_PATH,'\0',200);
	//strcpy(ADAPT2_MMAP_FILE_PATH,"../MemMapFiles/ENAdapt2MapTrd");
	sprintf(ADAPT2_MMAP_FILE_PATH,"%s/ENAdapt2MapTrd",sMemMapPath);



	if(( RcvQ = OpenMsgQ(ConnToTrdMapNSEEQ)) == ERROR)
	{
		logDebug2("OpenMsgQ : Error in opening EquNSEToRmsNse");
		exit(ERROR);
	}

	if(( SndQ = OpenMsgQ( MmapToENMapTrd )) == ERROR)
	{
		logDebug2("OpenMsgQ : Error in opening MmapToChild ");
		exit(ERROR);
	}


	logDebug2("ReadMsgQ %d	WriteMsgQ	%d ADAPT2_MMAP_FILE_PATH :%s:",RcvQ,SndQ,ADAPT2_MMAP_FILE_PATH);

	attr.mq_maxmsg = MAX_MESSAGES;
	attr.mq_msgsize = LOCAL_MAX_PACKET_SIZE;
	lmqd = OpenMmap(ADAPT2_MMAP_FILE_PATH, O_CREAT |  O_RDWR , FILE_MODE, &attr);

	GetAttrMmap(lmqd, &info);

	logDebug2("1: maxmsg = %ld, msgsize = %ld, flags = %ld, curmsgs = %ld\n", info.mq_maxmsg, info.mq_msgsize, info.mq_flags, info.mq_curmsgs);

	if (info.mq_curmsgs != 0)
	{
		SACFLAG = 1; 
		SACOUNT = info.mq_curmsgs;
	}
	if(pthread_mutex_init (&OffMsgArrayMutex,NULL ) != 0)
		logDebug2("Init_Routine: OffMsgArrayMutex Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&MaxPacketMutex,NULL ) != 0)
		logDebug2("Init_Routine: MaxPacketMutex Error in intialising Mutex"),exit(1);

	if( pthread_mutex_init(&array_lock, NULL) != 0)
		logDebug2("Init_Routine: Array Lock Error in intialising Mutex"),exit(1);

	if(pthread_cond_init (&array_wait,NULL ) != 0)
		logDebug2("Init_Routine: Array Wait Error in intialising Cond Variable"),exit(1);	

	pthread_mutexattr_init(&attrPipe);

	pthread_mutex_init(&Pipelock,&attrPipe);

	pthread_mutexattr_destroy (&attrPipe);	

	if (pipe(DummyPipe) != 0)
	{
		logDebug2("Error in creation of the DummyPipe");
		exit(1);
	}	

	iRetVal=InitializeMemoryMapWrite();
	if (iRetVal)
		logDebug2("MemoryMapinitialized");
	else 
		logDebug2("Data present in the file or improper file");

	logDebug2(" Before Threads are started");
	if ( ( pthread_create( &thread_id1 , NULL , MemMapFunc , NULL ) ) != 0 )
	{
		logDebug2( " IN MAIN :   Can't create write MemMapFunc " ) ;
	}
	else
	{
		logDebug2( " IN MAIN :  Created write MemMapFunc " )    ;
	}

	logDebug2(" Going to Spawn 2nd Thread");	
	if ( ( pthread_create( &thread_id2 , NULL , ReadFrmFile , NULL ) ) != 0 )
	{
		logDebug2( " IN MAIN :   Can't create thread ReadFrmFile " ) ;
	}
	else
	{
		logDebug2( "IN ELSE :  Created thread ReadFrmFile  " )    ;
	}

	while(1)
	{
		sleep(1000);
	}
}	
/***********************************************************************************************
  Function Name      :       ReadFrmFile
Arguments          :       Character Pointer
Return Values      :       BOOL
Tables Used        :       NONE
Dependencies       :
Functions Called By:       Threads in the main function.
 ***********************************************************************************************/
void ReadFrmFile ( )
{
	long FileIndex;
	int prio=2;
	int iPacketCount=0;
	struct  mymq_attr  memmap_attr,memmap_attr_sac;
	int Length=0;
	int Length1=0;
	int MsgNumber=0;
	LONG32	iTempMsgCode = 0 ;
	sigset_t SequenceSet;
	int sig1=0;
	int UserId=0;
	int RFLAG = TRUE;
	struct NNF_HEADER *header;	
	LONG32	iMsglen=0;
	CHAR	RcvMsg [ LOCAL_MAX_PACKET_SIZE  ] , SndMsg [ LOCAL_MAX_PACKET_SIZE ]         ;
	CHAR	MapdMsg [ LOCAL_MAX_PACKET_SIZE  ], *RcvMsgMMap;
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet , SIGUSR1);
	sigaddset ( &SequenceSet , SIGUSR2);            
	sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
	logDebug2("In Readthread :: Process Id	::	%d",getpid());	

	RcvMsgMMap = (char *)malloc (sizeof(struct TempMmap));

	while ( TRUE )
	{
		memset (RcvMsgMMap,' ',sizeof(struct TempMmap));

		GetAttrMmap ( lmqd , &memmap_attr_sac );
		iTempMsgCode = 0 ;

		if (memmap_attr_sac.mq_curmsgs == 0)
			logDebug2("Readthread : There are no packets already in the file ;pipecount =  %d",pipecount); 

#ifdef DBG 	
		logDebug2("Readthread : Messages to be read from the file = %d",memmap_attr_sac.mq_curmsgs);
#endif	

		if (SACOUNT !=0)
		{
#ifdef DBG
			logDebug2("Rreadthread : :Inside sacount not 0");
#endif
			logDebug2(" Readthread : SACFLAG = %d & msgs = %d",SACFLAG,memmap_attr_sac.mq_curmsgs);
		}
		else if(PipeCheck(RFLAG)) 
		{
			logDebug2("Readthread : pipecount =  %d",pipecount);
		}
		else
		{
			logDebug2(" Readthread : Waiting for write thread to signal on dummy pipe.");
			read(DummyPipe[0],&DummyChar,sizeof(CHAR));
			logDebug2(" Readthread : Finished Reading from dummy pipe");
		}
		if ( ( ReadPrsntSeqMmap(lmqd, RcvMsgMMap, sizeof(struct TempMmap), &prio)) < 0)
		{
			logDebug2("Readthread : ReadFrmFile error in receiving");
			exit(1);
		}
		if (SACOUNT == 0)
			SACFLAG=0;

		GetAttrMmap ( lmqd , &memmap_attr );
		iPacketCount++;
		memset ( &RcvMsg 	, ' ' , LOCAL_MAX_PACKET_SIZE );

		logDebug2("Readthread ******** Packets read from file and sent ahead : %d ************** ",iPacketCount);
		MsgNumber	=	(( struct TempMmap*)RcvMsgMMap)->MsgNumber;
		FileIndex=(( struct TempMmap*)RcvMsgMMap)->FileIndex;
		memcpy((char*)RcvMsg,(( struct TempMmap*)RcvMsgMMap)->RcvMsg,LOCAL_MAX_PACKET_SIZE);



		logDebug3("((struct NNF_HEADER *)RcvMsg)->iMsgLength :%d:",((struct NNF_HEADER *)RcvMsg)->iMsgLength);
		logDebug3("((struct NNF_HEADER *)RcvMsg)->iMsgCode	:%d:",((struct NNF_HEADER *)RcvMsg)->iMsgCode);

		TWIDDLE(((struct NNF_HEADER *)RcvMsg)->iMsgCode);
		iTempMsgCode = 	((struct NNF_HEADER *)RcvMsg)->iMsgCode;

		
		TWIDDLE(((struct NNF_HEADER *)RcvMsg)->iMsgCode);

		logInfo("iTempMsgCode :%d:",iTempMsgCode);

		switch(iTempMsgCode)
		{

			case TC_EQU_NSE_ORD_ENT_ERR_RSP_TM:
                        case TC_EQU_NSE_ORD_MOD_ERR_RSP_TM:
                        case TC_EQU_NSE_ORD_CAN_ERR_RSP_TM:
                        case TC_EQU_NSE_ORD_ENT_CON_RSP_TM:
                        case TC_EQU_NSE_ORD_MOD_CON_RSP_TM:
                        case TC_EQU_NSE_ORD_CAN_CON_RSP_TM:
                        case TC_EQU_NSE_MKT_TO_LMT_RSP_TM:

					iMsglen = sizeof(struct NNF_ORD_RESPONSE_TM);
					

				break;

			case TC_EQU_NSE_TRADE_RSP_TM:
					iMsglen =  sizeof(struct NNF_TRADE_RESP_TM);

				break;

			default:

				TWIDDLE(((struct NNF_HEADER *)RcvMsg)->iMsgLength);

				iMsglen = ((struct NNF_HEADER *)RcvMsg)->iMsgLength;

				logDebug3("iMsglen :%d:",iMsglen);
				TWIDDLE(((struct NNF_HEADER *)RcvMsg)->iMsgLength); /***** Again Twiddeling for making it original packet -- DO not remove this ****/
				logDebug3("((struct NNF_HEADER *)RcvMsg)->iMsgLength :%d:",((struct NNF_HEADER *)RcvMsg)->iMsgLength);

				break;

		}
		logDebug2("-----------Before Twiddle---------------");
		logDebug2(" ReadFrmFile Message Length ::%d",Length);
		logDebug2(" ReadFrmFile Message Length1 ::%d",Length1);
		logDebug2(" ReadFrmFile Message MsgNumber ::%d",MsgNumber);
		logDebug2(" ReadFrmFile Message FileIndex ::%d",FileIndex);
		logDebug2("----------End--------------------");

		if( WriteMsgQ(SndQ, &RcvMsg,iMsglen, 1) ==ERROR)
		{
			perror("Readthread : Write to Q Failed ...");
			logDebug2("Readthread SndQ id = %d \n",SndQ);
			exit(1);
		}
		else
		{
			SetStatusofPacket(TRUE, lmqd); /* Packet Can be Marked as processed, as sucessfully processed */
			logDebug2("Readthread : Calling ReduceMesgMmap ...\n");

			ReduceMesgMmap(lmqd);

			if(SACFLAG)
			{
				logDebug2("Readthread : Reducing SACOUNT....\n");
				logDebug2("Readthread : SACOUNT b4 Reducing = [%d]..\n",SACOUNT);
				SACOUNT--;
				logDebug2("Readthread : SACOUNT aftr Reducing = [%d]..\n",SACOUNT);
				if (SACOUNT == 0)
					SACFLAG=0;
			}

		}		
		logDebug2("Readthread.. successfully Written To The Queue%d",SndQ);
	}	
}
BOOL InitializeMemoryMapWrite()
{
	CHAR    RcvMsg [ LOCAL_MAX_PACKET_SIZE  ];
	int iPktCount =0;
	char choice ;
	int i=0;
	int sig_send=0;
	int iForkFlag=FALSE;
	float OrderNumber =0.0;
	struct  mymq_attr   MemMapFunc_attr , MemMapFunc_info ;
	struct timeval MStartTime,MEndTime;
	MemMapFunc_attr.mq_maxmsg       = MAX_MESSAGES;
	MemMapFunc_attr.mq_msgsize  = MSG_SIZE;

	Memory_Mmap     = OpenMmap( ADAPT2_MMAP_FILE_PATH, O_CREAT |  O_RDWR , FILE_MODE, &MemMapFunc_attr );

	GetAttrMmap ( Memory_Mmap , &MemMapFunc_info );

	if ( MemMapFunc_info.mq_maxmsg != MAX_MESSAGES ||MemMapFunc_info.mq_msgsize != 512 || MemMapFunc_info .mq_curmsgs != 0 )
	{
		logDebug2("GetAttrMmap in Init MemMap maxmsg = %ld, msgsize = %ld, flags = %ld, curmsgs = %ld\n", MemMapFunc_info.mq_maxmsg, MemMapFunc_info.mq_msgsize, MemMapFunc_info.mq_flags, MemMapFunc_info.mq_curmsgs );
		return FALSE;
	}
	else 
		return TRUE;
}

void MemMapFunc ()
{
	CHAR    RcvMsg [ LOCAL_MAX_PACKET_SIZE  ];
	int iPktCount =0;
	char choice ;
	int i=0;
	int sig_send=0;
	int iForkFlag=FALSE;
	CHAR    NewMsg[ LOCAL_MAX_PACKET_SIZE  ];
	float OrderNumber =0.0;
	struct  mymq_attr   MemMapFunc_attr , MemMapFunc_info ;
	struct timeval MStartTime,MEndTime;
	struct NNF_HEADER *header;
	int Length=0;
	int WFLAG = FALSE;	
	logDebug2(" MemMapFunc In WriteTo File :: Process Id	::	%d",getpid());	

	logDebug2("ReadMsgQ		= %d",RcvQ);

	for(;;)
	{
		logDebug2(" MemMapFunc ==============WRITE TO MEMMAP PACKET NO: %d ====================", iPktCount++ ) ;
		memset(NewMsg,' ',LOCAL_MAX_PACKET_SIZE);
		logDebug2 ("Before reading");	
		if((ReadMsgQ(RcvQ,NewMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE)
		{
			perror("Error ReadMesgQ ");
			exit(1);
		}
		OrderNumber=OrderNumber+1.0;
		header = (struct NNF_HEADER *)malloc(sizeof (struct NNF_HEADER));
		memset (header,' ', sizeof( struct NNF_HEADER));
		memcpy(header, NewMsg, sizeof(struct NNF_HEADER));	
		Length = header->iMsgLength;

#ifdef DBG
		logDebug2("MemMapFunc OrderNumber      ::  %f",OrderNumber);
		logDebug2("MemMapFunc Length           ::  %d",Length);
#endif
		WriteMmap( Memory_Mmap, (CHAR *)&NewMsg,LOCAL_MAX_PACKET_SIZE, 2 ,OrderNumber , iPktCount );
		if (PipeCheck(WFLAG))
		{		
			logDebug2(" Waiting to write on dummy pipe %d times ",pipecount );
			if (write(DummyPipe[1],(void *)&DummyChar,sizeof(CHAR)) < 0)
			{
				perror("ProcessIncomingPacket: Error in writing to pipe");
				logDebug2(" error is :%d",errno);
			}
		}

	}
}

BOOL PipeCheck(int FLAG)
{
	logDebug2 ("Inside pipecheck..... pipecount = %d", pipecount);	
	pthread_mutex_lock(&Pipelock);
	switch(FLAG)
	{
		case TRUE:
			if (pipecount >= (INDICATOR + 2))
			{
				pipecount--;
				pthread_mutex_unlock(&Pipelock);	
				logDebug2("pipecount= %d" , pipecount);		
				return TRUE;
			}
			else
			{
				pipecount--;
				pthread_mutex_unlock(&Pipelock);
				logDebug2(" pipecount = %d", pipecount);	
				return FALSE;
			}
			break;	
		case FALSE:
			if (pipecount <= INDICATOR )
			{
				pipecount++;
				pthread_mutex_unlock(&Pipelock);
				logDebug2 ("pipecount <=1; pipecount = %d", pipecount);
				return TRUE;
			}
			else
			{
				pipecount++;
				pthread_mutex_unlock(&Pipelock);	
				logDebug2 ("else' pipecount = %d ", pipecount);	
				return FALSE;
			}	
			break ;
		default :
			logDebug2(" INVALID FLAG FROM Pipecheck");

	}

}

key_t  GetDecimalVal(char * hexString)
{
	int valuetobeadded = 0;
	int i;
	int ascii = 0;
	int decimal = 0;
	int itemp = 0;
	char str[50];
	strcpy(str,hexString);

	int j=0;
	for(i=strlen(str)-1;i>=5;i--)
	{
		decimal +=  itemp;
		switch(str[i])
		{
			case  'a'  :
			case  'A'  :  ascii = 10;
				      break;
			case  'b'  :
			case  'B'  :  ascii = 11;
				      break;
			case  'c'  :
			case  'C'  :  ascii = 12;
				      break;
			case  'd'  :
			case  'D'  :  ascii = 13;
				      break;
			case  'e'  :
			case  'E'  :  ascii = 14;
				      break;
			case  'f'  :
			case  'F'  :  ascii = 15;
				      break;
			default     :  ascii  = str[i] - 48;
		}

		if (j != 0)
			itemp = powii(16,j);
		else
			itemp = 1;
		j++;
		itemp = ascii * itemp;
		valuetobeadded += itemp;
	}
	logDebug2("Decimal = %d",valuetobeadded);
	return (key_t)valuetobeadded;
}

int powii(int val,int pow)
{
	int i ;
	int value = 1;
	for(i=0;i<pow;i++)
		value = value * val;
	return value;
}

/*********************************************************************************
 **********************************************************************************
 **      FUNCTION NAME     : signal_handler                                      **
 **                                                                              **
 **      DESCRIPTION       : Gets called when a a signal is caught by the process**
 **                          and in turn calls exit_handler for clearing the     **
 **                          resources and exiting gracefully.                   **
 **                                                                              **
 **      ARGUMENTS PASSED  : NONE                                                **
 **                                                                              **
 **      RETURN VALUE      : BOOL                                                **
 **********************************************************************************
 *********************************************************************************/
void signal_handler(LONG32 Sig)
{
#ifdef DBG
	logDebug2("signal_handler: Signal caught is::%d",Sig);
#endif
	exit_handler();
	return;
}

/***************************************************************
 ****************************************************************
 **      FUNCTION NAME   :exit_handler                         **
 **      DESCRIPTION     :Gets called when the process exits . **
 **                       Updates the shared memory            **
 **                       to indicated the status of the       **
 **                       process(DOWN).                       **
 ****************************************************************
 ***************************************************************/
BOOL exit_handler()
{
	logDebug2("Inside the exit_handler ");
	_exit(1);
}

void TwiddleMMAP(void *pVoid,short iLen)
{

	char  * pStr = (char  *)pVoid;
	char    cTemp[ 500 ];
	short   i;
	memcpy (cTemp,
			pStr,
			iLen);

	for (i = 0; i < iLen; i++)
	{
		*(pStr + i) = cTemp[iLen - i - 1];
	}
}


