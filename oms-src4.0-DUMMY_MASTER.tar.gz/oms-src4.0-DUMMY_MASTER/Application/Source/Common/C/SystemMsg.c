

#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"


MYSQL	*DB_SysMsg;

LONG32	iRcvMsgQ;

main()
{
	logTimestamp("Entry : SystemMsg [main]");	

	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);	

	DB_SysMsg = DB_Connect();	

	if((iRcvMsgQ=OpenMsgQ(TrdRtrToSysMsg))==ERROR)
	{
		perror("\n Error in Opening TrdRtrToSysMsg....");
		exit(ERROR);
	}

	ProcessMsg();	

	logTimestamp("Exit : SystemMsg [main]");
}

BOOL	ProcessMsg()
{
	logDebug2("hiii............");
	CHAR    sRcvMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR    sSystemMsg[90];
	struct ORDER_RESPONSE *pSysMsg;
	struct INT_ERROR_FE_RESP *pErrMsg;	
	struct INT_COMMON_RESP_HDR *pHrdRsp;

	LONG32 iMsgCode;
	DOUBLE64	fOrdNumber;	

	//CHAR	*sInsQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sInsQry [MAX_QUERY_SIZE];

	LONG32	iCount = 0;
	CHAR	sExchId[EXCHANGE_LEN];
	CHAR	sSecurityId[SECURITY_ID_LEN];
	CHAR	sClientId[CLIENT_ID_LEN];
	CHAR 	cSegment;
	LONG32	iSeqNo,iUserId;;	


	while(TRUE)
	{
		memset(sRcvMsg,'\0',LOCAL_MAX_PACKET_SIZE);
		memset(sSystemMsg,'\0',90);
		memset(&pSysMsg,'\0',sizeof(struct ORDER_RESPONSE));
		memset(&pErrMsg,'\0',sizeof(struct INT_ERROR_FE_RESP));
		memset(&pHrdRsp ,'\0',sizeof(struct INT_COMMON_RESP_HDR));
		memset(sExchId,'\0',EXCHANGE_LEN);
		memset(sSecurityId,'\0',SECURITY_ID_LEN);
		memset(sClientId,'\0',CLIENT_ID_LEN);
		memset(sInsQry,'\0',MAX_QUERY_SIZE);


		fOrdNumber = 0.00;

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if((ReadMsgQ(iRcvMsgQ,&sRcvMsg,LOCAL_MAX_PACKET_SIZE, 0)) != TRUE)
		{
			perror("Error Read Q ");
			exit(ERROR);
		}

		pHrdRsp = (struct INT_COMMON_RESP_HDR *) &sRcvMsg;
		pSysMsg = (struct ORDER_RESPONSE *) &sRcvMsg;
		pErrMsg = (struct INT_ERROR_FE_RESP *) &sRcvMsg;

		iSeqNo   = pHrdRsp->iSeqNo;
		iMsgCode = pHrdRsp->iMsgCode;


		iUserId = pHrdRsp->iUserId;
		cSegment = pHrdRsp->cSegment;


		logDebug2("Recieved iMsgCode :%d:",iMsgCode);
		logDebug2("Recieved cSegment :%c:",cSegment);

		switch(iMsgCode)
		{
			case TC_INT_OM_CONF_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	

				logDebug2("sClientId :%s:",sClientId);
				sprintf(sSystemMsg,"Exch Order Modification Confirmation %f",fOrdNumber);	
				break;	
			case TC_INT_OC_CONF_RESP:
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				fOrdNumber = pSysMsg->fOrderNum;
				sprintf(sSystemMsg,"Exch Order Cancellation Confirmation %f",fOrdNumber);	
				break;
			case TC_INT_ORDER_ENTRY_RSP:
				logDebug2("New Msg1");
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				fOrdNumber = pSysMsg->fOrderNum;
				logDebug2("New Msg2");
				sprintf(sSystemMsg,"New ORDER NO is %f",fOrdNumber);	
				break;
			case TC_INT_OE_CONF_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Exch Order Confirmation is %f",fOrdNumber);	
				break;
			case TC_INT_ORDER_REJECTION:
			case TC_INT_RMS_ORD_REJECTION:
				logDebug2("New Msg1 %s",pErrMsg->sClientId);

				logDebug2("New Msg1");
				strncpy(sSystemMsg,pErrMsg->sErrorMsg,ERROR_MSG_LEN);
				strncpy(sClientId,pErrMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pErrMsg->sSecurityId,SECURITY_ID_LEN);	
				logDebug2("New Msg1 %s %s",sClientId,sSecurityId);
				break;

			case TC_INT_MKT_LMT_CONVT_RESP :
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Market To Limit Confirmation %f",fOrdNumber);	
				break;

			case TC_INT_OE_ERROR_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Exch Order Rejection NO is %f",fOrdNumber);	

				break;
			case TC_INT_SL_ORDER_TRIG_RESP:		
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Stop Losss Trigger is %f",fOrdNumber);	
				break;

			case TC_INT_OM_ERROR_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				logDebug2("sClientId :%s:",sClientId);
				sprintf(sSystemMsg,"Exch Modification Rejection NO is %f",fOrdNumber);	
				break;
			case TC_INT_OC_ERROR_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Exch Cancellation Rejection NO is %f",fOrdNumber);	
				break;
			case TC_INT_OE_FREEZE_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Exch Order Freeze %f",fOrdNumber);	

				break;
			case TC_INT_ORDER_MODIFY_RSP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Modify ORDER NO is %f",fOrdNumber);	

				break;
			case TC_INT_ORDER_CANCEL_RSP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Cancellation ORDER NO is %f",fOrdNumber);	
				break;

			case TC_INT_TRADE_RESP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);	
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);	
				sprintf(sSystemMsg,"Exch Trade Response is %f",fOrdNumber);	

				break;

			case TC_INT_OFF_ORDER_ENTRY_RSP:
				fOrdNumber = pSysMsg->fOrderNum;
				strncpy(sClientId,pSysMsg->sClientId,CLIENT_ID_LEN);
				strncpy(sSecurityId,pSysMsg->sSecurityId,SECURITY_ID_LEN);
				sprintf(sSystemMsg,"OFF Order Response is %f",fOrdNumber);

			default :
				logDebug2("Invalid MsgCode :%d:",iMsgCode);
				continue;

		};
		strncpy(sExchId,pHrdRsp->sExcgId,EXCHANGE_LEN);		
		logDebug2("iUserId :%d:",iUserId);
		logDebug2("iMsgCode:%d:",iMsgCode);
		logDebug2("sSystemMsg:%s:",sSystemMsg);
		logDebug2("iSeqNo:%d:",iSeqNo);
		logDebug2("sExchId:%s:",sExchId);
		logDebug2("sClientId:%s:",sClientId);
		logDebug2("pSysMsg->sClientId:%s:",pSysMsg->sClientId);
		logDebug2("sSecurityId:%s:",sSecurityId);
		logDebug2("cSegment:%c:",cSegment);


		sprintf(sInsQry,"INSERT INTO SYSTEM_MESGS (SM_USER_ID , SM_TRANS_CODE ,SM_TIME ,SM_GENERAL_MESG, \
			SM_SEQUENCE_NO, SM_EXCH_ID,SM_CLIENT_ID,SM_SECURITY_ID,SM_SEGMENT)\
				VALUES(\
					%d,\
					%d,\
					now(),\
					\"%s\",\
					%d,\
					\"%s\",\
					\"%s\",\
					\"%s\",\
					\'%c\'\										
				      );",iUserId,iMsgCode,sSystemMsg,iSeqNo,sExchId,sClientId,sSecurityId,cSegment);

		logDebug2("sInsQry :%s:",sInsQry);

		if((mysql_query(DB_SysMsg,sInsQry)) != SUCCESS)
		{
			logSqlFatal("Error in Insert QUERY.");
			sql_Error(DB_SysMsg);
		}
		else
		{
			logDebug2("Row Inserted :%d:",mysql_affected_rows(DB_SysMsg));
		}




	}	

}




