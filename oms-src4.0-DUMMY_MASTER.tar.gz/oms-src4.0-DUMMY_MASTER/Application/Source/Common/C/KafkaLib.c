#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include "rdkafka.h"


static void
dr_msg_cb(rd_kafka_t *rk, const rd_kafka_message_t *rkmessage, void *opaque) {
        if (rkmessage->err)
                fprintf(stderr, "%% Message delivery failed: %s\n",
                        rd_kafka_err2str(rkmessage->err));
        else
                fprintf(stderr,
                        "%% Message delivered (%zd bytes, "
                        "partition %" PRId32 ")\n",
                        rkmessage->len, rkmessage->partition);

        /* The rkmessage is destroyed automatically by librdkafka */
}


rd_kafka_t	*KafkaConProducer(char *topic)
{
	rd_kafka_conf_t *conf;
	char errstr[512];      /* librdkafka API error reporting buffer */
	rd_kafka_t *rk;        /* Producer instance handle */
	char brokers[100];   /* Argument: broker list */
	memset(brokers,'\0',100);
	printf("\n Topic value :%s: \n",topic);
	if(getenv("RS_KAFKA_HOST_PORT") == NULL)
	{
		printf("\n Value is null \n");
	}
	else
	{
		printf("\n Value is not null :%s:\n",getenv("RS_KAFKA_HOST_PORT"));

	}		
	strncpy(brokers,getenv("RS_KAFKA_HOST_PORT"),100);	

	conf = rd_kafka_conf_new();

	if (rd_kafka_conf_set(conf, "bootstrap.servers", brokers, errstr,sizeof(errstr)) != RD_KAFKA_CONF_OK) 
	{
                printf("%s\n", errstr);
                return 1;
        }

	rd_kafka_conf_set_dr_msg_cb(conf, dr_msg_cb);

	rk = rd_kafka_new(RD_KAFKA_PRODUCER, conf, errstr, sizeof(errstr));
        if (!rk) {
                printf( " Failed to create new producer: %s\n",
                        errstr);
                return 1;
        }


	return rk;		

}

rd_kafka_t      *KafkaConConsumer(char *topic,char *groupid)
{
        rd_kafka_conf_t *conf;
        char errstr[512];      /* librdkafka API error reporting buffer */
        rd_kafka_t *rk;        /* Producer instance handle */
        char brokers[100];   /* Argument: broker list */
        memset(brokers,'\0',100);
	int i;
	rd_kafka_topic_partition_list_t *subscription;
	rd_kafka_resp_err_t err;
        printf("\n Topic value :%s: \n",topic);
        if(getenv("RS_KAFKA_HOST_PORT") == NULL)
        {
                printf("\n Value is null \n");
        }
        else
        {
                printf("\n Value is not null :%s:\n",getenv("RS_KAFKA_HOST_PORT"));

        }
        strncpy(brokers,getenv("RS_KAFKA_HOST_PORT"),100);

        conf = rd_kafka_conf_new();

        if (rd_kafka_conf_set(conf, "bootstrap.servers", brokers, errstr,sizeof(errstr)) != RD_KAFKA_CONF_OK)
        {
                printf("%s\n", errstr);
                return 1;
        }

	if (rd_kafka_conf_set(conf, "group.id", groupid, errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

	if (rd_kafka_conf_set(conf, "auto.offset.reset", "earliest", errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

	rk = rd_kafka_new(RD_KAFKA_CONSUMER, conf, errstr, sizeof(errstr));
        if (!rk) {
                fprintf(stderr, "%% Failed to create new consumer: %s\n",
                        errstr);
                return 1;
        }

        conf = NULL;
	rd_kafka_poll_set_consumer(rk);
	
	subscription = rd_kafka_topic_partition_list_new(1);
        for (i = 0; i < 1 ; i++)
                rd_kafka_topic_partition_list_add(subscription, topic,
                                                  /* the partition is ignored
 *  *                                                    * by subscribe() */
                                                  RD_KAFKA_PARTITION_UA);


	err = rd_kafka_subscribe(rk, subscription);
        if (err) {
                fprintf(stderr, "%% Failed to subscribe to %d topics: %s\n",
                        subscription->cnt, rd_kafka_err2str(err));
                rd_kafka_topic_partition_list_destroy(subscription);
                rd_kafka_destroy(rk);
                return 1;
        }

	rd_kafka_topic_partition_list_destroy(subscription);

        return rk;

}




rd_kafka_resp_err_t KafkaProducer(rd_kafka_t *rk,char *TopicName,char *MemBuf,int MsgLength)
{
	rd_kafka_resp_err_t err;
	
	err = rd_kafka_producev(rk,RD_KAFKA_V_TOPIC(TopicName),RD_KAFKA_V_MSGFLAGS(RD_KAFKA_MSG_F_COPY),RD_KAFKA_V_VALUE(MemBuf, MsgLength),RD_KAFKA_V_OPAQUE(NULL),RD_KAFKA_V_END);
	
	if(err)
	{
		perror("Message not written to Kafka ");
		
		return -1;	
	}
	else
	{
		printf("\n\n---Written succesfully to the Kafka with acknowledge of 500 milli second");
		rd_kafka_flush(rk, 500);
		printf("\n\n---Written succesfully to the Kafka = %s  MsgLength=%d\n",TopicName,MsgLength);
		rd_kafka_poll(rk, 0 /*non-blocking*/);
		return 1;

	}
}


void	KafkaReader(rd_kafka_t *rk,char *MsgBuf)
{
	while (1) {
                rd_kafka_message_t *rkm;

                rkm = rd_kafka_consumer_poll(rk, 10);
                if (!rkm)
                        continue;
		if (rkm->err) {
			printf("\nCaught Error\n");
                        rd_kafka_message_destroy(rkm);
                        continue;
                }
		
		
		memcpy(MsgBuf,rkm->payload,rkm->len);
		rd_kafka_message_destroy(rkm);	
			
		return 1;
	}
}
