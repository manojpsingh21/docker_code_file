#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"
#include "IPCS.h"

redisReply *reply2;
redisContext    *RdConn1;


BOOL fUpdateMktStatus_InRedis(INT16 iMktStatus,CHAR cSegment ,CHAR *sExchange, INT16 iMkttype)

{
	logTimestamp("Entry : [fUpdateMktStatus_InRedis]");
	
	logDebug2("Printing all values from argument");
	logDebug2("iMktStatus  :%d:",iMktStatus);
        logDebug2("iMkttype    :%d:",iMkttype);
        logDebug2("cSegment    :%c:",cSegment);
        logDebug2("sExchange   :%s:",sExchange);

/*	
	INT16 iMktSts  = 0;
        INT16 iMktType = 0;
        CHAR  sExch     [EXCHANGE_LEN];
        CHAR  cSeg     = '\0';
	memset(sExch,'\0',EXCHANGE_LEN);
*/
	CHAR sKeyValue[MAX_COMMAND_LEN];
        CHAR sCommand[MAX_COMMAND_LEN];
        
	memset(sKeyValue,'\0',MAX_COMMAND_LEN);
        memset(sCommand,'\0',MAX_COMMAND_LEN);

/*
        iMktSts = iMktStatus;
        iMktType = iMkttype;
        cSeg = cSegment;
	strncpy (sExch,sExchange,EXCHANGE_LEN);
	
        logDebug2("iMktStatus  :%d:",iMktSts);
        logDebug2("iMktType    :%d:",iMktType);
        logDebug2("cSeg        :%c:",cSeg);
        logDebug2("sExch       :%s:",sExch);
*/
		
	RdConn1 = RDConnect(REDIS_TYPE_MKT_STATUS);	
	if(RdConn1 == NULL)
        {
                logInfo("Redis not connected ");
        }

	sprintf(sKeyValue,"%s:%c:%d",sExchange,cSegment,iMkttype);	
	logDebug2("sKeyValue :%s:",sKeyValue);
	
	sprintf(sCommand,"HMSET %s MARKET_STATUS %d",sKeyValue,iMktStatus);
	logTimestamp("sCommand -> %s",sCommand);
	reply2 = redisCommand(RdConn1,sCommand);
	freeReplyObject(reply2);

	logTimestamp("Exit  : [fUpdateMktStatus_InRedis]");	

}
