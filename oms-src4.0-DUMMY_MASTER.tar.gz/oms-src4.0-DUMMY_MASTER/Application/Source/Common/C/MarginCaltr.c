#include <stdio.h>
#include <stdlib.h>
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>


LONG32          iOrderRtrToCalMrg;
LONG32          iOrdSrvToTrdRtr;

//LONG32          iRcvQId;

LONG32          iCnt = 0;
MYSQL	*DBconMRG;


main(int argc, char *argv[])
{
	logTimestamp("------------Entry in main-------------");
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);

	DBconMRG = DB_Connect();
	OpenMsgQue();
	CalculatorMarg();
}


void OpenMsgQue()
{
	logTimestamp("----------------Entry in Openmsg queue.----------------");

	if((iOrderRtrToCalMrg= OpenMsgQ(OrderRtrToCalMrg)) == ERROR)
	{
		logFatal("Error in open queue (OrderRtrToCalMrg)");
		exit(ERROR);
	}
	logInfo("OrderRtrToCalMrg open successfully with id = %d ",iOrderRtrToCalMrg);

	if((iOrdSrvToTrdRtr = OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal("Error in open queue (OrdSrvToTrdRtr)");
		exit(ERROR);
	}
	logInfo("DeaNotiToTrdRtr open successfully with id = %d ",iOrdSrvToTrdRtr);

	logTimestamp("Exit [OpenMsgQue]");
}


void CalculatorMarg()
{
	logTimestamp("-----------Entry :CalculatorMarg------------");

	struct INT_COMMON_REQUEST_HDR *pIntHeadr;
	struct  MARGIN_CAL_RESP	 pRspMargin;	

	CHAR    RecBuff[RUPEE_MAX_PACKET_SIZE];
	LONG64  iEntryTime;
	BOOL    iCheckFlag = FALSE;
	LONG32  iMsgCode ;
	//      LONG32  iCnt = 0;

	while(TRUE)
	{
		memset(RecBuff , '\0', RUPEE_MAX_PACKET_SIZE);
		memset( &pIntHeadr , '\0', sizeof(struct INT_COMMON_REQUEST_HDR));
		memset( &pRspMargin , '\0', sizeof(struct MARGIN_CAL_RESP));

		logInfo("----------------------- Notification LOOP = %d -----------------------",iCnt++);

		if((ReadMsgQ(iOrderRtrToCalMrg,&RecBuff,RUPEE_MAX_PACKET_SIZE, 0)) != TRUE)
		{
			logFatal("Error : MsgQId is %d",iOrderRtrToCalMrg);
			exit(ERROR);
		}

		if(mysql_set_server_option(DBconMRG,CLIENT_MULTI_STATEMENTS) == 0)
        	{
                	logDebug2(" mysql_set_server_option SUCCESS");
        	}
        	else
        	{
                	logDebug2(" mysql_set_server_option FAILS");
        	}

		pIntHeadr = (struct INT_COMMON_REQUEST_HDR *) &RecBuff;

		iMsgCode = pIntHeadr->iMsgCode; 

		logDebug2("iMsgCode :%d:",iMsgCode);

		switch(iMsgCode)
		{
			case TC_INT_CO_MRG_CAL_REQ:
			case TC_INT_BO_MRG_CAL_REQ:
			case TC_INT_MRG_CAL_REQ :
				CalOrdMrg(&RecBuff,&pRspMargin);	
				break;
			default :
				logFatal("Request is Invalid iMsgCode :%d:",iMsgCode);
				continue ;

		};

		if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pRspMargin, sizeof(struct  MARGIN_CAL_RESP), 1)) != TRUE  )
		{
			logFatal("Error : WriteMsgQ failed in SendRespToFE.");
			exit(ERROR);
		}
	}

	logTimestamp("-----------Exit :CalculatorMarg:-----------");
}


LONG32	CalOrdMrg(CHAR	*sRecvMsg,struct  MARGIN_CAL_RESP *pMrgCal)
{
	logTimestamp("-----------Entry :CalOrdMrg:------------");
	
	DOUBLE64 	fBOTriggerPrice=0.00;
	DOUBLE64	fTotMargin = 0.00;
	DOUBLE64	fSpanMargin = 0.00;
	DOUBLE64	fExpoMargin = 0.00;
	DOUBLE64	fVarElmMargin = 0.00;
	DOUBLE64	fAvailBalance = 0.00;
	DOUBLE64	fInsffBalnc = 0.00;
	DOUBLE64        fBrokerage = 0.00;
	INT16		iStatus;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	Pr_Query [MAX_QUERY_SIZE];

	struct  ORDER_REQUEST *pReqMrg;
	memset(&pReqMrg,'\0',sizeof(struct  ORDER_REQUEST));

	memset(Pr_Query,'\0',MAX_QUERY_SIZE);

	pReqMrg = (struct  ORDER_REQUEST *)sRecvMsg;

	fTrim(pReqMrg->sSecurityId,strlen(pReqMrg->sSecurityId));
	fTrim(pReqMrg->sEntityId,strlen(pReqMrg->sEntityId));
	fTrim(pReqMrg->sClientId,strlen(pReqMrg->sClientId));
	
	logDebug2("sSecurityId :%s:",pReqMrg->sSecurityId);
	logDebug2("sEntityId :%s:" ,pReqMrg->sEntityId);
	logDebug2("sClientId :%s:",pReqMrg->sClientId);
	logDebug2("pReqMrg->cProductId :%c: ",pReqMrg->cProductId);
	logDebug2("ReqHeader.cSegment :%c:",pReqMrg->ReqHeader.cSegment);
	logDebug2("pReqMrg->ReqHeader.sExcgId :%s:",pReqMrg->ReqHeader.sExcgId);
	logDebug2("pReqMrg->iTotalQtyRem :%i:",pReqMrg->iTotalQtyRem);	
	logDebug2("pReqMrg->fPrice :%f:",pReqMrg->fPrice);
	logDebug2("pReqMrg->cBuyOrSell :%c:",pReqMrg->cBuyOrSell);
	logDebug2("pReqMrg->fTriggerPrice :%f:",pReqMrg->fTriggerPrice);
	

	if (pReqMrg->cProductId != 'B')
	{	
	sprintf(Pr_Query,"CALL PR_KNOW_YOUR_MARG(LTRIM(RTRIM(\"%s\")),LTRIM(RTRIM(\"%s\")),\'%c\',\'%c\',\"%s\",%d,%f,\'%c\',%f,@STATUS,@MARGIN, \
		@SPAN_MARGIN, @EXPO_MARGIN,@VAR_ELM_MAGIN,@AVAILFUNDLIMIT,@INSFAMT,@BROKERAGE); \
			SELECT @STATUS,IFNULL(@MARGIN,0),IFNULL(@SPAN_MARGIN,0),IFNULL(@EXPO_MARGIN,0),IFNULL(@VAR_ELM_MAGIN,0),IFNULL(@AVAILFUNDLIMIT,0),IFNULL(@INSFAMT,0),IFNULL(@BROKERAGE,0);",pReqMrg->sClientId,pReqMrg->sSecurityId,\
			pReqMrg->cProductId,pReqMrg->ReqHeader.cSegment,pReqMrg->ReqHeader.sExcgId,pReqMrg->iTotalQtyRem,pReqMrg->fPrice,pReqMrg->cBuyOrSell,pReqMrg->fTriggerPrice);

	logDebug2(":%s:",Pr_Query);
	}

	if (pReqMrg->cProductId == 'B') 
	{

		if (pReqMrg->cBuyOrSell==INT_BUY)
		{	
			fBOTriggerPrice =  pReqMrg->fPrice + pReqMrg->fTriggerPrice;
			logDebug2("fBOTriggerPrice :%f:",fBOTriggerPrice);
	
		}
		else if (pReqMrg->cBuyOrSell==INT_SELL)
		{
			fBOTriggerPrice =  pReqMrg->fPrice - pReqMrg->fTriggerPrice;
                        logDebug2("fBOTriggerPrice :%f:",fBOTriggerPrice);
		}
	

	sprintf(Pr_Query,"CALL PR_KNOW_YOUR_MARG(LTRIM(RTRIM(\"%s\")),LTRIM(RTRIM(\"%s\")),\'%c\',\'%c\',\"%s\",%d,%f,\'%c\',%f,@STATUS,@MARGIN, \
                @SPAN_MARGIN, @EXPO_MARGIN,@VAR_ELM_MAGIN,@AVAILFUNDLIMIT,@INSFAMT,@BROKERAGE); \
                        SELECT @STATUS,IFNULL(@MARGIN,0),IFNULL(@SPAN_MARGIN,0),IFNULL(@EXPO_MARGIN,0),IFNULL(@VAR_ELM_MAGIN,0),IFNULL(@AVAILFUNDLIMIT,0),IFNULL(@INSFAMT,0),IFNULL(@BROKERAGE,0);",pReqMrg->sClientId,pReqMrg->sSecurityId,\
                        pReqMrg->cProductId,pReqMrg->ReqHeader.cSegment,pReqMrg->ReqHeader.sExcgId,pReqMrg->iTotalQtyRem,pReqMrg->fPrice,pReqMrg->cBuyOrSell,fBOTriggerPrice);
        logDebug2("BO Query--- :%s:",Pr_Query);

		
	}
	if(mysql_query(DBconMRG,Pr_Query) != SUCCESS)
	{
		sql_Error(DBconMRG);
		logFatal("Error IN CALLING PR_KNOW_YOUR_MARG.");
		return ERROR;
		//exit(ERROR);
	}

	do
	{
		Res = mysql_store_result(DBconMRG);
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				fTotMargin = atof(Row[1]);
				logDebug2("%f",atof(Row[1]));
				fSpanMargin = atof(Row[2]);
				logDebug2("%f",atof(Row[2]));
				fExpoMargin = atof(Row[3]);
				logDebug2("%f",atof(Row[3]));
				fVarElmMargin = atof(Row[4]);
				logDebug2("%f",atof(Row[4]));
				fAvailBalance = atof(Row[5]);
				logDebug2("%f",atof(Row[5]));
				fInsffBalnc = atof(Row[6]);
				logDebug2("%f",atof(Row[6]));
				fBrokerage = atof(Row[7]);
                                logDebug2("%f",atof(Row[7]));

				logInfo("Client:%s: fTotMargin :%f: fSpanMargin :%f: fExpoMargin :%f: fVarElmMargin:%f: fAvailBalance :%f: fInsffBalnc :%f: fBrokerage :%f:",pReqMrg->sClientId,fTotMargin,fSpanMargin,fExpoMargin,fVarElmMargin,fAvailBalance,fInsffBalnc,fBrokerage);
				mysql_free_result(Res);
			}
		}
		else
		{
			logDebug2("Noo Result Set ");
		}

		logDebug2(" Before mysql_next_result");
		if((iStatus = mysql_next_result(DBconMRG)) > 0)
		{
			logDebug3("Could not execute statement");
		}

	}while(iStatus == 0);

	pMrgCal->pRspHeader.iSeqNo           = pReqMrg->ReqHeader.iSeqNo;
	pMrgCal->pRspHeader.iMsgLength       = sizeof(struct MARGIN_CAL_RESP);
	pMrgCal->pRspHeader.iMsgCode	     = TC_INT_MRG_CAL_RESP ;
	pMrgCal->pRspHeader.iErrorId         = 0;
	pMrgCal->pRspHeader.iUserId          = pReqMrg->ReqHeader.iUserId;
	pMrgCal->pRspHeader.cSource          = pReqMrg->ReqHeader.cSource;
	pMrgCal->pRspHeader.iTimeStamp       = 0;
	pMrgCal->pRspHeader.cSegment         = pReqMrg->ReqHeader.cSegment;
	strncpy(pMrgCal->pRspHeader.sExcgId,pReqMrg->ReqHeader.sExcgId,EXCHANGE_LEN);

	pMrgCal->fTotMargin = fTotMargin;
	pMrgCal->fSpanMargin= fSpanMargin;
	pMrgCal->fExpoMargin= fExpoMargin;
	pMrgCal->fVarElmMargin= fVarElmMargin;
	pMrgCal->fAvailBalance= fAvailBalance;
	pMrgCal->fInsffBalnc= fInsffBalnc;
	pMrgCal->fBrokerage= fBrokerage;



	logTimestamp("Exit :CalOrdMrg:");
}



/*LONG32	CalCOMrg(CHAR	*sRecvMsg,struct  MARGIN_CAL_RESP *pMrgCal)
{
	logTimestamp("Entry  :CalCOMrg:");
	logTimestamp("Exit :CalCOMrg:");

}
LONG32	CalBOMrg(CHAR	*sRecvMsg,struct  MARGIN_CAL_RESP *pMrgCal)
{
	logTimestamp("Entry :CalBOMrg:");
	logTimestamp("Exit :CalBOMrg:");

}*/

