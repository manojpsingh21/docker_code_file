#include <time.h>
//#include "timedef.h"
#define		OFFSET			315532800
#define     	TIMEZONE		19800


void ConvSecToDate(long seconds,char *pDateTime)
{
	logTimestamp(" Entry :ConvSecToDate:");
	struct tm *tmr;

	time_t julian;


	tmr = (struct tm *) malloc (sizeof(struct tm )) ;
	julian = seconds + OFFSET - TIMEZONE;
	localtime_r(&julian,tmr);
	sprintf(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_mday, tmr->tm_mon+1,tmr->tm_year+1900,tmr->tm_hour ,
			tmr->tm_min  ,tmr->tm_sec );
	logTimestamp("quit");
	free(tmr);

}
void convert_seconds_to_date_bcast(long seconds,char *pDateTime)
{
	struct tm *tmr;

	time_t julian;


	tmr = (struct tm *) malloc (sizeof(struct tm )) ;
	julian = seconds + OFFSET - TIMEZONE;
	localtime_r(&julian,tmr);
	sprintf(pDateTime,"%d-%d-%d %d:%d:%d",tmr->tm_mday, tmr->tm_mon+1,tmr->tm_year+1900,tmr->tm_hour ,
			tmr->tm_min  ,tmr->tm_sec );
	printf("\n The Date is : %s",pDateTime);
	free(tmr);

}
