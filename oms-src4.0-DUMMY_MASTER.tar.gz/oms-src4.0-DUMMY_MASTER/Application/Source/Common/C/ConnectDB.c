#include <my_global.h>
#include <mysql.h>
//#include "IPCS.h"
#define min 40
#define max 125


void sql_Error(MYSQL *con)
{
	if(strcmp(mysql_error(con),"MySQL server has gone away") == 0)
	{
		sql_Fatal(con);
	}
	else
	{
		logError("%i", mysql_errno(con));
		logError("%s", mysql_error(con));
	}
}

void sql_Fatal(MYSQL *con)
{
	logFatal("%i", mysql_errno(con));
	logFatal("%s", mysql_error(con));
	mysql_close(con);
	exit(1);
}

void Unscramble(char *sStr)
{
	int i=0;
	for(i = strlen(sStr) - 1; i >= 0; i--)
	{
		//printf("%c\n",sStr[i]);
		if((sStr[i] - i) < min)
		{
			sStr[i] = max - (min - (sStr[i] - i));
		}
		else
		{
			sStr[i] = sStr[i] - i;
		}
	}
}

MYSQL *DB_Connect()
{
	logTimestamp("Entry : [DB_Connect]");
	char sDbUser[20];
	char sDbPasswd[20];
	char sSchema[20];
	char sHostIP[75];
	char sHostPort[10];
	int  iPort = 0;

	memset(sDbUser,'\0',20);
	memset(sDbPasswd,'\0',20);
	memset(sSchema,'\0',20);
	memset(sHostIP,'\0',75);

	MYSQL *DB_Con = mysql_init(NULL);

	strncpy(sDbUser,getenv("MYSQL_USER"),20);
	strncpy(sDbPasswd,getenv("MYSQL_PASS"),20);
	strncpy(sSchema,getenv("MYSQL_DB"),20);
	strncpy(sHostIP,getenv("MYSQL_HOST"),75);
	strncpy(sHostPort,getenv("MYSQL_PORT"),10);
	iPort = atoi(sHostPort); 

	if (DB_Con == NULL){
		sql_Fatal(DB_Con);
		return DB_Con;
	}

	my_bool reconnect = 1;
	//mysql_options(DB_Con, MYSQL_OPT_RECONNECT, &reconnect);
	//mysql_options(DB_Con, MYSQL_OPT_CONNECT_TIMEOUT, 60);

	if (mysql_options(DB_Con, MYSQL_OPT_RECONNECT, &reconnect)) {
		logInfo("MYSQL_OPT_RECONNECT SET FAILED.");
	} else {
		logInfo("MYSQL_OPT_RECONNECT SET SUCCESS.");
	}

	logDebug2("sHostIP 	:%s:",sHostIP);
	logDebug2("sDbUser	:%s:",sDbUser);
	logDebug2("sDbPasswd	:%s:",sDbPasswd);
	logDebug2("sSchema	:%s:",sSchema);



	Unscramble(sDbPasswd);
	Unscramble(sSchema);
	logDebug2("sSchema :%s: sDbPasswd :%s:",sSchema,sDbPasswd);
	//logDebug2("sSchema :%s: sDbPasswd :%s:",sSchema,sDbPasswd);

	//if (mysql_real_connect(DB_Con, "localhost", "root", "rupeesql", "rupeeSQLDB", 0, NULL, 0) == NULL){
	//if (mysql_real_connect(DB_Con, sHostIP, sDbUser, sDbPasswd, sSchema, 0, NULL, 0) == NULL)
	if (mysql_real_connect(DB_Con, sHostIP, sDbUser, sDbPasswd, sSchema, iPort, NULL,CLIENT_MULTI_STATEMENTS) == NULL)
	{
		sql_Fatal(DB_Con);
		return DB_Con;
	}

	logInfo("Connected to Database.");

	logTimestamp("Exit : [DB_Connect]");
	return DB_Con;
}

MYSQL *DB_Slave_Connect()
{
        logTimestamp("Entry : [DB_Slave_Connect]");
        char sDbUser[20];
        char sDbPasswd[20];
        char sSchema[20];
        char sHostIP[75];
        char sHostPort[10];
        int  iPort = 0;

        memset(sDbUser,'\0',20);
        memset(sDbPasswd,'\0',20);
        memset(sSchema,'\0',20);
        memset(sHostIP,'\0',75);

        MYSQL *DB_Con = mysql_init(NULL);

        strncpy(sDbUser,getenv("MYSQL_SLAVE_USER"),20);
        strncpy(sDbPasswd,getenv("MYSQL_SLAVE_PASS"),20);
        strncpy(sSchema,getenv("MYSQL_SLAVE_DB"),20);
        strncpy(sHostIP,getenv("MYSQL_SLAVE_HOST"),75);
        strncpy(sHostPort,getenv("MYSQL_SLAVE_PORT"),10);
        iPort = atoi(sHostPort);

        if (DB_Con == NULL){
                sql_Fatal(DB_Con);
                return DB_Con;
        }

        my_bool reconnect = 1;
	if (mysql_options(DB_Con, MYSQL_OPT_RECONNECT, &reconnect)) {
                logInfo("MYSQL_OPT_RECONNECT SET FAILED.");
        } else {
                logInfo("MYSQL_OPT_RECONNECT SET SUCCESS.");
        }

        logDebug2("sHostIP      :%s:",sHostIP);
        logDebug2("sDbUser      :%s:",sDbUser);
        logDebug2("sDbPasswd    :%s:",sDbPasswd);
        logDebug2("sSchema      :%s:",sSchema);



        Unscramble(sDbPasswd);
        Unscramble(sSchema);
        logDebug2("sSchema :%s: sDbPasswd :%s:",sSchema,sDbPasswd);
	if (mysql_real_connect(DB_Con, sHostIP, sDbUser, sDbPasswd, sSchema, iPort, NULL,CLIENT_MULTI_STATEMENTS) == NULL)
        {
                sql_Fatal(DB_Con);
                return DB_Con;
        }

        logInfo("Connected to slave Database.");

        logTimestamp("Exit : [DB_Slave_Connect]");
        return DB_Con;
}


