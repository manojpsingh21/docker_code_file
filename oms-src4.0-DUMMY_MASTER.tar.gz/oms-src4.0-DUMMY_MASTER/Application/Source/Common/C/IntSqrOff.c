#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

LONG32 	iAutoSqoffToOrdRtr;
LONG32	iRDaemonToSqoff;
LONG32  iMmapToD2C1;
LONG32  iOrdSrvToTrdRtr;
LONG32	iMsgType = 0;
LONG32	iCount = 0;
LONG32	iGrpId= 0;
LONG32	iCanCount = 0;
LONG32	iPumpCount = 0;
LONG32	iCount1 = 0;
LONG32	iCount2 = 0;

SHORT	fTrim(CHAR * sStr_In ,SHORT iMaxLen);
MYSQL	*DB_IntSqr;
CHAR    sAdmin [15];
CHAR    sOrderVal[INTSQROFF_ORDER_VAL_LEN];
LONG32  iOrderVal;
ULONG64  iUserId;
CHAR	sFreuency[SIP_REG_NEM_LEN];
CHAR	sBatchName[20];
CHAR	cFrency	= '\0';
CHAR	cIntradayFlag = '\0';
CHAR    sGrpId [ENV_VARIABLE_LEN];
CHAR    sOmstype[ENV_VARIABLE_LEN];
CHAR	cOmstype = '\0';
BOOL    fPumpOffOrdSIP(CHAR *RcvMsg,CHAR cFreuency);
BOOL    fUpdtOffMktBPSIP(CHAR *RcvMsg, CHAR sBatchName[20]);
LONG32	iBuffSec =0;
CHAR    sAmotype[ENV_VARIABLE_LEN];
CHAR	cAmo_type = '\0';

main(INT16 argc, CHAR **argv)
{
	BOOL	iRetVal;
	CHAR    sMsgType [3];
	CHAR	cDay[SIP_REG_NEM_LEN];
	CHAR	cTDay[SIP_REG_NEM_LEN];

	LONG32  iMsgCode , iRow ,iValue, i ;
	CHAR	cSegment;
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;

	LONG64	Time = 0;
	CHAR	sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	struct 	ORDER_REQUEST	*pSrOfOrd;
	struct  INT_COMMON_REQUEST_HDR *pIntHeadr;
	CHAR    sSelectQry[MAX_QUERY_SIZE];
	CHAR    sQry1[MAX_QUERY_SIZE];
	CHAR    sQry2[MAX_QUERY_SIZE];

	memset(sFreuency,'\0',SIP_REG_NEM_LEN);
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	memset(sQry1,'\0',MAX_QUERY_SIZE);
	memset(sQry2,'\0',MAX_QUERY_SIZE);
	memset(sAdmin ,'\0',15);
	memset(sMsgType,'\0',3);
	memset(cDay,'\0',SIP_REG_NEM_LEN);
	memset(cTDay,'\0',SIP_REG_NEM_LEN);
	memset(sAmotype,'\0',ENV_VARIABLE_LEN);

	setbuf(stdout,NULL);
	setbuf(stdin, NULL );
	OpenMsgQue();
	//	cMsgType = argv[1][0];
	//        iMsgType = cMsgType - '0';

	logDebug2("argv[1]:%s:",argv[1]);
	strcpy(sMsgType,argv[1]);
	iMsgType = atoi(sMsgType);
	logDebug2("sMsgTyps[%s] iMsgType[%d]",sMsgType,iMsgType);

	if(getenv("GROUP_ID") == NULL)
	{
		logFatal("Error : Environment Variable missing : GROUP_ID");
		exit(ERROR);
	}
	else
	{
		strncpy(sGrpId,getenv("GROUP_ID"),ENV_VARIABLE_LEN);
		iGrpId = atoi(sGrpId);
	}
	if(getenv("MASTER_SLAVE") == NULL)
	{
		logFatal("Error : Environment Variable missing : MASTER_SLAVE");
		exit(ERROR);
	}
	else
	{
		strncpy(sOmstype,getenv("MASTER_SLAVE"),ENV_VARIABLE_LEN);
		cOmstype = sOmstype[0];
		logDebug2("Master Slave :%s:",sOmstype); 
		logDebug2("Master Slave :%c:",cOmstype); 
	}
	if(getenv("AMO_TYPE") == NULL)
        {
                logDebug2("Not Configured amo type so default is multiple pump with independent of market type: ");
        }
        else
        {
		strncpy(sAmotype,getenv("AMO_TYPE"),ENV_VARIABLE_LEN);
		cAmo_type = sAmotype[0];
		logDebug2( "cAmo_type :%c:", cAmo_type);
        }
	

	DB_IntSqr = DB_Connect();

	//	sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  = 'Default_admin' ");
	sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  IN ( 'Default_admin'  ,'Intr_Sqoff_Sys_config','Default_userid') order by s.PARAM_NAME asc");

	if (mysql_query(DB_IntSqr ,sSelectQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error Fetching SysAdmin .");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry);

	Res = mysql_store_result(DB_IntSqr);
	iRow = (mysql_num_rows(Res));
	if(iRow == 0)
	{
		mysql_free_result(Res);
		logDebug2("Zero rows selected from sys_parameter for param_name Default_admin & Intr_Sqoff_Sys_config");
		exit(ERROR);
	}
	else
	{
		logDebug2("Number of rows Selected from SYS_PARAMETER = :%d:",iRow);
		for(i = 0 ; i < iRow ; i ++)
		{
			if(Row = mysql_fetch_row(Res))
			{

				switch (i)
				{
					case 0 :
						strncpy(sAdmin,Row[0],15);
						break ;

					case 1 :
						logDebug2("Row[0] :%d:",atoi(Row[0]));
						// As this value will get fetched from user master so commenting this @Ashish
						/**if(Row[0] == NULL)
						{
							iUserId = 123;
							logDebug2("iUserId in if :%d:",iUserId);
						}
						else
						{
							iUserId = strtoull(Row[0],NULL,10);	
							logDebug2("iUserId in else :%llu:",iUserId);
						}**/
					case 2 :
						logInfo("Fetching Intr_Sqoff_Sys_config Flag");
						if(Row[0][0] == NULL)
						{
							cIntradayFlag = ALL ;
							logDebug2("Assining All Flag as NULL Value is set for Intr_Sqoff_Sys_config in SYS_PARAMETER ");
							break ;

						}
						else
						{
							logInfo("Got Intr_Sqoff_Sys_config flag as :%c:",Row[0][0]);
							cIntradayFlag = Row[0][0] ;
							break ;
						}

					default :
						logDebug2("Wrong case");
						break ;
				}
			}
		}
		mysql_free_result(Res);
	}
	// User ID fetching from user master for default admin set in SYS PARAMETERS @Ashish
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
        sprintf(sSelectQry,"SELECT USER_CODE FROM USER_MASTER WHERE USER_ENTITY_CODE = LTRIM(RTRIM(\"%s\")); ",sAdmin);
        logDebug2("sSelectQry :%s:",sSelectQry);

        if (mysql_query(DB_IntSqr ,sSelectQry) != SUCCESS)
        {
                sql_Error(DB_IntSqr);
                logSqlFatal("Error Fetching SysAdmin .");
	                exit(ERROR);
        }
        logDebug2("Query [%s]",sSelectQry);

        Res = mysql_store_result(DB_IntSqr);
	if(Row =  mysql_fetch_row(Res))
        {
                logDebug2("Row[0] :%llu:",strtoull(Row[0],NULL,10));
                if(Row[0] == NULL)
                {
                        iUserId = 123;
                        logDebug2("iUserId in if :%llu:",iUserId);
                }
                else
                {
			iUserId = strtoull(Row[0],NULL,10);	
                        logDebug2("iUserId in else :%llu:",iUserId);
                }
        }
        mysql_free_result(Res);
	
	logDebug2("Value loaded from Sys_parameter for sAdmin :%s: and cIntradayFlag :%c: and iUserId :%llu:",sAdmin,cIntradayFlag,iUserId);
	/*Intraday Squareoff order validity make configurable*/
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
        sprintf(sSelectQry,"SELECT PARAM_VALUE FROM SYS_PARAMETERS WHERE PARAM_NAME='INTRADAY_SQROFF_VALIDITY'");
        logDebug2("sSelectQry :%s:",sSelectQry);

        if (mysql_query(DB_IntSqr ,sSelectQry) != SUCCESS)
        {
                sql_Error(DB_IntSqr);
                logSqlFatal("Error Fetching SysAdmin .");
                exit(ERROR);
        }
        logDebug2("Query [%s]",sSelectQry);
        Res = mysql_store_result(DB_IntSqr);
        if(Row =  mysql_fetch_row(Res))
        {
                logDebug2("Row[0] :%s:",Row[0]);
                strncpy(sOrderVal,Row[0],INTSQROFF_ORDER_VAL_LEN);
                logDebug2("sOrderVal :%s:",sOrderVal);

                if(strcmp(sOrderVal,"DAY") == 0)
                {
                        logDebug3("IN CASE OF DAY");
                        iOrderVal = VALIDITY_DAY;
                }
                else if(strcmp(sOrderVal,"IOC") == 0)
                {
                        logDebug3("IN CASE OF IOC");
                        iOrderVal = VALIDITY_IOC;
                }
                else
                {
                        logDebug3("IN CASE OF DEFAULT 1");
                }

        }
	else
        {
                iOrderVal = VALIDITY_IOC;
                logDebug3("IN CASE OF DEFAULT 2");
                logDebug2("iOrderVal :%d:",iOrderVal);
        }
        mysql_free_result(Res);
        logDebug2("Value loaded from Sys_parameter for INTRADAY_SQROFF_VALIDITY :%d:",iOrderVal);
	
	if(getenv("AMO_THROTTLING_ORDER_RATE") == NULL)
	{
		logWarn("Environment AMO_THROTTLING_ORDER_RATE not define in rupeeseed.env.Setting this to 0");
		iBuffSec =0;
	}
	else
	{
		if(atoi(getenv("AMO_THROTTLING_ORDER_RATE")) <= 0  )
		{
			iBuffSec =0;
		}
		else
		{
			iBuffSec = 1000000/atoi(getenv("AMO_THROTTLING_ORDER_RATE")) ;
			logInfo("iBuffSec is :%d: microseconds",iBuffSec);	
		}
	}

	while(1)
	{
		memset(&sRcvMsg,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(&pSrOfOrd,'\0',sizeof(struct ORDER_REQUEST));
		logDebug2("iMsgType :%d:",iMsgType);	

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if(ReadMsgQ(iRDaemonToSqoff,&sRcvMsg,RUPEE_MAX_PACKET_SIZE,iMsgType) != 1)
		{
			logFatal("Error : MsgQID is %d",iRDaemonToSqoff);
			exit(ERROR);
		}

		pSrOfOrd = (struct ORDER_REQUEST *)&sRcvMsg;

		iMsgCode = pSrOfOrd->ReqHeader.iMsgCode;
		logDebug2("iMsgCode = %d",iMsgCode);
		logDebug2("SEGMENT :%c:",pSrOfOrd->ReqHeader.cSegment);
		logDebug2("EXCAHNGE :%s:",pSrOfOrd->ReqHeader.sExcgId);

		logTimestamp("------------------Printing Header--------------------");
		logDebug2("pReqHeader->iUserId          :%llu:",pSrOfOrd->ReqHeader.iUserId);
		logDebug2("pReqHeader->iMsgLength       :%d:",pSrOfOrd->ReqHeader.iMsgLength);
		logDebug2("pReqHeader->iMsgCode         :%d:",pSrOfOrd->ReqHeader.iMsgCode);
		logDebug2("pReqHeader->sExcgId          :%s:",pSrOfOrd->ReqHeader.sExcgId);
		logDebug2("pReqHeader->cSource          :%c:",pSrOfOrd->ReqHeader.cSource );
		logDebug2("pReqHeader->cSegment         :%c:",pSrOfOrd->ReqHeader.cSegment);
		logInfo("-------------------------------------------------------");

		logDebug2("Going To Send Resp to FE");
		iRetVal = fSqOffRespToFE(&sRcvMsg);
		if(iRetVal == FALSE)
		{
			logInfo("Failed !!! Messages Are sent to failed");
		}
		else
		{
			logInfo("Sucessfully messages are sent to FE");
		}
		
		if(iMsgCode != TC_INT_PUMPOFFLINE_REQ)
		{
			logDebug2("The Orders are NON AMO So Taking Sleep of 5 Seconds");
			sleep(5);	
		}

		if(iMsgCode == TC_INT_SQUAREOFF_INTRADAY_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);	
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlEqPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Cancelled Failed");	
				}
				else
				{
					logInfo("Equity Orders Cancelled Sucessfully");
				}						

				sleep(60);	

				if(cOmstype == OMS_MASTER)
				{
					iRetVal = fSqrOffEqSellOrd(&sRcvMsg);
					logDebug2("iCount1 :%d:",iCount1);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Sell Equity Orders Failed");
					}	
					else
					{
						logInfo("SquareOff of Sell Equity Orders Sucess");	
					}

					iRetVal=fSqrOffEqBuyOrd(&sRcvMsg);		
					logDebug2("iCount2 :%d:",iCount2);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Buy Equity Orders Failed");	
					}
					else
					{
						logInfo("SquareOff of Buy Equity Orders Sucess");
					}
					iPumpCount = iCount1 + iCount2;
					logDebug2("iPumpCount:%d:",iPumpCount);

				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}	
			else 	if((pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlDrPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Derivative Orders Cancelled Failed");
				}
				else
				{
					logInfo("Derivative Orders Cancelled Sucessfully");
				}

				sleep(60);

				if(cOmstype == OMS_MASTER)
				{
					iRetVal = fSqrOffDrSellOrd(&sRcvMsg);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Sell Derivative Orders Failed");
					}
					else
					{
						logInfo("SquareOff of Sell Derivative Orders Sucess");
					}

					iRetVal=fSqrOffDrBuyOrd(&sRcvMsg);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Buy Derivative Orders Failed");
					}
					else
					{
						logInfo("SquareOff of Buy Derivative Orders Sucess");
					}	
					//iPumpCount = iCount1 + iCount2;
					iPumpCount = iCount1 + iCount2;
					logDebug2("iPumpCount:%d:",iPumpCount);
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Derivative");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Derivative");
				}


			}
			else if(pSrOfOrd->ReqHeader.cSegment == COMMODITY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlMcxPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Commodity Orders Cancelled Failed");
				}
				else
				{
					logInfo("Commodity Orders Cancelled Sucessfully");
				}

				sleep(60);
				if(cOmstype == OMS_MASTER)
				{
					iRetVal = fSqrOffMcxSellOrd(&sRcvMsg);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Sell Commodity Orders Failed");
					}
					else
					{
						logInfo("SquareOff of Sell Commodity Orders Sucess");
					}

					iRetVal=fSqrOffMcxBuyOrd(&sRcvMsg);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Buy Commodity Orders Failed");
					}
					else
					{
						logInfo("SquareOff of Buy Commodity Orders Sucess");
					}
					iPumpCount = iCount1 + iCount2;
					logDebug2("iPumpCount:%d:",iPumpCount);
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Commodity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Commodity");
				}

			}	
			else
			{
				logInfo("Invalid Segment :%c:",pSrOfOrd->ReqHeader.cSegment);	
			}
		}
		else if(iMsgCode == TC_INT_SQUAREOFF_COVER_ORD_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT)
			{
				iRetVal = fBlockCoverOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockCoverOrd");
				}
				else
				{
					logInfo("Cover  Orders Blocked Sucessfully");
				}

				iRetVal = fEqCoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Exit  Failed");
				}
				else
				{
					logInfo("Equity Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}
			else    if((pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockCoverOrd (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockCoverOrd ");
				}
				else
				{
					logInfo("Cover  Orders Blocked Sucessfully ");
				}

				iRetVal = fDrvCoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Derivative/Currency  Orders Exit  Failed");
				}
				else
				{
					logInfo("Derivative/Currency Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Derivative");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Derivative");
				}


			}
			else if (pSrOfOrd->ReqHeader.cSegment == COMMODITY_SEGMENT)
			{	
				iRetVal = fBlockCoverOrd (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockCoverOrd ");
				}
				else
				{
					logInfo("Cover  Orders Blocked Sucessfully ");
				}

				iRetVal = fMcxCoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Commodity  Orders Exit  Failed");
				}
				else
				{
					logInfo("Commodity Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Commodity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Commodity");
				}

			}
			else
			{
				logInfo("Invalid Segment :%c:",pSrOfOrd->ReqHeader.cSegment);
			}
		}
		else if(iMsgCode == TC_INT_SQUAREOFF_BRACKET_ORD_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT)
			{
				iRetVal = fBlockBoOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockBoOrd ");
				}
				else
				{
					logInfo("Bracket  Orders Blocked Sucessfully");
				}

				iRetVal = fEqBoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Exit  Failed");
				}
				else
				{
					logInfo("Equity Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}
			else    if((pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{	
				iRetVal = fBlockBoOrd (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockBoOrd ");
				}
				else
				{
					logInfo("Bracket  Orders Blocked Sucessfully");
				}

				iRetVal = fDrvBoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Derivative/Currency  Orders Exit  Failed");
				}
				else
				{
					logInfo("Derivative/Currency Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Derivative");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Derivative");
				}


			}
			else if (pSrOfOrd->ReqHeader.cSegment == COMMODITY_SEGMENT)
			{
				iRetVal = fBlockBoOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockBoOrd ");
				}
				else
				{
					logInfo("Bracket  Orders Blocked Sucessfully");
				}

				iRetVal = fMcxBoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Commodity Orders Exit  Failed");
				}
				else
				{
					logInfo("Commodity Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Commodity ");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Commodity");
				}

			}
			else
			{
				logInfo("Invalid Segment :%c:",pSrOfOrd->ReqHeader.cSegment);
			}

		}

		else if(iMsgCode == TC_INT_PUMPOFFLINE_REQ)
		{
			pIntHeadr = (struct  INT_COMMON_REQUEST_HDR *)&sRcvMsg;
			cSegment = pIntHeadr->cSegment;
			logDebug2("cSegment :%c:",cSegment);

			if(cSegment == EQUITY_SEGMENT)
			{
				logDebug1("THIS IS EQUITY ");
				if(fDisableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDisableOffMkt Equity");
					return FALSE;
				}
				logDebug3("Success : fDisableOffMkt Equity");

				if(fEquPumpOffOrd(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEquPumpOffOrd Equity");
					return FALSE;
				}
				logDebug3("Success : fEquPumpOffOrd Equity");

				if(fUpdtOffMktBP(&sRcvMsg) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBP Equity");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBP Equity");
				sleep(1);
				if(fEnableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEnableOffMkt Equity");
					return FALSE;
				}
				logDebug3("Success : fEnableOffMkt Equity");

			}		
			else if((cSegment == DERIVATIVE_SEGMENT) || (cSegment == CURRENCY_SEGMENT))
			{
				logDebug1("THIS IS DERIVATIVE ");
				if(fDisableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDisableOffMkt Derivative");
					return FALSE;
				}
				logDebug3("Success : fDisableOffMkt Derivative");

				if(fDrvPumpOffOrd(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDrvPumpOffOrd Derivative");
					return FALSE;
				}
				logDebug3("Success : fDrvPumpOffOrd Derivative");

				if(fUpdtOffMktBP(&sRcvMsg) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBP Derivative");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBP Derivative");
				sleep(1);
				if(fEnableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEnableOffMkt Derivative");
					return FALSE;
				}
				logDebug3("Success : fEnableOffMkt Derivative");

			}
			else if(cSegment == COMMODITY_SEGMENT)
			{

				logDebug1("THIS IS COMMODITY");
				if(fDisableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDisableOffMkt Commodity");
					return FALSE;
				}
				logDebug3("Success : fDisableOffMkt Commodity");

				if(fCommPumpOffOrd(pIntHeadr) == FALSE)
				{
					logFatal("Error : fCommPumpOffOrd Commodity");
					return FALSE;
				}
				logDebug3("Success : fCommPumpOffOrd Commodity");

				if(fUpdtOffMktBP(&sRcvMsg) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBP Commodity");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBP Commodity");

				if(fEnableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEnableOffMkt Commodity");
					return FALSE;
				}
				logDebug3("Success : fEnableOffMkt Commodity");

			}
			else
			{
				logFatal("Invalid Segment :%c:",cSegment);
				return FALSE;
			}	
		}
		else if(iMsgCode == TC_INT_PUMPSIPORDER_REQ)
		{
			logDebug2("^^^^^^^^^^^^^^^^^ START Order for DAY ^^^^^^^^^^^^^^^^^");
			if(fPumpOffOrdSIP(&sRcvMsg,SIP_DY) == FALSE)
			{
				logFatal("Error fPumpOffOrdSIP Equity.. for day");
				return FALSE;
			}
			logDebug3("Success : fPumpOffOrdSIP Equity.. for day");	

			if(fUpdtOffMktBPSIP(&sRcvMsg,&SIP_DAY) == FALSE)
			{
				logFatal("Error : fUpdtOffMktBPSIP Equity for day");
				return FALSE;
			}
			logDebug3("Success : fUpdtOffMktBPSIP Equity for day");
			logDebug2("^^^^^^^^^^^^^^^^^ END Order for DAY ^^^^^^^^^^^^^^^^^");

			logDebug2("******** Start Order for WEEK ********");

			sprintf(sQry1," SELECT CASE WHEN DATE(BP_NEXT_SCHEDULE_DATE) = DATE(SYSDATE()) THEN '%d' ELSE '%d' END \
					FROM BATCH_PROCESS A WHERE A.BP_BATCH_NAME = \'%s\' AND A.BP_EXCH_ID = \'%s\';",TRUE,FALSE,SIP_WEEK,pSrOfOrd->ReqHeader.sExcgId);

			logDebug1("QUERY :%s:",sQry1);

			if (mysql_query(DB_IntSqr,sQry1) != SUCCESS)
			{
				sql_Error(DB_IntSqr);
				logSqlFatal("Error in select date for WEEK.");
				return ERROR;
			}

			Res = mysql_store_result(DB_IntSqr);
			if(mysql_num_rows(Res) == 0)
			{
				logFatal("!!!!!!! Zero row returned for WEEK !!!!!! ");
				mysql_free_result(Res);
				return FALSE;
			}
			else
			{
				Row = mysql_fetch_row(Res);
				iValue = atol(Row[0]);
			}
			logDebug2("iValue = %d",iValue);

			if(iValue == TRUE)
			{
				if(fPumpOffOrdSIP(&sRcvMsg,SIP_WK) == FALSE)
				{
					logFatal("Error fPumpOffOrdSIP Equity.. for Week");
					return FALSE;
				}
				logDebug3("Success : fPumpOffOrdSIP Equity.. for Week");

				if(fUpdtOffMktBPSIP(&sRcvMsg,&SIP_WEEK) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBPSIP Equity for Week");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBPSIP Equity for Week");

			}

			logDebug2("************** END Order for WEEK *************");

			logDebug2("!!!!!!!!!!!!!!!!! START Order for Month !!!!!!!!!!!!!!!!!");
			//			sprintf(sQry2,"select DATE_FORMAT(BP_NEXT_SCHEDULE_DATE,'%d') - DATE_FORMAT(SYSDATE(),'%d') \
			FROM BATCH_PROCESS where BP_BATCH_NAME = 'SIP_MONTHLY';")
				sprintf(sQry2," SELECT CASE WHEN DATE(BP_NEXT_SCHEDULE_DATE) = DATE(SYSDATE()) THEN '%d' ELSE '%d' END FROM BATCH_PROCESS A \
						WHERE A.BP_BATCH_NAME = \'%s\' AND A.BP_EXCH_ID = \'%s\';",TRUE,FALSE,SIP_MONTH,pSrOfOrd->ReqHeader.sExcgId);

			logDebug1("QUERY :%s:",sQry2);

			if (mysql_query(DB_IntSqr,sQry2) != SUCCESS)
			{
				sql_Error(DB_IntSqr);
				logSqlFatal("Error in select date for month.");
				return ERROR;
			}

			Res = mysql_store_result(DB_IntSqr);
			if(mysql_num_rows(Res) == 0)
			{
				logFatal("!!!!!!! Zero row returned.. !!!!!! ");
				mysql_free_result(Res);
				return FALSE;
			}
			else
			{
				Row = mysql_fetch_row(Res);
				iValue = atol(Row[0]);
			}
			logDebug2("iValue = %d",iValue);	

			if(iValue == TRUE)
			{
				if(fPumpOffOrdSIP(&sRcvMsg,SIP_MON) == FALSE)
				{
					logFatal("Error fPumpOffOrdSIP Equity.. for month");
					return FALSE;
				}
				logDebug3("Success : fPumpOffOrdSIP Equity.. for month");

				if(fUpdtOffMktBPSIP(&sRcvMsg,&SIP_MONTH) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBPSIP Equity for Month");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBPSIP Equity for Month");

			}
			logDebug2("!!!!!!!!!!!!!!!!! END Order for Month !!!!!!!!!!!!!!!!!");

			if(fSIPStatusUptd() == FALSE)
			{
				logFatal("ERROR in fSIPStatusUptd function");
				return FALSE;
			}
			logDebug3("Sucess : fSIPStatusUptd");

		}
		else if(iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlCCPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Cancelled Failed");
				}
				else
				{
					logInfo("Equity Orders Cancelled Sucessfully");
				}

				sleep(5);
				if(cOmstype == OMS_MASTER)
				{
					iRetVal = fSqrOffCCSellOrd(&sRcvMsg);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Sell Equity Orders Failed");
					}
					else
					{
						logInfo("SquareOff of Sell Equity Orders Sucess");
					}

					iRetVal=fSqrOffCCBuyOrd(&sRcvMsg);
					if(iRetVal == FALSE)
					{
						logInfo("SquareOff of Buy Equity Orders Failed");
					}
					else
					{
						logInfo("SquareOff of Buy Equity Orders Sucess");
					}
					iPumpCount = iCount1 + iCount2;
					logDebug2("iPumpCount:%d:",iPumpCount);
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}
		}
		else if(iMsgCode == TC_BULK_CANCEL_ADMIN_REQ)
		{
			iRetVal = fBulkCnlEqPendingOrd(&sRcvMsg);
/*			if(iRetVal == FALSE)
			{
				logInfo("Equity Orders Cancellation for Admin Instruction Failed");
			}
			else
			{
				logInfo("Equity Orders Cancellation for Admin Instruction Sucessfull");
			}

*/			if(iRetVal == FALSE)
                        {
                            	if( pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT) 
                                {
                                	logInfo("Equity Orders Cancellation for Admin Instruction Failed");
                                }

 				else if ( pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT)
				{
					logInfo("Derivative Orders Cancellation for Admin Instruction Failed");
				}
				else 
				{
					logInfo("Commodity Orders Cancellation for Admin Instruction Failed");
				}
 			}   
                        else
                        {
                                logInfo(" Orders Cancellation for Admin Instruction Sucessfull");
                        }

		}
		else if(iMsgCode == TC_BULK_SQUAREOFF_ADMIN_REQ)
		{
			iRetVal = fSqrOffEqBulkOrd(&sRcvMsg);
			logDebug2("iCount1 :%d:",iCount1);
			if(iRetVal == FALSE)
			{
				logInfo("SquareOff of Orders From Admin Instruction Failed");
			}
			else
			{
				logInfo("SquareOff of Orders From Admin Instruction Success");
			}
		}
		else if(iMsgCode == TC_BULK_CO_EXIT_ADMIN_REQ)
                {
                        iRetVal = fBulkCoOrdExit(&sRcvMsg);
                        if(iRetVal == FALSE)
                        {
                                logInfo("Equity Orders CO exit for Admin Instruction Failed");
                        }
                        else
                        {
                                logInfo("Equity Orders CO exit for Admin Instruction Sucessfull");
                        }
                }
		else if(iMsgCode == TC_BULK_BO_EXIT_ADMIN_REQ)
                {
                        iRetVal = fBulkBoOrdExit(&sRcvMsg);
                        if(iRetVal == FALSE)
                        {
                                logInfo("Equity Orders BO exit for Admin Instruction Failed");
                        }
                        else
                        {
                                logInfo("Equity Orders BO exit for Admin Instruction Sucessfull");
                        }
                }
		else
		{
			logInfo("Invalid MsdCode :%d:",iMsgCode);
		}

	}

	return TRUE;	

}

BOOL	fSIPStatusUptd()
{
	logTimestamp("Enrty fSIPStatusUptd");

	CHAR	sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);

	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;	

	sprintf(sQry," update SIP_ORDERS set SIP_ORD_STATUS = '%c' where SIP_ORD_STATUS != '%c' AND(DATE(SIP_EXPIRE_DATE) < DATE(SYSDATE()));",\
			EXCH_DELETE_STATUS,EXCH_DELETE_STATUS);

	logDebug2("Query [%s]",sQry);

	if (mysql_query(DB_IntSqr ,sQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error UPDATE SIP_ORDERS STATUS .");
		exit(ERROR);
	} 
	else
	{
		logSqlFatal("UPDATED SUCEESSFULLY SIP_ORDERS STATUS");
	}
	logTimestamp("Exit fSIPStatusUptd");
	return TRUE;

}

BOOL    fPumpOffOrdSIP(CHAR *RcvMsg,CHAR cFreuency)
{
	logTimestamp("Entry in fPumpOffOrdSIP");

	CHAR    *sQuery1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sQuery2 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    *sLTDQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	memset(sQuery1,'\0',MAX_QUERY_SIZE);
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;

	LONG32		iNoOfRow;
	LONG32  	iQty;
	DOUBLE64	fAmount;
	DOUBLE64  	fLtp;
	BOOL		ChkFlag; 
	CHAR		sReason[50];	
	LONG32		iIntMsgCode;	

	struct  ORDER_REQUEST   *pSIPOrd;	
	struct  ORDER_REQUEST   pSIPOrdReq;

	pSIPOrd = (struct  ORDER_REQUEST *)RcvMsg ;

	/*        sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
		  SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
		  SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM SIP_ORDERS\
		  WHERE SIP_ORD_STATUS = 'C' AND SIP_MSG_CODE IN (3000) AND SIP_EXCH_ID = \"%s\"\
		  AND SIP_SERIAL_NO= (SELECT MAX(SIP_SERIAL_NO) FROM SIP_ORDERS WHERE SIP_ORDER_NO = SIP_ORDER_NO)",pSIPOrd->ReqHeader.sExcgId);
		  */

	/*	sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
		SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
		SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM SIP_ORDERS\
		WHERE SIP_ORD_STATUS = '%c' AND SIP_MSG_CODE IN (3000) AND SIP_EXCH_ID = \"%s\"\
		AND SIP_FREQUENCY = \'%c\' AND (DATE(SIP_EXPIRE_DATE) >= DATE(SYSDATE()));",EXCH_CONFIRM_STATUS,pSIPOrd->ReqHeader.sExcgId,cFreuency);

		sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
		SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
		SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM  SIP_ORDERS a WHERE SIP_ORD_STATUS <> '%c' AND SIP_EXCH_ID = \"%s\"\
		AND SIP_FREQUENCY = \'%c\' AND (DATE(SIP_EXPIRE_DATE) >= DATE(SYSDATE())) AND SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO)\
		FROM SIP_ORDERS b WHERE a.SIP_ORDER_NO = b.SIP_ORDER_NO AND a.SIP_ORD_STATUS = '%c');",EXCH_DELETE_STATUS,\
		*/
	//			strncpyp(SIPOrd->ReqHeader.sExcgId,cFreuency,EXCH_CONFIRM_STATUS);

	sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
			SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
			SIP_MKT_TYPE,SIP_EXCH_SYMBOL,SIP_USER_ID,SIP_PAN_NO,SIP_PARTICIPANT_TYPE,SIP_SETTLOR,\
			SIP_MKT_PROTECT_FLG,SIP_MKT_PROTECT_VAL,SIP_GTC_FLG,SIP_ENCASH_FLG,SIP_AMOUNT,IFNULL(IFNULL(L1_LTP, f.BC_PERVIOUS_CLOSE),0),SIP_PRODUCT_ID,\
			SIP_REMARKS1,SIP_REMARKS2 \
			FROM  SIP_ORDERS a LEFT JOIN EQ_L1_WATCH c ON (a.SIP_SCRIP_CODE = c.L1_SCRIP_CODE and c.L1_SEGMENT=a.SIP_SEGMENT \
				and c.L1_EXCHANGE=a.SIP_EXCH_ID) LEFT JOIN BHAV_COPY f ON (f.BC_SCRIP_CODE=a.SIP_SCRIP_CODE and f.BC_SEGMENT=a.SIP_SEGMENT \
					and f.BC_EXCHANGE=a.SIP_EXCH_ID) WHERE SIP_EXCH_ID = \"%s\"\
			AND SIP_FREQUENCY = \'%c\' AND (DATE(SIP_EXPIRE_DATE) >= DATE(SYSDATE())) \
			AND (DATE(SIP_NTD) <= DATE(SYSDATE())) AND SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO)\
				FROM SIP_ORDERS b WHERE a.SIP_ORDER_NO = b.SIP_ORDER_NO AND a.SIP_ORD_STATUS = '%c');",pSIPOrd->ReqHeader.sExcgId,\
			cFreuency,EXCH_CONFIRM_STATUS);

	logDebug2("sQuery1 = %s",sQuery1);

	if(mysql_query(DB_IntSqr,sQuery1)!= SUCCESS)
	{
		logSqlFatal("Error in fPumpOffOrdSIP Query.");
		sql_Error(DB_IntSqr);
		exit(ERROR);
	}
	logDebug2("Query done [fPumpOffOrdSIP]");
	Res = mysql_store_result(DB_IntSqr);

	iNoOfRow = mysql_num_rows(Res);
	logDebug2("iNoOfRow = %d",iNoOfRow);	

	while(Row = mysql_fetch_row(Res))
	{
		memset(&pSIPOrdReq,'\0',sizeof(struct ORDER_REQUEST));
		pSIPOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
		pSIPOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
		strncpy(pSIPOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
		logDebug2("pSIPOrdReq.ReqHeader.sExcgId = %s",pSIPOrdReq.ReqHeader.sExcgId);
		//pSIPOrdReq.ReqHeader.iUserId = atoi(Row[18]);
		pSIPOrdReq.ReqHeader.iUserId = iUserId;
		pSIPOrdReq.ReqHeader.cSource = Row[14][0];		
		logDebug2("pSIPOrdReq.ReqHeader.cSource = %c",pSIPOrdReq.ReqHeader.cSource);
		pSIPOrdReq.ReqHeader.cSegment = Row[5][0];
		logDebug2("pSIPOrdReq.ReqHeader.cSegment = %c",pSIPOrdReq.ReqHeader.cSegment);
		strncpy(pSIPOrdReq.sSecurityId,Row[2],SECURITY_ID_LEN);
		logDebug2("pSIPOrdReq.sSecurityId = %s",pSIPOrdReq.sSecurityId);
		strncpy(pSIPOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
		logDebug2("pSIPOrdReq.sEntityId = %s",pSIPOrdReq.sEntityId);
		strncpy(pSIPOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
		logDebug2("pSIPOrdReq.sClientId = %s",pSIPOrdReq.sClientId);
		pSIPOrdReq.ReqHeader.cSource = Row[14][0];		
		logDebug2("pSIPOrdReq.ReqHeader.cSource = %c",pSIPOrdReq.ReqHeader.cSource);
		//pSIPOrdReq.cProductId = PROD_CNC;
		pSIPOrdReq.cProductId = Row[28][0];
		logDebug2("pSIPOrdReq.cProductId = %c",pSIPOrdReq.cProductId);
		pSIPOrdReq.cBuyOrSell = Row[7][0];
		logDebug2("pSIPOrdReq.cBuyOrSell = %c",pSIPOrdReq.cBuyOrSell);
		pSIPOrdReq.iOrderType = atoi(Row[10]);
		pSIPOrdReq.iOrderValidity = atoi(Row[9]);
		logDebug2("pSIPOrdReq.iOrderValidity = %d",pSIPOrdReq.iOrderValidity);
		pSIPOrdReq.iDiscQty = 0;
		pSIPOrdReq.iDiscQtyRem = 0;
		//	pSIPOrdReq.iTotalQtyRem = atoi(Row[8]);

		iQty = atoi(Row[8]);
		logDebug2("iQty = %d",iQty);
		fAmount = atoi(Row[26]);
		logDebug2("fAmount = %lf",fAmount);
		fLtp = atoi(Row[27]);
		logDebug2("fLtp = %lf",fLtp);

		if(iQty > 0)
		{ 
			pSIPOrdReq.iTotalQty = iQty;
			pSIPOrdReq.iTotalQtyRem = iQty;
		}
		else
		{
			pSIPOrdReq.iTotalQty = fAmount/fLtp ; 
			pSIPOrdReq.iTotalQtyRem = fAmount/fLtp;
		}

		logDebug2("pSIPOrdReq.iTotalQty = %d",pSIPOrdReq.iTotalQty);
		logDebug2("pSIPOrdReq.iTotalQtyRem = %d",pSIPOrdReq.iTotalQtyRem);

		pSIPOrdReq.iTotalTradedQty = 0;
		pSIPOrdReq.iMinFillQty = 0;
		pSIPOrdReq.fPrice = 0;
		pSIPOrdReq.fTriggerPrice = 0;
		pSIPOrdReq.fOrderNum = 0;
		pSIPOrdReq.iSerialNum = 1;
		pSIPOrdReq.cHandleInst = Row[15][0];
		pSIPOrdReq.fAlgoOrderNo = atof(Row[0]); 
		logDebug2("pSIPOrdReq.fAlgoOrderNo = %lf",pSIPOrdReq.fAlgoOrderNo);
		pSIPOrdReq.iStratergyId = STRG_SIP_ORD_PUMP;
		pSIPOrdReq.cOffMarketFlg = OFF_ORD_DISABLE;
		pSIPOrdReq.cProCli = Row[12][0];
		pSIPOrdReq.cUserType = Row[11][0];
		//                pSIPOrdReq.sRemarks = Row[13][0];
		//		strncpy(pSIPOrdReq.sRemarks ,Row[13],REMARKS_LEN);
		strncpy(pSIPOrdReq.sRemarks ,SIP_REMARKS,REMARKS_LEN);
		//                pSIPOrdReq.iMktType = Row[16][0];
		pSIPOrdReq.iAuctionNum = 0;

		if(strcmp(Row[16],MKT_TYPE_NL)== 0)
		{
			pSIPOrdReq.iMktType = NORMAL_MARKET;
		}
		else if(strcmp(Row[16],MKT_TYPE_OL) == 0)
		{
			pSIPOrdReq.iMktType = ODDLOT_MARKET;
		}
		else if(strcmp(Row[16],MKT_TYPE_SP)== 0)
		{
			pSIPOrdReq.iMktType = SPOT_MARKET;
		}
		else if(strcmp(Row[16],MKT_TYPE_AU) == 0)
		{
			pSIPOrdReq.iMktType = AUCTION_MARKET;
		}
		else
		{
			logDebug2(" %s ",Row[16]);
		}
		strncpy(pSIPOrdReq.sPanID,Row[19],INT_PAN_LEN);
		logDebug2("pSIPOrdReq.sPanID = %s",pSIPOrdReq.sPanID);
		pSIPOrdReq.cParticipantType = Row[20][0];
		strncpy(pSIPOrdReq.sSettlor,Row[21],SETTLOR_LEN);
		logDebug2("pSIPOrdReq.sSettlor = %s",pSIPOrdReq.sSettlor);
		pSIPOrdReq.cMarkProFlag = Row[22][0];
		pSIPOrdReq.fMarkProVal = atof(Row[23]);
		pSIPOrdReq.cGTCFlag = Row[24][0];
		pSIPOrdReq.cEncashFlag = Row[25][0];
		strncpy(pSIPOrdReq.sPlatform,Row[29],PLATFORM_LEN);
                logDebug2("pSIPOrdReq.sPlatform = %s",pSIPOrdReq.sPlatform);
                strncpy(pSIPOrdReq.sChannel,Row[30],CHANNEL_LEN);
                logDebug2("pSIPOrdReq.sChannel = %s",pSIPOrdReq.sChannel);


		ChkFlag = FALSE;
		ChkFlag = fSIPPumpValidation(&pSIPOrdReq);

		if(ChkFlag == TRUE)	
		{
			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pSIPOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				logFatal("Error in sent Msg");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
			logDebug2("Send Msg Q Sucessfully.");
			iIntMsgCode = TC_INT_SIP_SUCESS_RESP;
			logDebug2("iIntMsgCode = %d",iIntMsgCode);
			strncpy(sReason,"Order Pump Successfully",50);
		}				
		else if(ChkFlag == FALSE)
		{
			iIntMsgCode = TC_INT_SIP_ERROR_RESP;
			logDebug2("iIntMsgCode = %d",iIntMsgCode);
			strncpy(sReason,"Amount to invest less than LTP",50);	
		}
		logDebug2("sReason : %s",sReason);		

		memset(sLTDQry,'\0',MAX_QUERY_SIZE);
		sprintf(sLTDQry,"UPDATE SIP_ORDERS set SIP_LTD = now() where SIP_ORDER_NO = %lf",pSIPOrdReq.fAlgoOrderNo);
		logDebug2("sLTDQry = %s",sLTDQry);

		if(mysql_query(DB_IntSqr,sLTDQry)!= SUCCESS)
		{
			logSqlFatal("Error in LTD Query.");
			sql_Error(DB_IntSqr);
			exit(ERROR);
		}

		memset(sQuery2,'\0',MAX_QUERY_SIZE);
		sprintf(sQuery2,"INSERT INTO SIP_ORDERS_ARCHIVE (SIP_ORDER_NO, SIP_SERIAL_NO, SIP_SCRIP_CODE, SIP_SYMBOL, SIP_EXCH_ID, \
			SIP_SEGMENT, SIP_ENTITY_ID, SIP_CLIENT_ID, SIP_BUY_SELL_IND, SIP_MSG_CODE, SIP_PRODUCT_ID, SIP_ORD_STATUS,\
				SIP_INTERNAL_ENTRY_DATE, SIP_EXCH_ORDER_TIME, SIP_TOTAL_QTY, SIP_VALIDITY, SIP_ORDER_TYPE, SIP_GOOD_TILL_DAYS,\
				SIP_USER_TYPE, SIP_PRO_CLIENT, SIP_REMARKS, SIP_ERROR_CODE, SIP_SOURCE_FLG, SIP_REASON_CODE, SIP_REASON_DESCRIPTION,\
				SIP_HANDLE_INST, SIP_CLORDID, SIP_ORIG_CLORDID, SIP_MKT_TYPE, SIP_FREQUENCY, SIP_START_DATE, SIP_PERIOD, SIP_EXCH_SYMBOL,\
				SIP_EXPIRE_DATE, SIP_PUMP_DATE,SIP_USER_ID,SIP_PAN_NO,SIP_PARTICIPANT_TYPE,SIP_SETTLOR,SIP_MKT_PROTECT_FLG,\
				SIP_MKT_PROTECT_VAL,SIP_GTC_FLG,SIP_ENCASH_FLG,SIP_AMOUNT,SIP_REMARKS1,SIP_REMARKS2,SIP_INT_START_DATE ) \
			SELECT SIP_ORDER_NO, SIP_SERIAL_NO, SIP_SCRIP_CODE,\
			SIP_SYMBOL, SIP_EXCH_ID, SIP_SEGMENT,SIP_ENTITY_ID, SIP_CLIENT_ID, SIP_BUY_SELL_IND,%d, \
			SIP_PRODUCT_ID, SIP_ORD_STATUS, SIP_INTERNAL_ENTRY_DATE,\
			SIP_EXCH_ORDER_TIME, SIP_TOTAL_QTY, SIP_VALIDITY, SIP_ORDER_TYPE, SIP_GOOD_TILL_DAYS, SIP_USER_TYPE, SIP_PRO_CLIENT,\
			\"%s\", SIP_ERROR_CODE, SIP_SOURCE_FLG, SIP_REASON_CODE, SIP_REASON_DESCRIPTION, SIP_HANDLE_INST, SIP_CLORDID,\
			SIP_ORIG_CLORDID, SIP_MKT_TYPE, SIP_FREQUENCY, SIP_START_DATE, SIP_PERIOD, SIP_EXCH_SYMBOL, SIP_EXPIRE_DATE, NOW(),SIP_USER_ID, \
			SIP_PAN_NO,SIP_PARTICIPANT_TYPE,SIP_SETTLOR,SIP_MKT_PROTECT_FLG,SIP_MKT_PROTECT_VAL,SIP_GTC_FLG,SIP_ENCASH_FLG,SIP_AMOUNT,SIP_REMARKS1,\
			SIP_REMARKS2,SIP_INT_START_DATE FROM SIP_ORDERS B WHERE B.SIP_ORDER_NO = %lf AND B.SIP_SERIAL_NO = (SELECT  MAX(A.SIP_SERIAL_NO) \
			FROM SIP_ORDERS A WHERE A.SIP_ORDER_NO = B.SIP_ORDER_NO);",iIntMsgCode,sReason,pSIPOrdReq.fAlgoOrderNo);

		logDebug2("sQuery2 = %s",sQuery2);

		if(mysql_query(DB_IntSqr,sQuery2)!= SUCCESS)
		{
			logSqlFatal("Error in  Query.");
			sql_Error(DB_IntSqr);
			exit(ERROR);
		}
		logDebug2("Query2 done");

	}

	/*	memset(sQuery2,'\0',MAX_QUERY_SIZE);
		sprintf(sQuery2,"INSERT INTO SIP_ORDERS_ARCHIVE (SIP_ORDER_NO, SIP_SERIAL_NO, SIP_SCRIP_CODE, SIP_SYMBOL, SIP_EXCH_ID, \
		SIP_SEGMENT, SIP_ENTITY_ID, SIP_CLIENT_ID, SIP_BUY_SELL_IND, SIP_MSG_CODE, SIP_PRODUCT_ID, SIP_ORD_STATUS,\
		SIP_INTERNAL_ENTRY_DATE, SIP_EXCH_ORDER_TIME, SIP_TOTAL_QTY, SIP_VALIDITY, SIP_ORDER_TYPE, SIP_GOOD_TILL_DAYS,\
		SIP_USER_TYPE, SIP_PRO_CLIENT, SIP_REMARKS, SIP_ERROR_CODE, SIP_SOURCE_FLG, SIP_REASON_CODE, SIP_REASON_DESCRIPTION,\
		SIP_HANDLE_INST, SIP_CLORDID, SIP_ORIG_CLORDID, SIP_MKT_TYPE, SIP_FREQUENCY, SIP_START_DATE, SIP_PERIOD, SIP_EXCH_SYMBOL,\
		SIP_EXPIRE_DATE, SIP_PUMP_DATE) (SELECT SIP_ORDER_NO, SIP_SERIAL_NO, SIP_SCRIP_CODE, SIP_SYMBOL, SIP_EXCH_ID, SIP_SEGMENT,\
		SIP_ENTITY_ID, SIP_CLIENT_ID, SIP_BUY_SELL_IND, SIP_MSG_CODE, SIP_PRODUCT_ID, SIP_ORD_STATUS, SIP_INTERNAL_ENTRY_DATE,\
		SIP_EXCH_ORDER_TIME, SIP_TOTAL_QTY, SIP_VALIDITY, SIP_ORDER_TYPE, SIP_GOOD_TILL_DAYS, SIP_USER_TYPE, SIP_PRO_CLIENT,\
		SIP_REMARKS, SIP_ERROR_CODE, SIP_SOURCE_FLG, SIP_REASON_CODE, SIP_REASON_DESCRIPTION, SIP_HANDLE_INST, SIP_CLORDID,\
		SIP_ORIG_CLORDID, SIP_MKT_TYPE, SIP_FREQUENCY, SIP_START_DATE, SIP_PERIOD, SIP_EXCH_SYMBOL, SIP_EXPIRE_DATE, NOW() \
		FROM SIP_ORDERS B WHERE B.SIP_SERIAL_NO = (SELECT  MAX(A.SIP_SERIAL_NO) \
		FROM SIP_ORDERS A WHERE A.SIP_ORDER_NO = B.SIP_ORDER_NO ) );",pSIPOrdReq.fAlgoOrderNo);

		logDebug2("sQuery2 = %s",sQuery2);

		if(mysql_query(DB_IntSqr,sQuery2)!= SUCCESS)
		{
		logSqlFatal("Error in  Query.");
		sql_Error(DB_IntSqr);
		exit(ERROR);
		}
		logDebug2("Query2 done");
		*/

	logTimestamp("Exit.... fPumpOffOrdSIP");
	return TRUE;

}


BOOL fEqCoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fEqCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	LONG32 iNoOfRec = 0 ;
	LONG32 	i = 0; 

	struct  CO_ORDER_REQUEST   *pCnlEOrd;
	struct  CO_ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  CO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);	
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause," AND A.EQ_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.EQ_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);


	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_SL_ABSTICK_VALUE ,\
			EQ_PR_ABSTICK_VALUE ,\
			EQ_SL_AT_FLAG ,\
			EQ_PR_ST_FLAG ,\
			EQ_PAN_NO,\
			EQ_PARTICIPANT_TYPE,\
			EQ_SETTLOR,\
			EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,\
			EQ_GTC_FLG,\
			EQ_ENCASH_FLG,\	
			EQ_GROUP_ID,EQ_REMARKS1,EQ_REMARKS2 \
			FROM    EQ_ORDERS A\
			WHERE  A.EQ_ORD_STATUS IN (\'%c\',\'%c\') \
			AND     A.EQ_PRODUCT_ID = \'%c\' \
			AND     A.EQ_LEG_NO =   %d \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
			AND     A.EQ_EXCH_ID = \"%s\" \
			AND     A.EQ_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sClause);

	/*A.EQ_ORD_STATUS IN (\'C\',\'T\')\
	  AND     A.EQ_PRODUCT_ID = \'%c\'\
	  AND	A.EQ_LEG_NO =	%d \
	  AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
	  AND     A.EQ_EXCH_ID = \"%s\" AND A.EQ_SEGMENT = \'%c\';",PROD_COVER,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment);*/

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEqCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	
	logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

	for(i = 0 ; i < iNoOfRec ; i++)
	{
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];

			pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];

			pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			//                pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= STRG_CO_SQR_OFF ;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.fTrailingSLValue = 0.00 ;
			pEOrdReq.fAlgoOrderNo = 0.00 ;
			pEOrdReq.iNoOfLeg = 1 ;
			pEOrdReq.iMinFillQty = atoi(Row[18]) ;
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cAvgLtpFlg = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			//		fPrintAll(pEOrdReq);
			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[31][0];
			strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[35][0];
			pEOrdReq.cEncashFlag= Row[36][0];
			pEOrdReq.iGrpId = atoi(Row[37]) ;
			strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[38],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[39],CHANNEL_LEN);


			logDebug2(" pEOrdReq.CoArray[0].cBuySellInd :%c: ",pEOrdReq.CoArray[0].cBuySellInd);
			logDebug2("pEOrdReq.CoArray[0].fTriggerPrice :%f:",pEOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pEOrdReq.CoArray[1].fTriggerPrice :%f:",pEOrdReq.CoArray[1].fTriggerPrice);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" sClientId :%s: ",pEOrdReq.sClientId);
			logDebug2(" pEOrdReq.sPanID	:%s: ",pEOrdReq.sPanID);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fEqCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fEqBoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fEqBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	LONG32 	iNoOfRec = 0 ;
	LONG32	i = 0;

	struct  BO_ORDER_REQUEST   *pCnlEOrd;
	struct  BO_ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  BO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND  A.EQ_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.EQ_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);

	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_SL_ABSTICK_VALUE ,\
			EQ_PR_ABSTICK_VALUE ,\
			EQ_SL_AT_FLAG ,\
			EQ_PR_ST_FLAG ,\
			EQ_PAN_NO,\
			EQ_PARTICIPANT_TYPE,\
			EQ_SETTLOR,\
			EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,\
			EQ_GTC_FLG,\
			EQ_ENCASH_FLG,\
			EQ_GROUP_ID,EQ_REMARKS1,EQ_REMARKS2\
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS IN (\'%c\',\'%c\') \
			AND     A.EQ_PRODUCT_ID = \'%c\' \
			AND     A.EQ_LEG_NO =   %d \
			AND     A.EQ_ALGO_ORDER_NO = -1 \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
			AND     A.EQ_EXCH_ID = \"%s\" \
			AND     A.EQ_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sClause);
	//A.EQ_ORD_STATUS IN (\'C\',\'T\')\
	AND     A.EQ_PRODUCT_ID = \'%c\'\
		AND     A.EQ_LEG_NO =   %d \
		AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
		AND     A.EQ_EXCH_ID = \"%s\" ;",PROD_BRACKET,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEqBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	

	logDebug2("fEqBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			//	                pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//	                strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			//                pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.fAlgoOrderNo	= -1 ;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= STRG_BO_SQR_OFF;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.BoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cFlag 	  = '0';
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			//	                strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			//              fPrintAll(pEOrdReq);

			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[31][0];
			strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[35][0];
			pEOrdReq.cEncashFlag= Row[36][0];
			pEOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[38],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[39],CHANNEL_LEN);
			logDebug2(" pEOrdReq.BoArray[0].cBuySellInd :%c: ",pEOrdReq.BoArray[0].cBuySellInd);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fEqBoOrdExit [EXIT]");
	return TRUE;
}


BOOL fCnlEqPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlEqPendingOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	CHAR		*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		sClause[MAX_QUERY_SIZE];


	struct	ORDER_REQUEST	*pCnlEOrd;
	struct	ORDER_REQUEST	pEOrdReq;
	LONG32 	 iNoOfRec = 0;
	LONG32 	 i= 0;

	memset(sClause,'\0',MAX_QUERY_SIZE);
	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/	
		sprintf(sClause," AND A.EQ_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF ) /* P */
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/	
		sprintf(sClause,"AND  A.EQ_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);
	/*In where Clause Message code TC_INT_SL_ORDER_TRIG_RESP is added*/
	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\	
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_ALGO_ORDER_NO ,\
			EQ_STRATEGY_ID ,\
			EQ_ORDER_OFFON ,\
			EQ_PAN_NO,\
			EQ_PARTICIPANT_TYPE,\
			EQ_SETTLOR,\
			EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,\
			EQ_GTC_FLG,\
			EQ_ENCASH_FLG,\
			EQ_GROUP_ID,EQ_REMARKS1,EQ_REMARKS2\
			FROM	EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS = \'%c\' \
			AND     A.EQ_MSG_CODE IN (%d,%d,%d)\
			AND     A.EQ_PRODUCT_ID = \'%c\' \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO)\
			AND     A.EQ_EXCH_ID = \"%s\" %s ",\
			EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,TC_INT_SL_ORDER_TRIG_RESP,PROD_INTRADAY,pCnlEOrd->ReqHeader.sExcgId,sClause);


	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlEqPendingOrd Query.");
		exit(ERROR);

	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	

	for (i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));	
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);	
			//	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			//			pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[36]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//			strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);	
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);	
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);	
			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);

			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = '1';//Row[19][0];

			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iStratergyId= STRG_INT_SQR_OFF;
			pEOrdReq.iMinFillQty = atoi(Row[18]);
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			//			pEOrdReq.cOffMarketFlg= Row[28][0];
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			//			pEOrdReq.cUserType = Row[20][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			//			strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);	
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);	


			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}	
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}	
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}	
			else
			{
				logDebug2(" %s ",Row[3]);	
			}

			pEOrdReq.cMarkProFlag= Row[32][0];
			pEOrdReq.fMarkProVal= atof(Row[33]);
			pEOrdReq.cParticipantType= Row[30][0];
			strncpy(pEOrdReq.sSettlor,Row[31],SETTLOR_LEN);	
			pEOrdReq.cGTCFlag= Row[34][0];
			pEOrdReq.cEncashFlag= Row[35][0];
			pEOrdReq.iGrpId = atoi(Row[36]);
			strncpy(pEOrdReq.sPanID,Row[29],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[37],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[38],CHANNEL_LEN);
			logDebug2("SQUARE oFF TESTTTTTTT");
			logDebug2("DB VAL :%s:%c:%s:",Row[29],Row[30][0],Row[31]);
			logDebug2("sSettler :%s:%d:",pEOrdReq.sSettlor,SETTLOR_LEN);	
			logDebug2("sPandId :%s:%d:",pEOrdReq.sPanID,INT_PAN_LEN);	
			logDebug2("cParticipantType :%c:",pEOrdReq.cParticipantType);	
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.sClientId:%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}	
	logTimestamp("EXIT  [fCnlEqPendingOrd]");	
	return TRUE;

}	


BOOL fCnlDrPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlDrPendingOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		sWhereCls[MAX_QUERY_SIZE];

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	LONG32	iNoOfRec = 0;
	LONG32	i = 0;

	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;


	if(pCnlEOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order cancel");
		//sprintf(sWhereCls," AND SUBSTRING_INDEX(DRV_SYMBOL, '-', 1) not in ('EURUSD','GBPUSD','USDJPY')");
		sprintf(sWhereCls," AND DRV_CROSS_CUR_FLAG = \'%c\'",NO);

		logDebug2("sWhereCls :%s:",sWhereCls);	
	}
	else
	{
		sprintf(sWhereCls ," ");	
	}

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);	
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND A.DRV_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.DRV_CLIENT_ID  IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);


	/*In where Clause Message code TC_INT_SL_ORDER_TRIG_RESP is added*/
	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT,\
			DRV_OMS_ALGO_ORD_NO ,\
			DRV_STRATEGY_ID ,\
			DRV_ORDER_OFFON, \				
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID,DRV_REMARKS1,DRV_REMARKS2\
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS  = \'%c\' \
			AND     A.DRV_MSG_CODE IN (%d,%d,%d)\
			AND     A.DRV_PRODUCT_ID  = \'%c\' \
			AND     A.DRV_SERIAL_NO  = (SELECT MAX(B.DRV_SERIAL_NO ) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
			AND     A.DRV_EXCH_ID = \"%s\" \
			AND     A.DRV_SEGMENT = \'%c\' %s %s",\
			EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,TC_INT_SL_ORDER_TRIG_RESP,PROD_INTRADAY,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sWhereCls,sClause);
	/*				 A.DRV_STATUS = \'C\'\
					 AND     A.DRV_MSG_CODE IN (2073,2074)\
					 AND     A.DRV_PRODUCT_ID = \'I\'\
					 AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
					 AND     A.DRV_EXCH_ID = \"%s\" AND DRV_SEGMENT = \'%c\' %s;",pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sWhereCls);*/

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlDrPendingOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);

		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			//pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);

			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = '1';//Row[19][0];
			pEOrdReq.iStratergyId= STRG_INT_SQR_OFF;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			//			pEOrdReq.cOffMarketFlg= Row[28][0];
			//	                pEOrdReq.cUserType = Row[20][0]
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.iAuctionNum = 0;
			//                strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pEOrdReq.cMarkProFlag= Row[32][0];
			pEOrdReq.fMarkProVal= atof(Row[33]);
			pEOrdReq.cParticipantType= Row[30][0];
			strncpy(pEOrdReq.sSettlor,Row[31],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[34][0];
			pEOrdReq.cEncashFlag= Row[35][0];
			pEOrdReq.iGrpId  = atoi(Row[36]);
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[36]);
			strncpy(pEOrdReq.sPanID,Row[29],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[37],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[38],CHANNEL_LEN);


			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.ReqHeader.iSeqNo :%d:",pEOrdReq.ReqHeader.iSeqNo);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("EXIT [fCnlDrPendingOrd]");
	return TRUE;

}

BOOL fDrvCoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fDrvCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32 iNoOfRec = 0;
	LONG32 i = 0;
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	struct  CO_ORDER_REQUEST   *pCnlEOrd;
	struct  CO_ORDER_REQUEST   pDrOrdReq;

	pCnlEOrd = (struct  CO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause," AND  A.DRV_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.DRV_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);


	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT,\
			DRV_SL_ABSTICK_VALUE ,\
			DRV_PR_ABSTICK_VALUE ,\
			DRV_SL_AT_FLAG ,\
			DRV_PR_ST_FLAG ,\
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID,DRV_REMARKS1,DRV_REMARKS2\
			FROM    DRV_ORDERS A\
			WHERE    A.DRV_STATUS IN (\'%c\',\'%c\') \
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND     A.DRV_LEG_NO =   %d \
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
			AND     A.DRV_EXCH_ID = \"%s\" \
			AND     A.DRV_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sClause);

	/*			A.DRV_STATUS IN (\'C\',\'T\')\
				AND     A.DRV_PRODUCT_ID = \'%c\' \
				AND	A.DRV_LEG_NO = %d \
				AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
				AND     A.DRV_EXCH_ID = \"%s\" AND A.DRV_SEGMENT = \'%c\';",PROD_COVER,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment);*/

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fDrvCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	

	logDebug2("fDrvCoOrdExit : Rows returned from Database = :%d:",iNoOfRec);


	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pDrOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pDrOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pDrOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pDrOrdReq.ReqHeader.iUserId = iUserId;
			pDrOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			//	                pDrOrdReq.ReqHeader.cSource= Row[22][0];
			pDrOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDrOrdReq.ReqHeader.cSegment = Row[25][0];
			pDrOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pDrOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);

			strncpy(pDrOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//	                strncpy(pDrOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDrOrdReq.cProductId= Row[23][0];

			pDrOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pDrOrdReq.iOrderType = atoi(Row[16]);
			//                pDrOrdReq.iOrderValidity = atof(Row[15]);
			pDrOrdReq.iOrderValidity = iOrderVal;
			pDrOrdReq.iTotalQty = atoi(Row[8]);
			pDrOrdReq.iTotalQtyRem = atoi(Row[8]);
			pDrOrdReq.iDiscQty = atoi(Row[10]);
			pDrOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDrOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDrOrdReq.fPrice = atof(Row[13]);
			pDrOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pDrOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pDrOrdReq.fOrderNum = atof(Row[0]);
			pDrOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pDrOrdReq.cHandleInst = Row[19][0];
			pDrOrdReq.cProCli = Row[19][0];
			//                pDrOrdReq.cUserType = Row[20][0];
			pDrOrdReq.CoArray[0].iLegValue = LEG_1 ;

			pDrOrdReq.fSLTikAbsValue = atof(Row[26]);
			pDrOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pDrOrdReq.cSLFlag  =  Row[28][0];
			pDrOrdReq.cPBFlag  = Row[29][0];
			pDrOrdReq.cAvgLtpFlg = 0;
			strncpy(pDrOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pDrOrdReq.iMinFillQty = atoi(Row[18]) ;
			pDrOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pDrOrdReq.iNoOfLeg = 1 ;
			pDrOrdReq.cAvgLtpFlg = 0;
			pDrOrdReq.iStratergyId= STRG_CO_SQR_OFF ;
			pDrOrdReq.fTrailingSLValue = 0.00 ;
			pDrOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDrOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDrOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDrOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDrOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			//			fPrintAll(pDrOrdReq);

			pDrOrdReq.cMarkProFlag= Row[33][0];
			pDrOrdReq.fMarkProVal= atof(Row[34]);
			pDrOrdReq.cParticipantType= Row[31][0];
			strncpy(pDrOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pDrOrdReq.cGTCFlag= Row[35][0];
			pDrOrdReq.cEncashFlag= Row[36][0];
			pDrOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pDrOrdReq.sPanID,Row[30],INT_PAN_LEN);	
			strncpy(pDrOrdReq.sPlatform,Row[38],PLATFORM_LEN);
			strncpy(pDrOrdReq.sChannel,Row[39],CHANNEL_LEN);
			logDebug2("pDrOrdReq.CoArray[0].fTriggerPrice :%f:",pDrOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pDrOrdReq.CoArray[1].fTriggerPrice :%f:",pDrOrdReq.CoArray[1].fTriggerPrice);
			logDebug2("pDrOrdReq.fOrderNum = %f ",pDrOrdReq.fOrderNum);
			logDebug2("pDrOrdReq.sClientId = %s",pDrOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pDrOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fDrvCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fDrvBoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fDrvBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32 		iNoOfRec = 0;
	LONG32 		i = 0;

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	struct  BO_ORDER_REQUEST   *pCnlEOrd;
	struct  BO_ORDER_REQUEST   pDrOrdReq;

	pCnlEOrd = (struct  BO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND  A.DRV_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.DRV_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);

	//Comma was missing after SEGMENT in query @abhishek
	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT,\
			DRV_SL_ABSTICK_VALUE ,\
			DRV_PR_ABSTICK_VALUE ,\
			DRV_SL_AT_FLAG ,\
			DRV_PR_ST_FLAG ,\
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID,DRV_REMARKS1,DRV_REMARKS2\
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS IN (\'%c\',\'%c\') \
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND     A.DRV_LEG_NO =   %d \
			AND 	A.DRV_OMS_ALGO_ORD_NO = -1\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
			AND     A.DRV_EXCH_ID = \"%s\" \
			AND     A.DRV_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sClause);
	//A.DRV_STATUS IN (\'C\',\'T\')\
	AND     A.DRV_PRODUCT_ID = \'%c\' \
		AND     A.DRV_LEG_NO = %d \
		AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
		AND     A.DRV_EXCH_ID = \"%s\" AND A.DRV_SEGMENT = \'%c\' ;",PROD_BRACKET,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fDrvBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	

	logDebug2(" fDrvBoOrdExit :Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{ 
			memset(&pDrOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));	
			strncpy(pDrOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pDrOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pDrOrdReq.ReqHeader.iUserId = iUserId;
			pDrOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			//	                pDrOrdReq.ReqHeader.cSource= Row[22][0];
			pDrOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDrOrdReq.ReqHeader.cSegment = Row[25][0];
			pDrOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pDrOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);



			strncpy(pDrOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pDrOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDrOrdReq.cProductId= Row[23][0];

			pDrOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pDrOrdReq.iOrderType = atoi(Row[16]);
			//                pDrOrdReq.iOrderValidity = atof(Row[15]);
			pDrOrdReq.iOrderValidity = iOrderVal ;
			pDrOrdReq.iTotalQty = atoi(Row[8]);
			pDrOrdReq.iTotalQtyRem = atoi(Row[8]);
			pDrOrdReq.iDiscQty = atoi(Row[10]);
			pDrOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDrOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDrOrdReq.fPrice = atof(Row[13]);
			pDrOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pDrOrdReq.fOrderNum = atof(Row[0]);
			pDrOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pDrOrdReq.cHandleInst = Row[19][0];
			pDrOrdReq.iStratergyId= STRG_BO_SQR_OFF ;
			pDrOrdReq.cProCli = Row[19][0];
			pDrOrdReq.cUserType = ADMIN_TYPE ;
			pDrOrdReq.BoArray[0].iLegValue = LEG_1 ;

			pDrOrdReq.fSLTikAbsValue = atof(Row[26]);
			pDrOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pDrOrdReq.cSLFlag  =  Row[28][0];
			pDrOrdReq.cPBFlag  = Row[29][0];
			pDrOrdReq.cFlag =  '0' ;
			pDrOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			//	                strncpy(pDrOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pDrOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDrOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDrOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDrOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDrOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pDrOrdReq.cMarkProFlag= Row[33][0];
			pDrOrdReq.fMarkProVal= atof(Row[34]);
			pDrOrdReq.cParticipantType= Row[31][0];
			strncpy(pDrOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pDrOrdReq.cGTCFlag= Row[35][0];
			pDrOrdReq.cEncashFlag= Row[36][0];
			pDrOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pDrOrdReq.sPanID,Row[30],INT_PAN_LEN);
			strncpy(pDrOrdReq.sPlatform,Row[38],PLATFORM_LEN);
			strncpy(pDrOrdReq.sChannel,Row[39],CHANNEL_LEN);

			logDebug2("pDrOrdReq.BoArray[0].cBuySellInd :%c:",pDrOrdReq.BoArray[0].cBuySellInd);
			logDebug2("pDrOrdReq.fOrderNum = %f ",pDrOrdReq.fOrderNum);
			logDebug2("pDrOrdReq.sClientId = %s",pDrOrdReq.sClientId);
			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pDrOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fDrvBoOrdExit [EXIT]");
	return TRUE;

}

BOOL fCnlMcxPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlMcxPendingOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 		iNoOfRec = 0;
	LONG32 		i = 0;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND  A.COMM_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.COMM_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}


	logDebug2("sClause :%s",sClause);


	/*In where Clause Message code TC_INT_SL_ORDER_TRIG_RESP is added*/
	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_MKT_TYPE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_USER_TYPE,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE,\
			COMM_SEGMENT , \
			COMM_OMS_ALGO_ORDER_NO ,\
			COMM_STRATEGY_ID ,\
			COMM_ORDER_OFFON, \
			COMM_PAN_NO,\
			COMM_PARTICIPANT_TYPE,\
			COMM_SETTLOR,\
			COM_MKT_PROTECT_FLG,\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG,\
			COMM_GROUP_ID,COMM_REMARKS1,COMM_REMARKS2\
			FROM    COMM_ORDERS A\
			WHERE   A.COMM_STATUS  = \'%c\' \
			AND     A.COMM_MSG_CODE IN (%d,%d,%d)\
			AND     A.COMM_PRODUCT_ID  = \'%c\' \
			AND     A.COMM_SERIAL_NO  = (SELECT MAX(B.COMM_SERIAL_NO ) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO)\
			AND     A.COMM_EXCH_ID = \"%s\" \
			AND	A.COMM_SERIES = %d \
			AND     A.COMM_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,TC_INT_SL_ORDER_TRIG_RESP,PROD_INTRADAY,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.iSeqNo,pCnlEOrd->ReqHeader.cSegment,sClause);
	//A.COMM_ORD_STATUS = \'C\'\
	AND     A.COMM_MSG_CODE IN (2073,2074)\
		AND     A.COMM_PRODUCT_ID = \'I\'\
		AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO)\
		AND     A.COMM_EXCH_ID = \"%s\" ;",pCnlEOrd->ReqHeader.sExcgId);
	logDebug2("sSelQry :%s:",sSelQry);
	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlMcxPendingOrd query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);	
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.iUserId = iUserId; 
			pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[36]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL; 
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST); 
			pEOrdReq.ReqHeader.cSegment = Row[25][0];

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[20][0];
			pEOrdReq.iStratergyId= STRG_INT_SQR_OFF;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pEOrdReq.cMarkProFlag= Row[32][0];
			pEOrdReq.fMarkProVal= atof(Row[33]);
			pEOrdReq.cParticipantType= Row[30][0];
			strncpy(pEOrdReq.sSettlor,Row[31],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[34][0];
			pEOrdReq.cEncashFlag= Row[35][0];
			pEOrdReq.iGrpId = atoi(Row[36]);
			strncpy(pEOrdReq.sPanID,Row[29],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[37],PLATFORM_LEN);
                        strncpy(pEOrdReq.sChannel,Row[38],CHANNEL_LEN);


			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("EXIT fCnlMcxPendingOrd");
	return TRUE;

}

BOOL fSqrOffEqSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffEqSellOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	
	LONG32 		iNoOfRec = 0;
	LONG32 		i = 0;
	LONG32 		j = 0;
	LONG32 		iSliceCount= 0;
	LONG32 		iQty= 0;
	LONG32 		iRemainQty= 0;
	LONG32 		iSliceQty= 0;

	CHAR    sQuery[DOUBLE_MAX_QUERY_SIZE];
        memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/	
		sprintf(sClause,"AND a.CLIENT_ID IN (SELECT USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\');",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause,"AND um.USER_ENTITY_CODE = a.client_id ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  a.CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' \
			AND s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}

	logDebug2("sClause :%s:",sClause);	
/****
	 sprintf(sQuery,"SELECT  SECURITY_ID, MKT_TYPE, EXCH_ID, CLIENT_ID, PROD_ID, (NET_QTY) QTY_ORIGINNAL, (NET_QTY) QTY_REMAINING, 0 USER_CODE, em.ENTITY_PAN, (CASE WHEN SEGMENT = 'E' THEN (CASE WHEN TOT_SELL_VAL > SOVL THEN (CASE WHEN TOT_SELL_QTY > SOQL THEN (CASE WHEN (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) > SOVL THEN CEILING(((SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) / SOVL)) * CEILING(TOT_SELL_QTY / SOQL) ELSE CEILING(TOT_SELL_QTY / SOQL) END) ELSE CEILING((TOT_SELL_VAL / SOVL)) END) ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1 END) END) END) AS SLICE_NUMBER, (CASE WHEN SEGMENT = 'E' THEN (CASE WHEN TOT_SELL_VAL > SOVL THEN (CASE WHEN TOT_SELL_QTY > SOQL THEN (CASE WHEN (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) > SOVL THEN FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) ELSE SOQL END) ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) END) ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY END) END) END) AS SLICE_QTY,em.ENTITY_SUB_TYPE FROM (SELECT  NPT_CLIENT_ID AS CLIENT_ID, NPT_SECURITY_ID AS SECURITY_ID, IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT, NPT_SYMBOL AS SYMB_SECID, IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING, NPT_EXCH_ID AS EXCH_ID, IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE, IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE, NPT_SEGMENT AS SEGMENT, NPT_MKT_TYPE AS MKT_TYPE, NPT_SYMBOL AS SYMBOL, NPT_TOT_BUY_QTY AS TOT_BUY_QTY, NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF, NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY, NPT_TOT_BUY_VAL AS TOT_BUY_VAL, NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF, NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY, NPT_BUY_AVG AS BUY_AVG, NPT_TOT_SELL_QTY AS TOT_SELL_QTY, NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF, NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY, NPT_TOT_SELL_VAL AS TOT_SELL_VAL, NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF, NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY, NPT_SELL_AVG AS SELL_AVG, NPT_NET_QTY AS NET_QTY, NPT_NET_VAL AS NET_VAL, NPT_NET_AVG AS NET_AVG, NPT_GROSS_QTY AS GROSS_QTY, NPT_GROSS_VAL AS GROSS_VAL, NPT_PROD_ID AS PROD_ID, NPT_REALISED_PROFIT AS REALISED_PROFIT, NPT_REF_ID AS REF_ID, NPT_MTM AS MTM, IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES, IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT, MWA.L1_LTP AS LAST_TRADED_PRICE, IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG, IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE, IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER, 0 AS CUSTOM_SYMBOL, 0 AS ISIN, 0 AS EXCH_INSTRUMENT_TYPE, NPT_RPM_CODE AS RPM_CODE, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY AND NPT_SEGMENT IN ('E' , 'D'), NPT_FRZ_QTY, RPM_MAX_ORD_QTY) SOQL, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_LOT AND NPT_SEGMENT IN ('C' , 'M'), NPT_FRZ_QTY, RPM_MAX_LOT) SOLL, RPM_MAX_ORD_VALUE AS SOVL, SM.SM_UPPER_LIMIT AS UPPER_DPR, SM.SM_LOWER_LIMIT AS LOWER_DPR FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT) LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM WHERE NOT (NPT_GROSS_QTY = 0 AND NPT_REALISED_PROFIT = 0) AND NPT.NPT_RPM_CODE = RPM.RPM_CODE AND NPT.NPT_NET_QTY < 0 AND NPT.NPT_PROD_ID = \'%c\' AND NPT.NPT_SEGMENT = \'%c\' AND NPT.NPT_EXCH_ID = \"%s\") AS a ,USER_MASTER um LEFT JOIN ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') where 1=1 %s ; ",PROD_INTRADAY,SEGMENT_EQUITY,pEQSellOrd->ReqHeader.sExcgId,sClause);
****/

	sprintf(sQuery,"SELECT  SECURITY_ID, MKT_TYPE, EXCH_ID, CLIENT_ID, PROD_ID, (NET_QTY) QTY_ORIGINNAL, (NET_QTY) QTY_REMAINING, 0 USER_CODE, em.ENTITY_PAN, (CASE WHEN SEGMENT = 'E' THEN (CASE WHEN TOT_SELL_VAL > SOVL THEN (CASE WHEN TOT_SELL_QTY > SOQL THEN (CASE WHEN (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) > SOVL THEN CEILING(((SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) / SOVL)) * CEILING(TOT_SELL_QTY / SOQL) ELSE CEILING(TOT_SELL_QTY / SOQL) END) ELSE CEILING((TOT_SELL_VAL / SOVL)) END) ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1 END) END) END) AS SLICE_NUMBER, (CASE WHEN SEGMENT = 'E' THEN (CASE WHEN TOT_SELL_VAL > SOVL THEN (CASE WHEN TOT_SELL_QTY > SOQL THEN (CASE WHEN (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) > SOVL THEN FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) ELSE SOQL END) ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', LOWER_DPR, LAST_TRADED_PRICE)) END) ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY END) END) END) AS SLICE_QTY,em.ENTITY_SUB_TYPE FROM (SELECT  NPT_CLIENT_ID AS CLIENT_ID, NPT_SECURITY_ID AS SECURITY_ID, IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT, NPT_SYMBOL AS SYMB_SECID, IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING, NPT_EXCH_ID AS EXCH_ID, IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE, IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE, NPT_SEGMENT AS SEGMENT, NPT_MKT_TYPE AS MKT_TYPE, NPT_SYMBOL AS SYMBOL, NPT_TOT_BUY_QTY AS TOT_BUY_QTY, NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF, NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY, NPT_TOT_BUY_VAL AS TOT_BUY_VAL, NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF, NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY, NPT_BUY_AVG AS BUY_AVG, NPT_TOT_SELL_QTY AS TOT_SELL_QTY, NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF, NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY, NPT_TOT_SELL_VAL AS TOT_SELL_VAL, NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF, NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY, NPT_SELL_AVG AS SELL_AVG, NPT_NET_QTY AS NET_QTY, NPT_NET_VAL AS NET_VAL, NPT_NET_AVG AS NET_AVG, NPT_GROSS_QTY AS GROSS_QTY, NPT_GROSS_VAL AS GROSS_VAL, NPT_PROD_ID AS PROD_ID, NPT_REALISED_PROFIT AS REALISED_PROFIT, NPT_REF_ID AS REF_ID, NPT_MTM AS MTM, IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES, IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT, MWA.L1_LTP AS LAST_TRADED_PRICE, IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG, IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE, IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER, 0 AS CUSTOM_SYMBOL, 0 AS ISIN, 0 AS EXCH_INSTRUMENT_TYPE, NPT_RPM_CODE AS RPM_CODE, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY AND NPT_SEGMENT IN ('E' , 'D'), IF(NPT_SEGMENT='E',NPT_FRZ_QTY-1,NPT_FRZ_QTY), RPM_MAX_ORD_QTY) SOQL, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_LOT AND NPT_SEGMENT IN ('C' , 'M'), IF(NPT_SEGMENT='C',NPT_FRZ_QTY-1,NPT_FRZ_QTY), RPM_MAX_LOT) SOLL, RPM_MAX_ORD_VALUE AS SOVL, SM.SM_UPPER_LIMIT AS UPPER_DPR, SM.SM_LOWER_LIMIT AS LOWER_DPR FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT) LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM WHERE NOT (NPT_GROSS_QTY = 0 AND NPT_REALISED_PROFIT = 0) AND NPT.NPT_RPM_CODE = RPM.RPM_CODE AND NPT.NPT_NET_QTY < 0 AND NPT.NPT_PROD_ID = \'%c\' AND NPT.NPT_SEGMENT = \'%c\' AND NPT.NPT_EXCH_ID = \"%s\") AS a ,USER_MASTER um LEFT JOIN ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') where 1=1 AND um.USER_ENTITY_CODE = a.CLIENT_ID %s ; ",PROD_INTRADAY,SEGMENT_EQUITY,pEQSellOrd->ReqHeader.sExcgId,sClause);

	printf("\n sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("error in fSqrOffEqSellOrd select Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCount1 = iNoOfRec;
	logDebug2("iCount1 :%d:",iCount1);

	logDebug2("fSqrOffEqSellOrd :%d: Rows returned from Database ",iNoOfRec);

	for(i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);

		if(Row = mysql_fetch_row(Res))
		{
			
			iSliceCount= 0;
			iQty= 0;
	 		iRemainQty= 0;
	 		iSliceQty= 0;
			//Slicing the quantity from seelct query..
			iQty = (atoi(Row[5])* -1);
			iSliceQty = atoi(Row[10]);
			logDebug2("iSliceQty :%d:",atoi(Row[10]));
                        if (iSliceQty <= 0)
                        {
                           iSliceQty = 1;
                        }
                        logDebug2("iSliceQty --> :%d:",iSliceQty);
			iSliceCount = iQty/iSliceQty;
			iRemainQty = (iQty - (iSliceCount * iSliceQty));
			logDebug2("iQty :%d:",iQty);
			logDebug2("iSliceQty :%d:",iSliceQty);
			logDebug2("iSliceCount :%d:",iSliceCount);
			logDebug2("iRemainQty :%d:",iRemainQty);
			
			for(j=0;j < iSliceCount ; j++)
			{
				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
				pEOrdReq.ReqHeader.iUserId = iUserId;
				//pEOrdReq.ReqHeader.iSeqNo = iGrpId;
				pEOrdReq.ReqHeader.iSeqNo = 1;
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
				pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;
				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			//	 	strncpy(pEOrdReq.sEntityId,Row[3],ENTITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell = INT_BUY;
				logDebug2("iSliceQty :%d:",iSliceQty);
				pEOrdReq.iTotalQty = atoi(Row[10]);
				pEOrdReq.iTotalQtyRem= atoi(Row[10]);
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0;
				pEOrdReq.fTriggerPrice= 0;
				pEOrdReq.fOrderNum = 0;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				pEOrdReq.cProCli = NNF_CLI;
				pEOrdReq.cUserType = ADMIN_TYPE;
				strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
				strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
					pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
					pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
					pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
					pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else
				{
					logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
				}
				pEOrdReq.iAuctionNum = 0;
				pEOrdReq.cMarkProFlag=NO ; 
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				pEOrdReq.iGrpId=iGrpId;//Ashish
				strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);

				logDebug2("pEOrdReq.sSecurityId  :%s:",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId	:%s:",pEOrdReq.sClientId);

				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
					perror("Error WriteMsgQ");
					mysql_free_result(Res);
					mysql_close(DB_IntSqr);
					exit(ERROR);
				}
			}
			logDebug2("iRemainQty :%d:" , iRemainQty);	
			if(iRemainQty > 0)
			{
				
				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				logDebug2("iRemainQty :%d:" , iRemainQty);	
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
				//pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
				pEOrdReq.ReqHeader.iUserId = iUserId;
				//pEOrdReq.ReqHeader.iSeqNo = iGrpId;
				pEOrdReq.ReqHeader.iSeqNo = 1;
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
				pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;
				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
                                strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                                strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
                                pEOrdReq.cProductId = Row[4][0];
                                pEOrdReq.cBuyOrSell = INT_BUY;
				pEOrdReq.iTotalQty = iRemainQty; 
                                pEOrdReq.iTotalQtyRem = iRemainQty; 
                                pEOrdReq.iOrderType = ORD_TYPE_MKT;
                                pEOrdReq.iOrderValidity = iOrderVal;
                                pEOrdReq.iDiscQty = 0;
                                pEOrdReq.iDiscQtyRem = 0;
                                pEOrdReq.iTotalTradedQty = 0;
                                pEOrdReq.iMinFillQty = 0;
                                pEOrdReq.fPrice= 0;
                                pEOrdReq.fTriggerPrice= 0;
                                pEOrdReq.fOrderNum = 0;
                                pEOrdReq.iSerialNum= 1;
                                pEOrdReq.cHandleInst = '1';
                                pEOrdReq.fAlgoOrderNo = 0;
                                pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
                                pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                                pEOrdReq.cProCli = NNF_CLI;
                                pEOrdReq.cUserType = ADMIN_TYPE;
                                strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
                                strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

                                if(strcmp(Row[1],MKT_TYPE_NL)== 0)
                                {
                                        pEOrdReq.iMktType = NORMAL_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
                                {
                                        pEOrdReq.iMktType = ODDLOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
                                {
                                        pEOrdReq.iMktType = SPOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
                                {
                                        pEOrdReq.iMktType = AUCTION_MARKET;
                                }
                                else
                                {
                                        logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
                                }
				pEOrdReq.iAuctionNum = 0;
                                pEOrdReq.cMarkProFlag=NO ;
                                pEOrdReq.fMarkProVal= 1.00;
                                pEOrdReq.cParticipantType= PARTICI_BROKER;
                                strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
                                pEOrdReq.cGTCFlag= NO;
                                pEOrdReq.cEncashFlag=NO;
                                pEOrdReq.iGrpId=iGrpId;//Ashish
                                strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);

                                logDebug2("pEOrdReq.sSecurityId  :%s:",pEOrdReq.sSecurityId);
                                logDebug2("pEOrdReq.sClientId   :%s:",pEOrdReq.sClientId);

                                if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
                                {
                                        perror("Error WriteMsgQ");
                                        mysql_free_result(Res);
                                        mysql_close(DB_IntSqr);
                                        exit(ERROR);
                                }

			}

		}		
	}
	logTimestamp("EXIT  [fSqrOffEqSellOrd]");
	return TRUE;

}	

BOOL fSqrOffEqBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffEqBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32	iNoOfRec = 0;
        LONG32          i = 0;
        LONG32          j = 0;
	LONG32          iSliceCount= 0;
	LONG32          iQty= 0;
	LONG32          iRemainQty= 0;
	LONG32          iSliceQty= 0;

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	CHAR    sQuery[DOUBLE_MAX_QUERY_SIZE];
        memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);


	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;


	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND a.CLIENT_ID IN (SELECT USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\');",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause,"AND um.USER_ENTITY_CODE = a.client_id");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  a.CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s:",sClause);

/****
	 sprintf(sQuery,"SELECT SECURITY_ID, MKT_TYPE, EXCH_ID, CLIENT_ID, PROD_ID, (NET_QTY) QTY_ORIGINNAL, (NET_QTY) QTY_REMAINING, um.USER_CODE, em.ENTITY_PAN,(CASE WHEN SEGMENT = 'E' AND PROD_ID = 'I' THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * UPPER_DPR) > SOVL THEN CEILING(((SOQL * UPPER_DPR) / SOVL)) * CEILING(TOT_BUY_QTY / SOQL) ELSE CEILING(TOT_BUY_QTY / SOQL) END) ELSE CEILING((TOT_BUY_VAL / SOVL)) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1 END) END) WHEN SEGMENT = 'E' AND PROD_ID <> 'I' THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * LAST_TRADED_PRICE) > SOVL THEN CEILING(((SOQL * LAST_TRADED_PRICE) / SOVL)) * CEILING(TOT_BUY_QTY / SOQL) ELSE CEILING(TOT_BUY_QTY / SOQL) END) ELSE CEILING((TOT_BUY_VAL / SOVL)) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1 END) END) END) AS SLICE_NUMBER, (CASE WHEN SEGMENT = 'E' AND PROD_ID = 'I' THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * UPPER_DPR) > SOVL THEN FLOOR(SOVL / UPPER_DPR) ELSE SOQL END) ELSE FLOOR(SOVL / UPPER_DPR) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY END) END) WHEN SEGMENT = 'E' AND PROD_ID <> 'I'  THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * LAST_TRADED_PRICE) > SOVL THEN FLOOR(SOVL / LAST_TRADED_PRICE) ELSE SOQL END) ELSE FLOOR(SOVL / LAST_TRADED_PRICE) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY END) END) END) AS SLICE_QTY,em.ENTITY_SUB_TYPE FROM (SELECT NPT_CLIENT_ID AS CLIENT_ID, NPT_SECURITY_ID AS SECURITY_ID, IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT, NPT_SYMBOL AS SYMB_SECID, IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING, NPT_EXCH_ID AS EXCH_ID, IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE, IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE, NPT_SEGMENT AS SEGMENT, NPT_MKT_TYPE AS MKT_TYPE, NPT_SYMBOL AS SYMBOL, NPT_TOT_BUY_QTY AS TOT_BUY_QTY, NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF, NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY, NPT_TOT_BUY_VAL AS TOT_BUY_VAL, NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF, NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY, NPT_BUY_AVG AS BUY_AVG, NPT_TOT_SELL_QTY AS TOT_SELL_QTY, NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF, NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY, NPT_TOT_SELL_VAL AS TOT_SELL_VAL, NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF, NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY, NPT_SELL_AVG AS SELL_AVG, NPT_NET_QTY AS NET_QTY, NPT_NET_VAL AS NET_VAL, NPT_NET_AVG AS NET_AVG, NPT_GROSS_QTY AS GROSS_QTY, NPT_GROSS_VAL AS GROSS_VAL, NPT_PROD_ID AS PROD_ID, NPT_REALISED_PROFIT AS REALISED_PROFIT, NPT_REF_ID AS REF_ID, NPT_MTM AS MTM, IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES, IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT, NPT_LTP AS LAST_TRADED_PRICE, IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG, IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE, IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER, NPT_RPM_CODE AS RPM_CODE, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY AND NPT_SEGMENT IN ('E' , 'D'), NPT_FRZ_QTY, RPM_MAX_ORD_QTY) SOQL, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_LOT AND NPT_SEGMENT IN ('C' , 'M'), NPT_FRZ_QTY, RPM_MAX_LOT) SOLL, RPM_MAX_ORD_VALUE AS SOVL, SM.SM_UPPER_LIMIT AS UPPER_DPR, SM.SM_LOWER_LIMIT AS LOWER_DPR FROM NET_POSITION_TABLE NPT LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM WHERE NOT (NPT_GROSS_QTY = 0 AND NPT_REALISED_PROFIT = 0) AND NPT.NPT_RPM_CODE = RPM.RPM_CODE AND NPT.NPT_NET_QTY > 0 AND NPT.NPT_PROD_ID = \'%c\' AND NPT.NPT_SEGMENT = \'%c\' AND NPT.NPT_EXCH_ID = \"%s\") as a,  USER_MASTER um LEFT JOIN ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') where 1=1 %s ;",PROD_INTRADAY,SEGMENT_EQUITY,pEQBuyOrd->ReqHeader.sExcgId,sClause);
****/

	sprintf(sQuery,"SELECT SECURITY_ID, MKT_TYPE, EXCH_ID, CLIENT_ID, PROD_ID, (NET_QTY) QTY_ORIGINNAL, (NET_QTY) QTY_REMAINING, um.USER_CODE, em.ENTITY_PAN,(CASE WHEN SEGMENT = 'E' AND PROD_ID = 'I' THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * UPPER_DPR) > SOVL THEN CEILING(((SOQL * UPPER_DPR) / SOVL)) * CEILING(TOT_BUY_QTY / SOQL) ELSE CEILING(TOT_BUY_QTY / SOQL) END) ELSE CEILING((TOT_BUY_VAL / SOVL)) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1 END) END) WHEN SEGMENT = 'E' AND PROD_ID <> 'I' THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * LAST_TRADED_PRICE) > SOVL THEN CEILING(((SOQL * LAST_TRADED_PRICE) / SOVL)) * CEILING(TOT_BUY_QTY / SOQL) ELSE CEILING(TOT_BUY_QTY / SOQL) END) ELSE CEILING((TOT_BUY_VAL / SOVL)) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1 END) END) END) AS SLICE_NUMBER, (CASE WHEN SEGMENT = 'E' AND PROD_ID = 'I' THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * UPPER_DPR) > SOVL THEN FLOOR(SOVL / UPPER_DPR) ELSE SOQL END) ELSE FLOOR(SOVL / UPPER_DPR) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY END) END) WHEN SEGMENT = 'E' AND PROD_ID <> 'I'  THEN (CASE WHEN TOT_BUY_VAL > SOVL THEN (CASE WHEN TOT_BUY_QTY > SOQL THEN (CASE WHEN (SOQL * LAST_TRADED_PRICE) > SOVL THEN FLOOR(SOVL / LAST_TRADED_PRICE) ELSE SOQL END) ELSE FLOOR(SOVL / LAST_TRADED_PRICE) END) ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY END) END) END) AS SLICE_QTY,em.ENTITY_SUB_TYPE FROM (SELECT NPT_CLIENT_ID AS CLIENT_ID, NPT_SECURITY_ID AS SECURITY_ID, IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT, NPT_SYMBOL AS SYMB_SECID, IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING, NPT_EXCH_ID AS EXCH_ID, IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE, IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE, NPT_SEGMENT AS SEGMENT, NPT_MKT_TYPE AS MKT_TYPE, NPT_SYMBOL AS SYMBOL, NPT_TOT_BUY_QTY AS TOT_BUY_QTY, NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF, NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY, NPT_TOT_BUY_VAL AS TOT_BUY_VAL, NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF, NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY, NPT_BUY_AVG AS BUY_AVG, NPT_TOT_SELL_QTY AS TOT_SELL_QTY, NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF, NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY, NPT_TOT_SELL_VAL AS TOT_SELL_VAL, NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF, NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY, NPT_SELL_AVG AS SELL_AVG, NPT_NET_QTY AS NET_QTY, NPT_NET_VAL AS NET_VAL, NPT_NET_AVG AS NET_AVG, NPT_GROSS_QTY AS GROSS_QTY, NPT_GROSS_VAL AS GROSS_VAL, NPT_PROD_ID AS PROD_ID, NPT_REALISED_PROFIT AS REALISED_PROFIT, NPT_REF_ID AS REF_ID, NPT_MTM AS MTM, IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES, IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT, NPT_LTP AS LAST_TRADED_PRICE, IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG, IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE, IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER, NPT_RPM_CODE AS RPM_CODE, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY AND NPT_SEGMENT IN ('E' , 'D'), IF(NPT_SEGMENT='E',NPT_FRZ_QTY-1,NPT_FRZ_QTY), RPM_MAX_ORD_QTY) SOQL, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM_MAX_LOT AND NPT_SEGMENT IN ('C' , 'M'), IF(NPT_SEGMENT='C',NPT_FRZ_QTY-1,NPT_FRZ_QTY), RPM_MAX_LOT) SOLL, RPM_MAX_ORD_VALUE AS SOVL, SM.SM_UPPER_LIMIT AS UPPER_DPR, SM.SM_LOWER_LIMIT AS LOWER_DPR FROM NET_POSITION_TABLE NPT LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM WHERE NOT (NPT_GROSS_QTY = 0 AND NPT_REALISED_PROFIT = 0) AND NPT.NPT_RPM_CODE = RPM.RPM_CODE AND NPT.NPT_NET_QTY > 0 AND NPT.NPT_PROD_ID = \'%c\' AND NPT.NPT_SEGMENT = \'%c\' AND NPT.NPT_EXCH_ID = \"%s\") as a,  USER_MASTER um LEFT JOIN ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') where 1=1 AND um.USER_ENTITY_CODE = a.CLIENT_ID %s ;",PROD_INTRADAY,SEGMENT_EQUITY,pEQBuyOrd->ReqHeader.sExcgId,sClause);
	
	printf("\n sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffEqBuyOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);

	iNoOfRec= mysql_num_rows(Res);
	iCount2 = iNoOfRec;
	logDebug2("iCount2 :%d:",iCount2);
	logDebug2("fSqrOffEqBuyOrd :%d: Rows returned from Database ",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);	
		if (Row = mysql_fetch_row(Res))
		{
			
		        iSliceCount= 0;
			iQty= 0;
		        iRemainQty= 0;
		        iSliceQty= 0;
			//Slicing the quantity from seelct query..
	
			iQty = atoi(Row[5]);	
			iSliceQty = atoi(Row[10]);
			logDebug2("iSliceQty :%d:",iSliceQty);
			if (iSliceQty <= 0)
    			{
        		   iSliceQty = 1;
    			}
			logDebug2("iSliceQty --> :%d:",iSliceQty);
			iSliceCount = iQty/iSliceQty;

                        iRemainQty = (iQty - (iSliceCount* iSliceQty));
			logDebug2("iQty :%d:",iQty);
                        logDebug2("iSliceCount :%d:",iSliceCount);
                        logDebug2("iRemainQty :%d:",iRemainQty);

			for(j=0;j<iSliceCount ;j++)
			{
				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
				pEOrdReq.ReqHeader.iUserId = iUserId; 
				//pEOrdReq.ReqHeader.iSeqNo = iGrpId; 
				pEOrdReq.ReqHeader.iSeqNo = 1;
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN ;
				pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;

				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell = INT_SELL;
				pEOrdReq.iTotalQty = atoi(Row[10]);
				pEOrdReq.iTotalQtyRem= atoi(Row[10]);
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0;
				pEOrdReq.fTriggerPrice= 0;
				pEOrdReq.fOrderNum = 0;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				pEOrdReq.cProCli = NNF_CLI;
				pEOrdReq.cUserType = ADMIN_TYPE;
				strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
				strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
					pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
					pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
					pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
					pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else
				{
					logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
				}
				pEOrdReq.iAuctionNum = 0;
				pEOrdReq.cMarkProFlag=NO ;
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				pEOrdReq.iGrpId=iGrpId;
				strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);
	
				logDebug2("pEOrdReq.sSecurityId :%s:",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId   :%s:",pEOrdReq.sClientId);
	

				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
					perror("Error WriteMsgQ");
					mysql_free_result(Res);
					mysql_close(DB_IntSqr);
					exit(ERROR);
				}
			}
			
			if(iRemainQty >0)
			{
				logDebug2("iRemainQty :%d:",iRemainQty);	
				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
				pEOrdReq.ReqHeader.iUserId = iUserId; 
				//pEOrdReq.ReqHeader.iSeqNo = iGrpId; 
				pEOrdReq.ReqHeader.iSeqNo = 1;
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN ;
				pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;

				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell = INT_SELL;
				pEOrdReq.iTotalQty = iRemainQty;
				logDebug2("pEOrdReq.iTotalQty :%d:",pEOrdReq.iTotalQty);	
				pEOrdReq.iTotalQtyRem= iRemainQty;
				logDebug2("pEOrdReq.iTotalQtyRem :%d:",pEOrdReq.iTotalQtyRem);	
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0;
				pEOrdReq.fTriggerPrice= 0;
				pEOrdReq.fOrderNum = 0;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				pEOrdReq.cProCli = NNF_CLI;
				pEOrdReq.cUserType = ADMIN_TYPE;
				strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
				strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
					pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
					pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
					pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
					pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else
				{
					logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
				}
				pEOrdReq.iAuctionNum = 0;
				pEOrdReq.cMarkProFlag=NO ;
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				pEOrdReq.iGrpId=iGrpId;
				strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);
	
				logDebug2("pEOrdReq.sSecurityId :%s:",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId   :%s:",pEOrdReq.sClientId);
	

				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
					perror("Error WriteMsgQ");
					mysql_free_result(Res);
					mysql_close(DB_IntSqr);
					exit(ERROR);
				}
			}	
		}

	}
	logTimestamp("ENTRY [fSqrOffEqBuyOrd]");
	return TRUE;

}

BOOL fSqrOffDrSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffDrSellOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	LONG32	iNoOfRec = 0;	
	LONG32	i= 0;	
	LONG32          j = 0;
        LONG32          iSliceCount= 0;
        LONG32          iQty= 0;
        LONG32          iRemainQty= 0;
        LONG32          iSliceQty= 0;

	//CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sQuery[DOUBLE_MAX_QUERY_SIZE];
        memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);

	CHAR	sWhereCls[MAX_QUERY_SIZE];

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);
	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	if(pEQSellOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order Sell SqrOff");
		//sprintf(sWhereCls," AND SUBSTRING_INDEX(EXCH_SYMB, '-', 1) not in ('EURUSD','GBPUSD','USDJPY')");
		sprintf(sWhereCls," AND CROSS_CUR_FLAG = \'%c\'",NO);

		logDebug2("sWhereCls :%s:",sWhereCls);
	}
	else
	{
		sprintf(sWhereCls ," ");
	}



	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{	
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND a.CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause,"AND um.USER_ENTITY_CODE = a.client_id ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  a.CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s:",sClause);
/****
	 sprintf(sQuery,"SELECT SECURITY_ID,     MKT_TYPE,     EXCH_ID,     CLIENT_ID,     PROD_ID,     (NET_QTY) QTY_ORIGINNAL,     (NET_QTY) QTY_REMAINING,     0 USER_CODE,     SEGMENT,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  CEILING(TOT_SELL_QTY / FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)))   ELSE CEILING(TOT_SELL_QTY / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)     END),0) AS SLICE_NUMBER,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',    UPPER_DPR,    LAST_TRADED_PRICE))   ELSE SOQL    END)     ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE)   ELSE SOQL-mod(SOQL,LOT_SIZE)   END)     ELSE FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL-mod(SOQL,LOT_SIZE) ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI))) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI))) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)     END),0) AS SLICE_QTY,     em.ENTITY_PAN,     em.ENTITY_SUB_TYPE,     CLIENT_ID FROM     (SELECT     NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING,   NPT_EXCH_ID AS EXCH_ID,   IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE,   IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE,   NPT_SEGMENT AS SEGMENT,   NPT_MKT_TYPE AS MKT_TYPE,   NPT_SYMBOL AS SYMBOL,   NPT_TOT_BUY_QTY AS TOT_BUY_QTY,   NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF,   NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY,   NPT_TOT_BUY_VAL AS TOT_BUY_VAL,   NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF,   NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF,   NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF,   NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL AS NET_VAL,   NPT_NET_AVG AS NET_AVG,   NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_PROD_ID AS PROD_ID,   NPT_REALISED_PROFIT AS REALISED_PROFIT,   NPT_REF_ID AS REF_ID,   NPT_MTM AS MTM,   IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES,   IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT,   MWA.L1_LTP AS LAST_TRADED_PRICE,   IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG,   IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE,   IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER,   NPT_RPM_CODE AS RPM_CODE,  IF(NPT_FRZ_QTY > 0  AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY, NPT_FRZ_QTY, RPM_MAX_ORD_QTY) SOQL,   RPM_MAX_ORD_VALUE AS SOVL,   SM.SM_UPPER_LIMIT AS UPPER_DPR,   SM.SM_LOWER_LIMIT AS LOWER_DPR,   SM.SM_LOT_SIZE AS LOT_SIZE,   NPT_MCX_MULTIPLIER AS MCX_MULTI,   NPT_CURRENCY_MULTIPLIER AS CURR_MULTI     FROM    NET_POSITION_TABLE NPT     LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID    AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID    AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT)     LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE    AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE    AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM     WHERE    NOT (NPT_GROSS_QTY = 0   AND NPT_REALISED_PROFIT = 0)   AND NPT.NPT_RPM_CODE = RPM.RPM_CODE   AND NPT.NPT_NET_QTY < 0   AND NPT.NPT_PROD_ID = \'%c\'   AND NPT.NPT_SEGMENT = \'%c\'   AND NPT.NPT_EXCH_ID = \'%s\') AS a,     USER_MASTER um    LEFT JOIN     ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE)    LEFT JOIN     SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') WHERE     1 = 1 AND um.USER_ENTITY_CODE = a.CLIENT_ID    %s  %s;",PROD_INTRADAY,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->ReqHeader.sExcgId,sClause,sWhereCls);	
****/
	//logDebug2("sQuery :%s:",sQuery);

	sprintf(sQuery,"SELECT SECURITY_ID,     MKT_TYPE,     EXCH_ID,     CLIENT_ID,     PROD_ID,     (NET_QTY) QTY_ORIGINNAL,     (NET_QTY) QTY_REMAINING,     0 USER_CODE,     SEGMENT,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  CEILING(TOT_SELL_QTY / FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)))   ELSE CEILING(TOT_SELL_QTY / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)     END),0) AS SLICE_NUMBER,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',    UPPER_DPR,    LAST_TRADED_PRICE))   ELSE SOQL    END)     ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE)   ELSE SOQL-mod(SOQL,LOT_SIZE)   END)     ELSE FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL-mod(SOQL,LOT_SIZE) ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI))) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI))) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)     END),0) AS SLICE_QTY,     em.ENTITY_PAN,     em.ENTITY_SUB_TYPE,     CLIENT_ID FROM     (SELECT     NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING,   NPT_EXCH_ID AS EXCH_ID,   IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE,   IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE,   NPT_SEGMENT AS SEGMENT,   NPT_MKT_TYPE AS MKT_TYPE,   NPT_SYMBOL AS SYMBOL,   NPT_TOT_BUY_QTY AS TOT_BUY_QTY,   NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF,   NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY,   NPT_TOT_BUY_VAL AS TOT_BUY_VAL,   NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF,   NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF,   NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF,   NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL AS NET_VAL,   NPT_NET_AVG AS NET_AVG,   NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_PROD_ID AS PROD_ID,   NPT_REALISED_PROFIT AS REALISED_PROFIT,   NPT_REF_ID AS REF_ID,   NPT_MTM AS MTM,   IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES,   IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT,   MWA.L1_LTP AS LAST_TRADED_PRICE,   IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG,   IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE,   IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER,   NPT_RPM_CODE AS RPM_CODE,  IF(NPT_FRZ_QTY > 0  AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY, IF(NPT_SEGMENT='C',NPT_FRZ_QTY-1,NPT_FRZ_QTY), RPM_MAX_ORD_QTY) SOQL,   RPM_MAX_ORD_VALUE AS SOVL,   SM.SM_UPPER_LIMIT AS UPPER_DPR,   SM.SM_LOWER_LIMIT AS LOWER_DPR,   SM.SM_LOT_SIZE AS LOT_SIZE,   NPT_MCX_MULTIPLIER AS MCX_MULTI,   NPT_CURRENCY_MULTIPLIER AS CURR_MULTI     FROM    NET_POSITION_TABLE NPT     LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID    AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID    AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT)     LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE    AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE    AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM     WHERE    NOT (NPT_GROSS_QTY = 0   AND NPT_REALISED_PROFIT = 0)   AND NPT.NPT_RPM_CODE = RPM.RPM_CODE   AND NPT.NPT_NET_QTY < 0   AND NPT.NPT_PROD_ID = \'%c\'   AND NPT.NPT_SEGMENT = \'%c\'   AND NPT.NPT_EXCH_ID = \'%s\') AS a,     USER_MASTER um    LEFT JOIN     ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE)    LEFT JOIN     SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') WHERE     1 = 1 AND um.USER_ENTITY_CODE = a.CLIENT_ID    %s  %s;",PROD_INTRADAY,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->ReqHeader.sExcgId,sClause,sWhereCls,sWhereCls);

	printf("sQuery :%s:",sQuery);
	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffDrSellOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	iCount1 = iNoOfRec;
	logDebug2("iCount1 :%d:",iCount1);
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			iSliceCount= 0;
                        iQty= 0;
                        iRemainQty= 0;
                        iSliceQty= 0;
                        iQty = (atoi(Row[5])* -1);
                        iSliceQty = atoi(Row[10]);
			if (iSliceQty <= 0)
    			{
        		    iSliceQty = 1;
    			}
 			logDebug2("iSliceQty --> :%d:",iSliceQty);

                        iSliceCount = iQty/iSliceQty;
                        iRemainQty = (iQty - (iSliceCount* iSliceQty));
                        logDebug2("iQty :%d:",iQty);
                        logDebug2("iSliceCount :%d:",iSliceCount);
                        logDebug2("iRemainQty :%d:",iRemainQty);
			

			for(j=0;j<iSliceCount ;j++)
                        {

				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
				pEOrdReq.ReqHeader.iUserId = iUserId;
				pEOrdReq.ReqHeader.iSeqNo = 1;
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
				pEOrdReq.ReqHeader.cSegment= Row[8][0];

				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell = INT_BUY;
				pEOrdReq.iTotalQty = iSliceQty;
				pEOrdReq.iTotalQtyRem= iSliceQty;
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0.00;
				pEOrdReq.fTriggerPrice= 0.00;
				pEOrdReq.fOrderNum = 0.00;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				//pEOrdReq.cProCli = NNF_CLI;
				if(Row[12][0] == '1')
                                {
                                        pEOrdReq.cProCli = NNF_PRO;
                                }
                                else if(Row[12][0] == '7')
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                else
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }

				pEOrdReq.cUserType = ADMIN_TYPE;
				strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
				pEOrdReq.iAuctionNum = 0;
				strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);	
				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
					pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
					pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
					pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
					pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else
				{
					logDebug2("INVALID Mkt Type :%s: ",Row[1]);
				}

				pEOrdReq.cMarkProFlag=NO ;
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				pEOrdReq.iGrpId=iGrpId;
				strncpy(pEOrdReq.sPanID,Row[9],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);


				logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
				logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
					perror("Error WriteMsgQ");
					mysql_free_result(Res);
					mysql_close(DB_IntSqr);
					exit(ERROR);
				}
			}
			
			if(iRemainQty >0)
                        {
                                logDebug2("iRemainQty :%d:",iRemainQty);
                                memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
                                pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
                                pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
                                strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
				pEOrdReq.ReqHeader.iSeqNo = 1;

                                pEOrdReq.ReqHeader.iUserId = iUserId;
                                pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
                                pEOrdReq.ReqHeader.cSegment= Row[8][0];

                                strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
                                strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                                strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
                                pEOrdReq.cProductId = Row[4][0];
                                pEOrdReq.cBuyOrSell = INT_BUY;
                                pEOrdReq.iTotalQty = iRemainQty;
                                pEOrdReq.iTotalQtyRem= iRemainQty;
                                pEOrdReq.iOrderType = ORD_TYPE_MKT;
                                pEOrdReq.iOrderValidity = iOrderVal;
                                pEOrdReq.iDiscQty = 0;
                                pEOrdReq.iDiscQtyRem = 0;
                                pEOrdReq.iTotalTradedQty = 0;
                                pEOrdReq.iMinFillQty = 0;
                                pEOrdReq.fPrice= 0.00;
                                pEOrdReq.fTriggerPrice= 0.00;
                                pEOrdReq.fOrderNum = 0.00;
                                pEOrdReq.iSerialNum= 1;
                                pEOrdReq.cHandleInst = '1';
                                pEOrdReq.fAlgoOrderNo = 0;
                                pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
                                pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				if(Row[12][0] == '1')
                                {
                                        pEOrdReq.cProCli = NNF_PRO;
                                }
                                else if(Row[12][0] == '7')
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                else
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                pEOrdReq.cUserType = ADMIN_TYPE;
                                strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
                                pEOrdReq.iAuctionNum = 0;
                                strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
                                if(strcmp(Row[1],MKT_TYPE_NL)== 0)
                                {
                                        pEOrdReq.iMktType = NORMAL_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
                                {
                                        pEOrdReq.iMktType = ODDLOT_MARKET;
                                }
                                                                else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
                                {
                                        pEOrdReq.iMktType = SPOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
                                {
                                        pEOrdReq.iMktType = AUCTION_MARKET;
                                }
                                else
                                {
                                        logDebug2("INVALID Mkt Type :%s: ",Row[1]);
                                }
				pEOrdReq.cMarkProFlag=NO ;
                                pEOrdReq.fMarkProVal= 0;
                                pEOrdReq.cParticipantType= PARTICI_BROKER;
                                strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
                                pEOrdReq.cGTCFlag= NO;
                                pEOrdReq.cEncashFlag=NO;
                                strncpy(pEOrdReq.sPanID,Row[11],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);


                                logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
                                logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
                                logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


                                if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
                                {
                                        perror("Error WriteMsgQ");
                                        mysql_free_result(Res);
                                        mysql_close(DB_IntSqr);
                                        exit(ERROR);
                                }

			}
		}
	}
	mysql_free_result(Res);
	logTimestamp("EXIT  [fSqrOffDrSellOrd]");
	return TRUE;

}	

BOOL fSqrOffDrBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffDrBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


//	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sWhereCls[MAX_QUERY_SIZE];
	CHAR	sQuery[DOUBLE_MAX_QUERY_SIZE];
	LONG32		iNoOfRec = 0;
	LONG32		i= 0;
	LONG32          j = 0;
        LONG32          iSliceCount= 0;
        LONG32          iQty= 0;
        LONG32          iRemainQty= 0;
        LONG32          iSliceQty= 0;


	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;
	memset(sWhereCls,'\0',MAX_QUERY_SIZE);
	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);
	memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	if(pEQBuyOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order Sell SqrOff");
		//sprintf(sWhereCls," AND SUBSTRING_INDEX(EXCH_SYMB, '-', 1) not in ('EURUSD','GBPUSD','USDJPY')");
		sprintf(sWhereCls," AND CROSS_CUR_FLAG = \'%c\'",NO);

		logDebug2("sWhereCls :%s:",sWhereCls);
	}
	else
	{
		sprintf(sWhereCls ," ");
	}

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND a.CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause,"AND um.USER_ENTITY_CODE = a.client_id ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  a.CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}

	logDebug2("sClause :%s:",sClause);

	sprintf(sQuery,"SELECT SECURITY_ID,     MKT_TYPE,     EXCH_ID,     CLIENT_ID,     PROD_ID,     (NET_QTY) QTY_ORIGINNAL,     (NET_QTY) QTY_REMAINING,     0 USER_CODE,     SEGMENT,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  CEILING(TOT_BUY_QTY / FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)))   ELSE CEILING(TOT_BUY_QTY / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  (TOT_BUY_QTY / FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))),     LOT_SIZE))    ELSE CEILING(TOT_BUY_QTY  / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  (TOT_BUY_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_BUY_QTY  / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  (TOT_BUY_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_BUY_QTY  / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)     END),0) AS SLICE_NUMBER,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',    UPPER_DPR,    LAST_TRADED_PRICE))   ELSE SOQL    END)     ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE)   ELSE SOQL-mod(SOQL,LOT_SIZE)    END)     ELSE FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL-mod(SOQL,LOT_SIZE) ELSE TOT_BUY_QTY  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI))) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI))) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)     END),0) AS SLICE_QTY,     em.ENTITY_PAN,     em.ENTITY_SUB_TYPE FROM     (SELECT     NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING,   NPT_EXCH_ID AS EXCH_ID,   IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE,   IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE,   NPT_SEGMENT AS SEGMENT,   NPT_MKT_TYPE AS MKT_TYPE,   NPT_SYMBOL AS SYMBOL,   NPT_TOT_BUY_QTY AS TOT_BUY_QTY,   NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF,   NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY,   NPT_TOT_BUY_VAL AS TOT_BUY_VAL,   NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF,   NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF,   NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF,   NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL AS NET_VAL,   NPT_NET_AVG AS NET_AVG,   NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_PROD_ID AS PROD_ID,   NPT_REALISED_PROFIT AS REALISED_PROFIT,   NPT_REF_ID AS REF_ID,   NPT_MTM AS MTM,   IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES,   IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT,   MWA.L1_LTP AS LAST_TRADED_PRICE,   IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG,   IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE,   IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER,   NPT_RPM_CODE AS RPM_CODE,   IF(NPT_FRZ_QTY > 0  AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY, IF(NPT_SEGMENT='C',NPT_FRZ_QTY-1,NPT_FRZ_QTY), RPM_MAX_ORD_QTY) SOQL,   RPM_MAX_ORD_VALUE AS SOVL,   SM.SM_UPPER_LIMIT AS UPPER_DPR,   SM.SM_LOWER_LIMIT AS LOWER_DPR,   SM.SM_LOT_SIZE AS LOT_SIZE,   NPT_MCX_MULTIPLIER AS MCX_MULTI,   NPT_CURRENCY_MULTIPLIER AS CURR_MULTI     FROM    NET_POSITION_TABLE NPT     LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID    AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID    AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT)     LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE    AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE    AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM     WHERE    NOT (NPT_GROSS_QTY = 0   AND NPT_REALISED_PROFIT = 0)   AND NPT.NPT_RPM_CODE = RPM.RPM_CODE   AND NPT.NPT_NET_QTY > 0   AND NPT.NPT_PROD_ID = \'%c\'   AND NPT.NPT_SEGMENT = \'%c\'   AND NPT.NPT_EXCH_ID = \'%s\') AS a,     USER_MASTER um    LEFT JOIN     ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE)    LEFT JOIN     SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') WHERE     1 = 1 AND um.USER_ENTITY_CODE = a.CLIENT_ID     %s %s ;",    PROD_INTRADAY,pEQBuyOrd->ReqHeader.cSegment,pEQBuyOrd->ReqHeader.sExcgId,sClause,sWhereCls);
	
	printf("sQuery :%s:",sQuery);
	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffDrBuyOrd Query...");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCount2 = iNoOfRec;
	logDebug2("iCount2 :%d:",iCount2);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		
		if(Row = mysql_fetch_row(Res))
		{
			iSliceCount= 0;
                        iQty= 0;
                        iRemainQty= 0;
                        iSliceQty= 0;
                        iQty = atoi(Row[5]);
                        iSliceQty = atoi(Row[10]);
			logDebug2("iSliceQty :%d:",iSliceQty);
			if (iSliceQty <= 0)
		        {
        		   iSliceQty = 1;
    			}	
 			logDebug2("iSliceQty --> :%d:",iSliceQty);

                        iSliceCount = iQty/iSliceQty;
                        iRemainQty = (iQty - (iSliceCount* iSliceQty));
                        logDebug2("iQty :%d:",iQty);
                        logDebug2("iSliceCount :%d:",iSliceCount);
                        logDebug2("iRemainQty :%d:",iRemainQty);
			
			for(j=0;j<iSliceCount ;j++)
                        {


				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
				//	pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
				pEOrdReq.ReqHeader.iUserId = iUserId; 
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
				pEOrdReq.ReqHeader.cSegment= Row[8][0];
				pEOrdReq.ReqHeader.iSeqNo = 1;

				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell = INT_SELL;
				pEOrdReq.iTotalQty = iSliceQty;
				pEOrdReq.iTotalQtyRem= iSliceQty;
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0.00;
				pEOrdReq.fTriggerPrice= 0.00;
				pEOrdReq.fOrderNum = 0.00;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				//pEOrdReq.cProCli = NNF_CLI;
				if(Row[12][0] == '1')
                                {
                                        pEOrdReq.cProCli = NNF_PRO;
                                }
                                else if(Row[12][0] == '7')
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                else
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }

				pEOrdReq.cUserType = ADMIN_TYPE;
				pEOrdReq.iAuctionNum = 0;
				strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
				strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
					pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
					pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
					pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
					pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else
				{
					logDebug2("INVALID Mkt Type :%s: ",Row[1]);
				}

				pEOrdReq.cMarkProFlag=NO ;
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				pEOrdReq.iGrpId=iGrpId;
				strncpy(pEOrdReq.sPanID,Row[9],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);


				logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
				logDebug2("pEOrdReq.sSecurityId   :%s:",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);

				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
					perror("Error WriteMsgQ");
					mysql_free_result(Res);
					mysql_close(DB_IntSqr);
					exit(ERROR);
				}
			}
			
			if(iRemainQty >0)
                        {
                                logDebug2("iRemainQty :%d:",iRemainQty);
                                memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
                                pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
                                pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
                                strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);

                                pEOrdReq.ReqHeader.iUserId = iUserId;
                                pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
                                pEOrdReq.ReqHeader.cSegment= Row[8][0];
				pEOrdReq.ReqHeader.iSeqNo = 1;

                                strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
                                strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                                strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
                                pEOrdReq.cProductId = Row[4][0];
                                pEOrdReq.cBuyOrSell = INT_SELL;
                                pEOrdReq.iTotalQty = iRemainQty;
                                pEOrdReq.iTotalQtyRem= iRemainQty;
                                pEOrdReq.iOrderType = ORD_TYPE_MKT;
                                pEOrdReq.iOrderValidity = iOrderVal;
                                pEOrdReq.iDiscQty = 0;
                                pEOrdReq.iDiscQtyRem = 0;
                                pEOrdReq.iTotalTradedQty = 0;
                                pEOrdReq.iMinFillQty = 0;
                                pEOrdReq.fPrice= 0.00;
                                pEOrdReq.fTriggerPrice= 0.00;
                                pEOrdReq.fOrderNum = 0.00;
                                pEOrdReq.iSerialNum= 1;
                                pEOrdReq.cHandleInst = '1';
                                pEOrdReq.fAlgoOrderNo = 0;
                                pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
                                pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                                if(Row[12][0] == '1')
                                {
                                        pEOrdReq.cProCli = NNF_PRO;
                                }
                                else if(Row[12][0] == '7')
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                else
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                pEOrdReq.cUserType = ADMIN_TYPE;
                                strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
                                pEOrdReq.iAuctionNum = 0;
                                strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
                                if(strcmp(Row[1],MKT_TYPE_NL)== 0)
                                {
                                        pEOrdReq.iMktType = NORMAL_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
                                {
                                        pEOrdReq.iMktType = ODDLOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
                                {
                                        pEOrdReq.iMktType = SPOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
                                {
                                        pEOrdReq.iMktType = AUCTION_MARKET;
                                }
                                else
                                {
                                        logDebug2("INVALID Mkt Type :%s: ",Row[1]);
                                }
				pEOrdReq.cMarkProFlag=NO ;
                                pEOrdReq.fMarkProVal= 0;
                                pEOrdReq.cParticipantType= PARTICI_BROKER;
                                strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
                                pEOrdReq.cGTCFlag= NO;
                                pEOrdReq.cEncashFlag=NO;
                                strncpy(pEOrdReq.sPanID,Row[11],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);


                                logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
                                logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
                                logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


                                if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
                                {
                                        perror("Error WriteMsgQ");
                                        mysql_free_result(Res);
                                        mysql_close(DB_IntSqr);
                                        exit(ERROR);
                                }
                        }


		}
	}
	mysql_free_result(Res);
	logTimestamp("EXIT [fSqrOffDrBuyOrd]");
	return TRUE;

}


BOOL fSqrOffMcxSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffMcxSellOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	LONG32	iNoOfRec = 0;
	LONG32	i = 0;
	LONG32          j = 0;
        LONG32          iSliceCount= 0;
        LONG32          iQty= 0;
        LONG32          iRemainQty= 0;
        LONG32          iSliceQty= 0;
 	
	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	//CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR    sQuery[DOUBLE_MAX_QUERY_SIZE];
        memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);
	
	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;
	logDebug2("pEQBuyOrd->ReqHeader.iSeqNo :%d:",pEQSellOrd->ReqHeader.iSeqNo);
	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND a.CLIENT_ID IN (SELECT USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\');",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause,"AND um.USER_ENTITY_CODE = a.client_id");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  a.CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s:",sClause);

	/****
		sprintf(sQuery,"SELECT 	SECURITY_ID,\
	MKT_TYPE,\
		EXCH_ID ,\
		CLIENT_ID,\
		PROD_ID,\
		-(NET_QTY) QTY_ORIGINNAL,\
		-(NET_QTY) QTY_REMAINING,\
		um.USER_CODE,\
		SEGMNT  \
		FROM 	VIEW_NET_POSITION a, USER_MASTER um\
		WHERE \
		NOT (gross_qty = 0 AND realised_profit = 0)\
		AND a.net_qty < 0\
		AND a.prod_id='I'\
		and a.segmnt = 'M'\
		and um.USER_ENTITY_CODE = a.client_id\
		AND a.exch_id= ltrim(rtrim(\'%s\'));",pEQSellOrd->ReqHeader.sExcgId);	
		sprintf(sQuery,"SELECT  SECURITY_ID,\
				MKT_TYPE,\
				EXCH_ID ,\
				CLIENT_ID,\
				PROD_ID,\
				-(NET_QTY) QTY_ORIGINNAL,\
				-(NET_QTY) QTY_REMAINING,\
				um.USER_CODE,\
				em.ENTITY_PAN\
				FROM    VIEW_NET_POSITION a, USER_MASTER um,ENTITY_MASTER em\
				WHERE 	NOT (gross_qty = 0 AND realised_profit = 0)\
				AND a.net_qty < 0\
				AND a.prod_id= \'%c\'\
				AND a.segmnt =  \'%c\' \
				AND a.exch_id= ltrim(rtrim(\'%s\')) \
				AND um.USER_ENTITY_CODE = a.client_id\
				AND um.USER_ENTITY_CODE = em.ENTITY_CODE\
				AND a.GROUP_SERIES=%d  %s;"\
					,PROD_INTRADAY,SEGMENT_COMMODITY,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.iSeqNo,sClause);
	
	***/
	 sprintf(sQuery,"SELECT SECURITY_ID,     MKT_TYPE,     EXCH_ID,     CLIENT_ID,     PROD_ID,     (NET_QTY) QTY_ORIGINNAL,     (NET_QTY) QTY_REMAINING,     0 USER_CODE,     SEGMENT,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  CEILING(TOT_SELL_QTY / FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)))   ELSE CEILING(TOT_SELL_QTY / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  (TOT_SELL_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_SELL_QTY  / SOQL)    END)     ELSE CEILING((TOT_SELL_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN CEILING(TOT_SELL_QTY / SOQL) ELSE 1  END)   END)     END),0) AS SLICE_NUMBER,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',    UPPER_DPR,    LAST_TRADED_PRICE))   ELSE SOQL    END)     ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE)   ELSE SOQL    END)     ELSE FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI))) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_SELL_VAL > SOVL  THEN (CASE     WHEN    TOT_SELL_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI))) END)  ELSE (CASE WHEN TOT_SELL_QTY > SOQL THEN SOQL ELSE TOT_SELL_QTY  END)   END)     END),0) AS SLICE_QTY,     em.ENTITY_PAN,     em.ENTITY_SUB_TYPE,     CLIENT_ID FROM     (SELECT     NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING,   NPT_EXCH_ID AS EXCH_ID,   IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE,   IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE,   NPT_SEGMENT AS SEGMENT,   NPT_MKT_TYPE AS MKT_TYPE,   NPT_SYMBOL AS SYMBOL,   NPT_TOT_BUY_QTY AS TOT_BUY_QTY,   NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF,   NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY,   NPT_TOT_BUY_VAL AS TOT_BUY_VAL,   NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF,   NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF,   NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF,   NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL AS NET_VAL,   NPT_NET_AVG AS NET_AVG,   NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_PROD_ID AS PROD_ID,   NPT_REALISED_PROFIT AS REALISED_PROFIT,   NPT_REF_ID AS REF_ID,   NPT_MTM AS MTM,   IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES,   IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT,   MWA.L1_LTP AS LAST_TRADED_PRICE,   IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG,   IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE,   IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER,   NPT_RPM_CODE AS RPM_CODE,  IF(NPT_FRZ_QTY > 0  AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY, NPT_FRZ_QTY, RPM_MAX_ORD_QTY) SOQL,   RPM_MAX_ORD_VALUE AS SOVL,   SM.SM_UPPER_LIMIT AS UPPER_DPR,   SM.SM_LOWER_LIMIT AS LOWER_DPR,   SM.SM_LOT_SIZE AS LOT_SIZE,   NPT_MCX_MULTIPLIER AS MCX_MULTI,   NPT_CURRENCY_MULTIPLIER AS CURR_MULTI     FROM    NET_POSITION_TABLE NPT     LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID    AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID    AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT)     LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE    AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE    AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM     WHERE    NOT (NPT_GROSS_QTY = 0   AND NPT_REALISED_PROFIT = 0)   AND NPT.NPT_RPM_CODE = RPM.RPM_CODE   AND NPT.NPT_NET_QTY < 0   AND NPT.NPT_PROD_ID = \'%c\'   AND NPT.NPT_SEGMENT = \'%c\'   AND NPT.NPT_EXCH_ID = \'%s\' AND  NPT.NPT_GROUP_SERIES = %d) AS a,     USER_MASTER um    LEFT JOIN     ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE)    LEFT JOIN     SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') WHERE     1 = 1 AND um.USER_ENTITY_CODE  = a.CLIENT_ID    %s ;",PROD_INTRADAY,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.iSeqNo,sClause);



	
	//logDebug2("sQuery :%s:",sQuery);
	printf("\n sQuery :%s:",sQuery);
	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffMcxSellOrd query.");
		return FALSE;
	}
	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCount1 = iNoOfRec;
	logDebug3("iCount1 :%d:",iCount1);

	logDebug3("Rows returned from Database = :%d:",iNoOfRec);
	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			iSliceCount= 0;
                        iQty= 0;
                        iRemainQty= 0;
                        iSliceQty= 0;
			logDebug2("iSliceQty :%d:",iSliceQty);
			if(iSliceQty <=0)
			{
				iSliceQty = 1;
			}	
			logDebug2("iSliceQty --> :%d:",iSliceQty);
                        iQty = atoi(Row[5]);
                        iSliceQty = atoi(Row[10]);
			if(iSliceQty <=0)
			{
		           iSliceQty = 1;
			   logDebug2("iSliceQty --> :%d:",iSliceQty);	
			}
                        iSliceCount = iQty/iSliceQty;
                        iRemainQty = (iQty - (iSliceCount* iSliceQty));
                        logDebug2("iQty :%d:",iQty);
                        logDebug2("iSliceCount :%d:",iSliceCount);
                        logDebug2("iRemainQty :%d:",iRemainQty);

                        for(j=0;j<iSliceCount ;j++)
                        {

				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
				//pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
				pEOrdReq.ReqHeader.iUserId = iUserId;
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
				pEOrdReq.ReqHeader.cSegment= SEGMENT_COMMODITY; 

				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell = INT_BUY;
				pEOrdReq.iTotalQty = atoi(Row[5]);
				pEOrdReq.iTotalQtyRem= atoi(Row[6]);
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0;
				pEOrdReq.fTriggerPrice= 0;
				pEOrdReq.fOrderNum = 0;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				pEOrdReq.cProCli = NNF_CLI;
				pEOrdReq.cUserType = ADMIN_TYPE;
				strncpy(pEOrdReq.sRemarks,"great",REMARKS_LEN);

				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
				pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
				pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
				pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
				pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else	
				{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
				}
				pEOrdReq.iAuctionNum = 0;

				pEOrdReq.cMarkProFlag=NO ;
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);

				logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);

				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
				}

		}
		if(iRemainQty >0)
                        {
                                logDebug2("iRemainQty :%d:",iRemainQty);
                                memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
                                pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
                                pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
                                strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);

                                pEOrdReq.ReqHeader.iUserId = iUserId;
                                pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
                                pEOrdReq.ReqHeader.cSegment= Row[8][0];

                                strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
                                strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                                strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
                                pEOrdReq.cProductId = Row[4][0];
                                pEOrdReq.cBuyOrSell = INT_BUY;
                                pEOrdReq.iTotalQty = iRemainQty;
                                pEOrdReq.iTotalQtyRem= iRemainQty;
                                pEOrdReq.iOrderType = ORD_TYPE_MKT;
                                pEOrdReq.iOrderValidity = iOrderVal;
                                pEOrdReq.iDiscQty = 0;
                                pEOrdReq.iDiscQtyRem = 0;
                                pEOrdReq.iTotalTradedQty = 0;
                                pEOrdReq.iMinFillQty = 0;
                                pEOrdReq.fPrice= 0.00;
                                pEOrdReq.fTriggerPrice= 0.00;
                                pEOrdReq.fOrderNum = 0.00;
                                pEOrdReq.iSerialNum= 1;
                                pEOrdReq.cHandleInst = '1';
                                pEOrdReq.fAlgoOrderNo = 0;
				//pEOrdReq.iStratergyId = STRAT_INT_SQROFF;
				 pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
                                pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                                if(Row[12][0] == '1')
                                {
                                        pEOrdReq.cProCli = NNF_PRO;
                                }
                                else if(Row[12][0] == '7')
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                else
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                pEOrdReq.cUserType = ADMIN_TYPE;
                                strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
                                pEOrdReq.iAuctionNum = 0;
                                strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
                                if(strcmp(Row[1],MKT_TYPE_NL)== 0)
                                {
                                        pEOrdReq.iMktType = NORMAL_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
                                {
                                        pEOrdReq.iMktType = ODDLOT_MARKET;
                                }
                                                                else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
                                {
                                        pEOrdReq.iMktType = SPOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
                                {
                                        pEOrdReq.iMktType = AUCTION_MARKET;
                                }
                                else
                                {
                                        logDebug2("INVALID Mkt Type :%s: ",Row[1]);
                                }

				pEOrdReq.cMarkProFlag=NO ;
                                pEOrdReq.fMarkProVal= 0;
                                pEOrdReq.cParticipantType= PARTICI_BROKER;
                                strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
                                pEOrdReq.cGTCFlag= NO;
                                pEOrdReq.cEncashFlag=NO;
                                strncpy(pEOrdReq.sPanID,Row[11],INT_PAN_LEN);


                                logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
                                logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
                                logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


                                if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
                                {
                                        perror("Error WriteMsgQ");
                                        mysql_free_result(Res);
                                        mysql_close(DB_IntSqr);
                                        exit(ERROR);
                                }
                        }
                }

	}
	logTimestamp("EXIT [fSqrOffMcxSellOrd]");
	return TRUE;

}	

BOOL fSqrOffMcxBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffMcxBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32		iNoOfRec = 0;
	LONG32		i= 0;

	LONG32          j = 0;
        LONG32          iSliceCount= 0;
        LONG32          iQty= 0;
        LONG32          iRemainQty= 0;
        LONG32          iSliceQty= 0;

	//CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sQuery[DOUBLE_MAX_QUERY_SIZE];
        memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	logDebug2("pEQBuyOrd->ReqHeader.iSeqNo :%d:",pEQBuyOrd->ReqHeader.iSeqNo);
	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{	
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND a.CLIENT_ID IN (SELECT USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <>  \'%c\');",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause,"AND um.USER_ENTITY_CODE = a.client_id");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/	
		sprintf(sClause,"AND  a.CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s:",sClause);

	/**sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			em.ENTITY_PAN\
			FROM    VIEW_NET_POSITION a, USER_MASTER um,ENTITY_MASTER em\
			WHERE NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty > 0\
			AND a.prod_id= \'%c\'\
			AND a.segmnt =  \'%c\' \
			AND a.exch_id= ltrim(rtrim(\'%s\')) \
			AND um.USER_ENTITY_CODE = a.client_id \
			AND um.USER_ENTITY_CODE = em.ENTITY_CODE\
			AND a.GROUP_SERIES =%d %s;"\
			,PROD_INTRADAY,SEGMENT_COMMODITY,pEQBuyOrd->ReqHeader.sExcgId,pEQBuyOrd->ReqHeader.iSeqNo,sClause);


	//        sprintf(sQuery,"SELECT  SECURITY_ID,\
	MKT_TYPE,\
		EXCH_ID ,\
		CLIENT_ID,\
		PROD_ID,\
		(NET_QTY) QTY_ORIGINNAL,\
		(NET_QTY) QTY_REMAINING,\
		um.USER_CODE,\
		SEGMNT  \
		FROM    VIEW_NET_POSITION a, USER_MASTER um\
		WHERE \
		NOT (gross_qty = 0 AND realised_profit = 0)\
		AND a.net_qty > 0\
		AND a.prod_id='I'\
		and a.segmnt = 'M'\
		and um.USER_ENTITY_CODE = a.client_id\
		AND a.exch_id= ltrim(rtrim(\'%s\'));",pEQBuyOrd->ReqHeader.sExcgId);
	**/	
	
        sprintf(sQuery,"SELECT SECURITY_ID,     MKT_TYPE,     EXCH_ID,     CLIENT_ID,     PROD_ID,     (NET_QTY) QTY_ORIGINNAL,     (NET_QTY) QTY_REMAINING,     0 USER_CODE,     SEGMENT,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  CEILING(TOT_BUY_QTY / FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)))   ELSE CEILING(TOT_BUY_QTY / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  (TOT_BUY_QTY / FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE))),     LOT_SIZE))    ELSE CEILING(TOT_BUY_QTY  / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  (TOT_BUY_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*CURR_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_BUY_QTY  / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  (TOT_BUY_QTY / FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))) - MOD(FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)*MCX_MULTI))),     LOT_SIZE))    ELSE CEILING(TOT_BUY_QTY  / SOQL)    END)     ELSE CEILING((TOT_BUY_VAL / SOVL)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN CEILING(TOT_BUY_QTY / SOQL) ELSE 1  END)   END)     END),0) AS SLICE_NUMBER,     IFNULL((CASE    WHEN   SEGMENT = 'E'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D', UPPER_DPR, LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',    UPPER_DPR,    LAST_TRADED_PRICE))   ELSE SOQL    END)     ELSE FLOOR(SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',  UPPER_DPR,  LAST_TRADED_PRICE)) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)    WHEN   SEGMENT = 'D'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)) > SOVL   THEN  FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE)   ELSE SOQL    END)     ELSE FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))) - MOD(FLOOR((SOVL / IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE))),LOT_SIZE) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)    WHEN   SEGMENT = 'C'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*CURR_MULTI))) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)    WHEN   SEGMENT = 'M'    THEN   (CASE  WHEN TOT_BUY_VAL > SOVL  THEN (CASE     WHEN    TOT_BUY_QTY > SOQL     THEN    (CASE   WHEN  (SOQL * IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI) > SOVL   THEN  FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI)))   ELSE SOQL    END)     ELSE FLOOR((SOVL / (IF(IFNULL(SP.PARAM_VALUE, 'L') = 'D',UPPER_DPR,LAST_TRADED_PRICE)*MCX_MULTI))) END)  ELSE (CASE WHEN TOT_BUY_QTY > SOQL THEN SOQL ELSE TOT_BUY_QTY  END)   END)     END),0) AS SLICE_QTY,     em.ENTITY_PAN,     em.ENTITY_SUB_TYPE FROM     (SELECT     NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING,   NPT_EXCH_ID AS EXCH_ID,   IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE,   IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE,   NPT_SEGMENT AS SEGMENT,   NPT_MKT_TYPE AS MKT_TYPE,   NPT_SYMBOL AS SYMBOL,   NPT_TOT_BUY_QTY AS TOT_BUY_QTY,   NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF,   NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY,   NPT_TOT_BUY_VAL AS TOT_BUY_VAL,   NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF,   NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF,   NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF,   NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL AS NET_VAL,   NPT_NET_AVG AS NET_AVG,   NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_PROD_ID AS PROD_ID,   NPT_REALISED_PROFIT AS REALISED_PROFIT,   NPT_REF_ID AS REF_ID,   NPT_MTM AS MTM,   IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES,   IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT,   MWA.L1_LTP AS LAST_TRADED_PRICE,   IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG,   IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE,   IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER,    NPT_RPM_CODE AS RPM_CODE,   IF(NPT_FRZ_QTY > 0  AND NPT_FRZ_QTY < RPM_MAX_ORD_QTY, NPT_FRZ_QTY, RPM_MAX_ORD_QTY) SOQL,   RPM_MAX_ORD_VALUE AS SOVL,   SM.SM_UPPER_LIMIT AS UPPER_DPR,   SM.SM_LOWER_LIMIT AS LOWER_DPR,   SM.SM_LOT_SIZE AS LOT_SIZE,   NPT_MCX_MULTIPLIER AS MCX_MULTI,   NPT_CURRENCY_MULTIPLIER AS CURR_MULTI     FROM    NET_POSITION_TABLE NPT     LEFT JOIN L1_WATCH_ACTIVE MWA ON (MWA.L1_SCRIP_CODE = NPT.NPT_SECURITY_ID    AND MWA.L1_EXCHANGE = NPT.NPT_EXCH_ID    AND MWA.L1_SEGMENT = NPT.NPT_SEGMENT)     LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE    AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE    AND NPT.NPT_SEGMENT = SM.SM_SEGMENT), RMS_RISK_PROFILE_MAST RPM     WHERE    NOT (NPT_GROSS_QTY = 0   AND NPT_REALISED_PROFIT = 0)   AND NPT.NPT_RPM_CODE = RPM.RPM_CODE   AND NPT.NPT_NET_QTY > 0   AND NPT.NPT_PROD_ID = \'%c\'   AND NPT.NPT_SEGMENT = \'%c\'   AND NPT.NPT_EXCH_ID = \'%s\' AND  NPT.NPT_GROUP_SERIES = %d) AS a,     USER_MASTER um    LEFT JOIN     ENTITY_MASTER em ON (em.ENTITY_CODE = um.USER_ENTITY_CODE)    LEFT JOIN     SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'INT_SLICING_TYPE') WHERE     1 = 1 AND um.USER_ENTITY_CODE = a.CLIENT_ID     %s ;",    PROD_INTRADAY,pEQBuyOrd->ReqHeader.cSegment,pEQBuyOrd->ReqHeader.sExcgId,pEQBuyOrd->ReqHeader.iSeqNo,sClause);
	


	//logDebug2("sQuery :%s:",sQuery);
	printf("\n sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffMcxBuyOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCount2 = iNoOfRec;
	logDebug2("iCount2 :%d:",iCount2);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			iSliceCount= 0;
                        iQty= 0;
                        iRemainQty= 0;
                        iSliceQty= 0;
                        iQty = atoi(Row[5]);
                        iSliceQty = atoi(Row[10]);
			if(iSliceQty <=0)
			{
			   iSliceQty =1;
			}
			logDebug2("iSliceQty --> :%d:",iSliceQty);
                        iSliceCount = iQty/iSliceQty;
                        iRemainQty = (iQty - (iSliceCount* iSliceQty));
                        logDebug2("iQty :%d:",iQty);
                        logDebug2("iSliceCount :%d:",iSliceCount);
                        logDebug2("iRemainQty :%d:",iRemainQty);

                        for(j=0;j<iSliceCount ;j++)
                        {

				memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
				pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
				pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
				strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
				pEOrdReq.ReqHeader.iUserId = iUserId;
				//pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
				pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
				pEOrdReq.ReqHeader.cSegment= SEGMENT_COMMODITY;

				strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
				strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
				strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
				pEOrdReq.cProductId = Row[4][0];
				pEOrdReq.cBuyOrSell =INT_SELL ;
				pEOrdReq.iTotalQty = atoi(Row[5]);
				pEOrdReq.iTotalQtyRem= atoi(Row[6]);
				pEOrdReq.iOrderType = ORD_TYPE_MKT;
				pEOrdReq.iOrderValidity = iOrderVal;
				pEOrdReq.iDiscQty = 0;
				pEOrdReq.iDiscQtyRem = 0;
				pEOrdReq.iTotalTradedQty = 0;
				pEOrdReq.iMinFillQty = 0;
				pEOrdReq.fPrice= 0;
				pEOrdReq.fTriggerPrice= 0;
				pEOrdReq.fOrderNum = 0;
				pEOrdReq.iSerialNum= 1;
				pEOrdReq.cHandleInst = '1';
				pEOrdReq.fAlgoOrderNo = 0;
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
				pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
				pEOrdReq.cProCli = NNF_CLI;
				pEOrdReq.cUserType = ADMIN_TYPE;
				strncpy(pEOrdReq.sRemarks,"great",REMARKS_LEN);

				if(strcmp(Row[1],MKT_TYPE_NL)== 0)
				{
					pEOrdReq.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
				{
					pEOrdReq.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
				{
					pEOrdReq.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
				{
					pEOrdReq.iMktType = AUCTION_MARKET;
				}
				else
				{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
				}
				pEOrdReq.iAuctionNum = 0;

				pEOrdReq.cMarkProFlag=NO ;
				pEOrdReq.fMarkProVal= 1.00;
				pEOrdReq.cParticipantType= PARTICI_BROKER;
				strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
				pEOrdReq.cGTCFlag= NO;
				pEOrdReq.cEncashFlag=NO;
				strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
				strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
				strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);
				logDebug2("pEOrdReq.sSecurityId  :%s:",pEOrdReq.sSecurityId);
				logDebug2("pEOrdReq.sClientId   :%s:",pEOrdReq.sClientId);	

				if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
				{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
		 if(iRemainQty >0)
                        {
                                logDebug2("iRemainQty :%d:",iRemainQty);
                                memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
                                pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
                                pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
                                strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);

                                pEOrdReq.ReqHeader.iUserId = iUserId;
                                pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
                                pEOrdReq.ReqHeader.cSegment= Row[8][0];

                                strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
                                strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                                strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
                                pEOrdReq.cProductId = Row[4][0];
                                pEOrdReq.cBuyOrSell = INT_SELL;
                                pEOrdReq.iTotalQty = iRemainQty;
                                pEOrdReq.iTotalQtyRem= iRemainQty;
                                pEOrdReq.iOrderType = ORD_TYPE_MKT;
                                pEOrdReq.iOrderValidity = iOrderVal;
                                pEOrdReq.iDiscQty = 0;
                                pEOrdReq.iDiscQtyRem = 0;
                                pEOrdReq.iTotalTradedQty = 0;
                                pEOrdReq.iMinFillQty = 0;
                                pEOrdReq.fPrice= 0.00;
                                pEOrdReq.fTriggerPrice= 0.00;
                                pEOrdReq.fOrderNum = 0.00;
                                pEOrdReq.iSerialNum= 1;
                                pEOrdReq.cHandleInst = '1';
                                pEOrdReq.fAlgoOrderNo = 0;
				//pEOrdReq.iStratergyId = STRAT_INT_SQROFF
				pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
                                pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                                if(Row[12][0] == '1')
                                {
                                        pEOrdReq.cProCli = NNF_PRO;
                                }
                                else if(Row[12][0] == '7')
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                else
                                {
                                        pEOrdReq.cProCli = NNF_CLI;
                                }
                                pEOrdReq.cUserType = ADMIN_TYPE;
                                strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
                                pEOrdReq.iAuctionNum = 0;
                                strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
                                if(strcmp(Row[1],MKT_TYPE_NL)== 0)
                                {
                                        pEOrdReq.iMktType = NORMAL_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
                                {
                                        pEOrdReq.iMktType = ODDLOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
                                {
                                        pEOrdReq.iMktType = SPOT_MARKET;
                                }
                                else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
                                {
                                        pEOrdReq.iMktType = AUCTION_MARKET;
                                }
                                else
                                {
                                        logDebug2("INVALID Mkt Type :%s: ",Row[1]);
                                }
				pEOrdReq.cMarkProFlag=NO ;
                                pEOrdReq.fMarkProVal= 0;
                                pEOrdReq.cParticipantType= PARTICI_BROKER;
                                strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
                                pEOrdReq.cGTCFlag= NO;
                                pEOrdReq.cEncashFlag=NO;
                                strncpy(pEOrdReq.sPanID,Row[11],INT_PAN_LEN);


                                logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
                                logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
                                logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


                                if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
                                {
                                        perror("Error WriteMsgQ");
                                        mysql_free_result(Res);
                                        mysql_close(DB_IntSqr);
                                        exit(ERROR);
                                }
                        }
                }

	}
	logTimestamp("EXIT [fSqrOffMcxBuyOrd]");
	return TRUE;

}

BOOL fBlockCoverOrd(CHAR *RcvMsg)
{	


	logTimestamp("fBlockCoverOrd [ENTRY]");
	struct  CO_ORDER_REQUEST   *pOrdBlck;
	CHAR            sReqExcgId[EXCHANGE_LEN];
	CHAR 		cMode  = '0' ;
	CHAR		cReqSegment = '0';
	LONG32          iSeqNo = 0 ;
	LONG32          iResult = 0 ;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR      	*sFnUpdt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pOrdBlck= (struct CO_ORDER_REQUEST *)RcvMsg;

	memset(sReqExcgId,'\0',EXCHANGE_LEN);
	strncpy(sReqExcgId,pOrdBlck->ReqHeader.sExcgId,EXCHANGE_LEN);
	cMode = '\0';
	cReqSegment = '\0';

	cReqSegment = pOrdBlck->ReqHeader.cSegment;
	logDebug3("In fBlockCoverOrd  sReqExcgId.arr :%s: sReqExcgId.len :%d: cReqSegment:%c:",sReqExcgId,strlen(sReqExcgId),cReqSegment);
	if(cReqSegment == 'M')
	{
		iSeqNo = pOrdBlck->ReqHeader.iSeqNo;
	}
	else
	{
		iSeqNo = 1;
	}

	if(cReqSegment == 'M')
	{
		sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N' ,RPM_INTRA_SQOFF_STATUS = 'Y'\
				WHERE   PRODUCT_NAME = 'CO' \
				AND SEGMENT = \'%c\' \
				AND EXCH_ID = ltrim(rtrim(\"%s\")) \
				AND TRADING_GROUP = %d \
				AND PRODUCT_CODE = \'%c\';",cReqSegment,sReqExcgId,iSeqNo,PROD_COVER);

	}
	else
	{	sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N' ,RPM_INTRA_SQOFF_STATUS = 'Y'\
			WHERE   PRODUCT_NAME = 'CO' \
			AND SEGMENT = \'%c\' \
			AND EXCH_ID = ltrim(rtrim(\"%s\")) \
			AND PRODUCT_CODE = \'%c\';",cReqSegment,sReqExcgId,PROD_COVER);
	}
	logDebug1("sUpdSel :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fBlockCover  Update Query.");
		return FALSE;
	}

	//        sleep(60);
	return TRUE ;
	logTimestamp("fBlockCoverOrd [EXIT]");
}

BOOL fBlockBoOrd(CHAR *RcvMsg)
{
	logTimestamp("fBlockBoOrd [ENTRY]");
	struct  BO_ORDER_REQUEST   *pOrdBlck;


	CHAR            sReqExcgId[EXCHANGE_LEN];
	CHAR            cMode ;
	CHAR            cReqSegment ;
	LONG32          iSeqNo = 0 ;
	LONG32          iResult = 0 ;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sFnUpdt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pOrdBlck= (struct BO_ORDER_REQUEST *)RcvMsg;

	memset(sReqExcgId,'\0',EXCHANGE_LEN);
	strncpy(sReqExcgId,pOrdBlck->ReqHeader.sExcgId,EXCHANGE_LEN);
	cMode = '\0';
	cReqSegment = '\0';

	cReqSegment = pOrdBlck->ReqHeader.cSegment;
	logDebug3("In fBlockBoOrd   sReqExcgId.arr :%s: sReqExcgId.len :%d: cReqSegment:%c:",sReqExcgId,strlen(sReqExcgId),cReqSegment);
	if(cReqSegment == 'M')
	{
		iSeqNo = pOrdBlck->ReqHeader.iSeqNo;
	}
	else
	{
		iSeqNo = 1;
	}

	if(cReqSegment == 'M')
	{
		sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N',RPM_INTRA_SQOFF_STATUS = 'Y' \
				WHERE   PRODUCT_NAME = 'BO' \
				AND SEGMENT = \'%c\' \
				AND EXCH_ID = ltrim(rtrim(\"%s\")) \
				AND TRADING_GROUP = %d \
				AND PRODUCT_CODE = \'%c\';",cReqSegment,sReqExcgId,iSeqNo,PROD_BRACKET);

	}
	else
	{
		sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N',RPM_INTRA_SQOFF_STATUS = 'Y' \
				WHERE   PRODUCT_NAME = 'BO' \
				AND SEGMENT = \'%c\' \
				AND EXCH_ID = ltrim(rtrim(\"%s\")) \
				AND PRODUCT_CODE = \'%c\';",cReqSegment,sReqExcgId,PROD_BRACKET);
	}
	logDebug1("sUpdSel :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in Block Bracket Orders  Update Query.");
		return FALSE;
	}

	sleep(60);
	return TRUE ;
	logTimestamp("fBlockBoOrd [EXIT]");
}







BOOL fBlockIntraday(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fBlockIntraday]");
	struct  ORDER_REQUEST	*pOrdBlck;

	CHAR            cReqSegment,cMode;
	CHAR         	sReqExcgId[EXCHANGE_LEN];
	LONG32          iSeqNo;
	LONG32          iResult;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR		*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		*sFnUpdt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
	CHAR		sCrsCurrColumn [15];

	pOrdBlck= (struct ORDER_REQUEST *)RcvMsg;

	memset(sReqExcgId,'\0',EXCHANGE_LEN);
	memset(sCrsCurrColumn,'\0',15);
	strncpy(sReqExcgId,pOrdBlck->ReqHeader.sExcgId,EXCHANGE_LEN);
	cMode = '\0';

	cReqSegment = pOrdBlck->ReqHeader.cSegment;
	logDebug3("In Block Intraday sReqExcgId.arr :%s: sReqExcgId.len :%d: cReqSegment:%c: iMsgCode :%d:",sReqExcgId,strlen(sReqExcgId),cReqSegment,pOrdBlck->ReqHeader.iMsgCode);
	if(cReqSegment == 'M')
	{
		iSeqNo = pOrdBlck->ReqHeader.iSeqNo;
		printf("iSeqNo :%d:",iSeqNo);
	}
	else
	{
		iSeqNo = 1;
	}

	if(pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ)
	{
		logInfo("This is Cross Currency Product Block");
		strncpy(sCrsCurrColumn,"CROSS_CUR_FLAG",15);
	}
	else
	{
		logInfo("This is Non - Cross Currency Product Block");
		strncpy(sCrsCurrColumn,"PRODUCT_STATUS",15);
	}

	if(cReqSegment == 'M')
	{
		sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET %s = 'N',RPM_INTRA_SQOFF_STATUS = 'Y' \
				WHERE   PRODUCT_NAME = 'INTRADAY' \
				AND SEGMENT = \'%c\' \
				AND EXCH_ID = ltrim(rtrim(\"%s\")) \
				AND TRADING_GROUP = %d \
				AND PRODUCT_CODE = 'I';",sCrsCurrColumn,cReqSegment,sReqExcgId,iSeqNo);

	}
	else
	{
		sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET %s = 'N' ,RPM_INTRA_SQOFF_STATUS = 'Y'\
				WHERE   PRODUCT_NAME = 'INTRADAY' \
				AND SEGMENT = \'%c\' \
				AND EXCH_ID = ltrim(rtrim(\"%s\")) \
				AND PRODUCT_CODE = 'I';",sCrsCurrColumn,cReqSegment,sReqExcgId);
	}
	logDebug1("sUpdSel :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fBlockIntraday Update Query.");
		return FALSE;	
	}


	sleep(10);


	logTimestamp(" EXIT [fBlockIntraday]");
	return TRUE ;
}/** End of fBlockIntraday **/


BOOL    fUpdtOffMktBP(CHAR *RcvMsg)
{
	logTimestamp("fUpdtOffMktBP [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sFnQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32          iSeqNo, iStatus;
	iSeqNo = 1;
	CHAR sBatchName [20];
	CHAR sremarks [25];
	memset(sBatchName,'\0',20);
	memset (sremarks,'\0',25);	
	struct  ORDER_REQUEST   *pOrdBlck;
	pOrdBlck= (struct ORDER_REQUEST *)RcvMsg;
	strncpy(sremarks,pOrdBlck->sRemarks,REMARKS_LEN);
	logDebug2("MSGCODE IS:%d",TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ);
	logDebug2("TC_INT_PUMPOFFLINE_REQ :%d:",TC_INT_PUMPOFFLINE_REQ);
	if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_REQ)
	{
		strncpy(sBatchName,INTRADAY_SQUREOFF,20);
	}
	else if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ)
	{
		strncpy(sBatchName,INTRADAY_CROSS_CUR_SQROFF,20);
	}
	else if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_PUMPOFFLINE_REQ)
	{
		strncpy(sBatchName,OFFMARKET_PUMPER,20);
	}

	else if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_COVER_ORD_REQ)
	{
		strncpy(sBatchName,COVER_ORD_SQUREOFF,20);
	}
	else if(pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_BRACKET_ORD_REQ)
	{
		strncpy(sBatchName,BRACKET_ORD_SQUREOFF,20);
	}
	else
	{
		logDebug2("Wrong Msg Code");
	}
	logDebug2(".......[%s]........",pOrdBlck->sRemarks);
	strncpy(sremarks,"Auto_Sucess",REMARKS_LEN);
	logDebug2("pOrdBlck->ReqHeader.iSeqNo = %d",pOrdBlck->ReqHeader.iSeqNo);
	sprintf(sFnQuery,"SELECT BP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\'%s\',%d,\'%s',%d,%d,%d);",pOrdBlck->ReqHeader.sExcgId,pOrdBlck->ReqHeader.cSegment,sBatchName,pOrdBlck->ReqHeader.iSeqNo,sremarks,iGrpId,iCanCount,iPumpCount);
	logDebug2("sFnQuery :%s:",sFnQuery);

	if(mysql_query(DB_IntSqr,sFnQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fUpdtOffMktBP UPDATE QUERY.");
		return FALSE;
	}
	else
	{
		Res = mysql_store_result(DB_IntSqr);
		Row = mysql_fetch_row(Res);
		logDebug2("[%s] [%d]",Row[0],atoi(Row[0]));
		iStatus = atoi(Row[0]);
		logDebug2("BP_UPDATE Response :%d:",iStatus);
		mysql_commit(DB_IntSqr);
		logTimestamp("fUpdtOffMktBP [EXIT]");
		return TRUE;
	}

}

BOOL	fUpdtOffMktBPSIP(CHAR *RcvMsg, CHAR sBatchName[20])
{
	logTimestamp ("Entry fUpdtOffMktBPSIP");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32      	iSeqNo, iStatus;
	iSeqNo = 1;
	CHAR sRemarks [25];
	memset (sRemarks,'\0',25);
	struct  ORDER_REQUEST   *pOrdBlck;
	pOrdBlck= (struct ORDER_REQUEST *)RcvMsg;

	logDebug2("sBatchName = %s",sBatchName);
	//strncpy(sRemarks,pOrdBlck->sRemarks,REMARKS_LEN);
	strncpy(sRemarks,"Success",REMARKS_LEN);
	logDebug2("pOrdBlck->sRemarks = %s",pOrdBlck->sRemarks);

	logDebug2("pOrdBlck->ReqHeader.iSeqNo = %d",pOrdBlck->ReqHeader.iSeqNo);
	logDebug2(".......[%d]........",iSeqNo);
	
	sprintf(sQuery,"SELECT BP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\'%s\',%d,\'%s\',%d,%d,%d);",pOrdBlck->ReqHeader.sExcgId,pOrdBlck->ReqHeader.cSegment,sBatchName,iSeqNo,sRemarks,iGrpId,iCanCount,iPumpCount);
	
	logDebug2("sFnQuery :%s:",sQuery);
	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fUpdtOffMktBPSIP UPDATE QUERY.");
		return FALSE;
	}
	else
	{

		Res = mysql_store_result(DB_IntSqr);
		Row = mysql_fetch_row(Res);
		logDebug2("[%s] [%d]",Row[0],atoi(Row[0]));
		iStatus = atoi(Row[0]);
		logDebug2("SIP_UPDATE Response :%d:",iStatus);
		mysql_commit(DB_IntSqr);

	}
	logTimestamp ("Entry fUpdtOffMktBPSIP");
	return TRUE;


}

BOOL    fDisableOffMkt(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{
	logTimestamp("ENTRY fDisableOffMkt");
	CHAR    *sUpDtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//INT16   iMktNo =1;

	sprintf(sUpDtQry,"UPDATE BATCH_PROCESS b \
			SET b.BP_OFF_MKT_STATUS = \'N\' \
			WHERE   b.BP_EXCH_ID = LTRIM(RTRIM(\"%s\"))\
			AND     b.BP_SEGMENT = \'%c\' \
			AND     b.BP_MKT_TYPE_NO = %d \
			AND     b.BP_BATCH_NAME = \'OFFMKT_PUMP\';",pOrdReq->sExcgId,pOrdReq->cSegment,pOrdReq->iSeqNo);

	logDebug3("sUpDtQry :%s:",sUpDtQry);

	if(mysql_query(DB_IntSqr,sUpDtQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in Update Batch Process Query.");
		return FALSE;
	}
	else
	{
		mysql_commit(DB_IntSqr);
		logTimestamp("EXIT  fDisableOffMkt");
		return TRUE;
	}
}

BOOL    fEnableOffMkt(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{

	logTimestamp("ENTRY fEnableOffMkt ");
	CHAR    *sUpDtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	//INT16   iMktNo =1;
	logDebug2("Enabling Off market");
	sprintf(sUpDtQry,"UPDATE BATCH_PROCESS  \
			SET BP_OFF_MKT_STATUS = \'Y\' \
			WHERE   BP_EXCH_ID = LTRIM(RTRIM(\"%s\"))\
			AND     BP_SEGMENT = \'%c\' \
			AND     BP_MKT_TYPE_NO = %d \
			AND     BP_BATCH_NAME = \'OFFMKT_PUMP\';",pOrdReq->sExcgId,pOrdReq->cSegment,pOrdReq->iSeqNo);

	logDebug3("sUpDtQry :%s:",sUpDtQry);

	if(mysql_query(DB_IntSqr,sUpDtQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in Enable Off Mkt Query.");
		return FALSE;
	}
	else
	{
		mysql_commit(DB_IntSqr);
		logTimestamp("EXIT  fEnableOffMkt");
		return TRUE;
	}
}

BOOL fEquPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	logTimestamp("fEquPumpOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32 	iNoOfRec = 0;
	LONG32 	i= 0;

	//CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sSelQry[MAX_QUERY_SIZE];
	CHAR	sClause[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
        memset(sClause,'\0',MAX_QUERY_SIZE);
	CHAR    sUpdQry[MAX_QUERY_SIZE];

	struct  ORDER_REQUEST   pEOrdReq;

	strncpy(sClause," ",MAX_QUERY_SIZE);
        if(cAmo_type == 'M')
        {
                sprintf(sClause," AND (A.EQ_ENCASH_FLG = \"%d\" OR A.EQ_ENCASH_FLG IN ('N','X'))",pCnlEOrd->iSeqNo);
                logInfo("Inside If Condition");
        }
        else
        {
                if(pCnlEOrd->iSeqNo == 1)
                {
                        logInfo("This must be 9:00 pm batch where we should not pump SL and SLM order as exchange donot support SL and SLM in Pre open market.");
                        sprintf(sClause," AND EQ_ORDER_TYPE NOT IN (%d,%d)\
                                        AND EQ_SCRIP_CODE IN (SELECT SM_SCRIP_CODE FROM SECURITY_MASTER S WHERE S.SM_EXCHANGE = \"%s\"\
                                        AND S.SM_SEGMENT = \'%c\' AND S.SM_PREOPEN_EXCH_FLAG = 'Y')\
                                        ; ",ORD_TYPE_STOP_LOSS_MKT,ORD_TYPE_STOP_LIMIT,pCnlEOrd->sExcgId,pCnlEOrd->cSegment);
                }
        }

	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_STRATEGY_ID, \
			EQ_ORDER_OFFON, \
			EQ_PAN_NO,\
			EQ_PARTICIPANT_TYPE,\
			EQ_SETTLOR,\
			EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,\
			EQ_GTC_FLG,\
			EQ_ENCASH_FLG,\
			EQ_GROUP_ID,\
			EQ_REMARKS1,EQ_REMARKS2\
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS = \'%c\'\
			AND     A.EQ_MSG_CODE IN (%d,%d)\
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO )\
			AND     A.EQ_EXCH_ID = \"%s\" %s;",EXCH_CONFIRM_STATUS,TC_INT_OFF_ORDER_ENTRY,TC_INT_OFF_ORDER_MODIFY,pCnlEOrd->sExcgId,sClause);
	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEquPumpOffOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iPumpCount = iNoOfRec;
	logDebug2("iPumpCount = :%d:",iPumpCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(sUpdQry,'\0',MAX_QUERY_SIZE);
			memset(&pEOrdReq , '\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			logDebug2("pEOrdReq.ReqHeader.sExcgId :%s:",pEOrdReq.ReqHeader.sExcgId);
			pEOrdReq.ReqHeader.iSeqNo = 0;//@Darshan: Sending zero for routing all orders of same client to single OMS //atoi(Row[17]);
			logDebug2("pEOrdReq.ReqHeader.UserId:%llu:",Row[17]);
			pEOrdReq.ReqHeader.iUserId = strtoull(Row[17],NULL,10); 
			logDebug2("pEOrdReq.ReqHeader.UserId:%llu:",pEOrdReq.ReqHeader.iUserId);
			//pEOrdReq.ReqHeader.iSeqNo = atoi(Row[35]);
			pEOrdReq.ReqHeader.cSource= Row[22][0];
			//pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN;
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			//strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atoi(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1])+1;
			pEOrdReq.cHandleInst ='1';
			pEOrdReq.iStratergyId= STRG_OFF_ORD_PUMP;
			pEOrdReq.cOffMarketFlg = '0';
			pEOrdReq.cProCli = Row[19][0];
			//pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.cUserType = Row[20][0];
			strncpy(pEOrdReq.sRemarks ,PUMP_ORD_REMARKS,REMARKS_LEN);


			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pEOrdReq.cMarkProFlag= Row[31][0];
			pEOrdReq.fMarkProVal= atof(Row[32]);
			pEOrdReq.cParticipantType= Row[29][0];
			strncpy(pEOrdReq.sSettlor,Row[30],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[33][0];
			pEOrdReq.cEncashFlag= Row[34][0];
			pEOrdReq.iGrpId = atoi(Row[35]);
			strncpy(pEOrdReq.sPanID,Row[28],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[36],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[37],CHANNEL_LEN);
			logDebug2("Writing to Queue for Order Number :%f:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.cOffMarketFlg ;%c:",pEOrdReq.cOffMarketFlg);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.sClientId  :%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
			usleep(iBuffSec);			
		}

	}
	
	
	//if(pEOrdReq.iOrderValidity != VALIDITY_GTD)
	//{
	sprintf(sUpdQry,"UPDATE EQ_ORDERS SET EQ_GOOD_TILL_DATE = NOW() WHERE EQ_VALIDITY <> 6 AND EQ_MSG_CODE IN ('5112','5113','5114')");
	logDebug2("sUpdQry :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEquPumpOffOrd Query.");
	}
	else
	{
		mysql_commit(DB_IntSqr);
		logDebug2("------SUCCESS IN UPDATE QUERY-----");
	}

	//}
	logTimestamp("fEquPumpOffOrd [EXIT]");
	return TRUE;


}

BOOL fDrvPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	logTimestamp("fDrvPumpOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32		iNoOfRec = 0;
	LONG32		i= 0;
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pDOrdReq;


	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE, \
			DRV_STRATEGY_ID ,\
			DRV_SEGMENT , \
			DRV_ORDER_OFFON, \
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID,\
			DRV_REMARKS1,DRV_REMARKS2\
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'%c\'\
			AND     A.DRV_MSG_CODE IN (%d,%d)\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
			AND     A.DRV_EXCH_ID = \"%s\" AND A.DRV_SEGMENT = \'%c\' AND (A.DRV_ENCASH_FLG = \"%d\" OR A.DRV_ENCASH_FLG IN ('N','X') );",\
			EXCH_CONFIRM_STATUS,TC_INT_OFF_ORDER_ENTRY,TC_INT_OFF_ORDER_MODIFY,pCnlEOrd->sExcgId,pCnlEOrd->cSegment,pCnlEOrd->iSeqNo);
	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fDrvPumpOffOrd QUERY.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iPumpCount = iNoOfRec;
	logDebug2("iPumpCount = :%d:",iPumpCount);	

	logDebug2("fDrvPumpOffOrd : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pDOrdReq, '\0', sizeof(struct ORDER_REQUEST));
			pDOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
			pDOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pDOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pDOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pDOrdReq.ReqHeader.iUserId = strtoull(Row[17],NULL,10); 
			pDOrdReq.ReqHeader.iSeqNo = 0;
			pDOrdReq.ReqHeader.cSource= Row[22][0];
			//pDOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDOrdReq.ReqHeader.cSegment = Row[26][0];

			strncpy(pDOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pDOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			//strncpy(pDOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			logDebug2("Entity Id is :%s: ",pDOrdReq.sEntityId);
			strncpy(pDOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDOrdReq.cProductId= Row[23][0];
			pDOrdReq.cBuyOrSell = Row[7][0];
			pDOrdReq.iOrderType = atoi(Row[16]);
			pDOrdReq.iOrderValidity = atof(Row[15]);
			pDOrdReq.iTotalQty = atoi(Row[8]);
			pDOrdReq.iTotalQtyRem = atoi(Row[9]);
			pDOrdReq.iDiscQty = atoi(Row[10]);
			pDOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDOrdReq.fPrice = atof(Row[13]);
			pDOrdReq.fTriggerPrice = atof(Row[14]);
			pDOrdReq.fOrderNum = atof(Row[0]);
			pDOrdReq.iSerialNum = atoi(Row[1])+1;
			pDOrdReq.cHandleInst = '1';
			pDOrdReq.iStratergyId= STRG_OFF_ORD_PUMP;
			//	                pDOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;	
			pDOrdReq.cOffMarketFlg = Row[27][0];

			pDOrdReq.cProCli = Row[19][0];
			//	                pDOrdReq.cUserType = Row[20][0];
			pDOrdReq.cUserType = Row[20][0];
			strncpy(pDOrdReq.sRemarks ,PUMP_ORD_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
				return FALSE;
			}

			pDOrdReq.cMarkProFlag= Row[31][0];
			pDOrdReq.fMarkProVal= atof(Row[32]);
			pDOrdReq.cParticipantType= Row[29][0];
			strncpy(pDOrdReq.sSettlor,Row[30],SETTLOR_LEN);
			pDOrdReq.cGTCFlag= Row[33][0];
			pDOrdReq.cEncashFlag= Row[34][0];
			pDOrdReq.iGrpId = atoi(Row[35]);
			strncpy(pDOrdReq.sPlatform,Row[36],PLATFORM_LEN);
			strncpy(pDOrdReq.sChannel,Row[37],CHANNEL_LEN);
			//strncpy(pDOrdReq.sPanID,Row[28],INT_PAN_LEN);

			logDebug2("Writing to Queue for Order Number :%f:",pDOrdReq.fOrderNum);
			logDebug2("Market Type is :%d:",pDOrdReq.iMktType);
			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pDOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
			usleep(iBuffSec);			
		}
	}

	logTimestamp("fDrvPumpOffOrd [ENTRY]");
	return TRUE;

}

BOOL fCommPumpOffOrd(struct INT_COMMON_REQUEST_HDR *pCnlEOrd)
{
	logTimestamp("fCommPumpOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 	iNoOfRec = 0;
	LONG32 	i = 0;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pEOrdReq;

	logDebug2("pCnlEOrd->iSeqNo :%d:",pCnlEOrd->iSeqNo);	

	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE ,\
			COMM_STRATEGY_ID ,\
			COMM_SEGMENT ,\
			COMM_ORDER_OFFON ,\
			COMM_MKT_TYPE ,\
			COMM_USER_TYPE ,\
			COMM_PAN_NO,\
			COMM_PARTICIPANT_TYPE,\
			COMM_SETTLOR,\
			COM_MKT_PROTECT_FLG,\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG,\
			COMM_GROUP_ID,COMM_REMARKS1,COMM_REMARKS2\
			FROM    COMM_ORDERS A\
			WHERE   A.COMM_STATUS = \'%c\'\
			AND     A.COMM_MSG_CODE IN (%d,%d)\
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO)\
			AND     A.COMM_EXCH_ID = \"%s\" AND A.COMM_SEGMENT = \'%c\' AND A.COMM_SERIES = \"%d\" ;",\
			EXCH_CONFIRM_STATUS,TC_INT_OFF_ORDER_ENTRY,TC_INT_OFF_ORDER_MODIFY,pCnlEOrd->sExcgId,pCnlEOrd->cSegment,pCnlEOrd->iSeqNo);
	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCommPumpOffOrd Query........");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iPumpCount = iNoOfRec;
	logDebug2("iPumpCount = :%d:",iPumpCount);	

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq, '\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[3],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[16]);
			//pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.cSource= Row[20][0];
			//pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[24][0];
			pEOrdReq.ReqHeader.iSeqNo = 0;

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,Row[4],ENTITY_ID_LEN);
			//strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[5],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[21][0];
			pEOrdReq.cBuyOrSell = Row[6][0];
			pEOrdReq.iOrderType = atoi(Row[15]);
			pEOrdReq.iOrderValidity = atof(Row[14]);
			pEOrdReq.iTotalQty = atoi(Row[7]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[9]);
			pEOrdReq.iDiscQtyRem = atoi(Row[10]);
			pEOrdReq.iTotalTradedQty = atoi(Row[11]);
			pEOrdReq.fPrice = atof(Row[12]);
			pEOrdReq.fTriggerPrice = atof(Row[13]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.iStratergyId= STRG_OFF_ORD_PUMP;
			//	                pEOrdReq.cOffMarketFlg= Row[25][0];
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = Row[18][0];
			pEOrdReq.cUserType = Row[27][0];		
			//pEOrdReq.cUserType = ADMIN_TYPE ;		
			//			strncpy(pEOrdReq.sRemarks ,Row[19],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,PUMP_ORD_REMARKS,REMARKS_LEN);

			if(strcmp(Row[26],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[26],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[26],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[26],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[26]);
				return FALSE;
			}
			pEOrdReq.cMarkProFlag= Row[31][0];
			pEOrdReq.fMarkProVal= atof(Row[32]);
			pEOrdReq.cParticipantType= Row[29][0];
			strncpy(pEOrdReq.sSettlor,Row[30],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[33][0];
			pEOrdReq.cEncashFlag= Row[34][0];
			pEOrdReq.iGrpId = atoi(Row[35]);
			strncpy(pEOrdReq.sPanID,Row[28],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[36],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[37],CHANNEL_LEN);

			logDebug2("pEOrdReq.fOrderNum :%lf",pEOrdReq.fOrderNum);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
			usleep(iBuffSec);			
		}

	}
	logTimestamp("fCommPumpOffOrd [EXIT]");
	return TRUE;

}

/*
   void fPrintAll(struct CO_ORDER_REQUEST *pOrdReq)
   {
   logTimestamp("fPrintAll[ENTRY]");


   logDebug2("pOrdReq.fOrderNum  		:%f:",pOrdReq->fOrderNum);
   logDebug2("pOrdReq.iSerialNum 		:%d: ",pOrdReq->iSerialNum);
   logDebug2("pOrdReq.CoArray[0].cBuySellInd 	:%c: ",pOrdReq->CoArray[0].cBuySellInd);
   logDebug2("pOrdReq.CoArray[0].fTriggerPrice 	:%f: ",pOrdReq->CoArray[0].fTriggerPrice);
   logDebug2("pOrdReq.CoArray[0].iLegValue 	:%d: ",pOrdReq->CoArray[0].iLegValue);
   logDebug2("pOrdReq.fPrice 		:%f:",pOrdReq->fPrice);
   logDebug2("pOrdReq.iTotalQty 		:%d: ",pOrdReq->iTotalQty);
   logDebug2("pOrdReq.iTotalQtyRem 	:%d: ",pOrdReq->iTotalQtyRem);
   logDebug2("pOrdReq.iTotalTradedQty 	:%d: ",pOrdReq->iTotalTradedQty);

   logDebug2("pEOrdReq->ReqHeader.sExcgId 	:%s:",pOrdReq->ReqHeader.sExcgId);
   logDebug2("pOrdReq.ReqHeader.iUserId  	:%d:",pOrdReq->ReqHeader.iUserId );
   logDebug2("pOrdReq.ReqHeader.cSource 	:%c:",pOrdReq->ReqHeader.cSource);
   logDebug2("pOrdReq.ReqHeader.cSegment 	:%c: ",pOrdReq->ReqHeader.cSegment);
   logDebug2("pOrdReq.ReqHeader.iMsgCode 	:%d:",pOrdReq->ReqHeader.iMsgCode);
   logDebug2("pOrdReq.ReqHeader.iMsgLength	:%d:",pOrdReq->ReqHeader.iMsgLength);

   logDebug2("pOrdReq.sSecurityId	:%s:",pOrdReq->sSecurityId);
   logDebug2("pOrdReq.sEntityId	:%s:",pOrdReq->sEntityId);
   logDebug2("pOrdReq.sClientId	:%s:",pOrdReq->sClientId);
   logDebug2("pOrdReq.cProductId	:%c:",pOrdReq->cProductId);
   logDebug2("pOrdReq.iOrderType 	:%d: ",pOrdReq->iOrderType);
   logDebug2("pOrdReq.iOrderValidity 	:%d: ",pOrdReq->iOrderValidity);
   logDebug2("pOrdReq.iDiscQty 	:%d: ",pOrdReq->iDiscQty);
   logDebug2("prdReq.iDiscQtyRem 	:%d: ",pOrdReq->iDiscQtyRem);
   logDebug2("pOrdReq.cHandleInst  :%c:",pOrdReq->cHandleInst);
   logDebug2("pOrdReq.iStratergyId	:%d: ",pOrdReq->iStratergyId);
   logDebug2("pOrdReq.cProCli  	:%c:",pOrdReq->cProCli);
   logDebug2("pOrdReq.cUserType  	:%c:",pOrdReq->cUserType);
   logDebug2("pOrdReq.cSLFlag   	:%c:",pOrdReq->cSLFlag);
   logDebug2("pOrdReq.cPBFlag   	:%c:",pOrdReq->cPBFlag);
   logDebug2("pOrdReq.cAvgLtpFlg  	:%c:",pOrdReq->cAvgLtpFlg);
   logDebug2("pOrdReq.sRemarks 	:%s:",pOrdReq->sRemarks);
   logDebug2("pOrdReq.iMktType 	:%d:",pOrdReq->iMktType);
   logDebug2("pOrdReq.fSLTikAbsValue  	:%f:",pOrdReq->fSLTikAbsValue);
   logDebug2("pOrdReq.fPBTikAbsValue   	:%f:",pOrdReq->fPBTikAbsValue);

   logTimestamp("fPrintAll[EXIT]");

   }*/

OpenMsgQue()
{
	if( ( iAutoSqoffToOrdRtr = OpenMsgQ( (IntSqrOffToMemMap))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug2("write Q = %d",iAutoSqoffToOrdRtr);
	if( ( iRDaemonToSqoff= OpenMsgQ( (RDaemonToSqoff))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug2("Read Q = %d",iRDaemonToSqoff);
	if((iMmapToD2C1=  OpenMsgQ(MmapToD2C1)) == ERROR)
	{
		logFatal("Error in Opening MmapToD2C1");
		exit(1);
	}
	logDebug2("iMmapToD2C1 :%d:",iMmapToD2C1);
	if (( iOrdSrvToTrdRtr = OpenMsgQ ( OrdSrvToTrdRtr)) == ERROR)
        {
                perror("OpenMsgQ2 ...ParentToRelDirIORQ failed ");
                exit(ERROR);
        }
        logDebug2("SucessFully Created OrdSrvToTrdRtr key = %d iOrdSrvToTrdRtr:%d:",OrdSrvToTrdRtr,iOrdSrvToTrdRtr);

	return TRUE;
}

BOOL fCnlCCPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlCCPendingOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sWhereCls[MAX_QUERY_SIZE];

	struct  ORDER_REQUEST   *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	LONG32  iNoOfRec = 0;
	LONG32  i = 0;

	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;


	if(pCnlEOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order cancel");
		//sprintf(sWhereCls," AND SUBSTRING_INDEX(DRV_SYMBOL, '-', 1)  in ('EURUSD','GBPUSD','USDJPY')");
		sprintf(sWhereCls," AND DRV_CROSS_CUR_FLAG = \'%c\' ;",YES);

		logDebug2("sWhereCls :%s:",sWhereCls);
	}
	else
	{
		sprintf(sWhereCls ," ");
	}

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);	
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND A.DRV_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG = \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.DRV_CLIENT_ID  IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <>  \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);

	logDebug2("exchID:%s",pCnlEOrd->ReqHeader.sExcgId);
	logDebug2("c.segment:%c",pCnlEOrd->ReqHeader.cSegment);

	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT,\
			DRV_OMS_ALGO_ORD_NO ,\
			DRV_STRATEGY_ID ,\
			DRV_ORDER_OFFON, \
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID,\
			DRV_REMARKS1,\
			DRV_REMARKS2\
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'%c\' \
			AND     A.DRV_MSG_CODE IN (%d,%d)\
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO )\
			AND     A.DRV_EXCH_ID = \"%s\" AND DRV_SEGMENT = \'%c\' %s %s;",EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,PROD_INTRADAY,\
			pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sWhereCls,sClause);
			//AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_GROUP_ID = %d)\

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlCCPendingOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);	

		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[36]);
			//pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);

			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= STRG_INT_SQR_OFF;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			//                      pEOrdReq.cOffMarketFlg= Row[28][0];
			//                      pEOrdReq.cUserType = Row[20][0]
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.iAuctionNum = 0;
			//                strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)	
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pEOrdReq.cMarkProFlag= Row[32][0];
			pEOrdReq.fMarkProVal= atof(Row[33]);
			pEOrdReq.cParticipantType= Row[30][0];
			strncpy(pEOrdReq.sSettlor,Row[31],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[34][0];
			pEOrdReq.cEncashFlag= Row[35][0];
			pEOrdReq.iGrpId = atoi(Row[36]);
			strncpy(pEOrdReq.sPanID,Row[29],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[37],PLATFORM_LEN);
                        strncpy(pEOrdReq.sChannel,Row[38],CHANNEL_LEN);

			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.iGrpId :%d:",pEOrdReq.iGrpId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("EXIT [fCnlCCPendingOrd]");
	return TRUE;

}

BOOL fSqrOffCCSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffCCSellOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32  iNoOfRec = 0;
	LONG32  i= 0;

	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			-(NET_QTY) QTY_ORIGINNAL,\
			-(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT, \
			em.ENTITY_PAN \
			FROM    VIEW_NET_POSITION a, USER_MASTER um ,ENTITY_MASTER em\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty < 0\
			AND a.prod_id=\'%c\'\
			and a.segmnt = \'%c\'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND um.USER_ENTITY_CODE = em.ENTITY_CODE \
			AND a.exch_id= ltrim(rtrim(\'%s\'))\
			AND a.CROSS_CUR_FLAG = \'%c\';",PROD_INTRADAY,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->ReqHeader.sExcgId,YES);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffCCSellOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			//	pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.iUserId = iUserId; 
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_BUY;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0.00;
			pEOrdReq.fTriggerPrice= 0.00;
			pEOrdReq.fOrderNum = 0.00;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.iAuctionNum = 0;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2("INVALID Mkt Type :%s: ",Row[1]);
			}

			pEOrdReq.iAuctionNum = 0;
			pEOrdReq.cMarkProFlag=NO ;
			pEOrdReq.fMarkProVal= 1.00;
			pEOrdReq.cParticipantType= PARTICI_BROKER;
			strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
			pEOrdReq.cGTCFlag= NO;
			pEOrdReq.cEncashFlag=NO;
			strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);


			logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
			logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT  [fSqrOffCCSellOrd]");
	return TRUE;

}


BOOL fSqrOffCCBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffCCBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32          iNoOfRec = 0;
	LONG32          i= 0;

	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT,  \
			em.ENTITY_PAN \
			FROM    VIEW_NET_POSITION a, USER_MASTER um,ENTITY_MASTER em \
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty > 0\
			AND a.prod_id='I'\
			and a.segmnt = \'%c\'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND um.USER_ENTITY_CODE = em.ENTITY_CODE \ 	
			AND a.exch_id= ltrim(rtrim(\'%s\')) \
			AND a.CROSS_CUR_FLAG = \'%c\';",pEQBuyOrd->ReqHeader.cSegment,pEQBuyOrd->ReqHeader.sExcgId,YES);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffCCBuyOrd Query...");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			//			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_SELL;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0.00;
			pEOrdReq.fTriggerPrice= 0.00;
			pEOrdReq.fOrderNum = 0.00;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = STRG_INT_SQR_OFF;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			pEOrdReq.iAuctionNum = 0;	
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2("INVALID Mkt Type :%s: ",Row[1]);
			}

			pEOrdReq.iAuctionNum = 0;
			pEOrdReq.cMarkProFlag=NO ;
			pEOrdReq.fMarkProVal= 1.00;
			pEOrdReq.cParticipantType= PARTICI_BROKER;
			strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
			pEOrdReq.cGTCFlag= NO;
			pEOrdReq.cEncashFlag=NO;
			strncpy(pEOrdReq.sPanID,Row[9],INT_PAN_LEN);	

			logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
			logDebug2("pEOrdReq.sSecurityId   :%s:",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT [fSqrOffCCBuyOrd]");
	return TRUE;

}

BOOL fMcxCoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fMcxCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	LONG32 iNoOfRec = 0 ;
	LONG32  i = 0;

	struct  CO_ORDER_REQUEST   *pCnlMOrd;
	struct  CO_ORDER_REQUEST   pMOrdReq;

	pCnlMOrd = (struct  CO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause," AND A.COMM_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.COMM_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);

	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_MKT_TYPE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_USER_TYPE,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE,\
			COMM_SEGMENT ,\
			COMM_SL_ABSTICK_VALUE ,\
			COMM_PR_ABSTICK_VALUE ,\
			COMM_SL_AT_FLAG ,\
			COMM_PR_ST_FLAG ,\
			COMM_PAN_NO,\
			COMM_PARTICIPANT_TYPE,\
			COMM_SETTLOR,\
			COM_MKT_PROTECT_FLG,\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG,\
			COMM_GROUP_ID\
			FROM    COMM_ORDERS A\
			WHERE  A.COMM_STATUS IN (\'%c\',\'%c\') \
			AND     A.COMM_PRODUCT_ID = \'%c\' \
			AND     A.COMM_LEG_NO =   %d \
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO AND B.COMM_LEG_NO = %d )\
			AND     A.COMM_EXCH_ID = \"%s\" \
			AND	A.COMM_SERIES = %d \
			AND     A.COMM_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,pCnlMOrd->ReqHeader.sExcgId,pCnlMOrd->ReqHeader.iSeqNo,pCnlMOrd->ReqHeader.cSegment,sClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fMcxCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	
	logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

	for(i = 0 ; i < iNoOfRec ; i++)
	{
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pMOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pMOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			//                        pMOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pMOrdReq.ReqHeader.iUserId = iUserId;
			pMOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pMOrdReq.ReqHeader.cSegment = Row[25][0];
			pMOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pMOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);

			strncpy(pMOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pMOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pMOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pMOrdReq.cProductId= Row[23][0];
			pMOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pMOrdReq.iOrderType = atoi(Row[16]);
			pMOrdReq.iOrderValidity = iOrderVal;
			pMOrdReq.iTotalQty = atoi(Row[8]);
			pMOrdReq.iTotalQtyRem = atoi(Row[8]);
			pMOrdReq.iDiscQty = atoi(Row[10]);
			pMOrdReq.iDiscQtyRem = atoi(Row[11]);
			pMOrdReq.iTotalTradedQty = atoi(Row[12]);
			pMOrdReq.fPrice = atof(Row[13]);
			pMOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pMOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pMOrdReq.fOrderNum = atof(Row[0]);
			pMOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pMOrdReq.cHandleInst = '1';
			pMOrdReq.iStratergyId= STRG_CO_SQR_OFF ;
			pMOrdReq.cProCli = Row[19][0];
			pMOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pMOrdReq.fSLTikAbsValue = atof(Row[26]);
			pMOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pMOrdReq.fTrailingSLValue = 0.00 ;
			pMOrdReq.fAlgoOrderNo = 0.00 ;
			pMOrdReq.iNoOfLeg = 1 ;
			pMOrdReq.iMinFillQty = atoi(Row[18]) ;
			pMOrdReq.cSLFlag  =  Row[28][0];
			pMOrdReq.cPBFlag  = Row[29][0];
			pMOrdReq.cAvgLtpFlg = 0;
			pMOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pMOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pMOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pMOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pMOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pMOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pMOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			pMOrdReq.cMarkProFlag= Row[33][0];
			pMOrdReq.fMarkProVal= atof(Row[34]);
			pMOrdReq.cParticipantType= Row[31][0];
			strncpy(pMOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pMOrdReq.cGTCFlag= Row[35][0];
			pMOrdReq.cEncashFlag= Row[36][0];
			pMOrdReq.iGrpId = atoi(Row[37]);
			pMOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			logDebug2(" pMOrdReq.ReqHeader.iSeqNo :%d: ",pMOrdReq.ReqHeader.iSeqNo);
			logDebug2(" pMOrdReq.iGrpId :%d: ",pMOrdReq.iGrpId);
			strncpy(pMOrdReq.sPanID,Row[30],INT_PAN_LEN);


			logDebug2(" pMOrdReq.CoArray[0].cBuySellInd :%c: ",pMOrdReq.CoArray[0].cBuySellInd);
			logDebug2("pMOrdReq.CoArray[0].fTriggerPrice :%f:",pMOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pMOrdReq.CoArray[1].fTriggerPrice :%f:",pMOrdReq.CoArray[1].fTriggerPrice);
			logDebug2(" pMOrdReq.fOrderNum :%f: ",pMOrdReq.fOrderNum);
			logDebug2(" pMOrdReq.sClientId :%s: ",pMOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pMOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fMcxCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fMcxBoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fMcxBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR            sClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);

	LONG32  iNoOfRec = 0 ;
	LONG32  i = 0;

	struct  BO_ORDER_REQUEST   *pCnlMOrd;
	struct  BO_ORDER_REQUEST   pMOrdReq;

	pCnlMOrd = (struct  BO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("cIntradayFlag :%c:",cIntradayFlag);
	if(cIntradayFlag == CLIENT_TYPE)
	{
		/* for Client wise UM_INT_SQROFF_FLAG is added in USER_MASTER*/
		sprintf(sClause,"AND  A.COMM_CLIENT_ID IN (SELECT  USER_ENTITY_CODE FROM USER_MASTER WHERE UM_INT_SQROFF_FLAG <> \'%c\')",NO);
	}
	else if (cIntradayFlag == ALL )
	{
		sprintf(sClause," ");
	}
	else if (cIntradayFlag == RMS_PROFILE_BASED_SQROFF )
	{
		/*For RISK PROFILE WISE IntSqrOff RPM_SQ_OFF_MODE is added in RMS_RISK_PROFILE_MAST*/
		sprintf(sClause,"AND  A.COMM_CLIENT_ID IN (SELECT ENTITY_CODE FROM  ENTITY_MASTER s WHERE s.ENTITY_TYPE = \'%c\' and s.ENTITY_RISK_PROFILE IN (SELECT RPM_CODE FROM RMS_RISK_PROFILE_MAST s WHERE s.RPM_SQ_OFF_MODE <> \'%c\')) ",CLIENT_TYPE,NO);
	}
	else
	{
		logDebug2("Wrong Flag set in cIntradayFlag in Sys_Parameter");
		return FALSE ;
	}
	logDebug2("sClause :%s;",sClause);

	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_MKT_TYPE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_USER_TYPE,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE,\
			COMM_SEGMENT ,\
			COMM_SL_ABSTICK_VALUE ,\
			COMM_PR_ABSTICK_VALUE ,\
			COMM_SL_AT_FLAG ,\
			COMM_PR_ST_FLAG ,\
			COMM_PAN_NO,\
			COMM_PARTICIPANT_TYPE,\
			COMM_SETTLOR,\
			COM_MKT_PROTECT_FLG,\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG,\
			COMM_GROUP_ID\
			FROM    COMM_ORDERS A\
			WHERE   A.COMM_STATUS IN (\'%c\',\'%c\') \
			AND     A.COMM_PRODUCT_ID = \'%c\' \
			AND     A.COMM_LEG_NO =   %d \
			AND     A.COMM_OMS_ALGO_ORDER_NO = -1 \
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO AND B.COMM_LEG_NO = %d )\				AND     A.COMM_EXCH_ID = \"%s\" \
			AND 	A.COMM_SERIES = %d \
			AND     A.COMM_SEGMENT = \'%c\' %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,pCnlMOrd->ReqHeader.sExcgId,pCnlMOrd->ReqHeader.iSeqNo,pCnlMOrd->ReqHeader.cSegment,sClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fMcxBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	

	logDebug2("fMcxBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pMOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pMOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			// pMOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pMOrdReq.ReqHeader.iUserId = iUserId;
			pMOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pMOrdReq.ReqHeader.cSegment = Row[25][0];
			pMOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pMOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);

			strncpy(pMOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pMOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pMOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pMOrdReq.cProductId= Row[23][0];
			pMOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pMOrdReq.iOrderType = atoi(Row[16]);

			pMOrdReq.iOrderValidity = iOrderVal;
			pMOrdReq.fAlgoOrderNo   = -1 ;
			pMOrdReq.iTotalQty = atoi(Row[8]);
			pMOrdReq.iTotalQtyRem = atoi(Row[8]);
			pMOrdReq.iDiscQty = atoi(Row[10]);
			pMOrdReq.iDiscQtyRem = atoi(Row[11]);
			pMOrdReq.iTotalTradedQty = atoi(Row[12]);
			pMOrdReq.fPrice = atof(Row[13]);
			pMOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pMOrdReq.fOrderNum = atof(Row[0]);
			pMOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pMOrdReq.cHandleInst = '1';
			pMOrdReq.iStratergyId= STRG_BO_SQR_OFF;
			pMOrdReq.cProCli = Row[19][0];
			pMOrdReq.cUserType = ADMIN_TYPE ;
			pMOrdReq.BoArray[0].iLegValue = LEG_1 ;
			pMOrdReq.fSLTikAbsValue = atof(Row[26]);
			pMOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pMOrdReq.cSLFlag  =  Row[28][0];
			pMOrdReq.cPBFlag  = Row[29][0];
			pMOrdReq.cFlag    = '0';
			pMOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;

			strncpy(pMOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pMOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pMOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pMOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pMOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pMOrdReq.cMarkProFlag= Row[33][0];
			pMOrdReq.fMarkProVal= atof(Row[34]);
			pMOrdReq.cParticipantType= Row[31][0];
			strncpy(pMOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pMOrdReq.cGTCFlag= Row[35][0];
			pMOrdReq.cEncashFlag= Row[36][0];
			
			pMOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pMOrdReq.sPanID,Row[30],INT_PAN_LEN);
			pMOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
                        logDebug2(" pMOrdReq.ReqHeader.iSeqNo :%d: ",pMOrdReq.ReqHeader.iSeqNo);
			logDebug2(" pMOrdReq.BoArray[0].cBuySellInd :%c: ",pMOrdReq.BoArray[0].cBuySellInd);
			logDebug2(" pMOrdReq.fOrderNum :%f: ",pMOrdReq.fOrderNum);
			logDebug2(" pMOrdReq.sClientId :%s: ",pMOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pMOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fMcxBoOrdExit [EXIT]");
	return TRUE;
}

BOOL fSqOffRespToFE(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqOffRespToFE]");
	struct  ORDER_REQUEST   *Ord_Req;
	Ord_Req = (struct ORDER_REQUEST *)RcvMsg;
	struct INT_ERROR_FE_RESP pErrorResponce;
	CHAR    sErrorMsg[DB_REASON_DESC_LEN];
	CHAR	sMsg[DB_REASON_DESC_LEN];
	CHAR	sSegment[20];
	memset(sErrorMsg,'\0',DB_REASON_DESC_LEN);
	memset(sMsg,'\0',DB_REASON_DESC_LEN);
	memset(sSegment,'\0',20);
	logDebug2("Ord_Req->ReqHeader.iMsgCode :%d:",Ord_Req->ReqHeader.iMsgCode);
	if (Ord_Req->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_REQ)
	{
		strncpy(sMsg,INTRADAY_SQUREOFF,20);
	}
	else if (Ord_Req->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ)
	{
		strncpy(sMsg,INTRADAY_CROSS_CUR_SQROFF,20);
	}
	else if (Ord_Req->ReqHeader.iMsgCode == TC_INT_PUMPOFFLINE_REQ)
	{
		strncpy(sMsg,OFFMARKET_PUMPER,20);
	}

	else if (Ord_Req->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_COVER_ORD_REQ)
	{
		strncpy(sMsg,COVER_ORD_SQUREOFF,20);
	}
	else if(Ord_Req->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_BRACKET_ORD_REQ)
	{
		strncpy(sMsg,BRACKET_ORD_SQUREOFF,20);
	}
	else if( Ord_Req->ReqHeader.iMsgCode == TC_INT_PUMPSIPORDER_REQ)
	{
		strncpy(sMsg,SIP_DAY,20);
	}
	else if( Ord_Req->ReqHeader.iMsgCode == TC_BULK_CANCEL_ADMIN_REQ)
	{
		strncpy(sMsg,"BULK_CANCELLATION",20);
	}
	else if( Ord_Req->ReqHeader.iMsgCode == TC_BULK_SQUAREOFF_ADMIN_REQ)
	{
		strncpy(sMsg,"BULK_SQR_OFF",20);
	}
	else if( Ord_Req->ReqHeader.iMsgCode == TC_BULK_CO_EXIT_ADMIN_REQ)
	{
		strncpy(sMsg,"BULK_CO_EXIT",20);
	}
	else if( Ord_Req->ReqHeader.iMsgCode == TC_BULK_BO_EXIT_ADMIN_REQ)
	{
		strncpy(sMsg,"BULK_BO_EXIT",20);
	}
	else
	{
		logDebug2("Wrong Msg Code");
		logDebug2("Ord_Req->ReqHeader.iMsgCode :%d:",Ord_Req->ReqHeader.iMsgCode);
	}

	logDebug2("Ord_Req->ReqHeader.cSegment :%c:",Ord_Req->ReqHeader.cSegment);
	if(Ord_Req->ReqHeader.cSegment == EQUITY_SEGMENT)
	{
		strncpy(sSegment,"EQUITY",20);
	}
	else if(Ord_Req->ReqHeader.cSegment == DERIVATIVE_SEGMENT)
	{
		strncpy(sSegment,"DERIVATIVE",20);
	}
	else if(Ord_Req->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		strncpy(sSegment,"CURRENCY",20);
	}
	else if(Ord_Req->ReqHeader.cSegment == COMMODITY_SEGMENT)
	{
		strncpy(sSegment,"COMMODITY",20);
	}
	else
	{
		logDebug2("Wrong Segment");
		logDebug2("Ord_Req->ReqHeader.cSegment :%c:",Ord_Req->ReqHeader.cSegment);
	}

	pErrorResponce.IntRespHeader.iMsgLength = sizeof(struct INT_ERROR_FE_RESP);
	pErrorResponce.IntRespHeader.iErrorId = 0;
	pErrorResponce.IntRespHeader.iMsgCode = TC_INT_AUTOBATCH_MSG_RESP ;
	logDebug2("Ord_Req->ReqHeader.iUserId :%llu:",Ord_Req->ReqHeader.iUserId);
	//pErrorResponce.IntRespHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	pErrorResponce.IntRespHeader.iUserId = iUserId;
	logDebug2("pErrorResponce.IntRespHeader.iUserId :%llu:",pErrorResponce.IntRespHeader.iUserId);
	pErrorResponce.IntRespHeader.iSeqNo = Ord_Req->ReqHeader.iSeqNo;
	pErrorResponce.IntRespHeader.cSource = SOURCE_ADMIN;
	pErrorResponce.IntRespHeader.cSegment = Ord_Req->ReqHeader.cSegment;

	strncpy(pErrorResponce.IntRespHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);

	strncpy(pErrorResponce.sSecurityId,Ord_Req->sSecurityId,SECURITY_ID_LEN);
	strncpy(pErrorResponce.sClientId,Ord_Req->sClientId,CLIENT_ID_LEN);
	pErrorResponce.cProductId = Ord_Req->cProductId;
	pErrorResponce.cBuyOrSell = Ord_Req->cBuyOrSell;
	pErrorResponce.iTotalQty = Ord_Req->iTotalQty;
	pErrorResponce.fPrice = Ord_Req->fPrice;

	logDebug2("Messages are going to print");
	//	strncpy(sErrorMsg,"%s Are Going To Start In 5 Seconds ",sMsg);
	if( Ord_Req->ReqHeader.iMsgCode == TC_BULK_CANCEL_ADMIN_REQ || Ord_Req->ReqHeader.iMsgCode == TC_BULK_SQUAREOFF_ADMIN_REQ || Ord_Req->ReqHeader.iMsgCode == TC_BULK_CO_EXIT_ADMIN_REQ || Ord_Req->ReqHeader.iMsgCode == TC_BULK_BO_EXIT_ADMIN_REQ)
	{
		sprintf(sErrorMsg,"%s ARE GOING TO START IN 5 SECONDS ",sMsg,sSegment);
		pErrorResponce.IntRespHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	}
	else
	{
		sprintf(sErrorMsg,"%s FOR %s %s ARE GOING TO START IN 5 SECONDS ",sMsg,Ord_Req->ReqHeader.sExcgId,sSegment);
		//pErrorResponce.IntRespHeader.iUserId = iUserId;
	}
	strncpy(pErrorResponce.sErrorMsg,sErrorMsg,DB_REASON_DESC_LEN);
	logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);

	if((WriteMsgQ(iMmapToD2C1,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendErrorToFE.");
		exit(ERROR);
	}
	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendErrorToFE.");
		exit(ERROR);
	}
	logTimestamp("EXIT [fSqOffRespToFE]");
	return TRUE;	
}

BOOL fBulkCnlEqPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fBulkCnlEqPendingOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            sSelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR            sClause[MAX_QUERY_SIZE];
	CHAR            sClause1[MAX_QUERY_SIZE];
	CHAR            sClause2[MAX_QUERY_SIZE];
        CHAR            sClauseOuter[MAX_QUERY_SIZE];
        CHAR            sClauseOuter1[MAX_QUERY_SIZE];
        CHAR            sClauseOuter2[MAX_QUERY_SIZE];

	CHAR            sTempClause[MAX_QUERY_SIZE];
        CHAR            sTempClause1[MAX_QUERY_SIZE];
        CHAR            sTempClause2[MAX_QUERY_SIZE];
        CHAR            sTempOuter[MAX_QUERY_SIZE];
        CHAR            sTempOuter1[MAX_QUERY_SIZE];
        CHAR            sTempOuter2[MAX_QUERY_SIZE];

	struct  ORDER_INSTRUCTION_REQUEST *pEQSellOrd;
	struct  ORDER_REQUEST 		pEOrdReq;
	LONG32   iNoOfRec = 0;
	LONG32   i= 0;

	memset(sClause,'\0',MAX_QUERY_SIZE);
	memset(sClause1,'\0',MAX_QUERY_SIZE);
	memset(sClause2,'\0',MAX_QUERY_SIZE);

        memset(sClauseOuter,'\0',MAX_QUERY_SIZE);
        memset(sClauseOuter1,'\0',MAX_QUERY_SIZE);
        memset(sClauseOuter2,'\0',MAX_QUERY_SIZE);

	memset(sTempClause,'\0',MAX_QUERY_SIZE);
        memset(sTempClause1,'\0',MAX_QUERY_SIZE);
	memset(sTempClause2,'\0',MAX_QUERY_SIZE);

        memset(sTempOuter,'\0',MAX_QUERY_SIZE);
        memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
        memset(sTempOuter2,'\0',MAX_QUERY_SIZE);

	pEQSellOrd = (struct  ORDER_INSTRUCTION_REQUEST *)RcvMsg ;

	logDebug2("Received Bulk Cancellation request from admin");
	logDebug2("pEQSellOrd->ReqHeader.sExcgId :%s:",pEQSellOrd->ReqHeader.sExcgId);
	logDebug2("pEQSellOrd->ReqHeader.cSegment :%c:",pEQSellOrd->ReqHeader.cSegment);
	logDebug2("pEQSellOrd->ReqHeader.cSource :%c:",pEQSellOrd->ReqHeader.cSource);
	logDebug2("pEQSellOrd->sClientId :%s:",pEQSellOrd->sClientId);
	logDebug2("pEQSellOrd->sSymbol :%s:",pEQSellOrd->sSymbol);
	logDebug2("pEQSellOrd->cProduct :%c:",pEQSellOrd->cProduct);
	logDebug2("pEQSellOrd->sInstrument :%s:",pEQSellOrd->sInstrument);
	logDebug2("pEQSellOrd->sPlaceBy :%s:",pEQSellOrd->sPlaceBy);
	logDebug2("pEQSellOrd->sOrdStatus:%s:",pEQSellOrd->sOrdStatus);
	logDebug2("pEQSellOrd->iQuantity_val:%d:",pEQSellOrd->iQuantity_val);
	logDebug2("pEQSellOrd->fOrder_val:%f:",pEQSellOrd->fOrder_val);

	if(strcmp(pEQSellOrd->ReqHeader.sExcgId,SELECT_ALL)== 0)
        {
                logDebug2("If Condition for Exchange ID");
                logDebug2("Exchange id is %s", pEQSellOrd->ReqHeader.sExcgId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);

        }
        else
        {
                logDebug2("This is in Else loop For Exchange Id");
                logDebug2("Exchange id is %s", pEQSellOrd->ReqHeader.sExcgId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);
        }

/*	if(pEQSellOrd->ReqHeader.cSegment = 'E')
        {
                logDebug2("If condition for Equity Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'D')
        {
                logDebug2("else if for Derivative and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);


        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'C')
        {
                logDebug2("else if for Commodity and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

        }
        else
        {
                logDebug2("Else condition for Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
        }
*/	
	if(strcmp(pEQSellOrd->sClientId,SELECT_ALL) == 0)
	{           
		logDebug2("If Condition for Client ID");
  		logDebug2("Client Id is  %s", pEQSellOrd->sClientId);
	  	memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
		strcat(sClause,sTempClause);

 		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2,"  AND COMM_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause2,sTempClause2);

	}
 	else
	{
		logDebug2("This is in  Else loop for Client ID");
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2,"  AND COMM_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause2,sTempClause2);
	}
/*	if(strcmp(pEQSellOrd->ReqHeader.sExcgId,SELECT_ALL)== 0)
	{
		logDebug2("If Condition for Exchange ID");
		logDebug2("Exchange id is %s", pEQSellOrd->ReqHeader.sExcgId);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
		strcat(sClause,sTempClause);
 
                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);

	}
	else
	{
		logDebug2("This is in Else loop For Exchange Id");
		logDebug2("Exchange id is %s", pEQSellOrd->ReqHeader.sExcgId);
  		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);
	} */
	if(pEQSellOrd->ReqHeader.cSegment != '%')
	{  	
		logDebug2("If condition for Segment");
		logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
	       	memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
		strcat(sClause,sTempClause);
		
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

	}
	else
	{
		logDebug2("Else condition for Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

	} 

/* 	if(pEQSellOrd->ReqHeader.cSegment = 'E')
	{
		logDebug2("If condition for Equity Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

	} 
	else if(pEQSellOrd->ReqHeader.cSegment = 'D')
	{
		logDebug2("else if for Derivative and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);


	}
        else if(pEQSellOrd->ReqHeader.cSegment = 'C')
        {
                logDebug2("else if for Commodity and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

	}
	else
	{
		logDebug2("Else condition for Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
	}
*/
	if(strcmp(pEQSellOrd->sSymbol,SELECT_ALL) == 0)
	{
		logDebug2("IF condition for Symbol");
		logDebug2("Symbol is %s",pEQSellOrd->sSymbol);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
		strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause2,sTempClause2);

	}
	else
	{
		logDebug2("This is in  ELse Loop For Symbol");
                logDebug2("Symbol is %s", pEQSellOrd->sSymbol);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SYMBOL like  \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SYMBOL like  \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SYMBOL like  \"%s %\" ",pEQSellOrd->sSymbol);
                strcat(sClause2,sTempClause2);
	
	}
	if(pEQSellOrd->cProduct != '%')
	{
		logDebug2("If condition for Product");
		logDebug2("Product is %c",pEQSellOrd->cProduct);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_PRODUCT_ID like \"%c\" ",pEQSellOrd->cProduct);
		strcat(sClause,sTempClause);
		
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_PRODUCT_ID like \"%c\" ",pEQSellOrd->cProduct);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_PRODUCT_ID like \"%c\" ",pEQSellOrd->cProduct);
                strcat(sClause2,sTempClause2);
	}
	else
	{	
		logDebug2("Else condition for Product");
                logDebug2("Product is %c",pEQSellOrd->cProduct);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_PRODUCT_ID like \"%c\" ",pEQSellOrd->cProduct);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_PRODUCT_ID like \"%c\" ",pEQSellOrd->cProduct);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_PRODUCT_ID like \"%c\" ",pEQSellOrd->cProduct);
                strcat(sClause2,sTempClause2);
	}	


	if(strcmp(pEQSellOrd->sInstrument,SELECT_ALL)== 0)
	{
		logDebug2("IF conndition for Instrument");
		logDebug2("Instrument value is %s",pEQSellOrd->sInstrument);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
		strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause2,sTempClause2);

	}
	else
	{
		logDebug2("Else conndition for Instrument");
                logDebug2("Instrument value is %s",pEQSellOrd->sInstrument);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause2,sTempClause2);
	}
	if(pEQSellOrd->cSource != '%')
	{
		logDebug2("If condition for Source");
		logDebug2("Source is %c",pEQSellOrd->cSource);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_SOURCE_FLG like \"%c\" ",pEQSellOrd->cSource);
		strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SOURCE_FLG like \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SOURCE_FLG like \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause2,sTempClause2);

	}
	/**else
	{
		logDebug2("Else condition for Source");
                logDebug2("Source is %c",pEQSellOrd->cSource);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SOURCE_FLG like \"%c\" ",pEQSellOrd->ReqHeader.cSource);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SOURCE_FLG like \"%c\" ",pEQSellOrd->ReqHeader.cSource);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SOURCE_FLG like \"%c\" ",pEQSellOrd->ReqHeader.cSource);
                strcat(sClause2,sTempClause2);

	}**/
	if(strcmp(pEQSellOrd->sPlaceBy,SELECT_ALL) )
	{
		logDebug2("If condition for PlaceBy");
		logDebug2("Entity is %s",pEQSellOrd->sPlaceBy);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND EQ_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
		strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause2,sTempClause2);
	} 	
	//if(strcmp(pEQSellOrd->sOrdStatus,SELECT_ALL))
	if(strcmp(pEQSellOrd->sOrdStatus,SELECT_ALL) == 0)
	{
 		logDebug2("If condition for Order status");
		logDebug2("OrderStatus is %s",pEQSellOrd->sOrdStatus);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
			if(strcmp(pEQSellOrd->sOrdStatus,"Pending") == 0)
			{
				sprintf(sTempClause," AND L.EQ_MSG_CODE IN (%d) AND L.EQ_REM_QTY = L.EQ_TOTAL_QTY",TC_INT_OE_CONF_RESP);
				strcat(sClause,sTempClause);

      				sprintf(sTempClause1," AND M.DRV_MSG_CODE IN (%d) AND M.DRV_REM_QTY = M.DRV_TOTAL_QTY",TC_INT_OE_CONF_RESP);
                                strcat(sClause1,sTempClause1);

				sprintf(sTempClause2," AND N.COMM_MSG_CODE IN (%d) AND N.COMM_REM_QTY = N.COMM_TOTAL_QTY",TC_INT_OE_CONF_RESP);
                                strcat(sClause2,sTempClause2);
			}
			else if(strcmp(pEQSellOrd->sOrdStatus,"Pend/Mod") == 0 )
			{
				sprintf(sTempClause," AND L.EQ_MSG_CODE IN(2073, 2074 ,2212 )");
				strcat(sClause,sTempClause);

				sprintf(sTempClause1," AND M.DRV_MSG_CODE IN(2073, 2074 ,2212 )");
                                strcat(sClause1,sTempClause1);

				sprintf(sTempClause2," AND N.COMM_MSG_CODE IN(2073, 2074 ,2212 )");
                                strcat(sClause2,sTempClause2);
			}
			else if (strcmp(pEQSellOrd->sOrdStatus,"Modified") == 0)
			{
				sprintf(sTempClause," AND L.EQ_MSG_CODE IN (%d) AND L.EQ_REM_QTY = L.EQ_TOTAL_QTY",TC_INT_OM_CONF_RESP);
				strcat(sClause,sTempClause);

                                sprintf(sTempClause1," AND M.DRV_MSG_CODE IN (%d) AND M.DRV_REM_QTY = M.DRV_TOTAL_QTY",TC_INT_OM_CONF_RESP);
                                strcat(sClause1,sTempClause1);

				sprintf(sTempClause2," AND N.COMM_MSG_CODE IN (%d) AND N.COMM_REM_QTY = N.COMM_TOTAL_QTY",TC_INT_OM_CONF_RESP);
                                strcat(sClause2,sTempClause2);
			}
			else if (strcmp(pEQSellOrd->sOrdStatus,"Triggered") == 0)
			{
				sprintf(sTempClause," AND L.EQ_MSG_CODE IN (%d)",TC_INT_SL_ORDER_TRIG_RESP);
				strcat(sClause,sTempClause);

   				sprintf(sTempClause1," AND M.DRV_MSG_CODE IN (%d)",TC_INT_SL_ORDER_TRIG_RESP);
                                strcat(sClause1,sTempClause1);

				sprintf(sTempClause2," AND N.COMM_MSG_CODE IN (%d)",TC_INT_SL_ORDER_TRIG_RESP);
                                strcat(sClause2,sTempClause2);
			}	
			else if (strcmp(pEQSellOrd->sOrdStatus,"Part-Traded") == 0)
			{
				sprintf(sTempClause," AND((L.EQ_MSG_CODE IN(2073, 2074, 2212)) AND(L.EQ_REM_QTY <> L.EQ_TOTAL_QTY) )");
				strcat(sClause,sTempClause);

				sprintf(sTempClause1," AND((M.DRV_MSG_CODE IN(2073, 2074, 2212)) AND(M.DRV_REM_QTY <> M.DRV_TOTAL_QTY) )");
                                strcat(sClause1,sTempClause1);
	
				sprintf(sTempClause2," AND((N.COMM_MSG_CODE IN(2073, 2074, 2212)) AND(N.COMM_REM_QTY <> N.COMM_TOTAL_QTY) )");
                                strcat(sClause2,sTempClause2);
			}	
			else if (strcmp(pEQSellOrd->sOrdStatus,"O-Pending") == 0)
			{
				sprintf(sTempClause," AND L.EQ_MSG_CODE = (5112)");
				strcat(sClause,sTempClause);

				sprintf(sTempClause1," AND M.DRV_MSG_CODE = (5112)");
                                strcat(sClause1,sTempClause1);

				sprintf(sTempClause2," AND N.COMM_MSG_CODE = (5112)");
                                strcat(sClause2,sTempClause2);
			}	
			else if (strcmp(pEQSellOrd->sOrdStatus,"O-Modified") == 0) 
			{
				sprintf(sTempClause,"AND L.EQ_MSG_CODE = (5113)");
				strcat(sClause,sTempClause);

				
				sprintf(sTempClause1,"AND M.DRV_MSG_CODE = (5113)");
                                strcat(sClause1,sTempClause1);

				sprintf(sTempClause2,"AND N.COMM_MSG_CODE = (5113)");
                                strcat(sClause2,sTempClause2);
			}	
			
	}


 	 else
        {
                logDebug2("else condition for Order status");
                logDebug2("OrderStatus is %s",pEQSellOrd->sOrdStatus);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                        if(strcmp(pEQSellOrd->sOrdStatus,"Pending") == 0)
                        {
                                sprintf(sTempClause," AND L.EQ_MSG_CODE IN (%d) AND L.EQ_REM_QTY = L.EQ_TOTAL_QTY",TC_INT_OE_CONF_RESP);
                                strcat(sClause,sTempClause);

                                sprintf(sTempClause1," AND M.DRV_MSG_CODE IN (%d) AND M.DRV_REM_QTY = M.DRV_TOTAL_QTY",TC_INT_OE_CONF_RESP);
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2," AND N.COMM_MSG_CODE IN (%d) AND N.COMM_REM_QTY = N.COMM_TOTAL_QTY",TC_INT_OE_CONF_RESP);
                                strcat(sClause2,sTempClause2);
                        }
                        else if(strcmp(pEQSellOrd->sOrdStatus,"Pend/Mod") == 0)
                        {
                                sprintf(sTempClause," AND L.EQ_MSG_CODE IN(2073, 2074 ,2212 )");
                                strcat(sClause,sTempClause);

                                sprintf(sTempClause1," AND M.DRV_MSG_CODE IN(2073, 2074 ,2212 )");
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2," AND N.COMM_MSG_CODE IN(2073, 2074 ,2212 )");
                                strcat(sClause2,sTempClause2);
                        }
                        else if (strcmp(pEQSellOrd->sOrdStatus,"Modified") == 0)
                        {
                                sprintf(sTempClause," AND L.EQ_MSG_CODE IN (%d) AND L.EQ_REM_QTY = L.EQ_TOTAL_QTY",TC_INT_OM_CONF_RESP);
                                strcat(sClause,sTempClause);

				 sprintf(sTempClause1," AND M.DRV_MSG_CODE IN (%d) AND M.DRV_REM_QTY = M.DRV_TOTAL_QTY",TC_INT_OM_CONF_RESP);
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2," AND N.COMM_MSG_CODE IN (%d) AND N.COMM_REM_QTY = N.COMM_TOTAL_QTY",TC_INT_OM_CONF_RESP);
                                strcat(sClause2,sTempClause2);
                        }
                        else if (strcmp(pEQSellOrd->sOrdStatus,"Triggered") == 0)
                        {
                                sprintf(sTempClause," AND L.EQ_MSG_CODE IN (%d)",TC_INT_SL_ORDER_TRIG_RESP);
                                strcat(sClause,sTempClause);

                                sprintf(sTempClause1," AND M.DRV_MSG_CODE IN (%d)",TC_INT_SL_ORDER_TRIG_RESP);
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2," AND N.COMM_MSG_CODE IN (%d)",TC_INT_SL_ORDER_TRIG_RESP);
                                strcat(sClause2,sTempClause2);
                        }
                        else if (strcmp(pEQSellOrd->sOrdStatus,"Part-Traded") == 0)
                        {
                                sprintf(sTempClause," AND((L.EQ_MSG_CODE IN(2073, 2074, 2212)) AND(L.EQ_REM_QTY <> L.EQ_TOTAL_QTY) )");
                                strcat(sClause,sTempClause);

                                sprintf(sTempClause1," AND((M.DRV_MSG_CODE IN(2073, 2074, 2212)) AND(M.DRV_REM_QTY <> M.DRV_TOTAL_QTY) )");
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2," AND((N.COMM_MSG_CODE IN(2073, 2074, 2212)) AND(N.COMM_REM_QTY <> N.COMM_TOTAL_QTY) )");
	
				}
                        else if (strcmp(pEQSellOrd->sOrdStatus,"O-Pending") == 0)
                        {
                                sprintf(sTempClause," AND L.EQ_MSG_CODE = (5112)");
                                strcat(sClause,sTempClause);

                                sprintf(sTempClause1," AND M.DRV_MSG_CODE = (5112)");
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2," AND N.COMM_MSG_CODE = (5112)");
                                strcat(sClause2,sTempClause2);
                        }
                        else if (strcmp(pEQSellOrd->sOrdStatus,"O-Modified") == 0)
                        {
                                sprintf(sTempClause,"AND L.EQ_MSG_CODE = (5113)");
                                strcat(sClause,sTempClause);


                                sprintf(sTempClause1,"AND M.DRV_MSG_CODE = (5113)");
                                strcat(sClause1,sTempClause1);

                                sprintf(sTempClause2,"AND N.COMM_MSG_CODE = (5113)");
                                strcat(sClause2,sTempClause2);
                        }

        }




	if(pEQSellOrd->iQuantity_val != -1)
	{
		logDebug2("If condition for Quantity val");
		logDebug2("Quantity is %d",pEQSellOrd->iQuantity_val);
		memset(sTempOuter,'\0',MAX_QUERY_SIZE);                                          //Serial number changed, we put these in outer 
                sprintf(sTempOuter," AND A.EQ_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter,sTempOuter);

		memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter1," AND B.DRV_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter1,sTempOuter1);
	
		memset(sTempOuter2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter2," AND C.COMM_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter2,sTempOuter2);

	}
	if(pEQSellOrd->fOrder_val != -1)	
	{
		logDebug2("If condition for Order_val");
		logDebug2("Order val is %f",pEQSellOrd->fOrder_val);
		 memset(sTempOuter,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter," AND (A.EQ_ORDER_PRICE * A.EQ_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter,sTempOuter);

		 memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter1," AND (B.DRV_ORDER_PRICE * B.DRV_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter1,sTempOuter1);

		 memset(sTempOuter2,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter2," AND (C.COMM_ORDER_PRICE * C.COMM_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter2,sTempOuter2);
	}
        logDebug2("sClause  :%s:",sClause);
	logDebug2("sClause1 :%s:",sClause1);
	logDebug2("sClause2 :%s:",sClause2);

	logDebug2("sClauseOuter is :%s:",sClauseOuter);
	logDebug2("sClauseOuter1 is :%s:",sClauseOuter1);
	logDebug2("sClauseOuter2 is :%s:",sClauseOuter2);
	logDebug2("cIntradayFlag :%c:",cIntradayFlag);

        
        sprintf(sSelQry,"SELECT  ORDER_NO,\
                        SERIAL_NO,\
                        SCRIP_CODE,\
                        MKT_TYPE,\
                        EXCH_ID,\
                        ENTITY_ID,\
                        CLIENT_ID,\
                        BUY_SELL_IND,\
                        TOTAL_QTY,\
                        REM_QTY,\
                        DISC_QTY,\
                        DISC_REM_QTY,\
			TOTAL_TRADED_QTY,\
                        ORDER_PRICE,\
                        TRIGGER_PRICE,\
                        VALIDITY,\
                        ORDER_TYPE,\
                        USER_ID,\
                        MIN_FILL_QTY,\
                        PRO_CLIENT,\
                        USER_TYPE,\
                        REMARKS,\
                        SOURCE_FLG,\
                        PRODUCT_ID,\
                        MSG_CODE,\
                        SEGMENT ,\
                        ALGO_ORDER_NO ,\
                        STRATEGY_ID ,\
                        ORDER_OFFON ,\
			PAN_NO,\
                        PARTICIPANT_TYPE,\
                        SETTLOR,\
                        MKT_PROTECT_FLG,\
                        MKT_PROTECT_VAL,\
                        GTC_FLG,\
                        ENCASH_FLG,\
                        GROUP_ID,\
                        REMARKS1,\
                        REMARKS2\
             FROM   (           \
                        SELECT A.EQ_ORDER_NO   AS   ORDER_NO ,\
                        A.EQ_SERIAL_NO  AS   SERIAL_NO ,\
                        A.EQ_SCRIP_CODE AS   SCRIP_CODE,\
                        A.EQ_MKT_TYPE   AS   MKT_TYPE,\
                        A.EQ_EXCH_ID    AS   EXCH_ID ,\
                        A.EQ_ENTITY_ID  AS ENTITY_ID  ,\
                        A.EQ_CLIENT_ID  AS CLIENT_ID,\
                        A.EQ_BUY_SELL_IND  AS BUY_SELL_IND ,\
                        A.EQ_TOTAL_QTY  AS TOTAL_QTY ,\
                        A.EQ_REM_QTY  AS REM_QTY,\
                        A.EQ_DISC_QTY AS DISC_QTY,\
                        A.EQ_DISC_REM_QTY  AS DISC_REM_QTY,\
                        A.EQ_TOTAL_TRADED_QTY AS TOTAL_TRADED_QTY,\
                        A.EQ_ORDER_PRICE  AS ORDER_PRICE ,\
                        A.EQ_TRIGGER_PRICE  AS TRIGGER_PRICE ,\
                        A.EQ_VALIDITY  AS VALIDITY,\
                        A.EQ_ORDER_TYPE AS ORDER_TYPE,\
                        A.EQ_USER_ID AS USER_ID,\
                        A.EQ_MIN_FILL_QTY AS MIN_FILL_QTY,\
                        A.EQ_PRO_CLIENT AS PRO_CLIENT ,\
                        A.EQ_USER_TYPE AS USER_TYPE,\
                        A.EQ_REMARKS AS REMARKS,\
                        A.EQ_SOURCE_FLG AS SOURCE_FLG ,\
                        A.EQ_PRODUCT_ID  AS PRODUCT_ID  ,\
                        A.EQ_MSG_CODE AS MSG_CODE ,\
                        A.EQ_SEGMENT AS SEGMENT,\
                        A.EQ_ALGO_ORDER_NO AS ALGO_ORDER_NO,\
                        A.EQ_STRATEGY_ID AS STRATEGY_ID,\
                        A.EQ_ORDER_OFFON AS ORDER_OFFON ,\
                        A.EQ_PAN_NO AS PAN_NO,\
                        A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE  ,\
                        A.EQ_SETTLOR AS SETTLOR ,\
                        A.EQ_MKT_PROTECT_FLG AS  MKT_PROTECT_FLG ,\
                        A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL  ,\
                        A.EQ_GTC_FLG AS GTC_FLG ,\
                        A.EQ_ENCASH_FLG AS ENCASH_FLG  ,\
                        A.EQ_GROUP_ID AS GROUP_ID ,\
                        A.EQ_REMARKS1 AS REMARKS1,\
                        A.EQ_REMARKS2 AS  REMARKS2\
                        FROM  \  
			EQ_ORDERS A , (SELECT L.EQ_ORDER_NO AS ORD,MAX(L.EQ_SERIAL_NO) AS SER FROM EQ_ORDERS L WHERE 1=1 %s\ 
                        GROUP BY L.EQ_ORDER_NO)AS X\
                        WHERE \
                        (A.EQ_SERIAL_NO =X.SER)\
                        AND  (A.EQ_ORDER_NO = X.ORD) %s \
                        UNION ALL\
         		SELECT B.DRV_ORDER_NO AS ORDER_NO ,\
       			B.DRV_SERIAL_NO AS SERIAL_NO ,\
       			B.DRV_SCRIP_CODE AS SCRIP_CODE,\
       			B.DRV_MKT_TYPE AS MKT_TYPE,\
       			B.DRV_EXCH_ID AS EXCH_ID,\
       			B.DRV_ENTITY_ID AS ENTITY_ID,\
       			B.DRV_CLIENT_ID AS CLIENT_ID,\
       			B.DRV_BUY_SELL_IND AS BUY_SELL_IND ,\
       			B.DRV_TOTAL_QTY AS TOTAL_QTY ,\
      		 	B.DRV_REM_QTY AS REM_QTY ,\
       			B.DRV_DISC_QTY AS DISC_QTY  ,\
       			B.DRV_DISC_REM_QTY AS DISC_REM_QTY  ,\
       			B.DRV_TOTAL_TRADED_QTY AS  TOTAL_TRADED_QTY,\
       			B.DRV_ORDER_PRICE AS ORDER_PRICE ,\
       			B.DRV_TRIGGER_PRICE AS TRIGGER_PRICE  ,\
       			B.DRV_VALIDITY AS VALIDITY  ,\
       			B.DRV_ORDER_TYPE AS ORDER_TYPE  ,\
       			B.DRV_USER_ID AS USER_ID  ,\
       			B.DRV_MIN_FILL_QTY AS  MIN_FILL_QTY ,\
       			B.DRV_PRO_CLIENT AS  PRO_CLIENT,\
       			B.DRV_USER_TYPE AS  USER_TYPE,\
       			B.DRV_REMARKS AS REMARKS ,\
       			B.DRV_SOURCE_FLG AS SOURCE_FLG  ,\
       			B.DRV_PRODUCT_ID AS PRODUCT_ID  ,\
       			B.DRV_MSG_CODE AS MSG_CODE  ,\
       			B.DRV_SEGMENT AS SEGMENT ,\
       			B.DRV_ALGO_ID AS ALGO_ORDER_NO , \ 
       			B.DRV_STRATEGY_ID AS STRATEGY_ID  ,\
       			B.DRV_ORDER_OFFON AS ORDER_OFFON  ,\
       			B.DRV_PAN_NO AS PAN_NO ,\
       			B.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE  ,\
       			B.DRV_SETTLOR AS  SETTLOR,\
       			B.DRV_MKT_PROTECT_FLG AS  MKT_PROTECT_FLG,\
       			B.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL  ,\
       			B.DRV_GTC_FLG AS GTC_FLG  ,\
       			B.DRV_ENCASH_FLG AS ENCASH_FLG ,\
       			B.DRV_GROUP_ID AS GROUP_ID ,\
       			B.DRV_REMARKS1 AS REMARKS1 ,\
       			B.DRV_REMARKS2 AS REMARKS2\
        		FROM\
			DRV_ORDERS B , (SELECT M.DRV_ORDER_NO AS ORD,MAX(M.DRV_SERIAL_NO) AS SER FROM DRV_ORDERS M WHERE 1=1 %s\
                        GROUP BY M.DRV_ORDER_NO) AS Y\
       			WHERE\
                      	(B.DRV_SERIAL_NO =Y.SER)\
                        AND  (B.DRV_ORDER_NO = Y.ORD) %s\ 
                    	UNION ALL\ 
       			SELECT  C.COMM_ORDER_NO AS ORDER_NO ,\
			C.COMM_SERIAL_NO AS SERIAL_NO ,\
        		C.COMM_SCRIP_CODE AS  SCRIP_CODE,\
        		C.COMM_MKT_TYPE AS MKT_TYPE ,\
        		C.COMM_EXCH_ID AS EXCH_ID ,\
        		C.COMM_ENTITY_ID AS  ENTITY_ID,\
        		C.COMM_CLIENT_ID  AS  CLIENT_ID,\
        		C.COMM_BUY_SELL_IND  AS BUY_SELL_IND,\
        		C.COMM_TOTAL_QTY AS TOTAL_QTY ,\
       		 	C.COMM_REM_QTY  AS  REM_QTY,\
        		C.COMM_DISC_QTY AS DISC_QTY  ,\
        		C.COMM_DISC_REM_QTY AS  DISC_REM_QTY   ,\
        		C.COMM_TOTAL_TRADED_QTY  AS TOTAL_TRADED_QTY ,\
        		C.COMM_ORDER_PRICE  AS ORDER_PRICE ,\
        		C.COMM_TRIGGER_PRICE   AS TRIGGER_PRICE ,\
        		C.COMM_VALIDITY  AS VALIDITY  ,\
        		C.COMM_ORDER_TYPE  AS ORDER_TYPE ,\
        		C.COMM_USER_ID  AS  USER_ID ,\
        		C.COMM_MIN_FILL_QTY  AS  MIN_FILL_QTY,\
        		C.COMM_PRO_CLIENT  AS PRO_CLIENT ,\
        		C.COMM_USER_TYPE  AS USER_TYPE ,\
        		C.COMM_REMARKS  AS REMARKS,\
        		C.COMM_SOURCE_FLG  AS SOURCE_FLG ,\
        		C.COMM_PRODUCT_ID  AS PRODUCT_ID ,\
        		C.COMM_MSG_CODE AS MSG_CODE ,\
        		C.COMM_SEGMENT AS SEGMENT ,\
        		C.COMM_ALGO_ID  AS ALGO_ORDER_NO, \
        		C.COMM_STRATEGY_ID AS   STRATEGY_ID,\
        		C.COMM_ORDER_OFFON AS ORDER_OFFON ,\
        		C.COMM_PAN_NO  AS  PAN_NO,\
        		C.COMM_PARTICIPANT_TYPE AS  PARTICIPANT_TYPE ,\
        		C.COMM_SETTLOR   AS SETTLOR  ,\
        		C.COM_MKT_PROTECT_FLG   AS  MKT_PROTECT_FLG,\
        		C.COMM_MKT_PROTECT_VAL  AS MKT_PROTECT_VAL ,\
        		C.COMM_GTC_FLG  AS   GTC_FLG ,\
        		C.COMM_ENCASH_FLG  AS  ENCASH_FLG,\
        		C.COMM_GROUP_ID  AS  GROUP_ID,\               
        		C.COMM_REMARKS1  AS REMARKS1 ,\
        		C.COMM_REMARKS2 AS REMARKS2\
        		FROM COMM_ORDERS  C,(SELECT N.COMM_ORDER_NO AS ORD,MAX(N.COMM_SERIAL_NO) AS SER FROM COMM_ORDERS N WHERE 1=1  %s\
                        GROUP BY N.COMM_ORDER_NO) AS Z\
        		WHERE \
	                (C.COMM_SERIAL_NO =Z.SER)\
                        AND  (C.COMM_ORDER_NO = Z.ORD) %s\
                       ) AS P;",sClause,sClauseOuter, sClause1,sClauseOuter1, sClause2,sClauseOuter2 );
 
	printf("sSelQry :%s: \n",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fBulkCnlEqPendingOrdQuery.");
		exit(ERROR);

	}
        else 
        {
		logDebug2("******Query Executed Successfully******");
        }
	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for (i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);	
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[36]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iMsgCode = atoi(Row[24]);
			if (pEOrdReq.ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY || pEOrdReq.ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY )
                        {
                                pEOrdReq.ReqHeader.iMsgCode = TC_INT_OFF_ORDER_CANCEL;
                        }
                        else
                        {
                                pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
                        }
			
			if (strcmp(pEQSellOrd->sOrdStatus,"O-Pending") == 0 || strcmp(pEQSellOrd->sOrdStatus,"O-Modified") == 0)
                        {
				pEOrdReq.ReqHeader.iMsgCode = TC_INT_OFF_ORDER_CANCEL;
                        }
			else
			{
				pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			}
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);

			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = '1';//Row[19][0];

			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iStratergyId= 0;
			pEOrdReq.iMinFillQty = atoi(Row[18]);
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			pEOrdReq.cUserType = ADMIN_TYPE ;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);


			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pEOrdReq.cMarkProFlag= Row[32][0];
			pEOrdReq.fMarkProVal= atof(Row[33]);
			pEOrdReq.cParticipantType= Row[30][0];
			strncpy(pEOrdReq.sSettlor,Row[31],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[34][0];
			pEOrdReq.cEncashFlag= Row[35][0];
			pEOrdReq.iGrpId = atoi(Row[36]);
			strncpy(pEOrdReq.sPanID,Row[29],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,Row[37],PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,Row[38],CHANNEL_LEN);
			logDebug2("DB VAL :%s:%c:%s:",Row[29],Row[30][0],Row[31]);
			logDebug2("sSettler :%s:%d:",pEOrdReq.sSettlor,SETTLOR_LEN);
			logDebug2("sPandId :%s:%d:",pEOrdReq.sPanID,INT_PAN_LEN);
			logDebug2("cParticipantType :%c:",pEOrdReq.cParticipantType);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.sClientId:%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT  [fBulkCnlEqPendingOrd]");
	return TRUE;
}

BOOL fSqrOffEqBulkOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffEqBulkOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32          iNoOfRec = 0;
	LONG32          i = 0, iQty = 0;

	//CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR sQuery  [EXTRA_DOUBLE_MAX_QUERY_SIZE];

	struct  SQROFF_INSTRUCTION_REQUEST	*pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	CHAR            sClause[MAX_QUERY_SIZE];
	CHAR            sClause1[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);
	memset(sClause1,'\0',MAX_QUERY_SIZE);
	CHAR            sTempClause[MAX_QUERY_SIZE];
	CHAR  sNetVal[NET_VAL_LEN];
	CHAR  sNetQty[NET_QTY_LEN];
	memset(sNetVal,'\0',NET_VAL_LEN);
	memset(sNetQty,'\0',NET_QTY_LEN);
	memset(sQuery,'\0',EXTRA_DOUBLE_MAX_QUERY_SIZE);

	pEQSellOrd = (struct  SQROFF_INSTRUCTION_REQUEST *)RcvMsg ;
	
	logDebug2("Received Bulk SquareOff request from admin");
        logDebug2("pEQSellOrd->ReqHeader.sExcgId :%s:",pEQSellOrd->ReqHeader.sExcgId);
        logDebug2("pEQSellOrd->ReqHeader.cSegment :%c:",pEQSellOrd->ReqHeader.cSegment);
        logDebug2("pEQSellOrd->ReqHeader.cSource :%c:",pEQSellOrd->ReqHeader.cSource);
        logDebug2("pEQSellOrd->sClientId :%s:",pEQSellOrd->sClientId);
        logDebug2("pEQSellOrd->sSymbol :%s:",pEQSellOrd->sSymbol);
        logDebug2("pEQSellOrd->cProduct :%c:",pEQSellOrd->cProduct);
        logDebug2("pEQSellOrd->sInstrument :%s:",pEQSellOrd->sInstrument);
        logDebug2("pEQSellOrd->sPosDayCarryFwd :%s:",pEQSellOrd->sPosDayCarryFwd);
        logDebug2("pEQSellOrd->sNetQtyChk :%s:",pEQSellOrd->sNetQtyChk);
        logDebug2("pEQSellOrd->iOptQtyChk :%d:",pEQSellOrd->iOptQtyChk);
        logDebug2("pEQSellOrd->iOptValChk:%d:",pEQSellOrd->iOptValChk);
        logDebug2("pEQSellOrd->sNetValChk:%s:",pEQSellOrd->sNetValChk);

	
	if(strcmp(pEQSellOrd->sClientId,SELECT_ALL))
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND NPT_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
		strcat(sClause,sTempClause);
	}

	/**if(strcmp(pEQSellOrd->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND NPT_EXCH_ID =  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
		strcat(sClause,sTempClause);

	}**/
	if(pEQSellOrd->ReqHeader.cSegment != '%')
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND NPT_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
		strcat(sClause,sTempClause);

	}
	if(strcmp(pEQSellOrd->sSymbol,SELECT_ALL))
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND NPT_SYMBOL =  \"%s\" ",pEQSellOrd->sSymbol);
		strcat(sClause,sTempClause);

	}
	if(pEQSellOrd->cProduct != '%')
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND NPT_PROD_ID = \"%c\" ",pEQSellOrd->cProduct);
		strcat(sClause,sTempClause);

	}
	if(strcmp(pEQSellOrd->sInstrument,SELECT_ALL))
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		sprintf(sTempClause," AND NPT_INSTRUMENT = \"%s\" ",pEQSellOrd->sInstrument);
		strcat(sClause,sTempClause);

	}
	if(strcmp(pEQSellOrd->sPosDayCarryFwd,SELECT_ALL)&&(strcmp(pEQSellOrd->sPosDayCarryFwd,INTEROPS_POSITION)))
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		if(strcmp(pEQSellOrd->sPosDayCarryFwd,DAY_POSITION))
		{
			sprintf(sTempClause," AND NPT_REF_ID = 0  ");
		}
		else if(strcmp(pEQSellOrd->sPosDayCarryFwd,CARRY_POSITION))
		{
			sprintf(sTempClause," AND NPT_REF_ID  < 0 ");
		}	
		strcat(sClause,sTempClause);

	}
	
	if((strcmp(pEQSellOrd->sPosDayCarryFwd,INTEROPS_POSITION)))
	{
		strncpy(sNetVal,"NET_VAL",NET_VAL_LEN);
		strncpy(sNetQty,"NET_QTY",NET_VAL_LEN);
	}
	else
	{
		strncpy(sNetVal,"NPT_NET_VAL",NET_VAL_LEN);
		strncpy(sNetQty,"NPT_NET_QTY",NET_VAL_LEN);
	}
	
	if(strcmp(pEQSellOrd->sNetQtyChk,SELECT_ALL))
	{
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
		
		if((pEQSellOrd->iOptQtyChk) > 0)
		{
			switch(pEQSellOrd->iOptQtyChk)
			{
				case 1 : 
					//sprintf(sTempClause," AND NPT_NET_QTY  > %s ",pEQSellOrd->sNetQtyChk);
					sprintf(sTempClause," AND %s  > %s ",sNetQty,pEQSellOrd->sNetQtyChk);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 2 :
					sprintf(sTempClause," AND %s >= %s ",sNetQty,pEQSellOrd->sNetQtyChk);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 3 :
					sprintf(sTempClause," AND %s < %s ",sNetQty,pEQSellOrd->sNetQtyChk);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 4 :
					sprintf(sTempClause," AND %s <= %s ",sNetQty,pEQSellOrd->sNetQtyChk);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 5 :
					sprintf(sTempClause," AND ABS(%s) > %s ",sNetQty,pEQSellOrd->sNetQtyChk);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 6 :
					sprintf(sTempClause," AND ABS(%s) < %s ",sNetQty,pEQSellOrd->sNetQtyChk);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 7 :
					sprintf(sTempClause," AND %s <> 0 ",sNetQty);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				case 8 :
					sprintf(sTempClause," AND %s = 0 ",sNetQty);
					logDebug2("sTempClause :%s:",sTempClause);
					break;
				
				default :
					sprintf(sTempClause," AND 1=1");
					logDebug2("sTempClause :%s:",sTempClause);
					break;
			}
		}
		strcat(sClause1,sTempClause);
	}
	if((pEQSellOrd->iOptQtyChk) == 7 || (pEQSellOrd->iOptQtyChk) == 8)
	{
		switch(pEQSellOrd->iOptQtyChk)
		{
			case 7 :
				sprintf(sTempClause," AND %s <> 0 ",sNetQty);
	                        logDebug2("sTempClause :%s:",sTempClause);
        	                break;
                	case 8 :
                        	sprintf(sTempClause," AND %s = 0 ",sNetQty);
	                        logDebug2("sTempClause :%s:",sTempClause);
        	                break;
			default :
				sprintf(sTempClause," AND 1=1");
				logDebug2("sTempClause :%s:",sTempClause);
				break;
		}
		strcat(sClause1,sTempClause);

	}

	if(strcmp(pEQSellOrd->sNetValChk,SELECT_ALL))
        {
		memset(sTempClause,'\0',MAX_QUERY_SIZE);

                if((pEQSellOrd->iOptValChk) > 0)
                {
                        switch(pEQSellOrd->iOptValChk)
                        {
                                case 1 :
                                        sprintf(sTempClause," AND %s  > %s ",sNetVal,pEQSellOrd->sNetValChk);
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;
                                case 2 :
                                        sprintf(sTempClause," AND %s >= %s ",sNetVal,pEQSellOrd->sNetValChk);
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;
                                case 3 :
                                        sprintf(sTempClause," AND %s < %s ",sNetVal,pEQSellOrd->sNetValChk);
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;
                                case 4 :
                                        sprintf(sTempClause," AND %s <= %s ",sNetVal,pEQSellOrd->sNetValChk);
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;
                                case 5 :
                                        sprintf(sTempClause," AND ABS(%s) > %s ",sNetVal,pEQSellOrd->sNetValChk);
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;
                                case 6 :
                                        sprintf(sTempClause," AND ABS(%s) < %s ",sNetVal,pEQSellOrd->sNetValChk);
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;

                                default :
                                        sprintf(sTempClause," AND 1=1");
                                        logDebug2("sTempClause :%s:",sTempClause);
                                        break;
                        }
                }
		strcat(sClause1,sTempClause);


        }
	
	if(!strcmp(pEQSellOrd->sPosDayCarryFwd,INTEROPS_POSITION))
	{
		sprintf(sQuery,"SELECT  (CASE '%s' WHEN '%' THEN SECURITY_ID WHEN 'NSE' THEN IF(NPT_NSE_SCRIP='NA',SECURITY_ID,NPT_NSE_SCRIP) WHEN 'BSE' THEN IF(NPT_BSE_SCRIP='NA',SECURITY_ID,NPT_BSE_SCRIP) ELSE SECURITY_ID END)AS SECURITY_ID, MKT_TYPE, (CASE '%s' WHEN '%' THEN EXCH_ID WHEN 'NSE' THEN IF(NPT_NSE_SCRIP<>'NA','NSE',EXCH_ID) WHEN 'BSE' THEN IF(NPT_BSE_SCRIP<>'NA','BSE',EXCH_ID) ELSE EXCH_ID END) AS EXCH_ID, CLIENT_ID,  PROD_ID,  (NET_QTY) QTY_ORIGINNAL,  (NET_QTY) QTY_REMAINING,  um.USER_CODE,SEGMENT FROM  (SELECT  NPT_CLIENT_ID AS CLIENT_ID,  NPT_SECURITY_ID AS SECURITY_ID,  IFNULL(NPT_INSTRUMENT, 'NA') AS INSTRUMENT,  NPT_SYMBOL AS SYMB_SECID,  IFNULL(NPT_UNDERLAYING_CODE, 'NA') AS UNDERLAYING,  NPT_EXCH_ID AS EXCH_ID,  IFNULL(NPT_STRIKE_PRICE, 0) AS STRIKE_PRICE,  IFNULL(NPT_OPTION_TYPE, 'NA') AS OPTION_TYPE,  NPT_SEGMENT AS SEGMENT,  NPT_MKT_TYPE AS MKT_TYPE,  NPT_SYMBOL AS SYMBOL, NPT_TOT_BUY_QTY AS TOT_BUY_QTY,  NPT_TOT_BUY_QTY_CF AS TOT_BUY_QTY_CF,  NPT_TOT_BUY_QTY_DAY AS TOT_BUY_QTY_DAY,  NPT_TOT_BUY_VAL AS TOT_BUY_VAL,  NPT_TOT_BUY_VAL_CF AS TOT_BUY_VAL_CF,  NPT_TOT_BUY_VAL_DAY AS TOT_BUY_VAL_DAY,  NPT_BUY_AVG AS BUY_AVG,  NPT_TOT_SELL_QTY AS TOT_SELL_QTY,  NPT_TOT_SELL_QTY_CF AS TOT_SELL_QTY_CF,  NPT_TOT_SELL_QTY_DAY AS TOT_SELL_QTY_DAY,  NPT_TOT_SELL_VAL AS TOT_SELL_VAL,  NPT_TOT_SELL_VAL_CF AS TOT_SELL_VAL_CF,  NPT_TOT_SELL_VAL_DAY AS TOT_SELL_VAL_DAY,  NPT_SELL_AVG AS SELL_AVG,  NPT_NET_QTY AS NET_QTY,  NPT_NET_VAL AS NET_VAL,  NPT_NET_AVG AS NET_AVG,  NPT_GROSS_QTY AS GROSS_QTY,  NPT_GROSS_VAL AS GROSS_VAL,  NPT_PROD_ID AS PROD_ID,  NPT_REALISED_PROFIT AS REALISED_PROFIT,  NPT_REF_ID AS REF_ID,  NPT_MTM AS MTM,  IFNULL(NPT_GROUP_SERIES, 'NA') AS GROUP_SERIES,  IFNULL(NPT_LOT, 1) AS SEM_NSE_REGULAR_LOT,  NPT_LTP AS LAST_TRADED_PRICE,  IFNULL(NPT_CROSS_CUR_FLAG, 'N') AS CROSS_CUR_FLAG,  IFNULL(NPT_RBI_REFERENCE_RATE, 1) AS RBI_REFERENCE_RATE,  IFNULL(NPT_MCX_MULTIPLIER, 1) AS COMM_MULTIPLIER,  NPT_CUSTOM_SYMBOL AS CUSTOM_SYMBOL,  NPT_ISIN_CODE AS ISIN,  NPT_EXCH_INSTRUMENT_TYPE AS EXCH_INSTRUMENT_TYPE,NPT_NSE_SCRIP AS NPT_NSE_SCRIP,NPT_BSE_SCRIP AS NPT_BSE_SCRIP  FROM  NET_POSITION_TABLE  WHERE  	NOT (NPT_GROSS_QTY = 0 AND NPT_REALISED_PROFIT = 0)  %s ) a,  USER_MASTER um  WHERE  um.USER_ENTITY_CODE = a.client_id;",pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.sExcgId,sClause);
	}
	else
	{
		sprintf(sQuery,"SELECT  SECURITY_ID, MKT_TYPE, EXCH_ID, CLIENT_ID, PROD_ID,NET_QTY,NET_QTY,500,SEGMENT, INSTRUMENT,  symbol AS SYMB_SECID,  UNDERLAYING,   STRIKE_PRICE,  IFNULL(OPTION_TYPE, 'NA') AS OPTION_TYPE,  SEGMENT,  symbol AS SYMBOL,  EXPIRY_DATE,  TOT_BUY_QTY,  TOT_BUY_QTY_CF,  IF('A' = 'C', 0, TOT_BUY_QTY_DAY) AS TOT_BUY_QTY_DAY,  TOT_BUY_QTY_DAY,  TOT_BUY_VAL,  IF('A' = 'D', 0, TOT_BUY_VAL_CF) AS TOT_BUY_VAL_CF,  IF('A' = 'C', 0, TOT_BUY_VAL_DAY) AS TOT_BUY_VAL_DAY,  BUY_AVG,  TOT_SELL_QTY,  IF('A' = 'D', 0, TOT_SELL_QTY_CF) AS TOT_SELL_QTY_CF,  IF('A' = 'C', 0, TOT_SELL_QTY_DAY) AS TOT_SELL_QTY_DAY,  TOT_SELL_VAL,  IF('A' = 'D', 0, TOT_SELL_VAL_CF) AS TOT_SELL_VAL_CF,  IF('A' = 'C', 0, TOT_SELL_VAL_DAY) AS TOT_SELL_VAL_DAY,  SELL_AVG,  NET_VAL,  NET_AVG,  GROSS_QTY,  GROSS_VAL,  REALISED_PROFIT,  REF_ID,  0 AS MTM,  GROUP_SERIES,  SEM_NSE_REGULAR_LOT,  0 AS LTP,  CROSS_CUR_FLAG,  RBI_REFERENCE_RATE,  COMM_MULTIPLIER,  CUSTOM_SYMBOL,  ISIN,  EXCH_INSTRUMENT_TYPE,  COST_PRICE  FROM  (SELECT `MBNP`.`CLIENT_ID` AS `CLIENT_ID`,  `MBNP`.`SECURITY_ID` AS `SECURITY_ID`,  `MBNP`.`EXCH_ID` AS `EXCH_ID`,  'NL' AS `MKT_TYPE`,  SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) AS `TOT_BUY_QTY`,  SUM(`MBNP`.`BUY_QTY_CF`) AS `TOT_BUY_QTY_CF`,  SUM(`MBNP`.`BUY_QTY_DAY`) AS `TOT_BUY_QTY_DAY`,  SUM(CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) * MBNP.CURR_MULTIPLIER  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) * MBNP.COMM_MULTIPLIER)  ELSE (MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF)  END) AS TOT_BUY_VAL,  SUM(CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL_CF) * MBNP.CURR_MULTIPLIER  WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL_CF) * MBNP.COMM_MULTIPLIER  ELSE MBNP.BUY_VAL_CF  END) AS `TOT_BUY_VAL_CF`,  SUM(CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL_DAY) * MBNP.CURR_MULTIPLIER  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((MBNP.BUY_VAL_DAY) * MBNP.COMM_MULTIPLIER)  ELSE (MBNP.BUY_VAL_DAY)  END) AS `TOT_BUY_VAL_DAY`,  (CASE  WHEN  (`MBNP`.`SEGMENT_CODE` = 'C')  THEN  ROUND((CASE SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`BUY_VAL_CF` + `MBNP`.`BUY_VAL_DAY`) / SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`))  END), 4)  ELSE ROUND((CASE SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`BUY_VAL_CF` + `MBNP`.`BUY_VAL_DAY`) / SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`))  END), 2)  END) AS `BUY_AVG`,  SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`) AS `TOT_SELL_QTY`,  SUM(`MBNP`.`SELL_QTY_CF`) AS `TOT_SELL_QTY_CF`,  SUM(`MBNP`.`SELL_QTY_DAY`) AS `TOT_SELL_QTY_DAY`,  SUM(`MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_CF`) AS CF_NET_QTY,  SUM(`MBNP`.`BUY_QTY_DAY`) - SUM(`MBNP`.`SELL_QTY_DAY`) AS DAY_NET_QTY,  SUM(CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF) * MBNP.CURR_MULTIPLIER  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF) * MBNP.COMM_MULTIPLIER)  ELSE (MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF)  END) AS TOT_SELL_VAL,  SUM(CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL_CF) * MBNP.CURR_MULTIPLIER  WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL_CF) * MBNP.COMM_MULTIPLIER  ELSE MBNP.SELL_VAL_CF  END) AS `TOT_SELL_VAL_CF`,  SUM(CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL_DAY) * MBNP.CURR_MULTIPLIER  WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL_DAY) * MBNP.COMM_MULTIPLIER  ELSE (MBNP.SELL_VAL_DAY)  END) AS `TOT_SELL_VAL_DAY`,  (CASE  WHEN  (`MBNP`.`SEGMENT_CODE` = 'C')  THEN  ROUND((CASE SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`) / SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  END), 4)  ELSE ROUND((CASE SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`) / SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  END), 2)  END) AS `SELL_AVG`,  (SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)) AS `NET_QTY`,  (CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF) - SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF)) * MBNP.CURR_MULTIPLIER)  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF) - SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF)) * MBNP.COMM_MULTIPLIER)  ELSE (SUM(MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF) - SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF))  END) AS NET_VAL,  ROUND((CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL_CF) - SUM(MBNP.BUY_VAL_CF)) * MBNP.CURR_MULTIPLIER)  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL_CF) - SUM(MBNP.BUY_VAL_CF)) * MBNP.COMM_MULTIPLIER)  ELSE (SUM(MBNP.SELL_VAL_CF) - SUM(MBNP.BUY_VAL_CF))  END), 2) AS CF_NET_VAL,  ROUND((CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL_DAY) - SUM(MBNP.BUY_VAL_DAY)) * MBNP.CURR_MULTIPLIER)  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL_DAY) - SUM(MBNP.BUY_VAL_DAY)) * MBNP.COMM_MULTIPLIER)  ELSE (SUM(MBNP.SELL_VAL_DAY) - SUM(MBNP.BUY_VAL_DAY))  END), 2) AS DAY_NET_VAL,  (CASE  WHEN  (`MBNP`.`SEGMENT_CODE` = 'C')  THEN  ROUND((CASE (SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  WHEN 0 THEN 0  ELSE ((SUM(`MBNP`.`BUY_VAL_CF` + `MBNP`.`BUY_VAL_DAY`) - SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`)) / (SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)))  END), 2)  ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  WHEN 0 THEN 0  ELSE ((SUM(`MBNP`.`BUY_VAL_CF` + `MBNP`.`BUY_VAL_DAY`) - SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`)) / (SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)))  END), 2)  END) AS `NET_AVG`,  (CASE  WHEN  (`MBNP`.`SEGMENT_CODE` = 'C')  THEN  ROUND((CASE (SUM(`MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_CF`))  WHEN 0 THEN 0  ELSE ((SUM(`MBNP`.`BUY_VAL_CF`) - SUM(`MBNP`.`SELL_VAL_CF`)) / (SUM(`MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_CF`)))  END), 4)  ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_CF`))  WHEN 0 THEN 0  ELSE ((SUM(`MBNP`.`BUY_VAL_CF`) - SUM(`MBNP`.`SELL_VAL_CF`)) / (SUM(`MBNP`.`BUY_QTY_CF`) - SUM(`MBNP`.`SELL_QTY_CF`)))  END), 2)  END) AS CF_NET_AVG,  (CASE  WHEN  (`MBNP`.`SEGMENT_CODE` = 'C')  THEN  ROUND((CASE (SUM(`MBNP`.`BUY_QTY_DAY`) - SUM(`MBNP`.`SELL_QTY_DAY`))  WHEN 0 THEN 0  ELSE ((SUM(`MBNP`.`BUY_VAL_DAY`) - SUM(`MBNP`.`SELL_VAL_DAY`)) / (SUM(`MBNP`.`BUY_QTY_DAY`) - SUM(`MBNP`.`SELL_QTY_DAY`)))  END), 4)  ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY_DAY`) - SUM(`MBNP`.`SELL_QTY_DAY`))  WHEN 0 THEN 0  ELSE ((SUM(`MBNP`.`BUY_VAL_DAY`) - SUM(`MBNP`.`SELL_VAL_DAY`)) / (SUM(`MBNP`.`BUY_QTY_DAY`) - SUM(`MBNP`.`SELL_QTY_DAY`)))  END), 2)  END) AS DAY_NET_AVG,  (SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`) + SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)) AS `GROSS_QTY`,  (CASE  WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) + SUM(MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF)) * MBNP.CURR_MULTIPLIER)  WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) + SUM(MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF)) * MBNP.COMM_MULTIPLIER)  ELSE (SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) + SUM(MBNP.SELL_VAL_DAY + MBNP.SELL_VAL_CF))  END) AS GROSS_VAL,  MBNP.SEGMENT_CODE AS SEGMENT,  MBNP.PRODUCT AS PROD_ID,  (CASE  WHEN  (MBNP.SEGMENT_CODE = 'C')  THEN  (CASE  WHEN  `MBNP`.`CROSS_CUR_FLAG` = 'Y'  THEN  (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`), SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`) / SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) / SUM(MBNP.BUY_QTY_DAY + MBNP.BUY_QTY_CF))  END), 4))), 4) * MBNP.CURR_MULTIPLIER * `MBNP`.`RBI_REFERENCE_RATE`)  ELSE (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`), SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`) / SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(MBNP.BUY_VAL_DAY + MBNP.BUY_VAL_CF) / SUM(MBNP.BUY_QTY_DAY + MBNP.BUY_QTY_CF))  END), 4))), 4) * MBNP.CURR_MULTIPLIER)  END)  WHEN  (`MBNP`.`SEGMENT_CODE` = 'M')  THEN  (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`), SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`) / SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`BUY_VAL_CF` + `MBNP`.`BUY_VAL_DAY`) / SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`))  END), 2))), 2) * `MBNP`.`COMM_MULTIPLIER`)  ELSE ROUND((LEAST(SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`), SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`SELL_VAL_DAY` + `MBNP`.`SELL_VAL_CF`) / SUM(`MBNP`.`SELL_QTY_DAY` + `MBNP`.`SELL_QTY_CF`))  END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`)  WHEN 0 THEN 0  ELSE (SUM(`MBNP`.`BUY_VAL_CF` + `MBNP`.`BUY_VAL_DAY`) / SUM(`MBNP`.`BUY_QTY_DAY` + `MBNP`.`BUY_QTY_CF`))  END), 2))), 2)  END) AS `REALISED_PROFIT`,  `MBNP`.`INT_REF_ID` AS `REF_ID`,  `MBNP`.`CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,  `MBNP`.`RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,  COMM_MULTIPLIER,  INSTRUMENT,  SYMBOL,  UNDERLAYING,  STRIKE_PRICE,  OPTION_TYPE,  EXPIRY_DATE,  GROUP_SERIES,  SEM_NSE_REGULAR_LOT,  CUSTOM_SYMBOL,  ISIN,  EXCH_INSTRUMENT_TYPE,  COST_PRICE  FROM  (SELECT `DT`.`DRV_CLIENT_ID` AS `CLIENT_ID`,  `DT`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,  `DT`.`DRV_EXCH_ID` AS `EXCH_ID`,  `DT`.`DRV_SEGMENT` AS `SEGMENT_CODE`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'B'  AND `DT`.`DRV_CF_FLAG` = '0')  THEN  `DT`.`DRV_TRD_TRADE_QTY`  ELSE 0  END)) AS `BUY_QTY_DAY`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'B'  AND `DT`.`DRV_CF_FLAG` = '-1')  THEN  `DT`.`DRV_TRD_TRADE_QTY`  ELSE 0  END)) AS `BUY_QTY_CF`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'B'  AND `DT`.`DRV_CF_FLAG` = '0')  THEN  (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)  ELSE 0  END)) AS `BUY_VAL_DAY`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'B'  AND `DT`.`DRV_CF_FLAG` = '-1')  THEN  (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)  ELSE 0  END)) AS `BUY_VAL_CF`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'S'  AND `DT`.`DRV_CF_FLAG` = '0')  THEN  `DT`.`DRV_TRD_TRADE_QTY`  ELSE 0  END)) AS `SELL_QTY_DAY`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'S'  AND `DT`.`DRV_CF_FLAG` = '-1')  THEN  `DT`.`DRV_TRD_TRADE_QTY`  ELSE 0  END)) AS `SELL_QTY_CF`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'S'  AND `DT`.`DRV_CF_FLAG` = '0')  THEN  (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)  ELSE 0  END)) AS `SELL_VAL_DAY`,  SUM((CASE  WHEN  (`DT`.`DRV_BUY_SELL_IND` = 'S'  AND `DT`.`DRV_CF_FLAG` = '-1')  THEN  (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)  ELSE 0  END)) AS `SELL_VAL_CF`,  `DT`.`DRV_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,  `DT`.`DRV_SEGMENT` AS `EXCH_SEGMENT`,  `DT`.`DRV_PRODUCT_ID` AS `PRODUCT`,  `DT`.`DRV_CF_FLAG` AS `INT_REF_ID`,  `DT`.`DRV_SYMBOL` AS `SYMBOL`,  `DT`.`DRV_INSTRUMENT_NAME` AS `INSTRUMENT`,  `DT`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,  `DT`.`DRV_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,  `DT`.`DRV_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,  1 AS `COMM_MULTIPLIER`,  `DT`.`DRV_CURRENCY_MULTIPLIER` AS `CURR_MULTIPLIER`,  `DT`.`DRV_UNDERLINE_SCRIP` AS `UNDERLAYING`,  `DT`.`DRV_STRIKE_PRICE` AS `STRIKE_PRICE`,  `DT`.`DRV_OPTION_TYPE` AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  `DT`.`DRV_LOT_SIZE` AS `SEM_NSE_REGULAR_LOT`,  `DT`.`DRV_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  'NA' AS `ISIN`,  `DT`.`DRV_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  `DT`.`DRV_COST_PRICE` AS COST_PRICE  FROM  `DRV_ORDERS` `DT`  WHERE  DT.DRV_CLIENT_ID LIKE '%s'  AND DT.DRV_EXCH_ID LIKE '%s'  AND DT.DRV_SEGMENT LIKE '%c'  AND `DT`.`DRV_SYMBOL` LIKE '%s'  AND DT.DRV_INSTRUMENT_NAME LIKE '%s'  AND DT.DRV_PRODUCT_ID LIKE '%c'  AND ((`DT`.`DRV_TRD_STATUS` = 'C')  AND (`DT`.`DRV_MSG_CODE` = '2222'))  GROUP BY `DT`.`DRV_CLIENT_ID` , `DT`.`DRV_SCRIP_CODE` , `DT`.`DRV_EXCH_ID` , `DT`.`DRV_PRODUCT_ID` , `DT`.`DRV_SEGMENT` , `DT`.`DRV_CF_FLAG` UNION ALL SELECT `T`.`EQ_CLIENT_ID` AS `EQ_CLIENT_ID`,  `T`.`EQ_SCRIP_CODE` AS `EQ_SCRIP_CODE`,  `T`.`EQ_EXCH_ID` AS `EQ_EXCH_ID`,  `T`.`EQ_SEGMENT` AS `SEGMENT_CODE`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'B'  AND EQ_CF_FLAG = '0')  THEN  `T`.`EQ_LAST_TRADE_QTY`  ELSE 0  END)) AS `BUY_QTY_DAY`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'B'  AND EQ_CF_FLAG = '-1')  THEN  `T`.`EQ_LAST_TRADE_QTY`  ELSE 0  END)) AS `BUY_QTY_CF`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'B'  AND EQ_CF_FLAG = '0')  THEN  (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)  ELSE 0  END)) AS `BUY_VAL_DAY`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'B'  AND EQ_CF_FLAG = '-1')  THEN  (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)  ELSE 0  END)) AS `BUY_VAL_CF`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'S'  AND EQ_CF_FLAG = '0')  THEN  `T`.`EQ_LAST_TRADE_QTY`  ELSE 0  END)) AS `SELL_QTY_DAY`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'S'  AND EQ_CF_FLAG = '-1')  THEN  `T`.`EQ_LAST_TRADE_QTY`  ELSE 0  END)) AS `SELL_QTY_CF`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'S'  AND EQ_CF_FLAG = '0')  THEN  (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)  ELSE 0  END)) AS `SELL_VAL_DAY`,  SUM((CASE  WHEN  (`T`.`EQ_BUY_SELL_IND` = 'S'  AND EQ_CF_FLAG = '-1')  THEN  (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)  ELSE 0  END)) AS `SELL_VAL_CF`,  `T`.`EQ_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,  'E' AS `E`,  `T`.`EQ_PRODUCT_ID` AS `EQ_PRODUCT_ID`,  EQ_CF_FLAG AS `INT_REF_ID`,  `T`.`EQ_SYMBOL` AS `SYMBOL`,  `T`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,  '0001-01-01' AS `EXPIRY`,  1 AS `RBI_REFERENCE_RATE`,  'N' AS `CROSS_CUR_FLAG`,  1 AS `COMM_MULTIPLIER`,  1 AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  `T`.`EQ_STRIKE_PRICE` AS `STRIKE_PRICE`,  `T`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,  `T`.`EQ_SERIES` AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `T`.`EQ_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  `T`.`EQ_ISIN_CODE` AS `ISIN`,  `T`.`EQ_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  0 AS COST_PRICE  FROM  `EQ_ORDERS` `T`  WHERE  T.EQ_CLIENT_ID LIKE '%s'  AND T.EQ_EXCH_ID LIKE '%s'  AND T.EQ_SEGMENT LIKE '%c'  AND `T`.`EQ_SYMBOL` LIKE '%s'  AND T.EQ_INSTRUMENT_NAME LIKE '%s'  AND T.EQ_PRODUCT_ID LIKE '%c'  AND ((`T`.`EQ_TRD_STATUS` = 'C')  AND (`T`.`EQ_MSG_CODE` = 2222))  GROUP BY `T`.`EQ_CLIENT_ID` , `T`.`EQ_SCRIP_CODE` , `T`.`EQ_EXCH_ID` , `T`.`EQ_PRODUCT_ID` UNION ALL SELECT `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,  `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,  `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,  `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`  ELSE 0  END))) AS `BUY_QTY_DAY`,  0 AS `BUY_QTY_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END))) AS `BUY_VAL_DAY`,  0 AS `BUY_VAL_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`  ELSE 0  END))) AS `SELL_QTY_DAY`,  0 AS `SELL_QTY_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END))) AS `SELL_VAL_DAY`,  0 AS `SELL_VAL_CF`,  '0' AS `SL_TRIGGER_PRICE`,  `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,  `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,  0 AS `0`,  `CD`.`RCCD_SYMBOL` AS `SYMBOL`,  `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,  '0001-01-01' AS `EXPIRY`,  `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,  `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,  1 AS `COMM_MULTIPLIER`,  1 AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  0 AS `STRIKE_PRICE`,  'NA' AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `CD`.`RCCD_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  `CD`.`RCCD_ISIN` AS `ISIN`,  `CD`.`RCCD_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  `CD`.`RCCD_COST_PRICE` AS COST_PRICE  FROM  `RMS_CLIENT_CONVT_TO_DEL` `CD`  WHERE  RCCD_CLIENT_ID LIKE '%s'  AND RCCD_EXCHANGE LIKE '%s'  AND RCCD_SEGMENT LIKE '%c'  AND `RCCD_SCRIP_CODE` LIKE '%s'  AND RCCD_INSTRUMENT LIKE '%s'  AND RCCD_PRODUCT_SOURCE LIKE '%c'  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,  `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,  `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,  `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`  ELSE 0  END)) AS `BUY_QTY_DAY`,  0 AS `BUY_QTY_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END)) AS `BUY_VAL_DAY`,  0 AS `BUY_VAL_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`  ELSE 0  END)) AS `SELL_QTY_DAY`,  0 AS `SELL_QTY_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END)) AS `SELL_VAL_DAY`,  0 AS `SELL_VAL_CF`,  '0' AS `SL_TRIGGER_PRICE`,  `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,  `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,  0 AS `0`,  `CD`.`RCCD_SYMBOL` AS `SYMBOL`,  `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,  '0001-01-01' AS `EXPIRY`,  `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,  `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,  1 AS `COMM_MULTIPLIER`,  1 AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  0 AS `STRIKE_PRICE`,  'NA' AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `CD`.`RCCD_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  `CD`.`RCCD_ISIN` AS `ISIN`,  `CD`.`RCCD_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  `CD`.`RCCD_COST_PRICE` AS COST_PRICE  FROM  `RMS_CLIENT_CONVT_TO_DEL` `CD`  WHERE  RCCD_CLIENT_ID LIKE '%s'  AND RCCD_EXCHANGE LIKE '%s'  AND RCCD_SEGMENT LIKE '%c'  AND RCCD_SYMBOL LIKE '%s'  AND RCCD_INSTRUMENT LIKE '%s'  AND RCCD_PRODUCT_SOURCE LIKE '%c'  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,  `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,  `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,  `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`  ELSE 0  END))) AS `BUY_QTY_DAY`,  0 AS `BUY_QTY_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END))) AS `BUY_VAL_DAY`,  0 AS `BUY_VAL_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`  ELSE 0  END))) AS `SELL_QTY_DAY`,  0 AS `SELL_QTY_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END))) AS `SELL_VAL_DAY`,  0 AS `SELL_VAL_CF`,  '0' AS `SL_TRIGGER_PRICE`,  `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,  `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,  0 AS `0`,  `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,  `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,  `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,  `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,  `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,  1 AS `COMM_MULTIPLIER`,  `CD`.`RCCD_CURRENCY_MULTIPLIER` AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  0 AS `STRIKE_PRICE`,  'NA' AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `CD`.`RCCD_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  `CD`.`RCCD_ISIN` AS `ISIN`,  `CD`.`RCCD_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  `CD`.`RCCD_COST_PRICE` AS COST_PRICE  FROM  `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`  WHERE  RCCD_CLIENT_ID LIKE '%s'  AND RCCD_EXCHANGE LIKE '%s'  AND RCCD_SEGMENT LIKE '%c'  AND RCCD_SYMBOL LIKE '%s'  AND RCCD_INSTRUMENT LIKE '%s'  AND RCCD_PRODUCT_SOURCE LIKE '%c'  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,  `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,  `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,  `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`  ELSE 0  END)) AS `BUY_QTY_DAY`,  0 AS `BUY_QTY_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END)) AS `BUY_VAL_DAY`,  0 AS `BUY_VAL_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`  ELSE 0  END)) AS `SELL_QTY_DAY`,  0 AS `SELL_QTY_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END)) AS `SELL_VAL_DAY`,  0 AS `SELL_VAL_CF`,  '0' AS `SL_TRIGGER_PRICE`,  `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,  `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,  0 AS `0`,  `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,  `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,  `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,  `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,  `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,  1 AS `COMM_MULTIPLIER`,  `CD`.`RCCD_CURRENCY_MULTIPLIER` AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  0 AS `STRIKE_PRICE`,  'NA' AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `CD`.`RCCD_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  `CD`.`RCCD_ISIN` AS `ISIN`,  `CD`.`RCCD_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  `CD`.`RCCD_COST_PRICE` AS COST_PRICE  FROM  `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`  WHERE  RCCD_CLIENT_ID LIKE '%s'  AND RCCD_EXCHANGE LIKE '%s'  AND RCCD_SEGMENT LIKE '%c'  AND RCCD_SYMBOL LIKE '%s'  AND RCCD_INSTRUMENT LIKE '%s'  AND RCCD_PRODUCT_SOURCE LIKE '%c'  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT `MT`.`COMM_CLIENT_ID` AS `CLIENT_ID`,  `MT`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,  `MT`.`COMM_EXCH_ID` AS `EXCH_ID`,  `MT`.`COMM_SEGMENT` AS `SEGMENT_CODE`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'B'  AND `MT`.`COMM_CF_FLAG` = '0')  THEN  `MT`.`COMM_TRD_TRADE_QTY`  ELSE 0  END)) AS `BUY_QTY_DAY`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'B'  AND `MT`.`COMM_CF_FLAG` = '-1')  THEN  `MT`.`COMM_TRD_TRADE_QTY`  ELSE 0  END)) AS `BUY_QTY_CF`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'B'  AND `MT`.`COMM_CF_FLAG` = '0')  THEN  (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)  ELSE 0  END)) AS `BUY_VAL_DAY`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'B'  AND `MT`.`COMM_CF_FLAG` = '-1')  THEN  (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)  ELSE 0  END)) AS `BUY_VAL_CF`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'S'  AND `MT`.`COMM_CF_FLAG` = '0')  THEN  `MT`.`COMM_TRD_TRADE_QTY`  ELSE 0  END)) AS `SELL_QTY_DAY`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'S'  AND `MT`.`COMM_CF_FLAG` = '-1')  THEN  `MT`.`COMM_TRD_TRADE_QTY`  ELSE 0  END)) AS `SELL_QTY_CF`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'S'  AND `MT`.`COMM_CF_FLAG` = '0')  THEN  (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)  ELSE 0  END)) AS `SELL_VAL_DAY`,  SUM((CASE  WHEN  (`MT`.`COMM_BUY_SELL_IND` = 'S'  AND `MT`.`COMM_CF_FLAG` = '-1')  THEN  (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)  ELSE 0  END)) AS `SELL_VAL_CF`,  `MT`.`COMM_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,  `MT`.`COMM_SEGMENT` AS `EXCH_SEGMENT`,  `MT`.`COMM_PRODUCT_ID` AS `PRODUCT`,  `MT`.`COMM_CF_FLAG` AS `INT_REF_ID`,  SUBSTR(`MT`.`COMM_SYMBOL`, 1, 6) AS `SYMBOL`,  `MT`.`COMM_INSTRUMENT_NAME` AS `INSTRUMENT`,  `MT`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,  1 AS `RBI_REFERENCE_RATE`,  'N' AS `CROSS_CUR_FLAG`,  `MT`.`COMM_MULTIPLIER` AS `COMM_MULTIPLIER`,  1 AS `CURR_MULTIPLIER`,  `MT`.`COMM_UNDERLINE_SCRIP` AS `UNDERLAYING`,  `MT`.`COMM_STRIKE_PRICE` AS `STRIKE_PRICE`,  `MT`.`COMM_OPTION_TYPE` AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  `MT`.`COMM_LOT_SIZE` AS `SEM_NSE_REGULAR_LOT`,  `MT`.`COMM_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  'NA' AS `ISIN`,  `MT`.`COMM_EXCH_INSTRUMENT_TYPE` AS EXCH_INSTRUMENT_TYPE,  0 AS COST_PRICE  FROM  `COMM_ORDERS` `MT`  WHERE  MT.COMM_CLIENT_ID LIKE '%s'  AND MT.COMM_EXCH_ID LIKE '%s'  AND MT.COMM_SEGMENT LIKE '%c'  AND `MT`.`COMM_SYMBOL` LIKE '%s'  AND MT.COMM_INSTRUMENT_NAME LIKE '%s'  AND `MT`.`COMM_PRODUCT_ID` LIKE '%c'  AND ((`MT`.`COMM_TRD_STATUS` = 'C')  AND (`MT`.`COMM_MSG_CODE` = '2222'))  GROUP BY `MT`.`COMM_CLIENT_ID` , `MT`.`COMM_SCRIP_CODE` , `MT`.`COMM_EXCH_ID` , `MT`.`COMM_PRODUCT_ID` , `MT`.`COMM_SEGMENT` , `MT`.`COMM_CF_FLAG` UNION ALL SELECT `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,  `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,  `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,  `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`  ELSE 0  END))) AS `BUY_QTY_DAY`,  0 AS `BUY_QTY_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END))) AS `BUY_VAL_DAY`,  0 AS `BUY_VAL_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`  ELSE 0  END))) AS `SELL_QTY_DAY`,  0 AS `SELL_QTY_CF`,  (-(1) * SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END))) AS `SELL_VAL_DAY`,  0 AS `SELL_VAL_CF`,  '0' AS `SL_TRIGGER_PRICE`,  `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,  `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,  0 AS `0`,  `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,  `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,  `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,  1 AS `RBI_REFERENCE_RATE`,  'N' AS `CROSS_CUR_FLAG`,  `CD`.`RCCD_COMM_MULTIPLIER` AS `COMM_MULTIPLIER`,  1 AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  0 AS `STRIKE_PRICE`,  'NA' AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `CD`.`RCCD_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  'NA' AS `ISIN`,  'NA' AS EXCH_INSTRUMENT_TYPE,  0 AS COST_PRICE  FROM  `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`  WHERE  RCCD_CLIENT_ID LIKE '%s'  AND RCCD_EXCHANGE LIKE '%s'  AND RCCD_SEGMENT LIKE '%c'  AND RCCD_SYMBOL LIKE '%s'  AND RCCD_INSTRUMENT LIKE '%s'  AND RCCD_PRODUCT_SOURCE LIKE '%c'  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,  `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,  `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,  `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`  ELSE 0  END)) AS `BUY_QTY_DAY`,  0 AS `BUY_QTY_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END)) AS `BUY_VAL_DAY`,  0 AS `BUY_VAL_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`  ELSE 0  END)) AS `SELL_QTY_DAY`,  0 AS `SELL_QTY_CF`,  SUM((CASE  WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)  ELSE 0  END)) AS `SELL_VAL_DAY`,  0 AS `SELL_VAL_CF`,  '0' AS `SL_TRIGGER_PRICE`,  `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,  `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,  0 AS `0`,  `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,  `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,  `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,  1 AS `RBI_REFERENCE_RATE`,  'N' AS `CROSS_CUR_FLAG`,  `CD`.`RCCD_COMM_MULTIPLIER` AS `COMM_MULTIPLIER`,  1 AS `CURR_MULTIPLIER`,  'NA' AS `UNDERLAYING`,  0 AS `STRIKE_PRICE`,  'NA' AS `OPTION_TYPE`,  'NA' AS `GROUP_SERIES`,  1 AS `SEM_NSE_REGULAR_LOT`,  `CD`.`RCCD_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  'NA' AS `ISIN`,  'NA' AS EXCH_INSTRUMENT_TYPE,  0 AS COST_PRICE  FROM  `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`  WHERE  RCCD_CLIENT_ID LIKE '%s'  AND RCCD_EXCHANGE LIKE '%s'  AND RCCD_SEGMENT LIKE '%c'  AND RCCD_SYMBOL LIKE '%s'  AND RCCD_INSTRUMENT LIKE '%s'  AND RCCD_PRODUCT_SOURCE LIKE '%c'  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT`) AS MBNP  GROUP BY `MBNP`.`CLIENT_ID` , `MBNP`.`SECURITY_ID` , `MBNP`.`EXCH_ID` , `MBNP`.`SEGMENT_CODE` , `MBNP`.`PRODUCT`) AS NP  WHERE  1 = 1 %s;",pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,pEQSellOrd->sClientId,pEQSellOrd->ReqHeader.sExcgId,pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->sSymbol,pEQSellOrd->sInstrument,pEQSellOrd->cProduct,sClause1);
	}

	//logDebug1("sQuery :%s:",sQuery);
	printf("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("error in fSqrOffEqBulkOrd select Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCount1 = iNoOfRec;
	logDebug2("iCount1 :%d:",iCount1);

	logDebug2("fSqrOffEqBulkOrd :%d: Rows returned from Database ",iNoOfRec);

	for(i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);

		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			//pEOrdReq.ReqHeader.iSeqNo = iGrpId;
			pEOrdReq.ReqHeader.iSeqNo = 1;
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			//pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			iQty = atoi(Row[5]);
			logDebug2("iQty :%d:",iQty);
			if (iQty < 0) {
				iQty = iQty*-1;
				//pEOrdReq.cBuyOrSell = INT_SELL;
				pEOrdReq.cBuyOrSell = INT_BUY;
				logDebug2("pEOrdReq.cBuyOrSell:%c:",pEOrdReq.cBuyOrSell);
			}
			else {
				//pEOrdReq.cBuyOrSell = INT_BUY;
				pEOrdReq.cBuyOrSell = INT_SELL;
				logDebug2("pEOrdReq.cBuyOrSell:%c:",pEOrdReq.cBuyOrSell);
			}

			pEOrdReq.iTotalQty = iQty;
			pEOrdReq.iTotalQtyRem= iQty;
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0;
			pEOrdReq.fTriggerPrice= 0;
			pEOrdReq.fOrderNum = 0;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
			}
			pEOrdReq.iAuctionNum = 0;
			pEOrdReq.cMarkProFlag=NO ;
			pEOrdReq.fMarkProVal= 1.00;
			pEOrdReq.cParticipantType= PARTICI_BROKER;
			strncpy(pEOrdReq.sSettlor,"",SETTLOR_LEN);
			pEOrdReq.cGTCFlag= NO;
			pEOrdReq.cEncashFlag=NO;
			pEOrdReq.iGrpId=iGrpId;//Ashish
			strncpy(pEOrdReq.sPanID,Row[8],INT_PAN_LEN);
			strncpy(pEOrdReq.sPlatform,"NA",PLATFORM_LEN);
			strncpy(pEOrdReq.sChannel,"NA",CHANNEL_LEN);

			logDebug2("pEOrdReq.sSecurityId  :%s:",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId   :%s:",pEOrdReq.sClientId);
			logDebug2("pEOrdReq.cBuyOrSell:%c:",pEOrdReq.cBuyOrSell);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT  [fSqrOffEqBulkOrd]");
	return TRUE;

}

BOOL fBulkCoOrdExit(CHAR *RcvMsg)
{
	logTimestamp("fBulkCoOrdExit[ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            sSelQry[DOUBLE_MAX_QUERY_SIZE];

	CHAR            sClause[MAX_QUERY_SIZE];
	CHAR            sClause1[MAX_QUERY_SIZE];
	CHAR            sClause2[MAX_QUERY_SIZE];
        CHAR            sClauseOuter[MAX_QUERY_SIZE];
        CHAR            sClauseOuter1[MAX_QUERY_SIZE];
	CHAR            sClauseOuter2[MAX_QUERY_SIZE];

	CHAR            sTempClause[MAX_QUERY_SIZE];
	memset(sClause,'\0',MAX_QUERY_SIZE);
	CHAR            sTempClause1[MAX_QUERY_SIZE];
        memset(sClause1,'\0',MAX_QUERY_SIZE);
	CHAR            sTempClause2[MAX_QUERY_SIZE];
        memset(sClause2,'\0',MAX_QUERY_SIZE);
	CHAR            sTempOuter[MAX_QUERY_SIZE];
        memset(sClauseOuter,'\0',MAX_QUERY_SIZE);
	CHAR            sTempOuter1[MAX_QUERY_SIZE];
        memset(sClauseOuter1,'\0',MAX_QUERY_SIZE);
	CHAR            sTempOuter2[MAX_QUERY_SIZE];
        memset(sClauseOuter2,'\0',MAX_QUERY_SIZE);
  


	LONG32 iNoOfRec = 0 ;
	LONG32 	i = 0; 

	struct  ORDER_INSTRUCTION_REQUEST *pEQSellOrd;
	struct  CO_ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  ORDER_INSTRUCTION_REQUEST *)RcvMsg ;

	
	logDebug2("Received Bulk Cancellation request from admin");
        logDebug2("pEQSellOrd->ReqHeader.sExcgId :%s:",pEQSellOrd->ReqHeader.sExcgId);
        logDebug2("pEQSellOrd->ReqHeader.cSegment :%c:",pEQSellOrd->ReqHeader.cSegment);
        logDebug2("pEQSellOrd->ReqHeader.cSource :%c:",pEQSellOrd->ReqHeader.cSource);
        logDebug2("pEQSellOrd->sClientId :%s:",pEQSellOrd->sClientId);
        logDebug2("pEQSellOrd->sSymbol :%s:",pEQSellOrd->sSymbol);
        logDebug2("pEQSellOrd->cProduct :%c:",pEQSellOrd->cProduct);
        logDebug2("pEQSellOrd->sInstrument :%s:",pEQSellOrd->sInstrument);
        logDebug2("pEQSellOrd->sPlaceBy :%s:",pEQSellOrd->sPlaceBy);
        logDebug2("pEQSellOrd->sOrdStatus:%s:",pEQSellOrd->sOrdStatus);
        logDebug2("pEQSellOrd->iQuantity_val:%d:",pEQSellOrd->iQuantity_val);
        logDebug2("pEQSellOrd->fOrder_val:%f:",pEQSellOrd->fOrder_val);

        if(strcmp(pEQSellOrd->sClientId,SELECT_ALL) == 0)
        {
		logDebug2("If condition For Client ID");
		logDebug2("Client id is %s",pEQSellOrd->sClientId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause,sTempClause);
   		
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause2,sTempClause2);
        }
	else
	{
		logDebug2("Going in Else Condition for Client ID");
                logDebug2("Client id is %s",pEQSellOrd->sClientId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause2,sTempClause2);
	}

        if(strcmp(pEQSellOrd->ReqHeader.sExcgId,SELECT_ALL) == 0)
        {
		logDebug2("If condition For Exchange Id");
		logDebug2("Exchange id is %s", pEQSellOrd->ReqHeader.sExcgId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);

        }
	else
	{
		logDebug2("Going in Else Condition For Exchange Id");
                logDebug2("Exchange id is %s", pEQSellOrd->ReqHeader.sExcgId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);
	}
         if(pEQSellOrd->ReqHeader.cSegment != '%')
        {
	        logDebug2("If condition for Segment");
		logDebug2("Segment is %c",pEQSellOrd->ReqHeader.cSegment);	
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);
		
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);
	
		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
        }
      /*  else
	{
		logDebug2("Else condition for Segment");
                logDebug2("Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
	}

        *?
      /*  if(pEQSellOrd->ReqHeader.cSegment = 'E')
        {
                logDebug2("If condition for Equity Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'D')
        {
                logDebug2("else if for Derivative and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);


        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'C')
        {
                logDebug2("else if for Commodity and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

        }
        else
        {
                logDebug2("Else condition for Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
        }

*/
        if(strcmp(pEQSellOrd->sSymbol,SELECT_ALL) == 0)
        {
		logDebug2("If condition in  Symbol");
		logDebug2("Symbol is %s",pEQSellOrd->sSymbol);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause2,sTempClause2);

        }
	else
	{
		logDebug2("Else Condition Symbol");
		logDebug2("Symbol is %s",pEQSellOrd->sSymbol);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SYMBOL like \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SYMBOL like  \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SYMBOL like \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause2,sTempClause2);
	}
        if(strcmp(pEQSellOrd->sInstrument,SELECT_ALL) == 0 )
        {
		logDebug2("If Condition In Instrument");
		logDebug2("Instrument is %s",pEQSellOrd->sInstrument);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause2,sTempClause2);

        }
	else
	{
		logDebug2("Else Condition In Instrument");
                logDebug2("Instrument is %s",pEQSellOrd->sInstrument);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause2,sTempClause2);
	}
        if(pEQSellOrd->cSource != '%')
        {
		logDebug2("If condition for Source");
		logDebug2("Source is %c",pEQSellOrd->cSource);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SOURCE_FLG = \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause,sTempClause);
                  
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SOURCE_FLG = \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause1,sTempClause1);
	
		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SOURCE_FLG = \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause2,sTempClause2);
        }

        if(strcmp(pEQSellOrd->sPlaceBy,SELECT_ALL) )
        {
		logDebug2("If condition in PlaceBy");
		logDebug2("Entity id is %s",pEQSellOrd->sPlaceBy);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause2,sTempClause2);
        }
/*	else
	{
		logDebug2("Else condition in PlaceBy");
                logDebug2("Entity id is %s",pEQSellOrd->sPlaceBy);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause2,sTempClause2);	
	}

*/



	 if(pEQSellOrd->iQuantity_val != -1)
        {
		logDebug2("Quantity val is %d", pEQSellOrd->iQuantity_val);
                memset(sTempOuter,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter," AND A.EQ_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter,sTempOuter);

		memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter1," AND B.DRV_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter1,sTempOuter1);

		memset(sTempOuter2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter2," AND C.COMM_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter2,sTempOuter2);		

        }
        if(pEQSellOrd->fOrder_val != -1)
        {
		 logDebug2("Order val is %f",pEQSellOrd->fOrder_val);
                 memset(sTempOuter,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter," AND (A.EQ_ORDER_PRICE * A.EQ_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter,sTempOuter);

		 memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter1," AND (B.DRV_ORDER_PRICE * B.DRV_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter1,sTempOuter1);

		 memset(sTempOuter2,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter2," AND (C.COMM_ORDER_PRICE * C.COMM_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter2,sTempOuter2);
        }

	logDebug2("sClause :%s;",sClause);
	logDebug2("sClause1 :%s;",sClause1);
	logDebug2("sClause2 :%s;",sClause2);

        logDebug2("sClauseOuter :%s:",sClauseOuter);
        logDebug2("sClauseOuter1 :%s:",sClauseOuter);
        logDebug2("sClauseOuter2 :%s:",sClauseOuter2);

	sprintf(sSelQry,"SELECT ORDER_NO,\
                        SERIAL_NO,\
                        SCRIP_CODE,\
                        MKT_TYPE,\
                        EXCH_ID,\
                        ENTITY_ID,\
                        CLIENT_ID,\
                        BUY_SELL_IND,\
                        TOTAL_QTY,\
                        REM_QTY,\
                        DISC_QTY,\
                        DISC_REM_QTY,\
			TOTAL_TRADED_QTY,\
                        ORDER_PRICE,\
                        TRIGGER_PRICE,\
                        VALIDITY,\
                        ORDER_TYPE,\
                        USER_ID,\
                        MIN_FILL_QTY,\
                        PRO_CLIENT,\
                        USER_TYPE,\
                        REMARKS,\
                        SOURCE_FLG,\
                        PRODUCT_ID,\
                        MSG_CODE,\
                        SEGMENT ,\
                        SL_ABSTICK_VALUE ,\ 
                        PR_ABSTICK_VALUE ,\ 
                        SL_AT_FLAG ,\   
                        PR_ST_FLAG ,\   
			PAN_NO,\
                        PARTICIPANT_TYPE,\
                        SETTLOR,\
                        MKT_PROTECT_FLG,\
                        MKT_PROTECT_VAL,\
                        GTC_FLG,\
                        ENCASH_FLG,\
                        GROUP_ID \
               FROM   (           \
		SELECT 	A.EQ_ORDER_NO   AS   ORDER_NO ,\
                        A.EQ_SERIAL_NO  AS   SERIAL_NO ,\
                        A.EQ_SCRIP_CODE AS   SCRIP_CODE,\
                        A.EQ_MKT_TYPE   AS   MKT_TYPE,\
                        A.EQ_EXCH_ID    AS   EXCH_ID ,\
                        A.EQ_ENTITY_ID  AS ENTITY_ID  ,\
                        A.EQ_CLIENT_ID  AS CLIENT_ID,\
                        A.EQ_BUY_SELL_IND  AS BUY_SELL_IND ,\
                        A.EQ_TOTAL_QTY  AS TOTAL_QTY ,\
                        A.EQ_REM_QTY  AS REM_QTY,\
                        A.EQ_DISC_QTY AS DISC_QTY,\
                        A.EQ_DISC_REM_QTY  AS DISC_REM_QTY,\
                        A.EQ_TOTAL_TRADED_QTY AS TOTAL_TRADED_QTY,\
                        A.EQ_ORDER_PRICE  AS ORDER_PRICE ,\
                        A.EQ_TRIGGER_PRICE  AS TRIGGER_PRICE ,\
                        A.EQ_VALIDITY  AS VALIDITY,\
                        A.EQ_ORDER_TYPE AS ORDER_TYPE,\
                        A.EQ_USER_ID AS USER_ID,\
                        A.EQ_MIN_FILL_QTY AS MIN_FILL_QTY,\
                        A.EQ_PRO_CLIENT AS PRO_CLIENT ,\
                        A.EQ_USER_TYPE AS USER_TYPE,\
                        A.EQ_REMARKS AS REMARKS,\
                        A.EQ_SOURCE_FLG AS SOURCE_FLG ,\
                        A.EQ_PRODUCT_ID  AS PRODUCT_ID  ,\
                        A.EQ_MSG_CODE AS MSG_CODE ,\
                        A.EQ_SEGMENT AS SEGMENT,\
                        A.EQ_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE,\  
                        A.EQ_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,\ 
                        A.EQ_SL_AT_FLAG AS SL_AT_FLAG  ,\   
                        A.EQ_PR_ST_FLAG AS  PR_ST_FLAG ,\ 
                        A.EQ_PAN_NO AS PAN_NO,\
                        A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE  ,\
                        A.EQ_SETTLOR AS SETTLOR ,\
                        A.EQ_MKT_PROTECT_FLG AS  MKT_PROTECT_FLG ,\
                        A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL  ,\
                        A.EQ_GTC_FLG AS GTC_FLG ,\
                        A.EQ_ENCASH_FLG AS ENCASH_FLG ,\
                        A.EQ_GROUP_ID AS GROUP_ID \
                        FROM    EQ_ORDERS A , (SELECT L.EQ_ORDER_NO AS ORD,L.EQ_LEG_NO AS LEG,MAX(L.EQ_SERIAL_NO) AS SER FROM EQ_ORDERS L WHERE 1=1 %s \
                        GROUP BY L.EQ_ORDER_NO,L.EQ_LEG_NO)AS X\
                        WHERE \
                        (A.EQ_SERIAL_NO =X.SER)\
                        AND  (A.EQ_ORDER_NO = X.ORD)\
                        AND (A.EQ_LEG_NO=X.LEG) %s\
UNION ALL\
			SELECT B.DRV_ORDER_NO AS ORDER_NO ,\
       			B.DRV_SERIAL_NO AS SERIAL_NO ,\
       			B.DRV_SCRIP_CODE AS SCRIP_CODE,\
     		  	B.DRV_MKT_TYPE AS MKT_TYPE,\
       			B.DRV_EXCH_ID AS EXCH_ID,\
       			B.DRV_ENTITY_ID AS ENTITY_ID,\
       			B.DRV_CLIENT_ID AS CLIENT_ID,\
       			B.DRV_BUY_SELL_IND AS BUY_SELL_IND ,\
       			B.DRV_TOTAL_QTY AS TOTAL_QTY ,\
       			B.DRV_REM_QTY AS REM_QTY ,\
       			B.DRV_DISC_QTY AS DISC_QTY  ,\
      		 	B.DRV_DISC_REM_QTY AS DISC_REM_QTY  ,\
       			B.DRV_TOTAL_TRADED_QTY AS  TOTAL_TRADED_QTY,\
       			B.DRV_ORDER_PRICE AS ORDER_PRICE ,\
       			B.DRV_TRIGGER_PRICE AS TRIGGER_PRICE  ,\
       			B.DRV_VALIDITY AS VALIDITY  ,\
       			B.DRV_ORDER_TYPE AS ORDER_TYPE  ,\
       			B.DRV_USER_ID AS USER_ID  ,\
       			B.DRV_MIN_FILL_QTY AS  MIN_FILL_QTY ,\
       			B.DRV_PRO_CLIENT AS  PRO_CLIENT,\
       			B.DRV_USER_TYPE AS  USER_TYPE,\
       			B.DRV_REMARKS AS REMARKS ,\
       			B.DRV_SOURCE_FLG AS SOURCE_FLG  ,\
       			B.DRV_PRODUCT_ID AS PRODUCT_ID  ,\
       			B.DRV_MSG_CODE AS MSG_CODE  ,\
       			B.DRV_SEGMENT AS SEGMENT ,\
       			B.DRV_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE,\
	   		B.DRV_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,\
	   		B.DRV_SL_AT_FLAG  AS SL_AT_FLAG,\
	   		B.DRV_PR_ST_FLAG  AS PR_ST_FLAG,\
       			B.DRV_PAN_NO AS PAN_NO ,\
       			B.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE  ,\
       			B.DRV_SETTLOR AS  SETTLOR,\
       			B.DRV_MKT_PROTECT_FLG AS  MKT_PROTECT_FLG,\
      	 		B.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL  ,\
       			B.DRV_GTC_FLG AS GTC_FLG  ,\
       			B.DRV_ENCASH_FLG AS ENCASH_FLG ,\
       			B.DRV_GROUP_ID AS GROUP_ID \
       			FROM  DRV_ORDERS B , (SELECT M.DRV_ORDER_NO AS ORD,M.DRV_LEG_NO AS LEG,MAX(M.DRV_SERIAL_NO) AS SER FROM DRV_ORDERS M WHERE 1=1 %s \
			GROUP BY M.DRV_ORDER_NO,M.DRV_LEG_NO) AS Y\
                   WHERE\
                        (B.DRV_SERIAL_NO =Y.SER)\
                         AND  (B.DRV_ORDER_NO = Y.ORD)\
                         AND (B.DRV_LEG_NO=Y.LEG) %s\
UNION ALL \
			SELECT  C.COMM_ORDER_NO AS ORDER_NO ,\
			C.COMM_SERIAL_NO AS SERIAL_NO ,\
        		C.COMM_SCRIP_CODE AS  SCRIP_CODE,\
        		C.COMM_MKT_TYPE AS MKT_TYPE ,\
        		C.COMM_EXCH_ID AS EXCH_ID ,\
        		C.COMM_ENTITY_ID AS  ENTITY_ID,\
        		C.COMM_CLIENT_ID  AS  CLIENT_ID,\
        		C.COMM_BUY_SELL_IND  AS BUY_SELL_IND,\
        		C.COMM_TOTAL_QTY AS TOTAL_QTY ,\
        		C.COMM_REM_QTY  AS  REM_QTY,\
        		C.COMM_DISC_QTY AS DISC_QTY  ,\
        		C.COMM_DISC_REM_QTY AS  DISC_REM_QTY   ,\
        		C.COMM_TOTAL_TRADED_QTY  AS TOTAL_TRADED_QTY ,\
        		C.COMM_ORDER_PRICE  AS ORDER_PRICE ,\
       	 		C.COMM_TRIGGER_PRICE   AS TRIGGER_PRICE ,\
        		C.COMM_VALIDITY  AS VALIDITY  ,\
        		C.COMM_ORDER_TYPE  AS ORDER_TYPE ,\
        		C.COMM_USER_ID  AS  USER_ID ,\
        		C.COMM_MIN_FILL_QTY  AS  MIN_FILL_QTY,\
        		C.COMM_PRO_CLIENT  AS PRO_CLIENT ,\
        		C.COMM_USER_TYPE  AS USER_TYPE ,\
        		C.COMM_REMARKS  AS REMARKS,\
        		C.COMM_SOURCE_FLG  AS SOURCE_FLG ,\
        		C.COMM_PRODUCT_ID  AS PRODUCT_ID ,\
        		C.COMM_MSG_CODE AS MSG_CODE ,\
       	 		C.COMM_SEGMENT AS SEGMENT ,\
        		C.COMM_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE ,\
			C.COMM_PR_ABSTICK_VALUE  AS PR_ABSTICK_VALUE ,\
			C.COMM_SL_AT_FLAG  AS SL_AT_FLAG,\
			C.COMM_PR_ST_FLAG  AS PR_ST_FLAG,\
        		C.COMM_PAN_NO  AS  PAN_NO,\
        		C.COMM_PARTICIPANT_TYPE AS  PARTICIPANT_TYPE ,\
        		C.COMM_SETTLOR   AS SETTLOR  ,\
        		C.COM_MKT_PROTECT_FLG   AS  MKT_PROTECT_FLG,\
        		C.COMM_MKT_PROTECT_VAL  AS MKT_PROTECT_VAL ,\
        		C.COMM_GTC_FLG  AS   GTC_FLG ,\
        		C.COMM_ENCASH_FLG  AS  ENCASH_FLG,\
        		C.COMM_GROUP_ID  AS  GROUP_ID  \             
        	FROM COMM_ORDERS C ,(SELECT N.COMM_ORDER_NO AS ORD,N.COMM_LEG_NO AS LEG,MAX(N.COMM_SERIAL_NO) AS SER FROM COMM_ORDERS N WHERE 1=1 %s \
                        GROUP BY N.COMM_ORDER_NO,N.COMM_LEG_NO) AS Z \
		WHERE \
	                (C.COMM_SERIAL_NO =Z.SER)\
                        AND  (C.COMM_ORDER_NO = Z.ORD)\
                        AND (C.COMM_LEG_NO=Z.LEG) %s\
                        ) AS P;",sClause,sClauseOuter,sClause1,sClauseOuter1,sClause2,sClauseOuter2);
	printf("sSelQry :%s: \n",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fBulkCoOrdExit Query.");
		exit(ERROR);
	}
        else
   	{

		logDebug2("*****Query Executed SucessFully******");
	}
	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	
	logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

	for(i = 0 ; i < iNoOfRec ; i++)
	{
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];


			pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];

			pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= 0 ;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.fTrailingSLValue = 0.00 ;
			pEOrdReq.fAlgoOrderNo = 0.00 ;
			pEOrdReq.iNoOfLeg = 1 ;
			pEOrdReq.iMinFillQty = atoi(Row[18]) ;
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cAvgLtpFlg = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[31][0];
			strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[35][0];
			pEOrdReq.cEncashFlag= Row[36][0];
			pEOrdReq.iGrpId = atoi(Row[37]) ;
			strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);


			logDebug2(" pEOrdReq.CoArray[0].cBuySellInd :%c: ",pEOrdReq.CoArray[0].cBuySellInd);
			logDebug2("pEOrdReq.CoArray[0].fTriggerPrice :%f:",pEOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pEOrdReq.CoArray[1].fTriggerPrice :%f:",pEOrdReq.CoArray[1].fTriggerPrice);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" sClientId :%s: ",pEOrdReq.sClientId);
			logDebug2(" pEOrdReq.sPanID	:%s: ",pEOrdReq.sPanID);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				  mysql_close(DB_IntSqr);
                                exit(ERROR);
                        }
                }
        }
        logTimestamp("fBulkCoOrdExit [EXIT]");
        return TRUE;
}

BOOL fBulkBoOrdExit(CHAR *RcvMsg)
{
	logTimestamp("fBulkBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;




	CHAR            sSelQry[DOUBLE_MAX_QUERY_SIZE];

        CHAR            sClause[MAX_QUERY_SIZE];
        CHAR            sClause1[MAX_QUERY_SIZE];
        CHAR            sClause2[MAX_QUERY_SIZE];
        CHAR            sClauseOuter[MAX_QUERY_SIZE];
        CHAR            sClauseOuter1[MAX_QUERY_SIZE];
        CHAR            sClauseOuter2[MAX_QUERY_SIZE];

        CHAR            sTempClause[MAX_QUERY_SIZE];
        memset(sClause,'\0',MAX_QUERY_SIZE);
        CHAR            sTempClause1[MAX_QUERY_SIZE];
        memset(sClause1,'\0',MAX_QUERY_SIZE);
        CHAR            sTempClause2[MAX_QUERY_SIZE];
        memset(sClause2,'\0',MAX_QUERY_SIZE);
        CHAR            sTempOuter[MAX_QUERY_SIZE];
        memset(sClauseOuter,'\0',MAX_QUERY_SIZE);
        CHAR            sTempOuter1[MAX_QUERY_SIZE];
        memset(sClauseOuter1,'\0',MAX_QUERY_SIZE);
        CHAR            sTempOuter2[MAX_QUERY_SIZE];
        memset(sClauseOuter2,'\0',MAX_QUERY_SIZE);
	LONG32 	iNoOfRec = 0 ;
	LONG32	i = 0;

	struct  ORDER_INSTRUCTION_REQUEST *pEQSellOrd;
	struct  BO_ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  BO_ORDER_REQUEST   *)RcvMsg ;

	logDebug2("Received Bulk Cancellation request from admin");
        logDebug2("pEQSellOrd->ReqHeader.sExcgId :%s:",pEQSellOrd->ReqHeader.sExcgId);
        logDebug2("pEQSellOrd->ReqHeader.cSegment :%c:",pEQSellOrd->ReqHeader.cSegment);
        logDebug2("pEQSellOrd->ReqHeader.cSource :%c:",pEQSellOrd->ReqHeader.cSource);
        logDebug2("pEQSellOrd->sClientId :%s:",pEQSellOrd->sClientId);
        logDebug2("pEQSellOrd->sSymbol :%s:",pEQSellOrd->sSymbol);
        logDebug2("pEQSellOrd->cProduct :%c:",pEQSellOrd->cProduct);
        logDebug2("pEQSellOrd->sInstrument :%s:",pEQSellOrd->sInstrument);
        logDebug2("pEQSellOrd->sPlaceBy :%s:",pEQSellOrd->sPlaceBy);
        logDebug2("pEQSellOrd->sOrdStatus:%s:",pEQSellOrd->sOrdStatus);
        logDebug2("pEQSellOrd->iQuantity_val:%d:",pEQSellOrd->iQuantity_val);
        logDebug2("pEQSellOrd->fOrder_val:%f:",pEQSellOrd->fOrder_val);

        /*if(pEQSellOrd->ReqHeader.cSegment = 'E')
        {
                logDebug2("If condition for Equity Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'D')
        {
                logDebug2("else if for Derivative and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);


        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'C')
        {
                logDebug2("else if for Commodity and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

        }
        else
        {
                logDebug2("Else condition for Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
        }
       
 */
        if(strcmp(pEQSellOrd->sClientId,SELECT_ALL) == 0)
        {
		logDebug2("If condition For Client id");
		logDebug2("Client id is %s",pEQSellOrd->sClientId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause,sTempClause);

 		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause1,sTempClause1);	
		
		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause2,sTempClause2);
        }
	else
	{
		logDebug2("Else Condition for Client Id");
		logDebug2("Client id is %s",pEQSellOrd->sClientId);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_CLIENT_ID like \"%s\" ",pEQSellOrd->sClientId);
                strcat(sClause2,sTempClause2);

	}
        if(strcmp(pEQSellOrd->ReqHeader.sExcgId,SELECT_ALL) == 0)
        {	
		logDebug2("If Condition for Exchange Id");
		logDebug2("Exchange id is %s",pEQSellOrd->ReqHeader.sExcgId);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);	
                sprintf(sTempClause," AND EQ_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);
		
		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);

        }
	else
	{
		logDebug2("Else Condition for Exchange Id");
                logDebug2("Exchange id is %s",pEQSellOrd->ReqHeader.sExcgId);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_EXCH_ID like  \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_EXCH_ID like \"%s\" ",pEQSellOrd->ReqHeader.sExcgId);
                strcat(sClause2,sTempClause2);
	}

         if(pEQSellOrd->ReqHeader.cSegment != '%')
        {
		logDebug2("If condition in Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

 		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

        }
/*	else
	{
		logDebug2("Else Condition in Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT =  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

	}
*/
/*	if(pEQSellOrd->ReqHeader.cSegment = 'E')
        {
                logDebug2("If condition for Equity Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'D')
        {
                logDebug2("else if for Derivative and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);


        }
        else if(pEQSellOrd->ReqHeader.cSegment = 'C')
        {
                logDebug2("else if for Commodity and Segment is %c",pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);

        }
        else
        {
                logDebug2("Else condition for Segment");
                logDebug2("Segment is %c", pEQSellOrd->ReqHeader.cSegment);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SEGMENT like  \"%c\" ",pEQSellOrd->ReqHeader.cSegment);
                strcat(sClause2,sTempClause2);
        }

*/
	if(strcmp(pEQSellOrd->sSymbol,SELECT_ALL) == 0)
        {
		logDebug2("If condition for Symbol");
		logDebug2("Symbol is %s",pEQSellOrd->sSymbol);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SYMBOL like \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SYMBOL like  \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SYMBOL like \"%s\" ",pEQSellOrd->sSymbol);
                strcat(sClause2,sTempClause2);


        }
	else
	{
		logDebug2("Else condition for Symbol");
                logDebug2("Symbol is %s",pEQSellOrd->sSymbol);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SYMBOL like \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SYMBOL like \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SYMBOL like \"%s%\" ",pEQSellOrd->sSymbol);
                strcat(sClause2,sTempClause2);


	}
	if(strcmp(pEQSellOrd->sInstrument,SELECT_ALL) == 0)
        {
		logDebug2("If condition for Instrument");
		logDebug2("Instrument is %s",pEQSellOrd->sInstrument);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause2,sTempClause2);
        }
	else
	{
		logDebug2("Else condition for Instrument");
                logDebug2("Instrument is %s",pEQSellOrd->sInstrument);
		memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_INSTRUMENT_NAME like \"%s\" ",pEQSellOrd->sInstrument);
                strcat(sClause2,sTempClause2);
	}
        if(pEQSellOrd->cSource != '%')
        {
		logDebug2("Source is %c",pEQSellOrd->cSource);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_SOURCE_FLG = \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_SOURCE_FLG = \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_SOURCE_FLG = \"%c\" ",pEQSellOrd->cSource);
                strcat(sClause2,sTempClause2);

        }
        if(strcmp(pEQSellOrd->sPlaceBy,SELECT_ALL) )
        {
		logDebug2("If Condition for Entity id");
		logDebug2("Placeby is %s",pEQSellOrd->sPlaceBy);
                memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause,sTempClause);

		memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause1,sTempClause1);

		memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause2,sTempClause2);
        }
/*	else
	{
		logDebug2("Else Condition for Entity id");
                logDebug2("Placeby is %s",pEQSellOrd->sPlaceBy);
		 memset(sTempClause,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause," AND EQ_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause,sTempClause);

                memset(sTempClause1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause1," AND DRV_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause1,sTempClause1);

                memset(sTempClause2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempClause2," AND COMM_ENTITY_ID like \"%s\" ",pEQSellOrd->sPlaceBy);
                strcat(sClause2,sTempClause2);

	}*/
         if(pEQSellOrd->iQuantity_val != -1)
        {
		logDebug2("Quantity val is %d",pEQSellOrd->iQuantity_val);
                memset(sTempOuter,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter," AND A.EQ_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter,sTempOuter);

		memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter1," AND B.DRV_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter1,sTempOuter1);

		memset(sTempOuter2,'\0',MAX_QUERY_SIZE);
                sprintf(sTempOuter2," AND C.COMM_TOTAL_QTY > %d ",pEQSellOrd->iQuantity_val);
                strcat(sClauseOuter2,sTempOuter2);
        }
        if(pEQSellOrd->fOrder_val != -1)
        {	
		 logDebug2("Order val is %f",pEQSellOrd->fOrder_val);
                 memset(sTempOuter,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter," AND (A.EQ_ORDER_PRICE * A.EQ_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter,sTempOuter);

		 memset(sTempOuter1,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter1," AND (B.DRV_ORDER_PRICE * B.DRV_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter1,sTempOuter1);

		 memset(sTempOuter2,'\0',MAX_QUERY_SIZE);
                 sprintf(sTempOuter2," AND (C.COMM_ORDER_PRICE * C.COMM_TOTAL_QTY) > %f ",pEQSellOrd->fOrder_val);
                 strcat(sClauseOuter2,sTempOuter2);
        }

	

	logDebug2("sClause :%s;",sClause);
	logDebug2("sClause1 :%s;",sClause1);	
	logDebug2("sClause2 :%s;",sClause2);
        logDebug2("sClauseOuter :%s;",sClauseOuter);
	logDebug2("sClauseOuter1:%s;",sClauseOuter1);
	logDebug2("sClauseOuter2 :%s;",sClauseOuter2);



	sprintf(sSelQry,"SELECT ORDER_NO,\
                        SERIAL_NO,\
                        SCRIP_CODE,\
                        MKT_TYPE,\
                        EXCH_ID,\
                        ENTITY_ID,\
                        CLIENT_ID,\
                        BUY_SELL_IND,\
                        TOTAL_QTY,\
                        REM_QTY,\
                        DISC_QTY,\
                        DISC_REM_QTY,\
			TOTAL_TRADED_QTY,\
                        ORDER_PRICE,\
                        TRIGGER_PRICE,\
                        VALIDITY,\
                        ORDER_TYPE,\
                        USER_ID,\
                        MIN_FILL_QTY,\
                        PRO_CLIENT,\
                        USER_TYPE,\
                        REMARKS,\
                        SOURCE_FLG,\
                        PRODUCT_ID,\
                        MSG_CODE,\
                        SEGMENT ,\
                        SL_ABSTICK_VALUE ,\ 
                        PR_ABSTICK_VALUE ,\ 
                        SL_AT_FLAG ,\   
                        PR_ST_FLAG ,\   
			PAN_NO,\
                        PARTICIPANT_TYPE,\
                        SETTLOR,\
                        MKT_PROTECT_FLG,\
                        MKT_PROTECT_VAL,\
                        GTC_FLG,\
                        ENCASH_FLG,\
                        GROUP_ID \
                        FROM(           \
		SELECT 	A.EQ_ORDER_NO   AS   ORDER_NO ,\
                        A.EQ_SERIAL_NO  AS   SERIAL_NO ,\
                        A.EQ_SCRIP_CODE AS   SCRIP_CODE,\
                        A.EQ_MKT_TYPE   AS   MKT_TYPE,\
                        A.EQ_EXCH_ID    AS   EXCH_ID ,\
                        A.EQ_ENTITY_ID  AS ENTITY_ID  ,\
                        A.EQ_CLIENT_ID  AS CLIENT_ID,\
                        A.EQ_BUY_SELL_IND  AS BUY_SELL_IND ,\
                        A.EQ_TOTAL_QTY  AS TOTAL_QTY ,\
                        A.EQ_REM_QTY  AS REM_QTY,\
                        A.EQ_DISC_QTY AS DISC_QTY,\
                        A.EQ_DISC_REM_QTY  AS DISC_REM_QTY,\
                        A.EQ_TOTAL_TRADED_QTY AS TOTAL_TRADED_QTY,\
                        A.EQ_ORDER_PRICE  AS ORDER_PRICE ,\
                        A.EQ_TRIGGER_PRICE  AS TRIGGER_PRICE ,\
                        A.EQ_VALIDITY  AS VALIDITY,\
                        A.EQ_ORDER_TYPE AS ORDER_TYPE,\
                        A.EQ_USER_ID AS USER_ID,\
                        A.EQ_MIN_FILL_QTY AS MIN_FILL_QTY,\
                        A.EQ_PRO_CLIENT AS PRO_CLIENT ,\
                        A.EQ_USER_TYPE AS USER_TYPE,\
                        A.EQ_REMARKS AS REMARKS,\
                        A.EQ_SOURCE_FLG AS SOURCE_FLG ,\
                        A.EQ_PRODUCT_ID  AS PRODUCT_ID  ,\
                        A.EQ_MSG_CODE AS MSG_CODE ,\
                        A.EQ_SEGMENT AS SEGMENT,\
                        A.EQ_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE,\  
                        A.EQ_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,\ 
                        A.EQ_SL_AT_FLAG AS SL_AT_FLAG  ,\   
                        A.EQ_PR_ST_FLAG AS  PR_ST_FLAG ,\ 
                        A.EQ_PAN_NO AS PAN_NO,\
                        A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE  ,\
                        A.EQ_SETTLOR AS SETTLOR ,\
                        A.EQ_MKT_PROTECT_FLG AS  MKT_PROTECT_FLG ,\
                        A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL  ,\
                        A.EQ_GTC_FLG AS GTC_FLG ,\
                        A.EQ_ENCASH_FLG AS ENCASH_FLG ,\
                        A.EQ_GROUP_ID AS GROUP_ID \
                        FROM    EQ_ORDERS A , (SELECT L.EQ_ORDER_NO AS ORD,L.EQ_LEG_NO AS LEG,MAX(L.EQ_SERIAL_NO) AS SER FROM EQ_ORDERS L WHERE 1=1 %s \
                        GROUP BY L.EQ_ORDER_NO,L.EQ_LEG_NO)AS X\
                        WHERE \
                        (A.EQ_SERIAL_NO =X.SER)\
                        AND  (A.EQ_ORDER_NO = X.ORD)\
                        AND (A.EQ_LEG_NO=X.LEG) %s\
UNION ALL\
			SELECT B.DRV_ORDER_NO AS ORDER_NO ,\
       			B.DRV_SERIAL_NO AS SERIAL_NO ,\
       			B.DRV_SCRIP_CODE AS SCRIP_CODE,\
     		  	B.DRV_MKT_TYPE AS MKT_TYPE,\
       			B.DRV_EXCH_ID AS EXCH_ID,\
       			B.DRV_ENTITY_ID AS ENTITY_ID,\
       			B.DRV_CLIENT_ID AS CLIENT_ID,\
       			B.DRV_BUY_SELL_IND AS BUY_SELL_IND ,\
       			B.DRV_TOTAL_QTY AS TOTAL_QTY ,\
       			B.DRV_REM_QTY AS REM_QTY ,\
       			B.DRV_DISC_QTY AS DISC_QTY  ,\
      		 	B.DRV_DISC_REM_QTY AS DISC_REM_QTY  ,\
       			B.DRV_TOTAL_TRADED_QTY AS  TOTAL_TRADED_QTY,\
       			B.DRV_ORDER_PRICE AS ORDER_PRICE ,\
       			B.DRV_TRIGGER_PRICE AS TRIGGER_PRICE  ,\
       			B.DRV_VALIDITY AS VALIDITY  ,\
       			B.DRV_ORDER_TYPE AS ORDER_TYPE  ,\
       			B.DRV_USER_ID AS USER_ID  ,\
       			B.DRV_MIN_FILL_QTY AS  MIN_FILL_QTY ,\
       			B.DRV_PRO_CLIENT AS  PRO_CLIENT,\
       			B.DRV_USER_TYPE AS  USER_TYPE,\
       			B.DRV_REMARKS AS REMARKS ,\
       			B.DRV_SOURCE_FLG AS SOURCE_FLG  ,\
       			B.DRV_PRODUCT_ID AS PRODUCT_ID  ,\
       			B.DRV_MSG_CODE AS MSG_CODE  ,\
       			B.DRV_SEGMENT AS SEGMENT ,\
       			B.DRV_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE,\
	   		B.DRV_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,\
	   		B.DRV_SL_AT_FLAG  AS SL_AT_FLAG,\
	   		B.DRV_PR_ST_FLAG  AS PR_ST_FLAG,\
       			B.DRV_PAN_NO AS PAN_NO ,\
       			B.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE  ,\
       			B.DRV_SETTLOR AS  SETTLOR,\
       			B.DRV_MKT_PROTECT_FLG AS  MKT_PROTECT_FLG,\
      	 		B.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL  ,\
       			B.DRV_GTC_FLG AS GTC_FLG  ,\
       			B.DRV_ENCASH_FLG AS ENCASH_FLG ,\
       			B.DRV_GROUP_ID AS GROUP_ID \
       			FROM  DRV_ORDERS B , (SELECT M.DRV_ORDER_NO AS ORD,M.DRV_LEG_NO AS LEG,MAX(M.DRV_SERIAL_NO) AS SER FROM DRV_ORDERS M WHERE 1=1 %s \
			GROUP BY M.DRV_ORDER_NO,M.DRV_LEG_NO) AS Y\
                   WHERE\
                        (B.DRV_SERIAL_NO =Y.SER)\
                         AND  (B.DRV_ORDER_NO = Y.ORD)\
                         AND (B.DRV_LEG_NO=Y.LEG) %s\
UNION ALL \
			SELECT  C.COMM_ORDER_NO AS ORDER_NO ,\
			C.COMM_SERIAL_NO AS SERIAL_NO ,\
        		C.COMM_SCRIP_CODE AS  SCRIP_CODE,\
        		C.COMM_MKT_TYPE AS MKT_TYPE ,\
        		C.COMM_EXCH_ID AS EXCH_ID ,\
        		C.COMM_ENTITY_ID AS  ENTITY_ID,\
        		C.COMM_CLIENT_ID  AS  CLIENT_ID,\
        		C.COMM_BUY_SELL_IND  AS BUY_SELL_IND,\
        		C.COMM_TOTAL_QTY AS TOTAL_QTY ,\
        		C.COMM_REM_QTY  AS  REM_QTY,\
        		C.COMM_DISC_QTY AS DISC_QTY  ,\
        		C.COMM_DISC_REM_QTY AS  DISC_REM_QTY   ,\
        		C.COMM_TOTAL_TRADED_QTY  AS TOTAL_TRADED_QTY ,\
        		C.COMM_ORDER_PRICE  AS ORDER_PRICE ,\
       	 		C.COMM_TRIGGER_PRICE   AS TRIGGER_PRICE ,\
        		C.COMM_VALIDITY  AS VALIDITY  ,\
        		C.COMM_ORDER_TYPE  AS ORDER_TYPE ,\
        		C.COMM_USER_ID  AS  USER_ID ,\
        		C.COMM_MIN_FILL_QTY  AS  MIN_FILL_QTY,\
        		C.COMM_PRO_CLIENT  AS PRO_CLIENT ,\
        		C.COMM_USER_TYPE  AS USER_TYPE ,\
        		C.COMM_REMARKS  AS REMARKS,\
        		C.COMM_SOURCE_FLG  AS SOURCE_FLG ,\
        		C.COMM_PRODUCT_ID  AS PRODUCT_ID ,\
        		C.COMM_MSG_CODE AS MSG_CODE ,\
       	 		C.COMM_SEGMENT AS SEGMENT ,\
        		C.COMM_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE ,\
			C.COMM_PR_ABSTICK_VALUE  AS PR_ABSTICK_VALUE ,\
			C.COMM_SL_AT_FLAG  AS SL_AT_FLAG,\
			C.COMM_PR_ST_FLAG  AS PR_ST_FLAG,\
        		C.COMM_PAN_NO  AS  PAN_NO,\
        		C.COMM_PARTICIPANT_TYPE AS  PARTICIPANT_TYPE ,\
        		C.COMM_SETTLOR   AS SETTLOR  ,\
        		C.COM_MKT_PROTECT_FLG   AS  MKT_PROTECT_FLG,\
        		C.COMM_MKT_PROTECT_VAL  AS MKT_PROTECT_VAL ,\
        		C.COMM_GTC_FLG  AS   GTC_FLG ,\
        		C.COMM_ENCASH_FLG  AS  ENCASH_FLG,\
        		C.COMM_GROUP_ID  AS  GROUP_ID  \             
        		FROM COMM_ORDERS  C  ,(SELECT N.COMM_ORDER_NO AS ORD,N.COMM_LEG_NO AS LEG,MAX(N.COMM_SERIAL_NO) AS SER FROM COMM_ORDERS N WHERE 1=1 %s \
                        GROUP BY N.COMM_ORDER_NO,N.COMM_LEG_NO) AS Z \
		WHERE \
	                (C.COMM_SERIAL_NO =Z.SER)\
                        AND  (C.COMM_ORDER_NO = Z.ORD)\
                        AND (C.COMM_LEG_NO=Z.LEG) %s\
                        ) AS P;", sClause, sClauseOuter, sClause1,sClauseOuter1,sClause2,sClauseOuter2);
	printf("sSelQry :%s:\n",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEqBoOrdExit Query.");
		exit(ERROR);
	}
	else
	{
		logDebug2("*****Query Executed Successfully*****");
	}
	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	iCanCount = iNoOfRec;
	logDebug2("iCanCount  = :%d:",iCanCount);	
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	

	logDebug2("fEqBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = iUserId;
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.fAlgoOrderNo	= -1 ;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= 0;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.BoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cFlag 	  = '0';
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[31][0];
			strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[35][0];
			pEOrdReq.cEncashFlag= Row[36][0];
			pEOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);
			logDebug2(" pEOrdReq.BoArray[0].cBuySellInd :%c: ",pEOrdReq.BoArray[0].cBuySellInd);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fBulkBoOrdExit [EXIT]");
	return TRUE;
}
