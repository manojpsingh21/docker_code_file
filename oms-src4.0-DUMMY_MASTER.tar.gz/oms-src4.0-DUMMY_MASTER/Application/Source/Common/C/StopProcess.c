#include "IPCS.h"
#include <string.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <poll.h>

struct  ProcessMonitorArray * MemArray;
void Sleep ( int TimeSleep )
{
	logTimestamp("Entry : [Sleep]");	
	poll((struct pollfd **) NULL, 0,TimeSleep  );
	logTimestamp("Exit : [Sleep]");
}


int KillCommand ( int ChildId ,int Signal)
{
	logTimestamp("Entry : [KillCommand]");
	char Command[200];
	int i;
	/*	sprintf(Command,"ps -e -o user -o pid -o pgid | grep $LOGNAME | awk ' $2 ==\"%d\" {command=sprintf(\"kill -%d %s\", $3); system(command) } ' ",ChildId,Signal,"-%s"); */

	sprintf(Command,"%s %d %d","KillScript.sh",ChildId,Signal);
	logTimestamp("Exit : [KillCommand]");
	return( system(Command));

}


Kill ( int ChildId )
{
	logTimestamp("Entry : [Kill]");
	if( ChildId > 0 )
	{
		if ( KillCommand (ChildId,SIGTERM) != 0 )
		{
			logDebug3("kill failed\n" ) ;
			DeleteProcessMem ( ChildId,MemArray);
			return ;
		}
		Sleep(100);
		if ( kill (ChildId,0) == 0 )
		{
			Sleep(100);
			if ( KillCommand (ChildId,SIGKILL) != 0 )
			{
				logDebug3("kill failed second time\n" ) ;
				DeleteProcessMem ( ChildId,MemArray);
				return;
			}
		}
		DeleteProcessMem ( ChildId,MemArray);
	}
	logTimestamp("Exit : [Kill]");
}


int main (int argc,char ** argv )
{
	logTimestamp("Entry : [main]");
	int     ChildId;
	int     iProcessId =0;
	int     sProcessIdArr[MAX_NO_OF_SYSTEM_PROCESS];
	char    MainProcess[50];
	int     i,error_ind = 0;

	setbuf ( stdout,NULL);
	setbuf ( stdin ,NULL);

	signal(SIGCHLD,SIG_IGN);
	/***
	  if(fork()!=0)
	  {
	  exit (0);
	  }
	 ****/
	if ( argc != 2 )
	{
		logFatal("Error\n");
		exit(1);
	}
	LockShm(ProcessMonitorShm);
	MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
	if( *((int *)MemArray) == ERROR )
	{
		logFatal("StopCommand.c: ProcessMonitorArray:Open error\n");
		UnLockShm(ProcessMonitorShm);
		exit(1);
	}
	if ( strcmp ( argv[1],"ALL") == 0 )
	{
		for( i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i++ )
		{
			sProcessIdArr[i] = 0;
			if (MemArray->ProcessMonitor[i].iProcessId != UNUSED )
				sProcessIdArr[i] = MemArray->ProcessMonitor[i].iProcessId;
		}
		for( i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i++ )
		{
			Kill (sProcessIdArr[i] );
			error_ind = 1;
		}
	}
	else
	{
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			if (strcmp(MemArray->ProcessMonitor[i].sMainProcessName,argv[1]) == 0 && MemArray->ProcessMonitor[i].iProcessId != UNUSED )
			{
				iProcessId = MemArray->ProcessMonitor[i].iProcessId;
				Kill (iProcessId );
				error_ind = 1;
			}
		}
		if (error_ind != 1)
		{
			for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
			{

				if (strcmp(MemArray->ProcessMonitor[i].sProcessName,argv[1]) == 0 && MemArray->ProcessMonitor[i].iProcessId !=UNUSED )
				{
					iProcessId = MemArray->ProcessMonitor[i].iProcessId;
					Kill (iProcessId );
					error_ind = 1;
				}
			}
		}
	}
	if ((CloseSharedMemory(MemArray)) == ERROR )
	{
		logFatal("Error In Closing MemArray\n");
		exit(1);
	}
	UnLockShm(ProcessMonitorShm);
	if(error_ind == 0)
	{
		logFatal("There is no process to be stopped....\n");
		exit(2);
	}
	logTimestamp("Exit : [main]");
	exit(0);
}

