#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define min 40
#define max 125

int	i = 0;

void Scramble(char *sStr);
void Unscramble(char *sStr);
void IniFile(char *sStr);

main(int argc, char **argv)
{
	char 	cMsgType;
	char    sMsg[20];
	char    sReadMsg[20];
	FILE	*fPointer;

	memset(sMsg,'\0',sizeof(sMsg));
	memset(sReadMsg,'\0',sizeof(sMsg));


	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	if(argc != 3)
	{
		printf("StringScramble <MsgType> <String>(MsgType : E = Encrypt ; D = Decrypt ;F = Create and Write Into .ini File[date Format YYYY-MM-DD 00:00:00])\n");
		exit(1);
	}
	else
	{
		cMsgType = argv[1][0];
		strncpy(sReadMsg,argv[2],20);
	}

	printf("cMsgType :%c:  sReadMsg :%s:\n",cMsgType,sReadMsg);

	if(cMsgType == 'E')
	{
		Scramble(sReadMsg);
		printf("Encrypted OutPut :%s:\n",sReadMsg);
	}
	else if(cMsgType == 'D')
	{
		Unscramble(sReadMsg);
		printf("Decrypted OutPut :%s:\n",sReadMsg);
	}
	else if(cMsgType == 'F')
	{
		IniFile(sReadMsg);
	}


	return 0;
}

void Scramble(char *sStr)
{
	for(i = 0; i < strlen(sStr); i++)
	{
		//printf("%i\n",sStr[i] % 10);
		if((sStr[i] + i) > max)
		{
			sStr[i] = (sStr[i] + i) - max + min;
		}
		else 
		{
			sStr[i] = sStr[i] + i;
		}
	}
}

void Unscramble(char *sStr)
{
	for(i = strlen(sStr) - 1; i >= 0; i--)
	{
		//printf("%c\n",sStr[i]);
		if((sStr[i] - i) < min)
		{
			sStr[i] = max - (min - (sStr[i] - i));
		}
		else 
		{
			sStr[i] = sStr[i] - i;
		}
	}
}

void IniFile(char *sStr)
{
	FILE	*fPointer,*Open;
	fPointer = fopen("License.ini","wb");
	char	sUnixDate[20];
	char	sCommand[30];
	memset(sCommand,'\0',30);
	//memset(sUnixDate,'\0',20);

	if(fPointer == NULL)
	{
		perror("Error in Opening License.ini file :");
		exit(1);
	}
	sprintf(sCommand,"date -d \"%s GMT\" \'+%%s\'",sStr); // Date Format [YYYY-MM-DD 00:00:00]	

	printf("sCommand :%s:\n",sCommand);

	//long iUnixDate = system(sCommand);
	Open = popen(sCommand,"r");

	if(fgets(sUnixDate, sizeof(sUnixDate), Open) == NULL)	
	{
		printf("Some Error Occured\n");
		exit(1);
	}
	printf("sUnixDate :%s:",sUnixDate);	

	Scramble(sUnixDate);			
	printf("sUnixDate :%s:",sUnixDate);	
	fwrite(sUnixDate,sizeof(sUnixDate),1,fPointer);

	fclose(fPointer);
}
