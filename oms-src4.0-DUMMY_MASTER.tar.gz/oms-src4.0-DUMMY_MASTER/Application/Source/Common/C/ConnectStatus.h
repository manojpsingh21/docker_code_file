#ifndef         _CONN_STATUS_H
#define         _CONN_STATUS_H

//#include "Common.h"
#include "IPCS.h"
#include "IntTCodes.h"
//#include "Comm_def.h"


extern BOOL UpdateConnectStatus(SHORT,LONG32,LONG32,BOOL);
/*extern BOOL UpdateConnectStatus(SHORT,LONG32,LONG32);*/
extern CHAR Read_ConnectStatShm(SHORT,LONG32);
BOOL fOpenBcastSocket();
BOOL fConnectToOracle();
/***************
#pragma pack(1)
struct COMPRESSION_INTERNAL_DATA_ITS
{
CHAR            IsCompressed;
SHORT           data_len;
CHAR            broadcast_data[MAX_PACKET_SIZE_COMPRESS];
};
#pragma pack()

#pragma pack(1)
struct BCAST_HEADER_ITS
{
int8_t   MsgCode ;
int8_t   No_Records ;
};
#pragma pack()*************/
#pragma pack(4)

struct  INT_BCAST_HEADER
{
	SHORT       MsgCode                    ;
	CHAR        ExcgId[EXCHANGE_LEN]       ;
};
#pragma pack()

#pragma pack(1)
struct CONNECT_STATUS
{
	CHAR NseEqu;
	CHAR NseDrv;
	CHAR BseEqu;
	CHAR BseDrv;
	CHAR NseCur;
	/*****  CHAR Dma; ****/
	CHAR MCXComm;
	CHAR Reserved2;
	CHAR Reserved3;
};
#pragma pack()

#pragma pack(1)
struct BCAST_HEADER_ITS
{
	int8_t   MsgCode ;
	int8_t   No_Records ;
};

#pragma pack(1)
struct BCAST_CONNECT_STATUS
{
	struct BCAST_HEADER_ITS         BHeader;
	struct CONNECT_STATUS           CStatus[MAX_GROUPS];
};
#pragma pack()

#pragma pack(4)
struct CONNECT_STATUS_RESP
{
	struct INT_COMMON_RESP_HDR RespHeader;
	struct CONNECT_STATUS   CStatus[MAX_GROUPS];
};
#pragma pack()

#endif
