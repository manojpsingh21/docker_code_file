#include <stdio.h>
#include <stdlib.h>
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"


LONG32	iMmapToD2C1;
LONG32	iOrdSrvToTrdRtr;
redisContext *RediCon;
redisReply *reply;	

LONG32		iCnt = 0;

main(int argc, char *argv[])
{
	logTimestamp("Entry in main");
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	OpenMsgQue();
	RediCon = RDConnect(REDIS_TYPE_CLIENT_ADD);
	fAdminNotification();
}

LONG32 fAdminNotification()
{
	logTimestamp("Entry [fAdminNotification]");
	struct  INT_ERROR_FE_RESP pErrorResponce;

	CHAR    RecBuff[RUPEE_MAX_PACKET_SIZE];
	LONG64  iEntryTime;
	BOOL	iCheckFlag = FALSE;
	LONG32	iMsgCode ;
	CHAR 	sCommand[MAX_QUERY_SIZE];
	CHAR 	sKeyValue[DB_REASON_DESC_LEN];
	INT16	iCount = 0;

	while(TRUE)
	{	
		memset(sCommand,'\0',MAX_QUERY_SIZE);
		sprintf(sCommand,"SUBSCRIBE CLIENTADD");
		logDebug2("sCommand -> %s",sCommand);
		reply = fRedisCommand(RediCon,sCommand,REDIS_TYPE_CLIENT_ADD);
		logDebug2("INCR counter: %lld\n", reply->integer);

		while(redisGetReply(RediCon,(void**)&reply) == REDIS_OK)
		{
			memset(sKeyValue,'\0',DB_REASON_DESC_LEN);
			memset(&pErrorResponce, '\0', sizeof(struct INT_ERROR_FE_RESP));

			if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3)
			{
				fprintf(stderr, "Error:  Malformed subscribe response!\n");
				exit(-1);
			}

			logInfo("Channel: %s", reply->element[1]->str);
			logInfo("Received message: %s", reply->element[2]->str);
			sprintf(sKeyValue,"%s",reply->element[2]->str);
			freeReplyObject(reply);

			logDebug2("iMsgCode = %d",TC_INT_CLIENT_ADDED_NOTIFICATION);		

			pErrorResponce.IntRespHeader.iMsgLength = sizeof(struct INT_ERROR_FE_RESP);
			pErrorResponce.IntRespHeader.iErrorId = 0;
			pErrorResponce.IntRespHeader.iMsgCode = TC_INT_CLIENT_ADDED_NOTIFICATION;
			pErrorResponce.IntRespHeader.iUserId = 123;
			logDebug2("pErrorResponce.IntRespHeader.iUserId :%llu:",pErrorResponce.IntRespHeader.iUserId);
			pErrorResponce.IntRespHeader.iSeqNo = 0;
			pErrorResponce.IntRespHeader.cSource = SOURCE_ADMIN;
			pErrorResponce.IntRespHeader.cSegment = "";

			strncpy(pErrorResponce.IntRespHeader.sExcgId,"NA",EXCHANGE_LEN);

			strncpy(pErrorResponce.sSecurityId,"NA",SECURITY_ID_LEN);
			strncpy(pErrorResponce.sClientId,"",CLIENT_ID_LEN);
			pErrorResponce.cProductId = '%';
			pErrorResponce.cBuyOrSell = '%';
			pErrorResponce.iTotalQty = 0;
			pErrorResponce.fPrice = 0.00;
			strncpy(pErrorResponce.sErrorMsg,sKeyValue,DB_REASON_DESC_LEN);
			logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);

			if((WriteMsgQ(iMmapToD2C1,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
			{
				logFatal("Error : WriteMsgQ failed in SendErrorToFE.");
				exit(ERROR);
			}
			if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
			{
				logFatal("Error : WriteMsgQ failed in SendErrorToFE.");
				exit(ERROR);
			}


		}
		logError("Redis connection dropped, trying to reconnnect again");
		sleep(5);
		RediCon = RDConnect(REDIS_TYPE_CLIENT_ADD);
	}
	logTimestamp("EXIT [fAdminNotification]");	

}


void OpenMsgQue()
{
	logTimestamp("Entry in msg queue.");

	if((iMmapToD2C1 = OpenMsgQ(MmapToD2C1)) == ERROR)
	{
		logFatal("Error in open queue (MmapToD2C1)");
		exit(ERROR);
	}
	logInfo("OrdRtrToDeaNotify open successfully with id = %d ",iMmapToD2C1);

	if((iOrdSrvToTrdRtr = OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal("Error in open queue (OrdSrvToTrdRtr)");
		exit(ERROR);
	}
	logInfo("DeaNotiToTrdRtr open successfully with id = %d ",iOrdSrvToTrdRtr);

	logTimestamp("Exit [OpenMsgQue]");
}
