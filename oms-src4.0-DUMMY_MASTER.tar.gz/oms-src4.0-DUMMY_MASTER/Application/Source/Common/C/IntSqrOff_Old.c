#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

LONG32 	iAutoSqoffToOrdRtr;
LONG32	iRDaemonToSqoff;
LONG32	iMsgType = 0;
LONG32	iCount = 0;

SHORT	fTrim(CHAR * sStr_In ,SHORT iMaxLen);
MYSQL	*DB_IntSqr;
CHAR    sAdmin [15];
CHAR	sFreuency[SIP_REG_NEM_LEN];
CHAR	sBatchName[20];
CHAR	cFrency	= '\0';
BOOL    fPumpOffOrdSIP(CHAR *RcvMsg,CHAR cFreuency);
BOOL    fUpdtOffMktBPSIP(CHAR *RcvMsg, CHAR sBatchName[20]);
main(INT16 argc, CHAR **argv)
{
	BOOL	iRetVal;
	CHAR	sMsgType [3];
	CHAR	cDay[SIP_REG_NEM_LEN];
	CHAR	cTDay[SIP_REG_NEM_LEN];

	LONG32  iMsgCode , iRow ,iValue;
	CHAR	cSegment;
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;

	LONG64	Time = 0;
	CHAR	sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	struct 	ORDER_REQUEST	*pSrOfOrd;
	struct  INT_COMMON_REQUEST_HDR *pIntHeadr;
	CHAR    sSelectQry[MAX_QUERY_SIZE];
	CHAR    sQry1[MAX_QUERY_SIZE];
	CHAR    sQry2[MAX_QUERY_SIZE];

	memset(sFreuency,'\0',SIP_REG_NEM_LEN);
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	memset(sQry1,'\0',MAX_QUERY_SIZE);
	memset(sQry2,'\0',MAX_QUERY_SIZE);
	memset(sAdmin ,'\0',15);
	memset(sMsgType,'\0',3);
	memset(cDay,'\0',SIP_REG_NEM_LEN);
	memset(cTDay,'\0',SIP_REG_NEM_LEN);

	setbuf(stdout,NULL);
	setbuf(stdin, NULL );
	OpenMsgQue();
	//	cMsgType = argv[1][0];
	//       iMsgType = cMsgType - '0';

	logDebug2("argv[1]:%s:",argv[1]);
	strcpy(sMsgType,argv[1]);
	iMsgType = atoi(sMsgType);

	logDebug2("sMsgType[%s] iMsgType[%d]",sMsgType,iMsgType);

	DB_IntSqr = DB_Connect();
	while(1)
	{
		memset(&sRcvMsg,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(&pSrOfOrd,'\0',sizeof(struct ORDER_REQUEST));
		logDebug2("iMsgType :%d:",iMsgType);	

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if(ReadMsgQ(iRDaemonToSqoff,&sRcvMsg,RUPEE_MAX_PACKET_SIZE,iMsgType) != 1)
		{
			logFatal("Error : MsgQID is %d",iRDaemonToSqoff);
			exit(ERROR);
		}

		pSrOfOrd = (struct ORDER_REQUEST *)&sRcvMsg;

		iMsgCode = pSrOfOrd->ReqHeader.iMsgCode;
		logDebug2("iMsgCode = %d",iMsgCode);
		logDebug2("SEGMENT :%c:",pSrOfOrd->ReqHeader.cSegment);
		logDebug2("EXCAHNGE :%s:",pSrOfOrd->ReqHeader.sExcgId);

		sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  = 'Default_admin' ");	

		if (mysql_query(DB_IntSqr ,sSelectQry) != SUCCESS)
		{
			sql_Error(DB_IntSqr);
			logSqlFatal("Error Fetching SysAdmin .");
			exit(ERROR);
		}
		logDebug2("Query [%s]",sSelectQry);

		Res = mysql_store_result(DB_IntSqr);
		iRow = (mysql_num_rows(Res));
		if(iRow == 0)
		{
			mysql_free_result(Res);
			logDebug2("Zero rows selected");
		}	
		else
		{
			if (Row = mysql_fetch_row(Res))
			{
				strncpy(sAdmin,Row[0],15);			
				logDebug2("Printing name of Admin :%s:",sAdmin);
			}
		}
		mysql_free_result(Res);
		if(iMsgCode == TC_INT_SQUAREOFF_INTRADAY_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);	
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlEqPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Cancelled Failed");	
				}
				else
				{
					logInfo("Equity Orders Cancelled Sucessfully");
				}						

				sleep(5);	

				iRetVal = fSqrOffEqSellOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Sell Equity Orders Failed");
				}	
				else
				{
					logInfo("SquareOff of Sell Equity Orders Sucess");	
				}

				iRetVal=fSqrOffEqBuyOrd(&sRcvMsg);		
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Buy Equity Orders Failed");	
				}
				else
				{
					logInfo("SquareOff of Buy Equity Orders Sucess");
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}	
			else 	if((pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlDrPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Derivative Orders Cancelled Failed");
				}
				else
				{
					logInfo("Derivative Orders Cancelled Sucessfully");
				}

				sleep(30);

				iRetVal = fSqrOffDrSellOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Sell Derivative Orders Failed");
				}
				else
				{
					logInfo("SquareOff of Sell Derivative Orders Sucess");
				}

				iRetVal=fSqrOffDrBuyOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Buy Derivative Orders Failed");
				}
				else
				{
					logInfo("SquareOff of Buy Derivative Orders Sucess");
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Derivative");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Derivative");
				}


			}
			else if(pSrOfOrd->ReqHeader.cSegment == COMMODITY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlMcxPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Cancelled Failed");
				}
				else
				{
					logInfo("Equity Orders Cancelled Sucessfully");
				}

				sleep(30);

				iRetVal = fSqrOffMcxSellOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Sell Equity Orders Failed");
				}
				else
				{
					logInfo("SquareOff of Sell Equity Orders Sucess");
				}

				iRetVal=fSqrOffMcxBuyOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Buy Equity Orders Failed");
				}
				else
				{
					logInfo("SquareOff of Buy Equity Orders Sucess");
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Commodity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Commodity");
				}

			}	
			else
			{
				logInfo("Invalid Segment :%c:",pSrOfOrd->ReqHeader.cSegment);	
			}
		}
		else if(iMsgCode == TC_INT_SQUAREOFF_COVER_ORD_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT)
			{
				iRetVal = fBlockCoverOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockCoverOrd");
				}
				else
				{
					logInfo("Cover  Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fEqCoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Exit  Failed");
				}
				else
				{
					logInfo("Equity Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}
			else    if((pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockCoverOrd (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fDrvCoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Derivative/Currency  Orders Exit  Failed");
				}
				else
				{
					logInfo("Derivative/Currency Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Derivative");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Derivative");
				}


			}
			else
			{
				logInfo("Invalid Segment :%c:",pSrOfOrd->ReqHeader.cSegment);
			}
		}
		else if(iMsgCode == TC_INT_SQUAREOFF_BRACKET_ORD_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == EQUITY_SEGMENT)
			{
				iRetVal = fBlockBoOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockBoOrd ");
				}
				else
				{
					logInfo("Bracket  Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fEqBoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Exit  Failed");
				}
				else
				{
					logInfo("Equity Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}
			else    if((pSrOfOrd->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockBoOrd (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! fBlockBoOrd ");
				}
				else
				{
					logInfo("Bracket  Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fDrvBoOrdExit (&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Derivative/Currency  Orders Exit  Failed");
				}
				else
				{
					logInfo("Derivative/Currency Orders Exit Sucessfully");
				}

				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Derivative");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Derivative");
				}


			}
			else
			{
				logInfo("Invalid Segment :%c:",pSrOfOrd->ReqHeader.cSegment);
			}

		}

		else if(iMsgCode == TC_INT_PUMPOFFLINE_REQ)
		{
			pIntHeadr = (struct  INT_COMMON_REQUEST_HDR *)&sRcvMsg;
			cSegment = pIntHeadr->cSegment;
			logDebug2("cSegment :%c:",cSegment);

			if(cSegment == EQUITY_SEGMENT)
			{
				logDebug1("THIS IS EQUITY ");
				if(fDisableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDisableOffMkt Equity");
					return FALSE;
				}
				logDebug3("Success : fDisableOffMkt Equity");

				if(fEquPumpOffOrd(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEquPumpOffOrd Equity");
					return FALSE;
				}
				logDebug3("Success : fEquPumpOffOrd Equity");

				if(fUpdtOffMktBP(&sRcvMsg) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBP Equity");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBP Equity");
				sleep(1);
				if(fEnableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEnableOffMkt Equity");
					return FALSE;
				}
				logDebug3("Success : fEnableOffMkt Equity");

			}		
			else if((cSegment == DERIVATIVE_SEGMENT) || (cSegment == CURRENCY_SEGMENT))
			{
				logDebug1("THIS IS DERIVATIVE ");
				if(fDisableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDisableOffMkt Derivative");
					return FALSE;
				}
				logDebug3("Success : fDisableOffMkt Derivative");

				if(fDrvPumpOffOrd(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDrvPumpOffOrd Derivative");
					return FALSE;
				}
				logDebug3("Success : fDrvPumpOffOrd Derivative");

				if(fUpdtOffMktBP(&sRcvMsg) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBP Derivative");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBP Derivative");
				sleep(1);
				if(fEnableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEnableOffMkt Derivative");
					return FALSE;
				}
				logDebug3("Success : fEnableOffMkt Derivative");

			}
			else if(cSegment == COMMODITY_SEGMENT)
			{

				logDebug1("THIS IS COMMODITY");
				if(fDisableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fDisableOffMkt Commodity");
					return FALSE;
				}
				logDebug3("Success : fDisableOffMkt Commodity");

				if(fCommPumpOffOrd(pIntHeadr) == FALSE)
				{
					logFatal("Error : fCommPumpOffOrd Commodity");
					return FALSE;
				}
				logDebug3("Success : fCommPumpOffOrd Commodity");

				if(fUpdtOffMktBP(&sRcvMsg) == FALSE)
				{
					logFatal("Error : fUpdtOffMktBP Commodity");
					return FALSE;
				}
				logDebug3("Success : fUpdtOffMktBP Commodity");

				if(fEnableOffMkt(pIntHeadr) == FALSE)
				{
					logFatal("Error : fEnableOffMkt Commodity");
					return FALSE;
				}
				logDebug3("Success : fEnableOffMkt Commodity");

			}
			else
			{
				logFatal("Invalid Segment :%c:",cSegment);
				return FALSE;
			}	
		}
		else if(iMsgCode == TC_INT_SIP_ORD_REQ)
		{
			if(fPumpOffOrdSIP(&sRcvMsg,SIP_DY) == FALSE)
			{
				logFatal("Error fPumpOffOrdSIP Equity.. for day");
				return FALSE;
			}
			logDebug3("Success : fPumpOffOrdSIP Equity.. for day");	

			logDebug2("***************************");

			if(fUpdtOffMktBPSIP(&sRcvMsg,&SIP_DAY) == FALSE)
			{
				logFatal("Error : fUpdtOffMktBPSIP Equity for day");
				return FALSE;
			}
			logDebug3("Success : fUpdtOffMktBPSIP Equity for day");

			logDebug2("******** WEEK ********");

			sprintf(sQry1," SELECT CASE WHEN DATE(BP_NEXT_SCHEDULE_DATE) = DATE(SYSDATE()) THEN '%d' ELSE '%d' END \
					FROM BATCH_PROCESS A WHERE A.BP_BATCH_NAME = \'%s\' AND A.BP_EXCH_ID = \'%s\';",TRUE,FALSE,SIP_WEEK,pSrOfOrd->ReqHeader.sExcgId);

			logDebug1("QUERY :%s:",sQry1);

			if (mysql_query(DB_IntSqr,sQry1) != SUCCESS)
			{
				sql_Error(DB_IntSqr);
				logSqlFatal("Error in select date for WEEK.");
				return ERROR;
			}

			Res = mysql_store_result(DB_IntSqr);
			if(mysql_num_rows(Res) == 0)
			{
				logFatal("!!!!!!! Zero row returned for WEEK !!!!!! ");
				mysql_free_result(Res);
				return FALSE;
			}
			else
			{
				Row = mysql_fetch_row(Res);
				iValue = atol(Row[0]);
			}
			logDebug2("iValue = %d",iValue);

			if(iValue == TRUE)
			{
				if(fPumpOffOrdSIP(&sRcvMsg,SIP_WK) == FALSE)
				{
					logFatal("Error fPumpOffOrdSIP Equity.. for Week");
					return FALSE;
				}
				logDebug3("Success : fPumpOffOrdSIP Equity.. for Week");
			}

			if(fUpdtOffMktBPSIP(&sRcvMsg,&SIP_WEEK) == FALSE)
			{
				logFatal("Error : fUpdtOffMktBPSIP Equity for Week");
				return FALSE;
			}
			logDebug3("Success : fUpdtOffMktBPSIP Equity for Week");

			logDebug2("************** END WEEK *************");

			//			sprintf(sQry2,"select DATE_FORMAT(BP_NEXT_SCHEDULE_DATE,'%d') - DATE_FORMAT(SYSDATE(),'%d') \
			FROM BATCH_PROCESS where BP_BATCH_NAME = 'SIP_MONTHLY';")
				sprintf(sQry2," SELECT CASE WHEN DATE(BP_NEXT_SCHEDULE_DATE) = DATE(SYSDATE()) THEN '%d' ELSE '%d' END FROM BATCH_PROCESS A \
						WHERE A.BP_BATCH_NAME = \'%s\' AND A.BP_EXCH_ID = \'%s\';",TRUE,FALSE,SIP_MONTH,pSrOfOrd->ReqHeader.sExcgId);

			logDebug1("QUERY :%s:",sQry2);

			if (mysql_query(DB_IntSqr,sQry2) != SUCCESS)
			{
				sql_Error(DB_IntSqr);
				logSqlFatal("Error in select date for month.");
				return ERROR;
			}

			Res = mysql_store_result(DB_IntSqr);
			if(mysql_num_rows(Res) == 0)
			{
				logFatal("!!!!!!! Zero row returned.. !!!!!! ");
				mysql_free_result(Res);
				return FALSE;
			}
			else
			{
				Row = mysql_fetch_row(Res);
				iValue = atol(Row[0]);
			}
			logDebug2("iValue = %d",iValue);	

			if(iValue == TRUE)
			{
				if(fPumpOffOrdSIP(&sRcvMsg,SIP_MON) == FALSE)
				{
					logFatal("Error fPumpOffOrdSIP Equity.. for month");
					return FALSE;
				}
				logDebug3("Success : fPumpOffOrdSIP Equity.. for month");
			}
			if(fUpdtOffMktBPSIP(&sRcvMsg,&SIP_MONTH) == FALSE)
			{
				logFatal("Error : fUpdtOffMktBPSIP Equity for Month");
				return FALSE;
			}
			logDebug3("Success : fUpdtOffMktBPSIP Equity for Month");

			if(fSIPStatusUptd() == FALSE)
			{
				logFatal("ERROR in fSIPStatusUptd function");
				return FALSE;
			}
			logDebug3("Sucess : fSIPStatusUptd");

		}
		else if(iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ)
		{
			if(pSrOfOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
			{
				iRetVal = fBlockIntraday(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Failed !!! Intraday Orders Blocked");
				}
				else
				{
					logInfo("Intraday Orders Blocked Sucessfully Sucessfully");
				}

				iRetVal = fCnlCCPendingOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Equity Orders Cancelled Failed");
				}
				else
				{
					logInfo("Equity Orders Cancelled Sucessfully");
				}

				sleep(5);

				iRetVal = fSqrOffCCSellOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Sell Equity Orders Failed");
				}
				else
				{
					logInfo("SquareOff of Sell Equity Orders Sucess");
				}

				iRetVal=fSqrOffCCBuyOrd(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("SquareOff of Buy Equity Orders Failed");
				}
				else
				{
					logInfo("SquareOff of Buy Equity Orders Sucess");
				}
				iRetVal= fUpdtOffMktBP(&sRcvMsg);
				if(iRetVal == FALSE)
				{
					logInfo("Error : fUpdtOffMktBP Equity");
				}
				else
				{
					logInfo("Success : fUpdtOffMktBP Equity");
				}
			}
		}
		else
		{
			logInfo("Invalid MsdCode :%d:",iMsgCode);
		}

	}

	return TRUE;	

}

BOOL	fSIPStatusUptd()
{
	logTimestamp("Enrty fSIPStatusUptd");

	CHAR	sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);

	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;	

	sprintf(sQry," update SIP_ORDERS set SIP_ORD_STATUS = '%c' where SIP_ORD_STATUS != '%c' AND(DATE(SIP_EXPIRE_DATE) < DATE(SYSDATE()));",\
			EXCH_DELETE_STATUS,EXCH_DELETE_STATUS);

	logDebug2("Query [%s]",sQry);

	if (mysql_query(DB_IntSqr ,sQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error UPDATE SIP_ORDERS STATUS .");
		exit(ERROR);
	} 
	else
	{
		logSqlFatal("UPDATED SUCEESSFULLY SIP_ORDERS STATUS");
	}
	logTimestamp("Exit fSIPStatusUptd");
	return TRUE;

}

BOOL    fPumpOffOrdSIP(CHAR *RcvMsg,CHAR cFreuency)
{
	logTimestamp("Entry in fPumpOffOrdSIP");

	CHAR    *sQuery1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	memset(sQuery1,'\0',MAX_QUERY_SIZE);
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;

	LONG32	iNoOfRow;

	struct  ORDER_REQUEST   *pSIPOrd;	
	struct  ORDER_REQUEST   pSIPOrdReq;
	pSIPOrd = (struct  ORDER_REQUEST *)RcvMsg ;

	/*        sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
		  SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
		  SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM SIP_ORDERS\
		  WHERE SIP_ORD_STATUS = 'C' AND SIP_MSG_CODE IN (3000) AND SIP_EXCH_ID = \"%s\"\
		  AND SIP_SERIAL_NO= (SELECT MAX(SIP_SERIAL_NO) FROM SIP_ORDERS WHERE SIP_ORDER_NO = SIP_ORDER_NO)",pSIPOrd->ReqHeader.sExcgId);
	 */

	/*	sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
		SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
		SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM SIP_ORDERS\
		WHERE SIP_ORD_STATUS = '%c' AND SIP_MSG_CODE IN (3000) AND SIP_EXCH_ID = \"%s\"\
		AND SIP_FREQUENCY = \'%c\' AND (DATE(SIP_EXPIRE_DATE) >= DATE(SYSDATE()));",EXCH_CONFIRM_STATUS,pSIPOrd->ReqHeader.sExcgId,cFreuency);

		sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
		SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
		SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM  SIP_ORDERS a WHERE SIP_ORD_STATUS <> '%c' AND SIP_EXCH_ID = \"%s\"\
		AND SIP_FREQUENCY = \'%c\' AND (DATE(SIP_EXPIRE_DATE) >= DATE(SYSDATE())) AND SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO)\
		FROM SIP_ORDERS b WHERE a.SIP_ORDER_NO = b.SIP_ORDER_NO AND a.SIP_ORD_STATUS = '%c');",EXCH_DELETE_STATUS,\
		strncpy(pSIPOrd->ReqHeader.sExcgId,cFreuency,EXCH_CONFIRM_STATUS);
	 */	
	sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
			SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
			SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM  SIP_ORDERS a WHERE SIP_EXCH_ID = \"%s\"\
			AND SIP_FREQUENCY = \'%c\' AND (DATE(SIP_EXPIRE_DATE) >= DATE(SYSDATE())) AND SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO)\
				FROM SIP_ORDERS b WHERE a.SIP_ORDER_NO = b.SIP_ORDER_NO AND a.SIP_ORD_STATUS = '%c');",pSIPOrd->ReqHeader.sExcgId,\
			cFreuency,EXCH_CONFIRM_STATUS);

	logDebug2("sQuery1 = %s",sQuery1);

	if(mysql_query(DB_IntSqr,sQuery1)!= SUCCESS)
	{
		logSqlFatal("Error in fPumpOffOrdSIP Query.");
		sql_Error(DB_IntSqr);
		exit(ERROR);
	}
	logDebug2("Query done [fPumpOffOrdSIP]");
	Res = mysql_store_result(DB_IntSqr);

	iNoOfRow = mysql_num_rows(Res);
	logDebug2("iNoOfRow = %d",iNoOfRow);	

	while(Row = mysql_fetch_row(Res))
	{
		memset(&pSIPOrdReq,'\0',sizeof(struct ORDER_REQUEST));
		pSIPOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
		pSIPOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
		strncpy(pSIPOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
		logDebug2("pSIPOrdReq.ReqHeader.sExcgId = %s",pSIPOrdReq.ReqHeader.sExcgId);
		pSIPOrdReq.ReqHeader.cSegment = Row[5][0];
		logDebug2("pSIPOrdReq.ReqHeader.cSegment = %c",pSIPOrdReq.ReqHeader.cSegment);

		strncpy(pSIPOrdReq.sSecurityId,Row[2],SECURITY_ID_LEN);
		logDebug2("pSIPOrdReq.sSecurityId = %s",pSIPOrdReq.sSecurityId);
		strncpy(pSIPOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
		logDebug2("pSIPOrdReq.sEntityId = %s",pSIPOrdReq.sEntityId);
		strncpy(pSIPOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
		logDebug2("pSIPOrdReq.sClientId = %s",pSIPOrdReq.sClientId);
		pSIPOrdReq.ReqHeader.cSource = Row[14][0];		
		logDebug2("pSIPOrdReq.ReqHeader.cSource = %c",pSIPOrdReq.ReqHeader.cSource);
		pSIPOrdReq.cProductId = PROD_CNC;
		logDebug2("pSIPOrdReq.cProductId = %c",pSIPOrdReq.cProductId);
		pSIPOrdReq.cBuyOrSell = Row[7][0];
		pSIPOrdReq.iOrderType = atoi(Row[10]);
		pSIPOrdReq.iOrderValidity = atof(Row[9]);
		pSIPOrdReq.iDiscQty = 0;
		pSIPOrdReq.iDiscQtyRem = 0;
		pSIPOrdReq.iTotalQtyRem = 0;
		pSIPOrdReq.iTotalQty = atoi(Row[8]);
		pSIPOrdReq.iTotalTradedQty = 0;
		pSIPOrdReq.iMinFillQty = 0;
		pSIPOrdReq.fPrice = 0;
		pSIPOrdReq.fTriggerPrice = 0;
		pSIPOrdReq.fOrderNum = 0;
		//                pSIPOrdReq.iSerialNum = atoi(Row[1]);
		pSIPOrdReq.iSerialNum = 1;
		pSIPOrdReq.cHandleInst = Row[15][0];
		pSIPOrdReq.fAlgoOrderNo = atof(Row[0]);
		pSIPOrdReq.iStratergyId = 0;
		pSIPOrdReq.cOffMarketFlg = OFF_ORD_DISABLE;
		pSIPOrdReq.cProCli = Row[12][0];
		pSIPOrdReq.cUserType = Row[11][0];
		//                pSIPOrdReq.sRemarks = Row[13][0];
		strncpy(pSIPOrdReq.sRemarks ,Row[13],REMARKS_LEN);
		//                pSIPOrdReq.iMktType = Row[16][0];
		pSIPOrdReq.iAuctionNum = 0;

		if(strcmp(Row[16],MKT_TYPE_NL)== 0)
		{
			pSIPOrdReq.iMktType = NORMAL_MARKET;
		}
		else if(strcmp(Row[16],MKT_TYPE_OL) == 0)
		{
			pSIPOrdReq.iMktType = ODDLOT_MARKET;
		}
		else if(strcmp(Row[16],MKT_TYPE_SP)== 0)
		{
			pSIPOrdReq.iMktType = SPOT_MARKET;
		}
		else if(strcmp(Row[16],MKT_TYPE_AU) == 0)
		{
			pSIPOrdReq.iMktType = AUCTION_MARKET;
		}
		else
		{
			logDebug2(" %s ",Row[16]);
		}


		if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pSIPOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
		{
			logFatal("Error in sent Msg");
			mysql_free_result(Res);
			mysql_close(DB_IntSqr);
			exit(ERROR);

		}
		logDebug2("Send Msg Q Sucessfully.");

	}
	logTimestamp("Exit.... fPumpOffOrdSIP");
	return TRUE;

}
BOOL fEqCoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fEqCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32 iNoOfRec = 0 ;
	LONG32 	i = 0; 

	struct  CO_ORDER_REQUEST   *pCnlEOrd;
	struct  CO_ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  CO_ORDER_REQUEST   *)RcvMsg ;

	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_SL_ABSTICK_VALUE ,\
			EQ_PR_ABSTICK_VALUE ,\
			EQ_SL_AT_FLAG ,\
			EQ_PR_ST_FLAG \
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS IN (\'C\',\'T\')\
			AND     A.EQ_PRODUCT_ID = \'%c\'\
			AND	A.EQ_LEG_NO =	%d \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
			AND     A.EQ_EXCH_ID = \"%s\" AND A.EQ_SEGMENT = \'%c\';",PROD_COVER,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEqCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

	for(i = 0 ; i < iNoOfRec ; i++)
	{
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			//                pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iOrderValidity = VALIDITY_IOC ;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= 0 ;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.fTrailingSLValue = 0.00 ;
			pEOrdReq.fAlgoOrderNo = 0.00 ;
			pEOrdReq.iNoOfLeg = 1 ;
			pEOrdReq.iMinFillQty = atoi(Row[18]) ;
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cAvgLtpFlg = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			//		fPrintAll(pEOrdReq);
			logDebug2(" pEOrdReq.CoArray[0].cBuySellInd :%c: ",pEOrdReq.CoArray[0].cBuySellInd);
			logDebug2("pEOrdReq.CoArray[0].fTriggerPrice :%f:",pEOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pEOrdReq.CoArray[1].fTriggerPrice :%f:",pEOrdReq.CoArray[1].fTriggerPrice);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fEqCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fEqBoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fEqBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 	iNoOfRec = 0 ;
	LONG32	i = 0;

	struct  BO_ORDER_REQUEST   *pCnlEOrd;
	struct  BO_ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  BO_ORDER_REQUEST   *)RcvMsg ;
	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_SL_ABSTICK_VALUE ,\
			EQ_PR_ABSTICK_VALUE ,\
			EQ_SL_AT_FLAG ,\
			EQ_PR_ST_FLAG \
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS IN (\'C\',\'T\')\
			AND     A.EQ_PRODUCT_ID = \'%c\'\
			AND 	A.EQ_ALGO_ORDER_NO = -1 \
			AND     A.EQ_LEG_NO =   %d \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
			AND     A.EQ_EXCH_ID = \"%s\" ;",PROD_BRACKET,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEqBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fEqBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			//	                pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//	                strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			//                pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iOrderValidity = VALIDITY_IOC ;
			pEOrdReq.fAlgoOrderNo	= -1 ;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= atof(Row[0]);
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.BoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cFlag 	  = '0';
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			//	                strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			//              fPrintAll(pEOrdReq);
			logDebug2(" pEOrdReq.BoArray[0].cBuySellInd :%c: ",pEOrdReq.BoArray[0].cBuySellInd);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fEqBoOrdExit [EXIT]");
	return TRUE;
}


BOOL fCnlEqPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlEqPendingOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	CHAR		*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	

	struct	ORDER_REQUEST	*pCnlEOrd;
	struct	ORDER_REQUEST	pEOrdReq;
	LONG32 	 iNoOfRec = 0;
	LONG32 	 i= 0;

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\	
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_ALGO_ORDER_NO ,\
			EQ_STRATEGY_ID ,\
			EQ_ORDER_OFFON \					
			FROM	EQ_ORDERS A\
			WHERE 	A.EQ_ORD_STATUS = \'C\'\
			AND	A.EQ_MSG_CODE IN (2073,2074)\
			AND	A.EQ_PRODUCT_ID = \'I\'\
			AND	A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO)\
			AND	A.EQ_EXCH_ID = \"%s\" ;",pCnlEOrd->ReqHeader.sExcgId);	


	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlEqPendingOrd Query.");
		exit(ERROR);

	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);	

	for (i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));	
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);	
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			//			pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			//pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//			strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);	
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);	
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);	
			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);

			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];

			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iStratergyId= atoi(Row[27]);
			pEOrdReq.iMinFillQty = atoi(Row[18]);
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			//			pEOrdReq.cOffMarketFlg= Row[28][0];
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			//			pEOrdReq.cUserType = Row[20][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			//			strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);	
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);	


			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}	
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}	
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}	
			else
			{
				logDebug2(" %s ",Row[3]);	
			}

			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.sClientId:%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}	
	logTimestamp("EXIT  [fCnlEqPendingOrd]");	
	return TRUE;

}	


BOOL fCnlDrPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlDrPendingOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		sWhereCls[MAX_QUERY_SIZE];

	struct  ORDER_REQUEST   *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	LONG32	iNoOfRec = 0;
	LONG32	i = 0;

	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;


	if(pCnlEOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order cancel");
		sprintf(sWhereCls," AND SUBSTRING_INDEX(DRV_SYMBOL, '-', 1) not in ('EURUSD','GBPUSD','USDJPY')");

		logDebug2("sWhereCls :%s:",sWhereCls);	
	}
	else
	{
		sprintf(sWhereCls ," ");	
	}


	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT,\
			DRV_OMS_ALGO_ORD_NO ,\
			DRV_STRATEGY_ID ,\
			DRV_ORDER_OFFON \				
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'C\'\
			AND     A.DRV_MSG_CODE IN (2073,2074)\
			AND     A.DRV_PRODUCT_ID = \'I\'\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
			AND     A.DRV_EXCH_ID = \"%s\" AND DRV_SEGMENT = \'%c\' %s;",pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sWhereCls);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlDrPendingOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);

		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			//pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);

			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= 0;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			//			pEOrdReq.cOffMarketFlg= Row[28][0];
			//	                pEOrdReq.cUserType = Row[20][0]
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.iAuctionNum = 0;
			//                strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("EXIT [fCnlDrPendingOrd]");
	return TRUE;

}

BOOL fDrvCoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fDrvCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32 iNoOfRec = 0;
	LONG32 i = 0;
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  CO_ORDER_REQUEST   *pCnlEOrd;
	struct  CO_ORDER_REQUEST   pDrOrdReq;

	pCnlEOrd = (struct  CO_ORDER_REQUEST   *)RcvMsg ;

	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT\
			DRV_SL_ABSTICK_VALUE ,\
			DRV_PR_ABSTICK_VALUE ,\
			DRV_SL_AT_FLAG ,\
			DRV_PR_ST_FLAG \
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS IN (\'C\',\'T\')\
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND	A.DRV_LEG_NO = %d \
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
			AND     A.DRV_EXCH_ID = \"%s\" AND A.DRV_SEGMENT = \'%c\';",PROD_COVER,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fDrvCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fDrvCoOrdExit : Rows returned from Database = :%d:",iNoOfRec);


	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pDrOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pDrOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pDrOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			//	                pDrOrdReq.ReqHeader.cSource= Row[22][0];
			pDrOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDrOrdReq.ReqHeader.cSegment = Row[25][0];
			pDrOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pDrOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);

			strncpy(pDrOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//	                strncpy(pDrOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDrOrdReq.cProductId= Row[23][0];

			pDrOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pDrOrdReq.iOrderType = atoi(Row[16]);
			//                pDrOrdReq.iOrderValidity = atof(Row[15]);
			pDrOrdReq.iOrderValidity = VALIDITY_IOC ;
			pDrOrdReq.iTotalQty = atoi(Row[8]);
			pDrOrdReq.iTotalQtyRem = atoi(Row[8]);
			pDrOrdReq.iDiscQty = atoi(Row[10]);
			pDrOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDrOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDrOrdReq.fPrice = atof(Row[13]);
			pDrOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pDrOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pDrOrdReq.fOrderNum = atof(Row[0]);
			pDrOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pDrOrdReq.cHandleInst = Row[19][0];
			pDrOrdReq.cProCli = Row[19][0];
			//                pDrOrdReq.cUserType = Row[20][0];
			pDrOrdReq.CoArray[0].iLegValue = LEG_1 ;

			pDrOrdReq.fSLTikAbsValue = atof(Row[26]);
			pDrOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pDrOrdReq.cSLFlag  =  Row[28][0];
			pDrOrdReq.cPBFlag  = Row[29][0];
			pDrOrdReq.cAvgLtpFlg = 0;
			strncpy(pDrOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);
			pDrOrdReq.iMinFillQty = atoi(Row[18]) ;
			pDrOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pDrOrdReq.iNoOfLeg = 1 ;
			pDrOrdReq.cAvgLtpFlg = 0;
			pDrOrdReq.iStratergyId= 0 ;
			pDrOrdReq.fTrailingSLValue = 0.00 ;
			pDrOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDrOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDrOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDrOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDrOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			//			fPrintAll(pDrOrdReq);	
			logDebug2("pDrOrdReq.CoArray[0].fTriggerPrice :%f:",pDrOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pDrOrdReq.CoArray[1].fTriggerPrice :%f:",pDrOrdReq.CoArray[1].fTriggerPrice);
			logDebug2("pDrOrdReq.fOrderNum = %f ",pDrOrdReq.fOrderNum);
			logDebug2("pDrOrdReq.sClientId = %s",pDrOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pDrOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fDrvCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fDrvBoOrdExit (CHAR *RcvMsg)
{
	logTimestamp("fDrvBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32 		iNoOfRec = 0;
	LONG32 		i = 0;

	struct  BO_ORDER_REQUEST   *pCnlEOrd;
	struct  BO_ORDER_REQUEST   pDrOrdReq;

	pCnlEOrd = (struct  BO_ORDER_REQUEST   *)RcvMsg ;

	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT\
			DRV_SL_ABSTICK_VALUE ,\
			DRV_PR_ABSTICK_VALUE ,\
			DRV_SL_AT_FLAG ,\
			DRV_PR_ST_FLAG \
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS IN (\'C\',\'T\')\
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND     A.DRV_LEG_NO = %d \
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
			AND     A.DRV_EXCH_ID = \"%s\" AND A.DRV_SEGMENT = \'%c\' ;",PROD_BRACKET,LEG_1,LEG_1,pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fDrvBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2(" fDrvBoOrdExit :Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{ 
			memset(&pDrOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));	
			strncpy(pDrOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pDrOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			//	                pDrOrdReq.ReqHeader.cSource= Row[22][0];
			pDrOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDrOrdReq.ReqHeader.cSegment = Row[25][0];
			pDrOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pDrOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);



			strncpy(pDrOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pDrOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDrOrdReq.cProductId= Row[23][0];

			pDrOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pDrOrdReq.iOrderType = atoi(Row[16]);
			//                pDrOrdReq.iOrderValidity = atof(Row[15]);
			pDrOrdReq.iOrderValidity = VALIDITY_IOC ;
			pDrOrdReq.iTotalQty = atoi(Row[8]);
			pDrOrdReq.iTotalQtyRem = atoi(Row[8]);
			pDrOrdReq.iDiscQty = atoi(Row[10]);
			pDrOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDrOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDrOrdReq.fPrice = atof(Row[13]);
			pDrOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pDrOrdReq.fOrderNum = atof(Row[0]);
			pDrOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pDrOrdReq.cHandleInst = Row[19][0];
			pDrOrdReq.iStratergyId= 0 ;
			pDrOrdReq.cProCli = Row[19][0];
			pDrOrdReq.cUserType = ADMIN_TYPE ;
			pDrOrdReq.BoArray[0].iLegValue = LEG_1 ;

			pDrOrdReq.fSLTikAbsValue = atof(Row[26]);
			pDrOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pDrOrdReq.cSLFlag  =  Row[28][0];
			pDrOrdReq.cPBFlag  = Row[29][0];
			pDrOrdReq.cFlag =  '0' ;
			pDrOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			//	                strncpy(pDrOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pDrOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDrOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDrOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDrOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDrOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			logDebug2("pDrOrdReq.BoArray[0].cBuySellInd :%c:",pDrOrdReq.BoArray[0].cBuySellInd);
			logDebug2("pDrOrdReq.fOrderNum = %f ",pDrOrdReq.fOrderNum);
			logDebug2("pDrOrdReq.sClientId = %s",pDrOrdReq.sClientId);
			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pDrOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fDrvBoOrdExit [EXIT]");
	return TRUE;

}

BOOL fCnlMcxPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY fCnlMcxPendingOrd");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 		iNoOfRec = 0;
	LONG32 		i = 0;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM__SERIAL_NO,\
			COMM__SCRIP_CODE,\
			COMM__MKT_TYPE,\
			COMM__EXCH_ID,\
			COMM__ENTITY_ID,\
			COMM__CLIENT_ID,\
			COMM__BUY_SELL_IND,\
			COMM__TOTAL_QTY,\
			COMM__REM_QTY,\
			COMM__DISC_QTY,\
			COMM__DISC_REM_QTY,\
			COMM__TOTAL_TRADED_QTY,\
			COMM__ORDER_PRICE,\
			COMM__TRIGGER_PRICE,\
			COMM__VALIDITY,\
			COMM__ORDER_TYPE,\
			COMM__USER_ID,\
			COMM__MIN_FILL_QTY,\
			COMM__PRO_CLIENT,\
			COMM__USER_TYPE,\
			COMM__REMARKS,\
			COMM__SOURCE_FLG,\
			COMM__PRODUCT_ID,\
			COMM__MSG_CODE\
			FROM    COMM__ORDERS A\
			WHERE   A.COMM__ORD_STATUS = \'C\'\
			AND     A.COMM__MSG_CODE IN (2073,2074)\
			AND     A.COMM__PRODUCT_ID = \'I\'\
			AND     A.COMM__SERIAL_NO = (SELECT MAX(B.COMM__SERIAL_NO) FROM COMM__ORDERS B WHERE B.COMM__ORDER_NO = A.COMM__ORDER_NO)\
			AND     A.COMM__EXCH_ID = \"%s\" ;",pCnlEOrd->ReqHeader.sExcgId);
	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlMcxPendingOrd query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);	
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[5],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[18]);
			pEOrdReq.ReqHeader.cSource= Row[23][0];
			pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);



			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[7],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[24][0];
			pEOrdReq.cBuyOrSell = Row[8][0];
			pEOrdReq.iOrderType = atoi(Row[17]);
			pEOrdReq.iOrderValidity = atof(Row[16]);
			pEOrdReq.iTotalQty = atoi(Row[9]);
			pEOrdReq.iTotalQtyRem = atoi(Row[10]);
			pEOrdReq.iDiscQty = atoi(Row[11]);
			pEOrdReq.iDiscQtyRem = atoi(Row[12]);
			pEOrdReq.iTotalTradedQty = atoi(Row[13]);
			pEOrdReq.fPrice = atof(Row[14]);
			pEOrdReq.fTriggerPrice = atof(Row[15]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]);
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= 0 ;
			pEOrdReq.cProCli = Row[20][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("ENTRY fCnlMcxPendingOrd");
	return TRUE;

}

BOOL fSqrOffEqSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffEqSellOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	
	LONG32 		iNoOfRec = 0;
	LONG32 		i = 0;

	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT 	SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			-(NET_QTY) QTY_ORIGINNAL,\
			-(NET_QTY) QTY_REMAINING,\
			um.USER_CODE\
			FROM 	VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty < 0\
			AND a.prod_id='I'\
			AND a.segmnt = 'E'\
			AND um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\'));",pEQSellOrd->ReqHeader.sExcgId);	

		logDebug1("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("error in fSqrOffEqSellOrd select Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fSqrOffEqSellOrd :%d: Rows returned from Database ",iNoOfRec);

	for(i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);

		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			//	 	strncpy(pEOrdReq.sEntityId,Row[3],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_BUY;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0;
			pEOrdReq.fTriggerPrice= 0;
			pEOrdReq.fOrderNum = 0;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
			}
			pEOrdReq.iAuctionNum = 0;
			logDebug2("pEOrdReq.sSecurityId  :%s:",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId	:%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}		
	}
	logTimestamp("EXIT  [fSqrOffEqSellOrd]");
	return TRUE;

}	

BOOL fSqrOffEqBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffEqBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32	iNoOfRec = 0;
	LONG32	i= 0;

	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE\
			FROM    VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty > 0\
			AND a.prod_id='I'\
			and a.segmnt = 'E'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\'));",pEQBuyOrd->ReqHeader.sExcgId);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffEqBuyOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);

	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fSqrOffEqBuyOrd :%d: Rows returned from Database ",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);	
		if (Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment= SEGMENT_EQUITY;

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_SELL;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0;
			pEOrdReq.fTriggerPrice= 0;
			pEOrdReq.fOrderNum = 0;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			//	                strncpy(pEOrdReq.sRemarks,";",REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
			}
			pEOrdReq.iAuctionNum = 0;
			logDebug2("pEOrdReq.sSecurityId :%s:",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId   :%s:",pEOrdReq.sClientId);


			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("ENTRY [fSqrOffEqBuyOrd]");
	return TRUE;

}

BOOL fSqrOffDrSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffDrSellOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	LONG32	iNoOfRec = 0;	
	LONG32	i= 0;	

	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR	sWhereCls[MAX_QUERY_SIZE];

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;
	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	if(pEQSellOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order Sell SqrOff");
		sprintf(sWhereCls," AND SUBSTRING_INDEX(EXCH_SYMB, '-', 1) not in ('EURUSD','GBPUSD','USDJPY')");

		logDebug2("sWhereCls :%s:",sWhereCls);
	}
	else
	{
		sprintf(sWhereCls ," ");
	}


	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			-(NET_QTY) QTY_ORIGINNAL,\
			-(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT\
			FROM 	VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty < 0\
			AND a.prod_id='I'\
			and a.segmnt = \'%c\'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\')) %s ;",pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->ReqHeader.sExcgId,sWhereCls);	

		logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffDrSellOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_BUY;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0.00;
			pEOrdReq.fTriggerPrice= 0.00;
			pEOrdReq.fOrderNum = 0.00;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.iAuctionNum = 0;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);	
			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2("INVALID Mkt Type :%s: ",Row[1]);
			}


			logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
			logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT  [fSqrOffDrSellOrd]");
	return TRUE;

}	

BOOL fSqrOffDrBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffDrBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sWhereCls[MAX_QUERY_SIZE];
	LONG32		iNoOfRec = 0;
	LONG32		i= 0;

	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;
	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	if(pEQBuyOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order Sell SqrOff");
		sprintf(sWhereCls," AND SUBSTRING_INDEX(EXCH_SYMB, '-', 1) not in ('EURUSD','GBPUSD','USDJPY')");

		logDebug2("sWhereCls :%s:",sWhereCls);
	}
	else
	{
		sprintf(sWhereCls ," ");
	}

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT	\	
			FROM    VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty > 0\
			AND a.prod_id='I'\
			and a.segmnt = \'%c\'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\')) %s;",pEQBuyOrd->ReqHeader.cSegment,pEQBuyOrd->ReqHeader.sExcgId,sWhereCls);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffDrBuyOrd Query...");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_SELL;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0.00;
			pEOrdReq.fTriggerPrice= 0.00;
			pEOrdReq.fOrderNum = 0.00;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			pEOrdReq.iAuctionNum = 0;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2("INVALID Mkt Type :%s: ",Row[1]);
			}


			logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
			logDebug2("pEOrdReq.sSecurityId   :%s:",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT [fSqrOffDrBuyOrd]");
	return TRUE;

}


BOOL fSqrOffMcxSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffMcxSellOrd]");
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;	

	LONG32	iNoOfRec = 0;
	LONG32	i = 0;

	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT 	SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			-(NET_QTY) QTY_ORIGINNAL,\
			-(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT  \
			FROM 	VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty < 0\
			AND a.prod_id='I'\
			and a.segmnt = 'M'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\'));",pEQSellOrd->ReqHeader.sExcgId);	

		logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffMcxSellOrd query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);	
			pEOrdReq.ReqHeader.iUserId = atoi(Row[8]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[9][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[4],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[5][0];
			pEOrdReq.cBuyOrSell = INT_BUY;
			pEOrdReq.iTotalQty = atoi(Row[6]);
			pEOrdReq.iTotalQtyRem= atoi(Row[7]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0;
			pEOrdReq.fTriggerPrice= 0;
			pEOrdReq.fOrderNum = 0;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sRemarks,";",REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
			}
			pEOrdReq.iAuctionNum = 0;



			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("ENTRY [fSqrOffMcxSellOrd]");
	return TRUE;

}	

BOOL fSqrOffMcxBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffMcxBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32		iNoOfRec = 0;
	LONG32		i= 0;


	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT  \
			FROM    VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty > 0\
			AND a.prod_id='I'\
			and a.segmnt = 'M'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\'));",pEQBuyOrd->ReqHeader.sExcgId);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffMcxBuyOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[8]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[9][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[4],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[5][0];
			pEOrdReq.cBuyOrSell =INT_SELL ;
			pEOrdReq.iTotalQty = atoi(Row[6]);
			pEOrdReq.iTotalQtyRem= atoi(Row[7]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0;
			pEOrdReq.fTriggerPrice= 0;
			pEOrdReq.fOrderNum = 0;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sRemarks,";",REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
			}
			pEOrdReq.iAuctionNum = 0;

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT [fSqrOffMcxBuyOrd]");
	return TRUE;

}

BOOL fBlockCoverOrd(CHAR *RcvMsg)
{	


	logTimestamp("fBlockCoverOrd [ENTRY]");
	struct  CO_ORDER_REQUEST   *pOrdBlck;
	CHAR            sReqExcgId[EXCHANGE_LEN];
	CHAR 		cMode  = '0' ;
	CHAR		cReqSegment = '0';
	LONG32          iSeqNo = 0 ;
	LONG32          iResult = 0 ;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR      	*sFnUpdt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pOrdBlck= (struct CO_ORDER_REQUEST *)RcvMsg;

	memset(sReqExcgId,'\0',EXCHANGE_LEN);
	strncpy(sReqExcgId,pOrdBlck->ReqHeader.sExcgId,EXCHANGE_LEN);
	cMode = '\0';
	cReqSegment = '\0';

	cReqSegment = pOrdBlck->ReqHeader.cSegment;
	logDebug3("In fBlockCoverOrd  sReqExcgId.arr :%s: sReqExcgId.len :%d: cReqSegment:%c:",sReqExcgId,strlen(sReqExcgId),cReqSegment);
	if(cReqSegment == 'M')
	{
		iSeqNo = pOrdBlck->ReqHeader.iSeqNo;
	}
	else
	{
		iSeqNo = 1;
	}

	sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N' \
			WHERE   PRODUCT_NAME = 'CO' \
			AND SEGMENT = \'%c\' \
			AND EXCH_ID = ltrim(rtrim(\"%s\")) \
			AND PRODUCT_CODE = \'%c\';",cReqSegment,sReqExcgId,PROD_COVER);

	logDebug1("sUpdSel :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fBlockCover  Update Query.");
		return FALSE;
	}

	//        sleep(60);
	return TRUE ;
	logTimestamp("fBlockCoverOrd [EXIT]");
}

BOOL fBlockBoOrd(CHAR *RcvMsg)
{
	logTimestamp("fBlockBoOrd [ENTRY]");
	struct  BO_ORDER_REQUEST   *pOrdBlck;


	CHAR            sReqExcgId[EXCHANGE_LEN];
	CHAR            cMode ;
	CHAR            cReqSegment ;
	LONG32          iSeqNo = 0 ;
	LONG32          iResult = 0 ;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sFnUpdt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pOrdBlck= (struct BO_ORDER_REQUEST *)RcvMsg;

	memset(sReqExcgId,'\0',EXCHANGE_LEN);
	strncpy(sReqExcgId,pOrdBlck->ReqHeader.sExcgId,EXCHANGE_LEN);
	cMode = '\0';
	cReqSegment = '\0';

	cReqSegment = pOrdBlck->ReqHeader.cSegment;
	logDebug3("In fBlockBoOrd   sReqExcgId.arr :%s: sReqExcgId.len :%d: cReqSegment:%c:",sReqExcgId,strlen(sReqExcgId),cReqSegment);
	if(cReqSegment == 'M')
	{
		iSeqNo = pOrdBlck->ReqHeader.iSeqNo;
	}
	else
	{
		iSeqNo = 1;
	}

	sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N' \
			WHERE   PRODUCT_NAME = 'BO' \
			AND SEGMENT = \'%c\' \
			AND EXCH_ID = ltrim(rtrim(\"%s\")) \
			AND PRODUCT_CODE = \'%c\';",cReqSegment,sReqExcgId,PROD_BRACKET);

	logDebug1("sUpdSel :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in Block Bracket Orders  Update Query.");
		return FALSE;
	}

	sleep(60);
	return TRUE ;
	logTimestamp("fBlockBoOrd [EXIT]");
}







BOOL fBlockIntraday(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fBlockIntraday]");
	struct  ORDER_REQUEST	*pOrdBlck;

	CHAR            cReqSegment,cMode;
	CHAR         	sReqExcgId[EXCHANGE_LEN];
	LONG32          iSeqNo;
	LONG32          iResult;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR		*sUpdQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		*sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		*sFnUpdt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	

	pOrdBlck= (struct ORDER_REQUEST *)RcvMsg;

	memset(sReqExcgId,'\0',EXCHANGE_LEN);
	strncpy(sReqExcgId,pOrdBlck->ReqHeader.sExcgId,EXCHANGE_LEN);
	cMode = '\0';

	cReqSegment = pOrdBlck->ReqHeader.cSegment;
	logDebug3("In Block Intraday sReqExcgId.arr :%s: sReqExcgId.len :%d: cReqSegment:%c:",sReqExcgId,strlen(sReqExcgId),cReqSegment);
	if(cReqSegment == 'M')
	{
		iSeqNo = pOrdBlck->ReqHeader.iSeqNo;
	}
	else
	{
		iSeqNo = 1;
	}

	sprintf(sUpdQry," UPDATE RMS_PRODUCT_MASTER SET PRODUCT_STATUS = 'N' \
			WHERE   PRODUCT_NAME = 'INTRADAY' \
			AND SEGMENT = \'%c\' \
			AND EXCH_ID = ltrim(rtrim(\"%s\")) \
			AND PRODUCT_CODE = 'I';",cReqSegment,sReqExcgId);

	logDebug1("sUpdSel :%s:",sUpdQry);

	if(mysql_query(DB_IntSqr,sUpdQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fBlockIntraday Update Query.");
		return FALSE;	
	}


	sleep(60);
	/***


	  sprintf(sSelQry,"SELECT BP_MODE  FROM BATCH_PROCESS b \ 
	  WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\")) \
	  AND     b.bp_segment = \'%c\'\
	  AND     b.bp_batch_name = 'I_SQ_OFF' \
	  AND     b.bp_mkt_type_no = %d",sReqExcgId,cReqSegment,iSeqNo);	

	  logDebug2("sSelQry :%s:",sSelQry);

	  if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	  {
	  sql_Error(DB_IntSqr);
	  exit(ERROR);
	  }

	  Res = mysql_store_result(DB_IntSqr);

	  if(Row = mysql_fetch_row(Res))
	  {
	  cMode = Row[0][0];
	  }
	  mysql_free_result(Res);

	  if (cMode != 'A')
	  {
	  logFatal(" Batch Process is set to manual for :%s:%c:%d: ",sReqExcgId,cReqSegment,iSeqNo);
	//return FALSE;
	}
	else
	{
	sprintf(sFnUpdt,"SELECT BP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\'I_SQ_OFF\',%d)",sReqExcgId,cReqSegment,iSeqNo);

	if(mysql_query(DB_IntSqr,sFnUpdt) != SUCCESS)
	{
	sql_Error(sFnUpdt);
	exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);	
	if(Row = mysql_fetch_row(Res) )
	{
	iResult = atoi(Row[0]);
	}

	if(iResult == 0)
	{
	logFatal("Error : BP_UPDATE iResult :%d:",iResult);
	return FALSE;
	}
	else
	{
	logInfo("BP_UPDATE SUCCESS");
	return TRUE;
	}

	 ***/			


	logTimestamp(" EXIT [fBlockIntraday]");
	return TRUE ;
}/** End of fBlockIntraday **/


BOOL    fUpdtOffMktBP(CHAR *RcvMsg)
{
	logTimestamp("fUpdtOffMktBP [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sFnQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32          iSeqNo, iStatus;
	iSeqNo = 1;
	CHAR sBatchName [20];
	CHAR sremarks [25];
	memset(sBatchName,'\0',20);
	memset (sremarks,'\0',25);	
	struct  ORDER_REQUEST   *pOrdBlck;
	pOrdBlck= (struct ORDER_REQUEST *)RcvMsg;
	strncpy(sremarks,pOrdBlck->sRemarks,REMARKS_LEN);
	logDebug2("MSGCODE IS:%d",TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ);
	if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_REQ)
	{
		strncpy(sBatchName,INTRADAY_SQUREOFF,20);
	}
	else if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ)
	{
		strncpy(sBatchName,INTRADAY_CROSS_CUR_SQROFF,20);
	}
	else if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_PUMPOFFLINE_REQ)
	{
		strncpy(sBatchName,OFFMARKET_PUMPER,20);
	}

	else if (pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_COVER_ORD_REQ)
	{
		strncpy(sBatchName,COVER_ORD_SQUREOFF,20);
	}
	else if(pOrdBlck->ReqHeader.iMsgCode == TC_INT_SQUAREOFF_BRACKET_ORD_REQ)
	{
		strncpy(sBatchName,BRACKET_ORD_SQUREOFF,20);
	}
	else
	{
		logDebug2("Wrong Msg Code");
	}
	logDebug2(".......[%s]........",pOrdBlck->sRemarks);
	sprintf(sFnQuery,"SELECT BP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\'%s\',%d,\'%s\');",pOrdBlck->ReqHeader.sExcgId,pOrdBlck->ReqHeader.cSegment,sBatchName,iSeqNo,sremarks);
	logDebug2("sFnQuery :%s:",sFnQuery);

	if(mysql_query(DB_IntSqr,sFnQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fUpdtOffMktBP UPDATE QUERY.");
		return FALSE;
	}
	else
	{
		Res = mysql_store_result(DB_IntSqr);
		Row = mysql_fetch_row(Res);
		logDebug2("[%s] [%d]",Row[0],atoi(Row[0]));
		iStatus = atoi(Row[0]);
		logDebug2("BP_UPDATE Response :%d:",iStatus);
		mysql_commit(DB_IntSqr);
		logTimestamp("fUpdtOffMktBP [EXIT]");
		return TRUE;
	}

}

BOOL	fUpdtOffMktBPSIP(CHAR *RcvMsg, CHAR sBatchName[20])
{
	logTimestamp ("Entry fUpdtOffMktBPSIP");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32      	iSeqNo, iStatus;
	iSeqNo = 1;
	CHAR sRemarks [25];
	memset (sRemarks,'\0',25);
	struct  ORDER_REQUEST   *pOrdBlck;
	pOrdBlck= (struct ORDER_REQUEST *)RcvMsg;

	logDebug2("sBatchName = %s",sBatchName);
	strncpy(sRemarks,pOrdBlck->sRemarks,REMARKS_LEN);
	logDebug2("pOrdBlck->sRemarks = %s",pOrdBlck->sRemarks);

	sprintf(sQuery,"SELECT SIP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\'%s\',%d,\'%s\');",pOrdBlck->ReqHeader.sExcgId,pOrdBlck->ReqHeader.cSegment,sBatchName,iSeqNo,sRemarks);
	logDebug2("sFnQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fUpdtOffMktBPSIP UPDATE QUERY.");
		return FALSE;
	}
	else
	{

		Res = mysql_store_result(DB_IntSqr);
		Row = mysql_fetch_row(Res);
		logDebug2("[%s] [%d]",Row[0],atoi(Row[0]));
		iStatus = atoi(Row[0]);
		logDebug2("SIP_UPDATE Response :%d:",iStatus);
		mysql_commit(DB_IntSqr);

	}
	logTimestamp ("Entry fUpdtOffMktBPSIP");
	return TRUE;


}

BOOL    fDisableOffMkt(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{
	logTimestamp("ENTRY fDisableOffMkt");
	CHAR    *sUpDtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	INT16   iMktNo =1;

	sprintf(sUpDtQry,"UPDATE BATCH_PROCESS b \
			SET b.BP_OFF_MKT_STATUS = \'N\' \
			WHERE   b.BP_EXCH_ID = LTRIM(RTRIM(\"%s\"))\
			AND     b.BP_SEGMENT = \'%c\' \
			AND     b.BP_MKT_TYPE_NO = %d \
			AND     b.BP_BATCH_NAME = \'OFFMKT_PUMP\';",pOrdReq->sExcgId,pOrdReq->cSegment,iMktNo);

	logDebug3("sUpDtQry :%s:",sUpDtQry);

	if(mysql_query(DB_IntSqr,sUpDtQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in Update Batch Process Query.");
		return FALSE;
	}
	else
	{
		mysql_commit(DB_IntSqr);
		logTimestamp("EXIT  fDisableOffMkt");
		return TRUE;
	}
}

BOOL    fEnableOffMkt(struct  INT_COMMON_REQUEST_HDR *pOrdReq)
{

	logTimestamp("ENTRY fEnableOffMkt ");
	CHAR    *sUpDtQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	INT16   iMktNo =1;
	logDebug2("Enabling Off market");
	sprintf(sUpDtQry,"UPDATE BATCH_PROCESS  \
			SET BP_OFF_MKT_STATUS = \'Y\' \
			WHERE   BP_EXCH_ID = LTRIM(RTRIM(\"%s\"))\
			AND     BP_SEGMENT = \'%c\' \
			AND     BP_MKT_TYPE_NO = %d \
			AND     BP_BATCH_NAME = \'OFFMKT_PUMP\';",pOrdReq->sExcgId,pOrdReq->cSegment,iMktNo);

	logDebug3("sUpDtQry :%s:",sUpDtQry);

	if(mysql_query(DB_IntSqr,sUpDtQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in Enable Off Mkt Query.");
		return FALSE;
	}
	else
	{
		mysql_commit(DB_IntSqr);
		logTimestamp("EXIT  fEnableOffMkt");
		return TRUE;
	}
}

BOOL fEquPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	logTimestamp("fEquPumpOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32 	iNoOfRec = 0;
	LONG32 	i= 0;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pEOrdReq;


	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_STRATEGY_ID, \
			EQ_ORDER_OFFON \
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS = \'C\'\
			AND     A.EQ_MSG_CODE IN (5112,5113)\
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO)\
			AND     A.EQ_EXCH_ID = \"%s\" ;",pCnlEOrd->sExcgId);
	logDebug2("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fEquPumpOffOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);


	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq , '\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			logDebug2("pEOrdReq.ReqHeader.sExcgId :%s:",pEOrdReq.ReqHeader.sExcgId);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			//	                pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN;
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			///	                strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1])+1;
			pEOrdReq.cHandleInst ='1';
			pEOrdReq.iStratergyId= atoi(Row[26]);
			pEOrdReq.cOffMarketFlg = Row[27][0];
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			strncpy(pEOrdReq.sRemarks ,PUMP_ORD_REMARKS,REMARKS_LEN);


			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			logDebug2("Writing to Queue for Order Number :%f:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.cOffMarketFlg ;%c:",pEOrdReq.cOffMarketFlg);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.sClientId  :%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("fEquPumpOffOrd [EXIT]");
	return TRUE;


}

BOOL fDrvPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	logTimestamp("fDrvPumpOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32		iNoOfRec = 0;
	LONG32		i= 0;
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pDOrdReq;


	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE, \
			DRV_STRATEGY_ID ,\
			DRV_SEGMENT , \
			DRV_ORDER_OFFON \
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'C\'\
			AND     A.DRV_MSG_CODE IN (5112,5113)\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
			AND     A.DRV_EXCH_ID = \"%s\" AND A.DRV_SEGMENT = \'%c\';",pCnlEOrd->sExcgId,pCnlEOrd->cSegment);
	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fDrvPumpOffOrd QUERY.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fDrvPumpOffOrd : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pDOrdReq, '\0', sizeof(struct ORDER_REQUEST));
			pDOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
			pDOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pDOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pDOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			//	                pDOrdReq.ReqHeader.cSource= Row[22][0];
			pDOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDOrdReq.ReqHeader.cSegment = Row[26][0];

			strncpy(pDOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			///	                strncpy(pDOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pDOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			logDebug2("Entity Id is :%s: ",pDOrdReq.sEntityId);
			strncpy(pDOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDOrdReq.cProductId= Row[23][0];
			pDOrdReq.cBuyOrSell = Row[7][0];
			pDOrdReq.iOrderType = atoi(Row[16]);
			pDOrdReq.iOrderValidity = atof(Row[15]);
			pDOrdReq.iTotalQty = atoi(Row[8]);
			pDOrdReq.iTotalQtyRem = atoi(Row[9]);
			pDOrdReq.iDiscQty = atoi(Row[10]);
			pDOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDOrdReq.fPrice = atof(Row[13]);
			pDOrdReq.fTriggerPrice = atof(Row[14]);
			pDOrdReq.fOrderNum = atof(Row[0]);
			pDOrdReq.iSerialNum = atoi(Row[1])+1;
			pDOrdReq.cHandleInst = '1';
			pDOrdReq.iStratergyId= atoi(Row[25]);
			//	                pDOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;	
			pDOrdReq.cOffMarketFlg = Row[27][0];

			pDOrdReq.cProCli = Row[19][0];
			//	                pDOrdReq.cUserType = Row[20][0];
			pDOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pDOrdReq.sRemarks ,PUMP_ORD_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
				return FALSE;
			}

			logDebug2("Writing to Queue for Order Number :%f:",pDOrdReq.fOrderNum);
			logDebug2("Market Type is :%d:",pDOrdReq.iMktType);
			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pDOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}
	}

	logTimestamp("fDrvPumpOffOrd [ENTRY]");
	return TRUE;

}

BOOL fCommPumpOffOrd(struct  INT_COMMON_REQUEST_HDR   *pCnlEOrd)
{
	logTimestamp("fCommPumpOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 	iNoOfRec = 0;
	LONG32 	i = 0;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   pEOrdReq;


	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE ,\
			COMM_STRATEGY_ID ,\
			COMM_SEGMENT ,\
			COMM_ORDER_OFFON ,\
			COMM_MKT_TYPE ,\
			COMM_USER_TYPE \
			FROM    COMM_ORDERS A\
			WHERE   A.COMM_STATUS = \'C\'\
			AND     A.COMM_MSG_CODE IN (5112,5113)\
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO)\
			AND     A.COMM_EXCH_ID = \"%s\" ;",pCnlEOrd->sExcgId);
	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCommPumpOffOrd Query........");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq, '\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[3],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[16]);
			///	                pEOrdReq.ReqHeader.cSource= Row[20][0];
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[24][0];

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			//	                strncpy(pEOrdReq.sEntityId,Row[4],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[5],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[21][0];
			pEOrdReq.cBuyOrSell = Row[6][0];
			pEOrdReq.iOrderType = atoi(Row[15]);
			pEOrdReq.iOrderValidity = atof(Row[14]);
			pEOrdReq.iTotalQty = atoi(Row[7]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[9]);
			pEOrdReq.iDiscQtyRem = atoi(Row[10]);
			pEOrdReq.iTotalTradedQty = atoi(Row[11]);
			pEOrdReq.fPrice = atof(Row[12]);
			pEOrdReq.fTriggerPrice = atof(Row[13]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.iStratergyId= atoi(Row[23]);
			//	                pEOrdReq.cOffMarketFlg= Row[25][0];
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = Row[18][0];
			//	                pEOrdReq.cUserType = Row[27][0];		
			pEOrdReq.cUserType = ADMIN_TYPE ;		
			//			strncpy(pEOrdReq.sRemarks ,Row[19],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,PUMP_ORD_REMARKS,REMARKS_LEN);

			if(strcmp(Row[26],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[26],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[26],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[26],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[26]);
				return FALSE;
			}
			logDebug2("pEOrdReq.fOrderNum :%lf",pEOrdReq.fOrderNum);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("fCommPumpOffOrd [EXIT]");
	return TRUE;

}

/*
   void fPrintAll(struct CO_ORDER_REQUEST *pOrdReq)
   {
   logTimestamp("fPrintAll[ENTRY]");


   logDebug2("pOrdReq.fOrderNum  		:%f:",pOrdReq->fOrderNum);
   logDebug2("pOrdReq.iSerialNum 		:%d: ",pOrdReq->iSerialNum);
   logDebug2("pOrdReq.CoArray[0].cBuySellInd 	:%c: ",pOrdReq->CoArray[0].cBuySellInd);
   logDebug2("pOrdReq.CoArray[0].fTriggerPrice 	:%f: ",pOrdReq->CoArray[0].fTriggerPrice);
   logDebug2("pOrdReq.CoArray[0].iLegValue 	:%d: ",pOrdReq->CoArray[0].iLegValue);
   logDebug2("pOrdReq.fPrice 		:%f:",pOrdReq->fPrice);
   logDebug2("pOrdReq.iTotalQty 		:%d: ",pOrdReq->iTotalQty);
   logDebug2("pOrdReq.iTotalQtyRem 	:%d: ",pOrdReq->iTotalQtyRem);
   logDebug2("pOrdReq.iTotalTradedQty 	:%d: ",pOrdReq->iTotalTradedQty);

   logDebug2("pEOrdReq->ReqHeader.sExcgId 	:%s:",pOrdReq->ReqHeader.sExcgId);
   logDebug2("pOrdReq.ReqHeader.iUserId  	:%d:",pOrdReq->ReqHeader.iUserId );
   logDebug2("pOrdReq.ReqHeader.cSource 	:%c:",pOrdReq->ReqHeader.cSource);
   logDebug2("pOrdReq.ReqHeader.cSegment 	:%c: ",pOrdReq->ReqHeader.cSegment);
   logDebug2("pOrdReq.ReqHeader.iMsgCode 	:%d:",pOrdReq->ReqHeader.iMsgCode);
   logDebug2("pOrdReq.ReqHeader.iMsgLength	:%d:",pOrdReq->ReqHeader.iMsgLength);

   logDebug2("pOrdReq.sSecurityId	:%s:",pOrdReq->sSecurityId);
   logDebug2("pOrdReq.sEntityId	:%s:",pOrdReq->sEntityId);
   logDebug2("pOrdReq.sClientId	:%s:",pOrdReq->sClientId);
   logDebug2("pOrdReq.cProductId	:%c:",pOrdReq->cProductId);
   logDebug2("pOrdReq.iOrderType 	:%d: ",pOrdReq->iOrderType);
   logDebug2("pOrdReq.iOrderValidity 	:%d: ",pOrdReq->iOrderValidity);
   logDebug2("pOrdReq.iDiscQty 	:%d: ",pOrdReq->iDiscQty);
   logDebug2("prdReq.iDiscQtyRem 	:%d: ",pOrdReq->iDiscQtyRem);
   logDebug2("pOrdReq.cHandleInst  :%c:",pOrdReq->cHandleInst);
   logDebug2("pOrdReq.iStratergyId	:%d: ",pOrdReq->iStratergyId);
   logDebug2("pOrdReq.cProCli  	:%c:",pOrdReq->cProCli);
   logDebug2("pOrdReq.cUserType  	:%c:",pOrdReq->cUserType);
   logDebug2("pOrdReq.cSLFlag   	:%c:",pOrdReq->cSLFlag);
   logDebug2("pOrdReq.cPBFlag   	:%c:",pOrdReq->cPBFlag);
   logDebug2("pOrdReq.cAvgLtpFlg  	:%c:",pOrdReq->cAvgLtpFlg);
   logDebug2("pOrdReq.sRemarks 	:%s:",pOrdReq->sRemarks);
   logDebug2("pOrdReq.iMktType 	:%d:",pOrdReq->iMktType);
   logDebug2("pOrdReq.fSLTikAbsValue  	:%f:",pOrdReq->fSLTikAbsValue);
   logDebug2("pOrdReq.fPBTikAbsValue   	:%f:",pOrdReq->fPBTikAbsValue);

   logTimestamp("fPrintAll[EXIT]");

   }*/

OpenMsgQue()
{
	if( ( iAutoSqoffToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug2("write Q = %d",iAutoSqoffToOrdRtr);
	if( ( iRDaemonToSqoff= OpenMsgQ( (RDaemonToSqoff))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug2("Read Q = %d",iRDaemonToSqoff);

	return TRUE;
}

BOOL fCnlCCPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fCnlCCPendingOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sWhereCls[MAX_QUERY_SIZE];

	struct  ORDER_REQUEST   *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	LONG32  iNoOfRec = 0;
	LONG32  i = 0;

	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	pCnlEOrd = (struct  ORDER_REQUEST   *)RcvMsg ;


	if(pCnlEOrd->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		logInfo("Its a CURRENCY_SEGMENT Order cancel");
		sprintf(sWhereCls," AND SUBSTRING_INDEX(DRV_SYMBOL, '-', 1)  in ('EURUSD','GBPUSD','USDJPY')");

		logDebug2("sWhereCls :%s:",sWhereCls);
	}
	else
	{
		sprintf(sWhereCls ," ");
	}
	logDebug2("exchID:%s",pCnlEOrd->ReqHeader.sExcgId);
	logDebug2("c.segment:%c",pCnlEOrd->ReqHeader.cSegment);

	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT,\
			DRV_OMS_ALGO_ORD_NO ,\
			DRV_STRATEGY_ID ,\
			DRV_ORDER_OFFON \
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'C\'\
			AND     A.DRV_MSG_CODE IN (2073,2074)\
			AND     A.DRV_PRODUCT_ID = \'I\'\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO)\
			AND     A.DRV_EXCH_ID = \"%s\" AND DRV_SEGMENT = \'%c\' %s;",pCnlEOrd->ReqHeader.sExcgId,pCnlEOrd->ReqHeader.cSegment,sWhereCls);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_IntSqr,sSelQry) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fCnlCCPendingOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);	

		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			//pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);

			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= 0;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.fAlgoOrderNo = atof(Row[26]);
			//                      pEOrdReq.cOffMarketFlg= Row[28][0];
			//                      pEOrdReq.cUserType = Row[20][0]
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.iAuctionNum = 0;
			//                strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
			strncpy(pEOrdReq.sRemarks ,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)	
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}
		}

	}
	logTimestamp("EXIT [fCnlCCPendingOrd]");
	return TRUE;

}

BOOL fSqrOffCCSellOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffCCSellOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32  iNoOfRec = 0;
	LONG32  i= 0;

	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  ORDER_REQUEST   *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			-(NET_QTY) QTY_ORIGINNAL,\
			-(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT\
			FROM    VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty < 0\
			AND a.prod_id='I'\
			and a.segmnt = \'%c\'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\'))\
			AND SUBSTRING_INDEX(EXCH_SYMB,'-', 1) in ('EURUSD','GBPUSD','USDJPY');",pEQSellOrd->ReqHeader.cSegment,pEQSellOrd->ReqHeader.sExcgId);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffCCSellOrd Query.");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_BUY;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0.00;
			pEOrdReq.fTriggerPrice= 0.00;
			pEOrdReq.fOrderNum = 0.00;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);
			pEOrdReq.iAuctionNum = 0;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2("INVALID Mkt Type :%s: ",Row[1]);
			}


			logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
			logDebug2("pEOrdReq.sSecurityId = %s ",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId = %s ",pEOrdReq.sClientId);


			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT  [fSqrOffCCSellOrd]");
	return TRUE;

}


BOOL fSqrOffCCBuyOrd(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fSqrOffCCBuyOrd]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32          iNoOfRec = 0;
	LONG32          i= 0;

	struct  ORDER_REQUEST   *pEQBuyOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQBuyOrd = (struct  ORDER_REQUEST   *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE,\
			SEGMNT  \
			FROM    VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.net_qty > 0\
			AND a.prod_id='I'\
			and a.segmnt = \'%c\'\
			and um.USER_ENTITY_CODE = a.client_id\
			AND a.exch_id= ltrim(rtrim(\'%s\')) \
			AND SUBSTRING_INDEX(EXCH_SYMB, '-', 1) in ('EURUSD','GBPUSD','USDJPY');",pEQBuyOrd->ReqHeader.cSegment,pEQBuyOrd->ReqHeader.sExcgId);

	logDebug2("sQuery :%s:",sQuery);

	if(mysql_query(DB_IntSqr,sQuery) != SUCCESS)
	{
		sql_Error(DB_IntSqr);
		logSqlFatal("Error in fSqrOffCCBuyOrd Query...");
		return FALSE;
	}

	Res = mysql_store_result(DB_IntSqr);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{

		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];
			pEOrdReq.cBuyOrSell = INT_SELL;
			pEOrdReq.iTotalQty = atoi(Row[5]);
			pEOrdReq.iTotalQtyRem= atoi(Row[6]);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0.00;
			pEOrdReq.fTriggerPrice= 0.00;
			pEOrdReq.fOrderNum = 0.00;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			pEOrdReq.iAuctionNum = 0;	
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			strncpy(pEOrdReq.sRemarks,INTRADAY_REMARKS,REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2("INVALID Mkt Type :%s: ",Row[1]);
			}


			logDebug2("pEOrdReq.ReqHeader.cSegment = %c",pEOrdReq.ReqHeader.cSegment);
			logDebug2("pEOrdReq.sSecurityId   :%s:",pEOrdReq.sSecurityId);
			logDebug2("pEOrdReq.sClientId :%s:",pEOrdReq.sClientId);

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_IntSqr);
				exit(ERROR);
			}

		}
	}
	logTimestamp("EXIT [fSqrOffCCBuyOrd]");
	return TRUE;

}

