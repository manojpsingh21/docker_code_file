#include <stdlib.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"


struct	SCHEME_MAST_ARRAY *HashBySchID = NULL;	

BOOL	AddSchemeHash()
{
	MYSQL		*DBConSch;
	MYSQL_RES 	*Res;
	MYSQL_ROW	Row;

	LONG32		iNoOfRow = 0,i=0;
	CHAR		*sSelScheme = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR		sTempSecID[DB_SCRIP_CODE_LEN];

	DBConSch = DB_Connect();

	sprintf(sSelScheme,"SELECT NSM_EXCHANGE,NSM_TOKEN,NSM_ISIN,NSM_SYMBOL,NSM_NAME,NSM_SERIES,NSM_AMC_CODE,NSM_AMC_SCHEME_CODE,\
			NSM_CATAGORY_CODE,NSM_RT_AGENT_CODE,NSM_RT_SCHEME_CODE,NSM_SEC_ALLOW_DEP,NSM_SEC_DEP_MANDATORY\
			FROM NSE_SCHEME_MASTER ");
	logDebug2("sSelScheme :%s:",sSelScheme);	

	if(mysql_query(DBConSch,sSelScheme) != SUCCESS)
	{
		logSqlFatal("Error adding to Hash in [AddSchemeHash]");
		sql_Error(DBConSch);
		mysql_close(DBConSch);
		return FALSE;
	}

	Res = mysql_store_result(DBConSch);

	iNoOfRow = mysql_num_rows(Res);

	struct	SCHEME_MAST_ARRAY *pSchHash[iNoOfRow],*pTempSch;

	if(iNoOfRow == 0)
	{
		logInfo("No Data in Table SECURITY_MASTER_MF");
		mysql_close(DBConSch);
		return FALSE;
	}
	else
	{
		while(Row = mysql_fetch_row(Res))
		{
			memset(sTempSecID,'\0',DB_SCRIP_CODE_LEN);
			pSchHash[i] = (struct  SCHEME_MAST_ARRAY *)malloc(sizeof(struct  SCHEME_MAST_ARRAY)); 
			pTempSch = (struct  SCHEME_MAST_ARRAY *)malloc(sizeof(struct  SCHEME_MAST_ARRAY)) ;

			strncpy(sTempSecID,Row[2],DB_SCRIP_CODE_LEN);

			HASH_FIND(hNseSchmHndlr,HashBySchID,&sTempSecID,strlen(sTempSecID),pTempSch);

			if(pTempSch == NULL)
			{
				strncpy(pSchHash[i]->sExch,Row[0],DB_EXCH_ID_LEN);
				strncpy(pSchHash[i]->sSchemeCode,Row[1],DB_SCRIP_CODE_LEN);
				strncpy(pSchHash[i]->sExchSchemeCode,Row[2],DB_SCRIP_CODE_LEN);
				strncpy(pSchHash[i]->sISINCode,Row[3],DB_ISIN_CODE_LEN);
				strncpy(pSchHash[i]->sScheme,Row[4],DB_SCHM_LEN);
				strncpy(pSchHash[i]->sSchemeName,Row[5],DB_SCHM_NAME_LEN);
				strncpy(pSchHash[i]->sSeries,Row[6],DB_SERIES_LEN);
				strncpy(pSchHash[i]->sAMCCode,Row[7],DB_AMC_CODE_LEN);
				strncpy(pSchHash[i]->sAMCSchCode,Row[8],DB_AMC_SCHM_LEN);
				strncpy(pSchHash[i]->sCategoryCode,Row[9],DB_CATEGORY_LEN);
				strncpy(pSchHash[i]->sRTAgentCode,Row[10],DB_RT_AGT_CODE_LEN);
				strncpy(pSchHash[i]->sRTSchemeCode,Row[11],DB_RT_SCH_CODE_LEN);
				pSchHash[i]->cSchAllowDep = Row[12][0];
				pSchHash[i]->cSchDepMandrty =Row[13][0];

				HASH_ADD(hNseSchmHndlr,HashBySchID,sSchemeCode,strlen(pSchHash[i]->sSchemeCode),pSchHash[i]);
				i++;
			}
			free(pTempSch);		

		}

		mysql_close(DBConSch);
		return TRUE;
	}	


}


BOOL	GetSchemeDetail(struct  INT_MFSS_ORD    *pRes)
{
	MYSQL           *DBConSch;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32          iNoOfRow = 0,i=0;
	CHAR            *sSelScheme = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];

	struct  SCHEME_MAST_ARRAY *pSec,*pHashAdd ;

	pSec = (struct SCHEME_MAST_ARRAY *)malloc(sizeof(struct SCHEME_MAST_ARRAY));
	pHashAdd = (struct SCHEME_MAST_ARRAY *)malloc(sizeof(struct SCHEME_MAST_ARRAY));
	memset(sTempSecID,'\0',DB_SCRIP_CODE_LEN);

	strncpy(sTempSecID,pRes->sSecId,DB_SCRIP_CODE_LEN);					

	logDebug2("sTempSecID :%s:",sTempSecID);



	HASH_FIND(hNseSchmHndlr,HashBySchID,&sTempSecID,strlen(sTempSecID),pSec);	

	if(pSec == NULL)
	{
		strncpy(pRes->sScheme,pSec->sScheme,DB_SCHM_LEN);
		strncpy(pRes->sSchemeName,pSec->sSchemeName,DB_SCHM_NAME_LEN);
		strncpy(pRes->sSeries,pSec->sSeries,DB_SERIES_LEN);
		strncpy(pRes->sIsinCode,pSec->sISINCode,DB_ISIN_CODE_LEN);
		strncpy(pRes->sAMCCode,pSec->sAMCCode,DB_AMC_CODE_LEN);
		strncpy(pRes->sAMCSchemeCode,pSec->sAMCSchCode,DB_AMC_SCHM_LEN);
		strncpy(pRes->sCategory,pSec->sCategoryCode,DB_CATEGORY_LEN);
		strncpy(pRes->sRTagent,pSec->sRTAgentCode,DB_RT_AGT_CODE_LEN);
		strncpy(pRes->sRTSchemeCode,pSec->sRTSchemeCode,DB_RT_SCH_CODE_LEN);
		pRes->cSchemeDepoFlag= pSec->cSchAllowDep;
		pRes->cSchemeDepoManFlag= pSec->cSchDepMandrty;
	}
	else
	{
		DBConSch = DB_Connect();

		sprintf(sSelScheme,"SELECT NSM_EXCHANGE,NSM_TOKEN,NSM_ISIN,NSM_SYMBOL,NSM_NAME,NSM_SERIES,NSM_AMC_CODE,NSM_AMC_SCHEME_CODE,\
				NSM_CATAGORY_CODE,NSM_RT_AGENT_CODE,NSM_RT_SCHEME_CODE,NSM_SEC_ALLOW_DEP,NSM_SEC_DEP_MANDATORY\
				FROM NSE_SCHEME_MASTER WHERE NSM_TOKEN = %s;",sTempSecID);
		logDebug2("sSelScheme :%s:",sSelScheme);

		if(mysql_query(DBConSch,sSelScheme) != SUCCESS)
		{
			logSqlFatal("Error adding to Hash in [GetSchemeDetail]");
			sql_Error(DBConSch);
			mysql_close(DBConSch);
			return FALSE;
		}

		Res = mysql_store_result(DBConSch);

		if(Row = mysql_fetch_row(Res))
		{
			strncpy(pRes->sScheme,Row[3],DB_SCHM_LEN);
			strncpy(pRes->sSchemeName,Row[4],DB_SCHM_NAME_LEN);
			strncpy(pRes->sSeries,Row[5],DB_SERIES_LEN);
			strncpy(pRes->sIsinCode,Row[2],DB_ISIN_CODE_LEN);
			strncpy(pRes->sAMCCode,Row[6],DB_AMC_CODE_LEN);
			strncpy(pRes->sAMCSchemeCode,Row[7],DB_AMC_SCHM_LEN);
			strncpy(pRes->sCategory,Row[8],DB_CATEGORY_LEN);
			strncpy(pRes->sRTagent,Row[9],DB_RT_AGT_CODE_LEN);
			strncpy(pRes->sRTSchemeCode,Row[10],DB_RT_SCH_CODE_LEN);
			pRes->cSchemeDepoFlag= Row[11][0];
			pRes->cSchemeDepoManFlag= Row[12][0];

			strncpy(pHashAdd->sScheme,Row[3],DB_SCHM_LEN);
			strncpy(pHashAdd->sSchemeName,Row[4],DB_SCHM_NAME_LEN);
			strncpy(pHashAdd->sSeries,Row[5],DB_SERIES_LEN);
			strncpy(pHashAdd->sISINCode,Row[2],DB_ISIN_CODE_LEN);
			strncpy(pHashAdd->sAMCCode,Row[6],DB_AMC_CODE_LEN);
			strncpy(pHashAdd->sAMCSchCode,Row[7],DB_AMC_SCHM_LEN);
			strncpy(pHashAdd->sCategoryCode,Row[8],DB_CATEGORY_LEN);
			strncpy(pHashAdd->sRTAgentCode,Row[9],DB_RT_AGT_CODE_LEN);
			strncpy(pHashAdd->sRTSchemeCode,Row[10],DB_RT_SCH_CODE_LEN);
			pHashAdd->cSchAllowDep= Row[11][0];
			pHashAdd->cSchDepMandrty= Row[12][0];	

			//HASH_ADD(hSecHndlr,Hash_ByID, sScripCode,strlen(pHashAdd->sScripCode),pHashAdd);
			HASH_ADD(hNseSchmHndlr,HashBySchID,sSchemeCode,strlen(pHashAdd->sSchemeCode),pHashAdd);
			mysql_close(DBConSch);

		}
		else
		{
			logDebug2("Scheme Id is not in Hash And DB :%d:",sTempSecID);
			return FALSE;
		}



	}
	return TRUE;	


}
