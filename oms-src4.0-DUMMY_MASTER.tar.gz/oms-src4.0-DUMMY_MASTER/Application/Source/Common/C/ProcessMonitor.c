#include <stdio.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/procfs.h>  
#include "IPCS.h"

pthread_t                  SignalTid1;
pthread_t                  SignalTid2;
sigset_t                   MainSignalSet ;
sigset_t                   ChildSignalSet;

#define     NO_MONITORING       999
#define     LOG_WRITE                   1
#define     NO_LOG_WRITE        0

void * 	AutoRestartForCrash () ;
void * 	ChildMain ();
void *	SignalHandlerSigChldParent ();
void *	SignalHandlerSigTermParent ();
void 	ProcessSelfRestart(struct  ProcessMonitor *);
LONG32  getCurrTime ();

BOOL 	RestrtFlag = FALSE ;
LONG32  ChildId = 0;
LONG32  MaxSelfRetry = 0;
LONG32  selfRestrtCount = 0 ;

void main()
{
	logTimestamp("Entry : [main]");
	LONG32 forkid ;
	LONG32  sleepInterval = atoi(getenv("PROCESS_MON_DELAY") );

	if(getenv("MAX_AUTO_RETRY") == NULL)
	{
		logDebug1("\n environment variable MAX_AUTO_RETRY not defined, hence taking the default value as 3 ");
		MaxSelfRetry = 3 ;
	}
	else
	{
		MaxSelfRetry = atoi(getenv("MAX_AUTO_RETRY"));
	}
	signal (SIGHUP, SIG_IGN);
	sigemptyset ( &MainSignalSet );
	sigaddset ( &MainSignalSet , SIGTERM);
	sigaddset ( &MainSignalSet , SIGCHLD);
	sigprocmask (SIG_BLOCK,&MainSignalSet , NULL);

	setvbuf( stdout , NULL , _IONBF , 0 );

	forkid = fork ();

	if ( forkid == 0 )
	{
		logInfo("\n In Child...%d",forkid);
		ChildMain () ;
	}
	else
	{
		ChildId = forkid ;
		logInfo("\n In Parent...%d",forkid);
		sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
		signal(SIGCHLD,SignalHandlerSigChldParent);
		signal(SIGTERM,SignalHandlerSigTermParent);
		while(1)
		{
			sleep (sleepInterval );

			if (RestrtFlag  == TRUE)
			{
				forkid = fork ();
				if ( forkid == 0 )
				{
					logInfo("\n In Child again as it got killed...%d",forkid);
					ChildMain () ;
				}
				else
				{
					logInfo ("\n In Parent to reset RestrtFlag again");
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					signal(SIGCHLD,SignalHandlerSigChldParent);
					signal(SIGTERM,SignalHandlerSigTermParent);
					RestrtFlag  = FALSE ;
				}
			}
		} 
	}

	logTimestamp("Exit : [main]");
}

void *ChildMain ()
{
	logTimestamp("Entry : [ChildMain]");
	BOOL    iRetPthCreate ;
	LONG32      Signal;
	BOOL RetVal = FALSE ;

	iRetPthCreate = pthread_create(&SignalTid2, NULL, AutoRestartForCrash, NULL);
	if ( iRetPthCreate != 0 )
	{
		logFatal ("\n pthread_create:AutoRestartForCrash");
		exit (1);
	}
	logDebug2("\n AutoRestartForCrash thread created");
	sigemptyset ( &ChildSignalSet );
	sigaddset ( &ChildSignalSet , SIGTERM);
	pthread_sigmask ( SIG_BLOCK,&ChildSignalSet,NULL);
	while(1)
	{
		if((RetVal = sigwait(&ChildSignalSet,&Signal)) < 0)
		{
			logDebug3("\n sigwait:ChildSignalSet");
			break;
		}

		logInfo("\n Received Signal in Child :%d",Signal);
		if (Signal == SIGTERM)
		{
			pthread_cancel(SignalTid1);
			pthread_cancel(SignalTid2);
			break;
		}
	}
	logTimestamp("Exit : [ChildMain]");
}

void * AutoRestartForCrash ()
{
	logTimestamp("Entry : [AutoRestartForCrash]");
	LONG32 psp;
	struct elf_prpsinfo ps;
	CHAR fn[100];
	CHAR iProcessId[10];
	CHAR args[500];
	CHAR args1[500];
	CHAR ProgName[50];
	CHAR *arr[6];
	CHAR *buf;
	CHAR    tempProgName[50];
	BOOL    RetVal ;
	LONG32  sleepInterval = atoi(getenv("PROCESS_MON_DELAY") );
	LONG32  i ;
	BOOL    MonChkFlag = FALSE ;

	struct stat buffer;
	struct ProcessMonitorArray * MemArray;

	logInfo("\n IN AutoRestartForCrash" );
	while ( TRUE )
	{
		LockShm(ProcessMonitorShm);
		MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
		if( *((int *)MemArray) == ERROR )
		{
			logInfo("\n OpenSharedMemory:ProcessMonitorShm");
			UnLockShm(ProcessMonitorShm);
			exit(ERROR);
		}
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			if (MemArray->ProcessMonitor[i].iProcessId != UNUSED )
			{
				memset ( tempProgName ,'\0',50 );
				memset(iProcessId,0,10);
				sprintf(iProcessId,"%d",MemArray->ProcessMonitor[i].iProcessId);
				memset(fn,0,100);
				strcat(fn, "/proc/");
				strcat(fn, iProcessId);
				strcat(fn, "/stat");
				strncpy (tempProgName,MemArray->ProcessMonitor[i].sProcessName,strlen (MemArray->ProcessMonitor[i].sProcessName));
				errno = 0;
				if ((psp = open(fn, O_RDONLY)) == -1)
				{
					ProcessSelfRestart(&MemArray->ProcessMonitor[i]);
				}
			}
		}
		if ((CloseSharedMemory(MemArray)) == ERROR )
		{
			logInfo("\n CloseSharedMemory:ProcessMonitorShm");
			UnLockShm(ProcessMonitorShm);
			exit(ERROR);
		}
		UnLockShm ( ProcessMonitorShm );

		sleep (sleepInterval );

	}
	logTimestamp("Exit: [AutoRestartForCrash]");
}

void ProcessSelfRestart(struct  ProcessMonitor *ProcessMonitor)
{
	logTimestamp("Entry : [ProcessSelfRestart]");

	CHAR    tempProgName[50];
	BOOL    iRetVal ;
	LONG32  MaxAutoReTry = 0 ;
	LONG32  tempPID = 0;
	LONG32  result =0 ;

	MaxAutoReTry = atoi(getenv("MAX_AUTO_RETRY"));

	memset ( tempProgName ,'\0',50 );
	strncpy (tempProgName,ProcessMonitor->sProcessName,strlen (ProcessMonitor->sProcessName));
	tempPID = ProcessMonitor->iProcessId;

	if(ProcessMonitor->iAttempts >= MaxAutoReTry )
	{
		if ( ProcessMonitor->iAttempts == MaxAutoReTry )
		{
			logInfo( "\n Process [%s] Not to be restarted automatically as it has reached max level",tempProgName);
			ProcessMonitor->iAttempts = MaxAutoReTry + 1;
		}
	}
	else
	{
		do
		{
			logInfo( "\n Process to be  restarted  %s ",tempProgName );
			UnLockShm ( ProcessMonitorShm );
			iRetVal = selfRestrter ( ProcessMonitor->iProcessId );
			LockShm ( ProcessMonitorShm );
			if ( iRetVal != 0 )
			{
				ProcessMonitor->iAttempts = ProcessMonitor->iAttempts + 1 ;
			}
			sleep(3);
		}while ( iRetVal != 0 && ProcessMonitor->iAttempts < MaxAutoReTry );

		if ( iRetVal == 0 )
		{
			logInfo( "\n Process [%s] got restarted in [%d] attempt(s).",tempProgName ,ProcessMonitor->iAttempts + 1);
			ProcessMonitor->iAttempts = ProcessMonitor->iAttempts + 1;
		}
		else
		{
			logInfo("\n FATAL:Unable to start [%s]. Please check the log immediately.",tempProgName );
			ProcessMonitor->iAttempts = MaxAutoReTry ;
		}
	}
	logTimestamp("Exit : [ProcessSelfRestart]");
}

void *SignalHandlerSigChldParent ()
{
	logTimestamp("Entry : [SignalHandlerSigChldParent]");
	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	selfRestrtCount++;
	logInfo( "\n Received signal SIGCHLD %d times",selfRestrtCount);
	if ( selfRestrtCount <= MaxSelfRetry )
	{
		RestrtFlag = TRUE ;
	}
	else
	{
		logInfo("\n FATAL: Unable to recover ProcessMonitor, Please restart it manually");
	}
	logTimestamp("Exit : [SignalHandlerSigChldParent]");
}
void *SignalHandlerSigTermParent()
{
	logTimestamp("Entry : [SignalHandlerSigTermParent]");
	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	logFatal("\n Got SIGTERM to parent so killing the process ");
	sleep (3);
	kill(ChildId,SIGTERM);

	logTimestamp("Exit : [SignalHandlerSigTermParent]");
	exit(1);
}


BOOL selfRestrter (LONG32 pid)
{
	logTimestamp("Entry : [selfRestrter]");

	CHAR c_aCommand[80];
	FILE *fppopen;
	CHAR  pretval[30];
	CHAR sretval[5];
	LONG32 iretval = 0;

	memset ( c_aCommand ,'\0',80);
	memset ( pretval ,'\0',30);
	memset ( sretval,'\0',5);

	if ( pid ==  UNUSED )
	{
		return (1);
	}
	logInfo("\n Process ID for Restart %d",pid);
	sprintf (c_aCommand ,"selfRestrt.sh %d",pid);
	logInfo("\n c_aCommand :%s:",c_aCommand);
	fppopen = popen(c_aCommand, "r");
	fscanf(fppopen, "%s",sretval);
	pclose(fppopen);
	logInfo("\n sretval = [%s]",sretval);
	iretval = atoi (sretval);
	logDebug3("\n iretval = [%d]",iretval);
	return (iretval);
	logTimestamp("Exit : [selfRestrter]");
}


