#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <my_global.h>
#include <mysql.h>
//#include "hiredis.h"
#include "IPCS.h"


redisContext    *RdConn;
BOOL  main()
{
	logTimestamp("Entry : main");
	unsigned int  i,j;
	redisReply *reply;
	INT16   	iRow;
	MYSQL           *DBCon;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *SqlQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *RedisQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	setbuf(stdout,NULL);
	setbuf(stdin, NULL );
	RdConn   = RDConnect();

	DBCon = DB_Connect();

	sprintf(SqlQuery,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),SM_EXCH_SYMBOL,\
			SM_SYMBOL_NAME,SM_INSTRUMENT_NAME,ifnull(SM_SERIES,'EQ'),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),SM_PREOPEN_FLAG,\
			SM_PREOPEN_EXCH_FLAG,SM_ITS_FLAG,SM_ALGO_FLAG,ifnull(SM_CA_FLAG,1),ifnull(SM_FACE_VALUE,1),SM_TICK_SIZE,ifnull(SM_LOT_SIZE,1),\
			ifnull(SM_LOT_UNITS,1),SM_UPPER_LIMIT,SM_LOWER_LIMIT FROM SECURITY_MASTER WHERE SM_STATUS = 'A' AND  SM_SEGMENT = \'%c\'",EQUITY_SEGMENT);

	logDebug1("SqlQuery :%s:",SqlQuery);

	if(mysql_query(DBCon,SqlQuery) != 0)
	{
		logDebug2("ERROR While Executing  query ");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return ERROR ;
	}
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	logDebug1("############	Row  Selected :%i: ###############",iRow);

	while(Row = mysql_fetch_row(Res))
	{
		sprintf(RedisQry,"HMSET %s:%c:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s "Row[0],Row[1],Row[2],SM_EXCHANGE,Row[0],SM_SEGMENT,Row[1],SM_SCRIP_CODE,Row[2],SM_EXCH_SCRIP_CODE,Row[3],SM_ISIN_CODE,Row[4],SM_EXCH_SYMBOL,Row[5],SM_INSTRUMENT_NAME,Row[7],SM_SERIES,Row[8],SM_STATUS,Row[9],SM_EXCH_STATUS,Row[10],SM_PREOPEN_FLAG,Row[11],SM_PREOPEN_EXCH_FLAG,Row[12],SM_ITS_FLAG,Row[13],SM_ALGO_FLAG,Row[14],SM_CA_FLAG,"1",SM_FACE_VALUE,Row[16],SM_TICK_SIZE, Row[17],SM_LOT_SIZE,Row[18],SM_LOT_UNITS,Row[19],SM_UPPER_LIMIT,Row[20],SM_LOWER_LIMIT,Row[21]);

		logDebug2("RedisQry :%s:",RedisQry);

		reply = redisCommand(RdConn,RedisQry);

		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug1("Values added  Successfully to  hash for Security ID[%s]",Row[2]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error While Adding Security Master In hash    :%s:",reply->str);
		}

		freeReplyObject(reply);
		usleep(100);
	}

	redisFree(RdConn);
	mysql_close(DBCon);
	logTimestamp("EXIT : main");

	return TRUE ;
}

