#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"


void    OpenMsgQue();
LONG32  iRDaemonToSqoff=0;

LONG32 main (LONG32 argc,CHAR **argv)
{	

	logDebug2(" ENTRY [ManualSqrOffPumper]");
	struct  ORDER_REQUEST pReq_OffOrd,pReq_SqOff;
	INT16   iMsgType;
	INT16   iMktStat;
	CHAR    cMkt_Seg,cMode;
	CHAR    sOMSExch[EXCHANGE_LEN];
	CHAR    sMkt_Exch[EXCHANGE_LEN];
	LONG32  Mkt;
	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);
	LONG64	iMktType = 1;

	setbuf(stdin,0);
	setbuf(stdout,0);
	OpenMsgQue();
	LONG32  iTrdRtrToD2C=0;

	if ( argc != 3 )
	{
		logDebug2(" 2 Argument to be Entered Wil be -> [P -> PumpOrder / S -> SquareOff] And [0 -> BSE_EQU / 1-> NSE_EQU / 2 -> NSE_DRV / 3-> NSE_CURR / 4-> MCX_MORNING_SESS /5 -> MCX_MORNING_SESS  " );
		exit (0);
	}



	if ( strcmp ( argv[1],"P") == 0 )
	{	
		logDebug2("ENTRY [OffOrdExecute]");
		switch (atoi(argv[2]))
		{

			case 0:
				Mkt = BSE_EQU;   
				cMkt_Seg = SEGMENT_EQUITY;   
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);     
				break;

			case 1:
				Mkt = NSE_EQU;  
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				break;


			case 2:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				break;

			case 3:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				break;

			case 4:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_MORNING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				break;

			case 5:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_EVENING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				break;


			default:
				logFatal("[OffOrd:%d] Invalid market type",argv[2]);
				break;

		}

		memset(&pReq_OffOrd,'\0',sizeof(struct  ORDER_REQUEST));
		pReq_OffOrd.ReqHeader.iSeqNo = iMktType;
		pReq_OffOrd.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_OffOrd.ReqHeader.iMsgCode = TC_INT_PUMPOFFLINE_REQ;
		pReq_OffOrd.ReqHeader.iUserId = 0;
		pReq_OffOrd.ReqHeader.cSegment = cMkt_Seg;
		pReq_OffOrd.cUserType = 'A';
		strncpy(pReq_OffOrd.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		strncpy(pReq_OffOrd.sRemarks,"Manual_Success",REMARKS_LEN);
		logDebug2("[OffOrd:%d] Triggering Offline Orders for :%s:%c:",argv[2],sMkt_Exch,cMkt_Seg);	
		if(WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_OffOrd,sizeof(struct ORDER_REQUEST),1 )!= TRUE)  
		{
			logFatal("[OffOrd] Error WriteQ ");
			logDebug2("[OffOrd:%d] Write Q id %d",argv[2],iRDaemonToSqoff);
			exit(ERROR);
		}

		logTimestamp("Exit : [OffOrdExecute]");

	}

	else if (strcmp ( argv[1],"S") == 0 )
	{

		logTimestamp("Entry : [SqOffExecute]");

		switch (atoi(argv[2]))
		{

			case 0:
				Mkt = BSE_EQU;   
				cMkt_Seg = SEGMENT_EQUITY;   
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);       
				iMsgType = 1;
				break;

			case 1:
				Mkt = NSE_EQU;  
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;


			case 2:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;

			case 3:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 1;
				break;

			case 4:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_MORNING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;

			case 5:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_EVENING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;

			default:
				logFatal("[SqOff:%d] Invalid market type",argv[2]);
				break;
		}

		memset(&pReq_SqOff,'\0',sizeof(struct  ORDER_REQUEST));
		pReq_SqOff.ReqHeader.iSeqNo = iMktType;
		pReq_SqOff.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_SqOff.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_INTRADAY_REQ;
		pReq_SqOff.ReqHeader.iUserId = 0;
		pReq_SqOff.ReqHeader.cSegment = cMkt_Seg;
		pReq_SqOff.cUserType = 'A';
		strncpy(pReq_SqOff.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		strncpy(pReq_SqOff.sRemarks,"Manual_Success",REMARKS_LEN);
		logDebug2("[SqOff:%d] Triggering Square Off Orders for :%s:%c:",argv[2],sMkt_Exch,cMkt_Seg);
		if(WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_SqOff,sizeof(struct ORDER_REQUEST),iMsgType )!= TRUE)
		{
			logFatal("[OffOrd] Error WriteQ ");
			logDebug2("[OffOrd:%d] Write Q id %d",argv[2],iRDaemonToSqoff);
			exit(ERROR);
		}
		logTimestamp("Exit : [SqOffExecute]");

	}

	else
		logDebug2("Wrong Argument Passed");

	logDebug2(" EXIT[ManualSqrOffPumper]"); 
}


void OpenMsgQue()
{

	logTimestamp("Entry : [OpenMsgQue]");
	if((iRDaemonToSqoff= OpenMsgQ(RDaemonToSqoff)) == ERROR)
	{
		perror("\n OpenMsgQ ...RDaemonToSqoff");
		exit(ERROR);
	}

	logTimestamp("Exit : [OpenMsgQue]");
}






















