#include "IPCSSprd.h"

BOOL BasicValidation(struct INT_SPREAD_ORDERS *pReq)
{
	logTimestamp("Entry : [BasicValidation]");
		if(strlen(pReq->sEntityId) == 0){
			logDebug3("Invalid EntityId. :%s:",pReq->sEntityId);
				return BASIC_VALIDATION_FAILED;
		}
		else if(strlen(pReq->sClientId) == 0){
			logDebug3("Invalid ClientId.");
				return BASIC_VALIDATION_FAILED;
		}
		else if(strlen(pReq->sSecId_1) == 0){
			logDebug3("Invalid SecurityId.");
				return BASIC_VALIDATION_FAILED;
		}
		else if(strlen(pReq->sSecId_2) == 0){
			logDebug3("Invalid SecurityId.");
				return BASIC_VALIDATION_FAILED;
		}
		else if(pReq->fOrderPrice < 0){
			logDebug3("Invalid Price.");
				return BASIC_VALIDATION_FAILED;
		}
		else if(strchr (SRCFLAG, pReq->ReqHeader.cSource) == NULL){
			logDebug3("Invalid SourceFlag.");
				return BASIC_VALIDATION_FAILED;
		}
		else if(pReq->iTotalQty<=0)
		{
			logDebug3("Invalid Quantity");
				return BASIC_VALIDATION_FAILED;
		}
		else{
			logTimestamp("Exit : [BasicValidation]");
				return TRUE;
		}
}
