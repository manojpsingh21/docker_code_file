#include "ConnectStatus.h"
#include "IPCS.h"

//#define MAX_GROUPS      1

void main()
{
       	CHAR    RetFlag ;
	LONG32  i;
	LONG32  iRetval;
	CHAR	sExchAlow[ENV_VARIABLE_LEN];
//	CHAR	*sExchAlow = malloc(sizeof(CHAR) * ENV_VARIABLE_LEN);
	struct  CONNECT_STATUS TempReadConnectStatus[MAX_GROUPS];

	memset(sExchAlow,'\0',ENV_VARIABLE_LEN);

	iRetval = fReadConnStat(TempReadConnectStatus);
	if(iRetval == FALSE)
	{
		logFatal("Error in Reading Connection Status Shared Memory ");
		exit(ERROR);
	}

	if(getenv("EXCH_ALLOWED") == NULL)
	{
		logFatal("Error : Environment variables missing : EXCH_ALLOWED");
		exit(ERROR);
	}
	else
	{
		strncpy(sExchAlow,getenv("EXCH_ALLOWED"),ENV_VARIABLE_LEN);
	}

	logPrintf("\n\n\tNseEqu\tNseDrv\tBseEqu\tNSECur\tMCXCOM");
	logPrintf("\n\t------\t------\t------\t------\t------\t\n");

	for(i=GROUPID-1;i<GROUPID;i++)
	{
		logPrintf("Status: ");
		if(sExchAlow[0] == '1') {
			if(TempReadConnectStatus[i].NseEqu == '1')
				logPrintf("NSE-E~UP|");
			else
				logPrintf("NSE-E~DOWN|");
		}

		if(sExchAlow[1] == '1') {
			if(TempReadConnectStatus[i].NseDrv == '1')
				logPrintf("NSE-D~UP|");
			else
				logPrintf("NSE-D~DOWN|");
		}

		if(sExchAlow[3] == '1') {
			if(TempReadConnectStatus[i].BseEqu == '1')
				logPrintf("BSE-E~UP|");
			else
				logPrintf("BSE-E~DOWN|");
		}

		if(sExchAlow[2] == '1') {
			if(TempReadConnectStatus[i].NseCur == '1')
				logPrintf("NSE-C~UP|");
			else
				logPrintf("NSE-C~DOWN|");
		}

		if(sExchAlow[4] == '1') {
			if(TempReadConnectStatus[i].MCXComm == '1')
				logPrintf("MCX-M~UP|");
			else
				logPrintf("MCX-M~DOWN|");
		}

		if(sExchAlow[5] == '1') {
                        if(TempReadConnectStatus[i].BseDrv== '1')
                                logPrintf("BSE-D~UP|");
                        else
                                logPrintf("BSE-D~DOWN|");
                }

	}
	logPrintf("\n");
}
