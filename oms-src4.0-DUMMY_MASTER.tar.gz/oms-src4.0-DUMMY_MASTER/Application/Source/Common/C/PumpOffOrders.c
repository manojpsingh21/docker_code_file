#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>


LONG32 iOrdRtrToCatalystNSEEQ;

MYSQL *OdrConn;

main()//int argc, char argv[])
{

	int ich,rw;
	char statement[200];	
	double fOrderNum;
	int iSerialNum;
	int  iMsgcode;	
	char bs = 'B';
	double fPrice;

	OdrConn=DB_Connect();
	MYSQL_RES *result;	
	MYSQL_ROW row;

	printf("\n 3");

	struct ORDER_REQUEST  pOrdReq;

	memset(&pOrdReq,'\0',sizeof(struct ORDER_REQUEST));

	if((iOrdRtrToCatalystNSEEQ = OpenMsgQ(OrdRtrToOffOrd)) == ERROR)
	{
		perror("OpenMsgQ ...OrdRtrToCatalystNSEEQ");
		exit(ERROR);
	}
	printf("\n OrdRtrToCatalystNSEEQ opened successfully with id = %d", iOrdRtrToCatalystNSEEQ);

	//	printf("\n argc : %d",argc);





	/********************Nitish Code ********************************************/


	printf("\nENTER THE MESSAGE TYPE\n");

	printf("\n 1.New Entery ");
	printf("\n 2.Modify the Entry");
	printf("\n 3.Cancel the Entry\n");
	printf("->");

	scanf("%d",&ich);

	if(ich==1)
		pOrdReq.ReqHeader.iMsgCode=TC_INT_OFF_ORDER_ENTRY;
	else if(ich==2)
		pOrdReq.ReqHeader.iMsgCode=TC_INT_OFF_ORDER_MODIFY;
	else if(ich==3)
		pOrdReq.ReqHeader.iMsgCode=TC_INT_OFF_ORDER_CANCEL;
	else
		printf("Invalid Input");

	switch(pOrdReq.ReqHeader.iMsgCode)
	{
		case TC_INT_OFF_ORDER_ENTRY:
			{	
				printf("\nEnter Buy or Sell ");
				printf("\n B.Buy ");
				printf("\n S.Sell");
				printf("\n ->");
				scanf(" %c",&bs);

				if(bs == 'B' || bs == 'b')
				{
					bs = 'B';
					printf("\n buy/sell : %c",bs);
					printf("\nPlease enter the Buy Price");
					printf("\n ->");
					scanf(" %lf",&fPrice);
					pOrdReq.fPrice = fPrice;
				}
				else if(bs == 'S' || bs == 's')
				{
					bs = 'S';
					printf("\n buy/sell : %c",bs);
					printf("\n Please enter the Sell Price");
					printf("\n ->");
					scanf(" %lf",&fPrice);
					pOrdReq.fPrice = fPrice;
				}
				else
					printf("\nInvalid Input");
				pOrdReq.iSerialNum=1;
			}			

			break;

		case TC_INT_OFF_ORDER_MODIFY:
			{
				printf("\n Enter the Order Number ");
				printf("\n ->");
				scanf("%lf",&fOrderNum);
				pOrdReq.fOrderNum=fOrderNum;
				printf("\n order no. :  %lf",pOrdReq.fOrderNum);			
				sprintf(statement,"SELECT max(EQ_SERIAL_NO) FROM rupeeSQLDB.EQ_ORDERS WHERE EQ_ORDER_NO=%lf",pOrdReq.fOrderNum);			
				printf("\n query -> %s", statement);



				if(mysql_query(OdrConn,statement)!=SUCCESS)
				{
					logSqlFatal("Err in Query.");
					sql_Error(OdrConn);
					return ERROR;
				}
				result=mysql_store_result(OdrConn);

				if((rw=mysql_num_rows(result))==0)
				{
					sql_Error(OdrConn);
					return ERROR;

				}

				row = mysql_fetch_row(result);

				printf("\n Please Enter the Price ");
				printf("\n ->");
				scanf(" %lf",&fPrice);
				printf("\n 1");
				printf("\n %lf",fPrice);	
				pOrdReq.fPrice=fPrice;
				printf("\n 2");
				iSerialNum=atoi(row[0]);			
				pOrdReq.iSerialNum=iSerialNum;
				printf("\n Serial Number is %d \n",pOrdReq.iSerialNum);

				pOrdReq.iSerialNum++;

				mysql_free_result(result);		
				memset(statement,'\0',strlen(statement));
			}
			break;

		case TC_INT_OFF_ORDER_CANCEL:
			{
				printf("\n Enter the Order Number ");
				printf("\n ->");
				scanf(" %lf",&fOrderNum);

				pOrdReq.fOrderNum=fOrderNum;

				sprintf(statement,"SELECT max(EQ_SERIAL_NO) FROM rupeeSQLDB.EQ_ORDERS WHERE EQ_ORDER_NO=%lf",pOrdReq.fOrderNum);

				if(mysql_query(OdrConn,statement)!=SUCCESS)
				{
					logSqlFatal("Error in QUERY.");
					sql_Error(OdrConn);
					return ERROR;
				}

				result=mysql_store_result(OdrConn);

				if((rw=mysql_num_rows(result))==0)
				{
					sql_Error(OdrConn);
					return ERROR;
				}

				row = mysql_fetch_row(result);

				iSerialNum=atoi(row[0]);
				pOrdReq.iSerialNum=iSerialNum;
				printf("\n Serial Number is %d \n",pOrdReq.iSerialNum);

				pOrdReq.iSerialNum++;


				mysql_free_result(result);
				memset(statement,'\0',strlen(statement));
			}
			break;

		default:

			printf("\n Invalid input ");	
	}

	/********************End of Nitish COde ***************************************/





	//	pOrdReq.fOrderNum = atof(argv[1]);
	//	pOrdReq.iSerialNum = atoi(argv[2]);

	pOrdReq.ReqHeader.iSeqNo = 11;
	pOrdReq.ReqHeader.iMsgLength = 100;
	//	pOrdReq.ReqHeader.iMsgCode	=  atoi(argv[3]);
	strncpy(pOrdReq.ReqHeader.sExcgId,"NSE",EXCHANGE_LEN);
	pOrdReq.ReqHeader.iUserId = 9223;
	pOrdReq.ReqHeader.cSource = 'M';
	pOrdReq.ReqHeader.cSegment = 'E';
	//	pOrdReq.fOrderNum = 0;
	//pOrdReq.iSerialNum = 75;
	strncpy(pOrdReq.sSecurityId,"11536",DB_SECURITY_ID_LEN);
	strncpy(pOrdReq.sEntityId,"DP007",DB_ENTITY_ID_LEN);
	strncpy(pOrdReq.sClientId,"DP007",DB_CLIENT_ID_LEN);
	pOrdReq.iTotalQty = 5000;
	pOrdReq.iTotalQtyRem = 5000;
	pOrdReq.iDiscQty = 0;
	pOrdReq.iDiscQtyRem = 0;
	pOrdReq.iTotalTradedQty = 0;
	pOrdReq.cBuyOrSell = bs;
	pOrdReq.iMktType = 1;
	//pOrdReq.cBuyOrSell = 'B';
	//	pOrdReq.fPrice = 50.1;
	pOrdReq.iOrderType	= 1;
	/*	if(argc > 4)
		{
		printf("\n iMsgCode : %d",pOrdReq.ReqHeader.iMsgCode);
		if(pOrdReq.ReqHeader.iMsgCode == 2040)
		{
		pOrdReq.fPrice = atof(argv[4]);
	//pOrdReq.iOrderType	= atoi(argv[4]);
	}
	if(pOrdReq.ReqHeader.iMsgCode == 2070)
	{
	//pOrdReq.iOrderType	= atoi(argv[4]);
	}
	if(pOrdReq.ReqHeader.iMsgCode == 2000)
	{
	pOrdReq.cBuyOrSell = argv[4][0];
	}
	}
	else
	{
	pOrdReq.cBuyOrSell = 'B';
	pOrdReq.fPrice = 50.1;
	}*/
	printf("\n BuySell : %c",pOrdReq.cBuyOrSell);
	pOrdReq.fTriggerPrice = 2495.50000;
	pOrdReq.iOrderValidity = 0;
	pOrdReq.iMinFillQty = 10;
	pOrdReq.cProCli = 'C';
	pOrdReq.cUserType = 'C';
	pOrdReq.cOffMarketFlg = 'N';
	pOrdReq.cProductId = 'I';
	pOrdReq.cHandleInst = '1';

	printf("sExcgId is:%s",pOrdReq.ReqHeader.sExcgId);	
	if(WriteMsgQ( iOrdRtrToCatalystNSEEQ ,(CHAR *) &pOrdReq, sizeof(struct ORDER_REQUEST),1) != 1){
		perror("write to Q failed : ");
		exit(ERROR);
	}
	printf("\n write successful \n");
	printf("\n Serial NUMBer is %d \n",pOrdReq.iSerialNum);
	printf("\n Order NUmber %f \n",pOrdReq.fOrderNum);
	printf("\n MsgCode is %d \n",pOrdReq.ReqHeader.iMsgCode);
	printf("\n Price is %lf \n",pOrdReq.fPrice);
	printf("\n Buy/Sell is %c \n",pOrdReq.cBuyOrSell);

}
