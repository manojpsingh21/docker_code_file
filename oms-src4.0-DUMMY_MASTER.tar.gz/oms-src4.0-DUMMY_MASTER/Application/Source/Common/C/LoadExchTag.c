#include <stdio.h>
#include "IPCS.h"
#include "FIXStructures.h"
extern EXCH_CFG_FILE_STRUCT ExchCfgStruct[CFG_STRUCT_LEN];

#define         FIRST           1
#define         FIRST_COMPLETE          2

BOOL LoadFile (CHAR **argv )
{
	printf("\n In [LoadFile]");
	FILE *fp=NULL;
	CHAR    filename[100];
	CHAR    cTag[MAX_TAG_SIZE];
	LONG32  i = -1 ;
	LONG32  j = 0;
	LONG32  tagCount = 0;
	CHAR    *ptr ;
	LONG32  HERE = FIRST ;
	char *env = NULL;

	memset (filename,'\0',100);
	memset (cTag,'\0',MAX_TAG_SIZE);
	strcpy(filename,argv);

	printf("\n EXCH_CFG_FILE=[%s]",argv);
	printf("\n filename is [%s]",filename);

	fp = fopen(filename,"r");
	if ( fp == NULL )
	{
		printf("\n Unable to open file pointed by name in environment variable EXCH_CFG_FILE.");
		printf("\n Leaving [LoadFile]");
		return FALSE ;
	}
	while(TRUE )
	{
		if ((fgets(cTag,MAX_TAG_SIZE+1,fp)) != NULL)
		{
			if ( cTag[0] == '#' )                   //      For adding comment
			{
				continue;
			}
			else if ( cTag[0] == '\0' || cTag[0] == ' ' || cTag[0] == '\n' )                // for Blank lines
			{
				continue ;
			}
			else if ( strncasecmp(cTag,"EXCH",4) == 0 )             // for one specific broker or tag 128
			{
				ptr = strstr(cTag,"EXCH=");
				if( ptr == NULL )
				{
					printf("\n Leaving [LoadFile]:<EXCH=>");
					return FALSE ;
				}
				strncpy(ExchCfgStruct[++i].sDelToTargetComp, ptr+5, strlen(ptr) - 5 - 1);
				HERE = FIRST ;
			}
			else if ( strncasecmp(cTag,"MSGTYPE",7) == 0 )                          //for message type
			{
				ptr = strstr (cTag,"MSGTYPE=");
				sscanf(ptr,"%[^\n]\n",ptr);
				if ( ptr == NULL )
				{
					printf("\n Leaving [LoadFile]:<MSGTYPE=>");
					return FALSE ;
				}
				if ( HERE != FIRST )
				{
					i = i+1 ;
					strcpy(ExchCfgStruct[i].sDelToTargetComp,ExchCfgStruct[i-1].sDelToTargetComp);
				}
				j = 0;
				//ExchCfgStruct[i].cMsgType = ptr[8] ;
			
				strncpy(ptr, ptr+8,strlen(ptr)) ;
				//printf("\n ptr :%s:",ptr);
				memset(ExchCfgStruct[i].sMsgType,'\0',TAG_LEN);
				strncpy(ExchCfgStruct[i].sMsgType, ptr,strlen(ptr)) ;
				//sprintf(ExchCfgStruct[i].cMsgType,"%c%c",ptr[8],ptr[9]);
				ExchCfgStruct[i].iNoOfTags = 0;
				HERE = FIRST_COMPLETE ;
			}
			else                                                                                            // for tags
			{
				ExchCfgStruct[i].iTagList[j++]= atoi(cTag) ;
				ExchCfgStruct[i].iNoOfTags++ ;
			}
		}
		else
		{
			break;
		}
	}
	return TRUE;
}

Display ()
{
	printf("\n In [Display]");
	LONG32  i , j ;

	for ( i = 0; i < CFG_STRUCT_LEN;i++ )
	{
		if ( strlen(ExchCfgStruct[i].sDelToTargetComp) != 0 )
			//printf("\n DelToCom = %s ,MsgType = %c ,NoOfTags = %d, Tags = ",ExchCfgStruct[i].sDelToTargetComp,ExchCfgStruct[i].cMsgType,ExchCfgStruct[i].iNoOfTags);
			printf("\n DelToCom = %s ,MsgType = %s ,NoOfTags = %d, Tags = ",ExchCfgStruct[i].sDelToTargetComp,ExchCfgStruct[i].sMsgType,ExchCfgStruct[i].iNoOfTags);
		for ( j = 0 ;j < ExchCfgStruct[i].iNoOfTags; j++ )
		{
			printf("%d,",ExchCfgStruct[i].iTagList[j]);
		}
	}
	printf("\n Leaving [Display]");
}

