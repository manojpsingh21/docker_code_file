#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "IPCS.h"


CHAR ReadConnectStatShm(SHORT flag,LONG32 Groupid)
{
	logTimestamp("Entry : [ReadConnectStatShm]");
	CHAR    RetFlag ;
	LONG32  GroupidMod;
	
	logDebug3("flag :%d:",flag);
	logDebug3("Groupid :%d:",Groupid);
	
	struct  EXCH_CONNECT_STATUS *ConnStatusShm_mem,ReadConnectStatus[MAX_GROUPS];

	if((ConnStatusShm_mem = (struct EXCH_CONNECT_STATUS *)OpenSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)) == (struct EXCH_CONNECT_STATUS *) ERROR)
	{
		logFatal("ConnStatusShm Open error : ");
		exit(1);
	}
	if(Groupid < 1)
		GroupidMod = 0;
	else
		GroupidMod=Groupid - 1;

	LockShm(ConnStatusShm);
	memcpy(&ReadConnectStatus,ConnStatusShm_mem,sizeof( struct EXCH_CONNECT_STATUS)*MAX_GROUPS);
	CloseSharedMemory((void *)ConnStatusShm_mem);

	UnLockShm(ConnStatusShm);

	switch(flag)
	{
		case NSE_EQU:
			RetFlag = ReadConnectStatus[GroupidMod].cNseEqu ;
			break;

		case NSE_DRV:
			RetFlag = ReadConnectStatus[GroupidMod].cNseDrv ;
			break;

		case BSE_EQU:
			RetFlag = ReadConnectStatus[GroupidMod].cBseEqu ;
			break;

		case BSE_CUR:
			RetFlag = ReadConnectStatus[GroupidMod].cBseCur ;
			break;


		case BSE_DRV:
			RetFlag = ReadConnectStatus[GroupidMod].cBseDrv ;
			break;

		case NSE_CUR:
			RetFlag = ReadConnectStatus[GroupidMod].cNseCur;
			break;
		case MCX_COM:
			RetFlag = ReadConnectStatus[GroupidMod].cMCXComm;

			break;

/*		
		case BSE_CUR:
                        RetFlag = ReadConnectStatus[GroupidMod].cBseCur ;
                        break;



 		case BSE_COMM:
                        RetFlag = ReadConnectStatus[GroupidMod].cBseComm;
                        logDebug2("RetFlag :%d:",RetFlag);
                        break;

		case NSE_CM:
			RetFlag = ReadConnectStatus[GroupidMod].cNseCM;
			break;		
*/
		default:
			logDebug2("\n Wrong Flag supplied");
	}

	logTimestamp("Exit : [ReadConnectStatShm]");
	logDebug2("RetFlag :%d:",RetFlag);
	
	return RetFlag;
}

BOOL fUpdateConnectStatus(SHORT ConnectionFlag,LONG32 Groupid)
{
	logTimestamp("Entry : [fUpdateConnectStatus]");
	struct EXCH_CONNECT_STATUS *ConnStatusShm_mem,*TempConnStatusShm_mem,*TempConnStat;
	LONG32 	iRetVal = FALSE ;
	LONG32  Bcast_Portno;
	LONG32  GroupidMod;
	LONG32  Tcode = 0 ;
	LONG32  status = 0 ;
	BOOL    flag;

	logDebug2("ConnectionFlag :%d:",ConnectionFlag);
	if(Groupid < 1)
		GroupidMod = 0;
	else
		GroupidMod=Groupid - 1;

	

	/***
	  Updation of shared memory
	 ***/
	logDebug2("ConnectionFlag :%d:  and GROUPID = %d",ConnectionFlag, Groupid);
	if((ConnStatusShm_mem = (struct EXCH_CONNECT_STATUS *)OpenSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)) == (struct EXCH_CONNECT_STATUS *)ERROR)
	{
		logDebug3("ConnStatusShm:Open error");
		return FALSE;
	}
	LockShm(ConnStatusShm);

	logDebug2("ConnectionFlag :%d:",ConnectionFlag);
	/***
	  This is done so that the TempConnStatusShm_mem point to the memory where the connection status
	  for the given groupid is stored.
	 ***/
	TempConnStatusShm_mem = ConnStatusShm_mem + GroupidMod;

	TempConnStat = (struct EXCH_CONNECT_STATUS *) TempConnStatusShm_mem ;
//	printf("ConnectionFlag = %d\n",ConnectionFlag);
	logDebug2("ConnectionFlag :%d:",ConnectionFlag);
	switch(ConnectionFlag)
	{
		case NSE_EQU_UP:
			TempConnStat->cNseEqu= EXCHANGE_UP ;
			break;

		case NSE_EQU_DOWN:
			TempConnStat->cNseEqu= EXCHANGE_DOWN ;
			break;

		case NSE_DRV_UP:
			TempConnStat->cNseDrv= EXCHANGE_UP ;
			break;

		case NSE_DRV_DOWN:
			TempConnStat->cNseDrv= EXCHANGE_DOWN ;
			break;

		case BSE_EQU_UP:
			TempConnStat->cBseEqu= EXCHANGE_UP ;
			break;

		case BSE_EQU_DOWN:
			TempConnStat->cBseEqu= EXCHANGE_DOWN ;
			break;

		case BSE_DRV_UP:
		        logDebug2("In switch Case connectionFlag of BSE_DRV_UP:");
			TempConnStat->cBseDrv= EXCHANGE_UP ;
			break;

		case BSE_DRV_DOWN:
		        logDebug2("In switch Case connectionFlag of BSE_DRV_DOWN:");
			TempConnStat->cBseDrv= EXCHANGE_DOWN ;
			break;

                case BSE_CUR_UP:
                        TempConnStat->cBseCur= EXCHANGE_UP ;
                        break;

                case BSE_CUR_DOWN:
                        TempConnStat->cBseCur= EXCHANGE_DOWN ;
                        break;


		case NSE_CUR_UP:
			TempConnStat->cNseCur= EXCHANGE_UP ;
			break;

		case NSE_CUR_DOWN:
			TempConnStat->cNseCur= EXCHANGE_DOWN ;
			break;

		case MCX_UP:
			TempConnStat->cMCXComm= EXCHANGE_UP ;
			break;

		case MCX_DOWN:
			TempConnStat->cMCXComm= EXCHANGE_DOWN ;
			break;
/*		case BSE_CM_UP:
                        TempConnStat->cBseComm= EXCHANGE_UP ;
                        break;

                case BSE_CM_DOWN:
                        TempConnStat->cBseComm= EXCHANGE_DOWN ;
                        break;

		case NSE_CM_UP:
			TempConnStat->cNseCM= EXCHANGE_UP ;
                        break;
		
		case NSE_CM_DOWN:
                        TempConnStat->cNseCM= EXCHANGE_DOWN ;
                        break;

*/
		default:
			logDebug2("\nWrong transcode supplied");
			break;
	}


	UnLockShm(ConnStatusShm);
	CloseSharedMemory((void *)ConnStatusShm_mem);
	
	/******* Alerting Monitoring tool ******/
//	fNotifyExchStatus(ConnectionFlag);
	
	logTimestamp("Exit : [fUpdateConnectStatus]");
	return TRUE ;
}

BOOL fReadConnStat(CHAR *TempReadConnectStatus)
{
	logTimestamp("Entry : [fReadConnStat]");
	struct  EXCH_CONNECT_STATUS *ConnStatusShm_mem;


	if((ConnStatusShm_mem = (struct EXCH_CONNECT_STATUS *)OpenSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)) == (struct EXCH_CONNECT_STATUS *) ERROR)
	{
		logFatal("ConnStatusShm Open error : ");
		return FALSE;
	}

	LockShm(ConnStatusShm);
	memcpy(TempReadConnectStatus,ConnStatusShm_mem,ConnStatusShm_SIZE);
	CloseSharedMemory((void *)ConnStatusShm_mem);
	UnLockShm(ConnStatusShm);
	logTimestamp("Exit : [fReadConnStat]");
	return TRUE;
}


