# include "IPCS.h"
# include <string.h>
# include <errno.h>
# include <sys/ipc.h>
# include <sys/msg.h>

void  main ( int argc,char ** argv  )
{
	logTimestamp("Entry : [main]");
	struct ProcessMonitorArray * MemArray;
	char   MainProcess[50];
	int i,error_ind = 0;

	if (argc != 2 )
	{
		logFatal( "\n Improper Usage : Command line argument either ALL or Process name\n");
		exit (1);
	}
	LockShm(ProcessMonitorShm);
	MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
	if( *((int *)MemArray) == ERROR )
	{
		UnLockShm(ProcessMonitorShm);
		exit(1);
	}
	if ( strcmp ( argv[1],"COMPLETE") == 0 )
	{
		for( i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i++ )
		{
			{
				logPrintf("ProcessID: %d  %s    %s         %d             %d      %d      %c\n", MemArray->ProcessMonitor[i].iProcessId,\
						MemArray->ProcessMonitor[i].sProcessName,\
						MemArray->ProcessMonitor[i].sMainProcessName ,MemArray->ProcessMonitor[i].iAttempts,\
						MemArray->ProcessMonitor[i].iStartTime,MemArray->ProcessMonitor[i].iEndTime,\
						MemArray->ProcessMonitor[i].cRecoveryFlag);
			}
		}
	}
	else if ( strcmp ( argv[1],"ALL") == 0 )
	{
		for( i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i++ )
		{
			if (MemArray->ProcessMonitor[i].iProcessId != UNUSED )
			{
				logPrintf("ProcessID: %d  %s    %s\n", MemArray->ProcessMonitor[i].iProcessId,\
						MemArray->ProcessMonitor[i].sProcessName,\
						MemArray->ProcessMonitor[i].sMainProcessName );
				error_ind = 1;
			}
		}
	}
	else
	{
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			if (strcmp(MemArray->ProcessMonitor[i].sMainProcessName,argv[1]) == 0 &&
					MemArray->ProcessMonitor[i].iProcessId != UNUSED )
			{
				logPrintf("ProcessID: %d  %s    %s\n", MemArray->ProcessMonitor[i].iProcessId,\
						MemArray->ProcessMonitor[i].sProcessName,\
						MemArray->ProcessMonitor[i].sMainProcessName );
				error_ind = 1;
			}
		}
		if (error_ind != 1)
		{
			for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
			{
				if (strcmp(MemArray->ProcessMonitor[i].sProcessName,argv[1]) == 0 &&
						MemArray->ProcessMonitor[i].iProcessId != UNUSED )
				{
					logPrintf("ProcessID: %d  %s    %s\n", MemArray->ProcessMonitor[i].iProcessId,\
							MemArray->ProcessMonitor[i].sProcessName,\
							MemArray->ProcessMonitor[i].sMainProcessName );
					error_ind = 1;
				}
			}
		}
	}
	UnLockShm(ProcessMonitorShm);
	if(error_ind == 0)
	{        
		logTimestamp("Exit : [main]");
		exit(1);
	}

}

