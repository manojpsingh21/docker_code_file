#include "HashTable.h"
#include "IPCSSprd.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

struct  SPRD_SEC_MASTER_ARRAY        *HashSprByID = NULL;
struct  SPRD_SEC_MASTER_ARRAY        *HashSprDrvID = NULL;

BOOL    fAddDrvSpreadSecHash(struct ORDER_SPREAD_REQUEST *pOrd_Sprd_Rq)
{
	logTimestamp("Entry fAddDrvSpreadSecHash [Main]");
	MYSQL           *DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32          iNumRow,i=0;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sTempSecID1[DB_SCRIP_CODE_LEN];
	CHAR            sTempSecID2[DB_SCRIP_CODE_LEN];
	LONG32		n =0;

	DBConSec = DB_Connect();

	sprintf(sSelQuery,"SELECT SPD_TOKEN1,SPD_INSTRUNAME1 ,SPD_SYMBOL1 ,JULIDATE(SPD_EXPIRYDATE1),SPD_EXPIRYDATE1 ,SPD_TOKEN2,SPD_INSTRUNAME2,SPD_SYMBOL2,JULIDATE(SPD_EXPIRYDATE2),SPD_EXPIRYDATE2 ,SPD_REFERENCEPRICE ,SPD_UNDERLYING_SCRIPCODE ,SPD_UNDERLYING_SYM ,SPD_TRADING_SYM1 ,SPD_TRADING_SYM2 ,SPD_UNDERLAYIN_STATUS ,SPD_EXCH ,SPD_SEG   FROM SECURITY_MASTER_SPREAD WHERE SPD_SEG = \'%c\';",DERIVATIVE_SEGMENT);

	logDebug1(" sSelQuery :%s:",sSelQuery);

	if(mysql_query(DBConSec,sSelQuery) != SUCCESS)
	{
		logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddDrvSpreadSecHash]");
		sql_Error(DBConSec);
		mysql_close(DBConSec);
		return FALSE;
	}
	Res = mysql_store_result(DBConSec);
	iNumRow = mysql_num_rows(Res);

	if (iNumRow == 0)
	{
		logDebug2("No result Set");

	}
	else
	{
		logDebug1("iNumRow :%d:",iNumRow);

		struct SPRD_SEC_MASTER_ARRAY *DrvSprdSecHsh[iNumRow],*TempSec ;

		while(Row = mysql_fetch_row(Res))
		{

			DrvSprdSecHsh[i] = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));
			TempSec     	= (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

			sprintf(DrvSecHsh[i]->sKey,"%s%s",Row[2],Row[3]);

			HASH_FIND(hSecHndlr,HashSprByID, &DrvSecHsh[i]->sKey,strlen(DrvSecHsh[i]->sKey),TempSec);

			if(TempSec == NULL)
			{


				for (LONG32 i = 0; iRecord <= pOrd_Sprd_Rq->iNoOfLeg ; i++ )
				{
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[i].sScripCode,Row[n],DB_SCRIP_CODE_LEN);
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[i].sInsName,Row[n+1],DB_INS_LEN);
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[i].sSymbol,Row[n+2],SYMBOL_LEN);
					DrvSprdSecHsh[i]->SprdSecMstr[i].iExpiryDate	= atoi(Row[n+3]);/*Julian Date */ 
					strncpy(DrvSprdSecHsh[i]->SprdSecMstr[i].sExpiryDate,Row[n+4],15);  
					n = 5;
				}

				DrvSprdSecHsh[i]->fReferencePrice  	= atof(Row[10]);
				DrvSprdSecHsh[i]->iUnderlyingScripCode	= atoi(Row[11]);

				strncpy(DrvSprdSecHsh[i]->sUnderlyingSym,Row[12],45);
				strncpy(DrvSprdSecHsh[i]->sSpdTradingSym1,Row[13],50);
				strncpy(DrvSprdSecHsh[i]->sSpdTradingSym2,Row[14],50);

				DrvSprdSecHsh[i]->cUnderlyingStatus 	= (Row[15][0]);
				strncpy(DrvSprdSecHsh[i]->sExch,Row[16],DB_EXCH_ID_LEN);
				DrvSprdSecHsh[i]->cSeg  		=  (Row[17][0]);

				HASH_ADD(hSecHndlr,HashSprByID,DrvSecHsh[i]->sKey,strlen(DrvSecHsh[i]->sKey), DrvSprdSecHsh[i]);
				i++;
			}
		}
		mysql_close(DBConSec);
		logTimestamp("Exit fAddDrvSpreadSecHash [Main]");
		return TRUE;
	}
}


BOOL fGetSpreadSecDetails(struct INT_SPREAD_ORDERS *pRes)
{
	logTimestamp("Entry : [GetSpreadSecDetails]");
	struct          SPRD_SEC_MASTER_ARRAY        *pSec,*pHashAdd ;
	LONG32          i = 0 , n =0;
	CHAR            sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR            sTempSecID_L1[DB_SCRIP_CODE_LEN];
	CHAR            sTempSecID_L2[DB_SCRIP_CODE_LEN];
	CHAR            *sSelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	MYSQL           *DBConSec;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	logDebug1("DP : SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("DP : SCRIPT_CODE 1: %s",pRes->sSecId_L1);
	logDebug1("DP : SCRIPT_CODE 2: %s",pRes->sSecId_L2);

	pSec = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

	pHashAdd = (struct SPRD_SEC_MASTER_ARRAY  *)malloc(sizeof(struct SPRD_SEC_MASTER_ARRAY));

	strncpy(sTempSecID_L1,pRes->SpreadArray[0].sSecId,DB_SECURITY_ID_LEN);
	strncpy(sTempSecID_L1,pRes->SpreadArray[1].sSecId,DB_SECURITY_ID_LEN);

	logDebug2("sTempSecID_L1 :%s: sTempSecID_L2 :%s:",sTempSecID_L1,sTempSecID_L2);

	sprintf(sTempSecID,"%s%s",sTempSecID_L1,sTempSecID_L2);

	HASH_FIND(hDrvSecHndlr,HashSprDrvID, &sTempSecID,strlen(sTempSecID),pSec);

	logDebug2("pRes->iNoOfLeg %d ",pRes->iNoOfLeg);

	if(pSec != NULL)
	{

		for ( LONG32 iNoOfLegs  = 0 ; iNoOfLegs <  pRes->iNoOfLeg ; iNoOfLegs ++)
		{
			strncpy(pRes->SpreadArray[iNoOfLegs].sSymbol,pSec->SprdSecMstr[iNoOfLegs].sSymbol,SYMBOL_LEN);
			strncpy(pRes->SpreadArray[iNoOfLegs]sInstrumentType,pSec->SprdSecMstr[iNoOfLegs].sInsName,DB_INS_LEN);
			strncpy(pRes->SpreadArray[iNoOfLegs]sMaturityDay,pSec->SprdSecMstr[iNoOfLegs].sExpiryDate,MAT_DAY);	
			strncpy(pRes->SpreadArray[iNoOfLegs]sSecId,pSec->SprdSecMstr[iNoOfLegs].sScripCode,DB_SECURITY_ID_LEN);

			pRes->SpreadArray[iNoOfLegs]iMaturityDay = pSec->>SprdSecMstr[iNoOfLegs].iExpiryDate;

			logDebug2("pRes->SpreadArray[iNoOfLegs]sSymbol:%s:",pRes->SpreadArray[iNoOfLegs]sSymbol);
			logDebug2("pRes->SpreadArray[iNoOfLegs]sInstrumentType :%s:",pRes->SpreadArray[iNoOfLegs]sInstrumentType);
			logDebug2("pRes->SpreadArray[iNoOfLegs]sMaturityDay :%s: pRes->SpreadArray[iNoOfLegs]sMaturityDay :%s:",pRes->SpreadArray[iNoOfLegs]sMaturityDay,pRes->SpreadArray[iNoOfLegs]sMaturityDay);

		}
		else
		{
			DBConSec = DB_Connect();


			sprintf(sSelQuery,"SELECT SPD_TOKEN1,SPD_INSTRUNAME1 ,SPD_SYMBOL1 ,JULIDATE(SPD_EXPIRYDATE1),SPD_EXPIRYDATE1 ,SPD_TOKEN2,SPD_INSTRUNAME2,SPD_SYMBOL2,JULIDATE(SPD_EXPIRYDATE2),SPD_EXPIRYDATE2 ,SPD_REFERENCEPRICE ,SPD_UNDERLYING_SCRIPCODE ,SPD_UNDERLYING_SYM ,SPD_TRADING_SYM1 ,SPD_TRADING_SYM2 ,SPD_UNDERLAYIN_STATUS ,SPD_EXCH ,SPD_SEG   FROM SECURITY_MASTER_SPREAD WHERE SPD_SEG = \'%c\';",DERIVATIVE_SEGMENT);

			logDebug1("sSelQry :%s:",sSelQry);

			if(mysql_query(DBConSec,sSelQry) != SUCCESS)
			{
				logSqlFatal("Some thing wrong with sSelQuery query Pls check [fGetSpreadSecDetails]");
				sql_Error(DBConSec);
				mysql_close(DBConSec);
				return FALSE;
			}

			Res = mysql_store_result(DBConSec);
			if(Row = mysql_fetch_row(Res))
			{

				for (LONG32 i = 0; iRecord <= pOrd_Sprd_Rq->iNoOfLeg ; i++ )
				{
					//                       	strncpy(pHashAdd[i]->SprdSecMstr[i].sScripCode,Row[n],DB_SCRIP_CODE_LEN);
					strncpy(pHashAdd->SprdSecMstr[i].sInsName,Row[n+1],DB_INS_LEN);
					strncpy(pHashAdd[i]->SprdSecMstr[i].sSymbol,Row[n+2],SYMBOL_LEN);
					pHashAdd[i]->SprdSecMstr[i].iExpiryDate    = atoi(Row[n+3]);/*Julian Date */
					strncpy(pHashAdd[i]->SprdSecMstr[i].sExpiryDate,Row[n+4],15);
					n = 5;
				}

				DrvSprdSecHsh[i]->fReferencePrice       = atof(Row[10]);
				DrvSprdSecHsh[i]->iUnderlyingScripCode  = atoi(Row[11]);

				strncpy(DrvSprdSecHsh[i]->sUnderlyingSym,Row[12],45);
				strncpy(DrvSprdSecHsh[i]->sSpdTradingSym1,Row[13],50);
				strncpy(DrvSprdSecHsh[i]->sSpdTradingSym2,Row[14],50);

				DrvSprdSecHsh[i]->cUnderlyingStatus     = (Row[15][0]);
				strncpy(DrvSprdSecHsh[i]->sExch,Row[16],DB_EXCH_ID_LEN);
				DrvSprdSecHsh[i]->cSeg                  =  (Row[17][0]);
				HASH_ADD(hDrvSecHndlr,HashSprDrvID,sTempSecID,strlen(sTempSecID),pHashAdd);
				mysql_close(DBConSec);

			}
			else
			{
				logDebug1("Security ID is not in Hash & in DB :%s:",pHashAdd->sScripCode);
				mysql_close(DBConSec);
				return FALSE;
			}
		}
		logTimestamp("Exit : [GetSpreadSecDetails]");
		return TRUE;
	}
