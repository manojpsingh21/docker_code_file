#include <stdlib.h>
#include <string.h>
#include "IPCS.h"

void main()

{

	LONG32 ireq;
	LONG32  ireqID;

	logDebug3("\n1. NSE Equity UP\n");

	logDebug3("2. NSE Derrivative UP\n");

	logDebug3("3. NSE Currency UP\n");

	logDebug3("4. NSE Equity DOWN\n");

	logDebug3("5. NSE  Derrivative DOWN\n");

	logDebug3("6. NSE Currency DOWN\n");

	logDebug3("7. BSE Equity UP\n");

	logDebug3("8. BSE Equity DOWN\n");

	logDebug3("9. BSE Derivative UP\n");

	logDebug3("10. BSE Derivative DOWN\n");

	logDebug3("11. MCX Commodity UP\n");

	logDebug3("12. MCX Commodity DOWN\n");

        logDebug3("13. BSE Currency UP\n");

        logDebug3("14. BSE Currency DOWN\n");

	logDebug3("15. NSE Commodity UP\n");

	logDebug3("16. NSE Commodity DOWN\n");

	/*logDebug3("17. BSE Commodity UP\n");

	logDebug3("18. BSE Commodity DOWN\n");
	*/

	while (1)
	{

		scanf("%d",&ireq);
		logDebug3("\n :%d:",ireq);

		switch(ireq)
		{
			case 1:
				ireqID = NSE_EQU_UP;
		//		NotifyMonTool(TRUE);
				break;

			case 2:
				ireqID = NSE_DRV_UP;
				break;

			case 3:
				ireqID = NSE_CUR_UP;
				break;

			case 4:
				ireqID = NSE_EQU_DOWN;
				NotifyMonTool(FALSE);
				break;

			case 5:
				ireqID = NSE_DRV_DOWN;
				break;

			case 6:
				ireqID = NSE_CUR_DOWN;
				break;

			case 7:
				ireqID = BSE_EQU_UP;
				break;

			case 8:
				ireqID = BSE_EQU_DOWN;
				break;

			case 9:
				ireqID = BSE_DRV_UP;
				break;

			case 10:
				ireqID = BSE_DRV_DOWN;
				break;
			case 11:
				ireqID = MCX_UP;
				break;
			case 12:
				ireqID = MCX_DOWN;
				break;
                        case 13:
                                ireqID = BSE_CUR_UP;
                                break;
                        case 14:
                                ireqID = BSE_CUR_DOWN;
                                break;
			case 15:
				ireqID = NSE_CM_UP;
				break;
			case 16:
				ireqID = NSE_CM_DOWN;
				break;
/*			case 17:
				ireqID = BSE_CM_UP;
				break;
			case 18:
				ireqID = BSE_CM_DOWN;
				break;
*/
			default:

				logDebug2("\nWrong Choice");
				break;

		}
			logDebug2("ireqID :%d:",ireqID);
		fUpdateConnectStatus(ireqID,0);
	}

}

void NotifyMonTool(BOOL Status)
{

	CHAR sCmd[200];
	CHAR sCmd1[200];
	CHAR sCmd2[200];

	memset(sCmd,'\0',200);
	memset(sCmd,'\0',200);
	memset(sCmd2,'\0',200);

	sprintf(sCmd,"%s/ExchStats.py %s %c %s >> %s/log.ExchStats &",getenv("PYTHON_PATH"),NSE_EXCH,EQUITY_SEGMENT,Status==1?"UP":"DOWN",getenv("LOGDIR"));
	sprintf(sCmd1,"%s/ExchStats.py %s %c %s >> %s/log.ExchStats &",getenv("PYTHON_PATH"),BSE_EXCH,EQUITY_SEGMENT,Status==1?"UP":"DOWN",getenv("LOGDIR"));
	sprintf(sCmd2,"%s/ExchStats.py %s %c %s >> %s/log.ExchStats &",getenv("PYTHON_PATH"),MCX_EXCH,COMMODITY_SEGMENT,Status==1?"UP":"DOWN",getenv("LOGDIR"));

	logDebug2("Command -> %s",sCmd);
	logDebug2("Command -> %s",sCmd1);
	logDebug2("Command -> %s",sCmd2);

	system(sCmd);
	system(sCmd1);
	system(sCmd2);


}
