#include "IPCS.h"
#include "Defination.h"

BOOL 	fBasicValidation(struct INT_ORDERS *pReq)
{
	logTimestamp("Entry : [BasicValidation]");
	logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
	logDebug3("pReq->sClientId = %s",pReq->sClientId);
	logDebug2("pReq->sSecId= %s",pReq->sSecId);
	logDebug2("pReq->fOrderPrice= %lf",pReq->fOrderPrice);
	logDebug2("pReq->iTotalQty = %d",pReq->iTotalQty);
	logDebug2("pReq->cProductId = :%c:",pReq->cProductId);
	logDebug2("pReq->sPanNo = :%s:",pReq->sPanNo);
	logDebug2("pReq->iGrpId :%d:",pReq->iGrpId);
	logDebug2("GROUPID  :%d:",GROUPID);
	logDebug2("Req->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s: SRC_MOB :%s: ,SRC_WEB :%s:, SRC_ADM:%s:",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE,SRC_MOB,SRC_WEB,SRC_ADM);
        logDebug3("iOrderType   :%d:",pReq->iOrderType);
	logDebug3("iMktType	:%d:",pReq->iMktType);

	if(strlen(pReq->sEntityId) == 0){
		logFatal("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logFatal("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sSecId) == 0){
		logFatal("Invalid SecurityId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->fOrderPrice< 0){
		logFatal("Invalid Price.");
		return IBASIC_VALIDATION_FAILED;
	}
	//	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) != NULL) ||  (strchr(SRC_MOB,pReq->ReqHeader.cSource) != NULL) || (strchr(SRC_WEB,pReq->ReqHeader.cSource) != NULL))
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug2("pReq->ReqHeader.cSource :%c: ",pReq->ReqHeader.cSource);
		logFatal("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->iTotalQty<=0)
	{
		logFatal("Invalid Quantity");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strchr(RUPEE_PRODUCT,pReq->cProductId) == NULL)
	{
		logDebug2("Product Not Allow in System :%c:",pReq->cProductId);
		return	IBASIC_VALIDATION_FAILED;
	}
	else if (pReq->iGrpId != GROUPID)
	{
		logDebug2("Invalid Groupid :%d:",pReq->iGrpId);
		return	INVALID_GRP_ID;
	} 
	else if(pReq->iOrderType == ORD_TYPE_STOP_LIMIT )
	{
		if(pReq->cBuySellInd == INT_BUY)
		{
			if(pReq->fTriggerPrice > pReq->fOrderPrice)
			{
				logDebug2("Triggerprice Cannot Be Modified Below Main Order Price as Main Order is Sell");
				return IBASIC_VALIDATION_FAILED; 
			}
		}else if(pReq->cBuySellInd == INT_SELL)
		{
			if(pReq->fTriggerPrice < pReq->fOrderPrice)
			{
				logDebug2("Triggerprice Cannot Be Modified Above Main Order Price as Main Order is Buy");
				return IBASIC_VALIDATION_FAILED;
			}
		}
		
		
	} 
	else if(pReq->iMktType ==AUCTION_MARKET)
	{	
		if(pReq->iOrderType != ORD_TYPE_LIMIT)
		{
			logDebug2("Only Limit Orders are allowed in Auction Market");
			return IBASIC_VALIDATION_FAILED;
		}
		else if(pReq->ReqHeader.iMsgCode == TC_INT_ORDER_MODIFY)
                {
                        logDebug3("Auction Order can't be modified");
                        return BASIC_VALIDATION_FAILED;
                }
	}
	logTimestamp("Exit : [BasicValidation]");
	return TRUE;
}

BOOL    fCoBasicValidation (struct CO_ORDER_REQUEST *pReq)
{
	logTimestamp("Entry : [fCoBasicValidation]");
	logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
	logDebug3("pReq->sClientId = %s",pReq->sClientId);
	logDebug2("pReq->sSecurityId = %s",pReq->sSecurityId );
	logDebug2("pReq->fPrice = %lf",pReq->fPrice);
	logDebug2("pReq->ReqHeader.cSource = %c",pReq->ReqHeader.cSource);
	logDebug2("pReq->iTotalQty = %d",pReq->iTotalQty);
	logDebug2("pReq->cProductId = :%c:",pReq->cProductId);
	logDebug2("RUPEE_PRODUCT= :%s:",RUPEE_PRODUCT);
	logDebug2("GROUPID  :%d:",pReq->iGrpId);
	//	logDebug2("pReq->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s:",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE);
	logDebug2("Req->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s: SRC_MOB :%s: ,SRC_WEB :%s:, SRC_ADM:%s:",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE,SRC_MOB,SRC_WEB,SRC_ADM);

	logDebug2("pReq->ReqHeader.iMsgCode	:%d:",pReq->ReqHeader.iMsgCode);
	if(pReq->cProductId != PROD_COVER) 
	{
		logDebug2("Received Product Other Than CO 'V' :%c:",pReq->cProductId);
		return  IBASIC_VALIDATION_FAILED;
	}
	if(pReq->ReqHeader.iMsgCode == TC_INT_CO_ORDER_REQ)
	{
		if(pReq->CoArray[0].iLegValue != LEG_1)
		{
			logFatal("Leg 1 value  is Incorrect");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->CoArray[1].iLegValue != LEG_2)
		{
			logFatal("Leg 2 value  is Incorrect");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->CoArray[1].fTriggerPrice <= 0.00)
		{
			logFatal("TriggerPrice entered  is Incorrect for Leg 2");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->CoArray[0].cBuySellInd == INT_BUY)
		{	 
			if(pReq->CoArray[1].cBuySellInd != INT_SELL)
			{
				logFatal("Leg 2 BuySellInd is Incorrect");
				return IBASIC_VALIDATION_FAILED;
			}

		}
		else if(pReq->CoArray[0].cBuySellInd == INT_SELL)
		{
			if(pReq->CoArray[1].cBuySellInd != INT_BUY)
			{
				logFatal("Leg 2 BuySellInd is Incorrect");
				return IBASIC_VALIDATION_FAILED;
			}
		}

	}
	if(strlen(pReq->sEntityId) == 0){
		logFatal("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logFatal("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sSecurityId) == 0){
		logFatal("Invalid SecurityId.");
		return IBASIC_VALIDATION_FAILED;
	}

	else if((pReq->fPrice < 0.00 && pReq->CoArray[0].iLegValue == LEG_1) && (pReq->cProductId == PROD_COVER)){
		logFatal("Invalid Price.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug3("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}

	//	else if(strchr(RUPEE_PRODUCT,pReq->cProductId) == NULL)
	/*	else if(strchr(PROD_COVER,pReq->cProductId) == NULL)
		{
		logDebug2("Received Product Other Than CO 'V' :%c:",pReq->cProductId);
		return  IBASIC_VALIDATION_FAILED;
		}*/
	else if(pReq->iTotalQty<=0)
	{
		logFatal("Invalid Quantity");
		return IBASIC_VALIDATION_FAILED;
	}
	else if (pReq->iGrpId != GROUPID)
        {
                logDebug2("Invalid Groupid :%d:",pReq->iGrpId);
                return  INVALID_GRP_ID;
        }

	else{
		logTimestamp("Exit : [fCoBasicValidation]");
		return TRUE;
	}
}

BOOL    fBoBasicValidation (struct BO_ORDER_REQUEST *pReq)
{
	logTimestamp("Entry : [fBoBasicValidation]");
	DOUBLE64 ret = 0.00 ;
	logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
	logDebug3("pReq->sClientId = %s",pReq->sClientId);
	logDebug2("pReq->sSecurityId = %s",pReq->sSecurityId );
	logDebug2("pReq->fPrice = %lf",pReq->fPrice);
	logDebug2("pReq->ReqHeader.cSource = %c",pReq->ReqHeader.cSource);
	logDebug2("pReq->iTotalQty = %d",pReq->iTotalQty);
	logDebug2("pReq->cProductId = :%c:",pReq->cProductId);
	logDebug2("pReq->iOrderType= :%d:",pReq->iOrderType);	
	logDebug2("pReq->fSLTikAbsValue	:%f:",pReq->fSLTikAbsValue);
	logDebug2("pReq->fPBTikAbsValue	:%f:",pReq->fPBTikAbsValue);
	logDebug2("pReq->BoArray[0].iLegValue :%d:",pReq->BoArray[0].iLegValue);
	logDebug2("pReq->fOrderNum	:%lf:",pReq->fOrderNum);
	logDebug2("Req->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s: SRC_MOB :%s: ,SRC_WEB :%s:, SRC_ADM:%s: SRC_SYS:%s: ",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE,SRC_MOB,SRC_WEB,SRC_ADM,SRC_SYS);

	logDebug2("pReq->ReqHeader.iMsgCode     :%d:",pReq->ReqHeader.iMsgCode);
	if(pReq->cProductId != PROD_BRACKET)
	{
		logDebug2("Received Product Other Than BO 'B' :%c:",pReq->cProductId);
		return  IBASIC_VALIDATION_FAILED;
	}

	if(pReq->ReqHeader.iMsgCode == TC_INT_BO_ORDER_REQ)
	{
		if(pReq->BoArray[0].iLegValue != LEG_1)
		{
			logFatal("Leg 1 value  is Incorrect");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->BoArray[1].iLegValue != LEG_2)
		{
			logFatal("Leg 2 value  is Incorrect");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->BoArray[2].iLegValue != LEG_3)
		{
			logFatal("Leg 3 value  is Incorrect");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->fSLTikAbsValue <= 0.00)
		{
			logFatal("Stop loss difference value entered is incorrect");
                     	return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->fPBTikAbsValue<= 0.00)
                {
                        logFatal("Profit  difference value entered is incorrect");
                        return IBASIC_VALIDATION_FAILED;
                }
/*
		if(pReq->fSLTikAbsValue > 0.00)
		{
			ret = pReq->fSLTikAbsValue / TICK_SIZE_VAL ;
			if (ret-(LONG32)ret == 0)
			{	
				logDebug2("Entered value is in multiple of tick size for stop loss ");
			}
			else
			{
				logFatal("Stop loss difference value entered is not in multiple of tick size:%f:",ret );
				return IBASIC_VALIDATION_FAILED;
			}
		}
		else
		{
			logFatal("Stop loss difference value entered is less than 0.00");
			return IBASIC_VALIDATION_FAILED;
		}
		if(pReq->fPBTikAbsValue > 0.00)
		{
			ret = 0.00 ;
			ret = pReq->fPBTikAbsValue/ TICK_SIZE_VAL ;
			if (ret-(LONG32)ret == 0)
			{
				logDebug2("Entered value is in multiple of tick size for Profit booking");
			}
			else
			{
				logFatal("Profit booking difference value entered is not in multiple of tick size :%f:",ret);
				return IBASIC_VALIDATION_FAILED;
			}

		}
		else
                {
                        logFatal("Stop loss difference value entered is less than 0.00");
                        return IBASIC_VALIDATION_FAILED;
                }
*/
		if(pReq->BoArray[0].cBuySellInd == INT_BUY)
		{
			if(pReq->BoArray[1].cBuySellInd != INT_SELL && pReq->BoArray[2].cBuySellInd != INT_SELL)
			{
				logFatal("Leg 2 & Leg 3  BuySellInd is Incorrect");
				return IBASIC_VALIDATION_FAILED;
			}

		}
		else if(pReq->BoArray[0].cBuySellInd == INT_SELL)
		{
			if(pReq->BoArray[1].cBuySellInd != INT_BUY && pReq->BoArray[2].cBuySellInd != INT_BUY)
			{
				logFatal("Leg 2  & Leg 3 BuySellInd is Incorrect");
				return IBASIC_VALIDATION_FAILED;
			}
		}

	}
	if(strlen(pReq->sEntityId) == 0){
		logDebug3("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logDebug3("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sSecurityId) == 0){
		logDebug3("Invalid SecurityId.");
		return IBASIC_VALIDATION_FAILED;
	}
	/*else if (pReq->cFlag != 'M')*this check is regarding Leg 2 getting rejected from exchange and whilw leg 3 getting modified at market it stops here as market order not allowed for leg 3 *
	{
		if (pReq->cProductId == PROD_BRACKET && pReq->fPrice == 0.00 && pReq->BoArray[0].fTriggerPrice == 0.00 && pReq->BoArray[0].iLegValue != LEG_2)
		{
			logDebug2("Market Order is Not allowed in Bracket Order");
			return  IBASIC_VALIDATION_FAILED;
		}
	}*/
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_SYS,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug3("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->iTotalQty<=0)
	{
		logDebug3("Invalid Quantity");
		return IBASIC_VALIDATION_FAILED;
	}
	else if (pReq->iGrpId != GROUPID)
        {
                logDebug2("Invalid Groupid :%d:",pReq->iGrpId);
                return  INVALID_GRP_ID;
        }

/**
	else if(pReq->iOrderType != ORD_TYPE_LIMIT) 
	{
                logDebug3("Invalid Order Type");
                return IBASIC_VALIDATION_FAILED;
        }
**/

	logTimestamp("Exit : [fBoBasicValidation]");
	return TRUE;
}



BOOL	fSIPBasicValidation(struct SIP_INT_ORDERS *pReq)
{
	logTimestamp("Entry : [SIPBasicValidation]");
	logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
	logDebug3("pReq->sClientId = %s",pReq->sClientId);
	logDebug2("pReq->sSecId = %s",pReq->sSecId);
	logDebug2("pReq->fOrderPrice = %lf",pReq->fOrderPrice);
	logDebug2("pReq->ReqHeader.cSource = %c",pReq->ReqHeader.cSource);
	logDebug2("pReq->iTotalQty = %d",pReq->iTotalQty);

	if(strlen(pReq->sEntityId) == 0){
		logDebug3("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logDebug3("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sSecId) == 0){
		logDebug3("Invalid SecurityId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->fOrderPrice < 0){
		logDebug3("Invalid Price.");
		return IBASIC_VALIDATION_FAILED;
	}
	/*	else if(strchr(SRC_EXE,pReq->ReqHeader.cSource) != NULL && strchr(SRC_MOB,pReq->ReqHeader.cSource) != NULL && strchr(SRC_WEB,pReq->ReqHeader.cSource) != NULL)
		{
		logDebug3("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
		} */
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug3("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->iTotalQty < 0)
	{
		logDebug3("Invalid Quantity");
		return IBASIC_VALIDATION_FAILED;
	}
	else
	{
		logTimestamp("Exit : [SIPBasicValidation]");
		return TRUE;
	}
}

/*(G*/
BOOL 	fBasicSprdValidation(struct ORDER_SPREAD_REQUEST *pReq)
{
	logTimestamp("Entry : [BasicSprdValidation]");

	if(strlen(pReq->sEntityId) == 0){
		logDebug3("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logDebug3("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}

	else if(strlen(pReq->sSpreadLeg[0].sSecurityId) == 0){
		logDebug3("Invalid SecurityId 1.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sSpreadLeg[1].sSecurityId) == 0){
		logDebug3("Invalid SecurityId 2.");
		return IBASIC_VALIDATION_FAILED;
	}
	/*  	else if(strchr(SRC_EXE,pReq->ReqHeader.cSource) == NULL && strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL && strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL)
		{
		logDebug3("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
		} */
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug3("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->sSpreadLeg[0].iTotalQty<=0)
	{
		logDebug3("Invalid Quantity leg 1");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->sSpreadLeg[1].iTotalQty<=0)
        {
                logDebug3("Invalid Quantity leg 2");
                return IBASIC_VALIDATION_FAILED;
        }
	else{
		logTimestamp("Exit : [BasicSprdValidation]");
		return TRUE;
	}
}

BOOL fOffOrdsBasicValidation (struct INT_ORDERS *pReq)
{
	logTimestamp("Entry : [fOffOrdsBasicValidation]");
	logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
	logDebug3("pReq->sClientId = %s",pReq->sClientId);
	logDebug2("pReq->sSecId= %s",pReq->sSecId);
	logDebug2("pReq->fOrderPrice= %lf",pReq->fOrderPrice);
	logDebug2("pReq->iTotalQty = %d",pReq->iTotalQty);
	logDebug2(" pReq->cProductId = :%c:",pReq->cProductId);
	logDebug2("Req->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s: SRC_MOB :%s: ,SRC_WEB :%s:, SRC_ADM:%s:",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE,SRC_MOB,SRC_WEB,SRC_ADM);

	if(pReq->cProductId == PROD_COVER || pReq->cProductId == PROD_BRACKET)
	{
		logDebug2("Order not allowed for the  Product :%c:",pReq->cProductId);
		return  IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sEntityId) == 0){
		logFatal("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logFatal("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sSecId) == 0){
		logFatal("Invalid SecurityId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->fOrderPrice< 0){
		logFatal("Invalid Price.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug2("pReq->ReqHeader.cSource :%c: ",pReq->ReqHeader.cSource);
		logFatal("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->iTotalQty<=0)
	{
		logFatal("Invalid Quantity");
		return IBASIC_VALIDATION_FAILED;
	}
	else if(pReq->cProductId == PROD_COVER)
	{
		logDebug2("Order not allowed for the  Product :%c:",pReq->cProductId);
		return  IBASIC_VALIDATION_FAILED;
	}
	else{
		logTimestamp("Exit : [fOffOrdsBasicValidation]");
		return TRUE;
	}
}




BOOL fBasicMulLegValidation(struct INT_MUL_LEG_ORDERS *pReq)
{
	LONG32	Count =0;
	logTimestamp("Entry : [fBasicMulLegValidation]");
	logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
	logDebug3("pReq->sClientId = %s",pReq->sClientId);
	logDebug2(" pReq->cProductId = :%c:",pReq->cProductId);
	logDebug2("Req->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s: SRC_MOB :%s: ,SRC_WEB :%s:, SRC_ADM:%s:",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE,SRC_MOB,SRC_WEB,SRC_ADM);

	if(pReq->cProductId == PROD_COVER || pReq->cProductId == PROD_BRACKET)
	{
		logDebug2("Order not allowed for the  Product :%c:",pReq->cProductId);
		return  IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sEntityId) == 0){
		logFatal("Invalid EntityId. :%s:",pReq->sEntityId);
		return IBASIC_VALIDATION_FAILED;
	}
	else if(strlen(pReq->sClientId) == 0){
		logFatal("Invalid ClientId.");
		return IBASIC_VALIDATION_FAILED;
	}
	else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
	{
		logDebug2("pReq->ReqHeader.cSource :%c: ",pReq->ReqHeader.cSource);
		logFatal("Invalid SourceFlag.");
		return IBASIC_VALIDATION_FAILED;
	}
	for(Count = 0 ; Count < pReq->iNoOfLeg; Count++)
	{	
		logDebug2("pReq->SecDetails[%d].iTotalQty = %d",Count,pReq->SecDetails[Count].iTotalQty);
		logDebug2("pReq->SecDetails[%d].fOrderPrice = %lf",Count,pReq->SecDetails[Count].fOrderPrice);
		logDebug2("pReq->SecDetails[%d].sSecId = %s",Count,pReq->SecDetails[Count].sSecId);
		if(pReq->SecDetails[Count].iTotalQty<=0)
		{
			logFatal("Invalid Quantity");
			return IBASIC_VALIDATION_FAILED;
		}
		else if(pReq->SecDetails[Count].fOrderPrice< 0){
			logFatal("Invalid Price.");
			return IBASIC_VALIDATION_FAILED;
		}
		else if(strlen(pReq->SecDetails[Count].sSecId) == 0){
			logFatal("Invalid SecurityId.");
			return IBASIC_VALIDATION_FAILED;
		}
	}
	logTimestamp("Exit : [fBasicMulLegValidation]");
	return TRUE;
}
/**/



BOOL    fSIPPumpValidation(struct ORDER_REQUEST *pReq)
{
        logTimestamp("Entry : [fSIPPumpValidation]");
        logDebug2("pReq->iTotalQty = %d",pReq->iTotalQty);

        if(pReq->iTotalQty <= 0)
        {
                logDebug3("Invalid Quantity");
                return FALSE;
        }
        else
        {
                logTimestamp("Exit : [fSIPPumpValidation]");
                return TRUE;
        }
}


BOOL    fGTTBasicValidation(struct FOREVER_ORDER_REQUEST *pReq)
{
        logTimestamp("Entry : [fGTTBasicValidation]");
        logDebug2("pReq->sEntityId = %s",pReq->sEntityId);
        logDebug3("pReq->sClientId = %s",pReq->sClientId);
        logDebug2("pReq->sSecurityId = %s",pReq->sSecurityId );
        logDebug2("pReq->fPrice = %lf",pReq->CoArray[0].fPrice);
        logDebug2("pReq->ReqHeader.cSource = %c",pReq->ReqHeader.cSource);
        logDebug2("pReq->iTotalQty = %d",pReq->CoArray[0].iTotalQty);
        logDebug2("pReq->cProductId = :%c:",pReq->cProductId);
        logDebug2("RUPEE_PRODUCT= :%s:",RUPEE_PRODUCT);
        logDebug2("Req->ReqHeader.cSource = %c  RUPEE_SOURCE_EXE :%s: SRC_MOB :%s: ,SRC_WEB :%s:, SRC_ADM:%s:",pReq->ReqHeader.cSource,RUPEE_SOURCE_EXE,SRC_MOB,SRC_WEB,SRC_ADM);

	logDebug2("pReq->fOrderTriggerPrice = %lf",pReq->CoArray[0].fOrdTriggerPrice);
	logDebug2("pReq->iOrderType = %d",pReq->iOrderType);

        logDebug2("pReq->ReqHeader.iMsgCode     :%d:",pReq->ReqHeader.iMsgCode);
        if(pReq->cProCli == '\0' )
        {
                logDebug2("Received cProCli is blank from the Front End");
                return BASIC_VALIDATION_FAILED;
        }
        if(pReq->CoArray[0].iTotalQty<=0)
        {
                logFatal("Invalid Quantity");
                return BASIC_VALIDATION_FAILED;
        }
        if(strlen(pReq->sEntityId) == 0){
                logFatal("Invalid EntityId. :%s:",pReq->sEntityId);
                return BASIC_VALIDATION_FAILED;
        }
        else if(strlen(pReq->sClientId) == 0){
                logFatal("Invalid ClientId.");
                return BASIC_VALIDATION_FAILED;
        }
        else if(strlen(pReq->sSecurityId) == 0){
                logFatal("Invalid SecurityId.");
                return BASIC_VALIDATION_FAILED;
        }
        else if((strchr(RUPEE_SOURCE_EXE,pReq->ReqHeader.cSource) == NULL) &&  (strchr(SRC_MOB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_WEB,pReq->ReqHeader.cSource) == NULL) && (strchr(SRC_ADM,pReq->ReqHeader.cSource) == NULL))
        {
                logDebug3("Invalid SourceFlag.");
                return BASIC_VALIDATION_FAILED;
        }
	else if ((pReq->iOrderType == ORD_TYPE_STOP_LOSS_MKT || pReq->iOrderType == ORD_TYPE_STOP_LIMIT) && (pReq->cGttType == GTT_ORDER))
	{
		if(pReq->CoArray[0].fOrdTriggerPrice == 0.00 )
		{
				
			logDebug3("Order trigger price cannot be zero as this is SL or SLM order.");
	                return BASIC_VALIDATION_FAILED;
	
		}
		else if((pReq->cBuySellInd == INT_BUY && pReq->iOrderType == ORD_TYPE_STOP_LIMIT) && (pReq->CoArray[0].fOrdTriggerPrice > pReq->CoArray[0].fPrice )) 
		{
			logDebug3("Order trigger price cannot be greater then Order Price as this is SL order.");
			return BASIC_VALIDATION_FAILED;
		}
		else if((pReq->cBuySellInd == INT_SELL && pReq->iOrderType == ORD_TYPE_STOP_LIMIT) && (pReq->CoArray[0].fOrdTriggerPrice < pReq->CoArray[0].fPrice ))
                {
                        logDebug3("Order trigger price cannot be less then Order Price as this is SL order.");
                        return BASIC_VALIDATION_FAILED;
                }
	}
	
	logTimestamp("Exit : [fGTTBasicValidation]");
	return TRUE;
}
