files=`find $1 -type f`
for file in $files
do
echo $file
vim -e -s -n "+normal gg=GZZ" $file
done
