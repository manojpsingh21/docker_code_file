
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include <stdio.h>
#include "IPCS.h"

#include "FIXStructures.h"
#define FIX_TAG_DELIMITER '='
#define FIX_FIELD_DELIMITER     '~'

MYSQL    *DB_Conn;

CHAR *GetMessageType(FIX_Msg *msg , CHAR *sErrString);
void main(int argc, char *argv[])
{
	logTimestamp("Entry To main");

	CHAR *sSelQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	sProcCall[MAX_QUERY_SIZE];
	memset(sProcCall,'\0',MAX_QUERY_SIZE);
	CHAR	sSelRes[MAX_QUERY_SIZE];
	memset(sSelRes,'\0',MAX_QUERY_SIZE);
	INT16	iStatus,iError;
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;
	CHAR	sErrCode[10];
	memset(sErrCode,'\0',10);
	CHAR	sErrVal[200];
	memset(sErrVal,'\0',200);
	CHAR	sErrString[DB_REASON_DESC_LEN];
	memset(sErrString,'\0',DB_REASON_DESC_LEN);
	CHAR	*sOutErrStrg;
	FIX_Msg msg;
		

	DB_Conn = DB_Connect();
	if(DB_Conn == NULL)
	{
		logDebug3("Databse Connection is UP");
	}
	else
	{
		logDebug3("Databse Connection is  DOWn");
	}	
	

	sprintf(sProcCall,"CALL PR_ERR_STRNG_TEST(@A,@B,@C);SELECT @A,@B,@C");
	
	logDebug2("sProcCall :%s:",sProcCall);
	
	if(mysql_query(DB_Conn,sProcCall) != SUCCESS)
        {
                sql_Error(DB_Conn);
                iError  = mysql_errno(DB_Conn);
                logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
                return ERROR;
        }
	

	do{

                Res = mysql_store_result(DB_Conn);
                if(Res)
                {
                        if((Row = mysql_fetch_row(Res)))
                        {
				strncpy(sErrCode,Row[0],10);
				strncpy(sErrVal,Row[2],200);
				logDebug2("sErrVal :%s:",sErrVal);
                                mysql_free_result(Res);

                        }
                }
                else
                {
                        logDebug2("No Result Set ");
                }

                if((iStatus =mysql_next_result(DB_Conn)) > 0)
                {
                        logDebug3("Could not execute statement :%d:",iStatus);
                }

                logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DB_Conn));

        }while(iStatus == 0);

	
	sprintf(sSelRes,"SELECT RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = \"%s\"; ",sErrCode);	
	
	if(mysql_query(DB_Conn,sSelRes) != SUCCESS)
        {
                sql_Error(DB_Conn);
                iError  = mysql_errno(DB_Conn);
                logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
                return ERROR;
        }

	Res = mysql_store_result(DB_Conn);
	
	if((Row = mysql_fetch_row(Res)))
        {
		strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);	
		logDebug2(" Row :%s:",Row[0]);
		mysql_free_result(Res);
	
	}		

	FIXParse(&msg,&sErrVal,strlen(sErrVal));
        sOutErrStrg = GetMessageType( &msg,&sErrString) ;

	printf("\n sOutErrStrg :%s:",sOutErrStrg);		

	mysql_close(DB_Conn);

}


LONG32 FIXParse(FIX_Msg* msg, const char* buffer, int len)
{
        printf("\nEntry : [FIXParse]");

        int nullValue = FALSE;
        int n         = 0;
        char c        = 0;
        char* src     = NULL;
        char* dst     = NULL;

        if(msg == NULL)
        {
                printf("\n Cannot Parse: msg NULL");
                return FALSE;
        }

        printf("Buffer :%s:",buffer);

        memcpy(msg->inputmsg, buffer, len);
        msg->length = len;
        msg->inputmsg[len] = 0;

        msg->numtags = 0;
        msg->inputmsg[msg->length] = 0;

        src = msg->inputmsg;
        dst = msg->buf;
        msg->tags[n] = dst;

        while ( FIXGetNextTag(& src, & dst) )
        {
                /***** logDebug3("Tag[%s]", msg->tags[n]); *****/
                msg->values[n] = dst;

                if (! FIXGetNextValue(& src, & dst) )
                        return FALSE;

                /***** logDebug3("Value[%s]", msg->values[n]); *****/

                ++n;
                msg->tags[n] = dst;
        }
        msg->numtags = n;
        printf("\n Number of Tags = %d", msg->numtags);


        printf("\nExit : [FIXParse > TRUE]");
        return TRUE;
}



LONG32 GetMessageTypeFromString(const char *string, char *result)
{
        printf("\nEntry : [GetMessageTypeFromString]");

        char *messageTypeTagStart, *messageTypeValueStart;
        int index = 0;
        messageTypeTagStart = strstr(string,"\00135=");
        if (messageTypeTagStart == NULL)
        {
                return FALSE;
        }
        messageTypeValueStart = messageTypeTagStart + 4;
        while (messageTypeValueStart[index] != FIX_FIELD_DELIMITER)
        {
                if( messageTypeValueStart[index] == FIX_MESSAGE_DELIMITER
                                || messageTypeValueStart[index] == '\0' )
                {
                        return FALSE;
                }
                result[index] = messageTypeValueStart[index];
                index ++;
        }
        if(index == 0)
        {
                printf("\nEntry : [GetMessageTypeFromString > FALSE]");
                return FALSE;
        }
        result[index] = '\0';
        printf("\nEntry : [GetMessageTypeFromString > TRUE]");
        return TRUE;
}
static LONG32 FIXGetNextTag(char** src, char** dst)
{
        printf("\nEntry : [FIXGetNextTag]");

        LONG32 rc = TRUE;
        char c     = 0;
        char* sptr = *src;
        char* dptr = *dst;


        while (TRUE)
        {
                c = *sptr++;

                /****
 *                   if ( isalpha(c))
 *                                     {
 *                                                       logDebug1("Invalid character in tag. '%c'", c);
 *                                                                         return FALSE;
 *                                                                                           }
 *                                                                                                            ****/
                if (c == 0)
                {
                        *sptr--;
                        *dptr++ = 0;
                        rc = 0;
                        break;
                }

                if (c == FIX_TAG_DELIMITER)
                {
                        *dptr++ = 0;
                        break;
                }

                *dptr++ = c;
        }
        printf("\n sptr :%s: dptr :%s:",sptr,dptr);

        *src = sptr;
        *dst = dptr;
        printf("\nExit : [FIXGetNextTag]");
        return rc;
}
static LONG32 FIXGetNextValue(char** src, char** dst)
{
        printf("\nEntry : [FIXGetNextValue]");

        char c     = 0;
        char* sptr = *src;
        char* dptr = *dst;
        while (TRUE)
        {
                c = *sptr++;

                if (c == FIX_FIELD_DELIMITER)
                {
                        *dptr++ = 0;
                        break;
                }
                if (c == 0)
                {
                        *dptr++ = 0;
                        *sptr--;
                        break;
                }
                /***
 *                   if (c == FIX_ESCAPE)
 *                                     {
 *                                                       c = *sptr++;
 *                                                                         }
 *                                                                                          ***/

                *dptr++ = c;
        }

        *src = sptr;
        *dst = dptr;
        printf("\nExit : [FIXGetNextValue > TRUE]");
        return TRUE;
}

BOOL formRejectString(CHAR *sIStr, CHAR *sOStr)
{
        printf("\nEntry : [formRejectString]");

        CHAR *token;

        CHAR    *Tokens_ap[FIX_MAX_TAGS];
        CHAR    *InputStrng;
        LONG32  iNoOfTokens=0;
        LONG32  init,end ,jcnt;
        LONG32  iRetval;
        LONG32  iCount;
        LONG32  iTag;
        CHAR    sMsgType[MESSAGE_TYPE_LEN];
        CHAR    sClOrdId[CLORDID_LEN];
        CHAR    cValue[MAX_TEXT_LEN];
        CHAR    sBeginStr[ENV_VARIABLE_LEN];
        CHAR    sSenderId[ENV_VARIABLE_LEN];
        CHAR    sTargetId[ENV_VARIABLE_LEN];
        CHAR    *sErrorMessage = "Application Not Available.";
        CHAR    *sStr = strdup(sIStr);
        BOOL    ChkFlag = FALSE;


        InputStrng = (char *) malloc(sizeof(char) * FIX_MAX_STRING_LEN);
        memset(InputStrng,'\0',FIX_MAX_STRING_LEN);
        memcpy(InputStrng,sIStr,strlen(sIStr));

        iNoOfTokens =   0;
        init    =       0;
        end     =       0;

        for(jcnt=0;jcnt<strlen(InputStrng);jcnt++)
        {

                if(InputStrng[jcnt] == 1 )
                {

                        end     =   jcnt;
                        if(iNoOfTokens  != 0)
                        {
                                Tokens_ap[iNoOfTokens]  = (CHAR*)malloc(sizeof(CHAR)*(end-init+1));
                                if(Tokens_ap[iNoOfTokens]   ==  NULL)
                                        memset(Tokens_ap[iNoOfTokens],'\0',end-init+1);
                                memcpy(Tokens_ap[iNoOfTokens],&InputStrng[init],end-init);
                        }
                        iNoOfTokens++;

                        init    =   jcnt+1;
                }
        }

        free(InputStrng);

        for(iRetval=TRUE,iCount=1;iCount<iNoOfTokens;iCount++)
        {
                memset(cValue,'\0',FIX_MAX_VALUE_LEN);
                sscanf(Tokens_ap[iCount],"%d=%[ -~]s",&iTag,cValue);
                printf("\n Token [%d] = %d=%s",iCount,iTag,cValue);

                switch(iTag)
                {
                        case 35:
                                memset(sMsgType,'\0',MESSAGE_TYPE_LEN);
                                strncpy(sMsgType,cValue,strlen(cValue));
                                break ;

                        case 11:
                                memset(sClOrdId,'\0',CLORDID_LEN);
                                strncpy(sClOrdId,cValue,strlen(cValue));
                                ChkFlag = TRUE;
                                break;

                        case 49:
                                break;
                        case 56:
                                break;
                }
        }




        if(ChkFlag == FALSE)
        {
                return FALSE;
        }
        else{
                sprintf(sOStr,"8=%s%c9=42%c35=j%c49=%s%c56=%s%c34=1%c58=%s%c11=%s%c380=0%c45=1%c",sBeginStr,\
                                FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,sTargetId,FIX_FIELD_DELIMITER,\
                                sSenderId,FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,sErrorMessage,FIX_FIELD_DELIMITER,sClOrdId,\
                                FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER, sClOrdId,FIX_FIELD_DELIMITER,FIX_FIELD_DELIMITER,\
                                FIX_FIELD_DELIMITER);
                return TRUE;
        }
}

char *str_replace(char* search, char* replace, char* subject)
{
        int i, j, k;

        int searchSize = strlen(search);
        int replaceSize = strlen(replace);
        int size = strlen(subject);

        char* ret;

        if (!searchSize) {
                ret = malloc(size + 1);
                for (i = 0; i <= size; i++) {
                        ret[i] = subject[i];
                }
                return ret;
        }

        int retAllocSize = (strlen(subject) + 1) * 2;

        ret = malloc(retAllocSize);

        int bufferSize = 0;

        char* foundBuffer = malloc(searchSize);

        for (i = 0, j = 0; i <= size; i++) 
	{
		if (retAllocSize <= j + replaceSize) {
                        retAllocSize *= 2;
                        ret = (char*) realloc(ret, retAllocSize);
                }
                else if (subject[i] == search[bufferSize]) {
                        foundBuffer[bufferSize] = subject[i];
                        bufferSize++;
                        if (bufferSize == searchSize) {
                                bufferSize = 0;
                                for (k = 0; k < replaceSize; k++) {
                                        ret[j++] = replace[k];
                                }
                        }
                }
                else {
                        for (k = 0; k < bufferSize; k++) {
                                ret[j++] = foundBuffer[k];
                        }
                        bufferSize = 0;
                ret[j++] = subject[i];
                }
        }

        free(foundBuffer);
	subject = ret;
        return ret;
}	

CHAR *GetMessageType(FIX_Msg *msg , CHAR *sErrString)
{
        printf("\nEntry : [GetMessageType]");
        char    sTagReplace[FIX_MAX_TAGS];
        char    *new;

        int i;
        for(i=0; i < msg->numtags ; i++)
        {
                memset(sTagReplace,'\0',FIX_MAX_TAGS);
                printf("\n msg->tags[%d]  :%s: msg->values[%d] :%s:",i,msg->tags[i],i,msg->values[i]);
                sprintf(sTagReplace,"^%s",msg->tags[i]);
                sErrString = str_replace(&sTagReplace,msg->values[i],sErrString);


        }
	printf("\nsErrString :%s:",sErrString);
        printf("\nExit : [GetMessageType ]");
        return sErrString;
}
