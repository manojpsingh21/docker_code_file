#include <stdlib.h>
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>

MYSQL	*DBConNEQ;
LONG32	iRelToOrdRtr;


main(int argc,char *argv[])
{
	logTimestamp("Entry : [main]");

	/***** -=Connect to DATABASE=- *****/
	DBConNEQ = DB_Connect();
	/***** -=DATABASE Connected=- *****/
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);
	OpenMsgQue();	
	ProcessMTM();

}

void	ProcessMTM()
{

}


void	OpenMsgQue()
{
	logTimestamp("Entry : [OpenMsgQue]");

	if((iRelToOrdRtr = OpenMsgQ(RelToOrdRtr)) == ERROR)
	{
		logFatal("OpenMsgQ ...RelToOrdRtr");
		exit(ERROR);
	}
	logInfo("RelToOrdRtr opened successfully with id = %d", iRelToOrdRtr);

}
