# include    <stdio.h>
# include    <stdlib.h>
# include    <sys/msg.h>
# include    <sys/ipc.h>
# include    "IPCS.h"

main()
{
	logTimestamp("Entry : [main]");

	logInfo("\n -------------------------- Creating Queues ------------------------------\n");

	if (CreateMsgQueue( ENBAdapToSpltr , ENBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("ENBAdapToSpltr failed : ");
		exit(1);
	}
	logInfo("1. ENBAdapToSpltr : ");

	if (CreateMsgQueue( ENBSpltrToMbpUpld , ENBSpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("ENBSpltrToMbpUpld failed : ");
		exit(1);
	}
	logInfo("2. ENBSpltrToMbpUpld : ");

	if (CreateMsgQueue( ENBSpltrToIndxUpld , ENBSpltrToIndxUpld_SIZE) == ERROR )
	{
		logFatal("ENBSpltrToIndxUpld failed : ");
		exit(1);
	}
	logInfo("3. ENBSpltrToIndxUpld : ");

	if (CreateMsgQueue( ENBSpltrToMStatUpld , ENBSpltrToMStatUpld_SIZE) == ERROR )
	{
		logFatal("ENBSpltrToMStatUpld failed : ");
		exit(1);
	}
	logInfo("4. ENBSpltrToMStatUpld : ");

	logInfo("\n -------------------------- END Creating Queues ------------------------------\n");


	logTimestamp("Exit : [main]");
	exit(0);

}
