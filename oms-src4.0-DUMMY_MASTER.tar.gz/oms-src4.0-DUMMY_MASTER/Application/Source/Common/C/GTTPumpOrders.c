#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"


LONG32 iOrdRtrToGTTOrd;

MYSQL *OdrConn;

main()//int argc, char argv[])
{

	int ich,rw;
	char statement[5000];
	double fOrderNum;
	double fStart;
	double fEnd;
	int iLegVal = 0;
	int iSerialNum;
	int  iMsgcode;
	int  k = 0 ,ival =0 ;
	int  iEntity ;
	int iQty ;

	char bs = 'B';
	char GTTType = 'G';
	double fPrice;
	double fTriggerPrice;
	double fOrdTriggerPrice;
	OdrConn=DB_Connect();
	MYSQL_RES *result;
	MYSQL_ROW row;

	logDebug2("\n 3");

	struct FOREVER_ORDER_REQUEST pOrdReq;

	memset(&pOrdReq,'\0',sizeof(struct FOREVER_ORDER_REQUEST));

	if((iOrdRtrToGTTOrd= OpenMsgQ(OrdRtrToGTTOrd)) == ERROR)
	{
		perror("OpenMsgQ ...iOrdRtrToGTTOrd");
		exit(ERROR);
	}
	logDebug2(" iOrdRtrToGTTOrd opened successfully with id = %d", iOrdRtrToGTTOrd);

	logDebug2("ENTER THE MESSAGE TYPE\n");

	logDebug2(" 1.New Cover Order Entery ");
	logDebug2(" 2.Modify the Entry");
	logDebug2(" 3.Exit the Entry \n");
	logDebug2("->");

	scanf("%d",&ich);

	if(ich==1)
		pOrdReq.ReqHeader.iMsgCode= TC_INT_GTT_ORDER_ENTRY;
	else if(ich==2)
		pOrdReq.ReqHeader.iMsgCode= TC_INT_GTT_ORDER_MODIFY;
	else if(ich==3)
		pOrdReq.ReqHeader.iMsgCode= TC_INT_GTT_ORDER_CANCEL;
	else
		logDebug2("Invalid Input");

	switch(pOrdReq.ReqHeader.iMsgCode)
	{
		case  TC_INT_GTT_ORDER_ENTRY:

			logDebug2("Enter Buy or Sell ");
			logDebug2(" B.Buy ");
			logDebug2(" S.Sell");
			logDebug2("\n ->");
			scanf(" %c",&bs);
			logDebug2("Enter GTT or OCO ");
			logDebug2(" G.GTT ");
			logDebug2(" O.OCO");
			logDebug2("\n ->");
			scanf(" %c",&GTTType);
			logDebug2("Please enter the Quantity");
			logDebug2("\n ->");
			scanf(" %d",&iQty);
			pOrdReq.CoArray[0].iTotalQty = iQty;
			pOrdReq.CoArray[0].iTotalQtyRem = iQty;
			//pOrdReq.CoArray[1].iTotalQty = iQty;
			//pOrdReq.CoArray[1].iTotalQtyRem = iQty;
			logDebug2(" 1 #########pOrdReq.iTotalQtyRem :%d: ###########",pOrdReq.CoArray[0].iTotalQtyRem);

			if(GTTType == 'G')
			{
				if(bs == 'B' || bs == 'b')
				{
					bs = 'B';
					logDebug2(" buy/sell : %c",bs);
					logDebug2("Please enter the Buy Price");
					logDebug2("->");
					scanf(" %lf",&fPrice);
					pOrdReq.CoArray[0].fPrice=fPrice;
					pOrdReq.CoArray[1].fPrice=0;
				}
				else if(bs == 'S' || bs == 's')
				{
					bs = 'S';
					logDebug2("buy/sell : %c",bs);
					logDebug2("Please enter the Sell Price");
					logDebug2("->");
					scanf(" %lf",&fPrice);
					pOrdReq.CoArray[0].fPrice=fPrice;
					pOrdReq.CoArray[1].fPrice=0;
				}
				else
				{
					logDebug2("Invalid Input");
				}
				logDebug2(" Enter The Trigger Price Of  Order");
				logDebug2(" ->");
				scanf(" %lf",&fTriggerPrice);
				logDebug2(" %lf",fTriggerPrice);
				pOrdReq.CoArray[0].fTriggerPrice = fTriggerPrice;
				pOrdReq.iNoOfLeg = 1;
			
				logDebug2(" Enter The Order Trigger Price Of  Order");
                                logDebug2(" ->");
                                scanf(" %lf",&fOrdTriggerPrice);
                                logDebug2(" %lf",fOrdTriggerPrice);
                                pOrdReq.CoArray[0].fOrdTriggerPrice = fOrdTriggerPrice;
			}
			else
			{
				if(bs == 'B' || bs == 'b')
				{
					bs = 'B';
					logDebug2(" buy/sell : %c",bs);
					logDebug2("Please enter the Buy Price of Leg1");
					logDebug2("->");
					scanf(" %lf",&fPrice);
					pOrdReq.CoArray[0].fPrice=fPrice;
					logDebug2(" Enter The Trigger Price Of  Order 1 ");
					logDebug2(" ->");
					scanf(" %lf",&fTriggerPrice);
					logDebug2(" %lf",fTriggerPrice);
					pOrdReq.CoArray[0].fTriggerPrice = fTriggerPrice;
					logDebug2("Please enter the Buy Price of Leg2");
					logDebug2("->");
					scanf(" %lf",&fPrice);
					pOrdReq.CoArray[1].fPrice=fPrice;
					logDebug2(" Enter The Trigger Price Of  Order 2");
					logDebug2(" ->");
					scanf(" %lf",&fTriggerPrice);
					logDebug2(" %lf",fTriggerPrice);
					pOrdReq.CoArray[1].fTriggerPrice = fTriggerPrice;
					pOrdReq.iNoOfLeg = 2;
					logDebug2("Please enter the Quantity for Leg 2");
					logDebug2("\n ->");
					scanf(" %d",&iQty);
					pOrdReq.CoArray[1].iTotalQty = iQty;
					pOrdReq.CoArray[1].iTotalQtyRem = iQty;
				}
				else if(bs == 'S' || bs == 's')
				{
					bs = 'S';
					logDebug2("buy/sell : %c",bs);
					logDebug2("Please enter the Buy Price of Leg1");
					logDebug2("->");
					scanf(" %lf",&fPrice);
					pOrdReq.CoArray[0].fPrice=fPrice;
					logDebug2(" Enter The Trigger Price Of  Order 1 ");
					logDebug2(" ->");
					scanf(" %lf",&fTriggerPrice);
					logDebug2(" %lf",fTriggerPrice);
					pOrdReq.CoArray[0].fTriggerPrice = fTriggerPrice;
					logDebug2("Please enter the Buy Price of Leg2");
					logDebug2("->");
					scanf(" %lf",&fPrice);
					pOrdReq.CoArray[1].fPrice=fPrice;
					logDebug2(" Enter The Trigger Price Of  Order 2");
					logDebug2(" ->");
					scanf(" %lf",&fTriggerPrice);
					logDebug2(" %lf",fTriggerPrice);
					pOrdReq.CoArray[1].fTriggerPrice = fTriggerPrice;
					logDebug2("Please enter the Quantity");
					logDebug2("\n ->");
					scanf(" %d",&iQty);
					pOrdReq.CoArray[1].iTotalQty = iQty;
					pOrdReq.CoArray[1].iTotalQtyRem = iQty;
					pOrdReq.iNoOfLeg = 2;

				}
				else
				{
					logDebug2("Invalid Input");
				}

			}
			break;

		case TC_INT_GTT_ORDER_MODIFY:

			logDebug2("Enter the Order Number ");
			logDebug2("->");
			scanf("%lf",&fOrderNum);
			pOrdReq.fOrderNum=fOrderNum;
			logDebug2("Enter The LegNo ");
			scanf("%d",&iLegVal);
			pOrdReq.CoArray[0].iLegValue = iLegVal;
			logDebug2("order no.:%lf",pOrdReq.fOrderNum);
			logDebug2("LegValue :%d:",pOrdReq.CoArray[0].iLegValue);
			logDebug2(" Enter the Entity that u want to modify : 1) Leg1 Order  Price   2) Leg2 Trigger Price");
			logDebug2(" ->");
			scanf("%d",&iEntity);
			switch (iEntity)
			{
				case 1 :
					logDebug2(" Enter The Order  Price that  You want to modify Of Leg1 Order");
					logDebug2(" ->");
					scanf(" %lf",&fPrice);
					logDebug2(" %lf",fPrice);
					pOrdReq.CoArray[0].fPrice=fPrice;
					logDebug2(" Enter The Trigger  Price that  You want to modify Of Leg1 Order");
					logDebug2(" ->");
					scanf(" %lf",&fTriggerPrice);
					logDebug2(" %lf",fTriggerPrice);
					pOrdReq.CoArray[0].fTriggerPrice = fTriggerPrice;
					
					logDebug2(" Enter The Order Trigger Price Of  Order");
                                	logDebug2(" ->");
                                	scanf(" %lf",&fOrdTriggerPrice);
                               		logDebug2(" %lf",fOrdTriggerPrice);
                                	pOrdReq.CoArray[0].fOrdTriggerPrice = fOrdTriggerPrice;
					break ;

				case 2  :
					logDebug2(" Enter The Order  Price that  You want to modify Of Leg2 Order");
					logDebug2(" ->");
					scanf(" %lf",&fPrice);
					logDebug2(" %lf",fPrice);
					pOrdReq.CoArray[1].fPrice=fPrice;
					logDebug2(" Enter The Trigger Price You want to modify Of Leg2  Order");
					logDebug2(" ->");
					scanf(" %lf",&fTriggerPrice);
					logDebug2(" %lf",fTriggerPrice);
					pOrdReq.CoArray[1].fTriggerPrice = fTriggerPrice;
					
					logDebug2(" Enter The Order Trigger Price Of  Order");
                                	logDebug2(" ->");
                                	scanf(" %lf",&fOrdTriggerPrice);
                                	logDebug2(" %lf",fOrdTriggerPrice);
                                	pOrdReq.CoArray[0].fOrdTriggerPrice = fOrdTriggerPrice;
					break ;

				default:
					logDebug2("Wrong Value Entered");
					return ERROR;
					break;
			}
			memset(statement,'\0',200);
			sprintf(statement,"SELECT max(GTT_SERIAL_NO),GTT_BUY_SELL_IND,GTT_TOTAL_QTY,GTT_REM_QTY ,GTT_TOTAL_TRADED_QTY  FROM GTT_ORDERS WHERE GTT_ORDER_NO=%lf AND GTT_LEG_NO = %d;",pOrdReq.fOrderNum,pOrdReq.CoArray[0].iLegValue);
			logDebug2("\n query -> %s", statement);

			if(mysql_query(OdrConn,statement)!=SUCCESS)
			{
				sql_Error(OdrConn);
				return ERROR;
			}
			result=mysql_store_result(OdrConn);

			if((rw=mysql_num_rows(result))==0)
			{
				sql_Error(OdrConn);
				return ERROR;

			}

			row = mysql_fetch_row(result);
			iSerialNum = atoi(row[0]);
			pOrdReq.CoArray[0].iTotalQty = atoi(row[2]);
			pOrdReq.CoArray[0].iTotalQtyRem = atoi(row[3]);
			pOrdReq.iSerialNum= iSerialNum +1;
			pOrdReq.iNoOfLeg = 1;
			logDebug2(" Serial Number is %d",pOrdReq.iSerialNum);
			pOrdReq.cBuySellInd = row[1][0];
			pOrdReq.iTotalTradedQty = atoi(row[4]);
			mysql_free_result(result);
			memset(statement,'\0',strlen(statement));

			break;

		case TC_INT_GTT_ORDER_CANCEL:
 			logDebug2("pOrdReq.ReqHeader.iMsgCode %d",pOrdReq.ReqHeader.iMsgCode);
			logDebug2("Enter the Order Number ");
			logDebug2("->");
			scanf(" %lf",&fOrderNum);
			pOrdReq.fOrderNum=fOrderNum;
			pOrdReq.CoArray[0].iLegValue = 1 ;
			pOrdReq.CoArray[1].iLegValue = 2 ;
			logDebug2("order no.:%lf",pOrdReq.fOrderNum);

			for( k==0 ; k < 1 ;k++)
			{
				if( k == 0)
				{
					ival = 1;
				}
				else
				{
					ival = 2;	
				}
				memset(statement,'\0',strlen(statement));
				sprintf(statement,"SELECT GTT_SERIAL_NO,GTT_BUY_SELL_IND ,GTT_TOTAL_QTY,GTT_REM_QTY,GTT_ORDER_PRICE,GTT_TRIGGER_PRICE,GTT_TOTAL_TRADED_QTY,GTT_ORD_TRIGGER_PRICE  FROM GTT_ORDERS WHERE GTT_ORDER_NO=%lf AND GTT_LEG_NO = %d  AND GTT_SERIAL_NO = (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO= %lf AND GTT_LEG_NO = %d );",pOrdReq.fOrderNum,ival,pOrdReq.fOrderNum,ival);
				logDebug2("Query [%s]",statement);

				if(mysql_query(OdrConn,statement)!=SUCCESS)
				{
					sql_Error(OdrConn);
					logSqlFatal("Error in query.");
					return ERROR;
				}

				result=mysql_store_result(OdrConn);

				if((rw=mysql_num_rows(result))==0)
				{
					sql_Error(OdrConn);
					return ERROR;
				}

				row = mysql_fetch_row(result);

				if( k == 0)
				{				
					pOrdReq.CoArray[0].fPrice  = atof(row[4]);
					logDebug2("pOrdReq.fPrice :%f:",pOrdReq.CoArray[0].fPrice);
					logDebug2("atof(row[4]) :%f:",atof(row[4]));
				}
				iSerialNum=atoi(row[0]);
				pOrdReq.iSerialNum =iSerialNum +1;
				pOrdReq.cBuySellInd = row [1][0];
				pOrdReq.CoArray[k].iTotalQty = atoi(row[2]);
				pOrdReq.CoArray[k].iTotalQtyRem = atoi(row[3]);
				pOrdReq.iTotalTradedQty = atoi(row[6]);

				pOrdReq.CoArray[k].fTriggerPrice = atof(row[5]);
				pOrdReq.CoArray[k].fOrdTriggerPrice = atof(row[7]);
			}
			pOrdReq.iNoOfLeg = 1;
			//pOrdReq.iSerialNum =iSerialNum +1;
			//pOrdReq.iSerialNum++;
			logDebug2("Serial Number is %d \n",pOrdReq.iSerialNum);
			mysql_free_result(result);
			memset(statement,'\0',strlen(statement));

			break;
			/*
			   case TC_INT_CO_ORDER_EXIT :

			   memset(statement,'\0',strlen(statement));
			   logDebug2("##########Here Leg2 will Execute to market");
			   logDebug2("Enter the Order Number ");
			   logDebug2("->");
			   scanf(" %lf",&fOrderNum);
			   pOrdReq.fOrderNum=fOrderNum;
			   pOrdReq.CoArray[0].iLegValue = 2 ;
			   sprintf(statement,"SELECT max(GTT_SERIAL_NO),GTT_BUY_SELL_IND,GTT_TRIGGER_PRICE,GTT_TOTAL_QTY,GTT_REM_QTY,GTT_ORDER_PRICE,GTT_TOTAL_TRADED_QTY   FROM GTT_ORDERS WHERE GTT_ORDER_NO=%lf AND GTT_LEG_NO = %d AND GTT_SERIAL_NO = (SELECT MAX(GTT_SERIAL_NO) FROM GTT_ORDERS WHERE GTT_ORDER_NO= %lf AND GTT_LEG_NO = %d );",pOrdReq.fOrderNum,pOrdReq.CoArray[0].iLegValue,pOrdReq.fOrderNum,pOrdReq.CoArray[0].iLegValue);

			   if(mysql_query(OdrConn,statement)!=SUCCESS)
			   {
			   sql_Error(OdrConn);
			   logSqlFatal("Error in query.");
			   return ERROR;
			   }

			   result  = mysql_store_result(OdrConn);

			   if((rw=mysql_num_rows(result))==0)
			   {

			   sql_Error(OdrConn);
			   return ERROR;
			   }
			   row = mysql_fetch_row(result);
			   iSerialNum=atoi(row[0]);
			   pOrdReq.iSerialNum=iSerialNum;
			   pOrdReq.iSerialNum++;
			   pOrdReq.CoArray[0].cBuySellInd = row[1][0];
			   pOrdReq.iTotalQty = atoi(row[3]);
			   pOrdReq.iTotalQtyRem = atoi(row[4]);
			   pOrdReq.iTotalTradedQty = atoi(row[6]);
			   pOrdReq.CoArray[0].fTriggerPrice = 0.00;
			   pOrdReq.fPrice  = 0.00;
			   pOrdReq.iNoOfLeg = 1;
			   logDebug2("Serial Number is %d",pOrdReq.iSerialNum);

			   mysql_free_result(result);
			   memset(statement,'\0',strlen(statement));
			   break;
			   */

		default:

			logDebug2("\n Invalid input ");
	}



	if( pOrdReq.ReqHeader.iMsgCode == TC_INT_GTT_ORDER_ENTRY)
	{
		pOrdReq.iSerialNum = 1 ;
		pOrdReq.iTotalTradedQty = 0;
		//		pOrdReq.iNoOfLeg = 1;
		pOrdReq.CoArray[0].iLegValue = 1 ;
		pOrdReq.CoArray[1].iLegValue = 2;

		pOrdReq.cBuySellInd= bs;

		pOrdReq.cGttType = GTTType ;			

	}
	else  if( pOrdReq.ReqHeader.iMsgCode == TC_INT_GTT_ORDER_MODIFY)
        {
                //pOrdReq.iSerialNum = 2 ;
                pOrdReq.iTotalTradedQty = 0;
		pOrdReq.CoArray[0].iLegValue = 1 ;
                pOrdReq.CoArray[1].iLegValue = 2;

                pOrdReq.cBuySellInd= bs;

                pOrdReq.cGttType = GTTType ;

        }
	else  if( pOrdReq.ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
        {
		 pOrdReq.ReqHeader.iMsgCode      =  TC_INT_GTT_ORDER_CANCEL;
                //pOrdReq.iSerialNum = 2 ;
                pOrdReq.iTotalTradedQty = 0;
                pOrdReq.CoArray[0].iLegValue = 1 ;
                pOrdReq.CoArray[1].iLegValue = 2;

                pOrdReq.cBuySellInd= bs;

                pOrdReq.cGttType = GTTType ;

        }


	/* pOrdReq.iSerialNum = 2 ;
                pOrdReq.iTotalTradedQty = 0;
                pOrdReq.CoArray[0].iLegValue = 1 ;
                pOrdReq.CoArray[1].iLegValue = 2;

                pOrdReq.cBuySellInd= bs;

                pOrdReq.cGttType = 'O' ;

*/




	pOrdReq.ReqHeader.iSeqNo = 11;
	pOrdReq.ReqHeader.iMsgLength = 100;
 
 // pOrdReq.ReqHeader.iMsgCode      =  TC_INT_GTT_ORDER_CANCEL;
	strncpy(pOrdReq.ReqHeader.sExcgId,"MCX",EXCHANGE_LEN);
	//        pOrdReq.ReqHeader.iUserId = 9223;
	pOrdReq.ReqHeader.iUserId = 100002;
	pOrdReq.ReqHeader.cSource = 'A';
	pOrdReq.ReqHeader.cSegment = 'M';
	//        strncpy(pOrdReq.sSecurityId,"11536",DB_SECURITY_ID_LEN);
//	strncpy(pOrdReq.sSecurityId,"35002",SECURITY_ID_LEN);
	strncpy(pOrdReq.sSecurityId,"233041",SECURITY_ID_LEN);
	strncpy(pOrdReq.sEntityId,"100001",ENTITY_ID_LEN);
	strncpy(pOrdReq.sPanID,"ABCDE1234F",INT_PAN_LEN);

	strncpy(pOrdReq.sClientId,"100001",CLIENT_ID_LEN);

	//strncpy(pOrdReq.sPlatform,"HII",PLATFORM_LEN);
	//strncpy(pOrdReq.sChannel,"BRO",CHANNEL_LEN);
	pOrdReq.iDiscQty = 0;
	pOrdReq.iDiscQtyRem = 0;


	pOrdReq.iMktType = 1;
	//      pOrdReq.fPrice = 50.1;
	//pOrdReq.iOrderType      = 2;

	if ( pOrdReq.CoArray[0].fPrice== 0.00 &&  pOrdReq.CoArray[0].fTriggerPrice == 0.00 )
        {
                pOrdReq.iOrderType  = ORD_TYPE_MKT ;
        }
        else if ( pOrdReq.CoArray[0].fPrice != 0.00 && pOrdReq.CoArray[0].fTriggerPrice == 0.00 )
        {
                pOrdReq.iOrderType = ORD_TYPE_LIMIT ;
        }
        else if ( pOrdReq.CoArray[0].fPrice == 0.00 && pOrdReq.CoArray[0].fTriggerPrice != 0.00)
        {
                pOrdReq.iOrderType = ORD_TYPE_STOP_LOSS_MKT ;
        }
        else if ( pOrdReq.CoArray[0].fPrice != 0.00 && pOrdReq.CoArray[0].fTriggerPrice  != 0.00)
        {
                pOrdReq.iOrderType = ORD_TYPE_STOP_LIMIT ;
        }
        else
        {
                logDebug2("OrderType Not Found from price and iTriggerPrice ");
                return FALSE;
        }

	pOrdReq.iOrderValidity = 0;
	pOrdReq.iMinFillQty = 0;
	pOrdReq.cProCli = 'C';
	pOrdReq.cUserType = 'C';
	pOrdReq.cOffMarketFlg = 'N';
	pOrdReq.cProductId = 'M';
	pOrdReq.cHandleInst = '1';
	pOrdReq.cParticipantType = 'C';
	pOrdReq.cGTCFlag= 'N';
	pOrdReq.cEncashFlag= 'N';
	pOrdReq.cMarkProFlag= 'N';
	logDebug2("pOrdReq.ReqHeader.iSeqNo :%d:",pOrdReq.ReqHeader.iSeqNo);
	logDebug2("pOrdReq.ReqHeader.iMsgLength :%d:",pOrdReq.ReqHeader.iMsgLength);
	logDebug2("pOrdReq.ReqHeader.iMsgCode :%d:",pOrdReq.ReqHeader.iMsgCode);
	logDebug2("pOrdReq.ReqHeader.iUserId :%llu:",pOrdReq.ReqHeader.iUserId);
	logDebug2("pOrdReq.ReqHeader.cSource  :%c:",pOrdReq.ReqHeader.cSource);
	logDebug2("pOrdReq.ReqHeader.cSegment :%c:",pOrdReq.ReqHeader.cSegment);
	logDebug2("pOrdReq.fOrderNum :%f:",pOrdReq.fOrderNum);
	logDebug2("pOrdReq.iSerialNum :%d:",pOrdReq.iSerialNum);
	logDebug2("pOrdReqs.SecurityId :%s:",pOrdReq.sSecurityId);
	logDebug2("pOrdReq.ReqHeader.sExcgId :%s:",pOrdReq.ReqHeader.sExcgId);
	logDebug2("pOrdReqs.ClientId :%s:",pOrdReq.sClientId);
	logDebug2("pOrdReq.iMktType :%d:",pOrdReq.iMktType);
	logDebug2("pOrdReq.CoArray[0].iLegValue :%d:",pOrdReq.CoArray[0].iLegValue);
	logDebug2("pOrdReq.CoArray[1].iLegValue :%d:",pOrdReq.CoArray[1].iLegValue);
	logDebug2("pOrdReq.CoArray[0].fTriggerPrice :%f:",pOrdReq.CoArray[0].fTriggerPrice);
	logDebug2("pOrdReq.CoArray[1].fTriggerPrice :%f:",pOrdReq.CoArray[1].fTriggerPrice);
	logDebug2("pOrdReq.cProCli :%c:",pOrdReq.cProCli);
	logDebug2("pOrdReq.iTotalQty :%d:",pOrdReq.CoArray[0].iTotalQty);
	logDebug2("pOrdReq.iTotalQtyRem :%d:",pOrdReq.CoArray[0].iTotalQtyRem);
	logDebug2("pOrdReq.iDiscQty :%d:",pOrdReq.iDiscQty);
	logDebug2("pOrdReq.iDiscQtyRem :%d:",pOrdReq.iDiscQtyRem );
	logDebug2("pOrdReq.iTotalTradedQty :%d:",pOrdReq.iTotalTradedQty );
	logDebug2("pOrdReq.fPrice :%f:",pOrdReq.CoArray[0].fPrice);
	logDebug2("pOrdReq.iOrderValidity :%d:",pOrdReq.iOrderValidity);
	logDebug2("pOrdReq.iOrderType :%d:",pOrdReq.iOrderType);
	logDebug2("pOrdReq.iMinFillQty :%d:",pOrdReq.iMinFillQty);
	logDebug2("pOrdReq.cUserType :%c:",pOrdReq.cUserType);
	logDebug2("pOrdReq.cProductId :%c:",pOrdReq.cProductId);
	logDebug2("pOrdReq.fTrailingSLValue :%f:",pOrdReq.fTrailingSLValue);
	logDebug2("pOrdReq.cOffMarketFlg :%c:",pOrdReq.cOffMarketFlg);
	logDebug2("pOrdReq.cHandleInst :%c:",pOrdReq.cHandleInst);
	logDebug2("pOrdReq.cIdentityFlag:%c:",pOrdReq.cGttType);
	logDebug2("pOrdReq.CoArray[0].fOrdTriggerPrice :%f:",pOrdReq.CoArray[0].fOrdTriggerPrice);

	logDebug2("iMktType %d ",pOrdReq.iMktType);
	if(WriteMsgQ( iOrdRtrToGTTOrd,(CHAR *) &pOrdReq, sizeof(struct FOREVER_ORDER_REQUEST),1) != 1){
		perror("write to Q failed : ");
		exit(ERROR);
	}
	logDebug2(" write successful ");
	logDebug2(" Serial NUMBer is %d ",pOrdReq.iSerialNum);
	logDebug2(" Order NUmber %lf ",pOrdReq.fOrderNum);
	logDebug2(" MsgCode is %d ",pOrdReq.ReqHeader.iMsgCode);
	logDebug2(" Price is %lf ",pOrdReq.CoArray[0].fPrice);

}

