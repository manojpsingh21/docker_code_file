# include    <stdio.h>
# include    <memory.h>
# include    <malloc.h>
# include    <string.h>
# include    <sys/types.h>
# include    <sys/ipc.h>
# include    <sys/sem.h>
# include    <sys/errno.h>
# include    <sys/stat.h>
# include    <sys/wait.h>
# include    <sys/msg.h>
# include    <sys/ipc.h>
# include    "IPCS.h"

BOOL	CheckLicense();
void Unscramble(char *sStr);

main()
{
	//logTimestamp("Entry : [main]");
	int             test;
	int             md;
	int             i,j;
	struct          user_relay_array   	*DirRelShm_mem		;
	struct          user_relay_array   	*AdmRelShm_mem		;
	struct          ProcessMonitorArray   	*ProcessMonitor_mem	;
	struct          PMonitor_array          *PMonitorShm_mem    	; 

	struct 		DWS_ADAPTER_USER_ARRAY	*AdminRelayUserShm_mem	; 
	struct		USER_DETAIL_ARRAY	*Equ_User_Dtl_Shm_mem	;

	struct		SEC_MASTER_ARRAY 	*Hash_ByID;
	struct 		DWS_ADAPTER_USER_ARRAY		*DWSRelayUserShm_mem;	
	int             * LockVar;
	int             ShmSize;
	struct 		EXCH_CONNECT_STATUS *ConnStatusShm_mem;
	struct 		InvitationCount		*NseEquInvMem	;
	struct 		InvitationCount		*NseDrvInvMem	;
	struct 		InvitationCount		*NseCurrInvMem	;
	struct 		InvitationCount		*NseMFInvMem	;
	struct 		InvitationCount		*NCMInvMem	;
	BOOL		iChkFlag = FALSE;

	iChkFlag = CheckLicense();	

	if(iChkFlag == TRUE)
	{
		printf("Your License Is Active\n");
	}
	else
	{
		printf("Your Licence Is Expired.!!! Kindly Update Your Licence\n");
		exit(ERROR);
	}

	printf("This is log Debug1\n ");	
/**
	if(CreateSharedMemory( LogLevelShm, LogLevelShm_SIZE) == ERROR )
	{
		perror("LogLevelShm failed ");
		exit(1);
	}
	printf("This is log Debug2\n ");	
	
	if(CreateSharedMemory( LockSystem, LockSystem_SIZE) == ERROR )
	{
		logFatal("LockSystem failed ");
		exit(1);
	}
	else
	{
		if((LockVar = (int *)OpenSharedMemory(LockSystem,LockSystem_SIZE)) == (int *)ERROR)
		{
			logFatal("LockSystem:Open error");
			exit(1);
		}
		//		if ( (*LockVar) == 87654324 )
		if ( (*LockVar) == 88654327 )
		{
			logInfo( "System is Already running, Stop it and run again");
			exit (2);
		} 
		else
		{
			(*LockVar) = 88654327;
		}
		if ( CloseSharedMemory( (void * ) LockVar ) == ERROR )
		{
			logFatal("Error in Closing LockSystem ");
			exit(1);
		}

	}

	printf("This is log Debug3\n ");	
	if (CreateSharedMemory(DirRelShm,DirRelShm_SIZE) == ERROR)
	{
		printf("\nDirRelShm Failed");
		exit(1);
	}
	else
	{
		if((DirRelShm_mem = (struct user_relay_array *)OpenSharedMemory(DirRelShm,DirRelShm_SIZE)) == (struct user_relay_array *)ERROR)
		{
			perror("DirRelShm:Open error");
			exit(1);
		}

		for(i=0; i < MAX_DWS_USERS ; i ++)
		{
			DirRelShm_mem->user_relay[i].iRelayId = UNUSED;
			DirRelShm_mem->user_relay[i].iUserId = UNUSED;
			DirRelShm_mem->user_relay[i].iCheck = UNUSED;
			DirRelShm_mem->user_relay[i].iProcessId = UNUSED;
			memset( DirRelShm_mem->user_relay[i].sClientId , ' ' , CLIENT_ID_LEN) ;
			DirRelShm_mem->user_relay[i].cUserType = ' ';
		}
		if ( CloseSharedMemory( (void * ) DirRelShm_mem ) == ERROR )
		{
			perror("Error in Closing DirRelShm_mem");
			exit(1);
		}
	}

	printf("This is log Debug3\n ");
        if (CreateSharedMemory(AdmRelShm,AdmRelShm_SIZE) == ERROR)
        {
                printf("\nAdmRelShm Failed");
                exit(1);
        }
        else
        {
                if((AdmRelShm_mem = (struct user_relay_array *)OpenSharedMemory(AdmRelShm,AdmRelShm_SIZE)) == (struct user_relay_array *)ERROR)
                {
                        perror("AdmRelShm :Open error");
                        exit(1);
                }

                for(i=0; i < MAX_DWS_USERS ; i ++)
                {
                        AdmRelShm_mem->user_relay[i].iRelayId = UNUSED;
                        AdmRelShm_mem->user_relay[i].iUserId = UNUSED;
                        AdmRelShm_mem->user_relay[i].iCheck = UNUSED;
                        AdmRelShm_mem->user_relay[i].iProcessId = UNUSED;
                        memset( AdmRelShm_mem->user_relay[i].sClientId , ' ' , CLIENT_ID_LEN) ;
                        AdmRelShm_mem->user_relay[i].cUserType = ' ';
                }
                if ( CloseSharedMemory( (void * ) AdmRelShm_mem ) == ERROR )
                {
                        perror("Error in Closing AdmRelShm_mem ");
                        exit(1);
                }
        }

	printf("This is log Debug4\n ");	
	if((CreateSharedMemory(InvitationCountShm,InvitationCountShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of InvitationCountShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseEquInvMem = (struct InvitationCount *)OpenSharedMemory(InvitationCountShm,InvitationCountShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for InvitationCountShm Status\n");
			exit(1);
		}

		NseEquInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseEquInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseEquInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseEquInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseEquInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseEquInvMem");
			exit(1);
		}
	}	

	printf("This is log Debug5\n ");	

	if((CreateSharedMemory(DrvInvitatnCntShm,DrvInvitatnCntShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of DrvInvitatnCntShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseDrvInvMem = (struct InvitationCount *)OpenSharedMemory(DrvInvitatnCntShm ,DrvInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for DrvInvitatnCntShm Status\n");
			exit(1);
		}

		NseDrvInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseDrvInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseDrvInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseDrvInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseDrvInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseDrvInvMem");
			exit(1);
		}
	}
	printf("This is log Debug6\n ");	

	if((CreateSharedMemory(CurrInvitatnCntShm,CurrInvitatnCntShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of CurrInvitatnCntShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseCurrInvMem = (struct InvitationCount *)OpenSharedMemory(CurrInvitatnCntShm ,CurrInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for CurrInvitatnCntShm Status\n");
			exit(1);
		}

		NseCurrInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseCurrInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseCurrInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseCurrInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseCurrInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseCurrInvMem");
			exit(1);
		}
	}
	printf("This is log Debug7\n ");	

	if((CreateSharedMemory( Bse_Conn_Shm_1 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_1 Failed");
		exit(1);
	}

	if((CreateSharedMemory( Bse_Conn_Shm_2 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_2 Failed");
		exit(1);
	}
	if((CreateSharedMemory( Bse_Conn_Shm_3 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_3 Failed");
		exit(1);
	}

	if((CreateSharedMemory( Bse_Conn_Shm_4 , Bse_Conn_Shm_SIZE ))==ERROR)
	{
		printf("Bse_Conn_Shm_4 Failed");
		exit(1);
	}

        if((CreateSharedMemory( Bse_CConn_Shm_1 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_1 Failed");
                exit(1);
        }

        if((CreateSharedMemory( Bse_CConn_Shm_2 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_2 Failed");
                exit(1);
        }
        if((CreateSharedMemory( Bse_CConn_Shm_3 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_3 Failed");
                exit(1);
        }

        if((CreateSharedMemory( Bse_CConn_Shm_4 , Bse_CConn_Shm_SIZE ))==ERROR)
        {
                printf("Bse_CConn_Shm_4 Failed");
                exit(1);
        }

	if((CreateSharedMemory(MfssInvitatnCntShm,MfssInvitatnCntShm_SIZE))==ERROR)
	{
		printf("Shared Memory Creation for status of MfssInvitatnCntShm Failed\n");
		exit(1);
	}
	else
	{


		if((NseMFInvMem= (struct InvitationCount *)OpenSharedMemory(MfssInvitatnCntShm ,MfssInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
		{
			printf("Error in Opening Shared Memory Created for MfssInvitatnCntShm Status\n");
			exit(1);
		}

		NseMFInvMem->InvCount_group[0].iInvPacketCount = 0;
		NseMFInvMem->InvCount_group[1].iInvPacketCount = 0;
		NseMFInvMem->InvCount_group[2].iInvPacketCount = 0;
		NseMFInvMem->InvCount_group[3].iInvPacketCount = 0;

		if ((CloseSharedMemory((void *)NseMFInvMem)) == ERROR )
		{
			printf("\n Error In Closing NseMFInvMem");
			exit(1);
		}
	}
	  if(CreateSharedMemory(Equ_User_Dtl_Shm,Equ_User_Dtl_Shm_SIZE) == ERROR)
	  {
	  logFatal("Shared Memory Creation Failed for EQU_USER_MASTER");
	  exit(1);
	  }
	  else
	  {
	  if((Equ_User_Dtl_Shm_mem = (struct USER_DETAIL_ARRAY *)OpenSharedMemory(Equ_User_Dtl_Shm,Equ_User_Dtl_Shm_SIZE)) == ERROR)
	  {
	  logFatal("Failed in Opening Shared Memory EQU_USER_MASTER_ARRAY" );
	  }
	  else
	  {
	  for(i = 0 ;i < MAX_NO_OF_USERS_SHM ;i++)
	  {
	  Equ_User_Dtl_Shm_mem -> User_Dtl[i].iUserId = 0;
	  Equ_User_Dtl_Shm_mem -> User_Dtl[i].iUserGrpId = 0;
	  strncpy(Equ_User_Dtl_Shm_mem -> User_Dtl[i].sLocationCode,"0.0",LOC_CODE_LEN);
	  }
	  Equ_User_Dtl_Shm_mem -> iNoOfUsers = 0;

	  if ( CloseSharedMemory( (void * ) Equ_User_Dtl_Shm_mem ) == ERROR )
	  {
	  logFatal("Error in Closing Equ_User_Master_mem");
	  exit(1);
	  }

	  }
	  }
	printf("This is log Debug8\n ");	

	if (SemophoreCreate(LogFatalShm) == ERROR)
	{
		perror("LogFatalShm Failed");
		exit(1);
	}

	printf("This is log Debug9\n ");	
	if (SemophoreCreate(ProcessDataLock1) == ERROR)
	{
		logFatal("ProcessDataLock Failed");
		exit(1);
	}
	if (CreateSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)==ERROR)
	{
		perror("Shared memory creation for ConnStatusShm failed");
		exit(1);
	}
	else
	{
		if((ConnStatusShm_mem = (struct EXCH_CONNECT_STATUS *)OpenSharedMemory(ConnStatusShm,ConnStatusShm_SIZE)) == (struct EXCH_CONNECT_STATUS *)ERROR)
		{
			perror("ConnStatusShm:Open error");
			exit(1);
		}
		memset( ConnStatusShm_mem ,'0', ConnStatusShm_SIZE);
		if ( CloseSharedMemory( (void * ) ConnStatusShm_mem ) == ERROR )
		{
			perror("Error in Closing ConnStatusShm_mem");
			exit(1);
		}
	}

	printf("This is log Debug10\n ");	

	if (CreateSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE)==ERROR)
	{
		perror("Failed To Create Shared Memory For STWRelay :DWSAdapterUserShm");
		printf("\nError Id = [%d]",errno);
		exit(1);
	}
	else
	{
		if((DWSRelayUserShm_mem= (struct DWS_ADAPTER_USER_ARRAY *)OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE)) == ( struct DWS_ADAPTER_USER_ARRAY *)ERROR)
		{
			perror("DWSAdapterUserShm Error");
			exit(1);
		}
		for ( i=0; i<MAX_DWS_USERS ; i++ )
		{
			DWSRelayUserShm_mem->dws_adapter_user[i].iRelayId		=	UNUSED	;
			DWSRelayUserShm_mem->dws_adapter_user[i].ProcessId	=	UNUSED	;
			memset(&(DWSRelayUserShm_mem->dws_adapter_user[i].sUser),' ',USER_ID_LEN);
		}
		if ((CloseSharedMemory(DWSRelayUserShm_mem)) == ERROR )
		{
			perror("Error In Closing DWSRelayUserShm_mem");
			exit(1);
		}
	}
	printf("This is log Debug11\n ");	

	if (CreateSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE)==ERROR)
	{
		perror("Failed To Create Shared Memory For AdminRelay :AdminAdapterUserShm");
		printf("\nError Id = [%d]",errno);
		exit(1);
	}
	else
	{
		if((AdminRelayUserShm_mem= (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE)) == ( struct ADMIN_ADAPTER_USER_ARRAY *)ERROR)
		{
			perror("AdminAdapterUserShm Error");
			exit(1);
		}
		for ( i=0; i<MAX_DWS_USERS ; i++ )
		{
			AdminRelayUserShm_mem->dws_adapter_user[i].iRelayId               =       UNUSED  ;
			AdminRelayUserShm_mem->dws_adapter_user[i].ProcessId      =       UNUSED  ;
			memset(&(AdminRelayUserShm_mem->dws_adapter_user[i].sUser),' ',USER_ID_LEN);
		}
		if ((CloseSharedMemory(AdminRelayUserShm_mem)) == ERROR )
		{
			perror("Error In Closing AdminRelayUserShm_mem");
			exit(1);
		}
	}

	  if(CreateSharedMemory( LogLevelShm, LogLevelShm_SIZE) == ERROR )
	  {
	  logFatal("LogLevelShm failed");
	  exit(1);
	  }

	
        if (CreateSharedMemory(AdminAdaptQryUserShm,AdminAdaptQryUserShm_SIZE)==ERROR)
        {
                perror("Failed To Create Shared Memory For AdminRelay :AdminAdapterUserShm");
                printf("\nError Id = [%d]",errno);
                exit(1);
        }
        else
        {
                if((AdminRelayUserShm_mem= (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminAdaptQryUserShm,AdminAdaptQryUserShm_SIZE)) == ( struct ADMIN_ADAPTER_USER_ARRAY *)ERROR)
                {
                        perror("AdminAdaptQryUserShm  Error");
                        exit(1);
                }
                for ( i=0; i<MAX_DWS_USERS ; i++ )
                {
                        AdminRelayUserShm_mem->dws_adapter_user[i].iRelayId               =       UNUSED  ;
                        AdminRelayUserShm_mem->dws_adapter_user[i].ProcessId      =       UNUSED  ;
                        memset(&(AdminRelayUserShm_mem->dws_adapter_user[i].sUser),' ',USER_ID_LEN);
                }
                if ((CloseSharedMemory(AdminRelayUserShm_mem)) == ERROR )
                {
                        perror("Error In Closing AdminRelayUserShm_mem");
                        exit(1);
                }
        }




	printf("This is log Debug12\n ");


	
	if (CreateSharedMemory1(ProcessMonitorShm,ProcessMonitor_SIZE) == ERROR)
	{
		perror("ProcessMonitorShm Failed");
		exit(1);
	}
	else
	{
		if((ProcessMonitor_mem = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE)) == (struct ProcessMonitorArray *)ERROR)
		{
			perror("ProcessMonitorArray:Open error");
			exit(1);
		}
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			memset(ProcessMonitor_mem->ProcessMonitor[i].sProcessName,' ',50);
			memset(ProcessMonitor_mem->ProcessMonitor[i].sMainProcessName,' ',50);
			ProcessMonitor_mem->ProcessMonitor[i].iProcessId = UNUSED;
		}
		if ( CloseSharedMemory( (void * ) ProcessMonitor_mem ) == ERROR )
		{
			perror("Error in Closing ProcessMonitor_mem");
			exit(1);
		}
	}

	printf("This is log Debug13\n ");
	

        if((CreateSharedMemory(NCMInvitatnCntShm,NCMInvitatnCntShm_SIZE))==ERROR)
        {
                printf("Shared Memory Creation for status of NCMInvitatnCntShm Failed\n");
                exit(1);
        }
        else
        {


                if((NCMInvMem = (struct InvitationCount *)OpenSharedMemory(NCMInvitatnCntShm ,NCMInvitatnCntShm_SIZE)) == (struct InvitationCount *) ERROR)
                {
                        printf("Error in Opening Shared Memory Created for DrvInvitatnCntShm Status\n");
                        exit(1);
                }

                NCMInvMem->InvCount_group[0].iInvPacketCount = 0;
                NCMInvMem->InvCount_group[1].iInvPacketCount = 0;
                NCMInvMem->InvCount_group[2].iInvPacketCount = 0;
                NCMInvMem->InvCount_group[3].iInvPacketCount = 0;

                if ((CloseSharedMemory((void *)NCMInvMem)) == ERROR )
                {
                        printf("\n Error In Closing NCMInvMem");
                        exit(1);
                }
        }
	
	/*****/	
	/**	if (CreateSharedMemory(EQ_SEC_MASTER_Shm,EQ_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  perror("Failed To Create Shared Memory For EQ_SEC_MASTER_Shm");
	  logFatal("Error Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {
	 ****
	 if((Hash_ByID = (struct SEC_MASTER_ARRAY *)OpenSharedMemory(EQ_SEC_MASTER_Shm,EQ_SEC_MASTER_Shm_SIZE)) == (struct SEC_MASTER_ARRAY *)ERROR)
	 {
	 logFatal("EQ_SEC_MASTER_Shm:Open error");
	 exit(1);
	 }

	//Hash_ByID = NULL;	

	if ( CloseSharedMemory( (void * ) Hash_ByID) == ERROR )
	{
	logFatal("Error in Closing Hash_ByID");
	exit(1);
	}	

	printf("\n Shared Memory For EQ_SEC_MASTER_Shm Created.");
	}
	 *******/

	/**	
	  if (CreateSharedMemory(DR_SEC_MASTER_Shm,DR_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  perror("Failed To Create Shared Memory For DR_SEC_MASTER_Shm");
	  printf("\nError Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\n Shared Memory For DR_SEC_MASTER_Shm Created.");
	  }

	  if (CreateSharedMemory(Temp_Shm,Temp_Shm_SIZE)==ERROR)
	  {
	  perror("Failed To Create Shared Memory For DR_SEC_MASTER_Shm");
	  printf("\nError Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\n Shared Memory For DR_SEC_MASTER_Shm Created.");
	  }

	  if (CreateSharedMemory(CR_SEC_MASTER_Shm,CR_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  logFatal("Failed To Create Shared Memory For CR_SEC_MASTER_Shm");
	  logFatal("Error Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\nShared Memory For CR_SEC_MASTER_Shm Created.");
	  }

	  if (CreateSharedMemory(CM_SEC_MASTER_Shm,CM_SEC_MASTER_Shm_SIZE)==ERROR)
	  {
	  logFatal("Failed To Create Shared Memory For CM_SEC_MASTER_Shm");
	  logFatal("Error Id = [%d]",errno);
	  exit(1);
	  }
	  else
	  {	
	  printf("\nShared Memory For CM_SEC_MASTER_Shm Created.");
	  }
	printf("\n-------------------------- Start Creating Queues ------------------------------");

	printf("\n1. RelToOrdRtr : ");
	if (CreateMsgQueue( RelToOrdRtr , RelToOrdRtr_SIZE ) == ERROR )
	{
		logFatal("RelToOrdRtr failed......");
		exit(1);
	} 

	printf("\n2. DWSRelayToDWSQueries :");
	if (CreateMsgQueue(RelToQuery , RelToQuery_SIZE) == ERROR )
	{
		logFatal("DWSRelayToDWSQueries failed : ");
		exit(1);
	}

	printf("\n3. DWSQueriesToDWSRelay : ");
	if (CreateMsgQueue(QueryToRel , QueryToRel_SIZE) == ERROR )
	{
		logFatal("DWSQueriesToDWSRelay failed : ");
		exit(1);
	}
	printf("\n4. OrderRouterToOrderServerBSEEQ Is Removed Due Merging of NSE AND BSE EQ OrderSever : ");
	printf("4. OrderRouterToOrderServerBSEEQ : ");
	if (CreateMsgQueue(OrdRtrToOrdSrvBSEEQ , OrdRtrToOrdSrvBSEEQ_SIZE) == ERROR )
	{
		logFatal("OrderRouterToOrderServerBSEEQ failed : ");
		exit(1);
	}
	printf("\n5. OrderRouterToCatalystNSEEQ : ");
	if (CreateMsgQueue(OrdRtrToCatalystNSEEQ , OrdRtrToCatalystNSEEQ_SIZE) == ERROR )
	{
		logFatal("OrderRouterToCatalystNSEEQ failed : ");
		exit(1);
	}

	printf("\n6. CatalystToOrderServerNSEEQ : ");
	if (CreateMsgQueue(CatalystToOrdSrvNSEEQ , CatalystToOrdSrvNSEEQ_SIZE) == ERROR )
	{
		logFatal("CatalystToOrderServerNSEEQ failed : ");
		exit(1);
	}

	printf("\n7. OrderRouterToCatalystDR : ");
	if (CreateMsgQueue(OrdRtrToCatalystDR, OrdRtrToCatalystDR_SIZE) == ERROR )
	{
		logFatal("OrderRouterToCatalystDR failed : ");
		exit(1);
	}

	printf("\n8. OrderRouterToOrderServerNSECR : ");
	if (CreateMsgQueue(OrdRtrToOrdSrvNSECR , OrdRtrToOrdSrvNSECR_SIZE) == ERROR )
	{
		logFatal("OrderRouterToOrderServerNSECR failed : ");
		exit(1);
	}       
	printf("\n9. OrderRouterToOrderServerMCX : ");
	if (CreateMsgQueue(OrdRtrToOrdSrvMCX , OrdRtrToOrdSrvMCX_SIZE) == ERROR )
	{
		logFatal("OrderRouterToOrderServerMCX failed : ");
		exit(1);
	}

	printf("\n10. OrderServerToTradeRouter : ");
	if (CreateMsgQueue(OrdSrvToTrdRtr , OrdSrvToTrdRtr_SIZE) == ERROR )
	{
		logFatal("OrderServerToTradeRouter failed : ");
		exit(1);
	}

	printf("\n11. OrderServerToFwdMapBSEEQ Is Removed Due Merging of NSE AND BSE EQ OrderSever : ");
	  printf("11. OrderServerToFwdMapBSEEQ : ");
	  if (CreateMsgQueue(OrdSrvToFwdMapBSEEQ , OrdSrvToFwdMapBSEEQ_SIZE) == ERROR )
	  {
	  logFatal("OrderServerToFwdMapBSEEQ failed : ");
	  exit(1);
	  }
	printf("\n12. OrdSrvToMapperNSEEQ: ");
	if (CreateMsgQueue(OrdSrvToMapperNSEEQ, OrdSrvToMapperNSEEQ_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperNSEEQ failed : ");
		exit(1);
	}

	printf("\n13. OrdSrvToMapperNSEDR: ");
	if (CreateMsgQueue(OrdSrvToMapperNSEDR, OrdSrvToMapperNSEDR_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperNSEDR failed : ");
		exit(1);
	}

	//        printf("\n14. OrderServerToFwdMapNSECR Is Removed Due Merging of NSE AND BSE EQ OrderSever : ");
	printf("14. OrdSrvToMapperNSECR : ");
	if (CreateMsgQueue(OrdSrvToMapperNSECR  , OrdSrvToMapperNSECR_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperNSECR failed : ");
		exit(1);
	}
	printf("\n15. OrderServerToFwdMapMCX : ");
	if (CreateMsgQueue(OrdSrvToFwdMapMCX , OrdSrvToFwdMapMCX_SIZE) == ERROR )
	{
		logFatal("OrderServerToFwdMapMCX failed : ");
		exit(1);
	}

	printf("\n16. OrdSrvToMapperBSEEQ: ");
	if (CreateMsgQueue(OrdSrvToMapperBSEEQ, OrdSrvToMapperBSEEQ_SIZE) == ERROR )
	{
		logFatal("OrdSrvToMapperBSEEQ failed : ");
		exit(1);
	}


	printf("\n17. FwdMapToInterfaceNSEEQ : ");
	if (CreateMsgQueue(ConnToInterfaceNSEEQ, ConnToInterfaceNSEEQ_SIZE) == ERROR )
	{
		logFatal("FwdMapToInterfaceNSEEQ failed : ");
		exit(1);
	}

	  printf("\n18. ConnToInterfaceNSEDR: ");
	  if (CreateMsgQueue(ConnToInterfaceNSEDR, ConnToInterfaceNSEDR_SIZE) == ERROR )
	  {
	  logFatal("ConnToInterfaceNSEDR failed : ");
	  exit(1);
	  }

	  printf("\n19. ConnToInterfaceNSECR : ");
	  if (CreateMsgQueue(ConnToInterfaceNSECR, ConnToInterfaceNSECR_SIZE) == ERROR )
	  {
	  logFatal("failed : ");
	  exit(1);
	  }

	printf("\n20. FwdMapToInterfaceMCX : ");
	if (CreateMsgQueue(FwdMapToInterfaceMCX , FwdMapToInterfaceMCX_SIZE) == ERROR )
	{
		logFatal("FwdMapToInterfaceMCX failed : ");
		exit(1);
	}

	printf("\n21. ConnToTrdMapBSEEQ: ");
	if (CreateMsgQueue(ConnToTrdMapBSEEQ, ConnToTrdMapBSEEQ_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapBSEEQ failed : ");
		exit(1);
	}

	printf("\n22. ConnToTrdMapNSEEQ : ");
	if (CreateMsgQueue(ConnToTrdMapNSEEQ , ConnToTrdMapNSEEQ_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapNSEEQ failed : ");
		exit(1);
	}

	printf("\n23. ConnToTrdMapNSEDR : ");
	if (CreateMsgQueue(ConnToTrdMapNSEDR , ConnToTrdMapNSEDR_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapNSEDR failed : ");
		exit(1);
	}

	printf("\n24. ConnToTrdMapNSECR : ");
	if (CreateMsgQueue(ConnToTrdMapNSECR , ConnToTrdMapNSECR_SIZE) == ERROR )
	{
		logFatal("ConnToTrdMapNSECR failed : ");
		exit(1);
	}

	printf("\n25. InterfaceToRevMapMCX : ");
	if (CreateMsgQueue(InterfaceToRevMapMCX , InterfaceToRevMapMCX_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapMCX failed : ");
		exit(1);
	}

	printf("\n26. RevMapToTradeServerBSEEQ Is Removed due to Merging of NSE AND BSE TradeServer : ");
	printf("26. RevMapToTradeServerBSEEQ : ");
	if (CreateMsgQueue(RevMapToTrdSrvBSEEQ , RevMapToTrdSrvBSEEQ_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerBSEEQ failed : ");
		exit(1);
	}
	printf("\n27. RevMapToTradeServerNSEEQ : ");
	if (CreateMsgQueue(RevMapToTrdSrvNSEEQ , RevMapToTrdSrvNSEEQ_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerNSEEQ failed : ");
		exit(1);
	}

	printf("\n28. RevMapToTradeServerNSEDR : ");
	if (CreateMsgQueue(RevMapToTrdSrvNSEDR , RevMapToTrdSrvNSEDR_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerNSEDR failed : ");
		exit(1);
	}


	printf("\n29. RevMapToTradeServerNSECR : ");
	if (CreateMsgQueue(RevMapToTrdSrvNSECR , RevMapToTrdSrvNSECR_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerNSECR failed : ");
		exit(1);
	}      
	printf("\n30. RevMapToTradeServerMCX : ");
	if (CreateMsgQueue(RevMapToTrdSrvMCX , RevMapToTrdSrvMCX_SIZE) == ERROR )
	{
		logFatal("RevMapToTradeServerMCX failed : ");
		exit(1);
	}

	printf("\n31. TradeServerToRMS : ");
	if (CreateMsgQueue(TrdSrvToRMS , TrdSrvToRMS_SIZE) == ERROR )
	{
		logFatal("TradeServerToRMS failed : ");
		exit(1);
	}

	printf("\n32. TradeServerToTradeRouter : ");
	if (CreateMsgQueue(TrdSrvToTrdRtr , TrdSrvToTrdRtr_SIZE) == ERROR )
	{
		logFatal("TradeServerToTradeRouter failed : ");
		exit(1);
	}

	printf("\n33. TrdRtrToDWSMMap: ");
	if (CreateMsgQueue(TrdRtrToDWSMMap, TrdRtrToDWSMMap_SIZE) == ERROR )
	{
		logFatal("TrdRtrToRel failed : ");
		exit(1);
	}

	printf("\n34. TradeRouterToWebAdapter : ");
	if (CreateMsgQueue(TrdRtrToWebAdap , TrdRtrToWebAdap_SIZE) == ERROR )
	{
		logFatal("TradeRouterToWebAdapter failed : ");
		exit(1);
	}

	printf("\n35. ENBAdapToSpltr: ");
	if (CreateMsgQueue(ENBAdapToSpltr, ENBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("ENBAdapToSpltr failed: ");
		exit(1);
	}

	printf("\n39. TrdRtrToRevRmsVal: ");
	if (CreateMsgQueue(TrdRtrToRevRmsVal, TrdRtrToRevRmsVal_SIZE) == ERROR )
	{
		logFatal("TrdRtrToRevRmsVal failed : ");
		exit(1);
	}


	printf("\n40. RDaemonToSqoff: ");
	if (CreateMsgQueue(RDaemonToSqoff, RDaemonToSqoff_SIZE) == ERROR )
	{
		logFatal("RDaemonToSqoff failed : ");
		exit(1);
	}


	printf("\n41.RDaemonToOffPump is removed due to Merging of SqrOff & OffPump: ");
	  printf("41.RDaemonToOffPump: ");
	  if (CreateMsgQueue(RDaemonToOffPump, RDaemonToOffPump_SIZE) == ERROR)
	  {
	  logFatal("RDaemonToOffPump failed : ");
	  exit(1);
	  }
	
	  printf("42.D2C1ToAdminAdap: ");
	  if (CreateMsgQueue(D2C1ToAdminAdap, D2C1ToAdminAdap_SIZE) == ERROR )
	  {
	  	logFatal("D2C1ToAdminAdap failed : ");
	  	exit(1);
	  }
	 
	printf("\n43.TrdRtrToD2C1MMap: ");
	if (CreateMsgQueue(TrdRtrToD2C1MMap, TrdRtrToD2C1MMap_SIZE) == ERROR )
	{
		logFatal("TrdRtrToD2C1MMap failed : ");
		exit(1);
	}

	printf("\n44. OffPumperToOrdRtr: ");
	if (CreateMsgQueue(OffPumperToOrdRtr,OffPumperToOrdRtr_SIZE) == ERROR )
	{
		logFatal("OffPumperToOrdRtr failed : ");
		exit(1);
	}

	printf("\n45.OrdRtrToOffOrd: ");
	if (CreateMsgQueue(OrdRtrToOffOrd, OrdRtrToOffOrd_SIZE) == ERROR )
	{
		logFatal("OrdRtrToOffOrd failed : ");
		exit(1);
	}


	printf("\n46.OffOrdToTrdRtr: ");
	if (CreateMsgQueue(OffOrdToTrdRtr, OffOrdToTrdRtr_SIZE) == ERROR )
	{
		logFatal("OffOrdToTrdRtr failed: ");
		exit(1);
	}

	printf("\n47.DWSQryToAdap: ");
	if (CreateMsgQueue(DWSQryToAdap, DWSQryToAdap_SIZE) == ERROR )
	{
		logFatal("DWSQryToAdap failed: ");
		exit(1);
	}

	printf("\n48. TrdRtrToAdminMMap: ");
	if (CreateMsgQueue(TrdRtrToAdminMMap, TrdRtrToAdminMMap_SIZE) == ERROR )
	{
		logFatal("TrdRtrToAdminMMap failed: ");
		exit(1);
	}

	printf("\n49. D2C1ToDWSAdap: ");
	if (CreateMsgQueue(D2C1ToDWSAdap, D2C1ToDWSAdap_SIZE) == ERROR )
	{
		logFatal("D2C1ToDWSAdap failed: ");
		exit(1);
	}

	printf("\n50. DNBAdapToSpltr: ");
	if (CreateMsgQueue(DNBAdapToSpltr, DNBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("DNBAdapToSpltr failed: ");
		exit(1);
	}

	printf("\n51. CNBAdapToSpltr: ");
	if (CreateMsgQueue(CNBAdapToSpltr, CNBAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("CNBAdapToSpltr failed: ");
		exit(1);
	}

	printf("\n52. CNBSpltrToMbpUpld: ");
	if (CreateMsgQueue(CNBSpltrToMbpUpld, CNBSpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("CNBSpltrToMbpUpld failed: ");
		exit(1);
	}


	printf("\n53. DNBSpltrToMbpUpld: ");
	if (CreateMsgQueue(DNBSpltrToMbpUpld, DNBSpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("DNBSpltrToMbpUpld failed: ");
		exit(1);
	}
	printf("\n58. DNBcasttoMktStatus: ");
	if (CreateMsgQueue(DNBcasttoMktStatus, DNBcasttoMktStatus_SIZE) == ERROR )
	{
		logFatal("DNBcasttoMktStatus failed: ");
		exit(1);
	}
	printf("\n59. OrdRtrToCon2Del: ");
	if (CreateMsgQueue(OrdRtrToCon2Del, OrdRtrToCon2Del_SIZE) == ERROR )
	{
		logFatal("OrdRtrToCon2Del failed: ");
		exit(1);
	}
	printf("\n60. CurSpltrToMktStatus: ");
	if (CreateMsgQueue(CurSpltrToMktSts, CurSpltrToMktSts_SIZE) == ERROR )
	{
		logFatal("CurSpltrToMktSts failed: ");
		exit(1);
	}
	printf("\n61. MCXAdapToUpdtr: ");
	if (CreateMsgQueue(MCXAdapToUpdtr, MCXAdapToUpdtr_SIZE) == ERROR )
	{
		logFatal("MCXAdapToUpdtr failed: ");
		exit(1);
	}
	printf("\n62. CatalystToOrdSrvDRV: ");
	if (CreateMsgQueue(CatalystToOrdSrvDRV, CatalystToOrdSrvDRV_SIZE) == ERROR )
	{
		logFatal("CatalystToOrdSrvDRV failed: ");
		exit(1);
	}
	if (CreateMsgQueue(TrdRtrToSysMsg, TrdRtrToSysMsg_SIZE) == ERROR )
	{
		logFatal("TrdRtrToSysMsg failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBAAdapToSpltr, EBAAdapToSpltr_SIZE) == ERROR )
	{
		logFatal("EBAAdapToSpltr failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBASpltrToMbpUpld, EBASpltrToMbpUpld_SIZE) == ERROR )
	{
		logFatal("EBASpltrToMbpUpld failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBABSpltrToIdxUpld, EBABSpltrToIdxUpld_SIZE) == ERROR )
	{
		logFatal("EBASpltrToMbpUpld failed: ");
		exit(1);
	}

	if (CreateMsgQueue(EBABSpltrToMktSts, EBABSpltrToMktSts_SIZE) == ERROR )
	{
		logFatal("EBASpltrToMbpUpld failed: ");
		exit(1);
	}

	printf("\n64. OrdRtrToOrdSrvSIP: ");
	if(CreateMsgQueue(OrdRtrToOrdSrvSIP, OrdRtrToOrdSrvSIP_SIZE) == ERROR )
	{
		logFatal(" OrdRtrToOrdSrvSIP failed : ");
		exit(1);
	}

	printf("\n65. OrdSrvSIPToTrdRtr: ");
	if(CreateMsgQueue(OrdSrvSIPToTrdRtr, OrdSrvSIPToTrdRtr_SIZE) == ERROR )
	{
		logFatal(" OrdSrvSIPToTrdRtr failed : ");
		exit(1);
	}

	printf("\n66. OrdRtrToCatalystSIP_EQ:");
	if(CreateMsgQueue(OrdRtrToCatalystSIP_EQ, OrdRtrToCatalystSIP_EQ_SIZE) == ERROR )
	{
		logFatal(" OrdRtrToCatalystSIP_EQ failed : ");
		exit(1);
	}

	printf("\n67. EquNSEToRmsNse:");
	if(CreateMsgQueue(EquNSEToRmsNse, EquNSEToRmsNse_SIZE) == ERROR )
	{
		logFatal(" EquNSEToRmsNse : ");
		exit(1);
	}

	printf("\n68. DrvNseToRmsnse:");
	if (CreateMsgQueue (DrvNseToRmsnse, DrvNseToRmsnse_SIZE) == ERROR )
	{
		logFatal(" DrvNseToRmsnse : ");
		exit(1);
	}

	printf("\n69. CurrNseToRmsnse :");
	if (CreateMsgQueue (CurrNseToRmsnse , CurrNseToRmsnse_SIZE) == ERROR )
	{
		logFatal ("CurrNseToRmsnse :");
		exit(1);
	}

	printf("\n72. MapperToConnBSEEQ:");
	if (CreateMsgQueue (MapperToConnBSEEQ, MapperToConnBSEEQ_SIZE) == ERROR )
	{
		logFatal ("MapperToConnBSEEQ:");
		exit(1);
	}

	printf("\n77. MapperToConnNSEEQ : ");
	if (CreateMsgQueue(MapperToConnNSEEQ , MapperToConnNSEEQ_SIZE) == ERROR )
	{
		logFatal("MapperToConnNSEEQ failed : ");
		exit(1);
	}

	printf("\n78. MapperToConnNSEFO: ");
	if (CreateMsgQueue(MapperToConnNSEFO, MapperToConnNSEFO_SIZE) == ERROR )
	{
		logFatal("MapperToConnNSEFO failed : ");
		exit(1);
	}

	printf("\n79. MapperToConnNSECD: ");
	if (CreateMsgQueue(MapperToConnNSECD, MapperToConnNSECD_SIZE) == ERROR )
	{
		logFatal("MapperToConnNSECD failed : ");
		exit(1);
	}

	printf("\n80. OrdRtrToDeaNotify: ");
	if (CreateMsgQueue(OrdRtrToDeaNotify, OrdRtrToDeaNotify_SIZE) == ERROR )
	{
		logFatal("OrdRtrToDeaNotify failed : ");
		exit(1);
	}
	printf("\n81. MmapToENMapTrd: ");
	if (CreateMsgQueue(MmapToENMapTrd, MmapToENMapTrd_SIZE) == ERROR )
	{
		logFatal("MmapToENMapTrd failed : ");
		exit(1);
	}
	printf("\n82. MmapToRevRmsVal: ");
	if (CreateMsgQueue(MmapToRevRmsVal , MmapToRevRmsVal_SIZE) == ERROR )
	{
		logFatal("MmapToRevRmsVal failed : ");
		exit(1);
	}
	printf("\n83. BOTradeSvrToPumper : ");
	if (CreateMsgQueue(BOTradeSvrToPumper , BOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("BOTradeSvrToPumper failed : ");
		exit(1);
	}
	printf("\n84. DrBOTradeSvrToPumper : ");
	if (CreateMsgQueue(DrBOTradeSvrToPumper , DrBOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("DrBOTradeSvrToPumper failed : ");
		exit(1);
	}

	printf("\n85. ENMbpToLTPUpd: ");
	if (CreateMsgQueue(ENMbpToLTPUpd, ENMbpToLTPUpd_SIZE) == ERROR )
	{
		logFatal("ENMbpToLTPUpd failed : ");
		exit(1);
	}
	printf("\n86. CurBOTradeSvrToPumper: ");
	if (CreateMsgQueue(CurBOTradeSvrToPumper, CurBOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("CurBOTradeSvrToPumper failed : ");
		exit(1);
	}
	printf("\n87. CatalystToRmsVal: ");
	if (CreateMsgQueue(CatalystToRmsVal, CatalystToRmsVal_SIZE) == ERROR)
	{
		logFatal("CatalystToRmsVal failed:");
		exit(1);
	}

	printf("\n88. RDaemonToMtmSqoff : ");
	if (CreateMsgQueue(RDaemonToMtmSqoff , RDaemonToMtmSqoff_SIZE) == ERROR)
	{
		logFatal("RDaemonToMtmSqoff failed:");
		exit(1);
	}

	printf("\n89. AdaptorToQuery : ");
	if(CreateMsgQueue(AdaptorToQuery ,AdaptorToQuery_SIZE) == ERROR)
	{
		logFatal("AdaptorToQuery failed:");
		exit(1);
	}

	printf("\n90. AdminQueriesToAdaptor :");
	if(CreateMsgQueue(AdminQueriesToAdaptor , AdminQueriesToAdaptor_SIZE) == ERROR)
	{
		logFatal("AdminQueriesToAdaptor failed");
		exit(1);
	}
	printf("\n93 . OrdRtrToAdminMsg :");
	if(CreateMsgQueue(OrdRtrToAdminMsg , OrdRtrToAdminMsg_SIZE) == ERROR)
	{
		logFatal("OrdRtrToAdminMsg failed");
		exit(1);
	}

	printf("\n90. AdaptorToAdminQry : ");
	if(CreateMsgQueue(AdaptorToAdminQry,AdaptorToAdminQry_SIZE) == ERROR)
	{
		logFatal("AdaptorToAdminQry failed:");
		exit(1);
	}

	printf("\n91. BEBOTradeSvrToPumper : ");
	if (CreateMsgQueue(BEBOTradeSvrToPumper ,BEBOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("BEBOTradeSvrToPumper failed : ");
		exit(1);
	}

	printf("\n94.  AdapToRangeQry :");
	if (CreateMsgQueue(AdapToRangeQry,AdapToRangeQry) == ERROR )
	{
		logFatal("AdapToRangeQry failed : ");
		exit(1);
	}

	printf("\n95.  RangeQryToAdap  :");
	if (CreateMsgQueue(RangeQryToAdap,RangeQryToAdap) == ERROR )
	{
		logFatal("RangeQryToAdap failed : ");
		exit(1);
	}

	printf("\n96.  InterfaceToRevMapNSEEQ  :");
	if (CreateMsgQueue(InterfaceToRevMapNSEEQ,InterfaceToRevMapNSEEQ_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEEQ failed : ");
		exit(1);
	}

	printf("\n97.  InterfaceToRevMapNSEDR  :");
	if (CreateMsgQueue(InterfaceToRevMapNSEDR,InterfaceToRevMapNSEDR_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}

	printf("\n98.  OrdSrvToFwdMapNSEEQ  :");
	if (CreateMsgQueue(OrdSrvToFwdMapNSEEQ,OrdSrvToFwdMapNSEEQ_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}

	printf("\n99.  FwdMapToInterfaceNSEEQ  :");
	if (CreateMsgQueue(FwdMapToInterfaceNSEEQ,FwdMapToInterfaceNSEEQ_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}

	printf("\n99.  TrdSvrEQToBoTrailer:");
	if (CreateMsgQueue(TrdSvrEQToBoTrailer,TrdSvrEQToBoTrailer_SIZE) == ERROR )
	{
		logFatal("InterfaceToRevMapNSEDR failed : ");
		exit(1);
	}
	printf("\n100.  EQCOTradeSvrToPumper:");
	if (CreateMsgQueue(EQCOTradeSvrToPumper,EQCOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("EQCOTradeSvrToPumper_SIZE failed : ");
		exit(1);
	}
	printf("\n101.  FoCrCOTradeSvrToPumper:");
	if (CreateMsgQueue(FoCrCOTradeSvrToPumper,FoCrCOTradeSvrToPumper_SIZE) == ERROR )
	{
		logFatal("FoCrCOTradeSvrToPumper failed : ");
		exit(1);
	}

	printf("\n105.  OrderRtrToCalMrg:");
	if (CreateMsgQueue(OrderRtrToCalMrg,OrderRtrToCalMrg_SIZE) == ERROR )
	{
		logFatal("OrderRtrToCalMrg failed : ");
		exit(1);
	}
	printf("\n106.  OrderRtrToCalMrgCat:");
        if (CreateMsgQueue(OrderRtrToCalMrgCat,OrderRtrToCalMrgCat_SIZE) == ERROR )
        {
                logFatal("OrderRtrToCalMrgCat failed : ");
                exit(1);
        }

	printf("\n108.  MCXCOTradeSvrToPumper:");
        if (CreateMsgQueue(MCXCOTradeSvrToPumper,MCXCOTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("MCXCOTradeSvrToPumper failed : ");
                exit(1);
        }

	printf("\n107.  BEqBoTradeSvrToPumper:");
        if (CreateMsgQueue(BEqBoTradeSvrToPumper,BEqBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BEqBoTradeSvrToPumper failed : ");
                exit(1);
        }

	printf("\n109.  CatalystToOrdSrvCOMM:");
        if (CreateMsgQueue(CatalystToOrdSrvCOMM,CatalystToOrdSrvCOMM_SIZE) == ERROR )
        {
                logFatal("CatalystToOrdSrvCOMM failed : ");
                exit(1);
        }

	printf("\n110.  DWSQryToAdap:");
        if (CreateMsgQueue(DWSQryToAdap,DWSQryToAdap_SIZE) == ERROR )
        {
                logFatal("DWSQryToAdapfailed : ");
                exit(1);
        }
	
	printf("\n111.  MmapToAdmnTrdRtr:");
        if (CreateMsgQueue(MmapToAdmnTrdRtr,MmapToAdmnTrdRtr_SIZE) == ERROR )
        {
                logFatal("MmapToTrdRtrAdmn failed : ");
                exit(1);
        }
        printf("\n112.  MmapToD2C1:");
        if (CreateMsgQueue(MmapToD2C1,MmapToD2C1_SIZE) == ERROR )
        {
                logFatal("MmapToD2C1 failed : ");
                exit(1);
        }
        printf("\n113.  AdmTrdRtrToAdmAdap:");
        if (CreateMsgQueue(AdmTrdRtrToAdmAdap,AdmTrdRtrToAdmAdap_SIZE) == ERROR )
        {
                logFatal("AdmTrdRtrToAdmAdap failed : ");
                exit(1);
        }

	printf("\n114.  MmapToDWSTrdRtr:");
        if (CreateMsgQueue(MmapToDWSTrdRtr,MmapToDWSTrdRtr_SIZE) == ERROR )
        {
                logFatal("MmapToDWSTrdRtr failed : ");
                exit(1);
        }

        printf("\n115.  DWSTrdRtrToDWSAdp:");
        if (CreateMsgQueue(DWSTrdRtrToDWSAdp,DWSTrdRtrToDWSAdp_SIZE) == ERROR )
        {
                logFatal("DWSTrdRtrToDWSAdp failed : ");
                exit(1);
        }
	
	if (CreateMsgQueue(OrdRtrToOrdSrvBSECD , OrdRtrToOrdSrvBSECD_SIZE) == ERROR )
        {
                logFatal("OrderRouterToOrderServerBSECD failed : ");
                exit(1);
        }
        printf("\n116. OrderRouterToOrderServerBSECD : ");

        if (CreateMsgQueue(OrdSrvToMapperBSECD , OrdSrvToMapperBSECD_SIZE) == ERROR )
        {
                logFatal("OrdSrvToMapperBSECD failed : ");
                exit(1);
        }
        printf("\n117. OrdSrvToMapperBSECD : ");

        if (CreateMsgQueue(MapperToConnBSECD , MapperToConnBSECD_SIZE) == ERROR )
        {
                logFatal("MapperToConnBSECD failed : ");
                exit(1);
        }
        printf("\n118. ConnToTrdMapBSECD : ");

        if (CreateMsgQueue(ConnToTrdMapBSECD , ConnToTrdMapBSECD_SIZE) == ERROR )
        {
                logFatal("ConnToTrdMapBSECD failed : ");
                exit(1);
        }
        printf("\n119. ConnToTrdMapBSECD : ");

        if (CreateMsgQueue(RevMapToTrdSrvBSECD , RevMapToTrdSrvBSECD_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSECD failed : ");
                exit(1);
        }
        printf("\n120. RevMapToTrdSrvBSECD : ");

        if (CreateMsgQueue(BCdBoTradeSvrToPumper , BCdBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BCdBoTradeSvrToPumper failed : ");
                exit(1);
        }
        printf("\n121. BCdBoTradeSvrToPumper : ");



        if (CreateMsgQueue(TrdSvrCDToBoTrailer , TrdSvrCDToBoTrailer_SIZE) == ERROR )
        {
                logFatal("TrdSvrCDToBoTrailer failed : ");
                exit(1);
        }
        printf("\n122. TrdSvrCDToBoTrailer : ");

        if (CreateMsgQueue(DNMbpToLtpUdr, DNMbpToLtpUdr_SIZE) == ERROR )
        {
                logFatal("DNMbpToLtpUdr failed : ");
                exit(1);
        }
        printf("\n128. DNMbpToLtpUdr: ");

        if (CreateMsgQueue(CNMbpToLtpUdr, CNMbpToLtpUdr_SIZE) == ERROR )
        {
                logFatal("CNMbpToLtpUdr failed : ");
                exit(1);
        }
        printf("\n129. CNMbpToLtpUdr : ");

        if (CreateMsgQueue(ComMbpToLtpUdr, ComMbpToLtpUdr_SIZE) == ERROR )
        {
                logFatal("ComMbpToLtpUdr failed : ");
                exit(1);
        }
        printf("\n130. ComMbpToLtpUdr : ");

//======================================================================================//
        if (CreateMsgQueue(OrdRtrToBComOrderSvr, OrdRtrToBComOrderSvr_SIZE) == ERROR )
        {
                logFatal("OrdRtrToBComOrderSvr failed : ");
                exit(1);
        }
        printf("\n131. OrdRtrToBComOrderSvr : ");


        if (CreateMsgQueue(BComOrdToSvrMapper, BComOrdToSvrMapper_SIZE) == ERROR )
        {
                logFatal("BComOrdToSvrMapper failed : ");
                exit(1);
        }
        printf("\n132. BComOrdToSvrMapper : ");


        if (CreateMsgQueue(BComMapToConn, BComMapToConn_SIZE) == ERROR )
        {
                logFatal("BComMapToConn failed : ");
                exit(1);
        }
        printf("\n133. BComMapToConn : ");


        if (CreateMsgQueue(BComConToRevMap, BComConToRevMap_SIZE) == ERROR )
        {
                logFatal("BComConToRevMap failed : ");
                exit(1);
        }
        printf("\n134. BComConToRevMap : ");

	
        if (CreateMsgQueue(BComRevMapToTrdSvr, BComRevMapToTrdSvr) == ERROR )
        {
                logFatal("BComRevMapToTrdSvr failed : ");
                exit(1);
        }
        printf("\n135. BComRevMapToTrdSvr : ");


        if (CreateMsgQueue(BComTrdSvrTrdRtr, BComTrdSvrTrdRtr_SIZE) == ERROR )
        {
                logFatal("BComTrdSvrTrdRtr failed : ");
                exit(1);
        }
        printf("\n136. BComTrdSvrTrdRtr : ");


        if (CreateMsgQueue(BComOrdSvrToTrdRtr, BComOrdSvrToTrdRtr_SIZE) == ERROR )
        {
                logFatal("BComOrdSvrToTrdRtr failed : ");
                exit(1);
        }
        printf("\n137. BComOrdSvrToTrdRtr : ");

//=================================================================================

	if (CreateMsgQueue(OrdRtrToCatalystNseCM, OrdRtrToCatalystNseCM_SIZE) == ERROR )
	{
		logFatal("OrdRtrToCatalystNseCM Failed : ");
		exit(1);
	}
	printf("\n138. OrdRtrToCatalystNseCM : ");

	if (CreateMsgQueue(CatalystToOrdSvrNseCM, CatalystToOrdSvrNseCM_SIZE) == ERROR)
	{
		logFatal("CatalystToOrdSvrNseCM Failed : ");
		exit(1);
	}
	printf("\n139. CatalystToOrdSvrNseCM : ");

	if (CreateMsgQueue(OrdSvrCMToTrdRtrCM, OrdSvrCMToTrdRtrCM_SIZE) == ERROR)
	{
		logFatal("OrdSvrCMToTrdRtrCM Failed : ");
		exit(1);
	}
	printf("\n140. OrdSvrCMToTrdRtrCM : ");

	if (CreateMsgQueue(OrdSvrCMToMapperNseCM, OrdSvrCMToMapperNseCM_SIZE) == ERROR)
	{
		logFatal("OrdSvrCMToMapperNseCM Failed : ");
		exit(1);
	}
	printf("\n141. OrdSvrCMToMapperNseCM : ");

	if (CreateMsgQueue(MapperNseCMToConNseCM, MapperNseCMToConNseCM_SIZE) == ERROR)
	{
		logFatal("MapperNseCMToConNseCM Failed : ");
		exit(1);
	}
	printf("\n142. MapperNseCMToConNseCM : ");

	if (CreateMsgQueue(ConNseCMToTrdMapNseCM, ConNseCMToTrdMapNseCM_SIZE) == ERROR)
	{
		logFatal("ConNseCMToTrdMapNseCM Failed : ");
		exit(1);
	}
	printf("\n143. ConNseCMToTrdMapNseCM : ");

	if (CreateMsgQueue(RevMapNseCMToTrdSvrCM, RevMapNseCMToTrdSvrCM_SIZE) == ERROR)
	{
		logFatal("RevMapNseCMToTrdSvrCM Failed : ");
		exit(1);
	}
	printf("\n144. RevMapNseCMToTrdSvrCM : ");

	if (CreateMsgQueue(TrdSvrCMToTrdRtrCM, TrdSvrCMToTrdRtrCM_SIZE ) == ERROR)
	{
		logFatal("TrdSvrCMToTrdRtrCM Failed : ");
		exit(1);
	}
	printf("\n145. TrdSvrCMToTrdRtrCM : ");


	if (CreateMsgQueue(TrdRtrToTradeMobMMap, TrdRtrToTradeMobMMap_SIZE ) == ERROR)
	{
		logFatal("TrdRtrToTradeMobMMap Failed : ");
		exit(1);
	}
	printf("\n146. TrdRtrToTradeMobMMap : ");


	if (CreateMsgQueue(MmapToNotifyFE, MmapToNotifyFE_SIZE ) == ERROR)
	{
		logFatal("MmapToNotifyFE Failed : ");
		exit(1);
	}
	printf("\n146. MmapToNotifyFE : ");

        printf("\n147. CMCOBOTradeSvrToPumper : ");
        if (CreateMsgQueue(ComCOBOTradeSvrToPumper , ComCOBOTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("ComCOBOTradeSvrToPumper failed : ");
                exit(1);
        }



	 if (CreateMsgQueue(OrdSrvToMapperBSEDR, OrdSrvToMapperBSEDR_SIZE ) == ERROR)
        {
                logFatal("OrdSrvToMapperBSEDR Failed : ");
                exit(1);
        }
        printf("\n150. OrdSrvToMapperBSEDR : ");


 	if (CreateMsgQueue(OrdRtrToOrdSrvBSEDR, OrdRtrToOrdSrvBSEDR_SIZE ) == ERROR)
        {
                logFatal("OrdRtrToOrdSrvBSEDR Failed : ");
                exit(1);
        }
        printf("\n151. OrdRtrToOrdSrvBSEDR : ");

	if (CreateMsgQueue(MapperToConnBSEDR, MapperToConnBSEDR_SIZE) == ERROR )
        {
                logFatal("MapperToConnBSEDR failed : ");
                exit(1);
        }

	 printf("\n152. MapperToConnBSEDR : ");


	if (CreateMsgQueue(ConnToTrdMapBSEDR , ConnToTrdMapBSEDR_SIZE) == ERROR )
        {
                logFatal("ConnToTrdMapBSEDR failed : ");
                exit(1);
        }
        printf("\n153. ConnToTrdMapBSEDR : ");





if (CreateMsgQueue(RevMapToTrdSrvBSEDR , RevMapToTrdSrvBSEDR_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSEDR failed : ");
                exit(1);
        }
        printf("\n154. RevMapToTrdSrvBSEDR : ");

if (CreateMsgQueue(RevMapToTrdSrvBSEDR , RevMapToTrdSrvBSEDR_SIZE) == ERROR )
        {
                logFatal("RevMapToTrdSrvBSEDR failed : ");
                exit(1);
        }
        printf("\n155. RevMapToTrdSrvBSEDR : ");


if (CreateMsgQueue(BDrBoTradeSvrToPumper , BDrBoTradeSvrToPumper_SIZE) == ERROR )
        {
                logFatal("BDrBoTradeSvrToPumper failed : ");
                exit(1);
        }
        printf("\n156. BDrBoTradeSvrToPumper : ");


if (CreateMsgQueue(TrdSvrDRToBoTrailer , TrdSvrDRToBoTrailer_SIZE) == ERROR )
        {
                logFatal("TrdSvrDRToBoTrailer failed : ");
                exit(1);
        }
        printf("\n157. TrdSvrDRToBoTrailer : ");


	printf("\n-------------------------- END Creating Queues ------------------------------");

	logTimestamp("Exit  CreateSeed: [main]");
	exit(0);
****/
}

BOOL	CheckLicense()
{
	FILE	*fPointer,*Open;
	CHAR	sReadBuf[50];
	CHAR	sUnixDate[20];
	LONG64	iLicendate,iTodaydate;

	memset(sReadBuf,'\0',50);
	//memset(sUnixDate,'\0',20);

	fPointer = fopen("License.ini","rb");		

	if(fPointer == NULL)
	{
	//	logFatal("Error in Opening File");
		perror("");
		return FALSE;
	}

	fread(sReadBuf,sizeof(sReadBuf),1,fPointer);	

	//	printf("Encrypted sReadBuf :%s:\n",sReadBuf);

	Unscramble(sReadBuf);		

	//	printf("Dencrypted sReadBuf :%s:\n",sReadBuf);

	Open = popen("date '+%s'","r");

	if(fgets(sUnixDate, sizeof(sUnixDate), Open) == NULL)
	{
		printf("Some Error Occured\n");
		exit(1);
	}
	//        printf("sUnixDate :%s:\n",sUnixDate);

	iLicendate = atol(sReadBuf);
	iTodaydate = atol(sUnixDate);

	printf("iLicendate :%ld:\n",iLicendate);
	printf("iTodaydate :%ld:\n",iTodaydate);

	if(iLicendate > iTodaydate)
	{
		return TRUE;	
	}
	else
	{
		return FALSE;
	}	

}

void Unscramble(char *sStr)
{
	int i =0 ;
	for(i = strlen(sStr) - 1; i >= 0; i--)
	{
		//printf("%c\n",sStr[i]);
		if((sStr[i] - i) < min)
		{
			sStr[i] = max - (min - (sStr[i] - i));
		}
		else
		{
			sStr[i] = sStr[i] - i;
		}
	}
}


