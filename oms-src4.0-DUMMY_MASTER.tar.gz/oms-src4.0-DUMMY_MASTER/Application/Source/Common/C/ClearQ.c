#define MAX_QUEUES  30

main (int argc, char ** argv)
{
	int LogQId;
	int Key;
	int i ;

	if(argc != 2)
	{
		printf ("\n Wrong call \n");
		exit(1);
	}

	Key =  atoi(argv[1]);

	printf("\nTrying to Clear %d",Key );

	/*     if (ClearQ(LogQId,Key)==ERROR)*/
	if (ClearQ( Key ,Key)== -1)
	{
		printf ("\n error in reading Q \n");
		exit (1);
	}
	else
		printf("\nSuccessfully cleared ");
}

