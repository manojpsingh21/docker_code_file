#include<stdio.h>
#include<string.h>
#include<mysql.h>
#include <stdlib.h>
#define min 40
#define max 125


int DBConnect();
void Unscramble(char *sStr);
int flag;

char sFrom[10];
char sTo[10];

main(int argc, char *argv[])
{
	//printf("argc :%d:",argc);

	if(argv[1] == NULL)
	{
		printf("No Option Set\n");
		exit(1);
	}
	else
	{	
		flag = atoi(argv[1]);
	}
	if(atoi(argv[1]) == 9)
        {
		strncpy(sFrom,argv[2],10);
		strncpy(sTo,argv[3],10);
//		printf("%s\n",sFrom);
//		printf("%s\n",sTo);
        }

	int iReturnvalue;
	//	printf("Flag is = :%d:\n",flag);
	iReturnvalue = DBConnect();
	if(iReturnvalue != 1)
	{
		//		printf("Failed to Coonect DB \n");
		printf("FAILED\n");
	}
	//	printf("EXIT Main \n");
	exit(0);	
}


int DBConnect()
{
	//	printf("Entry : [DBConnect]\n");
	char sDbUser[20];
	char sDbPasswd[20];
	char sSchema[20];
	char sHostIP[75];
	char sGroupId[10];

	char    Pr_Query [6000];
	char    sResult [6000];
	int iError;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	int iStatus =0;

	int Count;
	int EQ_COUNT;
	int DRV_COUNT;
	int COMM_COUNT; 
	char status[1500];
	memset(sDbUser,'\0',20);
	memset(sDbPasswd,'\0',20);
	memset(sSchema,'\0',20);
	memset(sHostIP,'\0',75);
	memset(sGroupId,'\0',10);

	MYSQL *DB_Con = mysql_init(NULL);

	strncpy(sDbUser,getenv("MYSQL_USER"),20);
	strncpy(sDbPasswd,getenv("MYSQL_PASS"),20);
	strncpy(sSchema,getenv("MYSQL_DB"),20);
	strncpy(sHostIP,getenv("MYSQL_HOST"),75);
	strncpy(sGroupId,getenv("GROUP_ID"),10);

	if (DB_Con == NULL)
	{
		perror("Error Got Here = :");
		return 0;
	}

	my_bool reconnect = 1;

	if (mysql_options(DB_Con, MYSQL_OPT_RECONNECT, &reconnect)) 
	{
		printf("MYSQL_OPT_RECONNECT SET FAILED.\n");
		return 0;
	}
	else
	{
		//		printf("MYSQL_OPT_RECONNECT SET SUCCESS.\n");
	}

	//	printf("sHostIP      :%s:\n",sHostIP);
	//	printf("sDbUser      :%s:\n",sDbUser);
	//	printf("sDbPasswd    :%s:\n",sDbPasswd);
	//	printf("sSchema      :%s:\n",sSchema);

	Unscramble(sDbPasswd);
	Unscramble(sSchema);
	//	printf("sSchema :%s: sDbPasswd :%s:\n",sSchema,sDbPasswd);
	//logDebug2("sSchema :%s: sDbPasswd :%s:",sSchema,sDbPasswd);

	//if (mysql_real_connect(DB_Con, "localhost", "root", "rupeesql", "rupeeSQLDB", 0, NULL, 0) == NULL){
	//	for(Count = 0; Count < NoofTry; Count++)
	if (mysql_real_connect(DB_Con, sHostIP, sDbUser, sDbPasswd, sSchema, 0, NULL, 0) == NULL)
	{
		//			perror("Error Got in mysql_real_connect = :");
		printf("Failed To Connect ");
		return 0;

	}

	if(flag == 1) //This is to Check the status of Database
	{

		if(mysql_set_server_option(DB_Con,CLIENT_MULTI_STATEMENTS) == 0)
		{
			//		printf("mysql_set_server_option SUCCESS\n");
		}
		else
		{
			//		printf("mysql_set_server_option FAILED\n");
			return 0;
		}


		sprintf(Pr_Query,"call ALL_PROCESS_TEST(@zstatus);\
				select @ZSTATUS;");

		//	printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			//	perror("Error in Calling Procedure \n");
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
			return 0;
		}
		do{
			Res = mysql_store_result(DB_Con);
			if(Res)
			{
				if((Row = mysql_fetch_row(Res)))
				{
					strncpy(status,Row[0],10);
					mysql_free_result(Res);
					printf("%s\n", status);

				}
			}
			else
			{
				//		printf("No Result Set \n");
			}

			if((iStatus =mysql_next_result(DB_Con)) > 0)
			{
				//		printf("Could not execute statement :%d:\n",iStatus);
			}


		}while(iStatus == 0);

	}
	else if ( flag == 2 ) //This is for EOD_BOD
	{
		sprintf(Pr_Query,"select concat(BP_EXCH_ID,'-', BP_SEGMENT, '~', BP_BATCH_NAME, '~',  BP_LAST_RUN_DATE, '~', (UNIX_TIMESTAMP(CONCAT(DATE(p.bp_date),\
                         ' ', DATE_FORMAT(p.bp_schedule_time, '%%H:%%i:%%s'))) - UNIX_TIMESTAMP(NOW())), IF((UNIX_TIMESTAMP(CONCAT(DATE(p.bp_date), ' ', \
                        DATE_FORMAT(p.bp_schedule_time, '%%H:%%i:%%s'))) - UNIX_TIMESTAMP(NOW())) > 0,'~Success','~Failed')) from BATCH_PROCESS p \
                        where p.BP_BATCH_NAME = 'EOD_BOD' AND p.BP_MODE = 'A';");

		//	printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//	int iNumRow = mysql_num_rows(Res);
		//	printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res)) 
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}
	else if ( flag == 3 ) //This is For File Uploads
	{
		sprintf(Pr_Query," SELECT  concat(ifnull(PROCESS_DATE,DATE('0001-01-01')), '~', PROCESS, '~',\
			SUCCESS_FLAG, '~', PROCESS_STATUS, '~', SUCCESS, '~', REJECTED, '~', \
				(UNIX_TIMESTAMP(BP_LAST_RUN_DATE) - UNIX_TIMESTAMP(ifnull(PROCESS_DATE,DATE('0001-01-01'))))) \
			FROM RMS_PROCESS_LOG R LEFT JOIN BATCH_PROCESS B ON (BP_BATCH_NAME \
					= 'EOD_BOD' AND BP_EXCH_ID = 'NSE' AND BP_SEGMENT = 'E');");

		// sprintf(Pr_Query," select concat(ifnull(PROCESS_DATE,DATE('0001-01-01')), '~', PROCESS, '~', SUCCESS_FLAG, '~', PROCESS_STATUS,\
		'~', SUCCESS, '~', REJECTED) from RMS_PROCESS_LOG;");
		//select concat(PROCESS_DATE, '~', PROCESS, '~', SUCCESS_FLAG, '~', PROCESS_STATUS, \
		'~', SUCCESS, '~', REJECTED) from RMS_PROCESS_LOG;");

		//      printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}
	else if ( flag == 4 ) //This is For Square_off
	{
		sprintf(Pr_Query,"SELECT concat(BP_EXCH_ID, '-', BP_SEGMENT, IF(BP_EXCH_ID = 'MCX',concat('-',BP_MKT_TYPE_NO),''),'~', BP_BATCH_NAME, '~',\
                        BP_LAST_RUN_DATE, '~', (UNIX_TIMESTAMP(CONCAT(DATE(p.BP_NEXT_SCHEDULE_DATE), ' ', DATE_FORMAT(p.bp_schedule_time, '%%H:%%i:%%s'))) - \
                         UNIX_TIMESTAMP(NOW()))) FROM BATCH_PROCESS p WHERE p.BP_BATCH_NAME LIKE '%%SQ_OFF' AND p.BP_MODE = 'A' AND p.BP_GROUP_ID = '%s';",sGroupId);


		//      printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//    int iNumRow = mysql_num_rows(Res);
		//  printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}

	else if ( flag == 5)	//This is for Offline Market
	{

		sprintf(Pr_Query,"SELECT concat(BP_EXCH_ID, '-', BP_SEGMENT, IF(BP_EXCH_ID = 'MCX',concat('-',BP_MKT_TYPE_NO),''),'~', BP_BATCH_NAME, '~',\
                        BP_LAST_RUN_DATE, '~', (UNIX_TIMESTAMP(CONCAT(DATE(p.BP_NEXT_SCHEDULE_DATE), ' ', DATE_FORMAT(p.bp_schedule_time, '%%H:%%i:%%s'))) - \
                        UNIX_TIMESTAMP(NOW()))) FROM BATCH_PROCESS p WHERE p.BP_BATCH_NAME = 'OFFMKT_PUMP' AND p.BP_MODE = 'A' AND p.BP_GROUP_ID = '%s';",sGroupId);
		//      printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//    int iNumRow = mysql_num_rows(Res);
		//  printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}

	else if ( flag == 6 ) //This is For Transit Orders
	{

		//      printf("Pr_Query = %s\n",Pr_Query);

		sprintf(Pr_Query,"SELECT CONCAT('NSE-E~', NSE_EQ_TRANS_COUNT, '|', 'BSE-E~', BSE_EQ_TRANS_COUNT, '|', 'NSE-D~', NSE_DRV_TRANS_COUNT, '|', 'BSE-D~', BSE_DRV_TRANS_COUNT, '|', 'NSE-C~', NSE_CURR_TRANS_COUNT, '|', 'BSE-C~', BSE_CURR_TRANS_COUNT, '|', 'NSE-M~', NSE_COMM_TRANS_COUNT, '|', 'MCX-M~', MCX_COMM_TRANS_COUNT) FROM (SELECT GROUP_CONCAT(CASE WHEN EQ = 'EQ' AND NSE = 'NSE' THEN EQ_TRANS_COUNT END) NSE_EQ_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'EQ' AND NSE = 'BSE' THEN EQ_TRANS_COUNT END) BSE_EQ_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'DR' AND NSE = 'NSE' THEN EQ_TRANS_COUNT END) NSE_DRV_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'DR' AND NSE = 'BSE' THEN EQ_TRANS_COUNT END) BSE_DRV_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'CDS' AND NSE = 'NSE' THEN EQ_TRANS_COUNT END) NSE_CURR_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'CDS' AND NSE = 'BSE' THEN EQ_TRANS_COUNT END) BSE_CURR_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'COM' AND NSE = 'NSE' THEN EQ_TRANS_COUNT END) NSE_COMM_TRANS_COUNT, GROUP_CONCAT(CASE WHEN EQ = 'COM' AND NSE = 'MCX' THEN EQ_TRANS_COUNT END) MCX_COMM_TRANS_COUNT FROM (SELECT COUNT(*) EQ_TRANS_COUNT, 'EQ', 'NSE' FROM EQ_ORDERS E, (SELECT MAX(C.EQ_SERIAL_NO) AS SER, C.EQ_ORDER_NO as ORDR_NO, C.EQ_LEG_NO AS LEG_NO FROM EQ_ORDERS C WHERE C.EQ_EXCH_ID = 'NSE' GROUP BY C.EQ_ORDER_NO, C.EQ_LEG_NO) as X WHERE E.EQ_ORDER_NO = X.ORDR_NO 		AND E.EQ_LEG_NO = X.LEG_NO 		AND E.EQ_SERIAL_NO = X.SER AND E.EQ_ORD_STATUS = 'E' 		AND E.EQ_EXCH_ID = 'NSE' UNION ALL SELECT COUNT(*) EQ_TRANS_COUNT, 'EQ', 'BSE' FROM EQ_ORDERS E, (SELECT MAX(C.EQ_SERIAL_NO) AS SER, C.EQ_ORDER_NO as ORDR_NO, C.EQ_LEG_NO AS LEG_NO FROM EQ_ORDERS C WHERE C.EQ_EXCH_ID = 'BSE' GROUP BY C.EQ_ORDER_NO, C.EQ_LEG_NO) as X WHERE E.EQ_ORDER_NO = X.ORDR_NO 		AND E.EQ_LEG_NO = X.LEG_NO 		AND E.EQ_SERIAL_NO = X.SER AND E.EQ_ORD_STATUS = 'E' 		AND E.EQ_EXCH_ID = 'BSE' UNION ALL SELECT COUNT(*) DRV_TRANS_COUNT, 'DR', 'NSE' FROM DRV_ORDERS E, (SELECT MAX(C.DRV_SERIAL_NO) AS SER, C.DRV_ORDER_NO as ORDR_NO, C.DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE C.DRV_EXCH_ID = 'NSE' AND C.DRV_SEGMENT = 'D' GROUP BY C.DRV_ORDER_NO, C.DRV_LEG_NO) as X WHERE E.DRV_ORDER_NO = X.ORDR_NO 		AND E.DRV_LEG_NO = X.LEG_NO 		AND E.DRV_SERIAL_NO = X.SER AND DRV_STATUS = 'E' AND DRV_EXCH_ID = 'NSE' 		AND DRV_SEGMENT = 'D' UNION ALL SELECT COUNT(*) DRV_TRANS_COUNT, 'DR', 'BSE' FROM DRV_ORDERS E, (SELECT MAX(C.DRV_SERIAL_NO) AS SER, C.DRV_ORDER_NO as ORDR_NO, C.DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE C.DRV_EXCH_ID = 'BSE' AND C.DRV_SEGMENT = 'D' GROUP BY C.DRV_ORDER_NO, C.DRV_LEG_NO) as X WHERE E.DRV_ORDER_NO = X.ORDR_NO 		AND E.DRV_LEG_NO = X.LEG_NO 		AND E.DRV_SERIAL_NO = X.SER AND DRV_STATUS = 'E' AND DRV_EXCH_ID = 'BSE' AND DRV_SEGMENT = 'D' UNION ALL SELECT COUNT(*) DRV_TRANS_COUNT, 'CDS', 'NSE' FROM DRV_ORDERS E, (SELECT MAX(C.DRV_SERIAL_NO) AS SER, C.DRV_ORDER_NO as ORDR_NO, C.DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE C.DRV_EXCH_ID = 'NSE' AND C.DRV_SEGMENT = 'C' GROUP BY C.DRV_ORDER_NO, C.DRV_LEG_NO) as X WHERE E.DRV_ORDER_NO = X.ORDR_NO 		AND E.DRV_LEG_NO = X.LEG_NO 		AND E.DRV_SERIAL_NO = X.SER AND DRV_STATUS = 'E' AND DRV_EXCH_ID = 'NSE' 		AND DRV_SEGMENT = 'C' UNION ALL SELECT COUNT(*) DRV_TRANS_COUNT, 'CDS', 'BSE' FROM DRV_ORDERS E, (SELECT MAX(C.DRV_SERIAL_NO) AS SER, C.DRV_ORDER_NO as ORDR_NO, C.DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE C.DRV_EXCH_ID = 'BSE' AND C.DRV_SEGMENT = 'C' GROUP BY C.DRV_ORDER_NO, C.DRV_LEG_NO) as X WHERE E.DRV_ORDER_NO = X.ORDR_NO 		AND E.DRV_LEG_NO = X.LEG_NO 		AND E.DRV_SERIAL_NO = X.SER AND DRV_STATUS = 'E' AND DRV_EXCH_ID = 'BSE' 		AND DRV_SEGMENT = 'C' UNION ALL SELECT COUNT(*) DRV_TRANS_COUNT, 'COM', 'NSE' FROM DRV_ORDERS E, (SELECT MAX(C.DRV_SERIAL_NO) AS SER, C.DRV_ORDER_NO as ORDR_NO, C.DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE C.DRV_EXCH_ID = 'NSE' AND C.DRV_SEGMENT = 'M' GROUP BY C.DRV_ORDER_NO, C.DRV_LEG_NO) as X WHERE E.DRV_ORDER_NO = X.ORDR_NO 		AND E.DRV_LEG_NO = X.LEG_NO 		AND E.DRV_SERIAL_NO = X.SER AND DRV_STATUS = 'E' AND DRV_EXCH_ID = 'NSE' 		AND DRV_SEGMENT = 'M' UNION ALL SELECT COUNT(*) AS COMM_TRANS_COUNT, 'COM', 'MCX' FROM COMM_ORDERS E, (SELECT MAX(C.COMM_SERIAL_NO) AS SER, C.COMM_ORDER_NO as ORDR_NO, C.COMM_LEG_NO AS LEG_NO FROM COMM_ORDERS C WHERE C.COMM_EXCH_ID = 'MCX' AND C.COMM_SEGMENT = 'M' GROUP BY C.COMM_ORDER_NO, C.COMM_LEG_NO) as X WHERE E.COMM_ORDER_NO = X.ORDR_NO 		AND E.COMM_LEG_NO = X.LEG_NO 		AND E.COMM_SERIAL_NO = X.SER AND COMM_STATUS = 'E' 		AND COMM_EXCH_ID = 'MCX') a) s;");

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//    int iNumRow = mysql_num_rows(Res);
		//  printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}


		mysql_free_result(Res);
		printf("%s\n", sResult);

	}
	else if ( flag == 7 ) //This is for SIP
	{
		sprintf(Pr_Query,"select concat(BP_EXCH_ID,'-', BP_SEGMENT, '~',  BP_BATCH_NAME, '~',  BP_LAST_RUN_DATE, '~', \
			(UNIX_TIMESTAMP(CONCAT(DATE(p.bp_date), ' ','~', DATE_FORMAT(p.bp_schedule_time, '%%H:%%i:%%s'))) - UNIX_TIMESTAMP(NOW())))\
			from BATCH_PROCESS p where p.BP_BATCH_NAME like 'SIP%%';");

		//      printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//      int iNumRow = mysql_num_rows(Res);
		//      printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}

	else if ( flag == 8 ) //This is for EOD_BOD
	{
		sprintf(Pr_Query,"SELECT        concat(\"EQ_TRD\", \"~\", EQ_TRD, \"|\",  \"DRV_TRD\",\"~\", DRV_TRD,\"|\",  \
                        \"CUR_TRD\",\"~\", CURR_TRD,\"|\",\"COMM_TRD\",\"~\", COMM_TRD,\"|\",  \"EQ_PEND\",\"~\", \
                                EQ_PEND,\"|\", \"DRV_PEND\",\"~\", DRV_PEND,\"|\", \"CURR_PEND\",\"~\", CURR_PEND,\"|\", \
                                \"COMM_PEND\",\"~\", COMM_PEND,\"|\", \"LOGNS\",\"~\", LOGNS)  FROM  (SELECT  \
                        SUM(CASE EQ_TRD WHEN 'EQ_TRD' THEN 1 ELSE 0 END) EQ_TRD, SUM(CASE \
                                EQ_TRD WHEN 'DRV_TRD' THEN 1 ELSE 0 END) DRV_TRD, SUM(CASE EQ_TRD \
                                WHEN 'CURR_TRD' THEN 1 ELSE 0 END) CURR_TRD,   SUM(CASE EQ_TRD WHEN \
                                'COMM_TRD' THEN 1 ELSE 0 END) COMM_TRD,   SUM(CASE EQ_TRD WHEN \
                                'EQ_PEND' THEN 1 ELSE 0 END) EQ_PEND,   SUM(CASE EQ_TRD WHEN \
                                'DRV_PEND' THEN 1 ELSE 0 END) DRV_PEND,   SUM(CASE EQ_TRD WHEN \
                                'CURR_PEND' THEN 1 ELSE 0 END) CURR_PEND,   SUM(CASE EQ_TRD WHEN \
                                'COMM_PEND' THEN 1 ELSE 0 END) COMM_PEND,   SUM(CASE EQ_TRD WHEN \
                                'LOGNS' THEN EQ_TRD_CNT ELSE 0 END) LOGNS  FROM   ((SELECT COUNT(\
                                DISTINCT(A.EQ_ORDER_NO)) AS EQ_TRD_CNT, 'EQ_TRD' FROM EQ_ORDERS \
                                A  WHERE A.EQ_MSG_CODE = 2222 GROUP BY A.EQ_ORDER_NO, A.EQ_CLIENT_ID) \
                                UNION ALL(SELECT COUNT(DISTINCT(D.DRV_ORDER_NO)) AS DRV_TRD_CNT, \
                                'DRV_TRD' FROM DRV_ORDERS D  WHERE D.DRV_MSG_CODE = 2222 AND D.DRV_SEGMENT = 'D' \
                                AND D.DRV_CF_FLAG <> -1 GROUP BY D.DRV_ORDER_NO, D.DRV_CLIENT_ID)   \
                                UNION ALL(SELECT COUNT(C.DRV_ORDER_NO) AS DRV_TRD_CNT, 'CURR_TRD' \
                                FROM DRV_ORDERS C  WHERE C.DRV_MSG_CODE = 2222 AND C.DRV_SEGMENT = 'C'\
                                AND C.DRV_CF_FLAG <> -1 GROUP BY C.DRV_ORDER_NO, C.DRV_CLIENT_ID)   \
                                UNION ALL    (SELECT COUNT(CO.COMM_ORDER_NO) AS COMM_TRD_CNT, 'COMM_TRD' \
                                FROM COMM_ORDERS CO  WHERE CO.COMM_MSG_CODE = 2222 AND CO.COMM_SEGMENT = 'M' \
                                AND CO.COMM_CF_FLAG <> -1 GROUP BY CO.COMM_ORDER_NO, CO.COMM_CLIENT_ID)  \
                                UNION ALL    (SELECT COUNT(DISTINCT(A1.EQ_ORDER_NO)) AS EQ_PEND_CNT, 'EQ_PEND'\
                                FROM EQ_ORDERS A1  WHERE A1.EQ_MSG_CODE = 2073 GROUP BY A1.EQ_ORDER_NO, A1.EQ_CLIENT_ID)\
                                UNION ALL(SELECT COUNT(DISTINCT(D1.DRV_ORDER_NO)) AS DRV_PEND_CNT, 'DRV_PEND' \
                                FROM DRV_ORDERS D1 WHERE D1.DRV_MSG_CODE = 2073 AND D1.DRV_SEGMENT = 'D' AND \
                                D1.DRV_CF_FLAG <> -1 GROUP BY D1.DRV_ORDER_NO, D1.DRV_CLIENT_ID)   UNION\
                                ALL(SELECT COUNT(C1.DRV_ORDER_NO) AS DRV_PEND_CNT, 'CURR_PEND' FROM \
                                DRV_ORDERS C1  WHERE C1.DRV_MSG_CODE = 2073 AND C1.DRV_SEGMENT = 'C'\
                                AND C1.DRV_CF_FLAG <> -1 GROUP BY C1.DRV_ORDER_NO, C1.DRV_CLIENT_ID) \
                                UNION ALL    (SELECT COUNT(CO.COMM_ORDER_NO) AS COMM_PEND_CNT, 'COMM_PEND'\
                                FROM COMM_ORDERS CO  WHERE CO.COMM_MSG_CODE = 2073 AND CO.COMM_SEGMENT = 'M'\
                                AND CO.COMM_CF_FLAG <> -1 GROUP BY CO.COMM_ORDER_NO, CO.COMM_CLIENT_ID)   \
                                UNION ALL   (SELECT COUNT(DISTINCT(L.LOGIN_ID)) AS LOGIN_CNT, 'LOGNS'FROM LOGIN_REPORT\
                                L WHERE L.LOGIN_TIME BETWEEN CONCAT(date(now()),' 00:00:00') \
                                AND CONCAT(date(now()),' 23:59:59'))) AS XXX) as SA;");

		      printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//      int iNumRow = mysql_num_rows(Res);
		//      printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s|",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}

	else if ( flag == 9 ) //This is for SIP
	{
			sprintf(Pr_Query,"select CONCAT('DATE_FROM',   '~',   DATE_FROM,   '|',   'DATE_TO',   '~',   DATE_TO,   '|',   'TOT_CLI_TRD', \
                        '~',   TOT_CLI_TRD,   '|',   'TOT_CLI_LOG',   '~',   TOT_CLI_LOG,   '|',   'WEB_LOG_TRADES',  \
                                '~',   WEB_LOG_TRADES,   '|',   'MOB_LOG_TRADES',   '~',   MOB_LOG_TRADES,   '|',  \
                                'EXE_LOG_TRADES',   '~',   EXE_LOG_TRADES,   '|',   'EXE_LOG_TRADES',   '~',  \
                                EXE_LOG_TRADES,   '|',   'MKT_ORD_CNT',   '~',   MKT_ORD_CNT,   '|',   'LMT_ORD_CNT',  \
                                '~',   LMT_ORD_CNT,   '|',   'TOT_CNC_TRADES',   '~',   TOT_CNC_TRADES,   '|',  \
                                'TOT_INT_TRADES',   '~',   TOT_INT_TRADES,   '|',   'TOT_MARG_TRADES',   '~',  \
                                TOT_MARG_TRADES,   '|',   'TOT_CO_TRADES',   '~',   TOT_CO_TRADES,   '|', \
                                'TOT_BO_TRADES',   '~',   TOT_BO_TRADES,   '|',   'TOT_NORM_TRADES',   '~', \
                                TOT_NORM_TRADES,   '|',   'TOT_MTF_TRADES',   '~',   TOT_MTF_TRADES,   '|',  \
                                'EQ_INS_TRADES',   '~',   EQ_INS_TRADES,   '|',   'FUT_IDX_TRADES',   '~',  \
                                FUT_IDX_TRADES,   '|',   'FUT_STK_TRADES',   '~',   FUT_STK_TRADES,   '|',  \
                                'OPT_IDX_TRADES',   '~',   OPT_IDX_TRADES,   '|',   'OPT_STK_TRADES',   '~', \
                                OPT_STK_TRADES,   '|',   'FUT_CUR_TRADES',   '~',   FUT_CUR_TRADES,   '|',  \
                                'OPT_CUR_TRADES',   '~',   OPT_CUR_TRADES,   '|',   'FUT_COM_TRADES',   '~', \
                                FUT_COM_TRADES,   '|',   'OPT_COM_TRADES',   '~',   OPT_COM_TRADES,   '|',  \
                                'EQ_ORD_TRADES',   '~',   EQ_ORD_TRADES,   '|',   'DRV_ORD_TRADES',   '~', \
                                DRV_ORD_TRADES,   '|',   'CURR_ORD_TRADES',   '~',   CURR_ORD_TRADES,   '|', \
                                'COMM_ORD_TRADES',   '~',   COMM_ORD_TRADES,   '|',   'WEB_LOG_COUNT',   '~', \
                                WEB_LOG_COUNT,   '|',   'MOB_LOG_COUNT',   '~',   MOB_LOG_COUNT,   '|',  \
                                'EXE_LOG_COUNT',   '~',   EXE_LOG_COUNT,   '|',   'CLIID_MAX_SELL_VOL',  \
                                '~',   CLIID_MAX_SELL_VOL,   '|',   'CLIID_MAX_SELL_VOL',   '~',   CLIID_MAX_SELL_VOL, \
                                '|',   'CLIID_MAX_BUY_VOL',   '~',   CLIID_MAX_BUY_VOL,   '|',   'MAX_BUY_VOL', \
                                '~',   MAX_BUY_VOL,   '|',   'MAX_SELL_VOL',   '~',   MAX_SELL_VOL,   '|',  \
                                'TRD_ORD_CNT',   '~',   TRD_ORD_CNT,   '|',   'PEN_ORD_CNT',   '~',   PEN_ORD_CNT,  \
                                '|',   'PEND_TRD_PERC',   '~',   PEND_TRD_PERC,   '|',   'CLI_LOG_TRD_PERC',   '~',   CLI_LOG_TRD_PERC)\
                                FROM ANALYTICS_RESULTS WHERE DATE_FROM = '%s' AND DATE_TO = '%s' ;",sFrom,sTo);

		//      printf("Pr_Query = %s\n",Pr_Query);

		if(mysql_query(DB_Con,Pr_Query) != 0)
		{
			iError  = mysql_errno(DB_Con);
			printf("ERROR Received While Select Query :%d:",iError);
			return 0;
		}
		Res = mysql_store_result(DB_Con);
		//      int iNumRow = mysql_num_rows(Res);
		//      printf("iNumRow :%d:\n",iNumRow);
		while(Row = mysql_fetch_row(Res))
		{
			sprintf(status,"%s*",Row[0]);
			strcat(sResult, status);

		}

		mysql_free_result(Res);
		printf("%s\n", sResult);

	}
	else if ( flag == 10 ) //This is For New File Uploads
        {
                sprintf(Pr_Query," SELECT  concat(ifnull(PROCESS_DATE,DATE('0001-01-01')), '~', PROCESS, '~',\
                        SUCCESS_FLAG, '~', PROCESS_STATUS, '~', SUCCESS, '~', REJECTED, '~', \
                        (UNIX_TIMESTAMP(BP_LAST_RUN_DATE) - UNIX_TIMESTAMP(ifnull(PROCESS_DATE,DATE('0001-01-01')))),\
                        '~', EXCH_ID, '-', SEGMENT) FROM RMS_PROCESS_LOG R LEFT JOIN BATCH_PROCESS B ON (BP_BATCH_NAME \
                        = 'EOD_BOD' AND BP_EXCH_ID = 'NSE' AND BP_SEGMENT = 'E') WHERE R.MON_FLG = 'Y';");

		if(mysql_query(DB_Con,Pr_Query) != 0)
                {
                        iError  = mysql_errno(DB_Con);
                        printf("ERROR Received While Select Query :%d:",iError);
                        return 0;
                }
                Res = mysql_store_result(DB_Con);

                while(Row = mysql_fetch_row(Res))
                {
                        sprintf(status,"%s|",Row[0]);
                        strcat(sResult, status);

                }

                mysql_free_result(Res);
                printf("%s\n", sResult);

        }
	else 
	{
		printf("Command Not Found \n");

	}
	return 1;
}
//	printf("Connected to Database.\n");

//	printf("Exit : [DB_Connect]\n");
//	return DB_Con;


void Unscramble(char *sStr)
{
	int i=0;
	for(i = strlen(sStr) - 1; i >= 0; i--)
	{
		//printf("%c\n",sStr[i]);
		if((sStr[i] - i) < min)
		{
			sStr[i] = max - (min - (sStr[i] - i));
		}
		else
		{
			sStr[i] = sStr[i] - i;
		}
	}
}
