#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"
#include "IPCS.h"
#include "RedisStruct.h"

extern	LONG32		iAlgoOrderType;
extern	LONG32		iMktProtectionType;
extern	DOUBLE64	fMktProtPer;

BOOL fLoadMktProtEnv()
{
	logTimestamp("Entry fLoadMktProtEnv");
	MYSQL	*DBCon;
	DBCon = DB_Connect();
	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;

	CHAR	sSysQry [MAX_QUERY_SIZE];

        memset(sSysQry,'\0',MAX_QUERY_SIZE);
        sprintf(sSysQry,"select PARAM_VALUE  from SYS_PARAMETERS where  PARAM_NAME = 'ALGO_ORDER_TYPE_FLAG';");

        logDebug2("Qry = %s",sSysQry);

        if (mysql_query(DBCon, sSysQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DBCon);
        }
        Res = mysql_store_result(DBCon);

        if((Row = mysql_fetch_row(Res)))
        {
                logInfo("Fetch row from sysparameter");
                iAlgoOrderType = atoi(Row[0]);
                logDebug2("iAlgoOrderType :%d:",iAlgoOrderType);
        }
        else
        {
                logInfo("no row fetch  from sysparameter");
                iAlgoOrderType = 0;
                logDebug2("iAlgoOrderType :%d:",iAlgoOrderType);
        }
        mysql_free_result(Res);

memset(sSysQry,'\0',MAX_QUERY_SIZE);
        sprintf(sSysQry,"select PARAM_VALUE  from SYS_PARAMETERS where  PARAM_NAME = 'MPP_ORDER_FLAG';");

        logDebug2("Qry = %s",sSysQry);

        if (mysql_query(DBCon, sSysQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DBCon);
        }
        Res = mysql_store_result(DBCon);

        if((Row = mysql_fetch_row(Res)))
        {
                logInfo("Fetch row from sysparameter");
                iMktProtectionType= atoi(Row[0]);
                logDebug2("iMktProtectionType :%d:",iMktProtectionType);
        }
        else
        {
                logInfo("no row fetch  from sysparameter");
                iMktProtectionType = 0;
                logDebug2("iMktProtectionType :%d:",iMktProtectionType);
        }
        mysql_free_result(Res);

        memset(sSysQry,'\0',MAX_QUERY_SIZE);
        sprintf(sSysQry,"select PARAM_VALUE  from SYS_PARAMETERS where  PARAM_NAME = 'MKT_ORD_PERC';");

        logDebug2("Qry = %s",sSysQry);

        if (mysql_query(DBCon, sSysQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DBCon);
        }
        Res = mysql_store_result(DBCon);

        if((Row = mysql_fetch_row(Res)))
        {
                logInfo("Fetch row from sysparameter");
                fMktProtPer= atof(Row[0]);
                logDebug2("fMktProtPer :%f:",fMktProtPer);
        }
        else
        {
                logInfo("no row fetch  from sysparameter");
                fMktProtPer = 0.00;
                logDebug2("fMktProtPer :%f:",fMktProtPer);
        }
        mysql_free_result(Res);
	mysql_close(DBCon);

	logTimestamp("Exit fLoadMktProtEnv");
	return TRUE;
}

BOOL fGetLTP(CHAR *sSecId,CHAR *cSegment,CHAR *sExchId ,CHAR *sInstrumentType,CHAR *sNearFutScrptId,DOUBLE64 *fLTP, DOUBLE64 *fNrSrptLTP)
{
        logTimestamp("Entry  fGetLTP ");

        redisReply *reply;
        redisContext    *RdConn;

        RdConn = RDConnect();

        CHAR    sExstCmd[COMMAND_LEN];
        CHAR    sSelLtp [MAX_QUERY_SIZE];
        memset(sExstCmd,'\0',COMMAND_LEN);
        memset(sSelLtp,'\0',MAX_QUERY_SIZE);

        sprintf(sExstCmd,"EXISTS %s:%s%c%s",SET_L1_WATCH,sExchId,cSegment,sSecId);
        logTimestamp("sExstCmd -> |%s|",sExstCmd);

        reply = redisCommand(RdConn,sExstCmd);
        logDebug3("reply->integer :%d:",reply->integer);
        if(reply->integer == TRUE)
        {
                //sprintf(sSelLtp,"HMGET %s:%c:%s LTP",sExchId,cSegment,sSecId);
                sprintf(sSelLtp,"HMGET %s:%s%c%s %s",SET_L1_WATCH,sExchId,cSegment,sSecId,SM_LTP);
		logDebug2("sSelLtp :%s:",sSelLtp);
                reply = redisCommand(RdConn,sSelLtp);

                if(reply->element[0]->str == NULL)
                {
                        *fLTP =0.00;
                        *fNrSrptLTP=0.00;
                }
                else
                {
                        *fLTP = atof(reply->element[0]->str);
                        if((strcmp(sNearFutScrptId,"NA") == 0) || (strlen(sNearFutScrptId) == 0))
                        {
                                *fNrSrptLTP =0.00;
                        }
                        else
                        {
                                freeReplyObject(reply);
                                logDebug2("sInstrumentType = |%s|",sInstrumentType);
                                if(strcmp(sInstrumentType,"OPTSTK") == 0)
                                {
                                        memset(sSelLtp,'\0',MAX_QUERY_SIZE);
                                        sprintf(sSelLtp,"HMGET %s:%s%c%s LTP",SET_L1_WATCH,sExchId,SEGMENT_EQUITY,sNearFutScrptId);
                                        logDebug2("sSelLtp :%s:",sSelLtp);
                                        reply = redisCommand(RdConn,sSelLtp);

                                        if(reply->element[0]->str == NULL)
                                        {
                                                *fNrSrptLTP =0.00;
                                        }
                                        else
                                        {
                                                *fNrSrptLTP = atof(reply->element[0]->str);
                                        }
                                }
                                else
                                {
                                        memset(sSelLtp,'\0',MAX_QUERY_SIZE);
                                        sprintf(sSelLtp,"HMGET %s:%s%c%s LTP",SET_L1_WATCH,sExchId,cSegment,sNearFutScrptId);
                                        logDebug2("sSelLtp :%s:",sSelLtp);
                                        reply = redisCommand(RdConn,sSelLtp);

                                        if(reply->element[0]->str == NULL)
                                        {
                                                *fNrSrptLTP =0.00;
                                        }
                                        else
                                        {
                                                *fNrSrptLTP = atof(reply->element[0]->str);
                                        }
                                }
                        }
                }
        }
        else
        {
                logDebug2("Redis Key doesn't exist");
                *fLTP =0.00;
                *fNrSrptLTP=0.00;
        }
        logDebug3("fLtp = |%lf|",*fLTP);
        logDebug3("fNrSrptLTP = |%lf|",*fNrSrptLTP);
        freeReplyObject(reply);
        redisFree(RdConn);
        logTimestamp("Exit  [fGetLTP]");
        return TRUE;
}

BOOL fMapMktProtPrice(struct INT_ORDERS *Ins_Req)
{
        logTimestamp("Entry |fMapMktProtPrice|");

        if(Ins_Req->fMppOrdPrice == 0.00)
        {
                logDebug2("Not Altering Order Type");
                logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                logDebug2("Ins_Req->iOrderType = |%d|",Ins_Req->iOrderType);
        }
        else
        {
                logDebug2("Altering Order Type");
                Ins_Req->fOrderPrice = Ins_Req->fMppOrdPrice;
                if(Ins_Req->iOrderType == ORD_TYPE_MKT)
                {
                        Ins_Req->iOrderType = ORD_TYPE_LIMIT;
                }
                else if(Ins_Req->iOrderType == ORD_TYPE_STOP_LOSS_MKT)
                {
                        Ins_Req->iOrderType = ORD_TYPE_STOP_LIMIT;
                }
                logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                logDebug2("Ins_Req->iOrderType = |%d|",Ins_Req->iOrderType);
        }
        logTimestamp("Exit |fMapMktProtPrice|");
        return TRUE;
}

BOOL fCBMapMktProtPrice(struct INT_COBO_ORDERS *Ins_Req)
{
        logTimestamp("Entry |fCBMapMktProtPrice|");

        if (Ins_Req->iLegValue == LEG_1)
        {
                if(Ins_Req->fMppOrdPrice == 0.00)
                {
                        logDebug2("Not Altering Order Type");
                        logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                        logDebug2("Ins_Req->iOrderType = |%d|",Ins_Req->iOrderType);
                }
                else
                {
                        logDebug2("Altering Order Type");
                        Ins_Req->fOrderPrice = Ins_Req->fMppOrdPrice;
                        if(Ins_Req->iOrderType == ORD_TYPE_MKT)
                        {
                                Ins_Req->iOrderType = ORD_TYPE_LIMIT;
                        }
                        else if(Ins_Req->iOrderType == ORD_TYPE_STOP_LOSS_MKT)
                        {
                                Ins_Req->iOrderType = ORD_TYPE_STOP_LIMIT;
                        }
                        logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                        logDebug2("Ins_Req->iOrderType = |%d|",Ins_Req->iOrderType);
                }
        }
        else if (Ins_Req->iLegValue == LEG_2)
        {
                if(Ins_Req->fSlMppOrdPrice == 0.00)
                {
                        logDebug2("Not Altering Order Type");
                        logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                        logDebug2("Ins_Req->iOrderType = |%d|",Ins_Req->iOrderType);
                }
                else
                {
                        logDebug2("Altering Order Type.....1");
                        /*if (Ins_Req->ReqHeader.iMsgCode == TC_BO_PUMP_REQ )
                        {
                                logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                        }
                        else
                        {*/
                                Ins_Req->fOrderPrice = Ins_Req->fSlMppOrdPrice;
                        //}
			if(Ins_Req->iOrderType == ORD_TYPE_MKT)
                        {
                                Ins_Req->iOrderType = ORD_TYPE_LIMIT;
                        }
                        else if(Ins_Req->iOrderType == ORD_TYPE_STOP_LOSS_MKT)
                        {
                                Ins_Req->iOrderType = ORD_TYPE_STOP_LIMIT;
                        }
                        logDebug2("Ins_Req->fOrderPrice = |%lf|",Ins_Req->fOrderPrice);
                        logDebug2("Ins_Req->iOrderType = |%d|",Ins_Req->iOrderType);
                }
        }

        logTimestamp("Exit |fCBMapMktProtPrice|");
        return TRUE;

}

BOOL fCBMapMktProtDetails(struct INT_COBO_ORDERS *Ins_Req, DOUBLE64 fMppOrdPrice, DOUBLE64 fSlMppOrdPrice, DOUBLE64 fMppBlkPrice, DOUBLE64 fSlMppBlkPrice)
{
        logTimestamp("Entry |fCBMapMktProtDetails|");
        if ((Ins_Req->ReqHeader.iMsgCode != TC_INT_CO_ORDER_EXIT ) && ( Ins_Req->ReqHeader.iMsgCode != TC_INT_BO_ORDER_EXIT ) && ( Ins_Req->ReqHeader.iMsgCode != TC_INT_BO_ORDER_CANCEL ) && ( Ins_Req->ReqHeader.iMsgCode != TC_BO_PUMP_REQ ) && (!((Ins_Req->ReqHeader.iMsgCode == TC_INT_CO_ORDER_MODIFY) && (Ins_Req->iLegValue == LEG_2) && (Ins_Req->iOrderType == ORD_TYPE_MKT))))
        {
                Ins_Req->fMppOrdPrice = fMppOrdPrice;
                Ins_Req->fSlMppOrdPrice = fSlMppOrdPrice;
                Ins_Req->fMppBlkPrice = fMppBlkPrice;
                Ins_Req->fSlMppBlkPrice = fSlMppBlkPrice;
        }
        logDebug2("Ins_Req->fMppOrdPrice |%f|",Ins_Req->fMppOrdPrice);
        logDebug2("Ins_Req->fSlMppOrdPrice |%f|",Ins_Req->fSlMppOrdPrice);
        logDebug2("Ins_Req->fMppBlkPrice |%f|",Ins_Req->fMppBlkPrice);
        logDebug2("Ins_Req->fSlMppBlkPrice |%f|",Ins_Req->fSlMppBlkPrice);
        logTimestamp("Exit |fCBMapMktProtDetails|");
        return TRUE;
}


BOOL fGetCktLmtLtpDet(CHAR *sSecId,CHAR *cSeg,CHAR *sExchId, DOUBLE64 *fUpperCktlmt, DOUBLE64 *fLowerCktlmt, DOUBLE64 *fTickSize)
{
	logTimestamp("Entry fGetCktLmtLtpDet");

	redisReply *reply;
	redisContext    *RdConn;

	RdConn = RDConnect();

	INT16	iCount;
	INT16	i;

	CHAR	sCommand[MAX_COMMAND_LEN];
	CHAR	sExstCmd[COMMAND_LEN];
	CHAR	sKeyValue[COMMAND_LEN];

	memset(sCommand,'\0',MAX_COMMAND_LEN);
	memset(sExstCmd,'\0',COMMAND_LEN);
	memset(sKeyValue,'\0',COMMAND_LEN);

	sprintf(sKeyValue,"%s:%s%c%s",SET_L1_WATCH,sExchId,cSeg,sSecId);
	logDebug2("sKeyValue -> |%s|",sKeyValue);
	sprintf(sExstCmd,"EXISTS %s",sKeyValue);
	logTimestamp("sExstCmd -> |%s|",sExstCmd);

	reply = redisCommand(RdConn,sExstCmd);
	logDebug3("reply->integer :%d:",reply->integer);
	if(reply->integer == TRUE)
	{	
		sprintf(sCommand,"HMGET %s SM_UPPER_LIMIT SM_LOWER_LIMIT SM_TICK_SIZE SM_LTP",sKeyValue);
		logTimestamp("sCommand -> |%s|",sCommand);
		reply = redisCommand(RdConn,sCommand);
		iCount = reply->elements;
		logDebug2("ELEMENT COUNT = |%d| ",iCount);
		for(i = 0; i < iCount-1; i++)
		{
			logDebug2("reply->element[%d]->str |%s|",i,reply->element[i]->str);
			if(reply->element[i]->str == NULL)
			{
				logDebug2("Value Getting from the redis is null");
				freeReplyObject(reply);
				redisFree(RdConn);
				logTimestamp("Exit fGetCktLmtLtpDet");
				return FALSE;
			}
		}
		*fUpperCktlmt = atof(reply->element[0]->str);
		*fLowerCktlmt = atof(reply->element[1]->str);
		*fTickSize = atof(reply->element[2]->str);
	}
	else
	{
		logDebug2("Redis Key doesn't exist");
		freeReplyObject(reply);
		redisFree(RdConn);
		logTimestamp("Exit fGetCktLmtLtpDet");
		return FALSE;
	}
	freeReplyObject(reply);
	redisFree(RdConn);
	logTimestamp("Exit fGetCktLmtLtpDet");
	return TRUE;
}

