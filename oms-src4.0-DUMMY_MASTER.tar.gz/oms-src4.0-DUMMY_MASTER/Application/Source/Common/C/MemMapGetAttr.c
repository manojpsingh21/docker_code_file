#include    "MemMapConfig.h"
#include    "MemMapqueue.h"
#include    "MemMapCommon.h"
int
Mq_GetAttr(mymqd_t mqd, struct mymq_attr *mqstat)
{
	int		n;
		struct mymq_hdr	*mqhdr;
		struct mymq_attr	*attr;
		struct mymq_info	*mqinfo;
		
		mqinfo = mqd;
		
		printf("\nInside Mq_GetAttr...\n");
		
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				printf("\nNo Magic found ....\n");
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;
		attr = &mqhdr->mqh_attr;
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			errno = n;
				printf("\nUnable to find mutex lock....\n");
				return(-1);
		}
	
		printf("\nGetting the attributes....\n");
		
		mqstat->mq_flags = mqinfo->mqi_flags;	/* per-open */
		mqstat->mq_maxmsg = attr->mq_maxmsg;	/* remaining three per-queue */
		mqstat->mq_msgsize = attr->mq_msgsize;
		mqstat->mq_curmsgs = attr->mq_curmsgs;
		
		printf("\nSet attributes...\n");
		
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		
		printf("\nexit from Mq_GetAttr....\n");
		
		return(0);
}
/* end mq_getattr */

void
GetAttrMmap(mymqd_t mqd, struct mymq_attr *mqstat)
{
	if (Mq_GetAttr(mqd, mqstat) == -1)
		printf("Mq_GetAttr error");
}


int
Mq_ReduceMesg(mymqd_t mqd)
{
	int n;
		struct mymq_hdr *mqhdr;
		struct mymq_attr        *attr;
		struct mymq_info        *mqinfo;
		
		mqinfo = mqd;
		
		printf("\Inside Mq_ReduceMesg...\n");
		
		if (mqinfo->mqi_magic != MQI_MAGIC)
		{
			errno = EBADF;
				printf("\nNo Magic found ....\n");
				return(-1);
		}
	
		mqhdr = mqinfo->mqi_hdr;
		attr = &mqhdr->mqh_attr;
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0)
		{
			errno = n;
				printf("\nUnable to find mutex lock....\n");
				return(-1);
		}
	
		printf("\nReducing curr mesgs by one ....\n");
		
		printf("\nmq_curmsgs before reducing = [%d] ...\n",attr->mq_curmsgs);
		
		attr->mq_curmsgs--;
		
		printf("\nmq_curmsgs after reducing = [%d] ...\n",attr->mq_curmsgs);
		
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		
		printf("\nexit from Mq_ReduceMesg....\n");
		
		return(0);
		
}

void
ReduceMesgMmap(mymqd_t mqd)
{
	if (Mq_ReduceMesg(mqd) == -1)
		printf("Mq_ReduceMesg error");
}
