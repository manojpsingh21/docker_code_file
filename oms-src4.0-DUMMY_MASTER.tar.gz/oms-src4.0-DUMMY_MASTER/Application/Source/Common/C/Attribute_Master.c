#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

MYSQL    *DB_Conn;

void  main ()
{
	INT16 i;
	LONG32 m;

	logTimestamp("Entry [main]");

	MYSQL_RES  *Res;
	MYSQL_ROW   Row;

	DB_Conn = DB_Connect ();

	setbuf(stdin,0);
	setbuf(stdout,0);

	CHAR *Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	sprintf(Sel,"SELECT * FROM rupeeSQLDB.ATTRIBUTE_MASTER;");


	logDebug2("Sel :%s",Sel);

	if (mysql_query(DB_Conn, Sel) != SUCCESS)
	{
		logSqlFatal("Error in selecting Query");
		mysql_close(DB_Conn);
		return ERROR;
	}

	Res = mysql_store_result(DB_Conn);
	m = mysql_num_fields(Res);

	while((Row = mysql_fetch_row(Res)))
	{     
		logDebug1(".................");
		for (i=0; i< m ; i++)
		{

			logDebug1("%s ", (Row[i] != NULL ? Row[i] : "NULL"));
		}
	}
	mysql_free_result(Res);
	mysql_close(DB_Conn);
	return 0;
}



























