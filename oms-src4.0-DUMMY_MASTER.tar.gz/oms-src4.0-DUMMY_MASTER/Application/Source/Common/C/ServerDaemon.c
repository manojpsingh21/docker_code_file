/*******************************
 *
 * ServerDaemon
 *
 ******************************/

#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"
//#include "FIXStructures.h"
//#include "ConnectStatus.h"
#define         MAX_PEEK_SIZE                 10+1
#define         MAX_OMS		              20


//void    GOMStoFIX(void *);
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
//BOOL SendBusinessRejectFor(CHAR *In);
void SocketReadThread ();
void QueueToSocketThread ();

LONG32  iMemMaptoServerDaemon=0;

pthread_t   th_id1;
pthread_t   th_id2;

LONG32  iSocket;

struct		DAEMON_CLIENT_LIST 	daemonClientList [ MAX_OMS ];
	
LONG32  	iMasterSocket,iRetval, iMaster_Port;

int main(LONG32 argc, CHAR **argv)
{
	logTimestamp("ENTRY : [MAIN]");
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;

	sig1 = 0;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logDebug2(" PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;

	logDebug2(" PORT : %d", iMaster_Port ) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);


	iMemMaptoServerDaemon = OpenMsgQ(MemMaptoServerDaemon);
	if(iMemMaptoServerDaemon < 0)
	{
		logFatal(" Error in Opening MemMaptoServerDaemon Queue");
		exit(ERROR);
	}
	logDebug2(" MemMaptoServerDaemon Queue Opened : %d", iMemMaptoServerDaemon);

	if ((iMasterSocket=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		logFatal(" Error in creating the iMasterSocket");
		exit(ERROR);
	}
	logDebug2(" Socket Created : %d", iMasterSocket);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iMaster_Port);
	servadd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetval = 1;
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetval, sizeof(iRetval))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_REUSEADDR:");
		exit(1);
	}

	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}


	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}

	if( bind(iMasterSocket, (struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("bind: ");
		logFatal(" Error in binding to the iMasterSocket");
		exit(ERROR);
	}


//	ConnectionDOWN();
	if (listen(iMasterSocket, 50) < 0)
	{
		perror("listen");
		exit(EXIT_FAILURE);
	}

	while(1)
	{
		memset((CHAR *)&cliadd, '\0', sizeof(struct sockaddr_in));
	//	ConnectionDOWN();

		if((pthread_create(&th_id2,NULL,QueueToSocketThread,NULL)!= 0))
		{
			logDebug2(" pthread_create:QueueToSocketThread");
			exit(ERROR);
		}

		if((pthread_create(&th_id1,NULL,SocketReadThread,NULL)!= 0))
		{
			logDebug2(" pthread_create:SocketReadThread");
			exit(ERROR);
		}

		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while(TRUE)
		{
			mainwait = sigwait( &SequenceSet,&Signal);
			logDebug2(" Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				logDebug2(" SIGTERM in Main");
				ConnectionDOWN();
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				logDebug2(" Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				logDebug2(" SIGUSR1 in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				logDebug2(" Break from loop");
				break;
			}
			else
			{
				logDebug2(" Received some other signal");
				logDebug2(" Closing Socket");
				close(iSocket);
				logDebug2(" Exiting");
				exit(ERROR);
			}

		}
		logDebug2(" Socket Connection closed on : %d", iSocket);
		logDebug2(" While Loop");
	}
	logTimestamp("EXIT : [MAIN]");
}

void SocketReadThread()
{
	logTimestamp("ENTRY : [SocketReadThread]");
	LONG32  iRetval=-1,iLen;
	CHAR    cMsgType, *tempPtr;
	LONG32  dcount = 0,i;
	LONG32  loopcount=0;
	LONG32  insertVal = 0;
	CHAR    PeekBuf[ MAX_PEEK_SIZE+1 ] ;
	CHAR    RecvBuf[ RUPEE_MAX_PACKET_SIZE ] ;
	struct  INT_COMMON_REQUEST_HDR *pReqHeader;


	socklen_t addrlen;
	fd_set fds, readfds;
	FD_ZERO (&fds);
	FD_SET (iMasterSocket, &fds);
	int fdmax = iMasterSocket;
	int fd;
	struct sockaddr_storage client_saddr;
	char str [INET6_ADDRSTRLEN];
	struct sockaddr_in  *ptr;
	struct sockaddr_in6  *ptr1;

	InitDaemonClientList();
	logDebug1("============= Waiting for ClientDaemon to connect on port : %d ===========", iMaster_Port);
	while(TRUE)
	{
		readfds = fds;
		memset(&pReqHeader,'\0' ,sizeof(struct INT_COMMON_REQUEST_HDR));
		
		logDebug2("============Waiting on select call==============");
		if (select (fdmax + 1, &readfds, NULL, NULL, NULL) == -1)
			perror ("select");

		for (fd = 0; fd < (fdmax + 1); fd++) 
		{	
			if (FD_ISSET (fd, &readfds)) 
			{ 
				if (fd == iMasterSocket) {  
					logDebug1("=======================Received New connection request==============");
					addrlen = sizeof (struct sockaddr_storage);
					int fd_new;
					if ((fd_new = accept (iMasterSocket, (struct sockaddr *) &client_saddr, &addrlen)) == -1)
					{
						perror ("accept");
						logFatal(" Error in accepting the connection %d", errno);
						continue;
					}
					FD_SET (fd_new, &fds); 
					if (fd_new > fdmax) 
						fdmax = fd_new;

					if (client_saddr.ss_family == AF_INET) {
						ptr = (struct sockaddr_in *) &client_saddr;
						inet_ntop (AF_INET, &(ptr -> sin_addr), str, sizeof (str));
					}
					else if (client_saddr.ss_family == AF_INET6) {
						ptr1 = (struct sockaddr_in6 *) &client_saddr;
						inet_ntop (AF_INET6, &(ptr1 -> sin6_addr), str, sizeof (str));
					}
					else
					{
						ptr = NULL;
						fprintf (stderr, "Address family is neither AF_INET nor AF_INET6\n");
					}
					if (ptr)
					{ 
						logDebug1("%s :%d: :%s:", "New Socket Connection Established on ", fd_new, str);
						
						insertVal = InsertDaemonClient(fd_new,-1,&str);
                                		logDebug2("Inserted into DaemonClientList :%d:",insertVal);
						if(insertVal == SOCKET_EXIST)
                        			{
                                			logDebug2("In socket exist after insert");
							continue;
                        			}
						else if(insertVal == NOT_TRUE)
						{
                                			logDebug2("No space left in ClientDaemonList");
							continue;	
						}
					}
				}
				else
				{
					logDebug1("================== recv from fd :%d: ==============", fd);

					memset(&RecvBuf, '\0', RUPEE_MAX_PACKET_SIZE);
					memset(&PeekBuf, '\0', MAX_PEEK_SIZE+1);
					memset(&pReqHeader,'\0' ,sizeof(struct INT_COMMON_REQUEST_HDR));

					iLen    =   MAX_PEEK_SIZE;
					
					iRetval = Recv(fd, &PeekBuf, &iLen, MSG_PEEK);
					if (iRetval == ERROR || iRetval == FALSE){
						logFatal("Got error[%d] in peek for socket %d", iRetval, fd);
						logDebug2("Socket %d closed by ClientDaemon | iRetval in peek %d:", fd, iRetval);
						insertVal = ClearDaemonClient(fd);
						if(insertVal == ERROR)
                                        	{
                                                	logDebug2("Socket :%d: not found in ClientDaemonList to clear",fd); //Ideally this should never get printed
                                        	}
						if (close (fd) == ERROR)
                            				perror ("close");
                        			FD_CLR (fd, &fds);
						//remove fd from list
						continue;
					}

					logDebug2("iRetval in peek :%d:",iRetval);
					pReqHeader      = (struct INT_COMMON_REQUEST_HDR *) &PeekBuf;

					iLen = pReqHeader->iMsgLength;
					logDebug2("Packet length to read :[%d]",iLen);
					logDebug2("MsgCode :[%d]",pReqHeader->iMsgCode);
					logDebug2("GroupId :[%d]",pReqHeader->iSeqNo);

					if(pReqHeader->iMsgCode != TC_INT_CLIENT_TO_SERVER_DAEMON || iLen != sizeof(struct INT_COMMON_REQUEST_HDR)){
						logFatal("Invalid request received :%d:",pReqHeader->iMsgCode);
						insertVal = ClearDaemonClient(fd);
                                                if(insertVal == ERROR)
                                                {
                                                        logDebug2("Socket :%d: not found in ClientDaemonList to clear",fd); //Ideally this should never get printed
                                                }
                                                if (close (fd) == ERROR)
                                                        perror ("close");
                                                FD_CLR (fd, &fds);
						continue;
					}

					insertVal = InsertDaemonClient(fd,pReqHeader->iSeqNo,(CHAR *)NULL);
                                	logDebug2("[Update]Inserted into DaemonClientList :%d:",insertVal);
					if(insertVal == SOCKET_EXIST)
                        		{
                                		logDebug2("In socket exist after insert");
						continue;
                        		}
					else if(insertVal == NOT_TRUE)
					{
                                		logDebug2("No space left in ClientDaemonList");
						continue;	
					}
					iRetval = Recv(fd, &RecvBuf, &iLen, 0);
                                        if (iRetval == ERROR || iRetval == FALSE){
						logFatal("Got error[%d] in peek for socket %d", iRetval, fd);
                                                logDebug2("Socket %d closed by ClientDaemon | iRetval in peek %d:", fd, iRetval);
						insertVal = ClearDaemonClient(fd);
						if(insertVal == ERROR)
                                        	{
                                                	logDebug2("Socket :%d: not found in ClientDaemonList to clear",fd); //Ideally this should never get printed
                                        	}
                                                if (close (fd) == ERROR)
                                                        perror ("close");
                                                FD_CLR (fd, &fds);
                                                //remove fd from list
                                                continue;
                                        }

					logDebug2(" Received from ServerDaemon");
					PrintDaemonClientList();
				}
			}
		}
	}
	close(iSocket);
	logTimestamp("EXIT : [SocketToQueueThread]");
}


void QueueToSocketThread()
{
	logTimestamp("ENTRY : [QueueToSocketThread]");
	LONG32  iRetval, iLen, iMsgCode, iSockFd, rrCount = 0;
	CHAR    RcvMsg [RUPEE_MAX_PACKET_SIZE] ;
	struct  INT_COMMON_REQUEST_HDR  *pReqHdr;
	struct  ORDER_REQUEST *pOrdReq;

	while(1)
	{
		logDebug2("================== Waiting on the Queue =====================");
		memset(&RcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset(&pReqHdr,'\0' ,sizeof(struct INT_COMMON_REQUEST_HDR));
		memset(&pOrdReq,'\0' ,sizeof(struct ORDER_REQUEST));

		if ((iRetval=ReadMsgQ(iMemMaptoServerDaemon, &RcvMsg, RUPEE_MAX_PACKET_SIZE, 1))== ERROR)
		{
			logFatal(" ERROR in receiving the Data from the Q %d", iMemMaptoServerDaemon);
			exit(ERROR);
		}

		logDebug2("Successfully Read From Queue");
		pReqHdr = (struct INT_COMMON_REQUEST_HDR *)&RcvMsg;

		iMsgCode = pReqHdr->iMsgCode ;
		iLen = pReqHdr->iMsgLength ;
		logDebug2("------------MsgCode Received :%d:------------",iMsgCode);	
		switch (iMsgCode)
		{
			case  TC_INT_ORDER_ENTRY_REQ	:
				logDebug2("Before Changing the sequence pReqHdr->iSeqNo:%d:", pReqHdr->iSeqNo);
				if(pReqHdr->iSeqNo == 0) {
					logDebug2("-User Id recieved :%llu:------------",pReqHdr->iUserId);	
					rrCount = GetDaemonSameClient(pReqHdr->iUserId);
					if (rrCount == ERROR)
                                	{
                                	        logDebug2("No DaemonClients connected. So dropping the offline pump packet");
                                	        continue;
                                	}
					else
					{
						logDebug2("Sending order for user :%llu: on DaemonClient :%d:",pReqHdr->iUserId,rrCount);
						iSockFd = daemonClientList[rrCount].iSockFd;
					}
				}
				else {
					logDebug2("Before Changing the sequence pReqHdr->iSeqNo:%d:", pReqHdr->iSeqNo);
					//pReqHdr->iSeqNo = 0;
					((struct INT_COMMON_REQUEST_HDR *)&RcvMsg)->iSeqNo = 0 ;
					logDebug2("Changing the sequence pReqHdr->iSeqNo:%d:", ((struct INT_COMMON_REQUEST_HDR *)&RcvMsg)->iSeqNo);
					rrCount = GetDaemonClient(++rrCount);
					if (rrCount == ERROR)
	                                {
	                                        logDebug2("No DaemonClients connected. So dropping the square off packet");
	                                        continue;
	                                }
					else
					{
						iSockFd = daemonClientList[rrCount].iSockFd;
					}
				}	
				break;
			default :
				iSockFd = GetDaemonClientByGroupId(pReqHdr->iSeqNo);
				if (iSockFd == ERROR) 
				{
					logDebug2("DaemonClient for GroupId :%d: not connected. So dropping the cancellation packet",pReqHdr->iSeqNo);
					continue;
				}
				break;
		}

		if ((iRetval = Send(iSockFd, &RcvMsg, &iLen, 0)) == FALSE)
		{
			logDebug2(" ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSockFd);
			RestartProcess();
			break;
		}
		logDebug2("Sent to ClientDaemon -> iMsgCode :%d: | GroupId :%d: | SockFd :%d:",iMsgCode,pReqHdr->iSeqNo,iSockFd);
	}
	logTimestamp("EXIT : [QueueToSocketThread]");

}

void RestartProcess()
{	
	logTimestamp("ENTRY : [RestartProcess]");
	//	ConnectionDOWN();
	logDebug2("\n Before killing");
	logDebug2("\nI'm here!!!  My pid is %d.", (int) getpid ());
	kill(getpid(), SIGUSR1);
	logDebug2("\n Sent Signal %d To pid %d", SIGUSR1, getpid());
	logTimestamp("EXIT : [RestartProcess]");
	return;
}


/******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Send                                       	     **
 **                                                                           **
 **   DESCRIPTION       : Send doesnt guarantee that all the data in the      **
 **			 buffer will be sent in a single call to send, loop  **
 **			 around checking the return value till all the bytes **
 **			 are sent.					     **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc to which data will be sent.   **
 **			 SendData- Data to be sent.			     **
 **			 SendLen - Len of the data to be sent.		     **
 **			 Flags   - If any.				     **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	logTimestamp("ENTRY : [Send]");
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{
		logDebug2(" sending fix msg :%d:", TotalLen); 
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		logDebug2(" After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	logTimestamp("EXIT : [Send]");
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


/*******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Recv                                                **
 **                                                                           **
 **   DESCRIPTION       : recv doesnt guarantee that all the data in the      **
 **			              buffer will be received in a single call, loop     **
 **			              around checking the return value till all the bytes **
 **			              are received.                                       **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc from which data will be recvd.**
 **			              SendData- Data to be recvd.                         **
 **			              SendLen - Len of the data to be recvd.              **
 **			              Flags   - If any.                                   **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	logTimestamp("ENTRY : [Recv]");
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	logDebug2("\n Trying to Recv = %d", *RecvLen); 
	while(TotalLen < *RecvLen)
	{
		logDebug2("\n Trying to recv %d bytes", BytesLeft);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		logDebug2("\n After recv Bytes = %d", Bytes); 
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	logTimestamp("EXIT : [Recv]");
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

/*
   BOOL SendBusinessRejectFor(CHAR *FixString)
   {
   logTimestamp("ENTRY : [SendBusinessRejectFor]");
   CHAR        outString[RUPEE_MAX_PACKET_SIZE];
   LONG32		iRetVal = FALSE ;
   memset(outString,'\0',RUPEE_MAX_PACKET_SIZE);

   if ( (formRejectString( FixString,outString,2)) == FALSE)
   {
   logDebug2("\n\t No Rejection string created for [%s]",FixString);
   }
   else
   {
   logDebug2("\n Received the String :%s",outString);
   if ((iRetVal=WriteMsgQ(iGOMSInterfaceToRev,outString,strlen(outString)-1,1))== ERROR)
   {
   exit(ERROR);
   }
   }
   logTimestamp("EXIT : [SendBusinessRejectFor]");
   }
   */

void ConnectionUP()
{	
	logTimestamp("ENTRY : [ConnectionUP]");
	//	fUpdateConnectStatus(MCX_UP, 0, BCAST_YES, TRUE);
	logDebug2("\n UpdateConnectStatus UP");
	logTimestamp("ENTRY : [ConnectionUP]");
	return;
}


void ConnectionDOWN()
{
	//	logTimestamp("ENTRY : [ConnectionDOWN]");
	//	fUpdateConnectStatus(MCX_DOWN, 0, BCAST_YES, FALSE);
	//	logDebug2("\n UpdateConnectStatus DOWN");
	//	logTimestamp("ENTRY : [ConnectionDOWN]");
	return;
}

void InitDaemonClientList()
{
        logTimestamp("Entry InitDaemonClientList");
        LONG32 Count;
        for(Count = 0 ;Count < MAX_OMS;Count++)
        {
                memset(daemonClientList[Count].sIPAdd,'\0',IP_ADDR_LEN); 
                daemonClientList[Count].iSockFd = UNUSED ;
                daemonClientList[Count].iGroupId = UNUSED ;
                /*if((pthread_mutex_init(&UserSocketTable[Count].UserSocketLock,NULL)) !=0)
                {
                        logFatal(" RelayId %d: Error in initializing UserSocketTable[%d]",RelayId,Count);
                        exit(1);
                }*/
        }

        logTimestamp("Exit InitDaemonClientList");
}


/****
 *
 *   This function is used to access the user socket table.
 *     The access is done on the basis of three flag
 *     FLAG:
 *     INSERT : This flag is sent to insert the socket in the table.
 *     SELECT : This flag is sent to get the index of the socket in the table.
 *     RETURN VALUE:
 *     On successful completion of the function the index of the socket is returned.
 *     A value NOT_TRUE is returned is the socket doesn't exists in case of select or
 *     no space left for new socket.
 *      ****/


LONG32 ClearDaemonClient( LONG32 Socket)
{
	logTimestamp("Entry ClearDaemonClient");
	LONG32 Count;

	for( Count = 0 ; Count < MAX_OMS ; Count++)
	{
		if(daemonClientList[Count].iSockFd == Socket)
		{
			logDebug2("[For Clearing] Found socket :%d: at position :%d: groupId is :%d:",Socket,Count,daemonClientList[Count].iGroupId);
			memset(daemonClientList[Count].sIPAdd,'\0',IP_ADDR_LEN);
                        daemonClientList[Count].iSockFd = UNUSED ;
                        daemonClientList[Count].iGroupId = UNUSED ;
			return Count;
		}
	}
	logTimestamp("Exit ClearDaemonClient");
	return ERROR;
}

LONG32 GetDaemonClient( LONG32 offset)
{
	logTimestamp("Entry GetDaemonClient");
	LONG32 Count, mod, joker;

	logDebug3("offset :%d:",offset);

	for( Count = 0, joker = offset; Count < MAX_OMS ; Count++, joker++)
	{
		if(joker >= MAX_OMS) 
			joker = 0;
		if(daemonClientList[joker].iSockFd != UNUSED && daemonClientList[joker].iGroupId != UNUSED)
		{
			logDebug2("[For Placing Order] Found socket :%d: at position :%d: groupId is :%d:",daemonClientList[joker].iSockFd,joker,daemonClientList[joker].iGroupId);
			return joker;
		}
	}
	logTimestamp("Exit GetDaemonClient");
	return ERROR;
}

LONG32 GetDaemonSameClient(ULONG64 offset)
{
	logTimestamp("Entry GetDaemonSameClient");
	LONG32 Count, mod, joker, sockCnt = 0;

	logDebug3("UserId :%llu:",offset);

	for( Count = 0 ; Count < MAX_OMS ; Count++ )
	{
		if(daemonClientList[Count].iSockFd != UNUSED && daemonClientList[Count].iGroupId != UNUSED)
		{
			sockCnt++;
		}
	}
	if(sockCnt == 0) { return ERROR; }

	mod = (offset % sockCnt) + 1;
	
	for( Count = 0, joker = 1; Count < MAX_OMS ; Count++ )
	{
		if(daemonClientList[Count].iSockFd != UNUSED && daemonClientList[Count].iGroupId != UNUSED)
		{
			if(joker == mod) { return Count; }
			joker++;
		}
	}
	
	logTimestamp("Exit GetDaemonSameClient");
	return ERROR;
}

LONG32 GetDaemonClientByGroupId( LONG32 GrpId)
{
	logTimestamp("Entry GetDaemonClientByGroupId");
	LONG32 Count;

	for( Count = 0 ; Count < MAX_OMS ; Count++)
	{
		if(daemonClientList[Count].iGroupId == GrpId)
		{
			logDebug2("[For Cancellation] Found socket :%d: at position :%d: for groupId :%d:",daemonClientList[Count].iSockFd,Count,daemonClientList[Count].iGroupId);
			return daemonClientList[Count].iSockFd;
		}
	}
	logTimestamp("Exit GetDaemonClientByGroupId");
	return ERROR;
}

LONG32 InsertDaemonClient( LONG32 Socket, LONG32 GrpId, CHAR *IpAddr)
{
	logTimestamp("Entry InsertDaemonClient");
	LONG32 Count;

	logDebug2("New Socket Request Recieved Socket :%d: for group id :%d: from ip :%s:", Socket, GrpId, IpAddr);
	for( Count = 0 ; Count < MAX_OMS ; Count++)
	{		
		if(daemonClientList[Count].iSockFd == Socket)
		{
			logDebug2("Index :%d: -> A socket fd :%d: already exists for id :%d:",Count,daemonClientList[Count].iSockFd,daemonClientList[Count].iGroupId);
			daemonClientList[Count].iSockFd = Socket;
			daemonClientList[Count].iGroupId = GrpId;
			logDebug2("Updated socket fd :%d: with group id :%d:",Socket,GrpId);
			return Count;
		}
	}
	for( Count = 0 ; Count < MAX_OMS ; Count++)
	{
		
		if(daemonClientList[Count].iSockFd != UNUSED)
		{
			logDebug2("::DaemonClientList[%d] SockFd = [%d] | GroupId = [%d] | IPAdd = [%s]",Count,daemonClientList[Count].iSockFd,daemonClientList[Count].iGroupId,daemonClientList[Count].sIPAdd);
		}
		if(daemonClientList[Count].iSockFd == UNUSED)
		{
			logDebug2("Index for the new socket is %d",Count);
			daemonClientList[Count].iSockFd = Socket;
			daemonClientList[Count].iGroupId = GrpId;
			strncpy(daemonClientList[Count].sIPAdd,IpAddr,IP_ADDR_LEN);
			return Count;
		}
	}
	logTimestamp("Exit InsertDaemonClient");
	return ERROR;
}

LONG32 PrintDaemonClientList()
{
	logTimestamp("Entry PrintDaemonClientList");
	LONG32 Count;

	for( Count = 0 ; Count < MAX_OMS ; Count++)
	{
		logDebug2("::DaemonClientList[%d] SockFd = [%d] | GroupId = [%d] | IPAdd = [%s]",Count,daemonClientList[Count].iSockFd,daemonClientList[Count].iGroupId,daemonClientList[Count].sIPAdd);
	}
	logTimestamp("Exit PrintDaemonClientList");
	return TRUE;
}

