#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
#include <my_global.h>    
#include <mysql.h>
#include "IPCS.h"

#define WAIT_BEFORE_RETRY 1
//#define NO_OF_SEG         6
//#define NO_OF_SEG         23
#define NO_OF_SEG         26
#define	SEG_SIP		  2
//#define BSE_MKT_OPEN     3
#define	RESTART_TIME	3600

struct THREAD_PARAMS
{
	MYSQL *DB_Con;
	LONG32 thread_id;
};

CHAR	sTempUID[10];
CHAR    sGroupId        [ENV_VARIABLE_LEN];
LONG32  iGroupId = 1; //hardcode by Ashish.
LONG32  iOMSGroupId = 1; //For Share memory .
void 	OpenMsgQue();
void	LoadEnv();
void    Daemon(void *parameter);
//void    CheckMTM(void *parameter);
//void 	CheckOPT_STRK(void *parameter);
void 	CDSLFileUpload (void *parameter);
LONG32  OffOrdExecute(void *DB_Con);
LONG32  IntradySqOffExecute(void *DB_Con);
LONG32	IntrdyCroCurSqOffExec(void *DB_Con);
LONG32	fCoverSqOffExecute(void *DB_Con);
LONG32	fBracketSqOffExecute (void *DB_Con);
LONG32	SIPOrdExecute(void *DB_Con);
//BOOL	NotifyFE(CHAR *sClientId, LONG32 iUserId, DOUBLE64 fMTMPer, DOUBLE64 fMTMLevel , CHAR cSqrOff);
//LONG32 	GetJuliDateTime();

LONG32  iRDaemonToOffPump=0;
LONG32  iRDaemonToSqoff=0;
LONG32  iRDaemonToMtmSqoff =0;
LONG32  iTrdRtrToD2C=0;

CHAR  	sAllowExch[EXCHANGE_ALLOW_LEN];
CHAR    sOmstype[ENV_VARIABLE_LEN];
CHAR    cOmstype = '\0';

LONG32 main (LONG32 argc,CHAR **argv)
{
	logTimestamp("Entry : [main]");

	struct THREAD_PARAMS paramsOffOrd[NO_OF_SEG];
	struct THREAD_PARAMS paramsSqOff[NO_OF_SEG];
	struct THREAD_PARAMS paramsCroCurSqOff;
	struct THREAD_PARAMS paramsCoSqOff[NO_OF_SEG];
	struct THREAD_PARAMS paramsBoSqOff[NO_OF_SEG];
	struct THREAD_PARAMS paramsDaemon;
//	struct THREAD_PARAMS paramsMTM;
	struct THREAD_PARAMS paramsSIPOrd[SEG_SIP];
	struct THREAD_PARAMS paramsOSPR;
	struct THREAD_PARAMS paramsICCL;	

	CHAR	cExch;

	INT16 	i;

	pthread_t OffOrd_th_id[NO_OF_SEG];
	pthread_t SqOff_th_id[NO_OF_SEG];
	pthread_t CroCurSqOff_th_id;
	pthread_t CoSqOff_th_id[NO_OF_SEG];
	pthread_t BoSqOff_th_id[NO_OF_SEG];
	pthread_t SIP_th_id[SEG_SIP];
	pthread_t daemon_th_id;
//	pthread_t MTM_th_id;
	pthread_t OSPR_th_id;
	pthread_t ICCL_th_id;

	memset(sAllowExch,'\0',EXCHANGE_ALLOW_LEN);		

	setbuf(stdin,0);
	setbuf(stdout,0);
	LoadEnv();
	OpenMsgQue();
	memset(sGroupId,'\0',ENV_VARIABLE_LEN);	
	memset(sOmstype,'\0',ENV_VARIABLE_LEN);	
	if(getenv("GROUP_ID") == NULL)
        {
                logFatal("Error : Environment Variable missing : GROUP_ID ");
                exit(ERROR);
        }
        else
        {
                strncpy(sGroupId,getenv("GROUP_ID"),ENV_VARIABLE_LEN);
                iOMSGroupId = atoi(sGroupId);
                logDebug2("iOMSGroupId:%d:",iOMSGroupId);
        }	
	if(getenv("MASTER_SLAVE") == NULL)
        {
                logFatal("Error : Environment Variable missing : MASTER_SLAVE");
                exit(ERROR);
        }
        else
        {
                strncpy(sOmstype,getenv("MASTER_SLAVE"),ENV_VARIABLE_LEN);
                cOmstype = sOmstype[0];
                logDebug2("Master Slave :%s:",sOmstype);
                logDebug2("Master Slave :%c:",cOmstype);
        }


	for(i=0;i<NO_OF_SEG;i++)
	{
		cExch = i + '0';		
		logDebug2("cExch :%c: i :%d:",cExch,i);

		//if(strchr(sAllowExch,cExch) != NULL)
		//{	

			paramsOffOrd[i].thread_id=i;
			paramsSqOff[i].thread_id=i;
			//		paramsCroCurSqOff[i].thread_id=i;
			paramsCoSqOff[i].thread_id=i;
			paramsBoSqOff[i].thread_id=i;
			paramsOffOrd[i].DB_Con = DB_Connect();
			//		paramsCroCurSqOff[i].DB_Con = DB_Connect();
			paramsSqOff[i].DB_Con = DB_Connect();
			paramsCoSqOff[i].DB_Con = DB_Connect();
			paramsBoSqOff[i].DB_Con = DB_Connect();

			if((pthread_create(&OffOrd_th_id[i],NULL,OffOrdExecute,(void *)&paramsOffOrd[i]))!=0)
				// if((pthread_create(&OffOrd_th_id[i],NULL,OffOrdExecute,(void *)DB_OffCon[i]))!=0)
				logFatal("[OffOrd] Cant create thread [%d]",i);
			else
				logDebug1("[OffOrd] Created thread [%d]",i);

			if((pthread_create(&SqOff_th_id[i],NULL,IntradySqOffExecute,(void *)&paramsSqOff[i]))!=0)
				logFatal("[IntSqOff] Cant create thread [%d]",i);
			else
				logDebug1("[IntSqOff] Created thread [%d]",i);

			/*			if((pthread_create(&CroCurSqOff_th_id[i],NULL,IntrdyCroCurSqOffExec,(void *)&paramsCroCurSqOff[i]))!=0)
						logFatal("[IntradyCroCurSqOff] Cant create thread [%d]",i);
						else
						logDebug1("[CroCusSqOff] Created thread [%d]",i);           */

			if((pthread_create(&CoSqOff_th_id[i],NULL,fCoverSqOffExecute,(void *)&paramsCoSqOff[i]))!=0)
				logFatal("[fCoSqOff] Cant create thread [%d]",i);
			else
				logDebug1("[fCoSqOff] Created thread [%d]",i);

			if((pthread_create(&BoSqOff_th_id[i],NULL,fBracketSqOffExecute,(void *)&paramsBoSqOff[i]))!=0)
				logFatal("[fBoSqOff] Cant create thread [%d]",i);
			else
				logDebug1("[fBoSqOff] Created thread [%d]",i);

			sleep(2);	
	//	}

	}
/**/
	paramsCroCurSqOff.thread_id = 0;
	paramsCroCurSqOff.DB_Con = DB_Connect();

	if ((pthread_create(&CroCurSqOff_th_id,NULL,IntrdyCroCurSqOffExec,(void *)&paramsCroCurSqOff)) != 0 )
		logFatal("[IntradyCroCurSqOff] Cant create thread ");
	else
		logDebug1("[CroCusSqOff] Created thread ");

/***/
	for(i=0;i<SEG_SIP;i++)
	{
		cExch = i + '0';
		logDebug2("cExch = %c : i = %d",cExch,i);

//		if(strchr(sAllowExch,cExch) != NULL)
//		{
			paramsSIPOrd[i].thread_id=i;
			paramsSIPOrd[i].DB_Con = DB_Connect();
			if((pthread_create(&SIP_th_id[i],NULL,SIPOrdExecute,(void *)&paramsSIPOrd[i]))!=0)
				logFatal(" SIP Ord Can't Create Thread [%d]",i);
			else
				logDebug1("SIP Ord Create Thread [%d]",i);
			sleep(2);
//		}

	}


	paramsDaemon.thread_id=0;	
	paramsDaemon.DB_Con = DB_Connect(); 

//	paramsMTM.thread_id=0;	
//	paramsMTM.DB_Con = DB_Connect(); 
/*
	if(mysql_set_server_option(paramsMTM.DB_Con,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2("mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2("mysql_set_server_option FAILed");
		return FALSE;
	}*/
	
	paramsOSPR.thread_id=0;
        paramsOSPR.DB_Con = DB_Connect();

        if(mysql_set_server_option(paramsOSPR.DB_Con,CLIENT_MULTI_STATEMENTS) == 0)
        {
                logDebug2("mysql_set_server_option SUCCESS...");
        }
        else
        {
                logDebug2("mysql_set_server_option FAILED...");
                return FALSE;
        }

	paramsICCL.thread_id=0;
        paramsICCL.DB_Con = DB_Connect();

        if(mysql_set_server_option(paramsICCL.DB_Con,CLIENT_MULTI_STATEMENTS) == 0)
        {
                logDebug2("mysql_set_server_option SUCCESS...");
        }
        else
        {
                logDebug2("mysql_set_server_option FAILED...");
                return FALSE;
        }



	if(cOmstype == OMS_MASTER)
	{	
		paramsDaemon.thread_id=0;	
		paramsDaemon.DB_Con = DB_Connect(); 
		if((pthread_create(&daemon_th_id,NULL,Daemon,(void *)&paramsDaemon))!=0)
		logDebug1("Cant create Daemon thread.");
		else
		logDebug1("Daemon thread Created.");
	}

	/*if((pthread_create(&MTM_th_id,NULL,CheckMTM,(void *)&paramsMTM))!=0)
		logDebug1("Cant create MTM thread.");
	else
		logDebug1("MTM thread Created.");*/

/*
	if((pthread_create(&OSPR_th_id,NULL,CheckOPT_STRK,(void *)&paramsOSPR))!=0)
                logDebug1("Cant create CheckOPT_STRK thread.");
        else
                logDebug1("CheckOPT_STRK thread Created.");
*/

	if((pthread_create(&ICCL_th_id,NULL,CDSLFileUpload,(void *)&paramsICCL))!=0)
                logDebug1("Cant create CDSLFileUpload thread.");
        else
                logDebug1("CDSLFileUpload thread Created.");
	
	for(i=0;i<NO_OF_SEG;i++)
	{
		cExch = i + '0';
		logDebug2("cExch :%c: i :%d:",cExch,i);

//		if(strchr(sAllowExch,cExch) != NULL)
//		{

			logDebug2("[OffOrd] Thread [%d]",i);

			if(pthread_join(OffOrd_th_id[i],NULL)!=0)
				logFatal("[OffOrd] Error when waiting for OffOrder thread [%d] to terminate", i);
			else
				logDebug2("[OffOrd] Stopped Thread [%d]",i);

			/*        logDebug2("[OffOrd] Detaching Thread [%d]",i);

				  if (pthread_detach(&OffOrd_th_id[i])!=0)
				  logFatal("[OffOrd] Error detaching Thread [%d]",i);
				  else
				  logDebug2("[OffOrd] Detached Thread [%d]",i);
			 */
			logDebug2("[OffOrd] Stop Session [%d]",i);
			logDebug2("[OffOrd] Logged Off Offline Orders for Thread [%d]",i);



			logDebug2("[SqOff] Thread [%d]",i);

			if (pthread_join(SqOff_th_id[i],NULL)!=0)
				logFatal("[SqOff] Error when waiting for SqOff thread [%d] to terminate",i);
			else
				logDebug1("[SqOff] Stopped Thread [%d]",i);

			/*        logDebug2("[SqOff] Detaching Thread [%d]",i);

				  if (pthread_detach(&SqOff_th_id[i])!=0)
				  logFatal("[SqOff] Error detaching Thread [%d]",i);
				  else
				  logDebug1("[SqOff] Detached Thread [%d]",i);
			 */
			logDebug2("[SqOff] Stop Session [%d]",i);

			logDebug2("[SqOff] Logged Off Square Off for Thread [%d]",i);

//		}
	}

	for(i=0;i<SEG_SIP;i++)
	{
		cExch = i + '0';
		logDebug2("cExch... = %c : i = %d",cExch,i);

		if(strchr(sAllowExch,cExch) != NULL)
		{
			if(pthread_join(SIP_th_id[i],NULL) !=0)
				logFatal("[SIPOrd] Error when waiting for SqOff thread [%d] to terminate",i);
			else
				logDebug2("[SIPOrd] Stopped Thread [%d]",i);

			logDebug2("[SIPOrd] Stop Session [%d]",i);

			logDebug2("[SIPOrd] Logged Off Square Off for Thread [%d]",i);
		}
	}

	logDebug2("[Daemon] Thread");
	
	if(cOmstype == OMS_MASTER)
	{
		if (pthread_join(daemon_th_id,NULL))
			logFatal("[Daemon] Error when waiting for Daemon thread to terminate");
		else
			logDebug2("[Daemon] Stopped");
	}
/*	if (pthread_join(MTM_th_id,NULL))
		logFatal("[MTM] Error when waiting for MTM thread to terminate");
	else
		logDebug2("[MTM] Stopped");*/
	
	if (pthread_join(CroCurSqOff_th_id,NULL))
		logFatal("[CroCurSqOff] Error when waiting for CroCurSqOff thread to terminate");
	else
		logDebug2("[CroCurSqOff] Stopped");

	if (pthread_join(OSPR_th_id,NULL))
                logFatal("OSPR_th_id Error when waiting for MTM thread to terminate");
        else
                logDebug2("OSPR_th_id Stopped");

	if (pthread_join(ICCL_th_id,NULL))
                logFatal("ICCL_th_id Error when waiting for MTM thread to terminate");
        else
                logDebug2("ICCL_th_id Stopped");

/**/
	/*
	   logDebug2("\n [Daemon] Detach thread...");

	   if (pthread_detach(&daemon_th_id))
	   logFatal("\n [Daemon] Error detaching thread!");
	   else
	   logDebug2("\n [Daemon] Detached!");
	 */
	logDebug2("[Daemon] Stop Session....");

	logDebug2("[Daemon] Logged Off");
	logTimestamp("Exit : [main]");

	//	return(0);

	/**
	  paramsCroCurSqOff.thread_id = 0;
	  paramsCroCurSqOff.DB_Con = DB_Connect();

	  if ((pthread_create(&CroCurSqOff_th_id,NULL,IntrdyCroCurSqOffExec,(void *)&paramsCroCurSqOff)) != 0 )
	  logFatal("[IntradyCroCurSqOff] Cant create thread ");
	  else
	  logDebug1("[CroCusSqOff] Created thread ");

	  if (pthread_join(CroCurSqOff_th_id,NULL))
	  logFatal("[CroCurSqOff] Error when waiting for CroCurSqOff thread to terminate");
	  else
	  logDebug2("[CroCurSqOff] Stopped");
	 ***/	
	return(0);
}

LONG32	SIPOrdExecute(void *parameter)
{
	logTimestamp("Entry SIPOrdExecute");

	MYSQL           *DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	LONG32		iTotalRow;

	LONG32	iCount = 1;
	INT16	th_id;
	LONG32	Mkt;
	CHAR	cMkt_Seg = SEGMENT_EQUITY;
	LONG64	iMktType = 1;
	LONG64	SleepTime = 0;	
	INT16	iMsgType;
	CHAR    sOMSExch[EXCHANGE_LEN];
	CHAR    sMkt_Exch[EXCHANGE_LEN];	
	//	CHAR	sBatchName[SIP_REG_NEM_LEN];
	CHAR    *Qry;
	CHAR    *Fir_Qry;
	CHAR    *Sec_Qry;
	CHAR	cMode = '\0'; 
	CHAR    flag = FALSE;
	INT16   iMktStat;
	LONG32	iGrpId = 1 ;
	struct 	THREAD_PARAMS *l_parameter = parameter;
	struct 	ORDER_REQUEST pReq_SIPOrd;
	th_id = l_parameter->thread_id;

	DB_Con = (MYSQL *)l_parameter->DB_Con;	

	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);
	//	memset(sBatchName,'\0',SIP_REG_NEM_LEN);	

	for(iCount; iCount<=1; iCount++)
	{
		switch(th_id)
		{
			case 0:
				Mkt = BSE_EQU;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    
				logDebug2("BSE sMkt_Exch = %s",sMkt_Exch);
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);  
				iMsgType = 1;
				break;

			case 1:
				Mkt = NSE_EQU; 
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				logDebug2("......NSE sMkt_Exch.... = %s",sMkt_Exch);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;

			default:
				logFatal("[SIPOrd:%d] Invalid market type",th_id);
				break;

		}
		Fir_Qry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Sec_Qry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Qry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

		logDebug2("sMkt_Exch = %s",sMkt_Exch);

		sprintf(Fir_Qry,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))-\
				julidate(sysdate())\
				FROM 	BATCH_PROCESS b \
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \'%c\' \
				AND     b.bp_batch_name = \'%s\'\
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d;",sMkt_Exch,cMkt_Seg,SIP_DAY,iMktType,iGroupId);


		logDebug1("QUERY :%s:",Fir_Qry);

		if (mysql_query(DB_Con,Fir_Qry) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in batch process query [SIPOrdExecute].");
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);
		iTotalRow = mysql_num_rows(Res);
		logDebug2("iTotalRow = %d",iTotalRow);	

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("!!!!!!! Zero row returned !!!!!! ");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			SleepTime = atol(Row[0]);
		}
		if(SleepTime < 0)
		{
			logFatal("[SIPOrd:%d] Error in selecting ETA for :%s:%c:%s:%d:",th_id,sMkt_Exch,cMkt_Seg,SIP_DAY,iMktType);
			return FALSE;
		}
		sleep(SleepTime);

		/*		
				if(strcmp(sFreuency,SIP_MONTH) == 0);
				{
		//			sprintf(Qry1,"SELECT PARAM_VALUE - DATE_FORMAT(SYSDATE(),'%d') FROM SYS_PARAMETERS WHERE PARAM_NAME = 'SIP_MONTHLY';");

		logDebug1("QUERY :%s:",Qry1);
		if (mysql_query(DB_Con,Qry1) != SUCCESS)
		{
		sql_Error(DB_Con);
		logSqlFatal("Error in select param value [SIPOrdExecute].");
		return ERROR;
		}
		Res = mysql_store_result(DB_Con);
		if(mysql_num_rows(Res) == 0)
		{
		logFatal("!!!!!!! Zero row returned !!!!!! ");
		mysql_free_result(Res);
		mysql_close(DB_Con);
		}
		else
		{
		Row = mysql_fetch_row(Res);
		SleepTime = (atol(Row[0]) * 86400);
		}
		if(SleepTime < 0)
		{
		logFatal("Error in Query.");
		}
		if(SleepTime == 0)
		{

		}
		sleep(SleepTime);
		}

		 */
		sprintf(Sec_Qry,"SELECT BP_MODE FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \"%c\"\
				AND     b.bp_batch_name = \'%s\'\
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d;",sMkt_Exch,cMkt_Seg,SIP_DAY,iMktType,iGroupId);

		if (mysql_query(DB_Con,Sec_Qry) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in SELECT BP_MODE [SIPOrdExecute]");
			free(Qry);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("Zero row returned....");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}

		else
		{
			Row = mysql_fetch_row(Res);
			cMode=Row[0][0];
		}
		logDebug1("cMode :%c:",cMode);

		if (cMode != 'A')
		{
			logFatal("[SIPOrd:%d] Batch Process is set to manual for :%s:%c:%s:%d: ",th_id,sMkt_Exch,cMkt_Seg,SIP_DAY,iMktType);
			return FALSE;
		}
		while(1)
		{
			//flag = ReadConnectStatShm( Mkt , iGrpId ); 
			flag = ReadConnectStatShm( Mkt , iOMSGroupId); 
			if(flag == EXCHANGE_UP || cOmstype == OMS_MASTER)     
				break;
			logFatal("[SIPOrd:%d] :%s:%c:%s:%d: Market is not Connected. Retrying",th_id,sMkt_Exch,cMkt_Seg,SIP_DAY,iMktType);
			sleep(WAIT_BEFORE_RETRY);
		}

		logDebug1("[SIPOrd:%d] :%s:%c:%s:%d: Market is Connected.",th_id,sMkt_Exch,cMkt_Seg,SIP_DAY,iMktType);

		switch(th_id)
		{
			case 0:
				while(1)
				{
					sprintf(Qry,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_MKT_TYPE = \'NL\'\
							AND EMM_EXCH_SEG=\'%c\';",sMkt_Exch,cMkt_Seg);

					if (mysql_query(DB_Con,Qry) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("Error in select status.[SIPOrdExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}


					Res = mysql_store_result(DB_Con);
					Row = mysql_fetch_row(Res);
					iMktStat = atoi(Row[0]);

					logDebug1("iMktStat_BSE is :%d",iMktStat);

					if(iMktStat == MKT_OPEN)
						break;
					logDebug1("[SIPOrd:%d] :%s:%c: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[SIPOrd:%d] :%s:%c: Market is Open.",th_id,sMkt_Exch,cMkt_Seg);
				free(Qry);
				break;

			case 1:
				while(1)
				{
					sprintf(Qry,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_MKT_TYPE = \'NL\'\
							AND EMM_EXCH_SEG=\'%c\';",sMkt_Exch,cMkt_Seg);
					logDebug2("Query :%s:",Qry);
					if (mysql_query(DB_Con,Qry) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("Error in SELECT STATUS QUERY [SIPOrdExecute].");
						free(Qry);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);

					Row = mysql_fetch_row(Res);
					iMktStat = atoi(Row[0]);

					logDebug1("iMktStat_NSE is :%d",iMktStat);
					if(iMktStat == MKT_OPEN)
						break;
					logDebug1("[SIPOrd:%d] :%s:%c: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[SIPOrd:%d] :%s:%c: Market is Open.",th_id,sMkt_Exch,cMkt_Seg);

				free(Qry);
				break;

			default:
				logFatal("[SIPOrd:%d] Invalid Type",th_id);
				break;
		}

		memset(&pReq_SIPOrd,'\0',sizeof(struct  ORDER_REQUEST));
		logDebug1("[SIPOrd:%d] Populating Struct.",th_id);
		pReq_SIPOrd.ReqHeader.iSeqNo = iMktType;
		pReq_SIPOrd.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_SIPOrd.ReqHeader.iMsgCode = TC_INT_PUMPSIPORDER_REQ;
		pReq_SIPOrd.ReqHeader.iUserId = atoi(sTempUID);
		logDebug2("USERID=%llu",pReq_SIPOrd.ReqHeader.iUserId);
		pReq_SIPOrd.ReqHeader.cSegment = cMkt_Seg;
		pReq_SIPOrd.cUserType = 'A';
		strncpy(pReq_SIPOrd.sRemarks,"Auto_Success",REMARKS_LEN);
		strncpy(pReq_SIPOrd.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		//		strncpy(pReq_SIPOrd.sGoodTillDaysDate,SIP_DAY,SIP_REG_NEM_LEN);
		//		logDebug2("pReq_SIPOrd.sGoodTillDaysDate = %s",pReq_SIPOrd.sGoodTillDaysDate);

		logDebug2("[SIPOrd:%d] Triggering SIP Orders for :%s:%c:",th_id,sMkt_Exch,cMkt_Seg);
		if(WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_SIPOrd,sizeof(struct ORDER_REQUEST),iMsgType )!= TRUE)  /*---Defined in Queue.c at coc---*/
		{
			logFatal("[SIPOrd] Error WriteQ ");
			logDebug2("[SIPOrd:%d] Write Q id %d",th_id,iRDaemonToSqoff);
			exit(ERROR);
		}
		if(mysql_commit(DB_Con)!=0)
			logFatal("Failed to commit");
		else
			logDebug2("Successfully committed");
		free(Fir_Qry);
		free(Sec_Qry);
		sleep(RESTART_TIME);
	}
	return(0);
	pthread_exit(NULL);
	logTimestamp("Exit SIPOrdExecute");
}

LONG32  OffOrdExecute(void *parameter)
{
	logTimestamp("Entry : [OffOrdExecute]");

	INT16		th_id;
	INT16           iMktStat;
	INT16		iMsgType;
	LONG32  	Mkt,iGrpId = 1,iCount=1;
	CHAR    	flag = FALSE;
	CHAR    	sOMSExch[EXCHANGE_LEN];
	LONG64  	SleepTime,iMktType = 1;
	CHAR    	cMkt_Seg,cMode;
	CHAR    	sMkt_Exch[EXCHANGE_LEN];
	MYSQL		Con;
	MYSQL		*DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	CHAR		*Sel;		
	CHAR		*Fir_Sel;
	CHAR		*Sec_Sel;


	struct THREAD_PARAMS *l_parameter = parameter;
	struct ORDER_REQUEST  pReq_OffOrd;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	th_id = l_parameter->thread_id;


	cMode = '\0';
	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);
	for(iCount; iCount<=2; iCount++)	
	{
		switch(th_id)
		{
			case 0:
				Mkt = BSE_EQU;   /*---#define BSE_EQU 13---*/
				cMkt_Seg = SEGMENT_EQUITY;   /*---#define SEGMENT_EQUITY 'E'---*/
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    /*---EXCHANGE_LEN=6 in ho---*/
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);       /*---EXCH_BSE up there---*/
				iMsgType = 1;
				break;

			case 1:
				Mkt = NSE_EQU;  /*---#define NSE_EQU   11---*/
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;


			case 2:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;

			case 3:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;

			case 4:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_MORNING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;

			case 5:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_EVENING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;

			case 6:
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_SPECIAL_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;
			case 7:
				Mkt = BSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 15;
				break;	
			case 8:
				Mkt = BSE_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;				
 			case 9:
                                Mkt = BSE_DRV;
                                cMkt_Seg = SEGMENT_FNO;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 19;
                                break;
			case 10:
                                Mkt = NSE_CM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
			case 11:
                                Mkt = ICEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,ICEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,ICEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;	
			case 12:
                                Mkt = NCDEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,NCDEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,NCDEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
			case 13:
				Mkt = NSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 2;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;
			case 14:
				Mkt = NSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 3;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;
		//	case 15:
				/* Mkt = BSE_EQU;   /\*---#define BSE_EQU 13---*\/ */
				/* cMkt_Seg = SEGMENT_EQUITY;   /\*---#define SEGMENT_EQUITY 'E'---*\/ */
				/* iMktType = 2; */
				/* strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    /\*---EXCHANGE_LEN=6 in ho---*\/ */
				/* strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);       /\*---EXCH_BSE up there---*\/ */
				/* iMsgType = 1; */
				/* break; */

			     //   Mkt = BSE_DRV;
                               // cMkt_Seg = SEGMENT_FNO;
                               // iMktType = 2;
                               // strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                               // strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                               // iMsgType = 19;
                               // break;

			case 16:
				Mkt = BSE_EQU;   /*---#define BSE_EQU 13---*/
				cMkt_Seg = SEGMENT_EQUITY;   /*---#define SEGMENT_EQUITY 'E'---*/
				iMktType = 3;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    /*---EXCHANGE_LEN=6 in ho---*/
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);       /*---EXCH_BSE up there---*/
				iMsgType = 1;
				break;
			case 17:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 2;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;
			case 18:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 3;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;
			case 19:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 2;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;
			case 20:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 3;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;
			case 21:
                                Mkt = BSE_CUR;
                                cMkt_Seg = SEGMENT_CURRENCY;
                                iMktType = 2;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 1;
                                break;
			case 22:
                                Mkt = BSE_CUR;
                                cMkt_Seg = SEGMENT_CURRENCY;
                                iMktType = 3;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 1;
                                break;
			case 23:
				Mkt = NSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 4;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;
			case 24:
				Mkt = BSE_EQU;   /*---#define BSE_EQU 13---*/
				cMkt_Seg = SEGMENT_EQUITY;   /*---#define SEGMENT_EQUITY 'E'---*/
				iMktType = 4;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);    /*---EXCHANGE_LEN=6 in ho---*/
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);       /*---EXCH_BSE up there---*/
				iMsgType = 1;
				break;
			default:
				logFatal("[OffOrd:%d] Invalid market type",th_id);
				break;
		}


		Fir_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Sec_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

		sprintf(Fir_Sel,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))- julidate(sysdate())\
				FROM BATCH_PROCESS b \
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \'%c\' \
				AND     b.bp_batch_name = \'OFFMKT_PUMP\'\
				AND     b.bp_mkt_type_no = %d \
				ANd	b.bp_group_id = %d ;",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);
		logDebug1("[OffOrd:%d] Sel :%s:",th_id,Fir_Sel);

		if (mysql_query(DB_Con,Fir_Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[OffOrd] Error in batch process query [OffOrdExecute].");
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);
		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[OffOrd]...Zero row returned");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			SleepTime=atol(Row[0]);
		}

		logDebug1("[OffOrd:%d] Success in selecting ETA for :%s:%c:%d:",th_id,sMkt_Exch,cMkt_Seg,iMktType);
		logDebug1("[OffOrd:%d] Pump Offline orders in :%ld: secs for :%s:%c:%d:",th_id,SleepTime,sMkt_Exch,cMkt_Seg,iMktType);


		sleep(SleepTime);


		sprintf(Sec_Sel," SELECT BP_MODE  FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\")) \
				AND     b.bp_segment = \"%c\" \
				AND     b.bp_batch_name = 'OFFMKT_PUMP'\
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);
		logDebug1("[OffOrd] Sel :%s:",Sec_Sel);	

		if (mysql_query(DB_Con,Sec_Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[OffOrd] Error in select BP mode [OffOrdExecute].");
			mysql_close(DB_Con);
			return ERROR;
		}
		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[OffOrd].....Zero row returned.......");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;	
		}
		else
		{
			Row = mysql_fetch_row(Res);
			cMode=Row[0][0];
		}
		logDebug1("[OffOrd] cMode :%c:",cMode);

		if (cMode != 'A')
		{
			logFatal("[OffOrd:%d] Batch Process is set to manual for :%s:%c:%d: ",th_id,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}
		while(1)
		{
			//flag = ReadConnectStatShm( Mkt , iGrpId ); /*---Defined in ConnectStatus.c located at coc---*/
			flag = ReadConnectStatShm( Mkt , iOMSGroupId); /*---Defined in ConnectStatus.c located at coc---*/
			if(flag == EXCHANGE_UP || cOmstype == OMS_MASTER)     /** flag is used to check the connection status in shm */
				break;
			logFatal("[OffOrd:%d] :%s:%c:%d: Market is not Connected. Retrying",th_id,sMkt_Exch,cMkt_Seg,iMktType);
			sleep(WAIT_BEFORE_RETRY);
		}

		logDebug1("[OffOrd:%d] :%s:%c:%d: Market is Connected.",th_id,sMkt_Exch,cMkt_Seg,iMktType);
		switch(th_id)
		{
			case 0:
				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG = \'%c\' ",sMkt_Exch,cMkt_Seg);
					//	logDebug2("Query-- %s",Sel);					


					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[OffOrd] Error in select status.[OffOrdExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}


					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[OffOrd] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[OffOrd] Value is: %d",iMktStat);
                                        }

					//logDebug2("Values:%s",Row[0]);
					
					if(iMktStat == MKT_OPEN || iMktStat == MKT_PREOPEN)
						break;
					logDebug1("[OffOrd:%d] :%s:%c: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[OffOrd:%d] :%s:%c: Market is Open.",th_id,sMkt_Exch,cMkt_Seg);
				free(Sel);
				break;

			case 1:
				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG=\'%c\';",sMkt_Exch,cMkt_Seg);
					logDebug2("[OffOrd] Sel :%s:",Sel);
					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[OffOrd] Error in SELECT STATUS QUERY [OffOrdExecute].");
						free(Sel);
						mysql_close(DB_Con);
						return ERROR;
					}	

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[OffOrd] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[OffOrd] Value is: %d",iMktStat);
                                        }

					/*In If MKT_PREOPEN checked is added for pumping offline orders*/
					if(iMktStat == MKT_OPEN || iMktStat == MKT_PREOPEN)
						break;
					logDebug1("[OffOrd:%d] :%s:%c: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[OffOrd:%d] :%s:%c: Market is Open.",th_id,sMkt_Exch,cMkt_Seg);

				free(Sel);
				break;

			case 2:
			  /** NSE DERIVATIVE   **/
			case 3:
			  /** NSE CURRENCY  **/
		        case 9:/** BSE CURRENCY  **/
			case 11:/** BSE DERIVATIVE   **/

				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS \
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE =\'NL\';",sMkt_Exch,cMkt_Seg);


					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[OffOrd] Error in SELECT STATUS [OffOrdExecute].");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[OffOrd] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[OffOrd] Value is: %d",iMktStat);
                                        }

					if(iMktStat == MKT_OPEN )
						break;
					logDebug1("[OffOrd:%d] :%s:%c: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}	
				logDebug1("[OffOrd:%d] :%s:%c: Market is Open.",th_id,sMkt_Exch,cMkt_Seg);

				free(Sel);
				break;

			case 4:         /***MCX_Morning Session***/
			case 5:         /***MCX_Evening Session***/
			case 6:         /***MCX_Special Seesion***/

				while(1)
				{
					Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
					sprintf(Sel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG =\'%c\' AND EMM_MKT_TYPE_NO = %d",sMkt_Exch,cMkt_Seg,iMktType);
					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[OffOrd] Error in select status query..... [OffOrdExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[OffOrd] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[OffOrd] Value is: %d",iMktStat);
                                        }

					if(iMktStat == MKT_OPEN )
                                        {
                                                logDebug1("[OffOrdExecute:%d] :%s:%c: Market is Open.",th_id,sMkt_Exch,cMkt_Seg);
                                                break;
                                        }
                                        else
                                        {
                                                logDebug1("[OffOrdExecute SqOff:%d] :%s:%c: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg);
                                                sleep(WAIT_BEFORE_RETRY);
                                        }

				//	if(iMktStat == MKT_OPEN)
				//		break;
				//	logDebug1("[OffOrd:%d] :%s:%c:%d: Market is Closed. Retrying",th_id,sMkt_Exch,cMkt_Seg,iMktType);
				//	sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[OffOrd:%d] :%s:%c:%d: Market is Open.",th_id,sMkt_Exch,cMkt_Seg,iMktType);

				free(Sel);
				break;

			default:
				logFatal("[OffOrd:%d] Invalid Type",th_id);
				break;
		}

		memset(&pReq_OffOrd,'\0',sizeof(struct  ORDER_REQUEST));
		logDebug1("[OffOrd:%d] Populating Struct.",th_id);
		pReq_OffOrd.ReqHeader.iSeqNo = iMktType;
		logDebug2("[OffOrd] pReq_OffOrd.ReqHeader.iSeqNo :%d:",pReq_OffOrd.ReqHeader.iSeqNo);
		pReq_OffOrd.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_OffOrd.ReqHeader.iMsgCode = TC_INT_PUMPOFFLINE_REQ;
		pReq_OffOrd.ReqHeader.iUserId = atoi(sTempUID);
		logDebug2("[OffOrd] USERID=%llu",pReq_OffOrd.ReqHeader.iUserId);
		pReq_OffOrd.ReqHeader.cSegment = cMkt_Seg;
		pReq_OffOrd.cUserType = 'A';
		strncpy(pReq_OffOrd.sRemarks,"Auto_Success",REMARKS_LEN);
		strncpy(pReq_OffOrd.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);

		logDebug2("[OffOrd:%d] Triggering Offline Orders for :%s:%c:",th_id,sMkt_Exch,cMkt_Seg);
		if(WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_OffOrd,sizeof(struct ORDER_REQUEST),iMsgType )!= TRUE)  /*---Defined in Queue.c at coc---*/
		{
			logFatal("[OffOrd] Error WriteQ ");
			logDebug2("[OffOrd:%d] Write Q id %d",th_id,iRDaemonToSqoff);
			exit(ERROR);
		}
		if(mysql_commit(DB_Con)!=0)
			logFatal("[OffOrd] Failed to commit");
		else
			logDebug2("[OffOrd] Successfully committed");
		free(Fir_Sel);
		free(Sec_Sel);
		sleep(RESTART_TIME);
	}
	logTimestamp("Exit : [OffOrdExecute]");
	return(0);
	pthread_exit(NULL);
}


LONG32 fCoverSqOffExecute (void *parameter)
{
	logTimestamp("Entry : [fCoSqOffExecute]");
	INT16           th_idn;
	LONG32          Mkt,iGrpId = 1,iCnt=1;
	CHAR            flag = FALSE;
	CHAR            sOMSExch[EXCHANGE_LEN];
	INT16           iMsgType;
	MYSQL           DBC;
	MYSQL           *DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	INT16           iMktStat;
	CHAR            cMkt_Seg,cMode ,cProd;
	CHAR            sMkt_Exch[EXCHANGE_LEN];
	CHAR            lvar_uid[30];
	LONG64          SleepTime = 0,iMktType = 1;
	/*
	   CHAR            *Firs_Sel;
	   CHAR            *Seco_Sel;
	   CHAR            *Sel; */
	CHAR sBatchSel [MAX_QUERY_SIZE];
	CHAR sModeSel [MAX_QUERY_SIZE];
	CHAR sStatusSel [MAX_QUERY_SIZE];

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	th_idn = l_parameter->thread_id;


	//      DB_Con = l_parameter->DB_Con[th_id];
	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);

	cMode = '\0';
	struct  CO_ORDER_REQUEST      pReq_SqOff;

	logDebug2("[CoSqOff] fCoverSqOffExecute th_idn :%d:",th_idn);
	logDebug2("[CoSqOff] fCoverSqOffExecute iCnt   :%d:",iCnt);
	for(iCnt ; iCnt<=2; iCnt++)
	{
		switch(th_idn)
		{
			case 0:
				Mkt = BSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
				iMsgType = 8;
				break;

			case 1:
				Mkt = NSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 5;
				break;

			case 2:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 6;
				break;

			case 3:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 7;
				break;

			case 4:         /*MCX_morningSession*/

				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_MORNING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 12;
				break;

			case 5:         /*MCX_eveningSession*/
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_EVENING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 12;
				break;

			case 6:         /*MCX_SpecialSession*/
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_SPECIAL_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 12;
				break;
			case 7:
				Mkt = BSE_CUR;
                                cMkt_Seg = SEGMENT_CURRENCY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 17;
                                break;			
                        case 8:
                                Mkt = BSE_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
                        case 9:
                                Mkt = BSE_DRV;
                                cMkt_Seg = SEGMENT_FNO;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 19;
                                break;
                        case 10:
                                Mkt = NSE_CM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
                        case 11:
                                Mkt = ICEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,ICEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,ICEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
			 case 12:
                                Mkt = NCDEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,NCDEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,NCDEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
				break;

			default:
				logDebug1("[CoSqOff] Invalid market (mysql_query(DB_Con,Sel) != SUCCESS");
				break;
		}
		//                Firs_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

		memset(sBatchSel,'\0',MAX_QUERY_SIZE);
		memset(sModeSel,'\0',MAX_QUERY_SIZE);
		//                Seco_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		//                Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		sprintf(sBatchSel,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))-julidate(sysdate())\
				FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id =ltrim(rtrim( \"%s\")) \
				AND     b.bp_segment = \"%c\" \
				AND     b.bp_batch_name = \'CO_SQ_OFF\' \
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d ;",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);

		logDebug1("[CoSqOff] Sel :%s:",sBatchSel);

		if (mysql_query(DB_Con,sBatchSel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[CoSqOff] Error in select juliDate [fCoverSqOffExecute]");
			//                        free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[CoSqOff] ******* Zero row returned ******");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			SleepTime=atol(Row[0]);
		}

		if(SleepTime < 0)
		{
			logFatal("[CoSqOff:%d] Error in selecting  ETA  :%s:%c:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}
		sleep(SleepTime);
		sprintf(sModeSel,"SELECT BP_MODE FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \"%c\"\
				AND     b.bp_batch_name = \"%s\"\
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d ;",sMkt_Exch,cMkt_Seg,COVER_ORD_SQUREOFF,iMktType,iGroupId);

		if (mysql_query(DB_Con,sModeSel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[CoSqOff] Error in SELECT BP_MODE [fCoverSqOffExecute]");
			//                        free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[CoSqOff] .......Zero row returned..........");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}

		else
		{
			Row = mysql_fetch_row(Res);
			cMode=Row[0][0];
		}

		if (cMode != 'A')
		{
			logDebug2("[CoSqOff:%d] Batch Process is set to manual for :%s:%c:%d: ",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}

		while(1)
		{
			//flag = ReadConnectStatShm( Mkt , iGrpId );
			flag = ReadConnectStatShm( Mkt , iOMSGroupId);
			if(flag == EXCHANGE_UP || cOmstype == OMS_MASTER)     /** flag is used to check the connection status in shm */
				break;
			logDebug1("[CoSqOff:%d] :%s:%c:%d: Market is not Connected. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			sleep(WAIT_BEFORE_RETRY);
		}
		logDebug1("[CoSqOff:%d] :%s:%c:%d: Market is Connected.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

		switch(th_idn)
		{
			case 0:         /***BSE EQ***/
				while(1)
				{
					sprintf(sStatusSel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG =\'%c\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[CoSqOff] Error in Query.. [fCoverSqOffExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[CoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
						logDebug1("[CoSqOff] Value is: %d",iMktStat);
                                        }
					if(iMktStat == MKT_OPEN)

						break;
					logDebug1("[CoSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[CoSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
				//                                        free(Sel);
				break;

			case 1:
				while(1)
				{

					memset(sStatusSel,'\0',MAX_QUERY_SIZE);
					sprintf(sStatusSel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\"))  AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG =\'%c\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[CoSqOff] Error in Query.. [fCoverSqOffExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[CoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[CoSqOff] Value is: %d",iMktStat);
                                        }

					if(iMktStat == MKT_OPEN)
						break;
					logDebug1("[CoSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[CoSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
				//                                        free(Sel);
				break;

			case 2:
			case 3:
				while(1)
				{
					memset(sStatusSel,'\0',MAX_QUERY_SIZE);
					sprintf(sStatusSel,"SELECT EMM_STATUS \
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE = \'NL\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[CoSqOff] ERROR in QUERY. [fCoverSqOffExecute]");
						//                                                free(Sel);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[CoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[CoSqOff] Value is: %d",iMktStat);
                                        }


					if(iMktStat == MKT_OPEN)
						break;
					logFatal("[CoSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}


				logDebug1("[CoSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);

				//                                        free(Sel);
				break;
			case 4:         /***MCX_Morning Session***/
			case 5:         /***MCX_Evening Session***/
			case 6:         /***MCX_Special Seesion***/

				while(1)
				{
					sprintf(sStatusSel," SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE_NO = %d",sMkt_Exch,cMkt_Seg,iMktType);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[CoSqOff] Err in qry [IntradySqOffExecute].");
						free(sStatusSel);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[CoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[CoSqOff] Value is: %d",iMktStat);
                                        }

					if(iMktStat == MKT_OPEN)
						break;
					logDebug1("[CoSqOff:%d] :%s:%c:%d: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[CoSqOff:%d] :%s:%c:%d: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

		//		free(sStatusSel);
				break;

		}
		memset(&pReq_SqOff,'\0',sizeof(struct  CO_ORDER_REQUEST));
		logDebug1("[CoSqOff:%d] Populating Struct.",th_idn);
		pReq_SqOff.ReqHeader.iSeqNo = iMktType;
		pReq_SqOff.ReqHeader.iMsgLength  = sizeof(struct CO_ORDER_REQUEST);
		pReq_SqOff.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_COVER_ORD_REQ;
		pReq_SqOff.ReqHeader.iUserId = atoi(sTempUID);
		pReq_SqOff.ReqHeader.cSegment = cMkt_Seg;
		pReq_SqOff.cUserType = 'A';
		strncpy(pReq_SqOff.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		strncpy(pReq_SqOff.sRemarks,"Auto_Success",REMARKS_LEN);
		logDebug1("[CoSqOff:%d] Triggering Square Off for MsgType :%s:%c:%d:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType,iMsgType);
		if((WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_SqOff,sizeof(struct CO_ORDER_REQUEST),iMsgType)!= TRUE))  /*---Defined in Queue.c at coc---*/
		{
			logFatal("[CoSqOff] Error WriteQ ");
			logDebug1("[CoSqOff:%d] Write Q id %d",th_idn,iRDaemonToSqoff);
			exit(ERROR);
		}

		if(mysql_commit(DB_Con)!=0)
			logDebug1("[CoSqOff] Failed to commit");
		else
			logDebug1("[CoSqOff] Successfully committed");
		//                free(Firs_Sel);
		//                free(Seco_Sel);
		sleep(RESTART_TIME);
	}
	logTimestamp("Exit : [CoSqOff]");
	return(0);
	pthread_exit(NULL);
}

LONG32 fBracketSqOffExecute (void *parameter)
{
	logTimestamp("Entry : [fBoSqOffExecute]");
	INT16           th_idn;
	LONG32          Mkt,iGrpId = 1,iCnt=1;
	CHAR            flag = FALSE;
	CHAR            sOMSExch[EXCHANGE_LEN];
	INT16           iMsgType;
	MYSQL           DBC;
	MYSQL           *DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	INT16           iMktStat;
	CHAR            cMkt_Seg,cMode ,cProd;
	CHAR            sMkt_Exch[EXCHANGE_LEN];
	CHAR            lvar_uid[30];
	LONG64          SleepTime = 0,iMktType = 1;
	/*
	   CHAR            *Firs_Sel;
	   CHAR            *Seco_Sel;
	   CHAR            *Sel; */
	CHAR sBatchSel [MAX_QUERY_SIZE];
	CHAR sModeSel [MAX_QUERY_SIZE];
	CHAR sStatusSel [MAX_QUERY_SIZE];

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	th_idn = l_parameter->thread_id;


	//      DB_Con = l_parameter->DB_Con[th_id];
	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);

	cMode = '\0';
	struct  BO_ORDER_REQUEST      pReq_SqOff;

	logDebug2("[BoSqOff] fBracketSqOffExecute th_idn :%d:",th_idn);
	logDebug2("[BoSqOff] fBracketSqOffExecute iCnt   :%d:",iCnt);
	for(iCnt ; iCnt<=2; iCnt++)
	{
		switch(th_idn)
		{
			case 0:
				Mkt = BSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
				iMsgType = 12;
				break;

			case 1:
				Mkt = NSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 9;
				break;

			case 2:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 10;
				break;

			case 3:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 11;
				break;

			case 4:         /*MCX_morningSession*/

				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_MORNING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 13;
				break;

			case 5:         /*MCX_eveningSession*/
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_EVENING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 13;
				break;

			case 6:         /*MCX_SpecialSession*/
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_SPECIAL_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 13;
				break;
			case 7:
                                Mkt = BSE_CUR;
                                cMkt_Seg = SEGMENT_CURRENCY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 18;
                                break;
                        case 8:
                                Mkt = BSE_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
                        case 9:
                                Mkt = BSE_DRV;
                                cMkt_Seg = SEGMENT_FNO;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 19;
                                break;
                        case 10:
                                Mkt = NSE_CM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
                        case 11:
                                Mkt = ICEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,ICEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,ICEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
			 case 12:
                                Mkt = NCDEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,NCDEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,NCDEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
				break;
			default:
				logDebug1("[BoSqOff] Invalid market (mysql_query(DB_Con,Sel) != SUCCESS");
				break;
		}
		//                Firs_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

		memset(sBatchSel,'\0',MAX_QUERY_SIZE);
		memset(sModeSel,'\0',MAX_QUERY_SIZE);
		//                Seco_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		//                Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		sprintf(sBatchSel,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))-julidate(sysdate())\
				FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id =ltrim(rtrim( \"%s\")) \
				AND     b.bp_segment = \"%c\" \
				AND     b.bp_batch_name = \"%s\" \
				AND     b.bp_mkt_type_no = %d \
				AND 	b.bp_group_id = %d;",sMkt_Exch,cMkt_Seg,BRACKET_ORD_SQUREOFF,iMktType,iGroupId);

		logDebug1("[BoSqOff] Sel :%s:",sBatchSel);

		if (mysql_query(DB_Con,sBatchSel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[BoSqOff] Error in select juliDate [fBracketSqOffExecute]");
			//                        free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[BoSqOff] ******* Zero row returned ******");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			SleepTime=atol(Row[0]);
		}
		logDebug2("[BoSqOff] SleepTime :%ld:",SleepTime);
		if(SleepTime < 0)
		{
			logFatal("[BoSqOff:%d] Error in selecting  ETA  :%s:%c:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}
		sleep(SleepTime);
		sprintf(sModeSel,"SELECT BP_MODE FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \"%c\"\
				AND     b.bp_batch_name = \"%s\" \
				AND     b.bp_mkt_type_no = %d \ 
				AND 	b.bp_group_id = %d;",sMkt_Exch,cMkt_Seg,BRACKET_ORD_SQUREOFF,iMktType,iGroupId);

		if (mysql_query(DB_Con,sModeSel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[BoSqOff] Error in SELECT BP_MODE [fBracketSqOffExecute]");
			//                        free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[BoSqOff] $$$$$$$ Zero row returned $$$$$");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}

		else
		{
			Row = mysql_fetch_row(Res);
			cMode=Row[0][0];
		}
		if (cMode != 'A')
		{
			logDebug2("[BoSqOff:%d] Batch Process is set to manual for :%s:%c:%d: ",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}

		while(1)
		{
			//flag = ReadConnectStatShm( Mkt , iGrpId );
			flag = ReadConnectStatShm( Mkt , iOMSGroupId);
			if(flag == EXCHANGE_UP || cOmstype == OMS_MASTER)     /** flag is used to check the connection status in shm */
				break;
			logDebug1("[BoSqOff:%d] :%s:%c:%d: Market is not Connected. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			sleep(WAIT_BEFORE_RETRY);
		}
		logDebug1("[BoSqOff:%d] :%s:%c:%d: Market is Connected.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

		switch(th_idn)
		{
			case 0:         /***BSE EQ***/
				while(1)
				{
					sprintf(sStatusSel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_EXCH_SEG = \'%c\' AND EMM_MKT_TYPE = \'NL\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[BoSqOff] Error in Query.. [fBracketSqOffExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[BoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
						logDebug1("[BoSqOff] Value is: %d",iMktStat);
                                        }
					if(iMktStat == MKT_OPEN)

						break;
					logDebug1("[BoSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[BoSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
				//                                        free(Sel);
				break;

			case 1:
				while(1)
				{

					memset(sStatusSel,'\0',MAX_QUERY_SIZE);
					sprintf(sStatusSel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\"))  AND EMM_EXCH_SEG = \'%c\' AND EMM_MKT_TYPE = \'NL\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[BoSqOff] Error in Query.. [fBracketSqOffExecute ]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[BoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[BoSqOff] Value is: %d",iMktStat);
                                        }

					if(iMktStat == MKT_OPEN)
						break;
					logDebug1("[BoSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[BoSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
				//                                        free(Sel);
				break;
			case 2:
			case 3:
				while(1)
				{
					memset(sStatusSel,'\0',MAX_QUERY_SIZE);
					sprintf(sStatusSel,"SELECT EMM_STATUS \
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE = \'NL\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[BoSqOff] ERROR in QUERY. [fBracketSqOffExecute ]");
						//                                                free(Sel);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[BoSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
						logDebug1("[BoSqOff] Value is: %d",iMktStat);
                                        }

					if(iMktStat == MKT_OPEN)
						break;
					logFatal("[BoSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}


				logDebug1("[BoSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);

				//                                        free(Sel);
				break;
			case 4:         /***MCX_Morning Session***/
			case 5:         /***MCX_Evening Session***/
			case 6:         /***MCX_Special Seesion***/

					while(1)
					{
						sprintf(sStatusSel," SELECT EMM_STATUS\
								FROM EXCH_MKT_MASTER\
								WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE_NO = %d",sMkt_Exch,cMkt_Seg,iMktType);
						if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
						{
							sql_Error(DB_Con);
							logSqlFatal("[BoSqOff] Err in qry [IntradySqOffExecute].");
							free(sStatusSel);
							mysql_close(DB_Con);
							return ERROR;
						}

						Res = mysql_store_result(DB_Con);
						/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
						if((Row = mysql_fetch_row(Res)))
	                                        {
	                                                logDebug2("[BoSqOff] Row :%s:",Row[0]);
        	                                        iMktStat = atoi(Row[0]);
                	                                logDebug1("[BoSqOff] Value is: %d",iMktStat);
                        	                }

						if(iMktStat == MKT_OPEN)
							break;
						logDebug1("[BoSqOff:%d] :%s:%c:%d: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
						sleep(WAIT_BEFORE_RETRY);
					}
					logDebug1("[BoSqOff:%d] :%s:%c:%d: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

//					free(sStatusSel);
					break;
		//}

	}
	memset(&pReq_SqOff,'\0',sizeof(struct  BO_ORDER_REQUEST));
	logDebug1("[BoSqOff:%d] Populating Struct.",th_idn);
	pReq_SqOff.ReqHeader.iSeqNo = iMktType;
	pReq_SqOff.ReqHeader.iMsgLength  = sizeof(struct BO_ORDER_REQUEST);
	pReq_SqOff.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_BRACKET_ORD_REQ;
	pReq_SqOff.ReqHeader.iUserId = atoi(sTempUID);
	pReq_SqOff.ReqHeader.cSegment = cMkt_Seg;
	pReq_SqOff.cUserType = 'A';
	strncpy(pReq_SqOff.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
	strncpy(pReq_SqOff.sRemarks,"Auto_Success",REMARKS_LEN);
	logDebug1("[BoSqOff:%d] Triggering  Square Off for MsgType :%s:%c:%d:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType,iMsgType);
	if((WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_SqOff,sizeof(struct BO_ORDER_REQUEST),iMsgType)!= TRUE))  /*---Defined in Queue.c at coc---*/
	{
		logFatal("[BoSqOff] Error WriteQ ");
		logDebug1("[BoSqOff] [%d] Write Q id %d",th_idn,iRDaemonToSqoff);
		exit(ERROR);
	}

	if(mysql_commit(DB_Con)!=0)
		logDebug1("[BoSqOff] Failed to commit");
	else
		logDebug1("[BoSqOff] Successfully committed");
	//                free(Firs_Sel);
	//                free(Seco_Sel);
		sleep(RESTART_TIME);
	}
	logTimestamp("Exit : [fBoSqOffExecute]");
	return(0);
	pthread_exit(NULL);
}						



LONG32 IntradySqOffExecute (void *parameter)
{
	logTimestamp("Entry : [IntSqOffExecute]");

	INT16   	th_idn;
	LONG32  	Mkt,iGrpId = 1,iCnt=1;
	CHAR    	flag = FALSE;
	CHAR    	sOMSExch[EXCHANGE_LEN];
	INT16   	iMsgType;
	MYSQL		DBC;
	MYSQL		*DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	INT16   	iMktStat;
	CHAR            cMkt_Seg,cMode ,cProd;
	CHAR 		sMkt_Exch[EXCHANGE_LEN];
	CHAR 		lvar_uid[30];
	LONG64          SleepTime = 0,iMktType = 1;	
	CHAR		*Firs_Sel;
	CHAR		*Seco_Sel;
	CHAR		*Sel;

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	th_idn = l_parameter->thread_id;


	//	DB_Con = l_parameter->DB_Con[th_id];
	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);

	cMode = '\0';
	struct  ORDER_REQUEST      pReq_SqOff;
	for(iCnt ; iCnt<=2; iCnt++)
	{
		switch(th_idn)
		{
			case 0:
				Mkt = BSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
				iMsgType = 1;
				break;

			case 1:
				Mkt = NSE_EQU;
				cMkt_Seg = SEGMENT_EQUITY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 2;
				break;

			case 2:
				Mkt = NSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;

			case 3:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				iMsgType = 3;
				break;

			case 4:         /*MCX_morningSession*/

				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_MORNING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;

			case 5:         /*MCX_eveningSession*/
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_EVENING_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;

			case 6:         /*MCX_eveningSession*/
				Mkt = MCX_COM;
				cMkt_Seg = SEGMENT_COMMODITY;
				iMktType = MCX_SPECIAL_SESS;
				strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,MCX_EXCH,EXCHANGE_LEN);
				iMsgType = 4;
				break;
			case 7:
                                Mkt = BSE_CUR;
                                cMkt_Seg = SEGMENT_CURRENCY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 15;
                                break;
                        case 8:
                                Mkt = BSE_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = 1;
                                strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
                                iMsgType = 4;
                                break;
			case 9:         /*ICEX_morningSession*/

                                Mkt = ICEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = MCX_MORNING_SESS;
                                strncpy(sMkt_Exch,ICEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,ICEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 16;
                                break;

                        case 10:         /*ICEX_eveningSession*/
                                Mkt = ICEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = MCX_EVENING_SESS;
                                strncpy(sMkt_Exch,ICEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,ICEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 16;
                                break;

                        case 11:         /*ICEX_eveningSession*/
                                Mkt = ICEX_COM;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                iMktType = MCX_SPECIAL_SESS;
                                strncpy(sMkt_Exch,ICEX_EXCH,EXCHANGE_LEN);
                                strncpy(sOMSExch,ICEX_EXCH,EXCHANGE_LEN);
                                iMsgType = 16;
                                break;

		         case 12:
				
				logDebug1("In BSE DRV case 12 mpsv ");
				Mkt = BSE_DRV;
				cMkt_Seg = SEGMENT_FNO;
				iMktType = 1;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,BSE_EXCH,EXCHANGE_LEN);
				iMsgType = 19;
				break;

			default:
				logDebug1("[IntSqOff:%d] Invalid market (mysql_query(DB_Con,Sel) != SUCCESS");
				break;
		}

		Firs_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Seco_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		sprintf(Firs_Sel,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))-julidate(sysdate())\
				FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id =ltrim(rtrim( \"%s\")) \
				AND     b.bp_segment = \"%c\" \
				AND     b.bp_batch_name = \'I_SQ_OFF\' \
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d;",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);

		logDebug1("[IntSqOff] Sel :%s:",Firs_Sel);

		if (mysql_query(DB_Con,Firs_Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[IntSqOff] Error in select juliDate [IntradySqOffExecute]");
			free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);
		logDebug2("[IntSqOff] Res :%d:",mysql_num_rows(Res));
		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[IntSqOff] ******* Zero row returned ******");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			SleepTime=atol(Row[0]);
		}
		logDebug2("[IntSqOff] SleepTime :%ld:",SleepTime);

		if(SleepTime < 0)
		{
			logFatal("[IntSqOff:%d] Error in selecting ETA for :%s:%c:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}
		sleep(SleepTime);
		sprintf(Seco_Sel,"SELECT BP_MODE FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \"%c\"\
				AND     b.bp_batch_name = \'I_SQ_OFF\'\
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d ;",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);

		if (mysql_query(DB_Con,Seco_Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("[IntSqOff] Error in SELECT BP_MODE [IntradySqOffExecute]");
			free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[IntSqOff] $$$$$$$ Zero row returned $$$$$");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;	
		}

		else
		{
			Row = mysql_fetch_row(Res);
			cMode=Row[0][0];
		}

		if (cMode != 'A')
		{
			logDebug2("[IntSqOff:%d] Batch Process is set to manual for :%s:%c:%d: ",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}

		while(1)
		{
			//flag = ReadConnectStatShm( Mkt , iGrpId );
			flag = ReadConnectStatShm( Mkt , iOMSGroupId);
			if(flag == EXCHANGE_UP || cOmstype == OMS_MASTER)     /** flag is used to check the connection status in shm */
				break;
			logDebug1("[IntSqOff:%d] :%s:%c:%d: Market is not Connected. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			sleep(WAIT_BEFORE_RETRY);
		}
		logDebug1("[IntSqOff:%d] :%s:%c:%d: Market is Connected.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

		switch(th_idn)
		{
			case 0:         /***BSE EQ***/
		        case 12:
				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG = \'%c\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[IntSqOff] Error in Query.. [IntradySqOffExecute]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
					{
						logDebug2("[IntSqOff] Row :%s:",Row[0]);
						iMktStat = atoi(Row[0]);
                                                logDebug1("[IntSqOff] Value is: %d",iMktStat);
					}

					if(iMktStat == MKT_OPEN)
						break;
					logDebug1("[IntSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[IntSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
				free(Sel);
				break;
			case 1:
				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG = \'%c\'",sMkt_Exch,cMkt_Seg);
					/* for debugging purpose logDebug2 uses @Rohit*/
					logDebug2("[IntSqOff] Sel :%s:",Sel);
					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[IntSqOff] Error in QUERY [IntradySqOffExecute].");
						free(Sel);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
					{
						logDebug2("[IntSqOff] Row :%s:",Row[0]);
						iMktStat = atoi(Row[0]);
						logDebug1("[IntSqOff] Value is: %d",iMktStat);
					}
					if(iMktStat == MKT_OPEN)
						break;
					logFatal("[IntSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}
				logDebug1("[IntSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);

				free(Sel);
				break;

			case 2:
			case 3:
		        //case 7:
		        case 15:

				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS \
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE = \'NL\' ;",sMkt_Exch,cMkt_Seg);


					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[IntSqOff] ERROR in QUERY. [IntradySqOffExecute]");
						free(Sel);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);

					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
					{
						logDebug2("[IntSqOff] Row :%s:",Row[0]);
						iMktStat = atoi(Row[0]);
						logDebug1("[IntSqOff] Value is: %d",iMktStat);
					}
					if(iMktStat == MKT_OPEN)
						break;
					logFatal("[IntSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
					sleep(WAIT_BEFORE_RETRY);
				}

				logDebug1("[IntSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);

				free(Sel);
				break;

			case 4:         /***MCX_Morning Session***/
			case 5:         /***MCX_Evening Session***/
			case 6:		/***MCX_Special Seesion***/
			case 7:
			case 9:		/***ICEX_Morning Session***/
			case 10:	/***ICEX_Evening Session***/
			case 11:	/***ICEX_Special Seesion***/
				while(1)
				{
					sprintf(Sel," SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) AND EMM_EXCH_SEG = \"%c\" AND EMM_MKT_TYPE_NO = %d",sMkt_Exch,cMkt_Seg,iMktType);
					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[IntSqOff] Err in qry [IntradySqOffExecute].");
						free(Sel);
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("[IntSqOff] Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("[IntSqOff] Value is: %d",iMktStat);
                                        }

					
				/*	if(iMktStat == MCX_OPEN)
						break;
					logDebug1("[IntradySqOffExecute SqOff:%d] :%s:%c:%d: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
					sleep(WAIT_BEFORE_RETRY);
				}*/
					if(iMktStat == MKT_OPEN)
                                        {
                                                logDebug1("[IntSqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
                                                break;
                                        }
                                        else
                                        {
                                                logDebug1("[IntSqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
                                                sleep(WAIT_BEFORE_RETRY);
                                        }
                                }

				logDebug1("[IntSqOff:%d] :%s:%c:%d: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

				free(Sel);
				break;
		}
		memset(&pReq_SqOff,'\0',sizeof(struct  ORDER_REQUEST));
		logDebug1("[IntSqOff:%d] Populating Struct.",th_idn);
		pReq_SqOff.ReqHeader.iSeqNo = iMktType;
		logDebug2("[IntSqOff] pReq_SqOff.ReqHeader.iSeqNo :%d:",pReq_SqOff.ReqHeader.iSeqNo);
		pReq_SqOff.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_SqOff.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_INTRADAY_REQ;
		pReq_SqOff.ReqHeader.iUserId = atoi(sTempUID);
		pReq_SqOff.ReqHeader.cSegment = cMkt_Seg;
		pReq_SqOff.cUserType = 'A';
		strncpy(pReq_SqOff.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		strncpy(pReq_SqOff.sRemarks,"Auto_Success",REMARKS_LEN);
		logDebug1("[IntSqOff:%d] Triggering  Square Off for MsgType :%s:%c:%d:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType,iMsgType);
		if((WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_SqOff,sizeof(struct ORDER_REQUEST),iMsgType)!= TRUE))  /*---Defined in Queue.c at coc---*/
		{
			logFatal("[IntSqOff] Error WriteQ ");
			logDebug1("[IntSqOff:%d] Write Q id %d",th_idn,iRDaemonToSqoff);
			exit(ERROR);
		}



		if(mysql_commit(DB_Con)!=0)
			logDebug1("[IntSqOff Failed to commit");
		else
			logDebug1("[IntSqOff Successfully committed");
		free(Firs_Sel);
		free(Seco_Sel);
		sleep(RESTART_TIME);
	}
	logTimestamp("Exit : [IntSqOffExecute]");
	return(0);
	pthread_exit(NULL);

}



void OpenMsgQue()
{
	logTimestamp("Entry : [OpenMsgQue]");
	/*****
	  if((iRDaemonToOffPump = OpenMsgQ(RDaemonToOffPump)) == ERROR)
	  {
	  perror("\n OpenMsgQ ...RDaemonToOffPump");
	  exit(ERROR);
	  }
	 *****/ //This Queue is romved due to merging of IntSqrOff and OffPumper process
	if((iRDaemonToSqoff= OpenMsgQ(RDaemonToSqoff)) == ERROR)
	{
		perror("\n OpenMsgQ ...RDaemonToSqoff");
		exit(ERROR);
	}

	if((iTrdRtrToD2C =  OpenMsgQ(MmapToD2C1)) == ERROR)  /*******  MTM Breach Info to Dealer and Client *******/ 
	{
		logFatal("Error in Opening RelayDir2ItsRelSMQ ");
		exit(ERROR);
	}

	if((iRDaemonToMtmSqoff =  OpenMsgQ(RDaemonToMtmSqoff)) == ERROR)  /*******  MTM Breach Info to Dealer and Client *******/
	{
		logFatal("Error in Opening RDaemonToMtmSqoff");
		exit(ERROR);
	}

	logDebug2("iRDaemonToSqoff 	= %d ",iRDaemonToSqoff);
	logDebug2("iTrdRtrToD2C 	= %d ",iTrdRtrToD2C);
	logDebug2("iRDaemonToMtmSqoff	= %d ",iRDaemonToMtmSqoff);
	/*	if((iRDaemonToSIPSqrOff = OpenMsgQ(RDaemonToSIPSqrOff)) == ERROR )
		{
		logFatal("Error in Opening RDaemonToSIPSqrOff ");
		exit(ERROR);
		}
	 */

	logTimestamp("Exit : [OpenMsgQue]");
}

void Daemon(void *parameter)
{
	logTimestamp("Entry : [Daemon]");
	MYSQL 		*DB_Con;
	CHAR 		*Sel;
	INT16 th_id;

	struct THREAD_PARAMS *l_parameter = parameter;

	th_id = l_parameter->thread_id;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	
	sprintf(Sel,"CALL PR_COMEODBODAUTOMATIC();");                          
	while(1)
	{	

		//sprintf(Sel,"CALL PRCOMEODBODAUTOMATIC();");                          
		logTimestamp("Sel :%s:",Sel);
		if(mysql_query(DB_Con,Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			//	free(Sel);
			logSqlFatal("Error IN CALLING PRCOMEODBODAUTOMATIC .");
			//	break;
		}

		if(mysql_commit(DB_Con)!=0)
			logFatal("Failed to commit");
		else
			logDebug2("Successfully committed");

		sleep(900); 
		logInfo("In Infinite loop of daemon");       
	}

	logTimestamp("Exit : [Daemon]");
}
/*
void CheckMTM(void *parameter)
{
	logTimestamp("Entry : [CheckMTM]");
	MYSQL 		*DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR 		*Sel;
	INT16 th_id;
	LONG32		iTimer = -1;	
	INT16           iStatus,iBreaches;

	struct THREAD_PARAMS *l_parameter = parameter;

	th_id = l_parameter->thread_id;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);	

	sprintf(Sel,"SELECT s.PARAM_VALUE from SYS_PARAMETERS s where s.PARAM_NAME = 'MTM_TIMER' ;");
	logDebug2("Query : %s",Sel);

	if (mysql_query(DB_Con,Sel) != SUCCESS)
	{
		sql_Error(DB_Con);
		logSqlFatal("Error in Select Param Value.");
		free(Sel);
		mysql_close(DB_Con);
		return ERROR;
	}

	Res = mysql_store_result(DB_Con);

	while(Res && (Row = mysql_fetch_row(Res)))
	{
		iTimer = atoi(Row[0]);
		mysql_free_result(Res);
	}

	while(iTimer != -1)
	{	
		sleep(iTimer); 

		sprintf(Sel,"CALL PR_MTM_BREACH(@ZSTATUS); SELECT @ZSTATUS ;");

		logDebug2("Query... = %s",Sel);

		if(mysql_query(DB_Con,Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			free(Sel);
			logSqlFatal("Error IN CALLING PR_MTM_BREACH.");
			return ERROR;
		}

		do{
			Res = mysql_store_result(DB_Con);
			if(Res)
			{
				if((Row = mysql_fetch_row(Res)))
				{
					iBreaches = atoi(Row[0]);
				}
			}
			else
			{
				logDebug2("No Result Set ");
			}

			if((iStatus =mysql_next_result(DB_Con)) > 0)
			{
				logDebug3("Could not execute statement");
			}
		}while(iStatus == 0);

		if(iBreaches == 0)
		{
			logInfo("No MTM Breaches");
		}
		else 
		{
			mysql_free_result(Res);

			sprintf(Sel,"SELECT CLIENT_ID, USER_ID, MTM, MTM_LEVEL ,SQ_OFF_FLAG  FROM MTM_BREACH;");
			logDebug2("Qry = %s",Sel);

			if (mysql_query(DB_Con,Sel) != SUCCESS)
			{
				sql_Error(DB_Con);
				logSqlFatal("Error in select Qry [CheckMTM].");
				free(Sel);
				mysql_close(DB_Con);
				return ERROR;
			}

			Res = mysql_store_result(DB_Con);

			while(Row = mysql_fetch_row(Res))
			{
				NotifyFE(Row[0],atoi(Row[1]),atof(Row[2]),atof(Row[3]),Row[4][0] );
			}
		}
		mysql_free_result(Res);
	}
	free(Sel);	
	logTimestamp("Exit : [CheckMTM]");
}
*/
/*
BOOL    NotifyFE(CHAR *sClientId, LONG32 iUserId, DOUBLE64 fMTMPer, DOUBLE64 fMTMLevel ,CHAR cSqrOffFlag)
{
	logTimestamp("Entry :NotifyFE:");	
	struct INT_MTM_BREACH_RESP pResp;

	memset(&pResp,'\0',sizeof(struct INT_MTM_BREACH_RESP));

	pResp.IntRespHeader.iMsgLength 	= sizeof(struct INT_MTM_BREACH_RESP);
	pResp.IntRespHeader.iErrorId 	= -1;
	pResp.IntRespHeader.iMsgCode 	= TC_INT_MTM_BREACH_RSP;
	pResp.IntRespHeader.cSource 	= SOURCE_ADMIN;
	pResp.IntRespHeader.cSegment 	= 'X';
	pResp.IntRespHeader.iTimeStamp 	= GetJuliDateTime();
	pResp.fMTMPercent 		= fMTMPer;
	pResp.fMTMLevel 		= fMTMLevel;
	pResp.IntRespHeader.iUserId 	= iUserId;
	pResp.cMTMFlag		    	= cSqrOffFlag ;
	strncpy(pResp.sClientId,sClientId,CLIENT_ID_LEN);

	logDebug2("pResp.sClientId		=  %s",pResp.sClientId);	
	logDebug2("pResp.fMTMLevel  		= %f",pResp.fMTMLevel);	
	logDebug2("pResp.fMTMPercent  		= %f",pResp.fMTMPercent);	
	logDebug2("pResp.cMTMFlag		= %c",pResp.cMTMFlag);	
	logDebug2("pResp.IntRespHeader.iUserId 	= %llu",pResp.IntRespHeader.iUserId);


	if((WriteMsgQ(iTrdRtrToD2C, (CHAR *)&pResp , sizeof(struct INT_MTM_BREACH_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in NotifyFE.");
		return ERROR;
	}
	/*if(cSqrOffFlag == YES)
	  {		
	  logDebug2("Pumping Auto SquareOff for ClientId = :%s:",sClientId);
	//		pResp.IntRespHeader.iMsgCode =  TC_INT_MTM_AUTO_SQR_OFF ;
	if((WriteMsgQ(iRDaemonToMtmSqoff, (CHAR *)&pResp , sizeof(struct INT_MTM_BREACH_RESP), 1)) != TRUE  )
	{
	logFatal("Error : WriteMsgQ failed  iRDaemonToMtmSqoff .");
	return ERROR;
	}

	}*/
/*	logTimestamp("Exit :NotifyFE:");	
}
*/
void	LoadEnv()
{
	if(getenv("EXCH_CON") == NULL)
	{
		logFatal("EXCH_CON is Not define");
		exit(ERROR);
	}
	else
	{
		strncpy(sAllowExch,getenv("EXCH_CON"),EXCHANGE_ALLOW_LEN);
	}
	logInfo("sAllowExch :%s:",sAllowExch);	

	if(getenv("SUPER_ADMIN_USER_ID") == NULL)
	{
		logFatal("SUPER_ADMIN_USER_ID is not defined");
		exit(ERROR);
	}
	else
	{
		strncpy(sTempUID,getenv("SUPER_ADMIN_USER_ID"),10);

	}

}


LONG32 	GetJuliDateTime()
{
	struct timeval tm;
	gettimeofday( &tm, NULL );
	//        printf("\n Time i : %i",tm.tv_sec);
	return tm.tv_sec;
}

LONG32 IntrdyCroCurSqOffExec (void *parameter)
{
	logTimestamp("Entry : [IntrdyCroCurSqOffExec]");

	INT16           th_idn;
	LONG32          Mkt,iGrpId = 1,iCnt=1;
	CHAR            flag = FALSE;
	CHAR            sOMSExch[EXCHANGE_LEN];
	INT16           iMsgType;
	MYSQL           DBC;
	MYSQL           *DB_Con;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	INT16           iMktStat;
	CHAR            cMkt_Seg,cMode ,cProd;
	CHAR            sMkt_Exch[EXCHANGE_LEN];
	CHAR            lvar_uid[30];
	LONG64          SleepTime = 0,iMktType = 1;
	CHAR            *Firs_Sel;
	CHAR            *Seco_Sel;
	CHAR            *Sel;

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;

	th_idn = l_parameter->thread_id;


	//      DB_Con = l_parameter->DB_Con[th_id];
	memset(sOMSExch,'\0',EXCHANGE_LEN);
	memset(sMkt_Exch,'\0',EXCHANGE_LEN);

	cMode = '\0';
	struct  ORDER_REQUEST      pReq_SqOff;
	for(iCnt ; iCnt<=2; iCnt++)
	{
		switch(th_idn)
		{
			case 0:
				Mkt = NSE_CUR;
				cMkt_Seg = SEGMENT_CURRENCY;
				iMktType = 1;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sOMSExch,NSE_EXCH,EXCHANGE_LEN);
				break;
			default:
				logDebug1(" [IntrdyCroCurSqOffExec:%d] Invalid marketf (mysql_query(DB_Con,Sel) != SUCCESS");
				break;
		}

		Firs_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Seco_Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		sprintf(Firs_Sel,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))-julidate(sysdate())\
				FROM BATCH_PROCESS b \
				WHERE   b.bp_exch_id = ltrim(rtrim( \"%s\")) \
				AND     b.bp_segment = \"%c\" \
				AND     b.bp_batch_name = \'I_SQ_OFF_CC\' \
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d;",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);

		logDebug1("Sel_is :%s:",Firs_Sel);
		//	logDebug1("sel is");
		if (mysql_query(DB_Con,Firs_Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in select juliDate [IntrdyCroCurSqOffExec]");
			free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);
		//	
		//	logDebug1("Result is :%c",Res);
		if(mysql_num_rows(Res) == 0)
		{
			logFatal("******* Zero row returned ******");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			//		logDebug2("row is:%s",Row[0]);
			SleepTime=atol(Row[0]);
			//		logDebug2("sleep time:%d",SleepTime);

		}
		//      logDebug2("SleepTime :%ld:",SleepTime);
		logDebug2("Rohit Printing SleepTime :%ld:",SleepTime);
		if(SleepTime < 0)
		{
			logFatal("[IntrdyCroCurSqOffExecSqOff:%d] Error in selecting ETA for :%s:%c:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}
		sleep(SleepTime);
		sprintf(Seco_Sel,"SELECT BP_MODE FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
				AND     b.bp_segment = \"%c\"\
				AND     b.bp_batch_name = \'I_SQ_OFF_CC\'\
				AND     b.bp_mkt_type_no = %d \
				AND	b.bp_group_id = %d ;",sMkt_Exch,cMkt_Seg,iMktType,iGroupId);

		//	printf("query\n");
		if (mysql_query(DB_Con,Seco_Sel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in SELECT BP_MODE [IntrdyCroCurSqOffExec]");
			free(Sel);
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);
		//		printf("store queery\n");
		if(mysql_num_rows(Res) == 0)
		{
			logFatal("$$$$$$$ Zero row returned $$$$$");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}

		else
		{
			Row = mysql_fetch_row(Res);
			cMode=Row[0][0];
		}

		if (cMode != 'A')
		{
			logDebug2("[IntrdyCroCurSqOffExec SqOff:%d] Batch Process is set to manual for :%s:%c:%d: ",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			return FALSE;
		}
		while(1)
		{
			//flag = ReadConnectStatShm( Mkt , iGrpId );
			flag = ReadConnectStatShm( Mkt , iOMSGroupId);
			if(flag == EXCHANGE_UP || cOmstype == OMS_MASTER)     /** flag is used to check the connection status in shm */
				break;
			logDebug1("[IntrdyCroCurSqOffExec SqOff:%d] :%s:%c:%d: Market is not Connected. Retrying",th_idn,sMkt_Exch,cMkt_Seg,iMktType);
			sleep(WAIT_BEFORE_RETRY);
		}
		logDebug1("[SqOff:%d] :%s:%c:%d: Market is Connected.",th_idn,sMkt_Exch,cMkt_Seg,iMktType);

		switch(th_idn)
		{
			case 0:         /***BSE EQ***/
				while(1)
				{
					sprintf(Sel,"SELECT EMM_STATUS\
							FROM EXCH_MKT_MASTER\
							WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG = \'%c\';",sMkt_Exch,cMkt_Seg);
					if (mysql_query(DB_Con,Sel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("Error in Query.. [IntrdyCroCurSqOffExec]");
						mysql_close(DB_Con);
						return ERROR;
					}

					Res = mysql_store_result(DB_Con);
					/*Previous condition is wrong  that 2nd tme fetch from Res show 0 rows*/
					if((Row = mysql_fetch_row(Res)))
                                        {
                                                logDebug2("Row :%s:",Row[0]);
                                                iMktStat = atoi(Row[0]);
                                                logDebug1("Value is: %d",iMktStat);
                                        }

			                
					if(iMktStat == MKT_OPEN)
					{
						logDebug1("[SqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
						break;
					}
					else
					{
						logDebug1("[IntrdyCroCurSqOffExec SqOff:%d] :%s:%c: Market is Closed. Retrying",th_idn,sMkt_Exch,cMkt_Seg);
						sleep(WAIT_BEFORE_RETRY);
					}
				}
				logDebug1("[SqOff:%d] :%s:%c: Market is Open.",th_idn,sMkt_Exch,cMkt_Seg);
				free(Sel);
				break;

		}
		memset(&pReq_SqOff,'\0',sizeof(struct  ORDER_REQUEST));
		logDebug1("[OffOrd:%d] Populating Struct.",th_idn);
		pReq_SqOff.ReqHeader.iSeqNo = iMktType;
		pReq_SqOff.ReqHeader.iMsgLength  = sizeof(struct ORDER_REQUEST);
		pReq_SqOff.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ;
		pReq_SqOff.ReqHeader.iUserId = atoi(sTempUID);
		pReq_SqOff.ReqHeader.cSegment = cMkt_Seg;
		pReq_SqOff.cUserType = 'A';
		strncpy(pReq_SqOff.ReqHeader.sExcgId,sOMSExch,EXCHANGE_LEN);
		strncpy(pReq_SqOff.sRemarks,"Auto_Success",REMARKS_LEN);
		logDebug1("[IntrdyCroCurSqOffExec SqOff:%d] Triggering  Square Off for MsgType :%s:%c:%d:%d:",th_idn,sMkt_Exch,cMkt_Seg,iMktType,iMsgType);
		if((WriteMsgQ(iRDaemonToSqoff,(CHAR *)&pReq_SqOff,sizeof(struct ORDER_REQUEST),3)!= TRUE))  /*---Defined in Queue.c at coc---*/
		{
			logFatal("[OffOrd] Error WriteQ ");
			logDebug1("[OffOrd:%d] Write Q id %d",th_idn,iRDaemonToSqoff);
			exit(ERROR);
		}



		if(mysql_commit(DB_Con)!=0)
			logDebug1("IntrdyCroCurSqOffExec Failed to commit");
		else
			logDebug1("IntrdyCroCurSqOffExec Successfully committed");
		free(Firs_Sel);
		free(Seco_Sel);
		sleep(RESTART_TIME);
	}
	logTimestamp("Exit : [IntrdyCroCurSqOffExec]");
	return(0);
	pthread_exit(NULL);

}

/*   // Implemented this in order flow //
void CheckOPT_STRK(void *parameter)
{
	logTimestamp("Entry : CheckOPT_STRK");

	MYSQL           *DB_Con;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	CHAR	sQry[QUERY_SIZE];
	CHAR    sQry1[QUERY_SIZE];
	LONG32  iTimer = -1;		

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;

	sprintf(sQry,"SELECT s.PARAM_VALUE from SYS_PARAMETERS s where s.PARAM_NAME = 'OPT_STRK_TIMER' ;");
	logDebug2("sQry = %s",sQry);

	if(mysql_query(DB_Con,sQry) != SUCCESS)
        {
                sql_Error(DB_Con);
                logSqlFatal("Error in Select Param Value.");
                mysql_close(DB_Con);
                return ERROR;
        }
	
        Res = mysql_store_result(DB_Con);

        while(Res && (Row = mysql_fetch_row(Res)))
        {
                iTimer = atoi(Row[0]);
                mysql_free_result(Res);
        }

	while(iTimer != -1)
        {
		sleep(iTimer);
		memset(sQry1,'\0',QUERY_SIZE);
		sprintf(sQry1,"CALL CHECK_OPT_STRIKE_PRICE_RANGE();");
		logDebug2("sQry1 = %s",sQry1);

		if(mysql_query(DB_Con,sQry1) != SUCCESS)
        	{
                	sql_Error(DB_Con);
                	logSqlFatal("Error in calling procedure.");
                	mysql_close(DB_Con);
                	return ERROR;
        	}
		Res = mysql_store_result(DB_Con);
		mysql_free_result(Res);
		
	}

	logTimestamp("Exit : CheckOPT_STRK");
}
*/

void CDSLFileUpload(void *parameter)
{
	logTimestamp("Entry : CDSLFileUpload");

	MYSQL           *DB_Con;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

	CHAR    sQry[QUERY_SIZE];
	CHAR sCommand[MAX_COMMAND_LEN];
	CHAR sCDSLFilePath[MAX_COMMAND_LEN];
	LONG32  iTimer = 30;		

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;

	memset(sQry,'\0',QUERY_SIZE);
	memset(sCommand,'\0',MAX_COMMAND_LEN);
	while(1)
        {
		sprintf(sQry,"SELECT s.PARAM_VALUE from SYS_PARAMETERS s where s.PARAM_NAME = 'EARLY_PAYIN_FILE_INTERVAL' ;");
		logDebug2("sQry = %s",sQry);

		if(mysql_query(DB_Con,sQry) != SUCCESS)
        	{
                	sql_Error(DB_Con);
                	logSqlFatal("Error in calling procedure for Early Payin.");
                	mysql_close(DB_Con);
                	return ERROR;
        	}
		Res = mysql_store_result(DB_Con);
		while(Res && (Row = mysql_fetch_row(Res)))
		{
			iTimer = atoi(Row[0])*60;
			logDebug2("iTimer Sleep is | %d |",iTimer);
			mysql_free_result(Res);
		}
		sleep(iTimer);
		logDebug2("CDSL_FILE_PATH ---> %s",CDSL_FILE_PATH);	
		sprintf(sCommand,"%s >Early_payinlogs.txt",CDSL_FILE_PATH);
        	logDebug2("sCommand -> %s",sCommand);
        	system(sCommand);
	
	}

	logTimestamp("Exit : CDSLFileUpload ");
}

