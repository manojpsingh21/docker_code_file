#include "IPCS.h"

//extern MaxSelfRetry;

BOOL fNotifyTradesToFE(BOOL iTrdNotFlag,struct INT_ORDERS *Int_Ord,CHAR *sTradeNotfUrl)
{
	logTimestamp("fNotifyTradesToFE [ENTRY]");
	//LONG32 iFlag = 0 ;

	//iFlag =	atoi(getenv("TRADE_RESPONSE_NOTIFICATION"));

	if(iTrdNotFlag == TRUE)
	{
		logDebug2("Sending Trade Notifications");
		CHAR sCmd[COMMAND_LEN];
		memset(sCmd,'\0',COMMAND_LEN);
		//sprintf(sCmd,"%s/SendTradeToFE.py >> %s/log.TradeNotification &",getenv("PYTHON_PATH"),getenv("LOGDIR"));
		sprintf(sCmd,"curl -X POST  %s '{\"RequestCode\":2000,\"UserId\":\"PUSH\",\"UserType\":\"C\",\"Source\":\"O\",\"DoCompress\":false,\"Reserved\":null,\"Data\":\"{\"header\":null,\"Msg\":\"\",\"DT\":\"02-08-2018 06:13:30\",\"Typ\":null,\"TypL\":[\"A\",\"I\"],\"EType\":[],\"ClientIDs\":[\"<CLIENTID>\"],\"IsAllClient\":false,\"DtToSendIOS\":{\"Key\":\"notification\",\"Value\":{\"body\":\"<MSG>\",\"MediaURL\":\"\",\"title\":\"Trade Notification\" ,\"icon\":\"myicon\",\"sound\":\"default\",\"MsgType\":\"S\"}},\"DtToSendA\":{\"Key\":\"data\",\"Value\":{\"Date\":\"<02-08-2018 18:13:31>\",\"Research\":\"<MSG>\",\"MediaURL\":\"\",\"MsgType\":\"S\"}}}\",\"Count\":1} '",sTradeNotfUrl);
		logDebug2("Command -> %s",sCmd);
		system(sCmd);
		logTimestamp("fNotifyTradesToFE [EXIT]");
		return TRUE ;


	}
	else
	{
		logDebug2("Trade Notification is disabled for Clients");

	}
}


BOOL NotifyMonTool(BOOL Status,LONG32 iID)
{
	logTimestamp("NotifyMonTool [ENTRY]");
	LONG32 iFlag = 0 ;
	LONG32 iErrorID;
	iFlag = atoi(getenv("EXCHANGE_STATUS_NOTIFICATION"));
	logDebug2("iFlag = :%d:",iFlag);
	if(iFlag == 1)	
	{

		CHAR sCmd[COMMAND_LEN];
		memset(sCmd,'\0',COMMAND_LEN);
		sprintf(sCmd,"%s/ExchStats.py %s %c %s %d >> %s/log.ExchStats &",getenv("PYTHON_PATH"),NSE_EXCH,EQUITY_SEGMENT,Status==1?"UP":"DOWN",iErrorID,getenv("LOGDIR"));
		logDebug2("Command -> %s",sCmd);
		system(sCmd);
		logTimestamp("NotifyMonTool[EXIT]");
		return TRUE ;
	}
	else
	{
		logDebug2("Exchange Status Notification is disabled ");

	}
}

void NotifyProcMonTool(struct  ProcessMonitor *ProcessMonitor, BOOL Status)
{
	logTimestamp("NotifyProcMonTool [ENTRY]");
	CHAR sCmd[200];
	memset(sCmd,'\0',200);
	LONG32	MaxSelfRetry = atoi(getenv("MAX_AUTO_RETRY"));
	BOOL	iSwitchFlag= atoi(getenv("PROCESS_RESTART_NOTIFICATION") );

	if(iSwitchFlag == 1)
	{	

		sprintf(sCmd,"%s/ProcStats.py %s %s %d %d >> %s/log.ProcStats &",getenv("PYTHON_PATH"),ProcessMonitor->sProcessName,Status==1?"UP":"DOWN",ProcessMonitor->iAttempts,MaxSelfRetry,getenv("NEW_LOGDIR"));
		logDebug2("Command -> %s",sCmd);
		system(sCmd);
		return TRUE;
	}
	else
	{
		logDebug2("Notifier is Disabled");
	}
	logTimestamp("NotifyProcMonTool [ENTRY]");
}


