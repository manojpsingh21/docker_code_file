#include <stdio.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <unistd.h>


LONG32          iOrdSrvToTrdRtr;
MYSQL           *DBConNET;
LONG64          iMsgType = 0;
LONG32          iCount = 0;
BOOL            ChkFlag = FALSE;
LONG32          iGroupId;
CHAR    	sDate[DATE_LEN];
CHAR            sGeneratedOrdNo[ORDER_LEN];
CHAR            sFileName[FILE_NAME_LEN];
CHAR            sGenerateOrdNo [2] [ORDER_LEN];

FILE            *fDMClOrdID;

main(int argc, char *argv[])
{
	logTimestamp("Entry : [main]");
        setbuf(stdout  ,NULL);
        setbuf(stderr  ,NULL);

	DBConNET = DB_Connect();
	fSelectDate(&sDate);	
	iMsgType = atoi(argv[1]);
	fOpenMsgQue();
	
	fOrderProcess(iOrdSrvToTrdRtr);
        logTimestamp("Exit : [main]");

}


void PrintAll(struct  ORDER_REQUEST           *pOE_Req)
{
        logTimestamp("-------------------Start Printing-------------------");

        logDebug3("iSeqNo :%d:",pOE_Req->ReqHeader.iSeqNo);
        logDebug3("iMsgLength   :%d:",pOE_Req->ReqHeader.iMsgLength);
        logDebug3("iMsgCode     :%d:",pOE_Req->ReqHeader.iMsgCode);
        logDebug3("sExcgId      :%s:",pOE_Req->ReqHeader.sExcgId);
        logDebug3("iUserId      :%d:",pOE_Req->ReqHeader.iUserId);
        logDebug3("cSource      :%c:",pOE_Req->ReqHeader.cSource);
        logDebug3("cSegment     :%c:",pOE_Req->ReqHeader.cSegment);
        logDebug3("sSecurityId  :%s:",pOE_Req->sSecurityId);
        logDebug3("sEntityId    :%s:",pOE_Req->sEntityId);
        logDebug3("sClientId    :%s:",pOE_Req->sClientId);
        logDebug3("cProductId   :%c:",pOE_Req->cProductId);
        logDebug3("cBuyOrSell   :%c:",pOE_Req->cBuyOrSell);
        logDebug3("iOrderType   :%d:",pOE_Req->iOrderType);
        logDebug3("iOrderValidity       :%d:",pOE_Req->iOrderValidity);
        logDebug3("iDiscQty     :%d:",pOE_Req->iDiscQty);
        logDebug3("iDiscQtyRem  :%d:",pOE_Req->iDiscQtyRem);
        logDebug3("iTotalQtyRem :%d:",pOE_Req->iTotalQtyRem);
        logDebug3("iTotalQty    :%d:",pOE_Req->iTotalQty);
        logDebug3("iTotalTradedQty      :%d:",pOE_Req->iTotalTradedQty);
        logDebug3("iMinFillQty  :%d:",pOE_Req->iMinFillQty);
        logDebug3("fPrice       :%f:",pOE_Req->fPrice);
        logDebug3("fTriggerPrice        :%f:",pOE_Req->fTriggerPrice);
        logDebug3("fOrderNum    :%f:",pOE_Req->fOrderNum);
        logDebug3("iSerialNum   :%d:",pOE_Req->iSerialNum);
        logDebug3("cHandleInst  :%c:",pOE_Req->cHandleInst);
        logDebug3("fAlgoOrderNo :%f:",pOE_Req->fAlgoOrderNo);
        logDebug3("iStratergyId :%d:",pOE_Req->iStratergyId);
        logDebug3("cOffMarketFlg        :%c:",pOE_Req->cOffMarketFlg);
        logDebug3("cProCli      :%c:",pOE_Req->cProCli);
        logDebug3("cUserType    :%c:",pOE_Req->cUserType);
        logDebug3("sRemarks     :%s:",pOE_Req->sRemarks);
        logDebug3("iMktType     :%d:",pOE_Req->iMktType);
        logDebug3("iAuctionNum  :%d:",pOE_Req->iAuctionNum);
        logDebug3("sGoodTillDaysDate    :%s:",pOE_Req->sGoodTillDaysDate);
        logDebug3("cMarkProFlag :%c:",pOE_Req->cMarkProFlag);
        logDebug3("fMarkProVal  :%f:",pOE_Req->fMarkProVal);
        logDebug3("cParticipantType     :%c:",pOE_Req->cParticipantType);
        logDebug3("sSettlor     :%s:",pOE_Req->sSettlor);
        logDebug3("cGTCFlag     :%c:",pOE_Req->cGTCFlag);
        logDebug3("cEncashFlag  :%c:",pOE_Req->cEncashFlag);
        logDebug3("sPanID       :%s:",pOE_Req->sPanID);
        logDebug2("pOE_Req->iGrpId              :%d:",pOE_Req->iGrpId);
        logDebug2("pOE_Req->splatform:%s:",pOE_Req->sPlatform);
        logDebug2("pOE_Req->sChannel:%s:",pOE_Req->sChannel);
	
	logTimestamp("-------------------End Printing-------------------");
}
	
	
void fCoOrdReq_Print (struct  CO_ORDER_REQUEST *Co_Req , LONG32 j)
{
        logTimestamp("-------------------Start Printing Cover Order Request Struct---------------");
        logDebug2("sizeof(CO_ORDER_REQUEST) = :%d:",sizeof( struct CO_ORDER_REQUEST));
        logDebug2("Co_Req->fSLTikAbsValue       :%f:",Co_Req->fSLTikAbsValue);
        logDebug2("Co_Req->ReqHeader.iMsgCode :%d:",Co_Req->ReqHeader.iMsgCode);

        logDebug3("Co_Req->CoArray[%d].cBuySellInd :%c:",j,Co_Req->CoArray[j].cBuySellInd);
        logDebug3("Co_Req->CoArray[%d].fTriggerPrice:%lf:",j,Co_Req->CoArray[j].fTriggerPrice);
        logDebug2("Co_Req->CoArray[%d].iLegValue :%d:",j,Co_Req->CoArray[j].iLegValue);
        logDebug2("Co_Req->iNoOfLeg :%d:",Co_Req->iNoOfLeg);
        logDebug2("Co_Req->fOrderNum :%lf:",Co_Req->fOrderNum);
        logDebug2("Co_Req->fAlgoOrderNo :%lf:",Co_Req->fAlgoOrderNo);
        logDebug2("Co_Req->ReqHeader.iSeqNo :%d:",Co_Req->ReqHeader.iSeqNo);
        logDebug2("Co_Req->ReqHeader.iMsgLength :%d:",Co_Req->ReqHeader.iMsgLength);

        logDebug2("Co_Req->ReqHeader.iUserId :%llu:",Co_Req->ReqHeader.iUserId);
        logDebug2("Co_Req->ReqHeader.cSource  :%c:",Co_Req->ReqHeader.cSource);
        logDebug2("Co_Req->ReqHeader.cSegment :%c:",Co_Req->ReqHeader.cSegment);
        logDebug2("Co_Req->iSerialNum :%d:",Co_Req->iSerialNum);

        logDebug2("Co_Req->sSecurityId         :%s:     strlen(Co_Req->sSecurityId)       = :%d:",Co_Req->sSecurityId,strlen(Co_Req->sSecurityId));
        logDebug2("Co_Req->ReqHeader.sExcgId  :%s:      strlen(Co_Req->ReqHeader.sExcgId) = :%d:",Co_Req->ReqHeader.sExcgId,strlen(Co_Req->ReqHeader.sExcgId));
        logDebug2("Co_Req->sClientId           :%s:     strlen(Co_Req->sClientId)         = :%d:",Co_Req->sClientId,strlen(Co_Req->sClientId));
        logDebug3("Co_Req->sEntityId           :%s:     strlen(Co_Req->sEntityId)  = :%d:", Co_Req->sEntityId,strlen(Co_Req->sEntityId));

        logDebug2("Co_Req->iMktType :%d:",Co_Req->iMktType);
        logDebug2("Co_Req->cProCli :%c:",Co_Req->cProCli);
        logDebug2("Co_Req->iTotalQty :%d:",Co_Req->iTotalQty);
        logDebug2("Co_Req->iTotalQtyRem :%d:",Co_Req->iTotalQtyRem);
        logDebug2("Co_Req->iDiscQty :%d:",Co_Req->iDiscQty);
        logDebug2("Co_Req->iDiscQtyRem :%d:",Co_Req->iDiscQtyRem );
        logDebug2("Co_Req->iTotalTradedQty :%d:",Co_Req->iTotalTradedQty );
        logDebug2("Co_Req->fPrice :%f:",Co_Req->fPrice);
        logDebug2("Co_Req->iOrderValidity :%d:",Co_Req->iOrderValidity);
        logDebug2("Co_Req->iOrderType :%d:",Co_Req->iOrderType);
        logDebug2("Co_Req->iMinFillQty :%d:",Co_Req->iMinFillQty);
        logDebug2("Co_Req->cUserType :%c:",Co_Req->cUserType);
        logDebug2("Co_Req->cProductId :%c:",Co_Req->cProductId);
        logDebug2("Co_Req->cSLFlag              :%c:",Co_Req->cSLFlag);
        logDebug2("Co_Req->cPBFlag              :%c:",Co_Req->cPBFlag);
        logDebug2("pOE_Req->iGrpId              :%d:",Co_Req->iGrpId);
        logDebug2("Co_Req->splatform:%s:",Co_Req->sPlatform);
        logDebug2("Co_Req->sChannel:%s:",Co_Req->sChannel);

        logTimestamp ("-------------------End Printing-------------------");

}

void fBoOrdReq_Print (struct  BO_ORDER_REQUEST *Bo_Req , LONG32 j)
{
        logTimestamp("------------------Start Printing Bracket  Order Request Struct---------------");
        logDebug2("sizeof(BO_ORDER_REQUEST)     :%d:",sizeof( struct BO_ORDER_REQUEST));

        logDebug2("Bo_Req->ReqHeader.iSeqNo     :%d:",Bo_Req->ReqHeader.iSeqNo);
        logDebug2("Bo_Req->ReqHeader.iMsgLength :%d:",Bo_Req->ReqHeader.iMsgLength);
        logDebug2("Bo_Req->ReqHeader.iMsgCode   :%d:",Bo_Req->ReqHeader.iMsgCode);
        logDebug2("Bo_Req->ReqHeader.sExcgId    :%s:      strlen(Bo_Req->ReqHeader.sExcgId) = :%d:",Bo_Req->ReqHeader.sExcgId,strlen(Bo_Req->ReqHeader.sExcgId));
        logDebug2("Bo_Req->ReqHeader.iUserId    :%llu:",Bo_Req->ReqHeader.iUserId);
        logDebug2("Bo_Req->ReqHeader.cSource    :%c:",Bo_Req->ReqHeader.cSource);
        logDebug2("Bo_Req->ReqHeader.cSegment   :%c:",Bo_Req->ReqHeader.cSegment);

        logDebug3("Bo_Req->BoArray[%d].fTriggerPrice    :%lf:",j,Bo_Req->BoArray[j].fTriggerPrice);
        logDebug3("Bo_Req->BoArray[%d].cBuySellInd      :%c:",j,Bo_Req->BoArray[j].cBuySellInd);
        logDebug2("Bo_Req->BoArray[%d].iLegValue        :%d:",j,Bo_Req->BoArray[j].iLegValue);

        logDebug2("Bo_Req->sSecurityId          :%s:     strlen(Bo_Req->sSecurityId)       = :%d:",Bo_Req->sSecurityId,strlen(Bo_Req->sSecurityId));
        logDebug3("Bo_Req->sEntityId            :%s:     strlen(Bo_Req->sEntityId)  = :%d:", Bo_Req->sEntityId,strlen(Bo_Req->sEntityId));
        logDebug2("Bo_Req->sClientId            :%s:     strlen(Bo_Req->sClientId)         = :%d:",Bo_Req->sClientId,strlen(Bo_Req->sClientId));
        logDebug2("Bo_Req->cProductId           :%c:",Bo_Req->cProductId);
        logDebug3("Bo_Req->cHandleInst          :%c:",Bo_Req->cHandleInst);
        logDebug3("Bo_Req->cOffMarketFlg        :%c:",Bo_Req->cOffMarketFlg);
        logDebug2("Bo_Req->cUserType            :%c:",Bo_Req->cUserType);
        logDebug2("Bo_Req->iMktType             :%d:",Bo_Req->iMktType);
        logDebug2("Bo_Req->iDiscQty             :%d:",Bo_Req->iDiscQty);
        logDebug2("Bo_Req->iDiscQtyRem          :%d:",Bo_Req->iDiscQtyRem );
        logDebug2("Bo_Req->iTotalQtyRem         :%d:",Bo_Req->iTotalQtyRem);
        logDebug2("Bo_Req->iTotalQty            :%d:",Bo_Req->iTotalQty);
        logDebug2("Bo_Req->iTotalTradedQty      :%d:",Bo_Req->iTotalTradedQty );
        logDebug2("Bo_Req->fPrice               :%f:",Bo_Req->fPrice);
        logDebug2("Bo_Req->fOrderNum            :%lf:",Bo_Req->fOrderNum);
        logDebug2("Bo_Req->iSerialNum           :%d:",Bo_Req->iSerialNum);
        logDebug2("Bo_Req->fAlgoOrderNo         :%lf:",Bo_Req->fAlgoOrderNo);
        logDebug2("Bo_Req->fTrailingSLValue     :%lf:",Bo_Req->fTrailingSLValue);
        logDebug2("Bo_Req->cProCli              :%c:",Bo_Req->cProCli);
        logDebug2("Bo_Req->sRemarks             :%s:    strlen(Bo_Req->sRemarks)        = :%d:",Bo_Req->sRemarks,strlen(Bo_Req->sRemarks));
        logDebug3("Bo_Req->iStratergyId         :%d:",Bo_Req->iStratergyId);
        logDebug2("Bo_Req->iNoOfLeg             :%d:",Bo_Req->iNoOfLeg);
        logDebug2("Bo_Req->iOrderType           :%d:",Bo_Req->iOrderType);
        logDebug2("Bo_Req->iOrderValidity       :%d:",Bo_Req->iOrderValidity);
        logDebug2("Bo_Req->iMinFillQty          :%d:",Bo_Req->iMinFillQty);
        logDebug2("Bo_Req->cSLFlag              :%c:",Bo_Req->cSLFlag);
        logDebug2("Bo_Req->cPBFlag              :%c:",Bo_Req->cPBFlag);
        logDebug2("Bo_Req->fPBTikAbsValue       :%f:",Bo_Req->fPBTikAbsValue);
        logDebug2("Bo_Req->fSLTikAbsValue       :%f:",Bo_Req->fSLTikAbsValue);
        logDebug2("Bo_Req->iChildLegsUniqId     :%d:",Bo_Req->iChildLegsUniqId);
        logDebug2("Bo_Req->iParentId            :%d:",Bo_Req->iParentId);
	logDebug2("Bo_Req->cFlag                :%c:",Bo_Req->cFlag);
        logDebug2("Bo_Req->iGrpId               :%d:",Bo_Req->iGrpId);
        logDebug2("Bo_Req->splatform            :%s:",Bo_Req->sPlatform);
        logDebug2("Bo_Req->sChannel             :%s:",Bo_Req->sChannel);
        logTimestamp ("-------------------End Printing-------------------");

}



void fOrderProcess (LONG32 respQ)
{
	logTimestamp("Entry : [fOrderProcess]");
	CHAR    RcvMsg [RUPEE_MAX_PACKET_SIZE] ;
	
	LONG32  iMsgCode = 0, i = 0 ;
	LONG32                          RcvQ;
        key_t                           RcvQId;
	CHAR    sTempClOrdId[CLORDID_LEN];

	sprintf(sFileName,"%sDMClOrdID%d_%s",FILE_SEQ,iMsgType,sDate);
        if(access(sFileName,F_OK) == ERROR)
        {
                fDMClOrdID = fopen(sFileName,"wb+");

                if (fDMClOrdID == NULL)
                {
                        logFatal("Not able to Open File");
                        exit(0);
                }
                else
                {
                        fprintf(fDMClOrdID,"100");
                }
                fclose(fDMClOrdID);
        }
        else
        {
                logInfo(":%s: File Already Exists",sFileName);
        }		
	switch (iMsgType)
	{
			
		case 1 :
                        RcvQId  = CatalystToOrdProNEQ;
                        logDebug2("Opening packet  CatalystToOrdProNEQ");
                        break;
                case 2 :
                        RcvQId  = CatalystToOrdProNFO;
                        logDebug2("Opening packet  CatalystToOrdProNFO");
                        break;
                case 3 :
                        RcvQId  = CatalystToOrdProNCD;
                        logDebug2("Opening packet  CatalystToOrdProNCD");
                        break;
                case 4 :
                        RcvQId  = CatalystToOrdProBEQ;
                        logDebug2("Opening packet  CatalystToOrdProBEQ");
                        break;
                case 5 :
                        RcvQId  = CatalystToOrdProMCX;
                        logDebug2("Opening packet  CatalystToOrdProMCX");
                        break;	
	}
		
	if(( RcvQ = OpenMsgQ(RcvQId)) == ERROR)
        {
                logDebug2("OpenMsgQ : Error in opening CatalystToOrdProcess ");
                exit(ERROR);
        }

        struct  ORDER_REQUEST           *pOE_Req;
        struct  CO_ORDER_REQUEST    *CoOrd_Req ;
        struct  BO_ORDER_REQUEST    *BoOrd_Req ;

        struct  INT_COMMON_REQUEST_HDR  *Int_hdr ;
	
	if(getenv("GROUP_ID") == NULL)
        {
                logFatal("Error : Environment Variable missing : GROUP_ID ");
                exit(ERROR);
        }
        else
        {
                iGroupId = atoi(getenv("GROUP_ID"));
        }

	while (TRUE)
	{
		logInfo("---------==================|||||||||||||||||||||||=================---------");
                logInfo("---------==================WHILE LOOP -> Count : %d %d==============---------",iCount++,iMsgType);
                logInfo("---------==================|||||||||||||||||||||||=================---------");
		
                memset(&pOE_Req,'\0' ,sizeof(struct ORDER_REQUEST));
                memset(&CoOrd_Req,'\0' ,sizeof(struct CO_ORDER_REQUEST));
                memset(&BoOrd_Req,'\0' ,sizeof(struct BO_ORDER_REQUEST));
		memset(sTempClOrdId,'\0' ,CLORDID_LEN);
                memset(&Int_hdr,'\0' ,sizeof(struct INT_COMMON_REQUEST_HDR));

		if((ReadMsgQ(RcvQ,&RcvMsg,RUPEE_MAX_PACKET_SIZE, 1)) != 1)
        	{
                	logFatal("Error : MsgQId is %d",RcvQ);
                 	exit(ERROR);
        	}
		
		logDebug2("Reading struct INT_COMMON_REQUEST_HDR From Queue....");
                Int_hdr = (struct INT_COMMON_REQUEST_HDR *)&RcvMsg;
                logDebug2("Successfully Read From Queue");
                ChkFlag = FALSE;

                iMsgCode = Int_hdr->iMsgCode ;
                logDebug2("------------MsgCode Received :%d:------------",iMsgCode);
		
		switch (iMsgCode)
                {

                        case  TC_INT_ORDER_ENTRY_REQ    :
                        case  TC_INT_ORDER_CANCEL       :
                        case  TC_INT_ORDER_MODIFY       :
							
				pOE_Req = (struct ORDER_REQUEST *) &RcvMsg;
				PrintAll(pOE_Req);
		
				ChkFlag = fGenerateClOrdId(&sTempClOrdId);

                                if(ChkFlag == FALSE)
                                {
                                        logDebug3("fGenerateClOrdId returned Error : generation ClOrdId");
                                        continue;
                                }
				if(iMsgCode == TC_INT_ORDER_ENTRY_REQ && pOE_Req->fOrderNum == 0.00)
                                {
                                        sprintf(sGeneratedOrdNo,"%d%s%s%d",iGroupId,"69",sDate,(EQUITY_SEQ + atoi(sTempClOrdId)));
					logDebug2("Date--> %s",sDate);
                                        logDebug2("(SEQ + atoi(sClOrdId)):%ld:",(EQUITY_SEQ + atoi(sTempClOrdId)));
                                        logDebug2("iGroupId:%d:",iGroupId);
                                        pOE_Req->fOrderNum = atof(sGeneratedOrdNo);
					logDebug2("pOE_Req->fOrderNum --> %lf",pOE_Req->fOrderNum);
                                        pOE_Req->iSerialNum= 1;
                                }	
				OrderEntry(pOE_Req);
				break;

			case TC_INT_CO_ORDER_REQ        :
                        case TC_INT_CO_ORDER_MODIFY     :
			case TC_INT_CO_ORDER_EXIT       :
                        case TC_INT_CO_ORDER_CANCEL     :
	
				CoOrd_Req  = (struct CO_ORDER_REQUEST *) &RcvMsg;
				fCoOrdReq_Print(CoOrd_Req , i);
		
				ChkFlag = fGenerateClOrdId(&sTempClOrdId);
				if(ChkFlag == FALSE)
				{
					logDebug3("fGenerateClOrdId returned Error : generation ClOrdId");
					break;
				}
				if(CoOrd_Req->ReqHeader.iMsgCode == TC_INT_CO_ORDER_REQ  )
				{
					sprintf(sGenerateOrdNo[i],"%d%s%s%d",iGroupId,"69",sDate,(EQUITY_SEQ + atoi(sTempClOrdId)));
					logDebug2("(SEQ + atoi(sClOrdId)):%ld:",(EQUITY_SEQ + atoi(sTempClOrdId)));
					logDebug2("iGroupId:%d:",iGroupId);
					CoOrd_Req->fOrderNum = atof(sGenerateOrdNo[0]);
					CoOrd_Req->iSerialNum = 1;
					logDebug2(" ###########Order No Generated is => :%lf: ############",CoOrd_Req->fOrderNum);
				}	
				CoOrderEntry(CoOrd_Req,i);		
				break;
			
	
			case TC_INT_BO_ORDER_REQ        :/*This are FE Request*/
			case TC_INT_BO_ORDER_MODIFY     :
                        case TC_INT_BO_ORDER_EXIT       :

                        case TC_BO_PUMP_REQ             :
			case TC_INT_BO_LEG_MODIFY       :
                        case TC_INT_BO_ORDER_CANCEL     :

				BoOrd_Req  = (struct BO_ORDER_REQUEST *) &RcvMsg;
				fBoOrdReq_Print(BoOrd_Req , 0);
				ChkFlag = fGenerateClOrdId(&sTempClOrdId);
				if(ChkFlag == FALSE)
				{
					logDebug3("fGenerateClOrdId returned Error : generation ClOrdId");
					break;
				}
				if(BoOrd_Req->ReqHeader.iMsgCode == TC_INT_BO_ORDER_REQ )
				{
					sprintf(sGenerateOrdNo[i],"%d%s%s%d",iGroupId,"69",sDate,(EQUITY_SEQ + atoi(sTempClOrdId)));
					logDebug2("iGroupId:%d:",iGroupId);
					BoOrd_Req->fOrderNum = atof(sGeneratedOrdNo);
					BoOrd_Req->iSerialNum = 1;
					logDebug2(" ###########Order No Generated is => :%lf: ############",BoOrd_Req->fOrderNum);
				}	
		
				BoOrderEntry(BoOrd_Req,i);
				break;
		}
		
	//While Loop Ending	
	}
	logTimestamp("Exit : [fProcessOrder]");
	
}			


void fOpenMsgQue()
{
        logTimestamp("Entry : [fOpenMsgQue]");
	 if((iOrdSrvToTrdRtr = OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
        {
                logFatal("OpenMsgQ ...OrdSrvToTrdRtr");
                exit(ERROR);
        }
        logInfo("OrdSrvToTrdRtr opened successfully with id = %d", iOrdSrvToTrdRtr);

        logTimestamp("Exit : [fOpenMsgQue]");
}

BOOL	OrderEntry(struct ORDER_REQUEST *pOE_Req )
{
	logTimestamp("Entry : [OrderEntry]");

	CHAR InsertQry [DOUBLE_MAX_QUERY_SIZE];	
	memset(InsertQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	
	struct INT_ERROR_FE_RESP pErrorResponce;

        memset(&pErrorResponce,'\0',sizeof(struct INT_ERROR_FE_RESP));

	LONG64	iErrorId=0;
        CHAR    sErrString[DB_REASON_DESC_LEN];
        memset(sErrString,'\0',DB_REASON_DESC_LEN);

	
	sprintf(InsertQry,"INSERT INTO DUMMY_BOOK \
			(DM_SEG_NO,DM_MSGCODE,DM_EXCH_ID,DM_USER_ID,DM_SOURCE,DM_SEGMENT,\
			DM_SCRIP_CODE,DM_ENTITY_ID,DM_CLIENT_ID,DM_PRODUCT,DM_BUYSELL,DM_ORDER_TYPE,DM_ORDER_VALIDITY,DM_DISC_QTY,\
			DM_DISC_REM_QTY,DM_REM_QTY,DM_TOTAL_QTY,DM_TOTAL_TRADED_QTY,DM_MIN_FILL_QTY,DM_PRICE,DM_TRIGGER_PRICE,DM_ORDER_NUMBER,\
			DM_SERIAL_NO,DM_HANDLE_INST,DM_ALGO_ORDER_NO,DM_STRATEGY_ID,DM_OFF_MKT_FLAG,DM_PROCLIENT,DM_USER_TYPE,DM_REMARKS,\
			DM_MKT_TYPE,DM_AUCTION_NUM,DM_GOOD_TILL_DATE,DM_MKT_PROTECT_FLG,DM_MKT_PROTECT_VAL,DM_PARTICIPANT_TYPE,\
			DM_SETTLOR,DM_GTC_FLG,DM_ENCASH_FLG,DM_PAN_NO,DM_GROUP_ID,DM_REMARKS1,DM_REMARKS2)\
			VALUES\
			(%i,%d,\"%s\",%d,\'%c\',\'%c\',\
			\"%s\",\"%s\",\"%s\",\'%c\',\'%c\',%d,%d,\
			%d,%d,%d,%d,%d,%d,%f,\
			%f,%f,%d,\'%c\',%f,%d,\'%c\',\
			\'%c\',\'%c\',\"%s\",%d,%d,\"%s\",\'%c\',\
			%f,\'%c\',\"%s\",\'%c\',\'%c\',\"%s\",%d,\
			\"%s\",\"%s\")",\
			pOE_Req->ReqHeader.iSeqNo,pOE_Req->ReqHeader.iMsgCode,pOE_Req->ReqHeader.sExcgId,pOE_Req->ReqHeader.iUserId,pOE_Req->ReqHeader.cSource,pOE_Req->ReqHeader.cSegment,\
			pOE_Req->sSecurityId,pOE_Req->sEntityId,pOE_Req->sClientId,pOE_Req->cProductId,pOE_Req->cBuyOrSell,pOE_Req->iOrderType,pOE_Req->iOrderValidity,\
			pOE_Req->iDiscQty,pOE_Req->iDiscQtyRem,pOE_Req->iTotalQtyRem,pOE_Req->iTotalQty,pOE_Req->iTotalTradedQty,pOE_Req->iMinFillQty,pOE_Req->fPrice,\
			pOE_Req->fTriggerPrice,pOE_Req->fOrderNum,pOE_Req->iSerialNum,pOE_Req->cHandleInst,pOE_Req->fAlgoOrderNo,pOE_Req->iStratergyId,pOE_Req->cOffMarketFlg,\
			pOE_Req->cProCli,pOE_Req->cUserType,pOE_Req->sRemarks,pOE_Req->iMktType,pOE_Req->iAuctionNum,pOE_Req->sGoodTillDaysDate,pOE_Req->cMarkProFlag,\
			pOE_Req->fMarkProVal,pOE_Req->cParticipantType,pOE_Req->sSettlor,pOE_Req->cGTCFlag,pOE_Req->cEncashFlag,pOE_Req->sPanID,pOE_Req->iGrpId,\
			pOE_Req->sPlatform,pOE_Req->sChannel);	
		
		
	logDebug2("Query [%s]",InsertQry);
        if(mysql_query(DBConNET, InsertQry) != SUCCESS)
        {
                logSqlFatal("Error in inserting DUMMY_BOOK TABLE");
                sql_Error(DBConNET);
                return FALSE;
        }
        else
        {
                logDebug2(" Sucessfully Inserted into DUMMY_BOOK Table");
                logDebug2("%d rows updated!!",mysql_affected_rows(DBConNET));
                mysql_commit(DBConNET);
        }
	
	logDebug2("pOE_Req->ReqHeader.cSource  :%c:",pOE_Req->ReqHeader.cSource);
        logDebug2("pOE_Req->ReqHeader.sExcgId   :%s:",pOE_Req->ReqHeader.sExcgId);
        logDebug2("pOE_Req->sSecurityId         :%s:",pOE_Req->sSecurityId);
        logDebug2("pOE_Req->sClientId           :%s:",pOE_Req->sClientId);
        logDebug2("pOE_Req->ReqHeader.iUserId   :%llu:",pOE_Req->ReqHeader.iUserId);

        pErrorResponce.IntRespHeader.iSeqNo     = pOE_Req->ReqHeader.iSeqNo;
        pErrorResponce.IntRespHeader.iMsgLength         = sizeof(struct INT_ERROR_FE_RESP);
        pErrorResponce.IntRespHeader.iErrorId           = iErrorId;
        pErrorResponce.IntRespHeader.iMsgCode           = TC_INT_ORDER_REJECTION;
        pErrorResponce.IntRespHeader.cSource            = pOE_Req->ReqHeader.cSource;
        pErrorResponce.IntRespHeader.cSegment           = pOE_Req->ReqHeader.cSegment;
        strncpy(pErrorResponce.IntRespHeader.sExcgId,pOE_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
        strncpy(pErrorResponce.sSecurityId,pOE_Req->sSecurityId ,SECURITY_ID_LEN);
        strncpy(pErrorResponce.sClientId,pOE_Req->sClientId,CLIENT_ID_LEN);

        pErrorResponce.cBuyOrSell       =       pOE_Req->cBuyOrSell;
        pErrorResponce.cProductId       =       pOE_Req->cProductId;
        pErrorResponce.iTotalQty        =       pOE_Req->iTotalQty;
        pErrorResponce.fPrice           =       pOE_Req->fPrice;
        pErrorResponce.IntRespHeader.iUserId = pOE_Req->ReqHeader.iUserId;

	iErrorId = 56625;
        strncpy(pErrorResponce.sErrorMsg,"Currently System is not Available ",DB_REASON_DESC_LEN);
        logDebug2("Error Message :%s:",pErrorResponce.sErrorMsg);
        sprintf(pErrorResponce.sErrorCode,"MK-%d",iErrorId);
	logDebug2("pErrorResponce.IntRespHeader.iMsgLength :%d:",pErrorResponce.IntRespHeader.iMsgLength);
	
        if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
        {
                logFatal("Error : WriteMsgQ failed in fSendErrorToFE.");
                exit(ERROR);
        }
	
	logTimestamp("Entry : [OrderEntry]");
}	

BOOL 	CoOrderEntry(struct CO_ORDER_REQUEST *CoOrd_Req ,LONG32 j)
{
	logTimestamp("Entry : [CoOrderEntry]");

	CHAR InsertQry [DOUBLE_MAX_QUERY_SIZE];
	memset(InsertQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	
	struct INT_ERROR_FE_RESP pErrorResponce;
	memset(&pErrorResponce,'\0',sizeof(struct INT_ERROR_FE_RESP));

	LONG64  iErrorId=0;
        CHAR    sErrString[DB_REASON_DESC_LEN];
        memset(sErrString,'\0',DB_REASON_DESC_LEN);	
	
	sprintf(InsertQry,"INSERT INTO DUMMY_BOOK \
			(DM_SEG_NO,DM_MSGCODE,DM_EXCH_ID,DM_USER_ID,DM_SOURCE,DM_SEGMENT,\
			DM_SCRIP_CODE,DM_ENTITY_ID,DM_CLIENT_ID,DM_PRODUCT,DM_BUYSELL,DM_ORDER_TYPE,DM_ORDER_VALIDITY,DM_DISC_QTY,\
			DM_DISC_REM_QTY,DM_REM_QTY,DM_TOTAL_QTY,DM_TOTAL_TRADED_QTY,DM_MIN_FILL_QTY,DM_PRICE,DM_TRIGGER_PRICE,DM_ORDER_NUMBER,\
			DM_SERIAL_NO,DM_HANDLE_INST,DM_ALGO_ORDER_NO,DM_STRATEGY_ID,DM_OFF_MKT_FLAG,DM_PROCLIENT,DM_USER_TYPE,DM_REMARKS,\
			DM_MKT_TYPE,DM_MKT_PROTECT_FLG,DM_MKT_PROTECT_VAL,DM_PARTICIPANT_TYPE,\
			DM_SETTLOR,DM_GTC_FLG,DM_ENCASH_FLG,DM_PAN_NO,DM_GROUP_ID,DM_REMARKS1,DM_REMARKS2,\
			DM_TRAILING_SL_VALUE,DM_LEG_NO,DM_SL_AT_FLAG,DM_PR_ST_FLAG,DM_PR_ABSTICK_VALUE,DM_SL_ABSTICK_VALUE)\
			VALUES\
                        (%i,%d,\"%s\",%d,\'%c\',\
			\'%c\',\"%s\",\"%s\",\"%s\",\'%c\',\'%c\',\
			%d,%d,%d,%d,%d,%d,\
			%d,%d,%f,%f,%f,%d,\
			\'%c\',%f,%d,\'%c\',\'%c\',\'%c\',\
			\"%s\",%d,\'%c\',\
			%f,\'%c\',\"%s\",\'%c\',\'%c\',\"%s\",%d,\
			\"%s\",\"%s\",%f,%d,\'%c\',\'%c\',\
			%f,%f)",\
			CoOrd_Req->ReqHeader.iSeqNo,CoOrd_Req->ReqHeader.iMsgCode,CoOrd_Req->ReqHeader.sExcgId,CoOrd_Req->ReqHeader.iUserId,CoOrd_Req->ReqHeader.cSource,\
			CoOrd_Req->ReqHeader.cSegment,CoOrd_Req->sSecurityId,CoOrd_Req->sEntityId,CoOrd_Req->sClientId,CoOrd_Req->cProductId,CoOrd_Req->CoArray[j].cBuySellInd,\
			CoOrd_Req->iOrderType,CoOrd_Req->iOrderValidity,CoOrd_Req->iDiscQty,CoOrd_Req->iDiscQtyRem,CoOrd_Req->iTotalQtyRem,CoOrd_Req->iTotalQty,\
			CoOrd_Req->iTotalTradedQty,CoOrd_Req->iMinFillQty,CoOrd_Req->fPrice,CoOrd_Req->CoArray[j].fTriggerPrice,CoOrd_Req->fOrderNum,CoOrd_Req->iSerialNum,\
			CoOrd_Req->cHandleInst,CoOrd_Req->fAlgoOrderNo,CoOrd_Req->iStratergyId,CoOrd_Req->cOffMarketFlg,CoOrd_Req->cProCli,CoOrd_Req->cUserType,\
			CoOrd_Req->sRemarks,CoOrd_Req->iMktType,CoOrd_Req->cMarkProFlag,\
			CoOrd_Req->fMarkProVal,CoOrd_Req->cParticipantType,CoOrd_Req->sSettlor,CoOrd_Req->cGTCFlag,CoOrd_Req->cEncashFlag,CoOrd_Req->sPanID,CoOrd_Req->iGrpId,\
			CoOrd_Req->sPlatform,CoOrd_Req->sChannel,CoOrd_Req->fTrailingSLValue,CoOrd_Req->iNoOfLeg,CoOrd_Req->cSLFlag,CoOrd_Req->cPBFlag,\
			CoOrd_Req->fPBTikAbsValue,CoOrd_Req->fSLTikAbsValue);
	
	logDebug2("Query [%s]",InsertQry);
        if(mysql_query(DBConNET, InsertQry) != SUCCESS)
        {
                logSqlFatal("Error in inserting DUMMY_BOOK TABLE");
                sql_Error(DBConNET);
                return FALSE;
        }
        else
        {
                logDebug2(" Sucessfully Inserted into DUMMY_BOOK Table");
                logDebug2("%d rows updated!!",mysql_affected_rows(DBConNET));
                mysql_commit(DBConNET);
        }
	
	pErrorResponce.IntRespHeader.iSeqNo             = CoOrd_Req->ReqHeader.iSeqNo;
        pErrorResponce.IntRespHeader.iMsgLength         = sizeof(struct INT_ERROR_FE_RESP);
        pErrorResponce.IntRespHeader.iErrorId           = iErrorId;
        pErrorResponce.IntRespHeader.iMsgCode           = TC_INT_ORDER_REJECTION ;
        pErrorResponce.IntRespHeader.cSource            = CoOrd_Req->ReqHeader.cSource;
        pErrorResponce.IntRespHeader.cSegment           = CoOrd_Req->ReqHeader.cSegment;

        strncpy(pErrorResponce.IntRespHeader.sExcgId,CoOrd_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
        strncpy(pErrorResponce.sSecurityId,CoOrd_Req->sSecurityId ,SECURITY_ID_LEN);
        strncpy(pErrorResponce.sClientId,CoOrd_Req->sClientId,CLIENT_ID_LEN);

        pErrorResponce.cBuyOrSell       =       CoOrd_Req->CoArray[0].cBuySellInd;
        pErrorResponce.cProductId       =       CoOrd_Req->cProductId;
        pErrorResponce.iTotalQty        =       CoOrd_Req->iTotalQty ;
        pErrorResponce.fPrice           =       CoOrd_Req->fPrice ;
        pErrorResponce.IntRespHeader.iUserId = CoOrd_Req->ReqHeader.iUserId;
	iErrorId = 56625;
        strncpy(pErrorResponce.sErrorMsg,"Currently System is not Available ",DB_REASON_DESC_LEN);
	logDebug2("Error string :%s:",pErrorResponce.sErrorMsg);
	sprintf(pErrorResponce.sErrorCode,"MK-%d",iErrorId);
	logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);



        logDebug2("pErrorResponce.IntRespHeader.iMsgCode        :%d:",pErrorResponce.IntRespHeader.iMsgCode);
        logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);
        logDebug2("pErrorResponce.IntRespHeader.iMsgLength      :%d:",pErrorResponce.IntRespHeader.iMsgLength);
        logDebug2("pErrorResponce.IntRespHeader.iErrorId        :%d:",pErrorResponce.IntRespHeader.iErrorId);
        logDebug2("pErrorResponce.IntRespHeader.iUserId         :%llu:",pErrorResponce.IntRespHeader.iUserId);
        logDebug2("pErrorResponce.IntRespHeader.cSource         :%c:",pErrorResponce.IntRespHeader.cSource);
        logDebug2("pErrorResponce.IntRespHeader.cSegment        :%c:",pErrorResponce.IntRespHeader.cSegment);
        logDebug2("pErrorResponce.IntRespHeader.sExcgId         :%s:", pErrorResponce.IntRespHeader.sExcgId);


        if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
        {
                logFatal("Error : WriteMsgQ failed in fCoSendErrorToFE.");
                exit(ERROR);
        }
			
	
	logTimestamp("Entry : [CoOrderEntry]");

}																									
	
BOOL 	BoOrderEntry(struct BO_ORDER_REQUEST *BoOrd_Req,LONG32 j)
{

	logTimestamp("Entry : [BoOrderEntry]");
	
	CHAR InsertQry [DOUBLE_MAX_QUERY_SIZE];
	memset(InsertQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	struct INT_ERROR_FE_RESP pErrorResponce;
        memset(&pErrorResponce,'\0',sizeof(struct INT_ERROR_FE_RESP));

        LONG64  iErrorId=0;
        CHAR    sErrString[DB_REASON_DESC_LEN];
        memset(sErrString,'\0',DB_REASON_DESC_LEN);
					
	sprintf(InsertQry,"INSERT INTO DUMMY_BOOK \
                        (DM_SEG_NO,DM_MSGCODE,DM_EXCH_ID,DM_USER_ID,DM_SOURCE,DM_SEGMENT,\
                        DM_SCRIP_CODE,DM_ENTITY_ID,DM_CLIENT_ID,DM_PRODUCT,DM_BUYSELL,DM_ORDER_TYPE,DM_ORDER_VALIDITY,DM_DISC_QTY,\
                        DM_DISC_REM_QTY,DM_REM_QTY,DM_TOTAL_QTY,DM_TOTAL_TRADED_QTY,DM_MIN_FILL_QTY,DM_PRICE,DM_TRIGGER_PRICE,DM_ORDER_NUMBER,\
                        DM_SERIAL_NO,DM_HANDLE_INST,DM_ALGO_ORDER_NO,DM_STRATEGY_ID,DM_OFF_MKT_FLAG,DM_PROCLIENT,DM_USER_TYPE,DM_REMARKS,\
                        DM_MKT_TYPE,DM_MKT_PROTECT_FLG,DM_MKT_PROTECT_VAL,DM_PARTICIPANT_TYPE,\
                        DM_SETTLOR,DM_GTC_FLG,DM_ENCASH_FLG,DM_PAN_NO,DM_GROUP_ID,DM_REMARKS1,DM_REMARKS2,\
			DM_TRAILING_SL_VALUE,DM_LEG_NO,DM_SL_AT_FLAG,DM_PR_ST_FLAG,DM_PR_ABSTICK_VALUE,DM_SL_ABSTICK_VALUE)\
                        VALUES\
                        (%i,%d,\"%s\",%d,\'%c\',\
                        \'%c\',\"%s\",\"%s\",\"%s\",\'%c\',\'%c\',\
                        %d,%d,%d,%d,%d,%d,\
                        %d,%d,%f,%f,%f,%d,\
                        \'%c\',%f,%d,\'%c\',\'%c\',\'%c\',\
                        \"%s\",%d,\'%c\',\
                        %f,\'%c\',\"%s\",\'%c\',\'%c\',\"%s\",%d,\
                        \"%s\",\"%s\",%f,%d,\'%c\',\'%c\',\
			%f,%f)",\
                        BoOrd_Req->ReqHeader.iSeqNo,BoOrd_Req->ReqHeader.iMsgCode,BoOrd_Req->ReqHeader.sExcgId,BoOrd_Req->ReqHeader.iUserId,BoOrd_Req->ReqHeader.cSource,\
			BoOrd_Req->ReqHeader.cSegment,BoOrd_Req->sSecurityId,BoOrd_Req->sEntityId,BoOrd_Req->sClientId,BoOrd_Req->cProductId,BoOrd_Req->BoArray[j].cBuySellInd,\
			BoOrd_Req->iOrderType,BoOrd_Req->iOrderValidity,BoOrd_Req->iDiscQty,BoOrd_Req->iDiscQtyRem,BoOrd_Req->iTotalQtyRem,BoOrd_Req->iTotalQty,\
			BoOrd_Req->iTotalTradedQty,BoOrd_Req->iMinFillQty,BoOrd_Req->fPrice,BoOrd_Req->BoArray[j].fTriggerPrice,BoOrd_Req->fOrderNum,BoOrd_Req->iSerialNum,\
			BoOrd_Req->cHandleInst,BoOrd_Req->fAlgoOrderNo,BoOrd_Req->iStratergyId,BoOrd_Req->cOffMarketFlg,BoOrd_Req->cProCli,BoOrd_Req->cUserType,\
			BoOrd_Req->sRemarks,BoOrd_Req->iMktType,BoOrd_Req->cMarkProFlag,\
                        BoOrd_Req->fMarkProVal,BoOrd_Req->cParticipantType,BoOrd_Req->sSettlor,BoOrd_Req->cGTCFlag,BoOrd_Req->cEncashFlag,BoOrd_Req->sPanID,BoOrd_Req->iGrpId,\
                        BoOrd_Req->sPlatform,BoOrd_Req->sChannel,BoOrd_Req->fTrailingSLValue,BoOrd_Req->iNoOfLeg,BoOrd_Req->cSLFlag,BoOrd_Req->cPBFlag,\
			BoOrd_Req->fPBTikAbsValue,BoOrd_Req->fSLTikAbsValue);

	logDebug2("Query [%s]",InsertQry);
        if(mysql_query(DBConNET, InsertQry) != SUCCESS)
        {
                logSqlFatal("Error in inserting DUMMY_BOOK TABLE");
                sql_Error(DBConNET);
                return FALSE;
        }
        else
        {
                logDebug2(" Sucessfully Inserted into DUMMY_BOOK Table");
                logDebug2("%d rows updated!!",mysql_affected_rows(DBConNET));
                mysql_commit(DBConNET);
        }

	logDebug2(" New 1");
        pErrorResponce.IntRespHeader.iSeqNo     = BoOrd_Req->ReqHeader.iSeqNo;
        logDebug2(" New 2");
        pErrorResponce.IntRespHeader.iMsgLength         = sizeof(struct INT_ERROR_FE_RESP);
        logDebug2(" New 3");
        pErrorResponce.IntRespHeader.iErrorId           = iErrorId;
        logDebug2(" New 4");
        pErrorResponce.IntRespHeader.iMsgCode           = TC_INT_ORDER_REJECTION;
        logDebug2(" New 5");
        pErrorResponce.IntRespHeader.cSource            = BoOrd_Req->ReqHeader.cSource;
        logDebug2(" New 6");
        pErrorResponce.IntRespHeader.cSegment           = BoOrd_Req->ReqHeader.cSegment;
        logDebug2(" New 7");

        strncpy(pErrorResponce.IntRespHeader.sExcgId,BoOrd_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
        logDebug2(" New 8");
        strncpy(pErrorResponce.sSecurityId,BoOrd_Req->sSecurityId ,SECURITY_ID_LEN);
        logDebug2(" New 9");
        strncpy(pErrorResponce.sClientId,BoOrd_Req->sClientId,CLIENT_ID_LEN);
        logDebug2(" New 10");

        pErrorResponce.cBuyOrSell       =       BoOrd_Req->BoArray[0].cBuySellInd;
        logDebug2(" New 11");
        pErrorResponce.cProductId       =       BoOrd_Req->cProductId;
        logDebug2(" New 12");
        pErrorResponce.iTotalQty        =       BoOrd_Req->iTotalQty;
        logDebug2(" New 13");
        pErrorResponce.fPrice           =       BoOrd_Req->fPrice;
        logDebug2(" New 14");
        pErrorResponce.IntRespHeader.iUserId = BoOrd_Req->ReqHeader.iUserId;
	iErrorId = 56625;

        strncpy(pErrorResponce.sErrorMsg,"Currently System is not Available ",DB_REASON_DESC_LEN);
        sprintf(pErrorResponce.sErrorCode,"MK-%d",iErrorId);
	logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);	
	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
        {
                logFatal("Error : WriteMsgQ failed in fSendErrorToFE.");
                exit(ERROR);
        }
			
	
        logTimestamp("Entry : [BoOrderEntry]");

}

BOOL    fGenerateClOrdId(CHAR *sClOrdId)
{
        logTimestamp("fGenerateClOrdId [Entry]");
        CHAR    sTempClOrdId[CLORDID_LEN];

        fDMClOrdID =fopen(sFileName,"rb+");
        LONG64 iTempSeq;

        if(fDMClOrdID == NULL)
        {
                logFatal("Not Able to Open File");
                exit(0);
        }
        else
        {
                while(!feof(fDMClOrdID))
                {
                        memset(sTempClOrdId, '\0', CLORDID_LEN); // clean buffer
                        fscanf(fDMClOrdID, "%[^\n]\n",sTempClOrdId);
                }
                logDebug2("Last Line :: %s",sTempClOrdId);
        }

        iTempSeq = atoi(sTempClOrdId);
        iTempSeq++;

        fprintf(fDMClOrdID,"\n%i",iTempSeq);
        sprintf(sClOrdId,"%s%d",sTempClOrdId,iMsgType);
        fclose(fDMClOrdID);


        logTimestamp("fGenerateClOrdId [Exit]");
}
	
	
BOOL fSelectDate(CHAR *sSeq)
{
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
		
	if (mysql_query(DBConNET, "SELECT SUBSTR(CONCAT(Date_format(CURDATE(),'%Y%m%d')),3,8);") != SUCCESS)
        {
                sql_Error(DBConNET);
                logSqlFatal("error in select Date [EQOrdSvr].");
                return FALSE;
        }

        Res = mysql_store_result(DBConNET);
        while((Row = mysql_fetch_row(Res)))
        {
                strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Date_format : %s", sSeq);
        }

        mysql_free_result(Res);

        return TRUE;
}
