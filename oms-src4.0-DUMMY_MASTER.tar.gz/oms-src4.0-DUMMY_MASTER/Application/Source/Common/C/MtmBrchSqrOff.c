#include "IPCS.h"
#include <sys/time.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <mysql.h>

LONG32  iAutoSqoffToOrdRtr;
LONG32  iRDaemonToMtmSqoff;

LONG32  iMsgType = 0;
LONG32  iCount = 0;
LONG32	iMtmFlag ;
LONG32	iDefaultMtmFlag = 0 ;
LONG32 iRow ;

MYSQL           *DBCon;
CHAR    sAdmin [15];

main(LONG32 argc,CHAR **argv)
{
	logTimestamp("ENTRY [Main]");

	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;

	LONG32	i = 0;
	CHAR    cMsgType;
	CHAR sSelectQry[MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	memset(sAdmin,'\0',15);
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);

	fOpenMsgQue();
	DBCon = DB_Connect();


	sprintf(sSelectQry,"SELECT s.PARAM_VALUE from SYS_PARAMETERS  s where s.PARAM_NAME  = 'Default_admin' OR s.PARAM_NAME = 'MtmAutoSqroff_Flag'");

	if (mysql_query(DBCon ,sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching SysAdmin .");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry);

	Res = mysql_store_result(DBCon);
	iRow = (mysql_num_rows(Res));

	if(iRow == 0)
	{
		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{	
		while (Row = mysql_fetch_row(Res))
		{
			if(i == 0)
			{
				strncpy(sAdmin,Row[0],15);
			}
			else
			{
				iDefaultMtmFlag = atoi(Row[0]);
			}

			i ++ ;
		}
	}
	logDebug2("Printing name of Admin:%s:",sAdmin);
	logDebug2("Printing iMtmFlag  	:%d:",iDefaultMtmFlag);
	mysql_free_result(Res);
	fMtmSquareOff();

	logTimestamp("EXIT [MAIN]");
}

BOOL fMtmSquareOff ()
{

	logTimestamp("fMtmSquareOff [ENTRY]");

	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;
	CHAR    sRcvMsg[RUPEE_MAX_PACKET_SIZE];

	struct  INT_MTM_BREACH_RESP *pSrOfOrd;
	LONG32  iRetVal = 0;
	LONG32	iMsgCode = 0;

	CHAR sSelectQry [MAX_QUERY_SIZE];
	CHAR SelQry[MAX_QUERY_SIZE];

	while(1)
	{
		memset(&pSrOfOrd,'\0',sizeof(struct INT_MTM_BREACH_RESP));
		memset(&sRcvMsg,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(sSelectQry ,'\0',MAX_QUERY_SIZE);
		memset(SelQry,'\0',MAX_QUERY_SIZE);

		logDebug2("iMsgType :%d:",iMsgType);

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if(ReadMsgQ(iRDaemonToMtmSqoff,&sRcvMsg,RUPEE_MAX_PACKET_SIZE,1) != 1)
		{
			logFatal("Error : MsgQID is %d",iRDaemonToMtmSqoff);
			exit(ERROR);
		}
		logDebug2("Dropping the packet");
		logTimestamp("fMtmSquareOff [EXIT]");

	}
}
/*

   pSrOfOrd = (struct INT_MTM_BREACH_RESP*)&sRcvMsg;

   logDebug2("pSrOfOrd->sClientId :%s:",pSrOfOrd->sClientId);

   sprintf(sSelectQry,"select UM_MTM_SQROFF_FLAG from USER_MASTER where USER_ENTITY_CODE = ltrim(rtrim(\'%s\'))",pSrOfOrd->sClientId);

   if (mysql_query(DBCon ,sSelectQry) != SUCCESS)
   {
   sql_Error(DBCon);
   logSqlFatal("Error Fetching SysAdmin .");
   exit(ERROR);
   }
   logDebug2("Query [%s]",sSelectQry);

   Res = mysql_store_result(DBCon);
   iRow = (mysql_num_rows(Res));
   if(iRow == 0)
   {
   mysql_free_result(Res);
   logDebug2("Zero rows selected");
   }
   else
   {
   while (Row = mysql_fetch_row(Res))
   {
   iMtmFlag = atoi(Row[0]);
   }
   }

   if((iMtmFlag != 0) || (iMtmFlag != 1) || (iMtmFlag != 2) || (iMtmFlag != 3) )
   {
   logDebug2("Assigning Default Value from Sysparameter :%d:",iDefaultMtmFlag);
   iMtmFlag = iDefaultMtmFlag ;
   }
   mysql_free_result(Res);	

   logInfo("ALL_SQUAREOFF_POSITION -> 0");
   logInfo("MAX_LOSS_POSITION	-> 1");
   logInfo("MIN_LOSS_POSITION 	-> 2");
   logInfo("MAX_PROFIT_POSITION	-> 3");

   logDebug2("CLIENT_ID 	:%s:",pSrOfOrd->sClientId);
   logDebug2("UM_MTM_SQROFF_FLAG  :%d:",iMtmFlag);
   logDebug2("EXCAHNGE 	:%s:",pSrOfOrd->IntRespHeader.sExcgId);
   logDebug2("ENTITY_ID	:%s:",sAdmin);

   iRetVal = fCnlEqPendingOrd(&sRcvMsg);
   if(iRetVal == FALSE)
   {
   logInfo(" Equity Orders Cancelled Failed");
   }
   else if(iRetVal == NO_ROWS)
   {
   logInfo(" No Equity Pending Orders ");
   }			
   else  
   {
   logInfo(" Equity Orders Cancelled Sucessfully");
   }

   iRetVal = fCnlDrPendingOrd(&sRcvMsg);
   if(iRetVal == FALSE)
   {
   logInfo("Derivative Orders Cancelled Failed");
   }
   else if(iRetVal == NO_ROWS)
   {
   logInfo(" No Derivative  Pending Orders ");
   }
else
{
	logInfo("Derivative Orders Cancelled Sucessfully");
}

switch(iMtmFlag)
{
	case ALL_SQUAREOFF_POSITION    :
		sprintf(SelQry," ORDER BY a.MTM");

		break;
	case MAX_LOSS_POSITION          :

		sprintf(SelQry,"ORDER BY  a.MTM ASC LIMIT 1");

		break;
	case MIN_LOSS_POSITION          :
		sprintf(SelQry,"AND a.MTM < 0 ORDER BY  a.MTM  DESC LIMIT 1 ");
		break;
	case MAX_PROFIT_POSITION        :
		sprintf(SelQry," ORDER BY a.MTM DESC LIMIT 1");
		break;

	default :
		return FALSE;
}

logDebug2("SelQry[%s]",SelQry);
iRetVal = fSqrOffOrd(&sRcvMsg,SelQry);
if(iRetVal == FALSE)
{
	logInfo("SquareOff Orders Failed");
}
else if(iRetVal == NO_ROWS)
{
	logInfo(" No Sell Position ");
}
else
{
	logInfo("SquareOff of Orders Sucess");
}

}
*/
/*	
	BOOL fCnlEqPendingOrd (CHAR *RcvMsg)
	{
	logTimestamp("fCnlEqPendingOrd	[ENTRY]");
	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32          iRow, iRow2;

	CHAR    sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	struct  INT_MTM_BREACH_RESP *pCnlEOrd;	
	struct  ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  INT_MTM_BREACH_RESP *)RcvMsg ;

	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
	EQ_SERIAL_NO,\
	EQ_SCRIP_CODE,\
	EQ_MKT_TYPE,\
	EQ_EXCH_ID,\
	EQ_ENTITY_ID,\
	EQ_CLIENT_ID,\
	EQ_BUY_SELL_IND,\
	EQ_TOTAL_QTY,\
	EQ_REM_QTY,\
	EQ_DISC_QTY,\
	EQ_DISC_REM_QTY,\
	EQ_TOTAL_TRADED_QTY,\
	EQ_ORDER_PRICE,\
	EQ_TRIGGER_PRICE,\
	EQ_VALIDITY,\
	EQ_ORDER_TYPE,\
	EQ_USER_ID,\
	EQ_MIN_FILL_QTY,\
	EQ_PRO_CLIENT,\
	EQ_USER_TYPE,\
	EQ_REMARKS,\
	EQ_SOURCE_FLG,\
	EQ_PRODUCT_ID,\
	EQ_MSG_CODE,\
	EQ_SEGMENT\
	FROM    EQ_ORDERS A\
	WHERE   A.EQ_ORD_STATUS = \'%c\' \
	AND     A.EQ_MSG_CODE IN (%d,%d)\
	AND	A.EQ_CLIENT_ID = \"%s\" \
	AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO) ;",EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,pCnlEOrd->sClientId);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DBCon,sSelQry) != SUCCESS)
	{
	sql_Error(DBCon);
	logSqlFatal("Error in fCnlEqPendingOrd Query.");
	exit(ERROR);
	}

	Res = mysql_store_result(DBCon);
	if( mysql_num_rows(Res)  == 0)
	{
	mysql_free_result(Res);
	return NO_ROWS ;
	}
	else
	{
	logDebug2("Total No Of PenDing Orders :%d:",mysql_num_rows(Res));
	while(Row = mysql_fetch_row(Res))
	{
	strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
	pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
	pEOrdReq.ReqHeader.cSource= Row[22][0];
pEOrdReq.ReqHeader.cSegment = Row[25][0];
pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);

strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

pEOrdReq.cProductId= Row[23][0];
pEOrdReq.cBuyOrSell = Row[7][0];
pEOrdReq.iOrderType = atoi(Row[16]);
pEOrdReq.iOrderValidity = atof(Row[15]);
pEOrdReq.iTotalQty = atoi(Row[8]);
pEOrdReq.iTotalQtyRem = atoi(Row[9]);
pEOrdReq.iDiscQty = atoi(Row[10]);
pEOrdReq.iDiscQtyRem = atoi(Row[11]);
pEOrdReq.iTotalTradedQty = atoi(Row[12]);
pEOrdReq.fPrice = atof(Row[13]);
pEOrdReq.fTriggerPrice = atof(Row[14]);
pEOrdReq.fOrderNum = atof(Row[0]);
pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
pEOrdReq.cHandleInst = Row[19][0];
pEOrdReq.iStratergyId= atof(Row[0]);
pEOrdReq.cProCli = Row[19][0];
pEOrdReq.cUserType = Row[20][0];
strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);
if(strcmp(Row[3],MKT_TYPE_NL)== 0)
{
	pEOrdReq.iMktType = NORMAL_MARKET;
}
else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
{
	pEOrdReq.iMktType = ODDLOT_MARKET;
}
else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
{
	pEOrdReq.iMktType = SPOT_MARKET;
}
else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
{
	pEOrdReq.iMktType = AUCTION_MARKET;
}
else
{
	logDebug2(" %s ",Row[3]);
}
if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
{
	perror("Error WriteMsgQ");
	mysql_free_result(Res);
	mysql_close(DBCon);
	exit(ERROR);
}
}
}
logTimestamp("fCnlEqPendingOrd  [EXIT]");
return TRUE;
}	

BOOL fSqrOffOrd (CHAR *RcvMsg ,CHAR *Query)
{
	logTimestamp("fSqrOffOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;


	CHAR *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	struct  INT_MTM_BREACH_RESP *pEQSellOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pEQSellOrd = (struct  INT_MTM_BREACH_RESP *)RcvMsg ;

	sprintf(sQuery,"SELECT  SECURITY_ID,\
			MKT_TYPE,\
			EXCH_ID ,\
			CLIENT_ID,\
			PROD_ID,\
			(NET_QTY) QTY_ORIGINNAL,\
			(NET_QTY) QTY_REMAINING,\
			um.USER_CODE ,\
			SEGMNT \
			FROM    VIEW_NET_POSITION a, USER_MASTER um\
			WHERE \
			NOT (gross_qty = 0 AND realised_profit = 0)\
			AND a.segmnt  IN ('E','D','C')\
			AND um.USER_ENTITY_CODE = ltrim(rtrim(\'%s\')) \		
			AND a.CLIENT_ID = ltrim(rtrim(\'%s\')) %s",pEQSellOrd->sClientId,pEQSellOrd->sClientId,Query);


	//                                AND a.exch_id= ltrim(rtrim(\'%s\')) %s",pEQSellOrd->sClientId,pEQSellOrd->sClientId,pEQSellOrd->IntRespHeader.sExcgId ,Con);

	logDebug1("sQuery :%s:",sQuery);

	if(mysql_query(DBCon,sQuery) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in fSqrOffOrd select Query.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);

	if(mysql_num_rows(Res) == 0)
	{
		mysql_free_result(Res);	
		logDebug2("No  Sell Position Orders");
		return NO_ROWS ;
	}
	else
	{
		while(Row = mysql_fetch_row(Res))
		{
			logDebug2("Total No Of Sell Orders which needs to be SquareOff:%d:",mysql_num_rows(Res));

			pEOrdReq.ReqHeader.iMsgLength = sizeof(struct  ORDER_REQUEST);
			pEOrdReq.ReqHeader.iMsgCode   = TC_INT_ORDER_ENTRY_REQ;
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[2],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[7]);
			pEOrdReq.ReqHeader.cSource = SOURCE_ADMIN;
			logDebug2("Segment =  :%c:",Row[8][0]);
			pEOrdReq.ReqHeader.cSegment= Row[8][0];

			strncpy(pEOrdReq.sSecurityId,Row[0],SECURITY_ID_LEN);
			//              strncpy(pEOrdReq.sEntityId,Row[3],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[3],CLIENT_ID_LEN);
			pEOrdReq.cProductId = Row[4][0];


			if(atoi(Row[5]) < 0)
			{
				pEOrdReq.iTotalQty = (atoi(Row[5]) * -1);
				pEOrdReq.iTotalQtyRem = (atoi(Row[6]) * -1)  ;
			}
			else
			{
				pEOrdReq.iTotalQty = atoi(Row[5]);	
				pEOrdReq.iTotalQtyRem= atoi(Row[6]);	
			}
			logDebug2("Total Qty = :%d:",atoi(Row[5]));
			if(atoi(Row[5]) < 0)
			{
				pEOrdReq.cBuyOrSell = INT_BUY;
			}
			else if (atoi(Row[5]) > 0)
			{
				pEOrdReq.cBuyOrSell = INT_SELL;
			}
			else
			{
				logDebug2("Error in Qty");
				return FALSE;
			}
			logDebug2("pEOrdReq.cBuyOrSell :%c:",pEOrdReq.cBuyOrSell);
			pEOrdReq.iOrderType = ORD_TYPE_MKT;
			pEOrdReq.iOrderValidity = VALIDITY_IOC;
			pEOrdReq.iDiscQty = 0;
			pEOrdReq.iDiscQtyRem = 0;
			pEOrdReq.iTotalTradedQty = 0;
			pEOrdReq.iMinFillQty = 0;
			pEOrdReq.fPrice= 0;
			pEOrdReq.fTriggerPrice= 0;
			pEOrdReq.fOrderNum = 0;
			pEOrdReq.iSerialNum= 1;
			pEOrdReq.cHandleInst = '1';
			pEOrdReq.fAlgoOrderNo = 0;
			pEOrdReq.iStratergyId = 0;
			pEOrdReq.cOffMarketFlg= NO;
			pEOrdReq.cProCli = NNF_CLI;
			pEOrdReq.cUserType = ADMIN_TYPE;
			strncpy(pEOrdReq.sRemarks,";",REMARKS_LEN);

			if(strcmp(Row[1],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[1],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" INVALID Mkt Type :%s: ",Row[1]);
			}
			pEOrdReq.iAuctionNum = 0;

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DBCon);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fSqrOffOrd [EXIT]");
	return TRUE;
}

BOOL fCnlDrPendingOrd(CHAR *RcvMsg)
{
	logTimestamp("fCnlDrPendingOrd [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR  sSelQry [MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	struct  INT_MTM_BREACH_RESP *pCnlEOrd;
	struct  ORDER_REQUEST   pEOrdReq;

	pCnlEOrd = (struct  INT_MTM_BREACH_RESP *)RcvMsg ;

	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT\
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS = \'%c\' \
			AND     A.DRV_MSG_CODE IN (%d,%d)\
			AND	DRV_CLIENT_ID = ltrim(rtrim(\'%s\')) \
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO);",EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,pCnlEOrd->sClientId);

	//			AND     A.DRV_EXCH_ID = \"%s\" ;",EXCH_CONFIRM_STATUS,TC_INT_OE_CONF_RESP,TC_INT_OM_CONF_RESP,pCnlEOrd->sClientId,pCnlEOrd->IntRespHeader.sExcgId);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DBCon,sSelQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error in fCnlDrPendingOrd Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DBCon);

	if(mysql_num_rows(Res) == 0)
	{
		mysql_free_result(Res);
		return NO_ROWS ;
	}
	else
	{
		while(Row = mysql_fetch_row(Res))
		{
			logDebug2("Total No Of PenDing Orders :%d:",mysql_num_rows(Res));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = atoi(Row[17]);
			pEOrdReq.ReqHeader.cSource= Row[22][0];
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			//pEOrdReq.ReqHeader.iMsgCode = atoi(Row[25]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);



			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,Row[5],ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.cBuyOrSell = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = atof(Row[15]);
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[9]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= atof(Row[0]);
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = Row[20][0];
			strncpy(pEOrdReq.sRemarks ,Row[21],REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			if(WriteMsgQ(iAutoSqoffToOrdRtr,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DBCon);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fCnlDrPendingOrd [EXIT]");
	return TRUE;
}
*/

BOOL fOpenMsgQue()
{
	if( ( iAutoSqoffToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug2("write Q = %d",iAutoSqoffToOrdRtr);
	if( ( iRDaemonToMtmSqoff = OpenMsgQ( (RDaemonToMtmSqoff))) == ERROR )
	{
		perror("Open iRDaemonToMtmSqoff:");
		exit( 1 );
	}
	logDebug2("Read Q = %d",iRDaemonToMtmSqoff);

	return TRUE;
}
