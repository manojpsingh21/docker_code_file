#include <stdio.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

MYSQL          *DB_Con;
MYSQL_RES      *Res;
MYSQL_ROW       Row;

CHAR	sTempErrStr[200];
CHAR    sDate[DATE_LEN];
CHAR   	sGeneratedOrdNo[ORDER_LEN];
CHAR    sGenerateOrdNo [2] [ORDER_LEN];
CHAR    sFileName[FILE_NAME_LEN];
CHAR    sSettler[SETTLOR_LEN];
CHAR    sSettlor[SETTLOR_LEN];
CHAR    sSelectQry[MAX_QUERY_SIZE];
CHAR    sNseSettler[SETTLOR_LEN];
CHAR    sBseSettler[SETTLOR_LEN];
CHAR    sMcxSettler[SETTLOR_LEN];
CHAR	sDefSettler[SETTLOR_LEN];
CHAR	cGttType  = '\0';


DOUBLE64        iOrder_no_date = 0.0;
BOOL            ChkFlag = FALSE;
LONG32 		iOrdRtrToGTTOrd=0;
LONG32  	iOrdSrvToTrdRtr=0;
DOUBLE64        GeneratedOrdNo = 0;

LONG32  	rcvQ;
LONG32          iNCmBranchId ;
LONG32          iNFoBranchId ;
LONG32          iNCurBranchId ;
LONG32		iMcxBranchId ;
CHAR            sSettlor        [SETTLOR_LEN];
LONG32          iMcxUsrId ;
CHAR            sMcxBrokerId [BROKER_CODE_LEN];
LONG32          iMktChk=0;

CHAR     sGTTExpiryDate[DB_DATETIME_LEN];

FILE            *fClOrdID;

BOOL 	ForeverOrderProcess(LONG32 iOrdRtrToGTTOrd, LONG32 iOrdSrvToTrdRtr);
BOOL 	fSendSucessRespToFE(struct INT_ORDERS *p_oe_request,LONG32 sndQ);
BOOL  	fOffline_Order_DBUpdate(struct INT_ORDERS * p_Req_in, char * p_Req_out);
BOOL 	fFwdStructMapper(struct  FOREVER_ORDER_REQUEST *Ord_Req,struct INT_ORDERS *Ins_Req, CHAR *sTempClOrdId,LONG32 j);
void 	fPrintAll (struct  FOREVER_ORDER_REQUEST *pIntReqHeader, LONG32 j);

LONG32          iGroupId=1;

redisContext *RdConn;

CHAR    cGTTFlag = '\0';
CHAR    sGTTFlag [ENV_VARIABLE_LEN];
void    LoadEnv();

main (int argc, char **argv)
{
	logTimestamp("Entry : [Main]");
	setbuf ( stdout,NULL);
	setbuf ( stdin ,NULL);
	memset(sDate, '\0',DATE_LEN);
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);

	if((iOrdRtrToGTTOrd=OpenMsgQ(OrdRtrToGTTOrd)) == ERROR)
	{
		logFatal("OpenMsgQ2 ...OrdRtrToGTTOrd");
		exit(ERROR);
	}

	if (( iOrdSrvToTrdRtr= OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal("OpenMsgQ2 ...OffOrdToTrdRtr ");
		exit(ERROR);
	}

	logInfo("QUEUES OPENED SUCCESSFULLY");

	logDebug2("Recv Queue id is :%d, Send Q Id Is :%d",iOrdRtrToGTTOrd,iOrdSrvToTrdRtr);

	DB_Con = DB_Connect();
	RdConn = RDConnect();

	fSelectDate(&sDate);

	LoadEnv();
	fLoadDBNseEnv ();
	fLoadDBMcxEnv ();
	fLoadDBBseEnv ();

	if(fAddEQSecHash() == TRUE)
	{
		logInfo("Success Adding Equity Securities to HASH ");
	}
	else
	{
		logInfo("Adding Securities to HASH FAILS");
	}
	if(fAddDrvSecHash() == TRUE)
	{
		logInfo("Success Adding Derivative Securities to HASH ");
	}
	else
	{
		logInfo("Adding Securities to HASH FAILS");
	}
	
	if(fAddMCXSecHash() != TRUE )
	{
		logFatal("Error in Fetching COMM Security");                
	}
	
	if(getenv("GROUP_ID") == NULL)
        {
                logFatal("Error : Environment Variable missing : GROUP_ID ");
                exit(ERROR);
        }
        else
        {
                iGroupId = atoi(getenv("GROUP_ID"));
        }

	
	ForeverOrderProcess(iOrdRtrToGTTOrd,iOrdSrvToTrdRtr);

	logTimestamp("Exit : [Main]");

}

void fPrintAll(struct  FOREVER_ORDER_REQUEST *pOE_Req , LONG32 j)
{
	logTimestamp("-------------------Start Printing Forever Order Request Struct---------------");

	logDebug2("sizeof(FOREVER_ORDER_REQUEST) = :%d:",sizeof( struct FOREVER_ORDER_REQUEST));

	logDebug2("Co_Req->ReqHeader.iSeqNo     	:%d:",pOE_Req->ReqHeader.iSeqNo);
	logDebug2("Co_Req->ReqHeader.iMsgLength		:%d:",pOE_Req->ReqHeader.iMsgLength);
	logDebug2("Co_Req->ReqHeader.iMsgCode 		:%d:",pOE_Req->ReqHeader.iMsgCode);
	logDebug2("Co_Req->ReqHeader.sExcgId 		:%s: strlen(pOE_Req->ReqHeader.sExcgId) = :%d:",pOE_Req->ReqHeader.sExcgId,strlen(pOE_Req->ReqHeader.sExcgId));
	logDebug2("Co_Req->ReqHeader.iUserId  		:%llu:",pOE_Req->ReqHeader.iUserId);
	logDebug2("Co_Req->ReqHeader.cSource  		:%c:",pOE_Req->ReqHeader.cSource);
	logDebug2("Co_Req->ReqHeader.cSegment 		:%c:",pOE_Req->ReqHeader.cSegment);

	logDebug3("Co_Req->CoArray[%d].fTriggerPrice	:%lf:",j,pOE_Req->CoArray[j].fTriggerPrice);
	logDebug2("Co_Req->CoArray[%d].iLegValue	:%d:",j,pOE_Req->CoArray[j].iLegValue);
	logDebug3("Co_Req->CoArray[%d].fPrice		:%lf:",j,pOE_Req->CoArray[j].fPrice);
	logDebug2("Co_Req->CoArray[%d].iTotalQtyRem	:%d:",j,pOE_Req->CoArray[j].iTotalQtyRem);
	logDebug2("Co_Req->CoArray[%d].iTotalQty	:%d:",j,pOE_Req->CoArray[j].iTotalQty);

	logDebug2("Co_Req->sSecurityId         		:%s:     strlen(Co_Req->sSecurityId)       = :%d:",pOE_Req->sSecurityId,strlen(pOE_Req->sSecurityId));
	logDebug3("Co_Req->sEntityId           		:%s:     strlen(Co_Req->sEntityId)  = :%d:", pOE_Req->sEntityId,strlen(pOE_Req->sEntityId));
	logDebug2("Co_Req->sClientId           		:%s:     strlen(Co_Req->sClientId)         = :%d:",pOE_Req->sClientId,strlen(pOE_Req->sClientId));
	logDebug2("Co_Req->cProductId 			:%c:",pOE_Req->cProductId);
	logDebug2("Co_Req->cHandleInst			:%c:",pOE_Req->cHandleInst);
	logDebug2("Co_Req->cOffMarketFlg		:%c:",pOE_Req->cOffMarketFlg);
	logDebug2("Co_Req->cUserType			:%c:",pOE_Req->cUserType);
	logDebug2("Co_Req->cBuySellInd	 		:%c:",pOE_Req->cBuySellInd);
	logDebug2("Co_Req->iMktType 			:%d:",pOE_Req->iMktType);
	logDebug2("Co_Req->iDiscQty 			:%d:",pOE_Req->iDiscQty);
	logDebug2("Co_Req->iDiscQtyRem 			:%d:",pOE_Req->iDiscQtyRem );
	logDebug2("Co_Req->iTotalTradedQty 		:%d:",pOE_Req->iTotalTradedQty );
	logDebug2("Co_Req->fOrderNum 			:%lf:",pOE_Req->fOrderNum);
	logDebug2("Co_Req->iSerialNum 			:%d:",pOE_Req->iSerialNum);
	logDebug2("Co_Req->fAlgoOrderNo 		:%lf:",pOE_Req->fAlgoOrderNo);
	logDebug2("Co_Req->fTrailingSLValue		:%f:",pOE_Req->fTrailingSLValue);
	logDebug2("Co_Req->cProCli 			:%c:",pOE_Req->cProCli);
	logDebug2("Co_Req->sRemarks			:%s:",pOE_Req->sRemarks);
	logDebug2("Co_Req->iStratergyId			:%d:",pOE_Req->iStratergyId);
	logDebug2("Co_Req->iNoOfLeg 			:%d:",pOE_Req->iNoOfLeg);
	logDebug2("Co_Req->iOrderType 			:%d:",pOE_Req->iOrderType);
	logDebug2("Co_Req->iOrderValidity 		:%d:",pOE_Req->iOrderValidity);
	logDebug2("Co_Req->iMinFillQty 			:%d:",pOE_Req->iMinFillQty);
	logDebug2("Co_Req->cSLFlag              	:%c:",pOE_Req->cSLFlag);
	logDebug2("Co_Req->cPBFlag              	:%c:",pOE_Req->cPBFlag);
	logDebug2("Co_Req->cAvgLtpFlg			:%c:",pOE_Req->cAvgLtpFlg);
	logDebug2("Co_Req->fPBTikAbsValue		:%f:",pOE_Req->fPBTikAbsValue);
	logDebug2("Co_Req->fSLTikAbsValue       	:%f:",pOE_Req->fSLTikAbsValue);
	logDebug2("Co_Req->cMarkProFlag			:%c:",pOE_Req->cMarkProFlag);
	logDebug2("Co_Req->fMarkProVal			:%f:",pOE_Req->fMarkProVal);
	logDebug2("Co_Req->cParticipantType		:%c:",pOE_Req->cParticipantType);
	logDebug2("Co_Req->sSettlor			:%s:",pOE_Req->sSettlor);
	logDebug2("Co_Req->cGTCFlag			:%c:",pOE_Req->cGTCFlag);
	logDebug2("Co_Req->cEncashFlag			:%c:",pOE_Req->cEncashFlag);
	logDebug2("Co_Req->sPanID			:%s:",pOE_Req->sPanID);
	logDebug2("Co_Req->cGttType			:%c:",pOE_Req->cGttType);
	logDebug3("Co_Req->CoArray[%d].fOrdTriggerPrice    :%lf:",j,pOE_Req->CoArray[j].fOrdTriggerPrice);


	logTimestamp ("-------------------End Printing-------------------");

}

BOOL ForeverOrderProcess(LONG32 iOrdRtrToGTTOrd, LONG32 iOrdSrvToTrdRtr)
{

	logTimestamp("Entry : [ForeverOrderProcess]");

	CHAR    SndMsg[RUPEE_MAX_PACKET_SIZE],RcvMsg[RUPEE_MAX_PACKET_SIZE];
	LONG32  l_count=0;
	LONG32  i=0;
	LONG32  iRetVal =0;
	LONG32 iMsgCode=0;
	LONG32 iNoOfLeg=0;

	LONG32	iFlag = 0 ;
	CHAR    BasicError[ ERROR_MSG_LEN ];
	DOUBLE64                        fOrderNo;

	LONG32  iQty = 0;
	DOUBLE64 fAmnt = 0.00;
	LONG32	iBranchId = 0;
	LONG32	iChkFlag = 0;
	CHAR    sErrorID[10];
	CHAR    sTempClOrdId[CLORDID_LEN];

	struct  FOREVER_ORDER_REQUEST *pIntReqHeader;
	struct  INT_ORDERS          pOff_Ord;

	sprintf(sFileName,"../File/GTTClOrdID_%s",sDate);
	if(access(sFileName,F_OK) == ERROR)
	{
		fClOrdID = fopen(sFileName,"wb+");

		if (fClOrdID == NULL)
		{
			logFatal("Not able to Open File");
			exit(0);
		}
		else
		{
			fprintf(fClOrdID,"100");
		}
		fclose(fClOrdID);
	}
	else
	{
		logInfo(":%s: File Already Exists",sFileName);
	}


	for(;;)
	{
		l_count = l_count+1;

		memset(sTempClOrdId,'\0' ,CLORDID_LEN);
		memset(sErrorID,'\0' ,10);
		memset (RcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset (SndMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset( &BasicError,'\0', ERROR_MSG_LEN);
		memset (&pIntReqHeader,'\0',sizeof(struct  FOREVER_ORDER_REQUEST));
		memset (&pOff_Ord,'\0',sizeof(struct  INT_ORDERS));
		memset(sGeneratedOrdNo,'\0', ORDER_LEN);
		memset(sGTTExpiryDate,'\0',DB_DATETIME_LEN);
		iRetVal =0;
		CHAR	cGttType  = '\0';

		logDebug2("**************** Offline LOOP = %d ***************",l_count);
		if((ReadMsgQ(iOrdRtrToGTTOrd,&RcvMsg,RUPEE_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			logFatal("Error Read Q :Qid %d",iOrdRtrToGTTOrd);
			exit(ERROR);
		}

		pIntReqHeader =(struct FOREVER_ORDER_REQUEST*) &RcvMsg;

		fTrim(pIntReqHeader->sSecurityId,strlen(pIntReqHeader->sSecurityId));
		fTrim(pIntReqHeader->sEntityId,strlen(pIntReqHeader->sEntityId));
		fTrim(pIntReqHeader->sClientId,strlen(pIntReqHeader->sClientId));

		iMsgCode = pIntReqHeader->ReqHeader.iMsgCode ;
		logDebug2("------------MsgCode Received :%d:------------",iMsgCode);
	
		ChkFlag = fCheckGTTOrders();
		if(ChkFlag == TRUE)
		{
			logDebug2("GTT Orders are Allowed");
		}
		else
		{
			logDebug2("GTT Orders are Not Allowed");
			fSendErrorToFE(pIntReqHeader,GTTORDERS_NOT_ALLOWED);
			continue ;
		}

		switch (iMsgCode)
		{	
			case TC_INT_GTT_ORDER_ENTRY:
			case TC_INT_GTT_ORDER_MODIFY:
			case TC_INT_GTT_ORDER_CANCEL:

				pIntReqHeader = (struct FOREVER_ORDER_REQUEST *) &RcvMsg;

				logDebug3("pIntReqHeader->sEntityId :%s:",pIntReqHeader->sEntityId);
				logDebug3("pIntReqHeader->sClientId :%s:",pIntReqHeader->sClientId);
				/* If Client is disable or suspended then he cant place an order dealer or admin can  place order for him*/
				ChkFlag = fOrderValidation(DB_Con,pIntReqHeader->sEntityId,pIntReqHeader->sClientId);
				if(ChkFlag == FALSE)
				{
					logDebug3("Client is disable");
					fSendErrorToFE(pIntReqHeader,DISABLE_CLIENT,0,0);
					continue;
				}
				logDebug3("fOrderValidation is success");

				/*If Client is Offline then client cant place order handling @ Rohit*/
				ChkFlag = fChkClientOffline(DB_Con,pIntReqHeader->sEntityId,pIntReqHeader->sClientId);
				if(ChkFlag == FALSE)
				{
					fSendErrorToFE(pIntReqHeader,OFFLINE_CLIENT_ORDER,0,0);
					continue;
				}
				else
				{
					logDebug3("CLIENT ID AND ENTITY ID IS NOT SAME");
				}

				/* GTT Order Validation*/
				ChkFlag = fGTTBasicValidation(pIntReqHeader);
				if(ChkFlag == TRUE)
				{
					logDebug2("Success in Basic Validation");
				}
				else
				{
					logDebug2("Basic Validation returns error");
					fSendErrorToFE(pIntReqHeader,IBASIC_VALIDATION_FAILED);
					break ;
				}

				if(pIntReqHeader->ReqHeader.cSegment != SEGMENT_EQUITY)
                		{
                        		iFlag = fGTTOrdersExpCheck(DB_Con,pIntReqHeader->ReqHeader.sExcgId,pIntReqHeader->ReqHeader.cSegment,pIntReqHeader->sSecurityId);
                        		if(iFlag == FALSE)
                        		{
                                		fSendErrorToFE(pIntReqHeader, GTTORDERS_SCRIPT_EXPIRED);
                                		continue;
                        		}
                        		else
                        		{
                                	logDebug3("ORDER EXPIRY IS PROPER FOR GTTORDERS ORDERS");
                        		}
                		}	
		
				if(((iMsgCode ==  TC_INT_GTT_ORDER_ENTRY ) && (pIntReqHeader->cGttType == OCO_ORDER)))
				{
					iNoOfLeg = 2;
				}
				else
				{
					iNoOfLeg = 1;
				}

				logDebug2("iNoOfLeg = :%d:",iNoOfLeg);


				for(i = 0 ;  i < iNoOfLeg  ;i++)
				{
					ChkFlag = FALSE ;

					fTrim(pIntReqHeader->sSecurityId,strlen(pIntReqHeader->sSecurityId));
					fTrim(pIntReqHeader->sEntityId,strlen(pIntReqHeader->sEntityId));
					fTrim(pIntReqHeader->sClientId,strlen(pIntReqHeader->sClientId));
					logDebug1("before map CoOrd_Req->sClientId %s",pIntReqHeader->sClientId);
					fPrintAll(pIntReqHeader, i);

					ChkFlag = fGenGTTClOrdId(&sTempClOrdId);

					if(ChkFlag == FALSE)
					{
						logDebug3("fGenerateClOrdId returned Error : generation ClOrdId");
						fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
						break;
					}
					logDebug2("CoOrd_Req->ReqHeader.iMsgCode = :%d:",pIntReqHeader->ReqHeader.iMsgCode);
					if(pIntReqHeader->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_ENTRY && pIntReqHeader->cGttType == OCO_ORDER)
					{
						logDebug3("ORDER GENERATED FOR OCO ORDER");
						sprintf(sGenerateOrdNo[i],"%d%d%s%d",iGroupId,GTT_ORD_NO_START,sDate,(EQUITY_SEQ + atoi(sTempClOrdId)));
						logDebug2("(EQUITY_SEQ + atoi(pEQCBIntOrd.sClOrdId)):%ld:",(EQUITY_SEQ + atoi(sTempClOrdId)));
						logDebug2("iGroupId:%d:",iGroupId);
						pOff_Ord.fOrdNo = atof(sGenerateOrdNo[0]);
						pIntReqHeader->fOrderNum = pOff_Ord.fOrdNo ;
						pIntReqHeader->iSerialNum = 1;
						logDebug2(" ###########Order No Generated is => :%lf: ############",pOff_Ord.fOrdNo);

					}
					else if(pIntReqHeader->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_ENTRY && pIntReqHeader->cGttType == GTT_ORDER)
					{
						logDebug3("ORDER GENERATED FOR GTT ORDER");
						sprintf(sGeneratedOrdNo,"%d%d%s%d",iGroupId,GTT_ORD_NO_START,sDate,(EQUITY_SEQ + atoi(sTempClOrdId)));
						logDebug2("(EQUITY_SEQ + atoi(pEQCBIntOrd.sClOrdId)):%ld:",(EQUITY_SEQ + atoi(sTempClOrdId)));
						logDebug2("iGroupId:%d:",iGroupId);
						pOff_Ord.fOrdNo = atof(sGeneratedOrdNo);
						pIntReqHeader->fOrderNum = pOff_Ord.fOrdNo ;
						pIntReqHeader->iSerialNum = 1;
						logDebug2(" ###########Order No Generated is => :%lf: ############",pOff_Ord.fOrdNo);

					}
					else
					{
						logDebug3("No Need To Genrate Order NO. Not A NEW ORDER");	
					}


					ChkFlag = fFwdStructMapper(pIntReqHeader,&pOff_Ord,sTempClOrdId,i);

					if(ChkFlag == FALSE)
					{
						logDebug3("fCoFwdStructMapper returned Error");
						fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
						break;
					}
					else
					{
						logDebug1("Fetch Loc Code for ID :%s:",pOff_Ord.sEntityId);
					}
					
					   if((pIntReqHeader->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL) || (pIntReqHeader->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_MODIFY))
					   {
					   logDebug2("**********************************");
					   ChkFlag = FALSE;
					   logDebug3("pIntReqHeader->ReqHeader.iMsgCode :%d:",pIntReqHeader->ReqHeader.iMsgCode);
					   logDebug3("pIntReqHeader->ReqHeader.cSegment :%c:",pIntReqHeader->ReqHeader.cSegment);
					   if(pIntReqHeader->ReqHeader.cSegment == EQUITY_SEGMENT)
					   {
					   ChkFlag = fFetchEQSerialNo(&pOff_Ord);
					   }
					   else if((pIntReqHeader->ReqHeader.cSegment == DERIVATIVE_SEGMENT )|| (pIntReqHeader->ReqHeader.cSegment == CURRENCY_SEGMENT))
					   {
					   ChkFlag = fFetchDRVSerialNo(&pOff_Ord);
					   }
					   else if(pIntReqHeader->ReqHeader.cSegment == COMMODITY_SEGMENT)
					   {
					   ChkFlag = fFetchMCXSerialNo(&pOff_Ord);
					   }
					   if(ChkFlag == FALSE)
					   {
					   logDebug2("Order Status Changed. Try Again");

					   fSendErrorToFE(pIntReqHeader, RET_STAT_CHANGE);
					   continue;
					   }
					   if(ChkFlag == ERROR){
					   logDebug2("DB Error.");

					   fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);

					   continue;
					   }
					   if(ChkFlag == NO_MODIFICATION){
					   logDebug2("Nothing Modified.");

					   fSendErrorToFE(pIntReqHeader, INOTHING_TO_MODIFY);
					   continue;
					   }
					   if(ChkFlag == ORDER_REJECTED ){
					   logDebug2("Order is Rejected previously");

					   fSendErrorToFE(pIntReqHeader, RET_CANCEL_STAT);
					   continue;
					   }
					   if(ChkFlag == RET_TRANSIT_STAT)
					   {
					   logDebug2("Order Not Confirmed yet.");
					   fSendErrorToFE(pIntReqHeader, RET_TRANSIT_STAT);
					   continue;
					   }

					   logDebug2("*******************************");
					   }
					   
					ChkFlag = FALSE;

					if(pIntReqHeader->ReqHeader.cSegment == EQUITY_SEGMENT)
					{
						ChkFlag = fGetSecDetails(&pOff_Ord);
					}
					else if((pIntReqHeader->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || (pIntReqHeader->ReqHeader.cSegment ==CURRENCY_SEGMENT ))
					{
						ChkFlag = fGetDrvSecDetails(&pOff_Ord);
					}
					else if(pIntReqHeader->ReqHeader.cSegment == COMMODITY_SEGMENT)
					{
						ChkFlag = fGetMcxSecDetails(&pOff_Ord);
					}
					else
					{	
						logDebug2("pIntReqHeader->ReqHeader.cSegment :%c:",pIntReqHeader->ReqHeader.cSegment);
						continue;
					}

					if(ChkFlag == FALSE)
					{
						logDebug2("Error in GetSecDetails");
						fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
						break;
					}

					ChkFlag = fCheckLtpPrice(&pOff_Ord);
					if(ChkFlag == FALSE && pIntReqHeader->ReqHeader.iMsgCode != TC_INT_GTT_ORDER_CANCEL)
					{
						fSendErrorToFE(pIntReqHeader, ILTP_NOT_IN_REDIS);
						continue;
					}
					else
					{
						logDebug2("pOff_Ord->fLtp = |%lf|",pOff_Ord.fLtp);
						logDebug2("pOff_Ord->cGTCFlag = |%c|",pOff_Ord.cGTCFlag);
					}
					
					if ((iRetVal =  fOffline_Order_DBUpdate (&pOff_Ord,&BasicError)) == TRUE )
					{
						logDebug2("fOffline_Order_DBUpdate returned Sucess");
					}
					else
					{
						logFatal("fOffline_Order_DBUpdate FAILED -> Reason : [%s].",BasicError);
						fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
						mysql_rollback(DB_Con);
						break;
					}
					fSendSucessRespToFE(&pOff_Ord,iOrdSrvToTrdRtr);

				}


				break;

			default :
				logDebug2("Received Wrong Msgcode");
				fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
				continue;
		}

	} /*---END OF FOR LOOP---*/
	logTimestamp("Exit : [OfflineOrderProcess]");
	return TRUE;
}

BOOL fSendSucessRespToFE(struct INT_ORDERS  *pOEReq,LONG32 sndQ)
{
	logTimestamp("Entry : [pSendSucessRespToFE]");

	struct  FOREVER_ORDER_RESPONSE     pOEResp;	
	memset(&pOEResp,'\0',sizeof(struct FOREVER_ORDER_RESPONSE));
	pOEResp.IntRespHeader.iSeqNo = pOEReq->ReqHeader.iSeqNo;
	pOEResp.IntRespHeader.iMsgLength = sizeof(struct  FOREVER_ORDER_RESPONSE);
	pOEResp.IntRespHeader.iErrorId = 0;
	pOEResp.IntRespHeader.iUserId = pOEReq->ReqHeader.iUserId;
	pOEResp.iLegValue      = pOEReq->iLegValue;
	pOEResp.cUserType = pOEReq->cUserType;
	pOEResp.IntRespHeader.cSource = pOEReq->ReqHeader.cSource;
	pOEResp.IntRespHeader.cSegment = pOEReq->ReqHeader.cSegment;

	strncpy(pOEResp.IntRespHeader.sExcgId,pOEReq->ReqHeader.sExcgId,EXCHANGE_LEN);

	if(pOEReq->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_ENTRY)
	{
		pOEResp.IntRespHeader.iMsgCode = TC_INT_GTT_ORDER_ENTRY_RSP;

	}
	else if(pOEReq->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_MODIFY)
	{
		pOEResp.IntRespHeader.iMsgCode=TC_INT_GTT_ORDER_MODIFY_RSP;
	}
	else if(pOEReq->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
	{
		pOEResp.IntRespHeader.iMsgCode=TC_INT_GTT_ORDER_CANCEL_RSP;
	}
	logDebug2("pOEResp.IntRespHeader.iMsgCode = %d",pOEResp.IntRespHeader.iMsgCode);
	pOEResp.cBuyOrSell = pOEReq->cBuySellInd ;
	pOEResp.iOrderType = pOEReq->iOrderType;
	strncpy(pOEResp.sSecurityId,pOEReq->sSecId,SECURITY_ID_LEN);
	strncpy(pOEResp.sEntityId,pOEReq->sEntityId,ENTITY_ID_LEN);
	strncpy(pOEResp.sClientId,pOEReq->sClientId,CLIENT_ID_LEN);
	pOEResp.fOrderNum = pOEReq->fOrdNo ;
	pOEResp.iSerialNum = pOEReq->iSerialNo;

	pOEResp.iDiscQty = pOEReq->iDiscQty;
	pOEResp.iDiscQtyRem = pOEReq->iDiscRemQty;
	pOEResp.iTotalQtyRem = pOEReq->iTotalQty;
	pOEResp.iTotalQty= pOEReq->iTotalQty;
	pOEResp.iTotalTradedQty= pOEReq->iTotalTradedQty;
	pOEResp.iMinFillQty= pOEReq->iMinFillQty;


	pOEResp.fPrice = pOEReq->fOrderPrice;
	pOEResp.fTriggerPrice = pOEReq->fTriggerPrice;
	logDebug2("pOEReq->iValidity :%d:",pOEReq->iValidity);
	pOEResp.iOrderValidity = pOEReq->iValidity;
	logDebug2("pOEResp.iOrderValidity :%d:",pOEResp.iOrderValidity);
	/*in case of Gtd and gtc goodtilldate send to FE*/	
	if(pOEResp.iOrderValidity == VALIDITY_GTD || pOEResp.iOrderValidity == VALIDITY_GTC)
	{
		logDebug2("pOEReq->sGoodTillDaysDate :%s:",pOEReq->sGoodTillDaysDate);
		strncpy(pOEResp.sGoodTillDaysDate,pOEReq->sGoodTillDaysDate,DB_DATETIME_LEN);	
		logDebug2("pOEResp.sGoodTillDaysDate:%s:",pOEResp.sGoodTillDaysDate);

	}

	pOEResp.cProductId= pOEReq->cProductId;
	pOEResp.cProCli = pOEReq->cProClient;
	pOEResp.iMktType = pOEReq->iMktType;

	strncpy(pOEResp.sPanID,pOEReq->sPanNo,INT_PAN_LEN);
	logDebug2("pOEReq->sSettlor :%s:",pOEReq->sSettlor);
	strncpy(pOEResp.sSettlor,pOEReq->sSettlor,SETTLOR_LEN);
	logDebug2("pOEResp.sSettlor :%s:",pOEResp.sSettlor);
	pOEResp.cMarkProFlag=          pOEReq->cMarkProFlag;
	pOEResp.fMarkProVal=           pOEReq->fMarkProVal;
	pOEResp.cParticipantType=      pOEReq->cParticipantType;
	pOEResp.cGTCFlag=              pOEReq->cGTCFlag;
	pOEResp.cEncashFlag=           pOEReq->cEncashFlag;
	pOEResp.cGttType =           cGttType;

	logDebug2("----------Printing fSendRespToFE ------------");
	logDebug2("pOEResp.iLegValue   :%d:",pOEResp.iLegValue);
	logDebug2("pOEResp.iMsgLength :%d:",pOEResp.IntRespHeader.iMsgLength);
	logDebug2("pOEResp.iMsgCode    :%d: Ord_Req->ReqHeader.iMsgCode :%d:",pOEResp.IntRespHeader.iMsgCode,pOEReq->ReqHeader.iMsgCode);
	logDebug2("pOEResp.iUserId     :%llu:",pOEResp.IntRespHeader.iUserId);
	logDebug2("pOEResp.cSource     :%c:",pOEResp.IntRespHeader.cSource);
	logDebug2("pOEResp.cSegment    :%c:",pOEResp.IntRespHeader.cSegment);
	logDebug2("pOEResp.sSecurityId :%s:",pOEResp.sSecurityId);
	logDebug2("pOEResp.sClientId   :%s:",pOEResp.sClientId);
	logDebug2("pOEResp.cProductId  :%c:",pOEResp.cProductId);
	logDebug2("pOEResp.cBuyOrSell  :%c:",pOEResp.cBuyOrSell);
	logDebug2("pOEResp.iOrderType  :%d:",pOEResp.iOrderType);
	logDebug2("pOEResp.fOrderNum   :%.2f:",pOEResp.fOrderNum);
	logDebug2("pOEResp.iSerialNum  :%d:",pOEResp.iSerialNum);
	logDebug2("pOEResp.cUserType   :%c:",pOEResp.cUserType);
	logDebug2("pOEResp.cGttType    :%c:",pOEResp.cGttType);

	pOEResp.fOrdTriggerPrice = pOEReq->fOrdTriggerPrice;
        logDebug2("pOEReq->fOrdTriggerPrice :%f:",pOEReq->fOrdTriggerPrice);
		

	if((WriteMsgQ(sndQ,(CHAR *)&pOEResp ,sizeof(struct FOREVER_ORDER_RESPONSE), 1)) != 1)
	{
		logFatal("Error Rms error sent failed ... ");
		exit(ERROR); 
	}

	logTimestamp("Exit : [fSendSucessRespToFE]");
}


BOOL  fOffline_Order_DBUpdate(struct INT_ORDERS * p_Req_in, char * p_Req_out)
{
	logTimestamp("Entry : [fOffline_Order_DBUpdate]");

	logDebug2("p_Req_in->ReqHeader.cSegment :%c:",p_Req_in->ReqHeader.cSegment);

	if(p_Req_in->ReqHeader.cSegment == SEGMENT_EQUITY)
	{
		if(NSEEQInsert(p_Req_in) == FALSE)
		{
			logDebug2("Error in Insert ORDERS.");
			return FALSE;                
		}
	}	
	else if(p_Req_in->ReqHeader.cSegment == SEGMENT_FNO || p_Req_in->ReqHeader.cSegment == SEGMENT_CURRENCY)
	{
		if(NSEDRVInsert(p_Req_in) == FALSE)
		{
			logDebug2("Error in Insert ORDERS.");
			return FALSE;
		}
	}
	else if(p_Req_in->ReqHeader.cSegment == COMMODITY_SEGMENT)
	{
		if(MCXInsert(p_Req_in) == FALSE)
		{
			logDebug2("Error in Insert ORDERS.");
			return FALSE;
		}
	}

	else
	{
		logFatal("Invalid Segment so returning false");
		return FALSE;
	}

	logTimestamp("Exit : [fOffline_Order_DBUpdate]");
	return TRUE;
}


BOOL fFwdStructMapper(struct FOREVER_ORDER_REQUEST *Ord_Req,struct INT_ORDERS *Ins_Req,CHAR *sTempClOrdId,LONG32 i )
{
	logTimestamp("Entry : [fFwdStructMapper]");	

	CHAR sClOrdId   [CLORDID_LEN];
	CHAR sGoodTillDatetime[DB_DATETIME_LEN];
	CHAR sPan[INT_PAN_LEN];
        CHAR sAccCode[DB_CLIENT_ID_LEN];
	LONG32  iFlag;
	memset ( sPan,      '\0' ,INT_PAN_LEN);
        memset ( sAccCode,      '\0' ,DB_CLIENT_ID_LEN);
	memset ( sClOrdId,      '\0' ,CLORDID_LEN);
	memset ( sGoodTillDatetime,      '\0' ,DB_DATETIME_LEN);

        CHAR sPlatform [PLATFORM_LEN];
        CHAR sChannel  [CHANNEL_LEN];
        memset ( sPlatform,      '\0' ,PLATFORM_LEN);
        memset ( sChannel,      '\0' ,CHANNEL_LEN);

	Ins_Req->ReqHeader.iSeqNo = Ord_Req->ReqHeader.iSeqNo;
	Ins_Req->ReqHeader.iMsgLength = Ord_Req->ReqHeader.iMsgLength;
	Ins_Req->ReqHeader.iMsgCode = Ord_Req->ReqHeader.iMsgCode;
	logDebug2("Ins_Req->ReqHeader.iMsgCode = %d",Ins_Req->ReqHeader.iMsgCode);
	strncpy(Ins_Req->ReqHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
	Ins_Req->ReqHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	Ins_Req->ReqHeader.cSource = Ord_Req->ReqHeader.cSource;
	Ins_Req->ReqHeader.cSegment = Ord_Req->ReqHeader.cSegment;
	Ord_Req->cOffMarketFlg = OFF_ORD_ENABLE ;


	if(Ord_Req->ReqHeader.iMsgCode ==  TC_INT_GTT_ORDER_MODIFY || Ord_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
	{
		Ins_Req->fOrdNo = Ord_Req->fOrderNum;
	}
	else
	{
		logDebug2("Ins_Req->fOrdNo = :%lf:",Ins_Req->fOrdNo);
	}
	logDebug3("Ord_Req->CoArray[%d].iLegValue:%d:",i,Ord_Req->CoArray[i].iLegValue);
	Ins_Req->iLegValue  	= Ord_Req->CoArray[i].iLegValue ;	
	Ins_Req->iSerialNo 	= Ord_Req->iSerialNum;
	strncpy(Ins_Req->sSecId,Ord_Req->sSecurityId,DB_SECURITY_ID_LEN);
	strncpy(Ins_Req->sEntityId,Ord_Req->sEntityId,DB_ENTITY_ID_LEN);
	logDebug2("Ins_Req->sEntityId :%s:",Ins_Req->sEntityId);
	strncpy(Ins_Req->sExchOrdNo,"0",DB_EXCH_ORD_NO_LEN);
	strncpy(Ins_Req->sClientId,Ord_Req->sClientId,DB_CLIENT_ID_LEN);
	logDebug2("Ins_Req->sClientId:%s:",Ins_Req->sClientId);
	Ins_Req->cBuySellInd 	= Ord_Req->cBuySellInd;
	if(Ord_Req->ReqHeader.iMsgCode == TC_INT_GTT_ORDER_CANCEL)
	{
		Ins_Req->cOrdStatus     = EXCH_DELETE_STATUS ;	
	}
	else
	{
		Ins_Req->cOrdStatus 	= EXCH_CONFIRM_STATUS;
	}
	logDebug2("Ins_Req->cOrdStatus :%c:",Ins_Req->cOrdStatus);
	strncpy(Ins_Req->sEntryDate,"now()",DB_DATETIME_LEN);
	strncpy(Ins_Req->sOrderTime,"\0",DB_DATETIME_LEN);
	logDebug3("Ord_Req->CoArray[%d].iTotalQty:%d:",i,Ord_Req->CoArray[i].iTotalQty);
	Ins_Req->iTotalQty 	= Ord_Req->CoArray[i].iTotalQty;
	logDebug3("Ord_Req->CoArray[%d].iTotalQty:%d:,",i,Ord_Req->CoArray[i].iTotalQty);
	logDebug2("Ord_Req->iTotalQty :%d:",Ord_Req->CoArray[i].iTotalQty);
	logDebug2("Ins_Req->iTotalQty :%d:",Ins_Req->iTotalQty );
	logDebug3("Ord_Req->CoArray[%d].iTotalQtyRem:%d:,",i,Ord_Req->CoArray[i].iTotalQtyRem);
	Ins_Req->iRemQty 	= Ord_Req->CoArray[i].iTotalQtyRem;
	Ins_Req->iDiscQty 	= Ord_Req->iDiscQty;
	Ins_Req->iDiscRemQty 	= Ord_Req->iDiscQtyRem;
	Ins_Req->iTotalTradedQty = Ord_Req->iTotalTradedQty;
	logDebug3("Ord_Req->CoArray[%d].fPrice:%f:,",i,Ord_Req->CoArray[i].fPrice);
	Ins_Req->fOrderPrice 	= Ord_Req->CoArray[i].fPrice;
	logDebug3("Ord_Req->CoArray[%d].fTriggerPriced:%f:,",i,Ord_Req->CoArray[i].fTriggerPrice);
	Ins_Req->fTriggerPrice 	= Ord_Req->CoArray[i].fTriggerPrice;
	Ins_Req->iValidity 	= Ord_Req->iOrderValidity;
	Ins_Req->iOrderType 	= Ord_Req->iOrderType;
	Ins_Req->iGoodTillDaysFlg = 0;
	//strncpy(Ins_Req->sGoodTillDaysDate,"2015-05-13 21:01:57",DB_DATETIME_LEN);
	/**
	 *	Handling Good till date for case if client places an Offline order after 3:30 or before EOD BOD then that particular order should not get deleted in EOD BOD process of that segment @nitish
	 *
	 * **/	
	/*	if(Ins_Req->iValidity == VALIDITY_GTD)
		{
		sprintf(Ins_Req->sGoodTillDaysDate,"%s",Ord_Req->sGoodTillDaysDate);
		}
		else
		{
		fFetchNextSchDate(Ord_Req,&sGoodTillDatetime);	
		strncpy(Ins_Req->sGoodTillDaysDate,sGoodTillDatetime,DB_DATETIME_LEN);
		}*/
//	strncpy(Ins_Req->sAccCode,Ord_Req->sClientId,DB_CLIENT_ID_LEN);
	Ins_Req->iMinFillQty 	= Ord_Req->iMinFillQty;
	Ins_Req->cProClient 	= Ord_Req->cProCli;
	strncpy(Ins_Req->sRemarks,";                        ",OE_REMARKS_LEN);
	Ins_Req->cUserType 	= Ord_Req->cUserType;
	Ins_Req->cOrderOffOn 	= Ord_Req->cOffMarketFlg;
	Ins_Req->cProductId 	= Ord_Req->cProductId;
	strncpy(Ins_Req->sUserInfo,"\0",DB_USER_INFO_LEN);
	Ins_Req->iGrpId 	= Ord_Req->iGrpId;
	logDebug2("Ins_Req->iGrpId %d",Ins_Req->iGrpId);
	Ins_Req->iReasonCode 	= 0;
	strncpy(Ins_Req->sReasonDesc,"\0",DB_REASON_DESC_LEN);
	Ins_Req->iExchTrdNo 	= -1;
	Ins_Req->iTrdSerialNo 	= 0;
	Ins_Req->iTrdTransCode 	= 0;
	Ins_Req->cTrdStatus 	= EXCH_CONFIRM_STATUS;
	Ins_Req->iLstTrdQty 	= 0;
	Ins_Req->fTrdPrice 	= 0;
	strncpy(Ins_Req->sTrdTime,"2015-05-13 21:01:57",DB_DATETIME_LEN);
	Ins_Req->iTrdSeqNo 	= 0;
	Ins_Req->cHandleInst 	= Ord_Req->cHandleInst;
	Ins_Req->fAlgoOrderNo 	= Ord_Req->fAlgoOrderNo;
	Ins_Req->iStratergyId 	= Ord_Req->iStratergyId;
	if(Ord_Req->cUserType == CLIENT_TYPE || Ord_Req->cUserType == SUPER_ADMIN || Ord_Req->cUserType == ADMIN_TYPE)
	{
		if(Ord_Req->ReqHeader.cSource == SOURCE_MOBILE)
		{
			strncpy(Ins_Req->sLocCode,USER_INFO_MOBILE,TERMINAL_INFO_LEN);
			logDebug2("Ins_Req->sLocCode.. = %s",Ins_Req->sLocCode);
		}
		else
		{
			strncpy(Ins_Req->sLocCode,USER_INFO_ONLINE,TERMINAL_INFO_LEN);
			logDebug2("Ins_Req->sLocCode = %s",Ins_Req->sLocCode);
		}
	}

	strncpy(Ins_Req->sClOrdId,sTempClOrdId,CLORDID_LEN);
	strncpy(Ins_Req->sOrigClOrdId,"\0",CLORDID_LEN);
	Ins_Req->iMktType = Ord_Req->iMktType;

	logDebug2("sSettlor :%s:",sSettlor);

	/*	if(Ord_Req->cParticipantType == 'B')
		{
		strncpy(Ins_Req->sSettlor, sSettlor,SETTLOR_LEN);
		}
		else
		{
		strncpy(Ins_Req->sSettlor, Ord_Req->sSettlor,SETTLOR_LEN);
		}
		*/
	/*	if(!strcmp(Ord_Req->sSettlor,""))
		{
		strncpy(Ins_Req->sSettlor, sSettler,SETTLOR_LEN);
		}
		else
		{
		strncpy(Ins_Req->sSettlor, Ord_Req->sSettlor,SETTLOR_LEN);
		}
		*/
	strncpy(sDefSettler," ",SETTLOR_LEN);
	if(strcmp(Ord_Req->ReqHeader.sExcgId,"NSE") == 0)
	{
		strncpy(Ins_Req->sSettlor, sNseSettler,SETTLOR_LEN);
	}
	else if(strcmp(Ord_Req->ReqHeader.sExcgId,"BSE") == 0)
	{
		strncpy(Ins_Req->sSettlor, sBseSettler,SETTLOR_LEN);
	}
	else if(strcmp(Ord_Req->ReqHeader.sExcgId,"MCX") == 0)
	{
		strncpy(Ins_Req->sSettlor, sMcxSettler,SETTLOR_LEN);
	}
	else
	{
		strncpy(Ins_Req->sSettlor, sDefSettler,SETTLOR_LEN);
	}

	logDebug2("sSettlor :%s:",Ins_Req->sSettlor);	

//	strncpy(Ins_Req->sPanNo,Ord_Req->sPanID,INT_PAN_LEN);
	iFlag = fFetchData(Ord_Req,&sPan,&sAccCode); ///Is Use to fetch the pan and account code of client.
        if(iFlag == INVALID_CLIENT_ID)
        {
                return INVALID_CLIENT_ID;
        }
        strncpy(Ins_Req->sAccCode,sAccCode,DB_CLIENT_ID_LEN);
        strncpy(Ins_Req->sPanNo,sPan,INT_PAN_LEN);

	Ins_Req->iAlgoID        = 0;
	Ins_Req->iAlgoCat       = 0;
	Ins_Req->cCrossCurFlag= NO;

	Ins_Req->fRBIRefRate= 1.00;

	Ins_Req->cMarkProFlag=          Ord_Req->cMarkProFlag;
	Ins_Req->fMarkProVal=           Ord_Req->fMarkProVal;
	Ins_Req->cParticipantType=      Ord_Req->cParticipantType;
	Ins_Req->cGTCFlag=              Ord_Req->cGTCFlag;
	Ins_Req->cEncashFlag=           Ord_Req->cEncashFlag;
	cGttType =           Ord_Req->cGttType;
	logDebug3("cGttType :%c:",cGttType);
        strncpy(Ins_Req->sPlatform,Ord_Req->sPlatform,PLATFORM_LEN);
        strncpy(Ins_Req->sChannel,Ord_Req->sChannel,CHANNEL_LEN);
        logDebug2("Ins_Req->sPlatform... = %s",Ins_Req->sPlatform);
        logDebug2("Ins_Req->sChannel... = %s",Ins_Req->sChannel);

	logDebug3("Ord_Req->CoArray[%d].fOrdTriggerPriced:%f:,",i,Ord_Req->CoArray[i].fOrdTriggerPrice);
        Ins_Req->fOrdTriggerPrice  = Ord_Req->CoArray[i].fOrdTriggerPrice;
	logDebug2("Ins_Req->fOrdTriggerPrice... = %f",Ins_Req->fOrdTriggerPrice);

	logTimestamp(" EXIT : [fFwdStructMapper]");
	return TRUE;
}


BOOL    fGenGTTClOrdId(CHAR *sClOrdId)
{
	logTimestamp("fGenGTTClOrdId [Entry]");
	CHAR    sTempClOrdId[CLORDID_LEN];

	fClOrdID =fopen(sFileName,"rb+");
	LONG64 iTempSeq;

	if(fClOrdID == NULL)
	{
		logFatal("Not Able to Open File");
		logDebug2("Assigning Temporary value 0 to sTempClOrdId");
		sprintf(sTempClOrdId,"%d",0);
		return FALSE ;
	}
	else
	{
		while(!feof(fClOrdID))
		{
			memset(sTempClOrdId, '\0', CLORDID_LEN); // clean buffer
			fscanf(fClOrdID, "%[^\n]\n",sTempClOrdId);
		}
		logDebug2("Last Line :: %s",sTempClOrdId);
	}

	iTempSeq = atoi(sTempClOrdId);
	iTempSeq++;

	fprintf(fClOrdID,"\n%i",iTempSeq);
	sprintf(sClOrdId,"%s",sTempClOrdId);
	fclose(fClOrdID);


	logTimestamp("fGenGTTClOrdId [Exit]");
}

BOOL    fSendErrorToFE(struct FOREVER_ORDER_REQUEST *Ord_Req, LONG32 iErrorId,LONG32 iQty,DOUBLE64 fPrice)
{

	logTimestamp ("fSendErrorToFE [ENTRY]");
	struct INT_ERROR_FE_RESP pErrorResponce;

	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( &sErrString,     '\0' ,DB_REASON_DESC_LEN);

	memset(&pErrorResponce,'\0',sizeof(struct INT_ERROR_FE_RESP));

	logDebug2("pOE_Req->ReqHeader.cSource  :%c:",Ord_Req->ReqHeader.cSource);
	logDebug2("Ord_Req->ReqHeader.sExcgId   :%s:",Ord_Req->ReqHeader.sExcgId);
	logDebug2("Ord_Req->sSecurityId         :%s:",Ord_Req->sSecurityId);
	logDebug2("Ord_Req->sClientId           :%s:",Ord_Req->sClientId);
	logDebug2("Ord_Req->ReqHeader.iUserId   :%llu:",Ord_Req->ReqHeader.iUserId);

	pErrorResponce.IntRespHeader.iSeqNo     = Ord_Req->ReqHeader.iSeqNo;
	pErrorResponce.IntRespHeader.iMsgLength         = sizeof(struct INT_ERROR_FE_RESP);
	pErrorResponce.IntRespHeader.iErrorId           = iErrorId;
	pErrorResponce.IntRespHeader.iMsgCode           = TC_INT_ORDER_REJECTION;
	pErrorResponce.IntRespHeader.cSource            = Ord_Req->ReqHeader.cSource;
	pErrorResponce.IntRespHeader.cSegment           = Ord_Req->ReqHeader.cSegment;
	strncpy(pErrorResponce.IntRespHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
	strncpy(pErrorResponce.sSecurityId,Ord_Req->sSecurityId ,SECURITY_ID_LEN);
	strncpy(pErrorResponce.sClientId,Ord_Req->sClientId,CLIENT_ID_LEN);

	pErrorResponce.cBuyOrSell       =       Ord_Req->cBuySellInd;
	pErrorResponce.cProductId       =       Ord_Req->cProductId;
	pErrorResponce.iTotalQty        =       iQty;
	pErrorResponce.fPrice           =       fPrice;
	pErrorResponce.IntRespHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	logDebug2("pErrorResponce.IntRespHeader.iMsgLength :%d:",pErrorResponce.IntRespHeader.iMsgLength);

	if(fFetchOMSErrStr(iErrorId, &sErrString) == TRUE )
	{
		strncpy(pErrorResponce.sErrorMsg,sErrString,DB_REASON_DESC_LEN);
		logDebug2("Error Message :%s:",pErrorResponce.sErrorMsg);
		sprintf(pErrorResponce.sErrorCode,"%d",iErrorId);
		logDebug2("Error Message :%s:",pErrorResponce.sErrorMsg);
	}
	else
	{
		strncpy(sErrString,"Error Occured Please Contact System Administrator",DB_REASON_DESC_LEN);
		sprintf(pErrorResponce.sErrorCode,"%d",iErrorId);
		logDebug2("Error Message :%s:",pErrorResponce.sErrorMsg);
	}


	/*        if(iErrorId ==     ITRANSACTION_FAILED)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Transaction Fails",ERROR_MSG_LEN);
		  }
		  else  if(iErrorId ==     INOT_CONNECTED_TO_EXCH)
		  {
		  sprintf(pErrorResponce.sErrorMsg,"System is not connected to %s Equity market",pErrorResponce.IntRespHeader.sExcgId);
		  }
		  else if(iErrorId ==     RET_STAT_CHANGE)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order Status Changed. Try Again",ERROR_MSG_LEN);
		  }
		  else  if(iErrorId ==     RET_TRADED_STAT)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order Has Traded.Please refresh your OrderBook",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  RET_TRANSIT_STAT )
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order Still in Transit.Kindly refresh your OrderBook",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  RET_REJECT_STAT)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order is Rejected.Kindly refresh your OrderBook",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  RET_CANCEL_STAT)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order is Cancelled.Kindly refresh your OrderBook",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  RET_FREEZE_STAT)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order has been Freezed.Kindly refresh your OrderBook",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  RET_EXPIRED_STAT)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Order has been Expired.Kindly refresh your OrderBook",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  IBASIC_VALIDATION_FAILED)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Basic Validation Fails",ERROR_MSG_LEN);
		  }
		  else if(iErrorId ==  INOTHING_TO_MODIFY)
		  {
		  strncpy(pErrorResponce.sErrorMsg,"Nothing to Modify",ERROR_MSG_LEN);
		  }
	//error msg for offline order.06May2019 -Abhishek
	else if(iErrorId == OFFLINE_ORDER_FAILED)
	{
	strncpy(pErrorResponce.sErrorMsg,"Offline market is blocked at global level",ERROR_MSG_LEN);
	}
	else if(iErrorId == OFFLINE_ORDER_ERROR)
	{
	strncpy(pErrorResponce.sErrorMsg,"Market is open .Offline orders are not allowed",ERROR_MSG_LEN);
	}
	else if(iErrorId == OFFLINE_CLIENT_ORDER)
	{
	strncpy(pErrorResponce.sErrorMsg,"Offline Client can't Place an Order",ERROR_MSG_LEN);
	}
	else if(iErrorId == DISABLE_CLIENT)
	{
	strncpy(pErrorResponce.sErrorMsg,"Transactions are not allowed for the disable client",ERROR_MSG_LEN);
	}
	else
	{
	strncpy(pErrorResponce.sErrorMsg,"Error Occured Please Contact System Administrator",ERROR_MSG_LEN);
	}*/
	logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);
	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in fSendErrorToFE.");
		exit(ERROR);
	}

	logTimestamp ("fSendErrorToFE [EXIT]");
}

/*
   BOOL fChkClientOffline(struct  ORDER_REQUEST  *pReq)
   {
   logTimestamp("ENTRY : [fChkClientOffline]");
   CHAR    sSelQry [MAX_QUERY_SIZE];
   memset(sSelQry,'\0',MAX_QUERY_SIZE);
   CHAR cClientStat='N';


   logDebug3("sEntityId    :%s:",pReq->sEntityId);
   logDebug3("sClientId    :%s:",pReq->sClientId);	

   sprintf(sSelQry,"SELECT ENTITY_OFFLINE_FLAG FROM ENTITY_MASTER WHERE ENTITY_CODE = \"%s\";",pReq->sClientId);

   logDebug2("sSelQry = %s",sSelQry);

   if (mysql_query(DB_Con, sSelQry) != SUCCESS)
   {
   logSqlFatal("Error in select Qry1");
   sql_Error(DB_Con);
   return FALSE;
   }
   Res = mysql_store_result(DB_Con);

   if((Row = mysql_fetch_row(Res)))
   {
   logDebug2("Row fetched from ENTITY_MASTER");
   cClientStat = Row[0][0];
   logDebug2("cClientStat = %c",cClientStat);
   }
   else
   {
   logDebug2(" No row fetched from ENTITY_MASTER");
   return FALSE;

   }

   if(cClientStat == YES)
   {
   if((strncmp(pReq->sEntityId,pReq->sClientId,CLIENT_ID_LEN) == 0))
   {
   logDebug3("ENTITY ID AND CLIENT ID IS SAME");
   return FALSE;
   }
   else
   {
   return TRUE;
   }
   }
   else
   {
   return TRUE;
   }
   mysql_free_result(Res);
   logTimestamp("Exit : fChkClientOffline");

   }
   */

BOOL 	fCheckGTTOrders()
{
	logTimestamp("Entry :fCheckGTTOrders:");
	logDebug2("cGTTFlag :%c:",cGTTFlag);	

        logDebug2("GTTFLAG  :%s ",sGTTFlag);
	if(cGTTFlag == 'E')
	//if (strcmp(sGTTFlag, "E") == 0)
	{
		logDebug2("GTT Orders are Allowed to trade Since GTTFlag is ENABLE");
		return TRUE;
	}
	else 
	{
		logDebug2("GTT Orders are Not Allowed to Trade Since GTTFlag is DISABLE");
		return FALSE;
	}


	logTimestamp("Exit  :fCheckGTTOrders:");
	
}


void    LoadEnv()
{
        logTimestamp("Entry :      [LoadEnv]");
        if( getenv("GTTFLAG") == NULL)
        {
                cGTTFlag = 'E';
                //strcpy( sGTTFlag ,"E");
		logDebug3("value not defined in env for GTTFLAG");
        }
        else
        {
                //cGTTFlag = getenv("GTTFLAG");
               	strncpy(sGTTFlag,getenv("GTTFLAG"), ENV_VARIABLE_LEN);
                logDebug3("Value is selected from env for GTTFLAG");
		cGTTFlag = sGTTFlag[0];
        }

	
        logDebug2("GTTFLAG  is %s ",sGTTFlag);
        logDebug2("GTTFLAG  is %c ",cGTTFlag);
        logTimestamp("Exit :        [LoadEnv]");
}
