/*************************
 *
 * ClientDaemon
 *
 ************************/
#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"
//#include "FIXStructures.h"
//#include "ConnectStatus.h"
#define         MAX_PEEK_SIZE                 10+1

//void    GOMStoFIX(void *);
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
//BOOL SendBusinessRejectFor(CHAR *In);
void SocketToQueueThread ();
//void QueueToSocketThread ();

LONG32  iClientDaemonToMemMap = 0;

pthread_t   th_id1;
pthread_t   th_id2;

LONG32  iSocket;


int main(LONG32 argc, CHAR **argv)
{
	logTimestamp("ENTRY : [MAIN]");
	LONG32  size=512*1024;
	struct  sockaddr_in cli_addr;
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iMasterSocket,iRetval, iMaster_Port, iCount = 0;
	CHAR	sMasterAddress[30];

	sig1 = 0;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logDebug2(" PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;

	memset(&sMasterAddress, '\0', 30);
	strncpy(sMasterAddress,argv[2],30);

	logDebug2(" IP 		:%s:", sMasterAddress ) ;
	logDebug2(" PORT 	:%d:", iMaster_Port ) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);


	iClientDaemonToMemMap = OpenMsgQ(ClientDaemonToMemMap);
	if(iClientDaemonToMemMap < 0)
	{
		logFatal(" Error in Opening ClientDaemonToMemMap Queue");
		exit(ERROR);
	}
	logDebug2(" ClientDaemonToMemMap Queue Opened : %d", iClientDaemonToMemMap);


	memset(&cli_addr,0,sizeof(cli_addr));
	cli_addr.sin_family = AF_INET;
	cli_addr.sin_addr.s_addr = inet_addr(sMasterAddress);
	cli_addr.sin_port = htons(iMaster_Port); 
	
	if ((iSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{ 
		logFatal("Socket creation error "); 
		logDebug2(" Exiting");
		exit(ERROR); 
	} 
	logDebug2("iSocket %d:",iSocket);
	
	while(1)
	{
		logDebug2("============= Trying to connect ServerDaemon on port :%d: Count :%d: ===========", iMaster_Port, ++iCount);
		iRetval = sizeof(struct sockaddr);
		
		if (connect(iSocket, (struct sockaddr *)&cli_addr, sizeof(cli_addr)) < 0) 
		{ 
			logFatal("Connection Failed"); 
			sleep(2);
			continue; 
		} 

		logDebug2("New Socket Connection Established on :%d:", iSocket);


	/*	if((pthread_create(&th_id2,NULL,QueueToSocketThread,NULL)!= 0))
		{
			logDebug2("\n pthread_create:QueueToSocketThread");
			exit(ERROR);
		}
	*/
		if((pthread_create(&th_id1,NULL,SocketToQueueThread,NULL)!= 0))
		{
			logDebug2("pthread_create:SocketToQueueThread");
			exit(ERROR);
		}

		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while(TRUE)
		{
			mainwait = sigwait( &SequenceSet,&Signal);
			logDebug2("Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				logDebug2(" SIGTERM in Main");
				ConnectionDOWN();
				pthread_cancel(th_id1);
				//pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				//pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				logDebug2(" Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				logDebug2(" SIGUSR1 in Main");
				pthread_cancel(th_id1);
				//pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				//pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				//close(iSocket);
				logDebug2(" Exiting from loop");
				if ((iSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
				{ 
					logFatal("Socket creation error "); 
					logDebug2(" Exiting");
					exit(ERROR);
				} 
				logDebug2("iSocket %d:",iSocket);
				break;
			}
			else
			{
				logDebug2(" Received some other signal");
				logDebug2(" Closing Socket");
				close(iSocket);
				logDebug2(" Exiting");
				exit(ERROR);
			}

		}
		logDebug2(" Socket Connection closed on : %d", iSocket);
		logDebug2(" While Loop");
	}
	logTimestamp("EXIT : [MAIN]");
}

void SocketToQueueThread()
{	
	logTimestamp("ENTRY : [SocketToQueueThread]");
	LONG32  iRetval=-1,iLen,iMsgCode;
	CHAR    cMsgType, *tempPtr;
	LONG32	dcount = 0,i;
	LONG32  loopcount=0;
	CHAR    PeekBuf[ MAX_PEEK_SIZE+1 ] ;
	CHAR    RecvBuf[ RUPEE_MAX_PACKET_SIZE ] ;
	struct  INT_COMMON_REQUEST_HDR pReqHeader;
	struct  INT_COMMON_REQUEST_HDR *pRecvHeader;
	struct  ORDER_REQUEST          *pOE_Req;

	memset(&pReqHeader,'\0' ,sizeof(struct INT_COMMON_REQUEST_HDR));

	logDebug2(">>>>>>>>>>>>>%d",GROUPID);
	pReqHeader.iSeqNo = GROUPID;
	pReqHeader.iMsgCode = TC_INT_CLIENT_TO_SERVER_DAEMON;
	pReqHeader.iMsgLength = sizeof(struct INT_COMMON_REQUEST_HDR);

	iLen = sizeof(struct INT_COMMON_REQUEST_HDR);	
	if ((iRetval = Send(iSocket, (CHAR *)&pReqHeader, &iLen, 0)) == FALSE)
	{ 
		logDebug2(" ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
		RestartProcess();
	}                

	while(1)
	{
		memset(&RecvBuf, '\0', RUPEE_MAX_PACKET_SIZE);
		memset(&PeekBuf, '\0', MAX_PEEK_SIZE+1);
		memset(&pRecvHeader,'\0' ,sizeof(struct INT_COMMON_REQUEST_HDR));
		memset(&pOE_Req,'\0' ,sizeof(struct ORDER_REQUEST));

		iLen    =   MAX_PEEK_SIZE;
		logDebug1("================== Waiting to receive on socket %d ==============loopcount :%d iRetval:%d", iSocket,loopcount++,iRetval);

		if ((iRetval = Recv(iSocket, &PeekBuf, &iLen, MSG_PEEK)) == FALSE)
		{
			logDebug2(" Dropped Exchange Response while Peeking from Socket");
			logDebug2(" Error in receiving the Data from the Socket on PEEK");	
			logDebug2(" iRetval in peek %d:",iRetval);
			RestartProcess();
			break;
		}

		logDebug2("iRetval in peek :%d:",iRetval);
		pRecvHeader = (struct INT_COMMON_REQUEST_HDR *) &PeekBuf;

		iLen = pRecvHeader->iMsgLength;
		iMsgCode = pRecvHeader->iMsgCode ;
		logDebug2("Packet length to read :[%d]",iLen);
		logDebug2("MsgCode :[%d]",pRecvHeader->iMsgCode);
		logDebug2("GroupId :[%d]",pRecvHeader->iSeqNo);

		if ((iRetval = Recv(iSocket, &RecvBuf, &iLen, 0)) == -1)
		{
			logDebug2(" Dropped Exchange Response while Receiving on Socket");
			logDebug2(" Error in receiving the Data from the Socket");
			RestartProcess();
			break;
		}

		logDebug2(" Received from ServerDaemon");
		switch (iMsgCode)
		{
			case  TC_INT_ORDER_ENTRY_REQ    :
				pOE_Req = (struct ORDER_REQUEST *) &RecvBuf;
				pOE_Req->iGrpId = GROUPID;
				logDebug2("Setting GroupId :[%d]",pOE_Req->iGrpId);
				if ((iRetval=WriteMsgQ(iClientDaemonToMemMap, (CHAR *)pOE_Req, sizeof(struct ORDER_REQUEST), 1))== ERROR)
				{	
					logFatal(" Dropped Exchange Response while sending it to memmap");
					exit(ERROR);
				}
				break;
			default :
				if ((iRetval=WriteMsgQ(iClientDaemonToMemMap,&RecvBuf,iLen,1))== ERROR)
				{
					logFatal(" Dropped Exchange Response while sending it to memmap");
					exit(ERROR);
				}
				break;
		}
	}
	close(iSocket);
	logTimestamp("EXIT : [SocketToQueueThread]");
}

/*
   void QueueToSocketThread()
   {
   logTimestamp("ENTRY : [QueueToSocketThread]");
   LONG32  iRetval, iLen;
   CHAR    FixString[FIX_MAX_STRING_LEN];

   while(1)
   {
   logDebug2("\n ================== Waiting on the Queue =====================");
   memset(FixString, '\0', FIX_MAX_STRING_LEN);
   if ((iRetval=ReadMsgQ(iGOMSFwdToInterface, FixString, FIX_MAX_STRING_LEN, 1))== ERROR)
   {
   logFatal("\n ERROR in receiving the Data from the Q %d", iGOMSFwdToInterface);
   exit(ERROR);
   }
/******************************** 
if (( CheckExchStatus ( LOCAL ) == FALSE ) || isConnected == FALSE  )
{
printf("\n Not Connected to Exchange, so rejecting the packet");	
SendBusinessRejectFor(FixString);
continue ;
} ******************************************  ALOKK COMMENTED ******************** /
logDebug2("\n Data Received from Queue :%s", FixString);
/*** Please dont remove the \n from line. Multiple
string have to be saperated by \n ***** /
if( FixString[strlen(FixString)-1] != '\n')
strcat(FixString,"\n");

iLen = strlen(FixString);

if ((iRetval = Send(iSocket, FixString, &iLen, 0)) == FALSE)
{
logDebug2("\n ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
//SendBusinessRejectFor(FixString);
RestartProcess();
break;
}
logDebug2("\n Sent to Engine");
}
logTimestamp("EXIT : [QueueToSocketThread]");

}
*/
void RestartProcess()
{	
	logTimestamp("ENTRY : [RestartProcess]");
	//	ConnectionDOWN();
	logDebug2("\n Before killing");
	logDebug2("\nI'm here!!!  My pid is %d.", (int) getpid ());
	kill(getpid(), SIGUSR1);
	logDebug2("\n Sent Signal %d To pid %d", SIGUSR1, getpid());
	logTimestamp("EXIT : [RestartProcess]");
	return;
}


/******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Send                                       	     **
 **                                                                           **
 **   DESCRIPTION       : Send doesnt guarantee that all the data in the      **
 **			 buffer will be sent in a single call to send, loop  **
 **			 around checking the return value till all the bytes **
 **			 are sent.					     **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc to which data will be sent.   **
 **			 SendData- Data to be sent.			     **
 **			 SendLen - Len of the data to be sent.		     **
 **			 Flags   - If any.				     **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	logTimestamp("ENTRY : [Send]");
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{
		logDebug2("Total bytes sent :%d:", TotalLen); 
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		logDebug2("After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	logTimestamp("EXIT : [Send]");
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


/*******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Recv                                                **
 **                                                                           **
 **   DESCRIPTION       : recv doesnt guarantee that all the data in the      **
 **			              buffer will be received in a single call, loop     **
 **			              around checking the return value till all the bytes **
 **			              are received.                                       **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc from which data will be recvd.**
 **			              SendData- Data to be recvd.                         **
 **			              SendLen - Len of the data to be recvd.              **
 **			              Flags   - If any.                                   **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	logTimestamp("ENTRY : [Recv]");
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	logDebug2("Trying to Recv = %d", *RecvLen); 
	while(TotalLen < *RecvLen)
	{
		logDebug2("Trying to recv %d bytes", BytesLeft);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		logDebug2("After recv Bytes = %d", Bytes); 
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	logTimestamp("EXIT : [Recv]");
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

/*
   BOOL SendBusinessRejectFor(CHAR *FixString)
   {
   logTimestamp("ENTRY : [SendBusinessRejectFor]");
   CHAR        outString[RUPEE_MAX_PACKET_SIZE];
   LONG32		iRetVal = FALSE ;
   memset(outString,'\0',RUPEE_MAX_PACKET_SIZE);

   if ( (formRejectString( FixString,outString,2)) == FALSE)
   {
   logDebug2("\n\t No Rejection string created for [%s]",FixString);
   }
   else
   {
   logDebug2("\n Received the String :%s",outString);
   if ((iRetVal=WriteMsgQ(iGOMSInterfaceToRev,outString,strlen(outString)-1,1))== ERROR)
   {
   exit(ERROR);
   }
   }
   logTimestamp("EXIT : [SendBusinessRejectFor]");
   }
   */

void ConnectionUP()
{	
	logTimestamp("ENTRY : [ConnectionUP]");
	//	fUpdateConnectStatus(MCX_UP, 0, BCAST_YES, TRUE);
	logDebug2("\n UpdateConnectStatus UP");
	logTimestamp("ENTRY : [ConnectionUP]");
	return;
}


void ConnectionDOWN()
{
	logTimestamp("ENTRY : [ConnectionDOWN]");
	//	fUpdateConnectStatus(MCX_DOWN, 0, BCAST_YES, FALSE);
	logDebug2("\n UpdateConnectStatus DOWN");
	logTimestamp("ENTRY : [ConnectionDOWN]");
	return;
}

