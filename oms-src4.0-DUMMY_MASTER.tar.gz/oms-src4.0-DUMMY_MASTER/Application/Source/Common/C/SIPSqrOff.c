#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <errno.h>

MYSQL           *DB_Conn;
MYSQL_RES       *Res;
MYSQL_ROW        Row;

LONG32	iRDaemonToSIPSqrOff;
LONG32	iSIPSqrOffToOrdRtr;
CHAR    sAdmin [15];

main(INT16 argc, CHAR **argv)
{
	logTimestamp("Entry [Main]");

	struct  ORDER_REQUEST		*pOrdReq;
	struct  INT_COMMON_REQUEST_HDR 	*pIntHdr;

	CHAR    sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	LONG32  iCount = 0;
	LONG32	iMsgCode =0;
	CHAR    sQuery[MAX_QUERY_SIZE];

	memset(sQuery,'\0',MAX_QUERY_SIZE);
	memset (sAdmin ,'\0',15);

	DB_Conn = DB_Connect();
	logDebug2("Connect to the database.");

	setbuf(stdout, NULL);
	setbuf(stdin, NULL);

	OpenMsgQue();

	while(1)
	{
		memset(&sRcvMsg,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(&pOrdReq,'\0',sizeof(struct ORDER_REQUEST));

		logInfo("..........WHILE LOOP -> Count = %d................",iCount++);

		if(ReadMsgQ(iRDaemonToSIPSqrOff,&sRcvMsg,RUPEE_MAX_PACKET_SIZE,1) != 1)
		{
			logFatal("Error in Read MsgQ = %d",iRDaemonToSIPSqrOff);
			exit(ERROR);
		}
		logDebug2("Suceessfully Read MsgQ = %d",iRDaemonToSIPSqrOff);

		pOrdReq = (struct ORDER_REQUEST *)&sRcvMsg;
		iMsgCode = pOrdReq->ReqHeader.iMsgCode;

		logDebug2("iMsgCode = %d",iMsgCode);
		logDebug2("Segment = %c",pOrdReq->ReqHeader.cSegment);
		logDebug2("Exch = %s",pOrdReq->ReqHeader.sExcgId);

		sprintf(sQuery,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  = 'Default_admin'");
		logDebug2("Query = %s",sQuery);		

		if (mysql_query(DB_Conn, sQuery) != SUCCESS)
		{
			logSqlFatal("Error in select s.PARAM_VALUE");
			sql_Error(DB_Conn);
			exit(ERROR);
		}
		logDebug2("Query done Sucessfully.");

		Res = mysql_store_result(DB_Conn);
		iRow = (mysql_num_rows(Res));

		if(iRow == 0)
		{
			mysql_free_result(Res);
			logDebug2("Zero rows selected");
		}
		else
		{
			while (Row = mysql_fetch_row(Res))
			{
				strncpy(sAdmin,Row[0],15);
				logDebug2("sAdmin = %s",sAdmin);
			}
		}
		mysql_free_result(Res);

		if(iMsgCode == TC_INT_PUMPSIP_REQ)
		{
			pIntHdr = (struct  INT_COMMON_REQUEST_HDR *)&sRcvMsg;

			if(fPumpOffOrdSIP(pIntHdr) == FALSE)
			{
				logFatal("Error fPumpOffOrdSIP Equity");
				return FALSE;
			}
			logDebug3("Success : fPumpOffOrdSIP Equity");


		}


	}


}

BOOL	fPumpOffOrdSIP(struct  INT_COMMON_REQUEST_HDR  *pIntHeader)
{
	logTimestamp("Entry in fPumpOffOrdSIP");

	CHAR	*sQuery1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	struct  ORDER_REQUEST	pSIPOrdReq
		memset(&pSIPOrdReq , '\0',sizeof(struct ORDER_REQUEST));

	sprintf(sQuery1,"SELECT SIP_ORDER_NO,SIP_SERIAL_NO,SIP_SCRIP_CODE,SIP_SYMBOL,SIP_EXCH_ID,SIP_SEGMENT,SIP_CLIENT_ID,SIP_BUY_SELL_IND,\
			SIP_TOTAL_QTY,SIP_VALIDITY,SIP_ORDER_TYPE,SIP_USER_TYPE,SIP_PRO_CLIENT,SIP_REMARKS,SIP_SOURCE_FLG,SIP_HANDLE_INST,\
			SIP_MKT_TYPE,SIP_EXCH_SYMBOL FROM SIP_ORDERS\
			WHERE SIP_ORD_STATUS = \'C\' AND SIP_MSG_CODE IN (3000) AND SIP_EXCH_ID = \"%s\"\
			AND SIP_SERIAL_NO= (SELECT MAX(SIP_SERIAL_NO) FROM SIP_ORDERS WHERE SIP_ORDER_NO = SIP_ORDER_NO);",pIntHeader->sExcgId);

	logDebug2("sQuery1 = %s",sQuery1);

	if(mysql_query(DB_Conn,sQuery1)!= SUCCESS)
	{
		logSqlFatal("Error in fPumpOffOrdSIP Query.");
		sql_Error(DB_Conn);
		exit(ERROR);
	}
	logDebug2("Query done [fPumpOffOrdSIP]");
	Res = mysql_store_result(DB_Conn);

	while(Row = mysql_fetch_row(Res))
	{
		pSIPOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
		pSIPOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
		strncpy(pSIPOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
		logDebug2("pSIPOrdReq.ReqHeader.sExcgId = %s",pSIPOrdReq.ReqHeader.sExcgId);
		pSIPOrdReq.ReqHeader.cSegment = Row[5][0];
		logDebug2("pSIPOrdReq.ReqHeader.cSegment = %c",pSIPOrdReq.ReqHeader.cSegment);

		strncpy(pSIPOrdReq.sSecurityId,Row[2],SECURITY_ID_LEN);
		logDebug2("pSIPOrdReq.sSecurityId = %s",pSIPOrdReq.sSecurityId);
		strncpy(pSIPOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
		logDebug2("pSIPOrdReq.sEntityId = %s",pSIPOrdReq.sEntityId);
		strncpy(pSIPOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
		logDebug2("pSIPOrdReq.sClientId = %s",pSIPOrdReq.sClientId);

		pSIPOrdReq.cProductId = 'C';
		pSIPOrdReq.cBuyOrSell = Row[7][0];
		pSIPOrdReq.iOrderType = Row[10][0];
		pSIPOrdReq.iOrderValidity = Row[9][0]
		pSIPOrdReq.iDiscQty = 0;
		pSIPOrdReq.iDiscQtyRem = 0;
		pSIPOrdReq.iTotalQtyRem = 0;
		pSIPOrdReq.iTotalQty = Row[8][0];
		pSIPOrdReq.iTotalTradedQty = 0;
		pSIPOrdReq.iMinFillQty = 0;
		pSIPOrdReq.fPrice = 0;
		pSIPOrdReq.fTriggerPrice = 0;
		pSIPOrdReq.fOrderNum = atof(Row[0]);
		pSIPOrdReq.iSerialNum = Row[1][0];
		pSIPOrdReq.cHandleInst = Row[15][0];
		pSIPOrdReq.fAlgoOrderNo = 0;
		pSIPOrdReq.iStratergyId = 0; 
		pSIPOrdReq.cOffMarketFlg = 'O';
		pSIPOrdReq.cProCli = Row[12][0];
		pSIPOrdReq.cUserType = Row[11][0];
		pSIPOrdReq.sRemarks = Row[13][0];
		pSIPOrdReq.iMktType = Row[16][0];
		pSIPOrdReq.iAuctionNum = 0; 

		if(WriteMsgQ(iSIPSqrOffToOrdRtr,(CHAR *)pSIPOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
		{
			logFatal("Error in sent Msg");
			mysql_free_result(Res);
			mysql_close(DB_Conn);
			exit(ERROR);

		}		
		logDebug2("Send Msg Q Sucessfully.");	

	}
	logTimestamp("Exit.... fPumpOffOrdSIP");
	return TRUE;

}

OpenMsgQue();
{
	if( (iRDaemonToSIPSqrOff = OpenMsgQ(RDaemonToSIPSqrOff)) == TRUE )
	{
		logFatal("Error in OpenMsg ... RDaemonToSIPSqrOff");
		exit(ERROR);
	}
	if( (iSIPSqrOffToOrdRtr = OpenMsgQ(RelToOrdRtr)) == TRUE)
	{
		logFatal("Error in OpenMsg ... RelToOrdRtr");
		exit(ERROR);
	}

}

