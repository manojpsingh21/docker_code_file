#include "IPCS.h"
#include <stdlib.h>


BOOL GetMktType(CHAR *sMktType,LONG32 iMktType)
{

	switch(iMktType)
	{
		case NORMAL_MARKET:
			strncpy(sMktType,"NL",2);	
			break;
		case ODDLOT_MARKET:
			strncpy(sMktType,"OL",2);	
			break;
		case SPOT_MARKET:
			strncpy(sMktType,"SP",2);
			break;
		case AUCTION_MARKET:
			strncpy(sMktType,"AU",2);
			break;
		case CALL_AUCTION_MARKET1:
                        strncpy(sMktType,"A1",2);
                        break;
                case CALL_AUCTION_MARKET2:
                        strncpy(sMktType,"A2",2);
                        break;

		default :
			logInfo("Invalid Mkt Type  :%d:",iMktType);
			return FALSE;
			break;
	}
	logDebug2("Nishant_sMktType :%s:",sMktType);

	return TRUE;


}
