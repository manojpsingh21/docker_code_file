#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"


LONG32 iOrdRtrToOrdSrvNSEDR;

MYSQL *OdrConn;


main(int argc, char *argv[])
{
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;
	DOUBLE64 fPrice ;
	LONG32	i = 0;


	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);

	if ( argc != 2 )
	{
		logDebug2("Argument to be Entered  2.Price  ");
		exit (0);
	}

	OdrConn=DB_Connect();
	struct ORDER_REQUEST  pOrdReq;
	memset(&pOrdReq,'\0',sizeof(struct ORDER_REQUEST));


	if((iOrdRtrToOrdSrvNSEDR = OpenMsgQ(OrdRtrToCatalystDR)) == ERROR)
	{
		perror("OpenMsgQ ...OrdRtrToCatalystNSEEQ");
		exit(ERROR);
	}
	printf("\n OrdRtrToCatalystNSEEQ opened successfully with id = %d", iOrdRtrToOrdSrvNSEDR);



	fPrice = atof(argv[1]);

	logDebug2 ("fPrice  :%f:",fPrice);

	for(i = 0 ; i < 1000 ; i++)
	{
		pOrdReq.ReqHeader.iMsgCode=TC_INT_ORDER_ENTRY_REQ;
		pOrdReq.ReqHeader.iSeqNo = 11  ;
		pOrdReq.ReqHeader.iMsgLength = 100;
		strncpy(pOrdReq.ReqHeader.sExcgId,"NSE",EXCHANGE_LEN);
		pOrdReq.ReqHeader.iUserId = 9223;
		pOrdReq.ReqHeader.cSource = 'M';
		pOrdReq.ReqHeader.cSegment = 'E';
		strncpy(pOrdReq.sSecurityId,"47582",DB_SECURITY_ID_LEN);
		strncpy(pOrdReq.sEntityId,"CL001",DB_ENTITY_ID_LEN);
		strncpy(pOrdReq.sClientId,"CL001",DB_CLIENT_ID_LEN);
		pOrdReq.iTotalQty = 250;
		pOrdReq.iTotalQtyRem = 250;
		pOrdReq.iDiscQty = 0;
		pOrdReq.iDiscQtyRem = 0;
		pOrdReq.iStratergyId = 5;
		pOrdReq.iTotalTradedQty = 0;
		pOrdReq.cBuyOrSell = 'B' ;
		pOrdReq.iMktType = 1;
		pOrdReq.iOrderType      = 1;
		pOrdReq.fTriggerPrice =0.00 ;           /* 0.00*/
		pOrdReq.iOrderValidity = 0;
		pOrdReq.iMinFillQty = 0;
		pOrdReq.cProCli = 'C';
		pOrdReq.cUserType = 'C';
		pOrdReq.cOffMarketFlg = 'N';
		pOrdReq.cProductId = 'I';
		pOrdReq.cHandleInst = '1';

		if(WriteMsgQ( iOrdRtrToOrdSrvNSEDR ,(CHAR *) &pOrdReq, sizeof(struct ORDER_REQUEST),1) != 1)
		{
			perror("write to Q failed : ");
			exit(ERROR);
		}

	}

}


