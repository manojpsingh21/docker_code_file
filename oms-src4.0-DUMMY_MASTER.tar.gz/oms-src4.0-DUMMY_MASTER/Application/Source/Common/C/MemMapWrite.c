#include    "MemMapConfig.h"
#include    "MemMapqueue.h"
#include    "MemMapCommon.h"

/*
  extern double  OffMsgArray[MAX_NO_OFFLINE_THREAD];
  extern pthread_mutex_t             OffMsgArrayMutex;
 */


int
Mq_Write(mymqd_t mqd, const char *ptr, size_t len, unsigned int prio, ...)
{
		int		n;
		long	index, freeindex;
		int8_t	*mptr;
		struct sigevent	*sigev;
		struct mymq_hdr	*mqhdr;
		struct mymq_attr	*attr;
		struct mymsg_hdr	*msghdr, *nmsghdr, *pmsghdr;
		struct mymq_info	*mqinfo;
		
		va_list ap;
		double exch_ord_no=0;
		int  msg_number=0;
		
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				return(-1);
		}
	/******/
		va_start(ap, prio);
		exch_ord_no=va_arg(ap,double);
		msg_number=va_arg(ap,int);
		va_end(ap);
		printf("\nMq_Write:EXCH_ORD_NO:%lf", exch_ord_no);
		printf("\nMq_Write:MSG_NUMBER :%d", msg_number);
		/******/
		mqhdr = mqinfo->mqi_hdr;	/* struct pointer */
		mptr = (int8_t *) mqhdr;	/* byte pointer */
		attr = &mqhdr->mqh_attr;
		
		/*****************/
		printf("\nHead = %d",mqhdr ->mqh_head);
		printf("\nFree = %d",mqhdr ->mqh_free);
		printf ("\nThe number of msgs to be read from file is = %d", attr->mq_curmsgs);	
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			errno = n;
				return(-1);
		}
	
		if (len > attr->mq_msgsize) 
		{
			errno = EMSGSIZE;
				goto err;
		}
	if (attr->mq_curmsgs == 0) 
	{
		printf("\n No Of Msgs is Zero.");
	} 
	/****************************************	
	  else if (attr->mq_curmsgs >= attr->mq_maxmsg) 
	  {
	 * 4queue is full *
	 
	 if (mqinfo->mqi_flags & O_NONBLOCK) 
	 {
	 errno = EAGAIN;
	 goto err;
	 }
	 * 4wait for room for one message on the queue *
	 
	 while (attr->mq_curmsgs >= attr->mq_maxmsg)
	 {
	 pthread_cond_wait(&mqhdr->mqh_wait, &mqhdr->mqh_lock);
	 printf ("\n\t attr->mq_curmsgs = ", attr->mq_curmsgs);
	 }
	 }
	 ************************************************/
	/* 4nmsghdr will point to new message */
		/*
		  Assigned Free Ptr to new message.
		 */
		
		if ( (freeindex = mqhdr->mqh_free) == 0)
		{	
			printf("Mq_Send: curmsgs = %ld; free = 0", attr->mq_curmsgs);
				freeindex = mqhdr->mqh_head;
		}
	nmsghdr = (struct mymsg_hdr *) &mptr[freeindex];
		nmsghdr->msg_prio = prio;
		nmsghdr->msg_len = len;
		
		nmsghdr->msg_status = MSG_NOT_PROCESSED; /*Set Status as Un Processed */
		nmsghdr->msg_exch_ord_no = exch_ord_no;	 /* Copy Exch Ord No */
		nmsghdr->msg_number = msg_number;	 	/* Copy Msg No */
		
		memcpy(nmsghdr + 1, ptr, len);		/* copy message from caller */
		mqhdr->mqh_free = nmsghdr->msg_next;	/* new freelist head */
		
		if (mqhdr->mqh_free ==0)
		{
			printf ("\n\t Memory full");		
				printf ("\n\t head = %d",mqhdr->mqh_head);	
				mqhdr->mqh_free = mqhdr->mqh_head;
				/*			exit(0);*/
		}	
	/* 4find right place for message in linked list */
		if (attr->mq_curmsgs == 0)
			pthread_cond_broadcast(&mqhdr->mqh_wait);
				
				/******************added as mq_curmsgs canoot be greater than MAX_MESSAGES as we are using round robin***************/
				if( attr->mq_curmsgs < MAX_MESSAGES) 
					attr->mq_curmsgs++;
						
						printf("\n*****************CurMsgs**************::%d",attr->mq_curmsgs);
						
						pthread_mutex_unlock(&mqhdr->mqh_lock);
						/*************************************
						  LockThreadMutex(&array_lock);
						  
						  if(pthread_cond_broadcast(&array_wait) != 0)
						  {
						  printf("\n Error in broadcast condition variable ");
						  exit(1);
						  }
						  
						  UnLockThreadMutex(&array_lock);
						 *************************************/
						return(0);
						
						err:
						pthread_mutex_unlock(&mqhdr->mqh_lock);
						return(-1);
}
/* end MqWrite */

void
WriteMmap(mymqd_t mqd, const char *ptr, size_t len, unsigned int prio, ... )
{
	va_list ap;
		double exch_ord_no=0;
		int msg_number=0;
		
		/******/
		va_start(ap, prio);
		exch_ord_no=va_arg(ap,double);
		msg_number=va_arg(ap,int);
		va_end(ap);
		/******/
		
		if (Mq_Write(mqd, ptr, len, prio,exch_ord_no,msg_number) == -1)
			printf("Mq_Write error");
}

/*MqUpdate(mymqd_t mqd,  long FileIndex ,int ArrayPosn )*/
MqUpdate(mymqd_t mqd,  long FileIndex )
{
	int		n;
		long	index, freeindex;
		long    PrevIndex,NextIndex;
		int		msgsize=0;
		int8_t	*mptr;
		struct sigevent	*sigev;
		struct mymq_hdr	*mqhdr;
		struct mymq_attr	*attr;
		struct mymsg_hdr	*msghdr, *nmsghdr, *pmsghdr;
		struct mymq_info	*mqinfo;
		
		va_list ap;
		double exch_ord_no=0;
		int  msg_number=0;
		
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;	/* struct pointer */
		mptr = (int8_t *) mqhdr;	/* byte pointer */
		attr = &mqhdr->mqh_attr;
		
		if( FileIndex == -1) 
		{
			printf("\nWrong Index Recvd In MqUpdate.");
				exit(1);
		}
	
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			printf("\nERROR: pthread_mutex_lock:%d",errno);
				errno = n;
				return(-1);
		}
	
		
		
		/*
		  if (len > attr->mq_msgsize) 
		  {
		  errno = EMSGSIZE;
		  goto err;
		  }
		 */
		
		if (attr->mq_curmsgs == 0) 
		{
			printf("\n No Of Msgs is Zero.");
				printf("\nEXIT.");
				goto err;
		} 
		else if (attr->mq_curmsgs >= attr->mq_maxmsg) 
		{
			/* 4queue is full */
				
				if (mqinfo->mqi_flags & O_NONBLOCK) 
				{
					errno = EAGAIN;
						goto err;
				}
			
		}
	
		
		
		LockThreadMutex(&OffMsgArrayMutex);
		
		
		if ( (freeindex = mqhdr->mqh_free) == 0)
			printf("MqUpdate: curmsgs = %ld; free = 0", attr->mq_curmsgs);
				
				/*************************************
				  nmsghdr = (struct mymsg_hdr *) &mptr[FileIndex];
				  
				  nmsghdr->msg_status = MSG_PROCESSED;
				  
				  printf("\nMqUpdate:mqhdr->mqh_head:%ld",mqhdr->mqh_head);
				  
				  printf("\nWake up Threads Block For Process to complete.");
				 *************************************/
				
				LockThreadMutex(&array_lock);
				
				if(pthread_cond_broadcast(&array_wait) != 0)
				{
					printf("\n Error in broadcast condition variable ");
						exit(1);
				}
	
		UnLockThreadMutex(&array_lock);
		
		
		UnLockThreadMutex(&OffMsgArrayMutex);
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		
		return(0);
		
		err:
		UnLockThreadMutex(&OffMsgArrayMutex);
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		
		return(-1);
}
/* end MqUpdate */

