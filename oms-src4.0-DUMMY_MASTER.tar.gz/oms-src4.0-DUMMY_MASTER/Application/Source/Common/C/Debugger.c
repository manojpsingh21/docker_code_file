#include "Log.h"
#include <pthread.h>
int main(int argc, char *argv[])
{
	logTimestamp("Entry : [main]");

	int level = 0;
	if( argc != 2 )
	{
		logDebug3("useage: %s <log level> (<log level> can be 1, 2 or 3)\n", argv[0]);
		return EXIT_FAILURE;
	}
	level = atoi(argv[1]);
	SetLogLevel(level);
	logTimestamp("Exit : [main]");

}

