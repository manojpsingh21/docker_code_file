#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

SHORT           fTrim(CHAR *Str_Len,SHORT MaxLen);

BOOL fOrderValidation(MYSQL *DBObj,CHAR *sEntityId,CHAR *sClientId)
{
        logTimestamp("Entry :fOrderValidation");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        CHAR    cEntityStatus ;
        CHAR    sQry[MAX_QUERY_SIZE];
        memset(sQry,'\0',MAX_QUERY_SIZE);

	logDebug3("sEntityId :%s:",sEntityId);
        logDebug3("sClientId :%s:",sClientId);

        fTrim(sEntityId,strlen(sEntityId));
        fTrim(sClientId,strlen(sClientId));

        logDebug3("sEntityId :%s:",sEntityId);
        logDebug3("sClientId :%s:",sClientId);

        sprintf(sQry,"select ENTITY_STATUS from ENTITY_MASTER where ENTITY_CODE = \"%s\";",sClientId);
        logDebug2("sQry = %s",sQry);

        if (mysql_query(DBObj, sQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry");
                sql_Error(DBObj);
        }
        Res = mysql_store_result(DBObj);

        if((Row = mysql_fetch_row(Res)))
        {
                cEntityStatus = Row[0][0];
                logDebug2("cEntityStatus = :%c:",cEntityStatus);

        }
        mysql_free_result(Res);

        if((strcmp(sEntityId,sClientId) == 0) && (cEntityStatus == 'D' || cEntityStatus == 'S'))
        {
                return FALSE;
        }
        else
        {
                return TRUE;
        }

        logTimestamp("Exit :fOrderValidation");

}

SHORT  fTrim( CHAR *string , SHORT MaxLen )
{
        logTimestamp("Entry : [fTrim]");
        SHORT index=0;
        if ( MaxLen <= 0 )
        return 0 ;
        for( ; string[index] != ' ' && string[index] != '\0' && index < MaxLen ; index++ )
        continue;
        string[index]='\0';
        logTimestamp("Exit : [fTrim]");
        return index ;
}

BOOL fChkClientOffline(MYSQL *DBObj,CHAR *sEntityId1,CHAR *sClientId1)
{
        logTimestamp("ENTRY : [fChkClientOffline]");
        CHAR    sSelQry [MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
        CHAR cClientStat='N';

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug3("sEntityId    :%s:",sEntityId1);
        logDebug3("sClientId    :%s:",sClientId1);

        fTrim(sEntityId1,strlen(sEntityId1));
        fTrim(sClientId1,strlen(sClientId1));

        logDebug3("sEntityId :%s:",sEntityId1);
        logDebug3("sClientId :%s:",sClientId1);

	sprintf(sSelQry,"SELECT ENTITY_OFFLINE_FLAG FROM ENTITY_MASTER WHERE ENTITY_CODE = \"%s\";",sClientId1);

        logDebug2("sSelQry = %s",sSelQry);

        if (mysql_query(DBObj, sSelQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry1");
                sql_Error(DBObj);
                return FALSE;
        }
        Res = mysql_store_result(DBObj);

        if((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Row fetched from ENTITY_MASTER");
                cClientStat = Row[0][0];
                logDebug2("cClientStat = %c",cClientStat);
        }
        else
        {
                logDebug2(" No row fetched from ENTITY_MASTER");
                return FALSE;

        }

        if(cClientStat == YES)
        {
                if((strncmp(sEntityId1,sClientId1,CLIENT_ID_LEN) == 0))
                {
                        logDebug3("ENTITY ID AND CLIENT ID IS SAME");
                        return FALSE;
                }
                else
                {
                        return TRUE;
                }
        }
        else
        {
                return TRUE;
        }
	
	mysql_free_result(Res);
        logTimestamp("Exit : fChkClientOffline");
}

BOOL fGTTOrdersExpCheck(MYSQL *DBObj,CHAR *sExchId,CHAR *cSeg,CHAR *sSecId)
{
        logTimestamp("ENTRY : [fGTTOrdersExpCheck]");
        CHAR    sSelQry [MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);
        CHAR cSecExpStat = '\0';

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        logDebug3("sExchId :%s:",sExchId);
        logDebug3("cSeg    :%c:",cSeg);
        logDebug3("sSecId  :%s:",sSecId);

        sprintf(sSelQry,"select if(SM_EXPIRY_DATE>NOW(),'Y','N') from SECURITY_MASTER WHERE SM_EXCHANGE  = \"%s\" AND SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE = \"%s\";",sExchId,cSeg,sSecId);

        logDebug2("sSelQry = %s",sSelQry);

        if (mysql_query(DBObj, sSelQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry1");
                sql_Error(DBObj);
                return FALSE;
        }
        Res = mysql_store_result(DBObj);

        if((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Row fetched from SECURITY_MASTER");
                cSecExpStat = Row[0][0];
                logDebug2("cSecExpStat = %c",cSecExpStat);
        }
        else
        {
                logDebug2(" No row fetched from SECURITY_MASTER");
                return FALSE;

        }

        if(cSecExpStat == YES)
        {
                return TRUE;
        }
        else
        {
                return FALSE;
        }


	mysql_free_result(Res);
        logTimestamp("EXIT : [fGTTOrdersExpCheck]");
}

