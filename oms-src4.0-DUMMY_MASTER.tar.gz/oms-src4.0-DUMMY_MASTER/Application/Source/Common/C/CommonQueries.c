#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

extern   *DBQueries;

BOOL	fOrderBookQuery(CHAR sClientId,CHAR *sWhere_Clause,MYSQL_RES **Result)
{

	logTimestamp("Entry : fOrderBookQuery");

	//	MYSQL_RES               *Res;
	//MYSQL_ROW               Row;

	CHAR *sOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);	

	logDebug2("DOUBLE_MAX_QUERY_SIZE = %d",DOUBLE_MAX_QUERY_SIZE);	

	logDebug2("???");

	//	sprintf(sOrdBook,"SELECT * FROM (SELECT `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME");
	sprintf(sOrdBook,"SELECT * FROM (SELECT `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,\
		`A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,`A`.`EQ_EXCH_ID` AS `EXCH`,\
		(CASE `A`.`EQ_BUY_SELL_IND` WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS `BUY_SELL`,'E' AS `SEGMENT`,\
		`A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,`A`.`EQ_SYMBOL` AS `SYMBOL`,`A`.`EQ_LEG_NO` AS `LEG_NO`,\
		(CASE `A`.`EQ_PRODUCT_ID` WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' \
		 WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' ELSE `A`.`EQ_PRODUCT_ID` END) AS `PRODUCT`,\
		(CASE WHEN ((`A`.`EQ_MSG_CODE` = '2073') AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))\
		 THEN 'Part-Traded' WHEN ((`A`.`EQ_MSG_CODE` = '2074') AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`))\
		 THEN 'Part-Traded' WHEN ((`A`.`EQ_MSG_CODE` = '2212') AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))\
		 THEN 'Part-Traded' WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending' WHEN (`A`.`EQ_MSG_CODE` = '2000')\
		 THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2070') \
		 THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '2042') \
		 THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen' WHEN (`A`.`EQ_MSG_CODE` = '2074') \
		 THEN 'Modified' WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled' WHEN (`A`.`EQ_MSG_CODE` = '2222')\
		 THEN 'Traded' WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired' WHEN (`A`.`EQ_MSG_CODE` = '5112') \
		 THEN 'O-Pending' WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified' WHEN (`A`.`EQ_MSG_CODE` = '5114')\
		 THEN 'O-Cancelled' WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered' WHEN (`A`.`EQ_MSG_CODE` = '1111')\
		 THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '1115') \
		 THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4445') \
		 THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected' END) AS `STATUS`, \
		`A`.`EQ_TOTAL_QTY` AS `QUANTITY`, `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`, \
		(CASE `A`.`EQ_SEGMENT` WHEN 'C' THEN REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT'\
								     ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0) END), 4), ',', '') \
		 ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT'\
					 ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0) END), 2), ',', '') END)AS `PRICE`, \
		CASE `A`.`EQ_SEGMENT` WHEN 'C' THEN ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE` WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)\
						WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 2) \
		ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE` WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)\
						WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 2) END AS `TRG_PRICE`, \
		(CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`, \
		CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`, `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,\
		`A`.`EQ_SERIAL_NO` AS `SERIALNO`, `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`, `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,\
		(CASE `A`.`EQ_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS `ORDER_VALIDITY`,\
		`A`.`EQ_LOT_SIZE` AS `SEM_NSE_REGULAR_LOT`, 0 AS `TAKE_PROFIT_TRAIL_GAP`,`A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,\
		`A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`, `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`, `A`.`EQ_REASON_DESCRIPTION` AS `REASON_DESCRIPTION` \
		FROM `EQ_ORDERS` `A` \
		JOIN (SELECT @rn:=0) r WHERE `A`.`EQ_CLIENT_ID` = ltrim(rtrim(\"%s\")) AND `A`.`EQ_SERIAL_NO` = (SELECT MAX(`C`.`EQ_SERIAL_NO`) \
		FROM `EQ_ORDERS` `C` WHERE (`C`.`EQ_ORDER_NO` = `A`.`EQ_ORDER_NO`) AND (`A`.`EQ_ALGO_ORDER_NO` <> -(1) \
				AND (`A`.`EQ_LEG_NO` = `C`.`EQ_LEG_NO`)) AND (`A`.`EQ_ORD_STATUS` <> 'B')) UNION ALL SELECT `DO`.`DRV_CLIENT_ID` AS `CLIENT_ID`,\
				DATE_FORMAT(`DO`.`DRV_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`, `DO`.`DRV_ORDER_NO` AS `ORDER NUMBER`, \
				`DO`.`DRV_EXCH_ID` AS `EXCH`, (CASE `DO`.`DRV_BUY_SELL_IND` WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS `BUY/SELL`, \
				`DO`.`DRV_SEGMENT` AS `SEGMENT`, `DO`.`DRV_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`, `DO`.`DRV_SYMBOL` AS `SYMBOL`, \
				`DO`.`DRV_LEG_NO` AS `LEG_NO`, \
				(CASE `DO`.`DRV_PRODUCT_ID` WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB'\
				 WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' ELSE `DO`.`DRV_PRODUCT_ID` END) AS `PRODUCT`,\
				(CASE WHEN ((`DO`.`DRV_MSG_CODE` = '2073') AND (`DO`.`DRV_REM_QTY` <> `DO`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' \
				 WHEN ((`DO`.`DRV_MSG_CODE` = '2074') AND (`DO`.`DRV_REM_QTY` > `DO`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' \
				 WHEN ((`DO`.`DRV_MSG_CODE` = '2212') AND (`DO`.`DRV_REM_QTY` <> `DO`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '2073') THEN 'Pending' WHEN (`DO`.`DRV_MSG_CODE` = '2000') THEN 'Transit' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '2040') THEN 'Transit' WHEN (`DO`.`DRV_MSG_CODE` = '2070') THEN 'Transit' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '2231') THEN 'Rejected' WHEN (`DO`.`DRV_MSG_CODE` = '2042') THEN 'Rejected'\
				 WHEN (`DO`.`DRV_MSG_CODE` = '2170') THEN 'Frozen' WHEN (`DO`.`DRV_MSG_CODE` = '2074') THEN 'Modified' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '2075') THEN 'Cancelled' WHEN (`DO`.`DRV_MSG_CODE` = '2222') THEN 'Traded' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '9002') THEN 'Expired' WHEN (`DO`.`DRV_MSG_CODE` = '5112') THEN 'O-Pending' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '5113') THEN 'O-Modified' WHEN (`DO`.`DRV_MSG_CODE` = '5114') THEN 'O-Cancelled'\
				 WHEN (`DO`.`DRV_MSG_CODE` = '2212') THEN 'Triggered' WHEN (`DO`.`DRV_MSG_CODE` = '1111') THEN 'Rejected' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '1113') THEN 'Rejected' WHEN (`DO`.`DRV_MSG_CODE` = '1115') THEN 'Rejected'\
				 WHEN (`DO`.`DRV_MSG_CODE` = '4444') THEN 'Rejected' WHEN (`DO`.`DRV_MSG_CODE` = '4445') THEN 'Rejected' \
				 WHEN (`DO`.`DRV_MSG_CODE` = '4446') THEN 'Rejected' END) AS `STATUS`, `DO`.`DRV_TOTAL_QTY` AS `QUANTITY`,`DO`.`DRV_REM_QTY` AS `REM QTY`, \
				CASE `DO`.`DRV_SEGMENT` WHEN 'C' THEN REPLACE( FORMAT((CASE `DO`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
								ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0) END), 4), ',', '') ELSE REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3'\
								THEN 'MKT' ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0) END), 2), ',', '') END AS `PRICE`, \
								CASE `DO`.`DRV_SEGMENT` WHEN 'C' THEN ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE` WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) WHEN '4'\
												THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE` WHEN '3' \
												THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) \
												WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 2) END AS TRG_PRICE, \
												(CASE `DO`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`, \
												CONCAT(`DO`.`DRV_REM_QTY`, '/', `DO`.`DRV_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`, `DO`.`DRV_DISC_QTY` AS `DISCLOSE_QTY`, \
												`DO`.`DRV_SERIAL_NO` AS `SERIALNO`, `DO`.`DRV_TOTAL_TRADED_QTY` AS `TRADEDQTY`, `DO`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,\
												(CASE `DO`.`DRV_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS `ORDER_VALIDITY`,\
												`DO`.`DRV_LOT_SIZE` AS `SM_LOT_SIZE`, 0 AS `TAKE_PROFIT_TRAIL_GAP`, `DO`.`DRV_OMS_ALGO_ORD_NO` AS `ADV_GROUP_REF_NO`, \
												`DO`.`DRV_DISC_REM_QTY` AS `DQQTYREM`, `DO`.`DRV_EXCH_ORDER_NO` AS `EXCHORDERNO`, `DO`.`DRV_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`\
												FROM `DRV_ORDERS` `DO` JOIN (SELECT @rn:=0) r WHERE `DO`.`DRV_CLIENT_ID` = ltrim(rtrim(\"%s\")) \
												AND `DO`.`DRV_SERIAL_NO` = (SELECT MAX(`DOO`.`DRV_SERIAL_NO`) FROM `DRV_ORDERS` `DOO` WHERE (`DOO`.`DRV_ORDER_NO` = `DO`.`DRV_ORDER_NO`) \
														AND (`DO`.`DRV_OMS_ALGO_ORD_NO` <> -(1) AND (`DO`.`DRV_LEG_NO` = `DOO`.`DRV_LEG_NO`)) \
														AND (`DO`.`DRV_STATUS` <> 'B'))) orderbook where 1=1 %s ORDER BY ORDER_DATE_TIME DESC ;",sClientId,sClientId,sWhere_Clause);

	printf(">>>>sOrdBook :%s:",sOrdBook);

	logDebug2("//////////////////");	

	if(mysql_query(DBQueries,sOrdBook ) != SUCCESS)
	{
		logSqlFatal("ERROR in sOrdBook Query.");
		sql_Error(DBQueries);
	}
	else
	{
		logDebug2("Hee");
	}

	logDebug3("****************");	

	*Res = mysql_store_result(DBQueries);


	//	return	*Res;

	logDebug2("Res = %s",*Res);

	//	Row = mysql_num_rows(Res);

	//	logDebug2("Row = %d",Row);	

	return  *Res;

	logTimestamp("Exit : fOrderBookQuery");

}
