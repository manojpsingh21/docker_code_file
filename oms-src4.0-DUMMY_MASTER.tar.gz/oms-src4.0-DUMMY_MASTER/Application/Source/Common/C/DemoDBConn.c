
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include <stdio.h>
#include "IPCS.h"

MYSQL    *DB_Conn;

void main(int argc, char *argv[])
{
	logTimestamp("Entry To main");
	INT16           i;	
	INT16           num_fields;
	MYSQL_RES      *Res;
	MYSQL_ROW       Row;

	CHAR *sSelQ = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	DB_Conn = DB_Connect();

	mysql_close(DB_Conn);

}
