#include <stdio.h>
#include <stdlib.h>
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>


LONG32          iOrdRtrToDeaNotify;
LONG32          iOrdSrvToTrdRtr;

//LONG32          iRcvQId;

LONG32		iCnt = 0;

main(int argc, char *argv[])
{
	logTimestamp("Entry in main");
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	OpenMsgQue();
	fDealerNotification(iOrdRtrToDeaNotify);
}

fDealerNotification(LONG32 iOrdRtrToDeaNotify)
{
	logTimestamp("Entry [fDealerNotification]");
	struct  ORDER_REQUEST   *Ord_Req;

	CHAR    RecBuff[RUPEE_MAX_PACKET_SIZE];
	LONG64  iEntryTime;
	BOOL	iCheckFlag = FALSE;
	LONG32	iMsgCode ;
	//	LONG32  iCnt = 0;
	/**
 *	Adding comment for Dry Run v3.1 
 *
 * */

	while(TRUE)
	{
		memset(RecBuff , '\0', RUPEE_MAX_PACKET_SIZE);
		memset( &Ord_Req, '\0', sizeof(struct ORDER_REQUEST));

		logInfo("----------------------- Notification LOOP = %d -----------------------",iCnt++);

		if((ReadMsgQ(iOrdRtrToDeaNotify,&RecBuff,RUPEE_MAX_PACKET_SIZE, 0)) != TRUE)
		{
			logFatal("Error : MsgQId is %d",iOrdRtrToDeaNotify);
			exit(ERROR);
		}
		logTimestamp("entry in dealer notification");

		Ord_Req = (struct ORDER_REQUEST *) &RecBuff;

		logDebug3("SEQ NO = %d ",Ord_Req->ReqHeader.iSeqNo);
		//		Ord_Req->ReqHeader.iUserId;
		//		logDebug2("User ID = %d",Ord_Req->ReqHeader.iUserId);

		logDebug2("Ord_Reque->ReqHeader.iMsgCode = %d",Ord_Req->ReqHeader.iMsgCode);	
		iMsgCode = Ord_Req->ReqHeader.iMsgCode;
		logDebug2("iMsgCode = %d",iMsgCode);		

		switch(iMsgCode)
		{
			case TC_INT_CREATE_ALL_FILE_REQ :

				logDebug2("Creating All File");
			/**Passing File path in Variable @nitish */
				//system("CreateFile A $RRFILE_PATH >/dev/null");
				logDebug2("Creating RRFILE Normal");
				system("CreateFile A $RRFILE_PATH > $HOME/Application/Exec/abc.log");
				logDebug2("Creating RRFILE using Socket");
				system("CreateFileSock A $RRFILE_PATH > $HOME/Application/Exec/abc.log");
				fSendRspAdmin(&RecBuff);
				break ;

			case TC_INT_NOTIFICATION_REQ :

				iCheckFlag = fSendResToFE(Ord_Req);
				if(iCheckFlag == FALSE)
				{
					logDebug1("error {send Res To FE}");
				}
				else
				{
					logInfo("Generating New Client Dealer File for :%s:",Ord_Req->sEntityId);
					/**Passing File path in Variable @nitish */
					logDebug2("Creating RRFILE Normal");
					system("CreateFile D $RRFILE_PATH >/dev/null");
					logDebug2("Creating RRFILE using Socket");
					system("CreateFileSock D $RRFILE_PATH >/dev/null");
					fSendRspAdmin(&RecBuff);

				}
				break ;

			case TC_INT_DEALER_CLIENT_SUSPENSION_REQ :
				fSendResponse(Ord_Req);
				continue ;
				break ;

			default	:
				logDebug2("Invalid Msg Code = %d",iMsgCode);
				break ;

		}
	}

	logTimestamp("EXIT [Dealer notification]");	

}

BOOL	GetUserID(CHAR *sClientId,ULONG64 *iUserId)
{
	logTimestamp("ENTRY [GetUserID]");
	MYSQL		*DB_NotfyCon;
	MYSQL_RES 	*Res;
	MYSQL_ROW  	Row;

	DB_NotfyCon = DB_Connect();

	CHAR	*sSelQry = malloc(MAX_QUERY_SIZE * sizeof(CHAR));		

	sprintf(sSelQry,"SELECT USER_CODE from USER_MASTER  where USER_ENTITY_CODE = \"%s\" ; ",sClientId);

	logDebug1("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_NotfyCon,sSelQry) != SUCCESS)
	{
		logSqlFatal("Err in select User Code Qyery");
		mysql_close(DB_NotfyCon);
		return FALSE;	
	}

	Res = mysql_store_result(DB_NotfyCon);

	if(Row = mysql_fetch_row(Res))
	{
		if(Row[0] != NULL)
			*iUserId = atoi(Row[0]);
		else
			return FALSE;
	}
	mysql_close(DB_NotfyCon);
	logTimestamp("EXIT [GetUserID]");
	return TRUE;

}

BOOL fSendResponse (struct ORDER_REQUEST *Ord_Reque)
{
	logTimestamp("ENTRY [fSendResponse]");
	struct  ORDER_RESPONSE  Ord_Res;
	memset(&Ord_Res, '\0', sizeof(struct ORDER_RESPONSE));
	ULONG64  iTempUserID;
	BOOL    iRetVal;


	Ord_Res.IntRespHeader.iSeqNo            = Ord_Reque->ReqHeader.iSeqNo;
	Ord_Res.IntRespHeader.iMsgLength        = sizeof(struct ORDER_RESPONSE);
	Ord_Res.IntRespHeader.iMsgCode		= TC_INT_DEA_CLI_SUSPENSION_NOTIFICATION_RES ;

	strncpy(Ord_Res.IntRespHeader.sExcgId,Ord_Reque->ReqHeader.sExcgId,EXCHANGE_LEN);

	Ord_Res.IntRespHeader.iErrorId = 0;
	Ord_Res.IntRespHeader.cSource = SOURCE_RAPIDRUPEE;

	iRetVal = GetUserID(Ord_Reque->sClientId,&iTempUserID);

	if(iRetVal == FALSE)
	{
		logInfo("Error in Fetch User ID");
		return FALSE;
	}
	else
	{
		Ord_Res.IntRespHeader.iUserId = iTempUserID;
	}

	strncpy(Ord_Res.sEntityId,Ord_Reque->sEntityId,ENTITY_ID_LEN);
	strncpy(Ord_Res.sClientId,Ord_Reque->sClientId,CLIENT_ID_LEN);

	Ord_Res.cUserType	=  Ord_Reque->cUserType  ;
	sprintf(Ord_Res.sRemarks,"%s Suspended",Ord_Res.sClientId);

	logDebug2("------------Printing Responce-----------");
	logDebug2("Seq No       [%d] ",Ord_Res.IntRespHeader.iSeqNo);
	logDebug2("Msg Length   [%d] ",Ord_Res.IntRespHeader.iMsgLength);
	logDebug2("MSG Code     [%d] ",Ord_Res.IntRespHeader.iMsgCode);
	logDebug2("sExcgId      [%s] ",Ord_Res.IntRespHeader.sExcgId);
	logDebug2("User id      [%d] ",Ord_Res.IntRespHeader.iUserId);
	logDebug2("Source       [%c] ",Ord_Res.IntRespHeader.cSource);
	logDebug2("Segment      [%c] ",Ord_Res.IntRespHeader.cSegment);
	logDebug2("Entity Id    [%s] ",Ord_Res.sEntityId);
	logDebug2("sClientId    [%s] ",Ord_Res.sClientId);
	logDebug2("cUserType	[%c] ",Ord_Res.cUserType);
	logDebug2("Remarks    [%s] ",Ord_Res.sRemarks);
	logDebug2("--------------END------------------------");

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&Ord_Res , sizeof(struct  ORDER_RESPONSE), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendRespToFE.");
		exit(ERROR);
	}
	Ord_Res.IntRespHeader.cSource = SOURCE_ADMIN ;
	iTempUserID = 0;
	iRetVal = GetUserID(Ord_Reque->sEntityId,&iTempUserID);
	Ord_Res.IntRespHeader.iUserId = iTempUserID ;
	logDebug2("Writing to Admin user Id :%llu:",iTempUserID);
	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&Ord_Res , sizeof(struct  ORDER_RESPONSE), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendRespToFE.");
		exit(ERROR);
	}


	logTimestamp("EXIT [SendResToFE]");
	return TRUE;

}


BOOL fSendResToFE(struct ORDER_REQUEST *Ord_Reque)
{
	logTimestamp("ENTRY [fSendResToFE]");
	struct  ORDER_RESPONSE  Ord_Res;
	memset(&Ord_Res, '\0', sizeof(struct ORDER_RESPONSE));
	ULONG64	iTempUserID;
	BOOL	iRetVal;


	Ord_Res.IntRespHeader.iSeqNo 		= Ord_Reque->ReqHeader.iSeqNo;
	logDebug2("sizeof(struct ORDER_RESPONSE) :%d:",sizeof(struct ORDER_RESPONSE));
	Ord_Res.IntRespHeader.iMsgLength 	= sizeof(struct ORDER_RESPONSE);
	logDebug2("Ord_Res.IntRespHeader.iMsgLength :%d:",Ord_Res.IntRespHeader.iMsgLength);
	Ord_Res.IntRespHeader.iMsgCode 		= Ord_Reque->ReqHeader.iMsgCode;

	strncpy(Ord_Res.IntRespHeader.sExcgId,Ord_Reque->ReqHeader.sExcgId,EXCHANGE_LEN);

	Ord_Res.IntRespHeader.iErrorId = 0;

	iRetVal = GetUserID(Ord_Reque->sClientId,&iTempUserID);

	if(iRetVal == FALSE)	
	{
		logInfo("Error in Fetch User ID");
		return FALSE;
	}
	else
	{
		Ord_Res.IntRespHeader.iUserId = iTempUserID;
	}

	logDebug2("Ord_Res.IntRespHeader.iMsgCode = %d ",Ord_Res.IntRespHeader.iMsgCode);

	if(Ord_Res.IntRespHeader.iMsgCode == TC_INT_NOTIFICATION_REQ)
	{
		Ord_Res.IntRespHeader.cSource = SOURCE_RAPIDRUPEE;
	}
	else
	{
		Ord_Res.IntRespHeader.cSource = Ord_Reque->ReqHeader.cSource;
	}

	Ord_Res.IntRespHeader.iTimeStamp = 0;
	Ord_Res.IntRespHeader.cSegment 		= Ord_Reque->ReqHeader.cSegment;

	strncpy(Ord_Res.sEntityId,Ord_Reque->sClientId,ENTITY_ID_LEN);
	strncpy(Ord_Res.sClientId,Ord_Reque->sClientId,CLIENT_ID_LEN);

	Ord_Res.iTotalQty 			= Ord_Reque->iTotalQty ;

	logDebug2("------------Printing Responce-----------");
	logDebug2("Seq No  	[%d] ",Ord_Res.IntRespHeader.iSeqNo);
	logDebug2("Msg Length  	[%d] ",Ord_Res.IntRespHeader.iMsgLength);
	logDebug2("MSG Code  	[%d] ",Ord_Res.IntRespHeader.iMsgCode);
	logDebug2("sExcgId  	[%s] ",Ord_Res.IntRespHeader.sExcgId);
	logDebug2("User id  	[%d] ",Ord_Res.IntRespHeader.iUserId);
	logDebug2("Source  	[%c] ",Ord_Res.IntRespHeader.cSource);
	logDebug2("Segment  	[%c] ",Ord_Res.IntRespHeader.cSegment);
	logDebug2("Entity Id  	[%s] ",Ord_Res.sEntityId);
	logDebug2("sClientId 	[%s] ",Ord_Res.sClientId);
	logDebug2("Total Clients Mapped [%d]",Ord_Res.iTotalQty);
	logDebug2("--------------END------------------------");

	//DeaNo_Res.iTotalNoOfUsers = No_Req->iNoOfUsers;

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&Ord_Res , sizeof(struct  ORDER_RESPONSE), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendRespToFE.");
		exit(ERROR);
	}
	logTimestamp("EXIT [SendResToFE]");
	return TRUE;

}

BOOL fSendRspAdmin(CHAR *sResp)
{
	logTimestamp("ENTRY [fSendResToFE]");
	struct  ORDER_RESPONSE  Ord_Res;
	struct ORDER_REQUEST *Ord_Reque;
	memset(&Ord_Res, '\0', sizeof(struct ORDER_RESPONSE));
	LONG32  iTempUserID;
	BOOL    iRetVal;

	Ord_Reque = (struct ORDER_REQUEST *)sResp;

	Ord_Res.IntRespHeader.iSeqNo            = Ord_Reque->ReqHeader.iSeqNo;
	Ord_Res.IntRespHeader.iMsgLength        = sizeof(struct ORDER_RESPONSE);

	logDebug2(" Request iMsgCode = :%d:",Ord_Reque->ReqHeader.iMsgCode);        
	if(Ord_Reque->ReqHeader.iMsgCode == TC_INT_NOTIFICATION_REQ)
	{
		Ord_Res.IntRespHeader.iMsgCode = TC_INT_NOTIFICATION_RES;
	}
	else if(Ord_Reque->ReqHeader.iMsgCode == TC_INT_CREATE_ALL_FILE_REQ)
	{
		Ord_Res.IntRespHeader.iMsgCode = TC_INT_CREATE_ALL_FILE_RES;	
	}
	logDebug2(" Responce Ord_Res.IntRespHeader.iMsgCode = :%d:",Ord_Res.IntRespHeader.iMsgCode);        

	strncpy(Ord_Res.IntRespHeader.sExcgId,Ord_Reque->ReqHeader.sExcgId,EXCHANGE_LEN);

	Ord_Res.IntRespHeader.iErrorId = 0;

	Ord_Res.IntRespHeader.iUserId           = Ord_Reque->ReqHeader.iUserId;

	Ord_Res.IntRespHeader.cSource           = Ord_Reque->ReqHeader.cSource;

	Ord_Res.IntRespHeader.iTimeStamp = 0;
	Ord_Res.IntRespHeader.cSegment          = Ord_Reque->ReqHeader.cSegment;

	strncpy(Ord_Res.sEntityId,Ord_Reque->sEntityId,ENTITY_ID_LEN);
	strncpy(Ord_Res.sClientId,Ord_Reque->sClientId,CLIENT_ID_LEN);

	Ord_Res.iTotalQty                       = Ord_Reque->iTotalQty ;

	logDebug2("------------Printing Responce-----------");
	logDebug2("Seq No       [%d] ",Ord_Res.IntRespHeader.iSeqNo);
	logDebug2("Msg Length   [%d] ",Ord_Res.IntRespHeader.iMsgLength);
	logDebug2("MSG Code     [%d] ",Ord_Res.IntRespHeader.iMsgCode);
	logDebug2("sExcgId      [%s] ",Ord_Res.IntRespHeader.sExcgId);
	logDebug2("User id      [%d] ",Ord_Res.IntRespHeader.iUserId);
	logDebug2("Source       [%c] ",Ord_Res.IntRespHeader.cSource);
	logDebug2("Segment      [%c] ",Ord_Res.IntRespHeader.cSegment);
	logDebug2("Entity Id    [%s] ",Ord_Res.sEntityId);
	logDebug2("sClientId    [%s] ",Ord_Res.sClientId);
	logDebug2("Total Clients Mapped [%d]",Ord_Res.iTotalQty);
	logDebug2("--------------END------------------------");

	//DeaNo_Res.iTotalNoOfUsers = No_Req->iNoOfUsers;

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&Ord_Res , sizeof(struct  ORDER_RESPONSE), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendRespToFE.");
		exit(ERROR);
	}
	logTimestamp("EXIT [SendResToFE]");
	logDebug2("Total Clients Mapped [%d]",Ord_Res.iTotalQty);
	return TRUE;

}


void OpenMsgQue()
{
	logTimestamp("Entry in msg queue.");

	if((iOrdRtrToDeaNotify = OpenMsgQ(OrdRtrToDeaNotify)) == ERROR)
	{
		logFatal("Error in open queue (OrdRtrToDeaNotify)");
		exit(ERROR);
	}
	logInfo("OrdRtrToDeaNotify open successfully with id = %d ",iOrdRtrToDeaNotify);

	if((iOrdSrvToTrdRtr = OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal("Error in open queue (OrdSrvToTrdRtr)");
		exit(ERROR);
	}
	logInfo("DeaNotiToTrdRtr open successfully with id = %d ",iOrdSrvToTrdRtr);

	logTimestamp("Exit [OpenMsgQue]");
}
