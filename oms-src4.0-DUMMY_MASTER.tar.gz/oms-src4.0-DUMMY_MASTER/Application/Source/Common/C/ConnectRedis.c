#include <stdlib.h>
#include <stdio.h>
#include "IPCS.h"

redisContext *RDConnect(INT16 type)
{
	logTimestamp("Entry: Redis Connect");
	CHAR	sRdHostIP[REDIS_HOST_LEN];
	LONG32  iRdPort;
	char    sAuthId[20];
        char    sAuthPass[50];
        char    sAuth[70];	

	memset(sRdHostIP,'\0',REDIS_HOST_LEN);

	switch(type)
	{
		case REDIS_TYPE_ORDER_BCAST:
			strncpy(sRdHostIP,getenv("BROADCAST_REDIS_HOST"),REDIS_HOST_LEN);
			iRdPort = atoi(getenv("BROADCAST_REDIS_PORT"));
			break;
		case REDIS_TYPE_RMS_VALIDATION:
			strncpy(sRdHostIP,getenv("RMS_REDIS_HOST"),REDIS_HOST_LEN);
    			iRdPort = atoi(getenv("RMS_REDIS_PORT"));
    			break;
		case REDIS_TYPE_CLEARING_MEM:
			strncpy(sRdHostIP,getenv("CLEARING_MEM_REDIS_HOST"),REDIS_HOST_LEN);
    			iRdPort = atoi(getenv("CLEARING_MEM_REDIS_PORT"));
    			break;
		case REDIS_TYPE_PRICE_BCAST:
		case REDIS_TYPE_MKT_STATUS:
		case REDIS_TYPE_CLIENT_ADD:
		default:
			strncpy(sRdHostIP,getenv("REDIS_HOST_SLAVE"),REDIS_HOST_LEN);
			iRdPort = atoi(getenv("REDIS_PORT_SLAVE"));
			break;
	}

	logInfo("Connecting to :%s: :%d:",sRdHostIP,iRdPort);
	
	redisContext *Conn;
	redisReply *reply1;
	while(TRUE)
	{
		Conn = redisConnect(sRdHostIP, iRdPort);
		if(Conn == NULL || Conn->err)
		{
			logFatal("error in connection is [%s] ",Conn->errstr);
			redisFree(Conn);
			//exit(1);
			sleep(30);
		}
		else
		{
			logInfo("Connected to Redis Server");
			if(getenv("REDIS_FLAG") == NULL)
			{
				logDebug2("Redis Authentication Disabled...");
				return Conn;
			}
			if(strcmp(getenv("REDIS_FLAG"),"Y") == 0)
			{
				memset(sAuthId,'\0',20);
				memset(sAuthPass,'\0',50);
				memset(sAuth,'\0',70);
				if(getenv("REDIS_AUTH_ID")== NULL)
				{
					logFatal("Environment variables missing : default user");
					redisFree(Conn);
					exit(ERROR);
				}
				else
				{
					strncpy(sAuthId,getenv("REDIS_AUTH_ID"),20);
				}

				if(getenv("REDIS_AUTH_PASS")== NULL)
				{
					logFatal(" Environment variables missing : REDIS_AUTH_PASS");
					redisFree(Conn);
					exit(ERROR);
				}
				else
				{
					strncpy(sAuthPass,getenv("REDIS_AUTH_PASS"),50);
				}

				sprintf(sAuth,"AUTH %s %s", sAuthId, sAuthPass);
				reply1 = redisCommand(Conn, sAuth);
				freeReplyObject(reply1);
				logInfo("Connected to with auth redis Server");
				break;
			}
			else
			{
				logFatal("Redis Authentication Disabled..");
				break;
			}
		}
	}
	logTimestamp("Exit: Redis Connect");
	return Conn;
}

redisReply *fRedisCommand(redisContext *pRdCon, CHAR *sCmd, INT16 type) 
{
	redisReply *reply;
	logDebug3("Redis Cmd :%s:",sCmd);
	while(TRUE) {
		reply = redisCommand(pRdCon,sCmd);
		if(reply == NULL)
		{
			perror("Disconnected");
			logFatal("Redis was Disconnected. So reconnnecting again.");
			redisFree(pRdCon);
			sleep(5);
			pRdCon = RDConnect(type);
			if(pRdCon == NULL)
			{
				logInfo("Redis not connected ");
			}
			continue;
		}
		break;
	}	
	return reply;
}
