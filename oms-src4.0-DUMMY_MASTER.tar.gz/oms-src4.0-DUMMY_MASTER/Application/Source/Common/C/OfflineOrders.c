#include <stdio.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include "hiredis.h"
#include "RedisStruct.h"

MYSQL          *DB_Con;
MYSQL_RES      *Res;
MYSQL_ROW       Row;

CHAR	sTempErrStr[200];
CHAR    sDate[DATE_LEN];
CHAR   	sGeneratedOrdNo[ORDER_LEN];
CHAR    sFileName[FILE_NAME_LEN];
CHAR    sSettler[SETTLOR_LEN];
CHAR    sSettlor[SETTLOR_LEN];
CHAR    sSelectQry[MAX_QUERY_SIZE];

DOUBLE64        iOrder_no_date = 0.0;
BOOL            ChkFlag = FALSE;
LONG32 		iOrdRtrToOffOrd=0;
LONG32  	iOrdSrvToTrdRtr=0;
DOUBLE64        GeneratedOrdNo = 0;


LONG32  	rcvQ;
LONG32          iNCmBranchId ;
LONG32          iNFoBranchId ;
LONG32          iNCurBranchId ;
LONG32		iMcxBranchId ;
LONG32          iGroupId;
CHAR            sSettlor        [SETTLOR_LEN];
CHAR            sGroupId        [ENV_VARIABLE_LEN];
LONG32          iMcxUsrId ;
CHAR            sMcxBrokerId [BROKER_CODE_LEN];
LONG32          iMktChk=0;
redisContext    *RdConSt;


FILE            *fClOrdID;

BOOL 	OfflineOrderProcess(LONG32 iOrdRtrToOffOrd, LONG32 iOrdSrvToTrdRtr);
BOOL 	fSendSucessRespToFE(struct INT_ORDERS *p_oe_request,LONG32 sndQ);
BOOL  	fOffline_Order_DBUpdate(struct INT_ORDERS * p_Req_in, char * p_Req_out);
BOOL 	fFwdStructMapper(struct ORDER_REQUEST *Ord_Req,struct INT_ORDERS *Ins_Req, CHAR *sTempClOrdId);
BOOL 	GetMktType(CHAR *sMktType,LONG32 iMktType);
BOOL 	fRMSValidation(struct  INT_ORDERS *pReq, MYSQL *DBObj,LONG32 iNCmBranchId,CHAR *sErrorID,LONG32 *iQty,DOUBLE64 *fAmnt);
BOOL   	fRMSCommValidation(struct  INT_ORDERS *pReq, MYSQL *DBObj,LONG32 iMcxBranchId ,CHAR *sErrorID,LONG32 *iQty,DOUBLE64 *fAmnt);
void 	fPrintAll (struct  ORDER_REQUEST       *pIntReqHeader);


main (int argc, char **argv)
{
	logTimestamp("Entry : [Main]");
	setbuf ( stdout,NULL);
	setbuf ( stdin ,NULL);
	memset(sDate, '\0',DATE_LEN);
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);

	if((iOrdRtrToOffOrd=OpenMsgQ(OrdRtrToOffOrd)) == ERROR)
	{
		logFatal("OpenMsgQ2 ...OrdRtrToOffOrd");
		exit(ERROR);
	}

	if (( iOrdSrvToTrdRtr= OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal("OpenMsgQ2 ...OffOrdToTrdRtr ");
		exit(ERROR);
	}

	logInfo("QUEUES OPENED SUCCESSFULLY");

	logDebug2("Recv Queue id is :%d, Send Q Id Is :%d",iOrdRtrToOffOrd,iOrdSrvToTrdRtr);

	DB_Con = DB_Connect();
        logDebug2("connecting to redis Server ");
	RdConSt = RDConnect(REDIS_TYPE_PRICE_BCAST);
        if(RdConSt == NULL)
        {
                logInfo("Redis not connected ");
        }

	fSelectDate(&sDate);
	fLoadDBNseEnv ();
	fLoadDBMcxEnv ();
	
	if(getenv("GROUP_ID") == NULL)
        {
                logFatal("Error : Environment Variable missing : GROUP_ID ");
                exit(ERROR);
        }
        else
        {
                strncpy(sGroupId,getenv("GROUP_ID"),ENV_VARIABLE_LEN);
                iGroupId = atoi(sGroupId);
                logDebug2("iGroupId :%d:",iGroupId);
        }
	if(fAddEQSecHash() == TRUE)
	{
		logInfo("Success Adding Equity Securities to HASH ");
	}
	else
	{
		logInfo("Adding Securities to HASH FAILS");
	}
	if(fAddDrvSecHash() == TRUE)
	{
		logInfo("Success Adding Derivative Securities to HASH ");
	}
	else
	{
		logInfo("Adding Securities to HASH FAILS");
	}
/*
	if(fAddMCXSecHash() != TRUE )
        {
                logFatal("Error in Fetching COMM Security");                
        }
*/	
	//Added select Query to check whether it depends on market or not.if it depends on the market then user can not place order if market is open.@Abhishek 
	sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  = 'OFFLINE_CHECK';");
        if (mysql_query(DB_Con ,sSelectQry) != SUCCESS)
        {
                sql_Error(DB_Con);
                logSqlFatal("Error Fetching SysAdmin .");
                exit(ERROR);
        }
        logDebug2("Query [%s]",sSelectQry);

        Res = mysql_store_result(DB_Con);
	if(mysql_num_rows(Res) == 0)
        {
		iMktChk = 0;
                logDebug2("Default Market check     :%i:",iMktChk);
        }
   	else
        {
                while((Row = mysql_fetch_row(Res)))
                {
			iMktChk = atoi(Row[0]);
        	        logDebug2("Market check value    :%i:",iMktChk);
		}
        }
	mysql_free_result(Res);

	OfflineOrderProcess(iOrdRtrToOffOrd,iOrdSrvToTrdRtr);

	logTimestamp("Exit : [Main]");

}

void fPrintAll(struct  ORDER_REQUEST  *pOE_Req)
{
	logTimestamp("Offline Order [Entry]");

	logDebug3("iSeqNo 	:%d:",pOE_Req->ReqHeader.iSeqNo);
	logDebug3("iMsgLength   :%d:",pOE_Req->ReqHeader.iMsgLength);
	logDebug3("iMsgCode     :%d:",pOE_Req->ReqHeader.iMsgCode);
	logDebug3("sExcgId      :%s:",pOE_Req->ReqHeader.sExcgId);
	logDebug3("iUserId      :%llu:",pOE_Req->ReqHeader.iUserId);
	logDebug3("cSource      :%c:",pOE_Req->ReqHeader.cSource);
	logDebug3("cSegment     :%c:",pOE_Req->ReqHeader.cSegment);
	logDebug3("sSecurityId  :%s:",pOE_Req->sSecurityId);
	logDebug3("sEntityId    :%s:",pOE_Req->sEntityId);
	logDebug3("sClientId    :%s:",pOE_Req->sClientId);
	logDebug3("cProductId   :%c:",pOE_Req->cProductId);
	logDebug3("cBuyOrSell   :%c:",pOE_Req->cBuyOrSell);
	logDebug3("iOrderType   :%d:",pOE_Req->iOrderType);
	logDebug3("iOrderValidity       :%d:",pOE_Req->iOrderValidity);
	logDebug3("iDiscQty     :%d:",pOE_Req->iDiscQty);
	logDebug3("iDiscQtyRem  :%d:",pOE_Req->iDiscQtyRem);
	logDebug3("iTotalQtyRem :%d:",pOE_Req->iTotalQtyRem);
	logDebug3("iTotalQty    :%d:",pOE_Req->iTotalQty);
	logDebug3("iTotalTradedQty      :%d:",pOE_Req->iTotalTradedQty);
	logDebug3("iMinFillQty  :%d:",pOE_Req->iMinFillQty);
	logDebug3("fPrice       :%f:",pOE_Req->fPrice);
	logDebug3("fTriggerPrice        :%f:",pOE_Req->fTriggerPrice);
	logDebug3("fOrderNum    :%f:",pOE_Req->fOrderNum);
	logDebug3("iSerialNum   :%d:",pOE_Req->iSerialNum);
	logDebug3("cHandleInst  :%c:",pOE_Req->cHandleInst);
	logDebug3("fAlgoOrderNo :%f:",pOE_Req->fAlgoOrderNo);
	logDebug3("iStratergyId :%d:",pOE_Req->iStratergyId);
	logDebug3("cOffMarketFlg        :%c:",pOE_Req->cOffMarketFlg);
	logDebug3("cProCli      :%c:",pOE_Req->cProCli);
	logDebug3("cUserType    :%c:",pOE_Req->cUserType);
	logDebug3("sRemarks     :%s:",pOE_Req->sRemarks);
	logDebug3("iMktType     :%d:",pOE_Req->iMktType);
	logDebug3("iAuctionNum  :%d:",pOE_Req->iAuctionNum);
	logDebug3("sGoodTillDaysDate    :%s:",pOE_Req->sGoodTillDaysDate);
	logDebug3("cMarkProFlag :%c:",pOE_Req->cMarkProFlag);
	logDebug3("fMarkProVal  :%f:",pOE_Req->fMarkProVal);
	logDebug3("cParticipantType     :%c:",pOE_Req->cParticipantType);
	logDebug3("sSettlor     :%s:",pOE_Req->sSettlor);
	logDebug3("cGTCFlag     :%c:",pOE_Req->cGTCFlag);
	logDebug3("cEncashFlag  :%c:",pOE_Req->cEncashFlag);
	logDebug3("sPanID       :%s:",pOE_Req->sPanID);
	logDebug3("siGrpId 	:%d:",pOE_Req->iGrpId);

	logTimestamp("Offline Order [Exit]");
}

BOOL OfflineOrderProcess(LONG32 iOrdRtrToOffOrd, LONG32 iOrdSrvToTrdRtr)
{

	logTimestamp("Entry : [OfflineOrderProcess]");

	CHAR    SndMsg[RUPEE_MAX_PACKET_SIZE],RcvMsg[RUPEE_MAX_PACKET_SIZE];
	LONG32  l_count=0;
	LONG32  iRetVal =0;
	LONG32 iMsgCode=0;

	LONG32	iFlag = 0 ;
	CHAR    BasicError[ ERROR_MSG_LEN ];
	DOUBLE64                        fOrderNo;
	DOUBLE64 fLTP = 0.00;

	LONG32  iQty = 0;
	DOUBLE64 fAmnt = 0.00;
	LONG32	iBranchId = 0;
	LONG32	iChkFlag = 0;
	CHAR    sErrorID[10];
	CHAR    sTempClOrdId[CLORDID_LEN];

	struct  ORDER_REQUEST       *pIntReqHeader;
	struct  INT_ORDERS          pOff_Ord;

	sprintf(sFileName,"%sOfflineClOrdID_%s",FILE_SEQ,sDate);
	if(access(sFileName,F_OK) == ERROR)
	{
		fClOrdID = fopen(sFileName,"wb+");

		if (fClOrdID == NULL)
		{
			logFatal("Not able to Open File");
			exit(0);
		}
		else
		{
			fprintf(fClOrdID,"100");
		}
		fclose(fClOrdID);
	}
	else
	{
		logInfo(":%s: File Already Exists",sFileName);
	}


	for(;;)
	{
		l_count = l_count+1;

		memset(sTempClOrdId,'\0' ,CLORDID_LEN);
		memset(sErrorID,'\0' ,10);
		memset (RcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset (SndMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset( &BasicError,'\0', ERROR_MSG_LEN);
		memset (&pIntReqHeader,'\0',sizeof(struct  ORDER_REQUEST));
		memset (&pOff_Ord,'\0',sizeof(struct  INT_ORDERS));
		memset(sGeneratedOrdNo,'\0', ORDER_LEN);
		iRetVal =0;

		logDebug2("**************** Offline LOOP = %d ***************",l_count);
		if((ReadMsgQ(iOrdRtrToOffOrd,&RcvMsg,RUPEE_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			logFatal("Error Read Q :Qid %d",iOrdRtrToOffOrd);
			exit(ERROR);
		}

		pIntReqHeader =(struct ORDER_REQUEST *) &RcvMsg;

		fTrim(pIntReqHeader->sSecurityId,strlen(pIntReqHeader->sSecurityId));
		fTrim(pIntReqHeader->sEntityId,strlen(pIntReqHeader->sEntityId));
		fTrim(pIntReqHeader->sClientId,strlen(pIntReqHeader->sClientId));
		fPrintAll (pIntReqHeader);

		iFlag = fGenOfflineClOrdId (&sTempClOrdId);


		if((pIntReqHeader->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY) )
		{
			sprintf(sGeneratedOrdNo,"%d%d%s%d",iGroupId,OFF_ORD_NO_START,sDate,(OFFLINE_ORD_SEQ + atoi(sTempClOrdId)));
			logDebug2("(OFFLINE_ORD_SEQ + atoi(sTempClOrdId)):%ld:",(OFFLINE_ORD_SEQ + atoi(sTempClOrdId)));
			logDebug2("GeneratedOrdNo= :%lf:",atof(sGeneratedOrdNo)); 
			pOff_Ord.fOrdNo = atof(sGeneratedOrdNo);
			pOff_Ord.iSerialNo = 1;
		}

		ChkFlag = fFwdStructMapper(pIntReqHeader,&pOff_Ord,sTempClOrdId);

		if(ChkFlag == FALSE)
		{
//			fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
			fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
			continue;
		}
		if(ChkFlag == INVALID_CLIENT_ID)
		{
//			fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
			fSendErrorToFE(pIntReqHeader, INVALID_CLIENT_ID);
			continue;
		}
		logDebug1("Mapped ORDER_REQUEST to INT_ORDERS.");
		ChkFlag = FALSE;


		if(iFlag == FALSE)
		{
			logDebug3("fGenOfflineClOrdId returned Error : generation ClOrdId");
//			fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
			fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
			continue;
		}

		/*		if(fOffOrdsBasicValidation(&pOff_Ord) == BASIC_VALIDATION_FAILED)
				{
				logFatal("Error in BasicValidation");
				fSendErrorToFrontEnd(&pOff_Ord, BASIC_VALIDATION_FAILED);
				}
				else
				{
				logDebug2("Success in BasicValidation");
				}*/
		iChkFlag =  fOffOrdsBasicValidation(&pOff_Ord) ;

		if(iChkFlag == TRUE)
		{

			logDebug2("Success in BasicValidation");
		}
		else
		{
			logFatal("Error in BasicValidation");
//			fSendErrorToFrontEnd(&pOff_Ord, BASIC_VALIDATION_FAILED);
			fSendErrorToFE(pIntReqHeader, IBASIC_VALIDATION_FAILED, 0, 0);
			continue;	/*break statement was used.07May2019 - Abhishek*/

		}


		if(pIntReqHeader->ReqHeader.cSegment == EQUITY_SEGMENT)
		{
			ChkFlag = fGetSecDetails(&pOff_Ord);	
		}
		else if((pIntReqHeader->ReqHeader.cSegment == DERIVATIVE_SEGMENT) || (pIntReqHeader->ReqHeader.cSegment ==CURRENCY_SEGMENT ))  
		{
			ChkFlag = fGetDrvSecDetails(&pOff_Ord);	
		}
		else if(pIntReqHeader->ReqHeader.cSegment == COMMODITY_SEGMENT)
		{
			ChkFlag = fGetMcxSecDetails(&pOff_Ord);	
		}
		else
		{
			logDebug2("pIntReqHeader->ReqHeader.cSegment :%c:",pIntReqHeader->ReqHeader.cSegment);
			continue;
		}
		if(ChkFlag == FALSE)
		{
			logDebug2("Error in GetSecDetails");
//			fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
			fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
			continue;
		}
		if(strcmp(pIntReqHeader->ReqHeader.sExcgId,pOff_Ord.ReqHeader.sExcgId))
		{
			 logDebug2("Error i Invalid ScripCode");
			 fSendErrorToFE(pIntReqHeader, INVALID_SEC_ID);
                         continue;
		}
		
		//check flag added to check currently offline orders are allowed or not. 
		ChkFlag = fCheckOffMktStatus(&pOff_Ord);
		logDebug2("ChkFlag :%d:",ChkFlag);
		if(ChkFlag == FALSE)
		{	
			logDebug2("Currently offline orders are not allowed.");
			fSendErrorToFE(pIntReqHeader, OFFLINE_ORDER_FAILED);
			continue;	
		}
		iMsgCode = pIntReqHeader->ReqHeader.iMsgCode;
		logDebug2("iMsgCode = %d",iMsgCode);

		switch(iMsgCode)
		{
			case TC_INT_OFF_ORDER_ENTRY:
			case TC_INT_OFF_ORDER_MODIFY:
			case TC_INT_OFF_ORDER_CANCEL:

				if((pOff_Ord.ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY) )
				{
					logDebug2("pOff_Ord.fOrdNo = :%lf:",pOff_Ord.fOrdNo);
				}
				else if((pOff_Ord.ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL) || (pOff_Ord.ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY))
				{
					logDebug2("**********************************");
					ChkFlag = FALSE;
					if(pOff_Ord.ReqHeader.cSegment == EQUITY_SEGMENT)
					{
						ChkFlag = fFetchEQSerialNo(&pOff_Ord);
					}
					else if((pOff_Ord.ReqHeader.cSegment == DERIVATIVE_SEGMENT )|| (pOff_Ord.ReqHeader.cSegment == CURRENCY_SEGMENT))
					{
						ChkFlag = fFetchDRVSerialNo(&pOff_Ord);
					}
					else if(pOff_Ord.ReqHeader.cSegment == COMMODITY_SEGMENT)
                                        {
                                                ChkFlag = fFetchMCXSerialNo(&pOff_Ord);
                                        }
					
					if(ChkFlag == FALSE)
					{
						logDebug2("Order Status Changed. Try Again");
//						fSendErrorToFrontEnd(&pOff_Ord, ORDER_STATUS_CHANGED);
						fSendErrorToFE(pIntReqHeader, RET_STAT_CHANGE);
						continue;
					}
					if(ChkFlag == ERROR){
						logDebug2("DB Error.");
//						fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
						fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
						
						continue;
					}
					if(ChkFlag == NO_MODIFICATION){
						logDebug2("Nothing Modified.");
//						fSendErrorToFrontEnd(&pOff_Ord, NOTHING_TO_MODIFY);
						fSendErrorToFE(pIntReqHeader, INOTHING_TO_MODIFY);
						continue;
					}
					if(ChkFlag == NO_OFFLINE_ORDER){
						logDebug2("Invalid Offline order modification.");
//						fSendErrorToFrontEnd(&pOff_Ord, NOTHING_TO_MODIFY);
						fSendErrorToFE(pIntReqHeader, INVALID_OFFLINE_ORDER);
						continue;
					}
					if(ChkFlag == ORDER_REJECTED ){
						logDebug2("Order is Rejected previously");
//						fSendErrorToFrontEnd(&pOff_Ord,ORDER_REJECTED );
						fSendErrorToFE(pIntReqHeader, RET_CANCEL_STAT);
						continue;
					}
					if(ChkFlag == RET_TRANSIT_STAT)
                                        {
                                        	logDebug2("Order Not Confirmed yet.");
                                                fSendErrorToFE(pIntReqHeader, RET_TRANSIT_STAT);
                                               	continue;
                                        }

					if(ChkFlag == ONLINE_INVALID_STATUS)
                                        {
                                                logDebug2("Normal Order Mod and cancelled error.");
                                                fSendErrorToFE(pIntReqHeader, ONLINE_INVALID_STATUS);
                                                continue;
                                        }

					logDebug2("*******************************");
				}	

				//if((iMsgCode == TC_INT_OFF_ORDER_MODIFY) || (iMsgCode == TC_INT_OFF_ORDER_ENTRY ) ||(iMsgCode == TC_INT_OFF_ORDER_CANCEL))
				//{

				if(pOff_Ord.ReqHeader.cSegment == EQUITY_SEGMENT)
				{
					iBranchId  = iNCmBranchId ;
				}
				else if(pOff_Ord.ReqHeader.cSegment == DERIVATIVE_SEGMENT )
				{
					iBranchId  = iNFoBranchId ;	
				}
				else if(pOff_Ord.ReqHeader.cSegment == CURRENCY_SEGMENT)
				{
					iBranchId  = iNCurBranchId ;	

				}
				else if(pOff_Ord.ReqHeader.cSegment == COMMODITY_SEGMENT)
				{
					iBranchId  = iMcxBranchId ;

				}

				if(iMktChk == TRUE)
				{
					ChkFlag = fMktStatus(&pOff_Ord);
					logDebug2("ChkFlag :%d:",ChkFlag);
					if(ChkFlag == TRUE)
					{
						logDebug2("Market is open. Offline orders are not allowed.");
						fSendErrorToFE(pIntReqHeader, OFFLINE_ORDER_ERROR);
						continue;
					}
				}

/***
					if(pOff_Ord.ReqHeader.cSegment == COMMODITY_SEGMENT)
					{
						iRetVal	= fRMSCommValidation(&pOff_Ord,DB_Con,1,&sErrorID,&iQty,&fAmnt);
					}
					else
					{
						iRetVal =  fRMSValidation(&pOff_Ord,DB_Con,iBranchId,&sErrorID,&iQty,&fAmnt) ;
					}

					if (iRetVal ==  TRUE )
					{
						logDebug2("RMSValidation returned Sucess");

					}
					else if(iRetVal== ERROR)
					{
//						fSendErrorToFrontEnd (&pOff_Ord, TRANSACTION_FAILED);
						fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
						continue;
					}
					else
					{
						logInfo ("RMSValidation FAILED -> Reason : [%s].",sErrorID);
						fSendRMSErrToFE(&pOff_Ord,&sErrorID,iQty,fAmnt);
						fSendRMSErrorToFE(&pOff_Ord,&sErrorID,iQty,fAmnt);
						mysql_rollback(DB_Con);
						continue;
					} 
	***/
				//}
				ChkFlag = FALSE;
				ChkFlag = fGetLTP(pOff_Ord.sSecId,pOff_Ord.ReqHeader.cSegment,pOff_Ord.ReqHeader.sExcgId,&fLTP);
				if(ChkFlag == TRUE)
                                {
                                	logDebug2("fLtp = %f",fLTP);
                                        pOff_Ord.fLtp = fLTP;
                                        logDebug2("pOff_Ord.fLtp = %f",pOff_Ord.fLtp);
                                }

				if ((iRetVal =  fOffline_Order_DBUpdate (&pOff_Ord,&BasicError)) == TRUE )
				{
					logDebug2("fOffline_Order_DBUpdate returned Sucess");
				}
				else
				{
					logFatal("fOffline_Order_DBUpdate FAILED -> Reason : [%s].",BasicError);
//					fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
					fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
					mysql_rollback(DB_Con);
					continue;
				}

				fSendSucessRespToFE(&pOff_Ord,iOrdSrvToTrdRtr);

				break;

			default :
				logDebug2("Received Wrong Msgcode");
//				fSendErrorToFrontEnd(&pOff_Ord, TRANSACTION_FAILED);
				fSendErrorToFE(pIntReqHeader, ITRANSACTION_FAILED);
				continue;
		}

	} /*---END OF FOR LOOP---*/
	logTimestamp("Exit : [OfflineOrderProcess]");
	return TRUE;
}


BOOL fSendSucessRespToFE(struct INT_ORDERS  *pOEReq,LONG32 sndQ)
{
	logTimestamp("Entry : [pSendSucessRespToFE]");

	struct  ORDER_RESPONSE     pOEResp;	
	memset(&pOEResp,'\0',sizeof(struct ORDER_RESPONSE));
	pOEResp.IntRespHeader.iSeqNo = pOEReq->ReqHeader.iSeqNo;
	pOEResp.IntRespHeader.iMsgLength = sizeof(struct  ORDER_RESPONSE);
	pOEResp.IntRespHeader.iErrorId = 0;
	pOEResp.IntRespHeader.iUserId = pOEReq->ReqHeader.iUserId;
	pOEResp.iLegValue      = pOEReq->iLegValue;
	pOEResp.cUserType = pOEReq->cUserType;
	pOEResp.IntRespHeader.cSource = pOEReq->ReqHeader.cSource;
	pOEResp.IntRespHeader.cSegment = pOEReq->ReqHeader.cSegment;

	strncpy(pOEResp.IntRespHeader.sExcgId,pOEReq->ReqHeader.sExcgId,EXCHANGE_LEN);

	if(pOEReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_ENTRY)
	{
		pOEResp.IntRespHeader.iMsgCode = TC_INT_OFF_ORDER_ENTRY_RSP;

	}
	else if(pOEReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_MODIFY)
	{
		pOEResp.IntRespHeader.iMsgCode=TC_INT_OFF_ORDER_MODIFY_RSP;
	}
	else if(pOEReq->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		pOEResp.IntRespHeader.iMsgCode=TC_INT_OFF_ORDER_CANCEL_RSP;
	}
	logDebug2("pOEResp.IntRespHeader.iMsgCode = %d",pOEResp.IntRespHeader.iMsgCode);
	pOEResp.cBuyOrSell = pOEReq->cBuySellInd ;
	pOEResp.iOrderType = pOEReq->iOrderType;
	strncpy(pOEResp.sSecurityId,pOEReq->sSecId,SECURITY_ID_LEN);
	strncpy(pOEResp.sEntityId,pOEReq->sEntityId,ENTITY_ID_LEN);
	strncpy(pOEResp.sClientId,pOEReq->sClientId,CLIENT_ID_LEN);
	pOEResp.fOrderNum = pOEReq->fOrdNo ;
	pOEResp.iSerialNum = pOEReq->iSerialNo;

	pOEResp.iDiscQty = pOEReq->iDiscQty;
	pOEResp.iDiscQtyRem = pOEReq->iDiscRemQty;
	pOEResp.iTotalQtyRem = pOEReq->iTotalQty;
	pOEResp.iTotalQty= pOEReq->iTotalQty;
	pOEResp.iTotalTradedQty= pOEReq->iTotalTradedQty;
	pOEResp.iMinFillQty= pOEReq->iMinFillQty;


	pOEResp.fPrice = pOEReq->fOrderPrice;
	pOEResp.fTriggerPrice = pOEReq->fTriggerPrice;
	logDebug2("pOEReq->iValidity :%d:",pOEReq->iValidity);
	pOEResp.iOrderValidity = pOEReq->iValidity;
	logDebug2("pOEResp.iOrderValidity :%d:",pOEResp.iOrderValidity);	
	pOEResp.cProductId= pOEReq->cProductId;
	pOEResp.cProCli = pOEReq->cProClient;
	pOEResp.iMktType = pOEReq->iMktType;

	strncpy(pOEResp.sPanID,pOEReq->sPanNo,INT_PAN_LEN);
	logDebug2("pOEReq->sSettlor :%s:",pOEReq->sSettlor);
	strncpy(pOEResp.sSettlor,pOEReq->sSettlor,SETTLOR_LEN);
	logDebug2("pOEResp.sSettlor :%s:",pOEResp.sSettlor);
	pOEResp.cMarkProFlag=          pOEReq->cMarkProFlag;
	pOEResp.fMarkProVal=           pOEReq->fMarkProVal;
	pOEResp.cParticipantType=      pOEReq->cParticipantType;
	pOEResp.cGTCFlag=              pOEReq->cGTCFlag;
	pOEResp.cEncashFlag=           pOEReq->cEncashFlag;
	pOEResp.cOffMarketFlg=         pOEReq->cOrderOffOn;

	logDebug2("----------Printing fSendRespToFE ------------");
	logDebug2("pOEResp.iLegValue   :%d:",pOEResp.iLegValue);
	logDebug2("pOEResp.iMsgLength :%d:",pOEResp.IntRespHeader.iMsgLength);
	logDebug2("pOEResp.iMsgCode    :%d: Ord_Req->ReqHeader.iMsgCode :%d:",pOEResp.IntRespHeader.iMsgCode,pOEReq->ReqHeader.iMsgCode);
	logDebug2("pOEResp.iUserId     :%llu:",pOEResp.IntRespHeader.iUserId);
	logDebug2("pOEResp.cSource     :%c:",pOEResp.IntRespHeader.cSource);
	logDebug2("pOEResp.cSegment    :%c:",pOEResp.IntRespHeader.cSegment);
	logDebug2("pOEResp.sSecurityId :%s:",pOEResp.sSecurityId);
	logDebug2("pOEResp.sClientId   :%s:",pOEResp.sClientId);
	logDebug2("pOEResp.cProductId  :%c:",pOEResp.cProductId);
	logDebug2("pOEResp.cBuyOrSell  :%c:",pOEResp.cBuyOrSell);
	logDebug2("pOEResp.iOrderType  :%d:",pOEResp.iOrderType);
	logDebug2("pOEResp.fOrderNum   :%.2f:",pOEResp.fOrderNum);
	logDebug2("pOEResp.iSerialNum  :%d:",pOEResp.iSerialNum);
	logDebug2("pOEResp.cUserType   :%c:",pOEResp.cUserType);
	if((WriteMsgQ(sndQ,(CHAR *)&pOEResp ,sizeof(struct ORDER_RESPONSE), 1)) != 1)
	{
		logFatal("Error Rms error sent failed ... ");
		exit(ERROR); 
	}

	logTimestamp("Exit : [fSendSucessRespToFE]");
}

BOOL    fSendErrorToFrontEnd( struct INT_ORDERS *pIntReqHeader , CHAR *sErrorId )
{
	logTimestamp("Entry : [fSendErrorToFrontEnd]");


	struct      ORDER_RESPONSE pErrorResponce;
	memset( &pErrorResponce, '\0'  ,sizeof(struct ORDER_RESPONSE));

	CHAR	sTempInstru[11];
	memset(sTempInstru,'\0',11);	
	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( sErrString,     '\0' ,DB_REASON_DESC_LEN);
	logDebug2("pIntReqHeader->ReqHeader.cSegment = %c",pIntReqHeader->ReqHeader.cSegment);
	pErrorResponce.IntRespHeader.iMsgLength = sizeof(struct ORDER_RESPONSE);
	pErrorResponce.IntRespHeader.iErrorId = 0 ;

	switch(pIntReqHeader->ReqHeader.iMsgCode)
	{
		case TC_INT_OFF_ORDER_ENTRY :
			pErrorResponce.IntRespHeader.iMsgCode  = TC_INT_OE_REJECTION;
			break;
		case TC_INT_OFF_ORDER_MODIFY :
			pErrorResponce.IntRespHeader.iMsgCode  = TC_INT_OM_REJECTION;
			break;

		case TC_INT_OFF_ORDER_CANCEL :
			pErrorResponce.IntRespHeader.iMsgCode  = TC_INT_OC_REJECTION;
			break;
		default :
			logInfo("Invalid MsgCode :%d:",pIntReqHeader->ReqHeader.iMsgCode);
			return FALSE;

	};
	pIntReqHeader->ReqHeader.iMsgCode = pErrorResponce.IntRespHeader.iMsgCode ;
	logDebug2("pErrorResponce.IntRespHeader.iMsgCode = %d ",pErrorResponce.IntRespHeader.iMsgCode);
	pErrorResponce.IntRespHeader.cSource = pIntReqHeader->ReqHeader.cSource;
	pErrorResponce.IntRespHeader.cSegment = pIntReqHeader->ReqHeader.cSegment;
	strncpy(pErrorResponce.IntRespHeader.sExcgId,pIntReqHeader->ReqHeader.sExcgId,EXCHANGE_LEN);
	strncpy(pErrorResponce.sSecurityId,pIntReqHeader->sSecId,SECURITY_ID_LEN);
	strncpy(pErrorResponce.sClientId,pIntReqHeader->sClientId,CLIENT_ID_LEN);
	pErrorResponce.cBuyOrSell = pIntReqHeader->cBuySellInd;
	pErrorResponce.cProductId = pIntReqHeader->cProductId;
	pErrorResponce.iTotalQty = pIntReqHeader->iTotalQty;
	pErrorResponce.fPrice = pIntReqHeader->fOrderPrice ;
	pErrorResponce.IntRespHeader.iUserId = pIntReqHeader->ReqHeader.iUserId;
	logDebug2("pIntReqHeader->ReqHeader.cSegment = %c",pIntReqHeader->ReqHeader.cSegment);		

	if(pIntReqHeader->ReqHeader.cSegment == EQUITY_SEGMENT)
	{
		strncpy(sTempInstru,"Equity",11);
	}
	else if(pIntReqHeader->ReqHeader.cSegment == DERIVATIVE_SEGMENT)
	{
		strncpy(sTempInstru,"Derivative",11);
	}
	else if(pIntReqHeader->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		strncpy(sTempInstru,"Currency",11);
	}
	else if(pIntReqHeader->ReqHeader.cSegment == COMMODITY_SEGMENT)
	{
		strncpy(sTempInstru,"Commodity",11);
	}
	else
	{
		logDebug2("Invalid Segment :%c:",pIntReqHeader->ReqHeader.cSegment);
		return FALSE;	
	}

	if(fFetchErrStr(sErrorId, &sErrString) == TRUE )
	{
		logDebug2("Reason is :%s:",sErrString);
	}
	else
	{
		strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);
	}
	sprintf(pErrorResponce.sReasonDesc,"%s:%s",OMS_ERR_PREFIX,sErrString);


	if(pIntReqHeader->ReqHeader.cSegment == EQUITY_SEGMENT)
	{
		if(fNseEQRMSRejInsert(pIntReqHeader,&pErrorResponce,sErrorId) == FALSE)
		{
			logFatal("Error in Insert ");
			return FALSE;
		}
		else
		{
			logDebug2("Success in Insert");
		}
	}
	else if(pIntReqHeader->ReqHeader.cSegment == COMMODITY_SEGMENT)
        {
                if(fNseMCXRMSRejInsert(pIntReqHeader,&pErrorResponce,sErrorId) == FALSE)
                {
                        logFatal("Error in Insert ");
                        return FALSE;
                }
                else
                {
                        logDebug2("Success in Insert");
                }
        }
	else if(pIntReqHeader->ReqHeader.cSegment == DERIVATIVE_SEGMENT || pIntReqHeader->ReqHeader.cSegment == CURRENCY_SEGMENT)
	{
		if(fNseDrRMSRejInsert(pIntReqHeader,&pErrorResponce,sErrorId) == FALSE)
		{
			logFatal("Error in Insert ");
			return FALSE;
		}
		else
		{
			logDebug2("Success in Insert");
		}

	}
	else
	{
		logDebug2("Invalid Segment :%c:",pIntReqHeader->ReqHeader.cSegment);
		return FALSE;
	}

	logDebug2("Basic Error Mesg send to Q= %d : User = %llu ", iOrdSrvToTrdRtr, pErrorResponce.IntRespHeader.iUserId);
	logDebug2("Going to return %d " , TRUE ) ;

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  ORDER_RESPONSE ), 1)) != TRUE  )
	{
		perror("Error:Basic error sent failed ... ");
		logDebug2(" Write Q id %d user = %llu :Error No is:%d",iOrdSrvToTrdRtr, pErrorResponce.IntRespHeader.iUserId,errno);
		exit(ERROR);
	}




	logTimestamp("Exit : [fSendErrorToFrontEnd]");
	return TRUE;

}


BOOL fSendRMSErrToFE (struct INT_ORDERS *Ord_Req, CHAR *sErrorID ,LONG32 iQty,DOUBLE64 fAmnt)
{
	logTimestamp("fSendRMSErrToFE [ENTRY}");
	struct ORDER_RESPONSE pErrorResponce;
	memset(&pErrorResponce,'\0',sizeof(struct ORDER_RESPONSE ));

	CHAR    sErrString[DB_REASON_DESC_LEN];
	memset ( &sErrString,     '\0' ,DB_REASON_DESC_LEN);
	logDebug2("SendRMSErrorToFE :%s",sErrorID);
	pErrorResponce.IntRespHeader.iMsgLength = sizeof(struct ORDER_RESPONSE);
	pErrorResponce.IntRespHeader.iErrorId = 0;

	switch(Ord_Req->ReqHeader.iMsgCode)
	{
		case TC_INT_OFF_ORDER_ENTRY :
			logDebug2("TC_INT_OFF_ORDER_ENTRY");
			pErrorResponce.IntRespHeader.iMsgCode  = TC_INT_RMS_OE_REJECTION;
			break;
		case TC_INT_OFF_ORDER_MODIFY :
			logDebug2("TC_INT_OFF_ORDER_MODIFY");
			pErrorResponce.IntRespHeader.iMsgCode  = TC_INT_RMS_OM_REJECTION;
			break;

		case TC_INT_OFF_ORDER_CANCEL :
			logDebug2("TC_INT_OFF_ORDER_CANCEL");
			pErrorResponce.IntRespHeader.iMsgCode  = TC_INT_RMS_OC_REJECTION;
			break;
		default :
			logInfo("Invalid MsgCode :%d:",Ord_Req->ReqHeader.iMsgCode);
			return FALSE;

	};
	Ord_Req->ReqHeader.iMsgCode = pErrorResponce.IntRespHeader.iMsgCode;
	logDebug2("pErrorResponce.IntRespHeader.iMsgCode = %d",pErrorResponce.IntRespHeader.iMsgCode);
	pErrorResponce.IntRespHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	pErrorResponce.IntRespHeader.iSeqNo = Ord_Req->ReqHeader.iSeqNo;
	pErrorResponce.IntRespHeader.cSource = Ord_Req->ReqHeader.cSource;
	pErrorResponce.IntRespHeader.cSegment = Ord_Req->ReqHeader.cSegment;
	strncpy(pErrorResponce.IntRespHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
	strncpy(pErrorResponce.sSecurityId,Ord_Req->sSecId,SECURITY_ID_LEN);
	strncpy(pErrorResponce.sClientId,Ord_Req->sClientId,CLIENT_ID_LEN);

	pErrorResponce.IntRespHeader.iTimeStamp       = 0;

	strncpy(pErrorResponce.sEntityId,Ord_Req->sEntityId,ENTITY_ID_LEN);

	pErrorResponce.cProductId     = Ord_Req->cProductId;
	pErrorResponce.iLegValue      = Ord_Req->iLegValue;
	pErrorResponce.cBuyOrSell     = Ord_Req->cBuySellInd;
	pErrorResponce.iOrderType     = Ord_Req->iOrderType;
	pErrorResponce.iOrderValidity = Ord_Req->iValidity;
	pErrorResponce.iDiscQty       = Ord_Req->iDiscQty;
	pErrorResponce.iDiscQtyRem    = Ord_Req->iDiscRemQty;
	pErrorResponce.iTotalQtyRem   = Ord_Req->iRemQty;
	pErrorResponce.iTotalQty      = Ord_Req->iTotalQty;
	pErrorResponce.iTotalTradedQty        = Ord_Req->iTotalTradedQty;
	pErrorResponce.iMinFillQty    = Ord_Req->iMinFillQty;
	pErrorResponce.fPrice         = Ord_Req->fOrderPrice;
	pErrorResponce.fTriggerPrice  = Ord_Req->fTriggerPrice;
	pErrorResponce.fOrderNum      = Ord_Req->fOrdNo;
	pErrorResponce.iSerialNum     = Ord_Req->iSerialNo;
	pErrorResponce.cHandleInst    = Ord_Req->cHandleInst;
	pErrorResponce.fAlgoOrderNo   = Ord_Req->fAlgoOrderNo;
	pErrorResponce.iStratergyId   = Ord_Req->iStratergyId;
	pErrorResponce.cOffMarketFlg  = Ord_Req->cOrderOffOn;
	pErrorResponce.cProCli        = Ord_Req->cProClient;


	pErrorResponce.cUserType      = Ord_Req->cUserType;
	logDebug2("Ord_Req->ReqHeader.cSource :%c:",Ord_Req->ReqHeader.cSource);

	if(fFetchErrStr(sErrorID, &sErrString) == TRUE )
	{
		logDebug2("Reason is :%s:",sErrString);
		if((strncmp(sErrorID,"E0001",5) == 0))
		{
			sprintf(sErrString,"%s %.2lf",sErrString,fAmnt);
		}
		else if((strncmp(sErrorID,"E0002",5) == 0))
		{
			sprintf(sErrString,"%s %d",sErrString,iQty);
		}
		else
		{
			logDebug2("Reason is :%s:",sErrString);
		}
	}
	else
	{
		strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);
	}
	sprintf(pErrorResponce.sReasonDesc,"%s:%.0lf:%s",RMS_ERR_PREFIX,Ord_Req->fOrdNo,sErrString);
	strncpy(pErrorResponce.sPanID,Ord_Req->sPanNo,INT_PAN_LEN);
	strncpy(pErrorResponce.sSettlor,Ord_Req->sSettlor,SETTLOR_LEN);
	pErrorResponce.cMarkProFlag=          Ord_Req->cMarkProFlag;
	pErrorResponce.fMarkProVal=           Ord_Req->fMarkProVal;
	pErrorResponce.cParticipantType=      Ord_Req->cParticipantType;
	pErrorResponce.cGTCFlag=              Ord_Req->cGTCFlag;
	pErrorResponce.cEncashFlag=           Ord_Req->cEncashFlag;

	logDebug2("----------Printing fSendRespToFE ------------");
	logDebug2("pErrorResponce.iMsgLength :%d:",pErrorResponce.IntRespHeader.iMsgLength);
	logDebug2("pErrorResponce.iMsgCode    :%d: Ord_Req->ReqHeader.iMsgCode :%d:",pErrorResponce.IntRespHeader.iMsgCode,Ord_Req->ReqHeader.iMsgCode);
	logDebug2("pErrorResponce.iLegValue :%d:",pErrorResponce.iLegValue);
	logDebug2("pErrorResponce.iUserId     :%llu:",pErrorResponce.IntRespHeader.iUserId);
	logDebug2("pErrorResponce.cSource     :%c:",pErrorResponce.IntRespHeader.cSource);
	logDebug2("pErrorResponce.cSegment    :%c:",pErrorResponce.IntRespHeader.cSegment);
	logDebug2("pErrorResponce.sSecurityId :%s:",pErrorResponce.sSecurityId);
	logDebug2("pErrorResponce.sClientId   :%s:",pErrorResponce.sClientId);
	logDebug2("pErrorResponce.cProductId  :%c:",pErrorResponce.cProductId);
	logDebug2("pErrorResponce.cBuyOrSell  :%c:",pErrorResponce.cBuyOrSell);
	logDebug2("pErrorResponce.iOrderType  :%d:",pErrorResponce.iOrderType);
	logDebug2("pErrorResponce.fOrderNum   :%.2f:",pErrorResponce.fOrderNum);
	logDebug2("pErrorResponce.iSerialNum  :%d:",pErrorResponce.iSerialNum);
	logDebug2("pErrorResponce.cUserType   :%c:",pErrorResponce.cUserType);
	logDebug2("pErrorResponce.sReasonDesc :%s:",pErrorResponce.sReasonDesc);


	if(pErrorResponce.IntRespHeader.cSegment == EQUITY_SEGMENT)
	{
		if(fNseEQRMSRejInsert(Ord_Req,&pErrorResponce,sErrorID) == FALSE)
		{
			logFatal("Error in Insert ");
			return FALSE;
		}
		else
		{
			logDebug2("Success in Insert");
		}
	}
	else if(pErrorResponce.IntRespHeader.cSegment == COMMODITY_SEGMENT)
        {
                if(fNseMCXRMSRejInsert(Ord_Req,&pErrorResponce,sErrorID) == FALSE)
                {
                        logFatal("Error in Insert ");
                        return FALSE;
                }
                else
                {
                        logDebug2("Success in Insert");
                }
        }
	else if(pErrorResponce.IntRespHeader.cSegment == DERIVATIVE_SEGMENT || pErrorResponce.IntRespHeader.cSegment == CURRENCY_SEGMENT)
	{
		if(fNseDrRMSRejInsert(Ord_Req,&pErrorResponce,sErrorID) == FALSE)
		{
			logFatal("Error in Insert ");
			return FALSE;
		}
		else
		{
			logDebug2("Success in Insert");
		}

	}
	else
	{
		logDebug2("Invalid Segment :%c:",Ord_Req->ReqHeader.cSegment);
		return FALSE;
	}

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  ORDER_RESPONSE), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendErrorToFE.");
		exit(ERROR);
	}
	logTimestamp("fSendRMSErrToFE [Exit]");
}

BOOL    fSendRMSErrorToFE(struct INT_ORDERS *Ord_Req, CHAR *sRMSErrMsg,LONG32 iQty,DOUBLE64 fAmount)
{

	logDebug2("fSendRMSErrorToFE [Entry]");
	struct INT_ERROR_FE_RESP pErrorResponce;
	CHAR    sErrorMsg[DB_REASON_DESC_LEN];

	memset(&pErrorResponce,'\0',sizeof(struct INT_ERROR_FE_RESP));
	memset(sErrorMsg,'\0',DB_REASON_DESC_LEN);
	logDebug2("ErrorToFE :-%s",sRMSErrMsg);
	pErrorResponce.IntRespHeader.iMsgLength = sizeof(struct INT_ERROR_FE_RESP);
	pErrorResponce.IntRespHeader.iErrorId   = 0;
	pErrorResponce.IntRespHeader.iMsgCode   = TC_INT_RMS_ORD_REJECTION;
	pErrorResponce.IntRespHeader.iUserId    = Ord_Req->ReqHeader.iUserId;
	pErrorResponce.IntRespHeader.iSeqNo     = Ord_Req->ReqHeader.iSeqNo;
	pErrorResponce.IntRespHeader.cSource    = SOURCE_ADMIN;//Ord_Req->ReqHeader.cSource;
	pErrorResponce.IntRespHeader.cSegment   = Ord_Req->ReqHeader.cSegment;

	strncpy(pErrorResponce.IntRespHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
	strncpy(pErrorResponce.sSecurityId,Ord_Req->sSecId,SECURITY_ID_LEN);
	strncpy(pErrorResponce.sClientId,Ord_Req->sClientId,CLIENT_ID_LEN);
	//        strncpy(pErrorResponce.sErrorMsg,sErrorMsg,ERROR_MSG_LEN);

	pErrorResponce.cBuyOrSell       = Ord_Req->cBuySellInd;
	pErrorResponce.cProductId       = Ord_Req->cProductId;
	pErrorResponce.iTotalQty        = Ord_Req->iTotalQty ;
	pErrorResponce.fPrice           = Ord_Req->fOrderPrice;

	if(fFetchErrStr(sRMSErrMsg, &sErrorMsg) == TRUE )
	{
		logDebug2("Reason is :%s:",sErrorMsg);
		if((strncmp(sRMSErrMsg,"E0001",5) == 0))
		{
			sprintf(sErrorMsg,"%s:%.2lf",sErrorMsg,fAmount);
		}
		else if((strncmp(sRMSErrMsg,"E0002",5) == 0))
		{
			sprintf(sErrorMsg,"%s:%d",sErrorMsg,iQty);
		}
		else
		{
			logDebug2("Reason is :%s:",sErrorMsg);
		}
	}
	else
	{
		strncpy(sErrorMsg,"Not Specified ",DB_REASON_DESC_LEN);
	}

	logDebug2("sErrorMsg [%s]",sErrorMsg);
	strncpy(pErrorResponce.sErrorMsg,sErrorMsg,DB_REASON_DESC_LEN);
	strncpy(pErrorResponce.sErrorCode,sRMSErrMsg,ERROR_CODE_LEN);

	logDebug2("pErrorResponce.sErrorMsg,sErrorMsg [%s]",pErrorResponce.sErrorMsg,sErrorMsg);
	logDebug2("pErrorResponce.sErrorCode    [%s]",pErrorResponce.sErrorCode);
	logDebug2("Ord_Req->ReqHeader.cSource :%c:",Ord_Req->ReqHeader.cSource);
	logDebug2("ErrorResponce.IntRespHeader.cSource %c",pErrorResponce.IntRespHeader.cSource);
	logDebug2("ErrorResponce.IntRespHeader.sExcgId %s",pErrorResponce.IntRespHeader.sExcgId);

	if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
	{
		logFatal("Error : WriteMsgQ failed in SendRMSErrorToFE.");
		exit(ERROR);
	}

	logDebug2("SendRMSErrorToFE [EXIT]");

}


BOOL  fOffline_Order_DBUpdate(struct INT_ORDERS * p_Req_in, char * p_Req_out)
{
	logTimestamp("Entry : [fOffline_Order_DBUpdate]");
		
	logDebug2("p_Req_in->ReqHeader.cSegment :%c:",p_Req_in->ReqHeader.cSegment);
	
	if(p_Req_in->ReqHeader.cSegment == SEGMENT_EQUITY)
	{
		if(NSEEQInsert(p_Req_in) == FALSE)
		{
			logDebug2("Error in Insert ORDERS.");
			fSendErrorToFrontEnd(&p_Req_in, TRANSACTION_FAILED);
			return FALSE;                
		}
	}	
	else if(p_Req_in->ReqHeader.cSegment == SEGMENT_FNO || p_Req_in->ReqHeader.cSegment == SEGMENT_CURRENCY)
	{
		if(NSEDRVInsert(p_Req_in) == FALSE)
		{
			logDebug2("Error in Insert ORDERS.");
			fSendErrorToFrontEnd(&p_Req_in, TRANSACTION_FAILED);
			return FALSE;
		}
	}
	else if(p_Req_in->ReqHeader.cSegment == COMMODITY_SEGMENT)
	{
		if(NSEMCXInsert(p_Req_in) == FALSE)
		{
			logDebug2("Error in Insert ORDERS.");
			fSendErrorToFrontEnd(&p_Req_in, TRANSACTION_FAILED);
			return FALSE;
		}
	}

	else
	{
		logFatal("Invalid Segment so returning false");
		return FALSE;
	}

	logTimestamp("Exit : [fOffline_Order_DBUpdat]");
	return TRUE;
}


BOOL fFwdStructMapper(struct ORDER_REQUEST *Ord_Req,struct INT_ORDERS *Ins_Req,CHAR *sTempClOrdId )
{
	logTimestamp("Entry : [fFwdStructMapper]");	
	LONG32	iFlag;
	CHAR sClOrdId   [CLORDID_LEN];
	CHAR sGoodTillDatetime[DB_DATETIME_LEN];
	CHAR sPan[INT_PAN_LEN];
	CHAR sAccCode[DB_CLIENT_ID_LEN];
	memset ( sClOrdId,      '\0' ,CLORDID_LEN);
	memset ( sGoodTillDatetime,      '\0' ,DB_DATETIME_LEN);
	memset ( sPan,      '\0' ,INT_PAN_LEN);
	memset ( sAccCode,      '\0' ,DB_CLIENT_ID_LEN);
	Ins_Req->ReqHeader.iSeqNo = Ord_Req->ReqHeader.iSeqNo;
	Ins_Req->ReqHeader.iMsgLength = Ord_Req->ReqHeader.iMsgLength;
	Ins_Req->ReqHeader.iMsgCode = Ord_Req->ReqHeader.iMsgCode;
	logDebug2("Ins_Req->ReqHeader.iMsgCode = %d",Ins_Req->ReqHeader.iMsgCode);
	strncpy(Ins_Req->ReqHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
	Ins_Req->ReqHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	Ins_Req->ReqHeader.cSource = Ord_Req->ReqHeader.cSource;
	Ins_Req->ReqHeader.cSegment = Ord_Req->ReqHeader.cSegment;
	Ord_Req->cOffMarketFlg = OFF_ORD_ENABLE ;


	if(Ord_Req->ReqHeader.iMsgCode ==  TC_INT_OFF_ORDER_MODIFY || Ord_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		Ins_Req->fOrdNo = Ord_Req->fOrderNum;
	}
	else
	{
		logDebug2("Ins_Req->fOrdNo = :%lf:",Ins_Req->fOrdNo);
	}
	Ins_Req->iLegValue  	= LEG_1 ;	
	Ins_Req->iSerialNo 	= Ord_Req->iSerialNum;
	strncpy(Ins_Req->sSecId,Ord_Req->sSecurityId,DB_SECURITY_ID_LEN);
	strncpy(Ins_Req->sEntityId,Ord_Req->sEntityId,DB_ENTITY_ID_LEN);
	logDebug2("Ins_Req->sEntityId :%s:",Ins_Req->sEntityId);
	strncpy(Ins_Req->sExchOrdNo,"0",DB_EXCH_ORD_NO_LEN);
	strncpy(Ins_Req->sClientId,Ord_Req->sClientId,DB_CLIENT_ID_LEN);
	logDebug2("Ins_Req->sClientId:%s:",Ins_Req->sClientId);
	Ins_Req->cBuySellInd 	= Ord_Req->cBuyOrSell;
	if(Ord_Req->ReqHeader.iMsgCode == TC_INT_OFF_ORDER_CANCEL)
	{
		Ins_Req->cOrdStatus     = EXCH_DELETE_STATUS ;	
	}
	else
	{
		Ins_Req->cOrdStatus 	= EXCH_CONFIRM_STATUS;
	}
	logDebug2("Ins_Req->cOrdStatus :%c:",Ins_Req->cOrdStatus);
	strncpy(Ins_Req->sEntryDate,"now()",DB_DATETIME_LEN);
	strncpy(Ins_Req->sOrderTime,"\0",DB_DATETIME_LEN);
	Ins_Req->iTotalQty 	= Ord_Req->iTotalQty;
	logDebug2("Ord_Req->iTotalQty :%d:",Ord_Req->iTotalQty);
	logDebug2("Ins_Req->iTotalQty :%d:",Ins_Req->iTotalQty );
	Ins_Req->iRemQty 	= Ord_Req->iTotalQtyRem;
	Ins_Req->iDiscQty 	= Ord_Req->iDiscQty;
	Ins_Req->iDiscRemQty 	= Ord_Req->iDiscQtyRem;
	Ins_Req->iTotalTradedQty = Ord_Req->iTotalTradedQty;
	Ins_Req->fOrderPrice 	= Ord_Req->fPrice;
	Ins_Req->fTriggerPrice 	= Ord_Req->fTriggerPrice;
	Ins_Req->iValidity 	= Ord_Req->iOrderValidity;
	Ins_Req->iOrderType 	= Ord_Req->iOrderType;
	Ins_Req->iGoodTillDaysFlg = 0;
	if(Ins_Req->iValidity == VALIDITY_GTD)
        {
                sprintf(Ins_Req->sGoodTillDaysDate,"%s",Ord_Req->sGoodTillDaysDate);
        }
        else
        {
                fFetchNextSchDate(Ord_Req,&sGoodTillDatetime);
                strncpy(Ins_Req->sGoodTillDaysDate,sGoodTillDatetime,DB_DATETIME_LEN);
        }
//	strncpy(Ins_Req->sGoodTillDaysDate,"2015-05-13 21:01:57",DB_DATETIME_LEN);
	//strncpy(Ins_Req->sAccCode,Ord_Req->sClientId,DB_CLIENT_ID_LEN);
        iFlag = fFetchData(Ord_Req,&sPan,&sAccCode); ///Is Use to fetch the pan and account code of client.
	if(iFlag == INVALID_CLIENT_ID)
	{
		return INVALID_CLIENT_ID;
	}
	strncpy(Ins_Req->sAccCode,sAccCode,DB_CLIENT_ID_LEN);
	strncpy(Ins_Req->sPanNo,sPan,INT_PAN_LEN);
	Ins_Req->iMinFillQty 	= Ord_Req->iMinFillQty;
	Ins_Req->cProClient 	= Ord_Req->cProCli;
	strncpy(Ins_Req->sRemarks,Ord_Req->sRemarks,OE_REMARKS_LEN);
	strncpy(Ins_Req->sPlatform,Ord_Req->sPlatform,PLATFORM_LEN);
	strncpy(Ins_Req->sChannel,Ord_Req->sChannel,CHANNEL_LEN);
	Ins_Req->cUserType 	= Ord_Req->cUserType;
	Ins_Req->cOrderOffOn 	= Ord_Req->cOffMarketFlg;
	Ins_Req->cProductId 	= Ord_Req->cProductId;
	strncpy(Ins_Req->sUserInfo,"\0",DB_USER_INFO_LEN);
	Ins_Req->iGrpId 	= Ord_Req->iGrpId;
	Ins_Req->iReasonCode 	= 0;
	strncpy(Ins_Req->sReasonDesc,"\0",DB_REASON_DESC_LEN);
	Ins_Req->iExchTrdNo 	= -1;
	Ins_Req->iTrdSerialNo 	= 0;
	Ins_Req->iTrdTransCode 	= 0;
	Ins_Req->cTrdStatus 	= EXCH_CONFIRM_STATUS;
	Ins_Req->iLstTrdQty 	= 0;
	Ins_Req->fTrdPrice 	= 0;
	strncpy(Ins_Req->sTrdTime,"2015-05-13 21:01:57",DB_DATETIME_LEN);
	Ins_Req->iTrdSeqNo 	= 0;
	Ins_Req->cHandleInst 	= Ord_Req->cHandleInst;
	Ins_Req->fAlgoOrderNo 	= Ord_Req->fAlgoOrderNo;
	Ins_Req->iStratergyId 	= Ord_Req->iStratergyId;
	if(Ord_Req->cUserType == CLIENT_TYPE || Ord_Req->cUserType == SUPER_ADMIN || Ord_Req->cUserType == ADMIN_TYPE)
	{
		if(Ord_Req->ReqHeader.cSource == SOURCE_MOBILE)
		{
			strncpy(Ins_Req->sLocCode,USER_INFO_MOBILE,TERMINAL_INFO_LEN);
			logDebug2("Ins_Req->sLocCode.. = %s",Ins_Req->sLocCode);
		}
		else
		{
			strncpy(Ins_Req->sLocCode,USER_INFO_ONLINE,TERMINAL_INFO_LEN);
			logDebug2("Ins_Req->sLocCode = %s",Ins_Req->sLocCode);
		}
	}

	//strncpy(Ins_Req->sClOrdId,sTempClOrdId,CLORDID_LEN);
	strncpy(Ins_Req->sClOrdId,"90",CLORDID_LEN);
	strncpy(Ins_Req->sOrigClOrdId,"\0",CLORDID_LEN);
	Ins_Req->iMktType = Ord_Req->iMktType;
	
	logDebug2("sSettlor :%s:",sSettlor);
	
/*	if(Ord_Req->cParticipantType == 'B')
        {
                strncpy(Ins_Req->sSettlor, sSettlor,SETTLOR_LEN);
        }
        else
        {
                strncpy(Ins_Req->sSettlor, Ord_Req->sSettlor,SETTLOR_LEN);
        }
*/
	if(!strcmp(Ord_Req->sSettlor,""))
        {
                strncpy(Ins_Req->sSettlor, sSettler,SETTLOR_LEN);
        }
        else
        {
                strncpy(Ins_Req->sSettlor, Ord_Req->sSettlor,SETTLOR_LEN);
        }

		
	logDebug2("sSettlor :%s:",Ins_Req->sSettlor);	

	//strncpy(Ins_Req->sPanNo,Ord_Req->sPanID,INT_PAN_LEN);
	Ins_Req->iAlgoID        = 0;
	Ins_Req->iAlgoCat       = 0;
	Ins_Req->cCrossCurFlag= NO;

	Ins_Req->fRBIRefRate= 1.00;

	Ins_Req->cMarkProFlag=          Ord_Req->cMarkProFlag;
	Ins_Req->fMarkProVal=           Ord_Req->fMarkProVal;
	Ins_Req->cParticipantType=      Ord_Req->cParticipantType;
	Ins_Req->cGTCFlag=              Ord_Req->cGTCFlag;
	Ins_Req->cEncashFlag=           Ord_Req->cEncashFlag;
	logTimestamp(" EXIT : [fFwdStructMapper]");
	return TRUE;
}


BOOL    fGenOfflineClOrdId(CHAR *sClOrdId)
{
	logTimestamp("fGenOfflineClOrdId [Entry]");
	CHAR    sTempClOrdId[CLORDID_LEN];

	fClOrdID =fopen(sFileName,"rb+");
	LONG64 iTempSeq;

	if(fClOrdID == NULL)
	{
		logFatal("Not Able to Open File");
		logDebug2("Assigning Temporary value 0 to sTempClOrdId");
		sprintf(sTempClOrdId,"%d",0);
		return FALSE ;
	}
	else
	{
		while(!feof(fClOrdID))
		{
			memset(sTempClOrdId, '\0', CLORDID_LEN); // clean buffer
			fscanf(fClOrdID, "%[^\n]\n",sTempClOrdId);
		}
		logDebug2("Last Line :: %s",sTempClOrdId);
	}

	iTempSeq = atoi(sTempClOrdId);
	iTempSeq++;

	fprintf(fClOrdID,"\n%i",iTempSeq);
	sprintf(sClOrdId,"%s",sTempClOrdId);
	fclose(fClOrdID);


	logTimestamp("fGenOfflineClOrdId [Exit]");
}

BOOL    fSendErrorToFE(struct ORDER_REQUEST *Ord_Req, LONG32 iErrorId,LONG32 iQty,DOUBLE64 fPrice)
{

        logTimestamp ("fSendErrorToFE [ENTRY]");
        struct INT_ERROR_FE_RESP pErrorResponce;
	CHAR    sErrString[DB_REASON_DESC_LEN];
        
	memset(sErrString,'\0',DB_REASON_DESC_LEN);
        memset(&pErrorResponce,'\0',sizeof(struct INT_ERROR_FE_RESP));

        logDebug2("pOE_Req->ReqHeader.cSource  :%c:",Ord_Req->ReqHeader.cSource);
        logDebug2("Ord_Req->ReqHeader.sExcgId   :%s:",Ord_Req->ReqHeader.sExcgId);
        logDebug2("Ord_Req->sSecurityId         :%s:",Ord_Req->sSecurityId);
        logDebug2("Ord_Req->sClientId           :%s:",Ord_Req->sClientId);
        logDebug2("Ord_Req->ReqHeader.iUserId   :%llu:",Ord_Req->ReqHeader.iUserId);

        pErrorResponce.IntRespHeader.iSeqNo     = Ord_Req->ReqHeader.iSeqNo;
        pErrorResponce.IntRespHeader.iMsgLength         = sizeof(struct INT_ERROR_FE_RESP);
        pErrorResponce.IntRespHeader.iErrorId           = iErrorId;
        pErrorResponce.IntRespHeader.iMsgCode           = TC_INT_ORDER_REJECTION;
        pErrorResponce.IntRespHeader.cSource            = Ord_Req->ReqHeader.cSource;
        pErrorResponce.IntRespHeader.cSegment           = Ord_Req->ReqHeader.cSegment;
        strncpy(pErrorResponce.IntRespHeader.sExcgId,Ord_Req->ReqHeader.sExcgId,EXCHANGE_LEN);
        strncpy(pErrorResponce.sSecurityId,Ord_Req->sSecurityId ,SECURITY_ID_LEN);
        strncpy(pErrorResponce.sClientId,Ord_Req->sClientId,CLIENT_ID_LEN);

        pErrorResponce.cBuyOrSell       =       Ord_Req->cBuyOrSell;
        pErrorResponce.cProductId       =       Ord_Req->cProductId;
        pErrorResponce.iTotalQty        =       iQty;
        pErrorResponce.fPrice           =       fPrice;
        pErrorResponce.IntRespHeader.iUserId = Ord_Req->ReqHeader.iUserId;
	logDebug2("pErrorResponce.IntRespHeader.iMsgLength :%d:",pErrorResponce.IntRespHeader.iMsgLength);
	
	if(fFetchOMSErrStr(iErrorId, &sErrString) == TRUE )
        {
                strncpy(pErrorResponce.sErrorMsg,sErrString,DB_REASON_DESC_LEN);
                logDebug2("Error Message :%s:",pErrorResponce.sErrorMsg);
                sprintf(pErrorResponce.sErrorCode,"%d",iErrorId);
                logDebug2("Error Message :%s:",pErrorResponce.sErrorMsg);
        }
        else
        {
                strncpy(sErrString,"Error Occured Please Contact System Administrator",DB_REASON_DESC_LEN);
                sprintf(pErrorResponce.sErrorCode,"%d",iErrorId);
        }
        logDebug2("pErrorResponce.IntRespHeader.iMsgLength :%d:",pErrorResponce.IntRespHeader.iMsgLength);

        /**if(iErrorId ==     ITRANSACTION_FAILED)
        {
                strncpy(pErrorResponce.sErrorMsg,"Transaction Fails",ERROR_MSG_LEN);
        }
        else  if(iErrorId ==     INOT_CONNECTED_TO_EXCH)
        {
                sprintf(pErrorResponce.sErrorMsg,"System is not connected to %s Equity market",pErrorResponce.IntRespHeader.sExcgId);
        }
        else if(iErrorId ==     RET_STAT_CHANGE)
        {
                strncpy(pErrorResponce.sErrorMsg,"Order Status Changed. Try Again",ERROR_MSG_LEN);
        }
        else  if(iErrorId ==     RET_TRADED_STAT)
        {
                strncpy(pErrorResponce.sErrorMsg,"Order Has Traded.Please refresh your OrderBook",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  RET_TRANSIT_STAT )
        {
                strncpy(pErrorResponce.sErrorMsg,"Order Still in Transit.Kindly refresh your OrderBook",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  RET_REJECT_STAT)
        {
                strncpy(pErrorResponce.sErrorMsg,"Order is Rejected.Kindly refresh your OrderBook",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  RET_CANCEL_STAT)
        {
                strncpy(pErrorResponce.sErrorMsg,"Order is Cancelled.Kindly refresh your OrderBook",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  RET_FREEZE_STAT)
        {
                strncpy(pErrorResponce.sErrorMsg,"Order has been Freezed.Kindly refresh your OrderBook",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  RET_EXPIRED_STAT)
        {
                strncpy(pErrorResponce.sErrorMsg,"Order has been Expired.Kindly refresh your OrderBook",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  IBASIC_VALIDATION_FAILED)
        {
                strncpy(pErrorResponce.sErrorMsg,"Basic Validation Fails",ERROR_MSG_LEN);
        }
        else if(iErrorId ==  INOTHING_TO_MODIFY)
        {
                strncpy(pErrorResponce.sErrorMsg,"Nothing to Modify",ERROR_MSG_LEN);
        }
	//error msg for offline order.06May2019 -Abhishek
	else if(iErrorId == OFFLINE_ORDER_FAILED)
	{
		strncpy(pErrorResponce.sErrorMsg,"Offline market is blocked at global level",ERROR_MSG_LEN);
	}
        else if(iErrorId == OFFLINE_ORDER_ERROR)
        {
                strncpy(pErrorResponce.sErrorMsg,"Market is open .Offline orders are not allowed",ERROR_MSG_LEN);
        }
        else
        {
                strncpy(pErrorResponce.sErrorMsg,"Error Occured Please Contact System Administrator",ERROR_MSG_LEN);
        }**/
        logDebug2("pErrorResponce.sErrorMsg :%s:",pErrorResponce.sErrorMsg);
        if((WriteMsgQ(iOrdSrvToTrdRtr,(CHAR *)&pErrorResponce , sizeof(struct  INT_ERROR_FE_RESP), 1)) != TRUE  )
        {
                logFatal("Error : WriteMsgQ failed in fSendErrorToFE.");
                exit(ERROR);
        }

        logTimestamp ("fSendErrorToFE [EXIT]");
}
//New Fuction is created for checking market status whether Offline order is enable or disable. 
BOOL fCheckOffMktStatus(struct INT_ORDERS *pRes)
{
	logTimestamp("Entry : [fCheckOffMktStatus]");
	
	CHAR	sSelQry [MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	CHAR	cMktStatus;
	LONG32	iMktType = 1;
	
	logDebug2("SEGMENT	: %c",pRes->ReqHeader.cSegment);
	logDebug2("EXCHNAGE	: %s",pRes->ReqHeader.sExcgId);
	
	
	if(strcmp(pRes->ReqHeader.sExcgId,MCX_EXCH)==0)
	{
		sprintf(sSelQry,"Select BP_OFF_MKT_STATUS from BATCH_PROCESS where BP_BATCH_NAME = 'OFFMKT_PUMP' and BP_EXCH_ID= \"%s\" \
				and BP_SEGMENT= \'%c\' and BP_MKT_TYPE_NO=\"%s\";",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,pRes->sSeries);
	}
	else
	{
		sprintf(sSelQry,"Select BP_OFF_MKT_STATUS from BATCH_PROCESS where BP_BATCH_NAME = 'OFFMKT_PUMP' and BP_EXCH_ID= \"%s\" \
                                and BP_SEGMENT= \'%c\' and BP_MKT_TYPE_NO=\"%d\";",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,iMktType);
	}
	

	logDebug2("sSelQry = %s",sSelQry);

        if (mysql_query(DB_Con, sSelQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry1");
                sql_Error(DB_Con);
                return FALSE;
        }
        Res = mysql_store_result(DB_Con);

        if((Row = mysql_fetch_row(Res)))
        {	
		logDebug2("Row fetched from batch process");
		cMktStatus = Row[0][0];
        	logDebug2("cMktStatus = %c",cMktStatus);
        }
	else	
	{
		logDebug2(" No row fetched from batch process");
                return FALSE;
		
	}

	if(cMktStatus == NO)
        {
		return FALSE;
	}
        
        logTimestamp("Exit : fCheckOffMktStatus");
        return TRUE;
}

//To check market is open or closed @Abhishek-9June2019
BOOL fMktStatus(struct INT_ORDERS *pRes)
{
        logTimestamp("Entry : [fMktStatus]");

        CHAR    sSelQry [MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);

        LONG32    iMktStat;
        LONG32  iMktType = 1;

        logDebug2("SEGMENT      : %c",pRes->ReqHeader.cSegment);
        logDebug2("EXCHNAGE     : %s",pRes->ReqHeader.sExcgId);


        if(strcmp(pRes->ReqHeader.sExcgId,MCX_EXCH)==0)
        {
                sprintf(sSelQry,"Select EMM_STATUS from EXCH_MKT_MASTER where EMM_EXM_EXCH_ID = \"%s\" \
                                and EMM_EXCH_SEG= \'%c\' and EMM_MKT_TYPE_NO=\"%s\";",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,pRes->sSeries);
        }
        else
        {
                sprintf(sSelQry,"Select EMM_STATUS from EXCH_MKT_MASTER where EMM_EXM_EXCH_ID = \"%s\" \
                                and EMM_EXCH_SEG= \'%c\' and EMM_MKT_TYPE_NO=\"%d\";",pRes->ReqHeader.sExcgId,pRes->ReqHeader.cSegment,iMktType);
        }


        logDebug2("sSelQry = %s",sSelQry);

        if (mysql_query(DB_Con, sSelQry) != SUCCESS)
        {
                logSqlFatal("Error in select Qry1");
                sql_Error(DB_Con);
                return FALSE;
        }
        Res = mysql_store_result(DB_Con);

        if((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Row fetched from Exch Market status");
                iMktStat = atoi(Row[0]);
                logDebug2("iMktStat = %d",iMktStat);
        }
	else
        {
                logDebug2(" No row fetched from Exch Market status");
                return FALSE;

        }

	if(iMktStat == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	mysql_free_result(Res);
        logTimestamp("Exit : fMktStatus");
}

BOOL fGetLTP(CHAR *sSecId,CHAR *cSegment,CHAR *sExchId ,DOUBLE64 *fLTP)
{
        logTimestamp("Entry  fGetLTP ");
        CHAR    sSelDrp [MAX_QUERY_SIZE];
        memset(sSelDrp,'\0',MAX_QUERY_SIZE);
        redisReply *reply;

        sprintf(sSelDrp,"HMGET %s:%s%c%s %s",SET_L1_WATCH,sExchId,cSegment,sSecId,SM_LTP);
        logDebug2("sSelDrp :%s:",sSelDrp);
	reply = fRedisCommand(RdConSt,sSelDrp,REDIS_TYPE_PRICE_BCAST);

        if(reply->element[0]->str == NULL)
        {
                *fLTP =0;
        }
        else
        {
                *fLTP = atof(reply->element[0]->str);
        }
        logTimestamp("Exit  [fGetLTP]");
        return TRUE;
}

