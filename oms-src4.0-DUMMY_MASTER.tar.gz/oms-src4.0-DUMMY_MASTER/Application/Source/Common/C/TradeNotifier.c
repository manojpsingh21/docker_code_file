#include "HashTable.h"
#include "IPCS.h"
#include <my_global.h>
#include <mysql.h>
#include "hiredis.h"

redisContext *RdConn;
INT16	iSleep = 0 ;
CHAR sTradeSmsNotfUrl[URL_LEN];
CHAR sTradeMailNotfUrl[URL_LEN];
CHAR sTradeTPushNotfUrl[URL_LEN];
BOOL fLoadNotifyEnv();
	

main (int argv,char *argc[])
{
	logTimestamp("ENTRY [Main]");
	setbuf(stdout,0);

	RdConn = RDConnect();
	
	iSleep = atoi(argc[1]);
	fLoadNotifyEnv();	
	ProcessUrl();			
	
	logTimestamp("EXIT [Main]");
}


BOOL	ProcessUrl()
{
	logTimestamp("ENTRY [ProcessUrl]");
	
	CHAR    sMembers[MAX_QUERY_SIZE];
	CHAR    sGetKey[MAX_QUERY_SIZE];
	CHAR    sClientName[DB_SCHM_NAME_LEN];
	CHAR    sClientNameFix[DB_SCHM_NAME_LEN];
	redisReply	*SmemReply;
	redisReply	*HmgetReply;
	LONG32		iCount=0, i = 0;
	CHAR sOrdString[MAX_COMMAND_LEN];
        CHAR sOrdStringUrl[MAX_COMMAND_LEN +15 ];
	CHAR sCommand[MAX_COMMAND_LEN];
	INT16	c = 0, a = 0 ;	
	INT16	m = 0, n = 0 ;
	CHAR	sSymbol[NOTI_SYMBOL_LEN];	
	CHAR	sSymbolfix[NOTI_SYMBOL_LEN];	
	
	while(TRUE)
	{
		memset(sMembers,'\0',MAX_QUERY_SIZE);



		sprintf(sMembers,"SMEMBERS TRADE:NOTIFY ")	;
		
		SmemReply = redisCommand(RdConn,sMembers);
	
		iCount = SmemReply->elements;

		for(i= 0 ; i < iCount; i ++)
		{
			c = 0;
			a = 0;
			m = 0;
			n = 0;
			memset(sOrdString,'\0',MAX_COMMAND_LEN);
			memset(sCommand,'\0',MAX_COMMAND_LEN);
			memset(sOrdStringUrl,'\0',MAX_COMMAND_LEN + 15);
			memset(sGetKey,'\0',MAX_QUERY_SIZE);
			memset(sClientName,'\0',DB_SCHM_NAME_LEN);
			memset(sClientNameFix,'\0',DB_SCHM_NAME_LEN);
			memset(sSymbol,'\0',NOTI_SYMBOL_LEN);
			memset(sSymbolfix,'\0',NOTI_SYMBOL_LEN);
			sprintf(sGetKey," HMGET %s   CLIENTNAME    CLIENTID    EMAIL    TYPE    NUMBER    PAN    SEGMENT   PRICE    QTY    EXCHANGE    SCRIPTNAME    BUYSELL    ORDERNUMB  TRADENUMB    SOURCE    USERTYPE INSTRUMENT PARTQTY FINALPRICE MULTIPLIER NOTI_FLAG ",SmemReply->element[i]->str);
			logInfo("sGetKey :%s:", sGetKey);
			HmgetReply = redisCommand(RdConn,sGetKey);
			logInfo("CLIENTNAME :%s:",HmgetReply->element[0]->str);
			logInfo("Client Id :%s:",HmgetReply->element[1]->str);

			if(HmgetReply->element[0]->str != NULL)
			{
				logInfo("CLIENTNAME :%s:",HmgetReply->element[0]->str);

				strncpy(sClientName,HmgetReply->element[0]->str,strlen(HmgetReply->element[0]->str));

				logDebug3("sClientName :%s:",sClientName);

				for(m =0; m<= strlen(sClientName); m++, n++)
                                {
                                        if(sClientName[m]=='_')     
                                        {          
						sClientNameFix[n] = ' ';
                                        }
                                        else
                                        {
                                                sClientNameFix[n] = sClientName[m];
                                        }


                                }
				logDebug3("sClientNameFix :%s:",sClientNameFix);
				m=0;
				n=0;
				strncpy(sSymbol,HmgetReply->element[10]->str,strlen(HmgetReply->element[10]->str));
				logDebug3("sSymbol 	:%s:",sSymbol);
				for(m =0; m<= (strlen(sSymbol) + 3) ; m++, n++)
			        {
                			if(sSymbol[m]=='&')
                			{
                        			strncpy(sSymbolfix+n,"%26",3);
                        			n = n + 2;
                			}
                			else
                			{
                        			sSymbolfix[n] = sSymbol[m];
                			}


        			}
        			logDebug3("Final sSymbolfix :%s:",sSymbolfix);

				


				sprintf(sOrdString,"clientName=%s&clientId=%s&passwd=&email=%s&type=%s&number=%s&pan=%s&segment=%s&price=%s&qty=%s&exchange=%s&scriptName=%s&buysell=%s&ordernumb=%s&tradenumb=%s&source=%s&usertype=%s&instrument=%s&partqty=%s&finalprice=%s&multiplier=%s",sClientNameFix,HmgetReply->element[1]->str,HmgetReply->element[2]->str,HmgetReply->element[3]->str,HmgetReply->element[4]->str,HmgetReply->element[5]->str,HmgetReply->element[6]->str,HmgetReply->element[7]->str,HmgetReply->element[8]->str,HmgetReply->element[9]->str,sSymbolfix,HmgetReply->element[11]->str,HmgetReply->element[12]->str,HmgetReply->element[13]->str,HmgetReply->element[14]->str,HmgetReply->element[15]->str,HmgetReply->element[16]->str,HmgetReply->element[17]->str,HmgetReply->element[18]->str,HmgetReply->element[19]->str );

                		logInfo(" sOrdString ->:%s:",sOrdString);

                		for(a =0; a< MAX_COMMAND_LEN; a++, c++)
                		{
                		        if(sOrdString[a]==' ')     //case used to find space in sOrdString
                		        {               //Replacing space with %20 in sOrdStringUrl
                        		        sOrdStringUrl[c] = '%';
                               	 		c++;
                               	 		sOrdStringUrl[c] = '2';
                                		c++;
                                		sOrdStringUrl[c] = '0';
                        		}
                        		else
                        		{
                        		        sOrdStringUrl[c] = sOrdString[a];
                        		}


                		}
				logInfo("sOrdStringUrl :%s:",sOrdStringUrl);
				
				if(HmgetReply->element[20]->str[0] == 'S')
				{	
					logDebug2("[Sending SMS]");	
					memset(sCommand,'\0',MAX_COMMAND_LEN);
					sprintf(sCommand,"curl -m 5 -X GET \"%s\?%s\" ",sTradeSmsNotfUrl,sOrdStringUrl);
					logTimestamp("SMS Command :%s:",sCommand);
					system(sCommand);
				}
				else if (HmgetReply->element[20]->str[0] == 'M')
				{
					logDebug2("[Sending Mail]");

					memset(sCommand,'\0',MAX_COMMAND_LEN);
                                        sprintf(sCommand,"curl -m 5 -X GET \"%s\?%s\" ",sTradeMailNotfUrl,sOrdStringUrl);
                                        logTimestamp("Mail Command :%s:",sCommand);
                                        system(sCommand);
				}
                                else if (HmgetReply->element[20]->str[0] == 'P')
                                {
                                        memset(sCommand,'\0',MAX_COMMAND_LEN);
                                        sprintf(sCommand,"curl -m 5 -X GET \"%s\?%s\" ",sTradeTPushNotfUrl,sOrdStringUrl);
                                        logTimestamp("TPush Command :%s:",sCommand);
                                        system(sCommand);
                                }

			}	
			freeReplyObject(HmgetReply);
			memset(sGetKey,'\0',MAX_QUERY_SIZE);
                        sprintf(sGetKey,"SREM TRADE:NOTIFY %s ",SmemReply->element[i]->str);
                        logInfo("sGetKey :%s:", sGetKey);
                        HmgetReply = redisCommand(RdConn,sGetKey);			
			freeReplyObject(HmgetReply);
			
			memset(sGetKey,'\0',MAX_QUERY_SIZE);
                        sprintf(sGetKey,"HDEL %s ",SmemReply->element[i]->str);
                        logInfo("sGetKey :%s:", sGetKey);
                        HmgetReply = redisCommand(RdConn,sGetKey);			
			freeReplyObject(HmgetReply);
		}	
		
		
		sleep(iSleep);			
	
		
	}

	logTimestamp("ENTRY [ProcessUrl]");

}

BOOL fLoadNotifyEnv()
{
        logTimestamp("********ENTRY: fLoadNotifyEnv ***********");
        CHAR            sNotiFyVal         [ENV_VARIABLE_LEN];

        memset(sNotiFyVal,'\0',ENV_VARIABLE_LEN);
	if(getenv("SMS_URL_NOTIFY")== NULL) // Sms URL @pratik
        {
                strncpy(sTradeSmsNotfUrl,"NO_VAL",URL_LEN);
                logFatal("Error : Environment variables missing : SMS_URL_NOTIFY");
        }
        else
        {
                strncpy(sTradeSmsNotfUrl,getenv("SMS_URL_NOTIFY"),URL_LEN);
        }

        if(getenv("MAIL_URL_NOTIFY")== NULL) // Mail URL @pratik
        {
                strncpy(sTradeMailNotfUrl,"NO_VAL",URL_LEN);
                logFatal("Error : Environment variables missing : MAIL_URL_NOTIFY");
        }
        else
        {
                strncpy(sTradeMailNotfUrl,getenv("MAIL_URL_NOTIFY"),URL_LEN);
        }

        if(getenv("TPUSH_URL_NOTIFY")== NULL) 
        {
                strncpy(sTradeTPushNotfUrl,"NO_VAL",URL_LEN);
                logFatal("Error : Environment variables missing : TPUSH_URL_NOTIFY");
        }
        else
        {
                strncpy(sTradeTPushNotfUrl,getenv("TPUSH_URL_NOTIFY"),URL_LEN);
        }
	
        logTimestamp("********Exit: fLoadNotifyEnv ***********");

}
