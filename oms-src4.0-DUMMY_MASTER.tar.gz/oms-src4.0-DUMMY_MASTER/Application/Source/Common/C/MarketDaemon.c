#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
#include <my_global.h>    
#include <mysql.h>
#include "IPCS.h"
#include "hiredis.h"

#define WAIT_BEFORE_RETRY 1
#define NO_OF_SESSION     18 
#define	RESTART_TIME	3600

redisReply *reply2;
redisContext    *RdConn1;
LONG64 iPostCloseMKTStatus =0;
struct THREAD_PARAMS
{
	MYSQL *DB_Con;
	LONG32 thread_id;
	redisContext *c;
	redisReply *reply;
};

LONG32	iMktStatusUpdater(void *DB_Con);


LONG32 main (LONG32 argc,CHAR **argv)
{
	logTimestamp("Entry : [main]");
	
	LoadEnv();
	struct THREAD_PARAMS paramsBroadcast[NO_OF_SESSION];

	INT16 	i;

	pthread_t iMktUpdt_th_id[NO_OF_SESSION];

	setbuf(stdin,0);
	setbuf(stdout,0);


	for(i=0;i<NO_OF_SESSION;i++)
	{
		logDebug2("In loop : i :%d:",i);


			paramsBroadcast[i].thread_id=i;
			paramsBroadcast[i].DB_Con = DB_Connect();
			paramsBroadcast[i].c = RDConnect(REDIS_TYPE_MKT_STATUS);
			

			if((pthread_create(&iMktUpdt_th_id[i],NULL,iMktStatusUpdater,(void *)&paramsBroadcast[i]))!=0)
				logFatal("[iMktUpdt] Cant create thread [%d]",i);
			else
				logDebug1("[iMktUpdt] Created thread [%d]",i);

			sleep(2);	

	}

	for(i=0;i<NO_OF_SESSION;i++)
	{
		if(pthread_join(iMktUpdt_th_id[i],NULL)!=0)
                                logFatal("[iMktUpdt_th_id] Error when waiting for OffOrder thread [%d] to terminate", i);
                        else
                                logDebug2("[iMktUpdt_th_id] Stopped Thread [%d]",i);

	}

}



LONG32 iMktStatusUpdater (void *parameter)
{
	logTimestamp("Entry : [iMktStatusUpdater]");
	INT16           th_idn;
	LONG32          Mkt,iCnt=1;
	MYSQL           DBC;
	MYSQL           *DB_Con;
	redisContext *c;
	redisReply *reply;
	MYSQL_RES       *Res;
	MYSQL_ROW        Row;
	INT16           iMktStat = 0;;
	CHAR            cMkt_Seg = '\0';
	CHAR 		cMode 	= '\0';
	CHAR		cProd   = '\0';
	CHAR            sMkt_Exch[EXCHANGE_LEN];
	CHAR            sSession[MARKET_SESSION_LEN];
	CHAR            lvar_uid[30];
	LONG64          SleepTime = 0,iMktType = 1;
	CHAR sBatchSel [MAX_QUERY_SIZE];
	CHAR sModeSel [MAX_QUERY_SIZE];
	CHAR sStatusSel [MAX_QUERY_SIZE];
	CHAR		cFlag;
	CHAR sKeyValue[MAX_COMMAND_LEN];
	CHAR sCommand[MAX_COMMAND_LEN];

	struct THREAD_PARAMS *l_parameter = parameter;
	DB_Con = (MYSQL *)l_parameter->DB_Con;
	th_idn = l_parameter->thread_id;
	c = (redisContext *)l_parameter->c;
	reply = (redisReply *)l_parameter->reply;

	
	logDebug2(" iMktStatusUpdater th_idn :%d:",th_idn);
	logDebug2(" iMktStatusUpdater	iCnt   :%d:",iCnt);
	//for(iCnt ; iCnt<=2; iCnt++)
	while(TRUE)
	{
		cMode = '\0';
		cFlag = '\0';
		memset(sMkt_Exch,'\0',EXCHANGE_LEN);
		memset(sBatchSel,'\0',MAX_QUERY_SIZE);
		memset(sModeSel,'\0',MAX_QUERY_SIZE);
		logDebug3("th_idn :%d:",th_idn);
		switch(th_idn)
		{
			case 0:
				iMktStat = MKT_PREOPEN;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,PRE_OPEN,MARKET_SESSION_LEN);
				break;
			case 1:
				iMktStat = MKT_CLOSE;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,PRE_CLOSE,MARKET_SESSION_LEN);
				break;
			case 2:
				iMktStat = MKT_OPEN;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,OPEN_MARKET,MARKET_SESSION_LEN);
				break;
			case 3:
				iMktStat = MKT_CLOSE; 
				cFlag = NO;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,CLOSE_MARKET,MARKET_SESSION_LEN);
				break;
			case 4:
				iMktStat = MKT_POSTCLOSE;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,POST_OPEN,MARKET_SESSION_LEN);
				break;
			case 5:
				iMktStat = MKT_CLOSE;
				cMkt_Seg = SEGMENT_EQUITY;
				cFlag = YES;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,POST_CLOSE,MARKET_SESSION_LEN);
				break;
			case 6:
				iMktStat = MKT_PREOPEN;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,PRE_OPEN,MARKET_SESSION_LEN);
				break;
			case 7:
				iMktStat = MKT_CLOSE;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,PRE_CLOSE,MARKET_SESSION_LEN);
				break;
			case 8:
				iMktStat = MKT_OPEN;
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,OPEN_MARKET,MARKET_SESSION_LEN);
				break;
			case 9:
				iMktStat = MKT_CLOSE; 
				cMkt_Seg = SEGMENT_EQUITY;
				cFlag = NO;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,CLOSE_MARKET,MARKET_SESSION_LEN);
				break;
			case 10:
				iMktStat = MKT_POSTCLOSE; 
				cMkt_Seg = SEGMENT_EQUITY;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,POST_OPEN,MARKET_SESSION_LEN);
				break;
			case 11:
				iMktStat= MKT_CLOSE;
				cMkt_Seg = SEGMENT_EQUITY;
				cFlag = YES;
				strncpy(sMkt_Exch,BSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,POST_CLOSE,MARKET_SESSION_LEN);
				break;
			case 12:
				iMktStat = MKT_OPEN;
				cMkt_Seg = SEGMENT_FNO;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,OPEN_MARKET,MARKET_SESSION_LEN);
				break;
			case 13:
				iMktStat = MKT_CLOSE;
				cMkt_Seg = SEGMENT_FNO;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,CLOSE_MARKET,MARKET_SESSION_LEN);
				break;
			case 14:
				iMktStat = MKT_OPEN;
				cMkt_Seg = SEGMENT_CURRENCY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,OPEN_MARKET,MARKET_SESSION_LEN);
				break;
			case 15:
				iMktStat = MKT_CLOSE; 
				cMkt_Seg = SEGMENT_CURRENCY;
				strncpy(sMkt_Exch,NSE_EXCH,EXCHANGE_LEN);
				strncpy(sSession,CLOSE_MARKET,MARKET_SESSION_LEN);
				break;

			case 16:
                                iMktStat = MKT_OPEN;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
                                strncpy(sSession,OPEN_MARKET,MARKET_SESSION_LEN);
                                break;
                        case 17:
                                iMktStat = MKT_CLOSE;
                                cMkt_Seg = SEGMENT_COMMODITY;
                                strncpy(sMkt_Exch,MCX_EXCH,EXCHANGE_LEN);
                                strncpy(sSession,CLOSE_MARKET,MARKET_SESSION_LEN);
                                break;


			default:
				logDebug1("[iMktUpdt  (mysql_query(DB_Con,Sel) != SUCCESS");
				break;
		}

		sprintf(sBatchSel,"SELECT julidate(CONCAT(DATE_FORMAT(b.bp_next_schedule_date,\'%%Y-%%m-%%d\') ,\' \', DATE_FORMAT(b.bp_schedule_time,\'%%T\')))-julidate(sysdate())\
				FROM BATCH_PROCESS b\
				WHERE   b.bp_exch_id =ltrim(rtrim( \"%s\")) \
				AND     b.bp_batch_name = \"%s\" AND b.bp_segment = \'%c\';",sMkt_Exch,sSession,cMkt_Seg);

		logTimestamp("Batch Name Sel :%s:",sBatchSel);

		if (mysql_query(DB_Con,sBatchSel) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Market status batch Error in select juliDate [iMktStatusUpdater]");
			mysql_close(DB_Con);
			return ERROR;
		}

		Res = mysql_store_result(DB_Con);

		if(mysql_num_rows(Res) == 0)
		{
			logFatal("[Market status batch******* Zero row returned ******");
			mysql_free_result(Res);
			mysql_close(DB_Con);
			return FALSE;
		}
		else
		{
			Row = mysql_fetch_row(Res);
			SleepTime=atol(Row[0]);
		}
		logDebug2("[status updater] SleepTime :%ld:",SleepTime);
		if(SleepTime < 0)
		{
			logFatal("[iMktStatus:%d] Error in selecting  ETA  :%s:%s:%ld:",th_idn,sMkt_Exch,sSession,SleepTime);
			return FALSE;
		}
		sleep(SleepTime);
		logDebug3("sMkt_Exch :%s:",sMkt_Exch);
		logDebug3("sSession :%s:",sSession);
		sprintf(sModeSel,"SELECT BP_MODE FROM BATCH_PROCESS b\
                                WHERE   b.bp_exch_id = ltrim(rtrim(\"%s\"))\
                                AND     b.bp_batch_name = \"%s\" AND b.bp_segment = \'%c\';",sMkt_Exch,sSession,cMkt_Seg);
		logTimestamp("sModeSel  :%s:",sModeSel);

                if (mysql_query(DB_Con,sModeSel) != SUCCESS)
                {
                        sql_Error(DB_Con);
                        logSqlFatal("[iMktStatus] Error in SELECT BP_MODE [iMktStatusUpdater]");
                        mysql_close(DB_Con);
                        return ERROR;
                }

                Res = mysql_store_result(DB_Con);

                if(mysql_num_rows(Res) == 0)
                {
                        logFatal("[iMktStatus] $$$$$$$ Zero row returned $$$$$");
                        mysql_free_result(Res);
                        mysql_close(DB_Con);
                }

                else
                {
                        Row = mysql_fetch_row(Res);
                        cMode=Row[0][0];
                }
		logDebug1("cMode :%c:",cMode);

                if (cMode != 'A')
                {
                        logDebug2("[iMktStatus:%d] Batch Process is set to manual for :%s:%c:%s: ",th_idn,sMkt_Exch,sSession);
                        return FALSE;
                }
		logDebug1("sModeSel  :%s:",sModeSel);

		
		logDebug2(" iMktStatusUpdater th_idn :%d:",th_idn);
		memset(sStatusSel,'\0',MAX_QUERY_SIZE);
                sprintf(sStatusSel,"UPDATE EXCH_MKT_MASTER SET EMM_STATUS = \'%d\' ,EMM_LUT = NOW() \
                                    WHERE EMM_EXM_EXCH_ID =ltrim(rtrim( \"%s\")) AND EMM_EXCH_SEG = \'%c\' AND EMM_MKT_TYPE = \'NL\';",iMktStat,sMkt_Exch,cMkt_Seg);
                logTimestamp("Updating market status :%s:",sStatusSel);
                if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
                {
                       	sql_Error(DB_Con);
                        logSqlFatal("[iMktStatus] Error in Query.. [iMktStatusUpdater]");
                        mysql_close(DB_Con);
                        return ERROR;
                }
			
	        memset(sKeyValue,'\0',MAX_COMMAND_LEN);
	        memset(sCommand,'\0',MAX_COMMAND_LEN);

	        sprintf(sKeyValue,"{\"MARKET_STATUS\":\"%d\",\"EXCH\":\"%s\",\"SEGMENT\":\"%c\",\"SESSION\":\"%s\"}",iMktStat,sMkt_Exch,cMkt_Seg,sSession);
        	logDebug2("sKeyValue >  %s",sKeyValue);
	        sprintf(sCommand,"PUBLISH MARKET_STATUS %s",sKeyValue);
	        logDebug2("sCommand >  %s",sCommand);
	        reply = fRedisCommand(c,sCommand,REDIS_TYPE_MKT_STATUS);
	
		fUpdateMktStatus_InRedis(iMktStat , cMkt_Seg, &sMkt_Exch, iMktType,c,reply);
		/********************
		 * Note By : Darshan
		 * Do not uncomment the below 2 lines and also do not try to access the reply object.
		 * If you do, the process will crash, in case of redis reconnection event. 
		 ********************/
	        //logDebug2("INCR counter: %lld", reply->integer); // Do not uncomment this
		//freeReplyObject(reply);  // Do not uncomment this

		switch(th_idn)
		{	
			
			logDebug2(" iMktStatusUpdater th_idn :%d:",th_idn);
			case 3:         
			case 5:         
			case 9:         
			case 11:   
				
				if (iPostCloseMKTStatus == 1)
                		{
					memset(sStatusSel,'\0',MAX_QUERY_SIZE);
					sprintf(sStatusSel,"UPDATE BATCH_PROCESS SET BP_OFF_MKT_STATUS = \'%c\' ,BP_UPDATED_BY = \"SYSTEM\" WHERE BP_EXCH_ID = \"%s\" \
                        					  AND BP_BATCH_NAME = \"OFFMKT_PUMP\" AND BP_SEGMENT = \'%c\' ;",cFlag,sMkt_Exch,cMkt_Seg);
					logTimestamp("Batch Process offline market status Update  :%s:",sStatusSel);
					if (mysql_query(DB_Con,sStatusSel) != SUCCESS)
					{
						sql_Error(DB_Con);
						logSqlFatal("[iMktStatus] Error in Query.. [iMktStatusUpdater]");
						mysql_close(DB_Con);
						return ERROR;
					}
				}
				break;

		}
		memset(sStatusSel,'\0',MAX_QUERY_SIZE);
        	sprintf(sStatusSel,"SELECT BP_UPDATE(LTRIM(RTRIM(\"%s\")),\'%c\',\'%s\','1',\"AUTO_SUCCESS\",'1','0','0');",sMkt_Exch,cMkt_Seg,sSession);
        		logTimestamp("sStatusSel:%s:",sStatusSel);

        	if(mysql_query(DB_Con,sStatusSel) != SUCCESS)
        	{
                	sql_Error(DB_Con);
                	logSqlFatal("Error in BP_UPDATE QUERY.");
                	return FALSE;
        	}
        	else
        	{
                	Res = mysql_store_result(DB_Con);
                	Row = mysql_fetch_row(Res);
                	logDebug2("Status of batch update [%s] [%d]",Row[0],atoi(Row[0]));
                	mysql_commit(DB_Con);
        	}
		sleep(RESTART_TIME);





	}




	
	logTimestamp("Exit : [iMktStatusUpdater]");
	return(0);
	pthread_exit(NULL);
}						


LONG32 	GetJuliDateTime()
{
	struct timeval tm;
	gettimeofday( &tm, NULL );
	//        printf("\n Time i : %i",tm.tv_sec);
	return tm.tv_sec;
}



void fUpdateMktStatus_InRedis(INT16 iMktStatus,CHAR cSegment ,CHAR *sExchange, INT16 iMkttype,redisContext *c,redisReply *reply)

{
        logTimestamp("Entry : [fUpdateMktStatus_InRedis]");

        logDebug2("Printing all values from argument");
        logDebug2("iMktStatus  :%d:",iMktStatus);
        logDebug2("iMkttype    :%d:",iMkttype);
        logDebug2("cSegment    :%c:",cSegment);
        logDebug2("sExchange   :%s:",sExchange);

        CHAR sKeyValue[MAX_COMMAND_LEN];
        CHAR sCommand[MAX_COMMAND_LEN];

        memset(sKeyValue,'\0',MAX_COMMAND_LEN);
        memset(sCommand,'\0',MAX_COMMAND_LEN);
        /*RdConn1 = RDConnect(REDIS_TYPE_MKT_STATUS);
        if(RdConn1 == NULL)
        {
                logInfo("Redis not connected ");
        }**/

        sprintf(sKeyValue,"%s:%c:%d",sExchange,cSegment,iMkttype);
        logDebug2("sKeyValue :%s:",sKeyValue);

        sprintf(sCommand,"HMSET %s MARKET_STATUS %d",sKeyValue,iMktStatus);
        logTimestamp("sCommand -> %s",sCommand);
        //reply = redisCommand(RdConn1,sCommand);
        reply = redisCommand(c,sCommand);
        freeReplyObject(reply);

        logTimestamp("Exit  : [fUpdateMktStatus_InRedis]");

}

BOOL LoadEnv()
{
        logTimestamp("Entry : [LoadEnv]");

        CHAR    sPostCloseMKTStatus     [ENV_VARIABLE_LEN];
        memset(sPostCloseMKTStatus,'\0',ENV_VARIABLE_LEN);

        if (getenv("POST_CLOSE_MKT_STATUS")== NULL){

                logFatal("Error : Environment variables missing : POST_CLOSE_MKT_STATUS");
                iPostCloseMKTStatus = 1;

        }
        else{
                strncpy(sPostCloseMKTStatus,getenv("POST_CLOSE_MKT_STATUS"),ENV_VARIABLE_LEN);
                iPostCloseMKTStatus = atoi (sPostCloseMKTStatus);
        }
        logTimestamp("Exit : [LoadEnv]");
}
