#include <string.h>	
#include <stdio.h>	
#include <stdlib.h>	
#include "IPCS.h"
#include "rdkafka.h"


int main(INT16 argc, CHAR **argv)
{
	setbuf(stdout , NULL);
        setbuf(stderr , NULL);

	rd_kafka_t *rk;
	char	sTopic[100];
	char	MessageBuf[1024];
	memset(sTopic,'\0',100);
	int iCnt=0;
	strncpy(sTopic,argv[1],100);
	rk = KafkaConConsumer(&sTopic,argv[2]);

	if(rk)
	{
		printf("\nConnected to Kafka\n");
		printf("\nConnected to Kafka\n");
		printf("\nConnected to Kafka\n");
		printf("\nConnected to Kafka\n");
		printf("\nConnected to Kafka\n");
	}
	
	while(1)
	{	iCnt++;
		memset(MessageBuf,'\0',1024);
		KafkaReader(rk,&MessageBuf);	
		
		printf("\n MessageBuf :%s: Length :%d:",MessageBuf,strlen(MessageBuf));	

	}
}

	
