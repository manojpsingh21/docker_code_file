#include <sys/time.h>
#include <stdlib.h>
#include <pthread.h>
#include <float.h>
#include  <stdarg.h>
#include <sys/types.h>
#include <stdio.h>
#include "MemMapConfig.h"

/***********
  Function Name:
  Arguments:
  Return Values:
  Tables Used:
  Dependencies:
  Functions Called By:
  Comments:
 **********/

void LockThreadMutex ( pthread_mutex_t * mutex)
{
	if(  pthread_mutex_lock (mutex ) != 0)
	{
#ifdef     DBG
		printf("\n Error in Locking Mutex \n");
			perror("Error in Locking Mutex ");
#endif
			exit(1);
	}
}

void UnLockThreadMutex ( pthread_mutex_t * mutex)
{
	if(  pthread_mutex_unlock ( mutex ) != 0)
	{
#ifdef     DBG
		printf("\n Error in UnLocking Mutex \n");
			perror("Error in UnLocking Mutex ");
#endif
			exit(1);
	}
}

void UpdateArrayStatus(int ArrayPosn)
{
	LockThreadMutex(&OffMsgArrayMutex);
		
		OffMsgArray[ArrayPosn ] = UNUSED;
		
		UnLockThreadMutex(&OffMsgArrayMutex);
		
		LockThreadMutex(&array_lock);
		
		if(pthread_cond_broadcast(&array_wait) != 0)
		{
			printf("\n Error in broadcast condition variable ");
				exit(1);
		}
	
		UnLockThreadMutex(&array_lock);
}

