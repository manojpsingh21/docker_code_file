#include <stdio.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <unistd.h>
#include "RedisStruct.h"
#include "hiredis.h"
#include "rdkafka.h"


LONG32  iMsgType = 0;
LONG32  iMmapToNotifyFE;

rd_kafka_t *KfConn;
rd_kafka_t *KfConn1;
CHAR    sKafkaTopic[100];



main (int argc, char **argv)
{
	logTimestamp("Main [ENTRY]");
	setbuf(stdout , NULL);
	setbuf(stderr , NULL);

	logDebug2("SIZE = %d",sizeof(struct INT_COMMON_RESP_HDR));
	struct  INT_REQUEST_HEADER      *pReqHeader;
	OpenMessageQueue();
	memset(sKafkaTopic,'\0',100);
	if((getenv("KAFKA_NOTIFY_TOPIC") != NULL ) && strlen(getenv("KAFKA_NOTIFY_TOPIC") ) != 0)
	{
		strcpy(sKafkaTopic,getenv("KAFKA_NOTIFY_TOPIC") );
		KfConn = KafkaConProducer(getenv("KAFKA_NOTIFY_TOPIC"));
		KfConn1= KafkaConProducer(KF_OMS_COOKED_DATA);
	}

	ReadMessage();
	logTimestamp("Main [EXIT]");
}


OpenMessageQueue()
{
	if((iMmapToNotifyFE=OpenMsgQ(KafkaToNotify)) == ERROR)
	{
		perror("OpenMsgQ ...MmapToNotifyFE");
		exit(ERROR);
	}
	logDebug2("SucessFully Created MmapToNotifyFE key = %d iMmapToNotifyFE:%d:",MmapToNotifyFE,iMmapToNotifyFE);
}

BOOL ReadMessage()
{

	logTimestamp("ReadMessage [ENTRY]");
	struct          INT_COMMON_RESP_HDR     pIntRespHdr;
	struct C2D_VIEW_NET_POSITION *pC2DPos;
	CHAR            sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	struct          ORDER_RESPONSE *Ord_Req;
	LONG32          iMsgCode,iCount=0;
	while(1)
	{
		memset (&sRcvMsg,'\0' ,sizeof (struct ORDER_RESPONSE));
		memset (&Ord_Req,'\0' ,sizeof (struct ORDER_RESPONSE));
		memset(&pC2DPos,'\0',sizeof(struct C2D_VIEW_NET_POSITION));
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %i =================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");
		if((ReadMsgQ(iMmapToNotifyFE,&sRcvMsg,RUPEE_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q");
			exit(ERROR);
		}
		iMsgCode = ((struct INT_COMMON_REQUEST_HDR *) sRcvMsg)->iMsgCode;
		if (iMsgCode == TC_INT_CON_DEL_POS_RESP || iMsgCode == TC_INT_CON_DEL_IP_POS_RESP)
		{
			pC2DPos=(struct C2D_VIEW_NET_POSITION *) &sRcvMsg;
			logDebug2("iMsgCode [%d]",iMsgCode);
			logDebug2("ClientId [%s]",pC2DPos->sClientId);
			logDebug2("Buy Quantity Carry Forward [%d]",pC2DPos->iBuyQtyCF);
			logDebug2("Leg Nos [%d]",pC2DPos->iRef_ID);
			if(KafkaProducer(KfConn,sKafkaTopic,(char *)pC2DPos,sizeof(struct C2D_VIEW_NET_POSITION)) != TRUE)
			{
				printf("\nError while message wrting\n");
			}
		}
		else{
			Ord_Req = (struct ORDER_RESPONSE *) &sRcvMsg;
			logDebug2("iMsgCode [%d]",iMsgCode);
			logDebug2("ClientId [%s]",Ord_Req->sClientId);
			logDebug2("Total Remaining Qty [%d]",Ord_Req->iTotalQtyRem);
			logDebug2("Order Number [%lf]",Ord_Req->fOrderNum);
			logDebug2("Leg Nos [%d]",Ord_Req->iLegValue);
			if(KafkaProducer(KfConn,sKafkaTopic,(char *)Ord_Req,sizeof(struct ORDER_RESPONSE)) != TRUE)
			{
				printf("\nError while message wrting\n");
			}
		}
	}
}

