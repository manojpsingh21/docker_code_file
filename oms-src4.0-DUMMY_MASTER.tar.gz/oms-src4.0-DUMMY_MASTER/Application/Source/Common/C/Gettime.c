#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

int main(int argc,int argv[])
{
	unsigned  int t,i;
	struct timeval begin, end;
	printf("the value we passing :%d\n",argv);
	for(i=0;i<=1000;i++)
	{
		t=0;
		gettimeofday(&begin, NULL);
		printf("begin time  : %d\n",begin.tv_usec );
		gettimeofday(&end, NULL);
		printf("end time : %d\n",end.tv_usec);

		t = end.tv_usec - begin.tv_usec;
		printf("The duration time is : %d\n",t);
	}
}

