#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

extern DBConNEQ;
extern  RdConStatic;

BOOL GetSecDetails(struct INT_ORDERS *pRes)
{

	logTimestamp("Entry : [GetSecDetails]");
	CHAR            sSelQry[MAX_QUERY_SIZE];
	redisReply      *reply;

	logDebug1("SEGMENT : %c",pRes->ReqHeader.cSegment);
	logDebug1("SCRIPT_CODE: %s",pRes->sSecId);

	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	sprintf(sSelQry,"HMGET %s:%c:%s %s %s %s %s %s %s %s %s",pRes->ReqHeader.sExcgId, pRes->ReqHeader.cSegment, pRes->sSecId,SM_EXCH_SYMBOL, SM_SYMBOL_NAME, SM_INSTRUMENT, SM_SERIES, SM_MATURITY_DAY, SM_MATURITY_MONYR, SM_OPTION_TYPE, SM_STRIKE_PRICE);


