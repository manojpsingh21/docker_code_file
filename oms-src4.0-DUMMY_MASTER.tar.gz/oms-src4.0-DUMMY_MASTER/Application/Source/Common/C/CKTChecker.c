#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "AdminAdaptor.h"
//MYSQL   *DB_MTM;
CHAR    sUsrId[50];
CHAR    sUsrId2[50];
CHAR 	cSendFlg;
static CHAR cCltrlStatus='N';
static CHAR sComLmtQry[DOUBLE_MAX_QUERY_SIZE];
static CHAR sLmtQry[DOUBLE_MAX_QUERY_SIZE];
static CHAR    sWhereClause[MAX_QUERY_SIZE];
LONG32  iCKTtimer;
LONG32  iIntSqrOffToMemMap=0;
CHAR    sAdmin [15];
LONG32  iUserId;
CHAR    sOrderVal[INTSQROFF_ORDER_VAL_LEN];
LONG32  iOrderVal = 3;
LONG32  iAdminQueriesToAdaptor = 0;
LONG32  GetJuliDateTime();
CHAR 	sCKTNotifyUrl[URL_LEN];
LONG32  iNotifyUrl = 0;
LONG32	iMTMOrdCancl=1;
MYSQL   *DB_MTM_MAIN;

struct THREAD_PARAMS
{
	MYSQL *DB_MTM;
	LONG32 thread_id;
};

void    fCheckDPR(void *parameter);
void    fCheckCKT(void *parameter);


LONG32 main (LONG32 argc,CHAR **argv)
{
	logTimestamp("Entry : [main]");

	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
//	MYSQL   *DB_MTM_MAIN;
	MYSQL_RES       *Res ;
	MYSQL_RES       *Res1 ;
	MYSQL_ROW       Row;
	LONG32 iRow,i;
	CHAR    sTempUsrID[50];
	CHAR    sSelectQry[MAX_QUERY_SIZE];
	CHAR    sUserId[MAX_QUERY_SIZE];
	CHAR    sAllUserId[300];
	memset(sTempUsrID,'\0',50);
	memset(sUserId,'\0',MAX_QUERY_SIZE);
	memset(sUsrId,'\0',50);
	memset(sUsrId2,'\0',50);
	memset(sAllUserId,'\0',300);
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	memset(sLmtQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhereClause,'\0',MAX_QUERY_SIZE);
	DB_MTM_MAIN = DB_Connect();
	OpenMsgQue();

	sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  IN ( 'CKT_TIMER','Default_userid','Default_admin','INTRADAY_SQROFF_VALIDITY') order by s.PARAM_NAME asc");
//	sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS s where s.PARAM_NAME  = 'CKT_TIMER' ;");

	if (mysql_query(DB_MTM_MAIN,sSelectQry) != SUCCESS)
	{
		sql_Error(DB_MTM_MAIN);
		logSqlFatal("Error Fetching SysAdmin .");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry);

	Res = mysql_store_result(DB_MTM_MAIN);
	iRow = (mysql_num_rows(Res));
	if(iRow == 0)
	{
		mysql_free_result(Res);
		logDebug2("Zero rows selected from sys_parameter");
		exit(ERROR);
	}
	else
	{
		logDebug2("Number of rows Selected from SYS_PARAMETER = :%d:",iRow);


/*		if(Row = mysql_fetch_row(Res))
		{
			iCKTtimer = atoi(Row[0]);
			logDebug2("In Third Loop iTimer :%d:",iCKTtimer);

		}
*/
	        for(i = 0 ; i < iRow ; i ++)
                {
                        if(Row = mysql_fetch_row(Res))
                        {

                                switch (i)
                                {
                                        case 0 :
                                                iCKTtimer = atoi(Row[0]);
                                                logDebug2("In 4th Loop iTimer :%d:",iCKTtimer);
                                                break;
                                        case 1  :
                                                strncpy(sAdmin,Row[0],15);
                                                logDebug2("sAdmin :%s:",sAdmin);
                                                break;
                                        case 2 :
                                                iUserId = atoi(Row[0]);
                                                logDebug2("iUserId :%d:",iUserId);
                                                break;
                                        case 3 :
                                                strncpy(sOrderVal,Row[0],INTSQROFF_ORDER_VAL_LEN);
                                                if(strcmp(sOrderVal,"DAY") == 0)
                                                {
                                                        logDebug3("IN CASE OF DAY");
                                                        iOrderVal = VALIDITY_DAY;
                                                }
                                                else if(strcmp(sOrderVal,"IOC") == 0)
                                                {
                                                        logDebug3("IN CASE OF IOC");
                                                        iOrderVal = VALIDITY_IOC;
                                                }
						else 
						{
							logDebug3("DEFAULT CASE");
							iOrderVal = VALIDITY_DAY;
						}
                                                break;
                                        default :
                                                logDebug2("Wrong case");
                                                break ;
                                }
                        }
                }

		mysql_free_result(Res);


	}

	if(iCKTtimer < 20)
	{
		iCKTtimer  = 20;
		logDebug2(" In IF iCKTtimer :%d:",iCKTtimer );
	}
	logDebug2("VALUE LOADED iCKTtimer :%d:  ",iCKTtimer);	

	sprintf(sUserId,"select PARAM_VALUE from SYS_PARAMETERS where PARAM_NAME = 'Survilliance admin';");

	logDebug2("sUserId :%s:",sUserId);

	if(mysql_query(DB_MTM_MAIN,sUserId) != SUCCESS)
	{
		sql_Error(DB_MTM_MAIN);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM_MAIN);

	if((Row = mysql_fetch_row(Res)))
	{
		strncpy(sUsrId,Row[0],50);
		logDebug2("In If sUserId :%s:",sUserId);
	}	
	else
	{		
		strncpy(sUsrId,"123",50);
	}	
	logDebug2("sUserId :%s:",sUsrId);

                                                

	if(getenv("CKT_URL_NOTIFY_FLAG")== NULL) 
	{
		iNotifyUrl = FALSE;
		logFatal("Error : Environment variables missing : CKT_URL_NOTIFY_FLAG");
	}
	else
	{
		iNotifyUrl = atoi(getenv("CKT_URL_NOTIFY_FLAG"));
	}
	logDebug2("iNotifyUrl :%d:",iNotifyUrl);

	if(getenv("CKT_URL_NOTIFY")== NULL) // Mail URL @pratik
	{
		strncpy(sCKTNotifyUrl,"NO_VAL",URL_LEN);
		logFatal("Error : Environment variables missing : CKT_URL_NOTIFY");
	}
	else
	{
		strncpy(sCKTNotifyUrl,getenv("CKT_URL_NOTIFY"),URL_LEN);
	}
	logDebug2("sCKTNotifyUrl :%s:",sCKTNotifyUrl);


	logDebug2("In Combined Query cSegLmtFlg == 'A' && cComLmtFlg == 'Y'");

	sprintf(sComLmtQry,"SELECT NPT_CLIENT_ID,  NPT_SECURITY_ID,  NPT_EXCH_ID,  NPT_MKT_TYPE,  NPT_SYMBOL,  NPT_INSTRUMENT,  IFNULL(NPT_EXPIRY_DATE, '') AS NPT_EXPIRY_DATE,  NPT_TOT_BUY_QTY,  NPT_TOT_BUY_QTY_CF,  NPT_TOT_BUY_QTY_DAY,  NPT_TOT_BUY_VAL,  NPT_TOT_BUY_VAL_CF,  NPT_TOT_BUY_VAL_DAY,  NPT_BUY_AVG,  NPT_TOT_SELL_QTY,  NPT_TOT_SELL_QTY_CF,  NPT_TOT_SELL_QTY_DAY,  NPT_TOT_SELL_VAL,  NPT_TOT_SELL_VAL_CF,  NPT_TOT_SELL_VAL_DAY,  NPT_SELL_AVG,  NPT_NET_QTY,  NPT_NET_VAL,  NPT_NET_AVG,  NPT_GROSS_QTY,  NPT_GROSS_VAL,  NPT_SEGMENT,  NPT_PROD_ID,  NPT_REALISED_PROFIT,  NPT_REF_ID,  0 AS MTM,  0 AS MTM_LEVEL,  'Y' AS SQ_OFF_FLAG,  RPM.RPM_MAX_ORD_VALUE AS SOVL, IF(NPT_FRZ_QTY > 0 AND NPT_FRZ_QTY < RPM.RPM_MAX_ORD_QTY AND NPT_SEGMENT IN ('E' , 'D'),    NPT_FRZ_QTY, RPM.RPM_MAX_ORD_QTY) AS SOQL,  RPM.RPM_MAX_LOT AS SOLL,  LWA.L1_LTP AS NPT_LTP,  RPM_MTM_SQ_OFF_FLAG,  0 AS SQ_LEVEL,  0 AS TRADING_BALANCE,  0 AS TOTAL_MTM,  0 AS PAYIN_AMT ,NPT_CUSTOM_SYMBOL FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE AND NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT) LEFT JOIN BHAV_COPY BC ON (NPT.NPT_SECURITY_ID = BC.BC_SCRIP_CODE AND NPT.NPT_EXCH_ID = BC.BC_EXCHANGE AND NPT.NPT_SEGMENT = BC.BC_SEGMENT)  LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT)  LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'CKT_BLOCK_THRESHHOLD_PERC') WHERE ((LWA.L1_LTP<=( BC.BC_CLOSE_PRICE - ( BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE/100)/100))AND NPT.NPT_NET_QTY >0)   OR (LWA.L1_LTP>=( BC.BC_CLOSE_PRICE + ( BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE/100)/100))AND NPT.NPT_NET_QTY <0)) AND NPT.NPT_PROD_ID NOT IN ('C','M') AND NPT.NPT_SEGMENT = 'E' AND SM.SM_DPR_BAND <> 0");		

	printf("In COMBINED sComLmtQry :%s:\n",sComLmtQry);

        logDebug2("In Combined Query cSegLmtFlg == 'A' && cComLmtFlg == 'Y'");

	sprintf(sLmtQry,"SELECT NPT_SECURITY_ID, NPT_CLIENT_ID, (CASE WHEN NPT_NET_QTY > 0 THEN 'S' WHEN NPT_NET_QTY < 0 THEN 'B' END) AS BUY_SELL, NPT_INTEROPS_SCRIP FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE AND NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT) LEFT JOIN BHAV_COPY BC ON (NPT.NPT_SECURITY_ID = BC.BC_SCRIP_CODE AND NPT.NPT_EXCH_ID = BC.BC_EXCHANGE AND NPT.NPT_SEGMENT = BC.BC_SEGMENT) LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT) LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'CKT_BLOCK_THRESHHOLD_PERC') WHERE ((LWA.L1_LTP <= (BC.BC_CLOSE_PRICE - (BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE / 100) / 100)) AND NPT.NPT_NET_QTY > 0) OR (LWA.L1_LTP >= (BC.BC_CLOSE_PRICE + (BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE / 100) / 100)) AND NPT.NPT_NET_QTY < 0)) AND NPT.NPT_PROD_ID NOT IN ('C' , 'M') AND NPT.NPT_SEGMENT = 'E' AND SM.SM_DPR_BAND <> 0");
	 printf("In COMBINED sLmtQry :%s:\n",sLmtQry);
/**	CKT Checker Cancellation Old Query NPT_INTEROPS_SCRIP this column was added for Interops
        sprintf(sLmtQry,"SELECT NPT_SECURITY_ID,NPT_CLIENT_ID, (CASE WHEN NPT_NET_QTY > 0 THEN 'S' WHEN NPT_NET_QTY < 0 THEN 'B' END) AS BUY_SELL FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE AND NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT) LEFT JOIN BHAV_COPY BC ON (NPT.NPT_SECURITY_ID = BC.BC_SCRIP_CODE AND NPT.NPT_EXCH_ID = BC.BC_EXCHANGE AND NPT.NPT_SEGMENT = BC.BC_SEGMENT)  LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT)  LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'CKT_BLOCK_THRESHHOLD_PERC') WHERE ((LWA.L1_LTP<=( BC.BC_CLOSE_PRICE - ( BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE/100)/100))AND NPT.NPT_NET_QTY >0)   OR (LWA.L1_LTP>=( BC.BC_CLOSE_PRICE + ( BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE/100)/100))AND NPT.NPT_NET_QTY <0)) AND NPT.NPT_PROD_ID NOT IN ('C','M') AND NPT.NPT_SEGMENT = 'E' AND SM.SM_DPR_BAND <> 0;");
        printf("In COMBINED sLmtQry :%s:\n",sLmtQry);

**/
	struct THREAD_PARAMS paramsChkCltrl;
	struct THREAD_PARAMS paramsMTM;
	struct THREAD_PARAMS paramsMTMBrch;
	pthread_t CKT_th_id;
	pthread_t Cltrl_th_id;

	paramsMTM.thread_id=0;
	paramsMTM.DB_MTM = DB_Connect();

	paramsChkCltrl.thread_id=0;
	paramsChkCltrl.DB_MTM = DB_Connect();


	if(mysql_set_server_option(paramsMTM.DB_MTM,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2("mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2("mysql_set_server_option FAILed");
		return FALSE;
	}
	if(mysql_set_server_option(paramsChkCltrl.DB_MTM,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2("mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2("mysql_set_server_option FAILed");
		return FALSE;
	}

	if((pthread_create(&Cltrl_th_id,NULL,fCheckDPR,(void *)&paramsChkCltrl))!=0)
		logDebug1("Cant create fCheckDPR thread.");
	else
		logDebug1("fCheckDPR thread Created.");

	if((pthread_create(&CKT_th_id,NULL,fCheckCKT,(void *)&paramsMTM))!=0)
		logDebug1("Cant create MTM thread.");
	else
		logDebug1("MTM thread Created.");


	if (pthread_join(Cltrl_th_id,NULL))
		logFatal("[CKT] Error when waiting for fCheckDPR thread to terminate");
	else
		logDebug2("fCheckDPR Stopped");

	if (pthread_join(CKT_th_id,NULL))
		logFatal("[CKT] Error when waiting for CKT thread to terminate");
	else
		logDebug2("[CKT] Stopped");


	logTimestamp("Exit : [main]");
	return (0);
}

void fCheckDPR (void *parameter)
{
	logTimestamp("Entry : [fCheckDPR]");
	MYSQL           *DB_MTM;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            Sel[MAX_QUERY_SIZE];
	INT16 th_id;
	INT16           iStatus,iBreaches;
	CHAR 		sStatus[15];
	CHAR            sSelQry[MAX_QUERY_SIZE];
	LONG32		iMktstatus = 0;
	struct THREAD_PARAMS *l_parameter = parameter;

	th_id = l_parameter->thread_id;
	DB_MTM = (MYSQL *)l_parameter->DB_MTM;
	while(1)
	{
		logDebug2("iCKTtimer :%d:",iCKTtimer);

		sleep(iCKTtimer);
		
		while(1)
                {
                        memset(sSelQry ,'\0',MAX_QUERY_SIZE);
                        sprintf(sSelQry,"SELECT EMM_STATUS FROM EXCH_MKT_MASTER WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) \
                                        AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG=\'%c\' ",NSE_EXCH,EQUITY_SEGMENT);

                        logDebug2("sSelQry of market status :%s:", sSelQry);
                        if (mysql_query(DB_MTM,sSelQry) != SUCCESS)
                        {
                                sql_Error(DB_MTM);
                                logSqlFatal("Error in select Qry market status.");
                                mysql_close(DB_MTM);
                                return ERROR;
                        }
                        Res = mysql_store_result(DB_MTM);
                        Row = mysql_fetch_row(Res);
                        iMktstatus = atoi(Row[0]);
                        logDebug2("iMktstatus :%d:", iMktstatus);
                        mysql_free_result(Res);
                        if(iMktstatus == MKT_OPEN)
                        {
                                logDebug2("Market is open we can continue .");
                                break;
                        }else
                        {
                                logDebug2("Market is closed .");

                        }
                        sleep(iCKTtimer);

                }

		memset(Sel,'\0',MAX_QUERY_SIZE);
		sprintf(Sel,"CALL PR_DPR_BLOCK_UNBLOCK(@ZSTATUS);SELECT @ZSTATUS;");
		logDebug2("Query... = %s",Sel);

		if(mysql_query(DB_MTM,Sel) != SUCCESS)
		{
			sql_Error(DB_MTM);
			logSqlFatal("Error IN CALLING PR_DPR_BLOCK_UNBLOCK.");
			exit(ERROR);//in case of mysql failure thread was exited.
			//return ERROR;
		}
		do{
			Res = mysql_store_result(DB_MTM);
			logDebug2("Res :%d:",Res);
			if(Res)
			{
				if((Row = mysql_fetch_row(Res)))
				{
					strncpy(sStatus,Row[0],15);
					logDebug2(" While Fetching sStatus :%s:",sStatus);
				}
			}	
			else
			{
				logDebug2("No Result Set ");
				logDebug2("In Else sStatus :%s:",sStatus);
			}

			if((iStatus =mysql_next_result(DB_MTM)) > 0)
			{
				logDebug3("Could not execute statement");
			}
		}while(iStatus == 0);

		logDebug2(" Printing sStatus :%s:",sStatus);
		if(strncmp(sStatus,"S",2) == 0)
		{
			cCltrlStatus='Y';			
			logDebug2("In Sucess compare cCltrlStatus :%c:",cCltrlStatus);
		}
		else
		{
			mysql_free_result(Res);
			cCltrlStatus='N';
			logDebug2("NO RESULT FOUND !!!! ");
		}
	}
	logTimestamp("Exit : [fCheckDPR]");
}

void fCheckCKT(void *parameter)
{
	logTimestamp("Entry : [fCheckCKT]");
	MYSQL *DB_MTM;
	MYSQL_RES       *Res;
	MYSQL_RES       *Res1;
	MYSQL_ROW       Row;
	LONG32          iTimer = -1;
	INT16           iStatus,iBreaches;
	INT16           th_id;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fSqrPer=0;
	DOUBLE64        fTotalMTM=0;
	DOUBLE64	fPAYIN_AMT=0;
	LONG32          iNoOfRec=0;
	LONG32          iNoOfPkt;
	LONG32          iQty = 0;
	LONG32          iTempNoOfRec;
	LONG32          i=0,j=0,iMktstatus =0;
	CHAR            sSelQry[MAX_QUERY_SIZE];
	CHAR		sCommand[MAX_COMMAND_LEN];

	struct THREAD_PARAMS *l_parameter = parameter;

	th_id = l_parameter->thread_id;
	DB_MTM = (MYSQL *)l_parameter->DB_MTM;

	struct VIEW_COMMON_HDR_RESP             pC2DPosHedResp;
	struct VIEW_MTM_C2D_VIEW_NET_POSITION  pC2DPos;
	while(1)
	{
		logDebug2("iCKTtimer :%d:",iCKTtimer);
		sleep(iCKTtimer);
		while(1)
		{
			memset(sSelQry ,'\0',MAX_QUERY_SIZE);	
			sprintf(sSelQry,"SELECT EMM_STATUS FROM EXCH_MKT_MASTER WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) \
					AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG=\'%c\' ",NSE_EXCH,EQUITY_SEGMENT);

			logDebug2("sSelQry of market status :%s:", sSelQry);
			if (mysql_query(DB_MTM,sSelQry) != SUCCESS)
			{
				sql_Error(DB_MTM);
				logSqlFatal("Error in select Qry market status.");
				mysql_close(DB_MTM);
				return ERROR;
			}
			Res = mysql_store_result(DB_MTM);
			Row = mysql_fetch_row(Res);
			iMktstatus = atoi(Row[0]);
			logDebug2("iMktstatus :%d:", iMktstatus);
			mysql_free_result(Res);		
			if(iMktstatus == MKT_OPEN)
			{
				logDebug2("Market is open we can continue .");
				break;
			}else
			{
				logDebug2("Market is closed .");

			}	
			sleep(iCKTtimer);

		}		

		logDebug2("cCltrlStatus:%c:",cCltrlStatus);
		if(cCltrlStatus == 'Y')
		{
			memset(&pC2DPos,'\0',sizeof(struct VIEW_MTM_C2D_VIEW_NET_POSITION));

			printf("QUERY :%s:\n",sComLmtQry);

			if (mysql_query(DB_MTM,sComLmtQry) != SUCCESS)
			{
				logSqlFatal("Error in select Qry [CheckCKT].");
				mysql_close(DB_MTM);
				return ERROR;
			}

			Res = mysql_store_result(DB_MTM);
			logDebug2("COMBINED RESULT RES :%d:",Res);
			logDebug2("COMBINE Rows : %i",mysql_num_rows(Res));
			iBreaches = mysql_num_rows(Res);
			logDebug2("iBreaches :%d:",iBreaches);
			if(iBreaches == 0)
			{
				logInfo("No CKT Breaches");
				/* when CKT is not breach front end response */
				pC2DPos.IntRespHeader.iMsgLength= sizeof(struct VIEW_MTM_C2D_VIEW_NET_POSITION);
				logDebug2("pC2DPos.IntRespHeader.iMsgLength :%d:",pC2DPos.IntRespHeader.iMsgLength);
				pC2DPos.IntRespHeader.iMsgCode = TC_INT_CKT_LIMIT_NET_POS_RESP;
				logDebug2("pCDPos.IntRespHeader.iMsgCode :%d:",pC2DPos.IntRespHeader.iMsgCode);
				pC2DPos.iNoofRec = 0;
				logDebug2("pCDPos.iNoofRec :%d:",pC2DPos.iNoofRec);

				Process_Request((CHAR *)&pC2DPos ,sizeof(struct VIEW_MTM_C2D_VIEW_NET_POSITION) );

			}
			else
			{
				if(iMTMOrdCancl == 1)
				{	
					logDebug3("CKT Order cancel configurable");
					printf("In ANother Fn QUERY sLmtQry :%s:\n",sLmtQry);
			                if(mysql_query(DB_MTM,sLmtQry) != SUCCESS)
        	        		{
			                        logSqlFatal("Error in select Qry [CheckCKT].");
		        	                mysql_close(DB_MTM);
		                	        return ERROR;
			                }
			                Res1 = mysql_store_result(DB_MTM);
					iBreaches = mysql_num_rows(Res1);
					while(Row = mysql_fetch_row(Res1))
		                	{
		                        	fGetOrderBookQry(Row[0],Row[1],Row[3]);
						logDebug2("ROW 0 is %s",Row[0]);
                                                logDebug2("ROW 1 is %s",Row[1]);
                                                logDebug2("ROW 3 is %s",Row[3]);
			                }
				        mysql_free_result(Res1);
				}
				else
				{	
					logDebug3("CKT Order can't cancel configurable");
				}

				logDebug2("In Else mysql_num_rows(Res) :%i:",mysql_num_rows(Res));
				iNoOfRec = mysql_num_rows(Res);
				logDebug2("iNoOfRec :%d:",iNoOfRec);
				fNoOfRec = iNoOfRec;
				iNoOfPkt = ceil(fNoOfRec/5);
				iTempNoOfRec = iNoOfPkt;

				logDebug2("iNoOfRec :%d:",iNoOfRec);

				pC2DPosHedResp.IntRespHeader.iSeqNo = 0;
				pC2DPosHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
				pC2DPosHedResp.IntRespHeader.iErrorId = 0;
				pC2DPosHedResp.IntRespHeader.iMsgCode = TC_INT_CKT_LIMIT_NETPOS_HEADER_RESP;
				pC2DPosHedResp.IntRespHeader.cSource = SOURCE_ADMIN;
				pC2DPosHedResp.cMsgType = 'H';
				pC2DPosHedResp.iNoofRec = iNoOfRec;

				logDebug2("pC2DPosHedResp.IntRespHeader.iMsgLength = %d",pC2DPosHedResp.IntRespHeader.iMsgLength);
				logDebug2("pC2DPosHedResp.IntRespHeader.iMsgCode = %d",pC2DPosHedResp.IntRespHeader.iMsgCode);
				logDebug2("pC2DPosHedResp.IntRespHeader.iUserId = %d",pC2DPosHedResp.IntRespHeader.iUserId);
				logDebug2("pC2DPosHedResp.IntRespHeader.cSource = %c",pC2DPosHedResp.IntRespHeader.cSource);
				logDebug2("pC2DPosHedResp.iNoofRec = %d",pC2DPosHedResp.iNoofRec);


				Process_Request((CHAR *)&pC2DPosHedResp ,sizeof(struct VIEW_COMMON_HDR_RESP) );


				for(i=0;i<iNoOfPkt;i++)
				{
					memset(&pC2DPos,'\0',sizeof(struct VIEW_MTM_C2D_VIEW_NET_POSITION));
					logDebug3("***START****");

					pC2DPos.IntRespHeader.iSeqNo= 0;
					pC2DPos.IntRespHeader.iMsgLength= sizeof(struct VIEW_MTM_C2D_VIEW_NET_POSITION);
					logDebug2("pC2DPos.IntRespHeader.iMsgLength :%d:",pC2DPos.IntRespHeader.iMsgLength);
					pC2DPos.IntRespHeader.iErrorId= -1;
					pC2DPos.IntRespHeader.iTimeStamp = 0;
					pC2DPos.IntRespHeader.cSource = SOURCE_ADMIN;
					pC2DPos.IntRespHeader.iMsgCode = TC_INT_CKT_LIMIT_NET_POS_RESP;
					pC2DPos.cMsgType = 'H';
					pC2DPos.iNoofRec = iNoOfRec;

					if(iTempNoOfRec <= 1)
					{
						pC2DPos.cMsgType = 'T';
					}
					else
					{
						pC2DPos.cMsgType = 'D';
					}

					for(j=0;j<5;j++)
					{
						if((Row = mysql_fetch_row(Res)))
						{
							memset(sCommand,'\0',MAX_COMMAND_LEN);
							iQty = 0;

							pC2DPos.IntRespHeader.cSegment= Row[26][0];
							strncpy(pC2DPos.subC2Dpos[j].sClientId,Row[0],CLIENT_ID_LEN);
							strncpy(pC2DPos.subC2Dpos[j].sSecurityID,Row[1],SECURITY_ID_LEN);
							strncpy(pC2DPos.subC2Dpos[j].sExchId,Row[2],EXCHANGE_LEN);
							strncpy(pC2DPos.subC2Dpos[j].cMktType,Row[3],MARKET_LEN);
							pC2DPos.subC2Dpos[j].iBuyQty = atoi(Row[7]);
							pC2DPos.subC2Dpos[j].iBuyQtyCF = atoi(Row[8]);
							pC2DPos.subC2Dpos[j].iBuyQtyDay = atoi(Row[9]);
							pC2DPos.subC2Dpos[j].fBuyVal = atof(Row[10]);
							pC2DPos.subC2Dpos[j].fBuyValCF = atof(Row[11]);
							pC2DPos.subC2Dpos[j].fBuyValDay = atof(Row[12]);
							pC2DPos.subC2Dpos[j].fBuyAvg = atof(Row[13]);
							pC2DPos.subC2Dpos[j].iSellQty = atoi(Row[14]);
							pC2DPos.subC2Dpos[j].iSellQtyCF = atoi(Row[15]);
							pC2DPos.subC2Dpos[j].iSellQtyDay = atoi(Row[16]);
							pC2DPos.subC2Dpos[j].fSellVal = atof(Row[17]);
							pC2DPos.subC2Dpos[j].fSellValCF = atof(Row[18]);
							pC2DPos.subC2Dpos[j].fSellValDay = atof(Row[19]);
							pC2DPos.subC2Dpos[j].fSellAvg = atof(Row[20]);
							pC2DPos.subC2Dpos[j].iNetQty = atoi(Row[21]);
							pC2DPos.subC2Dpos[j].fNetVal = atof(Row[22]);
							pC2DPos.subC2Dpos[j].fNetAvg = atof(Row[23]);
							pC2DPos.subC2Dpos[j].fGrossQty = atof(Row[24]);
							pC2DPos.subC2Dpos[j].fGrossVal = atof(Row[25]);
							pC2DPos.subC2Dpos[j].cSegment = Row[26][0];
							pC2DPos.subC2Dpos[j].cProductId = Row[27][0];
							pC2DPos.subC2Dpos[j].fRelaisedProfit = atof(Row[28]);
							pC2DPos.subC2Dpos[j].iRef_ID = atoi(Row[29]);
							pC2DPos.subC2Dpos[j].fMTMPercent = atof(Row[30]);
							pC2DPos.subC2Dpos[j].fMTMLevel   = atof(Row[31]);
							pC2DPos.subC2Dpos[j].cMTMFlag    = Row[32][0];
							pC2DPos.subC2Dpos[j].fSovl       = atof(Row[33]);
							pC2DPos.subC2Dpos[j].fSoql       = atof(Row[34]);
							pC2DPos.subC2Dpos[j].fSoll       = atof(Row[35]);
							pC2DPos.subC2Dpos[j].fLtp      	 = atof(Row[36]);
							pC2DPos.subC2Dpos[j].cMTMSqrFlg	 = Row[37][0];
							fSqrPer 			 = atof(Row[38]);							
							fTotalMTM			 = atof(Row[40]);							
							fPAYIN_AMT			 = atof(Row[41]);							
							pC2DPos.subC2Dpos[j].fTradingBal = atof(Row[39]);
							iQty = atoi(Row[21]);


							logDebug2("pC2DPos.IntRespHeader.cSegment :%c:",pC2DPos.IntRespHeader.cSegment);
							logDebug2("pC2DPos.cMsgType :%c:",pC2DPos.cMsgType);
							logDebug2("pC2DPos.iNoofRec :%d:",pC2DPos.iNoofRec);
							logDebug2("pC2DPos.sClientId :%s:",pC2DPos.subC2Dpos[j].sClientId);
							logDebug2("pC2DPos.sSecurityID:%s:",pC2DPos.subC2Dpos[j].sSecurityID);
							logDebug2("pC2DPos.sExchId :%s:",pC2DPos.subC2Dpos[j].sExchId);
							logDebug2("pC2DPos.cMktType :%s:",pC2DPos.subC2Dpos[j].cMktType);
							logDebug2("pC2DPos.iBuyQty :%d:",pC2DPos.subC2Dpos[j].iBuyQty);
							logDebug2("pC2DPos.iBuyQtyCF :%d:",pC2DPos.subC2Dpos[j].iBuyQtyCF);
							logDebug2("pC2DPos.iBuyQtyDay :%d:",pC2DPos.subC2Dpos[j].iBuyQtyDay);
							logDebug2("pC2DPos.fBuyVal :%lf:",pC2DPos.subC2Dpos[j].fBuyVal);
							logDebug2("pC2DPos.fBuyValCF :%lf:",pC2DPos.subC2Dpos[j].fBuyValCF);
							logDebug2("pC2DPos.fBuyValDay :%lf:",pC2DPos.subC2Dpos[j].fBuyValDay);
							logDebug2("pC2DPos.fBuyAvg :%lf:",pC2DPos.subC2Dpos[j].fBuyAvg);
							logDebug2("pC2DPos.iSellQty :%d:",pC2DPos.subC2Dpos[j].iSellQty);
							logDebug2("pC2DPos.iSellQtyCF :%d:",pC2DPos.subC2Dpos[j].iSellQtyCF);
							logDebug2("pC2DPos.iSellQtyDay :%d:",pC2DPos.subC2Dpos[j].iSellQtyDay);
							logDebug2("pC2DPos.fSellVal :%lf:",pC2DPos.subC2Dpos[j].fSellVal);
							logDebug2("pC2DPos.fSellValCF :%lf:",pC2DPos.subC2Dpos[j].fSellValCF);
							logDebug2("pC2DPos.fSellValDay :%lf:",pC2DPos.subC2Dpos[j].fSellValDay);
							logDebug2("pC2DPos.fSellAvg :%lf:",pC2DPos.subC2Dpos[j].fSellAvg);
							logDebug2("pC2DPos.iNetQty :%d:",pC2DPos.subC2Dpos[j].iNetQty);
							logDebug2("pC2DPos.fNetVal:%lf:",pC2DPos.subC2Dpos[j].fNetVal);
							logDebug2("pC2DPos.fNetAvg :%lf:",pC2DPos.subC2Dpos[j].fNetAvg);
							logDebug2("pC2DPos.fGrossQty :%lf:",pC2DPos.subC2Dpos[j].fGrossQty);
							logDebug2("pC2DPos.fGrossVal :%lf:",pC2DPos.subC2Dpos[j].fGrossVal);
							logDebug2("pC2DPos.cSegment:%c:",pC2DPos.subC2Dpos[j].cSegment);
							logDebug2("pC2DPos.cProductIdy :%c:",pC2DPos.subC2Dpos[j].cProductId);
							logDebug2("pC2DPos.fRelaisedProfit:%lf:",pC2DPos.subC2Dpos[j].fRelaisedProfit);
							logDebug2("pC2DPos.iRef_ID :%d:",pC2DPos.subC2Dpos[j].iRef_ID);
							logDebug2("pC2DPos.fMTMPercent :%lf:",pC2DPos.subC2Dpos[j].fMTMPercent);
							logDebug2("pC2DPos.fMTMLevel :%lf:",pC2DPos.subC2Dpos[j].fMTMLevel);
							logDebug2("pC2DPos.cMTMFlag :%c:",pC2DPos.subC2Dpos[j].cMTMFlag);
							logDebug2("pC2DPos.fSovl:%lf:",pC2DPos.subC2Dpos[j].fSovl);
							logDebug2("pC2DPos.fSoql :%lf:",pC2DPos.subC2Dpos[j].fSoql);
							logDebug2("pC2DPos.fSoll :%lf:",pC2DPos.subC2Dpos[j].fSoll);
							logDebug2("pC2DPos.fLtp :%lf:",pC2DPos.subC2Dpos[j].fLtp);
							logDebug2("pC2DPos.cMTMSqrFlg:%c:",pC2DPos.subC2Dpos[j].cMTMSqrFlg);
							logDebug2("fSqrPer:%lf:",fSqrPer);
							logDebug2("fPAYIN_AMT :%lf:",fPAYIN_AMT);
							logDebug2("iQty :%d:",iQty);
							logDebug2("pC2DPos.fTradingBal :%f:",pC2DPos.subC2Dpos[j].fTradingBal);

							if(iNotifyUrl == 1)
							{
								sprintf(sCommand,"curl -m 2 -X POST %s -H 'Cache-Control: no-cache' -H 'Content-Type: application/json' -d '{\"alert_type\":\"SQUAREOFF\",\"data\":{\"client_id\":\"%s\",\"security_id\":\"%s\",\"display_name\":\"%s\",\"exchange\":\"%s\",\"product\":\"%c\",\"quantity\":\"%d\",\"ltp\":\"%f\"}}'",sCKTNotifyUrl,Row[0],Row[1],Row[42],Row[2],Row[27][0],atoi(Row[21]),atof(Row[36]));
								logDebug2("sCommand -> %s",sCommand);
								system(sCommand); //for Paytm notification.
							}

						}

						/*						if(iNotifyUrl == 1)
												{
												sprintf(sCommand,"curl -m 2 -X POST %s -H 'Cache-Control: no-cache' -H 'Content-Type: application/json' -d '{\"alert_type\":\"SQUAREOFF\",\"data\":{\"client_id\":\"%s\",\"security_id\":\"%s\",\"display_name\":\"%s\",\"exchange\":\"%s\",\"product\":\"%c\",\"quantity\":\"%d\",\"ltp\":\"%f\"}}'",sCKTNotifyUrl,Row[0],Row[1],Row[42],Row[2],Row[27][0],atoi(Row[21]),atof(Row[36]));
												logDebug2("sCommand -> %s",sCommand);
												system(sCommand); //for Paytm notification.
												}
												*/

					}
					Process_Request((CHAR *)&pC2DPos ,sizeof(struct VIEW_MTM_C2D_VIEW_NET_POSITION) );
					iTempNoOfRec--;
					logDebug3("**END***");
				}
			}
			logTimestamp("EXIT : fSendMtmPostion");
			logDebug3("*********NOTIFYTOFE EXIT*******");
		}

	}
}

void OpenMsgQue()
{
	logTimestamp("Entry : [OpenMsgQue]");


	if((iAdminQueriesToAdaptor=  OpenMsgQ(AdminQueriesToAdaptor)) == ERROR)
	{
		logFatal("Error in Opening AdminQueriesToAdaptor");
		exit(ERROR);
	}

	logDebug2("AdminQueriesToAdaptor= %d ",iAdminQueriesToAdaptor);

        if((iIntSqrOffToMemMap =  OpenMsgQ(IntSqrOffToMemMap)) == ERROR)
        {
                logFatal("Error in Opening IntSqrOffToMemMap MQ ");
                exit(ERROR);
        }

        logDebug2("iTrdRtrToD2C         = %d ",RelToOrdRtr);


	logTimestamp("Exit : [OpenMsgQue]");
}

LONG32  GetJuliDateTime()
{
	logTimestamp("ENTRY : GetJuliDateTime ");
	struct timeval tm;
	gettimeofday( &tm, NULL );
	return tm.tv_sec;
	logTimestamp("EXIT : GetJuliDateTime ");
}



void Process_Request(CHAR *sStruct,LONG32 iMsgLen)
{
	logTimestamp("Entry : [Process_Request]");
	CHAR   *sRetValu;
	char changes[50];
	memset(changes,'\0',50);
	LONG32  irelayid1         =       0;
	LONG32  iuserid     =       0;
	LONG32  iRet_Val         =       0;
	INT16	iCount = 1;
	logDebug2("sUsrId:%s:",sUsrId);
	while(sUsrId != NULL)
	{
		strncpy(sUsrId2,sUsrId,strlen(sUsrId));
		sRetValu = strtok(sUsrId2,",");
		logDebug2("sRetValu :%s:",sRetValu);
		while(sRetValu != NULL)
		{
			logDebug2("sRetValu :%s:",sRetValu);
			iuserid = atoi(sRetValu);
			logDebug2("iuserid :%d:",iuserid);


			logDebug2("sRetValu [%s] ",sRetValu);

			((struct INT_COMMON_RESP_HDR *) sStruct )->iUserId = iuserid;

			irelayid1 = find_admin_adapter (((struct INT_COMMON_RESP_HDR *) sStruct )->iUserId);
			if (irelayid1 == FIND_USER_RELAY_ERROR)
			{
				logInfo(" Admin Relay No for this particular userid is not found :%d:",((struct INT_COMMON_RESP_HDR *) sStruct )->iUserId);
			}
			else
			{
				logDebug2("Writing to AdminAdaptor");
				iRet_Val = WriteMsgQ(iAdminQueriesToAdaptor,sStruct,iMsgLen,irelayid1);
				if (iRet_Val == ERROR)
				{
					logFatal(" No Data is  present in the Packet ");
					exit(1);
				}
			}
			sRetValu = strtok(NULL,",");
		}
		logInfo("Need to Check is order is placed by Controller ");
		if(sRetValu  == NULL)
		{
			logDebug2("Here 1");
			break;
		}


	}

	//	sRetValu = strtok(NULL, ",");

	//	}

}
BOOL    fGetOrderBookQry(CHAR *sSecId, CHAR *sClientId,CHAR *sInteropSecId)
{
        logTimestamp("Entry :fGetOrderBookQry:");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        struct  ORDER_REQUEST   pEOrdReq;
        LONG32   iNoOfRec = 0;
        LONG32   i= 0;
        logDebug2("sSecId:%s:",sSecId);
        logDebug2("sClientId :%s:",sClientId);
	logDebug2("sInteropSecId :%s:",sInteropSecId);
        CHAR    sSelQry [DOUBLE_MAX_QUERY_SIZE];
        memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);


        strncpy(sWhereClause,"LIKE '%'",MAX_QUERY_SIZE);


        logDebug2("Final sWhereClause:%s:",sWhereClause);


	sprintf(sSelQry,"SELECT  ORDER_NUMBER,  SERIALNO,  SEM_SECURITY_ID,  ORDER_TYPE,  QUANTITY,  REMAINING_QUANTITY,  DISCLOSE_QTY,  DQQTYREM,  PRICE,  TRG_PRICE,  TRADEDQTY,  PRODUCT,  ORDER_VALIDITY,  EXCHORDERNO,  ORDER_DATE_TIME,  EXCH,  BUY_SELL,  SEGMENT,  TRANSCODE,  CLIENT_ID,  JDATE,  IFNULL(STRATEGY_ID, 0),  PLACEDBY,  REASON_DESCRIPTION,  PRO_CLIENT,  TRADE_PRICE,  GOOD_TILL_DATE,  LEG_NO,  IFNULL(EXPIRY_DATE, 0),  IFNULL(SOURCE_FLG, 'NA'),  IFNULL(ALGOORDERNO, 0),  IFNULL(PAN_NO, 'NA'),  IFNULL(PARTICIPANT_TYPE, 'B'),  IFNULL(MKT_PROTECT_FLG, 'N'),  IFNULL(MKT_PROTECT_VAL, 1),  IFNULL(SETTLOR, 'NA'),  IFNULL(GTC_FLG, 'N'),  IFNULL(ENCASH_FLG, 'N'),  MKT_TYPE,  USER_ID,  USER_TYPE,  GROUP_ID  FROM  (SELECT  `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,  DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,  `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,  `A`.`EQ_EXCH_ID` AS `EXCH`,  `A`.`EQ_BUY_SELL_IND` AS `BUY_SELL`,  'E' AS `SEGMENT`,  `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,  `A`.`EQ_SYMBOL` AS `SYMBOL`,  `A`.`EQ_LEG_NO` AS `LEG_NO`,  `A`.`EQ_PRODUCT_ID` AS `PRODUCT`,  (CASE  WHEN  ((`A`.`EQ_MSG_CODE` = '2073')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2074')  AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2212')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending'  WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen'  WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified'  WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded'  WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired'  WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending'  WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified'  WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered'  WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected'  END) AS `STATUS`,  `A`.`EQ_TOTAL_QTY` AS `QUANTITY`,  `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,  (CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 4), ',', '')  ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 2), ',', '')  END) AS `PRICE`,  CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  END AS `TRG_PRICE`,  `A`.`EQ_ORDER_TYPE` AS `ORDER_TYPE`,  CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,  `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,  `A`.`EQ_SERIAL_NO` AS `SERIALNO`,  `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,  `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,  `A`.`EQ_VALIDITY` AS `ORDER_VALIDITY`,  IFNULL(`A`.`EQ_LOT_SIZE`, 0) AS `SEM_NSE_REGULAR_LOT`,  0 AS `TAKE_PROFIT_TRAIL_GAP`,  `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,  `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,  `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,  IFNULL(NULLIF(`A`.`EQ_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,  `A`.`EQ_PRO_CLIENT` AS `PRO_CLIENT`,  `A`.`EQ_TRD_TRADE_PRICE` AS `TRADE_PRICE`,  IFNULL(`A`.`EQ_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,  `A`.`EQ_ENTITY_ID` AS `PLACEDBY`,  `A`.`EQ_STRATEGY_ID` AS `STRATEGY_ID`,  JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,  `A`.`EQ_MSG_CODE` AS `TRANSCODE`,  `A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`,  `A`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,  `A`.`EQ_SOURCE_FLG` AS `SOURCE_FLG`,  `A`.`EQ_ALGO_ORDER_NO` AS `ALGOORDERNO`,  `A`.`EQ_PAN_NO` AS `PAN_NO`,  `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,  `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,  `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,  `A`.`EQ_SETTLOR` AS `SETTLOR`,  `A`.`EQ_GTC_FLG` AS `GTC_FLG`,  `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,  `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,  `A`.`EQ_USER_ID` AS `USER_ID`,  `A`.`EQ_USER_TYPE` AS `USER_TYPE`,  `A`.`EQ_GROUP_ID` AS `GROUP_ID`  FROM  (SELECT MAX(EQ_SERIAL_NO) AS SER, EQ_ORDER_NO AS ORD, EQ_LEG_NO AS LEG FROM EQ_ORDERS C WHERE C.`EQ_CF_FLAG` <> -(1) AND C.`EQ_ORD_STATUS` <> 'B' GROUP BY EQ_ORDER_NO, EQ_LEG_NO) X, `EQ_ORDERS` `A`  WHERE  `A`.`EQ_SERIAL_NO` = X.SER          AND A.EQ_ORDER_NO = X.ORD  AND A.EQ_LEG_NO = X.LEG      AND `A`.`EQ_MSG_CODE` IN (2073 , 2074, 2212) AND A.EQ_PRODUCT_ID = 'I' AND A.EQ_STRATEGY_ID <> 107 AND A.EQ_INTEROPS_SCRIP = \"%s\"  ) orderbook  WHERE  1 = 1 AND SEGMENT %s  ORDER BY ORDER_DATE_TIME DESC;",sInteropSecId,sWhereClause);

	printf("\n fGetOrderBookQry :%s:\n",sSelQry);



/***
	sprintf(sSelQry,"SELECT  ORDER_NUMBER,  SERIALNO,  SEM_SECURITY_ID,  ORDER_TYPE,  QUANTITY,  REMAINING_QUANTITY,  DISCLOSE_QTY,  DQQTYREM,  PRICE,  TRG_PRICE,  TRADEDQTY,  PRODUCT,  ORDER_VALIDITY,  EXCHORDERNO,  ORDER_DATE_TIME,  EXCH,  BUY_SELL,  SEGMENT,  TRANSCODE,  CLIENT_ID,  JDATE,  IFNULL(STRATEGY_ID, 0),  PLACEDBY,  REASON_DESCRIPTION,  PRO_CLIENT,  TRADE_PRICE,  GOOD_TILL_DATE,  LEG_NO,  IFNULL(EXPIRY_DATE, 0),  IFNULL(SOURCE_FLG, 'NA'),  IFNULL(ALGOORDERNO, 0),  IFNULL(PAN_NO, 'NA'),  IFNULL(PARTICIPANT_TYPE, 'B'),  IFNULL(MKT_PROTECT_FLG, 'N'),  IFNULL(MKT_PROTECT_VAL, 1),  IFNULL(SETTLOR, 'NA'),  IFNULL(GTC_FLG, 'N'),  IFNULL(ENCASH_FLG, 'N'),  MKT_TYPE,  USER_ID,  USER_TYPE,  GROUP_ID  FROM  (SELECT  `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,  DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,  `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,  `A`.`EQ_EXCH_ID` AS `EXCH`,  `A`.`EQ_BUY_SELL_IND` AS `BUY_SELL`,  'E' AS `SEGMENT`,  `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,  `A`.`EQ_SYMBOL` AS `SYMBOL`,  `A`.`EQ_LEG_NO` AS `LEG_NO`,  `A`.`EQ_PRODUCT_ID` AS `PRODUCT`,  (CASE  WHEN  ((`A`.`EQ_MSG_CODE` = '2073')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2074')  AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2212')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending'  WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen'  WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified'  WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded'  WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired'  WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending'  WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified'  WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered'  WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected'  END) AS `STATUS`,  `A`.`EQ_TOTAL_QTY` AS `QUANTITY`,  `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,  (CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 4), ',', '')  ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 2), ',', '')  END) AS `PRICE`,  CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  END AS `TRG_PRICE`,  `A`.`EQ_ORDER_TYPE` AS `ORDER_TYPE`,  CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,  `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,  `A`.`EQ_SERIAL_NO` AS `SERIALNO`,  `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,  `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,  `A`.`EQ_VALIDITY` AS `ORDER_VALIDITY`,  IFNULL(`A`.`EQ_LOT_SIZE`, 0) AS `SEM_NSE_REGULAR_LOT`,  0 AS `TAKE_PROFIT_TRAIL_GAP`,  `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,  `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,  `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,  IFNULL(NULLIF(`A`.`EQ_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,  `A`.`EQ_PRO_CLIENT` AS `PRO_CLIENT`,  `A`.`EQ_TRD_TRADE_PRICE` AS `TRADE_PRICE`,  IFNULL(`A`.`EQ_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,  `A`.`EQ_ENTITY_ID` AS `PLACEDBY`,  `A`.`EQ_STRATEGY_ID` AS `STRATEGY_ID`,  JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,  `A`.`EQ_MSG_CODE` AS `TRANSCODE`,  `A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`,  `A`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,  `A`.`EQ_SOURCE_FLG` AS `SOURCE_FLG`,  `A`.`EQ_ALGO_ORDER_NO` AS `ALGOORDERNO`,  `A`.`EQ_PAN_NO` AS `PAN_NO`,  `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,  `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,  `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,  `A`.`EQ_SETTLOR` AS `SETTLOR`,  `A`.`EQ_GTC_FLG` AS `GTC_FLG`,  `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,  `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,  `A`.`EQ_USER_ID` AS `USER_ID`,  `A`.`EQ_USER_TYPE` AS `USER_TYPE`,  `A`.`EQ_GROUP_ID` AS `GROUP_ID`  FROM  (SELECT MAX(EQ_SERIAL_NO) AS SER, EQ_ORDER_NO AS ORD, EQ_LEG_NO AS LEG FROM EQ_ORDERS C WHERE C.`EQ_CF_FLAG` <> -(1) AND C.`EQ_ORD_STATUS` <> 'B' GROUP BY EQ_ORDER_NO, EQ_LEG_NO) X, `EQ_ORDERS` `A`  WHERE  `A`.`EQ_SERIAL_NO` = X.SER          AND A.EQ_ORDER_NO = X.ORD  AND A.EQ_LEG_NO = X.LEG      AND `A`.`EQ_MSG_CODE` IN (2073 , 2074, 2212) AND A.EQ_PRODUCT_ID = 'I' AND A.EQ_STRATEGY_ID <> 107 AND A.EQ_INTEROPS_SCRIP = \"%s\" AND A.EQ_CLIENT_ID = \"%s\" ) orderbook  WHERE  1 = 1 AND SEGMENT %s  ORDER BY ORDER_DATE_TIME DESC;",sInteropSecId,sClientId,sWhereClause);
        printf("\n fGetOrderBookQry :%s:\n",sSelQry);


        sprintf(sSelQry,"SELECT  ORDER_NUMBER,  SERIALNO,  SEM_SECURITY_ID,  ORDER_TYPE,  QUANTITY,  REMAINING_QUANTITY,  DISCLOSE_QTY,  DQQTYREM,  PRICE,  TRG_PRICE,  TRADEDQTY,  PRODUCT,  ORDER_VALIDITY,  EXCHORDERNO,  ORDER_DATE_TIME,  EXCH,  BUY_SELL,  SEGMENT,  TRANSCODE,  CLIENT_ID,  JDATE,  IFNULL(STRATEGY_ID, 0),  PLACEDBY,  REASON_DESCRIPTION,  PRO_CLIENT,  TRADE_PRICE,  GOOD_TILL_DATE,  LEG_NO,  IFNULL(EXPIRY_DATE, 0),  IFNULL(SOURCE_FLG, 'NA'),  IFNULL(ALGOORDERNO, 0),  IFNULL(PAN_NO, 'NA'),  IFNULL(PARTICIPANT_TYPE, 'B'),  IFNULL(MKT_PROTECT_FLG, 'N'),  IFNULL(MKT_PROTECT_VAL, 1),  IFNULL(SETTLOR, 'NA'),  IFNULL(GTC_FLG, 'N'),  IFNULL(ENCASH_FLG, 'N'),  MKT_TYPE,  USER_ID,  USER_TYPE,  GROUP_ID  FROM  (SELECT  `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,  DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,  `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,  `A`.`EQ_EXCH_ID` AS `EXCH`,  `A`.`EQ_BUY_SELL_IND` AS `BUY_SELL`,  'E' AS `SEGMENT`,  `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,  `A`.`EQ_SYMBOL` AS `SYMBOL`,  `A`.`EQ_LEG_NO` AS `LEG_NO`,  `A`.`EQ_PRODUCT_ID` AS `PRODUCT`,  (CASE  WHEN  ((`A`.`EQ_MSG_CODE` = '2073')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2074')  AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2212')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending'  WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen'  WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified'  WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded'  WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired'  WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending'  WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified'  WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered'  WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected'  END) AS `STATUS`,  `A`.`EQ_TOTAL_QTY` AS `QUANTITY`,  `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,  (CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 4), ',', '')  ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 2), ',', '')  END) AS `PRICE`,  CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  END AS `TRG_PRICE`,  `A`.`EQ_ORDER_TYPE` AS `ORDER_TYPE`,  CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,  `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,  `A`.`EQ_SERIAL_NO` AS `SERIALNO`,  `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,  `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,  `A`.`EQ_VALIDITY` AS `ORDER_VALIDITY`,  IFNULL(`A`.`EQ_LOT_SIZE`, 0) AS `SEM_NSE_REGULAR_LOT`,  0 AS `TAKE_PROFIT_TRAIL_GAP`,  `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,  `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,  `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,  IFNULL(NULLIF(`A`.`EQ_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,  `A`.`EQ_PRO_CLIENT` AS `PRO_CLIENT`,  `A`.`EQ_TRD_TRADE_PRICE` AS `TRADE_PRICE`,  IFNULL(`A`.`EQ_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,  `A`.`EQ_ENTITY_ID` AS `PLACEDBY`,  `A`.`EQ_STRATEGY_ID` AS `STRATEGY_ID`,  JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,  `A`.`EQ_MSG_CODE` AS `TRANSCODE`,  `A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`,  `A`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,  `A`.`EQ_SOURCE_FLG` AS `SOURCE_FLG`,  `A`.`EQ_ALGO_ORDER_NO` AS `ALGOORDERNO`,  `A`.`EQ_PAN_NO` AS `PAN_NO`,  `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,  `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,  `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,  `A`.`EQ_SETTLOR` AS `SETTLOR`,  `A`.`EQ_GTC_FLG` AS `GTC_FLG`,  `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,  `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,  `A`.`EQ_USER_ID` AS `USER_ID`,  `A`.`EQ_USER_TYPE` AS `USER_TYPE`,  `A`.`EQ_GROUP_ID` AS `GROUP_ID`  FROM  (SELECT MAX(EQ_SERIAL_NO) AS SER, EQ_ORDER_NO AS ORD, EQ_LEG_NO AS LEG FROM EQ_ORDERS C WHERE C.`EQ_CF_FLAG` <> -(1) AND C.`EQ_ORD_STATUS` <> 'B' GROUP BY EQ_ORDER_NO, EQ_LEG_NO) X, `EQ_ORDERS` `A`  WHERE  `A`.`EQ_SERIAL_NO` = X.SER          AND A.EQ_ORDER_NO = X.ORD  AND A.EQ_LEG_NO = X.LEG      AND `A`.`EQ_MSG_CODE` IN (2073 , 2074, 2212)) orderbook  WHERE  1 = 1 AND PRODUCT = 'I'  AND STRATEGY_ID <> 107  AND SEM_SECURITY_ID = \"%s\" AND CLIENT_ID = \"%s\"  AND SEGMENT %s  ORDER BY ORDER_DATE_TIME DESC;",sSecId,sClientId,sWhereClause);
        printf("\n fGetOrderBookQry :%s:\n",sSelQry);
****/
        if(mysql_query(DB_MTM_MAIN,sSelQry) != SUCCESS)
        {
                sql_Error(DB_MTM_MAIN);
                logSqlFatal("Error IN fGetOrderBookQry.");
                return ERROR;
        }

        Res = mysql_store_result(DB_MTM_MAIN);
        iNoOfRec= mysql_num_rows(Res);
        logDebug2("Rows returned from Database = :%d:",iNoOfRec);

        for (i=0;i<iNoOfRec ;i++)
        {
                logDebug2("-------- iCount = %d  ----------",i);
                if(Row = mysql_fetch_row(Res))
                {
                        memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
                        strncpy(pEOrdReq.ReqHeader.sExcgId,Row[15],EXCHANGE_LEN);
                        pEOrdReq.ReqHeader.iUserId = iUserId;
                        pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
                        pEOrdReq.ReqHeader.cSegment = Row[17][0];
                        pEOrdReq.ReqHeader.iSeqNo = atoi(Row[41]);
                        pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
                        pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
                        strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
                        strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                        strncpy(pEOrdReq.sClientId,Row[19],CLIENT_ID_LEN);
                        pEOrdReq.cProductId= Row[11][0];
                        pEOrdReq.cBuyOrSell = Row[16][0];
                        pEOrdReq.iOrderType = atoi(Row[3]);
                        pEOrdReq.iOrderValidity = atof(Row[12]);
                        pEOrdReq.iTotalQty = atoi(Row[4]);
                        pEOrdReq.iTotalQtyRem = atoi(Row[5]);
                        pEOrdReq.iDiscQty = atoi(Row[6]);
                        pEOrdReq.iDiscQtyRem = atoi(Row[7]);
                        pEOrdReq.iTotalTradedQty = atoi(Row[10]);
                        pEOrdReq.fPrice = atof(Row[8]);

                        pEOrdReq.fTriggerPrice = atof(Row[9]);
                        pEOrdReq.fOrderNum = atof(Row[0]);
                        pEOrdReq.iSerialNum = atoi(Row[1]) + 1;

                        pEOrdReq.cHandleInst = '1';
                        pEOrdReq.cProCli = Row[24][0];
                        pEOrdReq.iStratergyId= STRG_CKT_SQR_OFF;
                        pEOrdReq.iMinFillQty = atoi(Row[18]);
                        pEOrdReq.fAlgoOrderNo = atof(Row[30]);
                        pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                        strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
                        pEOrdReq.cUserType = Row[40][0] ;
                        strncpy(pEOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT LIMIT",REMARKS_LEN);


                        if(strcmp(Row[38],MKT_TYPE_NL)== 0)
                        {
                                pEOrdReq.iMktType = NORMAL_MARKET;
                        }
                        else if(strcmp(Row[38],MKT_TYPE_OL) == 0)
                        {
                                pEOrdReq.iMktType = ODDLOT_MARKET;
                        }
                        else if(strcmp(Row[38],MKT_TYPE_SP)== 0)
                        {
                                pEOrdReq.iMktType = SPOT_MARKET;
                        }
                        else if(strcmp(Row[38],MKT_TYPE_AU) == 0)
                        {
                                pEOrdReq.iMktType = AUCTION_MARKET;
                        }
                        else
                        {
                                logDebug2(" %s ",Row[38]);
                        }

                        pEOrdReq.cMarkProFlag= Row[33][0];
                        pEOrdReq.fMarkProVal= atof(Row[34]);
                        pEOrdReq.cParticipantType= Row[32][0];
                        strncpy(pEOrdReq.sSettlor,Row[35],SETTLOR_LEN);
                        pEOrdReq.cGTCFlag= Row[36][0];
                        pEOrdReq.cEncashFlag= Row[37][0];
                        pEOrdReq.iGrpId = atoi(Row[41]);
                        strncpy(pEOrdReq.sPanID,Row[31],INT_PAN_LEN);
                        logDebug2("**********CANCELLING ORDERS************");
                        logDebug2("sSettler :%s:%d:",pEOrdReq.sSettlor,SETTLOR_LEN);
                        logDebug2("sPandId :%s:%d:",pEOrdReq.sPanID,INT_PAN_LEN);
                        logDebug2("cParticipantType :%c:",pEOrdReq.cParticipantType);
                        logDebug2("iGroupId :%d:",pEOrdReq.iGrpId);
                        logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
                        logDebug2("pEOrdReq.sClientId:%s:",pEOrdReq.sClientId);
                        if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
                        {
                                perror("Error WriteMsgQ");
                                mysql_free_result(Res);
                                mysql_close(DB_MTM_MAIN);
                                exit(ERROR);
                        }
                }
        }
        fEqCoOrdExit(sSecId,sClientId,sInteropSecId);
        fEqBoOrdExit(sSecId,sClientId,sInteropSecId);
        logTimestamp("Exit :fGetOrderBookQry:");
        return TRUE;

}
BOOL fEqCoOrdExit (CHAR *sSecId, CHAR *sClientId,CHAR *sInteropSecCoId)
{
        logTimestamp("fEqCoOrdExit [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32 iNoOfRec = 0;
        LONG32 i = 0;

        struct  CO_ORDER_REQUEST   pEOrdReq;
        logDebug2("sSecId :%s:",sSecId);
        logDebug2("sClientId:%s:",sClientId);
	logDebug2("sInteropSecCoId:%s:",sInteropSecCoId);
        CHAR sSelQry[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);

        sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
                        EQ_SERIAL_NO,\
                        EQ_SCRIP_CODE,\
                        EQ_MKT_TYPE,\
                        EQ_EXCH_ID,\
                        EQ_ENTITY_ID,\
                        EQ_CLIENT_ID,\
                        EQ_BUY_SELL_IND,\
                        EQ_TOTAL_QTY,\
                        EQ_REM_QTY,\
                        EQ_DISC_QTY,\
                        EQ_DISC_REM_QTY,\
                        EQ_TOTAL_TRADED_QTY,\
                        EQ_ORDER_PRICE,\
                        EQ_TRIGGER_PRICE,\
                        EQ_VALIDITY,\
                        EQ_ORDER_TYPE,\
                        EQ_USER_ID,\
                        EQ_MIN_FILL_QTY,\
                        EQ_PRO_CLIENT,\
                        EQ_USER_TYPE,\
                        EQ_REMARKS,\
                        EQ_SOURCE_FLG,\
                        EQ_PRODUCT_ID,\
                        EQ_MSG_CODE,\
                        EQ_SEGMENT ,\
                        EQ_SL_ABSTICK_VALUE ,\
                        EQ_PR_ABSTICK_VALUE ,\
                        EQ_SL_AT_FLAG ,\
                        EQ_PR_ST_FLAG ,\
                        EQ_PAN_NO,\
                        EQ_PARTICIPANT_TYPE,\
                        EQ_SETTLOR,\
                        EQ_MKT_PROTECT_FLG,\
                        EQ_MKT_PROTECT_VAL,\
                        EQ_GTC_FLG,\
                        EQ_ENCASH_FLG,\
                        EQ_GROUP_ID \
                        FROM    EQ_ORDERS A\
                        WHERE  A.EQ_ORD_STATUS IN (\'%c\',\'%c\') \
                        AND     A.EQ_PRODUCT_ID = \'%c\' \
                        AND     A.EQ_LEG_NO =   %d \
                        AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d ) \
                        AND A.EQ_INTEROPS_SCRIP = \"%s\" AND A.EQ_SEGMENT %s" \
                        ,EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,sInteropSecCoId,sWhereClause);

        logDebug3("sSelQry :%s:",sSelQry);

        if(mysql_query(DB_MTM_MAIN,sSelQry) != SUCCESS)
        {
                sql_Error(DB_MTM_MAIN);
                logSqlFatal("Error in fEqCoOrdExit Query.");
                exit(ERROR);
        }

        Res = mysql_store_result(DB_MTM_MAIN);
        iNoOfRec= mysql_num_rows(Res);
        logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

        for(i = 0 ; i < iNoOfRec ; i++)
        {
                if(Row = mysql_fetch_row(Res))
                {
                        memset(&pEOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
                        strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
                        pEOrdReq.ReqHeader.iUserId = iUserId;
                        pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
                        pEOrdReq.ReqHeader.cSegment = Row[25][0];
                        pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
                        pEOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
                        pEOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);
                        strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
                        strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                        strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

                        pEOrdReq.cProductId= Row[23][0];
                        pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];
                        pEOrdReq.iOrderType = atoi(Row[16]);
                        pEOrdReq.iOrderValidity = iOrderVal;
                        pEOrdReq.iTotalQty = atoi(Row[8]);
                        pEOrdReq.iTotalQtyRem = atoi(Row[8]);
                        pEOrdReq.iDiscQty = atoi(Row[10]);
                        pEOrdReq.iDiscQtyRem = atoi(Row[11]);
                        pEOrdReq.iTotalTradedQty = atoi(Row[12]);
                        pEOrdReq.fPrice = atof(Row[13]);
                        pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
                        pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
                        pEOrdReq.fOrderNum = atof(Row[0]);
                        pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
                        pEOrdReq.cHandleInst = Row[19][0];
                        pEOrdReq.iStratergyId= STRG_CKT_SQR_OFF ;
                        pEOrdReq.cProCli = Row[19][0];
                        pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
                        pEOrdReq.fSLTikAbsValue = atof(Row[26]);
                        pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
                        pEOrdReq.fTrailingSLValue = 0.00 ;
                        pEOrdReq.fAlgoOrderNo = 0.00 ;
                        pEOrdReq.iNoOfLeg = 1 ;
                        pEOrdReq.iMinFillQty = atoi(Row[18]) ;
                        pEOrdReq.cSLFlag  =  Row[28][0];
                        pEOrdReq.cPBFlag  = Row[29][0];
                        pEOrdReq.cAvgLtpFlg = 0;
                        pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                        strncpy(pEOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT LIMIT",REMARKS_LEN);
                        pEOrdReq.cUserType = ADMIN_TYPE;

                        if(strcmp(Row[3],MKT_TYPE_NL)== 0)
                        {
                                pEOrdReq.iMktType = NORMAL_MARKET;
                        }
                        else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
                        {
                                pEOrdReq.iMktType = ODDLOT_MARKET;
                        }
                        else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
                        {
                                pEOrdReq.iMktType = SPOT_MARKET;
                        }
                        else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
                        {
                                pEOrdReq.iMktType = AUCTION_MARKET;
                        }
                        else
                        {
                                logDebug2(" %s ",Row[3]);
                        }
                        pEOrdReq.cMarkProFlag= Row[33][0];
                        pEOrdReq.fMarkProVal= atof(Row[34]);
                        pEOrdReq.cParticipantType= Row[31][0];
                        strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
                        pEOrdReq.cGTCFlag= Row[35][0];
                        pEOrdReq.cEncashFlag= Row[36][0];
                        pEOrdReq.iGrpId = atoi(Row[37]);
                        strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);


                        logDebug2(" pEOrdReq.CoArray[0].cBuySellInd :%c: ",pEOrdReq.CoArray[0].cBuySellInd);
                        logDebug2("pEOrdReq.CoArray[0].fTriggerPrice :%f:",pEOrdReq.CoArray[0].fTriggerPrice);
                        logDebug2("pEOrdReq.CoArray[1].fTriggerPrice :%f:",pEOrdReq.CoArray[1].fTriggerPrice);
                        logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
                        logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);

                        if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pEOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
                        {
                                perror("Error WriteMsgQ");
                                mysql_free_result(Res);
                                mysql_close(DB_MTM_MAIN);
                                exit(ERROR);
                        }
                }
        }
        logTimestamp("fEqCoOrdExit [EXIT]");
        return TRUE;
}

BOOL fEqBoOrdExit (CHAR *sSecId,CHAR *sClientId ,CHAR *sInteropSecBoId)
{
        logTimestamp("fEqBoOrdExit [ENTRY]");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        logDebug2("sSecId :%s:",sSecId);
        logDebug2("sClientId:%s:",sClientId);
	logDebug2("sInteropSecBoId:%s:",sInteropSecBoId);
        CHAR sSelQry[MAX_QUERY_SIZE];
        memset(sSelQry,'\0',MAX_QUERY_SIZE);


        LONG32  iNoOfRec = 0 ;
        LONG32  i = 0;

        struct  BO_ORDER_REQUEST   pEOrdReq;
        sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
                        EQ_SERIAL_NO,\
                        EQ_SCRIP_CODE,\
                        EQ_MKT_TYPE,\
                        EQ_EXCH_ID,\
                        EQ_ENTITY_ID,\
                        EQ_CLIENT_ID,\
                        EQ_BUY_SELL_IND,\
                        EQ_TOTAL_QTY,\
                        EQ_REM_QTY,\
                        EQ_DISC_QTY,\
                        EQ_DISC_REM_QTY,\
                        EQ_TOTAL_TRADED_QTY,\
                        EQ_ORDER_PRICE,\
                        EQ_TRIGGER_PRICE,\
                        EQ_VALIDITY,\
                        EQ_ORDER_TYPE,\
                        EQ_USER_ID,\
                        EQ_MIN_FILL_QTY,\
                        EQ_PRO_CLIENT,\
                        EQ_USER_TYPE,\
                        EQ_REMARKS,\
                        EQ_SOURCE_FLG,\
                        EQ_PRODUCT_ID,\
                        EQ_MSG_CODE,\
                        EQ_SEGMENT ,\
                        EQ_SL_ABSTICK_VALUE ,\
                        EQ_PR_ABSTICK_VALUE ,\
                        EQ_SL_AT_FLAG ,\
                        EQ_PR_ST_FLAG ,\
                        EQ_PAN_NO,\
                        EQ_PARTICIPANT_TYPE,\
                        EQ_SETTLOR,\
                        EQ_MKT_PROTECT_FLG,\
                        EQ_MKT_PROTECT_VAL,\
                        EQ_GTC_FLG,\
                        EQ_ENCASH_FLG,\
                        EQ_GROUP_ID \
                        FROM    EQ_ORDERS A\
                        WHERE   A.EQ_ORD_STATUS IN (\'%c\',\'%c\') \
                        AND     A.EQ_PRODUCT_ID = \'%c\' \
                        AND     A.EQ_LEG_NO =   %d \
                        AND     A.EQ_ALGO_ORDER_NO = -1 \
                        AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
                        AND  A.EQ_INTEROPS_SCRIP = \"%s\" AND A.EQ_SEGMENT %s",\
                        EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,sInteropSecBoId,sWhereClause);

        logDebug3("sSelQry :%s:",sSelQry);

        if(mysql_query(DB_MTM_MAIN,sSelQry) != SUCCESS)
        {
                sql_Error(DB_MTM_MAIN);
                logSqlFatal("Error in fEqBoOrdExit Query.");
                exit(ERROR);
        }

        Res = mysql_store_result(DB_MTM_MAIN);
        iNoOfRec= mysql_num_rows(Res);

        logDebug2("fEqBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

        for(i = 0; i < iNoOfRec ; i ++)
        {
                logDebug2("-------- iCount = %d  ----------",i);
                if(Row = mysql_fetch_row(Res))
                {
                        memset(&pEOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
                        strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
                        pEOrdReq.ReqHeader.iUserId = iUserId;
                        pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
                        pEOrdReq.ReqHeader.cSegment = Row[25][0];
                        pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
                        pEOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
                        pEOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);
                        strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
                        strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
                        strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

                        pEOrdReq.cProductId= Row[23][0];
                        pEOrdReq.BoArray[0].cBuySellInd = Row[7][0];
                        pEOrdReq.iOrderType = atoi(Row[16]);
                        pEOrdReq.iOrderValidity = iOrderVal;
                        pEOrdReq.fAlgoOrderNo   = -1 ;
                        pEOrdReq.iTotalQty = atoi(Row[8]);
                        pEOrdReq.iTotalQtyRem = atoi(Row[8]);
                        pEOrdReq.iDiscQty = atoi(Row[10]);
                        pEOrdReq.iDiscQtyRem = atoi(Row[11]);
                        pEOrdReq.iTotalTradedQty = atoi(Row[12]);
                        pEOrdReq.fPrice = atof(Row[13]);
                        pEOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
                        pEOrdReq.fOrderNum = atof(Row[0]);
                        pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
                        pEOrdReq.cHandleInst = Row[19][0];
                        pEOrdReq.iStratergyId= STRG_CKT_SQR_OFF;
                        pEOrdReq.cProCli = Row[19][0];
                        pEOrdReq.cUserType = ADMIN_TYPE ;
                        pEOrdReq.BoArray[0].iLegValue = LEG_1 ;
                        pEOrdReq.fSLTikAbsValue = atof(Row[26]);
                        pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
                        pEOrdReq.cSLFlag  =  Row[28][0];
                        pEOrdReq.cPBFlag  = Row[29][0];
                        pEOrdReq.cFlag    = '0';
                        pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
                        strncpy(pEOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT LIMIT",REMARKS_LEN);

                        if(strcmp(Row[3],MKT_TYPE_NL)== 0)
                        {
                                pEOrdReq.iMktType = NORMAL_MARKET;
                        }
                        else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
                        {
                                pEOrdReq.iMktType = ODDLOT_MARKET;
                        }
                        else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
                        {
                                pEOrdReq.iMktType = SPOT_MARKET;
                        }
                        else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
                        {
                                pEOrdReq.iMktType = AUCTION_MARKET;
                        }
                        else
                        {
                                logDebug2(" %s ",Row[3]);
                        }
                        pEOrdReq.cMarkProFlag= Row[33][0];
                        pEOrdReq.fMarkProVal= atof(Row[34]);
                        pEOrdReq.cParticipantType= Row[31][0];
                        strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
                        pEOrdReq.cGTCFlag= Row[35][0];
                        pEOrdReq.cEncashFlag= Row[36][0];
                        pEOrdReq.iGrpId= atoi(Row[37]);
                        strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);
                        logDebug2(" pEOrdReq.BoArray[0].cBuySellInd :%c: ",pEOrdReq.BoArray[0].cBuySellInd);
                        logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
                        logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);
                        logDebug2("iGroupId :%d:",pEOrdReq.iGrpId);

                        if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pEOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
                        {
                                perror("Error WriteMsgQ");
                                mysql_free_result(Res);
                                mysql_close(DB_MTM_MAIN);
                                exit(ERROR);
                        }
                }
        }
        logTimestamp("fEqBoOrdExit [EXIT]");
        return TRUE;
}


