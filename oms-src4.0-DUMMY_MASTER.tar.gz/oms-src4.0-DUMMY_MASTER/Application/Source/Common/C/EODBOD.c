#include "IPCS.h"
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>

MYSQL    *DB_Conn;


int main (int argc, char *argv[]){


	logTimestamp("Entry [main]");

	INT16  iExchOpt;
	CHAR sExchID  [5];
	CHAR cSegment ;
	INT16   iStatuss;
	CHAR    sStatus[40];
	CHAR    sProcName[20];
	CHAR    sA[30];
	memset(sProcName,'\0',20);

	CHAR *Pr_Query = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	setbuf(stdin,0);
	setbuf(stdout,0);

	MYSQL_RES      *Res;
	MYSQL_ROW       Row;

	DB_Conn = DB_Connect();

	if(mysql_set_server_option(DB_Conn,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");

	}

	iExchOpt= atoi(argv[1]);
	switch(iExchOpt)
	{
		case 1:
			logDebug2("\nbefor  11");
			strcpy(sExchID,NSE_EXCH);	
			cSegment = EQUITY_SEGMENT;
			logDebug2("\ncase test 111");
			break;

		case 2:
			strcpy(sExchID,  NSE_EXCH);
			cSegment = DERIVATIVE_SEGMENT;
			logDebug2("\ncase test 112");
			break;

		case 3:
			strcpy(sExchID,  NSE_EXCH);
			cSegment = CURRENCY_SEGMENT ;
			logDebug2("\ncase test 113");
			break;

		case 4:
			strcpy(sExchID, BSE_EXCH);
			cSegment = EQUITY_SEGMENT;
			logDebug2("\ncase test 11");
			break;

		case 5:
			strcpy(sExchID, MCX_EXCH);
			cSegment =  COMMODITY_SEGMENT;
			logDebug2("\ncase test 115");
			break;

		default :
			logDebug2("\nInvalid Option :%d",iExchOpt);

			return;

	};




	memset(sProcName,'\0',20);

	CHAR *Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(Sel,"SELECT BP_NEXT_SCHEDULE_DATE as DATE_NOW FROM BATCH_PROCESS WHERE BP_EXCH_ID =\"%s\" AND BP_SEGMENT= \'%c\' AND BP_BATCH_NAME = 'EOD_BOD';",sExchID		,cSegment);

	logDebug2("Sel :%s:",Sel);

	if (mysql_query(DB_Conn, Sel) != SUCCESS)
	{
		logSqlFatal("Error in selecting BP_NEXT_SCHEDULE_DATE ");
		mysql_close(DB_Conn);
		return ERROR;
	}


	Res = mysql_store_result(DB_Conn);
	Row =  mysql_fetch_row(Res);

	logDebug2("DATE_NOW :%s:",Row[0]);
	logDebug2("csegment is :%c:",cSegment);
	logDebug2("sExchID is :%s:",sExchID);

	sprintf(Pr_Query,"CALL  PR_EOD_BOD(STR_TO_DATE((\'%s\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'EOD_BOD\',\'%c\',\'%s\',@ZSTATUS);\
			SELECT  @ZSTATUS ;",Row[0],cSegment,sExchID);


	logDebug2(":%s:",Pr_Query);

	mysql_free_result(Res);

	if (mysql_query(DB_Conn, Pr_Query) != SUCCESS)
	{
		logSqlFatal("Error in call PR_EOD_BOD");
		free(Pr_Query);
		mysql_close(DB_Conn);
		return ERROR;
	}


	do
	{
		Res = mysql_store_result(DB_Conn);

		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				strcpy(sStatus,Row[0]);
				mysql_free_result(Res);
				logInfo("EOD_BOD status:%s:",sStatus);
			}	
		}

		else

		{
			logDebug2("No Result Set ");
		}

		if((iStatuss =mysql_next_result(DB_Conn)) > 0)
		{
			logDebug3("Could not execute statement:%d",iStatuss);
		}

	}while(iStatuss == 0);

	if(strncmp(sStatus,"S",1) == 0)
	{
		return TRUE;

	}
	else  
	{
		logDebug1(" PR_EOD_BOD FAIL ");

	}
	logTimestamp("Exit [main]");	

	return 0;	
}

