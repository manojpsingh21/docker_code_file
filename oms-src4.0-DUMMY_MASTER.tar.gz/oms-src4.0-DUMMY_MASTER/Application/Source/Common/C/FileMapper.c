#include <my_global.h>     /*---gcc mysqldb.c -o mysql  `mysql_config --cflags --libs`---*/
#include <mysql.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "IPCS.h"
MYSQL	 *DB_Conn;
FILE     *client_fp;
CHAR	 sAdminID[50];
CHAR     sBAdminID[30];
CHAR     sAdID1[50];

struct	BRACH_ADMIN
{
	CHAR	sBranchID[30];
	CHAR	sAdminUserId[300];
};



int main()
{ 
	logTimestamp("Entry [main]");

	MYSQL_RES      *Res;
	MYSQL_ROW       Row;
	CHAR *SelAdmin = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR     	sAdID[50];
	memset(sAdminID,'\0',50);
	memset(sBAdminID,'\0',50);	
	memset(sAdID,'\0',50);  
	memset(sAdID1,'\0',50);
	DB_Conn = DB_Connect();
	/**/
	sprintf(SelAdmin,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE, EDM_DEALER_ID FROM ENTITY_MASTER S, USER_MASTER U, ENTITY_DEALER_MAPPING WHERE S.ENTITY_TYPE = 'S' AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");		

	logDebug2("SelAdmin :%s:",SelAdmin);

	if(mysql_query(DB_Conn,SelAdmin) != SUCCESS)
	{
		sql_Error(DB_Conn);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);	
	}

	Res = mysql_store_result(DB_Conn);

	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("S.ENTITY_CODE :%s:",Row[1]);
		//	strcat
		strcpy(sAdminID,Row[0]);
		if(strcmp(sAdID,sAdminID) != 0)
		{
			strcpy(sAdID,sAdminID);	
			logDebug2("sAdID = %s",sAdID);
			//			logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			strcat(sAdID1,sAdID);
			logDebug2("sAdID = %s",sAdID1);
			logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
		}
	}
	/**/	
	logDebug2("sAdminID..... = %s",sAdID1);
	CreateFile();	
	free(SelAdmin);
	logTimestamp("Exit [main]");



}


BOOL CreateFile()
{
	logDebug2("......sAdminID = %s",sAdID1);
	MYSQL_RES      *Res;
	MYSQL_ROW       Row;
	CHAR            sDealer[ENTITY_ID_LEN];
	CHAR		sClient[CLIENT_ID_LEN];
	CHAR            sTempClient[CLIENT_ID_LEN];

	memset(sTempClient,'\0',CLIENT_ID_LEN);
	memset(sDealer,'\0',ENTITY_ID_LEN);
	memset(sClient,'\0',CLIENT_ID_LEN);

	logDebug2("FILE_PATH :%s:",FILE_PATH);

	client_fp = fopen(FILE_PATH,"w");

	CHAR *Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR *selBrnch = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(Sel,"Select x.clientid AS ClientID, u.USER_CODE AS DealerId\ 
			from (\
				SELECT ENTITY_MANAGER_CODE AS DealerId, ENTITY_CODE as ClientID\
				FROM ENTITY_MASTER\
				WHERE ENTITY_MANAGER_CODE is not null\
				and ENTITY_TYPE = 'C'\
				UNION\
				SELECT EDM_DEALER_ID as DealerId, EDM_CLIENT_ID as ClientID\
				FROM ENTITY_DEALER_MAPPING) AS x,\
			USER_MASTER AS u\
			where x.DealerId = u.USER_ENTITY_CODE\
			UNION\
			SELECT ENTITY_CODE as ClientID, USER_CODE as DealerId\
			FROM ENTITY_MASTER, USER_MASTER\
			where ENTITY_CODE = USER_ENTITY_CODE and ENTITY_TYPE = 'C'\
			order by 1;");

	logDebug2("Sel :%s:",Sel);

	if (mysql_query(DB_Conn, Sel) != SUCCESS)
	{
		logSqlFatal("Error in selecting Query [CreateFile]");
		free(Sel);
		mysql_close(DB_Conn);
		return ERROR;
	}


	Res = mysql_store_result(DB_Conn);

	if(mysql_num_rows(Res) == 0)
	{
		printf("Zero rows selected");
	}
	else
	{
		printf("Rows selected");

		while((Row = mysql_fetch_row(Res)))
		{
			//			logDebug2("sAdminID = %s",sAdminID);
			strncpy(sClient,Row[0],CLIENT_ID_LEN);
			strncpy(sDealer,Row[1],ENTITY_ID_LEN);
			//			logDebug2("sClient = %s",sClient);
			//			logDebug2("sDealer = %s",sDealer);				

			if(strncmp(sTempClient,sClient,CLIENT_ID_LEN))
			{
				fprintf(client_fp,"\n%s:%s%s",sClient,sAdID1,sDealer);
			}
			else
			{
				fprintf(client_fp,",%s",sDealer);

			}	

			memset(sTempClient,'\0',CLIENT_ID_LEN);
			strncpy(sTempClient,sClient,CLIENT_ID_LEN);
		}
		/***
		  sprintf(sSelBrnch,"SELECT USER_CODE FROM ENTITY_MASTER WHERE ENTITY_MANAGER_CODE = (SELECT ENTITY_MANAGER_CODE FROM ENTITY_MASTER WHERE ENTITY_CODE =\"%s\" ) AND ENTITY_TYPE = 'A';");

		  logDebug2("sSelBrnch :%s:",sSelBrnch);	
		  if(mysql_query(DB_Conn,sSelBrnch) != SUCCESS )
		  {
		  sql_Error(DB_Conn);	
		  }
		  free(Sel);
		  mysql_close(DB_Conn);
		 ****/
		fprintf(client_fp,"\n*");

	}			


	return(0);
}



