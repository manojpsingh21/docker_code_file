#include <string.h>	
#include <stdio.h>	
#include <stdlib.h>	
#include "IPCS.h"
#include "rdkafka.h"


int main(INT16 argc, CHAR **argv)
{
	setbuf(stdout , NULL);
        setbuf(stderr , NULL);

	rd_kafka_t *rk;
	char	sTopic[100];
	char	MessageBuf[100];
	memset(sTopic,'\0',100);
	int iCnt=0;
	strncpy(sTopic,argv[1],100);
	rk = KafkaConProducer(&sTopic);

	if(rk)
	{
		printf("\nConnected to Kafka\n");
	}
	
	while(iCnt < 200)
	{	iCnt++;
		memset(MessageBuf,'\0',100);
		printf("\nPlease enter security code( or use scode 11536) :");
	        printf("\n ->");
	        scanf(" %s",&MessageBuf);

		sprintf(MessageBuf,"Message %d",iCnt);	
		if(KafkaProducer(rk,sTopic,(char *)MessageBuf,strlen(MessageBuf)) != TRUE)
		{
			printf("\nError while message wrting\n");
		}
	}
}

	
