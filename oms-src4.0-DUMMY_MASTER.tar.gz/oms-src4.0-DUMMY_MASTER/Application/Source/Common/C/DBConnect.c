#include <stdio.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <unistd.h>



int main() 
{
	MYSQL           *DBConn;

	DBConn = DB_Connect();

	if(DBConn == NULL)
	{
		logPrintf("Mysql Server Is Down. Please Start and Connect");
	}
	else
	{
		logPrintf("Mysql Server Is UP.");
	}

	return 0;

}
