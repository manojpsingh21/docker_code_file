#include <my_global.h> 
#include <mysql.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "IPCS.h"

#define FIND_USER_RELAY_ERROR          -1
#define Max_Num_Threads                 2
#define OMS_RAWDATA                     1024

void	Process_Request();

LONG32  iTrdRtrToRel= 0;
LONG32  iAdminQueriesToAdaptor = 0;
LONG32  iAdminQueriesToAdaptor1 = 0;
LONG32  iMmapToD2C1= 0;
SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen );

//FILE    *client_rfp;

MYSQL   *DB_Conn;
/*FILE    *client_fp;
CHAR    sDealrID[50];
CHAR    sSysAdminID [50];
//CHAR    sBAdminID[30];
CHAR    sAllDlrUserId[300];
CHAR    sAllAdmUserId[300];
CHAR    sAdmin2[300];
CHAR            sFileName[FILE_NAME_LEN];
*/
struct  BRACH_ADMIN
{
	CHAR    sBranchID[30];
	CHAR    sAdminUserId[300];
};

CHAR    sRedisHostIp[URL_LEN];
CHAR    iRedisPort[10];
CHAR    sHomeDir[50];
CHAR    sRedisPass[20];
CHAR    sRedisAuthFlag[10];
CHAR    cRedisAuthFlag='\0';
LONG32  iBuffSize;


main(LONG32 argc,CHAR **argv)
{
	logTimestamp("Entry : [Main]");

	setbuf(stdout , NULL);
	setbuf(stderr , NULL);
	LONG32  iSetFlg = 0;
        if(argc != 2)
        {
                iSetFlg = atoi(argv[1]);
                logInfo("iSetFlg %d",iSetFlg);
                logDebug2("No Key Set in Redis");
        }
        else
        {
                logInfo("iSetFlg %d",iSetFlg);
                logDebug2("Flag is not set taking as default");
        }
/*   To revert changes remove this
	MYSQL_RES      *Res;
	MYSQL_ROW       Row;

	CHAR	*sDealr = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	*SelAdmin = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR    sTempDlrID[50];
	CHAR    sTempAdmin [50];
	memset(sSysAdminID ,'\0',50);
	//        memset(sBAdminID,'\0',50);
	memset(sTempDlrID,'\0',50);
	memset(sTempAdmin,'\0',50);
	memset(sAllAdmUserId,'\0',300);
	memset(sFileName,'\0',FILE_NAME_LEN);
*/
	DB_Conn = DB_Connect();

	fMsgQue();
	fLoadEnv();
	//sprintf(SelAdmin,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE S.ENTITY_TYPE = 'S' AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");
/*   To revert changes remove this
    	sprintf(sDealr,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE  ((S.ENTITY_MANAGER_TYPE = 'B' AND S.ENTITY_TYPE = 'D')) AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");


	logDebug2("sDealr :%s:",sDealr);

	if(mysql_query(DB_Conn,sDealr) != SUCCESS)
	{
		sql_Error(DB_Conn);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_Conn);

	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("S.ENTITY_CODE :%s:",Row[1]);
		//      strcat
		strcpy(sDealrID,Row[0]);
		if(strcmp(sTempDlrID,sDealrID) != 0)
		{
			strcpy(sTempDlrID,sDealrID);
			logDebug2("sTempDlrID= %s",sTempDlrID);
			//                      logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			strcat(sAllDlrUserId,sTempDlrID);
			logDebug2("sAllDlrUserId = :%s:",sAllDlrUserId);
			//logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			memset(sDealrID,'\0',50);
		}

	}

	sprintf(SelAdmin,"SELECT concat(U.USER_CODE,\",\") ,S.ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE  ((S.ENTITY_MANAGER_TYPE = 'B' AND S.ENTITY_TYPE = 'S')) AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");

	logDebug2("SelAdmin:%s:",SelAdmin);

	if(mysql_query(DB_Conn,SelAdmin) != SUCCESS)
	{
		sql_Error(DB_Conn);
		logSqlFatal("Error in Select Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_Conn);

	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("S.ENTITY_CODE :%s:",Row[1]);
		//      strcat
		strcpy(sSysAdminID,Row[0]);
		if(strcmp(sTempAdmin,sSysAdminID) != 0)
		{
			strcpy(sTempAdmin,sSysAdminID);
			logDebug2("TempAdmin  :%s:",sTempAdmin);
			//                      logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			strcat(sAllAdmUserId,sTempAdmin);
			logDebug2("sAllAdmUserId= :%s:",sAllAdmUserId);
			//logDebug2("U.USER_CODE :%s: sAdminID = %s ",Row[0],Row[0]);
			memset(sSysAdminID,'\0',50);
		}

	}

	
	logDebug2(" sAllAdmUserId = :%s:",sAllAdmUserId);
	logDebug2("sAdminID..... = %s",sAllDlrUserId);
	CreateFile();
	free(sDealr);
*/	
	if(iSetFlg != 1)
	{
		SetDealerDetails();
        	SetAllAdminDetails();
	}
        SetAdminDetails();
	Process_Request();		

	logTimestamp("Exit : [Main]");

}

void fMsgQue()
{
	logTimestamp("Entry : fMsgQue");

//	if((iTrdRtrToRel= OpenMsgQ(D2C1ToDWSAdap)) == ERROR)
	if((iTrdRtrToRel= OpenMsgQ(D2C1ToDWSD2C1Adap)) == ERROR)
	{
		logFatal("Error in Opening D2C1ToDWSAdap ");
		exit(ERROR);
	}
//	if((iTrdRtrToD2C =  OpenMsgQ(TrdRtrToD2C)) == ERROR)
	if((iMmapToD2C1=  OpenMsgQ(MmapToD2C1)) == ERROR)
	{
		logFatal("Error in Opening MmapToD2C1");
		exit(ERROR);
	}
//	if ((iAdminQueriesToAdaptor = OpenMsgQ(D2C1ToAdminAdap)) == ERROR)
	if ((iAdminQueriesToAdaptor = OpenMsgQ(D2C1ToAdminD2C1Adap)) == ERROR)
	{
		logFatal("Error in Opening MmapToD2C1");
		exit(ERROR);
	}
	if ((iAdminQueriesToAdaptor1 = OpenMsgQ(D2C1ToAdminAdap)) == ERROR)
	{
		logFatal("Error in Opening MmapToD2C1");
		exit(ERROR);
	}
	logTimestamp("Exit : fMsgQue");
	

}

/*      Function Query Changes For Revert Changes Remove This
BOOL CreateFile()
{
	logDebug2("......sAllDlrUserId = :%s:",sAllDlrUserId);
	MYSQL_RES      *Res;
	MYSQL_ROW       Row;
	CHAR            sDealer[ENTITY_ID_LEN];
	CHAR            sClient[CLIENT_ID_LEN];
	CHAR            sTempClient[CLIENT_ID_LEN];
	//CHAR            sFileName[FILE_NAME_LEN];
	memset(sTempClient,'\0',CLIENT_ID_LEN);
	memset(sDealer,'\0',ENTITY_ID_LEN);
	memset(sClient,'\0',CLIENT_ID_LEN);

	//logDebug2("FILE_PATH :%s:",FILE_PATH);

	sprintf(sFileName,"%sClientDealerMapper",FILE_SEQ);
	client_fp = fopen(sFileName,"wb+");

	CHAR *Sel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR *selBrnch = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

//	sprintf(Sel,"SELECT x.EDM_CLIENT_ID AS ClientID, u.USER_CODE AS DealerId, x.EDM_DEALER_ID AS DLER FROM ENTITY_DEALER_MAPPING AS x,\
//		     USER_MASTER AS u WHERE x.EDM_DEALER_ID = u.USER_ENTITY_CODE ORDER BY ClientID;");


	Function Query Changes For Revert Changes Remove This
	sprintf(Sel,"SELECT      x.EDM_CLIENT_ID AS ClientID,     u.USER_CODE AS DealerId,     x.EDM_DEALER_ID AS DLER FROM     ENTITY_DEALER_MAPPING AS x,     USER_MASTER AS u WHERE     x.EDM_DEALER_ID = u.USER_ENTITY_CODE     UNION SELECT      ENTITY_CODE AS ClientID, USER_CODE AS DealerId,USER_ENTITY_CODE FROM     ENTITY_MASTER,     USER_MASTER WHERE     ENTITY_CODE = USER_ENTITY_CODE         AND ENTITY_TYPE = \'C\' ORDER BY ClientID;");

	logDebug2("Sel :%s:",Sel);

	if (mysql_query(DB_Conn, Sel) != SUCCESS)
	{
		logSqlFatal("Error in selecting Query [CreateFile]");
		free(Sel);
		mysql_close(DB_Conn);
		return ERROR;
	}

	Res = mysql_store_result(DB_Conn);

	if(mysql_num_rows(Res) == 0)
	{
		printf("Zero rows selected");
	}
	else
	{
		printf("Rows selected");

		while((Row = mysql_fetch_row(Res)))
		{
			//                      logDebug2("sAdminID = %s",sAdminID);
			strncpy(sClient,Row[0],CLIENT_ID_LEN);
			strncpy(sDealer,Row[1],ENTITY_ID_LEN);
			//                      	logDebug2("sClient = %s",sClient);
			//                      	logDebug2("sDealer = %s",sDealer);

			if(strncmp(sTempClient,sClient,CLIENT_ID_LEN))
			{
				fprintf(client_fp,"\n%s:%s%s",sClient,sAllDlrUserId,sDealer);
			}
			else
			{
				fprintf(client_fp,",%s",sDealer);

			}

			memset(sTempClient,'\0',CLIENT_ID_LEN);
			strncpy(sTempClient,sClient,CLIENT_ID_LEN);
		}
		fprintf(client_fp,"\n*");

	}
	fclose(client_fp);
	return(0);
}
*/
void Process_Request()
{
	logTimestamp("Entry : [Process_Request]");

	struct  ORDER_RESPONSE    *pOE_REQUEST;
	struct  ORDER_RESPONSE    *pTrade,*pORDER_RESP;
	struct  ORDER_SPREAD_RESPONSE    *pSpOE_REQUEST;
	FILE    *fp;

	CHAR	*sPtr;
	CHAR    sCpMsgBuf[RUPEE_MAX_PACKET_SIZE];
	CHAR    sExchId[EXCHANGE_LEN];
	CHAR   *sRetValu;	
	CHAR    sFileString[OMS_RAWDATA];
	CHAR    sTempValue[10];
	CHAR    cSegment;
	CHAR    c_userType;
	CHAR    sfilename[12];
	CHAR    sD2C1DealerId[CLIENT_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sEntityId[CLIENT_ID_LEN];	
	LONG32  iTranscode       =       0;
	LONG32  ilSeqNo          =       0;
	LONG32  imsglength       =       0;
	LONG32  iSndQid          =       0;
	LONG32  iRet_Val         =       0;
	LONG32  iRet_Val1         =       0;
	ULONG64  iuserid          =       0;
	LONG32  irelayid         =       0;
	LONG32  irelayid1         =       0;
	LONG32  iAlgorelayid     =       0;
	LONG32  iPktCount        =       0;
	ULONG64  itempuserid	=       0;
	ULONG64  iOrigUserid;
	ULONG64  iD2C1DealerUserid;
	ULONG64  iD2C1ClientUserid;
	BOOL	iSendFlag	= TRUE;/***iSendFlag is added for Dealer not to get Fund hold msg  ****/
	BOOL    iFoundClient    = FALSE;/** Client created intraday and started trading so need to send trades while intraday sqroff*/
        CHAR    sUserSelQry     [MAX_QUERY_SIZE];
        MYSQL_RES      *Res;
        MYSQL_ROW       Row;

        CHAR sCommand[MAX_COMMAND_LEN];
        CHAR sKeyValue[RADIS_KEY_LEN];
        CHAR sbuff[iBuffSize];

        DOUBLE64 fOrderNum = 0;


//	logDebug2("FILE_PATH :%s:",FILE_PATH);
/*	For Revert Changes Remove This
	sprintf(sFileName,"%sClientDealerMapper",FILE_SEQ);
	client_rfp = fopen(sFileName,"r");

	if(client_rfp == NULL)
	{
		logFatal("Error in file open");
		exit(ERROR);
	}
	else
	{
		logDebug2("Open Successful");
	}
*/
	iOrigUserid = 0 ;
	while(TRUE)
	{
		iPktCount++ ;
		memset(sFileString,'\0',OMS_RAWDATA);
		memset(sTempValue,'\0',10);
		memset(sExchId  ,'\0',EXCHANGE_LEN);
		memset( &sCpMsgBuf,'\0',RUPEE_MAX_PACKET_SIZE);
		memset(sD2C1DealerId,'\0',CLIENT_ID_LEN);
		memset(sEntityId,'\0',CLIENT_ID_LEN);
		memset(sClientId,'\0',CLIENT_ID_LEN);
		iD2C1DealerUserid = 0;
		iD2C1ClientUserid = 0;
//		memset(sAdmin2,'\0',300); For Revert Changes Remove This
		iSendFlag       = TRUE;

		logDebug2("===================== No Of Pkts : %d =================",iPktCount);
		if(ReadMsgQ(iMmapToD2C1,&sCpMsgBuf,RUPEE_MAX_PACKET_SIZE,1) ==  ERROR)
		{
			logFatal("Error has occured while reading from Queue = %d ",iMmapToD2C1);
			logFatal("Error in reading the Packet ");
			exit(ERROR);
		}
		else
		{
			logDebug2("Successfully Read From %d Q,",iMmapToD2C1);
		}

		//		logDebug2("c_userType: %c",((struct ORDER_RESPONSE *)sCpMsgBuf )->cUserType);

		iuserid  = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId;
		iOrigUserid = ((struct INT_COMMON_RESP_HDR*) sCpMsgBuf )->iUserId;

		logDebug2("User Id Received in RelayDir is  : %llu",iuserid);

		cSegment = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->cSegment ;

		logDebug2("Segment : %c",cSegment);

		imsglength = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iMsgLength;

		logDebug2("msglength : %d", imsglength);

		iTranscode = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iMsgCode;

		logDebug2("Transcode : %d",iTranscode );

		ilSeqNo   =   ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iSeqNo ;

		logDebug2("lSeqNo: %d",ilSeqNo);

		memcpy(sExchId ,((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->sExcgId, EXCHANGE_LEN);

//		rewind(client_rfp);
		switch(iTranscode)
		{
			case TC_INT_ORDER_ENTRY_RSP:
			case TC_INT_ORDER_MODIFY_RSP:
			case TC_INT_ORDER_CANCEL_RSP:
			case TC_INT_TRADE_RESP:
			case TC_INT_OE_CONF_RESP:
			case TC_INT_OM_CONF_RESP:
			case TC_INT_OC_CONF_RESP:
			case TC_INT_OE_ERROR_RESP:
			case TC_INT_OM_ERROR_RESP:
			case TC_INT_OC_ERROR_RESP:
			case TC_INT_OE_FREEZE_RESP:
			case TC_INT_SL_ORDER_TRIG_RESP:
				//			case TC_INT_CON_DEL_RESP:
			case TC_INT_MKT_LMT_CONVT_RESP:
			case TC_INT_OFF_ORDER_ENTRY:
			case TC_INT_OFF_ORDER_MODIFY:
			case TC_INT_OFF_ORDER_CANCEL:	
			case TC_INT_OFF_ORDER_ENTRY_RSP:
			case TC_INT_OFF_ORDER_MODIFY_RSP:
			case TC_INT_OFF_ORDER_CANCEL_RSP:
			case TC_INT_OE_REJECTION                        :
			case TC_INT_OM_REJECTION                        :
			case TC_INT_OC_REJECTION                        :
			case TC_INT_RMS_OE_REJECTION                    :
			case TC_INT_RMS_OM_REJECTION                    :
			case TC_INT_RMS_OC_REJECTION                    :
			
				/*	pORDER_RESP=(struct ORDER_RESPONSE *) sCpMsgBuf ;
					strncpy(sClientId,pORDER_RESP->sClientId,CLIENT_ID_LEN);
					strncpy(sTempValue,pORDER_RESP->sClientId,CLIENT_ID_LEN);				
					Changed By Darshan 16th Feb 2017	*/	

				strncpy(sClientId,((struct ORDER_RESPONSE *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct ORDER_RESPONSE *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);				

				break;

			case TC_INT_MTM_BREACH_RSP:
			case TC_INT_MTM_NET_POS_RESP:
			case TC_INT_MTM_C2D_NETPOS_HEADER_RESP:
				strncpy(sClientId,((struct INT_MTM_BREACH_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct INT_MTM_BREACH_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);				
				break;
			case TC_INT_ORDER_REJECTION:
			case TC_INT_RMS_ORD_REJECTION:
			case TC_INT_AUTOBATCH_MSG_RESP:
			case TC_INT_CLIENT_ADDED_NOTIFICATION:
				if (iTranscode == TC_INT_RMS_ORD_REJECTION || iTranscode == TC_INT_CLIENT_ADDED_NOTIFICATION)
				{
					logInfo("Setting Send flag False ");
					iSendFlag       = FALSE;
				}	
				strncpy(sClientId,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);	
				break;
				/**	
				  case TC_INT_CON_DEL_RESP:
				  strncpy(sClientId,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				  strncpy(sTempValue,((struct INT_ERROR_FE_RESP *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				  break;
				 **/
			case TC_INT_CON_DEL_POS_RESP:
				strncpy(sClientId,((struct C2D_VIEW_NET_POSITION *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				strncpy(sTempValue,((struct C2D_VIEW_NET_POSITION *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				break;	
			case TC_INT_SPREAD_OE_CONF_RESP			:
			case TC_INT_SPREAD_OM_CONF_RESP			:
			case TC_INT_SPREAD_OC_CONF_RESP			:
			case TC_INT_SPREAD_OE_ERR_RESP  :
			case TC_INT_SPREAD_OM_ERR_RESP  :
			case TC_INT_SPREAD_OC_ERR_RESP  :
			
				strncpy(sClientId,((struct ORDER_SPREAD_RESPONSE *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
                                strncpy(sTempValue,((struct ORDER_SPREAD_RESPONSE *) sCpMsgBuf)->sClientId,CLIENT_ID_LEN);
				break;	

			default :
				logFatal("Invalid Transcode :%d:",iTranscode);
				continue;
				//  break;

		}
		fTrim(sTempValue,strlen(sTempValue));
		logDebug2("sTempValue [%s]",sTempValue);
		logDebug2("iOrigUserid [%d]",iOrigUserid);

	
	
		if(iSendFlag  == TRUE)
		{
		
//			while(fgets(sFileString,OMS_RAWDATA,client_rfp) != NULL)
//			{
			//	logDebug2("sFileString -> :%s: sTempValue -> :%s:",sFileString,sTempValue);

			memset(sKeyValue,'\0',RADIS_KEY_LEN);
                        sprintf(sKeyValue,"DLD2C1:%s",sClientId);
                        memset(sCommand,'\0',MAX_COMMAND_LEN);
			if(cRedisAuthFlag == 'Y')
			{
                        	sprintf(sCommand,"%s/Application/redis/Installed/bin/redis-cli -h %s -p %s -a %s HMGET %s MAP ", sHomeDir, sRedisHostIp, iRedisPort,sRedisPass,sKeyValue);
			}
			else
			{
                        	sprintf(sCommand,"%s/Application/redis/Installed/bin/redis-cli -h %s -p %s HMGET %s MAP ", sHomeDir, sRedisHostIp, iRedisPort,sKeyValue);
			}
                        logTimestamp("sCommand -> %s",sCommand);
			memset(sbuff,'\0',iBuffSize);
                        fp = popen(sCommand,"r");
                        fscanf(fp,"%s",sbuff);
                        pclose(fp);

                        logDebug2("Received message MAP : %s",sbuff);

			if(strlen(sbuff) != 0)
			{
				iFoundClient = TRUE;
				//logDebug2("sFileString[%s]",sFileString);
				sRetValu = strtok(sFileString,":");
				sprintf(sFileString,"%s",sbuff);
				sRetValu = strtok(sFileString,":");
				//logDebug2("Molu sRetValu[%s]",sRetValu);		
				if(strcmp(sRetValu,sTempValue) == 0)
				{
					while(sRetValu != NULL)
					{
						sRetValu = strtok(NULL,",");
						//logDebug2("sRetValu [%s]",sRetValu);
						if(sRetValu == NULL)
						{
							break;
						}
						logDebug2("sRetValu [%s] sTempValue [%s]",sRetValu,sTempValue);

						if(atoi(sRetValu) != iOrigUserid) 
						{
							((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId = atoi(sRetValu);
							((struct ORDER_RESPONSE *) sCpMsgBuf )->cUserType = 'C';

							iuserid = 0;
							iuserid = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId;
							irelayid = find_user_D2C1adap(iuserid);

							if (irelayid == FIND_USER_RELAY_ERROR)
							{
								logInfo("Relay No for this particular userid is not found :%d:",iuserid);
							}

							else
							{
								iRet_Val = WriteMsgQ(iTrdRtrToRel,sCpMsgBuf,imsglength,irelayid);
								if(iRet_Val == ERROR)
								{
									logFatal(" No Data is  present in the Packet ");
									//fclose(client_rfp);
									exit(1);
								}
							}

						}
					}
				}
			}

		//	}
		}
		else
		{
			 logInfo("This is end of File");
                         sprintf(sUserSelQry,"SELECT USER_CODE FROM USER_MASTER WHERE USER_ENTITY_CODE = \"%s\" ;",sTempValue);
                         logDebug2("sUserSelQry :%s:",sUserSelQry);

                         if (mysql_query(DB_Conn, sUserSelQry) != SUCCESS)
			 logInfo("This is end of File");
                         sprintf(sUserSelQry,"SELECT USER_CODE FROM USER_MASTER WHERE USER_ENTITY_CODE = \"%s\" ;",sTempValue);

                         logDebug2("sUserSelQry :%s:",sUserSelQry);

                         if (mysql_query(DB_Conn, sUserSelQry) != SUCCESS)
                         {
                        	 logSqlFatal("Error in selecting Query [CreateFile]");
                                 mysql_close(DB_Conn);
                                 return ERROR;
                         }

                         Res = mysql_store_result(DB_Conn);
			if((Row = mysql_fetch_row(Res)))
                        {
	                        ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId = atoi(Row[0]);
                                ((struct ORDER_RESPONSE *) sCpMsgBuf )->cUserType = 'C';

                                iuserid = 0;
                                iuserid = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId;
                                irelayid = find_user_D2C1adap(iuserid);

                                if (irelayid == FIND_USER_RELAY_ERROR)
                                {
	                                logInfo("Relay No for this particular userid is not found :%d:",iuserid);
                                }
                                else
                                {
                                        iRet_Val = WriteMsgQ(iTrdRtrToRel,sCpMsgBuf,imsglength,irelayid);
                                        if(iRet_Val == ERROR)
                                        {
        	                                logFatal(" No Data is  present in the Packet ");
						exit(1);
                                        }
                                }
                        }
                        mysql_free_result(Res);
			
	
		}
		if ((strlen(sClientId) == 0) && (strlen(sTempValue) == 0))
                {
                        strcpy(sClientId,"ADMIN");
                        strcpy(sTempValue,"ADMIN");
                }
                memset(sFileString,'\0',iBuffSize);
		memset(sKeyValue,'\0',RADIS_KEY_LEN);
                sprintf(sKeyValue,"ADD2C1:%s",sClientId);
                memset(sCommand,'\0',MAX_COMMAND_LEN);
		if(cRedisAuthFlag == 'Y')
		{
                	sprintf(sCommand,"%s/Application/redis/Installed/bin/redis-cli -h %s -p %s -a %s HMGET %s MAP ", sHomeDir, sRedisHostIp, iRedisPort,sRedisPass,sKeyValue);
		}
		else
		{
                	sprintf(sCommand,"%s/Application/redis/Installed/bin/redis-cli -h %s -p %s HMGET %s MAP ", sHomeDir, sRedisHostIp, iRedisPort,sKeyValue);
		}
                logTimestamp("sCommand -> %s",sCommand);
                memset(sbuff,'\0',iBuffSize);
                fp = popen(sCommand,"r");
                fscanf(fp,"%s",sbuff);
                pclose(fp);
			if (strlen(sbuff) != 0)
                        {
                                sprintf(sFileString,"%s",sbuff);
                                sRetValu = strtok(sFileString,":");
                                if(strcmp(sRetValu,sTempValue) == 0)
                                {
                                        while(sRetValu != NULL)
                                        {
                                                sRetValu = strtok(NULL,",");
                                                if(sRetValu == NULL)
                                                {
                                                        break;
                                                }
                                                logDebug2("sRetValu [%s] sTempValue [%s]",sRetValu,sTempValue);

                                                if(atoi(sRetValu) != iOrigUserid)
                                                {
                                                        ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId = atoi(sRetValu);
                                                        ((struct ORDER_RESPONSE *) sCpMsgBuf )->cUserType = 'C';

                                                        iuserid = 0;
                                                        iuserid = ((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId;


							if(iTranscode == TC_INT_AUTOBATCH_MSG_RESP || iTranscode == TC_INT_CLIENT_ADDED_NOTIFICATION)
							{
								irelayid1 = find_admin_adapter(iuserid);
								if (irelayid1 == FIND_USER_RELAY_ERROR)
	                                                        {
        	                                                        logInfo("Relay No for this particular userid is not found :%d:",iuserid);
                	                                        }
                        	                                else
                                	                        {
                                                	                iRet_Val1 = WriteMsgQ(iAdminQueriesToAdaptor1,sCpMsgBuf,imsglength,irelayid1);
                                                        	        if(iRet_Val1 == ERROR)
                                                                	{
                                                                        	logFatal(" No Data is  present in the Packet ");
                                                                         	exit(1);
                                                                	}
                                        	                        logInfo("Sending this to admin");
                                                        	}
								
							}
                                                        irelayid = find_d2c1admin_adapter(iuserid);
							
                                                        if (irelayid == FIND_USER_RELAY_ERROR)
                                                        {
                                                                logInfo("Relay No for this particular userid is not found :%d:",iuserid);
                                                        }

                                                        else
                                                        {
                                                                logInfo("Sending this to branch Admin");
                                                                iRet_Val = WriteMsgQ(iAdminQueriesToAdaptor,sCpMsgBuf,imsglength,irelayid);
                                                                if(iRet_Val == ERROR)
                                                                {
                                                                        logFatal(" No Data is  present in the Packet ");
                                                                         exit(1);
                                                                }
                                                                logTimestamp("INTERNAL ORDER NUMBER :%f: OF CLIENT ID :%s: WRITTEN TO USER ID :%d: FOR MESSAGE CODE :%d:",fOrderNum,sClientId,iuserid,iTranscode);
                                                        }

                                                }
                                        }
                                }
                        }

/* For Revert Changes Remove This
		logDebug2("sAllAdmUserId :%s:",sAllAdmUserId);
		while(sAllAdmUserId!= NULL)
		{
			strncpy(sAdmin2,sAllAdmUserId,strlen(sAllAdmUserId));
			sPtr = strtok(sAdmin2,",");
			logDebug2("sAdminval [%s]",sAdmin2);

			while(sPtr != NULL)
			{
				logDebug2("sPtr :%s:",sPtr);
				itempuserid = atoi(sPtr);
				logDebug2("itempuserid :%d:",itempuserid);
				logDebug2("atoi(itempuserid ) :%d:",itempuserid);
				logDebug2("iOrigUserid ) :%d:",iOrigUserid);
				if (itempuserid == iOrigUserid )
				{
					logDebug2("Dropping packet");
					sPtr = strtok(NULL,",");
					continue;
				}

				((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId = itempuserid;

				irelayid1 = find_admin_adapter (((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId);
				if (irelayid1 == FIND_USER_RELAY_ERROR)
				{
					logInfo(" Admin Relay No for this particular userid is not found :%llu:",((struct INT_COMMON_RESP_HDR *) sCpMsgBuf )->iUserId);
				}
				else
				{
					logDebug2("Writing to AdminAdaptor");
					iRet_Val = WriteMsgQ(iAdminQueriesToAdaptor,sCpMsgBuf,imsglength,irelayid1);
					if (iRet_Val == ERROR)
					{
						logFatal(" No Data is  present in the Packet ");
						exit(1);
					}
				}
				sPtr = strtok(NULL,",");
			}


			logInfo("Need to Check is order is placed by Controller ");
			if(sPtr == NULL)
			{
				logDebug2("Here 1");
				break;
			}


		}
 For Revert Changes Remove This*/
	}/** End of while loop **/
//	fclose(client_rfp);


}


SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen )
{
	logTimestamp("Entry : [fTrim]");

	SHORT Strlen=0;

	if ( MaxLen <= 0 )
	{
		return FALSE ;
	}

	for( ; Str_In[Strlen] != ' ' && Strlen < MaxLen ; Strlen++ )
	{
		continue;
	}
	Str_In[Strlen]='\0';

	logTimestamp("Exit : [fTrim]");
	return Strlen;
}

BOOL fLoadEnv()
{
        logDebug2("Entry |fLoadEnv|");

        memset(sHomeDir,'\0',50);
        memset(sRedisHostIp,'\0',URL_LEN);
        memset(iRedisPort,'\0',10);
	memset(sRedisPass,'\0',20);

        strncpy(sHomeDir,getenv("HOME"),50);
        logInfo("HOME DIR :%s:",sHomeDir);


        if(getenv("REDIS_HOST_SLAVE")== NULL)
        {
                strncpy(sRedisHostIp,"127.0.0.1",URL_LEN);
                logFatal("Error : Environment variables missing : REDIS_HOST_SLAVE");
        }
        else
        {
                strncpy(sRedisHostIp,getenv("REDIS_HOST_SLAVE"),URL_LEN);
                logDebug2("sRedisHostIp:%s:",sRedisHostIp);
        }

        if(getenv("REDIS_PORT_SLAVE")== NULL)
        {
                strcpy(iRedisPort, "6379");
                logFatal("Error : Environment variables missing : REDIS_PORT_SLAVE");
        }
        else
        {
                strcpy(iRedisPort, getenv("REDIS_PORT_SLAVE"));
                logDebug2("iRedisPort :%s:",iRedisPort);
        }

        if(getenv("D2C1_BUFFER_SIZE") == NULL)
        {
                iBuffSize = OMS_RAWDATA;
                logFatal("Error : Environment variables missing : D2C1_BUFFER_SIZE");
                logDebug2("iBuffSize |%d|",iBuffSize);
        }
 	else
        {
                iBuffSize = atoi(getenv("D2C1_BUFFER_SIZE"));
                logDebug2("iBuffSize |%d|",iBuffSize);
        }

	if(getenv("REDIS_PASS")== NULL)
        {
                strncpy(sRedisPass,"rupee123",20);
                logFatal("Error : Environment variables missing : REDIS_PASS");
        }
        else
        {
                strncpy(sRedisPass,getenv("REDIS_PASS"),20);
        }	

	if(getenv("REDIS_FLAG") == NULL)
        {
                logFatal("Error : Environment Variable missing : REDIS_FLAG");
                cRedisAuthFlag = sRedisAuthFlag[0];
        }
        else
        {
                strncpy(sRedisAuthFlag,getenv("REDIS_FLAG"),ENV_VARIABLE_LEN);
                cRedisAuthFlag= sRedisAuthFlag[0];
        }

        logDebug2("Exit |fLoadEnv|");
        return TRUE;
}

BOOL SetAdminDetails()
{
        logTimestamp("Entry |SetAdminDetails|");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        CHAR    SelAdmin[MAX_QUERY_SIZE];
        CHAR    sCommand[MAX_COMMAND_LEN];

        memset(SelAdmin,'\0',MAX_QUERY_SIZE);

        sprintf(SelAdmin,"SELECT GROUP_CONCAT(U.USER_CODE) AS USER_CODE ,GROUP_CONCAT(S.ENTITY_CODE) AS ENTITY_CODE FROM ENTITY_MASTER S, USER_MASTER U WHERE  ((S.ENTITY_MANAGER_TYPE = 'B' AND S.ENTITY_TYPE = 'S')) AND S.ENTITY_CODE = U.USER_ENTITY_CODE;");

        logDebug2("SelAdmin    |%s|",SelAdmin);

        if(mysql_query(DB_Conn,SelAdmin) != SUCCESS)
        {
                sql_Error(DB_Conn);
                logSqlFatal("Error in Select Query.");
                logTimestamp("Exit SetAdminDetails");
                return FALSE;
        }

        Res = mysql_store_result(DB_Conn);

        while((Row = mysql_fetch_row(Res)))
        {
                logDebug2("ENTITY_CODE = |%s|",Row[0]);
                logDebug2("USER_CODE = |%s|",Row[1]);
                memset(sCommand, '\0', MAX_COMMAND_LEN);
		if(cRedisAuthFlag == 'Y')
		{
                	sprintf(sCommand, "%s/Application/redis/Installed/bin/redis-cli -h %s -p %s -a %s HMSET ADD2C1:ADMIN MAP ADMIN:%s", sHomeDir, sRedisHostIp, iRedisPort, sRedisPass,Row[0]);
		}
		else
		{
                	sprintf(sCommand, "%s/Application/redis/Installed/bin/redis-cli -h %s -p %s HMSET ADD2C1:ADMIN MAP ADMIN:%s", sHomeDir, sRedisHostIp, iRedisPort, Row[0]);
		}
                logDebug2("sCommand is |%s|", sCommand);
                system(sCommand);
        }
        mysql_free_result(Res);
        logTimestamp("Exit |SetAdminDetails|");

}
   
BOOL SetAllAdminDetails()
{
        logTimestamp("Entry |SetAllAdminDetails|");

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        MYSQL_RES       *Res1;
        MYSQL_ROW       Row1;

        CHAR sCommand[MAX_COMMAND_LEN];
        CHAR FuncQry[QUERY_SIZE];
        CHAR SelQry[MAX_QUERY_SIZE];
        memset(FuncQry,'\0',QUERY_SIZE);
        memset(SelQry,'\0',MAX_QUERY_SIZE);

        LONG32 iNoOfRec;

        sprintf(FuncQry,"SELECT FN_QRY_CLIENT_MAP_USR_ID('A');");
        logDebug2("FuncQry |%s|",FuncQry);

        if (mysql_query(DB_Conn,FuncQry) != SUCCESS)
        {
                logSqlFatal("Error in Function Query for Dealer");
                sql_Error(DB_Conn);
                logDebug2("Exit |SetAllAdminDetails|");
                return ERROR;
        }
        Res1 = mysql_store_result(DB_Conn);
        if((Row1 = mysql_fetch_row(Res1)))
        {
                strncpy(SelQry,Row1[0],MAX_QUERY_SIZE);
                logDebug2("SelQry |%s|",SelQry);
        }
        mysql_free_result(Res1);
        if(mysql_query(DB_Conn,SelQry) != SUCCESS)
        {
                logSqlFatal("Error in Map Dealer Qry");
                sql_Error(DB_Conn);
                logDebug2("Exit |SetAllAdminDetails|");
                return ERROR;
        }
        Res = mysql_store_result(DB_Conn);
        iNoOfRec = mysql_num_rows(Res);
        logDebug2("iNoOfRec |%d|",iNoOfRec);
        if (iNoOfRec == 0)
        {
                logDebug2("Exit |SetAllAdminDetails|");
                return FALSE;
        }
        while((Row = mysql_fetch_row(Res)))
        {
                memset(sCommand, '\0', MAX_COMMAND_LEN);
                if(cRedisAuthFlag == 'Y')
		{
			sprintf(sCommand, "%s/Application/redis/Installed/bin/redis-cli -h %s -p %s -a %s HMSET ADD2C1:%s MAP %s", sHomeDir, sRedisHostIp, iRedisPort,sRedisPass ,Row[0], Row[1]);
		}
		else
		{
			sprintf(sCommand, "%s/Application/redis/Installed/bin/redis-cli -h %s -p %s HMSET ADD2C1:%s MAP %s", sHomeDir, sRedisHostIp, iRedisPort, Row[0], Row[1]);
		}
                logDebug2("sCommand is |%s|", sCommand);
                system(sCommand);
        }
        mysql_free_result(Res);
        logDebug2("Exit |SetAllAdminDetails|");
        return TRUE;
}

BOOL SetDealerDetails()
{
        logTimestamp("Entry |SetDealerDetails|");

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        MYSQL_RES       *Res1;
        MYSQL_ROW       Row1;

        CHAR sCommand[MAX_COMMAND_LEN];
        CHAR FuncQry[QUERY_SIZE];
        CHAR SelQry[MAX_QUERY_SIZE];
        memset(FuncQry,'\0',QUERY_SIZE);
        memset(SelQry,'\0',MAX_QUERY_SIZE);

        LONG32 iNoOfRec;

        sprintf(FuncQry,"SELECT FN_QRY_CLIENT_MAP_USR_ID('D');");
        logDebug2("FuncQry |%s|",FuncQry);

        if (mysql_query(DB_Conn,FuncQry) != SUCCESS)
        {
                logSqlFatal("Error in Function Query for Dealer");
                sql_Error(DB_Conn);
                logDebug2("Exit |SetDealerDetails|");
                return ERROR;
        }
        Res1 = mysql_store_result(DB_Conn);
        if((Row1 = mysql_fetch_row(Res1)))
        {
                strncpy(SelQry,Row1[0],MAX_QUERY_SIZE);
                logDebug2("SelQry |%s|",SelQry);
        }
        mysql_free_result(Res1);
        if(mysql_query(DB_Conn,SelQry) != SUCCESS)
        {
                logSqlFatal("Error in Map Dealer Qry");
                sql_Error(DB_Conn);
                logDebug2("Exit |SetDealerDetails|");
                return ERROR;
        }
        Res = mysql_store_result(DB_Conn);
        iNoOfRec = mysql_num_rows(Res);
        logDebug2("iNoOfRec |%d|",iNoOfRec);
        if (iNoOfRec == 0)
        {
                logDebug2("Exit |SetDealerDetails|");
                return FALSE;
        }
        while((Row = mysql_fetch_row(Res)))
        {
                memset(sCommand,'\0',MAX_COMMAND_LEN);
                if(cRedisAuthFlag == 'Y')
		{
			sprintf(sCommand, "%s/Application/redis/Installed/bin/redis-cli -h %s -p %s -a %s HMSET DLD2C1:%s MAP %s", sHomeDir, sRedisHostIp, iRedisPort,sRedisPass ,Row[0], Row[1]);
		}
		else
		{
			sprintf(sCommand, "%s/Application/redis/Installed/bin/redis-cli -h %s -p %s HMSET DLD2C1:%s MAP %s", sHomeDir, sRedisHostIp, iRedisPort, Row[0], Row[1]);
		}
                logDebug2("sCommand is |%s|", sCommand);
                system(sCommand);
        }
        mysql_free_result(Res);
        logDebug2("Exit |SetDealerDetails|");
        return TRUE;
}
 
