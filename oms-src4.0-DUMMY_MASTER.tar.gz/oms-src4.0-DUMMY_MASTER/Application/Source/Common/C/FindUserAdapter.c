#include        <stdio.h>
#include        "IPCS.h"

LONG32  find_user_adapter(ULONG64 iUserId)
{
	logTimestamp("Entry : [find_user_adapter]");

	struct  DWS_ADAPTER_USER_ARRAY    *ptr    ;
	struct  DWS_ADAPTER_USER_ARRAY    *Tempptr;

	LONG32		iCount    =	0	;
	LONG32		iRetVal =	ERROR	;
	CHAR		sUserId[USER_ID_LEN]	;

	memset  (sUserId,'\0',USER_ID_LEN)	;
	sprintf (sUserId,"%llu" ,iUserId)		;
	logDebug2("sUserId :%s:",sUserId);

	LockShm(DWSAdapterUserShm);

	ptr     =       (struct DWS_ADAPTER_USER_ARRAY *)OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE);
	Tempptr =       ptr;

	for(iCount=0;iCount < MAX_DWS_USERS;iCount++)
	{
		if( !(memcmp(&(Tempptr->dws_adapter_user[iCount].sUser),sUserId,USER_ID_LEN)))
		{
			iRetVal = ( Tempptr->dws_adapter_user[iCount].iRelayId );
			break;
		}
	}

	if ( (CloseSharedMemory((void *)ptr)) == ERROR )
	{
		logFatal("\n Error In Closing SharedMemory : DWSAdapterUserShm");
		UnLockShm(DWSAdapterUserShm);
		exit(1);
	}
	UnLockShm(DWSAdapterUserShm);

	logDebug3("\n iRetVal :%d:",iRetVal);
	logTimestamp("Exit : [find_user_adapter]");

	return(iRetVal);
}


LONG32  find_admin_adapter(ULONG64 iUserId)
{
	logTimestamp("Entry : [find_admin_adapter]");

	struct  ADMIN_ADAPTER_USER_ARRAY	*ptr    ;
	struct  ADMIN_ADAPTER_USER_ARRAY	*Tempptr;

	LONG32	iCount	= 0       ;
	LONG32  iRetVal = ERROR   ;
	CHAR    sUserId[USER_ID_LEN]    ;

	memset  (sUserId,'\0',USER_ID_LEN)      ;
	sprintf (sUserId,"%llu" ,iUserId)         ;
	logDebug2("sUserId :%s:",sUserId);

	LockShm(AdminAdapterUserShm);

	ptr     =       (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE);
	Tempptr =       ptr;

	for(iCount=0;iCount < MAX_DWS_USERS;iCount++)
	{
//		logDebug2("Tempptr->admin_adap_user[%d].sUser = %s",iCount, Tempptr->admin_adap_user[iCount].sUser);
//		logDebug2("sUserId :%s:",sUserId);	
//		if( (strcmp((Tempptr->admin_adap_user[iCount].sUser),sUserId))==0 )
		if( !(memcmp(&(Tempptr->admin_adap_user[iCount].sUser),sUserId,USER_ID_LEN)))
		{
			iRetVal = ( Tempptr->admin_adap_user[iCount].iRelayId );
			break;
		}
	}

	if ( (CloseSharedMemory((void *)ptr)) == ERROR )
	{
		logFatal("Error In Closing SharedMemory : AdminAdapterUserShm");
		UnLockShm(AdminAdapterUserShm);
		exit(1);
	}
	UnLockShm(AdminAdapterUserShm);

	logDebug3("iRetVal :%d:",iRetVal);
	logTimestamp("Exit : [find_admin_adapter]");

	return(iRetVal);
}

LONG32  find_d2c1admin_adapter(LONG32 iUserId)
{
        logTimestamp("Entry : [find_d2c1admin_adapter]");

        struct  ADMIN_ADAPTER_USER_ARRAY        *ptr    ;
        struct  ADMIN_ADAPTER_USER_ARRAY        *Tempptr;

        LONG32  iCount  = 0       ;
        LONG32  iRetVal = ERROR   ;
        CHAR    sUserId[USER_ID_LEN]    ;

        memset  (sUserId,'\0',USER_ID_LEN)      ;
        sprintf (sUserId,"%d" ,iUserId)         ;
        logDebug2("sUserId :%s:",sUserId);

        LockShm(AdminD2C1AdapterUserShm);

        ptr     =       (struct ADMIN_ADAPTER_USER_ARRAY *)OpenSharedMemory(AdminD2C1AdapterUserShm,AdminD2C1AdapterUserShm_SIZE);
        Tempptr =       ptr;

        for(iCount=0;iCount < MAX_DWS_USERS;iCount++)
        {
                if( (strcmp((Tempptr->admin_adap_user[iCount].sUser),sUserId))==0 )

                if( !(memcmp(&(Tempptr->admin_adap_user[iCount].sUser),sUserId,USER_ID_LEN)))
                {
                        iRetVal = ( Tempptr->admin_adap_user[iCount].iRelayId );
                        break;
                }
        }
        if ( (CloseSharedMemory((void *)ptr)) == ERROR )
        {
                logFatal("Error In Closing SharedMemory : AdminD2C1AdapterUserShm");
                UnLockShm(AdminD2C1AdapterUserShm);
                exit(1);
        }
        UnLockShm(AdminD2C1AdapterUserShm);

        logDebug3("iRetVal :%d:",iRetVal);
        logTimestamp("Exit : [find_d2c1admin_adapter]");

        return(iRetVal);
}
LONG32  find_user_D2C1adap(ULONG64 iUserId)
{
        logTimestamp("Entry : [find_user_D2C1adap]");

        struct  DWS_ADAPTER_USER_ARRAY    *ptr    ;
        struct  DWS_ADAPTER_USER_ARRAY    *Tempptr;

        LONG32          iCount    =     0       ;
        LONG32          iRetVal =       ERROR   ;
        CHAR            sUserId[USER_ID_LEN]    ;

        memset  (sUserId,'\0',USER_ID_LEN)      ;
        sprintf (sUserId,"%llu" ,iUserId)               ;
        logDebug2("sUserId :%s:",sUserId);

        LockShm(DWSD2C1UserShm);

        ptr     =       (struct DWS_ADAPTER_USER_ARRAY *)OpenSharedMemory(DWSD2C1UserShm,DWSD2C1UserShm_SIZE);
        Tempptr =       ptr;

        for(iCount=0;iCount < MAX_DWS_USERS;iCount++)
        {
                if( !(memcmp(&(Tempptr->dws_adapter_user[iCount].sUser),sUserId,USER_ID_LEN)))
                {
                        iRetVal = ( Tempptr->dws_adapter_user[iCount].iRelayId );
                        break;
                }
        }

        if ( (CloseSharedMemory((void *)ptr)) == ERROR )
        {
                logFatal("\n Error In Closing SharedMemory : DWSD2C1UserShm");
                UnLockShm(DWSD2C1UserShm);
                exit(1);
        }
        UnLockShm(DWSD2C1UserShm);

        logDebug3("\n iRetVal :%d:",iRetVal);
        logTimestamp("Exit : [find_user_D2C1adap]");

        return(iRetVal);
}

