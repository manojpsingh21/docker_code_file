//Added this process which will create dealer and broaker files without zip
#include "IPCS.h"
#include <sys/time.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <mysql.h>

FILE *fpFile;
/**
 *Declaring Variable for File Patj @nitish
 * */

CHAR   sFilePath[100];
MYSQL  		*DBCon;

main(LONG32 argc,CHAR **argv)
{
	logTimestamp("ENTRY [Main]");	
	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;

	CHAR	cMsgType;
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);
	/**
 *	Initializing File path variable  @nitish
 * */
	memset(sFilePath,'\0',100);
/***8
	if ( argc != 3 )
	{
		logDebug2("Argument to be Entered  Enter F -> CaryFwd File  ; B -> Broker_ClientFile ; C -> Admin_ClientFile ; D ->Dealer_ClientFile ; A -> ALL  AND Mention FilePath");
		exit (0);
	}
	else
	{
***/
		cMsgType  = argv[1][0];
	/*
 *	Copying Value in File Path vairable  @nitish
 * */
		strncpy(sFilePath,argv[2],100);
		
//	}
	logDebug2("cMsgType = %d ",cMsgType);
/**
 *	Printing Values in File path variable  @nitish
 *
 * **/
	logDebug2("sFilePath = %s ",sFilePath);

	DBCon = DB_Connect();

	switch (cMsgType)
	{
		case 'G' : 
			logDebug2("Generating only one Dealer  file");
			fGenerateFileOp(argv[3]);
			break ;

		case 'C' :
			logDebug2("Generating Admin File");
			//fAdminClientFile ();
			break ;

		case 'B':
			logDebug2("Generating Broker Client File");
			fBrokerClientFile ();
			break ;

		case 'D':
			logDebug2("Generating Dealer Client File");
			fDealerClientFile ();
			break ;

		case 'S':
			logDebug2("Generating Calculated SPAN  File");
			fCalSpanFileGen ();
			break ;

		case 'P':
			logDebug2("Export DB SPAN Data in File");
			fSpanFileDBExport();
			break ;

		case 'E':
			logDebug2("Generating Calculated SPAN  File");
			fDrvExpoFileGen();
			break ;

		case 'X':
			logDebug2("Generating Calculated SPAN  File");
			fMcxExpoFileGen();
			break ;
			
		case 'V':
			logDebug2("Generating Calculated SPAN  File");
			fVarElmFileGen();
			break ;
		
		case 'O':
			logDebug2("Generating Calculated SPAN  File");
			fDrvCfPosFileGen();
			break ;
		
		case 'A':
			logDebug2("Creating All Files");
			//fCarryFwdPosition ();
			fAdminClientFile ();
			fBrokerClientFile ();
			fDealerClientFile ();
			fparticipantFile ();
			fCalSpanFileGen ();
			fSpanFileDBExport();
			fDrvExpoFileGen();
			fMcxExpoFileGen();
			fVarElmFileGen();
			fDrvCfPosFileGen();
			break ;

		default :
			logDebug2(" MsgType Entered is wrong");
			break;

	}
	logTimestamp("EXIT [MAIN]");
}

BOOL  fCarryFwdPosition()
{
	logTimestamp("ENTRY fCarryFwdPosition [MAIN]");

	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32		iRow, iRow2;
	CHAR	sDealer_Id [6];
	CHAR	sSelectQry1[MAX_QUERY_SIZE];
	CHAR	sSelectQry2[MAX_QUERY_SIZE];
	memset(sSelectQry1,'\0',MAX_QUERY_SIZE);
	memset(sSelectQry2,'\0',MAX_QUERY_SIZE);
	CHAR 	sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	
	/****
 *	This is for git and code freeze trying to acheive code review check list
 *
 *
 *
 *
 * ***/

	sprintf(sSelectQry1,"SELECT s.ENTITY_CODE from ENTITY_MASTER s where s.ENTITY_TYPE = \'%c\';",DEALER_TYPE);

	if (mysql_query(DBCon, sSelectQry1) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching Dealer ID in fCarryFwdPosition.");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry1);

	Res = mysql_store_result(DBCon);
	iRow2 = (mysql_num_rows(Res));
	if(iRow2 == 0)
	{
		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow2);
		while (Row = mysql_fetch_row(Res))
		{
			strncpy(sDealer_Id ,Row[0],6);
			logDebug2("Dealer_Id :%s:",sDealer_Id);

			sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(Order_Number,''),'|',IFNULL(Exchange,''),'|',IFNULL(CLIENT_ID,''),'|',IFNULL(Buy_Sell,''),'|',IFNULL(Segment,''),'|',IFNULL(Order_Type,''),'|',IFNULL(Product,''),'|',IFNULL(Qty,''),'|',IFNULL(Price,''),'|',IFNULL(TRADE_VALUE,''),'|',IFNULL(Trade_Number,''),'|',IFNULL(Exch_Order_number,''),'|',IFNULL(SCRIP_CODE,''))  FROM VIEW_CARRY_FWD_POSITION  x  \
					WHERE \
					x.CLIENT_ID IN (SELECT e.ENTITY_CODE  FROM  ENTITY_MASTER e WHERE  ENTITY_TYPE = \'%c\'  \
						UNION ALL \
						SELECT e.ENTITY_CODE FROM ENTITY_MASTER e , ENTITY_DEALER_MAPPING b WHERE e.ENTITY_CODE = b.EDM_CLIENT_ID \
						AND b.EDM_DEALER_ID = \"%s\");",CLIENT_TYPE,sDealer_Id);

			logDebug2("Query[%s]",sSelectQry2);

			if (mysql_query(DBCon, sSelectQry2) != SUCCESS) 
			{
				logDebug2("----------------");
				sql_Error(DBCon);
				logSqlFatal("Error Fetching Dealer Location Code in fCarryFwdPosition.");
				exit(ERROR);	
			}

			Res1 = mysql_store_result(DBCon);
			iRow = mysql_num_rows(Res1);
			if (iRow == 0)
			{
				mysql_free_result(Res1);
				logInfo("No result set");
			}
			else
			{
				/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
				sprintf(sFileName,"%s/%s_%s",sFilePath,DEALER_FILE_NM,sDealer_Id);
				logDebug2("sFileName = %s",sFileName);
				logDebug2("sFilePath = %s ",sFilePath);
				fpFile = fopen(sFileName,"w+");
				if (fpFile == NULL)
				{
					logFatal("Not able to Open File in append mode");
					exit(0);
				}
				else
				{	
					while((Row = mysql_fetch_row(Res1)))
					{
						logDebug2("Row :%s:",Row[0]);

						fprintf(fpFile ,"%s\n",Row[0]);


					}

					free(Res1);
					fprintf(fpFile,"*");
					fclose(fpFile);
					//fConvToPwdPrtect(sFileName,DEALER_FILE_NM,sDealer_Id);
					fConvToPwdPrtect(sFileName,sFileName);
				}
			}
		}
	}

	logTimestamp("EXIT fCarryFwdPosition [Main]");	
}

BOOL fAdminClientFile ()
{

	logTimestamp("Entry[..AdminClientFile Main]");

	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32	iRow ,iRow1;
	CHAR	sSelectQry1[MAX_QUERY_SIZE];
	CHAR	sSelectQry2[MAX_QUERY_SIZE];
	memset(sSelectQry1,'\0',MAX_QUERY_SIZE);
	memset(sSelectQry2,'\0',MAX_QUERY_SIZE);
	CHAR 	sFileName [FILE_NAME_LEN];	
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR 	sAdmin_Id [ENTITY_ID_LEN];
	memset (sAdmin_Id ,'\0',ENTITY_ID_LEN);
// Creating Branch Admin mapped client list with name of the Branch Admin itself @nitish.
	CHAR 	sBranchId[BRANCH_ID_LEN];
	memset (sBranchId,'\0',BRANCH_ID_LEN);

	sprintf(sSelectQry1,"SELECT ENTITY_CODE,ENTITY_MANAGER_CODE from ENTITY_MASTER  WHERE ENTITY_TYPE in (\'%c\',\'%c\') AND ENTITY_MANAGER_TYPE = \"%s\";",ADMIN_TYPE,SUPER_ADMIN,BRANCH_TYPE);

	if (mysql_query(DBCon, sSelectQry1) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching Dealer ID in fAdminClientFile.");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry1);
	Res = mysql_store_result(DBCon);
	iRow1 = mysql_num_rows(Res);
	if(iRow1 == 0)
	{
		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow1);
		while (Row = mysql_fetch_row(Res))
		{
			strncpy(sAdmin_Id ,Row[0],ENTITY_ID_LEN);
			strncpy(sBranchId,Row[1],BRANCH_ID_LEN);
			/**
			  sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(ENTITY_CODE,''),'|',IFNULL(ENTITY_NAME,''),'|',IFNULL(ENTITY_ADD_1,''),'|',IFNULL(ENTITY_ADD_2,''),'|',IFNULL(ENTITY_ADD_3,''),'|',IFNULL(ENTITY_PHONE,''),'|',IFNULL(ENTITY_MOBILE,''),'|',IFNULL(ENTITY_DOB,''),'|',IFNULL(ENTITY_PAN,''),'|',IFNULL(ENTITY_NSE_CODE,'')) AS v_string FROM ENTITY_MASTER e  WHERE e.ENTITY_MANAGER_CODE =  \"%s\" AND e.ENTITY_TYPE  = \'%c\' ;",sAdmin_Id,CLIENT_TYPE);
			 **/
			sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(ENTITY_CODE,''),'|',IFNULL(ENTITY_NAME,''),'|',IFNULL(ENTITY_PAN, ''),'|',\
					(CASE WHEN ENTITY_EMAIL IS NULL THEN 'NA' WHEN ENTITY_EMAIL ='' THEN 'NA' ELSE ENTITY_EMAIL END),\
					'|',(CASE WHEN ENTITY_MOBILE IS NULL THEN 0 WHEN ENTITY_MOBILE ='' THEN 0 ELSE ENTITY_MOBILE END),\
					'|',(CASE WHEN ENTITY_PHONE IS NULL THEN 0 WHEN ENTITY_PHONE ='' THEN 0 ELSE ENTITY_PHONE END),'|',ENTITY_SUB_TYPE, \
					'|',ENTITY_SETTLOR,'|',ENTITY_SETTLOR_DRV,'|',ENTITY_SETTLOR_CURR, \
					'|',ENTITY_BSE_SETTLOR,'|',ENTITY_BSE_SETTLOR_DRV,'|',ENTITY_BSE_SETTLOR_COMM,'|',ENTITY_BSE_SETTLOR_CURR) \
					FROM ENTITY_MASTER e  WHERE e.ENTITY_MANAGER_CODE =  \"%s\" AND e.ENTITY_TYPE  = \'%c\'  AND e.ENTITY_SUB_TYPE NOT IN (8);",sBranchId,CLIENT_TYPE);
			logDebug2("Query[%s]",sSelectQry2); 

			if (mysql_query(DBCon, sSelectQry2) != SUCCESS)
			{
				logDebug2("----------------");
				sql_Error(DBCon);
				logSqlFatal("Error Fetching Client Details for Admin in fAdminClientFile");
				exit(ERROR);
			}
		Res1 = mysql_store_result(DBCon);
			iRow = mysql_num_rows(Res1);	
			if (iRow == 0)
			{
				mysql_free_result(Res1);
				logInfo("No result set");
			}
			else
			{
				logDebug2("No of Rows Selected = %d",iRow);			
				logDebug2("Dealer_Id :%s:",sAdmin_Id);
				/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
				sprintf(sFileName,"%s/%s",sFilePath,sAdmin_Id);
				logDebug2("sFileName = %s",sFileName);
				logDebug2("sFilePath = %s ",sFilePath);
				fpFile = fopen(sFileName,"w+");
				if (fpFile == NULL)
				{
					logFatal("Not able to Open File in write mode");
					exit(0);
				}
				else
				{	
					while((Row = mysql_fetch_row(Res1)))
					{
						logDebug2("Row :%s:",Row[0]);
						fprintf(fpFile ,"%s\n",Row[0]);

					}
				}
				mysql_free_result(Res1);
				fprintf(fpFile,"*");
				fclose(fpFile);
				fConvToPwdPrtect(sFileName,sFileName);
			}

		}
	}

	logTimestamp("EXIT fAdminClientFile  [Main]");
}


BOOL fBrokerClientFile ()
{
	logTimestamp("ENTRY fBrokerClientFile [Main]");
	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32	iRow ,iRow1;
	CHAR    sDealer_Id [DEALER_ID_LEN];
	CHAR	sSelectQry1 [MAX_QUERY_SIZE];
	CHAR    sSelectQry2 [MAX_QUERY_SIZE];
	memset(sSelectQry1,'\0',MAX_QUERY_SIZE);
	memset(sSelectQry2,'\0',MAX_QUERY_SIZE);
	CHAR 	sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);

	sprintf(sSelectQry1,"SELECT s.ENTITY_CODE from ENTITY_MASTER s where s.ENTITY_TYPE in ('D','A','S') and s.ENTITY_MANAGER_TYPE  = 'B';",DEALER_TYPE);
	if (mysql_query(DBCon, sSelectQry1) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching Dealer ID in fBrokerClientFile.");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry1);
	Res = mysql_store_result(DBCon);
	iRow1 = mysql_num_rows(Res);
	if(iRow1 == 0)
	{	

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow1);
		sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(ENTITY_CODE, ''),'|',IFNULL(ENTITY_NAME, ''),'|',IFNULL(ENTITY_PAN, ''),'|',\
			(CASE WHEN ENTITY_EMAIL IS NULL THEN 'NA' WHEN ENTITY_EMAIL ='' THEN 'NA' ELSE ENTITY_EMAIL END),\
				'|',(CASE WHEN ENTITY_MOBILE IS NULL THEN 0 WHEN ENTITY_MOBILE ='' THEN 0 ELSE ENTITY_MOBILE END),\
				'|',(CASE WHEN ENTITY_PHONE IS NULL THEN 0 WHEN ENTITY_PHONE ='' THEN 0 ELSE ENTITY_PHONE END),\
				'|',ENTITY_SUB_TYPE,'|',ENTITY_SETTLOR,'|',ENTITY_SETTLOR_DRV,'|',ENTITY_SETTLOR_CURR ,\
				'|',ENTITY_BSE_SETTLOR,'|',ENTITY_BSE_SETTLOR_DRV,'|',ENTITY_BSE_SETTLOR_COMM,'|',ENTITY_BSE_SETTLOR_CURR) \
			FROM ENTITY_MASTER WHERE ENTITY_TYPE = \'%c'\  AND ENTITY_SUB_TYPE NOT IN (8) ;",CLIENT_TYPE);

		logDebug2("Query[%s]",sSelectQry2);

		if (mysql_query(DBCon, sSelectQry2) != SUCCESS)
		{
			logDebug2("----------------");
			sql_Error(DBCon);
			logSqlFatal("Error Fetching Dealer Location Code in fBrokerClientFile.");
			exit(ERROR);
		}
		Res1 = mysql_store_result(DBCon);
		iRow = mysql_num_rows(Res1);
		logDebug2("No of clients = :%d:",iRow);
		if (iRow == 0)
		{
			mysql_free_result(Res1);
			logInfo("GOT no result set");
		}
		else
		{
			while (Row = mysql_fetch_row(Res))
			{
				memset(sDealer_Id,'\0',DEALER_ID_LEN);
				strncpy(sDealer_Id ,Row[0],DEALER_ID_LEN);
				fTrim(sDealer_Id,strlen(sDealer_Id));
				logDebug2("No of Rows Selected = %d",iRow);
				logDebug2("Dealer_Id :%s:",sDealer_Id);
				/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
				logDebug2("sFilePath = %s",sFilePath);
				sprintf(sFileName,"%s/%s",sFilePath,sDealer_Id);
				logDebug2("sFileName = %s",sFileName);
				logDebug2("sFilePath = %s ",sFilePath);
				fpFile = fopen(sFileName,"wb");

				if (fpFile == NULL)
				{
					logFatal("Not able to Open File in append mode");
					exit(0);
				}
				else
				{
					while((Row = mysql_fetch_row(Res1)))
					{
						//	logDebug2("Row :%s:",Row[0]);
						fprintf(fpFile ,"%s\n",Row[0]);

					}
				}
				mysql_data_seek(Res1,0);
				iRow = mysql_num_rows(Res1);
				logDebug2("No of clients = :%d:",iRow);
				fprintf(fpFile,"*");
				fclose(fpFile);
				logDebug2("sDealer_Id :%s: :%s:",sDealer_Id,CLIENT_FILE_NM);
				fConvToPwdPrtect(sFileName,sFileName);
			}
		}
		mysql_free_result(Res1);
	}

	logTimestamp("EXIT fBrokerClientFile [Main]");
}

BOOL fDealerClientFile ()	
{
	logTimestamp("ENTRY fDealerClientFile [Main]");

	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32	iRow ,iRow1;
	CHAR    sDealer_Id [DEALER_ID_LEN];
	CHAR	sSelectQry1 [MAX_QUERY_SIZE];
	CHAR    sSelectQry2 [MAX_QUERY_SIZE];
	memset(sSelectQry1,'\0',MAX_QUERY_SIZE);
	memset(sSelectQry2,'\0',MAX_QUERY_SIZE);
	CHAR 	sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	//create file for those dealer who are not broker level
	sprintf(sSelectQry1,"SELECT s.ENTITY_CODE from ENTITY_MASTER s where s.ENTITY_TYPE = \'%c\'  and s.ENTITY_MANAGER_TYPE != 'B';",DEALER_TYPE);
	if (mysql_query(DBCon, sSelectQry1) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching Dealer ID in fDealerClientFile.");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry1);
	Res = mysql_store_result(DBCon);
	iRow1 = mysql_num_rows(Res);
	if(iRow1 == 0)
	{	

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow1);
		while (Row = mysql_fetch_row(Res))
		{
			strncpy(sDealer_Id ,Row[0],DEALER_ID_LEN);
			fTrim(sDealer_Id,strlen(sDealer_Id));
			/**
			  sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(e.ENTITY_CODE,'') , '|' , IFNULL(e.ENTITY_NAME,'') , '|' , IFNULL(e.ENTITY_ADD_1,'') , '|' , IFNULL(e.ENTITY_ADD_2,'') , '|' , IFNULL(e.ENTITY_ADD_3,'') , '|' , IFNULL(e.ENTITY_PHONE,'') , '|' , IFNULL(e.ENTITY_MOBILE,'') , '|' , IFNULL(e.ENTITY_DOB,'') , '|' , IFNULL(e.ENTITY_PAN,'') , '|' , IFNULL(e.ENTITY_NSE_CODE,'')) AS v_string \
			  FROM ENTITY_MASTER AS  e, ENTITY_DEALER_MAPPING AS b where e.ENTITY_CODE = b.EDM_CLIENT_ID AND b.edm_dealer_id =\"%s\"",sDealer_Id);
			 **/

			sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(ENTITY_CODE,''),'|',IFNULL(ENTITY_NAME,''),'|',IFNULL(ENTITY_PAN, ''),\
				'|',(CASE WHEN ENTITY_EMAIL IS NULL THEN 'NA' WHEN ENTITY_EMAIL ='' THEN 'NA' ELSE ENTITY_EMAIL END),\
					'|',(CASE WHEN ENTITY_MOBILE IS NULL THEN 0 WHEN ENTITY_MOBILE ='' THEN 0 ELSE ENTITY_MOBILE END),\
					'|',(CASE WHEN ENTITY_PHONE IS NULL THEN 0 WHEN ENTITY_PHONE ='' THEN 0 ELSE ENTITY_PHONE END),\
					'|',ENTITY_SUB_TYPE,'|',ENTITY_SETTLOR,'|',ENTITY_SETTLOR_DRV,'|',ENTITY_SETTLOR_CURR,\
					'|',ENTITY_BSE_SETTLOR,'|',ENTITY_BSE_SETTLOR_DRV,'|',ENTITY_BSE_SETTLOR_COMM,'|',ENTITY_BSE_SETTLOR_CURR) \
					FROM ENTITY_MASTER AS  e, \
				ENTITY_DEALER_MAPPING AS b where e.ENTITY_CODE = b.EDM_CLIENT_ID  AND b.edm_dealer_id =\"%s\"  AND e.ENTITY_SUB_TYPE NOT IN (8);",sDealer_Id); 
			logDebug2("Query[%s]",sSelectQry2);

			if (mysql_query(DBCon, sSelectQry2) != SUCCESS)
			{
				logDebug2("----------------");
				sql_Error(DBCon);
				logSqlFatal("Error Fetching Dealer Location Code in fDealerClientFile.");
				exit(ERROR);
			}
			Res1 = mysql_store_result(DBCon);
			iRow = mysql_num_rows(Res1);
			if (iRow == 0)
			{
				mysql_free_result(Res1);
				logInfo(" Nishant no result set");
			}
			else
			{
				logDebug2("No of Rows Selected = %d",iRow);
				logDebug2("Dealer_Id :%s:",sDealer_Id);
				/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
				logDebug2("sFilePath = %s",sFilePath);
				sprintf(sFileName,"%s/%s",sFilePath,sDealer_Id);
				logDebug2("sFileName = %s",sFileName);
				logDebug2("sFilePath = %s ",sFilePath);
				fpFile = fopen(sFileName,"wb");

				if (fpFile == NULL)
				{
					logFatal("Not able to Open File in append mode");
					exit(0);
				}
				else
				{
					while((Row = mysql_fetch_row(Res1)))
					{
						logDebug2("Row :%s:",Row[0]);
						fprintf(fpFile ,"%s\n",Row[0]);

					}
				}
				mysql_free_result(Res1);
				fprintf(fpFile,"*");
				fclose(fpFile);
				logDebug2("sDealer_Id :%s: :%s:",sDealer_Id,CLIENT_FILE_NM);
				fConvToPwdPrtect(sFileName,sFileName);
			}
		}
	}
	logTimestamp("EXIT fDealerClientFile[Main]");
}

BOOL fparticipantFile ()
{
	logTimestamp("ENTRY fparticipantFile [Main]");

	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32  iRow;
	CHAR    sSelectQry [MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	CHAR sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);

	sprintf(sSelectQry,"select concat(ifnull(PM_EXCHANGE,''),'|',ifnull(PM_SEGMENT,''),'|',\
		PM_PARTICIPANT_NAME,'|',PM_PARTICIPANT_ID) \
		from PARTICIPANT_MASTER s WHERE         s.PM_DELETE_FLAG = 'N'        AND s.PM_PARTICIPANT_STATUS = 'A';");

	logDebug2("Query[%s]",sSelectQry);

	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching Participant Code in fParticipantFile.");
		exit(ERROR);
	}
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if (iRow == 0)
	{
		mysql_free_result(Res);
		logInfo("No result set");
	}

	else
	{
		logDebug2("No of rows selected for fParticipantFile = %d",iRow);
		/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
		sprintf(sFileName,"%s/%s",sFilePath,PART_FILE_NM);
		logDebug2("sFileName = %s",sFileName);
		logDebug2("sFilePath = %s ",sFilePath);
		fpFile = fopen(sFileName,"wb");
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				logDebug2("Row :%s:",Row[0]);
				/*
				   strncpy(sString,Row[0],strlen(Row[0]));
				   for (i=0; sString[i]!= '\0'; i++)
				   {
				   if (sString[i] == '*')
				   {
				   for (j=0; j<1; j++)
				   {
				   sString[i+j] = '';
				   }
				   }
				   }
				   */

				fprintf(fpFile ,"%s\n",Row[0]);

			}
			mysql_free_result(Res);
			fprintf(fpFile,"*\n");
			fclose(fpFile);

			fConvToPwdPrtect(sFileName,sFileName);
		}

	}
	logTimestamp("EXIT fParticipantFile [Main]");
}

//void 	fConvToPwdPrtect(CHAR *sFileName,CHAR *sPreFix,CHAR *sDealerID)
void 	fConvToPwdPrtect(CHAR *sFileName,CHAR *sFileName1)
{
	logTimestamp("Entry :fConvToPwdPrtect:");
	CHAR	sCommand[200];

	memset(&sCommand,'\0',200);	


	logDebug2("sFileName :%s:%s:",sFileName,sFileName1);	

	//sprintf(sCommand,"zip -P rupee123 %s_%s.rrs %s",sPreFix,sDealerID,sFileName);	
	//	sprintf(sCommand,"zip -P %s %s.rrs %s",ZIP_PASSWORD,sFileName1,sFileName);	
	sprintf(sCommand,"zip  %s.zip %s",sFileName1,sFileName);	
	logDebug2("sCommand :%s:",sCommand);
	//	system(sCommand);


	memset(&sCommand,'\0',200);	

	//	sprintf(sCommand,"rm -f %s",sFileName);	
	logDebug2("sCommand :%s:",sCommand);
	system(sCommand);

	logTimestamp("Exit :fConvToPwdPrtect:");

}

BOOL fCalSpanFileGen()
{
	logTimestamp("Entry : fCalSpanFileGen");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset  (sSeq,'\0',30);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,CALCSPAN_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"SELECT  CONCAT(SM_EXCHANGE,     ',',     SM_SCRIP_CODE,     ',',     SM_EXCH_SYMBOL,     ',',     SM_EXPIRY_DATE,     ',',     IFNULL(SM_STRIKE_PRICE,0),     ',',     SM_INSTRUMENT_NAME,     ',',     SM_LOT_SIZE,     ',',     SM_OPTION_TYPE,     ',',     BUY_SPAN,     ',',     SELL_SPAN,     ',',     BUY_EXPOSURE,     ',',     SELL_EXPOSURE,     IFNULL(ROUND((BUY_SPAN / (BUY_SPAN + BUY_EXPOSURE)) * 100,     2),     0),     ',',     IFNULL(ROUND((SELL_SPAN / (SELL_SPAN + SELL_EXPOSURE)) * 100,     2),     0),     ',',     IFNULL(ROUND((BUY_EXPOSURE / (BUY_SPAN + BUY_EXPOSURE)) * 100,     2),     0),     ',',     IFNULL(ROUND((SELL_EXPOSURE / (SELL_SPAN + SELL_EXPOSURE)) * 100,     2),     0)) AS REPORT FROM     (SELECT  S.SM_EXCHANGE,     S.SM_SCRIP_CODE,     S.SM_EXCH_SYMBOL,     S.SM_EXPIRY_DATE,     S.SM_STRIKE_PRICE,     S.SM_INSTRUMENT_NAME,     S.SM_LOT_SIZE,     S.SM_OPTION_TYPE,     IFNULL(CASE     WHEN S.SM_INSTRUMENT_NAME LIKE 'OPT%' THEN 0     ELSE GREATEST(S.SM_LOT_SIZE * A.RSM_SPAN_1, S.SM_LOT_SIZE * A.RSM_SPAN_2, S.SM_LOT_SIZE * A.RSM_SPAN_3, S.SM_LOT_SIZE * A.RSM_SPAN_4, S.SM_LOT_SIZE * A.RSM_SPAN_5, S.SM_LOT_SIZE * A.RSM_SPAN_6, S.SM_LOT_SIZE * A.RSM_SPAN_7, S.SM_LOT_SIZE * A.RSM_SPAN_8, S.SM_LOT_SIZE * A.RSM_SPAN_9, S.SM_LOT_SIZE * A.RSM_SPAN_10, S.SM_LOT_SIZE * A.RSM_SPAN_11, S.SM_LOT_SIZE * A.RSM_SPAN_12, S.SM_LOT_SIZE * A.RSM_SPAN_13, S.SM_LOT_SIZE * A.RSM_SPAN_14, S.SM_LOT_SIZE * A.RSM_SPAN_15, S.SM_LOT_SIZE * A.RSM_SPAN_16, S.SM_LOT_SIZE * A.RSM_SOM)     END, 0) AS BUY_SPAN,     IFNULL(GREATEST(- S.SM_LOT_SIZE * A.RSM_SPAN_1, - S.SM_LOT_SIZE * A.RSM_SPAN_2, - S.SM_LOT_SIZE * A.RSM_SPAN_3, - S.SM_LOT_SIZE * A.RSM_SPAN_4, - S.SM_LOT_SIZE * A.RSM_SPAN_5, - S.SM_LOT_SIZE * A.RSM_SPAN_6, - S.SM_LOT_SIZE * A.RSM_SPAN_7, - S.SM_LOT_SIZE * A.RSM_SPAN_8, - S.SM_LOT_SIZE * A.RSM_SPAN_9, - S.SM_LOT_SIZE * A.RSM_SPAN_10, - S.SM_LOT_SIZE * A.RSM_SPAN_11, - S.SM_LOT_SIZE * A.RSM_SPAN_12, - S.SM_LOT_SIZE * A.RSM_SPAN_13, - S.SM_LOT_SIZE * A.RSM_SPAN_14, - S.SM_LOT_SIZE * A.RSM_SPAN_15, - S.SM_LOT_SIZE * A.RSM_SPAN_16, - S.SM_LOT_SIZE * A.RSM_SOM), 0) AS SELL_SPAN,     IFNULL((CASE     WHEN S.SM_INSTRUMENT_NAME LIKE 'OPT%' THEN 0     WHEN S.SM_INSTRUMENT_NAME = 'FUTIDX' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * SM_EXPOSER_PERC / 100)     WHEN S.SM_INSTRUMENT_NAME = 'FUTSTK' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * RFEM.RFEM_EFF_EXP_LIMIT / 100)     WHEN     S.SM_INSTRUMENT_NAME = 'FUTCUR'     THEN     CASE     WHEN S.SM_CROSS_CUR_FLAG = 'Y' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * 1000 * S.SM_CURRENCY_MULTIPLIER * 1 / 100)     ELSE ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * 1000 * 1 / 100)     END     WHEN S.SM_INSTRUMENT_NAME = 'FUTCOM' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE * S.SM_MCX_MULTIPLIER) * RMEM.RMEM_ELM_Long / 100)     ELSE 0     END), 0) AS BUY_EXPOSURE,     IFNULL((CASE     WHEN S.SM_INSTRUMENT_NAME = 'OPTSTK' THEN ((S.SM_LOT_SIZE * (D.DBC_CLOSE_PRICE + SM_STRIKE_PRICE)) * RFEM.RFEM_EFF_EXP_LIMIT / 100)    WHEN S.SM_INSTRUMENT_NAME = 'FUTSTK' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * RFEM.RFEM_EFF_EXP_LIMIT / 100)     WHEN S.SM_INSTRUMENT_NAME = 'OPTIDX' THEN ((S.SM_LOT_SIZE * (D.DBC_CLOSE_PRICE + SM_STRIKE_PRICE)) * SM_EXPOSER_PERC / 100)     WHEN S.SM_INSTRUMENT_NAME = 'FUTIDX' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * SM_EXPOSER_PERC / 100)     WHEN     S.SM_INSTRUMENT_NAME = 'OPTCUR'     THEN     CASE     WHEN S.SM_CROSS_CUR_FLAG = 'Y' THEN ((S.SM_LOT_SIZE * (D.DBC_CLOSE_PRICE + SM_STRIKE_PRICE)) * 1000 * S.SM_CURRENCY_MULTIPLIER * 1.5 / 100)     ELSE ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * 1000 * 1.5 / 100)     END     WHEN     S.SM_INSTRUMENT_NAME = 'FUTCUR'     THEN     CASE     WHEN S.SM_CROSS_CUR_FLAG = 'Y' THEN ((S.SM_LOT_SIZE * (D.DBC_CLOSE_PRICE + SM_STRIKE_PRICE)) * 1000 * S.SM_CURRENCY_MULTIPLIER * 1 / 100)     ELSE ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE) * 1000 * 1 / 100)     END     WHEN S.SM_INSTRUMENT_NAME = 'OPTFUT' THEN ((S.SM_LOT_SIZE * (D.DBC_CLOSE_PRICE + S.SM_STRIKE_PRICE) * RMEM.RMEM_ELM_Long) * 1 / 100)     WHEN S.SM_INSTRUMENT_NAME = 'FUTCOM' THEN ((S.SM_LOT_SIZE * D.DBC_CLOSE_PRICE * S.SM_MCX_MULTIPLIER) * RMEM.RMEM_ELM_Long / 100)     ELSE 0     END), 0) AS SELL_EXPOSURE     FROM     RMS_FNO_SPAN_MARGIN A     LEFT OUTER JOIN SECURITY_MASTER S ON (A.RSM_SECURITY_ID = S.SM_SCRIP_CODE)     LEFT OUTER JOIN DRV_BHAV_COPY D ON (A.RSM_SECURITY_ID = D.DBC_SCRIP_CODE)     LEFT OUTER JOIN RMS_FNO_EXP_MARGIN RFEM ON (RFEM.RFEM_SECURITY_ID = S.SM_UNDERLAYING_SCRIP_CODE     AND RFEM.RFEM_SEGMENT = S.SM_SEGMENT)     LEFT OUTER JOIN RMS_MCX_EXP_MARGIN RMEM ON (RMEM.RMEM_SECURITY_ID = S.SM_SCRIP_CODE     AND RMEM.RMEM_SEGMENT = S.SM_SEGMENT)     WHERE     A.RSM_EXCHANGE = S.SM_EXCHANGE     AND A.RSM_SEGMENT = S.SM_SEGMENT     AND A.RSM_EXCHANGE = D.DBC_EXCHANGE     AND A.RSM_SEGMENT = D.DBC_SEGMENT) AS SPA;");
	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}


	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"EXCHANGE,SCRIP CODE,EXCH SYMBOL,EXPIRY DATE,STRIKE PRICE,INSTRUMENT NAME,LOT SIZE,OPTION TYPE,BUY SPAN,SELL SPAN,BUY EXPOSURE,SELL EXPOSURE,BUY SPAN PERCENTAGE,SELL SPAN PERCENTAGE,BUY EXPOSURE PERCENTAGE,SELL EXPOSURE PERCENTAGE \n");
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fCalSpanFileGen");
	return TRUE;

}

BOOL fSpanFileDBExport()
{
	logTimestamp("Entry : fSpanFileDBExport");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset  (sSeq,'\0',30);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,SPAN_MASTER_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"select CONCAT(RSM_SECURITY_ID,',',\
		IFNULL(RSM_SYMBOL_NAME,'NA'),',',\
			RSM_SPAN_1,',',\
			RSM_SPAN_2,',',\
			RSM_SPAN_3,',',\
			RSM_SPAN_4,',',\
			RSM_SPAN_5,',',\
			RSM_SPAN_6,',',\
			RSM_SPAN_7,',',\
			RSM_SPAN_8,',',\
			RSM_SPAN_9,',',\
			RSM_SPAN_10,',',\
			RSM_SPAN_11,',',\
			RSM_SPAN_12,',',\
			RSM_SPAN_13,',',\
			RSM_SPAN_14,',',\
			RSM_SPAN_15,',',\
			RSM_SPAN_16,',',\
			IFNULL(RSM_DELTA,0),',',\
			IFNULL(RSM_OPTION_PREMIUM,0),',',\
			IFNULL(RSP_UPDATED_DATE,NOW()),',',\
			IFNULL(RSM_SPAN_MARGIN,0),',',\
			IFNULL(RSM_EXPO_MARGIN,0),',',\
			IFNULL(RSM_INSTRUMENT,'NA'),',',\
			IFNULL(RSM_EXPIRY_DATE,NOW()),',',\
			IFNULL(RSM_STRIKE_PRICE,0),',',\
			IFNULL(RSM_OPTION_TYPE,'NA'),',',\
			IFNULL(RSM_SOM,0),',',\
			IFNULL(RSM_UNDERLYING_SEC_ID,'NA'),',',\
			IFNULL(RSM_UNDERLYING_SYMBOL,'NA'),',',\
			RSM_SEGMENT,',',\
			RSM_EXCHANGE,',',\
			IFNULL(RSM_DELTA_SPREAD,0)) SPAN\
			from RMS_FNO_SPAN_MARGIN;");

	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}

	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"RSM_SECURITY_ID,RSM_SYMBOL_NAME,RSM_SPAN_1,RSM_SPAN_2,RSM_SPAN_3,RSM_SPAN_4,RSM_SPAN_5,RSM_SPAN_6,RSM_SPAN_7,RSM_SPAN_8,RSM_SPAN_9,RSM_SPAN_10,RSM_SPAN_11,RSM_SPAN_12,RSM_SPAN_13,RSM_SPAN_14,RSM_SPAN_15,RSM_SPAN_16,RSM_DELTA,RSM_OPTION_PREMIUM,RSP_UPDATED_DATE,RSM_SPAN_MARGIN,RSM_EXPO_MARGIN,RSM_INSTRUMENT,RSM_EXPIRY_DATE,RSM_STRIKE_PRICE,RSM_OPTION_TYPE,RSM_SOM,RSM_UNDERLYING_SEC_ID,RSM_UNDERLYING_SYMBOL,RSM_SEGMENT,RSM_EXCHANGE,RSM_DELTA_SPREAD\n");
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fSpanFileDBExport");
	return TRUE;

}


BOOL fDrvExpoFileGen()
{
	logTimestamp("Entry : fDrvExpoFileGen");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset	(sSeq,'\0',30);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,DRV_EXPOSER_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"SELECT concat(RFEM_SECURITY_ID,',',\
		ifnull(RFEM_SYMBOL_NAME,'NA'),',',\
			ifnull(RFEM_EFF_EXP_LIMIT,0),',',\
			ifnull(RFEM_UPDATED_DATE,now()),',',\
			RFEM_SEGMENT) DRV_EXPOSER\
		FROM RMS_FNO_EXP_MARGIN;");


	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}

	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"RFEM_SECURITY_ID,RFEM_SYMBOL_NAME,RFEM_EFF_EXP_LIMIT,RFEM_UPDATED_DATE,RFEM_SEGMENT\n");

	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fDrvExpoFileGen");
	return TRUE;

}


BOOL fMcxExpoFileGen()
{
	logTimestamp("Entry : fMcxExpoFileGen");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset  (sSeq,'\0',30);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,MCX_EXPOSER_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"SELECT CONCAT(RMEM_SECURITY_ID,',',\
		IFNULL(RMEM_SYMBOL_NAME,'NA'),',',\
			RMEM_Initial_Mar,',',\
			RMEM_Tender_Mar,',',\
			RMEM_Total_Mar,',',\
			RMEM_Add_Long_Mar,',',\
			RMEM_Add_Short_Mar,',',\
			RMEM_SP_Long_Mar,',',\
			RMEM_SP_Short_Mar,',',\
			RMEM_ELM_Long,',',\
			RMEM_ELM_Short,',',\
			RMEM_Del_Mar,',',\
			RMEM_SEGMENT,',',\
			RMEM_UPDATED_DATE) MCX_EXPOSER\
		FROM RMS_MCX_EXP_MARGIN;");


	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}

	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"RMEM_SECURITY_ID,RMEM_SYMBOL_NAME,RMEM_Initial_Mar,RMEM_Tender_Mar,RMEM_Total_Mar,RMEM_Add_Long_Mar,RMEM_Add_Short_Mar,RMEM_SP_Long_Mar,RMEM_SP_Short_Mar,RMEM_ELM_Long,RMEM_ELM_Short,RMEM_Del_Mar,RMEM_SEGMENT,RMEM_UPDATED_DATE\n");

	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fMcxExpoFileGen");
	return TRUE;

}

BOOL fVarElmFileGen()
{
	logTimestamp("Entry : fVarElmFileGen");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,VAR_ELM_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"SELECT CONCAT(IFNULL(SEC_SYMBOL,'NA'),',',\
		IFNULL(SEC_SERIES_GRP,'NA'),',',\
			SCRIP_ID,',',\
			IFNULL(ISIN,'NA'),',',\
			IFNULL(SECURITY_VAR,0),',',\
			IFNULL(INDEX_VAR,0),',',\
			IFNULL(VAR_MARGIN,0),',',\
			IFNULL(EXTREME_LOSS_RATE,0),',',\
			ADHOC_MARGIN,',',\
			IFNULL(APPLICABLE_MARGIN_RATE,0),',',\
			EXCH_ID,',',\
			IFNULL(SEM_MCX_LOT,0))VAR_ELM \
		FROM RMS_EQ_VAR_ELM;");


	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}

	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"SEC_SYMBOL,SEC_SERIES_GRP,SCRIP_ID,ISIN,SECURITY_VAR,INDEX_VAR,VAR_MARGIN,EXTREME_LOSS_RATE,ADHOC_MARGIN,APPLICABLE_MARGIN_RATE,EXCH_ID,SEM_MCX_LOT, \n");
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fVarElmFileGen");
	return TRUE;

}



BOOL fDrvCfPosFileGen()
{
	logTimestamp("Entry : fDrvCfPosFileGen");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset  (sSeq,'\0',30);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,DRV_POSITION_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"SELECT CONCAT(IFNULL(DRV_ORDER_NO,0),',',\
		DRV_SERIAL_NO,',',\
			ifnull(DRV_MULTILEG_ORD_TYPE,0),',',\
			DRV_LEG_NO,',',\
			DRV_SCRIP_CODE,',',\
			DRV_EXCH_ID,',',\
			DRV_SEGMENT,',',\
			DRV_ENTITY_ID,',',\
			IFNULL(DRV_EXCH_ORDER_NO,0),',',\
			DRV_CLIENT_ID,',',\
			DRV_BUY_SELL_IND,',',\
			IFNULL(DRV_MSG_CODE,0),',',\
			DRV_STATUS,',',\
			IFNULL(DRV_INTERNAL_ENTRY_DATE,NOW()),',',\
			IFNULL(DRV_EXCH_ORDER_TIME,NOW()),',',\
			DRV_TOTAL_QTY,',',\
			DRV_REM_QTY,',',\
			IFNULL(DRV_DISC_QTY,0),',',\
			IFNULL(DRV_DISC_REM_QTY,0),',',\
			IFNULL(DRV_TOTAL_TRADED_QTY,0),',',\
			IFNULL(DRV_ORDER_PRICE,0),',',\
			IFNULL(DRV_REF_LTP,0),',',\
			IFNULL(DRV_TRIGGER_PRICE,0),',',\
			IFNULL(DRV_SPREAD_PRICE_DIFF,0),',',\
			DRV_VALIDITY,',',\
			DRV_ORDER_TYPE,',',\
			IFNULL(DRV_GOOD_TILL_DAYS,0),',',\
			IFNULL(DRV_GOOD_TILL_DATE,0),',',\
			IFNULL(DRV_ACC_CODE,0),',',\
			DRV_USER_ID,',',\
			IFNULL(DRV_MIN_FILL_QTY,0),',',\
			DRV_PRO_CLIENT,',',\
			IFNULL(DRV_REMARKS,'NA'),',',\
			DRV_ERROR_CODE,',',\
			DRV_SOURCE_FLG,',',\
			IFNULL(DRV_ORDER_OFFON,0),',',\
			IFNULL(DRV_OPEN_CLOSE,'NA'),',',\
			IFNULL(DRV_COVER_UNCOVER,0),',',\
			DRV_PRODUCT_ID,',',\
			IFNULL(DRV_LOC_CODE,0),',',\
			DRV_GROUP_ID,',',\
			IFNULL(DRV_REASON_CODE,0),',',\
			IFNULL(DRV_REASON_DESCRIPTION,'NA'),',',\
			IFNULL(DRV_TRD_EXCH_TRADE_NO,'NA'),',',\
			IFNULL(DRV_TRD_SERIAL_NO,0),',',\
			IFNULL(DRV_TRD_TRANS_CODE,0),',',\
			IFNULL(DRV_TRD_STATUS,0),',',\
			IFNULL(DRV_TRD_TRADE_QTY,0),',',\
			IFNULL(DRV_TRD_TRADE_PRICE,0),',',\
			IFNULL(DRV_TRD_TRADE_TIME,NOW()),',',\
			IFNULL(DRV_TRD_SDRV_NO,0),',',\
			IFNULL(DRV_HANDLE_INST,0),',',\
			IFNULL(DRV_OMS_ALGO_ORD_NO,0),',',\
			IFNULL(DRV_STRATEGY_ID,0),',',\
			IFNULL(DRV_CLORDID,0),',',\
			IFNULL(DRV_ORIG_CLORDID,0),',',\
			IFNULL(DRV_ORIGINAL_PRICE,0),',',\
			IFNULL(DRV_SYMBOL,'NA'),',',\
			IFNULL(DRV_USER_TYPE,0),',',\
			IFNULL(DRV_INSTRUMENT_NAME,'NA'),',',\
			IFNULL(DRV_EXPIRY_DATE,NOW()),',',\
			IFNULL(DRV_STRIKE_PRICE,0),',',\
			IFNULL(DRV_OPTION_TYPE,'NA'),',',\
			IFNULL(DRV_LOT_SIZE,0),',',\
			IFNULL(DRV_BOOKTYPE,0),',',\
			IFNULL(DRV_MKT_TYPE,0),',',\
			IFNULL(DRV_SL_ABSTICK_VALUE,0),',',\
			IFNULL(DRV_PR_ABSTICK_VALUE,0),',',\
			IFNULL(DRV_SL_AT_FLAG,0),',',\
			IFNULL(DRV_PR_ST_FLAG,0),',',\
			DRV_CF_FLAG,',',\
			IFNULL(DRV_CHILD_LEG_UNQ_ID,0),',',\
			IFNULL(DRV_TRAILING_SL_VALUE,0),',',\
			IFNULL(DRV_CURRENCY_MULTIPLIER,0),',',\
			IFNULL(DRV_RBI_REFERENCE_RATE,0),',',\
			IFNULL(DRV_CROSS_CUR_FLAG,0),',',\	
			IFNULL(DRV_PAN_NO,0),',',\
			IFNULL(DRV_PARTICIPANT_TYPE,0),',',\
			IFNULL(DRV_SETTLOR,0),',',\
			IFNULL(DRV_MKT_PROTECT_FLG,0),',',\
			IFNULL(DRV_MKT_PROTECT_VAL,0),',',\
			IFNULL(DRV_GTC_FLG,0),',',\
			IFNULL(DRV_ENCASH_FLG,0),',',\
			IFNULL(DRV_SQROFF_FLAG,0),',',\
			IFNULL(DRV_EXCH_SEC,0)) DRV_POSITION\
			FROM DRV_ORDERS\
			WHERE DRV_CF_FLAG=-1;");


	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}

	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"DRV_ORDER_NO,DRV_SERIAL_NO,DRV_MULTILEG_ORD_TYPE,DRV_LEG_NO,DRV_SCRIP_CODE,DRV_EXCH_ID,DRV_SEGMENT,DRV_ENTITY_ID,DRV_EXCH_ORDER_NO,DRV_CLIENT_ID,DRV_BUY_SELL_IND,DRV_MSG_CODE,DRV_STATUS,DRV_INTERNAL_ENTRY_DATE,DRV_EXCH_ORDER_TIME,DRV_TOTAL_QTY,DRV_REM_QTY,DRV_DISC_QTY,DRV_DISC_REM_QTY,DRV_TOTAL_TRADED_QTY,DRV_ORDER_PRICE,DRV_REF_LTP,DRV_TRIGGER_PRICE,DRV_SPREAD_PRICE_DIFF,DRV_VALIDITY,DRV_ORDER_TYPE,DRV_GOOD_TILL_DAYS,DRV_GOOD_TILL_DATE,DRV_ACC_CODE,DRV_USER_ID,DRV_MIN_FILL_QTY,DRV_PRO_CLIENT,DRV_REMARKS,DRV_ERROR_CODE,DRV_SOURCE_FLG,DRV_ORDER_OFFON,DRV_OPEN_CLOSE,DRV_COVER_UNCOVER,DRV_PRODUCT_ID,DRV_LOC_CODE,DRV_GROUP_ID,DRV_REASON_CODE,DRV_REASON_DESCRIPTION,DRV_TRD_EXCH_TRADE_NO,DRV_TRD_SERIAL_NO,DRV_TRD_TRANS_CODE,DRV_TRD_STATUS,DRV_TRD_TRADE_QTY,DRV_TRD_TRADE_PRICE,DRV_TRD_TRADE_TIME,DRV_TRD_SDRV_NO,DRV_HANDLE_INST,DRV_OMS_ALGO_ORD_NO,DRV_STRATEGY_ID,DRV_CLORDID,DRV_ORIG_CLORDID,DRV_ORIGINAL_PRICE,DRV_SYMBOL,DRV_USER_TYPE,DRV_INSTRUMENT_NAME,DRV_EXPIRY_DATE,DRV_STRIKE_PRICE,DRV_OPTION_TYPE,DRV_LOT_SIZE,DRV_BOOKTYPE,DRV_MKT_TYPE,DRV_SL_ABSTICK_VALUE,DRV_PR_ABSTICK_VALUE,DRV_SL_AT_FLAG,DRV_PR_ST_FLAG,DRV_CF_FLAG,DRV_CHILD_LEG_UNQ_ID,DRV_TRAILING_SL_VALUE,DRV_CURRENCY_MULTIPLIER,DRV_RBI_REFERENCE_RATE,DRV_CROSS_CUR_FLAG,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_SETTLOR,DRV_MKT_PROTECT_FLG,DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG,DRV_SQROFF_FLAG,DRV_EXCH_SEC\n");
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fDrvCfPosFileGen");
	return TRUE;

}


BOOL fComCfPosFileGen()
{
	logTimestamp("Entry : fComCfPosFileGen");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR             sSeq[30];
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset  (sSeq,'\0',30);
	LONG32 iRow;

	if (mysql_query(DBCon, "SELECT Date_format(now(),'%Y%m%d');") != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	while((Row = mysql_fetch_row(Res)))
	{
		logDebug2("Row[0] = :%s:",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
	sprintf(sFileName,"%s/%s%s",sFilePath,COMM_POSITION_FILE,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);

	sprintf(sSelectQry,"select CONCAT(IFNULL(COMM_ORDER_NO,0),',',\
		IFNULL(COMM_SERIAL_NO,0),',',\
			IFNULL(COMM_MULTILEG_ORD_TYPE,0),',',\
			IFNULL(COMM_LEG_NO,0),',',\
			IFNULL(COMM_SCRIP_CODE,0),',',\
			IFNULL(COMM_EXCH_ID,0),',',\
			IFNULL(COMM_SEGMENT,0),',',\
			IFNULL(COMM_ENTITY_ID,0),',',\
			IFNULL(COMM_EXCH_ORDER_NO,0),',',\
			IFNULL(COMM_CLIENT_ID,0),',',\
			IFNULL(COMM_BUY_SELL_IND,0),',',\
			IFNULL(COMM_MSG_CODE,0),',',\
			IFNULL(COMM_STATUS,0),',',\
			IFNULL(COMM_INTERNAL_ENTRY_DATE,now()),',',\
			IFNULL(COMM_EXCH_ORDER_TIME,now()),',',\
			IFNULL(COMM_TOTAL_QTY,0),',',\
			IFNULL(COMM_REM_QTY,0),',',\
			IFNULL(COMM_DISC_QTY,0),',',\
			IFNULL(COMM_DISC_REM_QTY,0),',',\
			IFNULL(COMM_TOTAL_TRADED_QTY,0),',',\
			IFNULL(COMM_ORDER_PRICE,0),',',\
			IFNULL(COMM_REF_LTP,0),',',\
			IFNULL(COMM_TRIGGER_PRICE,0),',',\
			IFNULL(COMM_SPREAD_PRICE_DIFF,0),',',\
			IFNULL(COMM_VALIDITY,0),',',\
			IFNULL(COMM_ORDER_TYPE,0),',',\
			IFNULL(COMM_GOOD_TILL_DAYS,0),',',\
			IFNULL(COMM_GOOD_TILL_DATE,now()),',',\
			IFNULL(COMM_ACC_CODE,0),',',\
			IFNULL(COMM_USER_ID,0),',',\
			IFNULL(COMM_MIN_FILL_QTY,0),',',\
			IFNULL(COMM_PRO_CLIENT,0),',',\
			IFNULL(COMM_REMARKS,0),',',\
			IFNULL(COMM_ERROR_CODE,0),',',\
			IFNULL(COMM_SOURCE_FLG,0),',',\
			IFNULL(COMM_ORDER_OFFON,0),',',\
			IFNULL(COMM_OPEN_CLOSE,0),',',\
			IFNULL(COMM_COVER_UNCOVER,0),',',\
			IFNULL(COMM_PRODUCT_ID,0),',',\
			IFNULL(COMM_LOC_CODE,0),',',\
			IFNULL(COMM_GROUP_ID,0),',',\
			IFNULL(COMM_REASON_CODE,0),',',\
			IFNULL(COMM_REASON_DESCRIPTION,0),',',\
			IFNULL(COMM_TRD_EXCH_TRADE_NO,0),',',\
			IFNULL(COMM_TRD_SERIAL_NO,0),',',\
			IFNULL(COMM_TRD_TRANS_CODE,0),',',\
			IFNULL(COMM_TRD_STATUS,0),',',\
			IFNULL(COMM_TRD_TRADE_QTY,0),',',\
			IFNULL(COMM_TRD_TRADE_PRICE,0),',',\
			IFNULL(COMM_TRD_TRADE_TIME,now()),',',\
			IFNULL(COMM_TRD_SEQ_NO,0),',',\
			IFNULL(COMM_HANDLE_INST,0),',',\
			IFNULL(COMM_OMS_ALGO_ORDER_NO,0),',',\
			IFNULL(COMM_STRATEGY_ID,0),',',\
			IFNULL(COMM_CLORDID,0),',',\
			IFNULL(COMM_ORIG_CLORDID,0),',',\
			IFNULL(COMM_SYMBOL,0),',',\
			IFNULL(COMM_INSTRUMENT_NAME,0),',',\
			IFNULL(COMM_STRIKE_PRICE,0),',',\
			IFNULL(COMM_OPTION_TYPE,0),',',\
			IFNULL(COMM_LOT_SIZE,0),',',\
			IFNULL(COMM_USER_TYPE,0),',',\
			IFNULL(COMM_MKT_TYPE,0),',',\
			IFNULL(COMM_ARCHIVE_DATE,now()),',',\
			IFNULL(COMM_SEM_SYMBOL,0),',',\
			IFNULL(COMM_CF_FLAG,0),',',\
			IFNULL(COMM_EXPIRY_DATE,now()),',',\
			IFNULL(COMM_MULTIPLIER,0),',',\
			IFNULL(COMM_ORIGINAL_PRICE,0),',',\
			IFNULL(COMM_SL_ABSTICK_VALUE,0),',',\
			IFNULL(COMM_PR_ABSTICK_VALUE,0),',',\
			IFNULL(COMM_SL_AT_FLAG,0),',',\
			IFNULL(COMM_PR_ST_FLAG,0),',',\
			IFNULL(COMM_CHILD_LEG_UNQ_ID,0),',',\
			IFNULL(COMM_PAN_NO,0),',',\
			IFNULL(COMM_PARTICIPANT_TYPE,0),',',\
			IFNULL(COMM_SETTLOR,0),',',\
			IFNULL(COM_MKT_PROTECT_FLG,0),',',\
			IFNULL(COMM_MKT_PROTECT_VAL,0),',',\
			IFNULL(COMM_GTC_FLG,0),',',\
			IFNULL(COMM_ENCASH_FLG,0),',',\
			IFNULL(COMM_TRAILING_SL_VALUE,0),',',\
			IFNULL(COMM_SERIES,0)) COMM_POSITION\
			from COMM_ORDERS\
			where COMM_CF_FLAG = -1;");


	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error While Fetching the client details.");
		exit(ERROR);
	}

	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"COMM_ORDER_NO,COMM_SERIAL_NO,COMM_MULTILEG_ORD_TYPE,COMM_LEG_NO,COMM_SCRIP_CODE,COMM_EXCH_ID,COMM_SEGMENT,COMM_ENTITY_ID,COMM_EXCH_ORDER_NO,COMM_CLIENT_ID,COMM_BUY_SELL_IND,COMM_MSG_CODE,COMM_STATUS,COMM_INTERNAL_ENTRY_DATE,COMM_EXCH_ORDER_TIME,COMM_TOTAL_QTY,COMM_REM_QTY,COMM_DISC_QTY,COMM_DISC_REM_QTY,COMM_TOTAL_TRADED_QTY,COMM_ORDER_PRICE,COMM_REF_LTP,COMM_TRIGGER_PRICE,COMM_SPREAD_PRICE_DIFF,COMM_VALIDITY,COMM_ORDER_TYPE,COMM_GOOD_TILL_DAYS,COMM_GOOD_TILL_DATE,COMM_ACC_CODE,COMM_USER_ID,COMM_MIN_FILL_QTY,COMM_PRO_CLIENT,COMM_REMARKS,COMM_ERROR_CODE,COMM_SOURCE_FLG,COMM_ORDER_OFFON,COMM_OPEN_CLOSE,COMM_COVER_UNCOVER,COMM_PRODUCT_ID,COMM_LOC_CODE,COMM_GROUP_ID,COMM_REASON_CODE,COMM_REASON_DESCRIPTION,COMM_TRD_EXCH_TRADE_NO,COMM_TRD_SERIAL_NO,COMM_TRD_TRANS_CODE,COMM_TRD_STATUS,COMM_TRD_TRADE_QTY,COMM_TRD_TRADE_PRICE,COMM_TRD_TRADE_TIME,COMM_TRD_SEQ_NO,COMM_HANDLE_INST,COMM_OMS_ALGO_ORDER_NO,COMM_STRATEGY_ID,COMM_CLORDID,COMM_ORIG_CLORDID,COMM_SYMBOL,COMM_INSTRUMENT_NAME,COMM_STRIKE_PRICE,COMM_OPTION_TYPE,COMM_LOT_SIZE,COMM_USER_TYPE,COMM_MKT_TYPE,COMM_ARCHIVE_DATE,COMM_SEM_SYMBOL,COMM_CF_FLAG,COMM_EXPIRY_DATE,COMM_MULTIPLIER,COMM_ORIGINAL_PRICE,COMM_SL_ABSTICK_VALUE,COMM_PR_ABSTICK_VALUE,COMM_SL_AT_FLAG,COMM_PR_ST_FLAG,COMM_CHILD_LEG_UNQ_ID,COMM_PAN_NO,COMM_PARTICIPANT_TYPE,COMM_SETTLOR,COM_MKT_PROTECT_FLG,COMM_MKT_PROTECT_VAL,COMM_GTC_FLG,COMM_ENCASH_FLG,COMM_TRAILING_SL_VALUE,COMM_SERIES\n");
	Res = mysql_store_result(DBCon);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
	}
	fclose(fpFile);

	fConvToPwdPrtect(sFileName1,sFileName);

	logInfo("sFileName :%s: sFileName1 :%s:",sFileName,sFileName1);

	logTimestamp("Exit : fComCfPosFileGen");
	return TRUE;

}


BOOL fGenerateFileOp(CHAR *sEntityId)	
{
	logTimestamp("ENTRY fGenerateFileOp [Main]");

	MYSQL_RES       *Res , *Res1;
	MYSQL_ROW       Row;
	LONG32	iRow ,iRow1;
	CHAR    sDealer_Id [DEALER_ID_LEN];
	CHAR	sSelectQry1 [MAX_QUERY_SIZE];
	CHAR    sSelectQry2 [MAX_QUERY_SIZE];
	memset(sSelectQry1,'\0',MAX_QUERY_SIZE);
	memset(sSelectQry2,'\0',MAX_QUERY_SIZE);
	CHAR 	sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	//create file for those dealer who are not broker level
	sprintf(sSelectQry1,"SELECT s.ENTITY_CODE from ENTITY_MASTER s where s.ENTITY_CODE = \'%s\'  ;",sEntityId);
	if (mysql_query(DBCon, sSelectQry1) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching Dealer ID in fGenerateFileOp .");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry1);
	Res = mysql_store_result(DBCon);
	iRow1 = mysql_num_rows(Res);
	if(iRow1 == 0)
	{	

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow1);
		while (Row = mysql_fetch_row(Res))
		{
			strncpy(sDealer_Id ,Row[0],DEALER_ID_LEN);
			fTrim(sDealer_Id,strlen(sDealer_Id));
			/**
			  sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(e.ENTITY_CODE,'') , '|' , IFNULL(e.ENTITY_NAME,'') , '|' , IFNULL(e.ENTITY_ADD_1,'') , '|' , IFNULL(e.ENTITY_ADD_2,'') , '|' , IFNULL(e.ENTITY_ADD_3,'') , '|' , IFNULL(e.ENTITY_PHONE,'') , '|' , IFNULL(e.ENTITY_MOBILE,'') , '|' , IFNULL(e.ENTITY_DOB,'') , '|' , IFNULL(e.ENTITY_PAN,'') , '|' , IFNULL(e.ENTITY_NSE_CODE,'')) AS v_string \
			  FROM ENTITY_MASTER AS  e, ENTITY_DEALER_MAPPING AS b where e.ENTITY_CODE = b.EDM_CLIENT_ID AND b.edm_dealer_id =\"%s\"",sDealer_Id);
			 **/

			sprintf(sSelectQry2,"SELECT CONCAT(IFNULL(ENTITY_CODE,''),'|',IFNULL(ENTITY_NAME,''),'|',IFNULL(ENTITY_PAN, ''),\
				'|',(CASE WHEN ENTITY_EMAIL IS NULL THEN 'NA' WHEN ENTITY_EMAIL ='' THEN 'NA' ELSE ENTITY_EMAIL END),\
					'|',(CASE WHEN ENTITY_MOBILE IS NULL THEN 0 WHEN ENTITY_MOBILE ='' THEN 0 ELSE ENTITY_MOBILE END),\
					'|',(CASE WHEN ENTITY_PHONE IS NULL THEN 0 WHEN ENTITY_PHONE ='' THEN 0 ELSE ENTITY_PHONE END),\
					'|',ENTITY_SUB_TYPE,'|',ENTITY_SETTLOR,'|',ENTITY_SETTLOR_DRV,'|',ENTITY_SETTLOR_CURR) FROM ENTITY_MASTER AS  e, \
				ENTITY_DEALER_MAPPING AS b where e.ENTITY_CODE = b.EDM_CLIENT_ID  AND b.edm_dealer_id =\"%s\"  AND e.ENTITY_SUB_TYPE NOT IN (8);",sDealer_Id); 
			logDebug2("Query[%s]",sSelectQry2);

			if (mysql_query(DBCon, sSelectQry2) != SUCCESS)
			{
				logDebug2("----------------");
				sql_Error(DBCon);
				logSqlFatal("Error Fetching Dealer Location Code in fGenerateFileOp .");
				exit(ERROR);
			}
			Res1 = mysql_store_result(DBCon);
			iRow = mysql_num_rows(Res1);
			if (iRow == 0)
			{
				mysql_free_result(Res1);
				logInfo(" Nishant no result set");
			}
			else
			{
				logDebug2("No of Rows Selected = %d",iRow);
				logDebug2("Dealer_Id :%s:",sDealer_Id);
				/*** Replacing Varaible FILE_LOCATION with sFilePath @nitish***/
				logDebug2("sFilePath = %s",sFilePath);
				sprintf(sFileName,"%s/%s",sFilePath,sDealer_Id);
				logDebug2("sFileName = %s",sFileName);
				logDebug2("sFilePath = %s ",sFilePath);
				fpFile = fopen(sFileName,"wb");

				if (fpFile == NULL)
				{
					logFatal("Not able to Open File in append mode");
					exit(0);
				}
				else
				{
					while((Row = mysql_fetch_row(Res1)))
					{
						logDebug2("Row :%s:",Row[0]);
						fprintf(fpFile ,"%s\n",Row[0]);

					}
				}
				mysql_free_result(Res1);
				fprintf(fpFile,"*");
				fclose(fpFile);
				logDebug2("sDealer_Id :%s: :%s:",sDealer_Id,CLIENT_FILE_NM);
				fConvToPwdPrtect(sFileName,sFileName);
			}
		}
	}
	logTimestamp("EXIT fGenerateFileOp [Main]");
}


