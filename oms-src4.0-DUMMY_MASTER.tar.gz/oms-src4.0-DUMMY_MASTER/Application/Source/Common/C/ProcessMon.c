#include <stdio.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/procfs.h>  
#include "IPCS.h"

pthread_t                  SignalTid1;
pthread_t                  SignalTid2;
sigset_t                   MainSignalSet ;
sigset_t                   ChildSignalSet;

#define     NO_MONITORING       999
#define     LOG_WRITE                   1
#define     NO_LOG_WRITE        0

void * AutoRestartForCrash () ;
void * ChildMain ();
void *SignalHandlerSigChldParent ();
void *SignalHandlerSigTermParent ();
void ProcessSelfRestart(struct  ProcessMonitor *);
void LoadEnv();
LONG32  getCurrTime ();

BOOL RestrtFlag = FALSE ;
LONG32  ChildId = 0;
LONG32  MaxSelfRetry = 0;
LONG32  selfRestrtCount = 0 ;
// Notitication Flag for disable process stop and restart notification @NItish
LONG32	iMonToolNotifyFlag = FALSE;

void main()
{
	logTimestamp("Entry : [main]");
	LONG32 forkid ;
	LONG32  sleepInterval = atoi(getenv("PROCESS_MON_DELAY") );

	if(getenv("MAX_AUTO_RETRY") == NULL)
	{
		logDebug1("environment variable MAX_AUTO_RETRY not defined, hence taking the default value as 3 ");
		MaxSelfRetry = 3 ;
	}
	else
	{
		MaxSelfRetry = atoi(getenv("MAX_AUTO_RETRY"));
	}

// Notitication Flag for disable process stop and restart notification @NItish
	if(getenv("MON_TOOL_NOTI_FLAG") == NULL)
        {
                logDebug1("environment variable MON_TOOL_NOTI_FLAG not defined, hence taking the default value as 0 ie disable ");
                iMonToolNotifyFlag = FALSE ;
        }
        else
        {
                iMonToolNotifyFlag = atoi(getenv("MON_TOOL_NOTI_FLAG"));
        }

	//LoadEnv();
	signal (SIGHUP, SIG_IGN);
	sigemptyset ( &MainSignalSet );
	sigaddset ( &MainSignalSet , SIGTERM);
	sigaddset ( &MainSignalSet , SIGCHLD);
	sigprocmask (SIG_BLOCK,&MainSignalSet , NULL);

	setvbuf( stdout , NULL , _IONBF , 0 );

	forkid = fork ();
	if ( forkid == 0 )
	{
		logInfo("In Child...%d",forkid);
		ChildMain () ;
	}
	else
	{
		ChildId = forkid ;
		logDebug3("This is change for Git Repo Test");
		logInfo("In Parent...%d",forkid);
		sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
		signal(SIGCHLD,SignalHandlerSigChldParent);
		signal(SIGTERM,SignalHandlerSigTermParent);
		while(1)
		{
			sleep (sleepInterval );
			/****************
			  if (RestrtFlag  == TRUE)
			  {
			  forkid = fork ();
			  if ( forkid == 0 )
			  {
			  logInfo("\n In Child again as it got killed...%d",forkid);
			  ChildMain () ;
			  }
			  else
			  {
			  logInfo ("\n In Parent to reset RestrtFlag again");
			  sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
			  signal(SIGCHLD,SignalHandlerSigChldParent);
			  signal(SIGTERM,SignalHandlerSigTermParent);
			  RestrtFlag  = FALSE ;
			  }
			  }*****************/
		} /***************** End of while loop **************/
	}

	logTimestamp("Exit : [main]");
}

void *ChildMain ()
{
	logTimestamp("Entry : [ChildMain]");
	BOOL    iRetPthCreate ;
	LONG32      Signal;
	BOOL RetVal = FALSE ;

	iRetPthCreate = pthread_create(&SignalTid2, NULL, AutoRestartForCrash, NULL);
	if ( iRetPthCreate != 0 )
	{
		logFatal (" pthread_create:AutoRestartForCrash");
		exit (1);
	}
	logDebug2(" AutoRestartForCrash thread created");
	sigemptyset ( &ChildSignalSet );
	sigaddset ( &ChildSignalSet , SIGTERM);
	pthread_sigmask ( SIG_BLOCK,&ChildSignalSet,NULL);
	while(1)
	{
		if((RetVal = sigwait(&ChildSignalSet,&Signal)) < 0)
		{
			logDebug3(" sigwait:ChildSignalSet");
			break;
		}

		logInfo(" Received Signal in Child :%d",Signal);
		if (Signal == SIGTERM)
		{
			pthread_cancel(SignalTid1);
			pthread_cancel(SignalTid2);
			break;
		}
	}
	logTimestamp("Exit : [ChildMain]");
}

void * AutoRestartForCrash ()
{
	logTimestamp("Entry : [AutoRestartForCrash]");
	LONG32 psp;
	struct elf_prpsinfo ps;
	CHAR fn[100];
	CHAR sProcessId[10];
	CHAR args[500];
	CHAR args1[500];
	CHAR ProgName[50];
	CHAR *arr[6];
	CHAR *buf;
	CHAR    tempProgName[50];
	BOOL    RetVal ;
	LONG32  sleepInterval = atoi(getenv("PROCESS_MON_DELAY") );
	LONG32  i ;
	BOOL    MonChkFlag = FALSE ;

	struct stat buffer;
	struct ProcessMonitorArray * MemArray;

	fInitProcessMonShm(MemArray);

	logInfo(" IN AutoRestartForCrash" );
	while ( TRUE )
	{
		LockShm(ProcessMonitorShm);
		MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
		if( *((int *)MemArray) == ERROR )
		{
			logInfo(" OpenSharedMemory:ProcessMonitorShm");
			UnLockShm(ProcessMonitorShm);
			exit(ERROR);
		}
		for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
		{
			if (MemArray->ProcessMonitor[i].iProcessId != UNUSED )
			{
				memset ( tempProgName ,'\0',50 );
				/****
				  memset(sProcessId,0,10);
				  sprintf(sProcessId,"%d",MemArray->ProcessMonitor[i].iProcessId);
				  memset(fn,0,100);
				  strcat(fn, "/proc/");
				  strcat(fn, sProcessId);
				  strcat(fn, "/stat");
				 ***/
				sprintf(fn,"/proc/%d/stat",MemArray->ProcessMonitor[i].iProcessId);
				strncpy (tempProgName,MemArray->ProcessMonitor[i].sProcessName,strlen (MemArray->ProcessMonitor[i].sProcessName));
				errno = 0;

				if ((psp = access(fn,F_OK)) == -1)
				{
					logInfo(":%s:",fn);
					perror("Open Error :");
					ProcessSelfRestart(&MemArray->ProcessMonitor[i]);
				}
			}
		}
		if ((CloseSharedMemory(MemArray)) == ERROR )
		{
			logInfo(" CloseSharedMemory:ProcessMonitorShm");
			UnLockShm(ProcessMonitorShm);
			exit(ERROR);
		}
		UnLockShm ( ProcessMonitorShm );

		sleep (sleepInterval );

	}
	logTimestamp("Exit: [AutoRestartForCrash]");
}

void ProcessSelfRestart(struct  ProcessMonitor *ProcessMonitor)
{
	logTimestamp("Entry : [ProcessSelfRestart]");

	CHAR    tempProgName[50];
	BOOL    iRetVal ;
	LONG32  tempPID = 0;
	LONG32  result =0 ;

	memset ( tempProgName ,'\0',50 );
	strncpy (tempProgName,ProcessMonitor->sProcessName,strlen (ProcessMonitor->sProcessName));
	logDebug2("DP -> :%s:%i:",tempProgName,ProcessMonitor->iAttempts);
	tempPID = ProcessMonitor->iProcessId;

	if ( ProcessMonitor->iAttempts >= MaxSelfRetry )
	{
		if ( ProcessMonitor->iAttempts == MaxSelfRetry )
		{
			if(iMonToolNotifyFlag == TRUE)
			{
				NotifyProcMonTool(ProcessMonitor,FALSE);
			}	
			logInfo( " Process [%s] Not to be restarted automatically as it has reached max level",tempProgName);
			ProcessMonitor->iAttempts = MaxSelfRetry + 1;
		}
	}
	else
	{
		do
		{
// Notitication Flag for disable process stop and restart notification @NItish
			if(iMonToolNotifyFlag == TRUE)
			{
				NotifyProcMonTool(ProcessMonitor,FALSE);
			}	
			logInfo( " Process to be  restarted  %s ",tempProgName );
			UnLockShm ( ProcessMonitorShm );
			iRetVal = selfRestrter ( ProcessMonitor->iProcessId );
			LockShm ( ProcessMonitorShm );
			if ( iRetVal != 0 )
			{
				ProcessMonitor->iAttempts = ProcessMonitor->iAttempts + 1 ;
			}
			sleep(3);
		}while ( iRetVal != 0 && ProcessMonitor->iAttempts < MaxSelfRetry );
		if ( iRetVal == 0 )
		{
			logInfo( " Process [%s] got restarted in [%d] attempt(s).",tempProgName ,ProcessMonitor->iAttempts + 1);
			ProcessMonitor->iAttempts = ProcessMonitor->iAttempts + 1;
// Notitication Flag for disable process stop and restart notification @NItish
			if(iMonToolNotifyFlag == TRUE)
			{
				NotifyProcMonTool(ProcessMonitor,FALSE);
			}	
		}
		else
		{
			logInfo(" FATAL:Unable to start [%s]. Please check the log immediately.",tempProgName );
			ProcessMonitor->iAttempts = MaxSelfRetry ;
// Notitication Flag for disable process stop and restart notification @NItish
			if(iMonToolNotifyFlag == TRUE)
			{
				NotifyProcMonTool(ProcessMonitor,FALSE);
			}	
		}
	}
	logTimestamp("Exit : [ProcessSelfRestart]");

}

void *SignalHandlerSigChldParent ()
{
	logTimestamp("Entry : [SignalHandlerSigChldParent]");
	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	selfRestrtCount++;
	logInfo( " Received signal SIGCHLD %d times",selfRestrtCount);
	if ( selfRestrtCount <= MaxSelfRetry )
	{
		RestrtFlag = TRUE ;
	}
	else
	{
		logInfo(" FATAL: Unable to recover ProcessMonitor, Please restart it manually");
	}
	logTimestamp("Exit : [SignalHandlerSigChldParent]");
}
void *SignalHandlerSigTermParent()
{
	logTimestamp("Entry : [SignalHandlerSigTermParent]");
	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	logFatal(" Got SIGTERM to parent so killing the process ");
	sleep (3);
	kill(ChildId,SIGTERM);

	logTimestamp("Exit : [SignalHandlerSigTermParent]");
	exit(1);
}
BOOL selfRestrter (LONG32 pid)
{
	logTimestamp("Entry : [selfRestrter]");

	CHAR c_aCommand[80];
	FILE *fppopen;
	CHAR  pretval[30];
	CHAR sretval[5];
	LONG32 iretval = 0;

	memset ( c_aCommand ,'\0',80);
	memset ( pretval ,'\0',30);
	memset ( sretval,'\0',5);

	if ( pid ==  UNUSED )
	{
		return (1);
	}
	logInfo(" Process ID for Restart %d",pid);
	sprintf (c_aCommand ,"selfRestrt.sh %d",pid);
	logInfo(" c_aCommand :%s:",c_aCommand);
	fppopen = popen(c_aCommand, "r");
	fscanf(fppopen, "%s",sretval);
	pclose(fppopen);
	logInfo(" sretval = [%s]",sretval);
	iretval = atoi (sretval);
	logDebug3(" iretval = [%d]",iretval);
	logTimestamp("Exit : [selfRestrter]");
	return (iretval);
}



void	fInitProcessMonShm(struct ProcessMonitorArray *MemArray)
{
	logTimestamp("Entry :fInitProcessMonShm:");
	LONG32 i = 0;

	LockShm(ProcessMonitorShm);
	MemArray = (struct ProcessMonitorArray *)OpenSharedMemory(ProcessMonitorShm,ProcessMonitor_SIZE);
	if( *((int *)MemArray) == ERROR )
	{
		logInfo(" OpenSharedMemory:ProcessMonitorShm");
		UnLockShm(ProcessMonitorShm);
		exit(ERROR);
	}

	for(i=0; i < MAX_NO_OF_SYSTEM_PROCESS ; i ++)
	{
		if (MemArray->ProcessMonitor[i].iProcessId != UNUSED )
		{
			MemArray->ProcessMonitor[i].iAttempts = 0;			
		}
	}
	if ((CloseSharedMemory(MemArray)) == ERROR )
	{
		logInfo(" CloseSharedMemory:ProcessMonitorShm");
		UnLockShm(ProcessMonitorShm);
		exit(ERROR);
	}
	UnLockShm ( ProcessMonitorShm );
	logTimestamp("Exit :fInitProcessMonShm:");
}
/****
  void NotifyMonTool(struct  ProcessMonitor *ProcessMonitor, BOOL Status)
  {
  CHAR sCmd[200];
  memset(sCmd,'\0',200);
  sprintf(sCmd,"%s/ProcStats.py %s %s %d %d >> %s/log.ProcStats &",getenv("PYTHON_PATH"),ProcessMonitor->sProcessName,Status==1?"UP":"DOWN",ProcessMonitor->iAttempts,MaxSelfRetry,getenv("LOGDIR"));
  logDebug2("Command -> %s",sCmd);
  system(sCmd);
  }

  void LoadEnv()
  {
  if(getenv("MAX_AUTO_RETRY") == NULL)
  {
  logDebug1("environment variable MAX_AUTO_RETRY not defined, hence taking the default value as 3 ");
  MaxSelfRetry = 3 ;
  }
  else
  {
  MaxSelfRetry = atoi(getenv("MAX_AUTO_RETRY"));
  }

  if(getenv("PYTHON_PATH") == NULL)
  GDIR
  {
  logDebug1("environment variable PYTHON_PATH not defined");
  exit(ERROR);
  }
  else
  {
  MaxSelfRetry = atoi(getenv("PYTHON_PATH"));
  }

  if(getenv("LOGDIR") == NULL)
  {
  logDebug1("environment variable LOGDIR not defined");
  MaxSelfRetry = 3 ;
  }
  else
  {
  MaxSelfRetry = atoi(getenv("LOGDIR"));
  }

  }
 ***/
