#include "IPCS.h"
#include "FIXStructures.h"

main(int argc, char *argv[])
{
	logTimestamp("START [BatchProcessCancel]");
	LONG32	iQueId=0;
	CHAR	cSegment=0;
	CHAR	sSecId [SECURITY_ID_LEN];
	DOUBLE64  fHighCkt;
	DOUBLE64  fLowCkt;
	struct  FIX_SECURITY_STATUS pOrdRes;
	
	memset(&pOrdRes,'\0',sizeof(struct FIX_SECURITY_STATUS));

	setbuf(stdout  ,NULL);
        setbuf(stderr  ,NULL);

	iQueId = atoi(argv[1]);
       	cSegment = argv[2][0];

	
	logDebug2("argc :%d:",argc);

	logDebug2(" iQueId :%d:",iQueId);
        logDebug2(" cSegment :%c",cSegment);
	
	printf("Enter the Security Id :");
	printf("\n ->");
	scanf("%s",sSecId);
	printf("Entered Security Id is :%s:\n",sSecId);

	printf("Enter Upper Ckt Limit value :");
	printf("\n ->");
	scanf("%lf",&fHighCkt);
	printf("Entered Upper Ckt Limit Value is :%lf:\n",fHighCkt);

	printf("Enter Lower Ckt Limit value :");
        printf("\n ->");
        scanf("%lf",&fLowCkt);
        printf("Entered Low Ckt Limit Value is :%lf:\n",fLowCkt);	

        pOrdRes.Header.iMsgLength = sizeof(struct FIX_SECURITY_STATUS);
        pOrdRes.Header.iMsgCode = TC_INT_FIX_SECURITY_STAT;
	strncpy(pOrdRes.sSecurityId,sSecId,SECURITY_ID_LEN);
	strncpy(pOrdRes.sIdSource,"8",IDSOURCE_LEN);
        pOrdRes.fHighPx = fHighCkt*100;
        pOrdRes.fLowPx = fLowCkt*100;

	logDebug2("pOrdRes.iMsgCode :%d:",pOrdRes.Header.iMsgCode);
	logDebug2("pOrdRes.iMsgLength :%d:",pOrdRes.Header.iMsgLength);
	
	logDebug2("pOrdRes.fHighPx :%lf:",pOrdRes.fHighPx);
	logDebug2("pOrdRes.fLowPx :%lf:",pOrdRes.fLowPx);
			
	if(WriteMsgQ(iQueId,(CHAR *) &pOrdRes,sizeof(struct FIX_SECURITY_STATUS),1) == FALSE)
       	{
        	logFatal("Error : Basic error sent failed .");
               	exit(ERROR);
        }
	
	
	logTimestamp("EXIT [BatchProcessCancel]");


}		
