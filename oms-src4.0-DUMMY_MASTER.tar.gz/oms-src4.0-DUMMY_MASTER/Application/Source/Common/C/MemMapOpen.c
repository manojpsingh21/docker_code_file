#include    "MemMapConfig.h"
#include    "MemMapqueue.h"
#include    "MemMapCommon.h"
/* 
   Default Attributes If None as defined
   (FLAG,MAX NO OF MSGS, MAX SIZE OF MSGS, CURR MSGS )
 */

struct mymq_attr	defattr = { 0, 1000, 1024, 0 };  

mymqd_t
Mq_Open(const char *pathname, int oflag, ...)
{
	int		i, fd, nonblock, created, save_errno;
		int 	NoOfProcess=0, mutex_unlock_status=0;
		int 	reg_process_status=0;
		long	msgsize, filesize, index = 0;
		va_list	ap;
		mode_t	mode;
		int8_t	*mptr;
		struct stat	statbuff;
		struct mymq_hdr		*mqhdr;
		struct mymsg_hdr	*msghdr;
		struct mymq_attr	*attr;
		struct mymq_info	*mqinfo;
		pthread_mutexattr_t	mattr;
		pthread_condattr_t	cattr;
		pthread_mutex_t		*tempmutex;
		
		created = 0;
		
		/*
		  If O_NONBLOCK set, the call to open() will not block, and subsequent read() or
		  write() operations on the file will be nonblocking.
		 */
		
		nonblock = oflag & O_NONBLOCK;
		oflag &= ~O_NONBLOCK;
		
		mptr = (int8_t *) MAP_FAILED;
		mqinfo = NULL;
		
		again:
		
		/*
		  O_CREAT:
		  If the file exists, this flag has no effect, except as described under
		  the O_EXCL flag. If the file does not exist, a regular file is created
		 */
		if (oflag & O_CREAT) 
		{
			/*
S_IXUSR: Permits the file's owner to execute it (or to search the directory).
			 */
			va_start(ap, oflag);		/* init ap to final named argument */
				mode = va_arg(ap, va_mode_t) & ~S_IXUSR;
				attr = va_arg(ap, struct mymq_attr *);
				va_end(ap);
				
				/* 4open and specify O_EXCL and user-execute */
				printf("\n\t Pathname is ... : %s",pathname);
				fd = open(pathname, oflag | O_EXCL | O_RDWR, mode | S_IXUSR);
				if (fd < 0) 
				{
					if (errno == EEXIST && (oflag & O_EXCL) == 0)
					{
						perror("\npathname already exists");
							goto exists;		/* already exists, OK */
					}
					else
					{
						printf("\n\t File not present");
							return((mymqd_t) -1);
					}
				}
			created = 1;
				printf("\n\t Created file");	
				
				/* 4first one to create the file initializes it */
				if (attr == NULL)
					attr = &defattr;
				else 
				{
					if (attr->mq_maxmsg <= 0 || attr->mq_msgsize <= 0) 
					{
						errno = EINVAL;
							goto err;
					}
				}
			
				/* 4calculate and set the file size */
				
				msgsize = MSGSIZE(attr->mq_msgsize);
				printf("\n\t after   MSGSIZE");
				
				filesize = sizeof(struct mymq_hdr) + (attr->mq_maxmsg *
						(sizeof(struct mymsg_hdr) + msgsize));
				
				if (lseek(fd, filesize - 1, SEEK_SET) == -1)
					goto err;
						if (write(fd, "", 1) == -1)
							goto err;
								
								/* 4memory map the file */
								/*
								  PROT_READ:  The mapped region can be read.
								  
								  PROT_WRITE: The mapped region can be written.
								  
								  If MAP_SHARED is set in the flags parameter:
								  
								  +  If the region is a mapped region, modifications to the region are
								  visible to other processes that have mapped the same region using
								  MAP_SHARED:
								  
								  +   If the region is a mapped file region, modifications to the region are
								  written to the file.  (Note that the modifications are not immediately
								  written to the file because of buffer cache delay; that is, the write
								  to the file does not occur until there is a need to reuse the buffer
								  cache.  If the modifications must be written to the file immediately,
								  the msync() function can be used to ensure that this is done.)
								 */
								
								printf("\n\t mmap filesize = %d ",filesize);
								
								mptr = mmap(NULL, filesize, PROT_READ | PROT_WRITE,
										MAP_SHARED, fd, 0);
								if (mptr == MAP_FAILED)
									goto err;
										
										/* 
										   4allocate one mymq_info{} for the queue , This header is require per Queue.
										 */
										/* *INDENT-OFF* */
										
										if ( (mqinfo = malloc(sizeof(struct mymq_info))) == NULL)
											goto err;
												
												/* *INDENT-ON* */
												
												/*
												  Typecasting  memory mapped region to Queue Header.
												 */
												mqinfo->mqi_hdr = mqhdr = (struct mymq_hdr *) mptr;
												mqinfo->mqi_magic = MQI_MAGIC;
												mqinfo->mqi_flags = nonblock;
												
												/* 4initialize header at beginning of file */
												/* 4create free list with all messages on it */
												
												mqhdr->mqh_attr.mq_flags = 0;
												mqhdr->mqh_attr.mq_maxmsg = attr->mq_maxmsg;
												mqhdr->mqh_attr.mq_msgsize = attr->mq_msgsize;
												mqhdr->mqh_attr.mq_curmsgs = 0;
												mqhdr->mqh_nwait = 0;
												mqhdr->mqh_pid = 0;
												mqhdr->mqh_head = 0;
												
												index = sizeof(struct mymq_hdr);
												mqhdr->mqh_free = index;
												mqhdr->mqh_head = index;	
												mqhdr->mqh_last = mqhdr->mqh_free;
												printf("\n\t Honey :: index = %d,mqhdr->mqh_free = %d,mqhdr->mqh_head= %d",index,mqhdr->mqh_free,mqhdr->mqh_last);
												/*
												  Now, creating block each of MAX_MSG_SIZE and each block have index of next block.
												 */
												
												for (i = 0; i < attr->mq_maxmsg - 1; i++) 
												{
													msghdr = (struct mymsg_hdr *) &mptr[index];
														index += sizeof(struct mymsg_hdr) + msgsize;
														msghdr->msg_next = index;
												}
			msghdr = (struct mymsg_hdr *) &mptr[index];
				msghdr->msg_next = 0;		/* end of free list */
				
				/* 4initialize mutex & condition variable */
				
				printf("\nmg_flags = %d",mqhdr->mqh_attr.mq_flags);
				printf("\nmaxmsg = %d",mqhdr->mqh_attr.mq_maxmsg);
				printf("\nmsgsize = %d",mqhdr->mqh_attr.mq_msgsize);
				printf("\ncurmsgs = %d",mqhdr->mqh_attr.mq_curmsgs);
				printf("\nwait = %d",mqhdr->mqh_nwait);
				printf("\npid = %d",mqhdr->mqh_pid);
				printf("\nhead = %d",mqhdr->mqh_head);
				printf("\nlast = %d",mqhdr->mqh_last);
				
				if ( (i = pthread_mutexattr_init(&mattr)) != 0)
					goto pthreaderr;
						
						/*
						  pthread_mutexattr_setpshared - Sets the process-shared attribute of a mutex
						  attributes object.
						  PTHREAD_PROCESS_SHARED, to permit access to the mutex in by any thread in any 
						  process that can access the memory where the mutex object is allocated.
						 */
						
						pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED);
						i = pthread_mutex_init(&mqhdr->mqh_lock, &mattr);
						pthread_mutexattr_destroy(&mattr);	/* be sure to destroy */
						if (i != 0)
							goto pthreaderr;
								
								
								if ( (i = pthread_condattr_init(&cattr)) != 0)
									goto pthreaderr;
										
										/*
										  Now, Same with cond variable.
										 */
										
										pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED);
										i = pthread_cond_init(&mqhdr->mqh_wait, &cattr);
										pthread_condattr_destroy(&cattr);	/* be sure to destroy */
										if (i != 0)
											goto pthreaderr;
												
												
												/* 4initialization complete, turn off user-execute bit */
												if (fchmod(fd, mode) == -1)
													goto err;
														close(fd);
														
														return((mymqd_t) mqinfo);
														
														
		} /* End Of IF */
	
		exists:
		
		/* 4open the file then memory map */
		printf("\n\t exists pathname %s",pathname);
		
		if ( (fd = open(pathname, O_RDWR)) < 0) 
		{
			printf ( "fd = %d ", fd);
				if (errno == ENOENT && (oflag & O_CREAT))
				{
					printf("\n\t goto again");
						goto again;
				}
			printf("\n\t  goto err");
				goto err;
		}
	
		/* 4make certain initialization is complete */
		
		for (i = 0; i < MAX_TRIES; i++) 
		{
			if (stat(pathname, &statbuff) == -1) 
			{
				if (errno == ENOENT && (oflag & O_CREAT)) 
				{
					close(fd);
						goto again;
				}
				goto err;
			}
			
				if ((statbuff.st_mode & S_IXUSR) == 0)
					break;
						sleep(1);
		}
	
		if (i == MAX_TRIES) 
		{
			errno = ETIMEDOUT;
				goto err;
		}
	
		filesize = statbuff.st_size;
		mptr = mmap(NULL, filesize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		if (mptr == MAP_FAILED)
			goto err;
				close(fd);
				
				/* 4allocate one mymq_info{} for each open */
				/* *INDENT-OFF* */
				if ( (mqinfo = malloc(sizeof(struct mymq_info))) == NULL)
					goto err;
						/* *INDENT-ON* */
						mqinfo->mqi_hdr = (struct mymq_hdr *) mptr;
						mqinfo->mqi_magic = MQI_MAGIC;
						mqinfo->mqi_flags = nonblock;
						/*	printf("\nmg_flags = %d",mqhdr->mqh_attr.mq_flags);
							printf("\nmaxmsg = %d",mqhdr->mqh_attr.mq_maxmsg);
							printf("\nmsgsize = %d",mqhdr->mqh_attr.mq_msgsize);
							printf("\ncurmsgs = %d",mqhdr->mqh_attr.mq_curmsgs);
							printf("\nwait = %d",mqhdr->mqh_nwait);
							printf("\npid = %d",mqhdr->mqh_pid);
							printf("\nhead = %d",mqhdr->mqh_head);
							printfpOpen.c("\nlast = %d",&mqhdr->mqh_last); */
						
						printf("\n\t ");
						printf("\n\t ");
						
						printf("\nmg_flags = %d",mqinfo->mqi_hdr->mqh_attr.mq_flags);
						printf("\nmaxmsg = %d",mqinfo->mqi_hdr->mqh_attr.mq_maxmsg);
						printf("\nmsgsize = %d",mqinfo->mqi_hdr->mqh_attr.mq_msgsize);
						printf("\ncurmsgs = %d",mqinfo->mqi_hdr->mqh_attr.mq_curmsgs);
						printf("\nwait = %d",mqinfo->mqi_hdr->mqh_nwait);
						printf("\npid = %d",mqinfo->mqi_hdr->mqh_pid);
						printf("\nhead = %d",mqinfo->mqi_hdr->mqh_head);
						printf("\nlast = %d",&mqhdr->mqh_last);
						printf("\nlast = %d",&mqinfo->mqi_hdr->mqh_last);
						
						printf("\n\t ");
						printf("\n\t B4 Return ");
						return((mymqd_t) mqinfo);
						/* $$.bp$$ */
						pthreaderr:
						errno = i;
						err:
						/* 4don't let following function calls change errno */
						save_errno = errno;
						if (created)
							unlink(pathname);
								if (mptr != MAP_FAILED)
									munmap(mptr, filesize);
										if (mqinfo != NULL)
											free(mqinfo);
												close(fd);
												errno = save_errno;
												return((mymqd_t) -1);
}
/* end mq_open3 */

mymqd_t
OpenMmap (const char *pathname, int oflag, ...)
{
	mymqd_t	mqd;
		va_list	ap;
		mode_t	mode;
		struct mymq_attr	*attr;
		
		if (oflag & O_CREAT) 
		{
			va_start(ap, oflag);		/* init ap to final named argument */
				mode = va_arg(ap, va_mode_t);
				attr = va_arg(ap, struct mymq_attr *);
				if ( (mqd = Mq_Open(pathname, oflag, mode, attr)) == (mymqd_t) -1)
					printf("Mq_Open error for %s", pathname);
						va_end(ap);
		} 
		else 
		{
			if ( (mqd = Mq_Open(pathname, oflag)) == (mymqd_t) -1)
				printf("Mq_Open error for %s", pathname);
		}
	printf("\n\t OpenMmap finished...");
		return(mqd);
}
