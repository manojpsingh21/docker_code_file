#include "IPCS.h"

LONG32	iMmapToRevRmsVal;
LONG32	iCatalystToRmsVal;
//CHAR    cValue;
redisContext *c;
redisReply *reply;
CHAR    iValue;

main(int argc, char *argv[])
{
	logTimestamp("Entry : Main");
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);

	iValue = atoi(argv[1]);

	fOpenMsgQue();
	c = RDConnect(REDIS_TYPE_RMS_VALIDATION);
	fRmsProcess(iMmapToRevRmsVal ,iCatalystToRmsVal);

	logTimestamp("Exit : Main");
}

void	fRmsProcess(LONG32 iMmapToRevRmsVal ,LONG32 iCatalystToRmsVal)
{
	logTimestamp("Entry : fRmsProcess");

	CHAR    RcvMsg[RUPEE_MAX_PACKET_SIZE] ;
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];
        CHAR sKeyValue[50];
        LONG32  iCount = 0;
	LONG32	iVal;
	LONG32	iLen = 0;
	ULONG64	iUserCode = 0;
	LONG32	iMsgType = 0;
	LONG32  iMsgLen= 0;
        LONG32  iMsgCode= 0;
	ULONG64 iClientId = 0;
	//	struct 	INT_COMMON_RESP_HDR *Resp;	
	struct  ORDER_RESPONSE *Resp;
        struct  ORDER_SPREAD_RESPONSE   *pSpredRes;	
	iVal = iValue;
	logDebug2("iVal = %d",iVal);

	while ( TRUE )
	{
		memset(&RcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset(sKeyValue,'\0' ,50);
		//		memset(Resp, '\0', sizeof(struct INT_COMMON_RESP_HDR));

		logInfo("---------================== WHILE LOOP -> RMS Order Count : %d=================---------",iCount++);

		if((ReadMsgQ(iMmapToRevRmsVal,&RcvMsg,RUPEE_MAX_PACKET_SIZE, 1)) == ERROR)
		{
			logFatal("Error in RcvMsgQ Id = %d",iMmapToRevRmsVal);
			exit(ERROR);
		}

		//		Resp = (struct INT_COMMON_RESP_HDR)RcvMsg;
		logDebug2("sClientId = %s",((struct ORDER_RESPONSE *)RcvMsg)->sClientId);
		logDebug2("sClientId = %s",((struct ORDER_SPREAD_RESPONSE *)RcvMsg)->sClientId);

		iUserCode = ((struct INT_COMMON_RESP_HDR *)RcvMsg)->iUserId;
		iClientId = strtoull(((struct ORDER_RESPONSE *)RcvMsg)->sClientId,NULL,10);
		iLen = ((struct INT_COMMON_RESP_HDR *)RcvMsg)->iMsgLength;
		iMsgCode  = ((struct INT_COMMON_RESP_HDR *)RcvMsg)->iMsgCode;
                logDebug2("Resp->IntRespHeader.iMsgCode = %d",((struct INT_COMMON_RESP_HDR *)RcvMsg)->iMsgCode);
                logDebug2("iMsgCode = %d",iMsgCode);

		logDebug2("iUserCode = %llu",iUserCode);
		logDebug2("iClientId = %llu",iClientId);

		iMsgType = (iClientId % iVal) + 1 ;
		
		logDebug2("iMsgType = %d",iMsgType);
		
		if(iMsgType > iVal)
		{
			iMsgType = 1;	
			logDebug2("Value is more than instance level = %d",iMsgType);
		}
		
		if(iMsgCode == TC_INT_SPREAD_OC_CONF_RESP || iMsgCode == TC_INT_SPREAD_OE_ERR_RESP || iMsgCode == TC_INT_SPREAD_OM_ERR_RESP || iMsgCode == TC_INT_SPREAD_OC_ERR_RESP)
                {
                        logInfo("Calling Spread Revers");
                        pSpredRes= (struct  ORDER_SPREAD_RESPONSE *)RcvMsg;
                        fTrim(pSpredRes->sClientId,strlen(pSpredRes->sClientId));
                        fTrim(pSpredRes->IntRespHeader.sExcgId,strlen(pSpredRes->IntRespHeader.sExcgId));
                        fTrim(pSpredRes->sSpreadLeg[0].sSecurityId,strlen(pSpredRes->sSpreadLeg[0].sSecurityId));
			
			memset(sKeyValue,'\0',50);
                        sprintf(sKeyValue,"REV:%d:%d:%s:%s:%c:%s:%c",iMsgType,GROUPID,pSpredRes->sClientId,pSpredRes->IntRespHeader.sExcgId,pSpredRes->IntRespHeader.cSegment,pSpredRes->sSpreadLeg[0].sSecurityId,pSpredRes->cProductId);
                        memset(sCommand,'\0',COMMAND_LEN);
                        sprintf(sCommand,"HMSET %s CALLFLAG Y CLIENTID %s PRODUCTID %c EXCH %s SEGMENT %c SECURITYID %s ORDERNO %f MSGCODE %d BUYSELL %c MKT_TYPE %d ",sKeyValue,pSpredRes->sClientId,pSpredRes->cProductId,pSpredRes->IntRespHeader.sExcgId,pSpredRes->IntRespHeader.cSegment,pSpredRes->sSpreadLeg[0].sSecurityId,pSpredRes->fOrderNum,pSpredRes->IntRespHeader.iMsgCode,pSpredRes->sSpreadLeg[0].cBuyOrSell,pSpredRes->iMktType);
                }
                else
                {
                        logInfo("Calling for Normal orders ");
                        Resp = (struct  ORDER_RESPONSE *)RcvMsg;
                        fTrim(Resp->sClientId,strlen(Resp->sClientId));
                        fTrim(Resp->IntRespHeader.sExcgId,strlen(Resp->IntRespHeader.sExcgId));
                        fTrim(Resp->sSecurityId,strlen(Resp->sSecurityId));

                        sprintf(sKeyValue,"REV:%d:%d:%s:%s:%c:%s:%c",iMsgType,GROUPID,Resp->sClientId,Resp->IntRespHeader.sExcgId,Resp->IntRespHeader.cSegment,Resp->sSecurityId,Resp->cProductId);
                        memset(sCommand,'\0',COMMAND_LEN);
                        sprintf(sCommand,"HMSET %s CALLFLAG Y CLIENTID %s PRODUCTID %c EXCH %s SEGMENT %c SECURITYID %s ORDERNO %f MSGCODE %d BUYSELL %c MKT_TYPE %d ",sKeyValue,Resp->sClientId,Resp->cProductId,Resp->IntRespHeader.sExcgId,Resp->IntRespHeader.cSegment,Resp->sSecurityId,Resp->fOrderNum,Resp->IntRespHeader.iMsgCode,Resp->cBuyOrSell,Resp->iMktType);	
		}
                logTimestamp("sCommand -> %s",sCommand);
                //reply = redisCommand(c,sCommand);
		reply = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);
                if(strcmp(reply->str,"OK") == 0)
                {
                        freeReplyObject(reply);

                        memset(sCommand,'\0',COMMAND_LEN);
                        sprintf(sCommand,"SADD SET:REV:%d:%d %s ",iMsgType,GROUPID,sKeyValue);
                        logTimestamp("sCommand -> %s",sCommand);
                        //reply = redisCommand(c,sCommand);
			reply = fRedisCommand(c,sCommand,REDIS_TYPE_RMS_VALIDATION);

                }
                else
                {
                        logInfo("Something went wrong while HMSET :%s:",reply->str);
                }
                freeReplyObject(reply);
			

		/**if((WriteMsgQ(iCatalystToRmsVal,RcvMsg,iLen,iMsgType)) == ERROR)
		{
			logFatal("Error in WriteMsgQ Id = %d",iCatalystToRmsVal);
			exit(ERROR);
		}**/

	}

	logTimestamp("Exit : fRmsProcess");

}

void	fOpenMsgQue()
{
	logTimestamp("Entry : fOpenMsgQue");

	if((iMmapToRevRmsVal = OpenMsgQ(MmapToRevRmsVal) ) == ERROR)
	{
		logDebug2("Error in OpenMsgQ (MmapToRevRmsVal)");
		exit(ERROR);
	}
	logDebug2("MmapToRevRmsVal open Successfully = %d",iMmapToRevRmsVal);	

	if ((iCatalystToRmsVal = OpenMsgQ(CatalystToRmsVal)) == ERROR)
	{
		logDebug2("Error in OpenMsgQ (iCatalystToRmsVal)");
		exit(ERROR);
	}
	logDebug2("iCatalystToRmsVal open suceessfully = %d",iCatalystToRmsVal);

	logTimestamp("Exit : fOpenMsgQue");
}
