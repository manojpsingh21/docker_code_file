#include    "MemMapConfig.h"
#include    "MemMapqueue.h"
#include    "MemMapCommon.h"


/*
  extern double  OffMsgArray[MAX_NO_OFFLINE_THREAD];
  extern pthread_mutex_t             OffMsgArrayMutex;
 */

/*#define TWIDDLE(A)                  Twiddle ((char *) &A, sizeof(A))*/


ssize_t
Mq_Read(mymqd_t mqd, char *ptr, size_t maxlen, unsigned int *priop)
{
	int		n;
		long	index;
		int8_t	*mptr;
		ssize_t	len;
		struct mymq_hdr		*mqhdr;
		struct mymq_attr	*attr;
		struct mymsg_hdr	*msghdr;
		struct mymq_info	*mqinfo;
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;	/* struct pointer */
		mptr = (int8_t *) mqhdr;	/* byte pointer */
		attr = &mqhdr->mqh_attr;
		
		/*
		  Lock Mutex before accessing Q.
		 */
		
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			errno = n;
				return(-1);
		}
	
		if (maxlen < attr->mq_msgsize) 
		{
			errno = EMSGSIZE;
				goto err;
		}
	
		if (attr->mq_curmsgs == 0) 
		{
			/* i.e. queue is empty */
				
				if (mqinfo->mqi_flags & O_NONBLOCK) 
				{
					errno = EAGAIN;
						goto err;
				}
			
				/* 4wait for a message to be placed onto queue */
				
				mqhdr->mqh_nwait++;
				while (attr->mq_curmsgs == 0)
					pthread_cond_wait(&mqhdr->mqh_wait, &mqhdr->mqh_lock);
						mqhdr->mqh_nwait--;
		}
	
		/*
		  Copying the index of message to read.
		 */
		
		if ( (index = mqhdr->mqh_head) == 0)
		{
			printf("mymq_receive: curmsgs = %ld; head = 0", attr->mq_curmsgs);
				exit(1);
		}
	
		printf("\nmqhdr->mqh_head:%d",mqhdr->mqh_head);
		
		msghdr = (struct mymsg_hdr *) &mptr[index];
		
		/*
		  Now, Head Ptr is moved to next location.
		 */
		
		mqhdr->mqh_head = msghdr->msg_next;	/* new head of list */
		len = msghdr->msg_len;
		memcpy(ptr, msghdr + 1, len);		/* copy the message itself */
		
		if (priop != NULL)
			*priop = msghdr->msg_prio;
				
				/* 4just-read message goes to front of free list */
				
				msghdr->msg_next = mqhdr->mqh_free;
				mqhdr->mqh_free = index;
				
				/* 4wake up anyone blocked in mq_send waiting for room */
				if (attr->mq_curmsgs == attr->mq_maxmsg)
					pthread_cond_signal(&mqhdr->mqh_wait);
						attr->mq_curmsgs--;
						
						pthread_mutex_unlock(&mqhdr->mqh_lock);
						return(len);
						
						err:
						pthread_mutex_unlock(&mqhdr->mqh_lock);
						return(-1);
}
/* end mq_receive2 */

ssize_t
ReadMmap(mymqd_t mqd, char *ptr, size_t len, unsigned int *priop)
{
	ssize_t	n;
		
		if ( (n = Mq_Read(mqd, ptr, len, priop)) == -1)
			printf("Mq_Read error");
				
				return(n);
}

/*
  Purpose: To Read Sequntial Exchange Response for a  Exch Order No.
  Move Processed buffer to the Free List, i.e. msg_status=MSG_PROCESSED and move the Header Ptr as well.
  Picks packet not in Global Array nad mark as MSG_UNDER_PROCESS
  Access: Global Array Access Which contains exch ord no currently under processing.
  Lock Global Array before calling this function.
 */
ssize_t
Mq_Seq_Read(mymqd_t mqd, char *ptr, size_t maxlen, unsigned int *priop)
{
	int		n;
		int		NoOfThread=0;
		int 	PktStatus=0, InsertPosn=0,MsgNumber=0;
		long	index;
		int8_t	*mptr;
		ssize_t	len;
		struct mymq_hdr		*mqhdr;
		struct mymq_attr	*attr;
		struct mymsg_hdr	*msghdr, *pmsghdr ;
		struct mymq_info	*mqinfo;
		CHAR    RcvMsg [ LOCAL_MAX_PACKET_SIZE  ];
		int QtyRemain=0;
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;	/* struct pointer */
		mptr = (int8_t *) mqhdr;	/* byte pointer */
		attr = &mqhdr->mqh_attr;
		
		
		/*
		  Lock Mutex before accessing Q.
		 */
		
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			errno = n;
				return(-1);
		}
	
		if (maxlen < attr->mq_msgsize) 
		{
			errno = EMSGSIZE;
				goto err;
		}
	
		if (attr->mq_curmsgs == 0) 
		{
			/* i.e. queue is empty */
				
				if (mqinfo->mqi_flags & O_NONBLOCK) 
				{
					errno = EAGAIN;
						goto err;
				}
			
				/* 4wait for a message to be placed onto queue */
				
				mqhdr->mqh_nwait++;
				while (attr->mq_curmsgs == 0)
					pthread_cond_wait(&mqhdr->mqh_wait, &mqhdr->mqh_lock);
						mqhdr->mqh_nwait--;
		}
	
		/*
		  Acquire Lock On OffMsgArrayMutex, So that It remains unchanged while scanning pkts.
		 */
		
		LockThreadMutex(&OffMsgArrayMutex);
		
		printf("\n#############Acquired Lock On OffMsgArrayMutex.#####################");
		
		/*
		  Copying the index of message to read.
		 */
		
		if ( (index = mqhdr->mqh_head) == 0)
		{
			printf("mymq_receive: curmsgs = %ld; head = 0", attr->mq_curmsgs);
				exit(1);
		}
	
		printf("\nmqhdr->mqh_head:%d",mqhdr->mqh_head);
		
		msghdr = (struct mymsg_hdr *) &mptr[index];
		
		/*
		  To Check if the  corresponding Exch Ord No is already under process, skip the packet.
		 */
		
		for ( NoOfThread=0 ; NoOfThread< MAX_NO_OFFLINE_THREAD ; NoOfThread++)
		{
			printf("\nOffMsgArray:%lf",OffMsgArray[NoOfThread] );
		}
	
		printf("\n Mq_Seq_Read:Before while Loop.");
		
		while (index != 0)
		{
			PktStatus=0;
				msghdr = (struct mymsg_hdr *) &mptr[index];
				
				printf("\nIn MqSeqRead.");
				printf("\nmsghdr->msg_exch_ord_no:%lf",msghdr->msg_exch_ord_no);
				
				for ( NoOfThread=0 ; NoOfThread< MAX_NO_OFFLINE_THREAD ; NoOfThread++)
				{
					if (OffMsgArray[NoOfThread] == msghdr->msg_exch_ord_no)
					{
						PktStatus=PKT_EXIST ;
					}
				}
			if(PktStatus == 0)
			{
				PktStatus=PKT_NOT_EXIST ;
			}
			
				if (PktStatus == PKT_NOT_EXIST)
				{
					
						len = msghdr->msg_len;
						memcpy(ptr, msghdr + 1, len);		/* copy the message itself */
						
						memcpy(RcvMsg,msghdr + 1,len);   /*DELTEE */
						
						if( index == mqhdr->mqh_head )
						{
							printf("\nMsg is First on List, i.e. HeadPtr itself.");
								
								/*
								  Now, Head Ptr is moved to next location.
								 */
								
								mqhdr->mqh_head = msghdr->msg_next;	/* new head of list */
						}
						else 
						{
							/*nmsghdr->msg_next = index;*/
								pmsghdr->msg_next = msghdr->msg_next;
						}
					
						break;
				} /* End of IF for Order Match*/
				else
				{
					printf("\n Found Exch Ord No:%lf",msghdr->msg_exch_ord_no);
				}
			
				
				
				index = msghdr->msg_next;
				pmsghdr = msghdr;
				printf("\nindex:%ld, pmsghdr->msg_next:%ld",index,pmsghdr->msg_next);
				printf("\nwhile:index:%d",index); 
		}
	
		
		/* 
		   Put the Exchange Ord No in Array and send the location to Child.
		 */
		
		if (PktStatus == PKT_NOT_EXIST)
		{
			for ( NoOfThread=0 ; NoOfThread< MAX_NO_OFFLINE_THREAD ; NoOfThread++)
			{
				if (OffMsgArray[NoOfThread] == UNUSED)
				{
					OffMsgArray[NoOfThread]=msghdr->msg_exch_ord_no;
						InsertPosn=NoOfThread;
						MsgNumber=msghdr->msg_number;
						break;
				}
			}	
			
				/*TEMP-START*
				  
				  QtyRemain=((struct NNF_TRADE_CONF_RESP *)RcvMsg)->QtyRemaining;
				  
				  TWIDDLE(QtyRemain);
				  printf("\n Exch Order Nu :%lf, QtyRemainin : %d",msghdr->msg_exch_ord_no,QtyRemain);
				  
				  
				  
				 *TEMP-END*/
				
				/* 4just-read message goes to front of free list */
				
				printf("\nJust Read Message Going To Free Ptr:%ld",index);
				msghdr->msg_next = mqhdr->mqh_free;
				mqhdr->mqh_free = index;
		}
	
		
		
		if (priop != NULL)
			*priop = msghdr->msg_prio;
				
				/* 4just-read message goes to front of free list */
				
				/*
				  if(index !=0)
				  {
				  
				  printf("\nJust Read Message Going To Free Ptr:%ld",index);
				  msghdr->msg_next = mqhdr->mqh_free;
				  mqhdr->mqh_free = index;
				  }
				 */
				
				/* 4wake up anyone blocked in mq_send waiting for room */
				
				if (PktStatus == PKT_NOT_EXIST)
				{
					printf("\nReturning Position and Index for Pkt.");
						
						(( struct TempMmap * )ptr )->FileIndex = index;
						(( struct TempMmap * )ptr )->ArrayPosn = InsertPosn;
						(( struct TempMmap * )ptr )->MsgNumber = MsgNumber;
						
						if (attr->mq_curmsgs == attr->mq_maxmsg)
							pthread_cond_signal(&mqhdr->mqh_wait);
								attr->mq_curmsgs--;
				}
				else
				{
					(( struct TempMmap * )ptr )->FileIndex = PKT_NOT_FIND;
						(( struct TempMmap * )ptr )->ArrayPosn = PKT_NOT_FIND;
						(( struct TempMmap * )ptr )->MsgNumber = PKT_NOT_FIND;
				}
	
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		UnLockThreadMutex(&OffMsgArrayMutex);
		return(len);
		
		err:
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		UnLockThreadMutex(&OffMsgArrayMutex);
		return(-1);
}

ssize_t
ReadSeqMmap(mymqd_t mqd, char *ptr, size_t len, unsigned int *priop)
{
	ssize_t	n;
		
		if ( (n = Mq_Seq_Read(mqd, ptr, len, priop)) == -1)
			printf("Mq_Seq_Read error");
				
				return(n);
}

typedef struct TempMmap TempMmap;


/*******************Following Function is For Persistent Read From File-START***************/

Mq_Persist_Read(mymqd_t mqd, char *ptr, size_t maxlen, unsigned int *priop)
{
	int		n;
		int		NoOfThread=0;
		int 	PktStatus=0, InsertPosn=0,MsgNumber=0,MoveFree=0;
		long	index,MoveIndex=0;
		int8_t	*mptr;
		ssize_t	len;
		struct mymq_hdr		*mqhdr;
		struct mymq_attr	*attr;
		struct mymsg_hdr	*msghdr, *pmsghdr,*fmsghdr ;
		struct mymq_info	*mqinfo;
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;	/* struct pointer */
		mptr = (int8_t *) mqhdr;	/* byte pointer */
		attr = &mqhdr->mqh_attr;
		
		
		/*
		  Lock Mutex before accessing Q.
		 */
		
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			errno = n;
				return(-1);
		}
	
		if (maxlen < attr->mq_msgsize) 
		{
			errno = EMSGSIZE;
				goto err;
		}
	
		if (attr->mq_curmsgs == 0) 
		{
			/* i.e. queue is empty */
				
				if (mqinfo->mqi_flags & O_NONBLOCK) 
				{
					errno = EAGAIN;
						goto err;
				}
			
				/* 4wait for a message to be placed onto queue */
				
				mqhdr->mqh_nwait++;
				while (attr->mq_curmsgs == 0)
					pthread_cond_wait(&mqhdr->mqh_wait, &mqhdr->mqh_lock);
						mqhdr->mqh_nwait--;
		}
	
		/*
		  Acquire Lock On OffMsgArrayMutex, So that It remains unchanged while scanning pkts.
		 */
		
		LockThreadMutex(&OffMsgArrayMutex);
		
		printf("\n#############Acquired Lock On OffMsgArrayMutex.#####################");
		
		/*
		  Copying the index of message to read.
		 */
		
		if ( (index = mqhdr->mqh_head) == 0)
		{
			printf("mymq_receive: curmsgs = %ld; head = 0", attr->mq_curmsgs);
				exit(1);
		}
	
		printf("\nmqhdr->mqh_head:%d",mqhdr->mqh_head);
		
		msghdr = (struct mymsg_hdr *) &mptr[index];
		
		/*
		  To Check if the  corresponding Exch Ord No is already under process, skip the packet.
		 */
		
		for ( NoOfThread=0 ; NoOfThread< MAX_NO_OFFLINE_THREAD ; NoOfThread++)
		{
			printf("\nOffMsgArray:%lf",OffMsgArray[NoOfThread] );
		}
	
		printf("\n Before while Loop.");
		
		while (index != 0)
		{
			PktStatus=0;
				MoveFree=0;
				MoveIndex=0;
				msghdr = (struct mymsg_hdr *) &mptr[index];
				
				printf("\nIn MqSeqRead.");
				printf("\nmsghdr->msg_exch_ord_no:%lf",msghdr->msg_exch_ord_no);
				
				for ( NoOfThread=0 ; NoOfThread< MAX_NO_OFFLINE_THREAD ; NoOfThread++)
				{
					if (OffMsgArray[NoOfThread] == msghdr->msg_exch_ord_no)
					{
						PktStatus=PKT_EXIST ;
					}
				}
			if(PktStatus == 0)
			{
				PktStatus=PKT_NOT_EXIST ;
			}
			
				if (PktStatus == PKT_NOT_EXIST)
				{
					
						if(msghdr->msg_status == MSG_PROCESSED )
						{
							MoveFree=1;
								MoveIndex=index;
								
								/*
								  if( index == mqhdr->mqh_head )
								  {
								  printf("\nFREE:Msg is First on List, i.e. HeadPtr itself.");
								  
								 *
								 Now, Head Ptr is moved to next location.
								 *
								 
								 mqhdr->mqh_head = msghdr->msg_next;	* new head of list *
								 
								 
								 fmsghdr = (struct mymsg_hdr *) &mptr[msghdr->msg_next];
								 
								 
								 fmsghdr->msg_next = mqhdr->mqh_free;  * Move Pkt to FreePtr *
								 mqhdr->mqh_free = index;
								 
								 printf("\nHEAD:PKT_NOT_EXIST:MSG_PROCESSED:-msghdr->msg_next:%ld,mqhdr->mqh_free:%ld", msghdr->msg_next,mqhdr->mqh_free );
								 }
								 else 
								 {
								 printf("\nFREE:Msg is in Middle.");
								 
								 pmsghdr->msg_next = msghdr->msg_next;
								 
								 fmsghdr = (struct mymsg_hdr *) &mptr[msghdr->msg_next];
								 
								 fmsghdr->msg_next = mqhdr->mqh_free;   * Move Pkt to FreePtr *
								 
								 mqhdr->mqh_free = index;
								 
								 printf("\nMIDDLE:PKT_NOT_EXIST:MSG_PROCESSED:-msghdr->msg_next:%ld,mqhdr->mqh_free:%ld", msghdr->msg_next,mqhdr->mqh_free );
								 }
								 */
						}
					
						if( msghdr->msg_status == MSG_NOT_PROCESSED)
						{
							
								len = msghdr->msg_len;
								memcpy(ptr, msghdr + 1, len);				/* copy the message itself */
								msghdr->msg_status=MSG_UNDER_PROCESSES;  	/* Update Status as Msg is scheduled to process. */
								
								if( index == mqhdr->mqh_head )
								{
									printf("\nMsg is First on List, i.e. HeadPtr itself.");
										
										
								}
								else 
								{
									printf("\n Read Msg Lies in Middle.");
								}
							break;
						}	
					
						if(msghdr->msg_status == MSG_UNDER_PROCESSES )
						{
							printf("\n Here Control Should Not Reach, If it COMES some major ERROR.");
						}
					
				} /* End of IF for Order Match*/
				else
				{
					printf("\n Found Exch Ord No:%lf",msghdr->msg_exch_ord_no);
						
						/*
						  PKT EXIST: See If The Status of The Pkt is MSG_PROCESSED. Move it to FreePtr.
						  If it is HeadPtr then change it too.
						 */
						if(msghdr->msg_status ==  MSG_PROCESSED )
						{
							MoveFree=1;
								MoveIndex=index;
								
								/***************************
								  if( index == mqhdr->mqh_head )
								  {
								  printf("\nFREE:Msg is First on List, i.e. HeadPtr itself.");
								  
								 *
								 Now, Head Ptr is moved to next location.
								 *
								 
								 mqhdr->mqh_head = msghdr->msg_next;	* new head of list *
								 
								 fmsghdr = (struct mymsg_hdr *) &mptr[msghdr->msg_next];
								 fmsghdr->msg_next = mqhdr->mqh_free;   * Move Pkt to FreePtr *
								 
								 msghdr->msg_next = mqhdr->mqh_free;  * Move Pkt to FreePtr *
								 mqhdr->mqh_free = index;
								 }
								 else 
								 {
								 printf("\nFREE:Msg is in Middle.");
								 
								 pmsghdr->msg_next = msghdr->msg_next;
								 
								 fmsghdr = (struct mymsg_hdr *) &mptr[msghdr->msg_next];
								 fmsghdr->msg_next = mqhdr->mqh_free;   * Move Pkt to FreePtr *
								 
								 msghdr->msg_next = mqhdr->mqh_free;   * Move Pkt to FreePtr *
								 mqhdr->mqh_free = index;
								 }
								 *****************************/
						}
					
				}
			
				index = msghdr->msg_next;
				pmsghdr = msghdr;
				printf("\nindex:%ld, pmsghdr->msg_next:%ld",index,pmsghdr->msg_next);
				printf("\nwhile:index:%d",index); 
				
				if (MoveFree == 1)
				{
					fmsghdr = (struct mymsg_hdr *) &mptr[msghdr->msg_next];
						if( MoveIndex == mqhdr->mqh_head )
						{
							printf("\nFREE:Msg is First on List, i.e. HeadPtr itself.");
								
								/*
								  Now, Head Ptr is moved to next location.
								 */
								
								mqhdr->mqh_head = msghdr->msg_next;	/* new head of list */
								
								fmsghdr = (struct mymsg_hdr *) &mptr[MoveIndex];
								fmsghdr->msg_next = mqhdr->mqh_free;   /* Move Pkt to FreePtr */
								
								mqhdr->mqh_free = MoveIndex;
								printf("\nHEAD:%ldMSG_PROCESSED:msghdr->msg_next:%ld,mqhdr->mqh_free:%ld", mqhdr->mqh_head,msghdr->msg_next,mqhdr->mqh_free );
								printf("\nfmsghdr->msg_next:%ld",fmsghdr->msg_next);
						}
						else 
						{
							printf("\nFREE:Msg is in Middle.");
								
								pmsghdr->msg_next = msghdr->msg_next;
								
								fmsghdr = (struct mymsg_hdr *) &mptr[MoveIndex];
								fmsghdr->msg_next = mqhdr->mqh_free;   /* Move Pkt to FreePtr */
								
								mqhdr->mqh_free = MoveIndex;
								printf("\nMIDDLE:MSG_PROCESSED:msghdr->msg_next:%ld,mqhdr->mqh_free:%ld", msghdr->msg_next,mqhdr->mqh_free );
								printf("\nfmsghdr->msg_next:%ld",fmsghdr->msg_next);
						}
					
						/* 4wake up anyone blocked in mq_send waiting for room */
						if (attr->mq_curmsgs == attr->mq_maxmsg)
							pthread_cond_signal(&mqhdr->mqh_wait);
								attr->mq_curmsgs--;
								
				}
			
				/**
				  index = msghdr->msg_next;
				  pmsghdr = msghdr;
				  printf("\nindex:%ld, pmsghdr->msg_next:%ld",index,pmsghdr->msg_next);
				  printf("\nwhile:index:%d",index); 
				 ***/
				printf("\nindex:%ld, pmsghdr->msg_next:%ld",index,pmsghdr->msg_next);
		}
	
		
		/* 
		   Put the Exchange Ord No in Array and send the location to Child.
		 */
		
		if (PktStatus == PKT_NOT_EXIST)
		{
			for ( NoOfThread=0 ; NoOfThread< MAX_NO_OFFLINE_THREAD ; NoOfThread++)
			{
				if (OffMsgArray[NoOfThread] == UNUSED)
				{
					OffMsgArray[NoOfThread]=msghdr->msg_exch_ord_no;
						InsertPosn=NoOfThread;
						MsgNumber=msghdr->msg_number;
						break;
				}
			}	
			
				/* 4just-read message goes to front of free list */
				
				/*
				  printf("\nJust Read Message Going To Free Ptr:%ld",index);
				  msghdr->msg_next = mqhdr->mqh_free;
				  mqhdr->mqh_free = index;
				 */
		}
	
		
		
		if (priop != NULL)
			*priop = msghdr->msg_prio;
				
				
				
				/* 4wake up anyone blocked in mq_send waiting for room */
				
				if (PktStatus == PKT_NOT_EXIST)
				{
					printf("\nReturning Position and Index for Pkt.");
						
						(( struct TempMmap * )ptr )->FileIndex = index;
						(( struct TempMmap * )ptr )->ArrayPosn = InsertPosn;
						(( struct TempMmap * )ptr )->MsgNumber = MsgNumber;
						
						/***TEST***
						  if (attr->mq_curmsgs == attr->mq_maxmsg)
						  pthread_cond_signal(&mqhdr->mqh_wait);
						  attr->mq_curmsgs--;
						 ***TEST***/
				}
				else
				{
					(( struct TempMmap * )ptr )->FileIndex = PKT_NOT_FIND;
						(( struct TempMmap * )ptr )->ArrayPosn = PKT_NOT_FIND;
						(( struct TempMmap * )ptr )->MsgNumber = PKT_NOT_FIND;
				}
	
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		UnLockThreadMutex(&OffMsgArrayMutex);
		return(len);
		
		err:
		pthread_mutex_unlock(&mqhdr->mqh_lock);
		UnLockThreadMutex(&OffMsgArrayMutex);
		return(-1);
}

ssize_t
ReadPersistMmap(mymqd_t mqd, char *ptr, size_t len, unsigned int *priop)
{
	ssize_t	n;
		
		if ( (n = Mq_Seq_Read(mqd, ptr, len, priop)) == -1)
			printf("Mq_Seq_Read error");
				
				return(n);
}

/*******************Following Function is For Persistent Read From File-END***************/
