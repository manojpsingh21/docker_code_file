BOOL fparticipantFile ()
{
        logTimestamp("ENTRY fparticipantFile [Main]");

        MYSQL_RES       *Res , *Res1;
        MYSQL_ROW       Row;
        LONG32  iRow;
        CHAR    sSelectQry [MAX_QUERY_SIZE];
        memset(sSelectQry,'\0',MAX_QUERY_SIZE);
        CHAR sFileName [FILE_NAME_LEN];
        memset (sFileName,'\0',FILE_NAME_LEN);

	sprintf(sSelectQry,"select concat(ifnull(PM_EXCHANGE,'')),'|',ifnull(PM_SEGMENT,''),'|',\
				PM_PARTICIPANT_NAME,'|',PM_PARTICIPANT_ID \
				from PARTICIPANT_MASTER s WHERE    	s.PM_DELETE_FLAG = 'N'        AND s.PM_PARTICIPANT_STATUS = 'A';");
	
	logDebug2("Query[%s]",sSelectQry);
	
	if (mysql_query(DBCon, sSelectQry) != SUCCESS)
        {
                sql_Error(DBCon);
                logSqlFatal("Error Fetching Participant Code in fParticipantFile.");
                exit(ERROR);
        }
        Res = mysql_store_result(DBCon);
        iRow = mysql_num_rows(Res);
        if (iRow == 0)
        {
                mysql_free_result(Res);
                logInfo("No result set");
        }

	else
        {
                logDebug2("No of rows selected for fBrokerClientFile = %d",iRow);
                sprintf(sFileName,"%s/%s",FILE_LOCATION,ClientFileId);
                logDebug2("sFileName = %s",sFileName);
                logDebug2("FILE_LOCATION = %s ",FILE_LOCATION);
                fpFile = fopen(sFileName,"wb");
                if (fpFile == NULL)
                {
                        logFatal("Not able to Open File in append mode");
                        exit(0);
                }
                else
                {
                        while((Row = mysql_fetch_row(Res)))
                        {
                                logDebug2("Row :%s:",Row[0]);
                                /*
                                   strncpy(sString,Row[0],strlen(Row[0]));
                                   for (i=0; sString[i]!= '\0'; i++)
                                   {
                                   if (sString[i] == '*')
                                   {
                                   for (j=0; j<1; j++)
                                   {
                                   sString[i+j] = '';
                                   }
                                   }
                                   }
                                 */

                                fprintf(fpFile ,"%s\n",Row[0]);

                        }
                        mysql_free_result(Res);
                        fprintf(fpFile,"*\n");
                        fclose(fpFile);

                        fConvToPwdPrtect(sFileName,CLIENT_FILE_NM,ClientFileId);
                }

        }
        logTimestamp("EXIT fParticipantFile [Main]");
}
