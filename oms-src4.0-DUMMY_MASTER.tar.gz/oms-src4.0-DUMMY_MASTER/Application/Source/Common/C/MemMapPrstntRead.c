#include    "MemMapConfig.h"
#include    "MemMapqueue.h"
#include    "MemMapCommon.h"

extern double  OffMsgArray[MAX_NO_OFFLINE_THREAD];
extern pthread_mutex_t             OffMsgArrayMutex;
struct mymsg_hdr	*msghdrGLOBAL;
struct mymq_hdr     *mqhdrGLOBAL;
long	sacindexGLOBAL = 0;	

ssize_t
Mq_Read(mymqd_t mqd, char *ptr, size_t maxlen, unsigned int *priop)
{
	int		n;
		long	index;
		int8_t	*mptr;
		ssize_t	len;
		struct mymq_hdr		*mqhdr;
		struct mymq_attr	*attr;
		struct mymsg_hdr	*msghdr;
		struct mymq_info	*mqinfo;
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC) 
		{
			errno = EBADF;
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;	/* struct pointer */
		mptr = (int8_t *) mqhdr;	/* byte pointer */
		attr = &mqhdr->mqh_attr;
		/*
		  Lock Mutex before accessing Q.
		 */
		
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0) 
		{
			errno = n;
				return(-1);
		}
	
		if (maxlen < attr->mq_msgsize) 
		{
			errno = EMSGSIZE;
				goto err;
		}
	
		if (attr->mq_curmsgs == 0) 
		{
			/* i.e. queue is empty */
				
				if (mqinfo->mqi_flags & O_NONBLOCK) 
				{
					errno = EAGAIN;
						goto err;
				}
			
				/* 4wait for a message to be placed onto queue */
				
				mqhdr->mqh_nwait++;
				while (attr->mq_curmsgs == 0)
					pthread_cond_wait(&mqhdr->mqh_wait, &mqhdr->mqh_lock);
						mqhdr->mqh_nwait--;
		}
	
		/*
		  Copying the index of message to read.
		 */
		
		if ( (index = mqhdr->mqh_head) == 0)
		{
			printf("mymq_receive: curmsgs = %ld; head = 0", attr->mq_curmsgs);
				exit(1);
		}
	
		printf("\nmqhdr->mqh_head:%d",mqhdr->mqh_head);
		
		msghdr = (struct mymsg_hdr *) &mptr[index];
		
		/*
		  Now, Head Ptr is moved to next location.
		 */
		
		mqhdr->mqh_head = msghdr->msg_next;	/* new head of list */
		len = msghdr->msg_len;
		memcpy(ptr, msghdr + 1, len);		/* copy the message itself */
		
		if (priop != NULL)
			*priop = msghdr->msg_prio;
				
				/* 4just-read message goes to front of free list */
				
				msghdr->msg_next = mqhdr->mqh_free;
				mqhdr->mqh_free = index;
				
				/* 4wake up anyone blocked in mq_send waiting for room */
				if (attr->mq_curmsgs == attr->mq_maxmsg)
					pthread_cond_signal(&mqhdr->mqh_wait);
						attr->mq_curmsgs--;
						
						pthread_mutex_unlock(&mqhdr->mqh_lock);
						return(len);
						
						err:
						pthread_mutex_unlock(&mqhdr->mqh_lock);
						return(-1);
}
/* end mq_receive2 */

ssize_t
ReadMmap(mymqd_t mqd, char *ptr, size_t len, unsigned int *priop)
{
	ssize_t	n;
		
		if ( (n = Mq_Read(mqd, ptr, len, priop)) == -1)
			printf("Mq_Read error");
				
				return(n);
}

/*
  Purpose: To Read Sequntial Exchange Response for a  Exch Order No.
  Move Processed buffer to the Free List, i.e. msg_status=MSG_PROCESSED and move the Header Ptr as well.
  Picks packet not in Global Array nad mark as MSG_UNDER_PROCESS
  Access: Global Array Access Which contains exch ord no currently under processing.
  Lock Global Array before calling this function.
 */
ssize_t
Mq_Seq_Prsnt_Read(mymqd_t mqd, char *ptr, size_t maxlen, unsigned int *priop)
{
	int     n;
		int     NoOfThread=0;
		int     PktStatus=0, InsertPosn=0,MsgNumber=0,MoveFree=0;
		long    index,MoveIndex=0,sacindex;
		int8_t  *mptr;
		ssize_t len=0;
		struct mymq_hdr     *mqhdr;
		struct mymq_attr    *attr;
		struct mymsg_hdr    *msghdr, *pmsghdr,*fmsghdr ;
		struct mymq_info    *mqinfo;
		
		mqinfo = mqd;
		if (mqinfo->mqi_magic != MQI_MAGIC)
		{
			errno = EBADF;
				return(-1);
		}
	mqhdr = mqinfo->mqi_hdr;    /* struct pointer */
		mptr = (int8_t *) mqhdr;    /* byte pointer */
		attr = &mqhdr->mqh_attr;
		/*****************/
		printf("\n\tHead = %d",mqhdr ->mqh_head);
		
		/*
		  Lock Mutex before accessing Q.
		 */
		
		if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0)
		{
			errno = n;
				return(-1);
		}
	
		if (maxlen < attr->mq_msgsize)
		{
			errno = EMSGSIZE;
				goto err;
		}
	printf("\n ********** mq_curmsgs ****** :: %d",attr->mq_curmsgs);
		
		if (attr->mq_curmsgs == 0)
		{
			/* i.e. queue is empty */
				printf("\n ********** mq_curmsgs ****** :: %d",attr->mq_curmsgs);
				
				if (mqinfo->mqi_flags & O_NONBLOCK)
				{
					errno = EAGAIN;
						goto err;
				}
			
				/* 4wait for a message to be placed onto queue */
				mqhdr->mqh_nwait++;
				while (attr->mq_curmsgs == 0)
					pthread_cond_wait(&mqhdr->mqh_wait, &mqhdr->mqh_lock);
						mqhdr->mqh_nwait--;
						
						
						printf("\nFile is Empty:%d",attr->mq_curmsgs);
						
						goto err;
		}
	
		
		LockThreadMutex(&OffMsgArrayMutex);
		
		/*
		  Copying the index of message to read.
		 */
		
		
		printf("\nmqhdr->mqh_head:%d",mqhdr->mqh_head);
		
		sacindex = mqhdr->mqh_last;
		printf("\n\n\tsacindex = %d",sacindex);
		
		
		while (attr->mq_curmsgs != 0)
		{
			PktStatus=0;
				msghdr = (struct mymsg_hdr *) &mptr[sacindex];
				printf("\nmsghdr->msg_status :: %d ",msghdr->msg_status);
				if (msghdr->msg_status == 0)
				{	
					printf ("\n Empty packet");
						exit(1);	
				}
			if(msghdr->msg_status == MSG_NOT_PROCESSED)
			{
				printf("\nPktDetails:-START");
					printf("\nmsghdr->msg_exch_ord_no:%lf",msghdr->msg_exch_ord_no);
					printf("\nmsghdr->msg_status:%d",msghdr->msg_status);
					printf("\nmsghdr->msg_next:%ld",msghdr->msg_next);
					printf("\nPktDetails:-END");
					/***********************************************
					  msghdr->msg_status=MSG_PROCESSED; 
					  Will be changed later as per new req. of TradePush in IBSL
					 ***********************************************/
					printf("\n\t Copying the data in the packet... ");
					msghdrGLOBAL	=	msghdr;
					len = msghdr->msg_len;
					memcpy(ptr, msghdr + 1, len);
					
					/***********************************************
					  This GLOBAL variable will be used to restore the last ptr
					  index value if socket send is unsuccfesfuel .]
					  This is excluseive req. of TRADEPUSH in IBSL
					 ***********************************************/
					sacindexGLOBAL	=	sacindex;	
					/* Commented this part and moved this to SetStatusofPacket so that the program points to the next pointer
					   after the packet is written into the queue. */
					/*sacindex = msghdr->msg_next;
					  if (sacindex == 0)
					  {
					  sacindex = mqhdr->mqh_head ;
					  sacindexGLOBAL	=	sacindex;	
					  } 
					  mqhdr->mqh_last = sacindex;
					  mqhdrGLOBAL		=		mqhdr;
					  pmsghdr = msghdr;
					  if(msghdr->msg_next == 0)
					  {
					  (( struct TempMmap * )ptr )->FileIndex = index;
					  }
					  else
					  {
					  (( struct TempMmap * )ptr )->FileIndex = -1;
					  }*/
					
					
					pthread_mutex_unlock(&mqhdr->mqh_lock);
					UnLockThreadMutex(&OffMsgArrayMutex);
					if (attr->mq_curmsgs == attr->mq_maxmsg)
						pthread_cond_signal(&mqhdr->mqh_wait);
							
							/****** Commented  as messages are reduced after message state is changed to MSG_PROCESSED***
							  
							  attr->mq_curmsgs--;
							  
							 ****************************/
							printf("\nBefore Returning");
							return(len);
			}
			sacindex = msghdr->msg_next;
				pmsghdr = msghdr;
		}
	(( struct TempMmap * )ptr )->FileIndex = -1;
		(( struct TempMmap * )ptr )->ArrayPosn = -1;
		(( struct TempMmap * )ptr )->MsgNumber = -1;
		
		
		/*
		  Put the Exchange Ord No in Array and send the location to Child.
		 */
		
		
		
		if (priop != NULL)
			*priop = msghdr->msg_prio;
				
				
				
				
				pthread_mutex_unlock(&mqhdr->mqh_lock);
				UnLockThreadMutex(&OffMsgArrayMutex);
				return(len);
				
				err:
				pthread_mutex_unlock(&mqhdr->mqh_lock);
				UnLockThreadMutex(&OffMsgArrayMutex);
				return(-1);
}	

ssize_t
ReadPrsntSeqMmap(mymqd_t mqd, char *ptr, size_t len, unsigned int *priop)
{
	ssize_t	n;
		
		if ( (n = Mq_Seq_Prsnt_Read(mqd, ptr, len, priop)) == -1)
			printf("Mq_Seq_Read error");
				printf("\nMemMapPrstntRead ReadPrsntSeqMmap Return :: %ld ",n);
				
				return(n);
}

typedef struct TempMmap TempMmap;


void SetStatusofPacket( int STATUS,mymqd_t mqd)
{
	int n;
		int     NoOfThread=0;
		int     PktStatus=0, InsertPosn=0,MsgNumber=0,MoveFree=0;
		long    index,MoveIndex=0,sacindex;
		int8_t  *mptr;
		ssize_t len=0;
		struct mymq_hdr     *mqhdr;
		struct mymq_attr    *attr;
		struct mymsg_hdr    *msghdr, *pmsghdr,*fmsghdr ;
		struct mymq_info    *mqinfo;
		
		printf("\nSTATUS inside SetStatusofPacket = %d..\n",STATUS);
		
		
		if(STATUS     EQUALS      TRUE)
		{
			mqinfo = mqd;
				if (mqinfo->mqi_magic != MQI_MAGIC)
				{
					errno = EBADF;
				}
			mqhdr = mqinfo->mqi_hdr;    /* struct pointer */
				mptr = (int8_t *) mqhdr;    /* byte pointer */
				attr = &mqhdr->mqh_attr;
				
				printf("\n\t Setstatusof packet:  Head = %d",mqhdr ->mqh_head);
				if ( (n = pthread_mutex_lock(&mqhdr->mqh_lock)) != 0)
				{
					errno = n;
				}
			
				LockThreadMutex(&OffMsgArrayMutex);
				msghdr = (struct mymsg_hdr *) &mptr[sacindexGLOBAL];
				msghdrGLOBAL->msg_status=MSG_PROCESSED;
				sacindex = msghdr->msg_next;
				printf ("\n sacindex for next packet = %d ", sacindex);
				if (sacindex == 0)
				{
					sacindex = mqhdr->mqh_head ;
						sacindexGLOBAL  =       sacindex;
				}
			printf ("\n DBD 1"); 
				mqhdr->mqh_last = sacindex;
				printf ("\n DBD 2");
				mqhdrGLOBAL  =    mqhdr;
				printf ("\n DBD 3");
				pmsghdr = msghdr;
				printf ("\n mqhdr->mqh_last =%d " , mqhdr->mqh_last);
				pthread_mutex_unlock(&mqhdr->mqh_lock);
				UnLockThreadMutex(&OffMsgArrayMutex);
				if (attr->mq_curmsgs == attr->mq_maxmsg)
					pthread_cond_signal(&mqhdr->mqh_wait);
						
						
		}
		else
		{
			msghdrGLOBAL->msg_status= MSG_NOT_PROCESSED;
				mqhdrGLOBAL->mqh_last = sacindexGLOBAL;
		}
	
		printf("\nExiting from SetStatusofPacket ...\n");
}
