#include<stdio.h>

int main()
{
	int remainder, divisor, dividend;
	printf("\nEnter the Dividend:\t");
	scanf("%d", &dividend);
	printf("\nEnter the Divisor:\t");
	scanf("%d", &divisor);
	remainder = dividend % divisor;
	printf("\nRemainder of the Number:\t%d\n", remainder);
	return 0;
}
