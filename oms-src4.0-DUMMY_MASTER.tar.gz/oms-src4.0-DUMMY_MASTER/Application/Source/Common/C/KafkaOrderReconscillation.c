#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <my_global.h>
#include <unistd.h>
#include <mysql.h>
#include "IPCS.h"
#include "rdkafka.h"
#include "RedisStruct.h"
#include "hiredis.h"

CHAR        Password[100];
MYSQL       *DBCon;
MYSQL       *DBConvDel;

int main(int argc,char *argv[])
{
	logTimestamp(" ENTRY [Kafka Reconsicalltion ]");
	setbuf(stdout  ,NULL);
	setbuf(stderr  ,NULL);
	memset(Password,'\0',100);
	strcpy(Password,argv[1]);
	CHAR 	EnvPass[100];
	memset(EnvPass,'\0',100);
	CHAR  sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry ,'\0',MAX_QUERY_SIZE);
	int	LimitStart;
	int	LimtiTo;
	int	NP_reconcile=0;
	LONG32  ReconsToKafka;
	MYSQL_RES      *Res8;
        MYSQL_ROW       Row8;
	if ((ReconsToKafka = OpenMsgQ(KafkaToNotify)) == ERROR)
	{
		logDebug2("Error in OpenMsgQ (ReconsToKafka)");
		exit(ERROR);
	}
	logDebug2("ReconsToKafka open suceessfully = %d",ReconsToKafka);

	if(getenv("KAFKA_PASSWORD")== NULL)
	{
		logFatal("Error : Environment variables missing : KAFKA_PASSWORD : setting as 0 ");
		strcpy(EnvPass,"");
	}
	else
	{
		strcpy(EnvPass,getenv("KAFKA_PASSWORD"));
	}

	logDebug2("User Entered Password : %s \n ",Password);
	printf("Checking Password \n");
	if(!strcmp(EnvPass,Password)== 0)
	{
		logFatal("Invalid Pass");    
		return 0;
	}

	DBCon=DB_Connect();
	DBConvDel=DB_Connect();

	
	FetchPostnSend(ReconsToKafka,0);	
	fOrderBook(ReconsToKafka);
	FetchPostnSend(ReconsToKafka,2);
}

void fOrderBook(ReconsToKafka){
	struct ORDER_RESPONSE Ord_Res;
	memset(&Ord_Res,'\0',sizeof(struct ORDER_RESPONSE));
	CHAR sCount [DOUBLE_MAX_QUERY_SIZE];
	CHAR sQuery [DOUBLE_MAX_QUERY_SIZE];
	CHAR sMaxCount [DOUBLE_MAX_QUERY_SIZE];
	memset(sQuery,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sCount,'\0',DOUBLE_MAX_QUERY_SIZE);

	LONG32          iMsgCode;
	MYSQL_RES       *Res;
	MYSQL_RES       *Res1;
	MYSQL_RES       *Res2;
	MYSQL_ROW       Row;	
	MYSQL_ROW       Row1;	
	MYSQL_ROW       Row2;
	LONG32        	iNoOfRec;

	sprintf(sMaxCount,"select PARAM_VALUE from SYS_PARAMETERS where PARAM_NAME = 'BULK_COUNT';");
	printf("MaxCout Query = %s \n ",sMaxCount);

	if(mysql_query(DBCon,sMaxCount) != SUCCESS)
	{
		logSqlFatal("Error in sMaxCount.");
		sql_Error(DBCon);
		return FALSE;
	}

	Res2 = mysql_store_result(DBCon);
	Row2 = mysql_fetch_row(Res2);
	int maxcount = atoi(Row2[0]);
	logDebug2(" MAX COUNT : %d :",maxcount);

	logDebug2("******************************************************************************************************");
	logDebug2("*************************** [ Executing Reconsciallation in Now ] ************************************");
	logDebug2("******************************************************************************************************");

	//sprintf(sCount,"SELECT COUNT(1) AS ORD_COUNT FROM  ( SELECT `EQ_CLIENT_ID` AS `CLIENT_ID`  FROM  (SELECT MAX(EQ_SERIAL_NO) AS SER, EQ_ORDER_NO AS ORD_NO, EQ_LEG_NO AS LEG_NO FROM EQ_ORDERS C WHERE `C`.`EQ_CLIENT_ID` LIKE   \'%%\' AND C.EQ_EXCH_ID LIKE  \'%%\' AND C.EQ_SEGMENT LIKE  \'%%\' AND C.EQ_PRODUCT_ID LIKE   \'%%\' AND `C`.`EQ_PRODUCT_ID` <> 'B' AND C.EQ_SOURCE_FLG LIKE  \'%%\' AND C.EQ_SYMBOL LIKE  \'%%\' AND C.EQ_INSTRUMENT_NAME LIKE  \'%%\' AND C.EQ_ENTITY_ID LIKE  \'%%\' AND 1 = 1 AND `C`.`EQ_MKT_TYPE` <> 'SP' AND `C`.`EQ_ORD_STATUS` <> 'B' GROUP BY EQ_ORDER_NO, EQ_LEG_NO) AS X, `EQ_ORDERS` `A`  WHERE `A`.`EQ_SERIAL_NO` = X.SER AND A.EQ_ORDER_NO = X.ORD_NO AND A.EQ_LEG_NO = X.LEG_NO UNION ALL (SELECT  `DO`.`DRV_CLIENT_ID` AS `CLIENT_ID`  FROM (SELECT MAX(C.DRV_SERIAL_NO) AS SER, C.DRV_ORDER_NO AS ORD_NO, C.DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE  `C`.`DRV_CLIENT_ID` LIKE   \'%%\' AND `C`.DRV_EXCH_ID LIKE  \'%%\' AND `C`.DRV_SEGMENT LIKE  \'%%\' AND `C`.DRV_PRODUCT_ID LIKE   \'%%\' AND `C`.DRV_PRODUCT_ID <> 'B' AND `C`.DRV_SOURCE_FLG LIKE  \'%%\' AND `C`.DRV_OPTION_TYPE LIKE   \'%%\' AND `C`.DRV_SYMBOL LIKE  \'%%\' AND `C`.DRV_INSTRUMENT_NAME LIKE  \'%%\'  AND `C`.DRV_ENTITY_ID LIKE  \'%%\' AND 1 = 1 AND `C`.`DRV_CF_FLAG` <> - 1 AND `C`.`DRV_MKT_TYPE` <> 'SP' AND `C`.`DRV_STATUS` <> 'B' GROUP BY DRV_ORDER_NO, DRV_LEG_NO) AS X, `DRV_ORDERS` `DO` WHERE `DO`.`DRV_SERIAL_NO` = X.SER AND DO.DRV_ORDER_NO = X.ORD_NO  AND DO.DRV_LEG_NO = X.LEG_NO) UNION ALL (SELECT  `COM`.`COMM_CLIENT_ID` AS `CLIENT_ID`  FROM (SELECT MAX(C.COMM_SERIAL_NO) AS SER, C.COMM_ORDER_NO AS ORD_NO, C.COMM_LEG_NO AS LEG_NO FROM COMM_ORDERS C WHERE  `C`.`COMM_CLIENT_ID` LIKE   \'%%\' AND `C`.COMM_EXCH_ID LIKE  \'%%\' AND `C`.COMM_SEGMENT LIKE  \'%%\' AND `C`.COMM_PRODUCT_ID LIKE   \'%%\' AND `C`.COMM_PRODUCT_ID <> 'B' AND `C`.COMM_OPTION_TYPE LIKE   \'%%\' AND `C`.COMM_SOURCE_FLG LIKE  \'%%\' AND `C`.COMM_SYMBOL LIKE  \'%%\' AND `C`.COMM_INSTRUMENT_NAME LIKE  \'%%\' AND `C`.COMM_ENTITY_ID LIKE  \'%%\' AND 1 = 1 AND `C`.`COMM_CF_FLAG` <> - 1 AND `C`.`COMM_MKT_TYPE` <> 'SP' AND `C`.`COMM_STATUS` <> 'B' GROUP BY COMM_ORDER_NO, COMM_LEG_NO) AS X, `COMM_ORDERS` `COM` WHERE `COM`.`COMM_SERIAL_NO` = X.SER AND COM.COMM_ORDER_NO = X.ORD_NO  AND COM.COMM_LEG_NO = X.LEG_NO)) AS orderbook;");

	sprintf(sCount,"SELECT SUM(CNT) TOT_CNT FROM (SELECT COUNT(1) CNT FROM EQ_ORDERS WHERE EQ_ORD_STATUS <> 'B' UNION SELECT COUNT(1) DRV_CNT FROM DRV_ORDERS WHERE DRV_CF_FLAG <> -1 AND DRV_MKT_TYPE <> 'SP' AND DRV_STATUS <> 'B' UNION SELECT COUNT(1) COMM_CNT FROM COMM_ORDERS WHERE COMM_CF_FLAG <> -1 AND COMM_MKT_TYPE <> 'SP' AND COMM_STATUS <> 'B') X;");	

	printf("OrderBookQry Count = %s \n ",sCount);

	if(mysql_query(DBCon,sCount) != SUCCESS)
	{
		logSqlFatal("Error in sOrdBkQry Count.");
		sql_Error(DBCon);
		return FALSE;
	}

	Res1 = mysql_store_result(DBCon);
	Row1 = mysql_fetch_row(Res1);
	int  count = atoi(Row1[0]);
	maxcount = count;
	logDebug2(" Order Book Count : %d :",count);
	logDebug2(" Order Book max Count : %d :",maxcount);

	int i =0;
	for(i = 0; i <= count+maxcount; i = i+ maxcount){
		logDebug2(" StartRow : %d :",i);
		logDebug2(" EndRow : %d :",maxcount);


		sprintf(sQuery,"SELECT     CLIENT_ID,     ORDER_DATE_TIME,     LAST_UPDATED_TIME,     EXCH_ORDER_DATE_TIME,     JULIDATE(STR_TO_DATE(ORDER_DATE_TIME, \'%%Y-%%m-%%d %%T\')) AS JULI_DATE_TIME,     JULIDATE(STR_TO_DATE(LAST_UPDATED_TIME, \'%%Y-%%m-%%d %%T\')) AS JULI_LUT,     ORDER_NUMBER,     EXCH,     LAST_TRADE_QTY,     TRADED_PRICE,     BUY_SELL,     SEGMENT,     INSTRUMENT,     SYMBOL,     LEG_NO,     PRODUCT,     TradeNum,     MsgCode,     QUANTITY,     REMAINING_QUANTITY,     PRICE,     TRG_PRICE,     ORDER_TYPE,     REM_QTY_TOT_QTY,     DISCLOSE_QTY,     SERIALNO,     TRADEDQTY,     SEM_SECURITY_ID,     ORDER_VALIDITY,     SEM_NSE_REGULAR_LOT,     TAKE_PROFIT_TRAIL_GAP,     ADV_GROUP_REF_NO,     ALGO_ORD_NO,     DQQTYREM,     EXCHORDERNO,     REASON_DESCRIPTION,     GROUP_ID,     PRO_CLIENT,     ROUND(SL_ABSTICK_VALUE, 4) AS SL_ABSTICK_VALUE,     ROUND(PR_ABSTICK_VALUE, 4) AS PR_ABSTICK_VALUE,     ORDER_OFFON,     CHILD_LEG_UNQ_ID,     PAN_NO,     PARTICIPANT_TYPE,     MKT_PROTECT_FLG,     MKT_PROTECT_VAL,     SETTLOR,     GTC_FLG,     ENCASH_FLG,     MKT_TYPE,     STRIKE_PRICE,     EXPIRY_DATE,     OPT_TYPE,     CUSTOM_SYMBOL,     ISIN_CODE,     SERIES,     TradeNo,     ERROR_CODE,     IFNULL(SOURCE, 'NA') AS SOURCE,     GTDdate,     PLACED_BY,     ORD_VAL,     SOURCE_NAME,     UCC_ID,     REF_LTP,     TICK_SIZE,     ALGO_ID,     STRATEGY_ID,     PLACED_BY_TYPE,     REMARKS1,     REMARKS2,     EXPIRY_FLAG,     REMARKS,     USER_ID,     ENTITY_ID FROM     ((SELECT         `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,             `A`.`EQ_ACC_CODE` AS `UCC_ID`,             DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, \'%%Y-%%m-%%d %%T\') AS `ORDER_DATE_TIME`,             DATE_FORMAT(`A`.`EQ_LUT`, \'%%Y-%%m-%%d %%T\') AS `LAST_UPDATED_TIME`,             DATE_FORMAT(`A`.`EQ_EXCH_ORDER_TIME`, \'%%Y-%%m-%%d %%T\') AS `EXCH_ORDER_DATE_TIME`,             `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,             `A`.`EQ_EXCH_ID` AS `EXCH`,             `A`.`EQ_LAST_TRADE_QTY` AS `LAST_TRADE_QTY`, `A`.`EQ_TRD_TRADE_PRICE` AS `TRADED_PRICE` ,           `A`.`EQ_BUY_SELL_IND` AS `BUY_SELL`,             'E' AS `SEGMENT`,             `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,             `A`.`EQ_SYMBOL` AS `SYMBOL`,             `A`.`EQ_LEG_NO` AS `LEG_NO`,             `A`.`EQ_PRODUCT_ID` AS `PRODUCT`,             `A`.`EQ_TRD_EXCH_TRADE_NO` AS `TradeNum`,             `A`.`EQ_MSG_CODE` AS `MsgCode`,             `A`.`EQ_TOTAL_QTY` AS `QUANTITY`,             `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,             (CASE `A`.`EQ_SEGMENT`                 WHEN                     'C'                 THEN                     REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`                         WHEN '1' THEN 'MKT'                         WHEN '3' THEN 'MKT'                         ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)                     END), 4), ',', '')                 ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`                     WHEN '1' THEN 'MKT'                     WHEN '3' THEN 'MKT'                     ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)                 END), 2), ',', '')             END) AS `PRICE`,             CASE `A`.`EQ_SEGMENT`                 WHEN                     'C'                 THEN                     ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`                         WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)                         WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)                         ELSE 0                     END), 0), 2)                 ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`                     WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)                     WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)                     ELSE 0                 END), 0), 2)             END AS `TRG_PRICE`,             `A`.`EQ_ORDER_TYPE` `ORDER_TYPE`,             CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,             `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,             `A`.`EQ_SERIAL_NO` AS `SERIALNO`,             `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,             `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,             `A`.`EQ_VALIDITY` AS `ORDER_VALIDITY`,             `A`.`EQ_LOT_SIZE` AS `SEM_NSE_REGULAR_LOT`,             0 AS `TAKE_PROFIT_TRAIL_GAP`,             `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,             `A`.`EQ_ALGO_ORDER_NO` AS `ALGO_ORD_NO`,             `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,             `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,             `A`.`EQ_GROUP_ID` AS `GROUP_ID`,             `A`.`EQ_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`,             `A`.`EQ_PRO_CLIENT` AS `PRO_CLIENT`,             `A`.`EQ_SL_ABSTICK_VALUE` AS `SL_ABSTICK_VALUE`,             `A`.`EQ_PR_ABSTICK_VALUE` AS `PR_ABSTICK_VALUE`,             `A`.`EQ_ORDER_OFFON` AS `ORDER_OFFON`,             `A`.`EQ_CHILD_LEG_UNQ_ID` AS `CHILD_LEG_UNQ_ID`,             `A`.`EQ_PAN_NO` AS `PAN_NO`,             `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,             `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,             `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,             `A`.`EQ_SETTLOR` AS `SETTLOR`,             `A`.`EQ_GTC_FLG` AS `GTC_FLG`,             `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,             `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,             `A`.`EQ_STRIKE_PRICE` AS `STRIKE_PRICE`,             DATE_FORMAT(`A`.`EQ_EXPIRY_DATE`, \'%%Y-%%m-%%d\') AS `EXPIRY_DATE`,             IFNULL(IF(`A`.`EQ_OPTION_TYPE`, '', 'XX'), 'XX') AS `OPT_TYPE`,             `A`.`EQ_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,             `A`.`EQ_ISIN_CODE` AS `ISIN_CODE`,             `A`.`EQ_SERIES` AS `SERIES`,             `A`.`EQ_TRD_SERIAL_NO` AS `TradeNo`,             `A`.`EQ_ERROR_CODE` AS `ERROR_CODE`,             (CASE `A`.`EQ_SOURCE_FLG`                 WHEN 'M' THEN 'MOBILE'                 WHEN 'W' THEN 'WEB'                 WHEN 'A' THEN 'ADMIN'                 WHEN 'R' THEN 'RAPIDRUPEE'                 WHEN 'S' THEN 'RUPEESMART'                 WHEN 'F' THEN 'FALCON'                 WHEN 'H' THEN 'HELPDESK'                 WHEN 'E' THEN 'EXCHANGE'                 WHEN 'I' THEN 'ITS'                 WHEN 'B' THEN 'SYSTEM'             END) AS `SOURCE`,             DATE_FORMAT(A.EQ_GOOD_TILL_DATE, \'%%Y-%%m-%%d\') AS GTDdate,             `A`.`EQ_ENTITY_ID` AS `PLACED_BY`,             (A.EQ_ORDER_PRICE * A.EQ_TOTAL_QTY) AS ORD_VAL,   (CASE `A`.`EQ_SOURCE_FLG`                 WHEN 'I' THEN '  IOS  '                 WHEN 'N' THEN '  ANDROID  '                 WHEN 'W' THEN '  WEB  '                 WHEN 'A' THEN '  ADMIN  '                 WHEN 'R' THEN '  SRC_OWS  '                 WHEN 'S' THEN '  SRC_OWS  '                 WHEN 'O' THEN '  SRC_OWS  '                 WHEN 'H' THEN '  HELPDESK  '                 WHEN 'B' THEN '  SYSTEM  '                 WHEN 'M' THEN '  MOB_WEB  '                 ELSE '  OTHERS  '             END) AS `SOURCE_NAME`,             `A`.`EQ_REF_LTP` AS `REF_LTP`,             (A.EQ_TICK_SIZE) AS TICK_SIZE,             A.EQ_ALGO_ID AS ALGO_ID,             (CASE A.EQ_STRATEGY_ID                 WHEN '101' THEN 'INTRADAY_SQR_OFF'                 WHEN '102' THEN 'CO_SQ_OFF'                 WHEN '103' THEN 'BO_SQ_OFF'                 WHEN '104' THEN 'OFF_ORD_PUMP'                 WHEN '105' THEN 'SIP_ORD_PUMP'                 WHEN '106' THEN 'MTM_SQR_OFF'                 WHEN '107' THEN 'CKT_SQR_OFF'                 ELSE 'NA'             END) AS STRATEGY_ID,             (CASE A.EQ_USER_TYPE                 WHEN 'S' THEN 'ADMIN'                 WHEN 'A' THEN 'SYSTEM'                 WHEN 'C' THEN 'CUSTOMER'                 WHEN 'D' THEN 'DEALER'                 ELSE 'SYSTEM'             END) AS PLACED_BY_TYPE,             A.EQ_REMARKS1 AS REMARKS1,             A.EQ_REMARKS2 AS REMARKS2,             A.EQ_EXPIRY_FLAG AS EXPIRY_FLAG,             A.EQ_REMARKS AS REMARKS,   A.EQ_USER_ID AS USER_ID,             A.EQ_ENTITY_ID AS ENTITY_ID FROM `EQ_ORDERS` `A` WHERE `A`.`EQ_CF_FLAG` <> -1 AND `A`.`EQ_MKT_TYPE` <> 'SP' AND `A`.`EQ_ORD_STATUS` <> 'B'  ORDER BY `A`.`EQ_LUT` ASC LIMIT %d,%d  )   UNION ALL (SELECT         `DO`.`DRV_CLIENT_ID` AS `CLIENT_ID`,             `DO`.`DRV_ACC_CODE` AS `UCC_ID`,             DATE_FORMAT(`DO`.`DRV_INTERNAL_ENTRY_DATE`, \'%%Y-%%m-%%d %%T\') AS `ORDER_DATE_TIME`,             DATE_FORMAT(`DO`.`DRV_LUT`, \'%%Y-%%m-%%d %%T\') AS `LAST_UPDATED_TIME`,             DATE_FORMAT(`DO`.`DRV_EXCH_ORDER_TIME`, \'%%Y-%%m-%%d %%T\') AS `EXCH_ORDER_DATE_TIME`,             `DO`.`DRV_ORDER_NO` AS `ORDER_NUMBER`,             `DO`.`DRV_EXCH_ID` AS `EXCH`,             `DO`.`DRV_TRD_TRADE_QTY` AS `LAST_TRADE_QTY`, `DO`.`DRV_TRD_TRADE_PRICE` AS `TRADED_PRICE`,            `DO`.`DRV_BUY_SELL_IND` AS `BUY_SELL`,             `DO`.`DRV_SEGMENT` AS `SEGMENT`,             `DO`.`DRV_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`,             `DO`.`DRV_SYMBOL` AS `SYMBOL`,             `DO`.`DRV_LEG_NO` AS `LEG_NO`,             `DO`.`DRV_PRODUCT_ID` AS `PRODUCT`,             `DO`.`DRV_TRD_EXCH_TRADE_NO` AS `TradeNum`,             `DO`.`DRV_MSG_CODE` AS `MsgCode`,             `DO`.`DRV_TOTAL_QTY` AS `QUANTITY`,             `DO`.`DRV_REM_QTY` AS `REM QTY`,             CASE `DO`.`DRV_SEGMENT`                 WHEN                     'C'                 THEN                     REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE`                         WHEN '1' THEN 'MKT'                         WHEN '3' THEN 'MKT'                         ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0)                     END), 4), ',', '')                 ELSE REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE`                     WHEN '1' THEN 'MKT'                     WHEN '3' THEN 'MKT'                     ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0)                 END), 2), ',', '')             END AS `PRICE`,             CASE `DO`.`DRV_SEGMENT`                 WHEN                     'C'                 THEN                     ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE`                         WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)                         WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)                         ELSE 0                     END), 0), 4)                 ELSE ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE`                     WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)                     WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)                     ELSE 0                 END), 0), 2)             END AS TRG_PRICE,             `DO`.`DRV_ORDER_TYPE` AS `ORDER_TYPE`,             CONCAT(`DO`.`DRV_REM_QTY`, '/', `DO`.`DRV_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,             `DO`.`DRV_DISC_QTY` AS `DISCLOSE_QTY`,             `DO`.`DRV_SERIAL_NO` AS `SERIALNO`,             `DO`.`DRV_TOTAL_TRADED_QTY` AS `TRADEDQTY`,             `DO`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,             `DO`.`DRV_VALIDITY` AS `ORDER_VALIDITY`,             `DO`.`DRV_LOT_SIZE` AS `SM_LOT_SIZE`,             0 AS `TAKE_PROFIT_TRAIL_GAP`,             `DO`.`DRV_OMS_ALGO_ORD_NO` AS `ADV_GROUP_REF_NO`,             `DO`.`DRV_OMS_ALGO_ORD_NO` AS `ALGO_ORD_NO`,             `DO`.`DRV_DISC_REM_QTY` AS `DQQTYREM`,             `DO`.`DRV_EXCH_ORDER_NO` AS `EXCHORDERNO`,             `DO`.`DRV_GROUP_ID` AS `GROUP_ID`,             `DO`.`DRV_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`,             `DO`.`DRV_PRO_CLIENT` AS `PRO_CLIENT`,             `DO`.`DRV_SL_ABSTICK_VALUE` AS `SL_ABSTICK_VALUE`,             `DO`.`DRV_PR_ABSTICK_VALUE` AS `PR_ABSTICK_VALUE`,             `DO`.`DRV_ORDER_OFFON` AS `ORDER_OFFON`,             `DO`.`DRV_CHILD_LEG_UNQ_ID` AS `CHILD_LEG_UNQ_ID`,             `DO`.`DRV_PAN_NO` AS `PAN_NO`,             `DO`.`DRV_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,             `DO`.`DRV_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,             `DO`.`DRV_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,             `DO`.`DRV_SETTLOR` AS `SETTLOR`,             `DO`.`DRV_GTC_FLG` AS `GTC_FLG`,             `DO`.`DRV_ENCASH_FLG` AS `ENCASH_FLG`,             `DO`.`DRV_MKT_TYPE` AS `MKT_TYPE`,             `DO`.`DRV_STRIKE_PRICE` AS `STRIKE_PRICE`,             DATE_FORMAT(`DO`.`DRV_EXPIRY_DATE`, \'%%Y-%%m-%%d\') AS `EXPIRY_DATE`,             IFNULL(IF(`DO`.`DRV_OPTION_TYPE` = '', 'XX', `DO`.`DRV_OPTION_TYPE`), 'XX') AS `OPT_TYPE`,             `DO`.`DRV_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,             'NA' AS `ISIN_CODE`,             'XX' AS `SERIES`,             `DO`.`DRV_EXCH_INSTRUMENT_TYPE` AS TradeNo,             `DO`.`DRV_ERROR_CODE` AS `ERROR_CODE`,             (CASE `DO`.`DRV_SOURCE_FLG`                 WHEN 'M' THEN 'MOBILE'                 WHEN 'W' THEN 'WEB'                 WHEN 'A' THEN 'ADMIN'                 WHEN 'R' THEN 'RAPIDRUPEE'                 WHEN 'S' THEN 'RUPEESMART'                 WHEN 'F' THEN 'FALCON'                 WHEN 'H' THEN 'HELPDESK'                 WHEN 'E' THEN 'EXCHANGE'                 WHEN 'I' THEN 'ITS'                 WHEN 'B' THEN 'SYSTEM'             END) AS `SOURCE`,             DATE_FORMAT(DO.DRV_GOOD_TILL_DATE, \'%%Y-%%m-%%d\') AS GTDdate,             `DO`.`DRV_ENTITY_ID` AS `PLACED_BY`,             (CASE                 WHEN                     `DO`.DRV_SEGMENT = 'C'                 THEN                     CASE                         WHEN `DO`.DRV_CROSS_CUR_FLAG = 'Y' THEN ((`DO`.DRV_ORDER_PRICE * `DO`.DRV_TOTAL_QTY) * 1000 * `DO`.DRV_RBI_REFERENCE_RATE)                         ELSE ((`DO`.DRV_ORDER_PRICE * `DO`.DRV_TOTAL_QTY) * 1000)                     END                 ELSE (`DO`.DRV_ORDER_PRICE * `DO`.DRV_TOTAL_QTY)             END) AS ORD_VAL,             (CASE `DO`.`DRV_SOURCE_FLG`                 WHEN 'I' THEN '  IOS  '                 WHEN 'N' THEN '  ANDROID  '                 WHEN 'W' THEN '  WEB  '                 WHEN 'A' THEN '  ADMIN  '                 WHEN 'R' THEN '  SRC_OWS  '                 WHEN 'S' THEN '  SRC_OWS  '                 WHEN 'O' THEN '  SRC_OWS  '                 WHEN 'H' THEN '  HELPDESK  '                 WHEN 'B' THEN '  SYSTEM  '                 WHEN 'M' THEN '  MOB_WEB  '                 ELSE '  OTHERS  '             END) AS `SOURCE_NAME`,             `DO`.`DRV_REF_LTP` AS REF_LTP,             (`DO`.`DRV_TICK_SIZE`) AS TICK_SIZE,             `DO`.`DRV_ALGO_ID` AS ALGO_ID,             (CASE `DO`.`DRV_STRATEGY_ID`                 WHEN '101' THEN 'INTRADAY_SQR_OFF'                 WHEN '102' THEN 'CO_SQ_OFF'                 WHEN '103' THEN 'BO_SQ_OFF'                 WHEN '104' THEN 'OFF_ORD_PUMP'                 WHEN '105' THEN 'SIP_ORD_PUMP'                 WHEN '106' THEN 'MTM_SQR_OFF'                 ELSE 'NA'             END) AS STRATEGY_ID,             (CASE DO.DRV_USER_TYPE                 WHEN 'S' THEN 'ADMIN'                 WHEN 'A' THEN 'SYSTEM'                 WHEN 'C' THEN 'CUSTOMER'                 WHEN 'D' THEN 'DEALER'                 ELSE 'SYSTEM'             END) AS PLACED_BY_TYPE,             DO.DRV_REMARKS1 AS REMARKS1,             DO.DRV_REMARKS2 AS REMARKS2,             `DO`.`DRV_EXPIRY_FLAG` AS `EXPIRY_FLAG`,             `DO`.`DRV_REMARKS` AS `REMARKS`,             `DO`.`DRV_USER_ID` AS `USER_ID`,             `DO`.`DRV_ENTITY_ID` AS `ENTITY_ID`     FROM `DRV_ORDERS` `DO` WHERE `DO`.`DRV_CF_FLAG` <> - 1 AND `DO`.`DRV_MKT_TYPE` <> 'SP' AND `DO`.`DRV_STATUS` <> 'B' ORDER BY `DO`.`DRV_LUT` ASC LIMIT %d,%d)    UNION ALL (SELECT         `COM`.`COMM_CLIENT_ID` AS `CLIENT_ID`,             `COM`.`COMM_ACC_CODE` AS `UCC_ID`,             DATE_FORMAT(`COM`.`COMM_INTERNAL_ENTRY_DATE`, \'%%Y-%%m-%%d %%T\') AS `ORDER_DATE_TIME`,             DATE_FORMAT(`COM`.`COMM_LUT`, \'%%Y-%%m-%%d %%T\') AS `LAST_UPDATED_TIME`,             DATE_FORMAT(`COM`.`COMM_EXCH_ORDER_TIME`, \'%%Y-%%m-%%d %%T\') AS `EXCH_ORDER_DATE_TIME`,             `COM`.`COMM_ORDER_NO` AS `ORDER_NUMBER`,             `COM`.`COMM_EXCH_ID` AS `EXCH`,             `COM`.`COMM_TRD_TRADE_QTY` AS `LAST_TRADE_QTY`,    `COM`.`COMM_TRD_TRADE_PRICE` AS `TRADED_PRICE`,          `COM`.`COMM_BUY_SELL_IND` AS `BUY_SELL`,             `COM`.`COMM_SEGMENT` AS `SEGMENT`,             `COM`.`COMM_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`,             `COM`.`COMM_SYMBOL` AS `SYMBOL`,             `COM`.`COMM_LEG_NO` AS `LEG_NO`,             `COM`.`COMM_PRODUCT_ID` AS `PRODUCT`,             `COM`.`COMM_TRD_EXCH_TRADE_NO` AS `TradeNum`,             `COM`.`COMM_MSG_CODE` AS `MsgCode`,             `COM`.`COMM_TOTAL_QTY` AS `QUANTITY`,             `COM`.`COMM_REM_QTY` AS `REM QTY`,             CASE `COM`.`COMM_SEGMENT`                 WHEN                     'C'                 THEN                     REPLACE(FORMAT((CASE `COM`.`COMM_ORDER_TYPE`                         WHEN '1' THEN 'MKT'                         WHEN '3' THEN 'MKT'                         ELSE IFNULL(`COM`.`COMM_ORDER_PRICE`, 0)                     END), 4), ',', '')                 ELSE REPLACE(FORMAT((CASE `COM`.`COMM_ORDER_TYPE`                     WHEN '1' THEN 'MKT'                     WHEN '3' THEN 'MKT'                     ELSE IFNULL(`COM`.`COMM_ORDER_PRICE`, 0)                 END), 2), ',', '')             END AS `PRICE`,             CASE `COM`.`COMM_SEGMENT`                 WHEN                     'C'                 THEN                     ROUND(COALESCE((CASE `COM`.`COMM_ORDER_TYPE`                         WHEN '3' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0)                         WHEN '4' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0)                         ELSE 0                     END), 0), 4)                 ELSE ROUND(COALESCE((CASE `COM`.`COMM_ORDER_TYPE`                     WHEN '3' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0)                     WHEN '4' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0)                     ELSE 0                 END), 0), 2)             END AS TRG_PRICE,             `COM`.`COMM_ORDER_TYPE` AS `ORDER_TYPE`,             CONCAT(`COM`.`COMM_REM_QTY`, '/', `COM`.`COMM_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,             `COM`.`COMM_DISC_QTY` AS `DISCLOSE_QTY`,             `COM`.`COMM_SERIAL_NO` AS `SERIALNO`,             `COM`.`COMM_TOTAL_TRADED_QTY` AS `TRADEDQTY`,             `COM`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,             `COM`.`COMM_VALIDITY` AS `ORDER_VALIDITY`,             `COM`.`COMM_LOT_SIZE` AS `SM_LOT_SIZE`,             0 AS `TAKE_PROFIT_TRAIL_GAP`,             `COM`.`COMM_OMS_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,             `COM`.`COMM_OMS_ALGO_ORDER_NO` AS `ALGO_ORD_NO`,             `COM`.`COMM_DISC_REM_QTY` AS `DQQTYREM`,             `COM`.`COMM_EXCH_ORDER_NO` AS `EXCHORDERNO`,             `COM`.`COMM_GROUP_ID` AS `GROUP_ID`,             `COM`.`COMM_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`,             `COM`.`COMM_PRO_CLIENT` AS `PRO_CLIENT`,             `COM`.`COMM_SL_ABSTICK_VALUE` AS `SL_ABSTICK_VALUE`,             `COM`.`COMM_PR_ABSTICK_VALUE` AS `PR_ABSTICK_VALUE`,             `COM`.`COMM_ORDER_OFFON` AS `ORDER_OFFON`,             `COM`.`COMM_CHILD_LEG_UNQ_ID` AS `CHILD_LEG_UNQ_ID`,             `COM`.`COMM_PAN_NO` AS `PAN_NO`,             `COM`.`COMM_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,             `COM`.`COM_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,             `COM`.`COMM_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,             `COM`.`COMM_SETTLOR` AS `SETTLOR`,             `COM`.`COMM_GTC_FLG` AS `GTC_FLG`,             `COM`.`COMM_ENCASH_FLG` AS `ENCASH_FLG`,             `COM`.`COMM_MKT_TYPE` AS `MKT_TYPE`,             `COM`.`COMM_STRIKE_PRICE` AS `STRIKE_PRICE`,             DATE_FORMAT(`COM`.`COMM_EXPIRY_DATE`, \'%%Y-%%m-%%d\') AS `EXPIRY_DATE`,             IFNULL(IF(`COM`.`COMM_OPTION_TYPE`, '', 'XX'), 'XX') AS `OPT_TYPE`,             `COM`.`COMM_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,             'NA' AS `ISIN_CODE`,             'XX' AS `SERIES`,             `COM`.`COMM_TRD_SERIAL_NO` AS TradeNo,             `COM`.`COMM_ERROR_CODE` AS `ERROR_CODE`,             (CASE `COM`.`COMM_SOURCE_FLG`                 WHEN 'M' THEN 'MOBILE'                 WHEN 'W' THEN 'WEB'                 WHEN 'A' THEN 'ADMIN'                 WHEN 'R' THEN 'RAPIDRUPEE'                 WHEN 'S' THEN 'RUPEESMART'                 WHEN 'F' THEN 'FALCON'                 WHEN 'H' THEN 'HELPDESK'                 WHEN 'E' THEN 'EXCHANGE'                 WHEN 'I' THEN 'ITS'                 WHEN 'B' THEN 'SYSTEM'             END) AS `SOURCE`,             DATE_FORMAT(COM.COMM_GOOD_TILL_DATE, \'%%Y-%%m-%%d\') AS GTDdate,             `COM`.`COMM_ENTITY_ID` AS `PLACED_BY`,             ((COM.COMM_ORDER_PRICE * COM.COMM_TOTAL_QTY) * COMM_MULTIPLIER) AS ORD_VAL,             (CASE `COM`.`COMM_SOURCE_FLG`                 WHEN 'I' THEN '  IOS  '                 WHEN 'N' THEN '  ANDROID  '                 WHEN 'W' THEN '  WEB  '                 WHEN 'A' THEN '  ADMIN  '                 WHEN 'R' THEN '  SRC_OWS  '                 WHEN 'S' THEN '  SRC_OWS  '                 WHEN 'O' THEN '  SRC_OWS  '                 WHEN 'H' THEN '  HELPDESK  '                 WHEN 'B' THEN '  SYSTEM  '                 WHEN 'M' THEN '  MOB_WEB  '                 ELSE 'OTHERS'             END) AS `SOURCE_NAME`,             `COM`.`COMM_REF_LTP` AS REF_LTP,             COM.COMM_TICK_SIZE AS TICK_SIZE,             COM.COMM_ALGO_ID AS ALGO_ID,             (CASE COM.COMM_STRATEGY_ID                 WHEN '101' THEN 'INTRADAY_SQR_OFF'                 WHEN '102' THEN 'CO_SQ_OFF'                 WHEN '103' THEN 'BO_SQ_OFF'                 WHEN '104' THEN 'OFF_ORD_PUMP'                 WHEN '105' THEN 'SIP_ORD_PUMP'                 WHEN '106' THEN 'MTM_SQR_OFF'                 ELSE 'NA'             END) AS STRATEGY_ID,             (CASE COM.COMM_USER_TYPE                 WHEN 'S' THEN 'ADMIN'                 WHEN 'A' THEN 'SYSTEM'                 WHEN 'C' THEN 'CUSTOMER'                 WHEN 'D' THEN 'DEALER'                 ELSE 'SYSTEM'             END) AS PLACED_BY_TYPE,             COM.COMM_REMARKS1 AS REMARKS1,             COM.COMM_REMARKS2 AS REMARKS2,             `COM`.`COMM_EXPIRY_FLAG` AS `EXPIRY_FLAG`,             `COM`.`COMM_REMARKS` AS `REMARKS`,             `COM`.`COMM_USER_ID` AS `USER_ID`,             `COM`.`COMM_ENTITY_ID` AS `ENTITY_ID` FROM `COMM_ORDERS` `COM` WHERE `COM`.`COMM_CF_FLAG` <> - 1 AND `COM`.`COMM_MKT_TYPE` <> 'SP' AND `COM`.`COMM_STATUS` <> 'B' ORDER BY `COM`.`COMM_LUT` ASC LIMIT %d, %d )) orderbook;",i,maxcount,i,maxcount,i,maxcount);

		printf("OrderBookQry = %s \n ",sQuery);

		if(mysql_query(DBCon,sQuery) != SUCCESS)
		{
			logSqlFatal("Error in sOrdBkQry.");
			sql_Error(DBCon);
			return FALSE;
		}

		Res = mysql_store_result(DBCon);
		iNoOfRec= mysql_num_rows(Res);
		logDebug2("No of records >>> %d ", iNoOfRec);
		
		if(iNoOfRec != 0)
		{
			int j = 0;
			while((Row = mysql_fetch_row(Res)))
			{
				memset(&Ord_Res,'\0',sizeof(struct ORDER_RESPONSE));	
				Ord_Res.IntRespHeader.iSeqNo                 =0;
				j++;
				logDebug2("Sequence Number >> %d", Ord_Res.IntRespHeader.iSeqNo);
				Ord_Res.IntRespHeader.iMsgLength             =sizeof( struct ORDER_RESPONSE);
				Ord_Res.IntRespHeader.iMsgCode               =atoi(Row[17]);
				strncpy(Ord_Res.IntRespHeader.sExcgId,Row[7],EXCHANGE_LEN);
				Ord_Res.IntRespHeader.iErrorId               =0;
				Ord_Res.IntRespHeader.iUserId                =atoi(Row[73]);
				Ord_Res.IntRespHeader.cSource                =Row[58][0];
				Ord_Res.IntRespHeader.iTimeStamp             =0;
				Ord_Res.IntRespHeader.cSegment               =Row[11][0];
				strncpy(Ord_Res.sSecurityId, Row[27],SECURITY_ID_LEN);
				strncpy(Ord_Res.sEntityId, Row[74],ENTITY_ID_LEN);
				strncpy(Ord_Res.sClientId, Row[0],CLIENT_ID_LEN);
				strncpy(Ord_Res.sExchOrderID, Row[34],EXCH_ORDER_NO_LEN);
				Ord_Res.cProductId                           =Row[15][0];
				Ord_Res.cBuyOrSell                           =Row[10][0];
				Ord_Res.iOrderType                           =atoi(Row[22]);
				Ord_Res.iOrderValidity                       =atoi(Row[28]);
				Ord_Res.iDiscQty                             =atoi(Row[24]);
				Ord_Res.iDiscQtyRem                          =atoi(Row[33]);
				Ord_Res.iTotalQtyRem                         =atoi(Row[19]);
				Ord_Res.iTotalQty                            =atoi(Row[18]);
				Ord_Res.iLastTradedQty                       =atoi(Row[8]);
				Ord_Res.iTotalTradedQty                      =atoi(Row[26]);
				Ord_Res.iMinFillQty                          =0;
				Ord_Res.fPrice                               =atof(Row[20]);
				Ord_Res.fTriggerPrice                        =atof(Row[21]);
				Ord_Res.fOrderNum                            =atof(Row[6]);
				Ord_Res.iSerialNum                           =atoi(Row[25]);
				strncpy(Ord_Res.sTradeNo ,Row[16],DB_EXCH_TRD_NO_LEN);               ///To BE CHECKED
				Ord_Res.fTradePrice                          =atof(Row[9]);
				Ord_Res.cHandleInst                          ='0';   	             //FILLER CHECK  THESE
				Ord_Res.fAlgoOrderNo                         =atof(Row[32]);
				Ord_Res.iStratergyId                         =atoi(Row[67]);
				Ord_Res.cOffMarketFlg                        =Row[40][0] ;
				Ord_Res.cProCli                              =Row[37][0];
				Ord_Res.cUserType                            =Row[69][0];
				strncpy(Ord_Res.sOrdEntryTime,Row[1],DATE_TIME_LEN);
				strncpy(Ord_Res.sTransacTime,Row[3],DATE_TIME_LEN ) ;
				strncpy(Ord_Res.sRemarks, Row[72],REMARKS_LEN);
				if(strcmp(Row[49],"NL")== 0)
				{
					Ord_Res.iMktType = NORMAL_MARKET;
				}
				else if(strcmp(Row[49],"OL") == 0)
				{
					Ord_Res.iMktType = ODDLOT_MARKET;
				}
				else if(strcmp(Row[49],"SP")== 0)
				{
					Ord_Res.iMktType = SPOT_MARKET;
				}
				else if(strcmp(Row[49],"AU") == 0)
				{
					Ord_Res.iMktType = AUCTION_MARKET;
				}
				else logDebug2("Invalid MktType :%s:",Row[49]);

				strncpy(Ord_Res.sReasonDesc,Row[35],DB_REASON_DESC_LEN);
				strncpy(Ord_Res.sGoodTillDaysDate,Row[59],DB_DATETIME_LEN);
				Ord_Res.iLegValue                            =atoi(Row[14]);
				strncpy(Ord_Res.sTradeNum,Row[56],TRADE_NO_LEN);                     //TO BE CHECKD FILLER
				Ord_Res.cMarkProFlag                         =Row[44][0];
				Ord_Res.fMarkProVal                          =atof(Row[45]) ;
				Ord_Res.cParticipantType                     =Row[43][0];
				strncpy(Ord_Res.sSettlor, Row[46],SETTLOR_LEN);
				Ord_Res.cGTCFlag                             =Row[47][0];
				Ord_Res.cEncashFlag                          =Row[48][0] ;
				strncpy(Ord_Res.sPanID,Row[42],INT_PAN_LEN);
				Ord_Res.iGrpId                               =atoi(Row[36]) ;
				strncpy(Ord_Res.sErrorCode,Row[57],INT_PAN_LEN);
				strncpy(Ord_Res.sSmExpiryFlag, Row[71],DB_EXPIRY_FLAG_LEN);
				logDebug2("Mkt Type :%d:",Ord_Res.iMktType);
				logDebug2("--------------Printing ORDER RESPONSE--------------------");

				logDebug2("Ord_Res.IntRespHeader.iMsgLength   :%d:",Ord_Res.IntRespHeader.iMsgLength);
				logDebug2("Ord_Res.IntRespHeader.iMsgCode     :%d:",Ord_Res.IntRespHeader.iMsgCode);
				logDebug2("Ord_Res.IntRespHeader.sExcgId      :%s:",Ord_Res.IntRespHeader.sExcgId);
				logDebug2("Ord_Res.IntRespHeader.iErrorId     :%d:",Ord_Res.IntRespHeader.iErrorId);
				logDebug2("Ord_Res.IntRespHeader.iUserId      :%llu:",Ord_Res.IntRespHeader.iUserId);
				logDebug2("Ord_Res.IntRespHeader.cSource      :%c:",Ord_Res.IntRespHeader.cSource);
				logDebug2("Ord_Res.IntRespHeader.iTimeStamp   :%d:",Ord_Res.IntRespHeader.iTimeStamp);
				logDebug2("Ord_Res.IntRespHeader.cSegment     :%c:",Ord_Res.IntRespHeader.cSegment);
				logDebug2("Ord_Res.iLegValue                  :%d:",Ord_Res.iLegValue);
				logDebug2("Ord_Res.sSecurityId                :%s:",Ord_Res.sSecurityId);
				logDebug2("Ord_Res.sEntityId                  :%s:",Ord_Res.sEntityId);
				logDebug2("Ord_Res.sClientId                  :%s:",Ord_Res.sClientId);
				logDebug2("Ord_Res.sExchOrderID               :%s:",Ord_Res.sExchOrderID);
				logDebug2("Ord_Res.cProductId                 :%c:",Ord_Res.cProductId);
				logDebug2("Ord_Res.cBuyOrSell                 :%c:",Ord_Res.cBuyOrSell);
				logDebug2("Ord_Res.iOrderType                 :%d:",Ord_Res.iOrderType);
				logDebug2("Ord_Res.iOrderValidity             :%d:",Ord_Res.iOrderValidity);
				logDebug2("Ord_Res.iDiscQty                   :%d:",Ord_Res.iDiscQty);
				logDebug2("Ord_Res.iDiscQtyRem                :%d:",Ord_Res.iDiscQtyRem);
				logDebug2("Ord_Res.iTotalQtyRem               :%d:",Ord_Res.iTotalQtyRem);
				logDebug2("Ord_Res.iTotalQty                  :%d:",Ord_Res.iTotalQty);
				logDebug2("Ord_Res.iLastTradedQty             :%d:",Ord_Res.iLastTradedQty);
				logDebug2("Ord_Res.iTotalTradedQty            :%d:",Ord_Res.iTotalTradedQty);
				logDebug2("Ord_Res.iMinFillQty                :%d:",Ord_Res.iMinFillQty);
				logDebug2("Ord_Res.fPrice                     :%f:",Ord_Res.fPrice);
				logDebug2("Ord_Res.fTriggerPrice              :%f:",Ord_Res.fTriggerPrice);
				logDebug2("Ord_Res.fOrderNum                  :%f:",Ord_Res.fOrderNum);
				logDebug2("Ord_Res.iSerialNum                 :%d:",Ord_Res.iSerialNum);
				logDebug2("Ord_Res.sTradeNo                   :%s:",Ord_Res.sTradeNo);
				logDebug2("Ord_Res.fTradePrice                :%f:",Ord_Res.fTradePrice);
				logDebug2("Ord_Res.cHandleInst                :%c:",Ord_Res.cHandleInst);
				logDebug2("Ord_Res.fAlgoOrderNo               :%f:",Ord_Res.fAlgoOrderNo);
				logDebug2("Ord_Res.iStratergyId               :%d:",Ord_Res.iStratergyId);
				logDebug2("Ord_Res.cOffMarketFlg              :%c:",Ord_Res.cOffMarketFlg);
				logDebug2("Ord_Res.cProCli                    :%c:",Ord_Res.cProCli);
				logDebug2("Ord_Res.cUserType                  :%c:",Ord_Res.cUserType);
				logDebug2("Ord_Res.sOrdEntryTime              :%s:",Ord_Res.sOrdEntryTime);
				logDebug2("Ord_Res.sTransacTime               :%s:",Ord_Res.sTransacTime);
				logDebug2("Ord_Res.sRemarks                   :%s:",Ord_Res.sRemarks);
				logDebug2("Ord_Res.iMktType                   :%d:",Ord_Res.iMktType);
				logDebug2("Ord_Res.sReasDesc                  :%s:",Ord_Res.sReasonDesc);
				logDebug2("Ord_Res.cMarkProFlag               :%c:",Ord_Res.cMarkProFlag);
				logDebug2("Ord_Res.fMarkProVal                :%f:",Ord_Res.fMarkProVal);
				logDebug2("Ord_Res.cParticipantType           :%c:",Ord_Res.cParticipantType);
				logDebug2("Ord_Res.sSettlor                   :%s:",Ord_Res.sSettlor);
				logDebug2("Ord_Res.cGTCFlag                   :%c:",Ord_Res.cGTCFlag);
				logDebug2("Ord_Res.cEncashFlag                :%c:",Ord_Res.cEncashFlag);
				logDebug2("Ord_Res.sPanID                     :%s:",Ord_Res.sPanID);
				logDebug2("Ord_Res.iGrpId                     :%d:",Ord_Res.iGrpId);
				logDebug2("--------------------END----------------------------");

				if((WriteMsgQ(ReconsToKafka,&Ord_Res,RUPEE_MAX_PACKET_SIZE,1)) == ERROR)
				{
					logFatal("Error in WriteMsgQ Id = %d",ReconsToKafka);
					exit(ERROR);
				}
			}
			mysql_free_result(Res);
		}
	}
	logTimestamp("EXIT : [ Kafka Reconsicalltion ] ");
	return 0;
}



BOOL	FetchPostnSend(ReconsToKafka,iPositionType)
{
	logTimestamp("Entry : FetchPostnSend");
	struct C2D_VIEW_NET_POSITION pC2DPos;
	CHAR	sSelQry [50000];
	CHAR    sWhere_Clause[MAX_QUERY_SIZE];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	memset(sSelQry,'\0',50000);
	memset(sWhere_Clause,'\0',MAX_QUERY_SIZE);
	memset(&pC2DPos,'\0',sizeof(struct C2D_VIEW_NET_POSITION));

	logDebug2("iPositionType :%d:",iPositionType);
	if(iPositionType == 0)
	{
		sprintf(sWhere_Clause,"SELECT FN_QRY_NET_POSITION(\"%\",\"%\",\"%\",\'%\',\"%s\",\"%\",\"%\",\'%\',\'%\','C',\"%\");","BCF");
	}
	else
	{
		sprintf(sWhere_Clause,"SELECT FN_QRY_NET_POSITION(\"%\",\"%\",\"%\",\'%\',\"%s\",\"%\",\"%\",\'%\',\'%\','C',\"%\");","CTD");
	}
	
	
	logDebug2("Query :%s:",sWhere_Clause);
	if(mysql_query(DBConvDel,sWhere_Clause) != SUCCESS)
	{
		logSqlFatal("ERROR in ConvToDel Function.");
		sql_Error(DBConvDel);
		return FALSE;
	}
	Res = mysql_store_result(DBConvDel);

	if(Row = mysql_fetch_row(Res) )
	{
		sprintf(sSelQry,"%s",Row[0]);
	}
	else
	{
		logInfo("No Output from Net Position Function ");
	}
	mysql_free_result(Res);
	printf("sSelQry :%s:\n",sSelQry);

	if (mysql_query(DBConvDel, sSelQry) != SUCCESS)
	{
		logSqlFatal("Error in Select Serial No Query [EQTrdDBOp].");
		sql_Error(DBConvDel);
		return FALSE;
	}
	Res = mysql_store_result(DBConvDel);
	logDebug2("Rows : %i",mysql_num_rows(Res));

	while((Row = mysql_fetch_row(Res)))
	{
		pC2DPos.RespHeader.iSeqNo= 0;
		pC2DPos.RespHeader.iMsgLength= sizeof(struct C2D_VIEW_NET_POSITION);
		pC2DPos.RespHeader.iErrorId= 0;
		pC2DPos.RespHeader.iUserId= 0; 
		pC2DPos.RespHeader.cSegment= Row[23][0];
		pC2DPos.RespHeader.cSource = 'A'; 
		strncpy(pC2DPos.RespHeader.sExcgId,Row[2],EXCHANGE_LEN);
		logInfo("iPositionType :%d:",iPositionType);
		//if(iPositionType == 0)
		//{
		pC2DPos.RespHeader.iMsgCode = TC_INT_CON_DEL_POS_RESP;
		//}
		/**else
		{
			pC2DPos.RespHeader.iMsgCode = TC_INT_CON_DEL_IP_POS_RESP;
		}**/
		strncpy(pC2DPos.sSecurityID,Row[1],SECURITY_ID_LEN);
		strncpy(pC2DPos.sExchId,Row[2],EXCHANGE_LEN);
		pC2DPos.iBuyQty = atoi(Row[4]);
		pC2DPos.iBuyQtyCF = atoi(Row[5]);
		pC2DPos.iBuyQtyDay = atoi(Row[6]);
		pC2DPos.fBuyVal = atof(Row[7]);
		pC2DPos.fBuyValCF = atof(Row[8]);
		pC2DPos.fBuyValDay = atof(Row[9]);
		pC2DPos.fBuyAvg = atof(Row[10]);
		pC2DPos.iSellQty = atoi(Row[11]);
		pC2DPos.iSellQtyCF = atoi(Row[12]);
		pC2DPos.iSellQtyDay = atoi(Row[13]);
		pC2DPos.fSellVal = atof(Row[14]);
		pC2DPos.fSellValCF = atof(Row[15]);
		pC2DPos.fSellValDay = atof(Row[16]);
		pC2DPos.fSellAvg = atof(Row[17]);
		pC2DPos.iNetQty = atoi(Row[18]);
		pC2DPos.fNetVal = atof(Row[19]);
		pC2DPos.fNetAvg = atof(Row[20]);
		pC2DPos.fGrossQty = atof(Row[21]);
		pC2DPos.fGrossVal = atof(Row[22]);
		strncpy(pC2DPos.cMktType,Row[3],MARKET_LEN);
		pC2DPos.cProductId = Row[24][0];
		pC2DPos.fRelaisedProfit = atof(Row[25]);
		strncpy(pC2DPos.sClientId,Row[0],CLIENT_ID_LEN);
		pC2DPos.cSegment = Row[23][0];
		pC2DPos.iRef_ID = atoi(Row[26]);

		logDebug2("pC2DPos.sClientId :%s:",pC2DPos.sClientId);
		logDebug2("pC2DPos.sSecurityID:%s:",pC2DPos.sSecurityID);
		logDebug2("pC2DPos.sExchId :%s:",pC2DPos.sExchId);
		logDebug2("pC2DPos.cMktType :%s:",pC2DPos.cMktType);
		logDebug2("pC2DPos.iBuyQty :%d:",pC2DPos.iBuyQty);
		logDebug2("pC2DPos.iBuyQtyCF :%d:",pC2DPos.iBuyQtyCF);
		logDebug2("pC2DPos.iBuyQtyDay :%d:",pC2DPos.iBuyQtyDay);
		logDebug2("pC2DPos.fBuyVal :%lf:",pC2DPos.fBuyVal);
		logDebug2("pC2DPos.fBuyValCF :%lf:",pC2DPos.fBuyValCF);
		logDebug2("pC2DPos.fBuyValDay :%lf:",pC2DPos.fBuyValDay);
		logDebug2("pC2DPos.fBuyAvg :%lf:",pC2DPos.fBuyAvg);
		logDebug2("pC2DPos.iSellQty :%d:",pC2DPos.iSellQty);
		logDebug2("pC2DPos.iSellQtyCF :%d:",pC2DPos.iSellQtyCF);
		logDebug2("pC2DPos.iSellQtyDay :%d:",pC2DPos.iSellQtyDay);
		logDebug2("pC2DPos.fSellVal :%lf:",pC2DPos.fSellVal);
		logDebug2("pC2DPos.fSellValCF :%lf:",pC2DPos.fSellValCF);
		logDebug2("pC2DPos.fSellValDay :%lf:",pC2DPos.fSellValDay);
		logDebug2("pC2DPos.fSellAvg :%lf:",pC2DPos.fSellAvg);
		logDebug2("pC2DPos.iNetQty :%d:",pC2DPos.iNetQty);
		logDebug2("pC2DPos.fNetVal:%lf:",pC2DPos.fNetVal);
		logDebug2("pC2DPos.fNetAvg :%lf:",pC2DPos.fNetAvg);
		logDebug2("pC2DPos.fGrossQty :%lf:",pC2DPos.fGrossQty);
		logDebug2("pC2DPos.fGrossVal :%lf:",pC2DPos.fGrossVal);
		logDebug2("pC2DPos.cSegment:%c:",pC2DPos.cSegment);
		logDebug2("pC2DPos.cProductIdy :%c:",pC2DPos.cProductId);
		logDebug2("pC2DPos.fRelaisedProfit:%lf:",pC2DPos.fRelaisedProfit);
		logDebug2("pC2DPos.iRef_ID :%d:",pC2DPos.iRef_ID);
		if((WriteMsgQ(ReconsToKafka,&pC2DPos,RUPEE_MAX_PACKET_SIZE,1)) == ERROR)
		{
			logFatal("Error in WriteMsgQ Id = %d",ReconsToKafka);
			exit(ERROR);
		}

	}
	mysql_free_result(Res);
	logTimestamp("Exit : FetchPostnSend");

}















