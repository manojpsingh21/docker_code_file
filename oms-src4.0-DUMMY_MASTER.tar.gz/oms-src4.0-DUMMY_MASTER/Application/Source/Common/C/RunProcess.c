# include "IPCS.h"
# include <string.h>
# include <errno.h>
# include <sys/ipc.h>
# include <sys/msg.h>
# include <stdio.h>
# include <stdlib.h>

main (int argc,char ** argv )
{
	logTimestamp("Entry :RunProcess [main]");
	int iChildId;
	int iRetError;
	char sCommand[50];
	signal(SIGCHLD,SIG_IGN);
	setpgid ( 0,getpid ( ) );
	if((iRetError= CheckProcessMem ( argv[1]))== 0)
	{
		logFatal( " This Process is Already Running... You need to Stop and Start the process Again. If this does not resolve the issue please cal rupeeseed helpdesk.");

		exit(1);
	}
	if ( iRetError == ERROR )
	{
		logFatal( " Full Start is not done before Partial start.... Please stop the full system and start the same again. ");
		exit(1);
	}
	if((iChildId = fork())==0)
	{
		if(execv(argv[1],argv + 1 ) < 0 )
		{
			perror("execv");
			exit (-1);
		}
	}

	memset(sCommand,0,50);
	strcpy(sCommand,argv[1]);
	AddProcessMem ( sCommand,iChildId,argv[argc - 1]);
	logTimestamp("Exit :RunProcess  [main]");
	exit(0);
}

