[entity_type:S, token_id:375a65400d992de146e3, user_id:SYSADMIN14, v_mode:SCRIPINSERT, entity_manager_code:90061, ip:116.73.13.197, v_scrip_list:[
  {
    "v_series": "EQ",
    "v_scripcode": "4",
    "v_seg": "EQ",
    "v_exch": "NSE",
    "v_product": "ALL",
    "v_buy_sell": "ALL",
    "v_flag": "N",
    "v_basketName": "ABC"
  }
]]

