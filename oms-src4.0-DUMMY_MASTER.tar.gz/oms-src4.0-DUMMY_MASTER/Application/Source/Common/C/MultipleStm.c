#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"


MYSQL   *DBmul;

main(int argc ,char **argv)
{
        DBmul= DB_Connect();

	int loop = atoi(argv[1]);	
	int sleeptime = atoi(argv[2]);	

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	INT16           iStatus;

	logDebug2("loop :%d:", loop);
	logDebug2("sleeptime :%d:", sleeptime);
/**
        if(mysql_set_server_option(DBmul,CLIENT_MULTI_STATEMENTS) == 0)
        {
                logDebug2(" mysql_set_server_option SUCCESS");
        }
        else
        {
                logDebug2(" mysql_set_server_option FAILS");
        }
**/

	int i;
	for(i=0;i<=loop ;i++)
	{
/**/
		CHAR MulQur[MAX_QUERY_SIZE];
		if(mysql_set_server_option(DBmul,CLIENT_MULTI_STATEMENTS) == 0)
        	{
        	        logDebug2(" mysql_set_server_option SUCCESS");
        	}
        	else
        	{
			
                       	sql_Error(DBmul);
       	         	logDebug2(" mysql_set_server_option FAILS");
        	}
/**/

		memset(MulQur,'\0',MAX_QUERY_SIZE);
//		sprintf(MulQur," CALL REVERSE_VALIDATE_COMBINED(LTRIM(RTRIM(\"YES2330\")),LTRIM(RTRIM(\"NSE\")),'E','M',LTRIM(RTRIM(\"11536\")),@NUMMARGIN,@V_RELZ_PNL_ORGINAL, @V_DESCRIPTOR);SELECT IFNULL(@NUMMARGIN,0), IFNULL(@V_RELZ_PNL_ORGINAL,0), IFNULL(@V_DESCRIPTOR,'Returns NULL VALUES');");		

		sprintf(MulQur,"CALL PR_ADMIN_HOLDING_ADD(\'U\',\"NSE\",\"INE062A01020\",\"PK001\",\"MRG\",330.000000,5,@ZSTATUS);SELECT @ZSTATUS ;");

		logDebug2("MulQur:%s:",MulQur);	
		if(mysql_query(DBmul,MulQur) != SUCCESS)
                 {
                       sql_Error(DBmul);
                       logDebug2("Error IN CALLING REVERSE_VALIDATE_COMBINED.");
                                   //     fSendConvtToDelErrToFE (TRANSACTION_FAILED,pCTDReq,0,0.00);
                       continue;
                 }
		
		do{
                                Res = mysql_store_result(DBmul);
                                if(Res)
                                {
                                        if((Row = mysql_fetch_row(Res)))
                                        {
						logDebug2(" OutPut :%s:",Row[0]);
                                                mysql_free_result(Res);
                                        }


                                }
                                else
                                {
                                        logDebug2("No Result Set ");
                                }

                                logDebug2(" Before mysql_next_result");
                                if((iStatus = mysql_next_result(DBmul)) > 0)
                                {
                                        logDebug3("Could not execute statement");
                                }

                }while(iStatus == 0);
		sleep(sleeptime);
		

	}

}
