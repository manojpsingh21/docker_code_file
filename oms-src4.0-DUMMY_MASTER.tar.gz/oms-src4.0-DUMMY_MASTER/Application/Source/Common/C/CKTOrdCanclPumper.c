#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "AdminAdaptor.h"
MYSQL   *DB_MTM;
static CHAR sComLmtQry[DOUBLE_MAX_QUERY_SIZE]; 
static CHAR    sWhereClause[MAX_QUERY_SIZE];
LONG32  iCount = 0;
LONG32  iCKTTimer = 0;
LONG32  iMTMToOrdCanReq=0;
LONG32  iIntSqrOffToMemMap=0;
CHAR    sAdmin [15];
LONG32  iUserId;
CHAR    sOrderVal[INTSQROFF_ORDER_VAL_LEN];
LONG32  iOrderVal = 3;
void    ProcessOrder();



LONG32 main (LONG32 argc,CHAR **argv)
{
	logTimestamp("Entry : [main]");

	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;
	LONG32 iRow,i;
	CHAR    sSelectQry[MAX_QUERY_SIZE];
	memset(sSelectQry,'\0',MAX_QUERY_SIZE);
	CHAR    sGrpId [ENV_VARIABLE_LEN];


	memset(sWhereClause,'\0',MAX_QUERY_SIZE);
	memset(sComLmtQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sOrderVal,'\0',INTSQROFF_ORDER_VAL_LEN);
	DB_MTM = DB_Connect();


	OpenMsgQue();
	sprintf(sSelectQry,"SELECT s.PARAM_VALUE  from SYS_PARAMETERS  s where s.PARAM_NAME  IN ( 'CKT_TIMER','Default_userid','Default_admin','INTRADAY_SQROFF_VALIDITY') order by s.PARAM_NAME asc");

	if (mysql_query(DB_MTM ,sSelectQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error Fetching SysAdmin .");
		exit(ERROR);
	}
	logDebug2("Query [%s]",sSelectQry);

	Res = mysql_store_result(DB_MTM);
	iRow = (mysql_num_rows(Res));
	if(iRow == 0)
	{
		mysql_free_result(Res);
		logDebug2("Zero rows selected from sys_parameter");
		exit(ERROR);
	}
	else
	{
		logDebug2("Number of rows Selected from SYS_PARAMETER = :%d:",iRow);
		for(i = 0 ; i < iRow ; i ++)
		{
			if(Row = mysql_fetch_row(Res))
			{

				switch (i)
				{
                                        case 0 :
                                                iCKTTimer = atoi(Row[0]);
                                                logDebug2("In 4th Loop iTimer :%d:",iCKTTimer);
                                                break;
                                        case 1  :
                                                strncpy(sAdmin,Row[0],15);
                                                logDebug2("sAdmin :%s:",sAdmin);
                                                break;
                                        case 2 :
                                                iUserId = atoi(Row[0]);
                                                logDebug2("iUserId :%d:",iUserId);
                                                break;
					case 3 :
                                                strncpy(sOrderVal,Row[0],INTSQROFF_ORDER_VAL_LEN);
						if(strcmp(sOrderVal,"DAY") == 0)
						{
							logDebug3("IN CASE OF DAY");
							iOrderVal = VALIDITY_DAY;
						}
						else if(strcmp(sOrderVal,"IOC") == 0)
						{
							logDebug3("IN CASE OF IOC");
							iOrderVal = VALIDITY_IOC;
						}
						break;
					default :
						logDebug2("Wrong case");
						break ;
				}
			}
		}
		mysql_free_result(Res);
	}

	if(iCKTTimer < 20);
	{
		iCKTTimer = 20;
		logDebug2(" In IF iCKTTimer :%d:",iCKTTimer);
	}
	logDebug2("In Else iCKTTimer :%d:",iCKTTimer);
	logDebug2("VALUE LOADED iCKTTimer :%d:  ",iCKTTimer);	

	logDebug2("In Combined Query cSegLmtFlg == 'A' && cComLmtFlg == 'Y'");
	sprintf(sComLmtQry,"SELECT NPT_SECURITY_ID,NPT_CLIENT_ID, (CASE WHEN NPT_NET_QTY > 0 THEN 'S' WHEN NPT_NET_QTY < 0 THEN 'B' END) AS BUY_SELL FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE AND NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT) LEFT JOIN BHAV_COPY BC ON (NPT.NPT_SECURITY_ID = BC.BC_SCRIP_CODE AND NPT.NPT_EXCH_ID = BC.BC_EXCHANGE AND NPT.NPT_SEGMENT = BC.BC_SEGMENT)  LEFT JOIN SEM_ACTIVE SM ON (NPT.NPT_SECURITY_ID = SM.SM_SCRIP_CODE AND NPT.NPT_EXCH_ID = SM.SM_EXCHANGE AND NPT.NPT_SEGMENT = SM.SM_SEGMENT)  LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE) LEFT JOIN SYS_PARAMETERS SP ON (SP.PARAM_NAME = 'CKT_BLOCK_THRESHHOLD_PERC') WHERE ((LWA.L1_LTP<=( BC.BC_CLOSE_PRICE - ( BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE/100)/100))AND NPT.NPT_NET_QTY >0)   OR (LWA.L1_LTP>=( BC.BC_CLOSE_PRICE + ( BC.BC_CLOSE_PRICE * (SM.SM_DPR_BAND * SP.PARAM_VALUE/100)/100))AND NPT.NPT_NET_QTY <0)) AND NPT.NPT_PROD_ID NOT IN ('C','M') AND NPT.NPT_SEGMENT = 'E' AND SM.SM_DPR_BAND <> 0;");
	printf("In COMBINED sComLmtQry :%s:\n",sComLmtQry);


	ProcessOrder();


	logTimestamp("Exit : [main]");
}

void ProcessOrder()
{
	logTimestamp("Entry : [ProcessOrder]");

	CHAR  sRcvMsg  [RUPEE_MAX_PACKET_SIZE];
	MYSQL_RES 	*Res;  
	MYSQL_ROW	*Row;
	INT16            iBreaches;
	CHAR   sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);
	CHAR  sClientId[CLIENT_ID_LEN];
	memset(sClientId,'\0',CLIENT_ID_LEN);
	CHAR            sClause[MAX_QUERY_SIZE];
	CHAR            sSelQry[MAX_QUERY_SIZE];
	LONG32		iMktstatus =0;
        memset(sClause,'\0',MAX_QUERY_SIZE);


	
	CHAR sCommand[COMMAND_LEN];
	INT16	iExpSec =10;



	while(TRUE)
	{

		sleep(5);
		memset( sRcvMsg , '\0',RUPEE_MAX_PACKET_SIZE);


		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %d=================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		while(1)
                {
                        memset(sSelQry ,'\0',MAX_QUERY_SIZE);
                        sprintf(sSelQry,"SELECT EMM_STATUS FROM EXCH_MKT_MASTER WHERE EMM_EXM_EXCH_ID = ltrim(rtrim(\"%s\")) \
                                         AND EMM_MKT_TYPE = \'NL\' AND EMM_EXCH_SEG=\'%c\' ",NSE_EXCH,EQUITY_SEGMENT);

                        logDebug2("sSelQry of market status :%s:", sSelQry);
                        if (mysql_query(DB_MTM,sSelQry) != SUCCESS)
                        {
				sql_Error(DB_MTM);
                                logSqlFatal("Error in select Qry market status.");
                                mysql_close(DB_MTM);
                                return ERROR;
                        }
                        Res = mysql_store_result(DB_MTM);
                        Row = mysql_fetch_row(Res);
                        iMktstatus = atoi(Row[0]);
                        logDebug2("iMktstatus :%d:", iMktstatus);
                        mysql_free_result(Res);
                        if(iMktstatus == MKT_OPEN)
                        {
                                logDebug2("Market is open we can continue .");
                                break;
                        }else
                        {
                                logDebug2("Market is closed .");

                        }
                        sleep(5);

                }


		printf("In ANother Fn QUERY :%s:\n",sComLmtQry);
		if(mysql_query(DB_MTM,sComLmtQry) != SUCCESS)
		{
			logSqlFatal("Error in select Qry [CheckMTM].");
			mysql_close(DB_MTM);
			return ERROR;
		}
		Res = mysql_store_result(DB_MTM);
		logDebug2("COMBINED RESULT RES :%d:",Res);
		logDebug2("COMBINE Rows : %i",mysql_num_rows(Res));
		iBreaches = mysql_num_rows(Res);
		logDebug2("iBreaches :%d:",iBreaches);
		logDebug2("--------------------------------------------------------");
		logDebug2("-----------------------count:%d:------------------------",iCount);
		logDebug2("--------------------------------------------------------");
		while(Row = mysql_fetch_row(Res))
		{
		
			fGetOrderBookQry(Row[0],Row[1]);
			//fGetOrderBookQry(Row[0]);
			
		}	
		mysql_free_result(Res);

	}
	logTimestamp("Exit : [ProcessOrder]");
	return TRUE;

}

BOOL    fGetOrderBookQry(CHAR *sSecId, CHAR *sClientId)
{
	logTimestamp("Entry :fGetOrderBookQry:");

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	struct  ORDER_REQUEST   pEOrdReq;	
	LONG32   iNoOfRec = 0;
	LONG32   i= 0;
	logDebug2("sSecId:%s:",sSecId);
	logDebug2("sClientId :%s:",sClientId);
	CHAR    sSelQry [DOUBLE_MAX_QUERY_SIZE];
	memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);


	strncpy(sWhereClause,"LIKE '%'",MAX_QUERY_SIZE);
		

	logDebug2("Final sWhereClause:%s:",sWhereClause);


	sprintf(sSelQry,"SELECT  ORDER_NUMBER,  SERIALNO,  SEM_SECURITY_ID,  ORDER_TYPE,  QUANTITY,  REMAINING_QUANTITY,  DISCLOSE_QTY,  DQQTYREM,  PRICE,  TRG_PRICE,  TRADEDQTY,  PRODUCT,  ORDER_VALIDITY,  EXCHORDERNO,  ORDER_DATE_TIME,  EXCH,  BUY_SELL,  SEGMENT,  TRANSCODE,  CLIENT_ID,  JDATE,  IFNULL(STRATEGY_ID, 0),  PLACEDBY,  REASON_DESCRIPTION,  PRO_CLIENT,  TRADE_PRICE,  GOOD_TILL_DATE,  LEG_NO,  IFNULL(EXPIRY_DATE, 0),  IFNULL(SOURCE_FLG, 'NA'),  IFNULL(ALGOORDERNO, 0),  IFNULL(PAN_NO, 'NA'),  IFNULL(PARTICIPANT_TYPE, 'B'),  IFNULL(MKT_PROTECT_FLG, 'N'),  IFNULL(MKT_PROTECT_VAL, 1),  IFNULL(SETTLOR, 'NA'),  IFNULL(GTC_FLG, 'N'),  IFNULL(ENCASH_FLG, 'N'),  MKT_TYPE,  USER_ID,  USER_TYPE,  GROUP_ID  FROM  (SELECT  `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,  DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,  `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,  `A`.`EQ_EXCH_ID` AS `EXCH`,  `A`.`EQ_BUY_SELL_IND` AS `BUY_SELL`,  'E' AS `SEGMENT`,  `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,  `A`.`EQ_SYMBOL` AS `SYMBOL`,  `A`.`EQ_LEG_NO` AS `LEG_NO`,  `A`.`EQ_PRODUCT_ID` AS `PRODUCT`,  (CASE  WHEN  ((`A`.`EQ_MSG_CODE` = '2073')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2074')  AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN  ((`A`.`EQ_MSG_CODE` = '2212')  AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))  THEN  'Part-Traded'  WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending'  WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit'  WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen'  WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified'  WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded'  WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired'  WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending'  WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified'  WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled'  WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered'  WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected'  WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected'  END) AS `STATUS`,  `A`.`EQ_TOTAL_QTY` AS `QUANTITY`,  `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,  (CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 4), ',', '')  ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)  END), 2), ',', '')  END) AS `PRICE`,  CASE `A`.`EQ_SEGMENT`  WHEN  'C'  THEN  ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`  WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)  ELSE 0  END), 0), 2)  END AS `TRG_PRICE`,  `A`.`EQ_ORDER_TYPE` AS `ORDER_TYPE`,  CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,  `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,  `A`.`EQ_SERIAL_NO` AS `SERIALNO`,  `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,  `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,  `A`.`EQ_VALIDITY` AS `ORDER_VALIDITY`,  IFNULL(`A`.`EQ_LOT_SIZE`, 0) AS `SEM_NSE_REGULAR_LOT`,  0 AS `TAKE_PROFIT_TRAIL_GAP`,  `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,  `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,  `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,  IFNULL(NULLIF(`A`.`EQ_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,  `A`.`EQ_PRO_CLIENT` AS `PRO_CLIENT`,  `A`.`EQ_TRD_TRADE_PRICE` AS `TRADE_PRICE`,  IFNULL(`A`.`EQ_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,  `A`.`EQ_ENTITY_ID` AS `PLACEDBY`,  `A`.`EQ_STRATEGY_ID` AS `STRATEGY_ID`,  JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,  `A`.`EQ_MSG_CODE` AS `TRANSCODE`,  `A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`,  `A`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,  `A`.`EQ_SOURCE_FLG` AS `SOURCE_FLG`,  `A`.`EQ_ALGO_ORDER_NO` AS `ALGOORDERNO`,  `A`.`EQ_PAN_NO` AS `PAN_NO`,  `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,  `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,  `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,  `A`.`EQ_SETTLOR` AS `SETTLOR`,  `A`.`EQ_GTC_FLG` AS `GTC_FLG`,  `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,  `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,  `A`.`EQ_USER_ID` AS `USER_ID`,  `A`.`EQ_USER_TYPE` AS `USER_TYPE`,  `A`.`EQ_GROUP_ID` AS `GROUP_ID`  FROM  (SELECT MAX(EQ_SERIAL_NO) AS SER, EQ_ORDER_NO AS ORD, EQ_LEG_NO AS LEG FROM EQ_ORDERS C WHERE C.`EQ_CF_FLAG` <> -(1) AND C.`EQ_ORD_STATUS` <> 'B' GROUP BY EQ_ORDER_NO, EQ_LEG_NO) X, `EQ_ORDERS` `A`  WHERE  `A`.`EQ_SERIAL_NO` = X.SER  	AND A.EQ_ORDER_NO = X.ORD  AND A.EQ_LEG_NO = X.LEG  	AND `A`.`EQ_MSG_CODE` IN (2073 , 2074, 2212)) orderbook  WHERE  1 = 1 AND PRODUCT = 'I'  AND STRATEGY_ID <> 107  AND SEM_SECURITY_ID = \"%s\" AND CLIENT_ID = \"%s\"  AND SEGMENT %s  ORDER BY ORDER_DATE_TIME DESC;",sSecId,sClientId,sWhereClause);
	printf("\n fGetOrderBookQry :%s:\n",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error IN fGetOrderBookQry.");
		return ERROR;
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);
	logDebug2("Rows returned from Database = :%d:",iNoOfRec);

	for (i=0;i<iNoOfRec ;i++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[15],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = iUserId; 
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[17][0];
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[41]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_ORDER_CANCEL;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[19],CLIENT_ID_LEN);
			pEOrdReq.cProductId= Row[11][0];
			pEOrdReq.cBuyOrSell = Row[16][0];
			pEOrdReq.iOrderType = atoi(Row[3]);
			pEOrdReq.iOrderValidity = atof(Row[12]);
			pEOrdReq.iTotalQty = atoi(Row[4]);
			pEOrdReq.iTotalQtyRem = atoi(Row[5]);
			pEOrdReq.iDiscQty = atoi(Row[6]);
			pEOrdReq.iDiscQtyRem = atoi(Row[7]);
			pEOrdReq.iTotalTradedQty = atoi(Row[10]);
			pEOrdReq.fPrice = atof(Row[8]);

			pEOrdReq.fTriggerPrice = atof(Row[9]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;

			pEOrdReq.cHandleInst = '1';
			pEOrdReq.cProCli = Row[24][0];
			pEOrdReq.iStratergyId= STRG_CKT_SQR_OFF;
			pEOrdReq.iMinFillQty = atoi(Row[18]);
			pEOrdReq.fAlgoOrderNo = atof(Row[30]);
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sGoodTillDaysDate,"\0",DB_DATETIME_LEN);
			pEOrdReq.cUserType = Row[40][0] ;
			strncpy(pEOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT LIMIT",REMARKS_LEN);


			if(strcmp(Row[38],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[38],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[38],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[38],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[38]);
			}

			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[32][0];
			strncpy(pEOrdReq.sSettlor,Row[35],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[36][0];
			pEOrdReq.cEncashFlag= Row[37][0];
                        pEOrdReq.iGrpId = atoi(Row[41]);
			strncpy(pEOrdReq.sPanID,Row[31],INT_PAN_LEN);
			logDebug2("**********CANCELLING ORDERS************");
			logDebug2("sSettler :%s:%d:",pEOrdReq.sSettlor,SETTLOR_LEN);
			logDebug2("sPandId :%s:%d:",pEOrdReq.sPanID,INT_PAN_LEN);
			logDebug2("cParticipantType :%c:",pEOrdReq.cParticipantType);
			logDebug2("iGroupId :%d:",pEOrdReq.iGrpId);
			logDebug2("pEOrdReq.fOrderNum :%lf:",pEOrdReq.fOrderNum);
			logDebug2("pEOrdReq.sClientId:%s:",pEOrdReq.sClientId);
			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pEOrdReq,sizeof(struct ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}

	/*following case is previous in upper paranthesis*/
	fEqCoOrdExit(sSecId,sClientId);	
	fEqBoOrdExit(sSecId,sClientId);	
//	fDrvCoOrdExit(sSecId,sClientId);	
//	fDrvBoOrdExit(sSecId,sClientId);
//	fMcxCoOrdExit(sSecId,sClientId);	
//	fMcxBoOrdExit(sSecId,sClientId);

	logTimestamp("Exit :fGetOrderBookQry:");
	return TRUE;

}

BOOL fEqCoOrdExit (CHAR *sSecId, CHAR *sClientId)
{
	logTimestamp("fEqCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32 iNoOfRec = 0;
        LONG32 i = 0;

	struct  CO_ORDER_REQUEST   pEOrdReq;
	logDebug2("sSecId :%s:",sSecId);
	logDebug2("sClientId:%s:",sClientId);
	CHAR sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_SL_ABSTICK_VALUE ,\
			EQ_PR_ABSTICK_VALUE ,\
			EQ_SL_AT_FLAG ,\
			EQ_PR_ST_FLAG ,\
			EQ_PAN_NO,\
			EQ_PARTICIPANT_TYPE,\
			EQ_SETTLOR,\
			EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,\
			EQ_GTC_FLG,\
			EQ_ENCASH_FLG,\
			EQ_GROUP_ID \
			FROM    EQ_ORDERS A\
			WHERE  A.EQ_ORD_STATUS IN (\'%c\',\'%c\') \
			AND     A.EQ_PRODUCT_ID = \'%c\' \
			AND     A.EQ_LEG_NO =   %d \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d ) \
			AND A.EQ_SCRIP_CODE = \"%s\" AND A.EQ_CLIENT_ID = \"%s\" AND A.EQ_SEGMENT %s" \
			,EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,sSecId,sClientId,sWhereClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error in fEqCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);
	logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

	for(i = 0 ; i < iNoOfRec ; i++)
	{
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = iUserId; 
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);

			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= STRG_CKT_SQR_OFF ;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.fTrailingSLValue = 0.00 ;
			pEOrdReq.fAlgoOrderNo = 0.00 ;
			pEOrdReq.iNoOfLeg = 1 ;
			pEOrdReq.iMinFillQty = atoi(Row[18]) ;
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cAvgLtpFlg = 0;
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT LIMIT",REMARKS_LEN);
			pEOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[31][0];
			strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[35][0];
			pEOrdReq.cEncashFlag= Row[36][0];
			pEOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);


			logDebug2(" pEOrdReq.CoArray[0].cBuySellInd :%c: ",pEOrdReq.CoArray[0].cBuySellInd);
			logDebug2("pEOrdReq.CoArray[0].fTriggerPrice :%f:",pEOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pEOrdReq.CoArray[1].fTriggerPrice :%f:",pEOrdReq.CoArray[1].fTriggerPrice);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);

			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pEOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fEqCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fDrvCoOrdExit (CHAR *sSecId, CHAR *sClientId)
{
	logTimestamp("fDrvCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	logDebug2("sClientId :%s:",sClientId);
	CHAR sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	LONG32 iNoOfRec = 0;
	LONG32 i = 0;

	struct  CO_ORDER_REQUEST   pDrOrdReq;

	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT ,\
			DRV_SL_ABSTICK_VALUE ,\
			DRV_PR_ABSTICK_VALUE ,\
			DRV_SL_AT_FLAG ,\
			DRV_PR_ST_FLAG ,\
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID \
			FROM    DRV_ORDERS A\
			WHERE    A.DRV_STATUS IN (\'%c\',\'%c\') \
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND     A.DRV_LEG_NO =   %d \
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
			AND A.DRV_CLIENT_ID = \"%s\" AND A.DRV_SEGMENT %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,sClientId,sWhereClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error in fDrvCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fDrvCoOrdExit : Rows returned from Database = :%d:",iNoOfRec);


	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pDrOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pDrOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pDrOrdReq.ReqHeader.iUserId = iUserId; 
			pDrOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDrOrdReq.ReqHeader.cSegment = Row[25][0];
			pDrOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pDrOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pDrOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);
			strncpy(pDrOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pDrOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sClientId,Row[6],CLIENT_ID_LEN);
			pDrOrdReq.cProductId= Row[23][0];

			pDrOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pDrOrdReq.iOrderType = atoi(Row[16]);
			pDrOrdReq.iOrderValidity = iOrderVal;
			pDrOrdReq.iTotalQty = atoi(Row[8]);
			pDrOrdReq.iTotalQtyRem = atoi(Row[8]);
			pDrOrdReq.iDiscQty = atoi(Row[10]);
			pDrOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDrOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDrOrdReq.fPrice = atof(Row[13]);
			pDrOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pDrOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pDrOrdReq.fOrderNum = atof(Row[0]);
			pDrOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pDrOrdReq.cHandleInst = Row[19][0];
			pDrOrdReq.cProCli = Row[19][0];
			pDrOrdReq.CoArray[0].iLegValue = LEG_1 ;

			pDrOrdReq.fSLTikAbsValue = atof(Row[26]);
			pDrOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pDrOrdReq.cSLFlag  =  Row[28][0];
			pDrOrdReq.cPBFlag  = Row[29][0];
			pDrOrdReq.cAvgLtpFlg = 0;
			strncpy(pDrOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT BREACH",REMARKS_LEN);
			pDrOrdReq.iMinFillQty = atoi(Row[18]) ;
			pDrOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			pDrOrdReq.iNoOfLeg = 1 ;
			pDrOrdReq.cAvgLtpFlg = 0;
			pDrOrdReq.iStratergyId= STRG_MTM_SQR_OFF ;
			pDrOrdReq.fTrailingSLValue = 0.00 ;
			pDrOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDrOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDrOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDrOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDrOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			pDrOrdReq.cMarkProFlag= Row[33][0];
			pDrOrdReq.fMarkProVal= atof(Row[34]);
			pDrOrdReq.cParticipantType= Row[31][0];
			strncpy(pDrOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pDrOrdReq.cGTCFlag= Row[35][0];
			pDrOrdReq.cEncashFlag= Row[36][0];
			pDrOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pDrOrdReq.sPanID,Row[30],INT_PAN_LEN);
			logDebug2("pDrOrdReq.CoArray[0].fTriggerPrice :%f:",pDrOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pDrOrdReq.CoArray[1].fTriggerPrice :%f:",pDrOrdReq.CoArray[1].fTriggerPrice);
			logDebug2("pDrOrdReq.fOrderNum = %f ",pDrOrdReq.fOrderNum);
			logDebug2("pDrOrdReq.sClientId = %s",pDrOrdReq.sClientId);

			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pDrOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fDrvCoOrdExit [EXIT]");
	return TRUE;
}

BOOL fMcxCoOrdExit (CHAR *sSecId , CHAR *sClientId)
{
	logTimestamp("fMcxCoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	logDebug2("sClientId :%s:",sClientId);
	CHAR sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);

	LONG32 iNoOfRec = 0 ;
	LONG32  i = 0;

	struct  CO_ORDER_REQUEST   pMOrdReq;
	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_MKT_TYPE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_USER_TYPE,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE,\
			COMM_SEGMENT ,\
			COMM_SL_ABSTICK_VALUE ,\
			COMM_PR_ABSTICK_VALUE ,\
			COMM_SL_AT_FLAG ,\
			COMM_PR_ST_FLAG ,\
			COMM_PAN_NO,\
			COMM_PARTICIPANT_TYPE,\
			COMM_SETTLOR,\
			COM_MKT_PROTECT_FLG,\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG,\
			COMM_GROUP_ID \
			FROM    COMM_ORDERS A\
			WHERE  A.COMM_STATUS IN (\'%c\',\'%c\') \
			AND     A.COMM_PRODUCT_ID = \'%c\' \
			AND     A.COMM_LEG_NO =   %d \
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO AND B.COMM_LEG_NO = %d )\
			AND A.COMM_CLIENT_ID = \"%s\" AND A.COMM_SEGMENT %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_COVER,LEG_1,LEG_1,sClientId,sWhereClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error in fMcxCoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);
	logDebug2("Total no of orders to be cancelled = :%d:",iNoOfRec);

	for(i = 0 ; i < iNoOfRec ; i++)
	{
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pMOrdReq,'\0',sizeof(struct CO_ORDER_REQUEST));
			strncpy(pMOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pMOrdReq.ReqHeader.iUserId = iUserId; 
			pMOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pMOrdReq.ReqHeader.cSegment = Row[25][0];
			pMOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pMOrdReq.ReqHeader.iMsgCode = TC_INT_CO_ORDER_EXIT;
			pMOrdReq.ReqHeader.iMsgLength= sizeof(struct CO_ORDER_REQUEST);

			strncpy(pMOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pMOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pMOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pMOrdReq.cProductId= Row[23][0];
			pMOrdReq.CoArray[0].cBuySellInd = Row[7][0];
			pMOrdReq.iOrderType = atoi(Row[16]);
			pMOrdReq.iOrderValidity = iOrderVal;
			pMOrdReq.iTotalQty = atoi(Row[8]);
			pMOrdReq.iTotalQtyRem = atoi(Row[8]);
			pMOrdReq.iDiscQty = atoi(Row[10]);
			pMOrdReq.iDiscQtyRem = atoi(Row[11]);
			pMOrdReq.iTotalTradedQty = atoi(Row[12]);
			pMOrdReq.fPrice = atof(Row[13]);
			pMOrdReq.CoArray[0].fTriggerPrice = atof(Row[14]);
			pMOrdReq.CoArray[1].fTriggerPrice = 0.00 ;
			pMOrdReq.fOrderNum = atof(Row[0]);
			pMOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pMOrdReq.cHandleInst = '1';
			pMOrdReq.iStratergyId= STRG_MTM_SQR_OFF ;
			pMOrdReq.cProCli = Row[19][0];
			pMOrdReq.CoArray[0].iLegValue = LEG_1 ;
			pMOrdReq.fSLTikAbsValue = atof(Row[26]);
			pMOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pMOrdReq.fTrailingSLValue = 0.00 ;
			pMOrdReq.fAlgoOrderNo = 0.00 ;
			pMOrdReq.iNoOfLeg = 1 ;
			pMOrdReq.iMinFillQty = atoi(Row[18]) ;
			pMOrdReq.cSLFlag  =  Row[28][0];
			pMOrdReq.cPBFlag  = Row[29][0];
			pMOrdReq.cAvgLtpFlg = 0;
			pMOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pMOrdReq.sRemarks ,"ORDERS CANCELLED FOR MTM BREACH",REMARKS_LEN);
			pMOrdReq.cUserType = ADMIN_TYPE;

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pMOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pMOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pMOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pMOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			pMOrdReq.cMarkProFlag= Row[33][0];
			pMOrdReq.fMarkProVal= atof(Row[34]);
			pMOrdReq.cParticipantType= Row[31][0];
			strncpy(pMOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pMOrdReq.cGTCFlag= Row[35][0];
			pMOrdReq.cEncashFlag= Row[36][0];
			pMOrdReq.iGrpId = atoi(Row[37]);
			strncpy(pMOrdReq.sPanID,Row[30],INT_PAN_LEN);


			logDebug2(" pMOrdReq.CoArray[0].cBuySellInd :%c: ",pMOrdReq.CoArray[0].cBuySellInd);
			logDebug2("pMOrdReq.CoArray[0].fTriggerPrice :%f:",pMOrdReq.CoArray[0].fTriggerPrice);
			logDebug2("pMOrdReq.CoArray[1].fTriggerPrice :%f:",pMOrdReq.CoArray[1].fTriggerPrice);
			logDebug2(" pMOrdReq.fOrderNum :%f: ",pMOrdReq.fOrderNum);
			logDebug2(" pMOrdReq.sClientId :%s: ",pMOrdReq.sClientId);

			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pMOrdReq,sizeof(struct CO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fMcxCoOrdExit [EXIT]");
	return TRUE;
}


BOOL fMcxBoOrdExit (CHAR *sSecId, CHAR *sClientId)
{
	logTimestamp("fMcxBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	logDebug2("sClientId :%s:",sClientId);
	CHAR sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);


	LONG32  iNoOfRec = 0 ;
	LONG32  i = 0;

	struct  BO_ORDER_REQUEST   pMOrdReq;
	sprintf(sSelQry,"SELECT COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_SCRIP_CODE,\
			COMM_MKT_TYPE,\
			COMM_EXCH_ID,\
			COMM_ENTITY_ID,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_VALIDITY,\
			COMM_ORDER_TYPE,\
			COMM_USER_ID,\
			COMM_MIN_FILL_QTY,\
			COMM_PRO_CLIENT,\
			COMM_USER_TYPE,\
			COMM_REMARKS,\
			COMM_SOURCE_FLG,\
			COMM_PRODUCT_ID,\
			COMM_MSG_CODE,\
			COMM_SEGMENT ,\
			COMM_SL_ABSTICK_VALUE ,\
			COMM_PR_ABSTICK_VALUE ,\
			COMM_SL_AT_FLAG ,\
			COMM_PR_ST_FLAG ,\
			COMM_PAN_NO,\
			COMM_PARTICIPANT_TYPE,\
			COMM_SETTLOR,\
			COM_MKT_PROTECT_FLG,\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG,\
			COMM_GROUP_ID \
			FROM    COMM_ORDERS A\
			WHERE   A.COMM_STATUS IN (\'%c\',\'%c\') \
			AND     A.COMM_PRODUCT_ID = \'%c\' \
			AND     A.COMM_LEG_NO =   %d \
			AND     A.COMM_OMS_ALGO_ORDER_NO = -1 \
			AND     A.COMM_SERIAL_NO = (SELECT MAX(B.COMM_SERIAL_NO) FROM COMM_ORDERS B WHERE B.COMM_ORDER_NO = A.COMM_ORDER_NO AND B.COMM_LEG_NO = %d )\  
			AND A.COMM_CLIENT_ID = \"%s\" AND A.COMM_SEGMENT %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,sClientId,sWhereClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error in fMcxBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fMcxBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pMOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pMOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pMOrdReq.ReqHeader.iUserId = iUserId; 
			pMOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pMOrdReq.ReqHeader.cSegment = Row[25][0];
			pMOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pMOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pMOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);

			strncpy(pMOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pMOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pMOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pMOrdReq.cProductId= Row[23][0];
			pMOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pMOrdReq.iOrderType = atoi(Row[16]);

			pMOrdReq.iOrderValidity = iOrderVal;
			pMOrdReq.fAlgoOrderNo   = -1 ;
			pMOrdReq.iTotalQty = atoi(Row[8]);
			pMOrdReq.iTotalQtyRem = atoi(Row[8]);
			pMOrdReq.iDiscQty = atoi(Row[10]);
			pMOrdReq.iDiscQtyRem = atoi(Row[11]);
			pMOrdReq.iTotalTradedQty = atoi(Row[12]);
			pMOrdReq.fPrice = atof(Row[13]);
			pMOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pMOrdReq.fOrderNum = atof(Row[0]);
			pMOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pMOrdReq.cHandleInst = '1';
			pMOrdReq.iStratergyId= STRG_MTM_SQR_OFF;
			pMOrdReq.cProCli = Row[19][0];
			pMOrdReq.cUserType = ADMIN_TYPE ;
			pMOrdReq.BoArray[0].iLegValue = LEG_1 ;
			pMOrdReq.fSLTikAbsValue = atof(Row[26]);
			pMOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pMOrdReq.cSLFlag  =  Row[28][0];
			pMOrdReq.cPBFlag  = Row[29][0];
			pMOrdReq.cFlag    = '0';
			pMOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;

			strncpy(pMOrdReq.sRemarks ,"ORDERS CANCELLED FOR MTM BREACH",REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pMOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pMOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pMOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pMOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pMOrdReq.cMarkProFlag= Row[33][0];
			pMOrdReq.fMarkProVal= atof(Row[34]);
			pMOrdReq.cParticipantType= Row[31][0];
			strncpy(pMOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pMOrdReq.cGTCFlag= Row[35][0];
			pMOrdReq.cEncashFlag= Row[36][0];
			pMOrdReq.iGrpId= atoi(Row[37]);
			strncpy(pMOrdReq.sPanID,Row[30],INT_PAN_LEN);
			logDebug2(" pMOrdReq.BoArray[0].cBuySellInd :%c: ",pMOrdReq.BoArray[0].cBuySellInd);
			logDebug2(" pMOrdReq.fOrderNum :%f: ",pMOrdReq.fOrderNum);
			logDebug2(" pMOrdReq.sClientId :%s: ",pMOrdReq.sClientId);

			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pMOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fMcxBoOrdExit [EXIT]");
	return TRUE;
}

BOOL fEqBoOrdExit (CHAR *sSecId,CHAR *sClientId)
{
	logTimestamp("fEqBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	logDebug2("sSecId :%s:",sSecId);
	logDebug2("sClientId:%s:",sClientId);
	CHAR sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);


	LONG32  iNoOfRec = 0 ;
	LONG32  i = 0;

	struct  BO_ORDER_REQUEST   pEOrdReq;
	sprintf(sSelQry,"SELECT EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_SCRIP_CODE,\
			EQ_MKT_TYPE,\
			EQ_EXCH_ID,\
			EQ_ENTITY_ID,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_VALIDITY,\
			EQ_ORDER_TYPE,\
			EQ_USER_ID,\
			EQ_MIN_FILL_QTY,\
			EQ_PRO_CLIENT,\
			EQ_USER_TYPE,\
			EQ_REMARKS,\
			EQ_SOURCE_FLG,\
			EQ_PRODUCT_ID,\
			EQ_MSG_CODE,\
			EQ_SEGMENT ,\
			EQ_SL_ABSTICK_VALUE ,\
			EQ_PR_ABSTICK_VALUE ,\
			EQ_SL_AT_FLAG ,\
			EQ_PR_ST_FLAG ,\
			EQ_PAN_NO,\
			EQ_PARTICIPANT_TYPE,\
			EQ_SETTLOR,\
			EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,\
			EQ_GTC_FLG,\
			EQ_ENCASH_FLG,\
			EQ_GROUP_ID \
			FROM    EQ_ORDERS A\
			WHERE   A.EQ_ORD_STATUS IN (\'%c\',\'%c\') \
			AND     A.EQ_PRODUCT_ID = \'%c\' \
			AND     A.EQ_LEG_NO =   %d \
			AND     A.EQ_ALGO_ORDER_NO = -1 \
			AND     A.EQ_SERIAL_NO = (SELECT MAX(B.EQ_SERIAL_NO) FROM EQ_ORDERS B WHERE B.EQ_ORDER_NO = A.EQ_ORDER_NO AND B.EQ_LEG_NO = %d )\
			AND  A.EQ_SCRIP_CODE = \"%s\" AND A.EQ_CLIENT_ID = \"%s\" AND A.EQ_SEGMENT %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,sSecId,sClientId,sWhereClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error in fEqBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("fEqBoOrdExit : Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pEOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pEOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pEOrdReq.ReqHeader.iUserId = iUserId; 
			pEOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pEOrdReq.ReqHeader.cSegment = Row[25][0];
			pEOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pEOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pEOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);
			strncpy(pEOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);	
			strncpy(pEOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pEOrdReq.sClientId,Row[6],CLIENT_ID_LEN);

			pEOrdReq.cProductId= Row[23][0];
			pEOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pEOrdReq.iOrderType = atoi(Row[16]);
			pEOrdReq.iOrderValidity = iOrderVal;
			pEOrdReq.fAlgoOrderNo   = -1 ;
			pEOrdReq.iTotalQty = atoi(Row[8]);
			pEOrdReq.iTotalQtyRem = atoi(Row[8]);
			pEOrdReq.iDiscQty = atoi(Row[10]);
			pEOrdReq.iDiscQtyRem = atoi(Row[11]);
			pEOrdReq.iTotalTradedQty = atoi(Row[12]);
			pEOrdReq.fPrice = atof(Row[13]);
			pEOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pEOrdReq.fOrderNum = atof(Row[0]);
			pEOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pEOrdReq.cHandleInst = Row[19][0];
			pEOrdReq.iStratergyId= STRG_CKT_SQR_OFF;
			pEOrdReq.cProCli = Row[19][0];
			pEOrdReq.cUserType = ADMIN_TYPE ;
			pEOrdReq.BoArray[0].iLegValue = LEG_1 ;
			pEOrdReq.fSLTikAbsValue = atof(Row[26]);
			pEOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pEOrdReq.cSLFlag  =  Row[28][0];
			pEOrdReq.cPBFlag  = Row[29][0];
			pEOrdReq.cFlag    = '0';
			pEOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pEOrdReq.sRemarks ,"ORDERS CANCELLED FOR CKT LIMIT",REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pEOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pEOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pEOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pEOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}
			pEOrdReq.cMarkProFlag= Row[33][0];
			pEOrdReq.fMarkProVal= atof(Row[34]);
			pEOrdReq.cParticipantType= Row[31][0];
			strncpy(pEOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pEOrdReq.cGTCFlag= Row[35][0];
			pEOrdReq.cEncashFlag= Row[36][0];
			pEOrdReq.iGrpId= atoi(Row[37]);
			strncpy(pEOrdReq.sPanID,Row[30],INT_PAN_LEN);
			logDebug2(" pEOrdReq.BoArray[0].cBuySellInd :%c: ",pEOrdReq.BoArray[0].cBuySellInd);
			logDebug2(" pEOrdReq.fOrderNum :%f: ",pEOrdReq.fOrderNum);
			logDebug2(" pEOrdReq.sClientId :%s: ",pEOrdReq.sClientId);
			logDebug2("iGroupId :%d:",pEOrdReq.iGrpId);

			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pEOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fEqBoOrdExit [EXIT]");
	return TRUE;
}

BOOL fDrvBoOrdExit (CHAR *sSecId,CHAR *sClientId)
{
	logTimestamp("fDrvBoOrdExit [ENTRY]");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32          iNoOfRec = 0;
	LONG32          i = 0;
	logDebug2("sClientId :%s:",sClientId);
	CHAR sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);


	struct  BO_ORDER_REQUEST   pDrOrdReq;
	sprintf(sSelQry,"SELECT DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_SCRIP_CODE,\
			DRV_MKT_TYPE,\
			DRV_EXCH_ID,\
			DRV_ENTITY_ID,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_VALIDITY,\
			DRV_ORDER_TYPE,\
			DRV_USER_ID,\
			DRV_MIN_FILL_QTY,\
			DRV_PRO_CLIENT,\
			DRV_USER_TYPE,\
			DRV_REMARKS,\
			DRV_SOURCE_FLG,\
			DRV_PRODUCT_ID,\
			DRV_MSG_CODE,\
			DRV_SEGMENT\
			DRV_SL_ABSTICK_VALUE ,\
			DRV_PR_ABSTICK_VALUE ,\
			DRV_SL_AT_FLAG ,\
			DRV_PR_ST_FLAG ,\
			DRV_PAN_NO,\
			DRV_PARTICIPANT_TYPE,\
			DRV_SETTLOR,\
			DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,\
			DRV_GTC_FLG,\
			DRV_ENCASH_FLG,\
			DRV_GROUP_ID \
			FROM    DRV_ORDERS A\
			WHERE   A.DRV_STATUS IN (\'%c\',\'%c\') \
			AND     A.DRV_PRODUCT_ID = \'%c\' \
			AND     A.DRV_LEG_NO =   %d \
			AND     A.DRV_OMS_ALGO_ORD_NO = -1\
			AND     A.DRV_SERIAL_NO = (SELECT MAX(B.DRV_SERIAL_NO) FROM DRV_ORDERS B WHERE B.DRV_ORDER_NO = A.DRV_ORDER_NO AND B.DRV_LEG_NO = %d )\
			AND A.DRV_CLIENT_ID = \"%s\" AND A.DRV_SEGMENT %s",\
			EXCH_CONFIRM_STATUS,TRADED_STATUS,PROD_BRACKET,LEG_1,LEG_1,sClientId,sWhereClause);

	logDebug3("sSelQry :%s:",sSelQry);

	if(mysql_query(DB_MTM,sSelQry) != SUCCESS)
	{
		sql_Error(DB_MTM);
		logSqlFatal("Error in fDrvBoOrdExit Query.");
		exit(ERROR);
	}

	Res = mysql_store_result(DB_MTM);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2(" fDrvBoOrdExit :Rows returned from Database = :%d:",iNoOfRec);

	for(i = 0; i < iNoOfRec ; i ++)
	{
		logDebug2("-------- iCount = %d  ----------",i);
		if(Row = mysql_fetch_row(Res))
		{
			memset(&pDrOrdReq,'\0',sizeof(struct BO_ORDER_REQUEST));
			strncpy(pDrOrdReq.ReqHeader.sExcgId,Row[4],EXCHANGE_LEN);
			pDrOrdReq.ReqHeader.iUserId = iUserId;
			pDrOrdReq.ReqHeader.cSource= SOURCE_ADMIN ;
			pDrOrdReq.ReqHeader.cSegment = Row[25][0];
			pDrOrdReq.ReqHeader.iSeqNo = atoi(Row[37]);
			pDrOrdReq.ReqHeader.iMsgCode = TC_INT_BO_ORDER_EXIT;
			pDrOrdReq.ReqHeader.iMsgLength= sizeof(struct BO_ORDER_REQUEST);



			strncpy(pDrOrdReq.sSecurityId, Row[2],SECURITY_ID_LEN);
			strncpy(pDrOrdReq.sEntityId,sAdmin,ENTITY_ID_LEN);
			strncpy(pDrOrdReq.sClientId,Row[6],CLIENT_ID_LEN);


			pDrOrdReq.cProductId= Row[23][0];

			pDrOrdReq.BoArray[0].cBuySellInd = Row[7][0];
			pDrOrdReq.iOrderType = atoi(Row[16]);
			pDrOrdReq.iOrderValidity = iOrderVal;
			pDrOrdReq.iTotalQty = atoi(Row[8]);
			pDrOrdReq.iTotalQtyRem = atoi(Row[8]);
			pDrOrdReq.iDiscQty = atoi(Row[10]);
			pDrOrdReq.iDiscQtyRem = atoi(Row[11]);
			pDrOrdReq.iTotalTradedQty = atoi(Row[12]);
			pDrOrdReq.fPrice = atof(Row[13]);
			pDrOrdReq.BoArray[0].fTriggerPrice = atof(Row[14]);
			pDrOrdReq.fOrderNum = atof(Row[0]);
			pDrOrdReq.iSerialNum = atoi(Row[1]) + 1;
			pDrOrdReq.cHandleInst = Row[19][0];
			pDrOrdReq.iStratergyId= STRG_MTM_SQR_OFF ;
			pDrOrdReq.cProCli = Row[19][0];
			pDrOrdReq.cUserType = ADMIN_TYPE ;
			pDrOrdReq.BoArray[0].iLegValue = LEG_1 ;

			pDrOrdReq.fSLTikAbsValue = atof(Row[26]);
			pDrOrdReq.fPBTikAbsValue  = atof(Row[27]);
			pDrOrdReq.cSLFlag  =  Row[28][0];
			pDrOrdReq.cPBFlag  = Row[29][0];
			pDrOrdReq.cFlag =  '0' ;
			pDrOrdReq.cOffMarketFlg= OFF_ORD_DISABLE;
			strncpy(pDrOrdReq.sRemarks ,"ORDERS CANCELLED FOR MTM BREACH",REMARKS_LEN);

			if(strcmp(Row[3],MKT_TYPE_NL)== 0)
			{
				pDrOrdReq.iMktType = NORMAL_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_OL) == 0)
			{
				pDrOrdReq.iMktType = ODDLOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_SP)== 0)
			{
				pDrOrdReq.iMktType = SPOT_MARKET;
			}
			else if(strcmp(Row[3],MKT_TYPE_AU) == 0)
			{
				pDrOrdReq.iMktType = AUCTION_MARKET;
			}
			else
			{
				logDebug2(" %s ",Row[3]);
			}

			pDrOrdReq.cMarkProFlag= Row[33][0];
			pDrOrdReq.fMarkProVal= atof(Row[34]);
			pDrOrdReq.cParticipantType= Row[31][0];
			strncpy(pDrOrdReq.sSettlor,Row[32],SETTLOR_LEN);
			pDrOrdReq.cGTCFlag= Row[35][0];
			pDrOrdReq.cEncashFlag= Row[36][0];
			pDrOrdReq.iGrpId= atoi(Row[37]);
			strncpy(pDrOrdReq.sPanID,Row[30],INT_PAN_LEN);

			logDebug2("pDrOrdReq.BoArray[0].cBuySellInd :%c:",pDrOrdReq.BoArray[0].cBuySellInd);
			logDebug2("pDrOrdReq.fOrderNum = %f ",pDrOrdReq.fOrderNum);
			logDebug2("pDrOrdReq.sClientId = %s",pDrOrdReq.sClientId);
			if(WriteMsgQ(iIntSqrOffToMemMap,(CHAR *)&pDrOrdReq,sizeof(struct BO_ORDER_REQUEST),1) != TRUE)
			{
				perror("Error WriteMsgQ");
				mysql_free_result(Res);
				mysql_close(DB_MTM);
				exit(ERROR);
			}
		}
	}
	logTimestamp("fDrvBoOrdExit [EXIT]");
	return TRUE;
}



void OpenMsgQue()
{
	logTimestamp("Entry : [OpenMsgQue]");
	if((iIntSqrOffToMemMap =  OpenMsgQ(IntSqrOffToMemMap)) == ERROR)
	{
		logFatal("Error in Opening IntSqrOffToMemMap MQ ");
		exit(ERROR);
	}

	logDebug2("iTrdRtrToD2C         = %d ",RelToOrdRtr);
	/*
	   if (( iMTMToOrdCanReq = OpenMsgQ (MTMToOrdCanReq )) == ERROR)
	   {
	   perror("OpenMsgQ2 ...Parent MTMToOrdCanReq  failed ");
	   exit(ERROR);
	   }
	   logDebug2("SucessFully Created  RelToOrdRtr key = %d iOrdSrvToTrdRtr:%d:",iIntSqrOffToMemMap,iMTMToOrdCanReq);
	   */

	logTimestamp("Exit : [OpenMsgQue]");
}


