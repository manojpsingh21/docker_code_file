#include "Log.h"
#include "errno.h"

int logLevel = 0;
int logLevelSet = 0;
static int logLevelGen = 0;

FILE *logFile;
extern int LogTimeStamp (char * );

CHAR  logTime[DATE_TIME_LEN];

LONG32 SetLogLevel(LONG32 level)
{
	LONG32 *shmLevel;

	LockShm(LogLevelShm);
	shmLevel = (LONG32 *) OpenSharedMemory( LogLevelShm ,LogLevelShm_SIZE );
	if( shmLevel ==(LONG32 *)ERROR)
	{
		// perror("Error in Opening LogLevelShm");
		logLevel = 0;
		UnLockShm(LogLevelShm);
		return FALSE;
	}

	printf("Changing log level from %d to %d\n", *shmLevel, level);
	*shmLevel = level;

	logLevel = *shmLevel;
	logLevelSet = 0;
	if (CloseSharedMemory(shmLevel) == ERROR)
	{
		// printf("Error Closing Shared Memory LogLevelShm");
		UnLockShm(LogLevelShm);
		return FALSE;
	}
	UnLockShm(LogLevelShm);
	return TRUE;
}



int GetLogLevel()
{
	if( !logLevelSet )
	{
		int *shmLevel;
		if((shmLevel = (int *) OpenSharedMemory( LogLevelShm ,LogLevelShm_SIZE )) ==(LONG32 *)ERROR)
		{
			perror("Error in Opening LogLevelShm");
			logLevel = 0;
			return 0;
		}
		logLevel = *shmLevel;
		/**** printf("Log Level Is %d\n", logLevel); ****/
		logLevelSet = 1;
		CloseSharedMemory(shmLevel);
	}
	return 1;
}

/* log with timestamp */
void logTimestamp (const char *fmt, ...)
{
	va_list ap;
	CHAR buffer[LOG_TIMESTAMP_LENGTH];
	CHAR chktime[DATE_TIME_LEN];
	CHAR message[LOG_BUFFER_LENGTH];
	struct timeval tv;
	time_t curtime;
	gettimeofday(&tv, NULL);
	curtime=tv.tv_sec;

	GetLogLevel();

	strftime(chktime, DATE_TIME_LEN, "%d:%m:%Y", localtime(&curtime));
	if ( strcmp(chktime,logTime))
	{
		logLevelSet = 0;
		GetLogLevel();
	}

	strftime(buffer, LOG_TIMESTAMP_LENGTH, "%d:%m:%Y %T", localtime(&curtime));
	va_start(ap, fmt);
	vsprintf(message, fmt, ap);
	va_end(ap);
	printf("TIMESTAMP:%s %ld %s\n", buffer, tv.tv_usec, message);
	return;
}
/****/
void logFileTimestamp (const char *fmt, ...)
{
	printf("Inside logFileTimestamp");

	va_list ap;
	int Retval;
	CHAR buffer[LOG_TIMESTAMP_LENGTH];
	CHAR chktime[DATE_TIME_LEN];
	CHAR message[LOG_BUFFER_LENGTH];
	struct timeval tv;
	time_t curtime;
	if((logFile=fopen("../Log/TimeStamp.txt","a"))==NULL)
	{
		perror("Error in file open");
		exit(0);
	}


	gettimeofday(&tv, NULL);
	curtime=tv.tv_sec;

	GetLogLevel();

	strftime(chktime, DATE_TIME_LEN, "%d:%m:%Y", localtime(&curtime));
	if ( strcmp(chktime,logTime))
	{
		logLevelSet = 0;
		GetLogLevel();
	}

	strftime(buffer, LOG_TIMESTAMP_LENGTH, "%d:%m:%Y %T", localtime(&curtime));
	va_start(ap, fmt);
	vsprintf(message, fmt, ap);
	va_end(ap);
	printf("TIMESTAMP:%s %ld %s\n", buffer, tv.tv_usec, message);
	Retval = fprintf(logFile,"TIMESTAMP:%s %ld %s\n", buffer, tv.tv_usec, message);	

	if(Retval <0)
	{
		perror("the perror ");
	}
	fclose(logFile);
	return (0);
}
/*********/
/* log a debug message */

/* log a debug message */

	void
logDebug1 (const char *fmt, ...)
{

	GetLogLevel();
	if( logLevel >= 1 )
	{
		va_list ap;
		char message[LOG_BUFFER_LENGTH];

		va_start(ap, fmt);
		vsprintf(message, fmt, ap);
		printf("DEBUG1: %s\n", message);
		va_end(ap);
	}
	return;
}

	void
logDebug2 (const char *fmt, ...)
{
	GetLogLevel();
	if( logLevel >= 2 )
	{
		va_list ap;
		char message[LOG_BUFFER_LENGTH];
		va_start(ap, fmt);

		vsprintf(message, fmt, ap);
		printf("DEBUG2: %s\n", message);

		va_end(ap);
	}
	return;
}
	void
logDebug3 (const char *fmt, ...)
{
	GetLogLevel();
	if( logLevel >= 3 )
	{
		va_list ap;
		char message[LOG_BUFFER_LENGTH];
		va_start(ap, fmt);

		vsprintf(message, fmt, ap);
		printf("DEBUG3: %s\n", message);

		va_end(ap);
	}
	return;
}
	void
logDebug4 (const char *fmt, ...)
{
	GetLogLevel();
	if( logLevel >= 4 )
	{
		va_list ap;
		char message[LOG_BUFFER_LENGTH];
		va_start(ap, fmt);

		vsprintf(message, fmt, ap);
		printf("DEBUG4: %s\n", message);

		va_end(ap);
	}
	return;
}
/* log an informational message */

	void
logInfo (const char *fmt, ...)
{
	va_list ap;
	char message[LOG_BUFFER_LENGTH];

	GetLogLevel();
	va_start(ap, fmt);
	vsprintf(message, fmt, ap);
	printf("INFO: %s\n", message);

	va_end(ap);
	return;
}

/* log a warning condition */

	void
logWarn (const char *fmt, ...)
{
	va_list ap;
	char message[LOG_BUFFER_LENGTH];

	GetLogLevel();
	va_start(ap, fmt);


	vsprintf(message, fmt, ap);
	printf("WARN: %s\n", message);

	va_end(ap);

	return;
}

/* log an error condition */

	void
logError (const char *fmt, ...)
{
	va_list ap;
	char message[LOG_BUFFER_LENGTH];

	GetLogLevel();
	va_start(ap, fmt);


	vsprintf(message, fmt, ap);
	printf("ERROR: %s\n", message);

	va_end(ap);

	return;
}
/* log a fatal condition */

	void
logFatal (const char *fmt, ...)
{
	va_list ap;
	char message[LOG_BUFFER_LENGTH];

	GetLogLevel();
	va_start(ap, fmt);


	vsprintf(message, fmt, ap);
	printf("FATAL: %s\n", message);

	va_end(ap);

	return;
}

void logSqlFatal (const char *fmt, ...)
{
	va_list ap;
	char message[LOG_BUFFER_LENGTH];

	GetLogLevel();
	va_start(ap, fmt);


	vsprintf(message, fmt, ap);
	printf("SQLFATAL: %s\n", message);

	va_end(ap);

	return;
}

	void
logPError (const char *fmt, ...)
{
	va_list ap;
	char message[LOG_BUFFER_LENGTH];

	GetLogLevel();
	va_start(ap, fmt);


	vsprintf(message, fmt, ap);
	if ( errno != 0 )
	{
		printf("FATAL:%s:%d-%s\n", message,errno,strerror(errno));
	}
	va_end(ap);

	return;
}

	void
logPrintf (const char *fmt, ...)
{
	GetLogLevel();
	if( logLevel >= 0 )
	{
		va_list ap;
		char message[LOG_BUFFER_LENGTH];

		va_start(ap, fmt);

		vsprintf(message, fmt, ap);
		printf("%s",message);

		va_end(ap);
	}
	return;
}

double  logGetTime ()
{
	/***
	  struct timeval tv;
	  double iTime;	

	  gettimeofday(&tv, NULL);
	  iTime= (double) ((tv.tv_sec*1000000)+tv.tv_usec);
	  printf("\n getime :%lf:\n",iTime);	

	//return (tv.tv_sec*1000000)+tv.tv_usec;

	return iTime;
	 ***/
	return 0;
}

int fLogEQConFatal ( char * ProgName , char * Message )
{
	FILE *fp;
	char   TimeStamp[100];
	char   sLogConfile[30];

	//logTimestamp ( TimeStamp );
	if(LockShm ( LogFatalShm ) == ERROR )
	{
		printf ("\n Error in getting Lock \n");
		return (ERROR );
	}


	if ( ( fp = fopen (NSE_CM_CONN_ERR_FILE, "a")) == NULL )
	{
		printf ( "\n Error in opening File \n");
		return (ERROR );
	}
	fprintf ( fp , " %s:\t%s\t%s\n ",TimeStamp,ProgName,Message );
	if (  fclose(fp) == EOF )
	{
		printf ( "\n Error in closing File \n");
		return (ERROR );
	}
	if(UnLockShm ( LogFatalShm ) == ERROR )
	{
		printf ("\n Error in releasing Lock \n");
		return (ERROR );
	}
	return ( TRUE );
}

int fLogFoConFatal ( char * ProgName , char * Message )
{
	FILE *fp;
	char   TimeStamp[100];
	char   sLogConfile[30];

	logTimestamp ( TimeStamp );
	if(LockShm ( LogFatalShm ) == ERROR )
	{
		printf ("\n Error in getting Lock \n");
		return (ERROR );
	}


	if ( ( fp = fopen (NSE_FO_CONN_ERR_FILE, "a")) == NULL )
	{
		printf ( "\n Error in opening File \n");
		return (ERROR );
	}
	fprintf ( fp , " %s:\t%s\t%s\n ",TimeStamp,ProgName,Message );
	if (  fclose(fp) == EOF )
	{
		printf ( "\n Error in closing File \n");
		return (ERROR );
	}
	if(UnLockShm ( LogFatalShm ) == ERROR )
	{
		printf ("\n Error in releasing Lock \n");
		return (ERROR );
	}
	return ( TRUE );
}

int fLogCDConFatal ( char * ProgName , char * Message )
{
	FILE *fp;
	char   TimeStamp[100];
	char   sLogConfile[30];

	logTimestamp ( TimeStamp );
	if(LockShm ( LogFatalShm ) == ERROR )
	{
		printf ("\n Error in getting Lock \n");
		return (ERROR );
	}


	if ( ( fp = fopen (NSE_CD_CONN_ERR_FILE, "a")) == NULL )
	{
		printf ( "\n Error in opening File \n");
		return (ERROR );
	}
	fprintf ( fp , " %s:\t%s\t%s\n ",TimeStamp,ProgName,Message );
	if (  fclose(fp) == EOF )
	{
		printf ( "\n Error in closing File \n");
		return (ERROR );
	}
	if(UnLockShm ( LogFatalShm ) == ERROR )
	{
		printf ("\n Error in releasing Lock \n");
		return (ERROR );
	}
	return ( TRUE );
}

