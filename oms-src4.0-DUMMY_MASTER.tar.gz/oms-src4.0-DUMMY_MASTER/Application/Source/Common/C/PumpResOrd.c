#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "rdkafka.h"
#include <stdlib.h>

LONG32 iOrdRtrToCatalystNSEEQ;
LONG32 Count = 0;

MYSQL *OdrConn;
BOOL          iKafkaMsgFlag=TRUE;
rd_kafka_t *KfConn;
rd_kafka_t *KfConn1;
CHAR	sKafkaTopic[100];


main()//int (argc, char argv[])
{
	int ich,rw;
        char sClientID[CLIENT_ID_LEN];
        char statement[200];
        double fOrderNum;
        int iSerialNum;
        int  iMsgcode ,iQty = 0;
        char bs = 'B';
        double fPrice;


        MYSQL_RES *result;
        MYSQL_ROW row;
        //slee = argv[1];
        printf("\n 3");

        struct ORDER_RESPONSE  pOrdReq;

        memset(&pOrdReq,'\0',sizeof(struct ORDER_RESPONSE));

	
	memset(sKafkaTopic,'\0',100);
        if(iKafkaMsgFlag == TRUE)
        {
                if((getenv("KAFKA_NOTIFY_TOPIC") != NULL ) && strlen(getenv("KAFKA_NOTIFY_TOPIC") ) != 0)
                {
                        strcpy(sKafkaTopic,getenv("KAFKA_NOTIFY_TOPIC") );
                        KfConn = KafkaConProducer(getenv("KAFKA_NOTIFY_TOPIC"));
                        //KfConn1= KafkaConProducer(KF_OMS_COOKED_DATA);
                }
                else
                {
                        iKafkaMsgFlag = FALSE;
                }
        }	
	// Header
	pOrdReq.IntRespHeader.iMsgCode=2073;
	pOrdReq.IntRespHeader.iSeqNo=2;
	pOrdReq.IntRespHeader.iMsgLength= sizeof (struct ORDER_RESPONSE) ;
	strncpy(pOrdReq.IntRespHeader.sExcgId,"NSE",EXCHANGE_LEN);
	pOrdReq.IntRespHeader.iErrorId=0;
	pOrdReq.IntRespHeader.iUserId=555;
	pOrdReq.IntRespHeader.cSource='A';
	pOrdReq.IntRespHeader.iTimeStamp = 1344425032;
	pOrdReq.IntRespHeader.cSegment= 'E';
	
	// body
		strncpy(pOrdReq.sSecurityId,"1594",SECURITY_ID_LEN);     
		strncpy(pOrdReq.sEntityId,"MA134",ENTITY_ID_LEN);         
		strncpy(pOrdReq.sClientId,"MA134",CLIENT_ID_LEN);         
		strncpy(pOrdReq.sExchOrderID,"1100000000020990",EXCH_ORDER_NO_LEN);      
		pOrdReq.cProductId='C';
                pOrdReq.cBuyOrSell='B';
                pOrdReq.iOrderType=1;
                pOrdReq.iOrderValidity=0;
                pOrdReq.iDiscQty=0;
                pOrdReq.iDiscQtyRem=0;
                pOrdReq.iTotalQtyRem=10;
                pOrdReq.iTotalQty=10;
                pOrdReq.iLastTradedQty=0;
                pOrdReq.iTotalTradedQty=0;
                pOrdReq.iMinFillQty=0;
                pOrdReq.fPrice=0.000000;
                pOrdReq.fTriggerPrice=0.000000;
                pOrdReq.fOrderNum=12208082027.000000;
                pOrdReq.iSerialNum=1;
                strncpy(pOrdReq.sTradeNo,"-1",DB_EXCH_TRD_NO_LEN);
                pOrdReq.fTradePrice=0.000000;
                pOrdReq.cHandleInst='A';
                pOrdReq.fAlgoOrderNo=0.000000;
                pOrdReq.iStratergyId=0;
                pOrdReq.cOffMarketFlg='0';
                pOrdReq.cProCli='C';
                pOrdReq.cUserType='C';
                strncpy(pOrdReq.sOrdEntryTime,"",DATE_TIME_LEN);
                strncpy(pOrdReq.sTransacTime,"",DATE_TIME_LEN);
                strncpy(pOrdReq.sRemarks,"",REMARKS_LEN);
                pOrdReq.iMktType=1;
                strncpy(pOrdReq.sReasonDesc,"CONFIRMED",DB_REASON_DESC_LEN);
                strncpy(pOrdReq.sGoodTillDaysDate,"",DB_DATETIME_LEN);
                pOrdReq.iLegValue=1;
                strncpy(pOrdReq.sTradeNum,"",TRADE_NO_LEN);
                pOrdReq.cMarkProFlag='N';
                pOrdReq.fMarkProVal=0.000000;
                pOrdReq.cParticipantType='B';
                strncpy(pOrdReq.sSettlor,"90144",SETTLOR_LEN);
                pOrdReq.cGTCFlag='N';
                pOrdReq.cEncashFlag='N';
                strncpy(pOrdReq.sPanID,"AVVPK6383J",INT_PAN_LEN);
                pOrdReq.iGrpId=1;
                strncpy(pOrdReq.sErrorCode,"",ERROR_CODE_LEN);
                strncpy(pOrdReq.sSmExpiryFlag,"",DB_EXPIRY_FLAG_LEN);

		//if(KafkaProducer(KfConn,sKafkaTopic,(char *)pOrdReq,sizeof(struct ORDER_RESPONSE)) != TRUE)
		if(KafkaProducer(KfConn,sKafkaTopic,&pOrdReq,sizeof(struct ORDER_RESPONSE)) != TRUE)
		{
                	logFatal("Error while message wrting");
        	}
	
		
	//	fsendata(&pOrdReq);
		
		printf("\n pOrdReq.iTotalQty :%d:",pOrdReq.iTotalQty); ;
        	printf("\n pOrdReq.iTotalQtyRem :%d:",pOrdReq.iTotalQtyRem);
       		printf("\n Serial NUMBer is %d \n",pOrdReq.iSerialNum);
	        printf("\n Order NUmber %f \n",pOrdReq.fOrderNum);
	        printf("\n Price is %lf \n",pOrdReq.fPrice);
	        printf("\n Buy/Sell is %c \n",pOrdReq.cBuyOrSell);
	        printf("\n Client Id is :%s: \n",pOrdReq.sClientId);
       		printf("\n pOrdReq.fMarkProVal Id is :%f: \n",pOrdReq.fMarkProVal);
	
} 
/*
void fsendata(struct ORDER_REQUEST *sRcvMsg){
	

	struct  ORDER_RESPONSE *pCTDReq;
	memset (&pCTDReq,'\0' ,sizeof (struct ORDER_RESPONSE));


	pCTDReq=(struct ORDER_RESPONSE *) &sRcvMsg;
	if(KafkaProducer(KfConn,sKafkaTopic,(char *)pCTDReq,sizeof(struct ORDER_RESPONSE)) != TRUE)
        {
        	logFatal("Error while message wrting");
        }

}*/
