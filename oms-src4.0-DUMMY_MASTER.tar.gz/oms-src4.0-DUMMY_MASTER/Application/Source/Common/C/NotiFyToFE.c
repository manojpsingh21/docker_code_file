#include <stdio.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"
#include <unistd.h>
#include "RedisStruct.h"
#include "hiredis.h"
#include "rdkafka.h"
#include "HashTable.h"
struct  NOTIFY_SEC_MASTER_ARRAY *Hash_ByID= NULL;


//BOOL DBSelSerNo(CHAR cSegment,DOUBLE64 *fOrdNo,LONG32 *SrNo);
LONG32          iNotiFyVal=0;
LONG32          iNotiFyVal_2=0;
LONG32          iNotiFyVal_3=0;
LONG32          iTradeNotiFyVal=0;
MYSQL           *DBCon;
LONG32		iMsgType = 0;
LONG32 	iMmapToNotifyFE;
BOOL fNotifyTradeToFE(struct ORDER_RESPONSE *Ord_Res);
BOOL fNotifyTradeToPush(struct NOTIFICATION_RESPONSE *Ord_Res);
CHAR sTradeNotfUrl[URL_LEN];
CHAR sTradeNotfUrl2[URL_LEN];
CHAR sTradeNotfUrl3[URL_LEN];
CHAR sMTMNotUrl[URL_LEN];

redisContext *RdConn;
redisReply *reply;
INT16   iExpSec;
BOOL          iKafkaMsgFlag=FALSE;	
rd_kafka_t *KfConn;
rd_kafka_t *KfConn1;
CHAR	sKafkaTopic[100];

CHAR    	cMailFlag = DISABLE ;
CHAR    	cSmsFlag  = DISABLE ;
CHAR    	cTPushFlag= DISABLE ;
redisContext    *RdConn1;
redisReply      *reply1;
LONG32          iNotifyTPush;
LONG32          iNotifySms;
LONG32          iNotifyMail;


main (int argc, char **argv)
{
	logTimestamp("Main [ENTRY]");
	setbuf(stdout , NULL);
	setbuf(stderr , NULL);
	MYSQL_RES       *Res ;
	MYSQL_ROW       Row;
	LONG32 iRow,i;
	CHAR    sConfig[MAX_QUERY_SIZE];
	CHAR    sConfig1[MAX_QUERY_SIZE];


	logDebug2("SIZE = %d",sizeof(struct INT_COMMON_RESP_HDR));
	struct  INT_REQUEST_HEADER      *pReqHeader;
	OpenMessageQueue();
	fLoadNotifyEnv();

	strncpy(sTradeNotfUrl,getenv("URL_NOTIFY"),URL_LEN);
	strncpy(sTradeNotfUrl2,getenv("URL_NOTIFY_2"),URL_LEN);
	strncpy(sTradeNotfUrl3,getenv("URL_NOTIFY_3"),URL_LEN);
	DBCon = DB_Slave_Connect();
	RdConn = RDConnect(REDIS_TYPE_ORDER_BCAST);
	iMsgType = atoi(argv[1]);
	if(RdConn == NULL)
	{
		logError("Redis not connected ");
	}

	logDebug2("%s",sTradeNotfUrl);
	logDebug2("%s",sTradeNotfUrl2);
	logDebug2("%s",sTradeNotfUrl3);

	memset(sKafkaTopic,'\0',100);
	if(iKafkaMsgFlag == TRUE)
	{
		if((getenv("KAFKA_NOTIFY_TOPIC") != NULL ) && strlen(getenv("KAFKA_NOTIFY_TOPIC") ) != 0)
		{
			strcpy(sKafkaTopic,getenv("KAFKA_NOTIFY_TOPIC") );	
			KfConn = KafkaConProducer(getenv("KAFKA_NOTIFY_TOPIC"));
			KfConn1= KafkaConProducer(KF_OMS_COOKED_DATA);
		}
		else
		{
			iKafkaMsgFlag = FALSE;
		}	
	}

	memset(sConfig,'\0',MAX_QUERY_SIZE);
	sprintf(sConfig, "select CFG_PARAM_VALUE from CONFIG_SMS_EMAIL where CFG_PARAM_NAME in ('TradeMailFlag','TradeSmsFlag','TradeTPushFlag') order by CFG_PARAM_NAME asc ; ");
	if (mysql_query(DBCon,sConfig) != SUCCESS)
	{
		sql_Error(DBCon);
		logSqlFatal("Error Fetching CONFIG_SMS_EMAIL .");
		logInfo("Some Error with Query for using rupeeseed.env variable");
	}
	else
	{
		logDebug2("sConfig-->Query [%s]",sConfig);

		Res = mysql_store_result(DBCon);
		iRow = (mysql_num_rows(Res));
		if(iRow == 0)
		{
			mysql_free_result(Res);
			logDebug2("Zero rows selected from CONFIG_SMS_EMAIL");
			logInfo("No Row from Query. Using rupeeseed.env variable");
		}
		else
		{
			logDebug2("Number of rows Selected from CONFIG_SMS_EMAIL = :%d:",iRow);
			for(i = 0 ; i < iRow ; i ++)
			{
				if(Row = mysql_fetch_row(Res))
				{
					switch (i)
					{
						case 0 :
							cMailFlag =Row[0][0];
							logDebug2("In First Loop cMailFlag :%c:",cMailFlag);
							break;

						case 1 :
							cSmsFlag = Row[0][0];
							logDebug2("In Second Loop cSmsFlag :%c:",cSmsFlag);
							break;

						case 2 :
							cTPushFlag = Row[0][0];
							logDebug2("In Third Loop cTPushFlag :%c:",cTPushFlag);
							break;
						default :
							logDebug2("Wrong case");
							break ;
					}

				}
			}
			logDebug2("cMailFlag is %c",cMailFlag);
			logDebug2("cSmsFlag is %c",cSmsFlag);
			logDebug2("cTPushFlag is %c",cTPushFlag);

			mysql_free_result(Res);
		}
	}

	RdConn1     = RDConnect();
	if(RdConn1 == NULL)
	{
		logInfo("Redis is not connected");
	}

	memset(sConfig1,'\0',MAX_QUERY_SIZE);
	sprintf(sConfig1, "HMSET TRADE:CONFIG MAIL_FLAG %c  SMS_FLAG  %c TPUSH_FLAG %c", cMailFlag,cSmsFlag,cTPushFlag);
	logDebug2("HMSET command for SMS_MAIL :%s:",sConfig1);
	reply1 = redisCommand(RdConn1,sConfig1);
	if(reply1 == NULL) {
		logDebug2(".....Problem in Redis connection.....");

	}
	else
	{
		logDebug2(".....HMSET Successful.....");
	}
	freeReplyObject(reply1);	

	ReadMessage();
	logTimestamp("Main [EXIT]");
}/** END of main()***/

OpenMessageQueue()
{

	if((iMmapToNotifyFE=OpenMsgQ(MmapToNotifyFE)) == ERROR)
	{
		perror("OpenMsgQ ...MmapToNotifyFE");
		exit(ERROR);
	}
	logDebug2("SucessFully Created MmapToNotifyFE key = %d iMmapToNotifyFE:%d:",MmapToNotifyFE,iMmapToNotifyFE);

}/** END of OpenMessageQueue**/

BOOL ReadMessage()
{

	logTimestamp("ReadMessage [ENTRY]");
	struct 		INT_COMMON_RESP_HDR 	pIntRespHdr;
	//CHAR		sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	CHAR		sRcvMsg[RUPEE_MAX_PACKET_SIZE];
	struct          ORDER_RESPONSE *Ord_Req;
	struct          NOTIFICATION_RESPONSE Ord_Res;
	LONG32          iMsgCode,iCount=0;
	BOOL 		iFlag;
	SHORT		iRetFlag =0;
	while(1)
	{
		//memset (&sRcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		memset (&sRcvMsg,'\0' ,sizeof (struct ORDER_RESPONSE));
		memset (&Ord_Res,'\0' ,sizeof (struct NOTIFICATION_RESPONSE));
		memset (&Ord_Req,'\0' ,sizeof (struct ORDER_RESPONSE));

		logInfo("---------==================|||||||||||||||||||||||=================---------");
		logInfo("---------==================WHILE LOOP -> Count : %i =================---------",iCount++);
		logInfo("---------==================|||||||||||||||||||||||=================---------");

		if((ReadMsgQ(iMmapToNotifyFE,&sRcvMsg,RUPEE_MAX_PACKET_SIZE, iMsgType)) != 1)
		{
			perror("Error Read Q");
			exit(ERROR);
		}

		iMsgCode = ((struct INT_COMMON_REQUEST_HDR *) sRcvMsg)->iMsgCode;

		Ord_Req = (struct ORDER_RESPONSE *) &sRcvMsg;
		iRetFlag = 0;	

		iFlag = FALSE;

		logDebug2("iMsgCode [%d]",iMsgCode);	
		logDebug2("ClientId [%s]",Ord_Req->sClientId);	
		logDebug2("Total Remaining Qty [%d]",Ord_Req->iTotalQtyRem);	
		logDebug2("Order Number [%lf]",Ord_Req->fOrderNum);	
		logDebug2("Leg Nos [%d]",Ord_Req->iLegValue);
		Ord_Req->iGrpId = GROUPID;
	
		logDebug2("GROUP ID  [%d]",Ord_Req->iGrpId);


		switch(iMsgCode)
		{
			case TC_INT_TRADE_RESP		:
			case TC_INT_OE_FREEZE_RESP      :
			case TC_INT_OC_CONF_RESP        :
			case TC_INT_OE_ERROR_RESP       :
				//case TC_INT_ORDER_REJECTION	:
			case TC_INT_RMS_OC_REJECTION	:
			case TC_INT_RMS_OM_REJECTION	:
			case TC_INT_RMS_OE_REJECTION	:
				if(iKafkaMsgFlag)
				{

					if(iMsgCode!=TC_INT_TRADE_RESP)
					{
						//calling new fmapper function  with remarks
						iRetFlag = fkafkaMapper(Ord_Req);

                                                logDebug2("Ord_Req->sRemarks = %s",Ord_Req->sRemarks );
                                                logDebug2("Ord_Req->sRemarks2 = %s",Ord_Req->sRemarks2 );
                                                logDebug2("Ord_Req->sRemarks3 = %s",Ord_Req->sRemarks3 );

					}
					if(KafkaProducer(KfConn,sKafkaTopic,(char *)Ord_Req,sizeof(struct ORDER_RESPONSE)) != TRUE)
					{
						printf("\nError while message wrting\n");
					}
				}

				iRetFlag = fMapper(Ord_Req,&Ord_Res);
				if(iRetFlag == NO_ROW)
				{
					logDebug2(" ZERO row return for Order Number  :%lf: of leg no %d",Ord_Req->fOrderNum,Ord_Req->iLegValue);	
					continue;

				}
				logDebug2("iData for client id > %s || ORDER_NO is %lf and leg No is %d",Ord_Res.sClientId,Ord_Req->fOrderNum,Ord_Req->iLegValue);

				if(iNotiFyVal_2 == 1)
				{
					if(iMsgCode == TC_INT_TRADE_RESP) 
					{
						//if(Ord_Res.iTotalQtyRem == 0)
						if(Ord_Req->iTotalQtyRem == 0){
							fNotifyTradeToPush(&Ord_Res);
						}
					}
					else {
						fNotifyTradeToPush(&Ord_Res);
					}
				}

				if(iNotifySms == TRUE || iNotifyMail == TRUE || iNotifyTPush == TRUE )
				{
					if ((iMsgCode == TC_INT_TRADE_RESP) || (iMsgCode == TC_INT_OC_CONF_RESP && ((struct ORDER_RESPONSE *) sRcvMsg)->iTotalTradedQty  != 0 ))
					{
						Ord_Req=(struct ORDER_RESPONSE *) &sRcvMsg;
						fSmsNtyTrdToFE(Ord_Req);
					}

				}else
				{
					logDebug2("NOTIFYE VIA SMS & Mail TO FE IS DISABLED");
				}



				if(iTradeNotiFyVal == 1 && iMsgCode == TC_INT_TRADE_RESP)
				{
					logDebug2("Calling Function fTradeNotifyService");
					fTradeNotifyService(&Ord_Res);

				}
				iFlag = TRUE;
				//break;

			case TC_INT_OM_CONF_RESP        :
			case TC_INT_OE_CONF_RESP        :
			case TC_INT_OC_ERROR_RESP       :
			case TC_INT_OM_ERROR_RESP       :
			case TC_INT_MKT_LMT_CONVT_RESP  :
			case TC_INT_SL_ORDER_TRIG_RESP  :		
			case TC_INT_OFF_ORDER_ENTRY_RSP :
			case TC_INT_OFF_ORDER_CANCEL_RSP:
			case TC_INT_OFF_ORDER_MODIFY_RSP:
				
				if(!iFlag){
					if(iKafkaMsgFlag)
					{
						//calling fmapper function
						iRetFlag = fkafkaMapper(Ord_Req);
						logDebug2("Ord_Req->sRemarks = %s",Ord_Req->sRemarks );
						logDebug2("Ord_Req->sRemarks2 = %s",Ord_Req->sRemarks2 );
						logDebug2("Ord_Req->sRemarks3 = %s",Ord_Req->sRemarks3 );

						
						if(KafkaProducer(KfConn,sKafkaTopic,(char *)Ord_Req,sizeof(struct ORDER_RESPONSE)) != TRUE)
						{
							printf("\nError while message wrting\n");
						}
					}
					iRetFlag = fMapper(Ord_Req,&Ord_Res);
					if(iRetFlag == NO_ROW)
					{
						logDebug2(" ZERO row return for Order Number  :%lf: of leg no %d",Ord_Req->fOrderNum,Ord_Req->iLegValue);	
						continue;
					}
				}

				logDebug2("iData for client id > %s || ORDER_NO is %lf and leg No is %d",Ord_Res.sClientId,Ord_Req->fOrderNum,Ord_Req->iLegValue);
				if(iNotiFyVal == 1)
				{
					fNotifyTradeToFE(Ord_Req);	
				}
				if(iNotiFyVal_3 == 1)
				{
					//fNotifyToFE(&Ord_Res);
					fNotifyToFE_PUB(&Ord_Res);
				}
				break;
			case TC_INT_ORDER_ENTRY_RSP:
			case TC_INT_ORDER_MODIFY_RSP:
			case TC_INT_ORDER_CANCEL_RSP:
			case TC_INT_SPRD_ORD_ENT_RSP:
			case TC_INT_SPRD_ORD_MOD_RSP:
			case TC_INT_SPRD_ORD_CAN_RSP:
			case TC_INT_OE_REJECTION:
			case TC_INT_OM_REJECTION:
			case TC_INT_OC_REJECTION:
				logDebug2("iMsgCode [%d]",iMsgCode);	
				logDebug2("ClientId [%s]",Ord_Req->sClientId);	
				logDebug2("Total Remaining Qty [%d]",Ord_Req->iTotalQtyRem);	
				logDebug2("Order Number [%lf]",Ord_Req->fOrderNum);	
				logDebug2("Leg Nos [%d]",Ord_Req->iLegValue);
				Ord_Req->iGrpId = GROUPID;	
				logDebug2("GROUP ID  [%d]",Ord_Req->iGrpId);



				if(iKafkaMsgFlag)
                                {
					iRetFlag = fkafkaMapper(Ord_Req);

					logDebug2("Ord_Req->sRemarks = %s",Ord_Req->sRemarks );
					logDebug2("Ord_Req->sRemarks2 = %s",Ord_Req->sRemarks2 );
					logDebug2("Ord_Req->sRemarks3 = %s",Ord_Req->sRemarks3 );

					logDebug2(" TC_INT_CON_DEL_RESP ");

					if(KafkaProducer(KfConn,sKafkaTopic,(char *)Ord_Req,sizeof(struct ORDER_RESPONSE)) != TRUE)
                                        {
                                                printf("\nError while message wrting\n");
                                        }
                                }
				break;


			default:
				logDebug2("Notification not configured for this msg code :%d:",iMsgCode);
				break;

		}
	} 
}



BOOL fNotifyTradeToFE(struct ORDER_RESPONSE *Ord_Res)
{
	logTimestamp("fNotifyTradesToFE [ENTRY]");
	//LONG32 iFlag = 0 ;

	//iFlag =       atoi(getenv("TRADE_RESPONSE_NOTIFICATION"));

	logDebug2("Sending Trade Notifications");
	CHAR sOrdString[MAX_COMMAND_LEN];
	CHAR sCommand[MAX_COMMAND_LEN];
	memset(sOrdString,'\0',MAX_COMMAND_LEN);
	memset(sCommand,'\0',MAX_COMMAND_LEN);
	Ord_Res->cHandleInst = 'A';
	Ord_Res->cOffMarketFlg = 'B';
	Ord_Res->cProCli = 'A';		
	//sprintf(sCmd,"%s/SendTradeToFE.py >> %s/log.TradeNotification &",getenv("PYTHON_PATH"),getenv("LOGDIR"));
	sprintf(sOrdString,"%d|%d|%d|%s|%d|%llu|%c|%d|%c|%s|%s|%s|%s|%c|%c|%d|%d|%d|%d|%d|%d|%d|%d|%d|%f|%f|%f|%d|%s|%f|%c|%f|%d|%c|%c|%c|%s|%s|%s|%d|%s|%s|%d|%s|%c|%f|%c|%s|%c|%c|%s",Ord_Res->IntRespHeader.iSeqNo,Ord_Res->IntRespHeader.iMsgLength,Ord_Res->IntRespHeader.iMsgCode,Ord_Res->IntRespHeader.sExcgId,Ord_Res->IntRespHeader.iErrorId,Ord_Res->IntRespHeader.iUserId,Ord_Res->IntRespHeader.cSource,Ord_Res->IntRespHeader.iTimeStamp,Ord_Res->IntRespHeader.cSegment,Ord_Res->sSecurityId, Ord_Res->sEntityId , Ord_Res->sClientId , Ord_Res->sExchOrderID, Ord_Res->cProductId, Ord_Res->cBuyOrSell, Ord_Res->iOrderType, Ord_Res->iOrderValidity, Ord_Res->iDiscQty, Ord_Res->iDiscQtyRem, Ord_Res->iTotalQtyRem,  Ord_Res->iTotalQty , Ord_Res->iLastTradedQty,  Ord_Res->iTotalTradedQty, Ord_Res->iMinFillQty, Ord_Res->fPrice, Ord_Res->fTriggerPrice, Ord_Res->fOrderNum , Ord_Res->iSerialNum , Ord_Res->sTradeNo, Ord_Res->fTradePrice, Ord_Res->cHandleInst, Ord_Res->fAlgoOrderNo, Ord_Res->iStratergyId, Ord_Res->cOffMarketFlg, Ord_Res->cProCli, Ord_Res->cUserType, Ord_Res->sOrdEntryTime, Ord_Res->sTransacTime, Ord_Res->sRemarks,  Ord_Res->iMktType, Ord_Res->sReasonDesc, Ord_Res->sGoodTillDaysDate, Ord_Res->iLegValue, Ord_Res->sTradeNum, Ord_Res->cMarkProFlag, Ord_Res->fMarkProVal, Ord_Res->cParticipantType, Ord_Res->sSettlor, Ord_Res->cGTCFlag, Ord_Res->cEncashFlag, Ord_Res->sPanID);
	logDebug2("sOrdString ->:%s:",sOrdString);
	sprintf(sCommand,"curl -m 5 -X POST  %s -H 'Cache-Control: no-cache' -H 'Content-Type: application/json' -d '{\"ClientId\":\"%s\",\"Data\":\"%s\"}'",sTradeNotfUrl,Ord_Res->sClientId,sOrdString);
	logDebug2("sCommand -> %s",sCommand);
	system(sCommand);
	logTimestamp("fNotifyTradesToFE [EXIT]");
	return TRUE ;


}

BOOL fNotifyTradeToPush(struct NOTIFICATION_RESPONSE *Ord_Res)
{
	logTimestamp("fNotifyTradeToPush[ENTRY]");

	logDebug2("Sending Trade Notifications");
	CHAR sOrdString[MAX_COMMAND_LEN];
	CHAR sCommand[MAX_COMMAND_LEN];
	memset(sOrdString,'\0',MAX_COMMAND_LEN);
	memset(sCommand,'\0',MAX_COMMAND_LEN);

	logDebug2("Data > %s",Ord_Res->sClientId);
	logDebug2("Txntype > %c",Ord_Res->cBuyOrSell);

	sprintf(sOrdString,"{\"client_id\":\"%s\",\"order_date_time\":\"%s\",\"last_updated_time\":\"%s\",\"order_no\":\"%s\",\"exchange\":\"%s\",\"txn_type\":\"%c\",\"segment\":\"%c\",\"instrument\":\"%s\",\"symbol\":\"%s\",\"product\":\"%c\",\"product_name\":\"%s\",\"status\":\"%s\",\"quantity\":%i,\"remaining_quantity\":%i,\"price\":\"%f\",\"trigger_price\":\"%f\",\"order_type\":\"%s\",\"disc_quantity\":%i,\"serial_no\":%i,\"security_id\":\"%s\",\"validity\":\"%s\",\"lot_size\":%i,\"traded_qty\":%i,\"dq_qty_rem\":%i,\"exch_order_no\":\"%s\",\"exch_order_time\":\"%s\",\"reason_description\":\"%s\",\"leg_no\":\"%i\",\"traded_price\":%f,\"avg_traded_price\":%f,\"pan_no\":\"%s\",\"participant_type\":\"%c\",\"mkt_pro_flag\":\"%c\",\"mkt_pro_value\":%f,\"settlor\":\"%s\",\"encash_flag\":\"%c\",\"mkt_type\":\"%s\",\"algo_ord_no\":%f,\"trailing_sl_value\":%f,\"sl_abstick_value\":%f,\"pr_abstick_value\":%f,\"off_mkt_flag\":\"%c\",\"strike_price\":\"%f\",\"expiry_date\":\"%s\",\"opt_type\":\"%s\",\"series\":\"%s\",\"remarks\":\"%s\",\"good_till_days_date\":\"%s\",\"group_id\":\"%i\",\"isin\":\"%s\",\"display_name\":\"%s\",\"exchange_inst_name\":\"%s\",\"ref_ltp\":\"%f\",\"tick_size\":\"%f\",\"algo_id\":\"%s\",\"remarks1\":\"%s\",\"remarks2\":\"%s\",\"multiplier\":%f}",Ord_Res->sClientId,Ord_Res->sOrdEntryTime,Ord_Res->sLastUpdatedTime,Ord_Res->sOrderNum,Ord_Res->sExchId,Ord_Res->cBuyOrSell,Ord_Res->cSegment,Ord_Res->sInstrument,Ord_Res->sSymbol,Ord_Res->cProductId,Ord_Res->sProduct_Name,Ord_Res->sStatus,Ord_Res->iTotalQty,Ord_Res->iTotalQtyRem,Ord_Res->fPrice,Ord_Res->fTriggerPrice,Ord_Res->sOrderType,Ord_Res->iDiscQty,Ord_Res->iSerialNum,Ord_Res->sSecurityId,Ord_Res->sOrderValidity,Ord_Res->iLotsize,Ord_Res->iTotalTradedQty,Ord_Res->iDiscQtyRem,Ord_Res->sExchOrderID,Ord_Res->sExchOrderTime,Ord_Res->sReasonDesc,Ord_Res->iLegValue,Ord_Res->fTradePrice,Ord_Res->fAvgTradePrice,Ord_Res->sPanID,Ord_Res->cParticipantType,Ord_Res->cMarkProFlag,Ord_Res->fMarkProVal,Ord_Res->sSettlor,Ord_Res->cEncashFlag,Ord_Res->sMktType,Ord_Res->fAlgoOrderNo,Ord_Res->fSLTrail,Ord_Res->fSLTickValue,Ord_Res->fPRTickValue,Ord_Res->cOffMarketFlg,Ord_Res->fStrikePrice,Ord_Res->sExpiryDate,Ord_Res->sOption_typ,Ord_Res->sSeries,Ord_Res->sRemarks,Ord_Res->sGtdDate,Ord_Res->iGrpId,Ord_Res->sIsin,Ord_Res->sCustomSym,Ord_Res->sInstrumentTyp,Ord_Res->fLtp,Ord_Res->fTickSize,Ord_Res->sAlgoID,Ord_Res->sPlatform,Ord_Res->sChannel,Ord_Res->fMultiplier);

	//logDebug2("sOrdString ->:%s:",sOrdString);
	sprintf(sCommand,"curl -m 5 -X POST  %s -H 'Cache-Control: no-cache' -H 'Content-Type: application/json' -d '%s'",sTradeNotfUrl2,sOrdString);
	logDebug2("sCommand -> %s",sCommand);
	system(sCommand);
	logTimestamp("fNotifyTradesToFE [EXIT]");
	return TRUE ;
}


BOOL fNotifyToFE(struct NOTIFICATION_RESPONSE *Ord_Res)
{
	logTimestamp("fNotifyToFE [ENTRY]");

	logDebug2("Sending Trade Notifications");
	CHAR sOrdString[sizeof(struct NOTIFICATION_RESPONSE)];
	CHAR sCommand[MAX_COMMAND_LEN];
	CHAR result[sizeof(struct NOTIFICATION_RESPONSE)];
	memset(result,'\0',sizeof(struct NOTIFICATION_RESPONSE));        
	memset(sOrdString,'\0',sizeof(struct NOTIFICATION_RESPONSE));
	memset(sCommand,'\0',MAX_COMMAND_LEN);

	logDebug2("Data >  %s",Ord_Res->sClientId);

	// sprintf(sOrdString,"{\"client_id\":\"%s\",\"order_date_time\":\"%s\",\"last_updated_time\":\"%s\",\"order_no\":\"%s\",\"exchange\":\"%s\",\"txn_type\":\"%c\",\"segment\":\"%c\",\"instrument\":\"%s\",\"symbol\":\"%s\",\"product\":\"%c\",\"product_name\":\"%s\",\"status\":\"%s\",\"quantity\":%i,\"remaining_quantity\":%i,\"price\":\"%f\",\"trigger_price\":\"%f\",\"order_type\":\"%s\",\"disc_quantity\":%i,\"serial_no\":%i,\"security_id\":\"%s\",\"validity\":\"%s\",\"lot_size\":%i,\"traded_qty\":%i,\"dq_qty_rem\":%i,\"exch_order_no\":\"%s\",\"exch_order_time\":\"%s\",\"reason_description\":\"%s\",\"leg_no\":\"%i\",\"traded_price\":%f,\"avg_traded_price\":%f,\"pan_no\":\"%s\",\"participant_type\":\"%c\",\"mkt_pro_flag\":\"%c\",\"mkt_pro_value\":%f,\"settlor\":\"%s\",\"encash_flag\":\"%c\",\"mkt_type\":\"%s\",\"algo_ord_no\":%f,\"trailing_sl_value\":%f,\"sl_abstick_value\":%f,\"pr_abstick_value\":%f,\"off_mkt_flag\":\"%c\",\"strike_price\":\"%f\",\"expiry_date\":\"%s\",\"opt_type\":\"%s\",\"series\":\"%s\",\"remarks\":\"%s\",\"good_till_days_date\":\"%s\",\"group_id\":\"%i\",\"isin\":\"%s\",\"display_name\":\"%s\",\"exchange_inst_name\":\"%s\"}",Ord_Res->sClientId,Ord_Res->sOrdEntryTime,Ord_Res->sLastUpdatedTime,Ord_Res->sOrderNum,Ord_Res->sExchId,Ord_Res->cBuyOrSell,Ord_Res->cSegment,Ord_Res->sInstrument,Ord_Res->sSymbol,Ord_Res->cProductId,Ord_Res->sProduct_Name,Ord_Res->sStatus,Ord_Res->iTotalQty,Ord_Res->iTotalQtyRem,Ord_Res->fPrice,Ord_Res->fTriggerPrice,Ord_Res->sOrderType,Ord_Res->iDiscQty,Ord_Res->iSerialNum,Ord_Res->sSecurityId,Ord_Res->sOrderValidity,Ord_Res->iLotsize,Ord_Res->iTotalTradedQty,Ord_Res->iDiscQtyRem,Ord_Res->sExchOrderID,Ord_Res->sExchOrderTime,Ord_Res->sReasonDesc,Ord_Res->iLegValue,Ord_Res->fTradePrice,Ord_Res->fAvgTradePrice,Ord_Res->sPanID,Ord_Res->cParticipantType,Ord_Res->cMarkProFlag,Ord_Res->fMarkProVal,Ord_Res->sSettlor,Ord_Res->cEncashFlag,Ord_Res->sMktType,Ord_Res->fAlgoOrderNo,Ord_Res->fSLTrail,Ord_Res->fSLTickValue,Ord_Res->fPRTickValue,Ord_Res->cOffMarketFlg,Ord_Res->fStrikePrice,Ord_Res->sExpiryDate,Ord_Res->sOption_typ,Ord_Res->sSeries,Ord_Res->sRemarks,Ord_Res->sGtdDate,Ord_Res->iGrpId,Ord_Res->sIsin,Ord_Res->sCustomSym,Ord_Res->sInstrumentTyp);


	//logDebug2("sOrdString ->:%s:",sOrdString);
	logDebug2("Struct size > %i",sizeof(struct NOTIFICATION_RESPONSE));
	logDebug2("Data >  %s",result);
	base64Encoder((char *)Ord_Res, sizeof(struct NOTIFICATION_RESPONSE),result);

	//sprintf(result,"%s",(char *)Ord_Res);
	logDebug3("Encoded string is : :%s:", result);
	//	strncpy(sOrdString,result,sizeof(struct NOTIFICATION_RESPONSE)); 
	sprintf(sOrdString,"%s",result); 

	//logDebug2("sOrdString ->:%s:",sOrdString);
	sprintf(sCommand,"curl -m 5 -X POST  %s -H 'Cache-Control: no-cache' -H 'Content-Type: application/json' -d '{\"ClientId\":\"%s\",\"Data\":\"%s\"}'",sTradeNotfUrl3,Ord_Res->sClientId,sOrdString);
	logDebug2("sCommand -> %s",sCommand);
	system(sCommand);
	logTimestamp("fNotifyTradesToFE [EXIT]");
	return TRUE ;


}

BOOL fNotifyToFE_PUB(struct NOTIFICATION_RESPONSE *Ord_Res)
{
	logTimestamp("fNotifyToFE [ENTRY]");

	logDebug2("Sending Trade Notifications");
	CHAR sOrdString[sizeof(struct NOTIFICATION_RESPONSE)];
	CHAR sCommand[MAX_COMMAND_LEN];
	CHAR result[sizeof(struct NOTIFICATION_RESPONSE)];
	CHAR sKeyValue[MAX_COMMAND_LEN];
	memset(result,'\0',sizeof(struct NOTIFICATION_RESPONSE));
	memset(sOrdString,'\0',sizeof(struct NOTIFICATION_RESPONSE));
	memset(sKeyValue,'\0',MAX_COMMAND_LEN);
	memset(sCommand,'\0',MAX_COMMAND_LEN);


	logDebug2("Data > %s",Ord_Res->sClientId);
	logDebug2("Txn > %c",Ord_Res->cBuyOrSell);
	logDebug2("Struct size > %i",sizeof(struct NOTIFICATION_RESPONSE));
	base64Encoder((char *)Ord_Res, sizeof(struct NOTIFICATION_RESPONSE),result);
	logDebug3("Encoded string is : :%s: Len is :%d:", result, strlen(result));
	sprintf(sOrdString,"%s",result);
	logDebug3("sOrdString > :%s: Len :%d:",sOrdString,strlen(sOrdString));
	sprintf(sKeyValue,"{\"ClientId\":\"%s\",\"Data\":\"%s\"}",Ord_Res->sClientId,sOrdString);
	logDebug3("sKeyValue > :%s: Len :%d:",sKeyValue,strlen(sKeyValue));
	sprintf(sCommand,"PUBLISH TRDNOTIFY %s",sKeyValue);
	logDebug2("sCommand > %s",sCommand);
	reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_ORDER_BCAST);
	logDebug2("INCR counter: %lld", reply->integer);
	logTimestamp("fNotifyTradesToFE [EXIT]");
	return TRUE ;
}

BOOL fTradeNotifyService(struct NOTIFICATION_RESPONSE *Ord_Res)
{
	logTimestamp("Entry : [fTradeNotifyService]");

	CHAR sCommand[COMMAND_LEN];
	CHAR sKeyValue[RADIS_KEY_LEN];

	memset(sCommand,'\0',COMMAND_LEN);
	memset(sKeyValue,'\0',RADIS_KEY_LEN);

	logDebug2("ExchId --> %s",Ord_Res->sExchId);
	logDebug2("Segment --> %c",Ord_Res->cSegment);
	logDebug2("SecurityId --> %s",Ord_Res->sSecurityId);
	logDebug2("ClientId --> %s",Ord_Res->sClientId);

	sprintf(sKeyValue,"%s",Ord_Res->sClientId);
	logDebug3("sKeyValue --> %s",sKeyValue);

	memset(sCommand,'\0',COMMAND_LEN);
	sprintf(sCommand,"SADD FUND_ALLOCATION_CLIENT '%s'",sKeyValue);
	logTimestamp("sCommand -> %s",sCommand);
	reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_CLEARING_MEM);

	freeReplyObject(reply);

	//sprintf(sCommand,"HMSET %s CLIENTID %s",sKeyValue,Ord_Res->sClientId);
	//logDebug2("sCommand -> %s",sCommand);
	//reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_PRICE_BCAST);	

	/*sprintf(sKeyValue,"NOTIFY:%s:%s:%c:%s:%c",Resp->sClientId,Resp->IntRespHeader.sExcgId,Resp->IntRespHeader.cSegment,Resp->sSecurityId,Resp->cProductId);
	  memset(sCommand,'\0',COMMAND_LEN);
	  sprintf(sCommand,"HMSET %s CALLFLAG Y CLIENTID %s PRODUCTID %c EXCH %s SEGMENT %c SECURITYID %s ORDERNO %f MSGCODE %d BUYSELL %c MKT_TYPE %d ",sKeyValue,Resp->sClientId,Resp->cProductId,Resp->IntRespHeader.sExcgId,Resp->IntRespHeader.cSegment,Resp->sSecurityId,Resp->fOrderNum,Resp->IntRespHeader.iMsgCode,Resp->cBuyOrSell,Resp->iMktType);

	  logTimestamp("sCommand -> %s",sCommand);
	  reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_ORDER_BCAST);
	  if(strcmp(reply->str,"OK") == 0)
	  {
	  freeReplyObject(reply);
	  memset(sCommand,'\0',COMMAND_LEN);
	  sprintf(sCommand,"SADD SET:NOTIFY:%s",sKeyValue);
	  logTimestamp("sCommand -> %s",sCommand);
	  reply = fRedisCommand(RdConn,sCommand,REDIS_TYPE_ORDER_BCAST);

	  }
	  else
	  {
	  logInfo("Something went wrong while HMSET :%s:",reply->str);
	  }
	  freeReplyObject(reply); **/
	logTimestamp("Exit  : [fTradeNotifyService]");
	return TRUE ;

}




BOOL fLoadNotifyEnv()
{
	logTimestamp("Entry : [fLoadNotifyEnv]");
	CHAR            sNotiFyVal          [ENV_VARIABLE_LEN];
	CHAR            sNotiFyVal2         [ENV_VARIABLE_LEN];
	CHAR            sNotiFyVal3         [ENV_VARIABLE_LEN];

	memset(sNotiFyVal,'\0',ENV_VARIABLE_LEN);

	if(getenv("NOTIFY_VAL")== NULL)
	{
		logFatal("Error : Environment variables missing : NOTIFY_VAL");
	}
	else
	{
		iNotiFyVal= atoi(getenv("NOTIFY_VAL"));
	}
	if(getenv("NOTIFY_VAL_2")== NULL)
	{
		logFatal("Error : Environment variables missing : NOTIFY_VAL");
	}
	else
	{
		iNotiFyVal_2= atoi(getenv("NOTIFY_VAL_2"));
	}
	if(getenv("NOTIFY_VAL_3")== NULL)
	{
		logFatal("Error : Environment variables missing : NOTIFY_VAL");
	}
	else
	{
		iNotiFyVal_3= atoi(getenv("NOTIFY_VAL_3"));
	}
	if(getenv("CLEARING_MEM_NOTIFY_VAL")== NULL)
	{
		logFatal("Error : Environment variables missing : CLEARING_MEM_NOTIFY_VAL");
	}
	else
	{
		iTradeNotiFyVal = atoi(getenv("CLEARING_MEM_NOTIFY_VAL"));
	}
	/**if(getenv("RADIS_KEY_EXP_SEC")== NULL)
	  {
	  iExpSec = 10;
	  logFatal("Error : Environment variables missing : RADIS_KEY_EXP_SEC ");
	  }
	  else
	  {

	  iExpSec = atoi(getenv("RADIS_KEY_EXP_SEC"));
	  }**/

	if(getenv("KAFKA_NOTIFIER_FLAG")== NULL)
	{
		logFatal("Error : Environment variables missing : KAFKA_NOTIFIER_FLAG : setting as 0 ");
		iKafkaMsgFlag = FALSE;
	}
	else
	{
		iKafkaMsgFlag = atoi(getenv("KAFKA_NOTIFIER_FLAG"));
	}

	if(getenv("NOTIFY_TRADE_SMS_FLAG")== NULL)
	{
		iNotifySms = FALSE;
		logFatal("Error : Environment variables missing : NOTIFY_TRADE_SMS_FLAG");
	}
	else
	{
		iNotifySms = atoi(getenv("NOTIFY_TRADE_SMS_FLAG"));
	}

	if(getenv("NOTIFY_TRADE_MAIL_FLAG")== NULL)
	{
		iNotifyMail = FALSE;
		logFatal("Error : Environment variables missing : NOTIFY_TRADE_MAIL_FLAG");
	}
	else
	{
		iNotifyMail = atoi(getenv("NOTIFY_TRADE_MAIL_FLAG"));
	}

	if(getenv("NOTIFY_TRADE_TPUSH_FLAG")== NULL)
	{
		iNotifyTPush = FALSE;
		logFatal("Error : Environment variables missing : NOTIFY_TRADE_TPUSH_FLAG");
	}
	else
	{
		iNotifyTPush = atoi(getenv("NOTIFY_TRADE_TPUSH_FLAG"));
	}



	logTimestamp("Exit : [fLoadNotifyEnv]");
}

BOOL fMapper(struct ORDER_RESPONSE *Ord_Req ,struct NOTIFICATION_RESPONSE *Ord_Res)
{
	logTimestamp("fMapper [Entry]");

	MYSQL_RES       *Res;
	MYSQL_ROW       *Row;

	CHAR    SelQuery[DOUBLE_MAX_QUERY_SIZE];
	memset(SelQuery,'\0',DOUBLE_MAX_QUERY_SIZE);

	Ord_Res->iRequestCode =       23;
	Ord_Res->iMsgLength   =       sizeof(struct NOTIFICATION_RESPONSE);
	Ord_Res->cSource      =       Ord_Req->IntRespHeader.cSource;
	Ord_Res->cSegment     =       Ord_Req->IntRespHeader.cSegment;
	strncpy(Ord_Res->sExchId,Ord_Req->IntRespHeader.sExcgId,EXCHANGE_LEN);

	if(Ord_Req->IntRespHeader.cSegment == EQUITY_SEGMENT){

		sprintf(SelQuery," SELECT * FROM (SELECT CLIENT_ID, ORDER_DATE_TIME, LAST_UPDATED_TIME, EXCH_ORDER_DATE_TIME, ORDER_NUMBER, EXCH, TRADED_PRICE, IFNULL(AVG_PRICE.AVG_TRADE_PRICCE, 0) AS AVG_TRADED_PRICE, BUY_SELL, SEGMENT, INSTRUMENT, SYMBOL, LEG_NO, PRODUCT, PRODUCT_NAME, STATUS, QUANTITY, REMAINING_QUANTITY, PRICE, TRG_PRICE, ORDER_TYPE, DISCLOSE_QTY, SERIALNO, TRADEDQTY, SEM_SECURITY_ID, ORDER_VALIDITY, SEM_NSE_REGULAR_LOT, ALGO_ORD_NO, DQQTYREM, EXCHORDERNO, REASON_DESCRIPTION, GROUP_ID, ROUND(TRAILING_SL_VALUE, 4) AS TRAILING_SL_VALUE, ROUND(SL_ABSTICK_VALUE, 4) AS SL_ABSTICK_VALUE, ROUND(PR_ABSTICK_VALUE, 4) AS PR_ABSTICK_VALUE, ORDER_OFFON, PAN_NO, PARTICIPANT_TYPE, MKT_PROTECT_FLG, MKT_PROTECT_VAL, SETTLOR, GTC_FLG, ENCASH_FLG, MKT_TYPE, STRIKE_PRICE, EXPIRY_DATE, OPT_TYPE, CUSTOM_SYMBOL, ISIN_CODE, SERIES, GTDdate, REMARKS, INSTRUMENT_TYP, LTP, TICK_SIZE, ALGO_ID, REMARKS1, REMARKS2 ,1  FROM (SELECT `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`, DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`, DATE_FORMAT(`A`.`EQ_LUT`, '%%Y-%%m-%%d %%T') AS `LAST_UPDATED_TIME`, DATE_FORMAT(`A`.`EQ_EXCH_ORDER_TIME`, '%%Y-%%m-%%d %%T') AS `EXCH_ORDER_DATE_TIME`, `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`, `A`.`EQ_EXCH_ID` AS `EXCH`, `A`.`EQ_TRD_TRADE_PRICE` AS `TRADED_PRICE`, `A`.`EQ_BUY_SELL_IND` AS `BUY_SELL`, 'E' AS `SEGMENT`, `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`, `A`.`EQ_SYMBOL` AS `SYMBOL`, `A`.`EQ_LEG_NO` AS `LEG_NO`, `A`.`EQ_PRODUCT_ID` AS `PRODUCT`, (CASE `A`.`EQ_PRODUCT_ID` WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE `A`.`EQ_PRODUCT_ID` END) AS `PRODUCT_NAME`, (CASE WHEN ((`A`.`EQ_MSG_CODE` = '2073') AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`)) THEN 'Part-Traded' WHEN ((`A`.`EQ_MSG_CODE` = '2074') AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`)) THEN 'Part-Traded' WHEN ((`A`.`EQ_MSG_CODE` = '2212') AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`)) THEN 'Part-Traded' WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending' WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen' WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified' WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled' WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded' WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired' WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending' WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified' WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled' WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered' WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected' END) AS `STATUS`, `A`.`EQ_TOTAL_QTY` AS `QUANTITY`, `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`, (CASE `A`.`EQ_SEGMENT` WHEN 'C' THEN REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0) END), 4), ',', '') ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0) END), 2), ',', '') END) AS `PRICE`, CASE `A`.`EQ_SEGMENT` WHEN 'C' THEN ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE` WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 2) ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE` WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 2) END AS `TRG_PRICE`, (CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '2' THEN 'LMT' WHEN '3' THEN 'SLM' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`, CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`, `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`, `A`.`EQ_SERIAL_NO` AS `SERIALNO`, `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`, `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`, (CASE `A`.`EQ_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS `ORDER_VALIDITY`, `A`.`EQ_LOT_SIZE` AS `SEM_NSE_REGULAR_LOT`, 0 AS `TAKE_PROFIT_TRAIL_GAP`, `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`, `A`.`EQ_ALGO_ORDER_NO` AS `ALGO_ORD_NO`, `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`, `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`, `A`.`EQ_GROUP_ID` AS `GROUP_ID`, `A`.`EQ_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`, `A`.`EQ_TRAILING_SL_VALUE` AS `TRAILING_SL_VALUE`, `A`.`EQ_SL_ABSTICK_VALUE` AS `SL_ABSTICK_VALUE`, `A`.`EQ_PR_ABSTICK_VALUE` AS `PR_ABSTICK_VALUE`, `A`.`EQ_ORDER_OFFON` AS `ORDER_OFFON`, `A`.`EQ_CHILD_LEG_UNQ_ID` AS `CHILD_LEG_UNQ_ID`, `A`.`EQ_PAN_NO` AS `PAN_NO`, `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`, `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`, `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`, `A`.`EQ_SETTLOR` AS `SETTLOR`, `A`.`EQ_GTC_FLG` AS `GTC_FLG`, `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`, `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`, `A`.`EQ_STRIKE_PRICE` AS `STRIKE_PRICE`, `A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`, IFNULL(IF(`A`.`EQ_OPTION_TYPE`, '', 'XX'), 'XX') AS `OPT_TYPE`, `A`.`EQ_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`, `A`.`EQ_ISIN_CODE` AS `ISIN_CODE`, `A`.`EQ_SERIES` AS `SERIES`, DATE_FORMAT(A.EQ_GOOD_TILL_DATE, '%%Y-%%m-%%d') AS GTDdate, `A`.`EQ_REMARKS` AS `REMARKS`, `A`.`EQ_EXCH_INSTRUMENT_TYPE` AS `INSTRUMENT_TYP`, `A`.`EQ_REF_LTP` AS `LTP`, (`A`.`EQ_TICK_SIZE`) AS `TICK_SIZE`, `A`.`EQ_ALGO_ID` AS `ALGO_ID`, `A`.`EQ_REMARKS1` AS `REMARKS1`, `A`.`EQ_REMARKS2` AS `REMARKS2` FROM (SELECT MAX(C.EQ_SERIAL_NO) AS SER FROM `EQ_ORDERS` `C` WHERE (`C`.`EQ_CLIENT_ID` = \"%s\") AND (`C`.`EQ_ORDER_NO` = %lf ) AND (`C`.`EQ_LEG_NO` = %d)) X, `EQ_ORDERS` `A` WHERE `A`.`EQ_CLIENT_ID` = \"%s\" 	AND `A`.`EQ_MKT_TYPE` <> 'SP' 	AND `A`.`EQ_ORD_STATUS` <> 'B' 	AND `A`.`EQ_ORDER_NO` = %lf 	AND `A`.`EQ_LEG_NO` = %d 	AND `A`.`EQ_CF_FLAG` <> - 1 	AND `A`.`EQ_SERIAL_NO` = X.SER) orderbook LEFT JOIN (SELECT EQ_ORDER_NO AS ORDER_NO, EQ_LEG_NO AS A_LEG_NO, IFNULL((SUM(EQ_TRD_TRADE_PRICE * EQ_LAST_TRADE_QTY) / SUM(EQ_LAST_TRADE_QTY)), 0) AS AVG_TRADE_PRICCE FROM EQ_ORDERS EQ WHERE `EQ`.`EQ_CLIENT_ID` = \"%s\" AND `EQ`.`EQ_ORDER_NO` = %lf AND `EQ`.`EQ_ORD_STATUS` = 'T' AND (`EQ`.`EQ_ORD_STATUS` <> 'B') AND (`EQ`.`EQ_MKT_TYPE` <> 'SP') AND (`EQ`.`EQ_CF_FLAG` <> - 1) GROUP BY EQ_ORDER_NO , EQ_LEG_NO) AVG_PRICE ON (orderbook.ORDER_NUMBER = AVG_PRICE.ORDER_NO AND orderbook.LEG_NO = AVG_PRICE.A_LEG_NO) LEFT JOIN SEM_ACTIVE SM ON (SM.SM_SCRIP_CODE = orderbook.SEM_SECURITY_ID AND SM.SM_SEGMENT = orderbook.SEGMENT AND SM.SM_EXCHANGE = orderbook.EXCH)) SorOrdBook; ",Ord_Req->sClientId,Ord_Req->fOrderNum,Ord_Req->iLegValue,Ord_Req->sClientId,Ord_Req->fOrderNum,Ord_Req->iLegValue,Ord_Req->sClientId,Ord_Req->fOrderNum);
	}
	else if (Ord_Req->IntRespHeader.cSegment == DERIVATIVE_SEGMENT || Ord_Req->IntRespHeader.cSegment == CURRENCY_SEGMENT){


		sprintf(SelQuery,"SELECT   *  FROM  (SELECT   CLIENT_ID,  ORDER_DATE_TIME,  LAST_UPDATED_TIME,  EXCH_ORDER_DATE_TIME, ORDER_NUMBER,  EXCH,  TRADED_PRICE, IFNULL(AVG_PRICE.AVG_TRADE_PRICCE,0) AS AVG_TRADED_PRICE, BUY_SELL, SEGMENT, INSTRUMENT, SYMBOL, LEG_NO,  PRODUCT, PRODUCT_NAME, STATUS, QUANTITY,   REMAINING_QUANTITY, PRICE, TRG_PRICE, ORDER_TYPE, DISCLOSE_QTY, SERIALNO, TRADEDQTY, SEM_SECURITY_ID, ORDER_VALIDITY, SEM_NSE_REGULAR_LOT,  ALGO_ORD_NO,   DQQTYREM,  EXCHORDERNO, REASON_DESCRIPTION, GROUP_ID, ROUND(TRAILING_SL_VALUE, 4) AS TRAILING_SL_VALUE,  ROUND(SL_ABSTICK_VALUE, 4) AS SL_ABSTICK_VALUE,  ROUND(PR_ABSTICK_VALUE, 4) AS PR_ABSTICK_VALUE, ORDER_OFFON, PAN_NO, PARTICIPANT_TYPE, MKT_PROTECT_FLG, MKT_PROTECT_VAL,SETTLOR, GTC_FLG, ENCASH_FLG,  MKT_TYPE, STRIKE_PRICE, EXPIRY_DATE, OPT_TYPE, CUSTOM_SYMBOL,ISIN_CODE, SERIES, GTDdate, REMARKS ,INSTRUMENT_TYP,LTP,TICK_SIZE,ALGO_ID, REMARKS1, REMARKS2 ,MULTIPLIER FROM  (SELECT `DR`.`DRV_CLIENT_ID` AS `CLIENT_ID`,  DATE_FORMAT(`DR`.`DRV_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`, DATE_FORMAT(`DR`.`DRV_LUT`, '%%Y-%%m-%%d %%T') AS `LAST_UPDATED_TIME`,  DATE_FORMAT(`DR`.`DRV_EXCH_ORDER_TIME`, '%%Y-%%m-%%d %%T') AS `EXCH_ORDER_DATE_TIME`,`DR`.`DRV_ORDER_NO` AS `ORDER_NUMBER`,`DR`.`DRV_EXCH_ID` AS `EXCH`,`DR`.`DRV_TRD_TRADE_PRICE` AS `TRADED_PRICE`, `DR`.`DRV_BUY_SELL_IND` AS `BUY_SELL`,`DR`.`DRV_SEGMENT` AS `SEGMENT`,`DR`.`DRV_INSTRUMENT_NAME` AS  `INSTRUMENT`, `DR`.`DRV_SYMBOL` AS `SYMBOL`, `DR`.`DRV_LEG_NO` AS `LEG_NO`, `DR`.`DRV_PRODUCT_ID` AS `PRODUCT`,(CASE `DR`.`DRV_PRODUCT_ID` WHEN 'B' THEN 'BO'  WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'H' THEN 'NORMAL'   WHEN 'F' THEN 'MTF' ELSE `DR`.`DRV_PRODUCT_ID` END) AS `PRODUCT_NAME`, (CASE WHEN  ((`DR`.`DRV_MSG_CODE` = '2073') AND (`DR`.`DRV_REM_QTY` <> `DR`.`DRV_TOTAL_QTY`))   THEN 'Part-Traded' WHEN ((`DR`.`DRV_MSG_CODE` = '2074') AND (`DR`.`DRV_REM_QTY` > `DR`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' WHEN ((`DR`.`DRV_MSG_CODE` = '2212')   AND (`DR`.`DRV_REM_QTY` <> `DR`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' WHEN (`DR`.`DRV_MSG_CODE` = '2073') THEN 'Pending' WHEN (`DR`.`DRV_MSG_CODE` = '2000') THEN   'Transit' WHEN (`DR`.`DRV_MSG_CODE` = '2040') THEN 'Transit' WHEN (`DR`.`DRV_MSG_CODE` = '2070') THEN 'Transit' WHEN (`DR`.`DRV_MSG_CODE` = '2231') THEN  'Rejected' WHEN (`DR`.`DRV_MSG_CODE` = '2042') THEN 'Rejected' WHEN (`DR`.`DRV_MSG_CODE` = '2170') THEN 'Frozen' WHEN (`DR`.`DRV_MSG_CODE` = '2074') THEN 'Modified'   WHEN (`DR`.`DRV_MSG_CODE` = '2075') THEN 'Cancelled' WHEN (`DR`.`DRV_MSG_CODE` = '2222') THEN 'Traded' WHEN (`DR`.`DRV_MSG_CODE` = '9002') THEN 'Expired' WHEN   (`DR`.`DRV_MSG_CODE` = '5112') THEN 'O-Pending' WHEN (`DR`.`DRV_MSG_CODE` = '5113') THEN 'O-Modified' WHEN (`DR`.`DRV_MSG_CODE` = '5114') THEN 'O-Cancelled'   WHEN (`DR`.`DRV_MSG_CODE` = '2212') THEN 'Triggered' WHEN (`DR`.`DRV_MSG_CODE` = '1111') THEN 'Rejected' WHEN (`DR`.`DRV_MSG_CODE` = '1113') THEN 'Rejected'   WHEN (`DR`.`DRV_MSG_CODE` = '1115') THEN 'Rejected' WHEN (`DR`.`DRV_MSG_CODE` = '4444') THEN 'Rejected' WHEN (`DR`.`DRV_MSG_CODE` = '4445') THEN 'Rejected' WHEN (`DR`.`DRV_MSG_CODE` = '4446') THEN 'Rejected' END) AS `STATUS`, `DR`.`DRV_TOTAL_QTY` AS `QUANTITY`,`DR`.`DRV_REM_QTY` AS `REMAINING_QUANTITY`,   CASE `DR`.`DRV_SEGMENT` WHEN 'C' THEN REPLACE(FORMAT((CASE `DR`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`DR`.`DRV_ORDER_PRICE`, 0)  END), 4), ',', '') ELSE REPLACE(FORMAT((CASE `DR`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`DR`.`DRV_ORDER_PRICE`, 0) END), 2), ',', '')   END AS `PRICE`, CASE `DR`.`DRV_SEGMENT` WHEN 'C' THEN ROUND(COALESCE((CASE `DR`.`DRV_ORDER_TYPE` WHEN '3' THEN IFNULL(`DR`.`DRV_TRIGGER_PRICE`, 0) WHEN '4' THEN   IFNULL(`DR`.`DRV_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE `DR`.`DRV_ORDER_TYPE` WHEN '3' THEN IFNULL(`DR`.`DRV_TRIGGER_PRICE`, 0) WHEN '4'   THEN IFNULL(`DR`.`DRV_TRIGGER_PRICE`, 0) ELSE 0 END), 0), 2) END AS TRG_PRICE, (CASE `DR`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '2' THEN 'LMT' WHEN '3'  THEN 'SLM'  WHEN '4' THEN 'SL'  END) AS `ORDER_TYPE`,  CONCAT(`DR`.`DRV_REM_QTY`, '/', `DR`.`DRV_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,  `DR`.`DRV_DISC_QTY` AS `DISCLOSE_QTY`,  `DR`.`DRV_SERIAL_NO` AS `SERIALNO`,  `DR`.`DRV_TOTAL_TRADED_QTY` AS `TRADEDQTY`,  `DR`.`DRV_SCRIP_CODE` AS `SEM_SECURITY_ID`,  (CASE `DR`.`DRV_VALIDITY`  WHEN '0' THEN 'DAY'  WHEN '1' THEN 'GTC'  WHEN '2' THEN 'ATO'  WHEN '3' THEN 'IOC'  WHEN '6' THEN 'GTD'  ELSE 'EOS'  END) AS `ORDER_VALIDITY`,  `DR`.`DRV_LOT_SIZE` AS `SEM_NSE_REGULAR_LOT`,  0 AS `TAKE_PROFIT_TRAIL_GAP`,  `DR`.`DRV_OMS_ALGO_ORD_NO` AS `ADV_GROUP_REF_NO`,  `DR`.`DRV_OMS_ALGO_ORD_NO` AS `ALGO_ORD_NO`,  `DR`.`DRV_DISC_REM_QTY` AS `DQQTYREM`,  `DR`.`DRV_EXCH_ORDER_NO` AS `EXCHORDERNO`,  `DR`.`DRV_GROUP_ID` AS `GROUP_ID`,  `DR`.`DRV_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`,  `DR`.`DRV_TRAILING_SL_VALUE` AS `TRAILING_SL_VALUE`,  `DR`.`DRV_SL_ABSTICK_VALUE` AS `SL_ABSTICK_VALUE`,  `DR`.`DRV_PR_ABSTICK_VALUE` AS `PR_ABSTICK_VALUE`,  `DR`.`DRV_ORDER_OFFON` AS `ORDER_OFFON`,  `DR`.`DRV_CHILD_LEG_UNQ_ID` AS `CHILD_LEG_UNQ_ID`,  `DR`.`DRV_PAN_NO` AS `PAN_NO`,  `DR`.`DRV_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,  `DR`.`DRV_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,  `DR`.`DRV_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,  `DR`.`DRV_SETTLOR` AS `SETTLOR`,  `DR`.`DRV_GTC_FLG` AS `GTC_FLG`,  `DR`.`DRV_ENCASH_FLG` AS `ENCASH_FLG`,  `DR`.`DRV_MKT_TYPE` AS `MKT_TYPE`,  `DR`.`DRV_STRIKE_PRICE` AS `STRIKE_PRICE`,   DATE_FORMAT(DR.DRV_EXPIRY_DATE, '%%Y-%%m-%%d')  AS `EXPIRY_DATE`,   IFNULL(IF(`DR`.`DRV_OPTION_TYPE` = '','XX',`DR`.`DRV_OPTION_TYPE`),'XX') AS `OPT_TYPE`,  `DR`.`DRV_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,  'NA' AS `ISIN_CODE`,  'XX' AS `SERIES`,  DATE_FORMAT(DR.DRV_GOOD_TILL_DATE, '%%Y-%%m-%%d') AS GTDdate,   `DR`.`DRV_REMARKS` AS `REMARKS`,`DR`.`DRV_EXCH_INSTRUMENT_TYPE` AS `INSTRUMENT_TYP`,`DR`.`DRV_REF_LTP` AS `LTP` ,(`DR`.`DRV_TICK_SIZE`) AS `TICK_SIZE`,`DR`.`DRV_ALGO_ID` AS `ALGO_ID`, `DR`.`DRV_REMARKS1` AS `REMARKS1`, `DR`.`DRV_REMARKS2` AS `REMARKS2` ,(CASE DR.DRV_SEGMENT WHEN 'C' THEN IFNULL(DR.DRV_CURRENCY_MULTIPLIER,1000) ELSE 1 END) AS MULTIPLIER FROM (SELECT MAX(DRV_SERIAL_NO) AS SER, DRV_ORDER_NO AS ORD_NO, DRV_LEG_NO AS LEG_NO FROM DRV_ORDERS C WHERE `C`.`DRV_CLIENT_ID` = \"%s\"  AND `C`.`DRV_CF_FLAG` <> - 1  AND `C`.`DRV_MKT_TYPE` <> 'SP'  AND `C`.`DRV_STATUS` <> 'B'  AND `C`.`DRV_ORDER_NO` = %lf   AND `C`.`DRV_LEG_NO` = %d) AS X,   `DRV_ORDERS` `DR` WHERE `DR`.`DRV_SERIAL_NO` = X.SER AND DR.DRV_ORDER_NO = X.ORD_NO AND DR.DRV_LEG_NO = X.LEG_NO) orderbook  LEFT JOIN (SELECT   DRV_ORDER_NO AS ORDER_NO,  DRV_LEG_NO AS A_LEG_NO,   IFNULL((SUM(DRV_TRD_TRADE_PRICE * DRV_TRD_TRADE_QTY) / SUM(DRV_TRD_TRADE_QTY)), 0) AS AVG_TRADE_PRICCE  FROM  DRV_ORDERS CO  WHERE  (`CO`.`DRV_STATUS` <> 'B')  AND (`CO`.`DRV_MKT_TYPE` <> 'SP')  AND (`CO`.`DRV_CF_FLAG` <> - 1) AND CO.`DRV_ORDER_NO` = %lf AND CO.`DRV_LEG_NO` = %d AND DRV_STATUS = 'T' GROUP BY DRV_ORDER_NO , DRV_LEG_NO) AVG_PRICE ON (orderbook.ORDER_NUMBER = AVG_PRICE.ORDER_NO  AND orderbook.LEG_NO = AVG_PRICE.A_LEG_NO)) SorOrdBook;",Ord_Req->sClientId,Ord_Req->fOrderNum,Ord_Req->iLegValue,Ord_Req->fOrderNum,Ord_Req->iLegValue);

	}
	else if (Ord_Req->IntRespHeader.cSegment == COMMODITY_SEGMENT){
		sprintf(SelQuery,"SELECT *  FROM (SELECT     CLIENT_ID,    ORDER_DATE_TIME,    LAST_UPDATED_TIME,    EXCH_ORDER_DATE_TIME,    ORDER_NUMBER,    EXCH,    TRADED_PRICE,    AVG_PRICE.AVG_TRADE_PRICCE AS AVG_TRADED_PRICE,    BUY_SELL,    SEGMENT,    INSTRUMENT,    SYMBOL,    LEG_NO,    PRODUCT,    PRODUCT_NAME,    STATUS,    QUANTITY,    REMAINING_QUANTITY,    PRICE,    TRG_PRICE,    ORDER_TYPE,    DISCLOSE_QTY,    SERIALNO,    TRADEDQTY,    SEM_SECURITY_ID,    ORDER_VALIDITY,    SEM_LOT_SIZE,    ALGO_ORD_NO,    DQQTYREM,    EXCHORDERNO,    REASON_DESCRIPTION,    GROUP_ID,    ROUND(TRAILING_SL_VALUE, 4) AS TRAILING_SL_VALUE,    ROUND(SL_ABSTICK_VALUE, 4) AS SL_ABSTICK_VALUE,    ROUND(PR_ABSTICK_VALUE, 4) AS PR_ABSTICK_VALUE,    ORDER_OFFON,    PAN_NO,    PARTICIPANT_TYPE,    MKT_PROTECT_FLG,    MKT_PROTECT_VAL,    SETTLOR,    GTC_FLG,    ENCASH_FLG,    MKT_TYPE,    STRIKE_PRICE,    EXPIRY_DATE,    OPT_TYPE,    CUSTOM_SYMBOL,    ISIN_CODE,    SERIES,    GTDdate,    REMARKS,    INSTRUMENT_TYP,    LTP,    TICK_SIZE,    ALGO_ID,    REMARKS1,    REMARKS2,    MULTIPLIER FROM     (SELECT     `COM`.`COMM_CLIENT_ID` AS `CLIENT_ID`,    DATE_FORMAT(`COM`.`COMM_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`,    DATE_FORMAT(`COM`.`COMM_LUT`, '%%Y-%%m-%%d %%T') AS `LAST_UPDATED_TIME`,    DATE_FORMAT(`COM`.`COMM_EXCH_ORDER_TIME`, '%%Y-%%m-%%d %%T') AS `EXCH_ORDER_DATE_TIME`,    `COM`.`COMM_ORDER_NO` AS `ORDER_NUMBER`,    `COM`.`COMM_EXCH_ID` AS `EXCH`,    `COM`.`COMM_TRD_TRADE_PRICE` AS `TRADED_PRICE`,    `COM`.`COMM_BUY_SELL_IND` AS `BUY_SELL`,    `COM`.`COMM_SEGMENT` AS `SEGMENT`,    `COM`.`COMM_INSTRUMENT_NAME` AS `INSTRUMENT`,    `COM`.`COMM_SYMBOL` AS `SYMBOL`,    `COM`.`COMM_LEG_NO` AS `LEG_NO`,    `COM`.`COMM_PRODUCT_ID` AS `PRODUCT`,    (CASE `COM`.`COMM_PRODUCT_ID`   WHEN 'B' THEN 'BO'   WHEN 'V' THEN 'CO'   WHEN 'C' THEN 'CNC'   WHEN 'M' THEN 'MARGIN'   WHEN 'L' THEN 'MLB'   WHEN 'S' THEN 'COLLATERAL'   WHEN 'I' THEN 'INTRADAY'   WHEN 'H' THEN 'NORMAL'   WHEN 'F' THEN 'MTF'   ELSE `COM`.`COMM_PRODUCT_ID`    END) AS `PRODUCT_NAME`,    (CASE   WHEN  ((`COM`.`COMM_MSG_CODE` = '2073') AND (`COM`.`COMM_REM_QTY` <> `COM`.`COMM_TOTAL_QTY`))   THEN  'Part-Traded'   WHEN  ((`COM`.`COMM_MSG_CODE` = '2074') AND (`COM`.`COMM_REM_QTY` > `COM`.`COMM_TOTAL_QTY`))   THEN  'Part-Traded'   WHEN  ((`COM`.`COMM_MSG_CODE` = '2212') AND (`COM`.`COMM_REM_QTY` <> `COM`.`COMM_TOTAL_QTY`))   THEN  'Part-Traded'   WHEN (`COM`.`COMM_MSG_CODE` = '2073') THEN 'Pending'   WHEN (`COM`.`COMM_MSG_CODE` = '2000') THEN 'Transit'   WHEN (`COM`.`COMM_MSG_CODE` = '2040') THEN 'Transit'   WHEN (`COM`.`COMM_MSG_CODE` = '2070') THEN 'Transit'   WHEN (`COM`.`COMM_MSG_CODE` = '2231') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '2042') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '2170') THEN 'Frozen'   WHEN (`COM`.`COMM_MSG_CODE` = '2074') THEN 'Modified'   WHEN (`COM`.`COMM_MSG_CODE` = '2075') THEN 'Cancelled'   WHEN (`COM`.`COMM_MSG_CODE` = '2222') THEN 'Traded'   WHEN (`COM`.`COMM_MSG_CODE` = '9002') THEN 'Expired'   WHEN (`COM`.`COMM_MSG_CODE` = '5112') THEN 'O-Pending'   WHEN (`COM`.`COMM_MSG_CODE` = '5113') THEN 'O-Modified'   WHEN (`COM`.`COMM_MSG_CODE` = '5114') THEN 'O-Cancelled'   WHEN (`COM`.`COMM_MSG_CODE` = '2212') THEN 'Triggered'   WHEN (`COM`.`COMM_MSG_CODE` = '1111') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '1113') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '1115') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '4444') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '4445') THEN 'Rejected'   WHEN (`COM`.`COMM_MSG_CODE` = '4446') THEN 'Rejected'    END) AS `STATUS`,    `COM`.`COMM_TOTAL_QTY` AS `QUANTITY`,    `COM`.`COMM_REM_QTY` AS `REMAINING_QUANTITY`,    CASE `COM`.`COMM_SEGMENT`   WHEN  'C'   THEN  REPLACE(FORMAT((CASE `COM`.`COMM_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`COM`.`COMM_ORDER_PRICE`, 0)  END), 4), ',', '')   ELSE REPLACE(FORMAT((CASE `COM`.`COMM_ORDER_TYPE`  WHEN '1' THEN 'MKT'  WHEN '3' THEN 'MKT'  ELSE IFNULL(`COM`.`COMM_ORDER_PRICE`, 0)   END), 2), ',', '')    END AS `PRICE`,    CASE `COM`.`COMM_SEGMENT`   WHEN  'C'   THEN  ROUND(COALESCE((CASE `COM`.`COMM_ORDER_TYPE` WHEN '3' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0) ELSE 0  END), 0), 4)   ELSE ROUND(COALESCE((CASE `COM`.`COMM_ORDER_TYPE`  WHEN '3' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0)  WHEN '4' THEN IFNULL(`COM`.`COMM_TRIGGER_PRICE`, 0)  ELSE 0   END), 0), 2)    END AS TRG_PRICE,    (CASE `COM`.`COMM_ORDER_TYPE`   WHEN '1' THEN 'MKT'   WHEN '2' THEN 'LMT'   WHEN '3' THEN 'SLM'   WHEN '4' THEN 'SL'    END) AS `ORDER_TYPE`,    CONCAT(`COM`.`COMM_REM_QTY`, '/', `COM`.`COMM_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,    `COM`.`COMM_DISC_QTY` AS `DISCLOSE_QTY`,    `COM`.`COMM_SERIAL_NO` AS `SERIALNO`,    `COM`.`COMM_TOTAL_TRADED_QTY` AS `TRADEDQTY`,    `COM`.`COMM_SCRIP_CODE` AS `SEM_SECURITY_ID`,    (CASE `COM`.`COMM_VALIDITY`   WHEN '0' THEN 'DAY'   WHEN '1' THEN 'GTC'   WHEN '2' THEN 'ATO'   WHEN '3' THEN 'IOC'   WHEN '6' THEN 'GTD'   ELSE 'EOS'    END) AS `ORDER_VALIDITY`,    `COM`.`COMM_LOT_SIZE` AS `SEM_LOT_SIZE`,    0 AS `TAKE_PROFIT_TRAIL_GAP`,    `COM`.`COMM_OMS_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,    `COM`.`COMM_OMS_ALGO_ORDER_NO` AS `ALGO_ORD_NO`,    `COM`.`COMM_DISC_REM_QTY` AS `DQQTYREM`,    `COM`.`COMM_EXCH_ORDER_NO` AS `EXCHORDERNO`,    `COM`.`COMM_GROUP_ID` AS `GROUP_ID`,    `COM`.`COMM_REASON_DESCRIPTION` AS `REASON_DESCRIPTION`,    `COM`.`COMM_TRAILING_SL_VALUE` AS `TRAILING_SL_VALUE`,    `COM`.`COMM_SL_ABSTICK_VALUE` AS `SL_ABSTICK_VALUE`,    `COM`.`COMM_PR_ABSTICK_VALUE` AS `PR_ABSTICK_VALUE`,    `COM`.`COMM_ORDER_OFFON` AS `ORDER_OFFON`,    `COM`.`COMM_CHILD_LEG_UNQ_ID` AS `CHILD_LEG_UNQ_ID`,    `COM`.`COMM_PAN_NO` AS `PAN_NO`,    `COM`.`COMM_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,    `COM`.`COM_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,    `COM`.`COMM_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,    IFNULL(NULLIF(`COM`.`COMM_SETTLOR`,''),'NA') AS `SETTLOR`,    `COM`.`COMM_GTC_FLG` AS `GTC_FLG`,    `COM`.`COMM_ENCASH_FLG` AS `ENCASH_FLG`,    `COM`.`COMM_MKT_TYPE` AS `MKT_TYPE`,    `COM`.`COMM_STRIKE_PRICE` AS `STRIKE_PRICE`,    `COM`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,    IFNULL(IF(`COM`.`COMM_OPTION_TYPE`, '', 'XX'), 'XX') AS `OPT_TYPE`,    `COM`.`COMM_CUSTOM_SYMBOL` AS `CUSTOM_SYMBOL`,    'NA' AS `ISIN_CODE`,    'XX' AS `SERIES`,    DATE_FORMAT(COM.COMM_GOOD_TILL_DATE, '%%Y-%%m-%%d') AS GTDdate,    `COM`.`COMM_REMARKS` AS `REMARKS`,    `COM`.`COMM_MULTIPLIER` AS `MULTIPLIER`,    IFNULL(NULLIF (`COM`.`COMM_EXCH_INSTRUMENT_TYPE`,''),'NA') AS `INSTRUMENT_TYP`,    `COM`.`COMM_REF_LTP` AS `LTP`,    `COM`.`COMM_TICK_SIZE` AS `TICK_SIZE`,    `COM`.`COMM_ALGO_ID` AS `ALGO_ID`,   IFNULL( NULLIF(`COM`.`COMM_REMARKS1`,''),'NA') AS `REMARKS1`,    IFNULL(NULLIF(`COM`.`COMM_REMARKS2`,''),'NA') AS `REMARKS2` FROM     `COMM_ORDERS` `COM` WHERE     `COM`.`COMM_CLIENT_ID` = \"%s\"    AND `COM`.`COMM_CF_FLAG` <> - 1    AND `COM`.`COMM_MKT_TYPE` <> 'SP'    AND `COM`.`COMM_STATUS` <> 'B'    AND `COM`.`COMM_ORDER_NO` = %f    AND `COM`.`COMM_LEG_NO` = %d    AND `COM`.`COMM_SERIAL_NO` = (SELECT   MAX(`COMO`.`COMM_SERIAL_NO`)    FROM   `COMM_ORDERS` `COMO`    WHERE   (`COMO`.`COMM_ORDER_NO` = %f)  AND ((`COM`.`COMM_LEG_NO` = %d)))) orderbook LEFT JOIN (SELECT     COMM_ORDER_NO AS ORDER_NO,    COMM_LEG_NO AS A_LEG_NO,    IFNULL((AVG(CASE   WHEN COMM_STATUS = 'T' THEN COMM_TRD_TRADE_PRICE    END)), 0) AS AVG_TRADE_PRICCE FROM     COMM_ORDERS CO WHERE     (`CO`.`COMM_STATUS` <> 'B')    AND (`CO`.`COMM_MKT_TYPE` <> 'SP')    AND (`CO`.`COMM_CF_FLAG` <> - 1) GROUP BY COMM_ORDER_NO , COMM_LEG_NO) AVG_PRICE ON (orderbook.ORDER_NUMBER = AVG_PRICE.ORDER_NO     AND orderbook.LEG_NO = AVG_PRICE.A_LEG_NO) LEFT JOIN SECURITY_MASTER SM ON (SM.SM_SCRIP_CODE = orderbook.SEM_SECURITY_ID     AND SM.SM_SEGMENT = orderbook.SEGMENT     AND SM.SM_EXCHANGE = orderbook.EXCH)) SorOrdBook ",Ord_Req->sClientId,Ord_Req->fOrderNum,Ord_Req->iLegValue,Ord_Req->fOrderNum,Ord_Req->iLegValue); 

	}

	printf("\n Query :%s: \n",SelQuery);
	if (mysql_query(DBCon, SelQuery) != SUCCESS) {
		sql_Error(DBCon);
		return FALSE;
	}

	Res = mysql_store_result(DBCon);
	if(mysql_num_rows(Res) == 0)
	{
		mysql_free_result(Res);
		return NO_ROW;
	}
	else
	{
		while((Row = mysql_fetch_row(Res)))
		{
			logDebug2("Client ID > %s",Row[0]);;
			logDebug2("sOrdEntryTime > %s",Row[1]);;
			logDebug2("sOrderNum > %s",Row[4]);;
			logDebug2("Txn > %s",Row[8]);;
			strncpy(Ord_Res->sClientId,Row[0],CLIENT_ID_LEN);
			strncpy(Ord_Res->sOrdEntryTime,Row[1],DATE_TIME_LEN);
			strncpy(Ord_Res->sLastUpdatedTime,Row[2],DATE_TIME_LEN);
			strncpy(Ord_Res->sExchOrderTime,Row[3],DATE_TIME_LEN);
			strncpy(Ord_Res->sOrderNum,Row[4],EXCH_ORDER_NO_LEN);
			strncpy(Ord_Res->sExchId,Row[5],EXCHANGE_LEN);
			Ord_Res->fTradePrice= atof(Row[6]);
			Ord_Res->fAvgTradePrice= atof(Row[7]);
			Ord_Res->cBuyOrSell= Row[8][0];
			logDebug2("Txn > %c",Ord_Res->cBuyOrSell);
			Ord_Res->cSegment= Row[9][0];
			strncpy(Ord_Res->sInstrument,Row[10],INSTRUMENT_LEN);
			strncpy(Ord_Res->sSymbol,Row[11],DB_SYMBOL_LEN);
			Ord_Res->iLegValue = atoi(Row[12]);
			Ord_Res->cProductId= Row[13][0];
			strncpy(Ord_Res->sProduct_Name,Row[14],PRODUCT_NAME_LEN);
			strncpy(Ord_Res->sStatus,Row[15],STATUS_LEN_SIZE);
			Ord_Res->iTotalQty= atoi(Row[16]);
			Ord_Res->iTotalQtyRem= atoi(Row[17]);
			Ord_Res->fPrice= atof(Row[18]);
			Ord_Res->fTriggerPrice= atof(Row[19]);
			strncpy(Ord_Res->sOrderType,Row[20],ORDER_TYPE_LEN);
			Ord_Res->iDiscQty = atoi(Row[21]);
			Ord_Res->iSerialNum= atoi(Row[22]);
			Ord_Res->iTotalTradedQty= atoi(Row[23]);
			strncpy(Ord_Res->sSecurityId,Row[24],SECURITY_ID_LEN);
			strncpy(Ord_Res->sOrderValidity,Row[25],VALIDITY_LEN);
			Ord_Res->iLotsize= atoi(Row[26]);
			Ord_Res->fAlgoOrderNo= atof(Row[27]);
			Ord_Res->iDiscQtyRem = atoi(Row[28]);
			strncpy(Ord_Res->sExchOrderID,Row[29],EXCH_ORDER_NO_LEN);
			strncpy(Ord_Res->sReasonDesc,Row[30],DB_REASON_DESC_LEN);
			Ord_Res->iGrpId= atoi(Row[31]);
			Ord_Res->fSLTrail= atof(Row[32]);
			Ord_Res->fSLTickValue= atof(Row[33]);
			Ord_Res->fPRTickValue = atof(Row[34]);
			Ord_Res->cOffMarketFlg= Row[35][0];
			strncpy(Ord_Res->sPanID,Row[36],INT_PAN_LEN);
			Ord_Res->cParticipantType= Row[37][0];
			Ord_Res->cMarkProFlag= Row[38][0];
			Ord_Res->fMarkProVal= atof(Row[39]);
			strncpy(Ord_Res->sSettlor,Row[40],SETTLOR_LEN);
			Ord_Res->cGTCFlag= Row[41][0];
			Ord_Res->cEncashFlag = Row[42][0];
			strncpy(Ord_Res->sMktType,Row[43],MARKET_TYPES);
			Ord_Res->fStrikePrice= atof(Row[44]);
			strncpy(Ord_Res->sExpiryDate,Row[45],DATE_TIME_LEN);
			strncpy(Ord_Res->sOption_typ,Row[46],OPTION_LEN);
			strncpy(Ord_Res->sCustomSym,Row[47],CUSTOM_SYM_LEN);
			strncpy(Ord_Res->sIsin,Row[48],ISINCODE_LEN);
			strncpy(Ord_Res->sSeries,Row[49],SERIES_LEN);
			strncpy(Ord_Res->sGtdDate,Row[50],DATE_TIME_LEN);
			strncpy(Ord_Res->sRemarks,Row[51],REMARKS_LEN);
			strncpy(Ord_Res->sInstrumentTyp,Row[52],INSTRUMENT_TYPE);
			Ord_Res->fLtp = atof(Row[53]);
			Ord_Res->fTickSize = atof(Row[54]);
			strncpy(Ord_Res->sAlgoID,Row[55],BSE_INT_ALGO_ID_LEN);
			strncpy(Ord_Res->sClientId,Row[0],CLIENT_ID_LEN);
			strncpy(Ord_Res->sPlatform,Row[56],PLATFORM_LEN);
			strncpy(Ord_Res->sChannel,Row[57],CHANNEL_LEN);
			/*0000655: Multiplier Missing in OrderBcast*/
			Ord_Res->fMultiplier = atof(Row[58]);
		
			logDebug3("Ord_Res->fMultiplier ::%lf",Ord_Res->fMultiplier);
		        logDebug2("Ord_Req->sRemarks2 = %s",Ord_Req->sRemarks2 );
        		logDebug2("Ord_Req->sRemarks3 = %s",Ord_Req->sRemarks3 );
		}
		mysql_free_result(Res);

		/*		
				strncpy(Ord_Res->sClientId,"100002",CLIENT_ID_LEN);
				strncpy(Ord_Res->sOrdEntryTime,"24-05-2019 12:57:12",DATE_TIME_LEN);
				strncpy(Ord_Res->sLastUpdatedTime,"24-05-2019 12:57:13",DATE_TIME_LEN);
				strncpy(Ord_Res->sExchOrderTime,"24-05-2019 07:26:53",DATE_TIME_LEN);
				strncpy(Ord_Res->sOrderNum,"11905232044",EXCH_ORDER_NO_LEN);
				logDebug2("OrderNo :%s:",Ord_Res->sOrderNum);
				strncpy(Ord_Res->sExchId,"NSE",EXCHANGE_LEN);
				Ord_Res->fTradePrice= 700;
				Ord_Res->fAvgTradePrice= 700;
				Ord_Res->cBuyOrSell= 'B';
				Ord_Res->cSegment= 'E';
				strncpy(Ord_Res->sInstrument,"EQUITY",INSTRUMENT_LEN);
				strncpy(Ord_Res->sSymbol,"TCS",DB_SYMBOL_LEN);
				Ord_Res->iLegValue = 1;
				Ord_Res->cProductId= 'C';
				strncpy(Ord_Res->sProduct_Name,"CNC",PRODUCT_NAME_LEN);
				strncpy(Ord_Res->sStatus,"Traded",STATUS_LEN_SIZE);
				Ord_Res->iTotalQty= 15;
				Ord_Res->iTotalQtyRem= 0;
				Ord_Res->fPrice= 0;
				Ord_Res->fTriggerPrice= 0;//23.06; //atof(Row[19]);
				strncpy(Ord_Res->sOrderType,"MKT",ORDER_TYPE_LEN);
				Ord_Res->iDiscQty = 0;
				Ord_Res->iSerialNum= 2;
				Ord_Res->iTotalTradedQty= 15;
				strncpy(Ord_Res->sSecurityId,"11536",SECURITY_ID_LEN);
				strncpy(Ord_Res->sOrderValidity,"DAY",VALIDITY_LEN);
				Ord_Res->iLotsize= 1;
				Ord_Res->fAlgoOrderNo= 0;
				Ord_Res->iDiscQtyRem = 0;
				strncpy(Ord_Res->sExchOrderID,"12571284",EXCH_ORDER_NO_LEN);
				strncpy(Ord_Res->sReasonDesc,"CONFIRMED",DB_REASON_DESC_LEN);
				Ord_Res->iGrpId= 1;
				Ord_Res->fSLTrail= 0;
				Ord_Res->fSLTickValue= 0;
				Ord_Res->fPRTickValue = 0;
				Ord_Res->cOffMarketFlg= '0';
				strncpy(Ord_Res->sPanID,"ABCDE1234F",INT_PAN_LEN);
				Ord_Res->cParticipantType= 'B';
				Ord_Res->cMarkProFlag= 'N';
				Ord_Res->fMarkProVal= 0;
				strncpy(Ord_Res->sSettlor,"11159",SETTLOR_LEN);
				Ord_Res->cGTCFlag= 'N';
				Ord_Res->cEncashFlag = 'N';
				strncpy(Ord_Res->sMktType,"NL",MARKET_TYPES);
				Ord_Res->fStrikePrice= 0;
				strncpy(Ord_Res->sExpiryDate,"0001-01-01 00:00:00",DATE_TIME_LEN);
				strncpy(Ord_Res->sOption_typ,"XX",OPTION_LEN);
				strncpy(Ord_Res->sCustomSym,"NA",CUSTOM_SYM_LEN);
				strncpy(Ord_Res->sIsin,"NA",ISINCODE_LEN);
				strncpy(Ord_Res->sSeries,"XX",SERIES_LEN);
				strncpy(Ord_Res->sGtdDate,"0000-00-00",DATE_TIME_LEN);
				strncpy(Ord_Res->sRemarks,"NR",REMARKS_LEN);
				*/
		logDebug2("Data in Mapper > %s",Ord_Res->sClientId);
		logTimestamp("fMapper [Exit]");
		return TRUE;
	}
	logTimestamp("fMapper [Exit]");
}



BOOL fkafkaMapper(struct ORDER_RESPONSE *Ord_Req)
{
        logTimestamp("fkafkaMapper [Entry]");

        MYSQL_RES       *Res;
        MYSQL_ROW       *Row;

        CHAR    SelQuery[DOUBLE_MAX_QUERY_SIZE];
        memset(SelQuery,'\0',DOUBLE_MAX_QUERY_SIZE);


        if(Ord_Req->IntRespHeader.cSegment == EQUITY_SEGMENT)
	{

		sprintf(SelQuery,"SELECT EQ_REMARKS, EQ_REMARKS1, EQ_REMARKS2 FROM EQ_ORDERS WHERE EQ_ORDER_NO= %lf AND EQ_SERIAL_NO= %ld;",Ord_Req->fOrderNum,Ord_Req-> iSerialNum);

   	}
	else if (Ord_Req->IntRespHeader.cSegment == DERIVATIVE_SEGMENT || Ord_Req->IntRespHeader.cSegment == CURRENCY_SEGMENT)
	{

		sprintf(SelQuery,"SELECT DRV_REMARKS, DRV_REMARKS1, DRV_REMARKS2 FROM DRV_ORDERS WHERE DRV_ORDER_NO= %lf AND DRV_SERIAL_NO= %ld;",Ord_Req->fOrderNum,Ord_Req-> iSerialNum);

	}	 
        else if (Ord_Req->IntRespHeader.cSegment == COMMODITY_SEGMENT)
	{
		sprintf(SelQuery,"SELECT COMM_REMARKS, COMM_REMARKS1, COMM_REMARKS2 FROM COMM_ORDERS WHERE COMM_ORDER_NO= %lf AND COMM_SERIAL_NO= %ld;",Ord_Req->fOrderNum,Ord_Req-> iSerialNum);
	}

	printf("\n Query :%s: \n",SelQuery);
        if (mysql_query(DBCon, SelQuery) != SUCCESS) {
                sql_Error(DBCon);
                return FALSE;
        }

        Res = mysql_store_result(DBCon);
        if(mysql_num_rows(Res) == 0)
        {
                mysql_free_result(Res);
                return NO_ROW;
        }
        else
        {
                while((Row = mysql_fetch_row(Res)))
                {
                        strncpy(Ord_Req->sRemarks,Row[0],REMARKS_LEN);
                        strncpy(Ord_Req->sRemarks2,Row[1],REMARKS_LEN);
                        strncpy(Ord_Req->sRemarks3,Row[2],REMARKS_LEN);

			logDebug2("Ord_Req->sRemarks = %s",Ord_Req->sRemarks );
                        logDebug2("Ord_Req->sRemarks2 = %s",Ord_Req->sRemarks2 );
                        logDebug2("Ord_Req->sRemarks3 = %s",Ord_Req->sRemarks3 );
		}
		mysql_free_result(Res);
	
		logDebug2("Data in kafkamapper > %s",Ord_Req->sClientId);
                logTimestamp("fkafkaMapper [Exit]");
                return TRUE;
        }
        logTimestamp("fkafkaMapper [Exit]");
}

void base64Encoder(unsigned char * input_str, int len_str, unsigned char res_str[sizeof(struct NOTIFICATION_RESPONSE)])
{

	char char_set[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	int index, no_of_bits = 0, padding = 0, val = 0, count = 0, temp;
	int i, j, k = 0;

	for (i = 0; i < len_str; i += 3)
	{
		val = 0, count = 0, no_of_bits = 0;
		for (j = i; j < len_str && j <= i + 2; j++)
		{
			val = val << 8;
			val = val | input_str[j];
			count++;
			//printf("\n byte :%i:",input_str[j]);
			//printf("%i,",input_str[j]);
		}
		no_of_bits = count * 8;
		padding = no_of_bits % 3;
		while (no_of_bits != 0)
		{
			if (no_of_bits >= 6)
			{
				temp = no_of_bits - 6;
				index = (val >> temp) & 63;
				no_of_bits -= 6;
			}
			else
			{
				temp = 6 - no_of_bits;
				index = (val << temp) & 63;
				no_of_bits = 0;
			}
			res_str[k++] = char_set[index];
		}
	}
	//printf("\n");
	//printf("\n >> :%s: \n",res_str);
	//printf("\n >> :%i: \n",padding);
	for (i = 1; i <= padding; i++)
	{
		res_str[k++] = '=';
	}

	res_str[k] = '\0';
	//printf("\n >str> :%s: \n",res_str);
}



// new Method inserted Because of Full Trade Notification vai SMS @pratik

BOOL fSmsNtyTrdToFE(struct ORDER_RESPONSE *Ord_Res)
{
	logTimestamp("********* ENTRY : [fSmsNtyTrdToFE] ***********");

	logDebug2("Sending Trade SMS  Notifications");
	CHAR 		sSelQry[MAX_QUERY_SIZE];
	CHAR 		sClName[NOTI_CLIENT_NAME_LEN];
	CHAR 		sClMob[NOTI_MOBILE_NUM_LEN];
	CHAR 		sClEmail[EMAIL_ADDR_LEN];
	CHAR 		cTradeFlag;
	CHAR 		sTempSecID[DB_SCRIP_CODE_LEN];
	CHAR 		sTempSymbol[NOTI_SYMBOL_LEN];
	CHAR 		sTempInst[INSTRUMENT_LEN];
	CHAR 		sSelQuery[MAX_QUERY_SIZE];
	LONG32 		iNumRow,i;
	DOUBLE64	fTrdPrice = 0.00;
	DOUBLE64	fFinalprice = 0.00;
	LONG32		iMcxMultiplr;
	LONG32		iCurMultiplr;
        CHAR 		sConfig2[MAX_QUERY_SIZE];
	INT16		iTypeFlag = 3 ;
       	CHAR 		sRdCommand[MAX_COMMAND_LEN];
	CHAR 		sRSAdd[COMMAND_LEN];
  	redisReply 	*reply1;

        INT16   	a = 0 ,c =0;
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        LONG32          iTotal;

	struct         	NOTIFY_SEC_MASTER_ARRAY  *pSec;		
 
	memset(sConfig2,'\0',MAX_QUERY_SIZE);
	memset(sClName,'\0',NOTI_CLIENT_NAME_LEN);
	memset(sClMob,'\0',NOTI_MOBILE_NUM_LEN);
	memset(sClEmail,'\0',EMAIL_ADDR_LEN);
	memset(sSelQry,'\0',MAX_QUERY_SIZE);
	memset(sTempSecID,'\0',DB_SCRIP_CODE_LEN);
	memset(sTempSymbol,'\0',NOTI_SYMBOL_LEN);
	memset(sSelQuery,'\0',MAX_QUERY_SIZE);
	memset(sTempInst,'\0',INSTRUMENT_LEN);
	// Type added for part traded order sms and email @Ketan
	// 1424: Trade SMS and Email approach change
	memset(sRdCommand,'\0',MAX_COMMAND_LEN);
	memset(sRSAdd,'\0',COMMAND_LEN);
	
	pSec = (struct NOTIFY_SEC_MASTER_ARRAY *)malloc(sizeof(struct NOTIFY_SEC_MASTER_ARRAY));


	/** Inserted by Ketan for Trade  Notification 	*****/

	logDebug2("Ord_Res->iTotalQtyRem = %d",Ord_Res->iTotalQtyRem );
	logDebug2("Ord_Res->iTotalQty= %d",Ord_Res->iTotalQty);
	logDebug2("Ord_Res->sClientId= %s",Ord_Res->sClientId);
	logDebug2("Ord_Res->sPanID= %s",Ord_Res->sPanID);
	logDebug2("Ord_Res->sTransacTime= %s",Ord_Res->sTransacTime);
	logDebug2("Ord_Res->IntRespHeader.cSegment= %c",Ord_Res->IntRespHeader.cSegment);
	logDebug2("Ord_Res->fTradePrice= %f",Ord_Res->fTradePrice);
	logDebug2("Ord_Res->iTotalTradedQty= %d",Ord_Res->iTotalTradedQty);
	logDebug2("Ord_Res->IntRespHeader.sExcgId= %s",Ord_Res->IntRespHeader.sExcgId);
	logDebug2("Ord_Res->sSecurityId= %s",Ord_Res->sSecurityId);
	logDebug2("Ord_Res->sTradeNo	= %s",Ord_Res->sTradeNo);
	logDebug2("Ord_Res->cBuyOrSell= %c",Ord_Res->cBuyOrSell);

	if(Ord_Res->iTotalQtyRem == 0)
	{
		sprintf(sSelQry,"SELECT IFNULL(ENTITY_EMAIL,'NA'),IFNULL(ENTITY_MOBILE,'NA'),IFNULL(ENTITY_NAME,'NA'),IFNULL(ENTITY_TRADE_NOTIFIER,'N') from ENTITY_MASTER WHERE ENTITY_CODE = '%s';",Ord_Res->sClientId );	
		logDebug2("sSelQry->:%s:",sSelQry);
		if(mysql_query(DBCon,sSelQry) != SUCCESS)
		{
			sql_Error(DBCon);
			logSqlFatal("Error IN SELECT QUERY.");
		}
		Res = mysql_store_result(DBCon);
		if(Res)
		{
			iTotal = mysql_num_rows(Res);
			Row = mysql_fetch_row(Res);
			logDebug2("Total = %d",iTotal);
			logDebug2("CLIENT NAME = %s",Row[2]);
			logDebug2("CLIENT MOBILE = %s",Row[1]);
			logDebug2("CLIENT EMAIL = %s",Row[0]);
			logDebug2("Trade_Notifier_Flag = %c",Row[3][0]);
			strncpy(sClName,Row[2],NOTI_CLIENT_NAME_LEN);
			strncpy(sClMob,Row[1],NOTI_MOBILE_NUM_LEN);
			strncpy(sClEmail,Row[0],EMAIL_ADDR_LEN);
			cTradeFlag = Row[3][0];
			logDebug2("Trade_Notifier_Flag = %c",cTradeFlag);
			strncpy(sClName,Row[2],NOTI_CLIENT_NAME_LEN);
			mysql_free_result(Res);					
		}
		else
		{
			logDebug2("No Result Set ");
			return FALSE;

		}

		sprintf(sConfig2, "HMGET TRADE:CONFIG MAIL_FLAG SMS_FLAG TPUSH_FLAG  ");
                logTimestamp("HMGET command-> %s",sConfig2);
                logDebug2("......Connecting to Redis.....");
                reply1 = redisCommand(RdConn1,sConfig2);
                if(reply1 == NULL)
                {
                        logDebug2(".....Failed with Redis connect.....") ;
                        freeReplyObject(reply1);
                }
                else
                {
                        cMailFlag = reply1->element[0]->str[0];
                        cSmsFlag  = reply1->element[1]->str[0];
			cTPushFlag= reply1->element[2]->str[0];

                        if(cMailFlag ==  ENABLE && cSmsFlag == ENABLE && cTPushFlag == ENABLE )
                        {
                                iNotifyMail = TRUE;
                                iNotifySms  = TRUE;
				iNotifyTPush= TRUE;

                        }
                        else if(cMailFlag == ENABLE && cSmsFlag == ENABLE && cTPushFlag == DISABLE )
                        {
                                iNotifyMail = TRUE;
                                iNotifySms  = TRUE;
				iNotifyTPush= FALSE;

                        }
                        else if(cMailFlag == ENABLE && cSmsFlag == DISABLE  && cTPushFlag == ENABLE )
                        {
                                iNotifyMail = TRUE;
                                iNotifySms  = FALSE;
                                iNotifyTPush= TRUE;

                        }
                        else if(cMailFlag == DISABLE && cSmsFlag == ENABLE && cTPushFlag == ENABLE )
                        {
                                iNotifyMail = FALSE;
                                iNotifySms  = TRUE;
				iNotifyTPush= TRUE;

                        }
                        else if(cMailFlag ==  DISABLE && cSmsFlag == DISABLE && cTPushFlag == ENABLE )
                        {
                                iNotifyMail = FALSE;
                                iNotifySms  = FALSE;
                                iNotifyTPush= TRUE;
                        }
                        else if(cMailFlag ==  DISABLE && cSmsFlag == ENABLE && cTPushFlag == DISABLE )
                        {
                                iNotifyMail = FALSE;
                                iNotifySms  = TRUE;
                                iNotifyTPush= FALSE;
                        }
                        else if(cMailFlag ==  ENABLE && cSmsFlag == DISABLE && cTPushFlag == DISABLE )
                        {
                                iNotifyMail = TRUE;
                                iNotifySms  = FALSE;
                                iNotifyTPush= FALSE;
                        }
                        else if(cMailFlag ==  DISABLE && cSmsFlag == DISABLE && cTPushFlag == DISABLE )
                        {
                                iNotifyMail = FALSE;
                                iNotifySms  = FALSE;
                                iNotifyTPush= FALSE;
                        }

                        else
                        {
                                logDebug2("Invalid MailFalg and Smsflag.Not Sending SMS and Email");
				return FALSE;
                        }
                }
                logDebug2("iNotifyMail is %d",iNotifyMail);
                logDebug2("iNotifySms is %d",iNotifySms);
		logDebug2("iNotifyTPush is %d",iNotifyTPush);

		sprintf(sTempSecID,"%s%s%c",Ord_Res->sSecurityId,Ord_Res->IntRespHeader.sExcgId,Ord_Res->IntRespHeader.cSegment);
		logDebug2("sTempSecID SECID,EXCHID,SEG :%s:",sTempSecID);

		HASH_FIND(hSecHndlr,Hash_ByID,&sTempSecID,strlen(sTempSecID),pSec);
		if(pSec != NULL)
		{
			logDebug2("pSec->sSym :%s:",pSec->sSym);
			logDebug2("pSec->sInsName :%s:",pSec->sInsName);
			strncpy(sTempSymbol,pSec->sSym,NOTI_SYMBOL_LEN);
			strncpy(sTempInst,pSec->sInsName,INSTRUMENT_LEN);
			logDebug2("pRes->sSymbol :%s:",sTempSymbol);
			iMcxMultiplr = pSec->iMcxMultiplr;
			iCurMultiplr = pSec->iCurMultiplr;
                        logDebug2("MCX Multiplier = %d , Currency Multiplier = %d",iMcxMultiplr,iCurMultiplr);
		}else{

			sprintf(sSelQuery,"SELECT SM_EXCHANGE,SM_SEGMENT,SM_SCRIP_CODE,SM_EXCH_SCRIP_CODE,ifnull(SM_ISIN_CODE,1),IFNULL(SM_SYMBOL,''),\
					IFNULL(SM_SYMBOL_NAME,''),SM_INSTRUMENT_NAME,ifnull(SM_SERIES,''),SM_STATUS,ifnull(SM_EXCH_STATUS,'D'),ifnull(SM_MCX_MULTIPLIER,1),\
					ifnull(SM_CURRENCY_MULTIPLIER,'1')FROM SECURITY_MASTER WHERE SM_STATUS = 'A' ;");

			logDebug1("sSelQuery :%s:",sSelQuery);

			if(mysql_query(DBCon,sSelQuery) != SUCCESS)
			{
				logSqlFatal("Some thing wrong with sSelQuery query Pls check [fAddSecHash]");
				sql_Error(DBCon);
				return FALSE;
			}

			Res = mysql_store_result(DBCon);

			iNumRow = mysql_num_rows(Res);	
			logDebug1("iNumRow :%d:",iNumRow);

			if(iNumRow == 0)
			{
				logFatal("Num Of Row Fetched :%d:",iNumRow);
				return FALSE;
			}
			struct NOTIFY_SEC_MASTER_ARRAY *EqSecHsh[iNumRow];
			i=0;
			while(Row = mysql_fetch_row(Res))
			{
				logInfo("Row count :%d: :%s: :%s: :%s: ",i,Row[2],Row[0],Row[1]);
				EqSecHsh[i] = (struct NOTIFY_SEC_MASTER_ARRAY *)malloc(sizeof(struct NOTIFY_SEC_MASTER_ARRAY));

				strncpy(EqSecHsh[i]->sExch,Row[0],DB_EXCH_ID_LEN);
				strncpy(EqSecHsh[i]->sScripCode,Row[2],DB_SCRIP_CODE_LEN);
				sprintf(EqSecHsh[i]->sUnqScripCode,"%s%s%s",Row[2],Row[0],Row[1]); //Unique Key Combination of ScripCode ,Exch,Seg
				strncpy(EqSecHsh[i]->sISINCode,Row[4],DB_ISIN_CODE_LEN);
				strncpy(EqSecHsh[i]->sSym,Row[5],NOTI_SYMBOL_LEN);
				strncpy(EqSecHsh[i]->sSymName,Row[6],DB_SYM_NAME_LEN);
				strncpy(EqSecHsh[i]->sInsName,Row[7],DB_INS_LEN);
				strncpy(EqSecHsh[i]->sSeries,Row[8],DB_SERIES_LEN);
				EqSecHsh[i]->iMcxMultiplr = atoi(Row[11]);
				EqSecHsh[i]->iCurMultiplr = atoi(Row[12]);
				
				HASH_ADD(hSecHndlr,Hash_ByID,sUnqScripCode,strlen(EqSecHsh[i]->sUnqScripCode),EqSecHsh[i]);
				i++;
			}
			mysql_free_result(Res);					
			logDebug2("sTempSecID :%s:",sTempSecID);
			HASH_FIND(hSecHndlr,Hash_ByID,&sTempSecID,strlen(sTempSecID),pSec);
			logDebug2("pSec->sSym :%s:",pSec->sSym);
			strncpy(sTempSymbol,pSec->sSym,NOTI_SYMBOL_LEN);
			logDebug2("pRes->sSymbol :%s:",sTempSymbol);
			strncpy(sTempInst,pSec->sInsName,INSTRUMENT_LEN);
			iMcxMultiplr = pSec->iMcxMultiplr;
			iCurMultiplr = pSec->iCurMultiplr;
                        logDebug2("MCX Multiplier = %d , Currency Multiplier = %d",iMcxMultiplr,iCurMultiplr);
		}
// Trade Price for Part traded cancelled order case @Ketan
		memset(sSelQry,'\0',MAX_QUERY_SIZE);
		if(Ord_Res->IntRespHeader.cSegment  == EQUITY_SEGMENT)
		{
			sprintf(sSelQry,"select IFNULL(ROUND((SUM(EQ_TRD_TRADE_PRICE * EQ_LAST_TRADE_QTY) / SUM(EQ_LAST_TRADE_QTY)),2),0) AS AVG_TRADE_PRICCE from EQ_ORDERS s where s.EQ_EXCH_ORDER_NO = \"%s\" and EQ_MSG_CODE =2222 AND s.EQ_BUY_SELL_IND = \'%c\' ;",Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell);
		}
		else if(Ord_Res->IntRespHeader.cSegment  == DERIVATIVE_SEGMENT || Ord_Res->IntRespHeader.cSegment  == CURRENCY_SEGMENT)
                {
                        sprintf(sSelQry,"select  IFNULL(ROUND((SUM(DRV_TRD_TRADE_PRICE * DRV_TRD_TRADE_QTY) / SUM(DRV_TRD_TRADE_QTY)),4),0) AS AVG_TRADE_PRICCE from DRV_ORDERS s where s.DRV_EXCH_ORDER_NO = \"%s\" and DRV_MSG_CODE =2222 AND DRV_BUY_SELL_IND = \'%c\' ;",Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell);
                }
                else if(Ord_Res->IntRespHeader.cSegment  == COMMODITY_SEGMENT)
                {
                        sprintf(sSelQry,"select IFNULL(ROUND((SUM(COMM_TRD_TRADE_PRICE * COMM_TRD_TRADE_QTY) / SUM(COMM_TRD_TRADE_QTY)),2),0) AS AVG_TRADE_PRICCE  from COMM_ORDERS s where s.COMM_EXCH_ORDER_NO = \"%s\"  and COMM_MSG_CODE =2222 AND COMM_BUY_SELL_IND  = \'%c\' ;",Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell);
                }
		
                
                logDebug2("sSelQry->:%s:",sSelQry);
                if(mysql_query(DBCon,sSelQry) != SUCCESS)
                {
                        sql_Error(DBCon);
                        logSqlFatal("Error IN SELECT QUERY.");
			return FALSE;
                }
                Res = mysql_store_result(DBCon);
                if(Res)
                {
                        iTotal = mysql_num_rows(Res);
                        Row = mysql_fetch_row(Res);
			fTrdPrice = atof(Row[0]);
                        mysql_free_result(Res);
                }
                else
                {
                        logDebug2("No Result Set ");
			return FALSE;

                }
	// check for part traded order check	
		if(Ord_Res->IntRespHeader.iMsgCode == TC_INT_OC_CONF_RESP && Ord_Res->iTotalTradedQty != 0)
		{
			logInfo("This is part traded case so setting type to part trade");
			iTypeFlag = 7;
		}
		else
		{
			logInfo("This is full traded order ");
			iTypeFlag =3 ;
		}		
	
		for(a =0; a< strlen(sClName); a++, c++)
                {
                        if(sClName[a]==' ')
			{
				sClName[c] = '_';	
			}
		}			
		
		logInfo("sClName :%s:",sClName);
		
		logDebug2("Trade price = %f  total qty = %d",fTrdPrice,Ord_Res->iTotalQty);
		if(Ord_Res->IntRespHeader.cSegment == 'E' || Ord_Res->IntRespHeader.cSegment == 'D'){
			
			fFinalprice = fTrdPrice * Ord_Res->iTotalQty;
			logDebug2("Final Price = %.2lf", fFinalprice);

		}else if(Ord_Res->IntRespHeader.cSegment == 'C'){
			
			fFinalprice = fTrdPrice * Ord_Res->iTotalQty * iCurMultiplr ;
                        logDebug2("Final Price = %.4lf and Multiplier = %d", fFinalprice,iCurMultiplr);

		}else if(Ord_Res->IntRespHeader.cSegment == 'M'){
                        
			fFinalprice = fTrdPrice * Ord_Res->iTotalQty * iMcxMultiplr ;
                        logDebug2("Final Price = %.2lf", fFinalprice);

                }

		
		if(iNotifySms == TRUE && (cTradeFlag == TRADE_SMS_EMAIL_FLAG || cTradeFlag == TRADE_SMS_FLAG))
		{
			logDebug2("==========SENDING SMS=========");
			if(Ord_Res->IntRespHeader.cSegment == 'C'){
			sprintf(sRdCommand,"HMSET SMS:TRADE:%s:%c CLIENTNAME  %s  CLIENTID  %s  PASSWD NA   EMAIL  %s  TYPE  %d  NUMBER  %s  PAN  %s  SEGMENT  %c  PRICE  %.4lf  QTY  %d  EXCHANGE  %s  SCRIPTNAME  %s  BUYSELL  %c  ORDERNUMB  %.0f  TRADENUMB  %s  SOURCE  %c  USERTYPE  %c  INSTRUMENT  %s  PARTQTY  %d FINALPRICE %.4lf MULTIPLIER %d NOTI_FLAG S ",\
				Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell,sClName,Ord_Res->sClientId,sClEmail,iTypeFlag,sClMob,Ord_Res->sPanID,\
                                Ord_Res->IntRespHeader.cSegment,fTrdPrice,\
                                Ord_Res->iTotalQty,Ord_Res->IntRespHeader.sExcgId,sTempSymbol,Ord_Res->cBuyOrSell,Ord_Res->fOrderNum,Ord_Res->sTradeNo,\
                                Ord_Res->IntRespHeader.cSource,Ord_Res->cUserType,sTempInst, Ord_Res->iTotalTradedQty,fFinalprice,iCurMultiplr);
			logDebug2("sRdCommand :%s:",sRdCommand);
			}
			else{
                        sprintf(sRdCommand,"HMSET SMS:TRADE:%s:%c CLIENTNAME  %s  CLIENTID  %s  PASSWD NA   EMAIL  %s  TYPE  %d  NUMBER  %s  PAN  %s  SEGMENT  %c  PRICE  %.2lf  QTY  %d  EXCHANGE  %s  SCRIPTNAME  %s  BUYSELL  %c  ORDERNUMB  %.0f  TRADENUMB  %s  SOURCE  %c  USERTYPE  %c  INSTRUMENT  %s  PARTQTY  %d FINALPRICE %.2lf MULTIPLIER %d NOTI_FLAG S ",\
                                Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell,sClName,Ord_Res->sClientId,sClEmail,iTypeFlag,sClMob,Ord_Res->sPanID,\
                                Ord_Res->IntRespHeader.cSegment,fTrdPrice,\
                                Ord_Res->iTotalQty,Ord_Res->IntRespHeader.sExcgId,sTempSymbol,Ord_Res->cBuyOrSell,Ord_Res->fOrderNum,Ord_Res->sTradeNo,\
                                Ord_Res->IntRespHeader.cSource,Ord_Res->cUserType,sTempInst, Ord_Res->iTotalTradedQty,fFinalprice,iMcxMultiplr);
                        logDebug2("sRdCommand :%s:",sRdCommand);
			}
	
			reply1 = redisCommand(RdConn,sRdCommand);
			if(reply1 == NULL)
			{
				logInfo("reply1 is null");
			}
                        freeReplyObject(reply1);
			
			sprintf(sRSAdd,"SADD TRADE:NOTIFY  SMS:TRADE:%s:%c",Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell);
		
			logDebug2("sRSAdd :%s:",sRSAdd);
                        reply1 = redisCommand(RdConn,sRSAdd);
			if(reply1 == NULL)
			{
				logInfo("reply1 is null");
			}
                        freeReplyObject(reply1);
			

		}else
		{
			logDebug2(" CLIENT TEADE SMS DISABLE");
		}
		if(iNotifyMail == TRUE && (cTradeFlag == TRADE_SMS_EMAIL_FLAG || cTradeFlag == TRADE_EMAIL_FLAG))
		{

			memset(sRdCommand,'\0',MAX_COMMAND_LEN);
			memset(sRSAdd,'\0',COMMAND_LEN);
			logDebug2("==========SENDING EMAIL=========");

			if(Ord_Res->IntRespHeader.cSegment == 'C'){
			sprintf(sRdCommand,"HMSET MAIL:TRADE:%s:%c CLIENTNAME  %s  CLIENTID  %s  PASSWD NA   EMAIL  %s  TYPE  %d  NUMBER  %s  PAN  %s  SEGMENT  %c  PRICE  %.4lf  QTY  %d  EXCHANGE  %s  SCRIPTNAME  %s  BUYSELL  %c  ORDERNUMB  %.0f  TRADENUMB  %s  SOURCE  %c  USERTYPE  %c  INSTRUMENT  %s  PARTQTY  %d FINALPRICE %.4lf MULTIPLIER %d NOTI_FLAG M ",\
                                Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell,sClName,Ord_Res->sClientId,sClEmail,iTypeFlag,sClMob,Ord_Res->sPanID,\
                                Ord_Res->IntRespHeader.cSegment,fTrdPrice,\
                                Ord_Res->iTotalQty,Ord_Res->IntRespHeader.sExcgId,sTempSymbol,Ord_Res->cBuyOrSell,Ord_Res->fOrderNum,Ord_Res->sTradeNo,\
                                Ord_Res->IntRespHeader.cSource,Ord_Res->cUserType,sTempInst, Ord_Res->iTotalTradedQty,fFinalprice,iCurMultiplr);
                        logDebug2("sRdCommand :%s:",sRdCommand);
			}
			else{
			sprintf(sRdCommand,"HMSET MAIL:TRADE:%s:%c CLIENTNAME  %s  CLIENTID  %s  PASSWD NA   EMAIL  %s  TYPE  %d  NUMBER  %s  PAN  %s  SEGMENT  %c  PRICE  %.2lf  QTY  %d  EXCHANGE  %s  SCRIPTNAME  %s  BUYSELL  %c  ORDERNUMB  %.0f  TRADENUMB  %s  SOURCE  %c  USERTYPE  %c  INSTRUMENT  %s  PARTQTY  %d FINALPRICE %.2lf MULTIPLIER %d NOTI_FLAG M ",\
                                Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell,sClName,Ord_Res->sClientId,sClEmail,iTypeFlag,sClMob,Ord_Res->sPanID,\
                                Ord_Res->IntRespHeader.cSegment,fTrdPrice,\
                                Ord_Res->iTotalQty,Ord_Res->IntRespHeader.sExcgId,sTempSymbol,Ord_Res->cBuyOrSell,Ord_Res->fOrderNum,Ord_Res->sTradeNo,\
                                Ord_Res->IntRespHeader.cSource,Ord_Res->cUserType,sTempInst, Ord_Res->iTotalTradedQty,fFinalprice,iMcxMultiplr);
			logDebug2("sRdCommand :%s:",sRdCommand);
			}

                        reply1 = redisCommand(RdConn,sRdCommand);
                        if(reply1 == NULL)
                        {
                                logInfo("reply1 is null");
                        }
                        freeReplyObject(reply1);

                        sprintf(sRSAdd,"SADD TRADE:NOTIFY  MAIL:TRADE:%s:%c",Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell);

                        logDebug2("sRSAdd :%s:",sRSAdd);
                        reply1 = redisCommand(RdConn,sRSAdd);
                        if(reply1 == NULL)
                        {
                                logInfo("reply1 is null");
                        }
                        freeReplyObject(reply1);

		}
                else
                {
                        logDebug2(" CLIENT TRADE EMAIL FLAG DISABLE");
                }


                if(iNotifyTPush == TRUE && (cTradeFlag == TRADE_SMS_EMAIL_FLAG || cTradeFlag == TRADE_TPUSH_FLAG))
                {

                        memset(sRdCommand,'\0',MAX_COMMAND_LEN);
                        memset(sRSAdd,'\0',COMMAND_LEN);

                        logDebug2("==========SENDING PUSH NOTIFICATION=========");

                        if(Ord_Res->IntRespHeader.cSegment == 'C'){
                        sprintf(sRdCommand,"HMSET TPUSH:TRADE:%s:%c CLIENTNAME  %s  CLIENTID  %s  PASSWD NA   EMAIL  %s  TYPE  %d  NUMBER  %s  PAN  %s  SEGMENT  %c  PRICE  %.4lf  QTY  %d  EXCHANGE  %s  SCRIPTNAME  %s  BUYSELL  %c  ORDERNUMB  %.0f  TRADENUMB  %s  SOURCE  %c  USERTYPE  %c  INSTRUMENT  %s  PARTQTY  %d FINALPRICE %.4lf MULTIPLIER %d NOTI_FLAG P ",\
                                Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell,sClName,Ord_Res->sClientId,sClEmail,iTypeFlag,sClMob,Ord_Res->sPanID,\
                                Ord_Res->IntRespHeader.cSegment,fTrdPrice,\
                                Ord_Res->iTotalQty,Ord_Res->IntRespHeader.sExcgId,sTempSymbol,Ord_Res->cBuyOrSell,Ord_Res->fOrderNum,Ord_Res->sTradeNo,\
                                Ord_Res->IntRespHeader.cSource,Ord_Res->cUserType,sTempInst, Ord_Res->iTotalTradedQty,fFinalprice,iCurMultiplr);
                        logDebug2("sRdCommand :%s:",sRdCommand);
                        }
                        else{
                        sprintf(sRdCommand,"HMSET TPUSH:TRADE:%s:%c CLIENTNAME  %s  CLIENTID  %s  PASSWD NA   EMAIL  %s  TYPE  %d  NUMBER  %s  PAN  %s  SEGMENT  %c  PRICE  %.2lf  QTY  %d  EXCHANGE  %s  SCRIPTNAME  %s  BUYSELL  %c  ORDERNUMB  %.0f  TRADENUMB  %s  SOURCE  %c  USERTYPE  %c  INSTRUMENT  %s  PARTQTY  %d FINALPRICE %.2lf MULTIPLIER %d NOTI_FLAG P ",\
                                Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell,sClName,Ord_Res->sClientId,sClEmail,iTypeFlag,sClMob,Ord_Res->sPanID,\
                                Ord_Res->IntRespHeader.cSegment,fTrdPrice,\
                                Ord_Res->iTotalQty,Ord_Res->IntRespHeader.sExcgId,sTempSymbol,Ord_Res->cBuyOrSell,Ord_Res->fOrderNum,Ord_Res->sTradeNo,\
                                Ord_Res->IntRespHeader.cSource,Ord_Res->cUserType,sTempInst, Ord_Res->iTotalTradedQty,fFinalprice,iMcxMultiplr);
			logDebug2("sRdCommand :%s:",sRdCommand);
                        }
                        reply1 = redisCommand(RdConn,sRdCommand);
                        if(reply1 == NULL)
                        {
                                logInfo("reply1 is null");
                        }
                        freeReplyObject(reply1);

                        sprintf(sRSAdd,"SADD TRADE:NOTIFY TPUSH:TRADE:%s:%c",Ord_Res->sExchOrderID,Ord_Res->cBuyOrSell);

                        logDebug2("sRSAdd :%s:",sRSAdd);
                        reply1 = redisCommand(RdConn,sRSAdd);
                        if(reply1 == NULL)
                        {
                                logInfo("reply1 is null");
                        }
                        freeReplyObject(reply1);

                }

		else
		{
			logDebug2(" CLIENT TRADE PUSH FLAG DISABLE");
		}


		logTimestamp("********* EXIT : [fSmsNtyTrdToFE] ***********");
		return TRUE ;

	}
	else
	{
		logDebug2("This is PART-TRADE ");
	}
}




