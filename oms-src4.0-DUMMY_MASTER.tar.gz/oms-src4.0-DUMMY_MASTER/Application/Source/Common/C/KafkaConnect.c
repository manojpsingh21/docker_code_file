#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include "rdkafka.h"


rd_kafka_conf_t ConnectKafka(rd_kafka_conf_t *ConnObj)
{
	logTimestamp("Entry : ConnectKafka");

	CHAR	sHostIp[URL_LEN];
	CHAR	sKafkaPass[20];	
	CHAR	sHostPort[10];
	
	memset(sHostIp,'\0',URL_LEN);
	memset(sKafkaPass,'\0',20);
	memset(sHostPort,'\0',10);

	logTimestamp("Exit : ConnectKafka");

}
