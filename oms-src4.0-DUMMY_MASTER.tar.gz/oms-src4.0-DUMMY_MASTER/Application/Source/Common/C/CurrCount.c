#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include "IPCS.h"

MYSQL		*DB_Con;
MYSQL_RES	*Res;
MYSQL_ROW	Row;

main()
{
	LONG32	iCount;
	LONG32	iCnt;

	DB_Con=DB_Connect();
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	logDebug2("Using Table DRV_L1_WATCH");
	while(TRUE)
	{
		CHAR *SelQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
		CHAR *SelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

		sprintf(SelQry,"select count(*) from DRV_L1_WATCH s where s.DL1_SEGMENT = 'C' and s.DL1_ENTRY_TIME > now()-1;");
		if(mysql_query(DB_Con,SelQry) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in select count Query [CurrCount].");
			return FALSE;
		}
		Res = mysql_store_result(DB_Con);
		Row = mysql_fetch_row(Res);
		iCount=atoi(Row[0]);
		mysql_free_result(Res);	
		logTimestamp("Currency Count After :%d:",iCount);

		sprintf(SelQuery,"select count(*) from DRV_L1_WATCH s where s.DL1_SEGMENT = 'C' and s.DL1_ENTRY_TIME < now()-1;");
		if(mysql_query(DB_Con,SelQuery) != SUCCESS)
		{
			sql_Error(DB_Con);
			logSqlFatal("Error in COUNT QUERY.......[CurrCount]");
			return FALSE;
		}
		Res = mysql_store_result(DB_Con);
		Row = mysql_fetch_row(Res);
		iCnt=atoi(Row[0]);
		mysql_free_result(Res);
		logTimestamp("Currency Count Before:%d:",iCnt);		
		sleep(1);

	}

}					
