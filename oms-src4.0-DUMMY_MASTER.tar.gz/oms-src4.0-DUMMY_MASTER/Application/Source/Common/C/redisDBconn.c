#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"

MYSQL           *DBCon;
MYSQL_RES       *Res;
MYSQL_ROW       Row;
redisContext    *RDCon ;

int main()
{
	RmsBlockLog();
}

int RmsBlockLog()
{
	redisReply *reply;
	INT16   iNumRow;
	CHAR            *sSelQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            *sRedQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	sprintf(sSelQuery, "SELECT * FROM RMS_BLOCK_LOG;");
	printf("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBCon,sSelQuery) != 0)
	{
		printf("Some thing wrong with sSelQuery query Pls check");
		sql_Error(DBCon);
		mysql_close(DBCon);
		return (-1);
	}
	Res = mysql_store_result(DBCon);
	iNumRow = mysql_num_rows(Res);
	logDebug1("iNumRow :%i:",iNumRow);
	while(Row = mysql_fetch_row(Res))
	{
		sprintf(sRedQuery,"HMSET %s:%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",RBL_CLIENT_ID,Row[0],Row[0],RBL_SCRIP_CODE,Row[1],RBL_ORDBUYSELL,Row[2],RBL_ORDQTY,Row[3],RBL_ORDERRATE,Row[4],RBL_PRODUCTCODE,Row[5],RBL_SEGMENT,Row[6],RBL_EXCH_ID,Row[7],RBL_ORDNO,Row[8],RBL_ORDVERSIONNO,Row[9],RBL_ORDERTYPE,Row[10],RBL_ORDEXECUTIONSTATUS,Row[11],RBL_TRADE_DATE,Row[12],RBL_MKT_TYPE,Row[13],RBL_RMS_STATUS,Row[14],RBL_AMOUNT_BLOCKED,Row[15],RBL_INSUFFICIENT_QTY,Row[16],RBL_INSUFFICIENT_AMT,Row[17],RBL_ORDER_TIMESTAMP,Row[18],RBL_MKT_ORDER,Row[19],RBL_ORD_TRANS_CODE,Row[20],RBL_DESCRIPTOR,fStrTrim(Row[21],strlen(Row[21])));

		printf("sRedQuery :%s:",sRedQuery);
		reply = redisCommand(RDCon,sRedQuery);
		if(!strcasecmp(reply->str,"OK"))
		{
			logDebug2("Values added for ID[%s]",Row[0]);
		}
		else if(reply->type == REDIS_REPLY_ERROR)
		{
			logFatal("Error in adding values :%s:",reply->str);
		}
		freeReplyObject(reply);


	}
	return 0;
}




