#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"
#include "FIXStructures.h"

BOOL	fRecv(LONG32 iSocketfd, CHAR *cRecvData, LONG32 *iRecvLen, SHORT iFlags);
BOOL	fSend(LONG32 iSocketfd, CHAR *cSendData, LONG32 *iSendLen, SHORT iFlags);

void	fConnectionUp();
void	fConnectionDown();
void	fRestartProcess();

BOOL	fSendBusinessRejectFor(CHAR *In);

void	fSocketToQueueThread();
void	fQueueToSocketThread();

LONG32	iFwdMapToInterfaceNSEDRV = 0 ,iInterfaceToRevMapNSEDRV = 0 ;
LONG32	iConnected = FALSE;

pthread_t 	th_id1;
pthread_t	th_id2;

LONG32	iSocket;
INT16	iMsgType;
CHAR	cSegment;

int main(LONG32	argc,CHAR **argv)
{
	LONG32	iSize = 512*1024;
	struct 	sockaddr_in  pCliAdd,pServAdd;
	CHAR	sFixString[FIX_MAX_STRING_LEN];
	sigset_t SequenceSet;
	LONG32	Signal;
	LONG32  mainwait = -1, sig1=0;

	LONG32	iMasterSocket,iRetVal, iMaster_Port;

	setbuf(stdin,NULL);
	setbuf(stdout,NULL);
	setvbuf(stdout,NULL,_IONBF,0);

	logInfo("Parameter count :%d",argc);
	iMaster_Port = atol(argv[1]);
	iMsgType     = atoi(argv[2])	;
	cSegment     = argv[3][0];	

	logDebug3("Port Number is : %d",iMaster_Port);

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);



	fOpenMsgQue();

	if((iMasterSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		logFatal("Error in Socket");
		exit(ERROR);
	}

	logDebug3("Socket Created :%d",iMasterSocket);

	memset((CHAR *)&pServAdd,'0',sizeof(struct sockaddr_in) );
	pServAdd.sin_family      = AF_INET;
	pServAdd.sin_port        = htons(iMaster_Port);
	pServAdd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetVal = 1;

	if(setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetVal,sizeof(iRetVal)) == ERROR)
	{
		logFatal("Error in setting Socket Option");
		exit(ERROR);
	}

	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&iSize, sizeof(iSize))<0)
	{
		perror("setsockopt: ");
		printf("\n Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}


	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&iSize, sizeof(iSize))<0)
	{
		perror("setsockopt: ");
		printf("\n Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}

	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_KEEPALIVE, (char *)&iSize, sizeof(iSize))<0)
	{
		perror("setsockopt: ");
		printf("\n Error in setsockopt on the MasterSocket:SO_KEEPALIVE:");
		exit(1);
	}

	if(bind(iMasterSocket,(struct sockaddr *)&pServAdd,sizeof(pServAdd)) == ERROR)
	{
		logFatal("Error Binding Socket");
		exit(ERROR);
	}

	fConnectionDown();

	listen(iMasterSocket, 1);

	while(1)
	{
		memset((CHAR *)&pCliAdd,'\0',sizeof(struct sockaddr_in));
		fConnectionDown();

		while(1)
		{
			if ((iRetVal= ReadNBQ(iFwdMapToInterfaceNSEDRV, sFixString,FIX_MAX_STRING_LEN, 1)) != TRUE)
			{
				printf("\n Now no pending orders in queue");
				break;
			}
			printf("\n Clearing pending orders in queue");
			fSendBusinessRejectFor( sFixString);
		}

		logDebug3("============= Waiting for FIX Engine to connect on port : %d ===========",iMaster_Port);
		iRetVal = sizeof(struct sockaddr);

		if((iSocket = accept(iMasterSocket,(struct sockaddr *)&pCliAdd,&iRetVal)) < 0)	
		{
			logDebug3("Error while accepting connection");
			continue;
		}

		logDebug3("New Socket Connection Established on : %d", iSocket);

		iConnected = TRUE;
		//	fConnectionUp();

		if((pthread_create(&th_id2,NULL,fQueueToSocketThread,NULL)) != 0)
		{
			logFatal("\n pthread_create:QueueToSocketThread");
			exit(ERROR);
		}

		if((pthread_create(&th_id1,NULL,fSocketToQueueThread,NULL)) != 0)
		{
			logFatal("\n pthread_create:SocketToQueueThread");
			exit(ERROR);
		}
		/****
		  pthread_join(th_id1,NULL);
		  pthread_join(th_id2,NULL);
		 *****/
		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while( TRUE )
		{
			printf("Waiting For Signal");
			mainwait = sigwait( &SequenceSet,&Signal);
			printf("\n Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				printf("\n SIGTERM in Main");
				fConnectionDown();
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				printf("\n SIGUSR1 in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Break from loop");
				break;
			}
			else
			{
				printf("\n Received some other signal");
				printf("\n Closing Socket");
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}

		}
	}/*******While loop ends **********/


}

BOOL	fSend(LONG32 iSocketfd, CHAR *sSendData, LONG32 *iSendLen, SHORT iFlags)
{
	SHORT	iTotalLen= 0;
	SHORT	iBytesLeft = *iSendLen;
	SHORT	iBytes;

	while(iTotalLen < *iSendLen)
	{
		logDebug3("sending fix msg :%d: Socketid :%d:",iTotalLen,iSocketfd);
		if((iBytes = send(iSocketfd,sSendData + iTotalLen,iBytesLeft,iFlags)) <= 0)
		{
			perror("send Error is");
			//exit(ERROR);
			return FALSE;
		}
		logDebug3("After send Bytes = %d",iBytes);

		iTotalLen += iBytes;
		iBytesLeft -= iBytes;

	}

	iSendLen =iTotalLen;
	return TRUE;
}

BOOL fRecv(LONG32 iSocketfd, CHAR *sRecvData, LONG32 *iRecvLen, SHORT iFlags)
{
	SHORT   iTotalLen= 0;
	SHORT   iBytesLeft = *iRecvLen;
	SHORT   iBytes;

	logDebug3("Trying to Recv = %d",iRecvLen);
	while(iTotalLen < *iRecvLen)
	{
		logDebug3("Trying to recv %d bytes SocketId :%d:",iBytesLeft,iSocketfd);

		if((iBytes = recv(iSocketfd,sRecvData+iTotalLen,iBytesLeft,iFlags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}

		logDebug3("After recv Bytes = %d",iBytes);
		iTotalLen += iBytes;	
		iBytesLeft -= iBytes;
	}
	*iRecvLen =iTotalLen;
	return TRUE;
}

void    fConnectionUp()
{
	//UpdateConnectStatus(NSE_DRV_UP, 0);
	logDebug1("cSegment :%c:",cSegment);
	//UpdateConnectStatus((cSegment==DERIVATIVE_SEGMENT ? NSE_DRV_UP : NSE_CUR_UP), 0);
	UpdateConnectStatus( NSE_DRV_UP , 0);
	logDebug3(" UpdateConnectStatus UP");
	NotifyMonTool(TRUE);
	return;
}


void    fConnectionDown()
{
	//UpdateConnectStatus(cSegment==DERIVATIVE_SEGMENT ? NSE_DRV_DOWN : NSE_CUR_DOWN, 0);
	UpdateConnectStatus( NSE_DRV_DOWN , 0);
	logDebug3(" UpdateConnectStatus DOWN");
	NotifyMonTool(FALSE);
	return;	
}

void NotifyMonTool(BOOL Status)
{
	/*
	   CHAR sCmd[200];
	   memset(sCmd,'\0',200);
	   sprintf(sCmd,"%s/ExchStats.py %s %c %s >> %s/log.ExchStats &",getenv("PYTHON_PATH"),NSE_EXCH,DERIVATIVE_SEGMENT,Status==1?"UP":"DOWN",getenv("LOGDIR"));
	   logDebug2("Command -> %s",sCmd);
	   system(sCmd);
	 */
}

void    fRestartProcess()
{
	iConnected = FALSE;
	fConnectionDown();
	kill(getpid(),SIGUSR1);
	logDebug3("Sent Signal %d To pid %d",SIGUSR1,getpid());
	return ;

}


BOOL    fSendBusinessRejectFor(CHAR *sFixString)
{
	CHAR	sOutStr[RUPEE_MAX_PACKET_SIZE];
	LONG32	iRetVal;
	memset(sOutStr,'\0',RUPEE_MAX_PACKET_SIZE);
	logInfo("In fSendBusinessRejectFor");

	if(formRejectString(sFixString,sOutStr) == FALSE)
	{
		logDebug3("No Rejection string created for [%s]",sFixString);
	}
	else
	{
		logDebug3(" Received the String :%s",sOutStr);
		if((iRetVal=WriteMsgQ(iInterfaceToRevMapNSEDRV,sOutStr,strlen(sOutStr)-1,1)) == ERROR)
		{
			exit(ERROR);
		}
	}

}


void    fSocketToQueueThread()
{
	LONG32 	iRetVal=-1,iLen;
	CHAR	sFixString[FIX_MAX_STRING_LEN],sPeekString[MAX_PEEK_SIZE+1],sTempString[MAX_PEEK_SIZE+1];
	CHAR	cMsgType,*cTempPtr;
	LONG32	iCount = 0,i;
	LONG32	iLoopCount;

	while(1)
	{
		memset(sFixString,'\0',FIX_MAX_STRING_LEN);
		memset(sPeekString,'\0',MAX_PEEK_SIZE+1);
		memset(sTempString,'\0',MAX_PEEK_SIZE+1);

		iLen = MAX_PEEK_SIZE;
		logDebug3(" ================== Waiting on socket %d ==============loopcount :%d iRetval:%d",iSocket,iLoopCount,iRetVal);
		if((iRetVal = fRecv(iSocket,sPeekString,&iLen,MSG_PEEK)) == FALSE)
		{
			logDebug3(" Dropped Exchange Response while Peeking from Socket");
			logDebug3(" Error in receiving the Data from the Socket on PEEK");
			logDebug3(" iRetval in peek %d:",iRetVal);
			//	pthread_cancel(th_id2);			
			fRestartProcess();	
			return NULL;
		}	

		memcpy(sTempString,sPeekString,MAX_PEEK_SIZE);
		logDebug3("iRetval in peek %d:",iRetVal);
		logDebug3("MSG_PEEK String :[%s]",sTempString);

		iLen = 0;
		sscanf(sTempString,"%d|%c|",&iLen,&cMsgType);
		logDebug3("Len = %d cMsgType = %c iSocket=%d",iLen, cMsgType,iSocket);

		if((iRetVal = fRecv(iSocket,sFixString,&iLen,0)) == FALSE)
		{
			logDebug3(" Dropped Exchange Response while Peeking from Socket");
			logDebug3(" Error in receiving the Data from the Socket on PEEK");
			fRestartProcess();
			break;
		}

		logInfo("Received from Engine");
		logInfo("[%i *s]",iLen, sFixString);

		cTempPtr = sFixString;

		logDebug3("Received [%s]",sFixString);

		for(i=0,iCount = 0;iCount < 2;cTempPtr++)
		{
			if(cTempPtr[0] == '|')	
			{
				iCount++;
			}
			else if(cTempPtr[0] == '\0')
			{
				break;
			}

		}

		if (cMsgType == INTERFACE_CONN_UP)
		{
			/***
			 *      Now that the connection has been established inform the FE by bcasting this
			 *      information and update the shared memory as well...
			 ***/
			fConnectionUp();
			continue;
		}
		if (cMsgType == INTERFACE_CONN_DOWN)
		{
			/***
			 *      Now that the connection has been lost inform the FE by bcasting this
			 *      information and update the shared memory as well.
			 ***/
			fConnectionDown();
			continue;
		}

		if((iRetVal = WriteMsgQ(iInterfaceToRevMapNSEDRV,cTempPtr,strlen(cTempPtr)-1,1)) == ERROR)
		{
			logFatal("Dropped Exchange Response while Sending it to RevMap");
			exit(ERROR);
		}
	}
	close(iSocket);

}

void    fQueueToSocketThread()
{
	LONG32	iRetVal,iLen;
	CHAR	sFixString[FIX_MAX_STRING_LEN];

	while(1)
	{
		logDebug3("================== Waiting on the Queue =====================");
		memset(sFixString,'\0',FIX_MAX_STRING_LEN);

		if((iRetVal = ReadMsgQ(iFwdMapToInterfaceNSEDRV,sFixString,FIX_MAX_STRING_LEN,iMsgType)) == ERROR )
		{
			logFatal("ERROR in receiving the Data from the Q %d",iFwdMapToInterfaceNSEDRV);
			exit(ERROR);
		}
		/********************************
		  if (( fCheckExchStat ( LOCAL ) == FALSE ) || iConnected == FALSE  )
		  {
		  printf("\n Not Connected to Exchange, so rejecting the packet");
		  fSendBusinessRejectFor(sFixString);
		  continue ;
		  } *************************************************************/
		logDebug3(" Data Received from Queue :%s", sFixString);
		/*** Please dont remove the \n from line. Multiple
		  string have to be saperated by \n *****/

		if(sFixString[FIX_MAX_STRING_LEN - 1] != '\n')
		{
			strcat(sFixString,"\n");
		}

		iLen = strlen(sFixString);

		if((iRetVal = fSend(iSocket,sFixString,&iLen,0)) == FALSE)
		{
			logDebug3("ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
			fSendBusinessRejectFor(sFixString);
			fRestartProcess();
			break;
		}
		logInfo("Sent To Engine");


	}
}

void fOpenMsgQue()
{
	if((iFwdMapToInterfaceNSEDRV = OpenMsgQ(FwdMapToInterfaceNSEDR)) == ERROR)
	{
		logFatal("OpenMsgQ ...FwdMapToInterfaceNSEDRV");
		exit(ERROR);
	} 

	logDebug3("FwdMapToInterfaceNSEDRV opened successfully with id = %d",iFwdMapToInterfaceNSEDRV);

	if((iInterfaceToRevMapNSEDRV = OpenMsgQ(InterfaceToRevMapNSEDR)) == ERROR)
	{
		logFatal("\n InterfaceToRevMapNSEDRV opened successfully with id = %d", iInterfaceToRevMapNSEDRV);
	}
}
