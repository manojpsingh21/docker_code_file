#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"
#include "FIXStructures.h"

#define         MAX_PEEK_SIZE                 10+1

void    GOMStoFIX(void *);
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
BOOL SendBusinessRejectFor(CHAR *In);
void SocketToQueueThread ();
void QueueToSocketThread ();

LONG32  iGOMSInterfaceToRev=0, iGOMSFwdToInterface=0;
LONG32  isConnected = FALSE; 

pthread_t   th_id1;
pthread_t   th_id2;

LONG32  iSocket;


int main(LONG32 argc, CHAR **argv)
{
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	CHAR    FixString[FIX_MAX_STRING_LEN]; 
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iMasterSocket,iRetval, iMaster_Port;

	sig1 = 0;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	printf("\n PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;

	printf("\n PORT : %d", iMaster_Port ) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);


	iGOMSInterfaceToRev = OpenMsgQ(InterfaceToRevMapMCX);
	if(iGOMSInterfaceToRev < 0)
	{
		printf("\n Error in Opening InterfaceToRevMapMCX Queue");
		exit(ERROR);
	}
	printf("\n InterfaceToFIXRev Queue Opened : %d", iGOMSInterfaceToRev);

	iGOMSFwdToInterface = OpenMsgQ(FwdMapToInterfaceMCX);
	if(iGOMSFwdToInterface < 0)
	{
		printf("\n Error in Opening FwdMapToInterfaceMCX Queue");
		exit(ERROR);
	}
	printf("\n FIXFwdMapToTDWLInterface Queue Opened : %d", iGOMSFwdToInterface);

	if ((iMasterSocket=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		printf("\n Error in creating the iMasterSocket");
		exit(ERROR);
	}
	printf("\n Socket Created : %d", iMasterSocket);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iMaster_Port);
	servadd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetval = 1;
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetval, sizeof(iRetval))<0)
	{
		perror("setsockopt: ");
		printf("\n Error in setsockopt on the MasterSocket:SO_REUSEADDR:");
		exit(1);
	}

	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		printf("\n Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}


	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		printf("\n Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}

	if( bind(iMasterSocket, (struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("bind: ");
		printf("\n Error in binding to the iMasterSocket");
		exit(ERROR);
	}


	ConnectionDOWN();
	listen(iMasterSocket, 1);
	while(1)
	{
		memset((CHAR *)&cliadd, '\0', sizeof(struct sockaddr_in));
		ConnectionDOWN();

		/**
		  while(1)
		  {
		  if ((iRetval = ReadNBQ(iGOMSFwdToInterface, FixString,FIX_MAX_STRING_LEN, 1)) != TRUE)
		  {
		  printf("\n Now no pending orders in queue");
		  break;
		  }
		  SendBusinessRejectFor ( FixString );
		  }
		 **/
		printf("\n ============= Waiting for FIX Engine to connect on port : %d ===========", iMaster_Port);
		iRetval = sizeof(struct sockaddr);
		printf("\n iSocket %d:",iSocket);
		if ((iSocket = accept(iMasterSocket, (struct sockaddr *)&cliadd, &iRetval)) < 0)
		{
			perror("accept: ");
			printf("\n Error in accepting the connection %d", errno);
			continue;
		}

		printf("\n New Socket Connection Established on : %d", iSocket);
		isConnected = TRUE ;


		if((pthread_create(&th_id2,NULL,QueueToSocketThread,NULL)!= 0))
		{
			printf("\n pthread_create:QueueToSocketThread");
			exit(ERROR);
		}

		if((pthread_create(&th_id1,NULL,SocketToQueueThread,NULL)!= 0))
		{
			printf("\n pthread_create:SocketToQueueThread");
			exit(ERROR);
		}

		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while(TRUE)
		{
			mainwait = sigwait( &SequenceSet,&Signal);
			printf("\n Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				printf("\n SIGTERM in Main");
				ConnectionDOWN();
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				printf("\n SIGUSR1 in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Break from loop");
				break;
			}
			else
			{
				printf("\n Received some other signal");
				printf("\n Closing Socket");
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}

		}
		printf("\n Socket Connection closed on : %d", iSocket);
		printf("\n While Loop");
	}
}

void SocketToQueueThread()
{
	LONG32  iRetval=-1,iLen;
	CHAR    FixString[FIX_MAX_STRING_LEN], peekString[MAX_PEEK_SIZE+1],tempString[MAX_PEEK_SIZE+1];;
	CHAR    cMsgType, *tempPtr;
	LONG32	dcount = 0,i;
	LONG32 loopcount=0;

	while(1)
	{
		memset(FixString, '\0', FIX_MAX_STRING_LEN);
		memset(peekString, '\0', MAX_PEEK_SIZE+1);
		memset(tempString, '\0', MAX_PEEK_SIZE+1);

		iLen    =   MAX_PEEK_SIZE;
		printf("\n ================== Waiting on socket %d ==============loopcount :%d iRetval:%d", iSocket,loopcount++,iRetval);

		if ((iRetval = Recv(iSocket, peekString, &iLen, MSG_PEEK)) == FALSE)
		{
			printf("\n Dropped Exchange Response while Peeking from Socket");
			printf("\n Error in receiving the Data from the Socket on PEEK");	
			printf("\n iRetval in peek %d:",iRetval);
			RestartProcess();
			break;
		}

		memcpy(tempString,peekString,MAX_PEEK_SIZE);
		printf("\n iRetval in peek %d:",iRetval);
		printf("\nMSG_PEEK String :[%s]",tempString);

		iLen=0;
		sscanf(tempString,"%d|%c|",&iLen,&cMsgType);
		printf("\nLen = %d cMsgType = %c iSocket=%d",iLen, cMsgType,iSocket);


		if ((iRetval = Recv(iSocket, FixString, &iLen, 0)) == -1)
		{
			printf("\n Dropped Exchange Response while Receiving on Socket");
			printf("\n Error in receiving the Data from the Socket");
			/*** We do not need to send to Fwd or Rev this message ***/
			RestartProcess();
			break;
		}

		printf("\n Received from Engine");
		printf("\n [%.*s]", iLen, FixString);
		tempPtr = FixString;
		printf("Received=[%s]", FixString);
		for ( i=0,dcount=0 ; dcount<2 ; tempPtr++ )
		{
			if( tempPtr[0] == '|' )
				dcount++;
			if( tempPtr[0] == '\0')
				break;
		}

		/**********/
		if (cMsgType == INTERFACE_CONN_UP)
		{
			/***
			  Now that the connection has been established inform the FE by bcasting this
			  information and update the shared memory as well...
			 ***/
			ConnectionUP();
			continue;
		}
		if (cMsgType == INTERFACE_CONN_DOWN)
		{
			/***
			  Now that the connection has been lost inform the FE by bcasting this
			  information and update the shared memory as well.
			 ***/
			ConnectionDOWN();
			continue;
		}
		/****************************/
		if ((iRetval=WriteMsgQ(iGOMSInterfaceToRev,tempPtr,strlen(tempPtr)-1,1))== ERROR)
		{
			printf("\n Dropped Exchange Response while Sending it to RevMap");
			exit(ERROR);
		}
	}
	close(iSocket);

}


void QueueToSocketThread()
{
	LONG32  iRetval, iLen;
	CHAR    FixString[FIX_MAX_STRING_LEN];

	while(1)
	{
		printf("\n ================== Waiting on the Queue =====================");
		memset(FixString, '\0', FIX_MAX_STRING_LEN);
		if ((iRetval=ReadMsgQ(iGOMSFwdToInterface, FixString, FIX_MAX_STRING_LEN, 1))== ERROR)
		{
			printf("\n ERROR in receiving the Data from the Q %d", iGOMSFwdToInterface);
			exit(ERROR);
		}
		/******************************** 
		  if (( CheckExchStatus ( LOCAL ) == FALSE ) || isConnected == FALSE  )
		  {
		  printf("\n Not Connected to Exchange, so rejecting the packet");	
		  SendBusinessRejectFor(FixString);
		  continue ;
		  } ******************************************  ALOKK COMMENTED ********************/
		printf("\n Data Received from Queue :%s", FixString);
		/*** Please dont remove the \n from line. Multiple
		  string have to be saperated by \n *****/
		if( FixString[strlen(FixString)-1] != '\n')
			strcat(FixString,"\n");

		iLen = strlen(FixString);

		if ((iRetval = Send(iSocket, FixString, &iLen, 0)) == FALSE)
		{
			printf("\n ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
			SendBusinessRejectFor(FixString);
			RestartProcess();
			break;
		}
		printf("\n Sent to Engine");
	}

}

void RestartProcess()
{
	isConnected = FALSE ;
	ConnectionDOWN();
	printf("\n Before killing");
	printf ("\nI'm here!!!  My pid is %d.", (int) getpid ());
	kill(getpid(), SIGUSR1);
	printf("\n Sent Signal %d To pid %d", SIGUSR1, getpid());
	return;
}


/******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Send                                       	     **
 **                                                                           **
 **   DESCRIPTION       : Send doesnt guarantee that all the data in the      **
 **			 buffer will be sent in a single call to send, loop  **
 **			 around checking the return value till all the bytes **
 **			 are sent.					     **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc to which data will be sent.   **
 **			 SendData- Data to be sent.			     **
 **			 SendLen - Len of the data to be sent.		     **
 **			 Flags   - If any.				     **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{
		printf("\n sending fix msg :%d:", TotalLen); 
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		printf("\n After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


/*******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Recv                                                **
 **                                                                           **
 **   DESCRIPTION       : recv doesnt guarantee that all the data in the      **
 **			              buffer will be received in a single call, loop     **
 **			              around checking the return value till all the bytes **
 **			              are received.                                       **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc from which data will be recvd.**
 **			              SendData- Data to be recvd.                         **
 **			              SendLen - Len of the data to be recvd.              **
 **			              Flags   - If any.                                   **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	printf("\n Trying to Recv = %d", *RecvLen); 
	while(TotalLen < *RecvLen)
	{
		printf("\n Trying to recv %d bytes", BytesLeft);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		printf("\n After recv Bytes = %d", Bytes); 
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


BOOL SendBusinessRejectFor(CHAR *FixString)
{
	CHAR        outString[RUPEE_MAX_PACKET_SIZE];
	LONG32		iRetVal = FALSE ;
	memset(outString,'\0',RUPEE_MAX_PACKET_SIZE);

	if ( (formRejectString( FixString,outString,2)) == FALSE)
	{
		printf ("\n\t No Rejection string created for [%s]",FixString);
	}
	else
	{
		printf("\n Received the String :%s",outString);
		if ((iRetVal=WriteMsgQ(iGOMSInterfaceToRev,outString,strlen(outString)-1,1))== ERROR)
		{
			exit(ERROR);
		}
	}
}


void ConnectionUP()
{
	UpdateConnectStatus(MCX_UP, 0, BCAST_YES, TRUE);
	printf("\n UpdateConnectStatus UP");
	return;
}


void ConnectionDOWN()
{
	UpdateConnectStatus(MCX_DOWN, 0, BCAST_YES, FALSE);
	printf("\n UpdateConnectStatus DOWN");
	return;
}

