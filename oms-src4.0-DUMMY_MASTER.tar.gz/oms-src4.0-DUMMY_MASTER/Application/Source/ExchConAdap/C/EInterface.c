#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"
#include "FIXStructures.h"

void    GOMStoFIX(void *);
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
BOOL SendBusinessRejectFor(CHAR *In);
void SocketToQueueThread ();
void QueueToSocketThread ();

LONG32  iFwdMapToInterfaceNSEEQ = 0,iInterfaceToRevMapNSEEQ = 0;
LONG32  isConnected = FALSE; 

pthread_t   th_id1;
pthread_t   th_id2;

LONG32  iSocket;
INT16	iMsgType;
CHAR	cSegment;

int main(LONG32 argc, CHAR **argv)
{
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	CHAR    FixString[FIX_MAX_STRING_LEN]; 
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iMasterSocket,iRetval, iMaster_Port;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logInfo(" PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;
	iMsgType     = atoi(argv[2]);	
	cSegment	= argv[3][0];


	logDebug3(" PORT : %d", iMaster_Port ) ;
	logDebug3(" Msg Type : %d", iMsgType) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);

	OpenMsgQue();

	if ((iMasterSocket=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		logFatal(" Error in creating the iMasterSocket");
		exit(ERROR);
	}
	logDebug3(" Socket Created : %d", iMasterSocket);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iMaster_Port);
	servadd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetval = 1;
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetval, sizeof(iRetval)) == ERROR)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_REUSEADDR:");
		exit(1);
	}
	/************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}


	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}
	/**************************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_KEEPALIVE, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}



	if( bind(iMasterSocket, (struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("bind: ");
		logFatal(" Error in binding to the iMasterSocket");
		exit(ERROR);
	}


	ConnectionDOWN();
	listen(iMasterSocket, 1);
	while(1)
	{
		memset((CHAR *)&cliadd, '\0', sizeof(struct sockaddr_in));
		ConnectionDOWN();

		while(1)
		{
			if ((iRetval = ReadNBQ(iFwdMapToInterfaceNSEEQ, FixString,FIX_MAX_STRING_LEN, 1)) != TRUE)
			{
				logFatal(" Now no pending orders in queue");
				break;
			}
			logFatal(" Clearing pending orders in queue");
			SendBusinessRejectFor ( FixString );
		}


		printf("\n ============= Waiting for FIX Engine to connect on port : %d ===========", iMaster_Port);
		iRetval = sizeof(struct sockaddr);
		printf("\n iSocket %d:",iSocket);
		if ((iSocket = accept(iMasterSocket, (struct sockaddr *)&cliadd, &iRetval)) < 0)
		{
			perror("accept: ");
			printf("\n Error in accepting the connection %d", errno);
			continue;
		}

		printf("\n New Socket Connection Established on : %d", iSocket);

		isConnected = TRUE ;
		//ConnectionUP();

		if((pthread_create(&th_id2,NULL,QueueToSocketThread,NULL)!= 0))
		{
			printf("\n pthread_create:QueueToSocketThread");
			exit(ERROR);
		}

		if((pthread_create(&th_id1,NULL,SocketToQueueThread,NULL)!= 0))
		{
			printf("\n pthread_create:SocketToQueueThread");
			exit(ERROR);
		}
		/****	
		  pthread_join(th_id1,NULL);
		  pthread_join(th_id2,NULL);
		 *****/	
		/* Darshan**/
		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while( TRUE )
		{
			printf("Waiting For Signal");
			mainwait = sigwait( &SequenceSet,&Signal);
			printf("\n Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				printf("\n SIGTERM in Main");
				ConnectionDOWN();
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				printf("\n SIGUSR1 in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Break from loop");
				break;
			}
			else
			{
				printf("\n Received some other signal");
				printf("\n Closing Socket");
				ConnectionDOWN();
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}

		}
		printf("\n Socket Connection closed on : %d", iSocket);
		/* */
		printf("\n While Loop");
	}
}


void SocketToQueueThread()
{
	LONG32  iRetval=-1,iLen;
	CHAR    FixString[FIX_MAX_STRING_LEN], peekString[MAX_PEEK_SIZE+1],tempString[MAX_PEEK_SIZE+1];;
	CHAR    cMsgType, *tempPtr;
	LONG32	dcount = 0,i;
	LONG32 loopcount=0;
	LONG64                          iEntryTime,iEndTime;

	while(1)
	{
		memset(FixString, '\0', FIX_MAX_STRING_LEN);
		memset(peekString, '\0', MAX_PEEK_SIZE+1);
		memset(tempString, '\0', MAX_PEEK_SIZE+1);

		iLen    =   MAX_PEEK_SIZE;
		printf("\n ================== Waiting on socket %d ==============loopcount :%d iRetval:%d", iSocket,loopcount++,iRetval);

		if ((iRetval = Recv(iSocket, peekString, &iLen, MSG_PEEK)) == FALSE)
		{
			printf("\n Dropped Exchange Response while Peeking from Socket");
			printf("\n Error in receiving the Data from the Socket on PEEK");	
			printf("\n iRetval in peek %d:",iRetval);
			//	pthread_cancel(th_id2);
			RestartProcess();
			return NULL;
		}
		iEntryTime = logGetTime();

		memcpy(tempString,peekString,MAX_PEEK_SIZE);
		printf("\n iRetval in peek %d:",iRetval);
		printf("\nMSG_PEEK String :[%s]",tempString);

		iLen=0;
		sscanf(tempString,"%d|%c|",&iLen,&cMsgType);
		printf("\nLen = %d cMsgType = %c iSocket=%d",iLen, cMsgType,iSocket);


		if ((iRetval = Recv(iSocket, FixString, &iLen, 0)) == -1)
		{
			printf("\n Dropped Exchange Response while Receiving on Socket");
			printf("\n Error in receiving the Data from the Socket");
			/*** We do not need to send to Fwd or Rev this message ***/
			RestartProcess();
			break;
		}

		printf("\n Received from Engine");
		printf("\n [%.*s]", iLen, FixString);
		tempPtr = FixString;
		printf("Received=[%s]", FixString);
		for ( i=0,dcount=0 ; dcount<2 ; tempPtr++ )
		{
			if( tempPtr[0] == '|' )
				dcount++;
			if( tempPtr[0] == '\0')
				break;
		}

		/* */ 
		if (cMsgType == INTERFACE_CONN_UP)
		{
			/***
			 * 	Now that the connection has been established inform the FE by bcasting this
			 * 	information and update the shared memory as well...
			 ***/
			ConnectionUP();
			continue;
		}
		if (cMsgType == INTERFACE_CONN_DOWN)
		{
			/***
			 * 	Now that the connection has been lost inform the FE by bcasting this
			 * 	information and update the shared memory as well.
			 ***/
			ConnectionDOWN();
			continue;
		}/***/

		if ((iRetval=WriteMsgQ(iInterfaceToRevMapNSEEQ,tempPtr,strlen(tempPtr)-1,1))== ERROR)
		{
			printf("\n Dropped Exchange Response while Sending it to RevMap");
			exit(ERROR);
		}

		iEndTime = logGetTime();
		logInfo("R_Time_Elapse -> %ld", iEndTime - iEntryTime);
	}
	close(iSocket);
}


void QueueToSocketThread()
{
	LONG32  iRetval, iLen;
	CHAR    FixString[FIX_MAX_STRING_LEN];

	LONG64                          iEntryTime,iEndTime;

	while(1)
	{
		printf("\n ================== Waiting on the Queue =====================");
		memset(FixString, '\0', FIX_MAX_STRING_LEN);
		if ((iRetval=ReadMsgQ(iFwdMapToInterfaceNSEEQ, &FixString, FIX_MAX_STRING_LEN, iMsgType))== ERROR)
		{
			printf("\n ERROR in receiving the Data from the Q %d", iFwdMapToInterfaceNSEEQ);
			exit(ERROR);
		}

		iEntryTime = logGetTime();	
		/********************************
		  if (( CheckExchStatus ( LOCAL ) == FALSE ) || isConnected == FALSE  )
		  {
		  logDebug3(" Not Connected to Exchange, so rejecting the packet");	
		  SendBusinessRejectFor(FixString);
		  continue ;
		  } ******************************************  ALOKK COMMENTED ********************/
		printf("\n Data Received from Queue :%s", FixString);
		/*** Please dont remove the \n from line. Multiple
		  string have to be seperated by \n *****/
		if( FixString[strlen(FixString)-1] != '\n')
			strcat(FixString,"\n");

		iLen = strlen(FixString);

		if ((iRetval = Send(iSocket, FixString, &iLen, 0)) == FALSE)
		{
			printf("\n ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
			SendBusinessRejectFor(FixString);
			RestartProcess();
			break;
		}
		printf("\n Sent to Engine");
		iEndTime = logGetTime();
		logInfo("S_Time_Elapse -> %ld", iEndTime - iEntryTime);
	}

}

void RestartProcess()
{
	isConnected = FALSE ;
	ConnectionDOWN();
	printf("getpid :%d:",getpid());
	kill(getpid(), SIGUSR1);
	printf("\n Sent Signal %d To pid %d", SIGUSR1, getpid());
	return;
}


/******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Send                                       	     **
 **                                                                           **
 **   DESCRIPTION       : Send doesnt guarantee that all the data in the      **
 **			 buffer will be sent in a single call to send, loop  **
 **			 around checking the return value till all the bytes **
 **			 are sent.					     **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc to which data will be sent.   **
 **			 SendData- Data to be sent.			     **
 **			 SendLen - Len of the data to be sent.		     **
 **			 Flags   - If any.				     **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{

		printf("\n sending fix msg :%d: socketid :%d:", TotalLen,Socketfd); 
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		printf("\n After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


/*******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Recv                                                **
 **                                                                           **
 **   DESCRIPTION       : recv doesnt guarantee that all the data in the      **
 **			              buffer will be received in a single call, loop     **
 **			              around checking the return value till all the bytes **
 **			              are received.                                       **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc from which data will be recvd.**
 **			              SendData- Data to be recvd.                         **
 **			              SendLen - Len of the data to be recvd.              **
 **			              Flags   - If any.                                   **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	printf("\n Trying to Recv = %d", *RecvLen); 
	while(TotalLen < *RecvLen)
	{
		printf("\n Trying to recv %d bytes socketid :%d:", BytesLeft,Socketfd);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		printf("\n After recv Bytes = %d", Bytes); 
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


BOOL SendBusinessRejectFor(CHAR *FixString)
{
	CHAR        outString[RUPEE_MAX_PACKET_SIZE];
	LONG32		iRetVal = FALSE ;
	memset(outString,'\0',RUPEE_MAX_PACKET_SIZE);
	printf ("\n IN SendBusinessRejectFor");
	if ( (formRejectString( FixString,outString)) == FALSE)
	{
		printf ("\n\t No Rejection string created for [%s]",FixString);
	}
	else
	{
		printf("\n Received the String :%s",outString);
		if ((iRetVal=WriteMsgQ(iInterfaceToRevMapNSEEQ,outString,strlen(outString)-1,1))== ERROR)
		{
			exit(ERROR);
		}
	}
}


void ConnectionUP()
{
	UpdateConnectStatus(cSegment=='N'?NSE_EQU_UP:BSE_EQU_UP, 0);
	printf("\n UpdateConnectStatus UP");
	NotifyMonTool(TRUE);
	return;
}


void ConnectionDOWN()
{
	UpdateConnectStatus(cSegment=='N'?NSE_EQU_DOWN:BSE_EQU_DOWN, 0);
	printf("\n UpdateConnectStatus DOWN");
	NotifyMonTool(FALSE);
	return;
}

void NotifyMonTool(BOOL Status)
{

	CHAR sCmd[200];
	memset(sCmd,'\0',200);
	sprintf(sCmd,"%s/ExchStats.py %s %c %s >> %s/log.ExchStats &",getenv("PYTHON_PATH"),NSE_EXCH,EQUITY_SEGMENT,Status==1?"UP":"DOWN",getenv("LOGDIR"));
	logDebug2("Command -> %s",sCmd);
	system(sCmd);

}

	void OpenMsgQue(){
		if((iFwdMapToInterfaceNSEEQ = OpenMsgQ(FwdMapToInterfaceNSEEQ)) == ERROR)
		{
			perror("OpenMsgQ ...FwdMapToInterfaceNSEEQ");
			exit(ERROR);
		}
		printf("\n FwdMapToInterfaceNSEEQ opened successfully with id = %d", iFwdMapToInterfaceNSEEQ);

		if((iInterfaceToRevMapNSEEQ = OpenMsgQ(InterfaceToRevMapNSEEQ)) == ERROR)
		{
			perror("OpenMsgQ ...InterfaceToRevMapNSEEQ");
			exit(ERROR);
		}
		printf("\n InterfaceToRevMapNSEEQ opened successfully with id = %d", iInterfaceToRevMapNSEEQ);
	}
