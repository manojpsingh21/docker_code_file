
# ifndef _QUEUE_H_
# define _QUEUE_H_
# include <sys/types.h>
# include <sys/ipc.h>
# include <sys/sem.h>
# include <sys/shm.h>
# include <sys/uio.h>
# include <signal.h>
# include <sys/msg.h>
# include <fcntl.h>
//# include <stdlib.h>
//# include <my_global.h>	
//# include <mysql.h>
# include "HashTable.h"	
# include "Defination.h"
# include "IntSprdStruct.h"
# include "DBSprdStruct.h"
# include "Error.h"
# include "FIXSprdStructures.h"
# include "IntTCodes.h"
/************************/
#define PERMS				0666
/*************************/


/*************/
#define   IPC_RESOURCES_BASE  		atof(getenv("IPC_RESOURCES_BASE"))
#define   IPC_SHM_BASE			atof(getenv("IPC_SHM_BASE"))
#define   IPC_QUEUE_BASE		atof(getenv("IPC_QUEUE_BASE"))
#define   IPC_SHM_MIMLQRY_BASE		atof(getenv("IPC_SHM_MIMLQRY_BASE"))
#define	  IPC_SHM_IMLCONN_BASE		atof(getenv("IPC_SHM_IMLCONN_BASE"))
/*******/

#define 	NO_OF_PACKETS_TO_READ		20
#define 	MAX_NO_OF_SYSTEM_PROCESS	150
#define 	TRUE				1
#define 	FALSE				0
#define 	ERROR				-1
#define 	MAX_MESSAGE_SIZE                4096
#define		NO_ROW				2
#define		NO_MODIFICATION			3
#define		ORDER_IN_TRANSIT		4
#define		ORDER_TRADED			5

/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/********************************************* Shared Memories  ******************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/

#define  LockSystem_SIZE                100
#define  LockSystem                     (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 1 )

#define  ProcessMonitor_SIZE            sizeof(struct ProcessMonitorArray)
#define  ProcessMonitorShm              (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 2)

#define  LogLevelShm_SIZE               (sizeof(int))
#define  LogLevelShm                    (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 3 )

#define  LogFatalShm                    (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 4 )


#define  ConnStatusShm_SIZE             (sizeof(struct EXCH_CONNECT_STATUS)*(MAX_GROUPS))
#define  ConnStatusShm               	(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 5 )

#define  DWSAdapterUserShm_SIZE         sizeof(struct DWS_ADAPTER_USER_ARRAY)
#define  DWSAdapterUserShm              (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 6)

#define  DirRelShm_SIZE                 sizeof(struct user_relay_array)
#define  DirRelShm                      (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 7)


#define  ProcessDataLock1               (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 8 )


#define Equ_User_Dtl_Shm_SIZE		(sizeof(struct USER_DETAIL_ARRAY))
#define Equ_User_Dtl_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 9 )



#define EQ_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define EQ_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 10 )

#define DR_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define DR_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 11 )

#define CR_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define CR_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 12 )

#define CM_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define CM_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 13 )


/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/********************************************* Message Queues ********************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
#define RelToOrdRtr                     (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 1 )
#define RelToOrdRtr_SIZE                50000

#define RelToQuery                      (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 2 )
#define RelToQuery_SIZE                 50000

#define QueryToRel                      (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 3 )
#define QueryToRel_SIZE                 50000

#define OrdRtrToOrdSrvBSEEQ             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 4 )
#define OrdRtrToOrdSrvBSEEQ_SIZE        50000

#define OrdRtrToCatalystNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 5 )
#define OrdRtrToCatalystNSEEQ_SIZE	50000

#define CatalystToOrdSrvNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 6 )
#define CatalystToOrdSrvNSEEQ_SIZE	50000

#define OrdRtrToCatalystDR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 7 )
#define OrdRtrToCatalystDR_SIZE        50000

#define OrdRtrToOrdSrvNSECR             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 8 )
#define OrdRtrToOrdSrvNSECR_SIZE        50000

#define OrdRtrToOrdSrvMCX             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 9 )
#define OrdRtrToOrdSrvMCX_SIZE        50000

#define OrdSrvToTrdRtr                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 10 )
#define OrdSrvToTrdRtr_SIZE             50000

#define OrdSrvToFwdMapBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 11 )
#define OrdSrvToFwdMapBSEEQ_SIZE	50000

#define OrdSrvToFwdMapNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 12 )
#define OrdSrvToFwdMapNSEEQ_SIZE	50000

#define OrdSrvToFwdMapNSEDR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 13 )
#define OrdSrvToFwdMapNSEDR_SIZE	50000

#define OrdSrvToFwdMapNSECR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 14 )
#define OrdSrvToFwdMapNSECR_SIZE	50000

#define OrdSrvToFwdMapMCX		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 15 )
#define OrdSrvToFwdMapMCX_SIZE	50000

#define FwdMapToInterfaceBSEEQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 16 )
#define FwdMapToInterfaceBSEEQ_SIZE     50000

#define FwdMapToInterfaceNSEEQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 17 )
#define FwdMapToInterfaceNSEEQ_SIZE     50000

#define FwdMapToInterfaceNSEDR          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 18 )
#define FwdMapToInterfaceNSEDR_SIZE     50000

#define FwdMapToInterfaceNSECR          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 19 )
#define FwdMapToInterfaceNSECR_SIZE     50000

#define FwdMapToInterfaceMCX          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 20 )
#define FwdMapToInterfaceMCX_SIZE     	50000

#define InterfaceToRevMapBSEEQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 21 )
#define InterfaceToRevMapBSEEQ_SIZE     50000

#define InterfaceToRevMapNSEEQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 22 )
#define InterfaceToRevMapNSEEQ_SIZE     50000

#define InterfaceToRevMapNSEDR          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 23 )
#define InterfaceToRevMapNSEDR_SIZE     50000

#define InterfaceToRevMapNSECR          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 24 )
#define InterfaceToRevMapNSECR_SIZE     50000

#define InterfaceToRevMapMCX          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 25 )
#define InterfaceToRevMapMCX_SIZE     	50000

#define RevMapToTrdSrvBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 26 )
#define RevMapToTrdSrvBSEEQ_SIZE	50000

#define RevMapToTrdSrvNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 27 )
#define RevMapToTrdSrvNSEEQ_SIZE	50000

#define RevMapToTrdSrvNSEDR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 28 )
#define RevMapToTrdSrvNSEDR_SIZE	50000

#define RevMapToTrdSrvNSECR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 29 )
#define RevMapToTrdSrvNSECR_SIZE	50000

#define RevMapToTrdSrvMCX		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 30 )
#define RevMapToTrdSrvMCX_SIZE		50000

#define TrdSrvToRMS			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 31 )
#define TrdSrvToRMS_SIZE		50000

#define TrdSrvToTrdRtr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 32 )
#define TrdSrvToTrdRtr_SIZE		50000

#define TrdRtrToRel			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 33 )
#define TrdRtrToRel_SIZE		50000

#define TrdRtrToWebAdap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 34 )
#define TrdRtrToWebAdap_SIZE		50000

#define	ENBAdapToSpltr			(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 35 )
#define ENBAdapToSpltr_SIZE		50000

#define ENBSpltrToMbpUpld		(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 36 )
#define ENBSpltrToMbpUpld_SIZE		50000

#define ENBSpltrToIndxUpld		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 37 )
#define ENBSpltrToIndxUpld_SIZE		50000

#define ENBSpltrToMStatUpld		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 38 )
#define	ENBSpltrToMStatUpld_SIZE	50000

#define TrdRtrToRevRmsVal		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 39 )
#define	TrdRtrToRevRmsVal_SIZE		50000

#define RDaemonToSqoff			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 40 )
#define	RDaemonToSqoff_SIZE		50000

#define RDaemonToOffPump            	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 41 )
#define RDaemonToOffPump_SIZE        	5000

#define D2CToTrdRtr                     (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 42 )
#define D2CToTrdRtr_SIZE                 50000

#define TrdRtrToD2C                     (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 43 )
#define TrdRtrToD2C_SIZE                 50000

#define OffPumperToOrdRtr               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 44 )
#define OffPumperToOrdRtr_SIZE           50000

#define OrdRtrToOffOrd                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 45 )
#define OrdRtrToOffOrd_SIZE             50000

#define OffOrdToTrdRtr                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 46 )
#define OffOrdToTrdRtr_SIZE             50000

#define RelToDWSMap                  	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 47 )
#define RelToDWSMap_SIZE             	50000

#define TrdRtrToRevMap 			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 48 )
#define TrdRtrToRevMap_SIZE              50000

#define RevMapToDWSRel			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 49 )
#define RevMapToDWSRel_SIZE              50000

#define DNBAdapToSpltr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 50 )
#define DNBAdapToSpltr_SIZE              50000

#define CNBAdapToSpltr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 51 )
#define CNBAdapToSpltr_SIZE              50000

#define CNBSpltrToMbpUpld 		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 52 )
#define CNBSpltrToMbpUpld_SIZE           50000

#define DNBSpltrToMbpUpld               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 53 )
#define DNBSpltrToMbpUpld_SIZE           50000

#define EBAAdapToSpltr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 54 )
#define EBAAdapToSpltr_SIZE              50000

#define EBASpltrToMbpUpld               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 55 )
#define EBASpltrToMbpUpld_SIZE           50000

#define EBABSpltrToIdxUpld              (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 56 )
#define EBABSpltrToIdxUpld_SIZE           50000

#define EBABSpltrToMktSts              	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 57 )
#define EBABSpltrToMktSts_SIZE           50000

#define DNBcasttoMktStatus		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 58 )
#define DNBcasttoMktStatus_SIZE          50000

#define OrdRtrToCon2Del			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 59 )
#define OrdRtrToCon2Del_SIZE           	50000

#define CurSpltrToMktSts		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 60 )
#define CurSpltrToMktSts_SIZE		50000

#define MCXAdapToUpdtr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 61 )
#define MCXAdapToUpdtr_SIZE              50000

#define CatalystToOrdSrvDRV		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 62 )
#define CatalystToOrdSrvDRV_SIZE	50000





extern int		   ReadQ( int , char * ,int , long);
extern int	   	   WriteQ( int , char * ,int , long);
extern int         OpenMsgQ(key_t);
extern int         MsgQueueCreate(key_t , int);
extern int         SharedMemoryCreate(key_t , size_t );
extern int         SemophoreCreate(key_t );
extern void *      OpenSharedMemory ( key_t , int );
extern int         LockShm(key_t );
extern int         UnLockShm ( key_t );
extern int         DeleteLockShm ( key_t );
extern int         DeleteMsgQ ( key_t );
extern int         DeleteShmMem ( key_t );
extern int         ClearQ ( int,int );
extern int         AddProcessMem(char * ,int ,  char *);
extern int        DeleteProcessMem(int,struct ProcessMonitorArray * );
extern int         CheckProcessMem(char * );


struct  QueueMap
{
	char    QueueName[30]   ;
	int  	QueueKey        ;
};

#endif 


