
#pragma pack(2)
struct  NNF_HEADER
{
	LONG32		iReserved			; 
	LONG32		iLogTimeStamp			;
	CHAR		sAlphaSplit [ALPHA_SPLIT_LEN]	;
	INT16		iMsgCode			;
	INT16		iErrorCode			;
	CHAR		cTimeStamp1 [DATE_TIME_LEN]	;
	CHAR		cTimeStamp2 [DATE_TIME_LEN]	;
	CHAR		cTimeStamp3 [DATE_TIME_LEN]	;
	INT16		iMsgLength			;
};
#pragma pack()


#pragma pack(2)
struct  NNF_MARKET_STATUS_CHANGE_BCAST
{
	struct		NNF_HEADER	sHeader		;
	struct		NNF_SEC_INFO	SecInfo		;
	SHORT		iMarketType			;
	struct		NNF_DESTINATION	Dest		;
	SHORT           BcastMsgLength			;
	CHAR            BcastMsg [BCAST_MSG_LEN]	;
} ;
#pragma pack()

