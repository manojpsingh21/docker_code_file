#ifndef __COMMON_H__
#define __COMMON_H__
#include "SystemStructs.h"
#include "IntMsgCodes.h"


/****************************************
 *Changes are in user_id datatypes 
 *from int to unsigned long long int. 
 *Reason for changes is large number of user ids.
 ******************************************/

#pragma pack(4)
struct  INT_COMMON_RESP_HDR
{
	LONG32		iSeqNo				;
	SHORT		iMsgLength			; 
	SHORT 		iMsgCode			;
	CHAR		sExcgId[EXCHANGE_LEN]		;
	SHORT		iErrorId			;	
	ULONG64		iUserId				;/***********Latest Changes***********/  
	CHAR		cSource				;	
	LONG32          iTimeStamp			;
	CHAR		cSegment			;

};
#pragma pack()

#pragma pack(4)	
struct INT_COMMON_REQUEST_HDR
{
	LONG32		iSeqNo				;
	SHORT		iMsgLength			;
	SHORT     	iMsgCode			;
	CHAR		sExcgId[EXCHANGE_LEN]		;
	ULONG64 	iUserId				;/**********Latest Changes***********/ 
	//LONG32 	iUserId				;/Refer the comment above./ 
	CHAR		cSource				; 	
	CHAR		cSegment			;
};
#pragma pack()

#pragma pack(4)
struct ORDER_REQUEST
{
		struct  INT_COMMON_REQUEST_HDR      ReqHeader	;
		CHAR		sSecurityId		[SECURITY_ID_LEN]	;
		CHAR		sEntityId		[ENTITY_ID_LEN]		;
		CHAR		sClientId		[CLIENT_ID_LEN]		;
		CHAR		cProductId					;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
		CHAR		cBuyOrSell					;
		SHORT		iOrderType					;                               /***** SAME AS TAG 40 *****/
		SHORT		iOrderValidity					;                               /*** SAME AS TAG 59 *******/            
		LONG32		iDiscQty					;
		LONG32		iDiscQtyRem					;
		LONG32		iTotalQtyRem					;
		LONG32		iTotalQty					;
		LONG32		iTotalTradedQty					;
		LONG32		iMinFillQty					;
		DOUBLE64	fPrice						;
		DOUBLE64	fTriggerPrice					;
		DOUBLE64	fOrderNum					;
		//SHORT		iSerialNum					;
		LONG32		iSerialNum					;
		CHAR		cHandleInst					;
		DOUBLE64	fAlgoOrderNo					;
		SHORT		iStratergyId					;
		CHAR		cOffMarketFlg					;
		CHAR		cProCli						;
		CHAR		cUserType					;
		CHAR            sRemarks		[REMARKS_LEN]		;
		LONG32          iMktType                                        ;
		LONG32          iAuctionNum                                     ;
		CHAR        	sGoodTillDaysDate       [DB_DATETIME_LEN]   	;
                CHAR            cMarkProFlag                                    ;
                DOUBLE64        fMarkProVal                                     ;
                CHAR            cParticipantType                                ;/*B- For Broker ID and S - Participant/Clearing firm ID eg :ILFS1273622 (if B use settlor variable from db selected else if S use from above settlor varirable)*/
                CHAR            sSettlor                [SETTLOR_LEN]   ;
                CHAR            cGTCFlag                                        ;
                CHAR            cEncashFlag                                     ;
                CHAR            sPanID                  [INT_PAN_LEN]           ;
		LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
		CHAR            sPlatform               [PLATFORM_LEN]          ;
		CHAR            sChannel                [CHANNEL_LEN]           ;
		CHAR            sAlgoId                 [ALGO_ID_LEN]          ;
		CHAR            sFiller	                [50]			;
};
#pragma pack()

#pragma pack(4)
struct CO_SEC_INFO
{
	DOUBLE64        fTriggerPrice                                           ;
	CHAR            cBuySellInd                                             ;
	INT16            iLegValue                                            ;
};
#pragma pack()

#pragma pack(4)
struct CO_ORDER_REQUEST
{
		struct          INT_COMMON_REQUEST_HDR	ReqHeader		;
		struct          CO_SEC_INFO           CoArray [MAX_COBO_LEN]        ;
		CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
		CHAR            sEntityId               [ENTITY_ID_LEN]         ;
		CHAR            sClientId 		[CLIENT_ID_LEN]                       ;
		CHAR            cProductId                                      ;
		CHAR            cHandleInst                                     ;
		CHAR            cOffMarketFlg                                   ;
		CHAR            cUserType                                       ;
		LONG32          iMktType                                        ;
		LONG32          iDiscQty                                        ;
		LONG32          iDiscQtyRem                                     ;
		LONG32          iTotalQtyRem                                    ;
		LONG32          iTotalQty                                       ;
		LONG32          iTotalTradedQty                                 ;
		DOUBLE64        fPrice                                          ;
		DOUBLE64        fOrderNum                                       ;
		//SHORT           iSerialNum                                      ;
		LONG32		iSerialNum                                      ;
		DOUBLE64        fAlgoOrderNo                                    ;
		DOUBLE64        fTrailingSLValue                                ;
		CHAR            cProCli                                         ;
		CHAR            sRemarks                [REMARKS_LEN]           ;
		SHORT           iStratergyId                                    ;
		INT16		iNoOfLeg					;
		SHORT           iOrderType                                      ;
		SHORT           iOrderValidity                                  ;
		INT16          	iMinFillQty                                     	;
		CHAR		cSLFlag 					;
		CHAR		cPBFlag 					;
		CHAR		cAvgLtpFlg					; /* L - LTP & A - AVG_LTP */
		DOUBLE64	fPBTikAbsValue					;
		DOUBLE64	fSLTikAbsValue					;
		CHAR            cMarkProFlag                                    ;
                DOUBLE64        fMarkProVal                                     ;
                CHAR            cParticipantType                                ;
                CHAR            sSettlor                [SETTLOR_LEN]           ;
                CHAR            cGTCFlag                                        ;
                CHAR            cEncashFlag                                     ;
                CHAR            sPanID                  [INT_PAN_LEN]           ;
		LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
		CHAR            sPlatform               [PLATFORM_LEN]          ;
		CHAR            sChannel                [CHANNEL_LEN]           ;
		CHAR            sFiller	                [50]			;
};
#pragma pack()

#pragma pack(4)
struct BO_SEC_INFO
{
	DOUBLE64        fTriggerPrice                                           ;
	CHAR            cBuySellInd                                             ;
	INT16            iLegValue                                            ;
};
#pragma pack()

#pragma pack(4)
struct BO_ORDER_REQUEST
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader               ;
	struct          BO_SEC_INFO           	BoArray [MAX_COBO_LEN]	;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sEntityId               [ENTITY_ID_LEN]         ;
	CHAR            sClientId               [CLIENT_ID_LEN]     	;
	CHAR            cProductId                                      ;
	CHAR            cHandleInst                                     ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cUserType                                       ;
	LONG32          iMktType                                        ;
	LONG32          iDiscQty                                        ;
	LONG32          iDiscQtyRem                                     ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iTotalTradedQty                                 ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fOrderNum                                       ;
	//SHORT           iSerialNum                                      ;
	LONG32		iSerialNum                                      ;
	DOUBLE64        fAlgoOrderNo                                    ;
	DOUBLE64        fTrailingSLValue                                ;
	CHAR            cProCli                                         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	SHORT           iStratergyId                                    ;
	INT16           iNoOfLeg                                        ;
	SHORT           iOrderType                                      ;
	SHORT           iOrderValidity                                  ;
	INT16          	iMinFillQty                                      ;
	CHAR            cSLFlag                                         ;
	CHAR            cPBFlag                                         ;
	DOUBLE64        fPBTikAbsValue                                  ;
	DOUBLE64        fSLTikAbsValue                                  ;
	LONG32		iChildLegsUniqId				;
	LONG32		iParentId					;
	CHAR		cFlag						;
	CHAR            cMarkProFlag                                    ;
      	DOUBLE64        fMarkProVal                                     ;
        CHAR            cParticipantType                                ;
        CHAR            sSettlor                [SETTLOR_LEN]           ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
        CHAR            sPanID                  [INT_PAN_LEN]           ;
	LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
	CHAR            sPlatform               [PLATFORM_LEN]          ;
	CHAR            sChannel                [CHANNEL_LEN]           ;
	CHAR            sFiller  	        [50]			;
};
#pragma pack()

#pragma pack(4)
struct ORDER_RESPONSE
{
		struct  INT_COMMON_RESP_HDR      IntRespHeader   ;
		CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
		CHAR            sEntityId               [ENTITY_ID_LEN]         ;
		CHAR            sClientId               [CLIENT_ID_LEN]         ;
		CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]    	;
		CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
		CHAR            cBuyOrSell                                      ;
		SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
		SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
		LONG32          iDiscQty					;
		LONG32          iDiscQtyRem                                     ;
		LONG32          iTotalQtyRem                                    ;
		LONG32          iTotalQty                                       ;
		LONG32          iLastTradedQty					;
		LONG32          iTotalTradedQty                                 ;
		LONG32          iMinFillQty                                     ;
		DOUBLE64        fPrice                                          ;
		DOUBLE64        fTriggerPrice                                   ;
		DOUBLE64        fOrderNum                                       ;
		//SHORT           iSerialNum                                      ;
		LONG32		iSerialNum                                      ;
		CHAR		sTradeNo		[DB_EXCH_TRD_NO_LEN]	;
		DOUBLE64	fTradePrice					;		
		CHAR            cHandleInst                                     ;
		DOUBLE64        fAlgoOrderNo                                    ;
		SHORT           iStratergyId                                    ;
		CHAR            cOffMarketFlg                                   ;
		CHAR            cProCli                                         ;
		CHAR            cUserType                                      	;
		CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
		CHAR            sTransacTime            [DATE_TIME_LEN]         ;
		CHAR            sRemarks                [REMARKS_LEN]           ;
		LONG32		iMktType    					;
		/*------------------Latest Changes---------------------------*/
		CHAR        	sReasonDesc         [DB_REASON_DESC_LEN]    	;
		CHAR        	sGoodTillDaysDate       [DB_DATETIME_LEN]   	;	
		INT16       	iLegValue		                        ;
		CHAR		sTradeNum               [TRADE_NO_LEN]          ;
		CHAR            cMarkProFlag                                    ;
                DOUBLE64        fMarkProVal                                     ;
                CHAR            cParticipantType                                ;
                CHAR            sSettlor                [SETTLOR_LEN]           ;
                CHAR            cGTCFlag                                        ;
                CHAR            cEncashFlag                                     ;
                CHAR            sPanID                  [INT_PAN_LEN]           ;
		LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
		CHAR		sErrorCode		[ERROR_CODE_LEN]	;
		CHAR		sSmExpiryFlag		[DB_EXPIRY_FLAG_LEN];
                CHAR            sRemarks2               [REMARKS_LEN]           ;
                CHAR            sRemarks3               [REMARKS_LEN]           ;
		CHAR            sFiller                 [FILLER_LEN]            ;



};
#pragma pack()

#pragma pack(4)
struct NOTIFICATION_RESPONSE
{
                SHORT           iRequestCode					;
                SHORT           iMsgLength					;
                CHAR            sExchId                 [EXCHANGE_LEN]          ;
                CHAR            cSegment					;
		CHAR		cSource						; 	
                CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
                CHAR            sClientId               [CLIENT_ID_LEN]         ;
                CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]     ;
                CHAR	        sOrderNum               [EXCH_ORDER_NO_LEN]     ;
                CHAR            cProductId                                      ;
                CHAR            cBuyOrSell                                      ;
                CHAR            sOrderType              [ORDER_TYPE_LEN]        ;
                CHAR            sOrderValidity          [VALIDITY_LEN]          ;
                LONG32          iDiscQty                                        ;
                LONG32          iDiscQtyRem                                     ;
                LONG32          iTotalQtyRem                                    ;
                LONG32          iTotalQty                                       ;
                LONG32          iTotalTradedQty                                 ;
                DOUBLE64        fPrice                                          ;
                DOUBLE64        fTriggerPrice                                   ;
                SHORT           iSerialNum                                      ;
                //LONG32		iSerialNum                                      ;
                DOUBLE64        fTradePrice                                     ;
                DOUBLE64        fAvgTradePrice                                  ;
                DOUBLE64        fAlgoOrderNo                                    ;
                SHORT           iStratergyId                                    ;
                CHAR            cOffMarketFlg                                   ;
                CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
                CHAR            sExchOrderTime          [DATE_TIME_LEN]         ;
                CHAR            sLastUpdatedTime        [DATE_TIME_LEN]         ;
                CHAR            sRemarks                [REMARKS_LEN]           ;
                CHAR            sMktType                [MARKET_TYPES]         	;
		CHAR            sReasonDesc         [DB_REASON_DESC_LEN]        ;
                SHORT		iLegValue                                       ;
                CHAR            cMarkProFlag                                    ;
                DOUBLE64        fMarkProVal                                     ;
                CHAR            cParticipantType                                ;
                CHAR            sSettlor                [SETTLOR_LEN]           ;
                CHAR            cGTCFlag                                        ;
                CHAR            cEncashFlag                                     ;
                CHAR            sPanID                  [INT_PAN_LEN]           ;
                LONG32          iGrpId                                          ;
                CHAR            sInstrument             [INSTRUMENT_LEN]        ;
                CHAR            sSymbol                 [DB_SYMBOL_LEN]         ;
                CHAR            sProduct_Name           [PRODUCT_NAME_LEN]      ;
                CHAR            sStatus                 [STATUS_LEN_SIZE]       ;
                LONG32          iLotsize                                        ;
                DOUBLE64        fSLTrail                                        ;
                DOUBLE64        fSLTickValue                                    ;
                DOUBLE64        fPRTickValue                                    ;
                DOUBLE64        fStrikePrice                                    ;
                CHAR            sExpiryDate             [DATE_TIME_LEN]         ;
                CHAR            sOption_typ             [OPTION_LEN]            ;
                CHAR            sCustomSym              [CUSTOM_SYM_LEN]        ;
                CHAR            sIsin                   [ISINCODE_LEN]          ;
                CHAR            sSeries                 [HLD_SERIES_LEN]        ;
                CHAR            sGtdDate                [DATE_TIME_LEN]         ;
                CHAR            sInstrumentTyp          [INSTRUMENT_TYPE]       ;
                DOUBLE64        fLtp						;
                DOUBLE64        fTickSize					;
                CHAR            sAlgoID          	[BSE_INT_ALGO_ID_LEN]    ;
		CHAR            sPlatform               [PLATFORM_LEN]          ;
		CHAR            sChannel                [CHANNEL_LEN]           ;
                DOUBLE64        fMultiplier					;
};
#pragma pack()

#pragma pack(4)
struct NOTIFICATION_RESPONSE2
{
                struct  INT_COMMON_RESP_HDR             ResHeader               ;
                CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
                CHAR            sEntityId               [ENTITY_ID_LEN]         ;
                CHAR            sClientId               [CLIENT_ID_LEN]         ;
                CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]     ;
                CHAR            cProductId                                      ;
                CHAR            cBuyOrSell                                      ;
                CHAR            sOrderType              [ORDER_TYPE_LEN]        ;
                CHAR            sOrderValidity          [VALIDITY_LEN]          ;
                LONG32          iDiscQty                                        ;
                LONG32          iDiscQtyRem                                     ;
                LONG32          iTotalQtyRem                                    ;
                LONG32          iTotalQty                                       ;
                LONG32          iLastTradedQty                                  ;
                LONG32          iTotalTradedQty                                 ;
                LONG32          iMinFillQty                                     ;
                DOUBLE64        fPrice                                          ;
                DOUBLE64        fTriggerPrice                                   ;
                DOUBLE64        fOrderNum                                       ;
                LONG32		iSerialNum                                      ;
                CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]    ;
                DOUBLE64        fTradePrice                                     ;
                DOUBLE64        fAvgTradePrice                                  ;
                DOUBLE64        fAlgoOrderNo                                    ;
                SHORT           iStratergyId                                    ;
                CHAR            cOffMarketFlg                                   ;
                CHAR            cUserType                                       ;
                CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
                CHAR            sExchOrderTime          [DATE_TIME_LEN]         ;
                CHAR            sLastUpdatedTime        [DATE_TIME_LEN]         ;
                CHAR            sRemarks                [REMARKS_LEN]           ;
                CHAR            sMktType                [MARKET_TYPES]          ;
                CHAR            sReasonDesc         [DB_REASON_DESC_LEN]        ;
		CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
                INT16           iLegValue                                       ;
                CHAR            sTradeNum               [TRADE_NO_LEN]          ;
                CHAR            cMarkProFlag                                    ;
                DOUBLE64        fMarkProVal                                     ;
                CHAR            cParticipantType                                ;
                CHAR            sSettlor                [SETTLOR_LEN]           ;
                CHAR            cGTCFlag                                        ;
                CHAR            cEncashFlag                                     ;
                CHAR            sPanID                  [INT_PAN_LEN]           ;
                LONG32          iGrpId                                          ;
                CHAR            sInstrument             [INSTRUMENT_LEN]        ;
                CHAR            sSymbol                 [DB_SYMBOL_LEN]         ;
                CHAR            sProduct_Name           [PRODUCT_LEN]           ;
                CHAR            sStatus                 [STATUS_LEN_SIZE]       ;
                LONG32          iLotsize                                        ;
                DOUBLE64        fSLTrail                                        ;
                DOUBLE64        fSLTickValue                                    ;
                DOUBLE64        fPRTickValue                                    ;
                DOUBLE64        fStrikePrice                                    ;
                CHAR            sExpiryDate             [DATE_TIME_LEN]         ;
                CHAR            sOption_typ             [OPTION_LEN]            ;
                CHAR            sCustomSym              [CUSTOM_SYM_LEN]        ;
                CHAR            sIsin                   [ISINCODE_LEN]          ;
                CHAR            sSeries                 [HLD_SERIES_LEN]        ;
                CHAR            sGtdDate                [DATE_TIME_LEN]         ;
};
#pragma pack()

#pragma pack(4)
struct BO_ORDER_RESPONSE
{
	struct  INT_COMMON_RESP_HDR      IntRespHeader   ;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sEntityId               [ENTITY_ID_LEN]         ;
	CHAR            sClientId               [CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]     ;
	CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	CHAR            cBuyOrSell                                      ;
	SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	LONG32          iDiscQty                                        ;
	LONG32          iDiscQtyRem                                     ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iLastTradedQty                                  ;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTriggerPrice                                   ;
	DOUBLE64        fOrderNum                                       ;
	//SHORT           iSerialNum                                      ;
	LONG32		iSerialNum                                      ;
	CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]    ;
	DOUBLE64        fTradePrice                                     ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
	CHAR        	sReasonDesc         [DB_REASON_DESC_LEN]        ;
	CHAR        	sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	INT16        	iLegValue                                       ;
	LONG32		iChildLegsUniqId				;
	LONG32          iParentId                                       ;
	CHAR            cFlag						;
	/*------------------New Field -----------------------*/
	LONG32          iSLTranscode                                      ;
	LONG32          iSLOrdQty                                            ;
	LONG32          iSLRemQty                                         ;
	DOUBLE64        fSLPrice                                          ;
	LONG32          iProfTranscode                                      ;
	LONG32          iProfQty                                            ;
	LONG32          iProfRemQty                                         ;
	DOUBLE64        fProfPrice                                          ;
	LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/

};
#pragma pack()

#pragma pack(4)
struct INT_ERROR_FE_RESP
{
	struct INT_COMMON_RESP_HDR	IntRespHeader				;
	CHAR		sSecurityId[SECURITY_ID_LEN]			;
	CHAR            sClientId[CLIENT_ID_LEN]			;
	CHAR            cProductId					;	
	CHAR		cBuyOrSell					;	
	LONG32          iTotalQty					;
	DOUBLE64	fPrice						;
	CHAR		sErrorMsg		[DB_REASON_DESC_LEN]		;
	LONG32		iLegValue					;
	CHAR		sErrorCode		[ERROR_CODE_LEN]	;

};
#pragma pack()
/**
#pragma pack(4)
struct INT_ERROR_FE_RESP
{
struct INT_COMMON_RESP_HDR      IntRespHeader                           ;

CHAR            sErrorMsg               [ERROR_MSG_LEN]         	;
};
#pragma pack()
 **/
#pragma pack(4)
struct SUB_ORDER_REQUEST_SPREAD_2L_3L
{
	CHAR            sSecurityId[SECURITY_ID_LEN]      ;
	CHAR            cBuyOrSell                        ;
	DOUBLE64        fPrice                            ;
	LONG32          iTotalQty                         ;
	LONG32          iTotalQtyRem		                ;
	LONG32          iTotalTradedQty                         ;
	LONG32          iMinFillQty                             ;
};
#pragma pack()
/**
#pragma pack (2)
struct  SPRD_ERROR_FE
{
CHAR            sSecurityId[SECURITY_ID_LEN]                    ;	
CHAR            cBuyOrSell                                      ;
};
#pragma pack()
 **/

#pragma pack(4)
struct INT_SPRD_ERROR_FE_RESP
{
	struct 	INT_COMMON_RESP_HDR	pIntRespHdr				;
	LONG32	iNoOfLeg							;
	struct 	SUB_ORDER_REQUEST_SPREAD_2L_3L pSprdErrorFe	[LEG_LEN]		;
	CHAR            sClientId[CLIENT_ID_LEN]                        	;
	CHAR            cProductId                                      	;
	LONG32          iTotalQty                                       	;
	DOUBLE64        fPrice                                          	;
	CHAR            sErrorMsg       [ERROR_MSG_LEN]         		;
	LONG32		iMktType						;
};
#pragma pack()


#pragma pack(4)
struct INT_MTM_BREACH_RESP
{
	struct INT_COMMON_RESP_HDR      IntRespHeader                           ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	DOUBLE64        fMTMPercent                                     ;
	DOUBLE64        fMTMLevel                                     	;
	CHAR		cMTMFlag					;
};
#pragma pack()
/**
#pragma pack(4)
struct SUB_ORDER_REQUEST_SPREAD_2L_3L
{
CHAR            sSecurityId[SECURITY_ID_LEN]      ;
CHAR            cBuyOrSell                        ;
};
#pragma pack()
 **/
#pragma pack(4)
struct ORDER_SPREAD_REQUEST
{
	struct          INT_COMMON_REQUEST_HDR     ReqHeader    ;
	CHAR            sEntityId[ENTITY_ID_LEN]                ;
	CHAR            sClientId[CLIENT_ID_LEN]                ;
	CHAR            cProductId                              ;
	SHORT           iOrderType                              ;
	CHAR            cProCli                                 ;
	DOUBLE64        fOrderNum                               ;
//	LONG32          iTotalQtyRem		                ;
//	LONG32          iTotalQty                               ;
//	LONG32          iTotalTradedQty                         ;
//	LONG32          iMinFillQty                             ;
	DOUBLE64        fPriceDiff                              ;
	SHORT           iOrderValidity                          ;
	LONG32		iSerialNum                              ;
	CHAR            sRemarks[REMARKS_LEN]                   ;
	CHAR            sSettlor[SETTLOR_LEN]                   ;
	//        INT16           iGoodTillDays                            ;
	//        CHAR            sGoodTillDate[DATE_LEN]                  ;
	CHAR            cHandleInst                             ;
	LONG32		iNoOfLeg				;
	struct          SUB_ORDER_REQUEST_SPREAD_2L_3L  sSpreadLeg[LEG_LEN];
	CHAR            sCBrokerCode[BROKER_CODE_LEN]           ;
	DOUBLE64        fAlgoOrderNo                            ;
	SHORT           iStratergyId                            ;
	CHAR            cUserType                               ;
	LONG32          iMktType                                ;
	CHAR            cOffMarketFlg                           ;
	CHAR            cMarkProFlag                                    ;//N
	DOUBLE64        fMarkProVal                                     ;//0.00
	CHAR            cParticipantType                                ;//B
	CHAR            cGTCFlag                                        ;//N
	CHAR    	cEncashFlag                                     ;//N
	CHAR            sPanNo			[INT_PAN_LEN]           ;
	LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
	CHAR            sPlatform               [PLATFORM_LEN]          ;
        CHAR            sChannel                [CHANNEL_LEN]           ;


};
#pragma pack()

#pragma pack(4)
struct ORDER_SPREAD_RESPONSE
{
	struct          INT_COMMON_RESP_HDR     IntRespHeader    	;
	CHAR            sEntityId	[ENTITY_ID_LEN]         ;
	CHAR            sClientId	[CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID    [EXCH_ORDER_NO_LEN]     ;
	CHAR            cProductId                              ;
	SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iLastTradedQty                                  ;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	LONG32          iNoOfLeg                                	;
	struct          SUB_ORDER_REQUEST_SPREAD_2L_3L  sSpreadLeg[LEG_LEN];
	DOUBLE64        fOrderNum                                       ;
	LONG32		iSerialNum                                      ;
	CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]    ;
	DOUBLE64        fTradePrice                                     ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	CHAR        	sReasonDesc         [DB_REASON_DESC_LEN]        ;
	LONG32          iMktType                                        ;
	CHAR            cMarkProFlag                                    ;
	DOUBLE64        fMarkProVal                                     ;
	CHAR            cParticipantType                                ;
	CHAR            cGTCFlag                                        ;
	CHAR            cEncashFlag                                     ;
	CHAR            sPanNo 			[INT_PAN_LEN]           ;
	LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
};
#pragma pack()

#pragma pack(4)
struct CON_TO_DELIVERY_REQUEST
{
	struct  	INT_COMMON_REQUEST_HDR      	ReqHeader   	;
	CHAR    sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR    sEntityId               [ENTITY_ID_LEN]         ;
	CHAR    sClientId               [CLIENT_ID_LEN]         ;
	CHAR    cBuyOrSell                                      ;
	CHAR    cProdIdFrom                                     ;
	CHAR    cProdIdTo                                       ;
	CHAR	cUserType					;
	LONG32  iQty		                                ;
	LONG32  iMktType                                        ;
};
#pragma pack()

#pragma pack(4)
struct CON_TO_DELIVERY_RESPONSE
{
	struct          INT_COMMON_RESP_HDR     	RespHeader	;
	CHAR    sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR    sEntityId               [ENTITY_ID_LEN]         ;
	CHAR    sClientId               [CLIENT_ID_LEN]         ;
	CHAR    cBuyOrSell                                      ;
	CHAR    cProdIdFrom                                     ;
	CHAR   	cProdIdTo                                       ;
	CHAR	cUserType					;
	LONG32  iQty		                                ;
	LONG32  iMktType                                        ;
};
#pragma pack()

#pragma pack(4)
struct SPAN_CALC_REQUEST
{
	struct		INT_COMMON_REQUEST_HDR		ReqHeader	  	;
	CHAR		sSecurityId		[SECURITY_ID_LEN]	;
	CHAR		sEntityId		[ENTITY_ID_LEN]		;
	CHAR		sClientId		[CLIENT_ID_LEN]		;
	CHAR		cBuyOrSell					;
	CHAR 		sSymbol			[SYMBOL_LEN]		;			
	LONG32		iLotSize					;
	DOUBLE64	fSmargin					;
	DOUBLE64	fEmargin					;
	DOUBLE64	fMargin						;
};
#pragma pack()

#pragma pack(4)
struct SPAN_CALC_RESPONSE
{
	struct 		INT_COMMON_RESP_HDR		RespHeader		;
	CHAR		sSecurityId		[SECURITY_ID_LEN]	;
	CHAR		sEntityId		[ENTITY_ID_LEN]		;
	CHAR		sClientId		[CLIENT_ID_LEN]		;
	CHAR		cBuyOrSell					;
	CHAR		sSymbol			[SYMBOL_LEN]		;
	LONG32		iLotSize					;
	DOUBLE64	fSmargin					;
	DOUBLE64	fEmargin					;
	DOUBLE64	fMargin						;
};
#pragma pack(4)
struct SIP_ORD_REQUEST
{
	struct  INT_COMMON_REQUEST_HDR      ReqHeader   ;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sClientId               [CLIENT_ID_LEN]         ;
	CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	CHAR            cBuyOrSell                                      ;
	SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fOrderNum                                       ;
	LONG32		iSerialNum                                      ;
	SHORT		iForPeriod					;	
	CHAR            cHandleInst                                     ;
	CHAR		cFrequency					;	
	CHAR		sStartDate		[DATE_LENGTH]		;
	CHAR		cOffMarketFlg					;	
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR		cSIPFlag					;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
	CHAR		sEntityId		[ENTITY_ID_LEN]		;
	CHAR            cMarkProFlag                                    ;
        DOUBLE64        fMarkProVal                                     ;
        CHAR            cParticipantType                                ;/*B- For Broker ID and S - Participant/Clearing firm ID eg :ILFS1273622 (if B use settlor variable from db selected else if S use from above settlor varirable)*/
        CHAR            sSettlor                [SETTLOR_LEN]   ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
        CHAR            sPanID                  [INT_PAN_LEN]           ;
	LONG32          iGrpId						;
        CHAR            sPlatform               [PLATFORM_LEN]          ;
        CHAR            sChannel                [CHANNEL_LEN]           ;

};
#pragma pack()

#pragma pack(4)
struct SIP_ORD_RESPONSE
{
	struct  INT_COMMON_RESP_HDR      IntRespHeader   ;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sClientId               [CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]     ;
	CHAR            cBuyOrSell                                      ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fOrderNum                                       ;
	SHORT           iSerialNum                                      ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cUserType                                       ;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [SIP_REMARKS_LEN]       ;
	LONG32          iMktType                                        ;
	CHAR            sReasonDesc         [DB_REASON_DESC_LEN]        ;
};
#pragma pack()
/**
#pragma pack(4)
struct C2D_VIEW_NET_POSITION
{
struct  INT_COMMON_RESP_HDR      RespHeader;
CHAR            sSecurityID[SECURITY_ID_LEN];
DOUBLE64        fBuyQty;
DOUBLE64        fBuyVal;
DOUBLE64        fSellQty;
DOUBLE64        fSellVal;
DOUBLE64        fBuyAvg;
DOUBLE64        fSellAvg;
DOUBLE64        fNetQty;
DOUBLE64        fNetVal;
DOUBLE64        fNetAvg;
DOUBLE64        fGrossQty;
DOUBLE64        fGrossVal;
CHAR            cMktType[MARKET_LEN];
CHAR            cProductId;
DOUBLE64        fRelaisedProfit;
DOUBLE64        fMTM;
CHAR            sClientId[CLIENT_ID_LEN];
};
#pragma pack()
 **/
#pragma pack(4)
struct C2D_VIEW_NET_POSITION
{
	struct  INT_COMMON_RESP_HDR      RespHeader;
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchId[EXCHANGE_LEN];
	LONG32          iBuyQty;
	LONG32          iBuyQtyCF;
	LONG32          iBuyQtyDay;
	DOUBLE64        fBuyVal;
	DOUBLE64        fBuyValCF;
	DOUBLE64        fBuyValDay;
	DOUBLE64        fBuyAvg;
	LONG32          iSellQty;
	LONG32          iSellQtyCF;
	LONG32          iSellQtyDay;
	DOUBLE64        fSellVal;
	DOUBLE64        fSellValCF;
	DOUBLE64        fSellValDay;
	DOUBLE64        fSellAvg;
	LONG32          iNetQty;
	DOUBLE64        fNetVal;
	DOUBLE64        fNetAvg;
	DOUBLE64        fGrossQty;
	DOUBLE64        fGrossVal;
	CHAR            cMktType[MARKET_LEN];
	CHAR            cProductId;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fMTM;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	LONG32          iRef_ID;	
};
#pragma pack()

#pragma pack(4)
struct FE_BSE_STAR_ORD_REQ
{
	struct	INT_COMMON_REQUEST_HDR  ReqHeader  ;
	CHAR    sTransCode              [TRANSCODE_LEN]         ;
	CHAR    sScripID                [SCHEME_TOKEN_LEN]      ;
	CHAR    sScripCode              [SCRIP_CODE_LEN]        ;
	CHAR    cBuySell                                        ;
	CHAR    sBuySellType            [BUY_SELL_TYPE]         ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR    sMemberId               [MEMBER_ID_LEN]         ;
	CHAR    sRedemDestSource                                ;
	CHAR    sAmount                 [AMOUNT_LEN]            ;
	CHAR    sOrigPurchaseAmnt       [ORG_PURCHASE_AMOUNT_LEN];
	CHAR    sRedemQty               [REDEM_QTY]             ;
	CHAR    sOrigRedemQty           [ORG_REDEM_QTY]         ;
	CHAR    sFolioNo                [FOLIO_NO_LEN]          ;
	CHAR    cKycStatus                                      ;
	CHAR    sRemarks                [BSE_MF_REMARKS_LEN]    ;
	CHAR    sLoginId                [LOGIN_ID_LEN]          ;
	CHAR    sBranchCode             [BRANCH_CODE]           ;
	CHAR    sDealerId               [DEALER_ID_LEN]         ;
	CHAR    sRefNo                  [REFERENCE_NO]          ;
	CHAR    sSession                [SESSION_LEN]           ;
	CHAR    sOrderNo                [ORDER_NO_LEN]          ;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR    sSubBrokerCode          [SUB_BROK_CODE_LEN]     ;
	CHAR    sEuinCode               [EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR    sMinRedemFlag           [MIN_REDEM_FLAG]        ;
	CHAR    sFiller2                [FILLER_LEN_25]         ;
	CHAR    sFiller3                [FILLER_LEN_25]         ;
	CHAR    sSubBrokerArnCode       [SUB_BROK_ARN_CODE]     ;
	CHAR    sFiller4                [FILLER_LEN_20]         ;
	CHAR    sFiller5                [FILLER_LEN_20]         ;
	CHAR    sFiller6                [FILLER_LEN_20]         ;

};
#pragma pack()

#pragma pack(4)
struct 	MARGIN_CAL_RESP
{
	struct  INT_COMMON_RESP_HDR pRspHeader;
	DOUBLE64	fTotMargin;
	DOUBLE64	fSpanMargin;
	DOUBLE64	fExpoMargin;
	DOUBLE64	fVarElmMargin;
	DOUBLE64	fAvailBalance;
	DOUBLE64	fInsffBalnc;
	DOUBLE64        fBrokerage;

};
#pragma pack()

#pragma pack(4)
struct MUL_LEG_SEC_DETAILS
{
	CHAR            sSecurityId             [DB_SECURITY_ID_LEN]       ;
	CHAR            cBuyOrSell                                      ;
	LONG32          iDiscQty                                        ;
	LONG32          iDiscQtyRem                                     ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iTotalTradedQty                                 ;
	DOUBLE64        fPrice                                          ;			
	LONG32          iMinFillQty                                     ;
};

#pragma pack()

#pragma pack(4)
struct MUL_LEG_ORDER_REQUEST
{
	struct  	INT_COMMON_REQUEST_HDR 	ReqHeader   		;
	LONG32		iNoOfLeg					;	
	CHAR            sEntityId               [DB_ENTITY_ID_LEN]         ;
	CHAR            sClientId               [DB_CLIENT_ID_LEN]         ;
	CHAR            cProductId                                      ;      
	struct 		MUL_LEG_SEC_DETAILS	SecDetails[LEG_LEN]	;
	SHORT           iOrderType                                      ;      
	SHORT           iOrderValidity                                  ;        
	DOUBLE64        fTriggerPrice                                   ;
	DOUBLE64        fOrderNum                                       ;
	LONG32		iSerialNum                                      ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
	LONG32          iAuctionNum                                     ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	CHAR            cMarkProFlag                                    ;
	DOUBLE64        fMarkProVal                                     ;
	CHAR            cParticipantType                                ;
	CHAR            sSettlor                [SETTLOR_LEN]   	;
	CHAR            cGTCFlag                                        ;
	CHAR            cEncashFlag                                     ;
	CHAR            sPanID                  [INT_PAN_LEN]           ;
	LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
};
#pragma pack()

#pragma pack(4)
struct SEC_DETAILS_ERR
{
	CHAR		sSecurityId[SECURITY_ID_LEN]			;
	CHAR		cBuyOrSell					;	
	LONG32          iTotalQty					;
	DOUBLE64	fPrice						;
};
#pragma pack()


#pragma pack(4)
struct INT_MUL_ERROR_FE_RESP
{
	struct INT_COMMON_RESP_HDR	IntRespHeader			;
	struct 		SEC_DETAILS_ERR SecDetail[LEG_LEN]		;
	CHAR            sClientId[CLIENT_ID_LEN]			;
	CHAR            cProductId					;	
	CHAR		sErrorMsg		[DB_REASON_DESC_LEN]	;
	LONG32		iLegValue					;
	CHAR		sErrorCode		[ERROR_CODE_LEN]	;

};
#pragma pack()

#pragma pack(4)
struct MUL_SEC_RES_DETAILS
{
		CHAR            sSecurityId             [DB_SECURITY_ID_LEN]       ;
		CHAR            cBuyOrSell                                      ;
		LONG32          iDiscQty					;
		LONG32          iDiscQtyRem                                     ;
		LONG32          iTotalQtyRem                                    ;
		LONG32          iTotalQty                                       ;
		LONG32          iMinFillQty                                     ;
		LONG32          iLastTradedQty					;
		LONG32          iTotalTradedQty                                 ;
		DOUBLE64        fPrice                                          ;
		DOUBLE64        fTriggerPrice                                   ;
		SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
		DOUBLE64	fTradePrice					;		
};
#pragma pack()

#pragma pack(4)
struct MUL_DRV_ORDER_RESPONSE
{
	struct  	INT_COMMON_RESP_HDR      IntRespHeader   	;
	struct 		MUL_SEC_RES_DETAILS	SecDetails[LEG_LEN]		;
	CHAR            sEntityId               [ENTITY_ID_LEN]         ;
	CHAR            sClientId               [CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]    	;
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	DOUBLE64        fOrderNum                                       ;
	CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	LONG32		iSerialNum                                      ;
	CHAR		sTradeNo		[DB_EXCH_TRD_NO_LEN]	;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                      	;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32		iMktType    					;
	CHAR        	sReasonDesc         [DB_REASON_DESC_LEN]    	;
	CHAR        	sGoodTillDaysDate       [DB_DATETIME_LEN]   	;	
	INT16       	 iLegValue		                        ;
	CHAR		sTradeNum               [TRADE_NO_LEN]          ;
	CHAR            cMarkProFlag                                    ;
	DOUBLE64        fMarkProVal                                     ;
	CHAR            cParticipantType                                ;
	CHAR            sSettlor                [SETTLOR_LEN]           ;
	CHAR            cGTCFlag                                        ;
	CHAR            cEncashFlag                                     ;
	CHAR            sPanID                  [INT_PAN_LEN]           ;
	LONG32		iGrpId						;/* Adding group id for number of lease line or number of user id will connect with exchange*/
};
#pragma pack()

#pragma pack(4)
struct MTM_C2D_VIEW_NET_POSITION
{
        CHAR            sSecurityID[SECURITY_ID_LEN];
        CHAR            sExchId[EXCHANGE_LEN];
        LONG32          iBuyQty;
        LONG32          iBuyQtyCF;
        LONG32          iBuyQtyDay;
        DOUBLE64        fBuyVal;
        DOUBLE64        fBuyValCF;
        DOUBLE64        fBuyValDay;
        DOUBLE64        fBuyAvg;
        LONG32          iSellQty;
        LONG32          iSellQtyCF;
        LONG32          iSellQtyDay;
        DOUBLE64        fSellVal;
        DOUBLE64        fSellValCF;
        DOUBLE64        fSellValDay;
        DOUBLE64        fSellAvg;
        LONG32          iNetQty;
        DOUBLE64        fNetVal;
        DOUBLE64        fNetAvg;
        DOUBLE64        fGrossQty;
        DOUBLE64        fGrossVal;
        CHAR            cMktType[MARKET_LEN];
        CHAR            cProductId;
        DOUBLE64        fRelaisedProfit;
        DOUBLE64        fMTM;
        CHAR            sClientId[CLIENT_ID_LEN];
        CHAR            cSegment;
        LONG32          iRef_ID;
	DOUBLE64        fMTMPercent;
        DOUBLE64        fMTMLevel;
        CHAR            cMTMFlag;
        DOUBLE64        fSovl;
        DOUBLE64        fSoql;
        DOUBLE64        fSoll;
        DOUBLE64        fLtp;
	CHAR		cMTMSqrFlg;
	DOUBLE64	fTradingBal;
};
#pragma pack()

#pragma pack(4)
struct VIEW_MTM_C2D_VIEW_NET_POSITION
{
        struct INT_COMMON_RESP_HDR  IntRespHeader;
        CHAR    cMsgType;
        LONG32  iNoofRec;
        struct MTM_C2D_VIEW_NET_POSITION  subC2Dpos[5];
};
#pragma pack()

#pragma pack(4)
struct SQROFF_INSTRUCTION_REQUEST 
{
                struct  INT_COMMON_REQUEST_HDR      ReqHeader   ;
		CHAR            sEntityId               [ENTITY_ID_LEN]         ;
                CHAR            sClientId               [CLIENT_ID_LEN]         ;
                CHAR            sSymbol			[DB_SYMBOL_LEN]         ;
                CHAR            cProduct		         ;
                CHAR            sInstrument             [INSTRUMENT_LEN]         ;
                CHAR            sPosDayCarryFwd		[POSITION_TYPE_LEN]         ;
		CHAR		sNetQtyChk		[NET_QTY_LEN];
		LONG32		iOptQtyChk			;
		CHAR		sNetValChk		[NET_VAL_LEN]	;
		LONG32		iOptValChk			;

};
#pragma pack()

#pragma pack(4)
struct ORDER_INSTRUCTION_REQUEST
{
                struct  INT_COMMON_REQUEST_HDR      ReqHeader   ;
                CHAR            sEntityId               [ENTITY_ID_LEN]         ;
                CHAR            sInstrument             [INSTRUMENT_LEN]         ;
                CHAR            sSymbol                 [DB_SYMBOL_LEN]         ;
		CHAR		sOrdStatus		[ORDER_STATUS];
		CHAR		sExpiryDate		[DB_EXPIRY_LEN];
		CHAR		sOptType		[OPTION_LEN];
                CHAR            cProduct                  ;
                CHAR            cSource			  ;
                CHAR            sClientId               [CLIENT_ID_LEN]         ;
                CHAR            sPlaceBy		[ENTITY_ID_LEN]         ;
		LONG32		iQuantity_val		;
		DOUBLE64	fOrder_val		;	

};
#pragma pack()

#pragma pack(4)
struct FOREVER_SEC_INFO
{
        DOUBLE64        fTriggerPrice                                           ;
        INT16           iLegValue                                            ;
        DOUBLE64        fPrice                                          ;
        LONG32          iTotalQtyRem                                    ;
        LONG32          iTotalQty                                       ;
	DOUBLE64	fOrdTriggerPrice				;
};
#pragma pack()


#pragma pack(4)
struct FOREVER_ORDER_REQUEST
{
        struct          INT_COMMON_REQUEST_HDR  ReqHeader               ;
        struct          FOREVER_SEC_INFO           CoArray [MAX_COBO_LEN]        ;
        CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
        CHAR            sEntityId               [ENTITY_ID_LEN]         ;
        CHAR            sClientId               [CLIENT_ID_LEN]                       ;
        CHAR            cProductId                                      ;
        CHAR            cHandleInst                                     ;
        CHAR            cOffMarketFlg                                   ;
        CHAR            cUserType                                       ;
        CHAR            cBuySellInd                                             ;
        LONG32          iMktType                                        ;
        LONG32          iDiscQty                                        ;
        LONG32          iDiscQtyRem                                     ;
        LONG32          iTotalTradedQty                                 ;
        DOUBLE64        fOrderNum                                       ;
        SHORT           iSerialNum                                      ;
        DOUBLE64        fAlgoOrderNo                                    ;
        DOUBLE64        fTrailingSLValue                                ;
        CHAR            cProCli                                         ;
        CHAR            sRemarks                [REMARKS_LEN]           ;
        SHORT           iStratergyId                                    ;
        INT16           iNoOfLeg                                        ;
        SHORT           iOrderType                                      ;
        SHORT           iOrderValidity                                  ;
        INT16           iMinFillQty                                             ;
        CHAR            cSLFlag                                         ;
        CHAR            cPBFlag                                         ;
        CHAR            cAvgLtpFlg                                      ; /* L - LTP & A - AVG_LTP */
        DOUBLE64        fPBTikAbsValue                                  ;
        DOUBLE64        fSLTikAbsValue                                  ;
        CHAR            cMarkProFlag                                    ;
        DOUBLE64        fMarkProVal                                     ;
        CHAR            cParticipantType                                ;
        CHAR            sSettlor                [SETTLOR_LEN]           ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
        CHAR            sPanID                  [INT_PAN_LEN]           ;
        CHAR            cGttType                                        ;
	LONG32          iGrpId						;
	CHAR            sPlatform               [PLATFORM_LEN]         	;
        CHAR            sChannel                [CHANNEL_LEN]   	;
        CHAR            sFiller                 [50]            	;	
};
#pragma pack()

#pragma pack(4)
struct FOREVER_ORDER_RESPONSE
{
        struct  INT_COMMON_RESP_HDR      IntRespHeader   ;
        CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
        CHAR            sEntityId               [ENTITY_ID_LEN]         ;
        CHAR            sClientId               [CLIENT_ID_LEN]         ;
        CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]     ;
        CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
        CHAR            cBuyOrSell                                      ;
        SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
        SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
        LONG32          iDiscQty                                        ;
        LONG32          iDiscQtyRem                                     ;
        LONG32          iTotalQtyRem                                    ;
        LONG32          iTotalQty                                       ;
        LONG32          iLastTradedQty                                  ;
        LONG32          iTotalTradedQty                                 ;
        LONG32          iMinFillQty                                     ;
        DOUBLE64        fPrice                                          ;
        DOUBLE64        fTriggerPrice                                   ;
        DOUBLE64        fOrderNum                                       ;
        SHORT           iSerialNum                                      ;
        CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]    ;
        DOUBLE64        fTradePrice                                     ;
        CHAR            cHandleInst                                     ;
        DOUBLE64        fAlgoOrderNo                                    ;
        SHORT           iStratergyId                                    ;
        CHAR            cOffMarketFlg                                   ;
        CHAR            cProCli                                         ;
        CHAR            cUserType                                       ;
        CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
        CHAR            sTransacTime            [DATE_TIME_LEN]         ;
        CHAR            sRemarks                [REMARKS_LEN]           ;
        LONG32          iMktType                                        ;
        /*------------------Latest Changes---------------------------*/
        CHAR            sReasonDesc         [DB_REASON_DESC_LEN]        ;
        CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
        INT16            iLegValue                                      ;
        CHAR            sTradeNum               [TRADE_NO_LEN]          ;
        CHAR            cMarkProFlag                                    ;
        DOUBLE64        fMarkProVal                                     ;
	CHAR            cParticipantType                                ;
        CHAR            sSettlor                [SETTLOR_LEN]           ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
        CHAR            sPanID                  [INT_PAN_LEN]           ;
        CHAR            cGttType                                        ;
        LONG32          iGrpId                                          ;	
	DOUBLE64	fOrdTriggerPrice				;
};
#pragma pack()

#endif
