#include <netinet/in.h>

struct EXCH_CONNECT_STATUS
{
	CHAR	cNseEqu;
	CHAR	cNseDrv;
	CHAR	cBseEqu;
	CHAR	cBseDrv;
	CHAR	cNseCur;
	CHAR	cMCXComm;
	CHAR	cBseCur;
//	CHAR    cNseCM;
	//CHAR Reserved2;
        CHAR Reserved3;
	//CHAR	cBseComm;
//        CHAR    cReserved3;
        //CHAR    cIcex;
};
/****
  struct  ProcessMonitor {
  CHAR      ProcessName[50];
  LONG32    ProcessId;
  CHAR      MainProcessName[50];
  };
  struct ProcessMonitorArray {
  struct ProcessMonitor ProcessMonitor[MAX_NO_OF_SYSTEM_PROCESS];
  };*******/

struct  ProcessMonitor {
	CHAR	sProcessName[50];
	LONG32	iProcessId;
	CHAR	sMainProcessName[50];
	LONG32	iAttempts;					
	LONG32	iStartTime ;
	LONG32	iEndTime ;
	CHAR	cRecoveryFlag ;
	CHAR	cLogFlag ;
};

struct ProcessMonitorArray {
	struct ProcessMonitor ProcessMonitor[MAX_NO_OF_SYSTEM_PROCESS];
};


struct DWS_ADAPTER_USER
{
	LONG32  iRelayId     ;
	pid_t       ProcessId   ;
	CHAR        sUser[USER_ID_LEN]      ;
	CHAR     sClientId[CLIENT_ID_LEN] ; 
};

struct DWS_ADAPTER_USER_ARRAY
{
	struct DWS_ADAPTER_USER dws_adapter_user[MAX_DWS_USERS];
};

struct ADMIN_ADAPTER_USER
{
	LONG32	iRelayId     ;
	pid_t   ProcessId   ;
	CHAR    sUser[USER_ID_LEN]      ;
	CHAR    sClientId[CLIENT_ID_LEN] ;
};
/*
struct ADMIN_ADAPTER_USER
{
	LONG32	iRelayId     ;
	pid_t   ProcessId   ;
	CHAR    sUser[USER_ID_LEN]      ;
	LONG32 	iSocket;
};
*/

struct ADMIN_ADAPTER_USER_ARRAY
{
	struct ADMIN_ADAPTER_USER admin_adap_user[MAX_DWS_USERS];
};

#pragma pack(4)
struct user_relay 
{
	LONG32		iRelayId;
	//LONG32		iUserId;
	ULONG64		iUserId;
	LONG32		iCheck;
	LONG32		iProcessId;
	CHAR		sExchId[4][EXCHANGE_LEN];
	CHAR		sSegment[4];
	struct	sockaddr_in	PeerAddr;
	CHAR		sClientId[CLIENT_ID_LEN] ;
	CHAR		cUserType ;
};
#pragma pack()

#pragma pack(4)
struct user_relay_array {
	struct user_relay user_relay[MAX_DWS_USERS];
};

#pragma pack()

#pragma pack(4)
struct ProcessMON
{
	LONG32  pid;
};
#pragma pack()

struct USER_DETAIL
{
	ULONG64		iUserId;
	//LONG32		iUserId;
	LONG32		iUserGrpId;
	CHAR		sLocationCode[LOC_CODE_LEN];
};

struct USER_DETAIL_ARRAY
{
	struct  USER_DETAIL User_Dtl[MAX_NO_OF_USERS_SHM] ;
	LONG32  iNoOfUsers;
};

/** BSE Location Code for Admin So making Diff Structe bcoz BSE Loc Code in greater than NSE @Nitish***/
struct BSE_USER_DETAIL
{
        LONG32          iUserId;
        LONG32          iUserGrpId;
        CHAR            sLocationCode[BSE_LOC_CODE_LEN];
};

struct BSE_USER_DETAIL_ARRAY
{
        struct  BSE_USER_DETAIL User_Dtl[MAX_NO_OF_USERS_SHM] ;
        LONG32  iNoOfUsers;
};

struct ICEX_USER_DETAIL
{
        LONG32          iUserId;
        LONG32          iUserGrpId;
        CHAR            sLocationCode[ICEX_LOC_CODE_LEN];
};

struct ICEX_USER_DETAIL_ARRAY
{
        struct  ICEX_USER_DETAIL User_Dtl[MAX_NO_OF_USERS_SHM] ;
        LONG32  iNoOfUsers;
};



#pragma pack(4)
struct SEC_MASTER_ARRAY
{
	CHAR		sExch			[DB_EXCH_ID_LEN]		;
	CHAR            cSeg							;
	CHAR		sScripCode		[DB_SCRIP_CODE_LEN]		;
	CHAR            sExchScripCode		[DB_SCRIP_CODE_LEN]            	;
	CHAR            sISINCode		[DB_ISIN_CODE_LEN]          	;
	CHAR            sSym			[DB_SYM_LEN]		      	;
	CHAR		sSymName		[DB_SYM_NAME_LEN]		;
	CHAR		sInsName		[DB_INS_LEN]			;
	CHAR		sExpiryDate		[DB_DATETIME_LEN]		;
	LONG32		iExpiryDate						;
	DOUBLE64	fStrikePrice					   	;
	CHAR		sOptType		[DB_OPT_TYPE_LEN]		;
	CHAR            sUndScripCode		[DB_SCRIP_CODE_LEN]            	;
	CHAR		sSeries			[DB_SERIES_LEN]			;
	CHAR            sMaturityMonYr          [MAT_MONYR]                     ;
	CHAR            sMaturityDay            [MAT_DAY]                     	;
	CHAR		cStatus							;
	CHAR		cExchStatus						;
	CHAR		cUndStatus						;
	CHAR		cPreOpenFlag						;
	CHAR		cPreOpenExchFlag					;
	CHAR		cITSFlag						;// used as cross currency flag
	CHAR		cAlgoFlag						;
	CHAR		cCAFlag							;
	LONG32		iFaceValue						;
	DOUBLE64	fTickSize						;
	DOUBLE64	fLotSize						;
	CHAR		sLotUnits		[DB_LOT_UNITS_LEN]		;
	DOUBLE64	fMcxMutliplier						;
	DOUBLE64	fMcxLot							;//in case of cross currnecy as RBI rate
	DOUBLE64	fUpperLimit						;
	DOUBLE64	fLowerLimit						;
	UT_hash_handle  hSecHndlr						;
	UT_hash_handle  hDrvSecHndlr						;
	UT_hash_handle  hMcxSecHndlr						;
	CHAR		sCustomSym		[CUSTOM_SYM_LEN]		;/*Adding symbol customization*/
	CHAR		sInstrumentTyp		[INSTRUMENT_TYPE]		;/*Adding Instrument Type*/	

        /*INTEROPS CHANGES*/
        CHAR            sIntropScripCode        [DB_SECURITY_ID_LEN]                            ;
        CHAR            sIntropSymbol           [DB_SYM_LEN]                            ;
        CHAR            sNseScripCode           [DB_SECURITY_ID_LEN]                            ;
        CHAR            sBseScripCode           [DB_SECURITY_ID_LEN]                            ;

	CHAR		sSmExpiryFlag		[DB_EXPIRY_FLAG_LEN]				;

};
#pragma pack()

#pragma pack(4)
struct  EXCH_ERROR_MSG
{
	CHAR		sHashKey		[12]				;
	LONG32		iErrorID						;
	CHAR		sErrDesc		[DB_REASON_DESC_LEN]		;
};
#pragma pack()

#pragma pack(4)
struct Hash_point
{
	void	*EqHash;
};
#pragma pack()

struct InvitationCount_group
{
	LONG32 iInvPacketCount;
};

struct InvitationCount
{
	struct InvitationCount_group InvCount_group[4];
};

struct  SLOT_INFO
{
	SHORT   iStatus;
	LONG32  iSlot ;
};

#pragma pack(4)
struct SLOT{
	struct SLOT_INFO SlotInfo[NO_OF_SLOTS];
};
#pragma pack( )

struct  IML_INFO
{
	LONG32  iImlUserId;
	struct  SLOT_INFO pSlotInfo[NO_OF_SLOTS];
};

struct IML_INFO_SHM
{
	struct IML_INFO pImlInfo[NO_QRY_IML];
};

#pragma pack(4)
struct SCHEME_MAST_ARRAY
{
	CHAR            sExch                   [DB_EXCH_ID_LEN]                ;
	CHAR            sSchemeCode             [DB_SCRIP_CODE_LEN]             ;
	CHAR            sExchSchemeCode         [DB_SCRIP_CODE_LEN]             ;
	CHAR            sISINCode               [DB_ISIN_CODE_LEN]              ;
	CHAR            sScheme                 [DB_SCHM_LEN]                   ;
	CHAR            sSchemeName             [DB_SCHM_NAME_LEN]              ;
	CHAR            sSeries                	[DB_SERIES_LEN]                 ;
	CHAR		sAMCCode		[DB_AMC_CODE_LEN]		;	
	CHAR		sAMCSchCode		[DB_AMC_SCHM_LEN]		;
	CHAR		sCategoryCode		[DB_CATEGORY_LEN]		;	
	CHAR		sRTAgentCode		[DB_RT_AGT_CODE_LEN]		;
	CHAR		sRTSchemeCode		[DB_RT_SCH_CODE_LEN]		;
	CHAR		cSchAllowDep						;
	CHAR		cSchDepMandrty						;
	UT_hash_handle  hNseSchmHndlr;
	UT_hash_handle  hBseSchmHndlr;
};
#pragma pack()


#pragma pack(4)
struct LTP_ARRAY
{
	CHAR    	sTokenId [10];
	DOUBLE64  	fLtp;
	DOUBLE64  	fHighPrice ;
	DOUBLE64  	fLowPrice ;
	UT_hash_handle  HashID  ;
};
#pragma pack()
#pragma pack(2)
struct          SPRD_SEC_MASTER
{
	CHAR            sScripCode          [DB_SCRIP_CODE_LEN]                 ;
	CHAR            sExchScripCode      [DB_SCRIP_CODE_LEN]                 ;
	CHAR            sInsName           [DB_INS_LEN]                         ;
	LONG32          iExpiryDate                                             ;
	CHAR            sExpiryDate             [DB_DATETIME_LEN]               ;
	CHAR            sOptionType		[DB_OPT_TYPE_LEN]               ;
	CHAR            sSymbol                 [SYMBOL_LEN]                    ;
};
#pragma pack()

#pragma pack(4)
struct SPRD_SEC_MASTER_ARRAY
{
	CHAR            sExch                   [DB_EXCH_ID_LEN]                ;
	CHAR            cSeg                                                    ;
	struct          SPRD_SEC_MASTER         SprdSecMstr     [LEG_LEN]                       ;
	LONG32          iCAFlag1                                                ;
	LONG32          iCAFlag2                                                ;
	DOUBLE64        fReferencePrice                                         ;
	LONG32          iDayLowPriceDiffRange                                   ;
	LONG32          iDayHighPriceDiffRange                                  ;
	LONG32          iOpLowPriceDiffRange                                    ;
	LONG32          iOpHighPriceDiffRange                                   ;
	LONG32          iBoardLotQuantity1                                      ;
	LONG32          iMinimumLotQuantity1                                    ;
	LONG32          iTickSize1                                              ;
	LONG32          iBoardLotQuantity2                                      ;
	LONG32          iMinimumLotQuantity2                                    ;
	LONG32          iTickSize2                                              ;
	CHAR            cEligibility                                            ;
	CHAR            cDeleteFlag                                             ;
	LONG32          iUnderlyingScripCode                                    ;
	CHAR            cUnderlyingStatus                                       ;
	CHAR            sUnderlyingSym  [45]                                    ;
	CHAR            sSpdTradingSym1 [50]                                    ;
	CHAR            sSpdTradingSym2 [50]                                    ;
	CHAR            cPreOpenFlag                                            ;
	CHAR            cPreOpenExchFlag                                        ;
	CHAR            cITSFlag                                                ;
	CHAR            cAlgoFlag                                               ;
	CHAR            cCAFlag                                                 ;
	CHAR            sKey                    [DB_SCRIP_CODE_LEN]             ;
	UT_hash_handle  hSecHndlr;
	UT_hash_handle  hDrvSecHndlr;
	UT_hash_handle  hMcxSecHndlr;
};
#pragma pack()

#pragma pack(4)
struct ENTITY_SETTLOR_MASTER_ARRAY
{
	CHAR		sCode	 		[DB_ENTITY_CODE_LEN]			;
	CHAR 		sNseCode		[DB_ENTITY_NSE_CODE_LEN]		;
	CHAR		sMcxCode		[DB_ENTITY_MCX_CODE_LEN]		;
	CHAR		sType			[DB_ENTITY_TYPE_LEN]			;
	CHAR		sSubType		[DB_ENTITY_SUB_TYPE_LEN]		;	
	CHAR		sParticipantCodeEQ	[DB_ENITY_SETTLOREQ_LEN]		;
	CHAR		sParticipantCodeDRV	[DB_ENITY_SETTLORDRV_LEN]		;
	CHAR		sParticipantCodeCURR	[DB_ENITY_SETTLORCURR_LEN]		;
	UT_hash_handle  hSecHndlr							;
        UT_hash_handle  hDrvSecHndlr							;
        UT_hash_handle  hCurrSecHndlr							;
        UT_hash_handle  hMcxSecHndlr							;

};
#pragma pack()

#pragma pack(4)
struct NOTIFY_SEC_MASTER_ARRAY
{
        CHAR            sExch                   [DB_EXCH_ID_LEN]                ;
        CHAR            cSeg                                                    ;
        CHAR            sScripCode              [DB_SCRIP_CODE_LEN]             ;
        CHAR            sUnqScripCode           [DB_SCRIP_CODE_LEN]             ;
        CHAR            sISINCode               [DB_ISIN_CODE_LEN]              ;
        CHAR            sSym                    [NOTI_SYMBOL_LEN]                    ;// [DB_SCRIP_CODE_LEN]
        CHAR            sSymName                [DB_SYM_NAME_LEN]               ;
        CHAR            sInsName                [DB_INS_LEN]                    ;
        CHAR            sSeries                 [DB_SERIES_LEN]                 ;
        CHAR            cStatus                                                 ;
	CHAR            cExchStatus                                             ;
        LONG32          iMcxMultiplr                                            ;
        LONG32          iCurMultiplr 						;
        UT_hash_handle  hSecHndlr;
};
#pragma pack()
/** BSE Location Code for Admin So making Diff Structe bcoz BSE Loc Code in greater than NSE @Nitish***/

#pragma pack(4)	
struct DAEMON_CLIENT_LIST
{
        LONG32  iSockFd;
	LONG32	iGroupId;
	CHAR 	sIPAdd[IP_ADDR_LEN]  ;
};
#pragma pack()


