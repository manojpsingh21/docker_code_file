#ifndef __NNFDATA_H__
#define __NNFDATA_H__
#include "global.h"
#define MAX_NO_STREAMS 50 /*** TAP Reg Changes ***/
//typedef CHAR * (*P_TO_FUN)(CHAR * x, CHAR * y);
#define MSG_AREA_DLD_FO_DATA_LEN 436
#define         TWIDDLE(A)              Twiddle((char *) &A, sizeof(A))

typedef BOOL (*P_TO_FUN)(CHAR * x, CHAR * y,LONG32 GroupId);
#pragma pack(2)
struct TAP_WRAPPER
{
	SHORT  Message_Len;
	LONG32 Seq_No;
	unsigned char digest[16];
};
#pragma pack()


#pragma pack(2)
struct  NNF_HEADER
{
	INT16           iMsgCode                      ;
	LONG32          iLogTimeStamp                 ;
	CHAR            sAlphaSplit [ALPHA_SPLIT_LEN] ;
	LONG32          iTraderID                    ; /*** Userid related changes ***/
	INT16           iErrorCode                    ;
	CHAR            sTimeStamp1 [NNF_DATE_TIME_LEN]   ;
	CHAR            sTimeStamp2 [NNF_DATE_TIME_LEN]   ;
	CHAR            sTimeStamp3 [NNF_DATE_TIME_LEN]   ;
	INT16           iMsgLength                    ;
};
#pragma pack()

#pragma pack(2)
struct INVITATION_PACKET
{
	struct          TAP_WRAPPER tWrapper                                            ;
	struct      NNF_HEADER  sHeader                         ;
	SHORT       invitation_count;
};
#pragma pack()


struct  NNF_ELIGIBILITY_PER_MKT
{
#ifdef  BIGENDIAN
	USHORT          NormalMkt               : 1  ;
	USHORT          OddLotMkt               : 1  ;
	USHORT          SpotMkt                 : 1  ;
	USHORT          AuctionMkt              : 1  ;
	USHORT          Reserved                : 4  ;
	USHORT          Reserved1               : 8  ;
#elif   LITTLEENDIAN
	USHORT          Reserved                : 4  ;
	USHORT          AuctionMkt              : 1  ;
	USHORT          SpotMkt                 : 1  ;
	USHORT          OddLotMkt               : 1  ;
	USHORT          NormalMkt               : 1  ;
	USHORT          Reserved1               : 8  ;
#endif
};

#pragma pack(2)
struct  NNF_SIGNON_REQ
{
	struct      NNF_HEADER  sHeader                         ;
	LONG32      iUserId                                      ;  /*** Userid related changes ****/
	CHAR        sReserved3 [8]                                      ;
	CHAR        sPassword[NSE_PASSWORD_LEN]                      ;
	CHAR        sReserved4 [8]                                      ;
	CHAR        sNewPassword[NSE_PASSWORD_LEN]                   ;
	CHAR        sTraderName[TRADER_NAME_LEN]                 ;
	LONG32      iLastPasswdChangetime;
	CHAR        sBrokerCode[BROKER_CODE_LENGTH]                 ;
	CHAR        cReserved1                                   ;
	SHORT       iBranchId                                    ;
	LONG32      iVersionNumber                               ;
	LONG32      iBatch2StartTime                             ;
	CHAR        cHostSwitchContext                           ;
	CHAR        sColour[COLOUR_LEN]                          ;
	CHAR        cReserved2                                   ;
	SHORT       iUserType                                    ;
	DOUBLE64    fSequenceNumber                              ;
	CHAR        sWorkstationAddr	[CLASS_NAME]                     ;
	CHAR        cBrokerStat					;
	CHAR        cShowIndex                                   ;
	struct      NNF_ELIGIBILITY_PER_MKT EligibilityPerMkt   ;
	SHORT       iMemberType                                  ;
	CHAR        cClearingStatus                              ;
	CHAR        sBrokerName[DRV_BROKER_NAME_LEN]                 ;
	CHAR        sReserved5 [16]                                     ;
        CHAR        sReserved6 [16]                                     ;
        CHAR        sReserved7 [16]                                     ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_SIGNON_RESP
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      iUserId                                      ;  /*** Userid related changes ****/
	CHAR        sReserved5 [8]                               ;
	CHAR        sPassword[NSE_PASSWORD_LEN]                      ;
	CHAR        sReserved6 [8]                               ;
	CHAR        sNewPassword[NSE_PASSWORD_LEN]                   ;
	CHAR        sTraderName[TRADER_NAME_LEN]                 ;
	LONG32      iLastPasswordChange                          ;
	CHAR        sBrokerCode[BROKER_CODE_LENGTH]                 ;
	CHAR        cReserved                                    ;
	INT16       iBranchId                                    ;
	LONG32      iVersionNumber                               ;
	LONG32      iEndTime                                     ;
	CHAR        cReserved1                                       ;/****Corrected during CloseOut changes ***/
	CHAR        sReserved2 [50]                              ;/****Corrected during CloseOut changes ***/
	CHAR        cReserved3                                       ;/****Corrected during CloseOut changes ***/
	INT16       iUserType                                    ;
	DOUBLE64    fSeqNumber                                   ;
	CHAR        sReserved4 [14]                              ;
	CHAR        cBrokerStatus                                ;
	CHAR        cShowIndex                                   ;
	struct      NNF_ELIGIBILITY_PER_MKT EligibilityPerMkt   ;
	SHORT       iMemberType                                  ;
	CHAR        cClearingStatus                              ;
	CHAR        sBrokerName[BROKER_NAME_LEN]                 ;
	CHAR        sReserved7 [16]                               ;
	CHAR        sReserved8 [16]                               ;
	CHAR        sReserved9 [16]                               ;


};
#pragma pack()

#pragma pack(2)
struct  NNF_SYS_INFO_REQ
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      LastUpdateTimePortfolio                     ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_MARKET_STATUS
{
	INT16           Normal                                       ;
	INT16           Oddlot                                       ;
	INT16           Spot                                         ;
	INT16           Auction                                      ;
};
#pragma pack()



#pragma pack(2)
struct   NNF_EX_MKT_STATUS
{
	INT16           Normal                                       ;
	INT16           Oddlot                                       ;
	INT16           Spot                                         ;
	INT16           Auction                                      ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_CONTRACT_DESC
{
        CHAR        sInstrumentName[INSTR_NAME_LEN]              ;
        CHAR        sSymbol[SYMBOL_LEN]                          ;
        LONG32      iExpiryDate                                  ;
        LONG32      iStrikePrice                                 ;
        CHAR        sOptionType[OPT_TYPE_LEN]                    ;
        SHORT       iCALevel                                     ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_TM_CONTRACT_DESC
{
	CHAR        sInstrumentName[INSTR_NAME_LEN]              ;
	CHAR        sSymbol[SYMBOL_LEN]                          ;
	LONG32      iExpiryDate                                  ;
	LONG32      iStrikePrice                                 ;
	CHAR        sOptionType[OPT_TYPE_LEN]                    ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_PL_MKT_STATUS
{
	INT16           Normal                                       ;
	INT16           Oddlot                                       ;
	INT16           Spot                                         ;
	INT16           Auction                                      ;
};
#pragma pack()

struct TRANS_FUN_PAIR
{
	INT16        Transcode;
	P_TO_FUN     pToFun;
};


#pragma pack(2)
struct NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS
{
#ifdef  BIGENDIAN
	USHORT               uiAON           :1                         ;
	USHORT               uiMinFill       :1                         ;
	USHORT               uiBooksMerged   :1                         ;
	USHORT               uiFiller        :5                         ;
	USHORT               uiFiller1       :8                         ;
#elif   LITTLEENDIAN
	USHORT               uiFiller        :5                         ;
	USHORT               uiBooksMerged   :1                         ;
	USHORT               uiMinFill       :1                         ;
	USHORT               uiAON           :1                         ;
	USHORT               uiFiller1       :8                         ;
#endif
};
#pragma pack()


#pragma pack(2)
struct NNF_SYSTEM_INFO_BCAST
{
	struct          NNF_HEADER sHeader                              ;
	struct          NNF_MARKET_STATUS MarketStatus                  ;
	struct          NNF_EX_MKT_STATUS   sExStatus                   ;
	struct          NNF_PL_MKT_STATUS   sPlStatus                   ;
	CHAR            UpdatePortFolio                                 ;
	LONG32          MktIndex                                        ;
	INT16           DefaultSettNormal                               ;
	INT16           DefaultSettSpot                                 ;
	INT16           DefaultSettAuction                              ;
	INT16           CompetitorPeriod                                ;
	INT16           SolicitorPeriod                                 ;
	INT16           WarnigPercent                                   ;
	INT16           VolFreezePercent                                ;
	LONG32          Reserved                                        ;
	LONG32          BoardLotQty                                     ;
	LONG32          TickSize                                        ;
	INT16           MaxGtcDays                                      ;
	struct          NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS     StockEligibilityInd;
	INT16           DiscQty                                         ;
	LONG32          RiskFreeInterestRate                            ;
};
#pragma pack()


#pragma pack(4)
struct  ORDER_TERMS
{
	CHAR            MFTerm                          ;
	CHAR            AONTerm                         ;
	CHAR            IOCTerm                         ;
	CHAR            GTCTerm                         ;
	CHAR            DayTerm                         ;
	CHAR            StopLossTerm                    ;
	CHAR            Market                          ;
	CHAR            ATO                             ;
	CHAR            Frozen                          ;
	CHAR            Modified                        ;
	CHAR            Traded                          ;
	CHAR            MatchedInd                      ;
	CHAR        MITFlag                             ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_UPDATE_LDB_REQ
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      LastUpdateSecTime                           ;
	LONG32      LastUpdatePartTime                          ;
	LONG32      LastUpdateInstTime                          ;
	LONG32      LastUpdateIndxTime                          ;
	CHAR        ReqForOpenOrders                            ;
	CHAR        Reserved                                    ;
	struct      NNF_MARKET_STATUS MarketStatus              ;
	struct      NNF_EX_MKT_STATUS   sExStatus               ;
	struct      NNF_PL_MKT_STATUS   sPlStatus               ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_MSG_DOWNLOAD_REQ
{
	struct      NNF_HEADER sHeader                          ;
	DOUBLE64    ExchSeqNum                                  ;
};
#pragma pack()


#pragma pack(2)             /*  |Added for storing the 2 timestamps that needs to be */
struct NNF_DOUBLE_INT       /* sent to the exch for msg dowwnload. These 2 timestamps are  */
{                           /* inserted in ExchSeqNum of NNF_MSG_DOWNLOAD_REQ              */
	unsigned  int   iLogTime1;
	unsigned  int   iLogTime2;
};
#pragma pack()


#pragma pack(2)
struct  NNF_ERROR_RESP
{
	struct      NNF_HEADER  sHeader                 ;
	CHAR        Key[KEY_LEN]                        ;
	CHAR        ErrorString [ERROR_MSG_LEN]      ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_EXCH_MSG_TO_TRADER_RESP
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      iTraderId                                    ; /*** Userid related changes ***/
	CHAR        cReserved1                                   ;/***** For CloseOut Changes ******/
	CHAR        sReserved2[3]                                ;/***** For CloseOut Changes ******/
	SHORT       iBcastMsgLength                              ;
	CHAR        sBcastMsg [ BCAST_MSG_LEN]                   ;

};
#pragma pack()

#pragma pack(2)
struct  NNF_FILLER_TERMS
{
	USHORT    b1    : 1 ;
	USHORT    b2    : 1 ;
	USHORT    b3    : 1 ;
	USHORT    b4    : 1 ;
	USHORT    b5    : 1 ;
	USHORT    b6    : 1 ;
	USHORT    b7    : 1 ;
	USHORT    b8    : 1 ;
	USHORT    b9    : 1 ;
	USHORT    b10   : 1 ;
	USHORT    b11   : 1 ;
	USHORT    b12   : 1 ;
	USHORT    b13   : 1 ;
	USHORT    b14   : 1 ;
	USHORT    b15   : 1 ;
	USHORT    b16   : 1 ;
	USHORT    b17    : 1 ;
        USHORT    b18    : 1 ;
        USHORT    b19    : 1 ;
        USHORT    b20    : 1 ;
        USHORT    b21    : 1 ;
        USHORT    b22    : 1 ;
        USHORT    b23    : 1 ;
        USHORT    b24    : 1 ;
        USHORT    b25    : 1 ;
        USHORT    b26   : 1 ;
        USHORT    b27   : 1 ;
        USHORT    b28   : 1 ;
        USHORT    b29   : 1 ;
        USHORT    b30   : 1 ;
        USHORT    b31   : 1 ;
        USHORT    b32   : 1 ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_ORDER_TERMS
{
#ifdef  BIGENDIAN
	USHORT      ATO             : 1                         ;
	USHORT      Market          : 1                         ;
	USHORT      StopLossTerm    : 1                         ;
	USHORT      MIIT            : 1                         ;
	USHORT      DayTerm         : 1                         ;
	USHORT      GTCTerm         : 1                         ;
	USHORT      IOCTerm         : 1                         ;
	USHORT      AONTerm         : 1                         ;
	USHORT      MFTerm          : 1                         ;
	USHORT      MatchedInd      : 1                         ;
	USHORT      Traded          : 1                         ;
	USHORT      Modified        : 1                         ;
	USHORT      Frozen          : 1                         ;
	USHORT      Reserved1       : 1                         ;
	USHORT      Reserved2       : 1                         ;
	USHORT      Reserved3       : 1                         ;
#elif   LITTLEENDIAN
	USHORT      AONTerm         : 1                         ;
	USHORT      IOCTerm         : 1                         ;
	USHORT      GTCTerm         : 1                         ;
	USHORT      DayTerm         : 1                         ;
	USHORT      MIIT            : 1                         ;
	USHORT      StopLossTerm    : 1                         ;
	USHORT      Market          : 1                         ;
	USHORT      ATO             : 1                         ;
	USHORT      Reserved1       : 1                         ;
	USHORT      Reserved2       : 1                         ;
	USHORT      Reserved3       : 1                         ;
	USHORT      Frozen          : 1                         ;
	USHORT      Modified        : 1                         ;
	USHORT      Traded          : 1                         ;
	USHORT      MatchedInd      : 1                         ;
	USHORT      MFTerm          : 1                         ;
#endif
};
#pragma pack()


#pragma pack(2)
struct      NNF_TRADE
{
	struct      NNF_HEADER              sHeader             ;
	LONG32       TokenNo                                     ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	LONG32      TradeNumber                                 ;
	LONG32      TradeQty                                    ;
	LONG32      TradePrice                                  ;
	CHAR        MktType                                     ;
	CHAR        BuyOpenClose                                ;
	LONG32      NewTradeQty                                 ;
	CHAR        BuyBrokerCode[BROKER_CODE_LEN]              ;
	CHAR        SellBrokerCode[BROKER_CODE_LEN]             ;
	/***    INT16       TraderID                                    ; ****/
	LONG32       TraderID                                    ;  /*** Userid related changes ***/
	CHAR        RequestedByTraderID                         ;
	CHAR        SellOpenClose                               ;
	CHAR        BuyAcctNumber[BUY_ACC_LEN]                  ;
	CHAR        SellAcctNumber[SELL_ACC_LEN]                ;
	CHAR        BuyParticipant[SELL_PARTICIPANT_LEN]        ;
	CHAR        SellParticipant[SELL_PARTICIPANT_LEN]       ;
	CHAR        BuyCoverUncover                             ;
	CHAR        SellCoverUncover                            ;
	CHAR        BuyGiveupFlg                                ;
	CHAR        SellGiveupFlg                               ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_EXPL_INFO
{
	LONG32       Token                           ;
	CHAR        InstrumentName [INSTR_NAME_LEN] ;
	CHAR        Symbol [SYMBOL_LEN]             ;
	LONG32      ExpiryDate                      ;
	LONG32      StrikePrice                     ;
	CHAR        OptionType [OPT_TYPE_LEN ]      ;
	SHORT       CALevel                         ;
	SHORT       ExplFlag                        ;
	DOUBLE64    ExplNumber                      ;
	SHORT       MarketType                      ;
	CHAR        AccountNumber [ACCOUNT_CODE_LEN];
	LONG32      Quantity                        ;
	SHORT       ProCli                          ;
	SHORT       ExType                          ;
	LONG32      EntryTime                       ;
	SHORT       BranchId                        ;
	LONG32       TraderId                        ; /*** Userid related changes ***/
	CHAR        BrokerCode [BROKER_CODE_LEN]    ;
	CHAR        Remarks [EXPL_REMARKS_LEN]      ;
	CHAR        ParticipantId [PARTICIPANT_ID_LEN];
};
#pragma pack()


#pragma pack(2)
struct          NNF_ORDER_ENTRY
{
	struct      NNF_HEADER sHeader                          ;
	CHAR        cParticipantType                             ;
	CHAR        cReserved1                                   ;
	INT16       iCompititorPeriod                            ;
	INT16       iSolicitorPeriod                             ;
	CHAR        cModCanBy                                    ;
	CHAR        cReserved2                                   ;
	INT16       iReasonCode                                  ;
	CHAR        sReserved3[4]                                ;
	LONG32      iToken                                       ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;   /*28*/
	CHAR        sCPBrokerCode [BROKER_CODE_LENGTH]              ;
	CHAR        cReserved4                                           ;/***** For CloseOut Changes ******/
	CHAR        sReserved5[2]                                ;/***** For CloseOut Changes ******/
	CHAR        cCloseOutFlag                                                            ;/***** For CloseOut Changes ******/
	CHAR        cReserved6                                                                       ;
	SHORT       iOrderType                                   ;
	DOUBLE64    fOrderNum                                    ;
	CHAR        sAccCode[ACCOUNT_CODE_LEN]                   ;
	INT16       iBookType                                    ;
	INT16       iBuyOrSell                                   ;
	LONG32      iDiscQty                                     ;
	LONG32      iDiscQtyRemaining                            ;
	LONG32      iTotalQtyRemaining                           ;
	LONG32      iTotalQty                                    ;
	LONG32      iQtyFilledToday                              ;
	LONG32      iPrice                                       ;
	LONG32      iTriggerPrice                                ;
	LONG32      iGoodTillDate                                ;
	LONG32      iEntryTime                                   ;
	LONG32      iMinFillQty                                  ;
	LONG32      iLastModifiedTime                            ;
	struct      NNF_ORDER_TERMS OrderTerms                  ;
	INT16       iBranchId                                    ;
	//    INT16       ExcgUserId                                  
	LONG32      iExchUserId                                  ; 
	CHAR        sBrokerCode [ BROKER_CODE_LENGTH]               ;
	CHAR        sRemarks [ORDER_REMARKS_LEN]                 ;
	CHAR        cOpenClose                                   ;
	CHAR        sSettlor [NNF_SETTLOR_LEN]                       ;
	INT16       iProCli                                      ;
	INT16       iSettlementDays                              ;
	CHAR        cCoverUncover                                ;
	CHAR        cGiveupFlag                                  ;
	struct      NNF_FILLER_TERMS sExchRsrvdFlds             ;
	//CHAR        sSeq[PRG_TRD_RESERVED_FIELD_LEN]                         ;
	DOUBLE64    fUserInfo                                   ;
	DOUBLE64    fReservedPrgTrd                             ;
	CHAR        sPanId      [NNF_PAN_NUM_LEN]               ;
	LONG32      iAlgoId                                     ;
	SHORT       iAlgoCategory                               ;
	LONG64	    iLastActRefId				;	
	CHAR        sReserved6 [52]                             ;

};
#pragma pack()


#pragma pack(2)
struct                  NNF_SUB_LEG_INFO
{
	LONG32          iToken;
	struct     	NNF_CONTRACT_DESC       pContractDesc                ;
	CHAR            sCPBrokerCode[BROKER_CODE_LENGTH]                                   ;
	CHAR        	Reserved1                                           ;
	SHORT       	iOrderType                                           ;
	SHORT       	iBuyOrSell                                           ;
	LONG32      	iDiscQty                                             ;
	LONG32      	iDiscQtyRemaining                                ;
	LONG32      	iTotalQtyRemaining                               ;
	LONG32      	iTotalQty                                        ;
	LONG32      	iQtyFilledToday                                  ;
	LONG32      	iPrice                                           ;
	LONG32      	iTriggerPrice                                    ;
	LONG32      	iMinFillQty                                          ;
	struct      	NNF_ORDER_TERMS  pOrderTerms                          ;
	CHAR        	cOpenClose                                           ;
	CHAR        	cCoverUncover                                        ;
	CHAR        	cGiveupFlag                                      ;
	CHAR        	Reserved2                                               ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_SPREAD_2L_3L_OE_REQ
{
	// struct          NNF_ORDER_ENTRY     OrderEntry                 ;
	//   LONG32                  PriceDiff                                                                          ;
	//  struct          NNF_SUB_LEG_INFO        SubLegInfo[SPREAD_2L]      ;
	struct         NNF_HEADER 	pHeader  	;
	CHAR            cParticipantType                ;
	CHAR            cFiller1                        ;
	SHORT           iCompitrPeriod1                 ;
	SHORT           iSolicitorPeriod1               ;
	CHAR            cModCxlBy1                      ;
	CHAR            cFiller9                        ;
	SHORT           iReasonCode1                    ;
	CHAR            sStartAlpha     [ALPHA_SPLIT_LEN];
	CHAR            sEndAlpha       [ALPHA_SPLIT_LEN];
	LONG32          iToken                          ;
	struct          NNF_CONTRACT_DESC       pContrtDesc        ;
	CHAR            sOpBrokerId1    [BROKER_CODE_LENGTH]            ;
	CHAR            cFiller2                        ;
	CHAR            sFillerOp1      [3]             ;
	CHAR            cFiller3                        ;
	SHORT           iOrderType                      ;
	DOUBLE64        fExchOrdNum                     ;
	CHAR            sAccNumber      [ACCOUNT_CODE_LEN]              ;
	SHORT           iBookType                       ;
	SHORT           iBuySell                        ;
	LONG32          iDisClose1			;
	LONG32          iDisCloseRem1			;
	LONG32          iTotQtyRem                      ;
	LONG32          iTotalQty                       ;
	LONG32          iTotTrdQty                      ;
	LONG32          iOrdPrice                       ;
	LONG32          iTriggerPrice                   ;
	LONG32          iGoodTillDate                   ;
	LONG32          iEntryDateTime                  ;
	LONG32          iMinFillAON1                    ;
	LONG32          iLastModified                   ;
	struct          NNF_ORDER_TERMS  pOrdTerms       ;
	SHORT           iBranchId                       ;
	LONG32          iTraderId                       ;
	CHAR            sBrokerId       [BROKER_CODE_LENGTH];
	CHAR            sOrdFiller      [24]            ;
	CHAR            cOpenClose1                     ;
	CHAR            sSettlor        [NNF_SETTLOR_LEN];
	SHORT           iProCli                         ;
	SHORT           iSettlePeriod                   ;
	CHAR            cReserved1                      ;
	CHAR            cGiveupFlag                     ;
	struct          NNF_FILLER_TERMS pExchRsrvdFlds ;
	//CHAR            sSeq[PRG_TRD_RESERVED_FIELD_LEN];
	DOUBLE64        fUserInfo                       ;
	DOUBLE64        fReservedPrgTrd                 ;
	CHAR            sPanId      [NNF_PAN_NUM_LEN]               ;
	LONG32          iAlgoId                                     ;
	SHORT           iAlgoCategory                               ;
	LONG64		iLastActRefId			;		
	CHAR            sReserved5 [52]                             ;
	LONG32          iPriceDiff                      ;
	struct          NNF_SUB_LEG_INFO        pSubLeg1Info      ;
	struct          NNF_SUB_LEG_INFO        pSubLeg2Info      ;

};
#pragma pack()



#pragma pack(2)
struct  NNF_PORTFOLIO_REQ
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      lLastUpdateDtTime                           ;
};
#pragma pack()

#pragma pack(2)
struct Download_Data
{
	LONG32  Stream_Id ;
	LONG32  Stream_Flag ; /**** Flag 1 for ON , 0 for OFF ********/
	ULONG32 TimeStamp1;
	ULONG32 TimeStamp2;
}Msg_Dow_Data[MAX_NO_STREAMS] ;
#pragma pack()

#pragma pack(2)
struct          NNF_MSG_DOWNLOAD_DATA_RESP
{
	struct      NNF_HEADER sHeader                          ;
	struct      NNF_HEADER pInnerHeader                     ;
	CHAR        Data [MSG_AREA_DLD_FO_DATA_LEN]           ;
};
#pragma pack()

#pragma pack(2)
struct   NNF_PORTFOLIO_DATA
{
	CHAR        cPortfolio[PORTFOLIO_LEN]                   ;
	LONG32       iToken                                      ;
	LONG32      lLastUpdtDtTime                             ;
	CHAR        cDeleteFlag                                 ;
};
#pragma pack()

struct DRVInvitationCount_group
{
	LONG32 DRVInvPacketCount;
};

struct DRVInvitationCount
{
	struct DRVInvitationCount_group DRVInvCount_group[4];
};


#pragma pack(2)
struct  NNF_PORTFOLIO_RESP
{
	struct      NNF_HEADER sHeader                          ;
	SHORT       iNoOfRecords                                ;
	CHAR        cMoreRecords                                ;
	CHAR        cFiller                                     ;
	struct      NNF_PORTFOLIO_DATA      sPortfolioData[MAX_NO_OF_PORTFOLIO] ;
};
#pragma pack()


#pragma pack(4)
struct  MS_EXCH_MSG_TO_TRADER_RESP
{
	struct          INT_COMMON_RESP_HDR IntRespHeader  ;
	LONG32          iTraderId                           ;
	CHAR            sActionCode[ACTION_CODE_LEN]        ;
	SHORT           iBcastMsgLength                     ;
	CHAR            sBcastMsg [ BCAST_MSG_LEN]          ;
} ;
#pragma pack()

#pragma pack(4)
struct      TRADE
{
	struct      INT_COMMON_RESP_HDR IntRespHeader      ;
	LONG32      TradeNumber                            ;
	LONG32      TradeQty                               ;
	DOUBLE64     TradePrice                             ;
	SHORT       MarketType                             ;
	SHORT       BookType                               ;
	LONG32      NewTradeQty                            ;
	CHAR        BuySellInd                             ;
	CHAR        CoverUncoverFlg                        ;
	CHAR        OpenCloseFlg                           ;
	CHAR        GiveUpFlg                              ;
	CHAR        ParticipantCode[PARTICIPANT_CODE_LEN]  ;
	CHAR        CBrokerCode[BROKER_CODE_LEN]           ;
	LONG32      TraderID                               ;
	LONG32      RequestedByTraderID                    ;
	DOUBLE64    OrderNumber                            ;
	INT16       OrderSerialNumber                      ;
	INT16       TradeSerialNumber                      ;
	CHAR        ClientId[CLIENT_ID_LEN]                ;
	CHAR        EntityId[ENTITY_ID_LEN]                ;
	CHAR        Settler [SETTLOR_LEN]                  ;
	CHAR        SecurityId[SECURITY_ID_LEN]            ;
	CHAR        SourceFlag                             ;
	CHAR            D2C1Flag                                                                ;
	CHAR            RetailFIFlag                                                    ;
	DOUBLE64        InternalRefId                                                   ;
	DOUBLE64        BasketOrdNo                                     ;
	CHAR            Reserved[ 4 ]                                                   ;
	CHAR            ProductId                                                               ;
	CHAR            OrderSessionType                                                ;
	CHAR            HandlInst ;

};
#pragma pack()

#pragma pack(2)
struct          NNF_TRADE_CONF_RESP
{
	struct      NNF_HEADER sHeader                          ;
	DOUBLE64    fTradedOrdNumber                             ;
	CHAR        sBrokerCode [BROKER_CODE_LENGTH]                ;
	CHAR        cReserved                                    ;
	/***    INT16       TraderId                                    ; ****/
	LONG32      iTraderId                                    ;   /*** Userid related changes ***/
	CHAR        cAccountNumber [ACCOUNT_CODE_LEN]            ;
	INT16       iBuyOrSell                                   ;
	LONG32      iOriginalQty                                 ;
	LONG32      iDiscQty                                     ;
	LONG32      iQtyRemaining                                ;
	LONG32      iDiscQtyRemaining                            ;
	LONG32      iPrice                                       ;
	struct      NNF_ORDER_TERMS OrderTerms                  ;
	LONG32      iGoodTillDate                                ;
	LONG32      iTradeNumber                                 ;
	LONG32      iQtyTraded                                   ;
	LONG32      iTradePrice                                  ;
	LONG32      iQtyFilledToday                              ;
	CHAR        sActivityType [ACTIVITY_TYPE_LEN]            ;
	LONG32      iTradeTime                                   ;
	DOUBLE64    fCounterOrdNum                               ;
	CHAR        sCPBrokerCode [BROKER_CODE_LENGTH]              ;
	LONG32      iToken                                       ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	CHAR        cOpenClose                                   ;
	CHAR        cOldOpenClose                                ;
	CHAR        cBookType                                    ;
	LONG32      iNewQty                                      ;
	CHAR        sOldAcctNum[ACCOUNT_CODE_LEN]                ;
	CHAR        sParticipant[PARTICIPANT_ID_LEN]             ;
	CHAR        sOldParticipant[PARTICIPANT_ID_LEN]          ;
	CHAR        cCoverUncover                                ;
	CHAR        cOldCoverUncover                             ;
	CHAR        cGiveUpTrade                                 ;
	CHAR        sPanId [NNF_PAN_NUM_LEN]                    ;
	CHAR        sOldPanId [NNF_PAN_NUM_LEN]                	;
	LONG32      iAlgoId                                    		;
	SHORT       iAlgoCategory                              		;
	LONG64	    iLastActRefID				;	
	CHAR        sReserved2[52]                             		;

};
#pragma pack()



#pragma pack(4)
struct  MS_TRADE_CONF_RESP
{
	struct          INT_COMMON_RESP_HDR IntRespHeader;
	DOUBLE64        fTradedOrdNumber                               ;
	LONG32          TradeNumber                                   ;
	CHAR            AccountNumber [CLIENT_ID_LEN]                     ;
	INT16           BuyOrSell                                     ;
	CHAR            D2C1Flag                                          ;
	CHAR            RetailFIFlag                                      ;
	LONG32          OriginalQty                                   ;
	LONG32          DiscQty                                       ;
	LONG32          QtyTraded                                     ;
	LONG32          QtyRemaining                                  ;
	LONG32          DiscQtyRemaining                              ;
	LONG32          QtyFilledToday                                ;
	DOUBLE64        OrderPrice                                    ;
	DOUBLE64        TradePrice                                    ;
	struct          ORDER_TERMS OrderTerms                        ;
	LONG32          GoodTillDate                                  ;
	CHAR            ActivityType [ACTIVITY_TYPE_LEN]              ;
	LONG32          TradeTime                                     ;
	DOUBLE64        CounterOrdNum                                 ;
	CHAR            CPBrokerCode [BROKER_CODE_LEN]                ;
	INT16           BookType                                      ;
	INT16           NewQty                                        ;
	DOUBLE64        OrderNumber                                   ;
	INT16           OrderSerialNumber                             ;
	INT16           TradeSerialNumber                             ;
	CHAR            ClientId[CLIENT_ID_LEN]                       ;
	CHAR            EntityId[ENTITY_ID_LEN]                       ;
	CHAR            MktType [MARKET_LEN]                          ;
	CHAR            Settler [SETTLOR_LEN]                         ;
	CHAR            SecurityId[SECURITY_ID_LEN]                   ;
	LONG32          UserId                                        ;
	CHAR            SourceFlag                                                                                ;
	CHAR            OpenClose                                                                                 ;
	CHAR            OldOpenClose                                                                      ;
	CHAR            CoverUncover                                                                      ;
	CHAR            OldCoverUncover                                                                   ;
	CHAR            GiveUpFlag                                                                                ;
	CHAR            PreOpenFlag                       ;
	CHAR            BseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	DOUBLE64        InternalRefId                   ;
	DOUBLE64        BasketOrdNo;
	CHAR            Reserved[ 4 ];
	CHAR            ProductId;
	CHAR            OrderSessionType;
	CHAR            HandlInst ;
	SHORT           SettType;
};
#pragma pack()
#pragma pack(4)

struct          NNF_GIVEUP
{
	DOUBLE64    OrdNumber                                       ;
	LONG32      TradeNo                                     ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	LONG32      QtyTraded                                   ;
	LONG32      TradePrice                                  ;
	CHAR        BrokerCode [BROKER_CODE_LEN]                ;
	CHAR        Reserved                                    ;
	SHORT       BuyOrSell                                   ;
	SHORT       BookType                                    ;
	LONG32          LastModDate_Time                                                        ;
	CHAR            InitByControl                                                           ;
	CHAR        OpenClose                                   ;
	CHAR        CoverUncover                                ;
	CHAR        Participant[PARTICIPANT_ID_LEN]             ;
	CHAR        GiveUpTrade                                 ;
	CHAR            Deleted                                                                         ;
};
#pragma pack()


#pragma pack(4)
struct MS_EX_RESP
{
	struct          INT_COMMON_RESP_HDR IntRespHeader;
	CHAR            SecurityId  [SECURITY_ID_LEN]          ;
	SHORT           ExFlag                              ;
	DOUBLE64        ExchExNumber                        ;
	CHAR            ClientId  [CLIENT_ID_LEN]                       ;
	CHAR            MktType[MARKET_LEN]         ;
	LONG32          ReqQuantity                         ;
	SHORT           ProCli                              ;
	SHORT           ExType                              ;
	CHAR            Remarks [ORDER_REMARKS_LEN]            ;
	SHORT           ReasonCode                          ;
	CHAR            ParticipantId [PARTICIPANT_CODE_LEN]  ;
	DOUBLE64        InternalExerciseNo                  ;
	SHORT           SerialNo                            ;
	LONG32          EntryTime                           ;
	LONG32          LastModifiedTime                    ;
	CHAR            EntityId[ENTITY_ID_LEN]                         ;
	CHAR            Settler [SETTLOR_LEN]           ;
	CHAR            D2C1Flag            ;
	CHAR            SourceFlag                          ;
	CHAR                    c_OrderSessionType      ;

};
#pragma pack()

#pragma pack(2)
struct  NNF_EXPL_REQUEST
{
	struct      NNF_HEADER      sHeader         ;
	SHORT       ReasonCode                      ;
	struct      NNF_EXPL_INFO   ExPlInfo        ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_GIVEUP_CONF_RESP
{
	struct      NNF_HEADER sHeader                          ;
	INT16           Reason_Code                                                                     ;
	struct          NNF_GIVEUP giveup                                                       ;
};
#pragma pack()

#pragma pack(4)

struct MS_GIVEUP_CONF_RESP
{
	struct                  INT_COMMON_RESP_HDR IntRespHeader       ;
	DOUBLE64                TradedOrdNumber                                                 ;
	CHAR            BrokerCode [BROKER_CODE_LEN]            ;
	CHAR            AccountNumber [CLIENT_ID_LEN]           ;
	LONG32          TradeNumber                                                             ;
	INT16                   BuyorSell                                                               ;
	CHAR                    D2C1Flag                                                                ;
	CHAR            RetailFIFlag                            ;
	CHAR            MktType [MARKET_LEN]                    ;
	LONG32          QtyTraded                               ;
	DOUBLE64        TradePrice                              ;
	CHAR            SecurityId[SECURITY_ID_LEN]             ;
	INT16           BookType                                ;
	DOUBLE64        OrderNumber                             ;
	INT16           OrderSerialNumber                       ;
	CHAR            ClientId[CLIENT_ID_LEN]                 ;
	CHAR            EntityId[ENTITY_ID_LEN]                 ;
	CHAR            Settler [SETTLOR_LEN]                               ;
	CHAR            SourceFlag                              ;
	CHAR            OpenClose                               ;
	CHAR            CoverUncover                            ;
	CHAR            GiveUpFlag                              ;
	DOUBLE64        InternalRefId                                           ;
	CHAR            ProductId                                                               ;
	CHAR            OrderSessionType                                                ;
	DOUBLE64        BasketOrdNo                                                             ;
	CHAR            BseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
};

#pragma pack()

#pragma pack(4)
struct SEQNO_REMARKS
{
	char    Remarks[15]                 ;
	char    SeqNO[9]                       ;
};
#pragma pack()


#pragma pack(2)
struct NNF_GR_REQUEST
{
        struct      NNF_HEADER          pHeader ;
        INT16           iBoxID                  ;
        CHAR            sBrokerID       [BROKER_CODE_LENGTH];
        CHAR            cFiller1                ;

};
#pragma pack()

#pragma pack(2)
struct NNF_GR_RESP
{
        struct      NNF_HEADER          pHeader ;
        INT16           iBoxID                  ;
        CHAR            sBrokerID       [BROKER_CODE_LENGTH];
        CHAR            cFiller1                ;
        CHAR            sHostIP         [NNF_HOST_IP_LEN];
        LONG32          iHostPort       ;
        CHAR            sSessionKey     [NNF_SESSION_KEY_LEN];

};
#pragma pack()


#pragma pack(2)
struct NNF_BOX_SIGNIN_REQUEST
{
        struct      NNF_HEADER          pHeader ;
        INT16           iBoxID                  ;
        CHAR            sBrokerID       [BROKER_CODE_LENGTH];
        CHAR            sFiller1        [5]     ;
        CHAR            sSessionKey     [NNF_SESSION_KEY_LEN];
};
#pragma pack()

#pragma pack(2)
struct NNF_BOX_SIGNIN_RESPONSE
{
        struct      NNF_HEADER          pHeader ;
        INT16           iBoxID                  ;
        CHAR            sFiller1        [10]     ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_ORDER_ENTRY_REQ_TM
{
        INT16           iTransCode                              ;
        LONG32          iTradeID                                ;
        INT16           iReasonCode                             ;
        LONG32          iTokenNo                                ;
        struct          NNF_TM_CONTRACT_DESC	pSecInfo                ;
        CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
        INT16           iBookType                                        ;
        INT16           iBuyOrSell                                       ;
        LONG32          iDiscQty                                         ;
        LONG32          iTotalQty                                        ;
        LONG32          iPrice                                           ;
        LONG32          iGoodTillDate                                    ;
        struct          NNF_ORDER_TERMS pOrderTerms                      ;
        INT16           iBranchId                                        ;
        LONG32          iExcgUserId                                     ;
        CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
        CHAR            cSecSuspInd                                     ;
        CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
        INT16           iProCli                                          ;
	CHAR            cReservd2                                       ;
        //LONG32                iTransactionId                          ;
        struct          NNF_FILLER_TERMS sExchRsrvdFlds             ;
        DOUBLE64        fUserInfo                                       ;
        CHAR            sPanId  [NNF_PAN_NUM_LEN]                               ;
        LONG32          iAlgoId                                         ;
        INT16           iReservFiller                                   ;
        CHAR            sReservd4[32]                                   ;
};
#pragma pack()

#pragma pack(2)
struct                  NNF_ORD_MOD_CAN_REQ_TM
{
        INT16           iTransCode                              ;
        LONG32          iUserId                                         ;
        CHAR            cModCanBy                                       ;
	LONG32		iTokenNo;
        struct          NNF_TM_CONTRACT_DESC	pSecInfo                ;
        DOUBLE64        fOrderNum                                        ;
        CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
        INT16           iBookType                                        ;
        INT16           iBuyOrSell                                       ;
        LONG32          iDiscQty                                         ;
        LONG32          iDiscQtyRemaining                                ;
        LONG32          iTotalQtyRemaining                               ;
        LONG32          iTotalQty                                        ;
        LONG32          iQtyFilledToday                                  ;
        LONG32          iPrice                                           ;
	LONG32          iGoodTillDate                                   ;
        LONG32          iEntryTime                                       ;
        LONG32          iLastModifiedTime                                ;
        struct          NNF_ORDER_TERMS pOrderTerms                      ;
        INT16           iBranchId                                        ;
        LONG32          iExcgUserId                                     ;
        CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
        CHAR            cSecSuspInd                                      ;
        CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
        INT16           iProCli                                          ;
	CHAR            cReserved1                              ;
        struct          NNF_FILLER_TERMS sExchRsrvdFlds             ;
        DOUBLE64        fUserInfo                                       ;
        //LONG32          iTransactionID                                  ;
        CHAR            sPanId  [NNF_PAN_NUM_LEN]                               ;
        LONG32          iAlgoId                                         ;
        INT16           iReservdFiller1                                 ;
        LONG64          iLastActiRefrnc                                 ;
        CHAR            sReserved2      [24]                            ;
};
#pragma pack()

#pragma pack(2)
struct                  NNF_ORD_RESPONSE_TM
{
        INT16           iTransCode                                      ;
        LONG32          iLogTime                                        ;
        LONG32          iUserID                                         ;
        INT16           iErrorCode                                      ;
        DOUBLE64        fTimeStamp1                                     ;
        CHAR            cTimeStamp2                                     ;
	CHAR            cModCanBy                                       ;
        INT16           iReasonCode                                     ;
        LONG32		iTokenNo                                     ;
        struct          NNF_TM_CONTRACT_DESC       pSecInfo                ;
        CHAR            cCloseOutFlag                                           ;
        DOUBLE64        fOrderNum                                        ;
        CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
        INT16           iBookType                                        ;
        INT16           iBuyOrSell                                       ;
        LONG32          iDiscQty                                         ;
        LONG32          iDiscQtyRemaining                                ;
        LONG32          iTotalQtyRemaining                               ;
        LONG32          iTotalQty                                        ;
        LONG32          iQtyFilledToday                                  ;
        LONG32          iPrice                                           ;
	LONG32          iGoodTillDate                                    ;
        LONG32          iEntryTime                                       ;
        LONG32          iLastModifiedTime                                ;
        struct          NNF_ORDER_TERMS pOrderTerms                      ;
        INT16           iBranchId                                        ;
        LONG32          iExcgUserId                                     ;
        CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
        CHAR            cSecSuspInd                                      ;
        CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
        INT16           iProCli                                          ;
	CHAR            cReserved3                                      ;
        //LONG32                iTransactionID                                  ;
        struct          NNF_FILLER_TERMS sExchRsrvdFlds             ;
        DOUBLE64        fUserInfo                                       ;
        LONG64          iTimeStamp                                      ;
        CHAR            sPanId  [NNF_PAN_NUM_LEN]                               ;
        LONG32          iAlgoId                                         ;
        INT16           iReservedFill                                   ;
        LONG64          iLastActiRef                                    ;
        CHAR            sReserved1[52]                                  ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_TRADE_RESP_TM
{
        INT16           iTransCode                                              ;
        LONG32          iLogTime                                                ;
	LONG32          iUserID                                                 ;
        LONG64          iTimeStamp                                              ;
        DOUBLE64        fTimeStamp1                                             ;
        DOUBLE64        fTimeStamp2                                             ;
        DOUBLE64        fTradedOrdNumber                                        ;
        CHAR            sBrokerCode [BROKER_CODE_LENGTH]                            ;
        CHAR            cReservd1                                               ;
        CHAR            sAccountNumber [ACCOUNT_CODE_LEN]                        ;
        INT16           iBuyOrSell                                                                       ;
        LONG32          iOriginalQty                                                                     ;
        LONG32          iDiscQty                                                                         ;
        LONG32          iQtyRemaining                                                            ;
        LONG32          iDiscQtyRemaining                                                        ;
        LONG32          iPrice                                                                           ;
        struct          NNF_ORDER_TERMS pOrderTerms                                      ;
        LONG32          iGoodTillDate   ;

        LONG32          iFillNumber                                    ;/** Userid related changes **/
        LONG32          iQtyTraded                                                                       ;
        LONG32          iTradePrice                                                                      ;
        LONG32          iQtyFilledToday                                                          ;
        CHAR            sActivityType [ACTIVITY_TYPE_LEN]                        ;
        LONG32          iTradeTime                                                                       ;
        LONG32          iTokenNo        ;
        struct          NNF_TM_CONTRACT_DESC       pSecInfo                         ;
        CHAR            cOpenClose              ;
        CHAR           	cBookType                                                                        ;
        CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
        CHAR            cSecSuspInd                                      ;
        CHAR            sPanId  [NNF_PAN_NUM_LEN]                                               ;
        LONG32          iAlgoId                                                                 ;
        INT16           iReservedFiller                                                         ;
        LONG64          iLastActiRef                                                            ;
        CHAR            sReserved1[52]                                                          ;
};
#pragma pack()
/**
 *1. BOX_SIGN_OFF  20322 is send while NSE exchnage disconnects the interactive connections.
 *
 * */	
#pragma pack(2)
struct  NNF_BOX_SIGN_OFF_TM
{
        struct  NNF_HEADER pHeader;
        SHORT   iBoxId          ;
};
#pragma pack()


typedef struct {
	ULONG32 state[4];                                   /* state (ABCD) */
	ULONG32 count[2];        /* number of bits, modulo 2^64 (lsb first) */
	unsigned char buffer[64];                         /* input buffer */
} MD5_CTX;

void MD5Init PROTO_LIST ((MD5_CTX *));
void MD5Update PROTO_LIST ((MD5_CTX *, unsigned char *, unsigned int));
void MD5Final PROTO_LIST ((unsigned char [16], MD5_CTX *));

/* MD5 context. */
typedef struct  NNF_SYSTEM_INFO_BCAST       NNF_SYS_INFO_RESP;
typedef struct  NNF_EXCH_MSG_TO_TRADER_RESP NNF_EXCH_MSG_TO_TRADER_RESP;
typedef struct  MS_EXCH_MSG_TO_TRADER_RESP  MS_EXCH_MSG_TO_TRADER_RESP;
typedef struct  TRADE                      MS_TRADE_MOD_CAN_ERROR_RESP;
typedef	struct      NNF_TRADE		NNF_TRADE_MOD_CAN_ERROR_RESP;
typedef struct  MS_TRADE_CONF_RESP         MS_TRADE_CONF_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_TRADE_CONF_RESP;
typedef struct MS_EX_RESP                  MS_EX_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_REQUESTED_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_CONFIRMATION_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_ERROR_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_MOD_REQUESTED_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_MOD_CONFIRMATION_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_MOD_ERROR_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_CANCEL_REQUESTED_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_CANCEL_CONFIRMATION_RESP;
typedef struct MS_EX_RESP                  MS_EXPL_CANCEL_ERROR_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_ENTRY_REQUESTED_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_STOP_LOSS_ORDER_TRIGGER_RESP;
typedef struct MS_GIVEUP_CONF_RESP  	MS_GIVEUP_CONF_RESP;	
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_CONF_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_OE_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_3L_OE_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_REQ;






extern BOOL fMAP_ORDER                              (CHAR *, CHAR *);
extern BOOL fCMS_STOP_LOSS_ORDER_TRIGGER            (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CONF_MAP_RESP                (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CAN_MAP_RESP                 (CHAR *, CHAR *);
extern BOOL fCMS_EXCH_MSG_TO_TRADER_RESP            (CHAR *, CHAR *);
extern BOOL fCMS_UPDATE_LDB_TRAILER_RESP            (CHAR *, CHAR *);
extern BOOL fBATCH_ORDER_CANCELLATION		    (CHAR *, CHAR *);

extern BOOL fMAP_1L_ORDER_RESP(CHAR *,CHAR *);
extern BOOL fCMS_STOP_LOSS_ORDER_TRIGGER(  CHAR *,CHAR *);
extern BOOL fCMS_MAP_EXERCISE_RESP(CHAR *,CHAR *);
extern BOOL fCMS_TRADE_CONF_MAP_RESP(CHAR *,CHAR *);
extern BOOL fCMS_TRADE_CAN_MAP_RESP(CHAR *,CHAR *);
extern BOOL  fMAP_GIVEUP_APP_HANDLER(  CHAR *NNFData,CHAR *cp_Internal);
extern BOOL fCMS_EXCH_MSG_TO_TRADER_RESP(CHAR *,CHAR *);	
#endif
