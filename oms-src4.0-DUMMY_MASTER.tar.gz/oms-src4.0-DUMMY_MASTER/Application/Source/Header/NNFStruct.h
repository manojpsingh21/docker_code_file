
#ifndef __EQUNSENNFSTRUCTS_H__
#define __EQUNSENNFSTRUCTS_H__
#include "global.h"
typedef BOOL (*P_TO_FUN)(CHAR * x, CHAR * y,LONG32 GroupId);

#pragma pack(2)
struct TAP_WRAPPER
{
	SHORT  Message_Len;
	LONG32 Seq_No;
	unsigned char digest[16];
};
#pragma pack()


#pragma pack(2)
struct  NNF_HEADER
{
	INT16           iMsgCode                         ;
	LONG32          iLogTimeStamp                    ;
	CHAR            sAlphaSplit [ALPHA_SPLIT_LEN]    ;
	LONG32      	iTraderID                	;  
	INT16           iErrorCode                       ; 
	CHAR            sTimeStamp1 [NNF_DATE_TIME_LEN]  ;
	CHAR            sTimeStamp2 [NNF_DATE_TIME_LEN]  ;
	CHAR            sTimeStamp3 [NNF_DATE_TIME_LEN]  ;
	INT16           iMsgLength                       ;
};
#pragma pack()

#pragma pack(2)
struct INT_REQUEST_HEADER
{
	LONG32          iSeqNo                           ;
	SHORT           iMsgLength                       ;
	SHORT           iInternalTransCode               ;
	CHAR            sExcgId[EXCHANGE_LEN]            ;
	LONG32          iUserIdOrLogPktId                ;
	CHAR            cUserTypeOrLogInfoType           ;
	CHAR            cSegment                         ;
};
#pragma pack()

struct TRANS_FUN_PAIR
{
	INT16        Transcode;
	P_TO_FUN     pToFun;
};

#pragma pack(2)
struct INT_RESP_HEADER
{
	LONG32          iSeqNo                                   ;
	SHORT           iMsgLength                               ;
	SHORT           iMsgCode                                 ;
	CHAR            sExcgId[EXCHANGE_LEN]                    ;
	SHORT           iErrorId                                 ;
	LONG32          iUserIdOrLogPktId                        ;
	CHAR            cUserTypeOrLogInfoType                   ;
	LONG32          iTimeStamp                               ;
	CHAR            cSegment                                 ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SEC_INFO
{
	CHAR            sSymbol [10]             ;
	/****   CHAR            Symbol [SYMBOL_LEN]             ;*****/
	CHAR            sSeries [2]              ;
	/***    CHAR            Series [SERIES_LEN]             ;****/
}  ;
#pragma pack()

#pragma pack(2)
struct  NNF_MARKET_STATUS
{
	INT16           iNormal                          ;
	INT16           iOddlot                          ;
	INT16           iSpot                            ;
	INT16           iAuction                         ;
	INT16           iCallAuction1                    ;
	INT16           iCallAuction2                    ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_FILLER_TERMS
{
	USHORT    b1    	: 1 ;
	USHORT    b2    	: 1 ;
	USHORT    b3    	: 1 ;
	USHORT    b4    	: 1 ;
	USHORT    b5    	: 1 ;
	USHORT    b6    	: 1 ;
	USHORT    b7    	: 1 ;
	USHORT    b8    	: 1 ;
	USHORT    b9    	: 1 ;
	USHORT    b10           : 1 ;
	USHORT    b11           : 1 ;
	USHORT    b12           : 1 ;
	USHORT    b13           : 1 ;
	USHORT    b14           : 1 ;
	USHORT    b15           : 1 ;
	USHORT    b16           : 1 ;
	USHORT    b17    	: 1 ;
	USHORT    b18    	: 1 ;
	USHORT    b19    	: 1 ;
	USHORT    b20    	: 1 ;
	USHORT    b21    	: 1 ;
	USHORT    b22   	: 1 ;
	USHORT    b23   	: 1 ;
	USHORT    b24   	: 1 ;
	USHORT    b25   	: 1 ;
	USHORT    b26           : 1 ;
	USHORT    b27           : 1 ;
	USHORT    b28           : 1 ;
	USHORT    b29           : 1 ;
	USHORT    b30           : 1 ;
	USHORT    b31           : 1 ;
	USHORT    b32         	: 1 ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_ORDER_TERMS
{
	/****************************
#ifdef  BIGENDIAN
USHORT          ATO                     : 1     ;
USHORT          Market                  : 1     ;
USHORT          StopLossTerm            : 1     ;
USHORT          DayTerm                 : 1     ;
USHORT          GTCTerm                 : 1     ;
USHORT          IOCTerm                 : 1     ;
USHORT          AONTerm                 : 1     ;
USHORT          MFTerm                  : 1     ;


USHORT          MatchedInd              : 1     ;
USHORT          Traded                  : 1     ;
USHORT          Modified                : 1     ;
USHORT          Frozen                  : 1     ;
USHORT          PreOpen                 : 1     ;       ** added for PreOpen changes  **
USHORT          Reserved                : 3     ;       ** changed for PreOpen changes  **
#elif   LITTLEENDIAN*****************************/
	USHORT          MFTerm                  : 1     ;
	USHORT          AONTerm                 : 1     ;
	USHORT          IOCTerm                 : 1     ;
	USHORT          GTCTerm                 : 1     ;
	USHORT          DayTerm                 : 1     ;
	USHORT          StopLossTerm            : 1     ;
	USHORT          Market                  : 1     ;
	USHORT          ATO                     : 1     ;
	USHORT          Reserved                : 3     ;       /** changed for PreOpen changes  **/
	USHORT      	PreOpen         	: 1 	;       /** added for PreOpen changes  **/
	USHORT          Frozen                  : 1     ;
	USHORT          Modified                : 1     ;
	USHORT          Traded                  : 1     ;
	USHORT          MatchedInd              : 1     ;
	/**#endif***/
};
#pragma pack()


#pragma pack(2)
struct                  NNF_ORDER_ENTRY
{
	struct          NNF_HEADER 	pHeader				;
	CHAR            cParticipantType                         	;
	CHAR            cReserved                               		;
	INT16           iCompititorPeriod                                ;
	INT16           iSolicitorPeriod                                 ;
	CHAR            cModCanBy					;
	CHAR            cReserved1                               	;
	INT16           iReasonCode                              	;
	CHAR            sStartAlpha [ALPHA_SPLIT_LEN]            	;
	CHAR            sEndAlpha [ALPHA_SPLIT_LEN]              	;
	struct          NNF_SEC_INFO    pSecInfo		;
	INT16           iAuctionNum                                      ;
	CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                  ;
	CHAR            cSecSuspInd                                      ;
	DOUBLE64        fOrderNum                                        ;
	CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
	INT16           iBookType                                        ;
	INT16           iBuyOrSell                                       ;
	LONG32          iDiscQty                                         ;
	LONG32          iDiscQtyRemaining                                ;
	LONG32          iTotalQtyRemaining                               ;
	LONG32          iTotalQty                                        ;
	LONG32          iQtyFilledToday                                  ;
	LONG32          iPrice                                           ;
	LONG32          iTriggerPrice                                    ;
	LONG32          iGoodTillDate                                    ;
	LONG32          iEntryTime                                       ;
	LONG32          iMinFillQty                                      ;
	LONG32          iLastModifiedTime                                ;
	struct          NNF_ORDER_TERMS pOrderTerms                      ;
	INT16           iBranchId                                        ;
	LONG32      	iExcgUserId                                  	;
	CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
	CHAR            sRemarks[OE_REMARKS_LEN]                         ;
	CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
	INT16           iProCli                                          ;
	INT16           iSettlementDays                                  ;
	DOUBLE64    	fUserInfo                                   	;
	DOUBLE64    	fReservedPrgTrd                                 ;
	struct      	NNF_FILLER_TERMS 		pExchRsrvdFlds  ;
	//CHAR        	sSeq[PRG_TRD_RESERVED_FIELD_LEN] 		; 
	//LONG32		iMktType					;
	CHAR		sPanId	[NNF_PAN_NUM_LEN]				;
	LONG32		iAlgoId						;
	SHORT		iAlogCategory					;
//	CHAR		sReserved  [NNF_RESERVED_LEN]			;
	LONG64		iLastActRefId					;
	CHAR            sReserved  [52];
};
#pragma pack()

#pragma pack(2)
struct  NNF_ELIGIBILITY_PER_MKT
{
#ifdef  BIGENDIAN
	USHORT          NormalMkt               : 1     ;
	USHORT          OddLotMkt               : 1     ;
	USHORT          SpotMkt                 : 1     ;
	USHORT          AuctionMkt              : 1     ;
	USHORT          CallAuction1            : 1;
	USHORT          CallAuction2             : 1;
	USHORT          Reserved                : 4     ;
	USHORT          Reserved1               : 7; /** changed for PreOpen changes transcode 2300 **/
	USHORT          PreOpen                 : 1; /** added for PreOpen changes transcode 2300  **/

#elif   LITTLEENDIAN
	USHORT          Reserved                : 4     ;
	USHORT          CallAuction2             : 1;
	USHORT          CallAuction1            : 1;
	USHORT          AuctionMkt              : 1     ;
	USHORT          SpotMkt                 : 1     ;
	USHORT          OddLotMkt               : 1     ;
	USHORT          NormalMkt               : 1     ;
	USHORT          PreOpen                 : 1; /** added for PreOpen changes transcode 2300  **/
	USHORT          Reserved1               : 7; /** changed for PreOpen changes transcode 2300  **/
#endif
};
#pragma pack()


#pragma pack(2)
struct  NNF_SIGNON_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
	/*              INT16           UserId                                                                          ;*/
	LONG32      	iUserId                                      ;/** Userid related changes **/
	CHAR		sReserved4[8]					;
	CHAR            sPassword[NSE_PASSWORD_LEN]                                              ;
	CHAR		sReserved5[8]					;
	CHAR            sNewPassword[NSE_PASSWORD_LEN]                                   ;
	CHAR            sTraderName[TRADER_NAME_LEN]                                     ;
	LONG32          iLastPasswordChange                                                      ;
	CHAR            sBrokerCode[BROKER_CODE_LENGTH]                                     ;
	CHAR            cReserved                                                                        ;
	INT16           iBranchId                                                                        ;
	CHAR            sReserved1 [4]                                                           ;
	LONG32          iEndTime                                                                         ;
	CHAR            sReserved2 [52]                                                          ;
	INT16           iUserType                                                                        ;
	CHAR            sSeqNumber[EXCHANGE_SEQ_NUM_LEN]                         ;
	CHAR            sReserved3 [14]                                                          ;
	CHAR            cBrokerStatus                                                            ;
	CHAR            cReserved4                                                                       ;
	struct          NNF_ELIGIBILITY_PER_MKT pEligibilityPerMkt       ;
	CHAR        	sBrokerName[BROKER_NAME_LEN]                 ;
	CHAR        	cReserved5                                   ;
	CHAR            sReserved6 [16]                                                           ;
        CHAR            sReserved7 [16]                                                           ;
        CHAR            sReserved8 [16]                                                           ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_SIGNON_REQ
{
	struct          NNF_HEADER      pHeader                 ;
	LONG32      	iUserId                                 ;/** Userid related changes **/
	CHAR		sReserved5[8]				;
	CHAR            sPassword[NSE_PASSWORD_LEN]             ;
	CHAR		sReserved6[8]				;
	CHAR            sNewPassword[NSE_PASSWORD_LEN]          ;
	//CHAR            sReserved [30]                        ;
	CHAR		sTraderName[26]				;
	LONG32		iLastPasswdChangetime			;
	CHAR            sBrokerCode[BROKER_CODE_LENGTH]         ;
	CHAR            cReserved1                              ;
	INT16		iBranchID				;
	LONG32          iVersionNumber                          ;
	CHAR            sReserved2 [56]                         ;
	INT16		iUserType				;
	DOUBLE64	fSequenceNum				;
	CHAR            sWorkstationAddr [WORK_STATION_ADDR_LEN];
	CHAR		cBrokerStat				;
	CHAR		cShowIndex				;
	CHAR            sReserved3 [2]                          ;
	CHAR        	sBrokerName[BROKER_NAME_LEN]            ;
	CHAR            sReserved7 [16]                         ;
	CHAR            sReserved8 [16]                         ;
	CHAR            sReserved9 [16]                         ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SYS_INFO_REQ
{
	struct          NNF_HEADER pHeader                                                      ;
};
#pragma pack()

#pragma pack(2)
struct  ORDER_TERMS
{
	CHAR            cMFTerm                          ;
	CHAR            cAONTerm                         ;
	CHAR            cIOCTerm                         ;
	CHAR            cGTCTerm                         ;
	CHAR            cDayTerm                         ;
	CHAR            cStopLossTerm                    ;
	CHAR            cMarket                          ;
	CHAR            cATO                             ;
	CHAR            cFrozen                          ;
	CHAR            cModified                        ;
	CHAR            cTraded                          ;
	CHAR            cMatchedInd                      ;
	CHAR        	cMITFlag                             ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_SYS_INFO_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
	struct          NNF_MARKET_STATUS pMarketStatus;/**  PreOpen transcode 1601 **/
	LONG32          iMarketIndex                                                                     ;
	INT16           iNormalMktDefSttlPeriod                                          ;
	INT16           iSpotMktDefSttlPeriod                                            ;
	INT16           iAuctionMktDefSttlPeriod                                         ;
	INT16           iDefCompititorPeriod                                                     ;
	INT16           iDefSolicitorPeriod                                                      ;
	INT16           iWarnigPercent                                                           ;
	INT16           iVolFreezePercent                                                        ;
	LONG32          iReserved                                                                        ;
	LONG32          iBoardLotQty                                                                     ;
	LONG32          iTickSize                                                                        ;
	INT16           iMaxGTCDays                                                                      ;
	INT16           iDiscQty                                                                         ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_REQ
{
	struct          NNF_HEADER pHeader                                                      ;
	LONG32          iLastUpdateSecTime                                                       ;
	LONG32          iLastUpdatePartTime                                                      ;
	CHAR            cReqForOpenOrders                                                        ;
	CHAR            cReserved                                                                        ;
	struct          NNF_MARKET_STATUS pMarketStatus                          ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_MSG_DOWNLOAD_REQ
{
	struct          NNF_HEADER pHeader                                                      ;
	DOUBLE64        fExchSeqNum                                                                      ;
	/*      CHAR        ExchSeqNum[8];*/
};
#pragma pack()

#pragma pack(2)
struct NNF_DOUBLE_INT
{
	unsigned  int   LogTime1;
	unsigned  int   LogTime2;
};
#pragma pack()

#pragma pack(2)
struct  NNF_ERROR_RESP
{
	struct          NNF_HEADER      pHeader                                                 ;
	struct          NNF_SEC_INFO    pSecInfo                                         ;
	CHAR            sErrorString [ERROR_MSG_LEN]                          ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_EXCH_MSG_TO_TRADER_RESP
{
	struct              NNF_HEADER pHeader                                                      ;
	/*    SHORT             TraderId                                                                        ; */
	LONG32      	iTraderId                                    ;/** Userid related changes **/
	CHAR                sActionCode[ ACTION_CODE_LEN]                            ;
	CHAR            	cReserved                                                                        ;/***Addded while closeout changes*****/
	SHORT               iBcastMsgLength                                                          ;
	CHAR                sBcastMsg [ BCAST_MSG_LEN]                                       ;
} ;
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_HDR_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_TRAILER_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_DATA_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
	struct          NNF_HEADER pInnerHeader                                         ;
	CHAR            sData [LDB_UPDATE_PACKET_LEN]                            ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_MSG_DOWNLOAD_START_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
};
#pragma pack()

#pragma pack(2)
struct                  NNF_MSG_DOWNLOAD_DATA_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
	struct          NNF_HEADER pInnerHeader                                         ;
	CHAR            sData [MSG_AREA_EQ_DLD_DATA_LEN]                 ;
};
#pragma pack()

#pragma pack(2)
struct                  NNF_MSG_DOWNLOAD_END_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
};
#pragma pack()

#pragma pack(2)
struct INVITATION_PACKET
{
	struct          TAP_WRAPPER tWrapper  ; 
	struct      NNF_HEADER  pHeader   ;
	SHORT       invitation_count          ;
};
#pragma pack()

#pragma pack(2)
struct Download_Data
{
	LONG32  Stream_Id ;
	LONG32  Stream_Flag ; /**** Flag 1 for ON , 0 for OFF ********/
	ULONG32 TimeStamp1;
	ULONG32 TimeStamp2;
}Msg_Dow_Data[MAX_NO_STREAMS] ;
#pragma pack()

#pragma pack(2)
struct  NNF_TRADE_CONF_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
	DOUBLE64        fTradedOrdNumber                                                         ;
	CHAR            sBrokerCode [BROKER_CODE_LENGTH]                            ;
	CHAR            cReserved                                                                        ;
	/*      INT16           TraderId                                                                        ;*/
	LONG32      	iTraderId                                    ;/** Userid related changes **/
	CHAR            sAccountNumber [ACCOUNT_CODE_LEN]                        ;
	INT16           iBuyOrSell                                                                       ;
	LONG32          iOriginalQty                                                                     ;
	LONG32          iDiscQty                                                                         ;
	LONG32          iQtyRemaining                                                            ;
	LONG32          iDiscQtyRemaining                                                        ;
	LONG32          iPrice                                                                           ;
	struct          NNF_ORDER_TERMS pOrderTerms                                      ;
	LONG32          iGoodTillDate                                                            ;
	LONG32          iTradeNumber                                                                     ;
	LONG32          iQtyTraded                                                                       ;
	LONG32          iTradePrice                                                                      ;
	LONG32          iQtyFilledToday                                                          ;
	CHAR            sActivityType [ACTIVITY_TYPE_LEN]                        ;
	LONG32          iTradeTime                                                                       ;
	DOUBLE64        fCounterOrdNum                                                           ;
	CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                          ;
	struct          NNF_SEC_INFO                    pSecInfo                         ;
	CHAR            cReserved1                                                                       ;
	INT16           iBookType                                                                        ;
	LONG32          iNewQty                                                                          ;
	SHORT		iProCli										;
	CHAR		sPanId	[NNF_PAN_NUM_LEN]						;
	LONG32		iAlgoNo									;
	SHORT		iAlgoCategory								;
	LONG64		iLastActRefId								;
	CHAR		sReserved	[52]					;
};
#pragma pack()





#pragma pack(2)
struct  ORDER
{
	struct      INT_RESP_HEADER     IntRespHeader           ;
	CHAR        cParticipantType                         ;
	CHAR        sCPBrokerCode [BROKER_CODE_LEN]          ;
	CHAR        cSecSuspInd                              ;
	DOUBLE64    fOrderNum                                ;
	CHAR        sAccCode[CLIENT_ID_LEN]                  ;
	INT16       iBookType                                ;
	INT16       iBuyOrSell                               ;
	LONG32      iDiscQty                                 ;
	LONG32      iDiscQtyRemaining                        ;
	LONG32      iTotalQtyRemaining                       ;
	LONG32      iTotalQty                                ;
	LONG32      iQtyFilledToday                          ;
	LONG32      iMinFillQty                              ;
	DOUBLE64     fPrice                                  ;
	DOUBLE64     fTriggerPrice                           ;
	LONG32      iGoodTillDate                            ;
	LONG32      iEntryTime                               ;
	LONG32      iLastModifiedTime                        ;
	struct      ORDER_TERMS pOrderTerms                  ;
	CHAR        sBrokerCode[BROKER_CODE_LEN]             ;
	CHAR        sRemrks[OE_REMARKS_LEN]                  ;
	CHAR        sSettlor[SETTLOR_LEN]                    ;
	INT16       iProCli                                  ;
	INT16       iSettlementDays                          ;
	SHORT       iReasonCode                              ;
	CHAR        sEntityId[ENTITY_ID_LEN]                 ;
	DOUBLE64    fExchOrderNum                            ;
	INT16       iOrdSerialNo                             ;
	CHAR        sSecurityId[SECURITY_ID_LEN]             ;
	CHAR        sClientId[CLIENT_ID_LEN]                 ;
	CHAR        cCoverUncoverFlg                         ;
	CHAR        cOpenCloseFlg                            ;
	CHAR        cSourceFlag                              ;
	CHAR        sBseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	CHAR        cD2C1Flag                                                                ;
	CHAR        cRetailFIFlag                                                    ;
	DOUBLE64        fInternalRefId                                                   ;
	CHAR            sReserved[ 4 ]                                                   ;
	DOUBLE64        fBasketOrderNo                                                   ;
	CHAR            cOrderCheck                                                              ;
	CHAR        cProductId                                                           ;
	CHAR        cOrderSessionType                                            ;
	CHAR        sReplyText [ REPLY_TEXT_LEN ]                        ;
	CHAR        cSecSeriesInd                                                ;
	LONG32          iAuctionNum ;
	CHAR            cHandlInst ;
	SHORT           iMktProt ;
	SHORT           iCaClientType;
	SHORT           iSettType;
};
#pragma pack()

#pragma pack(2)
struct  MS_EXCH_MSG_TO_TRADER_RESP
{
	struct          INT_RESP_HEADER     IntRespHeader  ;
	LONG32          iTraderId                           ;
	CHAR            sActionCode[ACTION_CODE_LEN]        ;
	SHORT           cBcastMsgLength                     ;
	CHAR            sBcastMsg [ BCAST_MSG_LEN]          ;
} ;
#pragma pack()


#pragma pack(2)
struct          NNF_TRADE
{
	struct          NNF_HEADER                              pHeader                         ;
	struct          NNF_SEC_INFO                    pSecInfo                         ;
	LONG32          iTradeNumber                                                                     ;
	LONG32          iTradeQty                                                                        ;
	LONG32          iTradePrice                                                                      ;
	INT16           iMarketType                                                                      ;
	LONG32          iNewTradeQty                                                                     ;
	CHAR        	sBuyParticipantCode[PARTICIPANT_ID_LEN]              ;
	CHAR        	sSellParticipantCode[PARTICIPANT_ID_LEN]             ;
	CHAR            sBuyBrokerCode[BROKER_CODE_LEN]                          ;
	CHAR            sSellBrokerCode[BROKER_CODE_LEN]                         ;
	/*      INT16           TraderID                                                                        ;*/
	LONG32      	iTraderID                                    ;/** Userid related changes **/
	INT16           iRequestedByTraderID                                                     ;
};
#pragma pack()

#pragma pack(2)
struct      TRADE
{
	struct      INT_RESP_HEADER     IntRespHeader      ;
	LONG32      iTradeNumber                            ;
	LONG32      iTradeQty                               ;
	DOUBLE64    fTradePrice                             ;
	SHORT       iMarketType                             ;
	SHORT       iBookType                               ;
	LONG32      iNewTradeQty                            ;
	CHAR        cBuySellInd                             ;
	CHAR        cCoverUncoverFlg                        ;
	CHAR        cOpenCloseFlg                           ;
	CHAR        cGiveUpFlg                              ;
	CHAR        sParticipantCode[PARTICIPANT_ID_LEN]  ;
	CHAR        sCBrokerCode[BROKER_CODE_LEN]           ;
	LONG32      iTraderID                               ;
	LONG32      iRequestedByTraderID                    ;
	DOUBLE64    fOrderNumber                            ;
	INT16       iOrderSerialNumber                      ;
	INT16       iTradeSerialNumber                      ;
	CHAR        sClientId[CLIENT_ID_LEN]                ;
	CHAR        sEntityId[ENTITY_ID_LEN]                ;
	CHAR        sSettler [SETTLOR_LEN]                  ;
	CHAR        sSecurityId[SECURITY_ID_LEN]            ;
	CHAR        cSourceFlag                             ;
	CHAR        cD2C1Flag                                                                ;
	CHAR        cRetailFIFlag                                                    ;
	DOUBLE64    fInternalRefId                                                   ;
	DOUBLE64    fBasketOrdNo                                     ;
	CHAR        sReserved[ 4 ]                                                   ;
	CHAR        cProductId                                                               ;
	CHAR        cOrderSessionType                                                ;
	CHAR        cHandlInst ;

};
#pragma pack()
#pragma pack(2)
struct  MS_TRADE_CONF_RESP
{
	struct          INT_RESP_HEADER     IntRespHeader;
	DOUBLE64        fTradedOrdNumber                               ;
	LONG32          iTradeNumber                                   ;
	CHAR            sAccountNumber [CLIENT_ID_LEN]                     ;
	INT16           iBuyOrSell                                     ;
	CHAR            cD2C1Flag                                          ;
	CHAR            cRetailFIFlag                                      ;
	LONG32          iOriginalQty                                   ;
	LONG32          iDiscQty                                       ;
	LONG32          iQtyTraded                                     ;
	LONG32          iQtyRemaining                                  ;
	LONG32          iDiscQtyRemaining                              ;
	LONG32          iQtyFilledToday                                ;
	DOUBLE64        fOrderPrice                                    ;
	DOUBLE64        fTradePrice                                    ;
	struct          ORDER_TERMS pOrderTerms                        ;
	LONG32          iGoodTillDate                                  ;
	CHAR            sActivityType [ACTIVITY_TYPE_LEN]              ;
	LONG32          iTradeTime                                     ;
	DOUBLE64        fCounterOrdNum                                 ;
	CHAR            sCPBrokerCode [BROKER_CODE_LEN]                ;
	INT16           iBookType                                      ;
	INT16           iNewQty                                        ;
	DOUBLE64        fOrderNumber                                   ;
	INT16           iOrderSerialNumber                             ;
	INT16           iTradeSerialNumber                             ;
	CHAR            sClientId[CLIENT_ID_LEN]                       ;
	CHAR            sEntityId[ENTITY_ID_LEN]                       ;
	CHAR            sMktType [MARKET_LEN]                          ;
	CHAR            Settler [SETTLOR_LEN]                         ;
	CHAR            sSecurityId[SECURITY_ID_LEN]                   ;
	LONG32          iUserId                                        ;
	CHAR            cSourceFlag                                                                                ;
	CHAR            cOpenClose                                                                                 ;
	CHAR            cOldOpenClose                                                                      ;
	CHAR            cCoverUncover                                                                      ;
	CHAR            cOldCoverUncover                                                                   ;
	CHAR            cGiveUpFlag                                                                                ;
	CHAR            cPreOpenFlag                       ;
	CHAR            cBseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	DOUBLE64        fInternalRefId                   ;
	DOUBLE64        fBasketOrdNo;
	CHAR            sReserved[ 4 ];
	CHAR            cProductId;
	CHAR            cOrderSessionType;
	CHAR            cHandlInst ;
	SHORT           iSettType;
};
#pragma pack()

#pragma pack(2)
struct  NNF_INDEX_ORDER_ENTRY
{
	struct      NNF_HEADER pHeader                          ;
	INT16           iBranchId                                                                        ;
	INT16           iExcgUserId                                                                      ;
	LONG32          iLastModifiedTime                                                        ;
	INT16           iReasonCode                                                                      ;
	INT16           iIndustryCode                                                            ;
	INT16           iSectorCode                                                                      ;
	INT16           iSubSectorCode                                                           ;
	CHAR            sIndexName       [ INDEX_NAME_LEN]                              ;
	CHAR            sBrokerCode [BROKER_CODE_LEN]                            ;
	INT16           iBuyOrSell                                                                       ;
	DOUBLE64        fLimitPrice                                                                      ;
	struct          NNF_ORDER_TERMS pOrderTerms                                      ;
	INT16           iProCli                                                                          ;
	CHAR            sAccountNumber [ACCOUNT_CODE_LEN]                        ;
	CHAR            sParticipantId [ PARTICIPANT_ID_LEN      ]               ;
	CHAR            sRemarks[OE_REMARKS_LEN]                                         ;
	CHAR            cReserved                                                                       ;
	DOUBLE64        fReserved                                                                       ;
	DOUBLE64    	fUserInfo  ;
};
#pragma pack()

typedef struct {
	ULONG32 state[4];                                   /* state (ABCD) */
	ULONG32 count[2];        /* number of bits, modulo 2^64 (lsb first) */
	unsigned char buffer[64];                         /* input buffer */
} MD5_CTX;
void MD5Init PROTO_LIST ((MD5_CTX *));
void MD5Update PROTO_LIST ((MD5_CTX *, unsigned char *, unsigned int));
void MD5Final PROTO_LIST ((unsigned char [16], MD5_CTX *));

#pragma pack(2)
struct SEQNO_REMARKS
{
	char    Remarks[15]                 ;
	char    SeqNO[9]                       ;
};
#pragma pack()

#pragma pack(2)
struct 	INTERACT_EXCH_MSG
{
	struct      NNF_HEADER 		pHeader     ;
	LONG32		iTraderID	;
	CHAR		sActionCode[ACTION_CODE_LEN];
	CHAR		cResrved	;	
	SHORT           iMsgLenght	;
	CHAR		sExchMsg[EXCH_MSG_LEN];	           	
};
#pragma pack()


#pragma pack(2)
struct NNF_GR_REQUEST
{
	struct      NNF_HEADER          pHeader ;
	INT16		iBoxID			;
	CHAR		sBrokerID	[BROKER_CODE_LENGTH];
	CHAR		cFiller1		;

};
#pragma pack()

#pragma pack(2)
struct NNF_GR_RESP
{
	struct      NNF_HEADER          pHeader ;
	INT16		iBoxID			;
	CHAR		sBrokerID	[BROKER_CODE_LENGTH];
	CHAR		cFiller1		;
	CHAR		sHostIP		[NNF_HOST_IP_LEN];
	LONG32		iHostPort	;
	CHAR		sSessionKey	[NNF_SESSION_KEY_LEN];

};
#pragma pack()


#pragma pack(2)
struct NNF_BOX_SIGNIN_REQUEST
{
	struct      NNF_HEADER          pHeader ;
	INT16		iBoxID			;
	CHAR		sBrokerID	[BROKER_CODE_LENGTH];
	CHAR		sFiller1	[5]	;
	CHAR		sSessionKey	[NNF_SESSION_KEY_LEN];
};
#pragma pack()

#pragma pack(2)
struct NNF_BOX_SIGNIN_RESPONSE
{
        struct      NNF_HEADER          pHeader ;
        INT16           iBoxID                  ;
        CHAR            sFiller1        [10]     ;
};
#pragma pack()

#pragma pack(2)
struct                  NNF_ORDER_ENTRY_REQ_TM
{
        //struct          NNF_HEADER      pHeader                         ;
        INT16		iTransCode				;
	LONG32		iTradeID				;	
        struct          NNF_SEC_INFO    pSecInfo                ;
        CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
        INT16           iBookType                                        ;
        INT16           iBuyOrSell                                       ;
        LONG32          iDiscQty                                         ;
        LONG32          iTotalQty                                        ;
        LONG32          iPrice                                           ;
        LONG32          iGoodTillDate                                    ;
        struct          NNF_ORDER_TERMS pOrderTerms                      ;
        INT16           iBranchId                                        ;
        LONG32          iExcgUserId                                     ;
        CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
	CHAR		cSecSuspInd					;
        CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
        INT16           iProCli                                          ;
        DOUBLE64        fUserInfo                                       ;
	//LONG32		iTransactionID					;
	struct          NNF_FILLER_TERMS                pExchRsrvdFlds  ;	
	CHAR            sPanId  [NNF_PAN_NUM_LEN]                               ;
        LONG32          iAlgoId                                         ;
	INT16		iReservFiller					;
	CHAR		sReservd4[32]					;		

/**
        CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                  ;
        CHAR            cSecSuspInd                                      ;
        DOUBLE64        fOrderNum                                        ;




        LONG32          iDiscQtyRemaining                                ;
        LONG32          iTotalQtyRemaining                               ;

        LONG32          iQtyFilledToday                                  ;

        LONG32          iTriggerPrice                                    ;

        LONG32          iEntryTime                                       ;
        LONG32          iMinFillQty                                      ;
        LONG32          iLastModifiedTime                                ;




        CHAR            sRemarks[OE_REMARKS_LEN]                         ;


        INT16           iSettlementDays                                  ;

        DOUBLE64        fReservedPrgTrd                                 ;
        struct          NNF_FILLER_TERMS                pExchRsrvdFlds  ;


        SHORT           iAlogCategory                                   ;
        CHAR            sReserved  [NNF_RESERVED_LEN]                   ;
***/
};
#pragma pack()

#pragma pack(2)
struct                  NNF_ORD_MOD_CAN_REQ_TM
{
        INT16		iTransCode				;
	LONG32		iLogTime				;
	LONG32      	iUserId                                  	;
	INT16		iErrorCode					;
	DOUBLE64	fTimeStamp1					;
	CHAR		cTimeStamp2					;
	CHAR            cModCanBy					;
	INT16           iReasonCode                              	;
	struct          NNF_SEC_INFO    pSecInfo		;
	DOUBLE64        fOrderNum                                        ;
	CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
	INT16           iBookType                                        ;
	INT16           iBuyOrSell                                       ;
	LONG32          iDiscQty                                         ;
	LONG32          iDiscQtyRemaining                                ;
	LONG32          iTotalQtyRemaining                               ;
	LONG32          iTotalQty                                        ;
	LONG32          iQtyFilledToday                                  ;
	LONG32          iPrice                                           ;
	LONG32          iEntryTime                                       ;
	LONG32          iLastModifiedTime                                ;
	struct          NNF_ORDER_TERMS pOrderTerms                      ;
	INT16           iBranchId                                        ;
	LONG32      	iExcgUserId                                  	;
	CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
	CHAR            cSecSuspInd                                      ;
	CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
	INT16           iProCli                                          ;
	INT16           iSettlementDays                                  ;
	DOUBLE64    	fUserInfo                                   	;
	//LONG32		iTransactionID					;
	struct          NNF_FILLER_TERMS                pExchRsrvdFlds  ;
	CHAR		sPanId	[NNF_PAN_NUM_LEN]				;
	LONG32		iAlgoId						;
	INT16		iReservdFiller1					;
	LONG64		iLastActiRefrnc					;
	CHAR		sReserved1	[24]				;
/**
	CHAR            cParticipantType                         	;
	CHAR            cReserved                               		;
	INT16           iCompititorPeriod                                ;
	INT16           iSolicitorPeriod                                 ;

	CHAR            cReserved1                               	;

	CHAR            sStartAlpha [ALPHA_SPLIT_LEN]            	;
	CHAR            sEndAlpha [ALPHA_SPLIT_LEN]              	;

	INT16           iAuctionNum                                      ;
	CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                  ;
	LONG32          iTriggerPrice                                    ;
	LONG32          iGoodTillDate                                    ;

	LONG32          iMinFillQty                                      ;
	CHAR            sRemarks[OE_REMARKS_LEN]                         ;
	DOUBLE64    	fReservedPrgTrd                                 ;
	struct      	NNF_FILLER_TERMS 		pExchRsrvdFlds  ;
	//CHAR        	sSeq[PRG_TRD_RESERVED_FIELD_LEN] 		; 
	//LONG32		iMktType					;
	SHORT		iAlogCategory					;
	CHAR		sReserved  [NNF_RESERVED_LEN]			;
***/
};
#pragma pack()


#pragma pack(2)
struct                  NNF_ORD_RESPONSE_TM
{
	INT16		iTransCode					;
	LONG32		iLogTime					;
	LONG32		iUserID						;
	INT16		iErrorCode					;
	DOUBLE64	fTimeStamp1					;
	CHAR		cTimeStamp2					;
	CHAR            cModCanBy					;
	INT16           iReasonCode                              	;
	struct          NNF_SEC_INFO    pSecInfo		;
	DOUBLE64        fOrderNum                                        ;
	CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
	INT16           iBookType                                        ;
	INT16           iBuyOrSell                                       ;
	LONG32          iDiscQty                                         ;
	LONG32          iDiscQtyRemaining                                ;
	LONG32          iTotalQtyRemaining                               ;
	LONG32          iTotalQty                                        ;
	LONG32          iQtyFilledToday                                  ;
	LONG32          iPrice                                           ;
	LONG32          iEntryTime                                       ;
	LONG32          iLastModifiedTime                                ;
	struct          NNF_ORDER_TERMS pOrderTerms                      ;
	INT16           iBranchId                                        ;
	LONG32      	iExcgUserId                                  	;
	CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
	CHAR            cSecSuspInd                                      ;
	CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
	INT16           iProCli                                          ;
	INT16           iSettlementDays                                  ;
	DOUBLE64    	fUserInfo                                   	;
	//LONG32		iTransactionID					;
	struct          NNF_FILLER_TERMS                pExchRsrvdFlds  ;
	LONG64		iTimeStamp					;
	CHAR		sPanId	[NNF_PAN_NUM_LEN]				;
	LONG32		iAlgoId						;
	INT16		iReservedFill					;
	LONG64		iLastActiRef					;
	CHAR		sReserved1[52]					;
	
/***			


	CHAR            cParticipantType                         	;
	CHAR            cReserved                               		;
	INT16           iCompititorPeriod                                ;
	INT16           iSolicitorPeriod                                 ;

	CHAR            cReserved1                               	;

	CHAR            sStartAlpha [ALPHA_SPLIT_LEN]            	;
	CHAR            sEndAlpha [ALPHA_SPLIT_LEN]              	;

	INT16           iAuctionNum                                      ;
	CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                  ;



	LONG32          iTriggerPrice                                    ;
	LONG32          iGoodTillDate                                    ;

	LONG32          iMinFillQty                                      ;


	CHAR            sRemarks[OE_REMARKS_LEN]                         ;




	DOUBLE64    	fReservedPrgTrd                                 ;
	struct      	NNF_FILLER_TERMS 		pExchRsrvdFlds  ;
	//CHAR        	sSeq[PRG_TRD_RESERVED_FIELD_LEN] 		; 
	//LONG32		iMktType					;

	SHORT		iAlogCategory					;
	CHAR		sReserved  [NNF_RESERVED_LEN]			;
***/
};
#pragma pack()


#pragma pack(2)
struct  NNF_TRADE_RESP_TM
{
	INT16		iTransCode						;
	LONG32		iLogTime						;
	LONG32		iUserID							;	
	LONG64		iTimeStamp						;
	DOUBLE64	fTimeStamp1						;
        DOUBLE64        fTradedOrdNumber                                        ;
	CHAR		cTimeStamp2						;
        CHAR            sBrokerCode [BROKER_CODE_LENGTH]                            ;
        LONG32          iTradeNumber                                                                     ;
        INT16           iBuyOrSell                                                                       ;
        CHAR            sAccountNumber [ACCOUNT_CODE_LEN]                        ;
        LONG32          iOriginalQty                                                                     ;
        LONG32          iDiscQty                                                                         ;
        LONG32          iQtyRemaining                                                            ;
        LONG32          iDiscQtyRemaining                                                        ;
        LONG32          iPrice                                                                           ;
        struct          NNF_ORDER_TERMS pOrderTerms                                      ;
        LONG32          iFillNumber                                    ;/** Userid related changes **/
        LONG32          iQtyTraded                                                                       ;
        LONG32          iTradePrice                                                                      ;
        LONG32          iQtyFilledToday                                                          ;
        CHAR            sActivityType [ACTIVITY_TYPE_LEN]                        ;
        LONG32          iTradeTime                                                                       ;
        struct          NNF_SEC_INFO                    pSecInfo                         ;
        INT16           iBookType                                                                        ;
        SHORT           iProCli                                                                         ;
        CHAR            sPanId  [NNF_PAN_NUM_LEN]                                               ;
        LONG32          iAlgoId                                                                 ;
	INT16		iReservedFiller								;
	LONG64		iLastActiRef								;
	CHAR		sReserved1[52]								;
/**	
        CHAR            cReserved                                                                        ;
        LONG32          iGoodTillDate                                                            ;
        CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                          ;
        CHAR            cReserved1                                                                       ;
        LONG32          iNewQty                                                                          ;
        SHORT           iAlgoCategory                                                           ;
        CHAR            sReserved       [NNF_RESERVED_LEN]                                      ;
***/
	
};
#pragma pack()


#pragma pack(2)
struct	NNF_BOX_SIGN_OFF_TM
{
	struct  NNF_HEADER pHeader;
	SHORT	iBoxId		;
};
#pragma pack()


typedef struct  NNF_INDEX_ORDER_ENTRY           	NNF_INDEX_ORDER_ENTRY_REQUESTED_RESP    ;
typedef struct  TRADE                      		MS_TRADE_CAN_REQUESTED_BY_CP_RESP;
typedef struct	NNF_SYS_INFO_REQ			NNF_SYS_INFO_REQ;
typedef struct  NNF_SIGNON_REQ 				NNF_SIGNON_REQ;
typedef struct  NNF_EXCH_MSG_TO_TRADER_RESP     	NNF_EXCH_MSG_TO_TRADER_RESP;
typedef struct  NNF_ORDER_ENTRY                         NNF_ORDER_ENTRY_REQ;
typedef	struct	NNF_UPDATE_LDB_HDR_RESP			NNF_UPDATE_LDB_HDR_RESP;
typedef	struct	NNF_UPDATE_LDB_TRAILER_RESP		NNF_UPDATE_LDB_TRAILER_RESP;
typedef struct	NNF_UPDATE_LDB_DATA_RESP		NNF_UPDATE_LDB_DATA_RESP;
typedef struct	NNF_MSG_DOWNLOAD_START_RESP		NNF_MSG_DOWNLOAD_START_RESP;
typedef struct 	NNF_MSG_DOWNLOAD_DATA_RESP		NNF_MSG_DOWNLOAD_DATA_RESP;
typedef struct	NNF_MSG_DOWNLOAD_END_RESP		NNF_MSG_DOWNLOAD_END_RESP;
typedef struct	NNF_HEADER				NNF_HEADER;
typedef struct  NNF_ORDER_ENTRY                         NNF_ORDER_ENTRY_CONF_RESP;
typedef	struct	ORDER					MS_ORDER_ENTRY_CONF_RESP;
typedef struct	MS_EXCH_MSG_TO_TRADER_RESP		MS_EXCH_MSG_TO_TRADER_RESP;
typedef struct  NNF_TRADE                               NNF_TRADE_CAN_REQUESTED_BY_CP_RESP;
typedef	struct	NNF_TRADE_CONF_RESP			NNF_TRADE_CONF_RESP;
typedef	struct	MS_TRADE_CONF_RESP			MS_TRADE_CONF_RESP;
typedef struct  NNF_TRADE_CONF_RESP                     NNF_STOP_LOSS_ORDER_TRIGGER_RESP;
typedef struct  ORDER                      		MS_STOP_LOSS_ORDER_TRIGGER;
typedef struct  INT_REQUEST_HEADER          		INT_REQUEST_HEADER;


extern BOOL fMAP_ORDER                                                 (CHAR *, CHAR *);
extern BOOL UpdateSignOnResponse(struct NNF_SIGNON_RESP *);
//extern BOOL UpdateSysInfoResp(NNF_SYS_INFO_RESP *);
extern BOOL sendsignon(char *sendnnf, int groupid);
extern BOOL PLogOnR( NNF_SIGNON_REQ *, int );
extern BOOL sendsysinfo(char * ) ;
extern BOOL recvsysinfo( char *);
extern BOOL fCMS_OE_REQ                                                 (CHAR *, CHAR *,LONG32);
extern BOOL fCMS_TRADE_CAN_REQ                                  (CHAR *, CHAR *,LONG32 );
extern BOOL fCMS_EQU_AUCTION_ENQ                            (CHAR *, CHAR *, LONG32);
extern BOOL fCMS_EQU_ODDLOT_ENQ                                     (CHAR *, CHAR *, LONG32 );
extern BOOL fCMS_STOP_LOSS_ORDER_TRIGGER            (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CONF_MAP_RESP                (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CAN_MAP_RESP         (CHAR *, CHAR *);
extern BOOL fCMS_EXCH_MSG_TO_TRADER_RESP            (CHAR *, CHAR *);
extern BOOL fCMS_UPDATE_LDB_TRAILER_RESP            (CHAR *, CHAR *);


#endif


