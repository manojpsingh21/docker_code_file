/********************************* FILE AFTER PRECESION CHANGES ***********************/
/*--------------------------------------------------------------------------------------

Module           : NETWORK

Program name     : EquNseDBUpdMulti.h

Date             : 15-03-2005

Author           : T C S

----------------------------------------------------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>
#include <my_global.h>
#include <mysql.h>
//#include "Defination.h"
#include "IPCS.h"
#include "EQNSEBcastStruct.h"
#include "IntTCodes.h"


#define MAX_NO_OF_TRANSCODE_RECV 	  	 19
#define MAX_NO_OF_TRANSCODE      	  	 25
#define TRANSCODE_NOT_DATA       	  	 2
#define LOCAL_MAX_PACKET_SIZE    	  	 512
#define TERMS_LEN                	  	 3

#define MAX_NO_OF_TRANSCODE_RECV		 23
#define MAX_NO_OF_TRANSCODE  			 25
#define TRANSCODE_NOT_DATA 			 2
#define LOCAL_MAX_PACKET_SIZE 			 1050
/*#define ORACLE_CONNECT_STR_LEN   30*/

/*#define MAX_NO_OF_THREADS 4*/
//#define MAX_NO_OF_THREADS			 20 

#define MAX_MBP_REC_UPD MAX_INT_MBP_RECS*(MBP_NO_OF_RECS/2)
#define MAX_MKT_REC_UPD MKTWATCH_NO_OF_RECS*NOOF_MKTS_FOR_MW


LONG32  NseRecordCount;

/*struct THREAD_PARAMS
  {
  LONG32 thread_id;
  };*/


typedef BOOL (*P_TO_FUN)(char * x,MYSQL *y);

struct TRANS_FUN_PAIR
{
	INT16  Transcode;
	P_TO_FUN  pToFun;
};


#pragma pack(2)
struct TESTTYPE
{
	struct NNF_HEADER sHeader;
	CHAR MsgType;
};
#pragma pack()

BOOL  fBcastUpdt(MYSQL *EM);

LONG32 MapAuctionStatus(CHAR cAuctionStatus);

BOOL dTC_GENERAL_MSG_BCAST                  (char *NNFData,MYSQL *EM);
BOOL dTC_MBO_MBP_UPDATE_BCAST               (char *NNFData,MYSQL *EM);
BOOL dTC_MULTIPLE_INDEX_BCAST               (char *NNFData,MYSQL *EM);
BOOL dTC_PARTICIPANT_INFO_RESP              (char *NNFData,MYSQL *EM);
BOOL dTC_MARKET_STATUS_MSG_BCAST            (char *NNFData,MYSQL *EM);
BOOL dTC_SYSTEM_INFORMATION_BCAST           (char *NNFData,MYSQL *EM);
BOOL dTC_STOCK_STATUS_CHANGE_BCAST          (char *NNFData,MYSQL *EM);
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST         (char *NNFData,MYSQL *EM);
BOOL dTC_MKTWATCH_ROUND_ROBIN_BCAST         (char *NNFData,MYSQL *EM);
BOOL dTC_INDUSTRY_INDEX_UPDATE_BCAST        (char *NNFData,MYSQL *EM);
BOOL dTC_SECURITY_OPEN_MSG_BCAST            (char *NNFData,MYSQL *EM);
BOOL dTC_BROKER_TURNOVER_STATUS_BCAST       (char *NNFData,MYSQL *EM);
BOOL dTC_SYSTEM_INFORMATION_BCAST           (char *NNFData,MYSQL *EM);
BOOL dTC_TICKER_MARKET_INDEX_BCAST          (char *NNFData,MYSQL *EM);
BOOL dTC_BCAST_CKT_ALIVE                    (char *NNFData,MYSQL *EM);
BOOL dTC_MKT_STATS_RPT_BCAST                (char *NNFData,MYSQL *EM);
BOOL dTC_INSTRUMENT_UPDATE_BCAST            (char *NNFData,MYSQL *EM);
BOOL dTC_SPREAD_MBP_BCAST                   (char *NNFData,MYSQL *EM);
BOOL dTC_AUCTION_DATA_BCAST                 (char *NNFData,MYSQL *EM);
BOOL dTC_AUCTION_STATUS_CHANGE_BCAST        (char *NNFData,MYSQL *EM);
BOOL dTC_MARKET_OPEN_MSG_BCAST              (char *NNFData,MYSQL *EM);
BOOL dTC_MARKET_CLOSE_MSG_BCAST             (char *NNFData,MYSQL *EM);
BOOL dTC_PREOPEN_SHUTDOWN_BCAST             (char *NNFData,MYSQL *EM);
BOOL dTC_PRE_OPEN_ENDED_MSG_BCAST           (char *NNFData,MYSQL *EM);
BOOL dTC_ODD_MBO_UPDATE_BCAST               (char *NNFData,MYSQL *EM);
BOOL dTC_MBP_BCAST                          (char *NNFData,MYSQL *EM);
BOOL dTC_POSTCLOSE_BCAST		    (char *NNFData,MYSQL *EM);							

/* -- -- -- -- :  TNDTC Changes  : -- -- -- -- */

BOOL dTC_MBO_MBP_UPDATE_BCAST_TNDTC         (char *NNFData,MYSQL *EM);
BOOL dTC_MKTWATCH_ROUND_ROBIN_BCAST_TNDTC   (char *NNFData,MYSQL *EM);
BOOL dTC_MBP_BCAST_TNDTC                    (char *NNFData,MYSQL *EM);
BOOL dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC    (char *NNFData,MYSQL *EM);
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC   (char *NNFData,MYSQL *EM);

LONG32 rcvQ;
LONG32 SndEmmQ;
LONG32 SndAtBcastQ;

