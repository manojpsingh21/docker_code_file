//#include "IPCS.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <errno.h>
#include <pthread.h>
#define     MAX_NO_STATIC_WRITE_THREADS     100 /** Changed from 25 **/
#define     MAX_NO_STATIC_READ_THREADS      100
#define     MAX_NO_DYNAMIC_READ_THREADS     100 /** Changed from 25 **/
#define     MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS       10   /* Threads to write Exch Resp to ITS */
#define     MAX_NO_OF_SOCKETS               1000 
//#define     MAX_NO_STATIC_WRITE_THREADS     atoi(getenv("WAP_MAX_WTRHEAD")) /** Changed from 25 **/
//#define     MAX_NO_STATIC_READ_THREADS      atoi(getenv("WAP_MAX_RTRHEAD"))
//#define     MAX_NO_DYNAMIC_READ_THREADS     atoi(getenv("WAP_MAX_DYN_RTRHEAD")) /** Changed from 25 **/
//#define     MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS       1   /* Threads to write Exch Resp to ITS */
//#define     MAX_NO_OF_SOCKETS               atoi(getenv("WAP_MAX_SOCKETS"))
#define     MAX_PACKET_SIZE                2048 
#define     _VALID_USER_                    TRUE
#define     _INVALID_USER_                  FALSE

#define     UNUSED                         0 
#define     USED                            1

#define     SOCKET_ID                       0
#define     USER_ID                         1
#define     TC_SLOT_ERROR_RSP               -9999
#define     MKT_ORDER_PRICE_CONFIRMATION    2012
#define     ORDER_CONFIRMATION              2073
#define     INDEX_ORDER_CONFIRMATION        2101
#define     INDEX_ORDER_REJECTION        	2104
#define     TRADE_CONFIRMATION              2222
#define     TRADE_MOD_CONFIRMATION          2287
#define     TRADE_MOD_REJECTION          	2288
#define     TRADE_CAN_CONFIRMATION          2282
#define     TRADE_CAN_REJECTION          	2286
#define     TRADE_MOD_CAN_ERROR          	2283
#define     ORDER_MOD_CONFIRMATION          2074
#define     ORDER_CAN_CONFIRMATION          2075
#define     ORDER_REJECTION              	2231
#define     ORDER_FREEZE_RESP              	2170
#define     ORDER_CANC_ERROR_RESP          	2072
#define     STOP_LOSS_ORDER_TRIG_RESP      	2212

struct UserId_Lookup_Table
{
	ULONG64              UserId;
	//LONG32              UserId;/from int to unsigned long long int/
	CHAR                Exch[EXCHANGE_LEN];
	CHAR                Segment;
	LONG32              SocketId;
	struct              UserId_Lookup_Table     *Next;
}*IndexNode=NULL;
typedef struct UserId_Lookup_Table  UserId_Lookup_Table;

struct Thread_Status_Table
{
	pthread_t           ThreadId;
	BOOL                Status;
};

struct Socket_LookUp_Table
{
	LONG32              SocketId;
	BOOL                UserStatus;
	pthread_mutex_t     Mutex;
};

pthread_mutex_t             ActiveSocketLock;
pthread_mutex_t             SocketTableLock;
pthread_mutex_t             UserIdTableLock;
pthread_mutex_t             SocketCommunicationPipeLock;
pthread_mutex_t             OracleAccess;
pthread_mutex_t             TotalThreadsInProgressLock;
pthread_mutex_t             DynamicThreadsInProgressCondLock;
pthread_cond_t              DynamicThreadsInProgressCondVar;

pthread_cond_t              MappingLock;
pthread_cond_t              SendTimeLock;
pthread_cond_t              RecvTimeLock;

pthread_attr_t              ThreadAttr;
pthread_once_t              once_control = PTHREAD_ONCE_INIT;
fd_set                      ActiveSocketSet;

LONG32                      ItsToRmsDir;
LONG32                      RelDirToIts;
LONG32                      ItsToQuery;/* Puns */
LONG32                      SocketCommunicationPipe[2];
LONG32                      DummyPipe[2];
LONG32                      NoOfNodes=0;
LONG32                      TotalThreadsInProgress=0;
BOOL                        _SYSTEM_SUSPENDED_=FALSE;
LONG32						MasterPort		=0;
char *ReqDet                            ;
/**/
struct Thread_Status_Table  ThreadTable[MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS];
struct Socket_LookUp_Table  SocketTable[MAX_NO_OF_SOCKETS];

void        Init_Routine                    ();
void        *ReadWriteMainThread            (void *);
void        *ReadWorkerThread               (void *);
void        *DynamicReadWorkerThread        (void *);
void        *ProcessIncomingPacket          (void *);

void        *WriteWorkerThread              ();
void        *WriteExchRespWorkerThread              ();
void        *WriteSecWorkerThread               ();

void        CleanResources                  (LONG32,CHAR);
BOOL        GetIndex_In_Socket_Table        (LONG32);
BOOL        GetSlot_In_Socket_Table         ();
/*void        LockThreadMutex                 (pthread_mutex_t *,CHAR *);
  void        UnLockThreadMutex               (pthread_mutex_t *,CHAR *);*/
BOOL        Send                            (LONG32 ,CHAR *,LONG32 *,SHORT ,LONG32 );
BOOL        Recv                            (LONG32 ,CHAR *,LONG32 *,SHORT ,LONG32 );
void        AddUser                         (UserId_Lookup_Table *,LONG32 ,LONG32 ,CHAR *,CHAR );
/**void        DeleteUser                      (UserId_Lookup_Table *,LONG32 ,CHAR *, CHAR ,SHORT ,LONG32 *);***/

int   Map_Ord_Req(char * ,struct OE_REQUEST           *);
void  Map_T_Req    (char * ,struct T_REQUEST            *);
