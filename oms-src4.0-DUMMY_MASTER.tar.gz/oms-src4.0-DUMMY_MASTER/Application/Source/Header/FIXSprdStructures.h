#ifndef _FIX_STRUCTURE_
#define _FIX_STRUCTURE_

#include  "IPCS.h"
#include <ctype.h>
/*----------------------------------------------------------------------------------------------
  DEFINATIONS FOR FIX STRUCTURE
  ------------------------------------------------------------------------------------------------*/
#define		MAX_NO_OF_TAGS			100
#define         MAX_TAG_SIZE			20
#define		FIX_MAX_STRING_LEN		2836
#define		FIX_MAX_TAGS			512
#define		FIX_TAG_LENGTH			8
#define		BEGIN_STRING_LEN		8+1
#define		MESSAGE_TYPE_LEN		5+1
#define		FIX_DATE_TIME_LEN		25
#define		CSD_ACCT_NUMBER_LEN		15+1
#define		EXEC_INST_LEN			10
#define		SEC_TYPE			3+1
#define		TEXT_LEN			40
#define		ID_SOURCE_LEN			3
#define		DAY				2+1
#define		DATE				8+1
#define		COMPLIANCE_LEN			15
#define		CLEARING_ACCOUNT_LEN		12+1
#define		FIX_BROKER_LEN			5
#define		TERMINAL_INFO_LEN		15
#define		ORDER_ID_LEN			25
#define		MONTH_YEAR			6
#define		MEMBERID_LEN			9+1
#define		SUBSCRIBER_LEN			11+1
#define		MAX_CURRENCY_LEN		4
#define		TRADING_SESS_LEN		20
#define		CLEARING_FIRM_LEN		9+1
#define		IDSOURCE_LEN			2+1
#define		MAX_TEXT_LEN			255
#define		EXEC_ID_LEN			45
#define		BUSS_REJ_LEN			20+1
#define		MSGID_INT_LEN			19+1

#define		SYMBOL_SFX_LEN			2+1

#define 	ENV_VARIABLE_LEN 		30
#define 	TIME_TRUNC_LEN 			17
#define 	TEMP_STRUCT_LEN 		4
#define 	TRADE_NO_LEN			16+1
#define 	INTERFACE_CONN_DOWN             'X'
#define 	INTERFACE_CONN_UP               'U'


/*----------------------------------------------------------------------------------------------
  END DEFINATIONS FOR FIX STRUCTURE
  ------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------------
  DEFINING FIX VALUES
  -----------------------------------------------------------------------------------------------*/
#define CFG_STRUCT_LEN				21
#define DELIMITER                           1
#define FIX_FIELD_DELIMITER                 1
#define FIX_TAG_DELIMITER                   '='
#define FIX_ESCAPE                          '\\'
#define FIX_MESSAGE_DELIMITER                           '\n'

/*----------------------
  TAG 59 - TimeInForce
  -----------------------*/
#define FIX_TIME_IN_FORCE_DAY			'0'
#define FIX_TIME_IN_FORCE_GTC			'1'
#define FIX_TIME_IN_FORCE_ATO			'2'
#define FIX_TIME_IN_FORCE_IOC			'3'
#define FIX_TIME_IN_FORCE_FOK			'4'
#define FIX_TIME_IN_FORCE_GTX			'5'
#define FIX_TIME_IN_FORCE_GTD			'6'

/*----------------------
  TAG 59 -BSE TimeInForce
  -----------------------*/
#define FIX_BSE_TIME_IN_FORCE_SSN                   '0'
#define FIX_BSE_TIME_IN_FORCE_GTC                   '1'
#define FIX_BSE_TIME_IN_FORCE_ATO                   '2'
#define FIX_BSE_TIME_IN_FORCE_IOC                   '3'
#define FIX_BSE_TIME_IN_FORCE_FOK                   '4'
#define FIX_BSE_TIME_IN_FORCE_GTX                   '5'
#define FIX_BSE_TIME_IN_FORCE_GTD                   '6'
#define FIX_BSE_TIME_IN_FORCE_DAY                   '7'

/*----------------------
  TAG 40 - OrderType
  -----------------------*/
#define FIX_ORD_TYPE_MARKET			'1'
#define FIX_ORD_TYPE_LIMIT			'2'
#define FIX_ORD_TYPE_STOPLOSS			'3'
#define FIX_ORD_TYPE_STOPLIMIT			'4'
#define FIX_ORD_TYPE_MARK_TO_LMT		'K'
/*----------------------
  TAG 54 - Side
  -----------------------*/
#define FIX_SIDE_BUY				'1'
#define FIX_SIDE_SELL				'2'

/*----------------------
  TAG 21 - HandelInst
  -----------------------*/
#define FIX_HANDL_INST_AUTO_EXEC		'1'
#define FIX_HANDL_INST_BROKET_INT_EXEC		'2'
#define FIX_HANDL_INST_MANUAL_EXEC		'3'
/*----------------------
  TAG 150 - ExecType
  -----------------------*/
#define FIX_EXEC_TYPE_NEW			'0'
#define FIX_EXEC_TYPE_PARTIAL_FILL		'1'
#define FIX_EXEC_TYPE_FILL			'2'
#define FIX_EXEC_DONE_FOR_DAY			'3'
#define FIX_EXEC_TYPE_CANCELED			'4'
#define FIX_EXEC_TYPE_REPLACE			'5'
#define FIX_EXEC_TYPE_FREEZE			'7'
#define FIX_EXEC_TYPE_REJECTED			'8'
#define FIX_EXEC_TYPE_SUSPENDED			'9'
#define FIX_EXEC_TYPE_EXPIRED			'C'
#define FIX_EXEC_TYPE_RESTATED			'D'
#define FIX_EXEC_TYPE_TRIGGERED			'T'

/*----------------------
  TAG 39 - OrdStatus
  -----------------------*/
#define FIX_ORDER_STATUS_NEW			'0'
#define FIX_ORDER_STATUS_PARTIAL_FILL		'1'
#define FIX_ORDER_STATUS_FILLED			'2'
#define FIX_ORDER_STATUS_DONE_FOR_DAY		'3'
#define FIX_ORDER_STATUS_CANCELED		'4'
#define FIX_ORDER_STATUS_REPLACED		'5'
#define FIX_ORDER_STATUS_FREEZE			'7'
#define FIX_ORDER_STATUS_REJECTED		'8'
#define FIX_ORDER_STATUS_SUSPENDED		'9'
#define FIX_ORDER_STATUS_EXPIRED		'C'

/*----------------------
  TAG 20 - ExecTransType
  -----------------------*/
#define FIX_EXEC_TRANS_TYPE_NEW			'0'
#define FIX_EXEC_TRANS_TYPE_CANCEL		'1'
#define FIX_EXEC_TRANS_TYPE_STATUS		'3'

/*----------------------
  TAG 434 - CxlRejResponseTo 
  -----------------------*/
#define FIX_CXLREJ_TO_CANCEL_REQ		'1'
#define FIX_CXLREJ_TO_REPLACE_REQ		'2'

/*----------------------
  TAG 35 - MsgType
  -----------------------*/
#define FIX_TAG_MSG_TYPE			"35"
#define FIX_MSG_LOGON				"A"
#define FIX_MSG_SESSION_REJECT			"3"
#define FIX_MSG_BUSINESS_REJECT			"j"
#define FIX_MSG_EXECUTION_REPORT		"8"
#define FIX_MSG_BSE_TRADE_CONFRM		"AE"
#define FIX_MSG_ORDER_CANCEL_REJECT		"9"
#define FIX_TRADING_SESSION_STATUS		"h"
#define FIX_SECURITY_DEFINITION_DOWNLOAD	"d"
#define	FIX_ORDER_REQUEST			"D"
#define	FIX_ORDER_CANCELLATION			"F"
#define	FIX_ORDER_MODIFICATION			"G"
#define	FIX_SPREAD_ORDER_REQUEST		"U1"
#define	FIX_SPREAD_ORDER_REPLACE		"U2"


/*----------------------
  TAG 201 - PutOrCall
  -----------------------*/
#define CALL			1
#define PUT			0
/*----------------------
  TAG 206 - OptAttribute
  -----------------------*/
#define AMERICAN		'L'
#define EUROPEAN		'S'

/*----------------------
  TAG 167 - SecurityType
  -----------------------*/
#define OPTION			"OPT"
#define FUTURE			"FUT"

/*----------------------
  TAG 77 - OpenClose 
  -----------------------*/
#define OPEN_FLAG		'O'
#define CLOSE_FLAG		'C'

/*----------------------------------------------------------------------------------------------
  END DEFINING FIX VALUES
  -----------------------------------------------------------------------------------------------*/
typedef struct
{
	CHAR		sDelToTargetComp[ENTITY_ID_LEN];
	CHAR		cMsgType ;
	LONG32		iNoOfTags;
	LONG32		iTagList[MAX_NO_OF_TAGS];
}EXCH_CFG_FILE_STRUCT ;

typedef struct
{
	SHORT		iMsgLength;
	SHORT		iMsgCode;
	INT16		iQMsgType;
}INT_HEADER;

typedef struct
{
	char   inputmsg[FIX_MAX_STRING_LEN+1];
	char   buf[FIX_MAX_STRING_LEN*3/2];
	char   msgType[FIX_TAG_LENGTH+1];
	char*  tags[FIX_MAX_TAGS];
	char*  values[FIX_MAX_TAGS];
	char   headertag[FIX_MAX_TAGS];
	int    numtags;
	int    length;
} FIX_Msg;

typedef struct
{
	CHAR		sBeginString[BEGIN_STRING_LEN];
	LONG32		dMsgSeqNum;                                     /*****  TAG 34 *****/
	CHAR		sMsgType[MESSAGE_TYPE_LEN];                     /***** TAG 35 *****/
	CHAR		sSenderCompID[DATE_TIME_LEN];                   /***** TAG 49 *****/
	CHAR		sTargetCompID[ENTITY_ID_LEN];                   /***** TAG 56 *****/
	CHAR		sSenderSubID[ENTITY_ID_LEN];                    /****** TAG 50 *****/
	CHAR		sTargetSubID[ENTITY_ID_LEN];                    /****** TAG 57 *****/
	CHAR		sSendingTime[FIX_DATE_TIME_LEN];                    /***** TAG 52 ******/
	CHAR		cPossDupFlag;                                   /***** TAG 43 ******/

}FIX_HEADER;

typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;

	CHAR		sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR		sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
	CHAR		cHandlInst;                                 /***** TAG 21 ****/
	CHAR		sExecInst[EXEC_INST_LEN];                   /***** TAG 18 ****/
	DOUBLE64	fMinQty;                                    /***** TAG 110 ***/
	DOUBLE64	fMaxFloor;                                  /***** TAG 111****/
	CHAR		sSymbol[SYMBOL_LEN];                        /***** TAG 55 ****/
	CHAR		sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
	CHAR		sSecurityType[DB_INS_LEN];                  /***** TAG 167 ****/
	CHAR		cSide;                                      /***** TAG 54 ****/
	CHAR		sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
	DOUBLE64	fQuantity;                                  /***** TAG 38 ****/
	CHAR		cOrderType;                                 /***** TAG 40 ****/
	DOUBLE64	fPrice;                                     /***** TAG 44 ****/
	CHAR		cTimeInForce;                               /***** TAG 59 ****/
	CHAR		cOrderCapacity;                             /***** TAG 47 ****/
	CHAR		sText[TEXT_LEN];                            /***** TAG 58 ****/
	CHAR		sIdSource[ID_SOURCE_LEN];              	 /***** TAG 22 ****/
	DOUBLE64	fStopPx;                                /***** TAG 99 ****/
	INT16		iProduct;				/****** Tag 460 *******/
	CHAR		sSecurityId[SECURITY_ID_LEN];           /***** TAG 48 ****/
	CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	CHAR            cCoverUncover;                              /****** TAG 203 *****/
	SHORT		iCustomerOrFirm;                        /***** TAG 204 ***/
	CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];         /***** TAG 200 ****/
	CHAR            cOptAttribute;                          /***** TAG 206 *****/
	LONG32          iTradSesStatus;				/** TAG 340 **/ /** 1 = Halted , 2= Open , 3= Closed , 4= Pre-Open,5= PreClose **/
	CHAR		sComplianceID[COMPLIANCE_LEN];      	/*** 376 ***/
	CHAR		sExpireDate[FIX_DATE_TIME_LEN];         /***** TAG 432 ***/
	CHAR		sClearingFirm[CLEARING_ACCOUNT_LEN];    /***** TAG 440 ***/
	CHAR		sExecBroker[FIX_BROKER_LEN];            /***** TAG 76 ***/
	CHAR		sTerminalInfo[TERMINAL_INFO_LEN];       /***** TAG 9227 **/

} FIX_NEW_ORDER_REQUEST ;
typedef struct
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR		sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
	CHAR		sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR		sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR		sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
	CHAR		sSymbol[SYMBOL_LEN];                        /***** TAG 55 ****/
	CHAR		sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
	CHAR		cSide;                                      /***** TAG 54 ****/
	CHAR		sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
	CHAR		sIdSource[ID_SOURCE_LEN];                   /***** TAG 22 ****/
	DOUBLE64	fQuantity;                                  /***** TAG 38 ****/
	CHAR		cOrderType;				/***** TAG 40 *****/
	CHAR		sSecurityEx[EXCHANGE_LEN];                   /***** TAG 207 ****/
	DOUBLE64	fStrikePrice;                               /****** TAG 202 ****/
	SHORT		iSettlmntType;                              /****** TAG 63 *****/
	CHAR		sFutSettDate[FIX_DATE_TIME_LEN];            /****** TAG 64 *****/
	INT16           iProduct;                               /****** Tag 460 *******/
	CHAR		sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR		cCoverUncover;                              /****** TAG 203 *****/
	CHAR		cOpenCloseFlg;                              /***** TAG 77 ******/
	CHAR		sMaturityMonthYear[MAT_MONYR];             /***** TAG 200 *****/
	SHORT		iPutOrCall;                                 /***** TAG 201 *****/
	CHAR		cOptAttribute;                              /***** TAG 206 *****/
	CHAR		sMaturityDay[DAY];                          /***** TAG 205 *****/
	LONG32		dReceivedTime;
	SHORT		iQtyCondition ;                             /****FOR AON on ***/
	CHAR		sSecurityId[SECURITY_ID_LEN];               /***** TAG 48 *****/
	CHAR		cListID;                                    /***** TAG 66 *****/
	CHAR		sComplianceID[COMPLIANCE_LEN];      		/*** 376 ***/
	SHORT		iCustomerOrFirm;                            /***** TAG 204*****/
	CHAR		cTechnicalOrdType;                          /***** TAG 9941 ***/
	CHAR		sOrigOrderID[ORDER_ID_LEN];                 /***** TAG 9945 ***/
	CHAR		sMemberID[MEMBERID_LEN]    ;                /***** TAG 9946****/
	CHAR		sSubscriberID[SUBSCRIBER_LEN];              /***** TAG 9955****/
} FIX_ORDER_CANCEL_REQUEST;

typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;

	CHAR		sOrderID[ORDER_ID_LEN];				/***** TAG 37 *****/
	CHAR		sOrigClOrdId[CLORDID_LEN];			/***** TAG 41 *****/
	CHAR		sClOrdId[CLORDID_LEN];				/***** TAG 11 *****/
	CHAR		sAccount[CSD_ACCT_NUMBER_LEN];			/***** TAG 1  *****/
	SHORT		iOrderFamily;					/***** TAG 9743 ***/
	CHAR		cHandlInst;					/***** TAG 21 *****/
	CHAR		sExecInst[EXEC_INST_LEN];			/***** TAG 18 *****/
	DOUBLE64	fMinQty;					/***** TAG 110 ****/
	DOUBLE64	fMaxFloor;					/***** TAG 111 ****/
	CHAR		sSymbol[SYMBOL_LEN];				/***** TAG 55 *****/
	CHAR		sSymbolSfx[SYMBOL_SFX_LEN];			/***** TAG 65 *****/
	CHAR		cSide;						/***** TAG 54 *****/
	CHAR		sTransactTime[FIX_DATE_TIME_LEN];               /***** TAG 60 *****/
	DOUBLE64	fQuantity;					/***** TAG 38 *****/
	CHAR		cOrderType;					/***** TAG 40 *****/
	DOUBLE64	fPrice;						/***** TAG 44 *****/
	LONG32		dCumQty;					/***** TAG 14 *****/
	CHAR		cTimeInForce;					/***** TAG 59 *****/
	CHAR		sExpireTime[FIX_DATE_TIME_LEN];			/***** TAG 126 ****/
	CHAR		cOrderCapacity;					/***** TAG 47 *****/
	CHAR		cOrderFamily;					/***** TAG 9743 ***/
	CHAR		sIdSource[ID_SOURCE_LEN];			/***** TAG 22 *****/
	DOUBLE64	fStopPx;					/***** TAG 99 *****/
	CHAR		sSecurityEx[EXCHANGE_LEN];			/***** TAG 207 ****/
	DOUBLE64	fStrikePrice;					/***** TAG 202 ****/
	SHORT		iSettlmntType;                                  /***** TAG 63 *****/
	CHAR		sFutSettDate[FIX_DATE_TIME_LEN];		/***** TAG 64 *****/
	CHAR		sSecurityType[SEC_TYPE];			/***** TAG 167 ****/
	CHAR		cCoverUncover;					/***** TAG 203 ****/
	CHAR		cOpenCloseFlg;					/***** TAG 77 *****/
	INT16           iProduct;                               	/****** Tag 460 *******/
	CHAR		sMaturityMonthYear[MAT_MONYR];			/***** TAG 200 ****/
	SHORT		iPutOrCall;					/***** TAG 201 ****/
	CHAR		cOptAttribute;					/***** TAG 206 ****/
	CHAR		sMaturityDay[DAY];				/***** TAG 205 ****/
	CHAR		sCurrency[MAX_CURRENCY_LEN];			/***** TAG 15 *****/
	LONG32		dReceivedTime;					/****/
	SHORT		iQtyCondition ;					/****FOR AON on ***/
	CHAR            sOrigTime[FIX_DATE_TIME_LEN];			/***** TAG 42 *****/
	CHAR            sSecurityId[SECURITY_ID_LEN];			/***** TAG 48 *****/
	CHAR            sText[TEXT_LEN];				/***** TAG 58 *****/
	CHAR            sClientID[CLIENT_ID_LEN];			/***** TAG 109 ****/
	CHAR		sComplianceID[COMPLIANCE_LEN];			/***** TAG 376 ****/
	SHORT           iCustomerOrFirm;				/***** TAG 204 ****/
	DOUBLE64        fMaxShow;					/***** TAG 210 ****/
	CHAR            sTradingSessionID[TRADING_SESS_LEN];		/***** TAG 336 ****/
	SHORT           iNoTradingSessions;				/***** TAG 386 ****/
	CHAR		sClearingFirm[CLEARING_ACCOUNT_LEN];		/***** TAG 440 ****/
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];			/***** TAG 432 ****/
	CHAR		sLastModTime[FIX_DATE_TIME_LEN];		/***** TAG 6000 ***/

} FIX_ORDER_MODIFICATION_REQUEST;

struct FIX_SPREAD_EXECUTION_REPORT
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;

	CHAR            sClOrdId[CLORDID_LEN];                         /***** TAG 11 *****/
	CHAR            sOrigClOrdId[CLORDID_LEN];                     /***** TAG 41 *****/
	CHAR            sIdSource[IDSOURCE_LEN];                       /***** TAG 22 *****/
	CHAR            sSecurityId_1[SECURITY_ID_LEN];             	/***** TAG 48 *****/ /*****Since 22=4 it contains ISIN**/
	CHAR            sSecurityId_2[SECURITY_ID_LEN];             	/***** TAG 48 *****/ /*****Since 22=4 it contains ISIN**/
	INT16           iProduct;
	CHAR            sSymbol[SYMBOL_LEN];                      /***** TAG 55 *****/
	CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];             /***** TAG 200 *****/
	CHAR            sMaturityDay_1[DAY];                          /***** TAG 205 *****/
	CHAR            sMaturityDay_2[DAY];                          /***** TAG 205 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	CHAR            cOptAttribute;                              /***** TAG 206 *****/
	CHAR            cSide_1;                                      /***** TAG 54 *****/
	CHAR            cSide_2;                                      /***** TAG 54 *****/
	CHAR            cOrderType;                                 /***** TAG 40 *****/
	DOUBLE64        fMaxFloor;                              /***** TAG 111*****/
	DOUBLE64        fQuantity;                                  /***** TAG 38 *****/
	DOUBLE64        fPrice;                                     /***** TAG 44 *****/
	CHAR            sClientID[CLIENT_ID_LEN];                   /***** TAG 109*****/
	SHORT           iCustomerOrFirm;                        /***** TAG 204*****/
	LONG32		iMultilegOrdType;
	LONG32		iNoLegs;
	CHAR            sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1  *****/
	DOUBLE64        fStopPx;                                /***** TAG 99 ****/
	CHAR            sTransactTime[FIX_DATE_TIME_LEN];               /***** TAG 60 *****/
	CHAR            cTimeInForce;                               /***** TAG 59 *****/
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];               /***** TAG 432 ****/
	CHAR            sText[MAX_TEXT_LEN];                        /***** TAG 58 *****/
	CHAR            sOrderID[ORDER_ID_LEN];                         /***** TAG 37 *****/
	CHAR            sSecondryOrderID[ORDER_ID_LEN];                         /***** TAG 198 *****/
	CHAR            sExecID[EXEC_ID_LEN];                           /***** TAG 17 *****/
	CHAR            cExecTransType;                             /***** TAG 20 *****/
	CHAR            cExecType;                                  /***** TAG 150*****/
	CHAR            cOrdStatus;                                 /***** TAG 39 *****/
	LONG32          dOrdRejReason;                              /***** TAG 103*****/
	LONG32          dExecRestatementReason;                     /***** TAG 378 ****/
	LONG32          dLeavesQty_1;                                 /***** TAG 151*****/
	LONG32          dLeavesQty_2;                                 /***** TAG 151*****/
	LONG32          dCumQty_1;                                    /***** TAG 14 *****/
	LONG32          dCumQty_2;                                    /***** TAG 14 *****/
	DOUBLE64        fAvgPx;                                     /***** TAG 6  *****/
	CHAR            sExecBroker[FIX_BROKER_LEN];                    /***** TAG 76 ***/
	CHAR            sClearingFirm[CLEARING_FIRM_LEN];               /***** TAG 439*****/
	DOUBLE64        fLastPx;                                    /***** TAG 31 *****/
	LONG32          dLastShares;                                /***** TAG 32 *****/
	CHAR            sClearingAccount[CLEARING_ACCOUNT_LEN];          /***** TAG 440 ***/
	CHAR            sTradingSessionID[TRADING_SESS_LEN];      /***** TAG 336 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];                /***** TAG 15  *****/
};

struct FIX_ORDER_CANCEL_REJECT
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR        sOrderID[ORDER_ID_LEN];				/***** TAG 37 *****/
	CHAR        sClOrdId[CLORDID_LEN];				/***** TAG 11 ****/
	CHAR        sOrigClOrdId[CLORDID_LEN];			/***** TAG 41 *****/
	CHAR        cOrdStatus;					/***** TAG 39 *****/
	SHORT       iOrderFamily;					/****  TAG 9743 ***/
	CHAR        sTransactTime[FIX_DATE_TIME_LEN];		/***** TAG 60 *****/
	CHAR        cCxlRejResponseTo;				/***** TAG 434 ****/
	CHAR        cCxlRejReason;					/***** TAG 102 ****/
	CHAR        sText[MAX_TEXT_LEN];				/****  TAG 58 *****/
} ;

typedef struct
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR        sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR        sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR        sSymbol[SYMBOL_LEN];                        /***** TAG 55 *****/
	CHAR        cSide;                                      /***** TAG 54 *****/
} FIX_ORDER_STATUS_REQUEST;
typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	LONG32      dRefSeqNum;                                 /***** TAG 45 *****/
	CHAR        sRefMsgType[MESSAGE_TYPE_LEN];              /***** TAG 372 ****/
	CHAR        dBusinessRejectRefID[BUSS_REJ_LEN];         /***** TAG 379 ****/
	LONG32      dBusinessRejectReason;                      /***** TAG 380 ****/
	CHAR        sText[MAX_TEXT_LEN];                            /****  TAG 58 *****/

	CHAR        sClOrdId[CLORDID_LEN];                  /***** TAG 11 *****/
	CHAR        sMsgID[MSGID_INT_LEN];                  /***** TAG 9262 ***/
	CHAR        sFunctionCodeOrig[4];                   /***** TAG 9931 ***/

}FIX_BUSINESS_MESSAGE_REJECT;

typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	LONG32      dRefSeqNum;                                 /***** TAG 45 *****/
	LONG32          dRefTagID;                                                                      /***** TAG 371 ****/
	CHAR        sRefMsgType[MESSAGE_TYPE_LEN];              /***** TAG 372 ****/
	LONG32      dSessionRejectReason;                       /***** TAG 380 ****/
	CHAR        sClOrdId[CLORDID_LEN];                  /***** TAG 11 *****/
	CHAR        sText[MAX_TEXT_LEN];                            /****  TAG 58 *****/
} FIX_SESSION_REJECT;

struct FIX_SECURITY_TRADING_SESSION_RESPONSE
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	CHAR            sTradSesReqId[15];      /** TAG 335 **/
	CHAR            sTradSessId[2];         /** TAG 336 **/
	LONG32          iTradSesStatus;         /** TAG 340 **/ /** 1 = Halted , 2= Open , 3= Closed , 4= Pre-Open,5= PreClose **/
	LONG32          iGroupId;               /*** TAG 9268 ***/
	LONG32          iGroupIdTradStat;               /*** TAG 9272 ***/ /** 1= Start Of Trading for Group ID , 2= END Of Trading for Group ID ***/
};

struct FIX_SECURITY_DEFINITION_RESPONSE
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	CHAR            sSecurityReqId[15];     /**** TAG 320 ****/
	CHAR            sSecurityRespId[15];    /**** TAG 322 ****/
	CHAR            sSecurityRespType[15];  /**** TAG 323 ****/
	CHAR            sIdSource[IDSOURCE_LEN]; /**** TAG 22 ****/
	LONG32          iNoofSec;               /*** TAG 393 *****/
	CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR            sSymbol[SYMBOL_LEN];                             /**********TAG 55************/
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];          /** TAG 65 *******/
	CHAR            sSecurityId[SECURITY_ID_LEN];                           /***** TAG 48 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];             /***** TAG 200 *****/
	CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	CHAR            cOptAttribute;                              /***** TAG 206 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	CHAR            sSecurityDesc[25];                              /**** TAG 107 ***/
	CHAR            sText[MAX_TEXT_LEN];                            /****  TAG 58 *****/
	LONG32          iLotSize;                                       /****** TAG 9201 ****/
	CHAR            sTradingUnit[5];                                /**** TAG 9202 ******/
	DOUBLE64        fTradingUnitFactor;                             /********* TAG 9246 *****/
	CHAR            sDeliveryUnit[5];                               /**** TAG 9247 ****/
	DOUBLE64        fDeliveryUnitFactor;                            /**** TAG 9248 ****/
	DOUBLE64        fPriceNumerator;                                /**** TAG 9203 ****/
	DOUBLE64        fPriceDemoninator;                              /**** TAG 9204 ****/
	DOUBLE64        fGenNumerator;                                  /**** TAG 9205 ****/
	DOUBLE64        fGenDemoninator;                                /**** TAG 9206 ****/
	LONG32          iPriceTick;                                     /** TAG 9210 ***/
	DOUBLE64        fDecimalLocator;                                /**** TAG 9211 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];                /***** TAG 15  *****/
	CHAR            sSettelmentCurrency[MAX_CURRENCY_LEN];          /***** TAG 120  *****/
	CHAR            sProductMonth[7];                               /*** TAG 9265 ***/
	LONG32          iPreOpen;                                       /** TAG 9267 ***/
	LONG32          iGroupId;                                       /** TAG 9268 ***/
	LONG32          iMatchingType;                                  /** TAG 9269 ***/
	LONG32          iSpreadType;                                    /** TAG 9270 ***/
	CHAR            sUnderlyingSecurityId[SECURITY_ID_LEN];         /** TAG 9273 ***/
	DOUBLE64        fHighPx;                                        /** TAG 332***/
	DOUBLE64        fLowPx;                                         /** TAG 333 **/
};

typedef struct
{
	INT_HEADER  	Header;
	FIX_HEADER  	FIXHeader;
	CHAR    	sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR   		sAccount[CSD_ACCT_NUMBER_LEN];
	CHAR            cHandlInst;
	CHAR            sExecInst[EXEC_INST_LEN];
	DOUBLE64        fMinQty;
	DOUBLE64        fMaxFloor;
	CHAR            sSymbol[SYMBOL_LEN];
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];
	CHAR            sSecurityType[DB_INS_LEN];
	CHAR            cSide_1;
	CHAR            cSide_2;
	CHAR            sTransactTime[FIX_DATE_TIME_LEN];
	DOUBLE64        fQuantity;
	CHAR            cOrderType;
	DOUBLE64        fPrice;
	CHAR            cTimeInForce;
	CHAR            cOrderCapacity;                                 /***** TAG 47 *****/
	CHAR            sText[TEXT_LEN];
	CHAR            sIdSource[ID_SOURCE_LEN];
	DOUBLE64        fStopPx;
	INT16           iProduct;
	CHAR            sSecurityId_1[SECURITY_ID_LEN];	
	CHAR            sSecurityId_2[SECURITY_ID_LEN];	
	CHAR            cOpenCloseFlg;
	SHORT           iCustomerOrFirm;
	LONG32		iMultilegOrdType;
	LONG32		iNoLegs;
	CHAR            sMaturityDate_1[DATE];                          /***** TAG 205 *****/
	CHAR            sMaturityDate_2[DATE];                          /***** TAG 205 *****/
	CHAR            cOptAttribute;
	SHORT           iPutOrCall;
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	CHAR            sComplianceID[COMPLIANCE_LEN];
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];         /***** TAG 432 ***/
	CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];    /***** TAG 440 ***/
	CHAR            sExecBroker[FIX_BROKER_LEN];            /***** TAG 76 ***/
	CHAR            sTerminalInfo[TERMINAL_INFO_LEN];
} FIX_SPREAD_NEW_ORDER_REQUEST ;	

typedef struct
{
	INT_HEADER      Header;
	FIX_HEADER      FIXHeader;
	CHAR            sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
	CHAR            sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR            sClOrdId[CLORDID_LEN];
	CHAR            sAccount[CSD_ACCT_NUMBER_LEN];
	SHORT           iOrderFamily;
	CHAR            cHandlInst;                                     /***** TAG 21 *****/
	CHAR            sExecInst[EXEC_INST_LEN];                       /***** TAG 18 *****/
	DOUBLE64        fMinQty;                                        /***** TAG 110 ****/
	DOUBLE64        fMaxFloor;
	CHAR            sSymbol[SYMBOL_LEN];                            /***** TAG 55 *****/
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];
	CHAR            cSide_1;
	CHAR            cSide_2;
	CHAR            sTransactTime[FIX_DATE_TIME_LEN];
	DOUBLE64        fQuantity;
	CHAR            cOrderType;                                     /***** TAG 40 *****/
	DOUBLE64        fPrice;                                         /***** TAG 44 *****/
	LONG32          dCumQty;                                        /***** TAG 14 *****/
	CHAR            cTimeInForce;                                   /***** TAG 59 *****/
	CHAR            sExpireTime[FIX_DATE_TIME_LEN];                 /***** TAG 126 ****/
	CHAR            cOrderCapacity;                                 /***** TAG 47 *****/
	CHAR            cOrderFamily;                                   /***** TAG 9743 ***/
	CHAR            sIdSource[ID_SOURCE_LEN];                       /***** TAG 22 *****/
	DOUBLE64        fStopPx;                                        /***** TAG 99 *****/
	CHAR            sSecurityEx[EXCHANGE_LEN];                      /***** TAG 207 ****/
	DOUBLE64        fStrikePrice;             
	SHORT           iSettlmntType;                                  /***** TAG 63 *****/
	CHAR            sFutSettDate[FIX_DATE_TIME_LEN];                /***** TAG 64 *****/
	CHAR            sSecurityType[SEC_TYPE];                        /***** TAG 167 ****/
	CHAR            cCoverUncover;                                  /***** TAG 203 ****/
	CHAR            cOpenCloseFlg;                                  /***** TAG 77 *****/
	INT16           iProduct;
	CHAR            sMaturityMonthYear[MAT_MONYR];                  /***** TAG 200 ****/
	SHORT           iPutOrCall;                                     /***** TAG 201 ****/
	CHAR            cOptAttribute;                                  /***** TAG 206 ****/
	CHAR            sMaturityDate_1[DATE];                              /***** TAG 205 ****/
	CHAR            sMaturityDate_2[DATE];                              /***** TAG 205 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];
	LONG32          dReceivedTime;                                  /****/
	SHORT           iQtyCondition ;                                 /****FOR AON on ***/
	CHAR            sOrigTime[FIX_DATE_TIME_LEN];
	CHAR            sSecurityId_1 [SECURITY_ID_LEN];
	CHAR            sSecurityId_2 [SECURITY_ID_LEN];
	CHAR            sText[TEXT_LEN];                                /***** TAG 58 *****/
	CHAR            sClientID[CLIENT_ID_LEN];
	CHAR            sComplianceID[COMPLIANCE_LEN];                  /***** TAG 376 ****/
	SHORT           iCustomerOrFirm;                                /***** TAG 204 ****/
	LONG32		iMultilegOrdType;
	LONG32		iNoLegs;
	DOUBLE64        fMaxShow;                                       /***** TAG 210 ****/
	CHAR            sTradingSessionID[TRADING_SESS_LEN];            /***** TAG 336 ****/
	SHORT           iNoTradingSessions;                             /***** TAG 386 ****/
	CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];            /***** TAG 440 ****/
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];                 /***** TAG 432 ****/
	CHAR            sLastModTime[FIX_DATE_TIME_LEN];
	CHAR		cCancelFlag;
} FIX_SPREAD_MODCANCEL_ORDER_REQUEST ;	 

typedef struct
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR            sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
	CHAR            sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR            sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR            sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
	CHAR            sSymbol[SYMBOL_LEN];                        /***** TAG 55 ****/
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
	CHAR            cSide_1;                 
	CHAR            cSide_2;                 
	CHAR            sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
	CHAR            sIdSource[ID_SOURCE_LEN];                   /***** TAG 22 ****/
	DOUBLE64        fQuantity;                                  /***** TAG 38 ****/
	CHAR            cOrderType;                             /***** TAG 40 *****/
	CHAR            sSecurityEx[EXCHANGE_LEN];                   /***** TAG 207 ****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	SHORT           iSettlmntType;                              /****** TAG 63 *****/
	CHAR            sFutSettDate[FIX_DATE_TIME_LEN];            /****** TAG 64 *****/
	INT16           iProduct;                               /****** Tag 460 *******/
	CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR            cCoverUncover;                              /****** TAG 203 *****/
	CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
	CHAR            sMaturityMonthYear[MAT_MONYR];             /***** TAG 200 *****/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	CHAR            cOptAttribute;                              /***** TAG 206 *****/
	CHAR            sMaturityDate_1 [DATE];
	CHAR            sMaturityDate_2 [DATE];
	LONG32          dReceivedTime;
	SHORT           iQtyCondition ;                             /****FOR AON on ***/
	CHAR            sSecurityId_1 [SECURITY_ID_LEN];
	CHAR            sSecurityId_2 [SECURITY_ID_LEN];
	CHAR            cListID;                                    /***** TAG 66 *****/
	CHAR            sComplianceID[COMPLIANCE_LEN];                  /*** 376 ***/
	SHORT           iCustomerOrFirm;                            /***** TAG 204*****/
	CHAR            cTechnicalOrdType;                          /***** TAG 9941 ***/
	CHAR            sOrigOrderID[ORDER_ID_LEN];                 /***** TAG 9945 ***/
	CHAR            sMemberID[MEMBERID_LEN]    ;                /***** TAG 9946****/
	CHAR            sSubscriberID[SUBSCRIBER_LEN];              /***** TAG 9955****/
} FIX_SPREAD_ORDER_CANCEL_REQUEST;



LONG32 FIXParse(FIX_Msg* msg, const char* buffer, int len);
static LONG32 FIXGetNextTag(char** src, char** dst);
static LONG32 FIXGetNextValue(char** src, char** dst);
LONG32 FIXGetMessageType(FIX_Msg *msg);
#endif




