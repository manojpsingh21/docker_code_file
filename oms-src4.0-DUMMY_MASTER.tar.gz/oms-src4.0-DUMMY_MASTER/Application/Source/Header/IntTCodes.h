#ifndef      _NSETCODES_
#define      _NSETCODES_


#define   TC_MBP_BCAST                                      7208
#define   TC_MBP_BCAST_TNDTC                                18705

#define   TC_TICKER_INDEX_BCAST                             7202
#define   TC_TICKER_INDEX_BCAST_TNDTC                       18703

#define   TC_MARKET_OPEN_MSG_BCAST                          6511

#define   TC_MARKET_CLOSE_MSG_BCAST                         6521

#define   TC_MARKET_PREOPEN_MSG_BCAST                       6531

#define   TC_MARKET_PREOPEN_END_MSG_BCAST                   6571

#define   TC_MARKET_POSTCLOSE_MSG_BCAST                     6522

#define   TC_MULTIPLE_INDEX_BCAST                           7207

#define   TC_GENERAL_MSG_BCAST                              6501

#define   TC_SYSTEM_INFORMATION_BCAST                       7206

#define   TC_STOCK_DETAILS_CHANGE_BCAST                     7305
#define   TC_STOCK_DETAILS_CHANGE_BCAST_TNDTC               18720

#define   TC_STOCK_STATUS_CHANGE_BCAST                      7320
#define   TC_STOCK_STATUS_CHANGE_BCAST_TNDTC                18130

#define   TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST              7322
#define   TC_STOCK_STATUS_PREOPEN_CHANGE_BCAST_TNDTC        18707

#define   TC_MARKET_OPEN_MSG_BCAST                          6511

#define   TC_MARKET_CLOSE_MSG_BCAST                         6521

#define   TC_PREOPEN_SHUTDOWN_BCAST                         6531

#define   TC_PRE_OPEN_ENDED_MSG_BCAST                       6571

#define   TC_PARTICIPANT_INFO_RESP                          7306

#define   TC_MKT_STATS_RPT_BCAST                            1833

#define   TC_POST_CLOSING_START_BCAST                       6583

#define   TC_POST_CLOSING_END_BCAST                         6584

#define   TC_AUCTION_INQUIRY_MSG	                    6582
#define   TC_AUCTION_INQUIRY_MSG_TNDTC                      18700

#define	  TC_AUCTION_STATUS_CHNG			    6581

#define   TC_MBO_MBP_UPDATE_BCAST                           7200
#define   TC_MBO_MBP_UPDATE_BCAST_TNDTC                     18701

#define	  TC_CALL_AUCTION_MBP				     7214
#define   TC_CALL_AUCTION_MBP_TNDTC                          18710

#define   TC_MKTWATCH_ROUND_ROBIN_BCAST                     7201
#define   TC_MKTWATCH_ROUND_ROBIN_BCAST_TNDTC               18702

#define   TC_INT_MARKET_OPEN_MSG_BCAST                      8	

#define   TC_INT_MARKET_PREOPEN_MSG_BCAST                   10

#define   TC_INT_MARKET_PREOPEN_END_MSG_BCAST               11

#define   TC_INT_MARKET_POSTCLOSE_MSG_BCAST                 12

#define   TC_INT_POST_CLOSING_START_BCAST                   15

#define   TC_INT_POST_CLOSING_END_BCAST                     16

#define   TC_INT_MARKET_CLOSE_MSG_BCAST                     9

#define	  TC_INT_MBP_TOUCH_BCAST                            8051

#define   TC_INT_MULTIPLE_INDEX_BCAST                       4

#define   TC_STOCK_STATUS_CHANGE_PREOPEN_BCAST     	 7322

#define	  TC_SECURITY_OPEN_MSG_BCAST			 6013

#define   TC_BROKER_TURNOVER_EXCEEDED_BCAST		 9010	

#define	  TC_BROKER_TURNOVER_REACTIVATED_BCAST		 9011

#define   TC_INSTRUMENT_UPDATE_BCAST                     7324

#define   TC_BCAST_SPREAD_MBP				 7211 
#define   TC_BCAST_SPREAD_MBP_TNDTC                      18708

#define	  TC_BCAST_TRADE_EXECUTION_RANGE 		 7220	

#endif
