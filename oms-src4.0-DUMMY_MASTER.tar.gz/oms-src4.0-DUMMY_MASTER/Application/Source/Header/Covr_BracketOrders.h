#pragma pack(2)
struct	CO_BO_HEADER
{
	LONG32          iSeqNo                          ;
	SHORT           iMsgLength                      ;
	SHORT           iMsgCode                        ;
	CHAR            sExcgId[EXCHANGE_LEN]           ;
	LONG32          iUserId                         ;
	CHAR            cSource                         ;
	CHAR            cSegment                        ;

};
#pragma pack()

#pragma pack(2)
struct COVER_ORDERS
{
	struct 		CO_BO_HEADER					;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sEntityId               [ENTITY_ID_LEN]         ;
	CHAR            sClientId               [CLIENT_ID_LEN]         ;
	CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	CHAR            cBuyOrSel1l                                      ;
	CHAR            cBuyOrSell2                                      ;
	SHORT           iOrderType                                      ;                              
	SHORT           iOrderValidity                                  ;                              
	LONG32          iDiscQty                                        ;
	LONG32          iDiscQtyRem                                     ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTriggerPrice                                   ;
	DOUBLE64        fOrderNum                                       ;
	SHORT           iSerialNum                                      ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
	LONG32          iAuctionNum                                     ;
};
#pragma pack()


#pragma pack(4)
struct BRACKET_ORDERS_REQUEST
{
	struct 		CO_BO_HEADER 					;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sEntityId               [ENTITY_ID_LEN]         ;
	CHAR            sClientId [CLIENT_ID_LEN]         		;
	CHAR            cProductId                                      ; 
	CHAR            cBuySellInd1 					;
	CHAR            cBuySellInd2 					;
	SHORT           iOrderType           				;
	SHORT           iOrderValidity                                  ;
	LONG32          iDiscQty					;
	LONG32          iDiscQtyRem                                     ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty  					;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fOrderNum                                       ;
	SHORT           iSerialNum                                      ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
	LONG32          iAuctionNum                                     ;
	CHAR		cSqrOffAbsOrTicks[10]				;
	DOUBLE64	fSqrOffPrice					;
	CHAR		cStopLossAbsOrTicks[10]				;
	DOUBLE64	fTriggerPrice					;
	DOUBLE64	fTrailingSLValue				;
#pragma pack()
};
