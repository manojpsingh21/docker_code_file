#include <stdlib.h>
#include <stdio.h>
#include "IPCS.h"
#include "NNFDrvStruct.h"


int main()
{
        printf("struct  INT_COMMON_RESP_HDR :%d:\n",sizeof(struct  ORDER_RESPONSE));
	printf(" size of char :%d:\n",sizeof(char));
	printf(" size of short	:%d:\n",sizeof(short));
	printf(" size of int	:%d:\n",sizeof(int));
	printf(" size of unsigned long long int	:%d:\n",sizeof(unsigned long long int));
	printf(" size of char :%d:\n",sizeof(char));
	printf(" size of char :%d:\n",sizeof(char));
	printf(" size of char :%d:\n",sizeof(char));
	printf(" size of char :%d:\n",sizeof(char));
        return 0;
}

