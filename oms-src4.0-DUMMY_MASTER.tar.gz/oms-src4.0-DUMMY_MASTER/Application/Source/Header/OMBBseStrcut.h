#ifndef __OMB_BSE_EQDATA_H__
#define __OMB_BSE_EQDATA_H__
#define BSETWIDDLE(A)   BseTwiddle((char *) &A, sizeof(A))
typedef BOOL  (*P_TO_FUN)(CHAR * x,CHAR * y,LONG32 GroupId);
#pragma pack(2)
struct OMB_HEADER
{
	LONG32 	iSlotNo;
	LONG32  iMsgLen;
};
#pragma pack( )

#pragma pack(2)
struct OMB_KEEP_ALIVE_MSG_PCOL
{
	struct OMB_HEADER   pHeader;
	LONG32  	iMsgType;
};
#pragma pack( )


#pragma pack(2)
struct OMB_REPLY_ERR_MSG_PCOL
{
	struct OMB_HEADER   OmbHeader;
	LONG32      iMsgType;
	LONG32      iSlotNo;
	LONG32      iMsgTag;
	LONG32      iErrorNo;
	CHAR        sErrText [BSE_ERR_LEN ];      /****** 81 ******/
};
#pragma pack( )

#pragma pack(2)
struct  OMB_UPDATE_PASSWORD_REQ
{
	struct OMB_HEADER   pHeader;
	LONG32              iMsgType;
	CHAR                sOldPasswd[ BSE_PASSWORD_LEN ]; /********** 11 ************/
	CHAR                sNewPasswd[ BSE_PASSWORD_LEN ]; /********** 11 ************/
	LONG32              iMsgTag;
};

#pragma pack( )
/*****************      1.9             Update Password Reply   ********************/

#pragma pack(2)
struct OMB_UPDATE_PASSWORD_RESP
{
	struct OMB_HEADER   pHeader;
	LONG32              iMsgType;
	SHORT               iRepCode;
	CHAR                sRepText[ BSE_REPLY_TEXT_LEN ]; /****** 40 **********/
	LONG32              iMsgTag;
};
#pragma pack( )

#pragma pack(2)
struct OMB_USER_REGISTRATION_REQ_PCOL
{
	struct OMB_HEADER   pHeader;
	LONG32                  iMsgType;
	LONG32                  iSlotNo;
	LONG32                  iMmbrId;
	LONG32                  iTraderId;
};
#pragma pack( )


#pragma pack(2)
struct OMB_LOG_ON_OFF_REQUEST
{
	struct OMB_HEADER       pHeader;
	LONG32                  iMsgType;
	CHAR                    sPasswd [ BSE_PASSWORD_LEN ];
	CHAR                    cFiller;
	LONG32                  iMsgTag;
};
#pragma pack( )


#pragma pack(2)
struct OMB_LOG_OFF_REPLY
{
	struct OMB_HEADER               pHeader;
	LONG32                          iMsgType;
	INT16                           iRepCode;
	INT16                           iFiller;
	LONG32				iFiller2;
	CHAR                            sRepMsg[ BSE_REPLY_TEXT_LEN ];
	LONG32                          iMsgTag;
};
#pragma pack( )

#pragma pack(2)
struct OMB_NEWS_CATEGORY_REQ
{
	struct OMB_HEADER       pHeader;
	LONG32  iMsgType;
	LONG32  iMsgTag;
	SHORT   iCategory;
	CHAR    cDirection;
	LONG32  iNewsID;

};
#pragma pack()

#pragma pack(2)
struct SUB_NEWS_CATEGORY_RESP
{
	SHORT   iNewsCategory;
	CHAR    sNewTitle[NEWS_CATEGORY_TITLE_LEN];
};
#pragma pack()


#pragma pack(2)
struct OMB_NEWS_CATEGORY_RESP
{
	struct OMB_HEADER       pHeader;
	LONG32  iMsgType;
	SHORT   iReplyCode;
	SHORT   iNoOfRec;
	LONG32  iMsgTag;
	struct SUB_NEWS_CATEGORY_RESP   SubNewsCat[15];
};
#pragma pack()

#pragma pack(2)
struct OMB_BSE_YEAR
{
	CHAR            cDay;
	CHAR            cMonth;
	CHAR            cYear;
};
#pragma pack( )

#pragma pack(2)
struct OMB_BSE_YEAR_SHORT
{
	CHAR       iYear;
	CHAR        cMonth;
	CHAR        cDay;
};
#pragma pack( )

#pragma pack(2)
struct OMB_BSE_TIME
{
	CHAR            cHour;
	CHAR            cMinute;
	CHAR            cSecond;
	//	CHAR		sMiliSec[4];
};
#pragma pack( )


/**#pragma pack(2)
  struct SUB_TRADE_CONFIRMATION_UMS
  {
  LONG32         iScripCode;
  LONG32         iTradeId;
  LONG32         iRate;
  LONG32         iQty;
  LONG32         iOppMmbr;
  LONG32         iOppTradeId;
  struct         OMB_BSE_YEAR        ombbsedate;
  struct         OMB_BSE_TIME        ombbsetime;
  CHAR           sClient[ BSE_CLIENT_LEN ];  /******* 12 *******/
/**    	CHAR           cTransType;
  CHAR           cBuySel;
  CHAR           sOrderTimeStamp[20];             /**** Added by  as OMB document ver 40.0 ****/
/**    	SPARCLONG64    iTransId;
  LONG32         iMsgTag;
  LONG32         iCustdn;
  INT16          iCaClass;
  }; 
#pragma pack( ) ****/

#pragma pack(2)
struct	SUB_TRADE_CONFIRMATION_UMS
{
	LONG32		iScripCode			;
	LONG32		iTradeId			;
	LONG32		iRate				;
	LONG32		iQty				;
	LONG32		iPenQty;
	LONG32		iResField			;
	struct		OMB_BSE_YEAR_SHORT	pOmbYr		;
	struct		OMB_BSE_TIME	pOmbTime	;
	CHAR		sClient	[BSE_CLIENT_LEN]	;
	CHAR		cOrderType			;
	CHAR		cBuySel				;
	CHAR		cParticipantCode	[BSE_PARTICIPANT_CODE_LEN]	;
	long long	iOrdId				;
	LONG32		iMsgTag				;
	LONG32		iFlag				;
	SHORT		iCliType			;
	SHORT		iFiller2			;
	long long	iResField1			;
	long long	iFiller3			;
	LONG32		iFiller4			;
	LONG32		iFiller5			;
	CHAR		sAlgoId[BSE_ALGO_ID_LEN]	;

};
#pragma	pack(	)

#pragma pack(2)
struct OMB_TRADE_CONFIRMATION_UMS
{
	struct OMB_HEADER       pHeader;
	LONG32                  iMsgType;
	LONG32                  iNoOfRecords;
	struct SUB_TRADE_CONFIRMATION_UMS pSubTraDetails[TRADE_RECS];
};
#pragma pack( )

#pragma pack(2)
struct OMB_LOG_ON_REPLY
{
	struct OMB_HEADER   	pHeader;
	LONG32              iMsgType;
	INT16               iRepCode;
	LONG32              iResFiled;
	CHAR                sRepMsg[ BSE_REPLY_TEXT_LEN ];
	CHAR                sMotd[BSE_NEWS_DATA_LEN ];
	CHAR		    cResFiled1;
	CHAR                cResFiled2;
	CHAR                cResFiled3;
	CHAR                cResFiled4;
	CHAR                cResFiled5;
	CHAR                cResFiled6;
	CHAR                cResFiled7;
	CHAR                cResFiled8;
	CHAR                cResFiled9;
	CHAR                cResFiled10;
	CHAR                cResFiled11;
	CHAR                cResFiled12;
	CHAR                cResFiled13;
	UCHAR               cResFiled14;
	UCHAR               cResFiled15;
	CHAR		    cResFiled16[BSE_INDEX_ID_LEN];
	INT16               iTotPartitions;
	INT16		    iResFiled17;
	LONG32              iMsgTag;
};
#pragma pack( )


#pragma pack(2)
struct  ForkProcess
{
	int 	ProcessId;
	int 	ProcessStatus;
};
#pragma pack( )

#pragma pack(2)
struct SUB_QUERY_INDEX_VALUES_REPLY
{
	LONG32             iHigh;
	LONG32             iLow;
	LONG32             iOpen;
	LONG32             iClose;
	LONG32             iCurValue;
	LONG32             iIndexCode;
	CHAR               sIndexId[ INDEXID_LEN + 1 ];  /***** 7 *****/
};
#pragma pack( )


#pragma pack(2)
struct OMB_QUERY_INDEX_VALUES_REPLY
{
	struct OMB_HEADER       pHeader;

	LONG32                  iMsgType;
	SHORT                   iRepCode;
	LONG32                  iNoOfRecords;
	LONG32                  iMsgTag;
	struct SUB_QUERY_INDEX_VALUES_REPLY pDtls[ NO_INDEXVAL ];   /*** 10 ***/
};
#pragma pack( )

#pragma pack(1)
struct OMB_QUERY_INDEX_VALUES_REQUEST
{
	struct OMB_HEADER       pHeader;

	LONG32                  iMsgType;
	LONG32                  iIndexCode;
	CHAR                    cDirection;
	/*      CHAR                                    Filler[7];  Added by  .. Not mentioned in OMB ..But discussed with Exch**/
	LONG32                  iMsgTag;
};
#pragma pack( )

#pragma pack(2)
struct END_DOWNLOAD
{
	struct OMB_HEADER   pHeader;
	LONG32		iMsgType;
	LONG32		iNoOfRec;
	LONG32        	iGroupId;
};
#pragma pack( )

#pragma pack(2)
struct OMB_QUERY_INFO_RESP
{
	struct OMB_HEADER   pHeader;
	LONG32              iMsgType;
	SHORT               iRepCode;
	LONG32              iMsgTag;
};
#pragma pack( )

#pragma pack(2)
struct OMB_QUERY_PERSONAL_INFO
{
	struct OMB_HEADER   pHeader;
	LONG32              iMsgType;
	struct OMB_BSE_TIME ombbsetime; /****** PETQUERY DETAILS struct *******/
	CHAR                cFiller;
	LONG32              iMsgTag;
};
#pragma pack( )

struct OMB_QUERY_6A7A_INFO
{
	struct OMB_HEADER   pHeader;
	LONG32              iMsgType;
	LONG32              iMsgTag;
};

#pragma pack(2)
struct OMB_HEADER_INT
{
	struct 	OMB_HEADER	pHeader;
	int	iMsgType;
};

#pragma pack( )

/*#pragma pack(2)
struct BEST_RATE_QTY
{
	LONG32                    iBestBuyRate  ;
	LONG32                    iBestBuyQty   ;
	LONG32                    iBestSelRate  ;
	LONG32                    iBestSelQty   ;
};
#pragma pack( )

#pragma pack(2)
struct SUB_QUERY_MKT_INF_RESP
{
	LONG32                 iScripCode   ;
	LONG32                 iOpenRate    ;
	LONG32                 iCloseRate   ;
	LONG32                 iHighRate    ;
	LONG32                 iLowRate     ;
	LONG32                 iNoOfTrades  ;
	LONG32                 iTradedVolume;
	LONG32                 iTradedValue ;
	LONG32                 iLTradeQty   ;
	LONG32                 iLTradeRate  ;
	LONG32                 iTotBuyQty   ;
	LONG32                 iTotSelQty   ;
	CHAR                   cUnit        ;
	CHAR                   cTrend       ;
	LONG32                 iLowerCktLmt ;
	LONG32                 iUpperCktLmt ;
	LONG32                 iWeightedAvg ;
	struct BEST_RATE_QTY   pBest_Rates[NO_BEST];
};
#pragma pack( )
*/

#pragma pack(2)
struct SUB_QUERY_MKT_INF_RESP
{
	LONG32		iBestBidRate;
	LONG32		iTotBidQty;
	LONG32		iNoOfBidPriPnt;
	LONG32		iFiller1;
	LONG32		iBestOfferRate;
	LONG32		iTotOfferQty;
	LONG32		iNoOfAskPriPnt;
	LONG32		iFiller2;
};
#pragma pack()

#pragma pack(2)
struct OMB_QUERY_MKT_INF_RESP
{
	struct OMB_HEADER          pHeader  ;

	LONG32                  iMsgType;
	LONG32			iRefTag;	
	SHORT                   iRepCode;
	SHORT			iReservedField;
	LONG32                 	iScripCode   ;
	LONG32                 	iOpenRate    ;
	LONG32                 	iPerCloseRate;
	LONG32                 	iHighRate    ;
        LONG32                 	iLowRate     ;
	LONG32                 	iNoOfTrades  ;
        LONG32                 	iTradedVolume;
        LONG32                 	iTradedValue ;
	LONG32                 	iLTradeQty   ;
	LONG32			iLtp;
	LONG32			iCloseRate;
	LONG32			iBckDelRefPrice;
	LONG32			iEquilibriumPri;
	LONG32			iEquilibriumQty;
	long long 		iResField1;
	LONG32			iTotBidQty;
	LONG32			iTotOfferQty;
	CHAR			cTrdValueFlg;
	CHAR			cTrend;
	CHAR			cSixLakhFlg;
	CHAR			cResField2;
	LONG32                 	iLowerCktLmt ;
        LONG32                 	iUpperCktLmt ;
	LONG32                 	iWeightedAvg ;
	SHORT                   iMktType;
	SHORT                  	iSessNO;
	struct	OMB_BSE_TIME    pOmbBseTim;
	CHAR			cLtpMiliSec[3];
	CHAR			cResField3[2];
	SHORT			iResField4;
	SHORT			iNoOfPriPnt;
	struct SUB_QUERY_MKT_INF_RESP pDtls[5];
};
#pragma pack( )

#pragma pack(2)
struct  BSE_PACKET
{
	struct  OMB_HEADER pHeader;
	int     iMsgType;
	char    sMessage[BSE_PACKET_SIZE];
};
#pragma pack( )


#pragma pack(2)
struct OMB_QUERY_MARKET_INFO_REQUEST
{
	struct OMB_HEADER   pHeader;
	LONG32              iMsgType;
	SHORT               iNoOfScrips; /************ max value = 4 **********/
	LONG32              iMsgTag;
	LONG32              iScripCodes[ BSE_NO_OF_SCRIPS ]; /**************** 4 ***********/
};
#pragma pack( )

#pragma pack(2)
struct OMB_ORDER_REQ
{
	struct OMB_HEADER    pHeader;
	LONG32 		iMsgType;
	LONG32 		iScripCode;
	LONG32 		iMsgTag1;
	LONG32 		iQty;
	LONG32 		iRevealedQty;
	LONG32 		iRate;
	LONG32 		iTriggerRate;   /*** Changed for IML 56 ***/
	LONG32 		iReserved2;
	LONG32 		iReserved3;
	LONG32 		iFiller1;
	LONG32 		iFiller2;
	LONG32 		iMsgTag2;
	long long 	iOrderId;
	long long  	iLocationId;
	LONG32 		iFiller3;
	SHORT  		iFiller4;
	SHORT  		iFiller5;
	CHAR		sClientID[12];
	CHAR   		sParticipantCode[13];
	CHAR   		sMsgTag3[15];
	CHAR   		sFiller6[4];
	UCHAR  		cAUDCode;
	UCHAR  		cOrgBuySell;
	UCHAR  		cOrdType;
	UCHAR  		cExecutionType;
	SHORT		iClientType;
	SHORT  		iMktProtection;
	SHORT  		iRetention;
	SHORT  		iFiller8;
	long long	iReserved4;
	long long	iFiller9;
	LONG32		iFiller10;
	LONG32		iFiller11;
	CHAR            sAlgoId[BSE_ALGO_ID_LEN];	
};
#pragma pack( )

#pragma pack(2)
struct  OMB_ADD_UP_DEL_ORD_RLY
{
	struct	OMB_HEADER	pOmbHeader;
	LONG32                  iMsgType;
	LONG32                  iMsgTag1;
	SHORT                   iRlyCode;
	SHORT                   iFiller;
	LONG32                  iAmendedQty;
	long long		iOrderId;
	struct  OMB_BSE_YEAR    pOmbBseYr;
	struct  OMB_BSE_TIME    pOmbBseTim;
	CHAR                    cMillSec[4];
	UCHAR                   cOrdActionCode;
	UCHAR                   cBuySell;
	UCHAR                   cOrderType;
	CHAR                    sFiller1[3];
	CHAR                    sRelyText[99+1];
	CHAR                    sFill[2];
	CHAR                    sReserveFiled[13];
	CHAR                    sMsgTag3[15];
	LONG32                  iMsgTag2;
	LONG32                  iPendingQty;
	LONG32			iTotalTradQty;
	SHORT                   iFiller3;
	SHORT                   iFiller4;
	long long		sResFiled;
	long long		iFiller1;
	LONG32			iFiller2;
	LONG32			iFiller5;
	CHAR            	sAlgoId[BSE_ALGO_ID_LEN];
};
#pragma pack()

#pragma	pack(2)
struct	OMB_CONV_TO_LMT_RESP
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32			iMsgType;
	LONG32			iSecurityID;
	long	long		iExchOrderID;
	LONG32			iMsgTag;
	LONG32			iLmtPrice;		
};
#pragma pack()

#pragma pack(2)
struct OMB_SL_ORDER_UMS
{
	struct	OMB_HEADER	pOmbHeader;
	LONG32			iMsgType;
	LONG32			iScripCode;
	long	long		iSlOrdId;
	LONG32			iRate;
	LONG32			iQty;
	LONG32			iAvaQty;
	LONG32			iMsgTag;
	CHAR			cOrdType;
	CHAR			cBuySell;
	struct  OMB_BSE_YEAR    pOmbBseYr;
	struct  OMB_BSE_TIME    pOmbBseTim;
	CHAR			sClientId[12];
	LONG32			iSpTriggFlag;			
	SHORT			iClientTy;
	SHORT			iRetension;
	long	long		iLocationId;			

};
#pragma pack()

#pragma pack()
struct	KILL_MINI_FILL_ORD
{
	struct	OMB_HEADER	pOmbHeader;
	LONG32			iMsgType;
	LONG32			iScripCode;
	long	long		iOrdId;
	LONG32			iKilledQty;
	LONG32			iLastTrdId;
	LONG32			iMsgTag;

};
#pragma pack(2)

#pragma pack(2)
struct TRANS_FUN_PAIR
{
	INT16        Transcode;
	P_TO_FUN     pToFun;
};
#pragma pack()

struct AU_OMB_HEADER
{
        LONG32  iSlotNo;
        LONG32  iMsgLen;
};
#pragma pack()


#pragma pack(2)
struct AUCTION_CONNECTION_REQUEST
{
        struct AU_OMB_HEADER AuHeader;
        LONG32 MsgType;
        LONG32 MsgTag;
};
#pragma pack()

#pragma pack(2)
struct AUCTION_CONNECTION_RESPONSE
{
	struct  OMB_HEADER      pOmbHeader;	
	LONG32 iMsgType;
	LONG32 iMsgTag;
	SHORT  iReplyCode;
	SHORT  iAucSecNo;
	CHAR   cReplyMsg[39+1];	
};
#pragma pack()

#pragma pack(2)
struct AUCTION_SCRIP_MASTER_DOWNLOAD_REPLY
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32	iMsgType;
	LONG32	iMsgTag;
	SHORT	iReplyCode;
	CHAR   cReplyMsg[39+1];
};
#pragma pack()

#pragma pack(2)
struct AUCTION_END_OF_SCRIP_MASTER_DOWNLOAD
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32  iMsgType;
	LONG32 	iMemberid;
	LONG32	iTraderid;
	LONG32	iFiller;
	LONG32	iNoOfRec;
	LONG32	iMsgTag;
};
#pragma pack()

#pragma pack(2)
struct SUB_AUCTION_SCRIP_MASTER_UMS
{
	LONG32	iScripCode;
	LONG32	iUpperLmt;
	LONG32	iHawalaRate;
	LONG32	iClosingRate;
	LONG32	iFiller;
	LONG32	iFloorPrice;
	LONG32	iAucQty;
	LONG32	iMktLot;
	SHORT	iTickPrice;
	CHAR	sScripId[11+1];
	CHAR	sScripName[12+1];
	CHAR	cGroupName;
		

};
#pragma pack()

#pragma pack(2)
struct AUCTION_SCRIP_MASTER_UMS
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32  iMsgType;
	LONG32 	iNoOfRec;
	LONG32	iMsgTag;
	SHORT	iAucNo;
	SHORT	iSetNo;
	CHAR	cNoticeNo[10+1];
	CHAR	Filler;
	struct SUB_AUCTION_SCRIP_MASTER_UMS subAucUms[14];
	
};
#pragma pack()

#pragma pack(2)
struct	AUCTION_ADD_UPDATE_REQ
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32	iMsgType;
	LONG32	iScripCode;
	LONG32	iMsgTag;
	LONG32	iQty;
	LONG32	iRate;
	LONG32	iOfferId;
	CHAR	sClientId[11+1];
	CHAR	sNoitceNo[10+1];
	CHAR	sFiller[1+1];	
};
#pragma pack()

#pragma pack(2)
struct	AUCTION_ADD_UPDATE_DEL_RESP
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32	iMsgType;
	LONG32	iMsgTag;
	SHORT	iReplyCode;
	LONG32	iOrderNo;
	CHAR	cDay;
	CHAR	cMonth;
	CHAR	cYear;
	CHAR	cHour;
	CHAR	cMin;
	CHAR	cSec;
	CHAR	sReplyText[79+1];
};
#pragma pack()

#pragma pack(2)
struct AUCTION_DEL__REQ
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32	iMsgType;
	LONG32	iScripCode;
	LONG32	iMsgTag;
	LONG32	iOfferId;
	CHAR	sNoticeNo;
};
#pragma pack()

#pragma pack(2)
struct  SUB_ORD_MASS_CAN_UMS_RESP 
{
	LONG32	iInstruCode	;
	LONG32	iMsgTag		;
	LONG32	iOrdQty		;
	LONG32	iReasonCode	;
	LONG32	iFiller1	;
	LONG32	iFiller2	;
	LONG32	iFiller3	;
	LONG32	iFiller4	;
	LONG64	iExchOrdNumber	;
	CHAR	cYear		;
	CHAR	cMonth		;
	CHAR	cDay		;
	CHAR	cHours		;
	CHAR	cMinutes		;
	CHAR	cSeconds		;
	CHAR	cFiller5		;
	CHAR	cFiller6		;
	CHAR	cFiller7		;
	CHAR	sFiller8	[15]	;
	
};
#pragma pack()

#pragma pack(2)
struct	ORD_MASS_CAN_UMS_RESP
{
	struct  OMB_HEADER      pOmbHeader;
	LONG32	iMsgType	;
	LONG32	iNoOfRecords	;
	struct	SUB_ORD_MASS_CAN_UMS_RESP pSubUmsMass[14];	
	
};
#pragma pack()

#pragma pack(2)
struct THROTTLE_NOTIFICATION
{
        struct OMB_HEADER   pOmbHeader;
        LONG32  iMsgType ;
        LONG32  iTranstLmt ;
        LONG32  iMaxSlts ;
        LONG32  iRejctLmt ;
        SHORT   iuserType ;
        SHORT   iThrtleTimeLmt;
};
#pragma pack()

#pragma pack(2)
struct MASS_CANECL_REQ_INFO
{
        struct OMB_HEADER   pHeader;
        LONG32  iMsgType ;
        LONG32  iRefTag  ;
        LONG32  iFiller1 ;
        SHORT   iFiller2 ;
        SHORT   iFiller3 ;
};
#pragma pack()

#pragma pack(2)
struct MASS_CANECL_RESP_INFO
{
        struct OMB_HEADER   pHeader;
        LONG32  iMsgType  ;
        LONG32  iRefTag   ;
        SHORT   iRepCode;
        SHORT   iFiller1  ;
        CHAR    sRepltTxt[40] ;
};
#pragma pack()

#pragma pack(2)
struct NOT_AFFECTED_ORDERS_DETAILS
{
        LONG64  iNotAffctdOrdId ;
        LONG64  iFiller         ;
};
#pragma pack()



#pragma pack(2)
struct UMS_MASS_CANEL_INFO
{
        struct OMB_HEADER   pHeader;
        LONG32  iMsgType                ;
        CHAR    cLastFrgmnt             ;
        CHAR    cMassActnRsn            ;
        CHAR    sMassActnRptId[20]      ;
        CHAR    sPad2[2]                ;
        LONG64  iSecId                  ;
        LONG32  iPrdId                  ;
        LONG32  iRsvField1              ;
        LONG32  iRsvField2              ;
        LONG32  iRsvField3              ;
        SHORT   iPartitionId            ;
        SHORT   iNoNotAffctdOrds        ;
        struct NOT_AFFECTED_ORDERS_DETAILS  pOrdDetails ;

};
#pragma pack()

#pragma pack(2)
struct END_OF_UMS_MASS_CANEL_INFO
{
        struct OMB_HEADER   pHeader;
        LONG32  iMsgType        ;
        LONG32  iNoOfRcds       ;
        LONG32  iRegTag         ;
};
#pragma pack()


#pragma pack(2)
struct RRM_MESSAGE_ALERT_INFO_DETAILS 
{
        LONG32  iProductId	;
        LONG32  iAlert_type     ;
        LONG32  iPercentage	;
        LONG32  iFiller1	;
        LONG32  iFiller2	;
        LONG32  iReserved	;
        LONG32  iSegment_type	;
        LONG32  iFiller3	;
        SHORT	iFiller4	;
        SHORT	iRRM_State	;
        SHORT	iFiller5	;
        SHORT	iFiller6	;
        LONG64	iFiller7	;
        LONG64	iFiller8	;
        LONG64	iFiller9	;
        LONG64	iFiller10	;
        LONG64	iFiller11	;
	CHAR	cYear		;
	CHAR	cMonth		;
	CHAR	cDay		;
	CHAR	cHour		;
	CHAR	cMinute		;
	CHAR	cSecond		;
	CHAR	sStatus[2]	;
	CHAR	sFiller12[2]	;
	CHAR	sFiller13[2]	;
	CHAR	sDescription[40];
	CHAR	sCP_Code[13]	;
	CHAR	sFiller14[3]	;
	CHAR	sClientId[12]	;
};
#pragma pack()


#pragma pack(2)
struct RRM_MESSAGE_ALERT_INFO
{
        struct OMB_HEADER   pHeader;
        LONG32  iMsgType        ;
        SHORT	iNoOfRecords    ;
        SHORT   iRegTag         ;
	struct RRM_MESSAGE_ALERT_INFO_DETAILS  pAlertDetails[4]; 
};
#pragma pack()

#pragma pack(2)
struct CAPITAL_INFO_DETAILS
{
	LONG32	iMemberCode;	
	LONG32	iReserved;
	LONG32	iFiller1;
	LONG32	iPercentage;
	LONG64	iTotalCollateral;
	LONG64	iUtilizedCollateral;
	LONG64	iUnUtilizedCollateral;
	LONG64	iFiller2;
	SHORT	iFiller3;
	SHORT	iStatus;
	SHORT	iMemberStatus;
	SHORT	iReserved1;
	SHORT	iFiller4;
	SHORT	iFiller5;
	SHORT	iFiller6;
	SHORT	iFiller7;
	//SHORT	iFiller8;
	CHAR	cSegmentType;
	CHAR	cReserved2;
	CHAR	cReserved3;
	CHAR	cMemberType;
	CHAR	cYear;
	CHAR    cMonth;
        CHAR    cDay;
        CHAR    cHour;
        CHAR    cMinute;
        CHAR    cSecond;
	CHAR	cFiller9;
	CHAR	sMessage[40];
	CHAR	sReserved4[13];
	CHAR	sReserved5[12];
	CHAR	sFiller9[3];
};
#pragma pack()

#pragma pack(2)
struct CAPITAL_INFO_NOTIFICATION
{
        struct OMB_HEADER   pHeader;
        LONG32  iMsgType        ;
        LONG32  iRegTag         ;
        SHORT   iNoOfRecords    ;
	SHORT   iAlert_type	;
	SHORT   iReserved	;
	SHORT   iFiller		;
        struct  CAPITAL_INFO_DETAILS  pAlertDetails[5];
};
#pragma pack()


#pragma pack(2)
struct NOT_AFFECTED_ORDERS_NOTI_DETAILS
{
        LONG64  iNotAffctdOrdId ;
        LONG64  iFiller         ;
};
#pragma pack()

#pragma pack(2)
struct MASS_CANCEL_NOTIFICATION
{
	struct OMB_HEADER   pHeader;	
	LONG32  iMsgType        ;
	CHAR	cLastFragment	;	
	CHAR	cMassActReason;
	CHAR	sMassActReportId[19+1];
	CHAR	sPad2[2];
	LONG64	iSecurityId;
	LONG32	iProductId;
	LONG32	iReserved;
	LONG32	iReserved1;
	LONG32	iReserved2;
	SHORT	iPartionId;
	SHORT	iNoNotAffectOrders;
        struct  NOT_AFFECTED_ORDERS_NOTI_DETAILS pAlertDetails;
};
#pragma pack()

#pragma pack(2)
struct SUSPENSION_NOTIFICATION
{
	struct OMB_HEADER   pHeader;
	LONG32      iMsgType;
        LONG32  iFiller         ;
	CHAR	cDay		;
        CHAR    cMonth		;
	CHAR    cYear		;
        CHAR    cHour		;
        CHAR    cMinute		;
        CHAR    cSecond		;
	CHAR	sMarketFlag[2]  ;
	CHAR    sReason[79+1]	;

};
#pragma pack()

#pragma pack(2)
struct REACTIVATION_NOTIFICATION 
{
 	struct OMB_HEADER   pHeader;
	LONG32      iMsgType;
        LONG32  iFiller         ;
	CHAR    sReason[79+1]	;
        LONG32  iFiller1        ;
        LONG32  iFiller2        ;
};
#pragma pack()

#pragma pack(2)
struct  RRM_ORDER_REPLY_RESP_DETAIL 
{
	LONG32  iInstruCode     ;
	LONG32  iRate		;
        LONG32  iTotalQty         ;
        LONG32  iOrdQty         ;
        LONG32  iMsgTag         ;
        LONG32  iReserved	;
        LONG32  iFiller1        ;
        LONG32  iFiller2        ;
        SHORT	iEvent		;
        SHORT	iErrorId		;
        SHORT	iRetention	;
        SHORT	iFiller3        ;
        LONG64  iExchOrdNumber  ;
        LONG64  iValue		;
        LONG64  iUtilizedValue		;
        LONG64  iRRMValue		;
        LONG64  iPercentValue		;
        CHAR    cYear           ;
        CHAR    cMonth          ;
        CHAR    cDay            ;
        CHAR    cHours          ;
        CHAR    cMinutes                ;
        CHAR    cSeconds                ;
        CHAR    sAddUpdate[2]                ;
        CHAR    sFiller4[2]                ;
        CHAR    sOrderType[2]                ;
        CHAR    sMessage[40]                ;
        CHAR    sParticipant[13]                ;
        CHAR    sFiller5[3]                ;
        CHAR    sClientId[12]                ;
        LONG64  iReserved1		;
        LONG64  iFiller6		;
        LONG32  iFiller7;
        LONG32  iFiller8	;
        CHAR    sAlgoId[16]    ;
	

};
#pragma pack()


#pragma pack(2)
struct  RRM_ORDER_REPLY_RESP 
{
        struct 	OMB_HEADER   pHeader;
	LONG32      iMsgType;
        SHORT   iNoOfRecords	;
        SHORT	iFiller         ;
	struct	RRM_ORDER_REPLY_RESP_DETAIL	pSubUmsMass[4];
};
#pragma pack()

#pragma pack(2)
struct	TC_INCR_TRADE_RESP
{
        struct 	OMB_HEADER   pHeader;
	LONG32      	iMsgType;
	LONG32		iReferenceTag;
	SHORT		iReplyCode;
	SHORT		iAppTotMsgCount;
	LONG64		iAppEndSeqNum;
	LONG64		iRefAppLastSeqNum;
		
};	
#pragma pack()

struct OMB_QUERY_TRADE_RECOVERY_REQ
{
        struct OMB_HEADER   pHeader;
        LONG32              iMsgType;
        LONG32              iMsgTag;
	LONG64		    iAppStartNumber;
	LONG64		    iAppEndNumber;
	SHORT		    iPartionId;
	SHORT		    iRefFeild;
	
};

#pragma pack(2)
struct  SUB_ORDER_DLOAD_CONFIRMATION_UMS
{
        LONG32          iScripCode                      ;
        long long       iExchOrdId                        ;
        LONG32          iRate                           ;
        LONG32          iQty                            ;
        LONG32          iPenQty;
        LONG32          iRetention                       ;
        LONG32          iMsgTag                       ;
        LONG32          iTriggerRate                       ;
        CHAR            cOrderType                      ;
        CHAR            cBuySel                         ;
        struct          OMB_BSE_YEAR_SHORT      pOmbYr          ;
        struct          OMB_BSE_TIME    pOmbTime        ;
        CHAR            sClient [BSE_CLIENT_LEN]        ;
        LONG32          iFlag                           ;
        SHORT           iCliType                        ;
	LONG32		iMinQty				;
	long long	iLocationId			;	
        long long       iResField1                      ;
        long long       iFiller3                        ;
        LONG32          iFiller4                        ;
        LONG32          iFiller5                        ;
        CHAR            sAlgoId[BSE_ALGO_ID_LEN]        ;

};
#pragma pack(   )

#pragma pack(2)
struct OMB_ORDER_DLOAD_CONFIRMATION_UMS
{
        struct OMB_HEADER       pHeader;
        LONG32                  iMsgType;
        LONG32                  iNoOfRecords;
        struct SUB_ORDER_DLOAD_CONFIRMATION_UMS  pSubOrdDetails[BSE_ORDER_RECS];
};
#pragma pack( )

#pragma pack(2)
struct  SUB_CANCELLED_DLOAD_CONFIRMATION_UMS
{
        LONG32          iScripCode                      ;
        long long       iExchOrdId                        ;
        LONG32          iRate                           ;
        LONG32          iQty                            ;
        LONG32          iPenQty;
        LONG32          iRetention                       ;
        LONG32          iMsgTag                       ;
        LONG32          iLastTrdId                      ;
        CHAR            cOrderType                      ;
        CHAR            cBuySel                         ;
        struct          OMB_BSE_YEAR_SHORT      pOmbYr          ;
        struct          OMB_BSE_TIME    pOmbTime        ;
        CHAR            sClient [BSE_CLIENT_LEN]        ;
        LONG32          iFlag                           ;
        SHORT           iCliType                        ;
        LONG32          iReservedFld1                         ;
        long long       iLocationId                     ;
        long long       iResField1                      ;
        long long       iFiller3                        ;
        LONG32          iFiller4                        ;
        LONG32          iFiller5                        ;
        CHAR            sFiller[BSE_ALGO_ID_LEN]        ;

};
#pragma pack(   )

#pragma pack(2)
struct OMB_CANCELLED_DLOAD_CONFIRMATION_UMS
{
        struct OMB_HEADER       pHeader;
        LONG32                  iMsgType;
        LONG32                  iNoOfRecords;
        struct SUB_CANCELLED_DLOAD_CONFIRMATION_UMS  pSubOrdDetails[BSE_ORDER_RECS];
};
#pragma pack( )

#pragma pack(2)
struct  SUB_STOPLOSS_DLOAD_CONFIRMATION_UMS
{
        LONG32          iScripCode                      ;
        long long       iExchOrdId                        ;
        LONG32          iTriggerRate                           ;
        LONG32          iRate                           ;
        LONG32          iQty                            ;
        LONG32          iPenQty;
        LONG32          iRetention                       ;
        LONG32          iMsgTag                       ;
        CHAR            cOrderType                      ;
        CHAR            cBuySel                         ;
        struct          OMB_BSE_YEAR_SHORT      pOmbYr          ;
        struct          OMB_BSE_TIME    pOmbTime        ;
        CHAR            sClient [BSE_CLIENT_LEN]        ;
        LONG32          iMktProtection                       ;
        SHORT           iCliType                        ;
        long long       iLocationId                     ;
        long long       iResField1                      ;
        long long       iFiller3                        ;
        LONG32          iFiller4                        ;
        LONG32          iFiller5                        ;
        CHAR            sAlgoId[BSE_ALGO_ID_LEN]        ;

};
#pragma pack(   )

#pragma pack(2)
struct OMB_STOPLOSS_DLOAD_CONFIRMATION_UMS
{
        struct OMB_HEADER       pHeader;
        LONG32                  iMsgType;
        LONG32                  iNoOfRecords;
        struct SUB_STOPLOSS_DLOAD_CONFIRMATION_UMS pSubOrdDetails[BSE_ORDER_RECS];
};
#pragma pack( )

#pragma pack(2)
struct OMB_SERVICE_AVAILABILITY
{
        struct OMB_HEADER       pHeader;
	LONG32			iMsgType;
	LONG64			iSendingTime;
	LONG32			iFiller1;	
	LONG32			iMatchEngineServiceDate;
	LONG32			iTradeMngrServiceDate;
	LONG32			iOrderMngrServiceDate;
	SHORT			iPartitionId;
	CHAR			cMatchingEngineStat;
	CHAR			cTradeMngrStat;
	CHAR			cOrderMngrStat;
	CHAR			cLastFragment;
	CHAR			cFiller1;
			
};
#pragma pack( )
#endif
