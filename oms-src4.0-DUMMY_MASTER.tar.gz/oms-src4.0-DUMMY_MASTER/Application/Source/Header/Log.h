#include <sys/time.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include "IPCS.h"

#define TOSTRING(x) #x
#define CONCAT(x) TOSTRING(x)
#define THIS_LINE __FILE__ ":" CONCAT(__LINE__) ":"

#define  DatabaseErrorFile     "../Log/log.dberror"
#define  SystemErrorFile     "../Log/log.syserror"
#define  FuncErrorFile     "../Log/log.funcerror"
#define  LOG_MESSAGE_SIZE      100

#ifndef ERROR
#define ERROR  -1
#endif

extern LONG32 LogFatal (CHAR * ProgName , CHAR * Message );
extern LONG32 LogMessage (LONG32 id,CHAR * Message );
extern LONG32 LogTimeStamp (CHAR *TimeStamp );

#define LOG_TIMESTAMP_LENGTH 30
#define LOG_BUFFER_LENGTH 5121

