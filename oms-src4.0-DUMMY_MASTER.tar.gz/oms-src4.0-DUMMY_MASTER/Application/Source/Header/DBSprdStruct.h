/**
#pragma pack(4)
struct INT_ORDERS
{
struct		INT_COMMON_REQUEST_HDR	ReqHeader		;
DOUBLE64	fOrdNo						;
SHORT		iSerialNo					;
CHAR		sSecId			[DB_SECURITY_ID_LEN]	;
CHAR            sEntityId		[DB_ENTITY_ID_LEN]     	;
CHAR		sExchOrdNo		[DB_EXCH_ORD_NO_LEN]	;
CHAR            sClientId		[DB_CLIENT_ID_LEN]    	;
CHAR		cBuySellInd					;
CHAR            cOrdStatus					;
CHAR		sSymbol			[DB_SYM_LEN]		;
CHAR		sSymbolName		[DB_SYM_NAME_LEN]	;
CHAR		sSymbolSfx		[DB_SERIES_LEN]		;
CHAR		sEntryDate		[DB_DATETIME_LEN]	;
CHAR		sOrderTime		[DB_DATETIME_LEN]	;
LONG32          iTotalQty				   	;
LONG32          iRemQty					   	;
LONG32          iDiscQty				   	;
LONG32          iDiscRemQty				   	;
LONG32          iTotalTradedQty			 	   	;
DOUBLE64	fOrderPrice					;
DOUBLE64	fTriggerPrice					;
CHAR		sInstrumentType		[DB_INS_LEN]		;
SHORT		iValidity					;
SHORT		iOrderType					;
SHORT		iGoodTillDaysFlg				;
CHAR		sGoodTillDaysDate	[DB_DATETIME_LEN]	;
CHAR		sAccCode		[DB_ACC_CODE_LEN]	;
LONG32          iMinFillQty				   	;
CHAR            cProClient					;
CHAR		sRemarks		[DB_REMARKS_LEN]	;
LONG32		iErrorCode					;
CHAR		cUserType					;
CHAR		cOrderOffOn					;
CHAR		cProductId					;
CHAR		sUserInfo		[DB_USER_INFO_LEN]	;
LONG32		iGrpId						;
LONG32		iReasonCode					;
CHAR		sReasonDesc		[DB_REASON_DESC_LEN]	;
LONG32		iExchTrdNo					;
LONG32		iTrdSerialNo					;
LONG32		iTrdTransCode					;
CHAR		cTrdStatus					;
LONG32		iLstTrdQty					;
DOUBLE64	fTrdPrice					;
CHAR		sTrdTime		[DB_DATETIME_LEN]	;
LONG32		iTrdSeqNo					;
CHAR		cHandleInst					;
DOUBLE64	fAlgoOrderNo					;
SHORT		iStratergyId					;
CHAR		sClOrdId		[CLORDID_LEN]		;
CHAR		sOrigClOrdId		[CLORDID_LEN]		;
CHAR		sLastModTime		[DB_DATETIME_LEN]	;
CHAR		sLocCode		[LOC_CODE_LEN]		;
CHAR		sOptType		[DB_OPT_TYPE_LEN]	;
CHAR		sMaturityMonYr		[MAT_MONYR]		;
CHAR		sMaturityDay		[MAT_DAY]		;				
DOUBLE64	fStrikePrice					;
CHAR            sSeries                 [DB_SERIES_LEN]         ;
LONG32		iMktType					;
};
#pragma pack()
 **/
/***
  struct INT_SPREAD_ORDERS
  {
  struct          INT_COMMON_REQUEST_HDR  ReqHeader               ;
  DOUBLE64        fOrdNo                                          ;
  SHORT           iSerialNo                                       ;
  CHAR            sSecId_L1                  [DB_SECURITY_ID_LEN] ;
  CHAR            sSecId_L2                  [DB_SECURITY_ID_LEN] ;
  CHAR            sEntityId               [DB_ENTITY_ID_LEN]      ;
  CHAR            sExchOrdNo              [DB_EXCH_ORD_NO_LEN]    ;
  CHAR            sClientId               [DB_CLIENT_ID_LEN]      ;	
  CHAR            cBuySellInd_L1                                  ;
  CHAR            cBuySellInd_L2                                  ;
  CHAR            cOrdStatus                                      ;
  CHAR            sSymbol                [DB_SYM_LEN]            ;
  CHAR            sSymbolName            [DB_SYM_NAME_LEN]       ;
  CHAR            sSymbolSfx              [DB_SERIES_LEN]         ;
  CHAR            sEntryDate              [DB_DATETIME_LEN]       ;
  CHAR            sOrderTime              [DB_DATETIME_LEN]       ;
  LONG32          iTotalQty                                       ;
  LONG32          iRemQty                                         ;
  LONG32          iTotalTradedQty                                 ;
  DOUBLE64        fOrderPrice                                     ;
  CHAR            sInstrumentType1        [DB_INS_LEN]            ;
  SHORT           iValidity                                       ;
  SHORT           iOrderType                                      ;
  SHORT           iGoodTillDaysFlg                                ;
  CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
  CHAR            sAccCode                [DB_ACC_CODE_LEN]       ;
  LONG32          iMinFillQty                                     ;
  CHAR            cProClient                                      ;
  CHAR            sRemarks                [DB_REMARKS_LEN]        ;
  LONG32          iErrorCode                                      ;
  CHAR            cUserType                                       ;
  CHAR            cOrderOffOn                                     ;
  CHAR            cProductId                                      ;
  CHAR            sUserInfo               [DB_USER_INFO_LEN]      ;
  LONG32          iGrpId                                          ;
  LONG32          iReasonCode                                     ;
  CHAR            sReasonDesc             [DB_REASON_DESC_LEN]    ;
  LONG32          iExchTrdNo                                      ;
  LONG32          iTrdSerialNo                                    ;
  LONG32          iTrdTransCode                                   ;
  CHAR            cTrdStatus                                      ;
  LONG32          iLstTrdQty                                      ;
  DOUBLE64        fTrdPrice                                       ;
  CHAR            sTrdTime                [DB_DATETIME_LEN]       ;
  LONG32          iTrdSeqNo                                       ;
  CHAR            cHandleInst                                     ;
  DOUBLE64        fAlgoOrderNo                                    ;
  SHORT           iStratergyId                                    ;
  CHAR            sClOrdId                [CLORDID_LEN]           ;
  CHAR            sOrigClOrdId            [CLORDID_LEN]           ;
  CHAR            sLastModTime            [DB_DATETIME_LEN]       ;
  CHAR            sLocCode                [LOC_CODE_LEN]          ;
  CHAR		sOptType		[DB_OPT_TYPE_LEN]	;
  CHAR            sMaturityMonYr          [MAT_MONYR]            	;
  CHAR            sMaturityDate_L1        [DB_DATETIME_LEN]      	;
  CHAR            sMaturityDate_L2        [DB_DATETIME_LEN]       ;
  LONG32		iMaturityDate_L1				;
  LONG32          iMaturityDate_L2                                ;
  DOUBLE64	fStrikePrice					;
  LONG32          iMktType                                        ;
  INT16		iNoOfLeg					;
  CHAR		sOrdCategory		[ORD_CAT_LEN]		;	
  };
 ***/
#pragma pack(4)
struct  SPREAD_SEC_INFO
{
	CHAR            sSecId         	[DB_SECURITY_ID_LEN]    ;
	CHAR            sSymbol        	[DB_SYM_LEN]            ;
	CHAR            cBuySellInd                             ;
	CHAR            sInstrumentType	[DB_INS_LEN]            ;
	CHAR            sMaturityDate  	[MAT_DATE]              ;
	LONG32          iMaturityDate                           ;
	LONG32          iStrikePrice                            ;
	CHAR            sOptionType	[OPT_TYPE_LEN]          ;


};
#pragma pack()


#pragma pack(4)
struct INT_SPREAD_ORDERS
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader                       ;
	DOUBLE64        fOrdNo                                                  ;
	SHORT           iSerialNo                                               ;
	LONG32          iNoOfLeg                ;
	struct          SPREAD_SEC_INFO         SpreadArray [LEG_LEN]           ;
	CHAR            sEntityId               [DB_ENTITY_ID_LEN]              ;
	CHAR            sExchOrdNo              [DB_EXCH_ORD_NO_LEN]            ;
	CHAR            sClientId               [DB_CLIENT_ID_LEN]              ;
	CHAR            cOrdStatus                                              ;
	CHAR            sEntryDate              [DB_DATETIME_LEN]               ;
	CHAR            sOrderTime              [DB_DATETIME_LEN]               ;
	//      LONG32          iTotalQty                                               ;
	//      LONG32          iRemQty                                                 ;
	LONG32          iTotalQty                               		;
	LONG32          iRemQty                           			;
	LONG32          iTotalTradedQty                                         ;
	DOUBLE64        fOrderPrice                                             ;
	DOUBLE64        fTriggerPrice                                           ;
	SHORT           iValidity                                               ;
	SHORT           iOrderType                                              ;
	SHORT           iGoodTillDaysFlg                                        ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]               ;
	CHAR            sAccCode                [DB_ACC_CODE_LEN]               ;
	LONG32          iMinFillQty                                             ;
	CHAR            cProClient                                              ;
	CHAR            sRemarks                [DB_REMARKS_LEN]                ;
	LONG32          iErrorCode                                              ;
	CHAR            cUserType                                               ;
	CHAR            cOrderOffOn                                             ;
	CHAR            cProductId                                              ;
	CHAR            sUserInfo               [DB_USER_INFO_LEN]              ;
	LONG32          iGrpId                                                  ;
	LONG32          iReasonCode                                             ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]            ;
	LONG32          iExchTrdNo                                              ;
	LONG32          iTrdSerialNo                                            ;
	LONG32          iTrdTransCode                                           ;
	CHAR            cTrdStatus                                              ;
	LONG32          iLstTrdQty                                              ;
	DOUBLE64        fTrdPrice                                               ;
	CHAR            sTrdTime                [DB_DATETIME_LEN]               ;
	LONG32          iTrdSeqNo                                               ;
	CHAR            cHandleInst                                             ;
	DOUBLE64        fAlgoOrderNo                                            ;
	SHORT           iStratergyId                                            ;
	CHAR            sClOrdId                [CLORDID_LEN]                   ;
	CHAR            sOrigClOrdId            [CLORDID_LEN]                   ;
	CHAR            sLastModTime            [DB_DATETIME_LEN]               ;
	CHAR            sLocCode                [LOC_CODE_LEN]                  ;
	CHAR            sOptType                [DB_OPT_TYPE_LEN]               ;
	CHAR            sMaturityMonYr          [MAT_MONYR]                     ;
	DOUBLE64        fStrikePrice                                            ;
	LONG32          iMktType                                                ;
	CHAR            sOrdCategory            [ORD_CAT_LEN]           	;	
	CHAR            sPanID                  [INT_PAN_LEN]                   ;
        LONG32          iAlgoId                                                 ;
        SHORT           iAlgoCategory                                           ;

};
#pragma pack()

/*
#pragma pack(4)
struct SUB_ORDER_REQUEST_SPREAD_2L_3L
{
CHAR        sSecurityId[SECURITY_ID_LEN]      ;
CHAR        sBuyOrSell[BUY_SELL_IND_LEN]      ;
LONG32      iDiscQty                          ;
LONG32      iDiscQtyRemaining                 ;
LONG32      iTotalQtyRemaining                ;
LONG32      iTotalQty                         ;
LONG32      iQtyFilledToday                   ;
LONG32      iMinFillQty                       ;
DOUBLE64    fPrice                            ; 
DOUBLE64    fTriggerPrice                     ;
SHORT        iOrderValidity                                                                              ;

};
#pragma pack()





#pragma pack(4)
struct ORDER_REQUEST_SPREAD_2L
{
struct          INT_COMMON_REQUEST_HDR     IntReqHeader ;
CHAR            sEntityId[ENTITY_ID_LEN]                    ;
CHAR            sClientId[CLIENT_ID_LEN]                            ;
CHAR            cProductId                                                                                                                   ;
SHORT           iOrderType                                ;
CHAR            cProCli                                                                                   ;
DOUBLE64        fOrderNum                                   ;
INT16           iSerialNum                                           ;
INT16           iSerialNum1                                 ;                                    
DOUBLE64        fPriceDiff                                        ;              
CHAR            sRemarks[REMARKS_LEN]             ;
CHAR            sSettlor[SOME_LEN]                       ;
INT16           GoodTillDays                                       ;
CHAR            GoodTillDate[DATE_LEN]                      ;
CHAR            SourceFlag                                           ;
CHAR                     cHandleInst                                        ;
struct          SUB_ORDER_REQUEST_SPREAD_2L_3L  sSpread_leg[SPREAD_2L];
CHAR            sParticipantType[SOME_LEN]             ;
CHAR            sParticipantCode[SOME_LEN]            ;
CHAR            sCBrokerCode[BROKER_CODE_LEN]        ;
DOUBLE64        fAlgoOrderNo                            ;
SHORT           iStratergyId                            ;
CHAR            cUserType                               ;

};
#pragma pack()


 */






















