//added following headers files @Suraj
//Start----------
#include "openssl/ssl.h"
#include "openssl/err.h"
#include <time.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <error.h>
//End -------------
# ifndef _QUEUE_H_
# define _QUEUE_H_
#include    <stdio.h>
#include    <string.h>
#include    <signal.h>
#include    <pthread.h>
#include    <fcntl.h>

# include <sys/types.h>
# include <sys/ipc.h>
# include <sys/sem.h>
# include <sys/shm.h>
# include <sys/uio.h>
# include <signal.h>
# include <string.h>
#include    <sys/time.h>
# include <sys/msg.h>
# include <fcntl.h>
#include <wait.h>
#include <errno.h>
//# include <stdlib.h>
//# include <my_global.h>	
//# include <mysql.h>
# include "HashTable.h"	
# include "Defination.h"
# include "IntStruct.h"
# include "DBStruct.h"
//# include "NseEqConnect.h"
//# include "NseEQNNFStruct.h"	
# include "Error.h"
//# include "FIXStructures.h"
# include "IntTCodes.h"
# include "hiredis.h"
/************************/
#define PERMS				0666
/*************************/


/*************/
#define   IPC_RESOURCES_BASE  		atof(getenv("IPC_RESOURCES_BASE"))
#define   IPC_SHM_BASE			atof(getenv("IPC_SHM_BASE"))
#define   IPC_QUEUE_BASE		atof(getenv("IPC_QUEUE_BASE"))
#define   IPC_SHM_MIMLQRY_BASE		atof(getenv("IPC_SHM_MIMLQRY_BASE"))
#define	  IPC_SHM_IMLCONN_BASE		atof(getenv("IPC_SHM_IMLCONN_BASE"))
/*******/

#define 	NO_OF_PACKETS_TO_READ		20
//#define 	MAX_NO_OF_SYSTEM_PROCESS	250
#define 	TRUE				1
#define 	FALSE				0
#define 	ERROR				-1
#define 	MAX_MESSAGE_SIZE                8192
#define		NO_ROW				2
#define		NO_MODIFICATION			3
#define		NO_OFFLINE_ORDER		4
//#define		ORDER_IN_TRANSIT		4
#define		ORDER_TRADED			5
#define 	ORDER_BLOCKED			6
#define		ORDERS_REJECTED			7
#define		ORD_PRICE_MOD_BUY		8
#define		ORD_PRICE_MOD_SELL		9
#define		TRIG_PRICE_MOD_BUY		10
#define		TRIG_PRICE_MOD_SELL		11
#define		ORDER_COMPLETED			12
#define		ORDER_CANCELLED			13


/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/********************************************* Shared Memories  ******************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/

#define  LockSystem_SIZE                100
#define  LockSystem                     (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 1 )

#define  ProcessMonitor_SIZE            sizeof(struct ProcessMonitorArray)
#define  ProcessMonitorShm              (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 2)

#define  LogLevelShm_SIZE               (sizeof(int))
#define  LogLevelShm                    (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 3 )

#define  LogFatalShm                    (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 4 )


#define  ConnStatusShm_SIZE             (sizeof(struct EXCH_CONNECT_STATUS)*(MAX_GROUPS))
#define  ConnStatusShm               	(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 5 )

#define  DWSAdapterUserShm_SIZE         sizeof(struct DWS_ADAPTER_USER_ARRAY)
#define  DWSAdapterUserShm              (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 6)

#define  DirRelShm_SIZE                 sizeof(struct user_relay_array)
#define  DirRelShm                      (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 7)


#define  ProcessDataLock1               (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 8 )


#define Equ_User_Dtl_Shm_SIZE		(sizeof(struct USER_DETAIL_ARRAY))
#define Equ_User_Dtl_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 9 )

#define Temp_Shm_SIZE			(sizeof(struct INT_ORDERS))
#define Temp_Shm			(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 21 )


#define EQ_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define EQ_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 10 )

#define DR_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define DR_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 11 )

#define CR_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define CR_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 12 )

#define CM_SEC_MASTER_Shm_SIZE		(sizeof(struct SEC_MASTER_ARRAY))
#define CM_SEC_MASTER_Shm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 13 )

#define  AdminAdapterUserShm_SIZE       sizeof(struct ADMIN_ADAPTER_USER_ARRAY)
#define  AdminAdapterUserShm            (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 14)

#define  InvitationCountShm_SIZE       	sizeof(struct InvitationCount)
#define  InvitationCountShm 		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 15)

#define	Bse_Conn_Shm_1			(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 16)
#define	Bse_Conn_Shm_2			(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 17)
#define	Bse_Conn_Shm_3			(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 18)
#define	Bse_Conn_Shm_4			(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 19)
#define	Bse_Conn_Shm_SIZE		sizeof(struct IML_INFO_SHM)


#define Bse_CConn_Shm_1                  (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 128)
#define Bse_CConn_Shm_2                  (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 129)
#define Bse_CConn_Shm_3                  (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 130)
#define Bse_CConn_Shm_4                  (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 131)
#define Bse_CConn_Shm_SIZE               sizeof(struct IML_INFO_SHM)

#define  DrvInvitatnCntShm_SIZE       	sizeof(struct InvitationCount)
#define  DrvInvitatnCntShm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 20)


#define  CurrInvitatnCntShm_SIZE       	sizeof(struct InvitationCount)
#define  CurrInvitatnCntShm 		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 21)

#define  MfssInvitatnCntShm_SIZE       	sizeof(struct InvitationCount)
#define  MfssInvitatnCntShm		(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 22)

#define  AdminAdaptQryUserShm_SIZE      sizeof(struct ADMIN_ADAPTER_USER_ARRAY)
#define  AdminAdaptQryUserShm        	(key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 23)

#define  AdmRelShm_SIZE                 sizeof(struct user_relay_array)
#define  AdmRelShm                      (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 24)

#define  AdminQueriesAdapterUserShm_SIZE         sizeof(struct ADMIN_ADAPTER_USER_ARRAY)
#define AdminQueriesAdapterUserShm      (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 25)

#define Bse_CConn_Shm_2                 (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 26)
#define Bse_CConn_Shm_3                 (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 27)
#define Bse_CConn_Shm_4                 (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 28)
#define Bse_CConn_Shm_SIZE              sizeof(struct IML_INFO_SHM)

#define DAEMON_CLIENT_Shm_SIZE         	sizeof(struct DAEMON_CLIENT_LIST)
#define DAEMON_CLIENT_Shm               (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 29)

#define  AdminD2C1AdapterUserShm_SIZE         sizeof(struct ADMIN_ADAPTER_USER_ARRAY)
#define  AdminD2C1AdapterUserShm             (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 30)

#define  DWSD2C1UserShm_SIZE         sizeof(struct DWS_ADAPTER_USER_ARRAY)
#define  DWSD2C1UserShm              (key_t) (IPC_RESOURCES_BASE + IPC_SHM_BASE + 31)
/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/********************************************* Message Queues ********************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
#define RelToOrdRtr                     (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 1 )
#define RelToOrdRtr_SIZE                50000

#define RelToQuery                      (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 2 )
#define RelToQuery_SIZE                 50000

#define QueryToRel                      (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 3 )
#define QueryToRel_SIZE                 50000

#define OrdRtrToOrdSrvBSEEQ             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 4 )
#define OrdRtrToOrdSrvBSEEQ_SIZE        50000

#define OrdRtrToCatalystNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 5 )
#define OrdRtrToCatalystNSEEQ_SIZE	50000

#define CatalystToOrdSrvNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 6 )
#define CatalystToOrdSrvNSEEQ_SIZE	50000

#define OrdRtrToCatalystDR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 7 )
#define OrdRtrToCatalystDR_SIZE        	50000

#define OrdRtrToOrdSrvNSECR             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 8 )
#define OrdRtrToOrdSrvNSECR_SIZE        50000

#define OrdRtrToOrdSrvMCX             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 9 )
#define OrdRtrToOrdSrvMCX_SIZE        	50000

#define OrdSrvToTrdRtr                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 10 )
#define OrdSrvToTrdRtr_SIZE             50000

#define OrdSrvToMapperBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 11 )
#define OrdSrvToMapperBSEEQ_SIZE	50000

#define OrdSrvToMapperNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 12 )
#define OrdSrvToMapperNSEEQ_SIZE	50000

#define OrdSrvToMapperNSEDR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 13 )
#define OrdSrvToMapperNSEDR_SIZE	50000

#define OrdSrvToMapperNSECR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 14 )
#define OrdSrvToMapperNSECR_SIZE	50000

#define OrdSrvToFwdMapMCX		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 15 )
#define OrdSrvToFwdMapMCX_SIZE		50000

#define OrdSrvToMapperBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 16 )
#define OrdSrvToMapperBSEEQ_SIZE	50000
/****
#define FwdMapToInterfaceBSEEQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 16 )
#define FwdMapToInterfaceBSEEQ_SIZE     50000
 **/
#define ConnToInterfaceNSEEQ          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 17 )
#define ConnToInterfaceNSEEQ_SIZE     	50000
/**
#define ConnToInterfaceNSEDR          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 18 )
#define ConnToInterfaceNSEDR_SIZE     	50000

#define ConnToInterfaceNSECR          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 19 )
#define ConnToInterfaceNSECR_SIZE     	50000

 ****/
#define FwdMapToInterfaceMCX          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 20 )
#define FwdMapToInterfaceMCX_SIZE     	50000

#define ConnToTrdMapBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 21 )
#define ConnToTrdMapBSEEQ_SIZE     	50000

#define ConnToTrdMapNSEEQ          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 22 )
#define ConnToTrdMapNSEEQ_SIZE     	50000

#define ConnToTrdMapNSEDR          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 23 )
#define ConnToTrdMapNSEDR_SIZE     	50000

#define ConnToTrdMapNSECR          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 24 )
#define ConnToTrdMapNSECR_SIZE     	50000

#define InterfaceToRevMapMCX          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 25 )
#define InterfaceToRevMapMCX_SIZE     	50000

#define RevMapToTrdSrvBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 26 )
#define RevMapToTrdSrvBSEEQ_SIZE	50000

#define RevMapToTrdSrvNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 27 )
#define RevMapToTrdSrvNSEEQ_SIZE	50000

#define RevMapToTrdSrvNSEDR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 28 )
#define RevMapToTrdSrvNSEDR_SIZE	50000

#define RevMapToTrdSrvNSECR		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 29 )
#define RevMapToTrdSrvNSECR_SIZE	50000

#define RevMapToTrdSrvMCX		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 30 )
#define RevMapToTrdSrvMCX_SIZE		50000

#define TrdSrvToRMS			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 31 )
#define TrdSrvToRMS_SIZE		50000

#define TrdSrvToTrdRtr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 32 )
#define TrdSrvToTrdRtr_SIZE		50000

#define TrdRtrToDWSMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 33 )
#define TrdRtrToDWSMMap_SIZE		50000

#define TrdRtrToWebAdap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 34 )
#define TrdRtrToWebAdap_SIZE		50000

#define	ENBAdapToSpltr			(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 35 )
#define ENBAdapToSpltr_SIZE		50000

#define ENBSpltrToMbpUpld		(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 36 )
#define ENBSpltrToMbpUpld_SIZE		50000

#define ENBSpltrToIndxUpld		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 37 )
#define ENBSpltrToIndxUpld_SIZE		50000

#define ENBSpltrToMStatUpld		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 38 )
#define	ENBSpltrToMStatUpld_SIZE	50000

#define TrdRtrToRevRmsVal		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 39 )
#define	TrdRtrToRevRmsVal_SIZE		50000

#define RDaemonToSqoff			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 40 )
#define	RDaemonToSqoff_SIZE		50000

#define RDaemonToOffPump            	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 41 )
#define RDaemonToOffPump_SIZE        	5000

#define D2C1ToAdminAdap 		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 42 )
#define D2C1ToAdminAdap_SIZE             50000

#define TrdRtrToD2C1MMap                (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 43 )
#define TrdRtrToD2C1MMap_SIZE           50000

#define OffPumperToOrdRtr               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 44 )
#define OffPumperToOrdRtr_SIZE           50000

#define OrdRtrToOffOrd                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 45 )
#define OrdRtrToOffOrd_SIZE             50000

#define OffOrdToTrdRtr                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 46 )
#define OffOrdToTrdRtr_SIZE             50000

//#define DWSQryToAdap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 47 )
//#define DWSQryToAdap_SIZE             	50000

#define TrdRtrToAdminMMap		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 48 )
#define TrdRtrToAdminMMap_SIZE          50000

#define D2C1ToDWSAdap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 49 )
#define D2C1ToDWSAdap_SIZE              50000

#define DNBAdapToSpltr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 50 )
#define DNBAdapToSpltr_SIZE              50000

#define CNBAdapToSpltr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 51 )
#define CNBAdapToSpltr_SIZE              50000

#define CNBSpltrToMbpUpld 		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 52 )
#define CNBSpltrToMbpUpld_SIZE           50000

#define DNBSpltrToMbpUpld               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 53 )
#define DNBSpltrToMbpUpld_SIZE           50000

#define EBAAdapToSpltr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 54 )
#define EBAAdapToSpltr_SIZE              50000

#define EBASpltrToMbpUpld               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 55 )
#define EBASpltrToMbpUpld_SIZE           50000

#define EBABSpltrToIdxUpld              (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 56 )
#define EBABSpltrToIdxUpld_SIZE           50000

#define EBABSpltrToMktSts              	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 57 )
#define EBABSpltrToMktSts_SIZE           50000

#define DNBcasttoMktStatus		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 58 )
#define DNBcasttoMktStatus_SIZE          50000

#define OrdRtrToCon2Del			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 59 )
#define OrdRtrToCon2Del_SIZE           	50000

#define CurSpltrToMktSts		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 60 )
#define CurSpltrToMktSts_SIZE		50000

#define MCXAdapToUpdtr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 61 )
#define MCXAdapToUpdtr_SIZE              50000

#define CatalystToOrdSrvDRV		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 62 )
#define CatalystToOrdSrvDRV_SIZE	50000

#define TrdRtrToSysMsg			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 63 )
#define TrdRtrToSysMsg_SIZE		50000

#define OrdRtrToOrdSrvSIP		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 64 )
#define OrdRtrToOrdSrvSIP_SIZE 		50000

#define OrdSrvSIPToTrdRtr		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 65 )
#define OrdSrvSIPToTrdRtr_SIZE		50000

#define OrdRtrToCatalystSIP_EQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 66 )
#define OrdRtrToCatalystSIP_EQ_SIZE     50000

#define EquNSEToRmsNse 			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 67 )
#define EquNSEToRmsNse_SIZE		50000

#define DrvNseToRmsnse			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 68 )
#define DrvNseToRmsnse_SIZE		50000

#define	CurrNseToRmsnse			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 69 )
#define CurrNseToRmsnse_SIZE             50000

#define MapperToConnBSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 72 )
#define	MapperToConnBSEEQ_SIZE		50000

#define OrdRtrToOrdSrvNSEMF		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 74 )
#define	OrdRtrToOrdSrvNSEMF_SIZE	50000

#define OrdSrvNSEMFToTrdRtr 		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 75 )
#define	OrdSrvNSEMFToTrdRtr_SIZE	50000

#define OrdSrvNSEMFToMFSSAdap		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 76 )
#define OrdSrvNSEMFToTrdRtr_SIZE	50000

#define MapperToConnNSEEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 77 )
#define MapperToConnNSEEQ_SIZE		50000

#define MapperToConnNSEFO		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 78 )
#define MapperToConnNSEFO_SIZE		50000

#define MapperToConnNSECD		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 79 )
#define MapperToConnNSECD_SIZE		50000

#define OrdRtrToDeaNotify               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 80 )
#define OrdRtrToDeaNotify_SIZE          50000

#define MmapToENMapTrd			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 81 )
#define MmapToENMapTrd_SIZE		50000

#define MmapToRevRmsVal			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 82 )
#define MmapToRevRmsVal_SIZE		50000

#define BOTradeSvrToPumper		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 83 )
#define BOTradeSvrToPumper_SIZE		50000

#define DrBOTradeSvrToPumper		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 84 )
#define DrBOTradeSvrToPumper_SIZE	 50000

#define CurBOTradeSvrToPumper		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 86 )
#define CurBOTradeSvrToPumper_SIZE	50000
//#define RDaemonToSIPSqrOff		(Key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 84 )
//#define RDaemonToSIPSqrOff_SIZE		50000
#define ENMbpToLTPUpd			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 85 )
#define ENMbpToLTPUpd_SIZE	 	50000

#define CatalystToRmsVal		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 87 )
#define CatalystToRmsVal_SIZE		50000

#define	AdaptorToQuery			(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 88 )
#define	AdaptorToQuery_SIZE		50000

#define	RDaemonToMtmSqoff		(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 89)
#define	RDaemonToMtmSqoff_SIZE		50000

#define	AdminQueriesToAdaptor		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 90)
#define	AdminQueriesToAdaptor_SIZE	50000

#define	DWSAdapToDWSMediator		(key_t)	(IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 91)
#define	DWSAdapToDWSMediator_SIZE	50000

#define	DWSMediatorToDWSAdap		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 92)
#define	DWSMediatorToDWSAdap_SIZE	50000

#define OrdRtrToAdminMsg		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 93)
#define OrdRtrToAdminMsg_SIZE		50000

#define	AdaptorToAdminQry		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 94) 
#define	AdaptorToAdminQry_SIZE		50000

#define BEBOTradeSvrToPumper		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 95)
#define BEBOTradeSvrToPumper_SIZE	50000

#define AdapToRangeQry			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 96)
#define AdapToRangeQry_SIZE		50000

#define RangeQryToAdap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 97)
#define RangeQryToAdap			50000

#define InterfaceToRevMapNSEEQ          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 98 )
#define InterfaceToRevMapNSEEQ_SIZE     50000

#define InterfaceToRevMapNSEDR          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 99 )
#define InterfaceToRevMapNSEDR_SIZE     50000

#define FwdMapToInterfaceNSEEQ         	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 100 )
#define FwdMapToInterfaceNSEEQ_SIZE     50000

#define OrdSrvToFwdMapNSEEQ           	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 101 )
#define OrdSrvToFwdMapNSEEQ_SIZE     	50000

#define	TrdSvrEQToBoTrailer		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 102 )
#define	TrdSvrEQToBoTrailer_SIZE	50000

#define EQCOTradeSvrToPumper            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 103 )
#define EQCOTradeSvrToPumper_SIZE       50000

#define FoCrCOTradeSvrToPumper          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 104 )
#define FoCrCOTradeSvrToPumper_SIZE      50000

#define	OrderRtrToCalMrg		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 105 )
#define OrderRtrToCalMrg_SIZE       	50000

#define OrderRtrToCalMrgCat             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 106 )
#define OrderRtrToCalMrgCat_SIZE        50000

#define	BEqBoTradeSvrToPumper		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 107 )
#define	BEqBoTradeSvrToPumper_SIZE     	50000

#define MCXCOTradeSvrToPumper		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 108 )
#define MCXCOTradeSvrToPumper_SIZE	50000

#define CatalystToOrdSrvCOMM		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 109 )
#define CatalystToOrdSrvCOMM_SIZE	50000

#define DWSQryToAdap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 110 )
#define DWSQryToAdap_SIZE             	50000

#define MmapToAdmnTrdRtr                (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 111 )
#define MmapToAdmnTrdRtr_SIZE           50000

#define MmapToD2C1                      (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 112 )
#define MmapToD2C1_SIZE                 50000

#define AdmTrdRtrToAdmAdap              (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 113 )
#define AdmTrdRtrToAdmAdap_SIZE         50000

#define MmapToDWSTrdRtr			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 114 )
#define MmapToDWSTrdRtr_SIZE			50000

#define DWSTrdRtrToDWSAdp		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 115 )
#define DWSTrdRtrToDWSAdp_SIZE		50000

#define TrdRtrToRel			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 116 )
#define TrdRtrToRel_SIZE          	50000	

#define RelToDWSMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 117 )
#define RelToDWSMap_SIZE                50000

#define TrdRtrToRevMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 118 )
#define TrdRtrToRevMap_SIZE             50000

#define RevMapToDWSRel			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 119 )
#define RevMapToDWSRel_SIZE             50000

#define TrdRtrToD2C                	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 120 )
#define TrdRtrToD2C_SIZE           	50000

#define OrdRtrToOrdSrvBSECD         	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 121 )
#define OrdRtrToOrdSrvBSECD_SIZE       	50000

#define OrdSrvToMapperBSECD         	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 122 )
#define OrdSrvToMapperBSECD_SIZE       	50000

#define MapperToConnBSECD         	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 123 )
#define MapperToConnBSECD_SIZE       	50000

#define ConnToTrdMapBSECD         	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 124 )
#define ConnToTrdMapBSECD_SIZE       	50000

#define RevMapToTrdSrvBSECD         	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 125 )
#define RevMapToTrdSrvBSECD_SIZE       	50000

#define BCdBoTradeSvrToPumper           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 126 )
#define BCdBoTradeSvrToPumper_SIZE      50000

#define TrdSvrCDToBoTrailer             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 127 )
#define TrdSvrCDToBoTrailer_SIZE        50000

#define DNMbpToLtpUdr             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 128 )
#define DNMbpToLtpUdr_SIZE        	50000

#define CNMbpToLtpUdr             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 129 )
#define CNMbpToLtpUdr_SIZE        	50000

#define ComMbpToLtpUdr             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 130 )
#define ComMbpToLtpUdr_SIZE        	50000


//###############################################///

#define OrdRtrToBComOrderSvr             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 131 )
#define OrdRtrToBComOrderSvr_SIZE        	50000

#define BComOrdSrvToMapper             		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 132 )
#define BComOrdSrvToMapper_SIZE        		50000

#define BComMapToConn             		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 133 )
#define BComMapToConn_SIZE        		50000

#define BComConToRevMap             		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 134 )
#define BComConToRevMap_SIZE        		50000

#define BComRevMapToTrdSvr             		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 135 )
#define BComRevMapToTrdSvr_SIZE        		50000

#define BComTrdSvrToTrdRtr             		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 136 )
#define BComTrdSvrToTrdRtr_SIZE        		50000

#define BComOrdSvrToTrdRtr             		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 137 )
#define BComOrdSvrToTrdRtr_SIZE        		50000


#define OrdRtrToCatalystNseCM                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 138 )
#define OrdRtrToCatalystNseCM_SIZE                   50000

#define CatalystToOrdSvrNseCM                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 139 )
#define CatalystToOrdSvrNseCM_SIZE                   50000

#define OrdSvrCMToTrdRtrCM                           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 140 )
#define OrdSvrCMToTrdRtrCM_SIZE                      50000

#define OrdSvrCMToMapperNseCM                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 141 )
#define OrdSvrCMToMapperNseCM_SIZE                   50000

#define MapperNseCMToConNseCM                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 142 )
#define MapperNseCMToConNseCM_SIZE                   50000

#define ConNseCMToTrdMapNseCM                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 143 )
#define ConNseCMToTrdMapNseCM_SIZE                   50000

#define RevMapNseCMToTrdSvrCM                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 144 )
#define RevMapNseCMToTrdSvrCM_SIZE                   50000

#define TrdSvrCMToTrdRtrCM                           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 145 )
#define TrdSvrCMToTrdRtrCM_SIZE                      50000

#define TrdRtrToTradeMobMMap                           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 146 )
#define TrdRtrToTradeMobMMap_SIZE                      50000

#define MmapToNotifyFE                         	 (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 147 )
#define MmapToNotifyFE_SIZE                      50000

#define NCMInvitatnCntShm				(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 148 )	
#define NCMInvitatnCntShm_SIZE				50000

#define ComCOBOTradeSvrToPumper				(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 149 )
#define ComCOBOTradeSvrToPumper_SIZE			50000


#define OrdSrvToMapperBSEDR                         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 150 )
#define OrdSrvToMapperBSEDR_SIZE                    50000


#define OrdRtrToOrdSrvBSEDR                         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 151 )
#define OrdRtrToOrdSrvBSEDR_SIZE                    50000

#define MapperToConnBSEDR                            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 152 )
#define MapperToConnBSEDR_SIZE                        50000

#define ConnToTrdMapBSEDR                         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 153 )
#define ConnToTrdMapBSEDR_SIZE                      50000

#define RevMapToTrdSrvBSEDR             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 154 )
#define RevMapToTrdSrvBSEDR_SIZE        	50000

#define RevMapToTrdSrvBSEDR             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 155 )
#define RevMapToTrdSrvBSEDR_SIZE        	50000

#define BDrBoTradeSvrToPumper           	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 156 )
#define BDrBoTradeSvrToPumper_SIZE      	50000

#define TrdSvrDRToBoTrailer             	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 157 )
#define TrdSvrDRToBoTrailer_SIZE        	50000

#define CBAAdapToSpltr                  	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 158 )
#define CBAAdapToSpltr_SIZE             	50000

#define CBASpltrToMbpUpld               	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 159 )
#define CBASpltrToMbpUpld_SIZE          	50000

#define CBABSpltrToMktSts               	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 160 )
#define CBABSpltrToMktSts_SIZE          	50000

#define CBABSpltrToIdxUpld              	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 161 )
#define CBABSpltrToIdxUpld_SIZE         	50000

#define DBAAdapToSpltr                  	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 162 )
#define DBAAdapToSpltr_SIZE             	50000

#define DBASpltrToMbpUpld               	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 163 )
#define DBASpltrToMbpUpld_SIZE          	50000

#define DBABSpltrToMktSts               	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 164 )
#define DBABSpltrToMktSts_SIZE          	50000

#define DBABSpltrToIdxUpld              	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 165 )
#define DBABSpltrToIdxUpld_SIZE         	50000

#define BComBoTradeSvrToPumper			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 166 )
#define BComBoTradeSvrToPumper_SIZE             50000

#define COMBAdapToSpltr				(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 167 )
#define COMBAdapToSpltr_SIZE  	          	 50000

#define COMBSpltrToMbpUpld			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 168 )
#define COMBSpltrToMbpUpld_SIZE  	         50000
		
#define COMBcasttoMktStatus			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 169 )
#define COMBcasttoMktStatus_SIZE  	         50000

#define	TrdSvrNEQToTrdMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 170 )
#define	TrdSvrNEQToTrdMMap_SIZE			50000

#define	TrdSvrNFOToTrdMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 171 )
#define	TrdSvrNFOToTrdMMap_SIZE			50000

#define	TrdSvrNCDToTrdMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 172 )
#define	TrdSvrNCDToTrdMMap_SIZE			50000

#define	TrdSvrBEQToTrdMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 173 )
#define	TrdSvrBEQToTrdMMap_SIZE			50000

#define	TrdSvrMCXToTrdMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 174 )
#define	TrdSvrMCXToTrdMMap_SIZE			50000

#define COMBAAdapToSpltr                        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 175 )
#define COMBAAdapToSpltr_SIZE                   50000

#define COMBASpltrToMbpUpld                     (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 176 )
#define COMBASpltrToMbpUpld_SIZE                50000

#define COMBABSpltrToMktSts                     (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 177 )
#define COMBABSpltrToMktSts_SIZE                50000

#define COMBABSpltrToIdxUpld                    (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 178 )
#define COMBABSpltrToIdxUpld_SIZE               50000

#define OrdRtrToOrdSrvBSECOM                    (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 179 )
#define OrdRtrToOrdSrvBSECOM_SIZE               50000

#define OrdRtrToCatalystBSEEQ           	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 180 )
#define OrdRtrToCatalystBSEEQ_SIZE      	50000

#define CatalystToOrdSrvBSEEQ           	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 181 )
#define CatalystToOrdSrvBSEEQ_SIZE      	50000

#define MMAPToConnBSEEQ				(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 182 )
#define	MMAPToConnBSEEQ_SIZE			50000

#define ConnBSEEQToRevMMap			(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 183 )
#define	ConnBSEEQToRevMMap_SIZE			50000

/*----------------Nse Bcast New Queue @ntitish Start	---------------*/
#define ENBcastMemToSpltr			  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 184 )
#define ENBcastMemToSpltr_SIZE                    50000

#define ENSptrMemToMbpUpdt			  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 185 )
#define ENSptrMemToMbpUpdt_SIZE                   50000

#define DNBcastMemToSpltr			  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 186 )
#define DNBcastMemToSpltr_SIZE                    50000

#define DNSptrMemToMbpUpdt			  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 187 )
#define DNSptrMemToMbpUpdt_SIZE                   50000

#define CNBcastMemToSpltr			  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 188 )
#define CNBcastMemToSpltr_SIZE                    50000

#define CNSptrMemToMbpUpdt			  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 189 )
#define CNSptrMemToMbpUpdt_SIZE                   50000

#define FwdMMapToConAdapNSECM                    (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 190 )
#define FwdMMapToConAdapNSECM_SIZE               50000

#define FwdMMapToConAdapNSEFO                    (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 191 )
#define FwdMMapToConAdapNSEFO_SIZE               50000

#define FwdMMapToConAdapNSECD                    (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 192 )
#define FwdMMapToConAdapNSECD_SIZE               50000

#define OrdRtrToOrdSrvICEX             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 200 )
#define OrdRtrToOrdSrvICEX_SIZE       50000

#define OrdSrvToFwdMapICEX             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 201 )
#define OrdSrvToFwdMapICEX_SIZE       50000

#define FwdMapToInterfaceICEX          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 202 )
#define FwdMapToInterfaceICEX_SIZE    50000

#define InterfaceToRevMapICEX          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 203 )
#define InterfaceToRevMapICEX_SIZE    50000

#define RevMapToTrdSrvICEX             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 204 )
#define RevMapToTrdSrvICEX_SIZE       50000

#define ICEXAdapToUpdtr                (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 205 )
#define ICEXAdapToUpdtr_SIZE           50000

#define ICEXCOTradeSvrToPumper         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 206 )
#define ICEXCOTradeSvrToPumper_SIZE    50000

#define TrdSvrICEXToTrdMMap            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 207 )
#define TrdSvrICEXToTrdMMap_SIZE       50000

#define MemMaptoNotifyCatalyst          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 208 )
#define MemMaptoNotifyCatalyst_SIZE     50000

#define MemMaptoServerDaemon          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 209)
#define MemMaptoServerDaemon_SIZE     	50000

#define ClientDaemonToMemMap          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 210 )
#define ClientDaemonToMemMap_SIZE     	50000

#define IntSqrOffToMemMap          	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 211 )
#define IntSqrOffToMemMap_SIZE     	50000

#define TrdCatalystToRevMMap_1            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 212 )
#define TrdCatalystToRevMMap_1_SIZE       50000

#define TrdCatalystToRevMMap_2            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 213 )
#define TrdCatalystToRevMMap_2_SIZE       50000

#define TrdCatalystToRevMMap_3            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 214 )
#define TrdCatalystToRevMMap_3_SIZE       50000

#define TrdCatalystToRevMMap_4            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 215 )
#define TrdCatalystToRevMMap_4_SIZE       50000

#define TrdCatalystToRevMMap_5            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 216 )
#define TrdCatalystToRevMMap_5_SIZE       50000

#define TrdCatalystToRevMMap_6            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 217 )
#define TrdCatalystToRevMMap_6_SIZE       50000

#define TrdCatalystToRevMMap_7            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 218 )
#define TrdCatalystToRevMMap_7_SIZE       50000

#define TrdCatalystToRevMMap_8            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 219 )
#define TrdCatalystToRevMMap_8_SIZE       50000

#define TrdCatalystToRevMMap_9            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 220 )
#define TrdCatalystToRevMMap_9_SIZE       50000

#define RevMapToTrdSrvNSEEQ_2           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 221 )
#define RevMapToTrdSrvNSEEQ_2_SIZE      50000

#define RevMapToTrdSrvNSEEQ_3           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 222 )
#define RevMapToTrdSrvNSEEQ_3_SIZE      50000

#define RevMapToTrdSrvNSEEQ_4           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 223 )
#define RevMapToTrdSrvNSEEQ_4_SIZE      50000

#define RevMapToTrdSrvNSEEQ_5           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 224 )
#define RevMapToTrdSrvNSEEQ_5_SIZE      50000

#define RevMapToTrdSrvNSEEQ_6           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 225 )
#define RevMapToTrdSrvNSEEQ_6_SIZE      50000

#define RevMapToTrdSrvNSEEQ_7           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 226 )
#define RevMapToTrdSrvNSEEQ_7_SIZE      50000

#define RevMapToTrdSrvNSEEQ_8           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 227 )
#define RevMapToTrdSrvNSEEQ_8_SIZE      50000

#define RevMapToTrdSrvNSEEQ_9           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 228 )
#define RevMapToTrdSrvNSEEQ_9_SIZE      50000

#define RevMMapToRevMapNSEEQ_1          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 229 )
#define RevMMapToRevMapNSEEQ_1_SIZE     50000

#define RevMMapToRevMapNSEEQ_2          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 230 )
#define RevMMapToRevMapNSEEQ_2_SIZE     50000

#define RevMMapToRevMapNSEEQ_3          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 231 )
#define RevMMapToRevMapNSEEQ_3_SIZE     50000

#define RevMMapToRevMapNSEEQ_4          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 232 )
#define RevMMapToRevMapNSEEQ_4_SIZE     50000

#define RevMMapToRevMapNSEEQ_5          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 233 )
#define RevMMapToRevMapNSEEQ_5_SIZE     50000

#define RevMMapToRevMapNSEEQ_6          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 234 )
#define RevMMapToRevMapNSEEQ_6_SIZE     50000

#define RevMMapToRevMapNSEEQ_7          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 235 )
#define RevMMapToRevMapNSEEQ_7_SIZE     50000

#define RevMMapToRevMapNSEEQ_8          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 236 )
#define RevMMapToRevMapNSEEQ_8_SIZE     50000

#define RevMMapToRevMapNSEEQ_9          (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 237 )
#define RevMMapToRevMapNSEEQ_9_SIZE     50000

#define RevMapToTrdSrvNSEEQ_1           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 238 )
#define RevMapToTrdSrvNSEEQ_1_SIZE      50000

#define OrdRtrToGTTOrd                  (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 239 )
#define OrdRtrToGTTOrd_SIZE             50000

#define DNBcasttoSAddMktStatus		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 240 )
#define DNBcasttoSAddMktStatus_SIZE     50000

#define RevMapToMemMapBSEEQ_1           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 241 )
#define RevMapToMemMapBSEEQ_1_SIZE      50000

#define RevMapToMemMapBSEEQ_2           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 242 )
#define RevMapToMemMapBSEEQ_2_SIZE      50000

#define RevMapToMemMapBSEEQ_3           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 243 )
#define RevMapToMemMapBSEEQ_3_SIZE      50000

#define RevMapToMemMapBSEEQ_4           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 244 )
#define RevMapToMemMapBSEEQ_4_SIZE      50000

#define RevMapToMemMapBSEEQ_5           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 245 )
#define RevMapToMemMapBSEEQ_5_SIZE      50000

#define RevMapToMemMapBSEEQ_6           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 246 )
#define RevMapToMemMapBSEEQ_6_SIZE      50000

#define RevMapToMemMapBSEEQ_7           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 247 )
#define RevMapToMemMapBSEEQ_7_SIZE      50000

#define RevMapToMemMapBSEEQ_8           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 248 )
#define RevMapToMemMapBSEEQ_8_SIZE      50000

#define RevMapToMemMapBSEEQ_9           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 249 )
#define RevMapToMemMapBSEEQ_9_SIZE      50000

#define MemMapToTrdSvrBSEEQ_1           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 250 )
#define MemMapToTrdSvrBSEEQ_1_SIZE      50000

#define MemMapToTrdSvrBSEEQ_2           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 251 )
#define MemMapToTrdSvrBSEEQ_2_SIZE      50000

#define MemMapToTrdSvrBSEEQ_3           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 252 )
#define MemMapToTrdSvrBSEEQ_3_SIZE      50000

#define MemMapToTrdSvrBSEEQ_4           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 253 )
#define MemMapToTrdSvrBSEEQ_4_SIZE      50000

#define MemMapToTrdSvrBSEEQ_5           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 254 )
#define MemMapToTrdSvrBSEEQ_5_SIZE      50000

#define MemMapToTrdSvrBSEEQ_6           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 255 )
#define MemMapToTrdSvrBSEEQ_6_SIZE      50000

#define MemMapToTrdSvrBSEEQ_7           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 256 )
#define MemMapToTrdSvrBSEEQ_7_SIZE      50000

#define MemMapToTrdSvrBSEEQ_8           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 257 )
#define MemMapToTrdSvrBSEEQ_8_SIZE      50000

#define MemMapToTrdSvrBSEEQ_9           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 258 )
#define MemMapToTrdSvrBSEEQ_9_SIZE      50000

#define CurSpltrToSAddMktSts            (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 259 )
#define CurSpltrToSAddMktSts_SIZE       50000

#define CatalystToOrdSrvMCX           	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 260 )
#define CatalystToOrdSrvMCX_SIZE       	50000

#define CatalystToOrdSrvNCr            	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 261 )
#define CatalystToOrdSrvNCr_SIZE       	50000

#define ENBSpltrToSAddMStatUpld         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 262 )
#define ENBSpltrToSAddMStatUpld_SIZE    50000

#define CatalystToOrdSrvBSECD_1           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 263)
#define CatalystToOrdSrvBSECD_1_SIZE      50000

#define CatalystToOrdSrvBSECD_2           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 264)
#define CatalystToOrdSrvBSECD_2_SIZE      50000

#define CatalystToOrdSrvBSECD_3           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 265)
#define CatalystToOrdSrvBSECD_3_SIZE      50000

#define CatalystToOrdSrvBSECD_4           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 266)
#define CatalystToOrdSrvBSECD_4_SIZE      50000

#define CatalystToOrdSrvBSECD_5           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 267)
#define CatalystToOrdSrvBSECD_5_SIZE      50000

#define CatalystToOrdSrvBSECD_6           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 268)
#define CatalystToOrdSrvBSECD_6_SIZE      50000

#define CatalystToOrdSrvBSECD_7           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 269)
#define CatalystToOrdSrvBSECD_7_SIZE      50000

#define CatalystToOrdSrvBSECD_8           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 270)
#define CatalystToOrdSrvBSECD_8_SIZE      50000

#define CatalystToOrdSrvBSECD_9           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 271)
#define CatalystToOrdSrvBSECD_9_SIZE      50000

#define RevMapToMemMapBSECD_1           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 272 )
#define RevMapToMemMapBSECD_1_SIZE      50000

#define RevMapToMemMapBSECD_2           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 273 )
#define RevMapToMemMapBSECD_2_SIZE      50000

#define RevMapToMemMapBSECD_3           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 274 )
#define RevMapToMemMapBSECD_3_SIZE      50000

#define RevMapToMemMapBSECD_4           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 275 )
#define RevMapToMemMapBSECD_4_SIZE      50000

#define RevMapToMemMapBSECD_5           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 276 )
#define RevMapToMemMapBSECD_5_SIZE      50000

#define RevMapToMemMapBSECD_6           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 277 )
#define RevMapToMemMapBSECD_6_SIZE      50000

#define RevMapToMemMapBSECD_7           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 278 )
#define RevMapToMemMapBSECD_7_SIZE      50000

#define RevMapToMemMapBSECD_8           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 279 )
#define RevMapToMemMapBSECD_8_SIZE      50000

#define RevMapToMemMapBSECD_9           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 280 )
#define RevMapToMemMapBSECD_9_SIZE      50000

#define MemMapToTrdSvrBSECD_1           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 281 )
#define MemMapToTrdSvrBSECD_1_SIZE      50000

#define MemMapToTrdSvrBSECD_2           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 282 )
#define MemMapToTrdSvrBSECD_2_SIZE      50000

#define MemMapToTrdSvrBSECD_3           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 283 )
#define MemMapToTrdSvrBSECD_3_SIZE      50000

#define MemMapToTrdSvrBSECD_4           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 284 )
#define MemMapToTrdSvrBSECD_4_SIZE      50000

#define MemMapToTrdSvrBSECD_5           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 285 )
#define MemMapToTrdSvrBSECD_5_SIZE      50000

#define MemMapToTrdSvrBSECD_6           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 286 )
#define MemMapToTrdSvrBSECD_6_SIZE      50000

#define MemMapToTrdSvrBSECD_7           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 287 )
#define MemMapToTrdSvrBSECD_7_SIZE      50000

#define MemMapToTrdSvrBSECD_8           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 288 )
#define MemMapToTrdSvrBSECD_8_SIZE      50000

#define MemMapToTrdSvrBSECD_9           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 289 )
#define MemMapToTrdSvrBSECD_9_SIZE      50000

#define KafkaToNotify		        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 290 )
#define KafkaToNotify_SIZE      50000

#define D2C1ToDWSD2C1Adap               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 291 )
#define D2C1ToDWSD2C1Adap_SIZE          50000

#define D2C1ToAdminD2C1Adap               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 292 )
#define D2C1ToAdminD2C1Adap_SIZE          50000

#define CatalystToOrdSrvNSEEQ_1        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 293 )
#define CatalystToOrdSrvNSEEQ_1_SIZE    50000

#define CatalystToOrdSrvNSEEQ_2        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 294 )
#define CatalystToOrdSrvNSEEQ_2_SIZE    50000

#define CatalystToOrdSrvNSEEQ_3        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 295 )
#define CatalystToOrdSrvNSEEQ_3_SIZE    50000

#define CatalystToOrdSrvNSEEQ_4        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 296 )
#define CatalystToOrdSrvNSEEQ_4_SIZE    50000

#define CatalystToOrdSrvNSEEQ_5        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 297 )
#define CatalystToOrdSrvNSEEQ_5_SIZE    50000

#define CatalystToOrdSrvNSEEQ_6        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 298 )
#define CatalystToOrdSrvNSEEQ_6_SIZE    50000

#define CatalystToOrdSrvNSEEQ_7        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 299 )
#define CatalystToOrdSrvNSEEQ_7_SIZE    50000

#define CatalystToOrdSrvNSEEQ_8        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 300 )
#define CatalystToOrdSrvNSEEQ_8_SIZE    50000

#define CatalystToOrdSrvNSEEQ_9        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 301 )
#define CatalystToOrdSrvNSEEQ_9_SIZE    50000

#define CatalystToOrdSrvNSEEQ_10        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 302 )
#define CatalystToOrdSrvNSEEQ_10_SIZE    50000

#define CatalystToOrdSrvNSEEQ_11        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 303 )
#define CatalystToOrdSrvNSEEQ_11_SIZE    50000

#define CatalystToOrdSrvNSEEQ_12        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 304 )
#define CatalystToOrdSrvNSEEQ_12_SIZE    50000

#define CatalystToOrdSrvNSEEQ_13        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 305 )
#define CatalystToOrdSrvNSEEQ_13_SIZE    50000

#define CatalystToOrdSrvNSEEQ_14        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 306 )
#define CatalystToOrdSrvNSEEQ_14_SIZE    50000

#define CatalystToOrdSrvNSEEQ_15        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 307 )
#define CatalystToOrdSrvNSEEQ_15_SIZE    50000

#define CatalystToOrdSrvNSEEQ_16        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 308 )
#define CatalystToOrdSrvNSEEQ_16_SIZE    50000

#define CatalystToOrdSrvNSEEQ_17        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 309 )
#define CatalystToOrdSrvNSEEQ_17_SIZE    50000

#define CatalystToOrdSrvNSEEQ_18        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 310 )
#define CatalystToOrdSrvNSEEQ_18_SIZE    50000

#define CatalystToOrdSrvNSEEQ_19        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 311 )
#define CatalystToOrdSrvNSEEQ_19_SIZE    50000

#define CatalystToOrdSrvNSEEQ_20        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 312 )
#define CatalystToOrdSrvNSEEQ_20_SIZE    50000

#define CatalystToOrdSrvNSEEQ_21        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 313 )
#define CatalystToOrdSrvNSEEQ_21_SIZE    50000

#define CatalystToOrdSrvNSEEQ_22        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 314 )
#define CatalystToOrdSrvNSEEQ_22_SIZE    50000

#define CatalystToOrdSrvNSEEQ_23        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 315 )
#define CatalystToOrdSrvNSEEQ_23_SIZE    50000

#define CatalystToOrdSrvNSEEQ_24        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 316 )
#define CatalystToOrdSrvNSEEQ_24_SIZE    50000

#define CatalystToOrdSrvNSEEQ_25        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 317 )
#define CatalystToOrdSrvNSEEQ_25_SIZE    50000

#define CatalystToOrdSrvNSEEQ_26        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 318 )
#define CatalystToOrdSrvNSEEQ_26_SIZE    50000

#define CatalystToOrdSrvNSEEQ_27        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 319 )
#define CatalystToOrdSrvNSEEQ_27_SIZE    50000

#define CatalystToOrdSrvNSEEQ_28        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 320 )
#define CatalystToOrdSrvNSEEQ_28_SIZE    50000

#define CatalystToOrdSrvNSEEQ_29        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 321 )
#define CatalystToOrdSrvNSEEQ_29_SIZE    50000

#define CatalystToOrdSrvNSEEQ_30        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 322 )
#define CatalystToOrdSrvNSEEQ_30_SIZE    50000

#define CatalystToOrdSrvDRV_1        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 323 )
#define CatalystToOrdSrvDRV_1_SIZE    50000

#define CatalystToOrdSrvDRV_2        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 324 )
#define CatalystToOrdSrvDRV_2_SIZE    50000

#define CatalystToOrdSrvDRV_3        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 325 )
#define CatalystToOrdSrvDRV_3_SIZE    50000

#define CatalystToOrdSrvDRV_4        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 326 )
#define CatalystToOrdSrvDRV_4_SIZE    50000

#define CatalystToOrdSrvDRV_5        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 327 )
#define CatalystToOrdSrvDRV_5_SIZE    50000

#define CatalystToOrdSrvDRV_6        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 328 )
#define CatalystToOrdSrvDRV_6_SIZE    50000

#define CatalystToOrdSrvDRV_7        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 329 )
#define CatalystToOrdSrvDRV_7_SIZE    50000

#define CatalystToOrdSrvDRV_8        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 330 )
#define CatalystToOrdSrvDRV_8_SIZE    50000

#define CatalystToOrdSrvDRV_9        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 331 )
#define CatalystToOrdSrvDRV_9_SIZE    50000

#define CatalystToOrdSrvDRV_10        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 332 )
#define CatalystToOrdSrvDRV_10_SIZE    50000

#define CatalystToOrdSrvDRV_11        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 333 )
#define CatalystToOrdSrvDRV_11_SIZE    50000

#define CatalystToOrdSrvDRV_12        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 334 )
#define CatalystToOrdSrvDRV_12_SIZE    50000

#define CatalystToOrdSrvDRV_13        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 335 )
#define CatalystToOrdSrvDRV_13_SIZE    50000

#define CatalystToOrdSrvDRV_14        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 336 )
#define CatalystToOrdSrvDRV_14_SIZE    50000

#define CatalystToOrdSrvDRV_15        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 337 )
#define CatalystToOrdSrvDRV_15_SIZE    50000

#define CatalystToOrdSrvDRV_16        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 338 )
#define CatalystToOrdSrvDRV_16_SIZE    50000

#define CatalystToOrdSrvDRV_17        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 339 )
#define CatalystToOrdSrvDRV_17_SIZE    50000

#define CatalystToOrdSrvDRV_18        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 340 )
#define CatalystToOrdSrvDRV_18_SIZE    50000

#define CatalystToOrdSrvDRV_19        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 341 )
#define CatalystToOrdSrvDRV_19_SIZE    50000

#define CatalystToOrdSrvDRV_20        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 342 )
#define CatalystToOrdSrvDRV_20_SIZE    50000

#define CatalystToOrdSrvDRV_21        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 343 )
#define CatalystToOrdSrvDRV_21_SIZE    50000

#define CatalystToOrdSrvDRV_22        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 344 )
#define CatalystToOrdSrvDRV_22_SIZE    50000

#define CatalystToOrdSrvDRV_23        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 345 )
#define CatalystToOrdSrvDRV_23_SIZE    50000

#define CatalystToOrdSrvDRV_24        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 346 )
#define CatalystToOrdSrvDRV_24_SIZE    50000

#define CatalystToOrdSrvDRV_25        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 347 )
#define CatalystToOrdSrvDRV_25_SIZE    50000

#define CatalystToOrdSrvDRV_26        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 348 )
#define CatalystToOrdSrvDRV_26_SIZE    50000

#define CatalystToOrdSrvDRV_27        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 349 )
#define CatalystToOrdSrvDRV_27_SIZE    50000

#define CatalystToOrdSrvDRV_28        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 350 )
#define CatalystToOrdSrvDRV_28_SIZE    50000

#define CatalystToOrdSrvDRV_29        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 351 )
#define CatalystToOrdSrvDRV_29_SIZE    50000

#define CatalystToOrdSrvDRV_30        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 352 )
#define CatalystToOrdSrvDRV_30_SIZE    50000

#define CatalystToOrdSrvBSEEQ_1        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 353 )
#define CatalystToOrdSrvBSEEQ_1_SIZE    50000

#define CatalystToOrdSrvBSEEQ_2        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 354 )
#define CatalystToOrdSrvBSEEQ_2_SIZE    50000

#define CatalystToOrdSrvBSEEQ_3        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 355 )
#define CatalystToOrdSrvBSEEQ_3_SIZE    50000

#define CatalystToOrdSrvBSEEQ_4        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 356 )
#define CatalystToOrdSrvBSEEQ_4_SIZE    50000

#define CatalystToOrdSrvBSEEQ_5        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 357 )
#define CatalystToOrdSrvBSEEQ_5_SIZE    50000

#define CatalystToOrdSrvBSEEQ_6        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 358 )
#define CatalystToOrdSrvBSEEQ_6_SIZE    50000

#define CatalystToOrdSrvBSEEQ_7        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 359 )
#define CatalystToOrdSrvBSEEQ_7_SIZE    50000

#define CatalystToOrdSrvBSEEQ_8        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 360 )
#define CatalystToOrdSrvBSEEQ_8_SIZE    50000

#define CatalystToOrdSrvBSEEQ_9        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 361 )
#define CatalystToOrdSrvBSEEQ_9_SIZE    50000

#define CatalystToOrdSrvBSEEQ_10        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 362 )
#define CatalystToOrdSrvBSEEQ_10_SIZE    50000

#define CatalystToOrdSrvBSEEQ_11        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 363 )
#define CatalystToOrdSrvBSEEQ_11_SIZE    50000

#define CatalystToOrdSrvBSEEQ_12        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 364 )
#define CatalystToOrdSrvBSEEQ_12_SIZE    50000

#define CatalystToOrdSrvBSEEQ_13        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 365 )
#define CatalystToOrdSrvBSEEQ_13_SIZE    50000

#define CatalystToOrdSrvBSEEQ_14        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 366 )
#define CatalystToOrdSrvBSEEQ_14_SIZE    50000

#define CatalystToOrdSrvBSEEQ_15        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 367 )
#define CatalystToOrdSrvBSEEQ_15_SIZE    50000

#define CatalystToOrdSrvBSEEQ_16        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 368 )
#define CatalystToOrdSrvBSEEQ_16_SIZE    50000

#define CatalystToOrdSrvBSEEQ_17        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 369 )
#define CatalystToOrdSrvBSEEQ_17_SIZE    50000

#define CatalystToOrdSrvBSEEQ_18        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 370 )
#define CatalystToOrdSrvBSEEQ_18_SIZE    50000

#define CatalystToOrdSrvBSEEQ_19        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 371 )
#define CatalystToOrdSrvBSEEQ_19_SIZE    50000

#define CatalystToOrdSrvBSEEQ_20        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 372 )
#define CatalystToOrdSrvBSEEQ_20_SIZE    50000

#define CatalystToOrdSrvBSEEQ_21        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 373 )
#define CatalystToOrdSrvBSEEQ_21_SIZE    50000

#define CatalystToOrdSrvBSEEQ_22        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 374 )
#define CatalystToOrdSrvBSEEQ_22_SIZE    50000

#define CatalystToOrdSrvBSEEQ_23        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 375 )
#define CatalystToOrdSrvBSEEQ_23_SIZE    50000

#define CatalystToOrdSrvBSEEQ_24        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 376 )
#define CatalystToOrdSrvBSEEQ_24_SIZE    50000

#define CatalystToOrdSrvBSEEQ_25        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 377 )
#define CatalystToOrdSrvBSEEQ_25_SIZE    50000

#define CatalystToOrdSrvBSEEQ_26        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 378 )
#define CatalystToOrdSrvBSEEQ_26_SIZE    50000

#define CatalystToOrdSrvBSEEQ_27        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 379 )
#define CatalystToOrdSrvBSEEQ_27_SIZE    50000

#define CatalystToOrdSrvBSEEQ_28        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 380 )
#define CatalystToOrdSrvBSEEQ_28_SIZE    50000

#define CatalystToOrdSrvBSEEQ_29        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 381 )
#define CatalystToOrdSrvBSEEQ_29_SIZE    50000

#define CatalystToOrdSrvBSEEQ_30        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 382 )
#define CatalystToOrdSrvBSEEQ_30_SIZE    50000

#define CatalystToOrdSrvNCr_1        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 383 )
#define CatalystToOrdSrvNCr_1_SIZE    50000

#define CatalystToOrdSrvNCr_2        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 384 )
#define CatalystToOrdSrvNCr_2_SIZE    50000

#define CatalystToOrdSrvNCr_3        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 385 )
#define CatalystToOrdSrvNCr_3_SIZE    50000

#define CatalystToOrdSrvNCr_4        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 386 )
#define CatalystToOrdSrvNCr_4_SIZE    50000

#define CatalystToOrdSrvNCr_5        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 387 )
#define CatalystToOrdSrvNCr_5_SIZE    50000

#define CatalystToOrdSrvNCr_6        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 388 )
#define CatalystToOrdSrvNCr_6_SIZE    50000

#define CatalystToOrdSrvNCr_7        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 389 )
#define CatalystToOrdSrvNCr_7_SIZE    50000

#define CatalystToOrdSrvNCr_8        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 390 )
#define CatalystToOrdSrvNCr_8_SIZE    50000

#define CatalystToOrdSrvNCr_9        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 391 )
#define CatalystToOrdSrvNCr_9_SIZE    50000

#define CatalystToOrdSrvNCr_10        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 392 )
#define CatalystToOrdSrvNCr_10_SIZE    50000

#define CatalystToOrdSrvNCr_11        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 393 )
#define CatalystToOrdSrvNCr_11_SIZE    50000

#define CatalystToOrdSrvNCr_12        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 394 )
#define CatalystToOrdSrvNCr_12_SIZE    50000

#define CatalystToOrdSrvNCr_13        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 395 )
#define CatalystToOrdSrvNCr_13_SIZE    50000

#define CatalystToOrdSrvNCr_14        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 396 )
#define CatalystToOrdSrvNCr_14_SIZE    50000

#define CatalystToOrdSrvNCr_15        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 397 )
#define CatalystToOrdSrvNCr_15_SIZE    50000

#define CatalystToOrdSrvNCr_16        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 398 )
#define CatalystToOrdSrvNCr_16_SIZE    50000

#define CatalystToOrdSrvNCr_17        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 399 )
#define CatalystToOrdSrvNCr_17_SIZE    50000

#define CatalystToOrdSrvNCr_18        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 400 )
#define CatalystToOrdSrvNCr_18_SIZE    50000

#define CatalystToOrdSrvNCr_19        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 401 )
#define CatalystToOrdSrvNCr_19_SIZE    50000

#define CatalystToOrdSrvNCr_20        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 402 )
#define CatalystToOrdSrvNCr_20_SIZE    50000

#define CatalystToOrdSrvNCr_21        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 403 )
#define CatalystToOrdSrvNCr_21_SIZE    50000

#define CatalystToOrdSrvNCr_22        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 404 )
#define CatalystToOrdSrvNCr_22_SIZE    50000

#define CatalystToOrdSrvNCr_23        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 405 )
#define CatalystToOrdSrvNCr_23_SIZE    50000

#define CatalystToOrdSrvNCr_24        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 406 )
#define CatalystToOrdSrvNCr_24_SIZE    50000

#define CatalystToOrdSrvNCr_25        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 407 )
#define CatalystToOrdSrvNCr_25_SIZE    50000

#define CatalystToOrdSrvNCr_26        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 408 )
#define CatalystToOrdSrvNCr_26_SIZE    50000

#define CatalystToOrdSrvNCr_27        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 409 )
#define CatalystToOrdSrvNCr_27_SIZE    50000

#define CatalystToOrdSrvNCr_28        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 410 )
#define CatalystToOrdSrvNCr_28_SIZE    50000

#define CatalystToOrdSrvNCr_29        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 411 )
#define CatalystToOrdSrvNCr_29_SIZE    50000

#define CatalystToOrdSrvNCr_30        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 412 )
#define CatalystToOrdSrvNCr_30_SIZE    50000

#define CatalystToOrdSrvMCX_1        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 413 )
#define CatalystToOrdSrvMCX_1_SIZE    50000

#define CatalystToOrdSrvMCX_2        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 414 )
#define CatalystToOrdSrvMCX_2_SIZE    50000

#define CatalystToOrdSrvMCX_3        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 415 )
#define CatalystToOrdSrvMCX_3_SIZE    50000

#define CatalystToOrdSrvMCX_4        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 416 )
#define CatalystToOrdSrvMCX_4_SIZE    50000

#define CatalystToOrdSrvMCX_5        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 417 )
#define CatalystToOrdSrvMCX_5_SIZE    50000

#define CatalystToOrdSrvMCX_6        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 418 )
#define CatalystToOrdSrvMCX_6_SIZE    50000

#define CatalystToOrdSrvMCX_7        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 419 )
#define CatalystToOrdSrvMCX_7_SIZE    50000

#define CatalystToOrdSrvMCX_8        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 420 )
#define CatalystToOrdSrvMCX_8_SIZE    50000

#define CatalystToOrdSrvMCX_9        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 421 )
#define CatalystToOrdSrvMCX_9_SIZE    50000

#define CatalystToOrdSrvMCX_10        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 422 )
#define CatalystToOrdSrvMCX_10_SIZE    50000

#define CatalystToOrdSrvMCX_11        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 423 )
#define CatalystToOrdSrvMCX_11_SIZE    50000

#define CatalystToOrdSrvMCX_12        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 424 )
#define CatalystToOrdSrvMCX_12_SIZE    50000

#define CatalystToOrdSrvMCX_13        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 425 )
#define CatalystToOrdSrvMCX_13_SIZE    50000

#define CatalystToOrdSrvMCX_14        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 426 )
#define CatalystToOrdSrvMCX_14_SIZE    50000

#define CatalystToOrdSrvMCX_15        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 427 )
#define CatalystToOrdSrvMCX_15_SIZE    50000

#define CatalystToOrdSrvMCX_16        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 428 )
#define CatalystToOrdSrvMCX_16_SIZE    50000

#define CatalystToOrdSrvMCX_17        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 429 )
#define CatalystToOrdSrvMCX_17_SIZE    50000

#define CatalystToOrdSrvMCX_18        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 430 )
#define CatalystToOrdSrvMCX_18_SIZE    50000

#define CatalystToOrdSrvMCX_19        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 431 )
#define CatalystToOrdSrvMCX_19_SIZE    50000

#define CatalystToOrdSrvMCX_20        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 432 )
#define CatalystToOrdSrvMCX_20_SIZE    50000

#define CatalystToOrdSrvMCX_21        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 433 )
#define CatalystToOrdSrvMCX_21_SIZE    50000

#define CatalystToOrdSrvMCX_22        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 434 )
#define CatalystToOrdSrvMCX_22_SIZE    50000

#define CatalystToOrdSrvMCX_23        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 435 )
#define CatalystToOrdSrvMCX_23_SIZE    50000

#define CatalystToOrdSrvMCX_24        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 436 )
#define CatalystToOrdSrvMCX_24_SIZE    50000

#define CatalystToOrdSrvMCX_25        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 437 )
#define CatalystToOrdSrvMCX_25_SIZE    50000

#define CatalystToOrdSrvMCX_26        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 438 )
#define CatalystToOrdSrvMCX_26_SIZE    50000

#define CatalystToOrdSrvMCX_27        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 439 )
#define CatalystToOrdSrvMCX_27_SIZE    50000

#define CatalystToOrdSrvMCX_28        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 440 )
#define CatalystToOrdSrvMCX_28_SIZE    50000

#define CatalystToOrdSrvMCX_29        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 441 )
#define CatalystToOrdSrvMCX_29_SIZE    50000

#define CatalystToOrdSrvMCX_30        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 442 )
#define CatalystToOrdSrvMCX_30_SIZE    50000

#define CatalystToOrdProNEQ		(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 443 )
#define CatalystToOrdProNEQ_SIZE	50000

#define CatalystToOrdProNFO	        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 444 )
#define CatalystToOrdProNFO_SIZE	50000
	
#define CatalystToOrdProNCD	       	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 445 )
#define CatalystToOrdProNCD_SIZE    	50000

#define CatalystToOrdProBEQ	        (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 446 )
#define CatalystToOrdProBEQ_SIZE	50000

#define CatalystToOrdProMCX 	       	(key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 447 )
#define CatalystToOrdProMCX_SIZE	50000

//////////
#define OrdRtrToOrdSrvBSEDRV             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 448 )
#define OrdRtrToOrdSrvBSEDRV_SIZE        50000

#define OrdSrvToMapperBSEDRV             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 449 )
#define OrdSrvToMapperBSEDRV_SIZE        50000

#define MapperToConnBSEDRV               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 450 )
#define MapperToConnBSEDRV_SIZE          50000

#define ConnToTrdMapBSEDRV               (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 451 )
#define ConnToTrdMapBSEDRV_SIZE          50000

#define RevMapToTrdSrvBSEDRV             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 452 )
#define RevMapToTrdSrvBSEDRV_SIZE        50000

#define OrdRtrToCatalystBSEDRV           (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 453 )
#define OrdRtrToCatalystBSEDRV_SIZE      50000

#define CatalystToOrdSrvBSEDRV_1         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 454 )
#define CatalystToOrdSrvBSEDRV_1_SIZE    50000

#define CatalystToOrdSrvBSEDRV_2         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 455 )
#define CatalystToOrdSrvBSEDRV_2_SIZE    50000

#define CatalystToOrdSrvBSEDRV_3         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 456 )
#define CatalystToOrdSrvBSEDRV_3_SIZE    50000

#define CatalystToOrdSrvBSEDRV_4         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 457 )
#define CatalystToOrdSrvBSEDRV_4_SIZE    50000

#define CatalystToOrdSrvBSEDRV_5         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 458 )
#define CatalystToOrdSrvBSEDRV_5_SIZE    50000

#define CatalystToOrdSrvBSEDRV_6         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 459 )
#define CatalystToOrdSrvBSEDRV_6_SIZE    50000

#define CatalystToOrdSrvBSEDRV_7         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 460 )
#define CatalystToOrdSrvBSEDRV_7_SIZE    50000

#define CatalystToOrdSrvBSEDRV_8         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 461 )
#define CatalystToOrdSrvBSEDRV_8_SIZE    50000

#define CatalystToOrdSrvBSEDRV_9         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 462 )
#define CatalystToOrdSrvBSEDRV_9_SIZE    50000

#define CatalystToOrdSrvBSEDRV_10         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 463 )
#define CatalystToOrdSrvBSEDRV_10_SIZE    50000

#define CatalystToOrdSrvBSEDRV_11         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 464 )
#define CatalystToOrdSrvBSEDRV_11_SIZE    50000

#define CatalystToOrdSrvBSEDRV_12         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 465 )
#define CatalystToOrdSrvBSEDRV_12_SIZE    50000

#define CatalystToOrdSrvBSEDRV_13         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 466 )
#define CatalystToOrdSrvBSEDRV_13_SIZE    50000

#define CatalystToOrdSrvBSEDRV_14         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 467 )
#define CatalystToOrdSrvBSEDRV_14_SIZE    50000

#define CatalystToOrdSrvBSEDRV_15         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 468 )
#define CatalystToOrdSrvBSEDRV_15_SIZE    50000

#define CatalystToOrdSrvBSEDRV_16         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 469 )
#define CatalystToOrdSrvBSEDRV_16_SIZE    50000

#define CatalystToOrdSrvBSEDRV_17         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 470 )
#define CatalystToOrdSrvBSEDRV_17_SIZE    50000

#define CatalystToOrdSrvBSEDRV_18         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 471 )
#define CatalystToOrdSrvBSEDRV_18_SIZE    50000

#define CatalystToOrdSrvBSEDRV_19         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 472 )
#define CatalystToOrdSrvBSEDRV_19_SIZE    50000

#define CatalystToOrdSrvBSEDRV_20         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 473 )
#define CatalystToOrdSrvBSEDRV_20_SIZE    50000

#define CatalystToOrdSrvBSEDRV_21         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 474 )
#define CatalystToOrdSrvBSEDRV_21_SIZE    50000

#define CatalystToOrdSrvBSEDRV_22         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 475 )
#define CatalystToOrdSrvBSEDRV_22_SIZE    50000

#define CatalystToOrdSrvBSEDRV_23         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 476 )
#define CatalystToOrdSrvBSEDRV_23_SIZE    50000

#define CatalystToOrdSrvBSEDRV_24         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 477 )
#define CatalystToOrdSrvBSEDRV_24_SIZE    50000

#define CatalystToOrdSrvBSEDRV_25         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 478 )
#define CatalystToOrdSrvBSEDRV_25_SIZE    50000

#define CatalystToOrdSrvBSEDRV_26         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 479 )
#define CatalystToOrdSrvBSEDRV_26_SIZE    50000

#define CatalystToOrdSrvBSEDRV_27         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 480 )
#define CatalystToOrdSrvBSEDRV_27_SIZE    50000

#define CatalystToOrdSrvBSEDRV_28         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 481 )
#define CatalystToOrdSrvBSEDRV_28_SIZE    50000

#define CatalystToOrdSrvBSEDRV_29         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 482 )
#define CatalystToOrdSrvBSEDRV_29_SIZE    50000

#define CatalystToOrdSrvBSEDRV_30         (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 483 )
#define CatalystToOrdSrvBSEDRV_30_SIZE    50000

#define RevMapToMMapBSEDRV_1             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 484 )
#define RevMapToMMapBSEDRV_1_SIZE        50000

#define RevMapToMMapBSEDRV_2             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 485 )
#define RevMapToMMapBSEDRV_2_SIZE        50000

#define RevMapToMMapBSEDRV_3             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 486)
#define RevMapToMMapBSEDRV_3_SIZE        50000

#define RevMapToMMapBSEDRV_4             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 487 )
#define RevMapToMMapBSEDRV_4_SIZE        50000

#define RevMapToMMapBSEDRV_5             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 488 )
#define RevMapToMMapBSEDRV_5_SIZE        50000

#define RevMapToMMapBSEDRV_6             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 489 )
#define RevMapToMMapBSEDRV_6_SIZE        50000

#define RevMapToMMapBSEDRV_7             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 490 )
#define RevMapToMMapBSEDRV_7_SIZE        50000

#define RevMapToMMapBSEDRV_8             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 491 )
#define RevMapToMMapBSEDRV_8_SIZE        50000

#define RevMapToMMapBSEDRV_9             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 492 )
#define RevMapToMMapBSEDRV_9_SIZE        50000

#define MMapToTrdSvrBSEDRV_1             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 493 )
#define MMapToTrdSvrBSEDRV_1_SIZE        50000

#define MMapToTrdSvrBSEDRV_2             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 494 )
#define MMapToTrdSvrBSEDRV_2_SIZE        50000

#define MMapToTrdSvrBSEDRV_3             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 495 )
#define MMapToTrdSvrBSEDRV_3_SIZE        50000

#define MMapToTrdSvrBSEDRV_4             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 496 )
#define MMapToTrdSvrBSEDRV_4_SIZE        50000

#define MMapToTrdSvrBSEDRV_5             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 497 )
#define MMapToTrdSvrBSEDRV_5_SIZE        50000

#define MMapToTrdSvrBSEDRV_6             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 498 )
#define MMapToTrdSvrBSEDRV_6_SIZE        50000

#define MMapToTrdSvrBSEDRV_7             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 499 )
#define MMapToTrdSvrBSEDRV_7_SIZE        50000

#define MMapToTrdSvrBSEDRV_8             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 500 )
#define MMapToTrdSvrBSEDRV_8_SIZE        50000

#define MMapToTrdSvrBSEDRV_9             (key_t) (IPC_RESOURCES_BASE + IPC_QUEUE_BASE + 501 )
#define MMapToTrdSvrBSEDRV_9_SIZE        50000




extern int		   ReadQ( int , char * ,int , long);
extern int	   	   WriteQ( int , char * ,int , long);
extern int         OpenMsgQ(key_t);
extern int         MsgQueueCreate(key_t , int);
extern int         SharedMemoryCreate(key_t , size_t );
extern int         SemophoreCreate(key_t );
extern void *      OpenSharedMemory ( key_t , int );
extern int         LockShm(key_t );
extern int         UnLockShm ( key_t );
extern int         DeleteLockShm ( key_t );
extern int         DeleteMsgQ ( key_t );
extern int         DeleteShmMem ( key_t );
extern int         ClearQ ( int,int );
extern int         AddProcessMem(char * ,int ,  char *);
extern int        DeleteProcessMem(int,struct ProcessMonitorArray * );
extern int         CheckProcessMem(char * );


struct  QueueMap
{
	char    QueueName[30]   ;
	int  	QueueKey        ;
};

/**------------------------ KAFKA TOPICS ------------------------**/

#define		KF_OMS_COOKED_DATA "KF_OMS_COOKED_DATA"



#endif 


