

/*****************************************************************_CANNOT_BE_CANCELLED
  Defination of all the errors
 ******************************************************************/

#define		NOT_CONNECTED_TO_EXCH_NEQ						"O3000"
#define		NOT_CONNECTED_TO_EXCH_NFO						"O3001"
#define		NOT_CONNECTED_TO_EXCH_NCD						"O3002"
#define		NOT_CONNECTED_TO_EXCH_BEQ						"O3003"
#define		NOT_CONNECTED_TO_EXCH_BFO						"O3007"
#define		NOT_CONNECTED_TO_EXCH_MCX						"O3004"

#define		NOT_CONNECTED_TO_EXCH_BCD						"O3005"
#define		NOT_CONNECTED_TO_EXCH_BCOM						"O3006"
/**
#define		MARKET_IS_NOT_OPEN_FOR_TRADE					"O3001"
#define		MARKET_IS_CLOSED						"O3002" 		



#define		NOT_ALLOWED_TO_TRADE_IN_NSE_EQ					3010
#define		NOT_ALLOWED_TO_TRADE_IN_NSE_DR					3011
#define		NOT_ALLOWED_TO_TRADE_IN_NSE_CR					3012
#define		NOT_ALLOWED_TO_TRADE_IN_BSE_EQ					3013
#define		NOT_ALLOWED_TO_TRADE_IN_MCX_CM					3014

#define		DEALER_NOT_ALLOWED_TO_TRADE_IN_NSE_EQ				3110
#define		DEALER_NOT_ALLOWED_TO_TRADE_IN_NSE_DR				3111
#define		DEALER_NOT_ALLOWED_TO_TRADE_IN_NSE_CR				3112
#define		DEALER_NOT_ALLOWED_TO_TRADE_IN_BSE_EQ				3113
#define		DEALER_NOT_ALLOWED_TO_TRADE_IN_MCX_CM				3114
 ***/
/**
#define		QUANTITY_CANNOT_BE_NEGATIVE					"O3200"
#define		PRICE_CANNOT_BE_NEGATIVE					"O3201"

#define		DEALER_QUANTITY_OR_VALUE_LIMIT_VOILATED				3202
#define		BRANCH_QUANTITY_OR_VALUE_LIMIT_VOILATED				3203
#define		INSUFFICIENT_DEALER_FUNDS					3204
#define		INSUFFICIENT_BRANCH_FUNDS					3205

#define		NO_PARAMETERS_CHANGED						3300

#define		INVALID_SECURITY_ID						"O3301"
 ***/
#define		ORDER_IN_TRANSIT						"O3302"
#define		ORDER_CANNOT_BE_CAN_OR_MOD					"O3303"
#define		ORDER_BLOCKED_CANNOT_BE_CANCELLED				"O3304"
#define		ORDER_IS_TRADED							"O3305"
#define		ORDER_TRADED_CANNOT_BE_CANCELLED				"O3306"
#define		ORDER_REJECTED							"O3307"
#define 	PROD_NOT_ALLOWED_TO_CONVERT					"O3308"
#define 	PROD_GOT_NULL_CONV_TO_DEL					"O3309"
#define		BOTH_ORDER_REJECTED						"O3310"
#define		BUY_ORD_PRICE_MOD_ERROR						"O3311"
#define		SELL_ORD_PRICE_MOD_ERROR					"O3312"
#define		BUY_TRIG_PRICE_MOD_ERROR 					"O3313"
#define		SELL_TRIG_PRICE_MOD_ERROR					"O3314"
#define		TRANSACTION_FAILED						"O3991"
#define		BASIC_VALIDATION_FAILED						"O3992"
#define		ORDER_STATUS_CHANGED						"O3993"
#define         NOTHING_TO_MODIFY                                               "O3994"	
#define		INVALID_MKT_TYPE						"O3995"
#define		INVALID_PRODUCT							"O3996"
#define		SIP_NOT_ALLOWED 						"O3997"
#define		SIP_PERIOD_EXCEED 						"O3998"

#define		RET_TRANSIT_STAT						3302
#define		RET_TRADED_STAT							3305
#define		RET_CANCEL_STAT							3303
#define         INVALID_SECURITY_ID                                             3301
#define		RET_REJECT_STAT							3304
#define		RET_FREEZE_STAT							3306
#define		RET_EXPIRED_STAT						3307
#define		ITRANSACTION_FAILED						3308
#define		INOT_CONNECTED_TO_EXCH						3309
#define		IBASIC_VALIDATION_FAILED					3310
#define		INOTHING_TO_MODIFY						3311
#define		RET_STAT_CHANGE							3312
#define		IERROR_LOC_CODE						 	3313
#define		IBUY_ORD_PRICE_MOD_ERROR					3314
#define		ISELL_ORD_PRICE_MOD_ERROR					3315
#define		IBUY_TRIG_PRICE_MOD_ERROR					3316
#define		ISELL_TRIG_PRICE_MOD_ERROR					3317
#define		IBUY_SELL_TRIG_PRICE_MOD_ERROR					3318	
#define		INO_BO_ALGO_ID_DEFINE						3319
#define		INOT_CONNECTED_TO_EXCH_BSE_EQ					3320
#define		INOT_CONNECTED_TO_EXCH_NSE_EQ					3321
#define		INOT_CONNECTED_TO_EXCH_NSE_FO					3322
#define		INOT_CONNECTED_TO_EXCH_NSE_CD					3323
#define		INOT_CONNECTED_TO_EXCH_MCX					3324
#define		INOT_CONNECTED_TO_EXCH_BSE_CD					3325
#define		INOT_CONNECTED_TO_EXCH_BSE_FO					3326
#define		INOT_CONNECTED_TO_EXCH_NSE_COMM					3327
#define		INOT_CONNECTED_TO_EXCH_ICEX					3328
#define		INOT_CONNECTED_TO_EXCH_NCDEX					3329
#define		IORDER_CANNOT_BE_CAN_OR_MOD					3330
#define		IBOTH_ORDER_REJECTED						3331


#define 	INVALID_CLIENT_ID						3332
#define 	INVALID_SEC_ID							3333
#define		INVALID_GRP_ID							3334
#define		INVALID_ORDER							3335


#define		OFFLINE_ORDER_FAILED						3336
#define		OFFLINE_ORDER_ERROR						3337
#define		INVALID_OFFLINE_ORDER						3338

#define		INVALID_MULTIPLE_QUANTITY					3339

/*OFFLINE_CLIENT_ORDER is used to whether client is offline or not */
#define         OFFLINE_CLIENT_ORDER                                            3340
/*if last run date and start date is same */
#define         BATCH_ALREADY_RUN                                               3341
#define         TRADING_HOLIDAY_ERR                                             3342

#define         DISABLE_CLIENT                                                  3343

#define 	GTTORDERS_SCRIPT_EXPIRED					3344


#define		OFFLINE_INVALID_STATUS						3345
#define 	ONLINE_INVALID_STATUS						3346

#define		GTTORDERS_NOT_ALLOWED						3347
#define		ILTP_NOT_IN_REDIS						3348




