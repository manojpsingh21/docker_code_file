#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <stdio.h>

#ifdef BIT32
#define SPARCLONG64 long long
#endif
#ifdef BIT64
#define SPARCLONG64 long
#endif

/*---------------------------------------------
  -----------------------------------------------*/
#define  MAX_DWS_USERS                   1000
#define  MAX_DAEMON_USERS                50
/*---------------------------------------------
  -----------------------------------------------*/
#define         TWIDDLE(A)              Twiddle((char *) &A, sizeof(A))

#define    	CONNECT( CALLADDRESS , CALLDATA)        tcpConnect(CALLDATA,atoi(CALLADDRESS))
#define		RECV_INV(SOCKFD,MSG,FLAG)               tcpRecv_Inv(SOCKFD,MSG,FLAG)
#define         SEND(SOCKFD, MSG , LEN )                tcpSend(SOCKFD, MSG ,LEN )
#define         RECV(SOCKFD,MSG)                        tcpRecv(SOCKFD,MSG )



#ifdef DBG
#define     PLOGS(a,b)  printf("\n\nFile :%-20.20s  **** Function :%-20.20s      # START #\n",a,b)
#define     PLOGE(a,b)  printf("\n\nFile :%-20.20s  **** Function :%-20.20s      # END   #\n",a,b)
#else
#define     PLOGS(a,b)  {}
#define     PLOGE(a,b)  {}
#endif

#define USE_GRP_ID_IN_EQU_NSE 0      /**** To be Changed if multiple exch connection exixt ***/
#define USE_GRP_ID_IN_DRV_NSE 0      /**** To be Changed if multiple exch connection exixt ***/
#define USE_GRP_ID_IN_EQU_BSE 0      /**** To be Changed if multiple exch connection exixt ***/
#define USE_GRP_ID_IN_DRV_BSE 0          /**** To be Changed if multiple exch connection exixt ***/

#define         TWIDDLE(A)              Twiddle ((char *) &A, sizeof(A))

#define		PROCESS_NAME_LEN		20

#define		EQUALS					==
#define		NOT_EQUALS				!=
/*----------------------------------------------------------------------------------
  DATA TYPES FOR APPLICATION 
  --------------------------------------------------------------------------------*/
typedef    char            		CHAR         ;                          
typedef    short           		SHORT        ;
typedef    short           		INT16        ;
typedef    int             		LONG32       ;
typedef    float           		FLOAT32      ;
typedef    double          		DOUBLE64     ;
typedef    int             		BOOL         ;
typedef    unsigned short  		USHORT       ;
typedef    unsigned int    		ULONG32	     ;
typedef    unsigned char   		UCHAR        ;
typedef    long            		LONG64       ;
typedef    unsigned long long int   	ULONG64	     ;/**New added **/

#define   SPACE						      	' ' 
#define   TRUE						      	1 
#define   FALSE						      	0 
#define   ERROR						      	-1 
#define	  SUCCESS					      	0
#define	  BO_MOD						0
#define	  BO_CAN						1

#define	  BCAST_YES			TRUE
#define   ZERO                             0

#define   PACKET_SIZE                     2048
#define   MSG_TYPE_LEN                    2
//#define	  MAX_GROUPS			  3
#define	  MAX_GROUPS			  20
#define   ERROR_MSG_LEN			  200
#define   ERROR_CODE_LEN		  10

#define	  MOD_VALUE			  10

#define	  TIME_ELAPSED			getenv("TIME_ELAPSED")		


//#define   SRCFLAG		 	  getenv("SRCFLAG")
#define	SRC_EXE				getenv("SRC_EXE")
#define	SRC_MOB				getenv("SRC_MOB")
#define	SRC_WEB				getenv("SRC_WEB")
#define	SRC_ADM				getenv("SRC_ADM")
#define	SRC_SYS				getenv("SRC_SYS")

#define RUPEE_PRODUCT			getenv("RUPEE_PROD")
#define RUPEE_SOURCE_EXE		getenv("SRC_EXE")

#define SEM_SECURITY_STATUS	'A'
#define SEM_SECURITY_SUSPENDED  'S'

#define NSE_EQU_UP      1
#define NSE_EQU_DOWN    2
#define NSE_DRV_UP      3
#define NSE_DRV_DOWN    4
#define BSE_EQU_UP      5
#define BSE_EQU_DOWN    6
#define BSE_DRV_UP      7
#define BSE_DRV_DOWN    8
#define NSE_CUR_UP      9
#define NSE_CUR_DOWN    10
#define MCX_UP          19
#define MCX_DOWN        20
#define MCX_IDSOURCE    "8"
#define NSE_EQU         11
#define NSE_DRV         12
#define BSE_EQU         13
#define BSE_DRV         14
#define NSE_CUR         15
#define MCX_COM         16
#define BSE_CUR		17
#define	OFF_ORD		18
#define	CTD_ORD		19
#define	EXP_ORD		20
#define	SQR_ORD		21
#define	NSE_MFS		22
#define	BSE_MFS		23
#define DE_NOTI         24
#define SIP_ORD		25
#define MTM_SQROFF	26
#define	MRG_CAL		27
#define BSE_CUR_UP      28
#define BSE_CUR_DOWN   	29
#define BSE_COM		30
#define BSE_COM_UP	31
#define BSE_COM_DOWN	32
#define NSE_CM		33
#define NSE_CM_UP	34
#define NSE_CM_DOWN	35
#define BSE_CM_UP	36
#define BSE_CM_DOWN	37
#define BSE_COMM	38
#define ICEX_COM        39
#define ICEX_UP         40
#define ICEX_DOWN       41
#define NCDEX_COM	42
#define NCDEX_UP	43
#define NCDEX_DOWN	44
#define GTT_ORD         45


#define ICEX_IDSOURCE    "8"

#define EXCHANGE_UP     '1'
#define EXCHANGE_DOWN   '0'


# define                PERMS                           0666
# define                PERMS1                          0660
# define 		min 				40
# define 		max 				125

#define			SYSADMIN			"SYSADMIN"
#define			SYSADMIN1			"SYSADMIN1"
#define			INTRADAY_REMARKS		"Auto_Squareoff_Req"
#define			PUMP_ORD_REMARKS		"Auto_Pumpord_Req"


#define         FILE_PATH                               "../File/ClientDealerMapper"
#define 	FILE_LOCATION				"../RRService"
#define		FILE_NAME_LEN				150
#define         FILE_SEQ                                getenv("FILE_SEQ")
#define         CDSL_FILE_PATH                          getenv("CDSL_FILE_PATH")
#define         GROUPID					atoi(getenv("GROUP_ID"))

#define		NSE_CM_CONN_ERR_FILE			"../log/log.SysNCMconerror"
#define		NSE_FO_CONN_ERR_FILE			"../log/log.SysNFOconerror"
#define		NSE_CD_CONN_ERR_FILE			"../log/log.SysNCDconerror"
#define		BSE_CM_CONN_ERR_FILE			"../log/log.SysBCMconerror"

#define		NseCMProgName				"NseCMConnect"
#define		NseFOProgName				"NseFOConnect"
#define		NseCDProgName				"NseCDConnect"
#define		BseCMProgName				"BseCMConnect"


#define		MAX_NO_OF_SYSTEM_PROCESS                 500
#define		MAX_NO_OF_USERS_SHM			1500
#define  	UNUSED                                 -2

#define		EQUITY_SEGMENT			'E'
#define 	DERIVATIVE_SEGMENT		'D'
#define 	CURRENCY_SEGMENT		'C'
#define 	COMMODITY_SEGMENT		'M'
#define 	MUTUALFUND_SEGMENT		'F'
#define		SEGMENT_LENGTH			10

#define		EQUITY_SEQ			1000
#define         DERIVATIVE_SEQ                  1000
#define		CURRENCY_SEQ			1000
#define		COMMODITY_SEQ			1500
#define		NSE_FO_SEQ			2000
#define		NSE_CU_SEQ			3000
#define		ALGO_SEQ			5000
#define		OFFLINE_ORD_SEQ			7000
#define		BSE_STAR_SEQ			8000
#define		BASKET_SEQ			6000	
#define 	MCX_SEQ				1000
#define 	BSE_SCD				7000
#define         BSE_SDR                         4000
#define		NSE_CM_SEQ			9000
#define		BSE_CM_SEQ			4000
#define		ICEX_SEQ			1500

#define		BASKET_ID			6

#define 	INVALID_SEGMENT			0
#define		DATE_LEN			12
#define		NSE_EXCH			"NSE"
#define		BSE_EXCH			"BSE"
#define		MCX_EXCH			"MCX"
#define		ICEX_EXCH			"ICEX"
#define		INSTRU_CODE_LEN			11
#define		MKT_TYPE_NL			"NL"
#define		MKT_TYPE_OL			"OL"
#define         MKT_TYPE_SP			"SP"
#define         MKT_TYPE_AU			"AU"
#define         MKT_TYPE_CAU_1			"A1"
#define		MKT_TYPE_CAU_2			"A2"

#define		DEFAULT_SETTLOR			"000000000000"

#define		FNO_EQUITY			5
#define		FNO_INDEX			7
#define		FNO_INDAIVIX			21


#define		CD_CURR				4	
#define		CD_IRD				20			

#define 	RUPEE_MAX_PACKET_SIZE		8192
#define 	MAX_QUERY_SIZE			4096
#define		DOUBLE_MAX_QUERY_SIZE		25000
#define		EXTRA_DOUBLE_MAX_QUERY_SIZE	30000
#define		ULTRA_DOUBLE_MAX_QUERY_SIZE	40000
#define		QUERY_SIZE			500	
#define		MAX_NO_OF_SECURITIES		500
#define         MAX_PEEK_SIZE			10 

#define 	GRP_ID				atoi(getenv("GROUP_ID"))
#define		INT_BUY				'B'
#define		INT_SELL			'S'

#define         PROD_INTRADAY                   'I'
#define         PROD_MARGIN                     'M'
#define         PROD_CNC                        'C'
#define		PROD_COVER			'V'
#define		PROD_BRACKET			'B'
#define		PROD_NORMAL			'H'	
#define		PROD_MTF			'F'	

#define		USER_INFO_ONLINE		"111111111111100"
#define		USER_INFO_SYSTEM		"111111111111100"
#define		USER_INFO_MOBILE		"333333333333100"
#define		SYSTEM_VENDOR_CODE		"100"
#define		AUTOMATIC_ORDER_VAL		'0'

#define		FIX_MAX_VALUE_LEN		40

#define		FE_BUY				"BUY"
#define		FE_SELL				"SELL"
#define		FE_PROD_INTRADAY		"INTRADAY"
#define		FE_PROD_MARGIN			"MARGIN"
#define		FE_PROD_CNC			"CNC"
#define		FE_PROD_COVER			"CO"
#define		FE_PROD_BRACKET			"BO"

#define 	MCX_USER_INFO_ONLINE		"111111111111010"
#define         MCX_USER_INFO_SYSTEM        	"111111111111010"
#define         MCX_USER_INFO_MOBILE        	"333333333333010"
#define		MCX_SYSTEM_VENDOR_CODE		"010"
#define		ICEX_SYSTEM_VENDOR_CODE		"000"
#define		ICEX_SYSTEM_LAST_SIX_CODE	"000000"

#define		BSE_USER_INFO_ONLINE		"1111111111111088"
#define		BSE_USER_INFO_SYSTEM		"1111111111111088"
/**BSE Location code  for 5555555555555588 for Mobile Orders**/
#define		BSE_USER_INFO_MOBILE		"5555555555555588"
#define		BSE_SYSTEM_VENDOR_CODE		"088"

#define 	ICEX_USER_INFO_ONLINE		"111111111111000000"
#define         ICEX_USER_INFO_SYSTEM        	"111111111111000000"
#define         ICEX_USER_INFO_MOBILE        	"333333333333000000"

/*---------------------------------------------------------------------
  LENGTHS for ORDER Related structures
  ------------------20---------------------------------------------------*/

#define		EXCHANGE_LEN			6
#define		EXCHANGE_ALLOW_LEN		12
#define		SECURITY_ID_LEN			12
#define		SECURITY_SYM_LEN		25
#define		ENTITY_ID_LEN			30/**Changes size from 12 to 30**/
#define		CLIENT_ID_LEN			30/**Changes size from 12 to 30**/
#define		USER_ID_LEN			30
#define		SYMBOL_LEN			10
#define		SERIES_LEN			2
#define		SB_SERIES_LEN			10
#define		HLD_SERIES_LEN			3
#define		DATE_TIME_LEN			20
#define		REMARKS_LEN			24
#define		CLORDID_LEN			20+1
#define		EXCH_ORDER_NO_LEN		30
#define		LOC_CODE_LEN			17+1
#define		DESCRIPTOR_LEN			1000
#define		ORDER_LEN			30
#define		SETTLOR_LEN			30
#define		PARTICIPANT_LEN			30
#define		BROKER_CODE_LEN			30
#define		SETTLOR_CODE_LEN		30
#define		LEG_LEN				3
#define		LEG_1				1
#define         LEG_2                           2
#define         LEG_3                           3
#define		IP_ADDR_LEN			15
#define		BUY_SELL_LEN			5
#define		PRODUCT_LEN			10
#define		PRODUCT_NAME_LEN		20
#define		VALIDITY_LEN			5
#define		ORD_TYP_LEN			8
#define		SECURITY_SOURCE_LEN		4
#define		SEC_SOURCE_LEN			5
#define		DAY_POSITION			"DP"
#define		CARRY_POSITION			"CF"
#define		INTEROPS_POSITION		"IP"
#define		ORDER_STATUS			20	
#define		REM_TOT_QTY_LEN			12
#define		ISINCODE_LEN			15
#define		BATCH_CODE_LEN			20
#define		BATCH_OPERATION_MODE_LEN	10
#define		BP_STATUS_LEN			12
#define		BP_TIME_LEN			10
#define		BP_MKT_TYPE			20
#define		BP_ENTITY_ID_LEN		20
#define		BP_MAX_PACKET			5
#define		BP_REMARKS_LEN			20
#define		BP_REMARKS_LENGTH		70
#define		BP_IP_ADDRESS_LEN		50
#define		BP_SEGMENT_LEN			12
#define         BSE_SYM_LEN                	150
#define		SOURCE_FLG_LEN			12
#define		BASKET_DESC_LEN			500
#define		ACTIVITY_TYPE			20
#define		ORDER_TYP_LEN			10
#define		VOLUME_LEN			6
#define		FREQUENCY_LEN			8
#define		ORDER_REASON_LEN		200
#define		INSTRUMENT_LEN		 	10
#define		DB_STATUS_LEN			12		
#define		OPTION_LEN			5
#define 	BSE_LOC_CODE_LEN		18
#define 	ICEX_LOC_CODE_LEN		18
#define 	PAY_ORDER_STATUS		10
#define		FILLER_LEN			50
/*----------------------------------------------------------------------
  LENGTHS for DATABASE Related structures
  ---------------------------------------------------------------------*/

#define		DB_SECURITY_ID_LEN		30
#define		DB_KEY_LEN			60
#define		DB_EXCH_ID_LEN			6
#define		DB_ENTITY_ID_LEN		30
#define		DB_EXCH_ORD_NO_LEN		30
#define		DB_CLIENT_ID_LEN		30
#define		DB_DATETIME_LEN			40	
#define		DB_ACC_CODE_LEN			30
#define		DB_REMARKS_LEN			90
#define		DB_USER_INFO_LEN		16	
#define		DB_REASON_DESC_LEN		300
//#define		DB_REASON_DESC_LEN		600
#define		DB_CLIENT_TYPE_LEN		20
//#define		DB_REASON_DESC_LEN		128
#define 	REASON_DESC_LEN			15
#define		DB_SCRIP_CODE_LEN		30
#define		BUFFER_LEN			30
#define		DB_ISIN_CODE_LEN		20
#define		DB_SYM_LEN			50
#define		DB_SYM_NAME_LEN			40
#define		DB_INS_LEN			7
#define		DB_OPT_TYPE_LEN			3
#define		DB_SERIES_LEN			3
#define		DB_LOT_UNITS_LEN		20
#define		DB_EXCH_TRD_NO_LEN		30
#define		DB_CATEGORY_LEN			10
#define		DB_AMC_CODE_LEN			5
#define		DB_AMC_SCHM_LEN			20
#define		DB_SIP_REJ_NO_LEN		30
#define		DB_EUIN_LEN			20
#define		DB_RT_AGT_CODE_LEN		15
#define		DB_RT_SCH_CODE_LEN		7
#define		NUM_CLIENT_CODE_LEN		3
#define		DB_SCHM_LEN			15
#define		DB_SCHM_NAME_LEN		100	
#define		DB_INSTRU_LEN			10
#define		DB_EXPIRY_LEN			10
#define		DB_CLORDID_LEN			30
#define		DB_LOC_LEN			16
#define		DB_USER_CODE_LEN		30
#define		DB_EXCH_ALLOWED_LEN		10
#define		DB_EXPIRY_FLAG_LEN		5

/*-----------------------------------------------------------------------
  Lengths for checking Validity and Order Type of an Order	
  -----------------------------------------------------------------------*/

#define		VALIDITY_DAY				0
#define		VALIDITY_GTC				1
#define		VALIDITY_ATO				2
#define		VALIDITY_IOC				3
#define		VALIDITY_FOK				4
#define		VALIDITY_GTX				5
#define		VALIDITY_GTD				6
#define		VALIDITY_MIN_FILL			7
#define		VALIDITY_EOS				8

#define		ORD_TYPE_MKT			1
#define		ORD_TYPE_LIMIT			2
#define		ORD_TYPE_STOP_LOSS_MKT		3
#define		ORD_TYPE_STOP_LIMIT		4
#define 	ORD_TYPE_MARK_TO_LMT		5
#define		ORD_TYPE_AON			6
#define 	ORD_TYPE_MKT_TOUCH		7

/*-----------------------------------------------------------------------
  Order Status States
  -----------------------------------------------------------------------*/

#define		EXCH_CONFIRM_STATUS		'C'    
#define 	EXCH_REJECT_STATUS		'R'     
#define 	EXCH_DELETE_STATUS		'D'    
#define 	EXCH_FREEZE_STATUS		'Z'     
#define 	TRANSIT_STATUS			'E'    
#define 	EXPIRED_STATUS			'X'
#define 	TRADED_STATUS			'T'
#define		BLOCK_STATUS			'B'
#define		PAUSE_STATUS			'P'

/*----------------------------------------------------------------------
  Sources
  ----------------------------------------------------------------------*/
#define		SOURCE_MOBILE		'M'
#define		SOURCE_ITS		'W'
#define		SOURCE_ADMIN		'A'
#define		SOURCE_RAPIDRUPEE	'R'
#define		SOURCE_RRSMART		'S'
#define		SOURCE_FALCON		'F'
#define		SOURCE_HELPDESK		'H'
#define		SOURCE_EXCHANGE		'E'
#define		SOURCE_WEB		'I'
#define		SOURCE_SYSTEM		'B'

/*-----------------------------------------------------------------------
  DWS Codes
  ------------------------------------------------------------------------*/

#define         TC_INT_EQU_ORDER_ENTRY                  -5102
#define         TC_INT_EQU_ORDER_MODIFY                 -5103
#define         TC_INT_EQU_ORDER_CANCEL                 -5104
#define         TC_INT_EQU_TRADE_CANCEL                 -5106
#define         TC_INT_EQU_TRADE_MODIFY                 -5105
#define         TC_INT_EQU_AUCTION_ENQ                  -5107
#define         TC_INT_EQU_ODDLOT_ENQ                   -5108
#define         TC_INT_DRV_ORDER_ENTRY                  -4402
#define         TC_INT_DRV_ORDER_MODIFY                 -4403
#define         TC_INT_DRV_ORDER_CANCEL                 -4404

#define         BSE_EXCH_ORDER_NO_LEN                   25
#define         NSE_EXCH_ORDER_NO_LEN                   25


/*----------------------------------------------------------------------
  USER TYPES
  ---------------------------------------------------------------------*/
#define     	CLIENT_TYPE					'C'
#define		DEALER_TYPE					'D'
#define		ADMIN_TYPE					'A'
#define		SUPER_ADMIN					'S'
#define		BRANCH_TYPE					"BR"
#define		DEALER_FILE_NM					"RRCF"
#define		CLIENT_FILE_NM					"RRCL"
#define		ClientFileId					"RRCL_BROKER"
#define		PART_FILE_NM					"RRS_PARTICIPANT"

/*----------------------------------------------------------------------
  Broadcast
  ----------------------------------------------------------------------*/

#define   	INDEX_NAME_LEN				21
#define    	ALPHA_SPLIT_LEN  			2
#define    	MBP_NO_OF_RECS                		10
#define    	NOOF_MKTS_FOR_MW              		4
#define    	BROKER_CODE_LENGTH               	5
#define   	ACTION_CODE_LEN                 	3
#define   	BCAST_MSG_LEN                   	239
#define    	MKTWATCH_NO_OF_RECS           		5
#define    	MAX_INT_MBP_RECS              		2
#define   	MAX_RECORDS_FOR_INDICES			7
#define		MAX_TRADE_RANGE_DATA			25	
#define    	DRV_INDEX_NAME_LEN            		21
#define   	DATE_STRING_LENGTH              	20
#define    	MBO_NO_OF_RECS                		10
#define    	CREDIT_RATING_LEN             		12
#define		CREDIT_RATING_SIZE			17+2
#define    	MARKET_TYPES                  		4
#define    	SEC_DESC_LEN                  		25
#define    	OE_REMARKS_LEN                		25
#define   	ISIN_LEN                        	12
#define    	NOOF_SEC_STS_UPD_PER_PKT      		43
#define    	PARTICIPANT_ID_LEN            		12
#define    	PARTICIPANT_NAME_LEN          		25
#define    	CRPT_ACT_CONST_LEN             		4
#define         EQU_MAX_RECORDS_FOR_MKT_STATS_RPT       7
#define   	NSE_PACKET_SIZE              		1024
#define   	OFFSET                          	315532800
#define   	CONST_PRICE_FACTOR              	100.0
#define 	MAX_NO_OF_THREADS                     	20
#define  	TERMS_MF                          	"MF"
#define 	TERMS_LEN                             	3
#define  	TERMS_AON                         	"AON"
#define   	AUCTION_BOOK                     	7
#define   	ODD_LOT_BOOK                     	5
#define   	SPOT_LOT_BOOK                    	6
#define   	STOP_LOSS_BOOK                   	3
#define   	REGULAR_LOT_BOOK                 	1
#define   	SPECIAL_TERMS_BOOK               	2

#define   	NORMAL_MARKET                    	1
#define   	ODDLOT_MARKET                    	2
#define   	SPOT_MARKET                      	3
#define   	AUCTION_MARKET                   	4
#define   	CALL_AUCTION_MARKET1                 	5
#define         CALL_AUCTION_MARKET2                    6
#define   	MARKET_LEN                      	5
#define   	GOOD_TILL_DATE_LEN                      10
#define         ACCOUNT_CODE_LEN                        10
#define         ORDER_REMARKS_LEN                       24
#define         NNF_SETTLOR_LEN                             12
#define         PRG_TRD_RESERVED_FIELD_LEN              2
#define         SPREAD_2L                               2
#define		SPREAD_LEG_ORDER			1
#define		SINGLE_SPREAD_ORDER			1
#define		DOUBLE_SPREAD_ORDER			2
#define         ACTIVITY_TYPE_LEN                       2
#define         EXPL_REMARKS_LEN                        30
#define         BUY_ACC_LEN                             10
#define         SELL_ACC_LEN                            10
#define         SELL_PARTICIPANT_LEN                    12
#define		EQU_NSE_TICKER_INFO_PER_PKT		28
#define		CU_NSE_TICKER_INFO_PER_PKT		28
#define		FO_NSE_TICKER_INFO_PER_PKT		28
/*----------------------------------------------------------------------
  PARAMETERS FOR DERIVATIVE
  ----------------------------------------------------------------------*/

#define 	DRV_CE					"CE"
#define         DRV_PE                                  "PE"
#define		MAT_DAY					2+1
#define		MAT_MONYR				6+1
#define		MAT_DATE				8+1
#define		BSE_SEC_TYPE				"CS"
#define    	SEND_MSG_LEN        			250
#define    	SYSTEM_MSG_LEN				400
#define         ERROR_MESSAGE_LEN                       150
#define         MESSAGE_LEN                       	40	
#define		MKT_TYPE_LEN				3



/*----- ----------------REquired in RupeeDaemon.c-------------------------*/
#define         MAX_NO_OF_TRANSCODE                                     40

#define         MKT_PREOPEN                                             0
#define         MKT_OPEN                                                1
#define         MKT_CLOSE                                               2
#define         MKT_POSTCLOSE                                           3

#define         MCX_HALTED                                              1
#define         MCX_OPEN                                                2
#define         MCX_CLOSE                                               3

#define         MCX_START                                               1
#define         MCX_END                                                 2

#define         MCX_MORNING_SESS                                        1
#define         MCX_EVENING_SESS                                        2
#define 	MCX_SPECIAL_SESS					3

#define   	SEGMENT_EQUITY                	'E'
#define   	SEGMENT_FNO                   	'D'
#define   	SEGMENT_CURRENCY              	'C'
#define   	SEGMENT_COMMODITY             	'M'
#define		DATE_LENGTH			24	

#define    	MAX_NO_OF_TRANSCODE_TWIDDLE     25
#define         NNF_DATE_TIME_LEN               8
#define    	LOCAL_MAX_PACKET_SIZE           4096


/*---------------End of REquired in RupeeDaemon.c--------------------------*/
#define         INSTR_NAME_LEN                                          6
#define         OPT_TYPE_LEN                                            2
#define         DRV_ASSET_NAME_LEN                                      10
#define         TICKER_INFO_PER_PKT                                     19
#define         DRV_MAX_RECORDS_FOR_INDICES                             15
#define         INSTR_DESC_LEN                                          25
#define         NO_OF_SPD_RECS                                          5
#define         DRV_MAX_RECORDS_FOR_MKT_STATS_RPT                       6
#define         NNF_INDEX_NAME_LEN                                      15
#define         NNF_MAX_NO_INDEX_DETAIL                                 19
#define         NNF_MAX_NO_BASE_PRICE_DETAIL                            40
#define         NNF_INDEX_BCAST_NAME_LEN                                26
#define         NNF_INDEX_CHANGE_NAME_LEN                               10
#define         NNF_MAX_NO_INDEX_DLOAD_DETAIL                           10
#define		ACC_ID_LEN						10	
#define         MOD_CAN_CODE_FOR_DEALER                 		'T'
#define         NO_OF_AUCTION_INQUIRY_RECORDS                           5
#define         INDUSTRY_NAME_LEN                                       15
#define         NOOF_IND_INDICES_PER_PKT                                20
#define         TRADER_NAME_LEN                         26
#define         EXCHANGE_SEQ_NUM_LEN                    8
#define         BROKER_NAME_LEN                         25
#define		CLIENT_NAME_LEN						25
#define         KEY_LEN                                                 8
#define         ERROR_STRING_LEN                                        128
#define         NSE_PASSWORD_LEN                        		8
#define         COLOUR_LEN                                              50
#define         CLASS_NAME                                              14
#define         LDB_UPDATE_PACKET_LEN                   		432
#define         PORTFOLIO_LEN                                           10
#define         MAX_NO_OF_PORTFOLIO                                     25
#define         DRV_CONST_PRICE_FACTOR                             	100.0
#define         COMM_CONST_PRICE_FACTOR 				100.0
//#define 	MAX_NO_OF_TRANSCODE_RECV                 		25
#define 	MAX_NO_OF_TRANSCODE_RECV                 		50
#define   	SECURITY_LEN                     			12
#define    	ADMIN_MSG_LEN                   			512
#define   	GEN_CHAR_BUFF_SIZE              			256
#define   	CURR_CONST_PRICE_FACTOR      				10000000
#define   	HEADLINE_LEN						30	
#define		NEWS_TEXT_LEN						300
#define		MAX_NEWS_SIZE						50
#define         TIMEZONE                				19800
#define		OFF_MKT_STATUS_LEN					10	

#define         EXCH_MKT_PREOPEN					0
#define         EXCH_MKT_OPEN						1
#define         EXCH_MKT_CLOSE						2 
#define         EXCH_MKT_PREOPENEND					3


/*--------------BhavCopy Reports Broadcast-------------------*/

#define 	EQ_BCPY_HEADER_BCAST					'H'		
#define		EQ_BCPY_REPORT_DATA_BCAST				'R'
#define		EQ_BCPY_TRILR_RECRD_BCAST				'T'
#define		FO_FINAL_BHAVCOPY_RPT					'M'

#define		DIGEST_LEN						16
#define     	WORK_STATION_ADDR_LEN            			14
#define		MAX_NO_STREAMS						50
#define 	MSG_AREA_EQ_DLD_DATA_LEN 				472
#define		EXCHANGE_DOWN_ERROR					420
#define		DELTA_REMARKS						15
#define   	REPLY_TEXT_LEN                          		40
#define		CATEGORY_CODE_LEN					5
#define		AMC_CODE_LEN						3
#define		AMC_SCHEME_LEN						10
#define		RTA_CODE_LEN						10
#define		RTA_SCHEME_LEN						5	
#define		APPL_NUM_LEN						10
#define		DEPOSIT_ID_LEN						8
#define		DEPOSIT_CLIENT_LEN					16
#define		DEPOSIT_CODE						8		
#define		FOLIO_NUM_LEN						16	

#define		MODE_HOLD_LEN						2
#define		NUM_CLIENT_CODE						3
#define		CLI_CODE_LEN						10
#define		CLI_NAME1_LEN						70				
#define		CLI_NAME2_LEN						35				
#define		CLI_NAME3_LEN						35				
#define		NUM_OF_PAN_LEN						3
#define		PAN_CARD_LEN						10
#define		KYC_COMPL_LEN						3
#define		NUM_OF_ADDR_LEN						3
#define		ADDRS_LEN						40
#define		CITY_LEN						35
#define		STATE_LEN						2
#define		PHONE_OFC_LEN						8
#define		PHONE_RES_LEN						8
#define		MOBILE_NUM_LEN						10
#define		PHONE_LEN						12
#define		EMAIL_ADDR_LEN						50
#define		BANK_NAME_LEN						40
#define		BANK_BRANCH_LEN						40
#define		BANK_CITY_LEN						35
#define		ACC_NUM_LEN						40
#define		ECHO_BACK_LEN						4
#define		NEFT_CODE_LEN						11
#define		BANK_ACC_TYPE_LEN					10
#define		DOB_LEN							8
#define		GUARD_NAME_LEN						35
#define		GUARD_PAN_NUM_LEN					10
#define		NOMIEE_NAME_LEN						40
#define		NOMIEE_REL_LEN						40
#define		SUB_BROKER_LEN						15
#define		SIP_REG_NEM_LEN						15
#define		EUIN_LEN						10
#define		PIN_CODE_LEN						6
#define		NNF_CLI							'C'
#define		NNF_PRO							'P'
#define		NNF_NRI							'N'
#define		NNF_FII							'F'
#define    	PARTICIPANT_CODE_LEN                                    12
#define		EQ_DRV_FLAG						'N'
#define		FO_DRV_FLAG						'Y'
#define		CUR_DRV_FLAG						'C'
#define		ALPHA_SPLIT						"NT"
#define     	BSE_PASSWORD_LEN    					11
#define     	BSE_REPLY_TEXT_LEN    					40
#define 	BSE_NEWS_DATA_LEN 					400
#define		BSE_INDEX_ID_LEN					6+1			
#define		BSE_ALGO_ID_LEN						16
#define		BSE_PARTICIPANT_CODE_LEN				20

#define 	NO_OF_SLOTS             				2000 
#define 	NO_OF_SLOTS_QRY  					2
#define 	NO_QRY_IML           					1
#define		PROC_NAME_LEN						20

#define         NEW_ORDER						'N'
#define		ORDER_MODIFY						'M'
#define		ORDER_CANCEL						'C'

#define 	RMS_CURR					"RMS_VALIDATE_CUR"
#define		RMS_EQ_FO					"RMS_VALIDATE"
#define		REGISTRATION_LEN					200
#define		PROTOCOL_SLOT						-1
#define		BSE_ERR_LEN						81	

#define		REG_SUCCESS_RESP					0
#define		INVALID_MSG_TYPE					100
#define		CONN_REFUSE_RESP					800
#define		SLOT_FULL_RESP1						801
#define		SLOT_FULL_RESP2						804
#define		APP_ERR_RESP						802
#define		INVALID_ACCESS						803
#define		INVALID_SLOT_TYPE					805
#define		MAX_BSE_RETRY						100
#define     	BSE_PACKET_SIZE						4096
#define 	OPEN							'O'
#define		RETRY_CNTR						100

/*-------------Trade Router---------------*/
#define 	Max_Num_Threads                 			3
#define 	WEB_RELAY_ID                    			222
#define 	FIND_USER_RELAY_ERROR           			-1
/*------------------------*/


#define 	USER_LOGIN						"USER SUCCESSFULLY LOGIN FOR TRADING"
#define		ORD_CAT_LEN						10

#define		COLOR_LEN						50
#define		MFSS_LDB_UPDATE_PACKET_LEN				948
#define		MFSS_MSG_AREA_DLD_DATA_LEN				1052
#define     	ENV_VARIABLE_LEN                			30
#define         TERMINAL_INFO_LEN               			15+1
#define    	CONNECTED_TO_EXCH                       		'A'
#define    	P_LEN                                   		80
#define    	EQU_NSECONN_USER_ID_LEN                 		4
#define    	SIZE                                    		80	
#define         LISTENQ                                 		10
#define     	TRADE_NO_LEN                    			16+1

/****************************  NNF  ****************************/
#define		RESET_EQU						1
#define		SET_EQU							2
#define		TAP							1
#define		MAX_NO_UPDATE						100
#define 	BSE_ERR_LEN 						81	
#define     	BSE_PASSWORD_LEN    					11
#define     	BSE_REPLY_TEXT_LEN    					40	
#define 	PASSWORD_EXPIRED 					218
#define     	LOGON_SUCCESSFUL        				712
#define     	LOGON_SUCCESS           				159
#define     	USER_ALREADY_LOGGED_ON  				164
#define     	LOG_OFF_REQ_LEN         				150
#define   	PASSWORD_LEN                    			16
#define     	LOGOFF_SUCCESS          				160
#define     	REQUEST_SLOT            				3
#define     	UNUSED_SLOT             				-2
#define 	RETRY                   				5
#define      	OBFS_LEN                				40
#define  	MAX_USERS                               		500
#define 	SYS_TIME_LEN    					40
#define 	RESET_DRV 						3
#define 	SET_DRV 						4
#define     	USED_SLOT               				0	
#define 	SIZE_OF_TRANS_ID       					19
#define     	REJECTED_PACK_SIZE      				200	
#define 	DATETIME_LEN   						19
#define     	OMB_HEADER_LEN          				8
#define     	MAX_NO_PROCESSES        				4
#define		MAX_TRY							5
#define     	USER_HAS_LOGGED_OFF     				165	
#define     	SYS_DONOT_RECOGNIZE     				158
#define     	LOGIN_REQ_PACKET_SIZE   				600
#define     	BREAKCOUNTER            				100
#define     	BYTES_TO_READ           				4096
#define 	TIMEZONE_BSE            				5*60*60
#define 	TIME_LENGTH             				9
#define 	TIMESTAMP_LENGTH        				20
#define     	MAX_CONNECT_BREAK       				100
#define		PASS_TYPE_LEN						10
#define         LOOP_COUNTER 						10
#define     	NEWS_CATEGORY_TITLE_LEN 				42
#define   	BSE_CLIENT_LEN    					12
#define 	TRADE_RECS 						10
#define 	INDEXID_LEN 						6
#define 	NO_INDEXVAL 						10
#define 	NO_BEST 						5
#define 	NO_MKTINFO_SCRIP  					4
#define 	BSE_NO_OF_SCRIPS 					1
#define     	RECVCHLD                				0
#define     	RUNNING                 				1
#define     	TRANSCHLD               				1
#define     	KEEPALIVE               				2
#define 	ADDRESS_LEN             				20
#define         CLI_STRING_LEN                                  	300

/*---------------------BATCH_NAME-----------------*/
#define  	INTRADAY_SQUREOFF					"I_SQ_OFF"
#define		COVER_ORD_SQUREOFF					"CO_SQ_OFF"
#define		BRACKET_ORD_SQUREOFF					"BO_SQ_OFF"
#define		OFFMARKET_PUMPER					"OFFMKT_PUMP"
#define		SIP_DAY							"SIP_DAILY"
#define 	SIP_MONTH						"SIP_MONTHLY"
#define		SIP_WEEK						"SIP_WEEKLY"
#define		SIP_DY							'D'
#define		SIP_MON							'M'
#define		SIP_WK							'W'
#define 	INTRADAY_CROSS_CUR_SQROFF 				"I_SQ_OFF_CC"
/*--------------------------NSE Bcast -------------------------------*/
#define  	MAX_NO_THREADS 						3
#define 	CALLING_LENS    					20
#define 	NSE_MAX_PACKET_SIZE 					2560
#define    	NOT_TWIDDLE                     			999	
#define 	MAX_PACKET_SIZE_COMPRESS 				1600
#define 	NSE_MAX_PACKET_RECV_SIZE  				1050
#define 	WS_ADDRESS_LEN 						8
#define 	X25_LINK_NAME_LEN 					8
#define         OPTION_SIZE                             		3
#define         DRV_XX                                  		"XX"	
/*--------------------------------------------------------------------*/


/*--------------------------BSE Bcast -------------------------------*/
#define         BSE_MAX_BCAST_MSG_LEN   			2048
#define		EXCH_REJ_MSG					"EXCH"

#define		BSE_ACT_ADD					'A'
#define		BSE_ACT_UPD					'U'
#define		BSE_ACT_DEL					'D'

//-----------------------BSE AUTION ---------------------------------
#define		BSE_AUCTION_ADD					10001
#define		BSE_AUCTION_UPD					10002
#define		BSE_AUCTION_DEL					10003

//------------------------------------------------------------------

#define		BSE_ORD_TYPE_MKT				'G'
#define		BSE_ORD_TYPE_LMT				'L'
#define		BSE_ORD_TYPE_SL					'P'
#define 	BSE_ORD_TYPE_IOC				'C'

#define		BSE_PRO						20
#define		BSE_CLI						30
#define		BSE_SPCLI					40

#define		BSE_VALIDITY_DAY				2
#define		BSE_VALIDITY_IOC				0
//#define		BSE_VALIDITY_GTC				1
#define		BSE_VALIDITY_EOS				1

#define		PRICE_CONVERTER					100.0
#define		MAX_COBO_LEN					3

#define     	TEMP_STRUCT_LEN                 		4	


#define		MAX_NO_OFFLINE_THREAD				5

#define 	FLAG_LEN					10




#define     SOCKET_CLOSE                                        0
#define     SOCKET_EXIST                                        -2
#define     MAX_NO_OF_USER_SOCKETS                              1000
#define     MAX_NO_OF_OP                                                5
#define     MAX_PACKET_SIZE                                       2048
#define     MAX_NO_OF_CLIENT					50
#define     MAX_STW_USERS                   			1000	
#define     NOT_TRUE                                            -1
#define     UNUSED                                      -1
#define     MAX_READ_THREADS                                    300
#define     MAX_WRITE_THREADS                                   300
#define     MAX_WRITE_DLOAD_THREADS                             100
#define     MAX_WRITE_IOR_THREADS                               200
#define     MAX_NO_OF_PROCESS                                   4
#define     RESTART                                             -3
#define     BREAK_COUNTER                                       10
#define         QUERYQPCNT_FREE                                         0.1
#define         DLOADQPCNT_FREE                                         0.3
#define         DLOADDIRQPCNT_FREE                                      0.3
#define         READ_THREAD                                                     1
#define         WRITE_THREAD                                            2
#define         WRITE_DLOAD_THREAD                                      3
#define         WRITE_IOR_THREAD                                        4
#define         INIT                                                            0
#define         INSERT                                                          1
#define         DELETE                                                          2
#define         SELECT                                                          3
#define         REVSELECT                                                       4
#define		ERR_HASH_LEN					12

#define		NO_ROWS						2
#define         STATUS_LEN                      		8
#define         REASON_LEN                      		50
/***************PRE OPEN FLAG **********************/
#define		YES			'Y'
#define		STR_YES			"Y"
#define		STR_NO			"N"
#define		NO			'N'
/****************************************************/

#define		COMMODITY_TYPE		"COMMODITY"
#define		CAPITAL_TYPE		"CAPITAL"
#define		ALL_TYPE		"ALL"	

#define		SELECT_ALL		"%"
#define		SEL_ALL			'%'	
#define		ALL			'A'
#define		ALL_SELECT		"-1"
#define		MODIFY 			1	
#define		CANCEL			2
#define		CONTINUE		3

#define		RMS_ERR_PREFIX				"RMS"	
#define		OMS_ERR_PREFIX				"OMS"	

#define		EXCH_MSG_LEN				239	

#define		COMMAND_LEN				200
#define         RADIS_KEY_LEN           		20

#define		ALL_SQUAREOFF_POSITION			0
#define		MAX_LOSS_POSITION			1
#define		MIN_LOSS_POSITION			2
#define		MAX_PROFIT_POSITION			3

#define		TC_EQU_BSE_END_OF_DOWNLOAD_1_UMS	21501

/**************** ADMIN FLAG ************************/
#define		DEBIT_BALANCE_FLAG			1
#define		MARGIN_SHORTFALL_FLAG			1

#define 	ORDER_EXRIRED_SUCCESS			"Order Expired Success"
#define		SEC_SPRD_LEN				20

#define		ZIP_PASSWORD				"JNEJ@kjoiwec109232wfh832nklfn983jbcw"

#define		INT_NL_MKT_TYPE				1
#define		INT_OL_MKT_TYPE				2
#define		INT_SP_MKT_TYPE				3
#define		INT_AU_MKT_TYPE				4
#define		INT_AU1_MKT_TYPE			5
#define		INT_AU2_MKT_TYPE			6
#define         COMPANY_ID_LEN                  	30
#define         IPOORDTYPE_LEN                  	8
#define         MODE_LEN                                8
#define         PROFILE_ID_LEN                          4

/*------------ BSE MF -----------------------------------*/
#define		TRANSCODE_LEN				4
#define		LOGIN_ID_LEN				25
#define		MEMBER_ID_LEN				10
#define		BSE_MF_PASSWORD_LEN			8
#define		STAR_MFID_LEN				30
#define         COMPANY_OFF_LEN				30
#define		DEALER_ID_LEN				30
#define		BRANCH_CODE_LEN				10
#define		REPLY_CODE_LEN				3
#define		SESSION_LEN				50
#define		SETTLEMENT_NO_LEN			7
#define		TRADE_DATE_LEN				11
#define		CURRENT_TIME_LEN			8
#define		LOGON_RESP_MESSG_LEN			250
#define		LOGOFF_RESP_MESSG_LEN			100
#define		ORD_RESP_MESSG_LEN			1000

#define		SCHEME_TOKEN_LEN			5
#define		SCRIP_CODE_LEN				20
#define		BUY_SELL_TYPE				10
#define		CLIENT_CODE_LEN				10
#define		AMOUNT_LEN				17
#define		ORG_PURCHASE_AMOUNT_LEN			17
#define		REDEM_QTY				17
#define		ORG_REDEM_QTY				17
#define		FOLIO_NO_LEN				16
#define		SIP_FOLIO_NO_LEN			20
#define		BSE_MF_REMARKS_LEN			200
#define		SIP_REMARKS_LEN				100
#define		BRANCH_CODE				10
#define		REFERENCE_NO				30
#define         REFERENCE_NO_LEN                	20
#define		INT_REFERENCE_NO			10
#define		ORDER_NO_LEN				16
#define		LAST_MODIFIED_DATE_LEN			11
#define		LAST_MODIFIED_TIME_LEN			8
#define		SUB_BROK_CODE_LEN			20
#define		EUIN_LEN				20
#define		MIN_REDEM_FLAG				25
#define		FILLER_LEN_25				25
#define		SUB_BROK_ARN_CODE			20
#define		FILLER_LEN_20				20
#define		BSE_AMC_CODE_LEN			50
#define		SCHEME_CODE_LEN				20
#define		FREQUENCY_TYPE				20
#define		SIP_START_DATE				10
#define		SIP_END_DATE				10
#define		SIP_REGISTRATION_NO_LEN			10
#define		SIP_REGISTRATION_DATE_LEN		10
#define		DELTA_LAST_DATE				11
#define		DELTA_LAST_TIME				8
#define		ACC_TYPE_LEN				10
#define		USER_TYPE_LEN				12

#define		TAG_LEN					4
#define		NSEEQ_CODE_LEN				14
#define		NSEFO_CODE_LEN				14
#define		NSECD_CODE_LEN				14
#define		BSEEQ_CODE_LEN				14
#define		BSEFO_CODE_LEN				14
#define		PROD_ALLOWED_LEN			6
#define		MCX_CODE_LEN				14	
#define		RISK_PROF_LEN				15
#define		BASKET_LEN				15
#define		MARGIN_METHOD_LEN			4
#define		RPM_CODE_LEN				15
#define		PRODUCT_ENABLE_LEN			15
#define		CONTROLLER_ID_LEN			12
#define		BROKER					"BROKER"
#define		MAX_ADHOC_VALUE				"MaxAdhocValue"
#define		ROLE_ID					29
#define		ADMIN					"ADMIN"
#define		RESET					'R'
#define		PRO_SUCCESS				"S"

#define		ADD_IPO_DETAILS				'A'
#define 	EDIT_IPO_DETAILS			'E'
#define 	DEL_IPO_DETAILS				'D'
#define 	VIEW_IPO_DETAILS			'V'

#define		ADD_BASKET				'A'
#define		UPDATE_BASKET				'U'
#define		DEL_BASKET				'D'
#define		VIEW_BASKET				'V'
#define		ALL_BASKET				'U'
#define		BASKET_NAME				'N'
#define		DEL_BASKET_NAME				'E'

#define		ADD_RP					"ADD_RP"
#define		PROFILE_ADD_R                           'R'
#define		RMS_PROFILE_BASED_SQROFF		'P'
#define		IFSC_CODE_LEN				25
#define		PAY_MODE_LEN				25
#define		PAY_MODE_MSG_LEN			100
#define		LIMIT_TYPE_LEN				45
#define		LIMIT_LEN				20
#define 	MOBILE_LEN				12
#define		NOTES_LEN				30
#define		COMMENT_LEN				150
#define		EDIT_PROFILE				"EDITMAIN"
#define		BANK_ACC_NUM_LEN			30
/*------------------BSE STAR MF----------------------------------*/

#define		DB_TRANSCODE_LEN			6
#define		DB_SCHEME_TOKEN_LEN			7
#define		DB_SCRIP_CODE_LEN			25
#define		DB_BUY_SELL_TYPE			12
#define		DB_CLIENT_CODE_LEN			12
#define		DB_MEMBER_ID_LEN			12
#define		DB_AMOUNT_LEN				20
#define		DB_ORG_PURCHASE_AMOUNT_LEN		20
#define		DB_REDEM_QTY				20
#define		DB_ORG_REDEM_QTY			20
#define		DB_FOLIO_NO_LEN				20
#define		DB_BSE_MF_REMARKS_LEN			225
#define		DB_LOGIN_ID_LEN				30
#define		DB_BRANCH_CODE				12
#define		DB_DEALER_ID_LEN			15
#define		DB_REFERENCE_NO				35
#define		DB_SESSION_LEN				55
#define		DB_ORDER_NO_LEN				20
#define		DB_LAST_MODIFIED_DATE_LEN		15
#define		DB_LAST_MODIFIED_TIME_LEN		10
#define		DB_SUB_BROK_CODE_LEN			24
#define		DB_EUIN_LEN				24
#define		DB_MIN_REDEM_FLAG			28
#define		DB_SUB_BROK_ARN_CODE			24
#define		DB_ACTION_CODE_LEN			5
#define		DB_FILLER_LEN_25			30
#define		DB_FILLER_LEN_20			25

#define		NET_QTY					'0'
#define		ORD_STATUS				"Pend/Mod"
#define		ORD_PEND				"Pending"
#define		ORD_MODIFY				"Modified"	
#define		OFF_ORD_ENABLE				'1'
#define		OFF_ORD_DISABLE				'0'
#define         FILLER_3_LEN                            25
#define 	PATH_LEN				20
#define		NOT_AVAILABLE				"NA"
#define		SIP_FLAG				"SIP_EQ_FLAG"
#define		SIP_UNABLE_FlAG				'Y'
#define         SIP_REMARKS                		"This is SIP Order"
#define         SIP_PERIOD				"SIP_PERIOD"
#define         SIP_HOLIDAY_CHECK			"SIP_HOLIDAY_CHECK"


#define		EQ_ORD_NO_START				1
#define         DR_ORD_NO_START                         2
#define         CU_ORD_NO_START                        	3
#define		OFF_ORD_NO_START			5
#define		SIP_ORD_NO_START			6 
#define  	MCX_ORD_NO_START			8
#define  	BSE_ORD_NO_START			7
#define  	BSE_COM_ORD_NO_START			9
#define		NCM_ORD_NO_START			10
#define		ICEX_ORD_NO_START			11
#define         GTT_ORD_NO_START                        13
#define         BSECD_ORD_NO_START                      14

#define         MCX_CONST_PRICE_FACTOR          	100
#define         ICEX_CONST_PRICE_FACTOR          	100
#define		CLIENT_CODE				"CLIENT_IDS"
#define		TICK_SIZE_VAL 				0.05


#define         NNF_PAN_NUM_LEN                         10
#define         DRV_BROKER_NAME_LEN                     25

#define         PARTICI_BROKER                          'B'
#define         PARTICI_SETTLOR                         'S'

#define         INT_PAN_LEN                             12
#define		NNF_RESERVED_LEN			60


/********************** NEW VALUE *****************/
#define		DB_SYMBOL_LEN				15
#define		LIMIT_TYP_LEN				12

#define		MCX_DATE_TIME_LEN			20
#define		MCX_MKT_TYPE_LEN			5
#define		MCX_DATE_TIME_LENGTH			4
#define 	MCX_EXCH_MSG_LEN			239+1
#define		MKT_DESC_LEN				45	

#define		ENTITY_NAME_LEN				70
#define		BRANCH_TYPE_LEN				5
#define		ADD_LEN					300
#define		SUB_ADD_LEN				100
#define		USER_REMARKS_LEN			100
#define		EXCH_ALLOWED_LEN			10
#define		RPM_NAME_LEN				100

#define 	DB_ENTITY_CODE_LEN			30
#define 	DB_ENTITY_NSE_CODE_LEN			12
#define 	DB_ENTITY_MCX_CODE_LEN			12
#define		DB_ENTITY_TYPE_LEN			3
#define		DB_ENTITY_SUB_TYPE_LEN			5
#define		DB_ENITY_SETTLOREQ_LEN			12
#define		DB_ENITY_SETTLORDRV_LEN			12
#define		DB_ENITY_SETTLORCURR_LEN		12
#define 	BRANCH_ID_LEN				30	
#define 	BRNCH_STAT_LEN				30	


#define 	CLIENT_MASTER_FILE_NM			"RR_ADCM"	
#define 	ORDER_REPORT_FILE_NM			"RR_ADOR"	
#define 	TRADE_REPORT_FILE_NM			"RR_ADTR"	
#define 	CLIENT_LIMIT_FILE_NM			"RR_ADCL"	
#define		CALCSPAN_FILE				"RR_SPAN"	
#define		SPAN_MASTER_FILE			"SPAN_MASTER"
#define		DRV_EXPOSER_FILE			"DRV_EXPOSER"
#define		MCX_EXPOSER_FILE			"MCX_EXPOSER"
#define		VAR_ELM_FILE				"VAR_ELM"
#define		DRV_POSITION_FILE			"DRV_CF_POS"
#define		COMM_POSITION_FILE			"COMM_CF_POS"
#define		EQ_POSITION_FILE			"EQ_CF_POS"
	

#define		MAX_FILE_LEN				40	
#define		MAX_MES_LEN				40	



#define         FILE_CLIENT_MASTER			1 
#define         FILE_ORDER_REPORT			2 
#define         FILE_TRADE_REPORT			3 
#define         FILE_CLIENT_LIMIT			4 


#define         URL_LEN					70 
#define		MAX_COMMAND_LEN				4096
	
/******************* NEW SUB FIELD ********************/


#define		SUB_TYPE_PRO					1	
#define		SUB_TYPE_NRI					2
#define		SUB_TYPE_INSTITUTE				3
#define		SUB_TYPE_NON-INSTITUTE				4
#define		SUB_TYPE_FOREIGN				5
#define		SUB_TYPE_CLIENT					7

/********************************************************/
#define		QL_NAME_LEN					15
#define		BLOCK_INFO_LEN					50
#define		PROFILE_NAME					100
#define         PROFILE_CODE                                    15
#define         LINE_NUMBER                                     5
#define         DP_ID_LEN                                       30
#define         BEN_ACC_TYP_LEN                                 30
#define         BEN_ACC_POSITION_LEN                            30
#define         ISIN_STATUS_LEN                            	30
#define         ISIN_TYPE_LEN                            	30
#define 	BEN_CATEGORY					10
#define 	RECORD_TYPE					10
#define 	BLOCK_LOCK_CODE			  		10

#define		PIN_CODE_LEN					15
#define		CLIENT_TYPE_LEN					15
#define		STATUS_LEN_SIZE					15
#define		ORDER_TYPE_LEN					10
#define		CUSTOM_SYM_LEN 					40
#define		INSTRUMENT_TYPE					50

/***********************NEW STRATEGY ID****************************/
#define		STRG_INT_SQR_OFF				101	
#define		STRG_CO_SQR_OFF					102
#define		STRG_BO_SQR_OFF					103
#define		STRG_OFF_ORD_PUMP				104
#define		STRG_SIP_ORD_PUMP				105
#define		STRG_MTM_SQR_OFF				106
#define		STRG_CKT_SQR_OFF				107

/***********************NEW STRATEGY ID****************************/

/*** Adding Strategy Id in Definition for Auto pump order and Trades  ***/
#define         STRAT_OFF_MKT_ORDS      200


/***********************FOR MASTER SLAVE **************************/
#define		OMS_MASTER						'M'
#define		OMS_SLAVE						'S'
/***********************FOR MASTER SLAVE **************************/

#define 	MULTICAST_TYPE					'M'
#define		BROADCAST_TYPE					'U'

//Declared following two variable @suraj
#define		FILE_DATA_SIZE					3000	
#define		FILE_ROW_SIZE					275	
#define 	NOTI_MAX_PACKET_SIZE   				2048
#define 	NOTI_SYMBOL_LEN   				50

#define         NNF_HOST_IP_LEN                                 16
#define         NNF_SESSION_KEY_LEN                             8

#define         TRADE_SMS_FLAG                                 'S'
#define         TRADE_EMAIL_FLAG                               'E' 
#define         TRADE_SMS_EMAIL_FLAG                           'Y' 
#define         TRADE_NO_SMS_EMAIL_FLAG                        'N'   

#define         ICEX_EXCH                        	"ICEX"

#define         ICEX_HALTED                                              1
#define         ICEX_OPEN                                                2
#define         ICEX_CLOSE                                               3

#define         ICEX_START                                               1
#define         ICEX_END                                                 2

#define		ICEX_SYMBOL_LEN						30
#define		ICEX_PARTY_ID_LEN					30
#define		PARTY_ROLE_LEN						5
#define 	ICEX_MKT_TO_LMT						'K'
#define 	ICEX_MKT_IF_TOUCHED					'J'
#define		CURR_PRICE_FACTOR				10000
#define		KEY_WORD_MONITORING				"MONITORING" /** Exchange connection keyword to grep for monitoring **/
#define		POSITION_TYPE_LEN				15
#define    	INTSQROFF_ORDER_VAL_LEN         			5
#define		NET_QTY_LEN				20
#define		NET_VAL_LEN				20

/** Create NEAT File for Order cancellation and Position Square Off***/
#define         FILE_NEAT_ORDERS_POST           5
#define         RR_NEAT_EQ_ORDERS               "EQ_ORD_NEAT"
#define         RR_NEAT_EQ_POSTION              "EQ_POS_NEAT"
#define         RR_NEAT_FO_ORDERS               "FO_ORD_NEAT"
#define         RR_NEAT_FO_POSTION              "FO_POS_NEAT"
#define         RR_BOLT_EQ_ORDERS               "EQ_ORD_BOLT"
#define         RR_BOLT_EQ_POSTION              "EQ_POS_BOLT"
#define         RR_NOW_POSITION                 "NOW_POSITION"

#define         FILE_NEAT                       5
#define         FILE_NOW                        6
#define         FILE_BOLT			7
#define         BSE_INT_ALGO_ID_LEN             20

#define         PRE_OPEN                 	"EXCH_PRE_OPEN"	
#define         PRE_CLOSE                	"EXCH_PRE_CLOSE"
#define         OPEN_MARKET	                "EXCH_OPEN_MARKET"
#define         CLOSE_MARKET                    "EXCH_CLOSE_MARKET"
#define         POST_OPEN	    	        "EXCH_POST_OPEN"            
#define         POST_CLOSE               	"EXCH_POST_CLOSE"

#define		MARKET_SESSION_LEN			20

/*** Adding DMA Location code for NSE ****/
#define         NSE_EQ_DEALER_DMA_ONLINE                "222222222222"
#define         NSE_DR_DEALER_DMA_ONLINE                "222222222222"
#define         NSE_CD_DEALER_DMA_ONLINE                "222222222222"

#define         COVER_ORD_SQUREOFF_CC                                   "CO_SQ_OFF_CC"
#define         BRACKET_ORD_SQUREOFF_CC                                 "BO_SQ_OFF_CC"

#define         DMA_HANDLE_INST         '8'

#define		REDIS_HOST_LEN				50

#define		REDIS_TYPE_PRICE_BCAST			1
#define		REDIS_TYPE_ORDER_BCAST			2
#define		REDIS_TYPE_MKT_STATUS			3
#define		REDIS_TYPE_CLIENT_ADD			4
#define 	REDIS_TYPE_RMS_VALIDATION		5
#define         REDIS_TYPE_CLEARING_MEM                 6

#define 	BSE_ORDER_RECS 						12

#define         GTT_ORDER                       'G'
#define         OCO_ORDER                       'O'

#define        	PLATFORM_LEN                 30
#define        	CHANNEL_LEN                  30
#define        	FILLER		             50
/** BSE FIX ****@Abhishek ***/

#define         NETWORK_MSG_ID                  8
#define         FIX_ACCOUNT                     2
#define         PARTY_TRD_FIRM                  5
#define         PARTY_ORG_ORD_FIRM              7
#define         PARTY_ID_BENIF                  9
#define         REGULATORY_TXT                  20
#define         BSE_ALGO_ID                     16
#define         CLIENT_UCC_CODE                 12

#define         DEFAULT_CUST_APP_VER_ID_LEN     30
#define         BSE_ETI_PASSWORD_LEN            32

#define         FIX_ENGINE_NAME_LEN             30
#define         FIX_ENGINE_VERSION_LEN          30
#define         FIX_ENGINE_VENDOR_LEN           30
#define         FIX_APP_SYSTEM_NAME_LEN         30
#define         FIX_APP_SYSTEM_VERSION_LEN      30
#define         FIX_APP_SYSTEM_VENDOR_LEN       30


#define         FIX_BSE_ACCOUNT_LEN             2
#define         FIX_BSE_UCC_LEN                 12
#define         PARTY_TRD_FIRM_LEN              5
#define         PARTY_ORG_ORD_FIRM_LEN          7
#define         PARTY_ID_BENIF_LEN              9
#define         FIX_ACCOUNT_LEN                 2
#define         PARTY_LOC_LEN                   2
#define         NETWORK_MSG_ID_LEN              8
#define         REGULATORY_TXT_LEN              20
#define         ETI_ALGO_ID_LEN                 16
#define         CLIENT_UCC_CODE_LEN             12
#define         ETI_PARTICIPANT_LEN             12
#define         FREE_TXT_LEN                    12
#define         APP_MSG_IDTFR_LEN               16
#define         FILL_RECORD_CNT                 100
#define         LEG_RECORD_CNT                  600

#define         ETI_PAD7_LENGHT                 7
#define         ETI_PAD6_LENGHT                 6
#define         ETI_PAD5_LENGHT                 5
#define         ETI_PAD4_LENGHT                 4
#define         ETI_PAD3_LENGHT                 3
#define         ETI_PAD2_LENGHT                 2
#define         NO_OF_ORD_LEN                   500

#define         ETI_SUBSCRIBTION_TRADES                 1
#define         ETI_SUBSCRIBTION_NEWS                   2
#define         ETI_SUBSCRIBTION_SERVICE_AVAIABLITY     3
#define         ETI_SUBSCRIBTION_LISTER_DATA            5
#define         ETI_SUBSCRIBTION_TRADE_ENHANSEMENT      0

/****** NCDES******/

#define         NCDEX_EXCH                      "NCDEX"

#define         NCDEX_HALTED                    1
#define         NCDEX_OPEN                      2
#define         NCDEX_CLOSE                     3

#define         NCDEX_START                     1
#define         NCDEX_END                       2

#define         NCDEX_SYMBOL_LEN                30
#define         NCDEX_PARTY_ID_LEN              30
#define         PARTY_ROLE_LEN                  5
#define         NCDEX_MKT_TO_LMT                'K'
#define         NCDEX_MKT_IF_TOUCHED            'J'
#define         NCDEX_IDSOURCE                  "8"
#define         NCDEX_SYM_LEN                   10
#define         NCDEX_SERIES_LEN                2


#define         GTT_ORDER                       'G'
#define         OCO_ORDER                       'O'
#define         MAX_NO_OF_OWS_PROCESS           1
#define         ENCR_CLIENT_FILE_NM                                     "ERRCL"
#define         Encr_ClientFileId                                       "ERRCL_BROKER"

#define         CHECK_UPPLER_SIDE               'U'
#define         CHECK_LOWER_SIDE                'L'
#define         DISABLE                         'D'
#define         ENABLE                          'E'
#define    	TRADE_TPUSH_FLAG                'P'
#define         NOTI_CLIENT_NAME_LEN            100
#define         NOTI_MOBILE_NUM_LEN             12

/*******************NOTIFICATION RESPONSE LENGTH*******************/

#define         ADMIN_REMARKS_LEN               502
#define		MAX_GROUP_ID			20
#define		MAX_INSTANCE_ID			30
#define         ALGO_ID_LEN                     24
#define         EXTRA_REMARKS_LEN               30
