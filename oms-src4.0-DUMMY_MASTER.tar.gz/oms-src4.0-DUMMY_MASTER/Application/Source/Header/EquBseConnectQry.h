#ifndef _BSECONNECT_H_
#define _BSECONNECT_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/resource.h>
#include <sys/msg.h>
#include <sys/errno.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <errno.h>
#include <netinet/in.h>
#include <memory.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <openssl/des.h>
#include <openssl/crypto.h>

#include    "Comm_def.h"
#include    "Common.h"
#include    "EquBseTCodes.h"
#include    "EquBseExchStruct.h"
#include	"IPCS.h"
#include	"Unix.h"
#include 	"IntTCodes.h"
#include    "ConnectStatusQryIML.h"

#define FOREVER  for(;;)
#define RECV_SIZE 4096
#define BSE_PACKET_SIZE        4096
#define HOST_SERV_PORT1 7002
#define HOST_SERV_PORT2 7003
#define LOOP_COUNTER 10
#define COUNT_TO_ERROR 10
#define ERROR -1
#define LISTENQ 10
#define SIZE 80  
#define USER_REG_REQ_LEN                        200
#define USER_REG_RESP_LEN                       200
#define LOG_ON_OFF_REQ_LEN                      150
#define LOG_ON_OFF_RESP_LEN                     600
#define SIZE_OF_END_DOWNLOAD    50
#define	RETRY			5
#define	DBG	1
#define ADDRESS_LEN             20
#define PROTOCOL_SLOT           -1
#define BUFSIZE 128
#define MAX_SIZE 100
#define NO_OF_RETRIES 10
#define PASSWORD_EXPIRED 218
#define ITERATIONS 100
#define	DOWNLOAD_REQ_PACKET	31
#define	OMB_HEADER_LEN		8
#define	MAX_DLOAD_PACK_SIZE	4096
#define	NORMAL_READ_PACKET	200
#define TIMESTAMP_LENGTH        20
/**#define	NO_OF_SLOTS		20  **/ /***Changes done as no of slots increase****/
#define	NO_OF_SLOTS		7  /*** Changes done by jagannath as no of slots decreased for IML52 ****/
/** #define NO_OF_SLOTS_QRY  4  **/ /***Changes done as no of slots increase****/
#define NO_OF_SLOTS_QRY  2  /*** Changes done as no of slots decrease ****/
#define	TIME_LENGTH		9
#define TIMEZONE_BSE            5*60*60
#define NO_QRY_IML		1  			/****** This specifies the no of QRY IML present ***********/
#define	FWDMAPQPCNT_FREE		0.95
#define     BYTES_TO_READ           4096
#define     BREAKCOUNTER            100
#define     UPD_PASSWD_REPLY_PACKET 69
#define     USER_ALREADY_LOGGED_ON  164
#define     LOGON_SUCCESSFUL        712
#define     LOGON_SUCCESS           159
#define     LOGIN_REQ_PACKET_SIZE   600
#define     LOGIN_RESP_PACKET_SIZE  117
#define     SYS_DONOT_RECOGNIZE     158
#define     USER_HAS_LOGGED_OFF     165
#define     LOGOFF_SUCCESS          160
#define     LOG_OFF_REQ_LEN         150
#define     REQUEST_SLOT            3
#define     REGISTRATION_LEN        200
#define     KEEPALIVE_PACKET        11
#define     MAX_IML_IPS             2
#define     PRIMARY_MODE            0
#define     SECONDARY_MODE          1
#define     MAX_TRY                 80
#define     FATAL                   -1
#define     MAX_NO_PROCESSES        4
#define     RECVCHLD                0
#define     TRANSCHLD               1
#define     KEEPALIVE               2
#define     CLIENTREGREQ            3
#define     RUNNING                 1
#define     END_DOWNLOAD_PACK_SIZE  22
#define     USED_SLOT               0
#define     UNUSED_SLOT             -2
#define     MAX_CONNECT_BREAK       100
#define     REJECTED_PACK_SIZE      200
#define     ERR_MSG_LEN             40
#define     TRADER_ID_LEN           30
#define     PROG_LEN                18
#define     PASSWORD_EXPIRED        218
#define     TWIDDLE(A)          Twiddle ((CHAR *) &A, sizeof(A))
#define     STR_DATE_TIME_OFF1      3
#define     STR_DATE_TIME_OFF2      6
#define     STR_DATE_TIME_OFF3      10
#define     STR_DATE_TIME_OFF4      14
#define     STR_DATE_TIME_OFF5      17
#define     BASE_YEAR               1900
#define 	NO_IML					10
key_t       GlobQueueKey;
key_t       GlobShmKey;
int         ReadQueue ;
int         DloadQueue;
int         WriteQueue;
int         Sockfd    ;
char        TimeStamp[TIME_LENGTH];
sigset_t    MainSignalSet   ;
char        ImlIPAddress[ADDRESS_LEN];
int         ImlPort;
char        ClientReg[PROG_LEN];
int         GlobalError = ERROR;
void        InitSharedMemory ();
void        ProcessArguments ( );
/*void        ConnectToOracle ( ); */
void        GetParameters ( );
void        InitForkProcess ( );
void        UpdateForkProcess ( int, int, int);
void        ReceiveChild ();
void        TransmitChild ();
void        GetImlIPAddress ( );
void        BSEconnectLogFatal ( char * );
int         SqlErrorFun () ;
void        GetTimeForDownload ( );
void        KeepveChild ( );
void        WriteToBseRms ( char * ,int ) ;
void        WriteToDloadQ ( char * ,int ) ;
static      void init_routine ( void );
int         OpenPassiveSocket ( );
/*void        OpenMessageQueues ( ); */
int         ProcessInitialConnection ( );
int         QueryPersonalInfo(int );
int         DownloadEnd(int Tcode);
int         QueryIndexValue(int Tcode);
void        PrepareDownloadPacket (int ,char * );
void        Convert_Seconds_To_Time ( long ,char *) ;
int         RecvPacket (int ,char *) ;
int         SendPacket ( int , char * ,size_t );
int         HandleLogOn  ( );
int         HandleLogOff ( );
int         HandleRegistration ( );
int         PrepareRegistrationPacket (char * ,int );
int         PrepareLogOffPacket ( char * ,int );
int         PrepareLogOnPacket ( char * ,int );
int         ReceiveLogOffResp (char * ,int );
int         ReceiveRegistrationResp (char * );
int         ReceiveLogOnResp (char * ,int );
int         UpdateExchStatus ( int ,int );
void        SignalHandlerSigChldMain ( );
void        SignalHandlerSigTermMain (int dummy);
void        Sleep( int );
int         CheckQueueForPendingPackets ( );
void        SendPacketBackToUser ( char *);
int         PrepareEndOfDownload ( char * , int ,int );
void        SlotInit( key_t  );
int         GetFreeSlot( key_t );
int         IsFreeSlot( key_t   );
void        SetSlotFree(  key_t  , int );
int         ReceiveQueryPersonalResponse (char * ) ;
void        PrintStatus ( int );
void*       OpenSharedMem ( key_t  , int ) ;
int         GetHour( char * ) ;
int         GetMinute ( char * ) ;
int         GetSeconds ( char * ) ;
void        ClientChild ( );
int         KeyGenarate(char *);

BOOL        ReceivePasswdReply (CHAR * ,LONG32 );
BOOL        PrepareChangePwdReq (CHAR *, LONG32);
BOOL        fCOMBInquiryResp(char *pMem);

int  RecvQueryNewsCategory (struct OMB_NEWS_CATEGORY_RESP *NewsCatResp );
int  PrepareNewsCategory (struct  OMB_NEWS_CATEGORY_REQ *NewsCatReq  );
int QueryNewsCategory (int Tcode );

void       Twiddle (void *pVoid,short iLen);

extern LONG32    convert_date_to_seconds (char * pDateTime);
BOOL convert_bsedatetime_to_str(struct OMB_LOG_ON_REPLY *pDateTimebse , char *);
BOOL UpdateIMLQryConnectStatus(SHORT,CHAR);

BOOL UpdateIMLQryConnectStatus1(SHORT,CHAR);


#pragma pack(4)
struct SlotInfo
{
	short   Status;
	int   Slot ;
};
#pragma pack( )

#pragma pack(4)
struct Slot{
	struct SlotInfo SlotInfo[NO_OF_SLOTS];
};
#pragma pack( )

/***** Added for IML SPLIT ARCH *******/
#pragma pack(4)
struct 	Iml_Info
{
	LONG32  ImlUserId;
	struct SlotInfo SlotInfo[NO_OF_SLOTS];
};
#pragma pack( )

#pragma pack(4)
struct Iml_Info_Shm
{
	struct Iml_Info	ImlInfo[NO_QRY_IML];
};
#endif
#pragma pack(2)
struct  ForkProcess
{
	int ProcessId;
	int ProcessStatus;
};
#pragma pack( )

#pragma pack(2)
struct  ForkProcess ForkProcess[MAX_NO_PROCESSES] ;
#pragma pack( )

#pragma pack(2)
struct OMB_HEADER_INT
{
	struct OMB_HEADER OmbHeader;
	int MsgType;
};

#pragma pack( )

#pragma pack(2)
struct  BSE_PACKET
{
	struct  OMB_HEADER OmbHeader;
	int     MsgType;
	char    Message[BSE_PACKET_SIZE];
};
#pragma pack( )

#pragma pack(4)
struct Iml_Conn_Info
{
	LONG32  ImlUserId;
	struct SlotInfo SlotInfo[NO_OF_SLOTS];
};	
#pragma pack()

#pragma pack(4)
struct Iml_Conn_Info_shm
{
	struct Iml_Conn_Info ImlConnInfo[NO_IML];
};
#pragma pack ()

LONG32 last_msg_time;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
SHORT hh=0,mm=0,ss=0;  /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
void            EAMtimestamp(SHORT);   /*** ADDED FOR INCREAMENTAL DOWNLOAD ****/
