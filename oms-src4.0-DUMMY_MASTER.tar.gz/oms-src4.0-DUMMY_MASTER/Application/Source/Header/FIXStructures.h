#ifndef _FIX_STRUCTURE_
#define _FIX_STRUCTURE_

#include  "IPCS.h"
#include <ctype.h>
/*----------------------------------------------------------------------------------------------
  DEFINATIONS FOR FIX STRUCTURE
  ------------------------------------------------------------------------------------------------*/
#define		MAX_NO_OF_TAGS			100
#define         MAX_TAG_SIZE			20
#define		FIX_MAX_STRING_LEN		2836
#define		FIX_MAX_TAGS			512
#define		FIX_TAG_LENGTH			8
#define		BEGIN_STRING_LEN		8+1
#define		MESSAGE_TYPE_LEN		5+1
#define		FIX_DATE_TIME_LEN		25
#define		CSD_ACCT_NUMBER_LEN		15+1
#define		EXEC_INST_LEN			10
#define		SEC_TYPE			3+1
#define		TEXT_LEN			40
#define		ID_SOURCE_LEN			3
#define		DAY				2+1
#define		COMPLIANCE_LEN			15
#define		CLEARING_ACCOUNT_LEN		12+1
#define		FIX_BROKER_LEN			5
#define		TERMINAL_INFO_LEN		15
#define		ORDER_ID_LEN			25
#define		MONTH_YEAR			6
#define		MEMBERID_LEN			9+1
#define		SUBSCRIBER_LEN			11+1
#define		MAX_CURRENCY_LEN		4
#define		TRADING_SESS_LEN		20
#define		CLEARING_FIRM_LEN		9+1
#define		IDSOURCE_LEN			2+1
#define		MAX_TEXT_LEN			255
#define		EXEC_ID_LEN			45
#define		BUSS_REJ_LEN			20+1
#define		MSGID_INT_LEN			19+1

#define		SYMBOL_SFX_LEN			2+1

#define 	ENV_VARIABLE_LEN 		30
#define 	TIME_TRUNC_LEN 			17
#define 	TEMP_STRUCT_LEN 		4
#define 	TRADE_NO_LEN			16+1
#define 	INTERFACE_CONN_DOWN             'X'
#define 	INTERFACE_CONN_UP               'U'


#define 	ICEX_PARTY_SOURCE               'D'
#define 	ICEX_PARTY_ROLE               	"44"

#define         NCDEX_PARTY_SOURCE               'D'
#define         NCDEX_PARTY_ROLE                 "44"


//#define 	LEG_LEN 			3
/*----------------------------------------------------------------------------------------------
  END DEFINATIONS FOR FIX STRUCTURE
  ------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------------
  DEFINING FIX VALUES
  -----------------------------------------------------------------------------------------------*/
#define CFG_STRUCT_LEN				21
#define DELIMITER                           1
#define FIX_FIELD_DELIMITER                 1
#define FIX_TAG_DELIMITER                   '='
#define FIX_ESCAPE                          '\\'
#define FIX_MESSAGE_DELIMITER                           '\n'

/*----------------------
  TAG 59 - TimeInForce
  -----------------------*/
#define FIX_TIME_IN_FORCE_DAY			'0'
#define FIX_TIME_IN_FORCE_GTC			'1'
#define FIX_TIME_IN_FORCE_ATO			'2'
#define FIX_TIME_IN_FORCE_IOC			'3'
#define FIX_TIME_IN_FORCE_FOK			'4'
#define FIX_TIME_IN_FORCE_GTX			'5'
#define FIX_TIME_IN_FORCE_GTD			'6'

/*----------------------
  TAG 59 -BSE TimeInForce
  -----------------------*/
#define FIX_BSE_TIME_IN_FORCE_SSN                   '0'
#define FIX_BSE_TIME_IN_FORCE_GTC                   '1'
#define FIX_BSE_TIME_IN_FORCE_ATO                   '2'
#define FIX_BSE_TIME_IN_FORCE_IOC                   '3'
#define FIX_BSE_TIME_IN_FORCE_FOK                   '4'
#define FIX_BSE_TIME_IN_FORCE_GTX                   '5'
#define FIX_BSE_TIME_IN_FORCE_GTD                   '6'
#define FIX_BSE_TIME_IN_FORCE_DAY                   '7'

/*----------------------
  TAG 40 - OrderType
  -----------------------*/
#define FIX_ORD_TYPE_MARKET			'1'
#define FIX_ORD_TYPE_LIMIT			'2'
#define FIX_ORD_TYPE_STOPLOSS			'3'
#define FIX_ORD_TYPE_STOPLIMIT			'4'
#define FIX_ORD_TYPE_MARK_TO_LMT		'K'
#define FIX_ORD_TYPE_MKT_TOUCH			'J'
/*----------------------
  TAG 54 - Side
  -----------------------*/
#define FIX_SIDE_BUY				'1'
#define FIX_SIDE_SELL				'2'

/*----------------------
  TAG 21 - HandelInst
  -----------------------*/
#define FIX_HANDL_INST_AUTO_EXEC		'1'
#define FIX_HANDL_INST_BROKET_INT_EXEC		'2'
#define FIX_HANDL_INST_MANUAL_EXEC		'3'
/*----------------------
  TAG 150 - ExecType
  -----------------------*/
#define FIX_EXEC_TYPE_NEW			'0'
#define FIX_EXEC_TYPE_PARTIAL_FILL		'1'
#define FIX_EXEC_TYPE_FILL			'2'
#define FIX_EXEC_DONE_FOR_DAY			'3'
#define FIX_EXEC_TYPE_CANCELED			'4'
#define FIX_EXEC_TYPE_REPLACE			'5'
#define FIX_EXEC_TYPE_FREEZE			'7'
#define FIX_EXEC_TYPE_REJECTED			'8'
#define FIX_EXEC_TYPE_SUSPENDED			'9'
#define FIX_EXEC_TYPE_EXPIRED			'C'
#define FIX_EXEC_TYPE_RESTATED			'D'
#define FIX_EXEC_TYPE_TRIGGERED			'T'
#define FIX_EXEC_TYPE_NEW_PENDING		'A'
/*EXEC DOWNLOAD MSG*/
#define FIX_EXEC_TYPE_SYNC_STAT			'S'
#define FIX_EXEC_TYPE_TRADE			'F'
#define FIX_EXEC_TYPE_TRADE_CORRECT		'G'
#define FIX_EXEC_TYPE_TRADE_CANCEL		'H'
#define FIX_EXEC_TYPE_ICEX_TRIGGERED		'L'
#define FIX_EXEC_TYPE_NCDEX_TRIGGERED		'L'
#define FIX_EXEC_TYPE_BSE_TRIGGERED		'L'

#define FIX_EXEC_TYPE_BSE_RRM_ORDER_ACCEPT	'M'
#define FIX_EXEC_TYPE_BSE_RRM_ORDER_REJECT	'N'
#define FIX_EXEC_TYPE_BSE_PROVISIONAL_ACCEPT	'X'
#define FIX_EXEC_TYPE_BSE_PROVISIONAL_REJECT	'Y'
/*----------------------
  TAG 39 - OrdStatus
  -----------------------*/
#define FIX_ORDER_STATUS_NEW			'0'
#define FIX_ORDER_STATUS_PARTIAL_FILL		'1'
#define FIX_ORDER_STATUS_FILLED			'2'
#define FIX_ORDER_STATUS_DONE_FOR_DAY		'3'
#define FIX_ORDER_STATUS_CANCELED		'4'
#define FIX_ORDER_STATUS_REPLACED		'5'
#define FIX_ORDER_STATUS_FREEZE			'7'
#define FIX_ORDER_STATUS_REJECTED		'8'
#define FIX_ORDER_STATUS_SUSPENDED		'9'
#define FIX_ORDER_STATUS_EXPIRED		'C'
#define FIX_ORDER_STATUS_NEW_PENDING		'A'

/*----------------------
  TAG 20 - ExecTransType
  -----------------------*/
#define FIX_EXEC_TRANS_TYPE_NEW			'0'
#define FIX_EXEC_TRANS_TYPE_CANCEL		'1'
#define FIX_EXEC_TRANS_TYPE_STATUS		'3'

/*----------------------
  TAG 434 - CxlRejResponseTo 
  -----------------------*/
#define FIX_CXLREJ_TO_CANCEL_REQ		'1'
#define FIX_CXLREJ_TO_REPLACE_REQ		'2'

/*----------------------
  TAG 35 - MsgType
  -----------------------*/
#define FIX_TAG_MSG_TYPE			"35"
#define FIX_MSG_LOGON				"A"
#define FIX_MSG_SESSION_REJECT			"3"
#define FIX_MSG_BUSINESS_REJECT			"j"
#define FIX_MSG_EXECUTION_REPORT		"8"
#define FIX_MSG_BSE_TRADE_CONFRM		"AE"
#define FIX_MSG_ORDER_CANCEL_REJECT		"9"
#define FIX_TRADING_SESSION_STATUS		"h"
#define FIX_SECURITY_DEFINITION_DOWNLOAD	"d"
#define	FIX_ORDER_REQUEST			"D"
#define	FIX_ORDER_CANCELLATION			"F"
#define	FIX_ORDER_MODIFICATION			"G"
#define	FIX_SPREAD_ORDER_REQUEST		"U1"
#define	FIX_SPREAD_ORDER_REPLACE		"U2"
#define	FIX_SPREAD_GIVEUP_REPORT		"U3"
#define	FIX_NEWS				"B"
#define FIX_MSG_SECURITY_STATUS                 "f"

#define	FIX_SPREAD_ORDERS_REQUEST		"U14"

/*----------------------
  TAG 201 - PutOrCall
  -----------------------*/
#define CALL			1
#define PUT			0
/*----------------------
  TAG 206 - OptAttribute
  -----------------------*/
#define AMERICAN		'L'
#define EUROPEAN		'S'

/*----------------------
  TAG 167 - SecurityType
  -----------------------*/
#define OPTION			"OPT"
#define FUTURE			"FUT"

/*----------------------
  TAG 77 - OpenClose 
  -----------------------*/
#define OPEN_FLAG		'O'
#define CLOSE_FLAG		'C'

/*----------------------
   TAG 40 -BSE OrderType
   -----------------------*/
#define FIX_BSE_ORD_TYPE_MARKET                     '5'
#define FIX_BSE_ORD_TYPE_LIMIT                      '2'
#define FIX_BSE_ORD_TYPE_STOPLOSS                   '3'
#define FIX_BSE_ORD_TYPE_STOPLIMIT                  '4'
#define FIX_BSE_ORD_TYPE_MARK_TO_LMT                'K'
#define FIX_BSE_ORD_TYPE_MKT_TOUCH                  'J'

/*----------------------
    TAG 28500 -BSE TemplateID 
    -------------------------*/
#define BSE_NEW_ORD_RESPONSE			"10101"
#define BSE_REPLACE_ORD_RESPONSE		"10107"
#define BSE_IMM_EXE_RESPONSE			"10103"
#define BSE_CAN_ORD_RESPONSE			"10110"
#define BSE_MASS_CAN_RESPONSE			"10122"

/* ---------------------
    TAG 150 - BSE REASON CODE
	-----------------------*/

#define BSE_ORD_ADDED		101	//BSE CONFIRMATION
#define BSE_ORD_REPLACE		102	//BSE MODIFICATION
#define BSE_ORD_CANCEL		103	//BSE CANCELLATION
#define BSE_IOC_ORD_CAN		105
#define BSE_MKT_ORD_TRG		135
#define BSE_ORD_CAN_PEN		197	//BSE CANCELLATION

#define BSE_BOC_ORD_CAN		212
#define BSE_RRM_ORD_ADD		215
#define BSE_PRO_ORD_ADD		221
#define BSE_SLF_TRD_DLT		246
#define BSE_RVS_SLF_TRD_DLT	247

#define	BSE_MASS_CXL_NO_SPCL_REASON	0
#define	BSE_MASS_CXL_STOP_TRADING	1
#define	BSE_MASS_CXL_EMERGENCY		2
#define	BSE_MASS_CXL_MKT_MAKER_PROTECT	3
#define	BSE_MASS_CXL_STOP_BTN_ACTVATED	4
#define	BSE_MASS_CXL_BUSINESS_UNIT_SUSP	5
#define	BSE_MASS_CXL_SESSION_LOSS	6
#define	BSE_MASS_CXL_RRM_COLLETRAL	7
#define	BSE_MASS_CXL_PRICE_BAND_SHRINK	8
#define	BSE_MASS_CXL_PROD_STATE_CLOSING	114
#define	BSE_MASS_CXL_PROD_STATE_EOD	115
#define	BSE_MASS_CXL_RRM_REGULATORY	116
#define	BSE_MASS_CXL_RRM_MWPL		117

/*----------------------------------------------------------------------------------------------
  END DEFINING FIX VALUES
  -----------------------------------------------------------------------------------------------*/
typedef struct
{
	CHAR		sDelToTargetComp[ENTITY_ID_LEN];
	//CHAR		cMsgType ;
	CHAR		sMsgType[TAG_LEN] ;
	LONG32		iNoOfTags;
	LONG32		iTagList[MAX_NO_OF_TAGS];
}EXCH_CFG_FILE_STRUCT ;

typedef struct
{
	SHORT		iMsgLength;
	SHORT		iMsgCode;
	INT16		iQMsgType;
}INT_HEADER;

typedef struct
{
	char   inputmsg[FIX_MAX_STRING_LEN+1];
	char   buf[FIX_MAX_STRING_LEN*3/2];
	char   msgType[FIX_TAG_LENGTH+1];
	char*  tags[FIX_MAX_TAGS];
	char*  values[FIX_MAX_TAGS];
	char   headertag[FIX_MAX_TAGS];
	int    numtags;
	int    length;
} FIX_Msg;

typedef struct
{
	CHAR		sBeginString[BEGIN_STRING_LEN];
	LONG32		dMsgSeqNum;                                     /*****  TAG 34 *****/
	CHAR		sMsgType[MESSAGE_TYPE_LEN];                     /***** TAG 35 *****/
	CHAR		sSenderCompID[DATE_TIME_LEN];                   /***** TAG 49 *****/
	CHAR		sTargetCompID[ENTITY_ID_LEN];                   /***** TAG 56 *****/
	CHAR		sSenderSubID[ENTITY_ID_LEN];                    /****** TAG 50 *****/
	CHAR		sTargetSubID[ENTITY_ID_LEN];                    /****** TAG 57 *****/
	CHAR		sSendingTime[FIX_DATE_TIME_LEN];                    /***** TAG 52 ******/
	CHAR		cPossDupFlag;                                   /***** TAG 43 ******/

}FIX_HEADER;

typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;

	CHAR		sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR		sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
	CHAR		cHandlInst;                                 /***** TAG 21 ****/
	CHAR		sExecInst[EXEC_INST_LEN];                   /***** TAG 18 ****/
	DOUBLE64	fMinQty;                                    /***** TAG 110 ***/
	DOUBLE64	fMaxFloor;                                  /***** TAG 111****/
	CHAR		sSymbol[SYMBOL_LEN];                        /***** TAG 55 ****/
	CHAR		sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
	CHAR		sSecurityType[DB_INS_LEN];                  /***** TAG 167 ****/
	CHAR		cSide;                                      /***** TAG 54 ****/
	CHAR		sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
	DOUBLE64	fQuantity;                                  /***** TAG 38 ****/
	CHAR		cOrderType;                                 /***** TAG 40 ****/
	DOUBLE64	fPrice;                                     /***** TAG 44 ****/
	CHAR		cTimeInForce;                               /***** TAG 59 ****/
	CHAR		cOrderCapacity;                             /***** TAG 47 ****/
	CHAR		sText[TEXT_LEN];                            /***** TAG 58 ****/
	CHAR		sIdSource[ID_SOURCE_LEN];              	 /***** TAG 22 ****/
	DOUBLE64	fStopPx;                                /***** TAG 99 ****/
	INT16		iProduct;				/****** Tag 460 *******/
	CHAR		sSecurityId[SECURITY_ID_LEN];           /***** TAG 48 ****/
	CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	CHAR            cCoverUncover;                              /****** TAG 203 *****/
	SHORT		iCustomerOrFirm;                        /***** TAG 204 ***/
	CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];         /***** TAG 200 ****/
	CHAR            cOptAttribute;                          /***** TAG 206 *****/
	LONG32          iTradSesStatus;				/** TAG 340 **/ /** 1 = Halted , 2= Open , 3= Closed , 4= Pre-Open,5= PreClose **/
	CHAR		sComplianceID[COMPLIANCE_LEN];      	/*** 376 ***/
	CHAR		sExpireDate[FIX_DATE_TIME_LEN];         /***** TAG 432 ***/
	CHAR		sClearingFirm[CLEARING_ACCOUNT_LEN];    /***** TAG 440 ***/
	CHAR		sExecBroker[FIX_BROKER_LEN];            /***** TAG 76 ***/
	CHAR		sTerminalInfo[TERMINAL_INFO_LEN];       /***** TAG 9227 **/

} FIX_NEW_ORDER_REQUEST ;
typedef struct
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR		sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
	CHAR		sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR		sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR		sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
	CHAR		sSymbol[SYMBOL_LEN];                        /***** TAG 55 ****/
	CHAR		sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
	CHAR		cSide;                                      /***** TAG 54 ****/
	CHAR		sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
	CHAR		sIdSource[ID_SOURCE_LEN];                   /***** TAG 22 ****/
	DOUBLE64	fQuantity;                                  /***** TAG 38 ****/
	CHAR		cOrderType;				/***** TAG 40 *****/
	CHAR		sSecurityEx[EXCHANGE_LEN];                   /***** TAG 207 ****/
	DOUBLE64	fStrikePrice;                               /****** TAG 202 ****/
	SHORT		iSettlmntType;                              /****** TAG 63 *****/
	CHAR		sFutSettDate[FIX_DATE_TIME_LEN];            /****** TAG 64 *****/
	INT16           iProduct;                               /****** Tag 460 *******/
	CHAR		sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR		cCoverUncover;                              /****** TAG 203 *****/
	CHAR		cOpenCloseFlg;                              /***** TAG 77 ******/
	CHAR		sMaturityMonthYear[MAT_MONYR];             /***** TAG 200 *****/
	SHORT		iPutOrCall;                                 /***** TAG 201 *****/
	CHAR		cOptAttribute;                              /***** TAG 206 *****/
	CHAR		sMaturityDay[DAY];                          /***** TAG 205 *****/
	LONG32		dReceivedTime;
	SHORT		iQtyCondition ;                             /****FOR AON on ***/
	CHAR		sSecurityId[SECURITY_ID_LEN];               /***** TAG 48 *****/
	CHAR		cListID;                                    /***** TAG 66 *****/
	CHAR		sComplianceID[COMPLIANCE_LEN];      		/*** 376 ***/
	SHORT		iCustomerOrFirm;                            /***** TAG 204*****/
	CHAR		cTechnicalOrdType;                          /***** TAG 9941 ***/
	CHAR		sOrigOrderID[ORDER_ID_LEN];                 /***** TAG 9945 ***/
	CHAR		sMemberID[MEMBERID_LEN]    ;                /***** TAG 9946****/
	CHAR		sSubscriberID[SUBSCRIBER_LEN];              /***** TAG 9955****/
} FIX_ORDER_CANCEL_REQUEST;

typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;

	CHAR		sOrderID[ORDER_ID_LEN];				/***** TAG 37 *****/
	CHAR		sOrigClOrdId[CLORDID_LEN];			/***** TAG 41 *****/
	CHAR		sClOrdId[CLORDID_LEN];				/***** TAG 11 *****/
	CHAR		sAccount[CSD_ACCT_NUMBER_LEN];			/***** TAG 1  *****/
	SHORT		iOrderFamily;					/***** TAG 9743 ***/
	CHAR		cHandlInst;					/***** TAG 21 *****/
	CHAR		sExecInst[EXEC_INST_LEN];			/***** TAG 18 *****/
	DOUBLE64	fMinQty;					/***** TAG 110 ****/
	DOUBLE64	fMaxFloor;					/***** TAG 111 ****/
	CHAR		sSymbol[SYMBOL_LEN];				/***** TAG 55 *****/
	CHAR		sSymbolSfx[SYMBOL_SFX_LEN];			/***** TAG 65 *****/
	CHAR		cSide;						/***** TAG 54 *****/
	CHAR		sTransactTime[FIX_DATE_TIME_LEN];               /***** TAG 60 *****/
	DOUBLE64	fQuantity;					/***** TAG 38 *****/
	CHAR		cOrderType;					/***** TAG 40 *****/
	DOUBLE64	fPrice;						/***** TAG 44 *****/
	LONG32		dCumQty;					/***** TAG 14 *****/
	CHAR		cTimeInForce;					/***** TAG 59 *****/
	CHAR		sExpireTime[FIX_DATE_TIME_LEN];			/***** TAG 126 ****/
	CHAR		cOrderCapacity;					/***** TAG 47 *****/
	CHAR		cOrderFamily;					/***** TAG 9743 ***/
	CHAR		sIdSource[ID_SOURCE_LEN];			/***** TAG 22 *****/
	DOUBLE64	fStopPx;					/***** TAG 99 *****/
	CHAR		sSecurityEx[EXCHANGE_LEN];			/***** TAG 207 ****/
	DOUBLE64	fStrikePrice;					/***** TAG 202 ****/
	SHORT		iSettlmntType;                                  /***** TAG 63 *****/
	CHAR		sFutSettDate[FIX_DATE_TIME_LEN];		/***** TAG 64 *****/
	CHAR		sSecurityType[SEC_TYPE];			/***** TAG 167 ****/
	CHAR		cCoverUncover;					/***** TAG 203 ****/
	CHAR		cOpenCloseFlg;					/***** TAG 77 *****/
	INT16           iProduct;                               	/****** Tag 460 *******/
	CHAR		sMaturityMonthYear[MAT_MONYR];			/***** TAG 200 ****/
	SHORT		iPutOrCall;					/***** TAG 201 ****/
	CHAR		cOptAttribute;					/***** TAG 206 ****/
	CHAR		sMaturityDay[DAY];				/***** TAG 205 ****/
	CHAR		sCurrency[MAX_CURRENCY_LEN];			/***** TAG 15 *****/
	LONG32		dReceivedTime;					/****/
	SHORT		iQtyCondition ;					/****FOR AON on ***/
	CHAR            sOrigTime[FIX_DATE_TIME_LEN];			/***** TAG 42 *****/
	CHAR            sSecurityId[SECURITY_ID_LEN];			/***** TAG 48 *****/
	CHAR            sText[TEXT_LEN];				/***** TAG 58 *****/
	CHAR            sClientID[CLIENT_ID_LEN];			/***** TAG 109 ****/
	CHAR		sComplianceID[COMPLIANCE_LEN];			/***** TAG 376 ****/
	SHORT           iCustomerOrFirm;				/***** TAG 204 ****/
	DOUBLE64        fMaxShow;					/***** TAG 210 ****/
	CHAR            sTradingSessionID[TRADING_SESS_LEN];		/***** TAG 336 ****/
	SHORT           iNoTradingSessions;				/***** TAG 386 ****/
	CHAR		sClearingFirm[CLEARING_ACCOUNT_LEN];		/***** TAG 440 ****/
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];			/***** TAG 432 ****/
	CHAR		sLastModTime[FIX_DATE_TIME_LEN];		/***** TAG 6000 ***/
	CHAR            sTerminalInfo[TERMINAL_INFO_LEN];            	/***** TAG 9227 **/


} FIX_ORDER_MODIFICATION_REQUEST;

struct FIX_EXECUTION_REPORT
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;

	CHAR            sClOrdId[CLORDID_LEN];                         	/***** TAG 11 *****/
	CHAR            sOrigClOrdId[CLORDID_LEN];                     	/***** TAG 41 *****/
	CHAR            sIdSource[IDSOURCE_LEN];                       	/***** TAG 22 *****/
	CHAR            sSecurityId[SECURITY_ID_LEN];             	/***** TAG 48 *****/ /*****Since 22=4 it contains ISIN**/
	CHAR            sSymbol[SYMBOL_LEN];                      	/***** TAG 55 *****/
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];          		/** TAG 65 *******/
	CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];             /***** TAG 200 *****/
	CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	CHAR            cOptAttribute;                              /***** TAG 206 *****/
	CHAR            cSide;                                      /***** TAG 54 *****/
	CHAR            cOrderType;                                 /***** TAG 40 *****/
	DOUBLE64        fMaxFloor;                              /***** TAG 111*****/
	DOUBLE64        fQuantity;                                  /***** TAG 38 *****/
	DOUBLE64        fPrice;                                     /***** TAG 44 *****/
	CHAR            sClientID[CLIENT_ID_LEN];                   /***** TAG 109*****/
	SHORT           iCustomerOrFirm;                        /***** TAG 204*****/
	CHAR            sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1  *****/
	DOUBLE64        fStopPx;                                /***** TAG 99 ****/
	CHAR            sTransactTime[FIX_DATE_TIME_LEN];               /***** TAG 60 *****/
	CHAR            cTimeInForce;                               /***** TAG 59 *****/
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];               /***** TAG 432 ****/
	CHAR            sText[MAX_TEXT_LEN];                        /***** TAG 58 *****/
	CHAR            sOrderID[ORDER_ID_LEN];                         /***** TAG 37 *****/
	CHAR            sSecondryOrderID[ORDER_ID_LEN];                         /***** TAG 198 *****/
	CHAR            sExecID[EXEC_ID_LEN];                           /***** TAG 17 *****/
	CHAR            cExecTransType;                             /***** TAG 20 *****/
	CHAR            cExecType;                                  /***** TAG 150*****/
	CHAR            cOrdStatus;                                 /***** TAG 39 *****/
	LONG32          dOrdRejReason;                              /***** TAG 103*****/
	LONG32          dExecRestatementReason;                     /***** TAG 378 ****/
	LONG32          dLeavesQty;                                 /***** TAG 151*****/
	LONG32          dCumQty;                                    /***** TAG 14 *****/
	DOUBLE64        fAvgPx;                                     /***** TAG 6  *****/
	CHAR            sExecBroker[FIX_BROKER_LEN];                    /***** TAG 76 ***/
	CHAR            sClearingFirm[CLEARING_FIRM_LEN];               /***** TAG 439*****/
	DOUBLE64        fLastPx;                                    /***** TAG 31 *****/
	LONG32          dLastShares;                                /***** TAG 32 *****/
	CHAR            sClearingAccount[CLEARING_ACCOUNT_LEN];          /***** TAG 440 ***/
	CHAR            sTradingSessionID[TRADING_SESS_LEN];      /***** TAG 336 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];                /***** TAG 15  *****/
	SHORT           iMLReportType                                   /*******TAG 442 ************/
};

struct FIX_ORDER_CANCEL_REJECT
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR        sOrderID[ORDER_ID_LEN];				/***** TAG 37 *****/
	CHAR        sClOrdId[CLORDID_LEN];				/***** TAG 11 ****/
	CHAR        sOrigClOrdId[CLORDID_LEN];			/***** TAG 41 *****/
	CHAR        cOrdStatus;					/***** TAG 39 *****/
	SHORT       iOrderFamily;					/****  TAG 9743 ***/
	CHAR        sTransactTime[FIX_DATE_TIME_LEN];		/***** TAG 60 *****/
	CHAR        cCxlRejResponseTo;				/***** TAG 434 ****/
	CHAR        cCxlRejReason;					/***** TAG 102 ****/
	CHAR        sText[MAX_TEXT_LEN];				/****  TAG 58 *****/
} ;

typedef struct
{
	INT_HEADER  Header ;
	FIX_HEADER  FIXHeader;
	CHAR        sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR        sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	CHAR        sSymbol[SYMBOL_LEN];                        /***** TAG 55 *****/
	CHAR        cSide;                                      /***** TAG 54 *****/
} FIX_ORDER_STATUS_REQUEST;
typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	LONG32      dRefSeqNum;                                 /***** TAG 45 *****/
	CHAR        sRefMsgType[MESSAGE_TYPE_LEN];              /***** TAG 372 ****/
	CHAR        dBusinessRejectRefID[BUSS_REJ_LEN];         /***** TAG 379 ****/
	LONG32      dBusinessRejectReason;                      /***** TAG 380 ****/
	CHAR        sText[MAX_TEXT_LEN];                            /****  TAG 58 *****/

	CHAR        sClOrdId[CLORDID_LEN];                  /***** TAG 11 *****/
	CHAR        sMsgID[MSGID_INT_LEN];                  /***** TAG 9262 ***/
	CHAR        sFunctionCodeOrig[4];                   /***** TAG 9931 ***/

}FIX_BUSINESS_MESSAGE_REJECT;

typedef struct
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	LONG32      dRefSeqNum;                                 /***** TAG 45 *****/
	LONG32          dRefTagID;                                                                      /***** TAG 371 ****/
	CHAR        sRefMsgType[MESSAGE_TYPE_LEN];              /***** TAG 372 ****/
	LONG32      dSessionRejectReason;                       /***** TAG 380 ****/
	CHAR        sClOrdId[CLORDID_LEN];                  /***** TAG 11 *****/
	CHAR        sText[MAX_TEXT_LEN];                            /****  TAG 58 *****/
} FIX_SESSION_REJECT;


struct SUB_FIX_TRADING_STATUS
{
	LONG32          iTradSesStatus;         /** TAG 340 **/ /** 1 = Halted , 2= Open , 3= Closed , 4= Pre-Open,7= PreClose **/
};

typedef struct 
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	CHAR            sTradSesReqId[15];      /** TAG 335 **/
	CHAR            sTradSessId[5];         /** TAG 336 **/
	LONG32          iNoTradeSesStatus;
	struct 		SUB_FIX_TRADING_STATUS 	sTradSesStatus[3];
	LONG32          iGroupId;               /*** TAG 9268 ***/
	LONG32          iGroupIdTradStat;               /*** TAG 9272 ***/ /** 1= Start Of Trading for Group ID , 2= END Of Trading for Group ID ***/
	CHAR		cSeg;
} FIX_SECURITY_TRADING_SESSION_RESPONSE;



struct FIX_SECURITY_DEFINITION_RESPONSE
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	CHAR            sSecurityReqId[15];     /**** TAG 320 ****/
	CHAR            sSecurityRespId[15];    /**** TAG 322 ****/
	CHAR            sSecurityRespType[15];  /**** TAG 323 ****/
	CHAR            sIdSource[IDSOURCE_LEN]; /**** TAG 22 ****/
	LONG32          iNoofSec;               /*** TAG 393 *****/
	CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	CHAR            sSymbol[SYMBOL_LEN];                             /**********TAG 55************/
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];          /** TAG 65 *******/
	CHAR            sSecurityId[SECURITY_ID_LEN];                           /***** TAG 48 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];             /***** TAG 200 *****/
	CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	CHAR            cOptAttribute;                              /***** TAG 206 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
	CHAR            sSecurityDesc[25];                              /**** TAG 107 ***/
	CHAR            sText[MAX_TEXT_LEN];                            /****  TAG 58 *****/
	LONG32          iLotSize;                                       /****** TAG 9201 ****/
	CHAR            sTradingUnit[5];                                /**** TAG 9202 ******/
	DOUBLE64        fTradingUnitFactor;                             /********* TAG 9246 *****/
	CHAR            sDeliveryUnit[5];                               /**** TAG 9247 ****/
	DOUBLE64        fDeliveryUnitFactor;                            /**** TAG 9248 ****/
	DOUBLE64        fPriceNumerator;                                /**** TAG 9203 ****/
	DOUBLE64        fPriceDemoninator;                              /**** TAG 9204 ****/
	DOUBLE64        fGenNumerator;                                  /**** TAG 9205 ****/
	DOUBLE64        fGenDemoninator;                                /**** TAG 9206 ****/
	LONG32          iPriceTick;                                     /** TAG 9210 ***/
	DOUBLE64        fDecimalLocator;                                /**** TAG 9211 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];                /***** TAG 15  *****/
	CHAR            sSettelmentCurrency[MAX_CURRENCY_LEN];          /***** TAG 120  *****/
	CHAR            sProductMonth[7];                               /*** TAG 9265 ***/
	LONG32          iPreOpen;                                       /** TAG 9267 ***/
	LONG32          iGroupId;                                       /** TAG 9268 ***/
	LONG32          iMatchingType;                                  /** TAG 9269 ***/
	LONG32          iSpreadType;                                    /** TAG 9270 ***/
	CHAR            sUnderlyingSecurityId[SECURITY_ID_LEN];         /** TAG 9273 ***/
	DOUBLE64        fHighPx;                                        /** TAG 332***/
	DOUBLE64        fLowPx;                                         /** TAG 333 **/
};

struct  SUB_ORDER_REQ_SPD_2L_3L  
{
        CHAR            sSecurityId[SECURITY_ID_LEN];
        CHAR            cSide;
        DOUBLE64        fQuantity;
        DOUBLE64        fPrice;
        CHAR            cOrderType;
};

typedef struct
{
	INT_HEADER      Header;
	FIX_HEADER      FIXHeader;
	CHAR            sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
	INT16		iMLOrdAttrb;
	INT16		iNumOfSecurity;
	struct          SUB_ORDER_REQ_SPD_2L_3L  sSpreadLeg[LEG_LEN];
	CHAR            cTimeInForce;
	SHORT           iCustomerOrFirm;
	CHAR            sAccount[CSD_ACCT_NUMBER_LEN];
	CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];    /***** TAG 440 ***/
	CHAR            sExecBroker[FIX_BROKER_LEN];            /***** TAG 76 ***/
	CHAR            sTerminalInfo[TERMINAL_INFO_LEN];
	CHAR            sText[TEXT_LEN];
} FIX_SPREAD_NEW_ORDER_REQUEST ;

typedef struct
{
	INT_HEADER      Header;
	FIX_HEADER      FIXHeader;
	CHAR            sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
	CHAR            sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
	CHAR            sClOrdId[CLORDID_LEN];
	CHAR            sAccount[CSD_ACCT_NUMBER_LEN];
	SHORT           iOrderFamily;
	CHAR            cHandlInst;                                     /***** TAG 21 *****/
	CHAR            sExecInst[EXEC_INST_LEN];                       /***** TAG 18 *****/
	DOUBLE64        fMinQty;                                        /***** TAG 110 ****/
	DOUBLE64        fMaxFloor;
	CHAR            sSymbol[SYMBOL_LEN];                            /***** TAG 55 *****/
	CHAR            sSymbolSfx[SYMBOL_SFX_LEN];
	CHAR            cSide_L1;
	CHAR            cSide_L2;
	CHAR            sTransactTime[FIX_DATE_TIME_LEN];
	DOUBLE64        fQuantity;
	CHAR            cOrderType;                                     /***** TAG 40 *****/
	DOUBLE64        fPrice;                                         /***** TAG 44 *****/
	LONG32          dCumQty;                                        /***** TAG 14 *****/
	CHAR            cTimeInForce;                                   /***** TAG 59 *****/
	CHAR            sExpireTime[FIX_DATE_TIME_LEN];                 /***** TAG 126 ****/
	CHAR            cOrderCapacity;                                 /***** TAG 47 *****/
	CHAR            cOrderFamily;                                   /***** TAG 9743 ***/
	CHAR            sIdSource[ID_SOURCE_LEN];                       /***** TAG 22 *****/
	DOUBLE64        fStopPx;                                        /***** TAG 99 *****/
	CHAR            sSecurityEx[EXCHANGE_LEN];                      /***** TAG 207 ****/
	DOUBLE64        fStrikePrice;
	SHORT           iSettlmntType;                                  /***** TAG 63 *****/
	CHAR            sFutSettDate[FIX_DATE_TIME_LEN];                /***** TAG 64 *****/
	CHAR            sSecurityType[SEC_TYPE];                        /***** TAG 167 ****/
	CHAR            cCoverUncover;                                  /***** TAG 203 ****/
	CHAR            cOpenCloseFlg;                                  /***** TAG 77 *****/
	INT16           iProduct;
	CHAR            sMaturityMonthYear[MAT_MONYR];                  /***** TAG 200 ****/
	SHORT           iPutOrCall;                                     /***** TAG 201 ****/
	CHAR            cOptAttribute;                                  /***** TAG 206 ****/
	CHAR            sMaturityDate_L1[MAT_DATE];                              /***** TAG 205 ****/
	CHAR            sMaturityDate_L2[MAT_DATE];                              /***** TAG 205 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];
	LONG32          dReceivedTime;                                  /****/
	SHORT           iQtyCondition ;                                 /****FOR AON on ***/
	CHAR            sOrigTime[FIX_DATE_TIME_LEN];
	CHAR            sSecurityId_L1 [SECURITY_ID_LEN];
	CHAR            sSecurityId_L2 [SECURITY_ID_LEN];
	CHAR            sText[TEXT_LEN];                                /***** TAG 58 *****/
	CHAR            sClientID[CLIENT_ID_LEN];
	CHAR            sComplianceID[COMPLIANCE_LEN];                  /***** TAG 376 ****/
	SHORT           iCustomerOrFirm;                                /***** TAG 204 ****/
	LONG32          iMultilegOrdType;
	LONG32          iNoLegs;
	DOUBLE64        fMaxShow;                                       /***** TAG 210 ****/
	CHAR            sTradingSessionID[TRADING_SESS_LEN];            /***** TAG 336 ****/
	SHORT           iNoTradingSessions;                             /***** TAG 386 ****/
	CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];            /***** TAG 440 ****/
	CHAR            sExpireDate[FIX_DATE_TIME_LEN];                 /***** TAG 432 ****/
	CHAR            sLastModTime[FIX_DATE_TIME_LEN];
	CHAR            cCancelFlag;
} FIX_SPREAD_MODCANCEL_ORDER_REQUEST ;

struct FIX_GIVE_REPORT
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	CHAR            sOrderID[ORDER_ID_LEN]	;  	// Tag 37
	LONG32		iFillId			;	// Tag 6007
	LONG32		iGiveUpStat		;	// Tag 6012
	CHAR            sSymbol[SYMBOL_LEN];                      /***** TAG 55 *****/	
	CHAR            sSecurityId[SECURITY_ID_LEN];                   /***** TAG 48 *****/ /*****Since 22=4 it contains ISIN**/
	CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
	INT16           iProduct;
	CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
	CHAR            sMaturityMonthYear[MONTH_YEAR];         /***** TAG 200 ****/
	SHORT           iPutOrCall;                                 /***** TAG 201 *****/
	DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/				
	CHAR            cOptAttribute;                          /***** TAG 206 *****/
	CHAR            cSide;                                      /***** TAG 54 ****/
	DOUBLE64        fLastPx;                                    /***** TAG 31 *****/
	LONG32          dLastShares;                                /***** TAG 32 *****/
	CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
	CHAR            cCoverUncover;                              /****** TAG 203 *****/
	CHAR            sLastModTime[FIX_DATE_TIME_LEN];                /***** TAG 6000 ***/
	CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];    /***** TAG 440 ***/
};


typedef struct 
{
	INT_HEADER  Header;
	FIX_HEADER  FIXHeader;
	CHAR	    	sHeadLine	[HEADLINE_LEN];									
	LONG32		iLineOfText;			
	//CHAR		sNewsText 	[MAX_NEWS_SIZE][NEWS_TEXT_LEN];
	CHAR		sNewsText 	[NEWS_TEXT_LEN];

}FIX_EXCH_NEWS;

struct FIX_SECURITY_STATUS
{
        INT_HEADER  Header;
        FIX_HEADER  FIXHeader;
        CHAR            sSecurityId[SECURITY_ID_LEN]; /***** TAG 48 *****/
        CHAR            sIdSource[IDSOURCE_LEN]; /**** TAG 22 ****/
        DOUBLE64        fHighPx;                                        /** TAG 332***/
        DOUBLE64        fLowPx;                                         /** TAG 333 **/
};

struct SUB_ORDER_REQ_ICEX 
{
        CHAR            sPartyId[ICEX_PARTY_ID_LEN];
        CHAR            cPartySrc;
        CHAR            sPartyRole[PARTY_ROLE_LEN];
};

typedef struct
{
        INT_HEADER  Header;
        FIX_HEADER  FIXHeader;

        CHAR            sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
        CHAR            sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
        CHAR            cHandlInst;                                 /***** TAG 21 ****/
        CHAR            sExecInst[EXEC_INST_LEN];                   /***** TAG 18 ****/
        DOUBLE64        fMinQty;                                    /***** TAG 110 ***/
        DOUBLE64        fMaxFloor;                                  /***** TAG 111****/
        CHAR            sSymbol[ICEX_SYMBOL_LEN];                        /***** TAG 55 ****/
        CHAR            sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
        CHAR            sSecurityType[DB_INS_LEN];                  /***** TAG 167 ****/
        CHAR            cSide;                                      /***** TAG 54 ****/
        CHAR            sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
        DOUBLE64        fQuantity;                                  /***** TAG 38 ****/
        CHAR            cOrderType;                                 /***** TAG 40 ****/
        DOUBLE64        fPrice;                                     /***** TAG 44 ****/
        CHAR            cTimeInForce;                               /***** TAG 59 ****/
        CHAR            cOrderCapacity;                             /***** TAG 47 ****/
        CHAR            sText[TEXT_LEN];                            /***** TAG 58 ****/
        CHAR            sIdSource[ID_SOURCE_LEN];                /***** TAG 22 ****/
        DOUBLE64        fStopPx;                                /***** TAG 99 ****/
        INT16           iProduct;                               /****** Tag 460 *******/
        CHAR            sSecurityId[SECURITY_ID_LEN];           /***** TAG 48 ****/
        CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
        SHORT           iPutOrCall;                                 /***** TAG 201 *****/
        DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
        CHAR            cCoverUncover;                              /****** TAG 203 *****/
        SHORT           iCustomerOrFirm;                        /***** TAG 204 ***/
        CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
        CHAR            sMaturityMonthYear[MONTH_YEAR];         /***** TAG 200 ****/
        CHAR            cOptAttribute;                          /***** TAG 206 *****/
        LONG32          iTradSesStatus;                         /** TAG 340 **/ /** 1 = Halted , 2= Open , 3= Closed , 4= Pre-Open,5= PreClose **/
        CHAR            sComplianceID[COMPLIANCE_LEN];          /*** 376 ***/
        CHAR            sExpireDate[FIX_DATE_TIME_LEN];         /***** TAG 432 ***/
        CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];    /***** TAG 440 ***/
        CHAR            sExecBroker[FIX_BROKER_LEN];            /***** TAG 76 ***/
        CHAR            sTerminalInfo[TERMINAL_INFO_LEN];       /***** TAG 9227 **/
	struct 		SUB_ORDER_REQ_ICEX   sPartycomp[LEG_LEN];
} FIX_NEW_ORDER_ICEX_REQUEST ;

struct SUB_ORDER_MOD_ICEX
{
        CHAR            sPartyId[ICEX_PARTY_ID_LEN];
        CHAR            cPartySrc;
        CHAR            sPartyRole[PARTY_ROLE_LEN];
};

typedef struct
{
        INT_HEADER  Header;
        FIX_HEADER  FIXHeader;

        CHAR            sOrderID[ORDER_ID_LEN];                         /***** TAG 37 *****/
        CHAR            sOrigClOrdId[CLORDID_LEN];                      /***** TAG 41 *****/
        CHAR            sClOrdId[CLORDID_LEN];                          /***** TAG 11 *****/
        CHAR            sAccount[CSD_ACCT_NUMBER_LEN];                  /***** TAG 1  *****/
        SHORT           iOrderFamily;                                   /***** TAG 9743 ***/
        CHAR            cHandlInst;                                     /***** TAG 21 *****/
        CHAR            sExecInst[EXEC_INST_LEN];                       /***** TAG 18 *****/
        DOUBLE64        fMinQty;                                        /***** TAG 110 ****/
        DOUBLE64        fMaxFloor;                                      /***** TAG 111 ****/
        CHAR            sSymbol[ICEX_SYMBOL_LEN];                            /***** TAG 55 *****/
        CHAR            sSymbolSfx[SYMBOL_SFX_LEN];                     /***** TAG 65 *****/
        CHAR            cSide;                                          /***** TAG 54 *****/
        CHAR            sTransactTime[FIX_DATE_TIME_LEN];               /***** TAG 60 *****/
        DOUBLE64        fQuantity;                                      /***** TAG 38 *****/
        CHAR            cOrderType;                                     /***** TAG 40 *****/
        DOUBLE64        fPrice;                                         /***** TAG 44 *****/
        LONG32          dCumQty;                                        /***** TAG 14 *****/
        CHAR            cTimeInForce;                                   /***** TAG 59 *****/
        CHAR            sExpireTime[FIX_DATE_TIME_LEN];                 /***** TAG 126 ****/
        CHAR            cOrderCapacity;                                 /***** TAG 47 *****/
        CHAR            cOrderFamily;                                   /***** TAG 9743 ***/
        CHAR            sIdSource[ID_SOURCE_LEN];                       /***** TAG 22 *****/
        DOUBLE64        fStopPx;                                        /***** TAG 99 *****/
        CHAR            sSecurityEx[EXCHANGE_LEN];                      /***** TAG 207 ****/
        DOUBLE64        fStrikePrice;                                   /***** TAG 202 ****/
        SHORT           iSettlmntType;                                  /***** TAG 63 *****/
        CHAR            sFutSettDate[FIX_DATE_TIME_LEN];                /***** TAG 64 *****/
        CHAR            sSecurityType[SEC_TYPE];                        /***** TAG 167 ****/
        CHAR            cCoverUncover;                                  /***** TAG 203 ****/
        CHAR            cOpenCloseFlg;                                  /***** TAG 77 *****/
        INT16           iProduct;                                       /****** Tag 460 *******/
        CHAR            sMaturityMonthYear[MAT_MONYR];                  /***** TAG 200 ****/
        SHORT           iPutOrCall;                                     /***** TAG 201 ****/
        CHAR            cOptAttribute;                                  /***** TAG 206 ****/
        CHAR            sMaturityDay[DAY];            /***** TAG 205 ****/
	CHAR            sCurrency[MAX_CURRENCY_LEN];                    /***** TAG 15 *****/
        LONG32          dReceivedTime;                                  /****/
        SHORT           iQtyCondition ;                                 /****FOR AON on ***/
        CHAR            sOrigTime[FIX_DATE_TIME_LEN];                   /***** TAG 42 *****/
        CHAR            sSecurityId[SECURITY_ID_LEN];                   /***** TAG 48 *****/
        CHAR            sText[TEXT_LEN];                                /***** TAG 58 *****/
        CHAR            sClientID[CLIENT_ID_LEN];                       /***** TAG 109 ****/
        CHAR            sComplianceID[COMPLIANCE_LEN];                  /***** TAG 376 ****/
        SHORT           iCustomerOrFirm;                                /***** TAG 204 ****/
        DOUBLE64        fMaxShow;                                       /***** TAG 210 ****/
        CHAR            sTradingSessionID[TRADING_SESS_LEN];            /***** TAG 336 ****/
        SHORT           iNoTradingSessions;                             /***** TAG 386 ****/
        CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];            /***** TAG 440 ****/
        CHAR            sExpireDate[FIX_DATE_TIME_LEN];                 /***** TAG 432 ****/
        CHAR            sLastModTime[FIX_DATE_TIME_LEN];                /***** TAG 6000 ***/
        CHAR            sTerminalInfo[TERMINAL_INFO_LEN];               /***** TAG 9227 **/
	struct          SUB_ORDER_MOD_ICEX   sPartycomp[LEG_LEN];

} FIX_ORDER_MODIFICATION_ICEX_REQUEST;

struct SUB_ORDER_CAN_ICEX
{
        CHAR            sPartyId[ICEX_PARTY_ID_LEN];
        CHAR            cPartySrc;
        CHAR            sPartyRole[PARTY_ROLE_LEN];
};

typedef struct
{
        INT_HEADER  Header ;
        FIX_HEADER  FIXHeader;
        CHAR            sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
        CHAR            sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
        CHAR            sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
        CHAR            sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
        CHAR            sSymbol[ICEX_SYMBOL_LEN];                        /***** TAG 55 ****/
        CHAR            sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
        CHAR            cSide;                                      /***** TAG 54 ****/
        CHAR            sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
        CHAR            sIdSource[ID_SOURCE_LEN];                   /***** TAG 22 ****/
        DOUBLE64        fQuantity;                                  /***** TAG 38 ****/
        CHAR            cOrderType;                             /***** TAG 40 *****/
        CHAR            sSecurityEx[EXCHANGE_LEN];                   /***** TAG 207 ****/
        DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
        SHORT           iSettlmntType;                              /****** TAG 63 *****/
        CHAR            sFutSettDate[FIX_DATE_TIME_LEN];            /****** TAG 64 *****/
        INT16           iProduct;                               /****** Tag 460 *******/
        CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
        CHAR            cCoverUncover;                              /****** TAG 203 *****/
        CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
        CHAR            sMaturityMonthYear[MAT_MONYR];             /***** TAG 200 *****/
        SHORT           iPutOrCall;                                 /***** TAG 201 *****/
        CHAR            cOptAttribute;                              /***** TAG 206 *****/
        CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
        LONG32          dReceivedTime;
        SHORT           iQtyCondition ;                             /****FOR AON on ***/
        CHAR            sSecurityId[SECURITY_ID_LEN];               /***** TAG 48 *****/
        CHAR            cListID;                                    /***** TAG 66 *****/
        CHAR            sComplianceID[COMPLIANCE_LEN];                  /*** 376 ***/
        SHORT           iCustomerOrFirm;                            /***** TAG 204*****/
        CHAR            cTechnicalOrdType;                          /***** TAG 9941 ***/
        CHAR            sOrigOrderID[ORDER_ID_LEN];                 /***** TAG 9945 ***/
        CHAR            sMemberID[MEMBERID_LEN]    ;                /***** TAG 9946****/
        CHAR            sSubscriberID[SUBSCRIBER_LEN];              /***** TAG 9955****/
	struct      SUB_ORDER_CAN_ICEX   sPartycomp[LEG_LEN];
} FIX_ORDER_CANCEL_ICEX_REQUEST;

struct SUB_ORDER_REQ_NCDEX
{
        CHAR            sPartyId[ICEX_PARTY_ID_LEN];
        CHAR            cPartySrc;
        CHAR            sPartyRole[PARTY_ROLE_LEN];
};

typedef struct
{
        INT_HEADER  Header;
        FIX_HEADER  FIXHeader;

        CHAR            sClOrdId		[CLORDID_LEN];                  /***** TAG 11 ****/
        CHAR            sAccount		[CSD_ACCT_NUMBER_LEN];          /***** TAG 1 *****/
        CHAR            cHandlInst;                                 		/***** TAG 21 ****/
        CHAR            sExecInst		[EXEC_INST_LEN];                /***** TAG 18 ****/
        DOUBLE64        fMinQty;                                   		/***** TAG 110 ***/
        DOUBLE64        fMaxFloor;                                  		/***** TAG 111****/
        CHAR            sSymbol			[ICEX_SYMBOL_LEN];              /***** TAG 55 ****/
        CHAR            sSymbolSfx		[SYMBOL_SFX_LEN];               /***** TAG 65 ****/
        CHAR            sSecurityType		[DB_INS_LEN];                   /***** TAG 167 ****/
        CHAR            cSide;                                      		/***** TAG 54 ****/
        CHAR            sTransactTime		[FIX_DATE_TIME_LEN];            /***** TAG 60 ****/
        DOUBLE64        fQuantity;                                  		/***** TAG 38 ****/
        CHAR            cOrderType;                                 		/***** TAG 40 ****/
        DOUBLE64        fPrice;                                     		/***** TAG 44 ****/
        CHAR            cTimeInForce;                               		/***** TAG 59 ****/
        CHAR            cOrderCapacity;                             		/***** TAG 47 ****/
        CHAR            sText			[TEXT_LEN];                     /***** TAG 58 ****/
        CHAR            sIdSource		[ID_SOURCE_LEN];                /***** TAG 22 ****/
        DOUBLE64        fStopPx;                               			/***** TAG 99 ****/
        INT16           iProduct;                               		/****** Tag 460 *******/
        CHAR            sSecurityId		[SECURITY_ID_LEN];          	/***** TAG 48 ****/
        CHAR            cOpenCloseFlg;                          	    /***** TAG 77 ******/
        SHORT           iPutOrCall;                             	    /***** TAG 201 *****/
        DOUBLE64        fStrikePrice;                   	            /****** TAG 202 ****/
        CHAR            cCoverUncover;          	                    /****** TAG 203 *****/
        SHORT           iCustomerOrFirm;  	                      	    /***** TAG 204 ***/
        CHAR            sMaturityDay		[DAY];                      /***** TAG 205 *****/
        CHAR            sMaturityMonthYear	[MONTH_YEAR];               /***** TAG 200 ****/
        CHAR            cOptAttribute;          	                    /***** TAG 206 *****/
        LONG32          iTradSesStatus;                 	            /** TAG 340 **/ /** 1 = Halted , 2= Open , 3= Closed , 4= Pre-Open,5= PreClose **/
        CHAR            sComplianceID		[COMPLIANCE_LEN];           /*** 376 ***/
        CHAR            sExpireDate		[FIX_DATE_TIME_LEN];        /***** TAG 432 ***/
        CHAR            sClearingFirm		[CLEARING_ACCOUNT_LEN];     /***** TAG 440 ***/
        CHAR            sExecBroker		[FIX_BROKER_LEN];           /***** TAG 76 ***/
        CHAR            sTerminalInfo		[TERMINAL_INFO_LEN];        /***** TAG 9227 **/
        struct          SUB_ORDER_REQ_NCDEX	   sPartycomp[LEG_LEN];
} FIX_NEW_ORDER_NCDEX_REQUEST ;

struct SUB_ORDER_MOD_NCDEX
{
        CHAR            sPartyId[NCDEX_PARTY_ID_LEN];
        CHAR            cPartySrc;
        CHAR            sPartyRole[PARTY_ROLE_LEN];
};

typedef struct
{
        INT_HEADER  Header;
        FIX_HEADER  FIXHeader;

        CHAR            sOrderID[ORDER_ID_LEN];                         /***** TAG 37 *****/
        CHAR            sOrigClOrdId[CLORDID_LEN];                      /***** TAG 41 *****/
        CHAR            sClOrdId[CLORDID_LEN];                          /***** TAG 11 *****/
        CHAR            sAccount[CSD_ACCT_NUMBER_LEN];                  /***** TAG 1  *****/
        SHORT           iOrderFamily;                                   /***** TAG 9743 ***/
        CHAR            cHandlInst;                                     /***** TAG 21 *****/
        CHAR            sExecInst[EXEC_INST_LEN];                       /***** TAG 18 *****/
        DOUBLE64        fMinQty;                                        /***** TAG 110 ****/
        DOUBLE64        fMaxFloor;                                      /***** TAG 111 ****/
        CHAR            sSymbol[ICEX_SYMBOL_LEN];                            /***** TAG 55 *****/
        CHAR            sSymbolSfx[SYMBOL_SFX_LEN];                     /***** TAG 65 *****/
        CHAR            cSide;                                          /***** TAG 54 *****/
        CHAR            sTransactTime[FIX_DATE_TIME_LEN];               /***** TAG 60 *****/
        DOUBLE64        fQuantity;                                      /***** TAG 38 *****/
        CHAR            cOrderType;                                     /***** TAG 40 *****/
        DOUBLE64        fPrice;                                         /***** TAG 44 *****/
        LONG32          dCumQty;                                        /***** TAG 14 *****/
        CHAR            cTimeInForce;                                   /***** TAG 59 *****/
        CHAR            sExpireTime[FIX_DATE_TIME_LEN];                 /***** TAG 126 ****/
        CHAR            cOrderCapacity;                                 /***** TAG 47 *****/
        CHAR            cOrderFamily;                                   /***** TAG 9743 ***/
        CHAR            sIdSource[ID_SOURCE_LEN];                       /***** TAG 22 *****/
        DOUBLE64        fStopPx;                                        /***** TAG 99 *****/
        CHAR            sSecurityEx[EXCHANGE_LEN];                      /***** TAG 207 ****/
        DOUBLE64        fStrikePrice;                                   /***** TAG 202 ****/
        SHORT           iSettlmntType;                                  /***** TAG 63 *****/
        CHAR            sFutSettDate[FIX_DATE_TIME_LEN];                /***** TAG 64 *****/
        CHAR            sSecurityType[SEC_TYPE];                        /***** TAG 167 ****/
        CHAR            cCoverUncover;                                  /***** TAG 203 ****/
        CHAR            cOpenCloseFlg;                                  /***** TAG 77 *****/
        INT16           iProduct;                                       /****** Tag 460 *******/
        CHAR            sMaturityMonthYear[MAT_MONYR];                  /***** TAG 200 ****/
        SHORT           iPutOrCall;                                     /***** TAG 201 ****/
        CHAR            cOptAttribute;                                  /***** TAG 206 ****/
        CHAR            sMaturityDay[DAY];            /***** TAG 205 ****/
        CHAR            sCurrency[MAX_CURRENCY_LEN];                    /***** TAG 15 *****/
        LONG32          dReceivedTime;                                  /****/
        SHORT           iQtyCondition ;                                 /****FOR AON on ***/
        CHAR            sOrigTime[FIX_DATE_TIME_LEN];                   /***** TAG 42 *****/
        CHAR            sSecurityId[SECURITY_ID_LEN];                   /***** TAG 48 *****/
        CHAR            sText[TEXT_LEN];                                /***** TAG 58 *****/
        CHAR            sClientID[CLIENT_ID_LEN];                       /***** TAG 109 ****/
        CHAR            sComplianceID[COMPLIANCE_LEN];                  /***** TAG 376 ****/
        SHORT           iCustomerOrFirm;                                /***** TAG 204 ****/
        DOUBLE64        fMaxShow;                                       /***** TAG 210 ****/
        CHAR            sTradingSessionID[TRADING_SESS_LEN];            /***** TAG 336 ****/
        SHORT           iNoTradingSessions;                             /***** TAG 386 ****/
        CHAR            sClearingFirm[CLEARING_ACCOUNT_LEN];            /***** TAG 440 ****/
        CHAR            sExpireDate[FIX_DATE_TIME_LEN];                 /***** TAG 432 ****/
        CHAR            sLastModTime[FIX_DATE_TIME_LEN];                /***** TAG 6000 ***/
        CHAR            sTerminalInfo[TERMINAL_INFO_LEN];               /***** TAG 9227 **/
        struct          SUB_ORDER_MOD_ICEX   sPartycomp[LEG_LEN];

} FIX_ORDER_MODIFICATION_NCDEX_REQUEST;

struct SUB_ORDER_CAN_NCDEX
{
        CHAR            sPartyId[NCDEX_PARTY_ID_LEN];
        CHAR            cPartySrc;
        CHAR            sPartyRole[PARTY_ROLE_LEN];
};

typedef struct
{
        INT_HEADER  Header ;
        FIX_HEADER  FIXHeader;
        CHAR            sOrigClOrdId[CLORDID_LEN];                  /***** TAG 41 *****/
        CHAR            sOrderID[ORDER_ID_LEN];                     /***** TAG 37 *****/
        CHAR            sClOrdId[CLORDID_LEN];                      /***** TAG 11 ****/
        CHAR            sAccount[CSD_ACCT_NUMBER_LEN];              /***** TAG 1 *****/
        CHAR            sSymbol[ICEX_SYMBOL_LEN];                        /***** TAG 55 ****/
        CHAR            sSymbolSfx[SYMBOL_SFX_LEN];                 /***** TAG 65 ****/
        CHAR            cSide;                                      /***** TAG 54 ****/
        CHAR            sTransactTime[FIX_DATE_TIME_LEN];           /***** TAG 60 ****/
        CHAR            sIdSource[ID_SOURCE_LEN];                   /***** TAG 22 ****/
        DOUBLE64        fQuantity;                                  /***** TAG 38 ****/
        CHAR            cOrderType;                             /***** TAG 40 *****/
        CHAR            sSecurityEx[EXCHANGE_LEN];                   /***** TAG 207 ****/
        DOUBLE64        fStrikePrice;                               /****** TAG 202 ****/
        SHORT           iSettlmntType;                              /****** TAG 63 *****/
        CHAR            sFutSettDate[FIX_DATE_TIME_LEN];            /****** TAG 64 *****/
        INT16           iProduct;                               /****** Tag 460 *******/
        CHAR            sSecurityType[SEC_TYPE];                    /****** TAG 167 *****/
        CHAR            cCoverUncover;                              /****** TAG 203 *****/
        CHAR            cOpenCloseFlg;                              /***** TAG 77 ******/
        CHAR            sMaturityMonthYear[MAT_MONYR];             /***** TAG 200 *****/
        SHORT           iPutOrCall;                                 /***** TAG 201 *****/
        CHAR            cOptAttribute;                              /***** TAG 206 *****/
        CHAR            sMaturityDay[DAY];                          /***** TAG 205 *****/
        LONG32          dReceivedTime;
        SHORT           iQtyCondition ;                             /****FOR AON on ***/
        CHAR            sSecurityId[SECURITY_ID_LEN];               /***** TAG 48 *****/
        CHAR            cListID;                                    /***** TAG 66 *****/
        CHAR            sComplianceID[COMPLIANCE_LEN];                  /*** 376 ***/
        SHORT           iCustomerOrFirm;                            /***** TAG 204*****/
        CHAR            cTechnicalOrdType;                          /***** TAG 9941 ***/
        CHAR            sOrigOrderID[ORDER_ID_LEN];                 /***** TAG 9945 ***/
        CHAR            sMemberID[MEMBERID_LEN]    ;                /***** TAG 9946****/
        CHAR            sSubscriberID[SUBSCRIBER_LEN];              /***** TAG 9955****/
        struct      SUB_ORDER_CAN_NCDEX   sPartycomp[LEG_LEN];
} FIX_ORDER_CANCEL_NCDEX_REQUEST;

#pragma pack(2)
typedef struct
{
        ULONG32         iMsgLength;				/*****  TAG 9  *****/
        SHORT	        iMsgCode;      				/*****  TAG 28500 *****/
	CHAR		sNetworkMsgID[NETWORK_MSG_ID_LEN];	/*****  TAG 25028 *****/
	CHAR		sPad2[ETI_PAD2_LENGHT];					/*****  TAG 25017 *****/ 
}INT_BSE_HEADER;
#pragma pack()

#pragma pack(2)
typedef struct
{
        ULONG32         iMsgLength;                             /*****  TAG 9  *****/
        SHORT           iMsgCode;                               /*****  TAG 28500 *****/
        CHAR            sPad2[2];                                       /*****  TAG 25017 *****/
}INT_BSE_HEADER_OUT;
#pragma pack()


#pragma pack(2)
typedef struct
{
	ULONG32		iMsgSeqNum;				/*****  TAG 28500 **/
        ULONG32         iSenderSubID;                    	/****** TAG 50 *****/
}FIX_BSE_HEADER;
#pragma pack()



#pragma pack(2)
typedef struct
{
       	INT_BSE_HEADER  Header;
 	FIX_BSE_HEADER  FIXHeader;

	LONG64          iOrderID;                               /***** TAG 37 *****/
        LONG64          iClOrdId;                               /***** TAG 11 *****/
        LONG64          iOrigClOrdId;                           /***** TAG 41 *****/
	LONG64          iPrice;                                 /***** TAG 44 ****/
	LONG64          iStopPx;                                /***** TAG 99 ****/
        LONG64          iMarkProVal;                            /***** TAG 28740 ****/
	LONG64          iLocCode;                               /***** TAG 142 ****/
	LONG64          iActivityTime;                          /***** TAG 30645 *****/
	LONG64          iFiller1;                               /***** TAG 30646 ****/
        ULONG32         iFiller2;                               /***** TAG 30647 ****/
  //      ULONG32         iFiller3;                               /***** TAG 30647 ****/
	LONG32          iMsgTag;                                /***** TAG 526 ****/
	LONG32          iQuantity;                              /***** TAG 38 ****/
	LONG32          iMaxShow;                               /***** TAG 210 ****/
	ULONG32         iExpireDate;                            /***** TAG 432 ****/
	LONG32          iMktSegId;                              /***** TAG 1300 ****/
	ULONG32         iSecurityId;                            /***** TAG 30048 ****/
	ULONG32         iTrgPtySessionId;                       /***** TAG 20655 ****/
	ULONG32         iRegulatoryId;                          /***** TAG 25029 ****/
	SHORT 		iFiller4;
	CHAR            sPartyIdTrdFirm[PARTY_TRD_FIRM_LEN];        /***** TAG 20096 ****/
        CHAR            sPartIdOrdOrgFirm[PARTY_ORG_ORD_FIRM_LEN];  /***** TAG 20013 ****/
        CHAR            sPartIdBenfciary[PARTY_ID_BENIF_LEN];       /***** TAG 20032 ****/
	CHAR         	cAccType;                               /***** TAG 581 ****/
	CHAR         	cAppOrdType;                            /***** TAG 28703 ****/
	CHAR         	cSide;                                  /***** TAG 54 ****/
	CHAR         	cOrderType;                             /***** TAG 40 ****/
	CHAR         	cPriceValChk;                           /***** TAG 28710 ****/
	CHAR         	cTimeInForce;                           /***** TAG 59 ****/
	CHAR         	cExecInst;                              /***** TAG 18 ****/
	CHAR		cFiller5;
	CHAR         	cTrdSessionSubId;                       /***** TAG 625 ****/
	CHAR         	cTradeCap;                              /***** TAG 1815 ****/
	CHAR            cDeltaQtyFlg;                           /***** TAG 30640 ****/
	CHAR            sAccount[FIX_ACCOUNT_LEN];              /***** TAG 1 *****/
	CHAR            cOpenCloseFlg;                          /***** TAG 77 ******/
	CHAR            sPartyIdLocId[PARTY_LOC_LEN];           /***** TAG 20075 ****/
        CHAR            cCustOrdHandIns;                        /***** TAG 1031 ****/
        CHAR            sRegulatoryTxt[REGULATORY_TXT_LEN];	/***** TAG 25015 ****/		
	CHAR            sAlgoID[ETI_ALGO_ID_LEN];               /***** TAG 30649 ****/
	CHAR            sClientID[CLIENT_UCC_CODE_LEN];         /***** TAG 58 ****/
        CHAR            sParticipantCode[ETI_PARTICIPANT_LEN]; /***** TAG 30642 ****/
	CHAR            sFreeTxt3[FREE_TXT_LEN];             	/***** TAG 25009 ****/
	CHAR		sPad4[4];			/***** TAG  25019 ***/	


} FIX_BSE_ORD_MODIFICATION_REQ;
#pragma pack()

#pragma pack(2)
typedef struct
{
        INT_BSE_HEADER  Header ;
        FIX_BSE_HEADER  FIXHeader;

	LONG64          iOrderID;	                        /***** TAG 37 *****/
        LONG64          iOrigClOrdId;                           /***** TAG 41 *****/
        LONG64          iClOrdId;                               /***** TAG 11 *****/
	LONG64          iActivityTime;                          /***** TAG 30645 *****/
        LONG32          iMsgTag;                                /***** TAG 526 ****/
 	LONG32          iMktSegId;                              /***** TAG 1300 ****/
	ULONG32         iSecurityId;                            /***** TAG 30048 ****/
	ULONG32         iTrgPtySessionId;                       /***** TAG 20655 ****/
        ULONG32         iRegulatoryId;                          /***** TAG 25029 ****/
	CHAR            sAlgoID[ETI_ALGO_ID_LEN];               /***** TAG 30649 ****/
	CHAR            sPad4[ETI_PAD4_LENGHT];                  /***** TAG  25019 ***/
		
} FIX_BSE_ORDER_CANCEL_REQUEST;
#pragma pack()


#pragma pack(2)
typedef struct
{
        ULONG32         iMsgLength;                             /*****  TAG 9  *****/
        SHORT	        iMsgCode;                               /*****  TAG 28500 *****/
        CHAR            sPad2[ETI_PAD2_LENGHT];                 /*****  TAG 25017 *****/
}ETI_BSE_RES_HEADER;
#pragma pack()

#pragma pack(2)
typedef struct
{
	LONG64		iGateReqTime;				/*****  TAG 5979 *****/
	LONG64		iGateResTime;				/*****  TAG 7764 *****/
	LONG64		iTrdRegTSTimeIn;			/*****  TAG 21002 *****/
	LONG64		iTrdRegTSTimeOut;			/*****  TAG 21003 *****/
	LONG64		iResponseIn;				/*****  TAG 7765 *****/
	LONG64		iSendingTime;				/*****  TAG 52 *****/
	ULONG32         dMsgSeqNum;                             /*****  TAG 34 *****/
	SHORT		iPartitionID;				/*****  TAG 5948 *****/
	CHAR		cApplID;				/*****  TAG 1180 *****/
	CHAR            sApplMsgID[APP_MSG_IDTFR_LEN];          /*****  TAG 28704 ******/	
	CHAR		cLastFragment;				/*****  TAG 893 *****/

}ETI_EXE_BSE_HEADER;
#pragma pack()

#pragma pack(2)
typedef struct
{
   	LONG64          iTrdRegTSTimeOut;                       /*****  TAG 21003 *****/
	LONG64          iSendingTime;                           /*****  TAG 52 *****/
	LONG32		iApplSubID;				/*****	TAG 28727 **/	
	SHORT           iPartitionID;                           /*****  TAG 5948 *****/
	CHAR            sApplMsgID[APP_MSG_IDTFR_LEN];          /*****  TAG 28704 ******/
	CHAR            cApplID;                                /*****  TAG 1180 *****/
	CHAR		cApplResendFlag;			/*****	TAG 1352 *****/
	CHAR            cLastFragment;                          /*****  TAG 893 *****/	
	CHAR		sPad7[ETI_PAD7_LENGHT];			/*****	TAG 25022 ***/	

}ETI_MASS_CAN_BSE_HEADER;
#pragma pack()


#pragma pack(2)
typedef struct
{
	LONG64		iLegSecurityID;					/*****  TAG 602 ******/
	LONG64		iLegLastPrice;					/*****  TAG 637 ******/
	LONG32		iLegLastQty;					/*****  TAG 1418 ******/
	LONG32		iLegExecID;					/*****  TAG 1893 ******/
	CHAR		cLegSide;					/*****  TAG 624 ******/
	CHAR		cNoFillsIndex;					/*****  TAG 25010 ******/
	CHAR		sPad6[ETI_PAD6_LENGHT];				/*****  TAG  25021 ****/

} BSE_RECORD_CNT;
#pragma pack()

#pragma pack(2)
typedef struct
{
	LONG64		iFillPrice;					/*****  TAG 1364 ******/
	LONG64	        iFillYieldPrice;                                /*****  TAG 1623 ******/
        LONG64  	iFillDirtyPrice;                                /*****  TAG 30644 *****/
	LONG32		iFillQty;					/*****  TAG 1365 ******/
	LONG32		iFillMatchID;					/*****  TAG 1893 ******/
	LONG32		iFillExecID;					/*****  TAG 1363 ******/
	CHAR		cFillLiquidityInd;				/*****  TAG 1443 ******/
	CHAR		sPad3[ETI_PAD3_LENGHT];				/*****  TAG 25018 *****/

} BSE_PARTFILLS_CNT;
#pragma pack()




#pragma pack(2)
struct FIX_BSE_EXECUTION_REPORT
{
	ETI_BSE_RES_HEADER  Header;
        ETI_EXE_BSE_HEADER  FIXHeader;

	LONG64          iOrderID;                               /***** TAG 37 *****/
        LONG64          iClOrdId;                               /***** TAG 11 *****/
        LONG64          iOrigClOrdId;                           /***** TAG 41 *****/
	LONG64          iSecurityId;                            /***** TAG 48 ****/
        LONG64          iExecID;                                /***** TAG 17 *****/
	LONG64          iTrdRegEntryTime;                       /***** TAG 21009 *****/
        LONG64          iTrdRegTimePri;                         /***** TAG 21008 *****/
	LONG64          iActivityTime;                          /***** TAG 30645 ****/
        LONG64          iFiller1;                               /***** TAG 30646 ****/
        ULONG32	        iFiller2;                               /***** TAG 30647 ****/
       // ULONG32	        iFiller3;                               /***** TAG 30647 ****/
	LONG32          iMktSegId;                              /***** TAG 1300 *****/
	LONG32          dLeavesQty;                             /***** TAG 151 ******/
	LONG32          dCumQty;                                /***** TAG 14  ******/
	LONG32          iCxlQty;                                /***** TAG 84  ******/
	SHORT		cFiller4;
	SHORT           iNoLegExecs;                            /***** TAG 30555 ****/
	SHORT           dExecRestatReason;                      /***** TAG 378 ******/	
	CHAR            cProdComplex;                           /***** TAG 1227 *****/
	CHAR            cOrdStatus;                             /***** TAG 39  ******/
	CHAR            cExecType;                              /***** TAG 150  *****/
	CHAR            cTriggeredInd;                          /***** TAG 1823 *****/
	CHAR		cFiller5;
	CHAR            cNoFillsExc;                            /***** TAG 1365 *****/
	CHAR            sAlgoID[ETI_ALGO_ID_LEN];               /***** TAG 30649 ****/
//	CHAR		sPad7[7];
	BSE_PARTFILLS_CNT       NoFills;
	//BSE_RECORD_CNT          NoLegExecs[LEG_RECORD_CNT];

				
} ;
#pragma pack()

#pragma pack(2)
typedef struct 
{
	LONG64		iNotAffOrderID;			/***** TAG 1371  *****/
	LONG64		iNotAffOrigClOrdID;		/***** TAG 1372  *****/

} BSE_NOT_AFF_ORD_GRP;
#pragma pack()

#pragma pack(2)
struct FIX_BSE_MASS_CACELLATION
{
	ETI_BSE_RES_HEADER	Header;
        ETI_MASS_CAN_BSE_HEADER	FIXHeader;

	LONG64		iMassActionReportID;				/***** TAG 1369 *****/
	LONG64          iSecurityId;                            	/***** TAG 30048 ****/
	LONG32          iMktSegId;                                      /***** TAG 1300 *****/
	LONG32          iTrgPtySessionId;                               /***** TAG 20655 ****/
	LONG32          iExeTradeID;                                    /***** TAG 20612 ****/
	LONG32          iPartyIDEntTrd;                                 /***** TAG 20026 ****/
	SHORT	        iNoNotAffectedOrd;                              /***** TAG 1370 ****/
	CHAR	        cPartyIDEntFirm;                                /***** TAG 20007 ****/
	//LONG32          iMassActionReason;                              /***** TAG 28721 ****/
	CHAR		iMassActionReason;                              /***** TAG 28721 ****/
	//LONG32		iExecInst;		                   	/***** TAG 18 ****/
	CHAR		iExecInst;		                   	/***** TAG 18 ****/
	CHAR		sPad3[ETI_PAD3_LENGHT];	

	BSE_NOT_AFF_ORD_GRP	NotAffOrdersGrp[NO_OF_ORD_LEN];		
} ;
#pragma pack()

#pragma pack(2)
struct	FIX_BSE_GATEWAY_REQUEST
{
	INT_BSE_HEADER		pHeader;
	FIX_BSE_HEADER		pLoginHeader;
	ULONG32			iSessionPartyId;
	CHAR			sDefCustAppVerId[DEFAULT_CUST_APP_VER_ID_LEN];
	CHAR			sBsePassword	[BSE_ETI_PASSWORD_LEN];
	CHAR			sPad6		[6];
			
};
#pragma pack()

#pragma pack(2)
typedef struct
{
        ULONG32         iMsgLength;                             /*****  TAG 9  *****/
        SHORT           iMsgCode;                               /*****  TAG 28500 *****/
        CHAR            sPad2[2];                               /*****  TAG 25017 *****/
}ETI_BSE_HEADER_RES;
#pragma pack()

#pragma pack(2)
struct	SUB_FIX_BSE_SESSION_GRP
{
	LONG32	iPartSessoinId;
	CHAR	cSessionMode;
	CHAR	cSessionSubMode;
	CHAR	sPad2	[2];	
};
#pragma pack()


#pragma pack(2)
struct 	FIX_BSE_SESSION_RESPONSE
{
	INT_BSE_HEADER          pHeader;
	LONG64			iRequestTime;
	LONG64			iSendTime;
	LONG32			iMsgSeqNum;
	CHAR			sPad2[4];
	USHORT			iNoOfSession;
	CHAR			sPad6[6];
	struct  SUB_FIX_BSE_SESSION_GRP	sSubSession[1000];		
		
};
#pragma pack()


#pragma pack(2)
struct	FIX_BSE_GATEWAY_RESPONSE
{
	ETI_BSE_HEADER_RES          pHeader;
	LONG64                  iRequestTime;
        LONG64                  iSendTime;
        ULONG32                 iMsgSeqNum;
	CHAR			sPad4	[4];
	ULONG32			iPriGateWayId;
	ULONG32			iPriGateWaySubId;
	ULONG32			iSecGayeWayId;
	ULONG32			iSecGayeWaySubId;
	CHAR			cSessionMode;
	CHAR			cTradeSessMode;
	CHAR			sPad6	[6];
	
	
};
#pragma pack()


#pragma pack(2)
struct	FIX_BSE_SESSION_LOGON_REQ
{
	INT_BSE_HEADER          pHeader;
	LONG32			iMsgSeqNum	;
	LONG32			iSenderSubId	;
	LONG32			iHeartBeats	;
	LONG32			iPartySessionId	;
	CHAR                    sDefCustAppVerId[DEFAULT_CUST_APP_VER_ID_LEN];
	CHAR                    sBsePassword    [BSE_ETI_PASSWORD_LEN];
	CHAR			cAppUsageOrd	;
	CHAR			cAppUageQuotes	;
	CHAR			cOrderRoutiIndicator	;
	CHAR			sFixEngineName	[FIX_ENGINE_NAME_LEN];		
	CHAR			sFixEngineVersion	[FIX_ENGINE_VERSION_LEN];		
	CHAR			sFixEngineVendor	[FIX_ENGINE_VENDOR_LEN];		
	CHAR			sFixAppSysName	[FIX_APP_SYSTEM_NAME_LEN];		
	CHAR			sFixAppSysVersion	[FIX_APP_SYSTEM_VERSION_LEN];		
	CHAR			sFixAppSysVendor	[FIX_APP_SYSTEM_VENDOR_LEN];	
	CHAR			sPag3		[3];	
};
#pragma pack()


#pragma pack(2)
struct	FIX_SESSION_LOGON_RESP
{
	INT_BSE_HEADER_OUT	pHeader;
	LONG64                  iRequestTime;
        LONG64                  iSendTime;
        LONG32                  iMsgSeqNum;
        CHAR                    sPad4   [4];
	LONG64			iThrottleTimeInterval;
	LONG64			iLastLoginTime;
	LONG32			iLastLoginIp;
	LONG32			iThrottleNumMsg;
	LONG32			iThrottleDisconnLimit;
	LONG32			iHeartBeats;
	LONG32			iSessionInstanceId;
	CHAR			cTradeSessMode;
	CHAR			cNumOfPartition;
	CHAR			cDayLeftPassExpiry;
	CHAR			cGraceLoginLeft;
        CHAR                    sDefCustAppVerId[DEFAULT_CUST_APP_VER_ID_LEN];
	CHAR			sPad2[2];	
	
};
#pragma pack()


#pragma pack(2)
struct	FIX_SESSION_LOGOUT_REQ
{
	INT_BSE_HEADER          pHeader;
	LONG32                  iMsgSeqNum;
	LONG32			iSendSubId;
	
};
#pragma pack()

#pragma pack(2)
struct	FIX_SESSION_LOGOUT_RESP
{
	INT_BSE_HEADER          pHeader;
	LONG64                  iRequestTime;
        LONG64                  iSendTime;
        LONG32                  iMsgSeqNum;
	CHAR			sPad4[4];
};
#pragma pack()

#pragma pack(2)
struct	FIX_BSE_USER_LOGON_REQ
{
	INT_BSE_HEADER          pHeader;
	LONG32                  iMsgSeqNum;
        LONG32                  iSendSubId;
	LONG32			iExchUserId;
	CHAR			sBsePassword	[BSE_ETI_PASSWORD_LEN];
	CHAR			sPad4[4];


};
#pragma pack()


#pragma pack(2)
struct	FIX_BSE_USER_LOGON_RESP
{
	INT_BSE_HEADER_OUT	pHeader;
	LONG64                  iRequestTime;
        LONG64                  iSendTime;
        LONG32                  iMsgSeqNum;
        CHAR                    sPad4[4];
	LONG64			iLastLoginTime;
	CHAR			cDayLeftForPasswdExpiry;
	CHAR			cGraceLoginLeft;
	CHAR			sPad6[6];
};
#pragma pack()

#pragma pack(2)
struct	FIX_BSE_ORDER_DOWNLOAD
{
	INT_BSE_HEADER          pHeader;
        LONG32                  iMsgSeqNum;
        LONG32                  iSendSubId;
	LONG32			iSubscriptionScope;
	SHORT			iPartitionId;
	CHAR			cRefApplId;
	CHAR			sApplBeginMsgId[16];
	CHAR			sApplEndMsgId[16];
	CHAR			cPad1;	

};
#pragma pack()


#pragma pack(2)
struct	FIX_BSE_SESSION_REJECT_RESP
{
	INT_BSE_HEADER_OUT      pHeader;
	LONG64			iRequestTime;
	LONG64			iRequestOut;
	LONG64			iTradeRegTSTimeIn;
	LONG64			iTradeRegTSTimeOut;
	LONG64			iResponseIn;
	LONG64			iSendingTime;
	LONG32			iMsgSeqNum;
	CHAR			cLastFragment;
	CHAR			sPad3[3];
	LONG32			iRejectionReasonCode;
	SHORT			iRejMsgLen	;
	CHAR			cSessionStatus;
	CHAR			cPad1;
	CHAR			sRejectionMsg[2000];	

};
#pragma pack()

#pragma pack(2)
typedef struct
{
        INT_BSE_HEADER  Header;
        FIX_BSE_HEADER  FIXHeader;

        LONG64          iPrice;                                 /***** TAG 44 ****/
        LONG64          iStopPx;                                /***** TAG 99 ****/
        LONG64          iMarkProVal;                            /***** TAG 28740 ****/
        LONG64          iLocCode;                               /***** TAG 142 ****/
        LONG64          iClOrdId;                               /***** TAG 11 ****/
        LONG64          iFiller1;                               /***** TAG 30646 ****/
        ULONG32         iFiller2;                               /***** TAG 30647 ****/
 //       ULONG32         iFiller3;                               /***** TAG 30647 ****/
        LONG32          iMsgTag;                                /***** TAG 526 ****/
        LONG32          iQuantity;                              /***** TAG 38 ****/
        LONG32          iMaxShow;                               /***** TAG 210 ****/
        ULONG32         iExpireDate;                            /***** TAG 432 ****/
        LONG32          iMktSegId;                              /***** TAG 1300 ****/
        ULONG32         iSecurityId;                            /***** TAG 30048 ****/
        ULONG32         iRegulatoryId;                          /***** TAG 25029 ****/
        SHORT           iFiller4;                               /***** TAG 30652 ****/
        CHAR            sPartyIdTrdFirm[PARTY_TRD_FIRM_LEN];        /***** TAG 20096 ****/
        CHAR            sPartIdOrdOrgFirm[PARTY_ORG_ORD_FIRM_LEN];  /***** TAG 20013 ****/
        CHAR            sPartIdBenfciary[PARTY_ID_BENIF_LEN];       /***** TAG 20032 ****/
        CHAR            cAccType;                               /***** TAG 581 ****/
        CHAR            cAppOrdType;                            /***** TAG 28703 ****/
        CHAR            cSide;                                  /***** TAG 54 ****/
        CHAR            cOrderType;                             /***** TAG 40 ****/
        CHAR            cPriceValChk;                           /***** TAG 28710 ****/
        CHAR            cTimeInForce;                           /***** TAG 59 ****/
        CHAR            cExecInst;                              /***** TAG 18 ****/
	CHAR		cSTPCFlag;
	CHAR		cFiller5;
        CHAR            cTrdSessionSubId;                       /***** TAG 625 ****/
        CHAR            cTradeCap;                              /***** TAG 1815 ****/
        CHAR            sAccount[FIX_ACCOUNT_LEN];                  /***** TAG 1 *****/
	CHAR		cPositionEffect;
        CHAR            sPartyIdLocId[PARTY_LOC_LEN];                          /***** TAG 20075 ****/
        CHAR            cCustOrdHandIns;                        /***** TAG 1031 ****/
        CHAR            sRegulatoryTxt[REGULATORY_TXT_LEN];     /***** TAG 25015 ****/
        CHAR            sAlgoID[ETI_ALGO_ID_LEN];               /***** TAG 30649 ****/
        CHAR            sClientID[CLIENT_UCC_CODE_LEN];              /***** TAG 58 ****/
        CHAR            sParticipantCode[ETI_PARTICIPANT_LEN];      /***** TAG 30642 ****/
        CHAR            sFreeTxt3[FREE_TXT_LEN];                     /***** TAG 25009 ****/

}FIX_BSE_ORDER_REQUEST;
#pragma pack()

#pragma pack(2)
struct	ETI_BSE_NEW_ORD_RESPONSE
{
	ETI_BSE_RES_HEADER  Header;
	ETI_EXE_BSE_HEADER  FIXHeader;	

	LONG64          iOrderID;				/***** TAG 37 *****/
	LONG64          iClOrdId;				/***** TAG 11 *****/
	LONG64          iSecurityId;                            /***** TAG 30048 ****/
	LONG64          iMktToLmtPrice;				/***** TAG 44 ****/
	LONG64	        iYieldPrice;				/***** TAG 236 *****/
        LONG64  	iDirtyPrice;				/***** TAG 882 *****/
	LONG64		iExecID;	                        /***** TAG 17 *****/
	LONG64         	iTrdRegEntryTime;		        /***** TAG 21009 *****/
        LONG64         	iTrdRegTimePri;			        /***** TAG 21008 *****/
	LONG64         	iActivityTime;               		/***** TAG 30645 ****/	
	LONG64          iFiller1;                               /***** TAG 30646 ****/
        ULONG32         iFiller2;                               /***** TAG 30647 ****/
	//ULONG32		iFiller4;				/***** TAG 30648 ****/
	SHORT		iFiller4;				/***** TAG 30648 ****/
	CHAR            cOrdStatus;                             /***** TAG 39  ******/
	CHAR            cExecType;                              /***** TAG 150  *****/
	SHORT		dExecRestatReason;	                /***** TAG 378 ******/		
	CHAR           	cProdComplex;                           /***** TAG 1227 *****/
	CHAR	        cFiller5;                               /***** TAG 30653 ****/
	CHAR		sPad4[ETI_PAD4_LENGHT];			/***** TAG 25019 ****/

};
#pragma pack()

#pragma pack(2)
struct	ETI_BSE_MOD_ORD_RESPONSE
{
	ETI_BSE_RES_HEADER  Header;
        ETI_EXE_BSE_HEADER  FIXHeader;

	LONG64          iOrderID;                               /***** TAG 37 *****/
        LONG64          iClOrdId;                               /***** TAG 11 *****/
	LONG64          iOrigClOrdId;                           /***** TAG 41 *****/
	LONG64          iSecurityId;                            /***** TAG 48 ****/
	LONG64          iExecID;                                /***** TAG 17 *****/
        LONG64          iMktToLmtPrice;                         /***** TAG 44 ****/
        LONG64          iYieldPrice;                            /***** TAG 236 *****/
        LONG64          iDirtyPrice;                            /***** TAG 882 *****/
        LONG64          iTrdRegEntryTime;                       /***** TAG 21009 *****/
        LONG64	        iActivityTime;                          /***** TAG 30645 ****/
        LONG64          iFiller1;                               /***** TAG 30646 ****/
        ULONG32         iFiller2;                               /***** TAG 30647 ****/
      //  ULONG32         iFiller3;                               /***** TAG 30647 ****/
        LONG32          dLeavesQty;                             /***** TAG 151 ******/
        LONG32          dCumQty;                                /***** TAG 14  ******/
        LONG32          iCxlQty;                                /***** TAG 84  ******/
	SHORT		cFiller4;
        CHAR            cOrdStatus;                             /***** TAG 39  ******/
        CHAR            cExecType;                              /***** TAG 150  *****/
        SHORT           dExecRestatReason;                      /***** TAG 378 ******/
        CHAR            cProdComplex;                           /***** TAG 1227 *****/
       // CHAR	        cPad3[7];                               /***** TAG 30653 ****/
        CHAR		cFiller5;

};
#pragma pack()

#pragma pack(2)
struct  ETI_BSE_CAN_ORD_RESPONSE
{
	ETI_BSE_RES_HEADER  Header;
        ETI_EXE_BSE_HEADER  FIXHeader;

        LONG64          iOrderID;                               /***** TAG 37 *****/
        LONG64          iClOrdId;                               /***** TAG 11 *****/
        LONG64          iOrigClOrdId;                           /***** TAG 41 *****/
        LONG64		iSecurityId;                            /***** TAG 48 ****/
        LONG64          iExecID;                                /***** TAG 17 *****/
        LONG32          dCumQty;                                /***** TAG 14  ******/
        LONG32          iCxlQty;                                /***** TAG 84  ******/
        CHAR            cOrdStatus;                             /***** TAG 39  ******/
        CHAR            cExecType;                              /***** TAG 150  *****/
        SHORT           dExecRestatReason;                      /***** TAG 378 ******/
        CHAR            cProdComplex;                           /***** TAG 1227 *****/
	CHAR		sPad3[ETI_PAD3_LENGHT];			/***** TAG  25019 ***/	
};
#pragma pack()

#pragma pack(2)
struct	ETI_ORDER_CONFIRM_RESPONSE
{
	ETI_BSE_RES_HEADER  Header;
	LONG64                  iRequestTime;
        LONG64                  iSendTime;
        LONG32                  iMsgSeqNum;
        CHAR                    sPad1[4];
	
	LONG64          iOrderID;                               /***** TAG 37 *****/
        LONG64          iClOrdId;                               /***** TAG 11 *****/
	LONG32		iMsgTag	;				/***** TAG 526 ****/
	CHAR		sPad4[4]	;				/***** TAG 25019 ***/		
};
#pragma pack()

#pragma pack(2)
struct	ETI_SUBSCRIBE_REQ
{
	INT_BSE_HEADER  pHeader;
        FIX_BSE_HEADER  FIXHeader;

	LONG32		iSubscribScope;
	CHAR		iRefAppId;
	CHAR		sPad3[3];		
};	
#pragma pack()
#pragma pack(2)
struct	ETI_SUBSCRIBE_RESP
{
	ETI_BSE_RES_HEADER  Header;
	LONG64			iRequestTime;
	LONG64			iSendTime;
	LONG64			iMsgSeqNum;
	CHAR			Pad4[4];	

	LONG32			iApplSubId	;
	CHAR			Pad5[4];
};	
#pragma pack()


#pragma pack(2)
struct FIX_BSE_TRADE_NOTIFICATION_RESP
{
        ETI_BSE_RES_HEADER  Header;
//        ETI_EXE_BSE_HEADER  FIXHeader;
	LONG64		iSendingTime;
	LONG64		iApplSeqNum;
	LONG32		iApplSubId;
	SHORT		iPartionId;
	CHAR		cApplResendFlag;
	CHAR		cApplId;
	CHAR		cLastFragment;
	CHAR		sPad8[7];

	LONG64		iSecurityId;	
	LONG64		iRelatedSecId;
	LONG64		iOrderPrice;
	LONG64		iTradePrice;
	LONG64		iSideLastPrice;
	LONG64		iClearingTrdPrice;
	LONG64		iUndlyingDirtyPrice;
	LONG64		iYieldPrice;
	LONG64		iTransactTime;
	LONG64		iExchOrdNumber;
	LONG64		iSenderLocCode;
	LONG64		iClOrdId;
	LONG64		iActivityTime;	
	LONG64		iFiller4;
	LONG32		iFiller5;
	//LONG32		iFiller6;
	LONG32		iMsgTag;
	LONG32		iExchTradeNum;
	LONG32		iOrigTradeId;
	LONG32		iRootPartyIdExecUnit;
	LONG32		iRootPartyIdSessionId;
	LONG32		iRootPartyIdExecTrade;
	LONG32		iRootPartyIdClearUnit;
	LONG32		iCumQty;
	LONG32		iLeaveQty;
	LONG32		iMktSegmentId;
	LONG32		iRelatedSymbol;
	LONG32		iLastQtyTrade;
	LONG32		iSideLastQty;
	LONG32		iCLearTradeQty;
	LONG32		iSideTraderID;
	LONG32		iMatchDate;
	LONG32		iTrdMatchId;
	LONG32		iStrategyLinkId;
	LONG32		iTotTradeNumReport;
	SHORT 		cFiller4;
	CHAR		cMultiLegReportType;
	CHAR		cTradeReportType;
	CHAR		cTransferReason;
	CHAR		cFiller5;
	CHAR		sRootPartyIdBen[9];	
	CHAR		sRootPartyIdTakenUpTrdFrim[5];	
	CHAR		sRootPartyIdOrdOriginFirm[7];	
	CHAR		cAccountType;
	CHAR		cMatchType;
	CHAR		cMatchSubType;
	CHAR		cBuySellInd;
	CHAR		cAggresInd;
	CHAR		cTradeingCapacity;
	CHAR		sAccount[2];	
	CHAR		cPsotiionEffect;
	CHAR		cCustOrdHandlingInst;
	CHAR		sAlgoId[16];
	CHAR		sFreeText[12];	
	CHAR		sCPCode	[12];
	CHAR		sFreeText3[12];
	CHAR		cOrderCategory;	
	CHAR		cOrderType;
	CHAR		cRelatedProdComplx;
	CHAR		cOrderSide;
	CHAR            sRootPartyClearOrg[4];
        CHAR            sRootPartyExecFirm[5];
        CHAR            sRootPartyExecTradee[6];
        CHAR            sRootPartyClearFirm[5];
        CHAR            sPad7[7];

};
#pragma pack()


#pragma pack(2)
struct	FIX_BSE_EXTENDED_ORD_INFO_RESP
{
	INT_BSE_HEADER_OUT	pHeader;
	LONG64			iTrdRegTSTimeOut;
	LONG64			iSendingTime;
	LONG32			iApplSubId;
	SHORT			iPartionId;
	CHAR			sApplMsgId[16];	
	CHAR			cAppId;
	CHAR			cApplResendFlag;
	CHAR			cLastFragment;
	CHAR			sPad7[7];
	
	LONG64			iExchOrdNumber;
	LONG64			iClOrdId;	
	LONG64			iOrigClOrdId;
	LONG64			iSecurityId;
	LONG64			iMaxPricePercentage;
	LONG64			iSenderLocationCode;
	LONG64			iExecId;
	LONG64			iTrdRegTSEntryTime;
	LONG64			iTrdRegTimePrority;
	LONG64			iOrdPrice	;
	LONG64			iTriggerPrice	;
	LONG64			iUnderLyPrice	;
	LONG64			iYieldPrice;
	LONG64			iActivityTime	;
	LONG64			iFiller1	;
	LONG32			iFiller2	;
//	LONG32			iFiller3	;
	LONG32			iMktSegmentId	;
	LONG32			iMessageTag	;
	LONG32			iLeaveQty	;
	LONG32			iMaxShowQty	;
	LONG32			iCumQty		;
	LONG32			iCancelQty	;	
	LONG32			iOrderQty	;
	LONG32			iExpireDate	;
	LONG32			iPartyExeUnit	;
	LONG32			iPartSessionId	;
	LONG32			iPartyExecTrader	;
	LONG32			iPartyEnterTraderId	;
	SHORT			sFiller4	;
	SHORT			iNoOfLegs		;
	SHORT			iExecStatReason	;
	CHAR			cAccountType	;
	CHAR			cPartyIdEnterFirm	;
	CHAR			cProductComplex	;
	CHAR			cOrdStatus	;
	CHAR			cExecType	;
	CHAR			cBuySellInd	;
	CHAR			cOrderType	;
	CHAR			cTradingCapacity;
	CHAR			cTimeInForce	;
	CHAR			cExecInst	;	
	CHAR			cTradingSessSubId;
	CHAR			cApplSeqIndic	;
	CHAR			iSTPCFlag	;
	CHAR			iFiller5	;
	CHAR			sAccount[2];	
	CHAR			cPositionEffect;
	CHAR			sPartIdTakeUp[5];	
	CHAR			sPartIdOrdOrigFirm[7];
	CHAR			sPartIdBen[9];	
	CHAR			sPartyLocation[2];
	CHAR			cCustOrderHandling;
	CHAR			sRegularText[20];	
	CHAR			sAlgoId	[16];
	CHAR			sFreeText[12];
	CHAR			sCPCode	[12];
	CHAR			sFreeText1[12];
	CHAR			cNoOfFills;
	CHAR			cNoOfLegs;	
	CHAR			cTriggered;
	CHAR			sPad2[2];
/*
	CHAR			sLegAccount[2];
	CHAR			cLegPosiitEffect;
	CHAR			sPad5	[5];*/
/***	
	LONG64			iFillPrice	;
	LONG64			iFillYieldPrice	;
	LONG64			iFillDirtyPrice	;
	LONG32			iFillQty	;
	LONG32			iFillMatchId	;
	LONG32			iFillExecId	;
	LONG32			iFillLiqInd	;
	CHAR			sPad6[3];
****/
	LONG64			iFillPrice	;
	LONG64			iFillYieldPrice	;
	LONG64			iFillDirtyPrice	;
	LONG32			iFillQty	;
	LONG32			iFillMatchId	;
	LONG32			iFillExecId	;
	CHAR			iFillLiqInd	;
	CHAR			sPad6[3];
				
};
#pragma pack()

#pragma pack(2)
struct	FIX_ETI_BOOK_ORDER_EXEC_RESP
{
	INT_BSE_HEADER_OUT      pHeader;
        LONG64                  iTrdRegTSTimeOut;
        LONG64                  iSendingTime;
        LONG32                  iApplSubId;
        SHORT                   iPartionId;
        CHAR                    sApplMsgId[16];
        CHAR                    cAppId;
        CHAR                    cApplResendFlag;
        CHAR                    cLastFragment;
        CHAR                    sPad7[7];

	LONG64			iExchOrdNum;
	LONG64			iSenderLocCode;
	LONG64			iClOrdId;
	LONG64			iOrigClOrdId;
	LONG64			iSecurityId;
	LONG64			iExecId;
	LONG64			iActivityTime;
	LONG64			iFiller1;
	LONG32			iFiller2;
	//LONG32			iFiller3;
	LONG32			iMsgTag;
	LONG32			iMktSegmentId;	
	LONG32			iLeaveQty;
	LONG32			iCumQty;
	LONG32			iCanceledQty;
	SHORT			iNumOfLegsExec;
	SHORT 			cFiller;
	SHORT			iExecRestReason;
	CHAR			iAccountType;
	CHAR			iProdComplex;
	CHAR			cOrderStatus;
	CHAR			cExecType;
	CHAR			iTriggered;
	CHAR			iNumOfFills;
	CHAR			iBuySellSide;
	CHAR			cFiller5;
	CHAR			sAccount[2];
	CHAR			sAlgoId[16];
	CHAR			sUccClient[12];
	CHAR			sParticipantCode[12];
	CHAR			sFreeText2[12];
	CHAR			sPad4[4];		
	LONG64			iFillPrice;
	LONG64			iFillYeildPrice;
	LONG64			iFillDirtyPrice;
	LONG32			iFillQty;
	LONG32			iFillMatchId;
	LONG32			iFillExecId;					
	CHAR			iFillLiquidInd;
	CHAR			sPad6[3];	


};	
#pragma pack()

#pragma pack(2)
struct  TRADES_RETRANSMISSION_REQ
{
        INT_BSE_HEADER  pHeader;
        FIX_BSE_HEADER  FIXHeader;

	LONG64		iApplBegSeqNum;
	LONG64		iApplEndSeqNum;
	LONG32		iSubscriptionScope;
	SHORT		iPartitionId;
	CHAR		iRefApplId;

	CHAR		cPad3;
};
#pragma pack()


#pragma pack(2)
struct	TRADES_RETRANSMISSION_RESP
{
	INT_BSE_HEADER  pHeader;
	
	LONG64		iRequestTime;
	LONG64		iSendingTime;
	LONG32		iMsgSeqNum;
	CHAR		sPad4[4];

	LONG64		iApplEndSeqNum;
	LONG64		iRefAppLastSeqNum;
	SHORT		iTotalMsgCount;
	CHAR		sPad6[6];
};
#pragma pack()


#pragma pack(2)
struct	FIX_BSE_SESSION_LOGOUT_RESP
{
	INT_BSE_HEADER_OUT	pHeader;
	LONG64		iSendingTime;
	
	SHORT		iCounter;
	CHAR		sPad2[6];	
	CHAR		sErrorStrng[2000];
	
	
};
#pragma pack()

#pragma pack(2)
struct  ORDERS_RETRANSMISSION_REQ
{
        INT_BSE_HEADER  pHeader;
        FIX_BSE_HEADER  FIXHeader;

        LONG32          iSubscriptionScope;
        SHORT           iPartitionId;
        CHAR            iRefApplId;
        CHAR          	sApplBegSeqNum[16];
        CHAR          	sApplEndSeqNum[16];
        CHAR            cPad3;
};
#pragma pack()


#pragma pack(2)
struct  ORDERS_RETRANSMISSION_RESP
{
        INT_BSE_HEADER_OUT	pHeader;

        LONG64          iRequestTime;
        LONG64          iSendingTime;
        LONG32          iMsgSeqNum;
        CHAR            sPad4[4];

        SHORT           iTotalMsgCount;
        CHAR		sApplEndSeqNum[16];
        CHAR		sRefAppLastSeqNum[16];

        CHAR            sPad6[6];
};
#pragma pack()

#pragma pack(2)
struct	CANCEL_ORDER_NOTIFICATION
{
	INT_BSE_HEADER_OUT      pHeader;
	LONG64          iRequestTime;
        LONG64          iSendingTime;
	LONG32		iApplSubId;
	SHORT		iPartitionId;
	CHAR		sApplMsgId[16];	
	CHAR		cApplId;
	CHAR		cAppResendFlag;
	CHAR		cLastFragment;
	CHAR		sPad7[7];

	LONG64		iExchOrderNumb;
	LONG64		iClOrdId;
	LONG64		iOrigClOrdId;
	LONG64		iSecurityId;
	LONG64		iExecId;
	LONG32		iMesssageTag;
	LONG32		iCumQty;
	LONG32		iCancelQty;
	LONG32		iMarkSegId;
	LONG32		iPartIdEntTrade;
	SHORT		iExecRestReason;
	CHAR		cPartIdEntFirm;
	CHAR		cOrdStatus;
	CHAR		cExecType;
	CHAR		iProductComplex;
	CHAR		iBuySellInd;
	CHAR		sPad5[5];
	
};
#pragma pack()


LONG32 FIXParse(FIX_Msg* msg, const char* buffer, int len);
static LONG32 FIXGetNextTag(char** src, char** dst);
static LONG32 FIXGetNextValue(char** src, char** dst);
LONG32 FIXGetMessageType(FIX_Msg *msg);
#endif
