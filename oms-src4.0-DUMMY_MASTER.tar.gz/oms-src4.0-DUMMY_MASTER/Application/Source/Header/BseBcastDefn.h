#ifndef      __BSEBCAST__
#define      __BSEBCAST__

#define 	MAX_SIZE 			100
#define   	MAX_PACKET_SIZE_COMPRESS        1600


#define  	TC_EQU_BSE_AUC_SESSION_CHANGED_BROADCAST 		2003
#define  	TC_EQU_BSE_SESSION_CHANGED_BROADCAST             	2002
#define  	TC_EQU_BSE_TOUCH_LINE_BROADCAST                    	1901
#define  	TC_EQU_BSE_NEWS_BROADCAST                          	2004
#define  	TC_EQU_BSE_OPENING_PRICE_BROADCAST                 	2013
#define  	TC_EQU_BSE_CLOSING_PRICE_BROADCAST                 	2014
#define  	TC_EQU_BSE_MARKET_PIC_BROADCAST                    	2020
#define  	TC_EQU_BSE_POST_CLOSE_INDEX_BROADCAST              	1910
#define  	TC_EQU_BSE_INDEX_SENSEX_BROADCAST                  	1911
#define 	TC_EQU_BSE_INDEX_NEW_SENSEX_BROADCAST           	2011
#define 	TC_EQU_BSE_DETAIL_INDEX_BROADCAST                  	1948

#pragma pack(4)
struct  OMB_HEADER
{
	LONG32       iSlotNo;
	LONG32       iMsgLen;
};
#pragma pack()

#pragma pack(4)
struct  DUMMY_OMB_HEADER
{
	LONG32       iSlotNo;
	LONG32       iMsgLen;
	LONG32       iMsgType;
};
#pragma pack()

#pragma pack(4)
struct  OMB_NEWS_HEADLINE_BROADCAST
{
	struct  OMB_HEADER      OmbHeader;
	LONG32  iMsgType;
	LONG32  iReserved1;
	LONG32  iReserved2;
	USHORT  iReserved3;
	SHORT   iHour;  /** Time : HH**/
	SHORT   iMinute;        /** Time : MM**/
	SHORT   iSecond;        /** Time : SS**/
	SHORT   iMilliSecond;   /** Time : sss**/
	SHORT   iReserved4;
	SHORT   iReserved5;
	SHORT   iReserved6;
	SHORT   iNewsCategory;
	SHORT   Filler2;
	LONG32  iNewsId;
	CHAR    sNewsH1[40];
	CHAR    cReserved7;
	CHAR    cReserved8;
	CHAR    sReserved9[2];
};
#pragma pack()

#pragma pack(4)
struct  SUB_OPEN_CLOSE_PRICE_BROADCAST
{
	LONG32  iScripCode;
	LONG32  iPrice;
	CHAR    cReserved1;
	CHAR    cTradedToday; /*** Y - Yes , N-No****/
	CHAR    cReserved2;
	CHAR    cReserved3;
};
#pragma pack()

#pragma pack(4)
struct  OMB_OPEN_CLOSE_PRICE_BROADCAST
{
	struct  OMB_HEADER      OmbHeader;
	LONG32  iMsgType;
	LONG32  iReserved1;
	LONG32  iReserved2;
	USHORT  iReserved3;
	SHORT   iHour;  /** Time : HH**/
	SHORT   iMinute;        /** Time : MM**/
	SHORT   iSecond;        /** Time : SS**/
	SHORT   iMilliSecond;   /** Time : sss**/
	SHORT   iReserved4;
	SHORT   iReserved5;
	SHORT   iNoOfRecords;
	struct  SUB_OPEN_CLOSE_PRICE_BROADCAST  opencloseprice[80];
};
#pragma pack()

#pragma pack(4)
struct  OMB_SESSION_CHANGE_BROADCAST
{
	struct  OMB_HEADER     OmbHeader;
	LONG32  MsgType;
	LONG32  iReserved1;
	LONG32  iReserved2;
	USHORT  iReserved3;
	SHORT   iHour;  /** Time : HH**/
	SHORT   iMinute;        /** Time : MM**/
	SHORT   iSecond;        /** Time : SS**/
	SHORT   iMilliSecond;   /** Time : sss**/
	SHORT   iReserved4;
	SHORT   iReserved5;
	SHORT   iSegment;
	SHORT   iMktType;
	SHORT   iCurSession;
	LONG32  iReserved7;
	CHAR    cStartEndSess; /** S- Start of Session , E- End of Session**/
	CHAR    cReserved8;
	CHAR    sReserved9[2];
};
#pragma pack()

#pragma pack(4)
struct  BEST_RATE_DETAIL
{
	LONG32  iBestBuyRate;
	LONG32  iBestBuyQty;
	LONG32  iNoOfBuyOrders;
	LONG32  iReserved1;
	LONG32  iBestSellRate;
	LONG32  iBestSellQty;
	LONG32  iNoOfSellOrders;
	LONG32  iReserved2;
};
#pragma pack()

#pragma pack(4)
struct  SUB_MKT_PIC_DETAIL_BROADCAST
{
	LONG32  iScripCode;
	LONG32  iOpenRate;
	LONG32  iPevCloseRate;
	LONG32  iHighRate;
	LONG32  iLowRate;
	LONG32  iNoOfTrades;
	LONG32  iVolume;
	LONG32  iValue;
	LONG32  iLastTradeQty;
	LONG32  iLastTradeRate;
	LONG32  iCloseRate;
	LONG32  iReserved;
	LONG32  iIEP;   /***Indicative Equilibrium Price **/
	LONG32  iEQ;   /***Indicative Equilibrium Qty **/
	long long  iTimeStamp;
	LONG32  iTotBuyQty;
	LONG32  iTotSellQty;
	CHAR    cTradeValueFlag;
	CHAR    cTrend;
	CHAR    cSunFlag;
	CHAR    cReserved1;
	/***    CHAR    AllnoneFlag;*****/
	LONG32  iLowerCktLimit;
	LONG32  iUpperCktLimit;
	LONG32  iWeightedAverage;
	SHORT   iMktType;
	SHORT   iSession;
	CHAR    cHour;
	CHAR    cMinute;
	CHAR    cSecond;
	CHAR    sMilliSecond[3];
	CHAR    sReseverd2[2];
	SHORT   iReserved3;
	SHORT   iNoOfPricePoints;
	struct  BEST_RATE_DETAIL        MktBest [5];
};
#pragma pack()

#pragma pack(4)
struct  OMB_MKT_PIC_DETAIL_BROADCAST
{
	struct  OMB_HEADER      OmbHeader;
	LONG32   iMsgType;
	LONG32  iReserved1;
	LONG32  iReserved2;
	USHORT  iReserved3;
	SHORT   iHour;  /** Time : HH**/
	SHORT   iMinute;        /** Time : MM**/
	SHORT   iSecond;        /** Time : SS**/
	SHORT   iMilliSecond;   /** Time : sss**/
	SHORT   iReserved4;
	SHORT   iReserved5;
	SHORT   iNoOfRecords;
	struct  SUB_MKT_PIC_DETAIL_BROADCAST    mktpicture[6];
};
#pragma pack()

#pragma pack(4)
struct  OMB_POST_CLOSING_INDEX_BROADCAST
{
	struct  OMB_HEADER      OmbHeader;
	LONG32  iMsgType;
	SHORT   iSequenceNo;
	SHORT   iFiller;
	LONG32  iIndexValues;
};
#pragma pack()

#pragma pack(4)
struct SUB_OMB_NEW_SENSEX_BCAST
{
	LONG32  iIndexCode;
	LONG32  iIndexHigh;
	LONG32  iIndexLow;
	LONG32  iIndexOpen;
	LONG32  iIndexClose;
	LONG32  iIndexValue;
	CHAR    sIndexID[7];
	CHAR    cFiller;
	CHAR    cFiller1;
	CHAR    cFiller2;
	CHAR    cFiller3[2];
	SHORT   iFiller4;
	SHORT   iFiller5;
};
#pragma pack()


#pragma pack(4)
struct OMB_NEW_SENSEX_BCAST
{
	struct  OMB_HEADER  OmbHeader;
	LONG32  iMsgType;
	LONG32  iReserved1;
	LONG32  iReserved2;
	USHORT  iReserved3;
	SHORT   iHour;  /** Time : HH**/
	SHORT   iMinute;        /** Time : MM**/
	SHORT   iSecond;        /** Time : SS**/
	SHORT   iMilliSecond;   /** Time : sss**/
	SHORT   iReserved4;
	INT16   iTradingSession;
	INT16   iNoOfRec;
	struct SUB_OMB_NEW_SENSEX_BCAST subBcastDetails[24];
};
#pragma pack()

#pragma pack(2)
struct SUB_TOUCHLINE_INFORMATION
{
	LONG32                  iScripCode;
	LONG32                  iBuyRate;
	LONG32                  iBuyQty;
	CHAR                    cTrend;
	CHAR                    cSunOrderFlag;
	CHAR                    cAllOrNoneOrderFlag;
	CHAR                    cFiller;
	LONG32                  iSellRate;
	LONG32                  iSellQty;
	LONG32                  iLTRate;
	LONG32                  iLTQty;
	LONG32                  iHighRate;
	LONG32                  iLowRate;
	LONG32                  iCumTradedVol;
};
#pragma pack( )


#pragma pack(2)
struct OMB_TOUCHLINE_INFORMATION
{
	struct OMB_HEADER       OmbHeader;
	LONG32                  iMsgType;
	SHORT                   iSeqNo;
	SHORT                   iTradingSession;
	LONG32                  iCurIndexVal;
	SHORT                   iNoOfRecords;
	SHORT                   Filler;
	struct SUB_TOUCHLINE_INFORMATION        touchlineinfo[21];
};
#pragma pack()


#pragma pack(4)
struct  OMB_AUC_SESSION_CHANGE_BROADCAST
{
        struct  OMB_HEADER     OmbHeader;
        LONG32  MsgType;
        LONG32  iReserved1;
        LONG32  iReserved2;
        USHORT  iReserved3;
        SHORT   iHour;  /** Time : HH**/
        SHORT   iMinute;        /** Time : MM**/
        SHORT   iSecond;        /** Time : SS**/
        SHORT   iMilliSecond;   /** Time : sss**/
        SHORT   iReserved4;
        SHORT   iReserved5;
        SHORT   iReserved6;
        SHORT   iReserved7;
        SHORT   iCurSession;
        LONG32  iReserved9;
        CHAR    cReserved8;
        CHAR    cReserved9;
        CHAR    sReserved10[2];
	
};
#pragma pack()



typedef struct OMB_NEW_SENSEX_BCAST     OMB_NEW_INDICES_DETAIL_BROADCAST  ;


#endif
