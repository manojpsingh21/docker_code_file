#ifndef __EQUNSESTRUCTS_MFSS__
#define __EQUNSESTRUCTS_MFSS__


#pragma pack(2)
struct TAP_WRAPPER
{
	SHORT   iMsgLen;
	LONG32  iSeqNo;
	unsigned char sDigest[DIGEST_LEN];
};
#pragma pack()


#pragma pack(2)
struct	MFSS_HEADER
{
	CHAR	sReserved[2];
	LONG32	iLogTime;
	CHAR	sAlphaChar[ALPHA_SPLIT_LEN];
	INT16	iMsgCode;
	INT16	iErrorCode;
	CHAR	sTimeStamp1[NNF_DATE_TIME_LEN];
	CHAR	sTimeStamp2[NNF_DATE_TIME_LEN];
	CHAR	sTimeStamp3[NNF_DATE_TIME_LEN];
	INT16	iMsgLength;
};
#pragma pack()

#pragma pack(2)
struct  SECURITY_INFO
{
	CHAR	sSymbol	[SYMBOL_LEN];
	CHAR	sSeries	[SERIES_LEN];
};
#pragma pack()

#pragma pack(2)
struct  ORDER_FLAG 
{
	CHAR	cReseverd ;
	USHORT	iReseverd1 : 5;
	USHORT	iModified  : 1;	
	USHORT	iReseverd2 : 2;
};
#pragma pack()


#pragma pack(2)
struct  BROKER_ELIGILITY_MKT
{
#ifdef	BIGENDIAN
	USHORT	iReserve1 : 4;
	USHORT	iReserve2 : 1;
	USHORT	iSPOTMkt  : 1;
	USHORT	iReserve3 : 1;
	USHORT	iReserve4 : 1;
	USHORT	iReserve5 : 8;
#elif	LITTLEENDIAN
	USHORT  iReserve1 : 1;
	USHORT  iReserve2 : 1;
	USHORT  iSPOTMkt  : 1;
	USHORT  iReserve3 : 1;
	USHORT  iReserve4 : 4;
	USHORT  iReserve5 : 8;

#endif
};	
#pragma pack()

#pragma pack(2)
struct INVITATION_PACKET
{
	struct          TAP_WRAPPER tWrapper  ; /********** ANKIT ADDED FOR TAP ***********/
	struct          MFSS_HEADER  pHeader   ;
	SHORT           iInvitation_count     ;
};
#pragma pack()


#pragma pack(2)
struct	MFSS_SIGNON_REQ
{
	struct  	MFSS_HEADER pHeader			;
	INT16		iExchUserID				;
	CHAR		sPassword	[NSE_PASSWORD_LEN]	;	
	CHAR		sNewPassword	[NSE_PASSWORD_LEN]	;	
	CHAR		sTraderName	[TRADER_NAME_LEN]	;
	LONG32		iPasswdChngDate				;
	CHAR		sBrokerID	[BROKER_CODE_LENGTH]	;
	CHAR		cReserve1				;
	INT16		iBranchID				;
	LONG32		iVersionNum				;
	LONG32		iBatch2StartTime			;
	CHAR		cHostSwitchContxt			;
	CHAR		sColor		[COLOR_LEN]		;					
	CHAR		cReserve2				;
	INT16		iExchUserType				;
	DOUBLE64	fSequenceNum				;	
	CHAR		sWorkStatName	[WORK_STATION_ADDR_LEN]	;
	CHAR		cBrokerStatus				;
	CHAR		cReserve3				;
	struct		BROKER_ELIGILITY_MKT	pBrkElgMk	;

};
#pragma pack()


#pragma pack(2)
struct	MFSS_SIGNON_RESP
{
	struct          MFSS_HEADER pHeader                     ;
	INT16		iExchUserID				;
	CHAR            sPassword       [NSE_PASSWORD_LEN]      ;
	CHAR            sNewPassword    [NSE_PASSWORD_LEN]      ;
	CHAR            sTraderName     [TRADER_NAME_LEN]       ;
	LONG32          iPasswdChngDate                         ;
	CHAR            sBrokerID       [BROKER_CODE_LEN]       ;
	CHAR            cReserve1                               ;
	INT16           iBranchID                               ;
	LONG32          iVersionNum                             ;
	LONG32		iEndTime				;
	CHAR		sReserved2	[52]			;
	INT16		iUserType				;
	DOUBLE64        fSequenceNum                            ;
	CHAR		sReserve3	[14]			;
	CHAR		cBrokerStat				;
	CHAR		cReserved4				;
	struct          BROKER_ELIGILITY_MKT    pBrkElgMk       ;		

};
#pragma pack()


#pragma pack(2)
struct  MFSS_SYS_INFO_REQ
{
	struct          MFSS_HEADER	pHeader			;
};
#pragma pack()


#pragma pack(2)
struct  STOCK_ELIGILITY_IND
{
#ifdef  BIGENDIAN	
	USHORT	iReserved1	: 5	;	
	USHORT	iReserved2	: 1	;	
	USHORT	iReserved3	: 1	;	
	USHORT	iReserved4	: 1	;	
	USHORT	iReserved5	: 8	;	
#elif   LITTLEENDIAN
	USHORT	iReserved1	: 1	;	
	USHORT	iReserved2	: 1	;	
	USHORT	iReserved3	: 1	;	
	USHORT	iReserved4	: 5	;	
	USHORT	iReserved5	: 8	;	

#endif
};
#pragma pack()

#pragma pack(2)
struct  MFSS_MKT_STAT
{
	INT16	iReserved1		;
	INT16	iReserved2		;
	INT16	iSpotMkt		;
	INT16	iReserved3		;

};
#pragma pack()


#pragma pack(2)
struct	MFSS_SYS_INFO_RESP
{
	struct		MFSS_HEADER	pHeader			;
	struct		MFSS_MKT_STAT	pMktStat		;
	LONG32		iReserved1				;
	INT16		iReserved2				;	
	INT16		iReserved3				;	
	INT16		iReserved4				;	
	INT16		iReserved5				;	
	INT16		iReserved6				;	
	INT16		iReserved7				;	
	INT16		iReserved8				;	
	INT16		iReserved9				;	
	INT16		iTerminalIdleID				;
	LONG32		iReserved10				;
	LONG32		iReserved12				;
	INT16		iReserved13				;	
	struct		STOCK_ELIGILITY_IND	pStkInd		;
	INT16		iReserved14				;	
	INT16		iInqTimer				;

};
#pragma pack()


#pragma pack(2)
struct	MFSS_UPD_LDB_REQ
{
	struct          MFSS_HEADER     pHeader                 ;
	LONG32		iLastUpdSecTime				;
	LONG32		iLastUpdCatTime				;
	LONG32		iLastUpdSIPTime				;
	CHAR		cReserved1				;
	CHAR		cReserved2				;
	struct          MFSS_MKT_STAT   pMktStat                ;
	CHAR		sReserved3	[10]			;
	CHAR		sReserved4	[2]			;
	CHAR		sReserved5	[12]			;
	DOUBLE64	fReserved6				;
	LONG32		iReserved5				;
	INT16		iReserved6				;


};
#pragma pack()



#pragma pack(2)
struct	MFSS_UPD_LDB_HDR_RESP	
{
	struct          MFSS_HEADER     pHeader                 ;	

};
#pragma pack()

#pragma pack()
struct 	MFSS_MSG_DOWNLOAD_REQ
{
	struct		MFSS_HEADER	pHeader			;
	DOUBLE64	fExchSeqNum				;
}; 
#pragma pack()

#pragma pack(2)
struct MFSS_DOUBLE_INT
{
	unsigned  int   iLogTime1;
	unsigned  int   iLogTime2;
};
#pragma pack()


#pragma pack(2)
struct  CLIENT_INFO
{
	CHAR	sModeOfHolding[MODE_HOLD_LEN];
	CHAR	sClientCode[NUM_CLIENT_CODE_LEN][CLI_CODE_LEN];
	CHAR	sClientName1[CLI_NAME1_LEN];
	CHAR	sClientName2[CLI_NAME2_LEN];
	CHAR	sClientName3[CLI_NAME3_LEN];
	CHAR	sPANNumber[NUM_OF_PAN_LEN][PAN_CARD_LEN];
	CHAR	sKYCComplaint[KYC_COMPL_LEN];
	INT16	iOccupation;
	INT16	iTaxStatus;
	CHAR	sAddressLine[NUM_OF_ADDR_LEN][ADDRS_LEN];
	CHAR	sCity[CITY_LEN];
	CHAR	sState[STATE_LEN];
	CHAR	cGender;
	LONG32	iPINCode;
	CHAR	sPhoneOffice[PHONE_OFC_LEN];
	CHAR	sPhoneResidnc[PHONE_RES_LEN];
	CHAR	sMobNumber[MOBILE_NUM_LEN];
	CHAR	sEmailAddrs[EMAIL_ADDR_LEN];
	CHAR	sBankName[BANK_NAME_LEN];
	CHAR	sBankBranch[BANK_BRANCH_LEN];
	CHAR	sBankCity[BANK_CITY_LEN];
	CHAR	sAccNumber[ACC_NUM_LEN];
	CHAR	sEchoBack[ECHO_BACK_LEN];
	CHAR	sNEFTCode[NEFT_CODE_LEN];
	CHAR	sBankAccType[BANK_ACC_TYPE_LEN];
	CHAR	cStmtCommMode;
	CHAR	sReserved[5];
	INT16	iPayOutMech;
	CHAR	sDateOfBirth[DOB_LEN];
	CHAR	sGuardianName[GUARD_NAME_LEN];
	CHAR	sGuardianPanNo[GUARD_PAN_NUM_LEN];
	CHAR	sNomineeName[NOMIEE_NAME_LEN];
	CHAR	sNomineeRel[NOMIEE_REL_LEN];
	CHAR	sReserved1[7];


};
#pragma pack()



#pragma pack(2)
struct 	MFSS_ORD_ENTRY
{
	struct	MFSS_HEADER	pHeader;
	CHAR		cModCxlBy;
	CHAR		cSIPTranIndicator;
	INT16		iReasonCode;
	CHAR		sStartAlpha[ALPHA_SPLIT_LEN];
	CHAR		sEndAlpha[ALPHA_SPLIT_LEN];
	INT16		iSIPFrequency;	
	INT16		iSIPPeriod;
	INT16		iSIPMonth;
	INT16		iSIPDayDate;
	struct	SECURITY_INFO	pSecInfo;
	CHAR		cReserved1	;
	CHAR		sCategoryCode[CATEGORY_CODE_LEN];
	CHAR		sAMCCode[AMC_CODE_LEN];	
	CHAR		sAMCSchemeCode[AMC_SCHEME_LEN];	
	CHAR		sRTAgentCode[RTA_CODE_LEN];	
	CHAR		sRTSchemeCode[RTA_SCHEME_LEN];	
	DOUBLE64	fOrderNumber;
	CHAR		sApplNumber[APPL_NUM_LEN];
	INT16		iBookType;
	INT16		iBuySell;
	INT16		iPurchaseType;
	DOUBLE64	fAmount;
	DOUBLE64	fQuantity;
	CHAR		cTotalRedem;
	CHAR		cDividendMech;
	LONG32		iEntryDateTime;
	LONG32		iLastModTime;
	struct	ORDER_FLAG	pOrdFlg;		
	CHAR		cDepoSettle;
	CHAR		sDeposID[DEPOSIT_ID_LEN];
	CHAR		sDeposCliId[DEPOSIT_CLIENT_LEN];
	CHAR		sDeposCode[DEPOSIT_CODE];	
	CHAR		sFolioNumber[FOLIO_NUM_LEN];
	struct	CLIENT_INFO	pCliInfo;	
	DOUBLE64	fNNFUserInfo;
	INT16		iBranchID;
	INT16		iTraderID;
	CHAR		sBrokerID[BROKER_CODE_LENGTH];
	CHAR		sSubBrokerID[SUB_BROKER_LEN];
	CHAR		sSIPRegNum[SIP_REG_NEM_LEN];
	CHAR		cSIPFlag;
	LONG32		iSIPTrancheNum;
	CHAR		sEUIN[EUIN_LEN];		
	CHAR		cSIPGenOrder;
	CHAR		sReserver2[13];		

};
#pragma pack()



#pragma pack(2)
struct Download_Data
{
	LONG32  iStream_Id ;
	LONG32  iStream_Flag ; /**** Flag 1 for ON , 0 for OFF ********/
	ULONG32 iTimeStamp1;
	ULONG32 iTimeStamp2;
}Msg_Dow_Data[MAX_NO_STREAMS] ;
#pragma pack()

#pragma pack(2)
struct  MFSS_UPDATE_LDB_DATA_RESP
{
	struct          MFSS_HEADER pHeader               ;
	struct          MFSS_HEADER pInnerHeader          ;
	CHAR            sData [MFSS_LDB_UPDATE_PACKET_LEN];
};
#pragma pack()

#pragma pack(2)
struct  MFSS_MSG_DOWNLOAD_DATA_RESP
{
	struct          MFSS_HEADER pHeader                ;
	struct          MFSS_HEADER pInnerHeader           ;
	CHAR            sData [MFSS_MSG_AREA_DLD_DATA_LEN]  ;
};
#pragma pack()




#endif

