#ifndef _DWS_COMMON_H__
#define _DWS_COMMON_H__

struct USER_SOCKET_LOOKUP
{
	CHAR User[USER_ID_LEN]  ;
	CHAR ClientId[CLIENT_ID_LEN]  ;
	LONG32   Socket    ;
	pthread_mutex_t UserSocketLock ;
};

struct PROCESS_LOOKUP
{
	LONG32    RelayId;
	LONG32    ProcessId;
	LONG32    RelayPort;
	LONG32    NoOfUsers;
};

/*#pragma pack(4)
  struct VIEW_COMMON_QUERY_REQ
  {
  struct  INT_COMMON_REQUEST_HDR ReqHeader;
  CHAR    sClientId[CLIENT_ID_LEN];
  CHAR    sEntityId[ENTITY_ID_LEN];
  };
#pragma pack()
 */

#pragma pack(4)
struct VIEW_ADMIN_ORDER_BOOK_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sInstrument[SYMBOL_LEN];
	CHAR    sSymbol[SECURITY_ID_LEN];
	CHAR    sStatus[SYMBOL_LEN];
	CHAR    sExpiry[DATE_TIME_LEN];
	CHAR    sOptions[SYMBOL_LEN];
	CHAR    cProduct;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR	sPlacedBy[ENTITY_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN];
	LONG32	iEndRow;
};
#pragma pack()

#pragma pack(4)
struct	VIEW_CLIENT_LIMIT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR	sAccount[CLIENT_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR	sEntityId[ENTITY_ID_LEN];
	LONG32	iDebitBalanceFlag;
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_CLIENT_LIMIT
{
	DOUBLE64        fLimitSOD;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fReceivables;
	DOUBLE64        fBankHoldings;
	DOUBLE64        fCollaterals;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fSumofAll;
	DOUBLE64        fAvailableBal;
	DOUBLE64        fClearBalance;
	CHAR            sLimitType[PRODUCT_LEN];
	CHAR    	sClientId[ENTITY_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_ADMIN_CLIENT_LIMIT_RESP
{
	struct	INT_COMMON_RESP_HDR     IntRespHeader       ;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	//	CHAR    sClientId[ENTITY_ID_LEN];
	struct  SUB_VIEW_CLIENT_LIMIT   sSubViewClientlimit[5];
};
#pragma pack()

#pragma pack(4)
struct  EDIT_CLIENT_LIMIT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    	sEntityId[ENTITY_ID_LEN];
	CHAR    	sClientId[CLIENT_ID_LEN];
	CHAR    	sLimitType[PRODUCT_LEN];
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fBankHoldings;
};
#pragma pack()


/***** 
#pragma pack(4)
struct SUB_VIEW_NET_POSITION
{
CHAR            sSecurityID[SECURITY_ID_LEN];
CHAR            sExchId[EXCHANGE_LEN];
DOUBLE64        fBuyQty;
DOUBLE64        fBuyVal;
DOUBLE64        fSellQty;
DOUBLE64        fSellVal;
DOUBLE64        fBuyAvg;
DOUBLE64        fSellAvg;
DOUBLE64        fNetQty;
DOUBLE64        fNetVal;
DOUBLE64        fNetAvg;
DOUBLE64        fGrossQty;
DOUBLE64        fGrossVal;
CHAR            cMktType[MARKET_LEN];
CHAR            cProductId;
DOUBLE64        fLTP;
DOUBLE64        fRelaisedProfit;
DOUBLE64        fMTM;
CHAR            sClientId[CLIENT_ID_LEN];
CHAR            cSegment;
};
#pragma pack()
 **********/

#pragma pack(4)
struct SUB_VIEW_ADMIN_NET_POSITION
{
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchId[EXCHANGE_LEN];
	LONG32          iBuyQty;
	LONG32          iBuyQtyCF;
	LONG32          iBuyQtyDay;
	DOUBLE64        fBuyVal;
	DOUBLE64        fBuyValCF;
	DOUBLE64        fBuyValDay;
	DOUBLE64        fBuyAvg;
	LONG32          iSellQty;
	LONG32          iSellQtyCF;
	LONG32          iSellQtyDay;
	DOUBLE64        fSellVal;
	DOUBLE64        fSellValCF;
	DOUBLE64        fSellValDay;
	DOUBLE64        fSellAvg;
	LONG32          iNetQty;
	DOUBLE64        fNetVal;
	DOUBLE64        fNetAvg;
	DOUBLE64        fGrossQty;
	DOUBLE64        fGrossVal;
	CHAR            cMktType[MARKET_LEN];
	CHAR            cProductId;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fMTM;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	LONG32          iRef_ID;
};
#pragma pack()

#pragma pack(4)
struct VIEW_ADMIN_NET_POSITION_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_ADMIN_NET_POSITION subnetpos[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_ORDER_BOOK
{
	DOUBLE64        fOrderNo                                        ;
	LONG32          iSerialNo                                       ;
	CHAR            sBuySellInd[BUY_SELL_LEN]                       ;
	CHAR            sSecurityID[SECURITY_ID_LEN]                    ;
	CHAR            sOrderType[ORD_TYP_LEN]                         ;
	DOUBLE64        fQty                                            ;
	DOUBLE64        fRemQty                                         ;
	DOUBLE64        fDQQty                                          ;
	DOUBLE64        fDQQtyRem                                       ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTrgPrice                                       ;
	DOUBLE64        fTradeQty                                       ;
	CHAR            sProduct[PRODUCT_LEN]                           ;
	CHAR            sValidity[VALIDITY_LEN]                         ;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN]         ;
	CHAR            sDatetime[DATE_LENGTH]                          ;
	LONG32          iTranscode                                      ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            cSegment                                        ;
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	LONG32          iDateTime                                       ;
	/*----------------Latest Changes-----------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]    ;
	CHAR            cProClient                                      ;
	DOUBLE64                fTrdPrice                                       ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16		iLegValue	;

};
#pragma pack()

#pragma pack(4)
struct VIEW_ORDER_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_ORDER_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_ORDER_BOOK_DETAIL_RESP
{
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	LONG32          iTranscode;
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sFlags[10];  /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli,7-SourceFlag*/
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradePrice;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	CHAR            sProduct;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_STRING_LENGTH];
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sBuySellInd[5];
	CHAR            sOrdReasonDesc[200];

	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            cProClient                                      ;
	// LONG32          fTrdPrice                                       ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	INT16		iLegValue	;
};
#pragma pack()

#pragma pack(4)
struct VIEW_ORDER_BOOK_DETAIL_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_ORDER_BOOK_DETAIL_RESP suborderbookdtls[5];
};
#pragma pack()

#pragma	pack(4)
struct	VIEW_TRADE_BOOK_REQ
{
	struct	INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sSymbol[SECURITY_ID_LEN];	
	CHAR	cProduct;
	CHAR	sClientId[CLIENT_ID_LEN];
	CHAR	sPlacedBy[ENTITY_ID_LEN];
	CHAR	sEntityId[ENTITY_ID_LEN];
	LONG32	iEndRow;	
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_TRADE_BOOK
{
	DOUBLE64        fOrderNo;
	CHAR            sBuySellInd[BUY_SELL_LEN];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sOrderType[ORD_TYP_LEN];
	CHAR            sProduct[PRODUCT_LEN];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];
	LONG32          iDateTime;
	/*------------LAYESY CHANGES-------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16		iLegValue	;

};
#pragma pack()

#pragma pack(4)
struct VIEW_TRADE_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_TRADE_BOOK subTradeBook[5];
};
#pragma pack()

#pragma pack(4)
struct	VIEW_CLIENT_HOLD_REQ
{
	struct	INT_COMMON_REQUEST_HDR	ReqHeader;
	CHAR	sSecuritySource[SECURITY_SOURCE_LEN];
	CHAR    sSymbol[SECURITY_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];	
	CHAR	sEntityId[ENTITY_ID_LEN];
};
#pragma pack

#pragma pack(4)
struct SUB_VIEW_ADMIN_CLIENT_HOLDINGS
{
	//        CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR		sNseSecurityID[SECURITY_ID_LEN];
	CHAR		sBseSecurityID[SECURITY_ID_LEN];
	CHAR            sISINCode[ISINCODE_LEN];
	CHAR            sSecuritySource[SEC_SOURCE_LEN];
	LONG32          iQty;
	LONG32          iQtyUtilized;
	LONG32          iRemQty;
	CHAR            sExcgId[EXCHANGE_LEN];
	CHAR		sNseSymbol[SECURITY_SYM_LEN];
	CHAR		sBseSymbol[SECURITY_SYM_LEN];
	CHAR    	sClientId[CLIENT_ID_LEN];
	DOUBLE64	fLtp;
	DOUBLE64	fMarketValue;
	//        CHAR            sSymbol[SECURITY_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP
{
	struct 	INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct	SUB_VIEW_ADMIN_CLIENT_HOLDINGS subClientHoldings[5];
};
#pragma pack()


/*#pragma pack(4)
  struct VIEW_NET_POSITION_DATA_DETAIL
  {
  struct VIEW_COMMON_QUERY_REQ commonquery;
  CHAR    sSecurityID[SECURITY_ID_LEN];
  CHAR    cProductID;
  };

#pragma pack()
 */

#pragma pack(4)
struct VIEW_NET_POSITION_QRY
{
	struct 	INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR	sPosition[12];
	CHAR	sInstrument[10];
	CHAR	sSymbol[SECURITY_ID_LEN];
	CHAR 	cProduct;
	CHAR	sClientID[CLIENT_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN]; 
};
#pragma pack()

#pragma pack(4)
struct DWS_DNLD_SYS_MESGS_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR            cMsgType;
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sGenralMsg[SYSTEM_MSG_LEN];
	LONG32          iMsgCode;

};
#pragma pack()

#pragma pack(4)
struct	VIEW_REJECTED_ORDERS_REQ
{
	struct	INT_COMMON_REQUEST_HDR	ReqHeader;
	CHAR    sSymbol[SECURITY_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN];
};
#pragma	pack()

#pragma pack(4)
struct SUB_VIEW_REJECTED_ORDERS
{
	DOUBLE64        fOrderNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sOrderType[8];
	CHAR            sProduct[10];
	LONG32          iQty;
	DOUBLE64        fOrdPrice;
	LONG32          iInSuffQty;
	DOUBLE64        fInSuffAmt;
	DOUBLE64        fAmtBlocked;
	CHAR            sRmsStatus[10];
	CHAR            cMktOrder;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];

};
#pragma pack()

#pragma pack(4)
struct VIEW_REJECTED_ORDERS_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_REJECTED_ORDERS subRejOrdBook[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_DWS_ORD_REQ_SPREAD_2L_3L
{
	CHAR            sSecurityId[SECURITY_ID_LEN]      ;
	CHAR            cBuyOrSell                        ;
};
#pragma pack()

#pragma pack(4)
struct DWS_SPREAD_REQUEST
{
	struct          INT_COMMON_REQUEST_HDR              ReqHeader       ;
	CHAR            sEntityId[ENTITY_ID_LEN]                ;
	CHAR            sClientId[CLIENT_ID_LEN]                ;
	CHAR            cProductId                              ;
	SHORT           iOrderType                              ;
	CHAR            cProCli                                 ;
	DOUBLE64        fOrderNum                               ;
	LONG32          iTotalQtyRem                            ;
	LONG32          iTotalQty                               ;
	LONG32          iTotalTradedQty                         ;
	LONG32          iMinFillQty                             ;
	DOUBLE64        fPriceDiff                              ;
	SHORT           iOrderValidity                          ;
	INT16           iSerialNum                              ;
	CHAR            sRemarks[REMARKS_LEN]                   ;
	CHAR            sSettlor[SETTLOR_LEN]                   ;
	INT16           GoodTillDays                            ;
	CHAR            GoodTillDate[DATE_LEN]                  ;
	CHAR            cHandleInst                             ;
	LONG32          iNoOfLeg                                ;
	struct          SUB_DWS_ORD_REQ_SPREAD_2L_3L    sSprdLeg[LEG_LEN];
	CHAR            sCBrokerCode[BROKER_CODE_LEN]           ;
	DOUBLE64        fAlgoOrderNo                            ;
	SHORT           iStratergyId                            ;
	CHAR            cUserType                               ;
	LONG32          iMktType                                ;
	CHAR            cOffMarketFlg                           ;
};
#pragma pack()


#pragma pack(4)
struct DWS_SPREAD_RESPONSE
{
	struct          INT_COMMON_REQUEST_HDR      pRespHeader           ;
	CHAR            sEntityId       [ENTITY_ID_LEN]         ;
	CHAR            sClientId       [CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID    [EXCH_ORDER_NO_LEN]     ;
	CHAR            cProductId                              ;
	SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iLastTradedQty                                  ;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	struct          SUB_ORDER_REQUEST_SPREAD_2L_3L  sSpreadLeg[LEG_LEN];
	DOUBLE64        fOrderNum                                       ;
	SHORT           iSerialNum                                      ;
	CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]    ;
	DOUBLE64        fTradePrice                                     ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
};
#pragma pack()

#pragma pack(4)
struct  INT_DWS_LOGON_REQ
{
	struct          INT_COMMON_REQUEST_HDR	ReqHeader;
	CHAR            sLoginId[15];
	CHAR            sPassword[16];
	CHAR            sPanCard[20];
	CHAR            sMACAddr[15];
	LONG32          iFiller;
};



#pragma pack(4)
struct  INT_DWS_LOGON_RESP
{
	struct INT_COMMON_RESP_HDR      IntRespHeader;
	CHAR            sEntityId[12];
	CHAR            sName[60];
	CHAR            AccCode[12];
	CHAR            CurrDate[20];
	CHAR            ExpiryDate[20];
	CHAR            AllowedExch[10];        /** 1-NSE EQ,1-NSE DRV,1-BSE EQ,0-BSE DRV,0-NSE CUR,0-NCDEX,0-MCX ****/
	CHAR            cfprimaryip[16];
	CHAR            cffailoverip[16];
	CHAR            dsprimaryip[16];
	CHAR            failoverip[16];
	CHAR            TransPass[16];
	SHORT           Suscriptionlevel;
	/***    CHAR            srr_version[10];****/

};
#pragma pack()
#pragma pack(4)
struct SUB_ORDER_PROCESSOR_START
{
	LONG32    RelayId;
	LONG32    RelayPort;
};
#pragma pack()

#pragma pack(4)
struct  ORDER_PROCESSOR_START_RESP
{
	struct INT_COMMON_RESP_HDR      IntRespHeader;
	LONG32          NoOfProcess;
	struct SUB_ORDER_PROCESSOR_START        sSubOrdPrcRsp[MAX_NO_OF_PROCESS];
};
#pragma pack()

struct  MESG_STRUCT
{
	LONG32  Flag;
	CHAR    Mesg_Buf[RUPEE_MAX_PACKET_SIZE];
};
#pragma pack(4)

struct 	VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	DOUBLE64        fOrderNo;
	INT16		iLegNo;
};
#pragma pack()

#pragma pack(4)
struct 	VIEW_COMMON_HDR_RESP
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	/*      LONG32  iNoofPkt;*/
	CHAR    sClientId[CLIENT_ID_LEN];
};
#pragma pack()
#pragma pack(4)
struct 	SUB_CLIENT_CONVERT_TO_DELIVERY
{
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExcgId[EXCHANGE_LEN];
	CHAR            cProductSource;
	CHAR            cProductDest;
	CHAR            cSide;
	DOUBLE64        fConvertPrice;
	LONG32          iQty;
	CHAR            cSegment;
};
#pragma pack()

#pragma pack(4)
struct 	VIEW_CLIENT_CONVERT_TO_DELIVERY
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_CLIENT_CONVERT_TO_DELIVERY subCTOD[5];
};
#pragma pack()

#pragma pack(4)
struct 	SEND_MSG_TO_CLIENT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR            sSender[CLIENT_ID_LEN];
	LONG32          iReceiverUserId[25];
	LONG32          iNoOfRec;
	CHAR            sMsg[SEND_MSG_LEN];
};
#pragma pack()

#pragma pack(4)
struct 	SEND_MSG_TO_CLIENT_RESP
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR            sSender[CLIENT_ID_LEN];
	CHAR            sMsg[SEND_MSG_LEN];
};
#pragma pack()

#pragma pack(4)
struct 	SUB_DEALER_MAPP
{
	CHAR    sClientString[CLI_STRING_LEN]           ;
};
#pragma pack()

#pragma pack(4)
struct 	DEALER_MAPP_RESP
{
	struct  INT_COMMON_RESP_HDR IntRespHeader   ;
	CHAR    cMsgType                        ;
	LONG32  iNoofRec                        ;
	struct  SUB_DEALER_MAPP subdeamapp[5]   ;
};
#pragma pack()

#pragma pack(4)
struct 	SUB_VIEW_SPRD_ORD_BOOK
{
	DOUBLE64        fOrderNo                                        ;
	LONG32          iSerialNo                                       ;
	CHAR            sBuySellInd[5]                                  ;
	CHAR            sSecurityID[20]                    ;
	CHAR            sOrderType[8]                                   ;
	DOUBLE64        fQty                                            ;
	DOUBLE64        fRemQty                                         ;
	DOUBLE64        fDQQty                                          ;
	DOUBLE64        fDQQtyRem                                       ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTrgPrice                                       ;
	DOUBLE64        fTradeQty                                       ;
	CHAR            sProduct[10]                                    ;
	CHAR            sValidity[5]                                    ;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN]         ;
	CHAR            sDatetime[DATE_LENGTH]                          ;
	LONG32          iTranscode                                      ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            cSegment                                        ;
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	LONG32          iDateTime                                       ;
	/*----------------Latest Changes-----------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]    ;
	CHAR            cProClient                                      ;
	DOUBLE64        fTrdPrice                                       ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16           iLegValue       ;

};
#pragma pack()

#pragma pack(4)
struct 	VIEW_SPRD_ORD_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_SPRD_ORD_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct 	VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	LONG32  iMode;
	LONG32  iPercent;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sClientName[CLIENT_NAME_LEN];
	CHAR    cUserType;
	LONG32  iShortFallFlag;
	CHAR    sManager_Code [CLIENT_ID_LEN];
};
#pragma pack()

/*** #pragma pack(4)
  struct  SUB_VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP
  {
  CHAR            sClientId[CLIENT_ID_LEN];
  DOUBLE64        fTotalBal;
  DOUBLE64        fBankHodl;
  DOUBLE64        fAdhoc;
  DOUBLE64        fLimit_SOD;
  DOUBLE64        fMTMKT_EQ;
  DOUBLE64        fMTMKT_DR;
  DOUBLE64        fTotalMTM;
  DOUBLE64        fMTM_PER;
  DOUBLE64        fEXPO_EQ;
  DOUBLE64        fEXPO_EQ_GROSS;
  DOUBLE64        fEXPO_DR;
  DOUBLE64        fEXPO_DR_GROSS;
  DOUBLE64        fRealised_Profit;
  DOUBLE64        fSpan;
  DOUBLE64        fRealised_MTM;
  DOUBLE64        fShortfall_VAL;
  };
#pragma pack()
 *******/

#pragma pack(4)
struct  SUB_VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP
{
	CHAR            sClientId[CLIENT_ID_LEN];
	DOUBLE64        fSpan;
	DOUBLE64        fShortfall_VAL;
	DOUBLE64        fTotalMTM;
	DOUBLE64	fNet_option;
	DOUBLE64	fUtilized_cash;
	DOUBLE64	fFiller1;
	DOUBLE64	fFiller2;
	DOUBLE64	fFiller3;
	DOUBLE64	fFiller4;
	DOUBLE64	fFiller5;
	DOUBLE64	fFiller6;
	DOUBLE64	fFiller7;
	DOUBLE64	fFiller8;
	DOUBLE64	fFiller9;
	DOUBLE64	fFiller10;
	DOUBLE64	fFiller11;

};
#pragma pack()

#pragma pack(4)
struct  VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP
{
	struct  INT_COMMON_RESP_HDR     IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct  SUB_VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP   subViewMargin[5];
};
#pragma pack()

#pragma pack(4)
struct  SUB_VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP
{
	CHAR  sClientId[CLIENT_ID_LEN];
	DOUBLE64        fTotalBal;
	DOUBLE64        fBankHodl;
	DOUBLE64        fAdhoc;
	DOUBLE64        fLimit_SOD;
	DOUBLE64        fMTMKT_EQ;
	DOUBLE64        fMTMKT_DR;
	DOUBLE64        fTotalMTM;
	DOUBLE64        fMTM_PER;
	DOUBLE64        fEXPO_EQ;
	DOUBLE64        fEXPO_EQ_GROSS;
	DOUBLE64        fEXPO_DR;
	DOUBLE64        fEXPO_DR_GROSS;
	DOUBLE64        fRealised_Profit;
	DOUBLE64        fSpan;
	DOUBLE64        fRealised_MTM;
	DOUBLE64        fShortfall_VAL;
};
#pragma pack()

#pragma pack(4)
struct 	VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP
{
	struct INT_COMMON_RESP_HDR      IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP   subViewPercent[5];
};
#pragma pack()



#pragma pack(4)
struct	ADD_CLIENT_LIMIT_REQ
{
	struct	INT_COMMON_REQUEST_HDR	ReqHeader;
	CHAR	sEntityId[ENTITY_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sLimitType[PRODUCT_LEN];	
};
#pragma pack()

#pragma pack(4)
struct  ADMIN_VIEW_COMMON_HDR_RESP
{
	struct 	INT_COMMON_RESP_HDR IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR	sErrorMsg[ERROR_MESSAGE_LEN];
};
#pragma pack()

#pragma pack()
struct VIEW_CIRCUIT_LIMIT_REQ
{
	struct	INT_COMMON_REQUEST_HDR  ReqHeader;
	CHAR    sSymbol[SECURITY_ID_LEN];	
	CHAR    sInstrument[SYMBOL_LEN];
	CHAR    sOptions[SYMBOL_LEN];
};
#pragma pack()

#pragma pack(4)
struct ADMIN_IPO_SEC_DETAILS_RESP
{
	struct   INT_COMMON_REQUEST_HDR  ResHeader;
	CHAR		sCmpyId		[COMPANY_ID_LEN]	;
	CHAR		sCmpyName	[SYMBOL_LEN]		;
	CHAR		sSymbol		[DB_SYM_LEN]		;
	CHAR		sSymbolName	[DB_SYM_NAME_LEN]	;
	CHAR		sSeries		[DB_SERIES_LEN]		;
	LONG32		iIPOType	  			;
	LONG32		iIssueType	  			;
	DOUBLE64	fFaceValue	  			;
	DOUBLE64	fLowBand	  			;
	DOUBLE64	fHighBand	  			;
	LONG32		iMinBidlot	  			;
	LONG32		iQtyMul		  			;
	LONG32		iIpoSize	  			;
	CHAR		sStartDate	[DB_DATETIME_LEN]	;
	CHAR		sEndDate	[DB_DATETIME_LEN]	;
	CHAR		sFinalModDate	[DB_DATETIME_LEN]	;
	LONG32		iStatus		  			;
	CHAR		sCategory	[CATEGORY_CODE_LEN] 	;
	LONG32		iContctPrsn	  			;
	CHAR		sCompOffc 	[ADDRESS_LEN]		;
	CHAR		sStreet1	[ADDRESS_LEN]		;
	CHAR		sStreet2	[ADDRESS_LEN]		;
	CHAR		sState		[ADDRESS_LEN]		;
	CHAR		sCity		[ADDRESS_LEN]		;
	CHAR		sCountry	[ADDRESS_LEN]		;
	LONG32		iPin		  			;
	CHAR		sEmailId	[ADDRESS_LEN]		;
	LONG32		iMobile		  			;
	LONG32		iTelephone	  			;
	CHAR		sWebsite	[ADDRESS_LEN]		;
	CHAR		sIssueDate	[DB_DATETIME_LEN]	;				

};
#pragma pack()

static void init_routine (void);
void            InitUserSocketTable();
void            PrintLookup ( );
void            AssociateSocketSignal (LONG32 );
void            InitLookup ( );
LONG32          GetIndexForPacket ( CHAR * );
LONG32          SearchIndex ( LONG32 );
void            CleanSocketResour ( LONG32 );
LONG32          SendPacketToUser (LONG32 ,CHAR * );
LONG32          SendDloadPacketToUser (LONG32 ,CHAR * );
LONG32          SearchUserId ( LONG32 ,CHAR [][6], CHAR [],LONG32 * );
LONG32          SearchGlobalUserId ( LONG32 , CHAR [][6], CHAR [] );
void            SetUserId (LONG32 , CHAR *);
LONG32          SearchForFreeslot ( );
LONG32          OpenPassiveSocket ( );
void            GetPacketFromQueue ( CHAR * , LONG32 );
void            *SignalThread();
void            *ReadThread();
void            ReadWorkerThread(void *);
void            *WriteThread(LONG32 *);
void            WriteWorkerThread(struct  MESG_STRUCT *);
void            *ReadServerStartupThread(LONG32 );
LONG32        ProcessLogOnRequest(LONG32 *Index,CHAR *UserId);
void            WaitForMaxThreadCond(LONG32);
void            InitProcessTable();
void            *SignalHandler(LONG32 *RelayId,sigset_t SignalSet);
void            SignalHandlerSigio(LONG32 dummy);
void            SignalHandlerSigTerm(LONG32 );
void            SignalHandlerSigChldParent(LONG32 );
void            SignalReadThreadKillCond(LONG32);
LONG32  GetMaxSocket();
void WriteToRms(LONG32 id,CHAR * cpMsgBuf,LONG32 Size);
void LockThreadMutex ( pthread_mutex_t *, CHAR * );
void UnLockThreadMutex ( pthread_mutex_t * , CHAR *);
void ConnectToOracle ( ) ;
void ProcessArguments ( ) ;
void SqlErrorFun ( ) ;
void InitOracleRelayData ( );
void UpdateOracleRelayData ( LONG32 );
void UpdateOracleUserData (LONG32 ,LONG32  ,CHAR [][6], CHAR Segment [],char);
LONG32 WriteSearchExchSegment(CHAR [][6] , CHAR [6], CHAR [], CHAR );
void AddShmRelayData ( LONG32 ,CHAR [][6], CHAR [], struct sockaddr_in * , char);
void DeleteShmRelayData ( LONG32 ,CHAR [][6], CHAR [] );
void DeleteRelayUserShm ( LONG32 );
void WaitForMaxThreadCond ( );
void WaitForMaxThreadCondWrite ( );
LONG32 ProcessOrderProcessorStrtRequest();
void WaitForMaxDloadThreadCondWrite ( );
void SendMaxThreadCondSig ( );
void SendMaxThreadCondSigWrite ( );
void SendMaxDloadThreadCondSigWrite ( );
LONG32  CheckUserIdPassword ( LONG32 , CHAR * );
void UpdateForkProcess (LONG32 ,LONG32 ,LONG32 );
void UpdateForkProcessForRestart (LONG32 );
void DeleteRelayMaster ( );
void ProcessIncomePacket ( CHAR *,LONG32 , LONG32 );
void SendErrorResponce ( CHAR * , LONG32 );
void SendLogonResponce ( CHAR * , LONG32 );
LONG32  GetTimeStamp ( );
void RelayLogFatal (CHAR * );
void RelayLogMessage (CHAR * );
void Sleep (LONG32 );
void CheckPeerAddr ( struct sockaddr *,LONG32 );
void UpdatePeerAddr ( struct sockaddr *,LONG32 ,LONG32 );
void CleanUserResour ( );
void catch_alarm ( LONG32 );
void SendLogonErrorResponce (CHAR *,LONG32 );
void FindUserClient     ( LONG32 ,CHAR [][6], CHAR [] ,CHAR *);

#endif
