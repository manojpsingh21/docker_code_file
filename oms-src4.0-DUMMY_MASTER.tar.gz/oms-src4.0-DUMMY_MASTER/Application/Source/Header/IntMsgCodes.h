#define TC_INT_ORDER_PROCESSOR_STRT_REQ				-9500
#define TC_INT_ORDER_PROCESSOR_STRT_RESP			-9501

#define	TC_INT_LOGON_REQ					-1101
#define TC_INT_LOGON_RSP					-1201
#define TC_INT_LOGOFF_REQ					-1301

#define TC_INT_RECONNECT_REQ					-1102
#define TC_INT_RECONNECT_RESP					-1103

#define TC_INT_KEEP_ALIVE_REQ					-1401
#define TC_INT_KEEP_ALIVE_RESP					-1402

#define TC_INT_SPAN_CALC_REQ					-1501
#define TC_INT_SPAN_CALC_ERR_RESP				-1502
#define TC_INT_SPAN_CALC_RESP  		                        -1550
/*-----------------------------------------------------------------------
  QUERIES MSG CODES
  ------------------------------------------------------------------------*/
/*-----------------------------------Old Ones-------------------------


#define TC_INT_VIEW_CLIENT_LIMIT_REQ				-6001
#define TC_INT_VIEW_CLIENT_LIMIT_RESP				-6002

#define TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ			-6003
#define TC_INT_VIEW_CLIENT_DEALER_LIMIT_RESP			-6004

#define TC_INT_NET_POS_REQ					-6005
#define TC_INT_NET_POS_RESP					-6006

#define TC_INT_ORDER_BOOK_REQ					-6007 
#define TC_INT_ORDER_BOOK_HEADER_RESP				-6008	
#define TC_INT_ORDER_BOOK_RESP					-6009 

#define TC_INT_ORDER_BOOK_DTLS_REQ				-6010
#define TC_INT_ORDER_BOOK_DTLS_HEADER_RESP			-6011
#define TC_INT_ORDER_BOOK_DTLS_RESP				-6012

#define	TC_INT_TRADE_BOOK_REQ					-6014
#define TC_INT_TRADE_BOOK_HEADER_RESP				-6015
#define TC_INT_TRADE_BOOK_RESP					-6016

#define	TC_INT_CLINET_HOLDING_REQ				-6017
#define TC_INT_CLINET_HOLDING_HEADER_RESP			-6018
#define	TC_INT_CLINET_HOLDING_RESP				-6019

#define TC_INT_NETPOS_DTL_REQ					-6020
#define TC_INT_NETPOS_DTL_HEADER_RESP				-6021
#define TC_INT_NETPOS_DTL_RESP					-6022

#define TC_INT_CARRY_FWD_POS_REQ				-6023
#define TC_INT_CARRY_FWD_POS_HEADER_RESP			-6024
#define TC_INT_CARRY_FWD_POS_RESP				-6025

#define TC_INT_CONVT_TO_DELV_REQ				-6026
#define TC_INT_CONVT_TO_DELV_HEADER_RESP			-6027
#define TC_INT_CONVT_TO_DELV_RESP				-6028

#define TC_INT_CONVT_TO_DELV_REQ_1				-6029
#define TC_INT_CONVT_TO_DELV_HEADER_RESP_1			-6030
#define TC_INT_CONVT_TO_DELV_RESP_1				-6031

#define TC_INT_SEND_MSG_TO_CLIENT_REQ				-6032
#define TC_INT_SEND_MSG_TO_CLIENT_RESP				-6033

#define TC_INT_DNLD_SYSTEM_MSG_REQ				-6034---------
#define TC_INT_DNLD_SYSTEM_MSG_HDR_RESP				-6035
#define TC_INT_DNLD_SYSTEM_MSG_RESP				-6036	

#define TC_INT_CON_DEL_REQ					-6037
#define TC_INT_CON_DEL_RESP					-6038
-------------------------------------------------------*/
#define TC_INT_CONVT_TO_DELV_REQ				-5547
//#define TC_INT_CONVT_TO_DELV_REQ 				-2234
#define TC_INT_CON_DEL_REQ                                      -6037
#define TC_INT_CON_DEL_RESP                                     -6038
#define TC_INT_CON_DEL_ERR_RESP                                 -6039
#define TC_INT_CON_DEL_POS_RESP                                 -6700
#define TC_INT_CON_DEL_IP_POS_RESP                              -6709
#define TC_INT_RECONCILE_CF_POS                                 -6710
#define TC_INT_RECONCILE_CF_IP_POS                              -6711
#define TC_INT_RECONCILE_C2D_POS                                -6712
#define TC_INT_RECONCILE_C2D_IP_POS                             -6713

#define TC_INT_VIEW_CLIENT_LIMIT_REQ                            -6859
#define TC_INT_NET_POS_REQ                                      -6739

#define  TC_INT_ORDER_BOOK_REQ                                  -2286
#define  TC_INT_ORDER_BOOK_DTLS_REQ                             -2280
#define  TC_INT_BO_ORDER_BOOK_DTLS_REQ                          -3380
#define  TC_INT_SPRD_ORDER_BOOK_DTLS_REQ                        -2380

#define  TC_INT_ADMIN_BO_ORDER_BOOK_REQ				-2264

#define  TC_INT_TRADE_BOOK_REQ                                  -2283
#define  TC_INT_REJECTED_ORDERS_REQ                             -2290

#define  TC_INT_CLINET_HOLDING_REQ                              -2289
#define  TC_INT_NETPOS_DTL_REQ                                  -2293
#define  TC_INT_ADMIN_CKT_HITTING_HOLDING_REQ			-2390
#define  TC_INT_ADMIN_CKT_HITTING_NETPOS_REQ			-2391

#define TC_INT_CARRY_FWD_POS_REQ                                -2231

#define TC_INT_NET_POS_RESP                                     -6749

#define  TC_INT_ORDER_BOOK_HEADER_RESP                          -2287
#define  TC_INT_ORDER_BOOK_RESP                                 -2288

#define  TC_INT_TRADE_BOOK_HEADER_RESP                          -2284
#define  TC_INT_TRADE_BOOK_RESP                                 -2285

#define  TC_INT_ORDER_BOOK_DTLS_HEADER_RESP                     -2281
#define  TC_INT_ORDER_BOOK_DTLS_RESP                            -2282

#define  TC_INT_BO_ORDER_BOOK_DTLS_HEADER_RESP                    -3381
#define  TC_INT_BO_ORDER_BOOK_DTLS_RESP                           -3382


#define  TC_INT_CLINET_HOLDING_HEADER_RESP                      -2291
#define  TC_INT_CLINET_HOLDING_RESP                             -2292

#define  TC_INT_NETPOS_DTL_HEADER_RESP                          -2294
#define  TC_INT_NETPOS_DTL_RESP                                 -2295

#define  TC_INT_REJECTED_ORDERS_HEADER_RESP                     -2296
#define  TC_INT_REJECTED_ORDERS_RESP                            -2297

#define TC_INT_CONVT_TO_DELV_HEADER_RESP                        -2235
#define TC_INT_CONVT_TO_DELV_RESP                               -2236

#define TC_INT_CARRY_FWD_POS_HEADER_RESP                        -2232
#define TC_INT_CARRY_FWD_POS_RESP                               -2233

#define TC_INT_SEND_MSG_TO_CLIENT_RESP                          -5563

#define TC_INT_DNLD_SYSTEM_MSG_HDR_RESP                         -5565
#define TC_INT_DNLD_SYSTEM_MSG_RESP                             -5567

#define TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ                     -6861

#define TC_INT_SEND_MSG_TO_CLIENT_REQ                           -5562

#define TC_INT_DNLD_SYSTEM_MSG_REQ                              -5564

#define	TC_INT_EXCH_GEN_MSG_REQ					-6321
#define	TC_INT_EXCH_GEN_MSG_RESP				-6322

#define	TC_INT_VIEW_CLIENT_LIMIT_DET_REQ			-6862
#define	TC_INT_VIEW_CLIENT_LIMIT_DET_RES			-6863

#define TC_INT_VIEW_CLIENT_LIMIT_RESP				-6860

/*-----------------------------------------------------------------------
  ORDER RELATED MSG CODES
  ------------------------------------------------------------------------*/
#define	TC_INT_ORDER_ENTRY_REQ					2000
#define TC_INT_ORDER_ENTRY_RSP					-5502
#define TC_INT_BO_ORDER_ENTRY_RSP				-6602

#define TC_INT_ORDER_MODIFY					2040
#define TC_INT_ORDER_MODIFY_RSP					-5503

#define TC_INT_ORDER_CANCEL					2070
#define TC_INT_ORDER_CANCEL_RSP					-5504

#define TC_INT_ORDER_REJECTION					-1111
#define TC_INT_OE_REJECTION					1111
#define TC_INT_OM_REJECTION					1113
#define TC_INT_OC_REJECTION					1115

#define TC_INT_BO_OE_REJECTION                                     1119
#define TC_INT_BO_OM_REJECTION                                     1120
#define TC_INT_BO_OC_REJECTION                                     1121

#define TC_INT_RMS_ORD_REJECTION				-4444	

#define TC_INT_RMS_OE_REJECTION					4444	
#define TC_INT_RMS_OM_REJECTION					4445	
#define TC_INT_RMS_OC_REJECTION					4446	

#define TC_INT_BO_RMS_OE_REJECTION                               4450
#define TC_INT_BO_RMS_OM_REJECTION                               4451
#define TC_INT_BO_RMS_OC_REJECTION                               4452


#define TC_INT_OE_CONF_RESP					2073
#define TC_INT_OE_FREEZE_RESP					2170
#define TC_INT_OE_ERROR_RESP					2231

#define TC_BO_OE_CONF_RESP                                     3073
#define TC_BO_OE_FREEZE_RESP                                   3170
#define TC_BO_OE_ERROR_RESP                                    3231

#define TC_INT_OM_CONF_RESP					2074
#define TC_INT_OM_ERROR_RESP					2042

#define TC_BO_OM_CONF_RESP                                     3074
#define TC_BO_OM_ERROR_RESP                                    3042

#define TC_INT_OC_CONF_RESP					2075
#define TC_INT_OC_ERROR_RESP					2072

#define TC_BO_OC_CONF_RESP                                     3075
#define TC_BO_OC_ERROR_RESP                                    3072

#define TC_INT_MKT_LMT_CONVT_RESP				2012
#define TC_BO_MKT_LMT_CONVT_RESP				3012


#define TC_INT_SL_ORDER_TRIG_RESP				2212
#define TC_BO_SL_ORDER_TRIG_RESP				3212

#define TC_INT_TRADE_RESP					2222
#define TC_BO_TRADE_RESP					3333

#define TC_INT_BUSINESS_SESSION_REJ 				3001
#define TC_INT_FIX_TRADING_SESSION_RESP				3458
#define TC_INT_FIX_SECURITY_DNLD_RESP				3457
#define TC_INT_FIX_SECURITY_STAT                                3459

#define	TC_INT_SIP_ORD_REQ					3000
#define	TC_INT_SIP_ORD_RES					3020
#define	TC_INT_SIP_ORD_CANCEL					3050	
#define	TC_INT_SIP_ORD_CANCEL_RES				3052
#define	TC_INT_SIP_ORD_PAUSE_REQ				3030
#define	TC_INT_SIP_ORD_PAUSE_RES				3032
#define	TC_INT_SIP_ORD_CONTINUE_REQ				3040
#define TC_INT_SIP_ORD_CONTINUE_RES				3041
#define TC_INT_SIP_ORD_MODIFY_REQ                               3043
#define TC_INT_SIP_ORD_MODIFY_RES                               3045

#define	TC_INT_PUMPSIP_REQ					3060
#define	TC_INT_ADMIN_SIP_ORDER_BOOK_REQ				3022
#define TC_INT_ADMIN_SIP_ORDER_DETS_REQ				3024
#define	TC_INT_ADMIN_SIP_ORDER_TRALS_REQ			3026

#define TC_INT_SIP_ORDER_BOOK_REQ                         	3100
#define TC_INT_SIP_ORDER_DETS_REQ                         	3101
#define TC_INT_SIP_ORDER_TRALS_REQ                        	3102

#define TC_INT_ADMIN_TRADE_BOOK_REQ                             -6631
#define TC_INT_ADMIN_CONVT_TO_DELV_REQ                          -2237
#define TC_INT_NET_POS_HDR_RESP                                 -6740
#define TC_INT_ADMIN_TRADE_BOOK_HEADER_RESP                     -6632
#define TC_INT_ADMIN_TRADE_BOOK_RESP                            -6633
#define TC_INT_ADMIN_CONVT_TO_DELV_HEADER_RESP                  -2238
#define TC_INT_ADMIN_CONVT_TO_DELV_RESP                         -2239
#define TC_INT_SQUAREOFF_INTRADAY_REQ                           -2300

#define TC_INT_SQUAREOFF_COVER_ORD_REQ				-2301
#define TC_INT_SQUAREOFF_BRACKET_ORD_REQ			-2302
#define TC_INT_SQUAREOFF_INTRADAY_CROSS_CUR_REQ                 -2303
#define TC_INT_PUMPSIPORDER_REQ					-2304
#define	TC_INT_PUMPOFFLINE_REQ                                  -2230

#define	TC_INT_MTM_AUTO_SQR_OFF					2500

#define TC_INT_OFF_ORDER_ENTRY                         		5112
#define TC_INT_OFF_ORDER_MODIFY                        		5113
#define TC_INT_OFF_ORDER_CANCEL                        		5114
#define TC_INT_OFF_ORDER_ENTRY_RSP                     		5520
#define TC_INT_OFF_ORDER_MODIFY_RSP                    		5521
#define TC_INT_OFF_ORDER_CANCEL_RSP                    		5522

#define TC_INT_ADMIN_EXPIRY_REQ					-5549	
#define TC_INT_ADMIN_EXPIRY_RESP        			-5550
#define TC_INT_ADMIN_EXPIRY_ERR_RESP        			-5551
#define TC_CO_ADMIN_EXPIRY_REQ					-5552	

#define TC_INT_MTM_BREACH_RSP					7777

#define	TC_INT_ORDER_BASKET_REQ					-1010
#define	TC_INT_ORDER_BASKET_RESP				-1012
#define	TC_INT_ORDER_BASKET_ERR_RESP				-1011
#define	TC_INT_ORDER_BASKET_ADD_ERR_RESP			-1013
#define	TC_INT_ORDER_BASKET_EDIT_ERR_RESP			-1015
#define	TC_INT_ORDER_BASKET_DEL_ERR_RESP			-1017
#define	TC_INT_ORDER_BASKET_DETAIL_REQ				-1011
#define	TC_INT_ORDER_BASKET_NAME_REQ				-1019

/***********SPREAD ORDER TCODE *******************/
#define	TC_INT_SPREAD_OE_REQ					2100
#define	TC_INT_SPREAD_OM_REQ					2118	
#define	TC_INT_SPREAD_OC_REQ					2106	


#define	TC_INT_SPREAD_OE_CONF_RESP				2124	
#define	TC_INT_SPREAD_OM_CONF_RESP				2136	
#define	TC_INT_SPREAD_OC_CONF_RESP				2130	

#define	TC_INT_SPREAD_OE_ERR_RESP				2154	
#define	TC_INT_SPREAD_OM_ERR_RESP				2133	
#define	TC_INT_SPREAD_OC_ERR_RESP				2127	

#define TC_INT_GIVE_UP_CONF					4506				
#define TC_INT_GIVE_UP_ERR					4507

#define TC_INT_BATCH_CANCEL_REQ					9002
/***********SPREAD ORDER TCODE *******************/

#define	TC_INT_EXCH_NEWS					4000

#define	TC_INT_SET_ALGO_ORD_REQ					2200
#define	TC_INT_ALGO_ORD_RES					2700

#define	TC_INT_CAN_ALGO_ORD_REQ					2400
#define	TC_INT_CAN_ALGO_ORD_RES					2800

#define TC_NSE_INVITATION_REQ                               	15000
#define TC_NSE_SIGNON_REQ                             		2300

#define	TC_NSE_UPD_LDB_DOWNLD_REQ				7300
#define TC_NSE_SYS_INFO_REQ                           		1600

#define TC_NSE_SYS_INFO_RESP                          		1601

#define TC_NSE_PARTIAL_SYS_INFO_RESP                  		7321

#define TC_NSE_UPDATE_LDB_HEADER_RESP                 		7307

#define TC_NSE_UPDATE_LDB_DATA_RESP                   		7304

#define TC_NSE_UPDATE_LDB_TRAILER_RESP                		7308

#define TC_NSE_MSG_DOWNLOAD_START_RESP                		7011

#define TC_NSE_MSG_DOWNLOAD_DATA_RESP                 		7021

#define TC_NSE_MSG_DOWNLOAD_END_RESP                  		7031

#define TC_NSE_MSG_DOWNLOAD_REQ                       		7000

#define	TC_INT_NEG_ORD_CAN_RESP					2076					

#define	TC_INT_NEG_ORD_REG_LOT_RESP				2008
#define	TC_INT_NEG_ORD_ENT_CP_RESP				2009
/*-------------NNF MsgCodes-------------------------------------------*/
#define	 	TC_NSE_BATCH_ORDER_CANCEL_RESP				9002
/*	
#define 	TC_NSE_ORDER_PRICE_FREEZE_APPROVE_RESP              	3034

#define 	TC_NSE_ORDER_PRICE_FREEZE_REJECT_RESP               	3037

#define 	TC_NSE_ORDER_VOLUME_FREEZE_APPROVE_RESP             	3044

#define 	TC_NSE_ORDER_VOLUME_FREEZE_REJECT_RESP              	3047
 */

#define    	TC_NSE_NEG_ORDER_CANCELLED_RESP                     	2076

#define    	TC_NSE_NEG_ORDER_ENTERED_BY_CP_RESP 			2009

#define    	TC_NSE_NEG_ORDER_TO_REGULARLOT_RESP                 	2008

#define 	TRADE_MOD_CONFIRMATION                                  2287

#define    	TC_NSE_TRADE_MOD_REJECT_RESP        			2288

#define     	TRADE_CAN_REJECTION            				2286

#define    	TC_NSE_TRADE_CAN_REQUESTED_BY_CP_RESP               	5442

#define    	TC_NSE_TRADE_MOD_CAN_ERROR_RESP                     	2223

#define   	TC_NSE_TRADE_CAN_CONF_RESP                          	2282

#define    	TC_NSE_TRADE_MOD_REQ_ACK_RESP                       	5446

#define    	TC_NSE_TRADE_MOD_PARTICIPANT_RESP                   	5439

#define    	TC_NSE_EXCH_MSG_TO_TRADER_RESP      			5295

#define    	TC_NSE_TRADE_CAN_REQ_ACK_RESP                       	5441

#define    	TC_NSE_TRADE_MOD_REQUESTED_BY_CP_RESP               	5447

#define  	INDEX_ORDER_REJECTION                   		2104

#define         TC_NSE_INDEX_OE_CONF_RESP                      		2101

#define    	TC_NSE_ORDER_CAN_REQUESTED_RESP                     	2071

#define    	TC_NSE_ORDER_MOD_REQUESTED_RESP                     	2041

#define    	TC_NSE_ORDER_REQUESTED_RESP                         	2001

#define 	TC_EQU_NSE_INVITATION_REQ                               15000

#define 	TC_DRV_NSE_INVITATION_REQ                               15000

#define   	TC_DRV_NSE_SIGNON_REQ                             	2300

#define   	TC_EQU_NSE_SIGNON_REQ                             	2300

#define   	TC_EQU_NSE_SYS_INFO_RESP                          	1601

#define   	TC_EQU_NSE_PARTIAL_SYS_INFO_RESP                  	7321

#define   	TC_EQU_NSE_UPDATE_LDB_HEADER_RESP                 	7307

#define   	TC_EQU_NSE_UPDATE_LDB_DATA_RESP                   	7304

#define   	TC_EQU_NSE_UPDATE_LDB_TRAILER_RESP                	7308

#define   	TC_EQU_NSE_MSG_DOWNLOAD_START_RESP                	7011

#define   	TC_EQU_NSE_MSG_DOWNLOAD_DATA_RESP                 	7021

#define   	TC_EQU_NSE_MSG_DOWNLOAD_END_RESP                  	7031

#define   	TC_EQU_NSE_SYS_INFO_REQ                           	1600

#define		TC_NSE_MFSS_OE_REQ					2002	

#define   	TC_DRV_NSE_PORTFOLIO_RESP                         	1776

#define 	TC_EQU_BSE_NEWS_CATEGORY_REQ                     	1123

#define 	TC_EQU_BSE_KEEP_ALIVE_MSG_PROT                          13

#define  	TC_EQU_BSE_LOGOFF_REQUEST                          	1132

#define  	TC_EQU_BSE_LOGOFF_REPLY                            	1132

#define  	TC_EQU_BSE_LOGON_REQUEST                           	1131

#define  	TC_EQU_BSE_QUERY_INDEX_DETAILS_REPLY               	1112

#define  	TC_EQU_BSE_QUERY_INDEX_DETAILS_REQUEST             	1112

#define 	TC_END_OF_DOWNLOADS            				-8001

#define  	TC_EQU_BSE_END_OF_DOWNLOAD				1520

#define  	TC_EQU_BSE_QUERY_QUOTES_REQUEST                    	1091

#define  	TC_EQU_BSE_QUERY_6A7A_REQUEST                      	21501

#define  	TC_EQU_BSE_QUERY_ORDERS_REQUEST                    	1092

#define  	TC_EQU_BSE_QUERY_TRADERS_TRADES_REQUEST            	1095

#define  	TC_EQU_BSE_QUERY_MEMBERS_TRADES_REQUEST            	1096

#define  	TC_EQU_BSE_QUERY_PERSONAL_STOPLOSS_ORDERS          	1097

#define  	TC_EQU_BSE_QUERY_CKT_LIMIT                         	1098

#define  	TC_EQU_BSE_QUERY_RETURNED_ORDERS_REQUEST           	1170

#define  	TC_EQU_BSE_QUERY_RETURNED_QUOTES_REQUEST           	1171

#define  	TC_EQU_BSE_QUERY_RETURNED_STOPLOSS_ORDERS_REQUEST  	1173

#define  	TC_EQU_BSE_OWN_DEFAULT_IN_AUCTION_REQUEST          	10004

#define  	TC_EQU_BSE_QUERY_AUCTION_OFFERS_REQUEST            	10008

#define  	TC_EQU_BSE_AUC_SCRIP_DLOAD_UMS                     	10011

#define  	TC_EQU_BSE_END_OF_6A7A_DOWNLOAD                         21502

#define 	TC_INT_NOTIFICATION_REQ                                 2600

#define 	TC_INT_NOTIFICATION_RES                                 2601

#define		TC_INT_CREATE_ALL_FILE_REQ				2602

#define		TC_INT_CREATE_ALL_FILE_RES				2603

#define		TC_INT_DEALER_CLIENT_SUSPENSION_REQ			2604

#define		TC_INT_DEA_CLI_SUSPENSION_NOTIFICATION_RES		2605

#define 	TC_INT_DEA_CLIENT_MAPP_HEADER_RESP                      -5566

#define   	TC_INT_DEA_CLIENT_MAPP_RESP                             -5666

#define 	TC_INT_DEA_CLIENT_MAPP_REQ                              -5568

#define		TC_INT_MARGIN_SHORTFALL_REQ				-5570

#define		TC_INT_MARGIN_SHORTFALL_RESP                            -5572

#define		TC_INT_MARGIN_SHORTFALL_HEADER_RESP			-5574
//#define		TC_EQU_BSE_ORDER_REQUEST				1025

#define		TC_EQU_BSE_ORDER_REQ_RES                                1025

#define		TC_EQU_BSE_TRADE_CON_UMS				1521

#define		TC_EQU_BSE_MKT_TO_LMT_CONVT				1530

#define		TC_EQU_BSE_SP_OR_UMS					2507

#define		TC_EQU_BSE_KILL_MIN_FILL_ORD				1531		

#define		TC_EQU_BSE_RRM_MSG_ALERT_INFO				1921		
#define		TC_EQU_BSE_CAP_INFO					1922		
#define		TC_EQU_BSE_MASS_CANCEL_INFO				1927		
#define		TC_EQU_BSE_MEMBER_SUSPENSION_INFO			24004		
#define		TC_EQU_BSE_MEMBER_REACTIVATION_INFO			1528
#define		TC_EQU_BSE_RRM_ORDER_RESP				1920		


/*-------------------------------------------------------------------
  COVER/BRACKET ORDER MSG CODES
  --------------------------------------------------------------------*/
#define         TC_INT_CO_ORDER_REQ                     		6101
#define         TC_INT_CO_ORDER_MODIFY                  		6102
#define         TC_INT_CO_ORDER_EXIT					6103
#define         TC_INT_CO_ORDER_CANCEL					6104
#define         TC_INT_CO_REJ_SQROFF					6105
#define         TC_CO_ORDER_MODIFY 					6106

#define         TC_INT_BO_ORDER_REQ                     		8101
#define         TC_INT_BO_ORDER_MODIFY                  		8102
#define         TC_INT_BO_ORDER_EXIT					8103
#define         TC_INT_BO_LEG_MODIFY                    		8104
#define         TC_BO_PUMP_REQ                          		8105
#define         TC_INT_BO_ORDER_CANCEL                  		8106
#define         TC_BO_SQROFF_REQ	                  		8112

#define		TC_BO_DUMMY_MSGCODE					8107
#define		TC_BO_PARENT_ORD_PENDING				8108
#define		TC_BO_PARENT_ORD_TRADE					8109
#define		TC_BO_PARENT_ORD_CANCEL					8110
#define		TC_BO_ORD_EXPIRED					8111





#define 	TC_INT_SPRD_ORD_ENT_RSP					-5505
#define 	TC_INT_SPRD_ORD_MOD_RSP					-5506
#define 	TC_INT_SPRD_ORD_CAN_RSP					-5507
#define  	TC_INT_SPRD_ORD_BOOK_REQ                                -2298
#define  	TC_INT_SPRD_ORD_BOOK_RESP                               -2299
#define  	TC_INT_SPRD_ORD_BOOK_HDR_RESP				-2260


#define 	TC_INT_SPRD_OE_REJ					1116
#define 	TC_INT_SPRD_OM_REJ					1117
#define 	TC_INT_SPRD_OC_REJ					1118


#define 	TC_INT_RMS_SPRD_OE_REJ					4447	
#define 	TC_INT_RMS_SPRD_OM_REJ					4448	
#define 	TC_INT_RMS_SPRD_OC_REJ					4449	


/*-------------------------------------------------------------------
  ADMIN_MSG_CODE					
  --------------------------------------------------------------------*/

#define		TC_INT_ADMIN_ORDER_BOOK_REQ				-3386
#define		TC_INT_ADMIN_NET_POS_REQ				-3388
//#define		TC_INT_ADMIN_TRADE_BOOK_REQ				-3390
#define		TC_INT_ADMIN_VIEW_CLIENT_LIMIT_REQ			-3387
#define		TC_INT_ADMIN_CLINET_HOLDING_REQ				-3376
#define		TC_INT_ADMIN_REJECTED_ORDERS_REQ			-3379

#define		TC_INT_ADMIN_ORDER_BOOK_HEADER_RESP			-3384
#define		TC_INT_ADMIN_ORDER_BOOK_RESP				-3385
#define		TC_INT_ADMIN_TRAD_BOOK_RESP				-3391
#define		TC_INT_ADMIN_VIEW_CLIENT_LIMIT_RESP			-3393
#define		TC_INT_ADMIN_CLINET_HOLDING_RESP			-3377
#define		TC_INT_ADMIN_NET_POS_RESP				-3378
#define		TC_INT_ADMIN_NET_POS_HDR_RESP				-3468
#define 	TC_INT_ADMIN_CKT_HITTING_HOLDING_HEADER_RESP		-3290
#define		TC_INT_ADMIN_CKT_HITTING_HOLDING_RESP			-3291
#define		TC_INT_ADMIN_CKT_HITTING_NET_POS_HDR_RESP 		-3300
#define		TC_INT_ADMIN_CKT_HITTING_NET_POS_RESP 			-3301	

#define		TC_INT_ADMIN_IPO_ORDER_BOOK_HDR_RESP			-2555
#define		TC_INT_ADMIN_IPO_ORDER_BOOK_REQ				-2550	
#define		TC_INT_ADMIN_IPO_ORDER_BOOK_RESP			-2554

#define		TC_INT_CLIENT_LIMIT_HEADER_RESP				-3375
#define		TC_INT_CLT_LMT_HEADER_RESP				-3475
#define		TC_INT_ADMIN_CLINET_HOLDING_HEADER_RESP			-3383

#define		TC_INT_ADMIN_SIP_ORDER_BOOK_HED_RESP			-3372
#define		TC_INT_ADMIN_SIP_ORD_BOOK_RESP				-3374
#define		TC_INT_ADMIN_SIP_ORDER_DETS_HED_RESP			-3370
#define		TC_INT_ADMIN_SIP_ORDER_DETS_RESP			-3371
#define		TC_INT_ADMIN_SIP_ORDER_TRALS_HED_RESP			-3368
#define		TC_INT_ADMIN_SIP_ORDER_TRALS_RESP			-3369

#define         TC_INT_SIP_ORDER_BOOK_HED_RESP                    	-3361
#define         TC_INT_SIP_ORD_BOOK_RESP                          	-3362
#define         TC_INT_SIP_ORDER_DETS_HED_RESP                    	-3363
#define         TC_INT_SIP_ORDER_DETS_RESP                        	-3364
#define         TC_INT_SIP_ORDER_TRALS_HED_RESP                   	-3365
#define         TC_INT_SIP_ORDER_TRALS_RESP                       	-3366

#define 	TC_INT_PERCENT_MTM_QUERY_REQ				-5010
#define 	TC_INT_PERCENT_MTM_QUERY_RESP				-5012
#define 	TC_INT_PERCENT_MTM_HEADER_RESP				-5011 
#define		TC_INT_ADMIN_MARGIN_SHORTFALL_REQ			-3394
#define		TC_INT_ADMIN_MARGIN_SHORTFALL_HEADER_RESP		-3395
#define		TC_INT_ADMIN_MARGIN_SHORTFALL_RESP			-3396
#define		TC_INT_ADMIN_PERCENT_MTM_QUERY_REQ			-3397
#define		TC_INT_ADMIN_PERCENT_MTM_HEADER_RESP			-3398
#define		TC_INT_ADMIN_PERCENT_MTM_QUERY_RESP			-3399

#define		TC_INT_BO_ORDER_BOOK_REQ				-1421
#define		TC_INT_BO_ORDER_BOOK_HDR_RESP				-1422
#define		TC_INT_BO_ORDER_BOOK_RESP				-1423

#define		TC_INT_ADMIN_EDIT_CLIENT_LIMIT_REQ			-5601
#define		TC_INT_ADMIN_EDIT_CLIENT_LIMIT_SCC_RESP			-5602
#define		TC_INT_ADMIN_EDIT_CLIENT_LIMIT_ERR_RESP			-5603
#define		TC_INT_ADMIN_ADD_CLIENT_LIMIT_REQ			-5604
#define		TC_INT_ADMIN_ADD_CLIENT_LIMIT_SCC_RESP			-5605
#define		TC_INT_ADMIN_ADD_CLIENT_LIMIT_ERR_RESP			-5606
#define		TC_INT_ADMIN_CIRCUIT_LIMIT_REQ				-5607
#define		TC_INT_ADMIN_CIRCUIT_LIMIT_RESP				-5608
#define		TC_INT_ADMIN_CIRCUIT_LIMIT_HEADER_RESP			-5609

#define		TC_INT_ADMIN_PROFILE_MASTER_REQ				-5610
#define		TC_INT_ADMIN_PROFILE_MASTER_HED_RESP			-5611
#define		TC_INT_ADMIN_PROFILE_MASTER_RESP			-5612
#define		TC_INT_ADMIN_ADD_PROFILE_MASTER_REQ			-5613
#define		TC_INT_ADMIN_EDIT_PROFILE_MASTER_REQ			-5614
#define		TC_INT_ADMIN_ADD_EDIT_PROFILE_MASTER_PESP		-5615
#define		TC_INT_ADMIN_ADD_EDIT_PROFILE_MASTER_ERR_PESP		-5616
#define		TC_INT_ADMIN_VIEW_PAYOUT_REPORT_REQ			-5617
#define		TC_INT_ADMIN_VIEW_PAYOUT_REPORT_HEADER_RESP		-5618
#define		TC_INT_ADMIN_VIEW_PAYOUT_REPORT_RESP			-5619
#define		TC_INT_ADMIN_UPDATE_HOLDING_REQ				-5620
#define		TC_INT_ADMIN_UPDATE_HOLDING_RESP			-5621
#define		TC_INT_ADMIN_ADD_HOLDING_SCC_RESP			-5622
#define		TC_INT_ADMIN_ADD_HOLDING_ERR_RESP			-5623
#define		TC_INT_ADMIN_VIEW_CL_MASTER_REQ				-5624
#define		TC_INT_ADMIN_VIEW_CL_MASTER_RESP			-5625
#define		TC_INT_ADMIN_VIEW_CL_MASTER_HED_REQ			-5626
#define         TC_INT_ADMIN_ADD_HOLDING_REQ                            -5627
#define         TC_INT_ADMIN_ADD_HOLDING_RESP                           -5628
#define         TC_INT_ADMIN_VIEW_BR_MASTER_REQ				-5629
#define         TC_INT_ADMIN_VIEW_BR_MASTER_RESP			-5630
#define         TC_INT_ADMIN_VIEW_SCRIPT_BLOCK_REQ                      -5632
#define         TC_INT_ADMIN_VIEW_SCRIPT_BLOCK_RESP                     -5633
#define         TC_INT_ADMIN_VIEW_SCRIPT_BLOCK_HED_RESP                 -5634

#define         TC_INT_ADMIN_IPO_ORDER_REPORT_REQUEST                   -5712
#define         TC_INT_ADMIN_IPO_ORDER_REPORT_RESP                      -5714

#define		TC_INT_ADMIN_IPO_SEC_DETAILS_REQ			-1510	
#define		TC_INT_ADMIN_IPO_SEC_DETAIL_VIEW_HDR_RESP               -1512
#define		TC_INT_ADMIN_IPO_SEC_DETAIL_HDR_RESP		        -1511
#define		TC_INT_ADMIN_IPO_SEC_VIEW_DETAIL_RESP			-1513
#define		TC_INT_ADMIN_IPO_SEC_ADD_DETAIL_ERR_RESP		-1514
#define		TC_INT_ADMIN_IPO_SEC_EDIT_DETAIL_ERR_RESP		-1515


#define         TC_INT_ADMIN_ORDER_REPORT_REQUEST                       -1211
#define         TC_INT_ADMIN_ORDER_REPORT_RESP	                       	-1213
#define         TC_INT_ADMIN_ORDER_REPORT_ERR_RESP                      -1212
#define		TC_INT_ADMIN_TRADE_REPORT_REQUEST			-1311
#define		TC_INT_ADMIN_TRADE_REPORT_RESP				-1313
#define		TC_INT_ADMIN_TRADE_REPORT_ERR_RESP			-1312
#define		TC_INT_BATCH_PROCESS_REQ				-1424
#define		TC_INT_BATCH_PROCESS_RESP				-1425
#define         TC_INT_ADMIN_ORDER_REPORT_DETAILS_REQUEST               -1231
#define         TC_INT_ORDER_REPORT_DETAILS_HEADER_RESP                 -1228
#define         TC_INT_ORDER_REPORT_DETAILS_RESP                        -1229

#define		TC_INT_ADMIN_BATCH_PROCESS_HEADER_RESP			-1426

#define         TC_INT_UPDATE_BATCH_PROCESS_REQ				-1427
#define		TC_INT_UPDATE_BATCH_PROCESS_RESP			-1428
#define		TC_INT_RUN_BATCH_PROCESS_REQ				-1429
#define		TC_INT_RUN_BATCH_PROCESS_RESP				-1430

#define		TC_BSE_STAR_NEW_ORDER_ENTRY_REQ				1000
#define		TC_BSE_STAR_ORDER_MODIFY_REQ				2000
//#define		TC_BSE_STAR_ORDER_CANCEL_REQ				3000

#define		TC_INT_COBO_RANGE_REQUEST			        -1414
#define		TC_INT_COBO_RANGE_RESP					-1415
#define		TC_INT_COBO_RANGE_ERROR_RESP				-1416

#define		TC_INT_DEALER_NISM_CERT_REQ				-1700
#define		TC_INT_DEALER_NISM_CERT_HDR_RES				-1701
#define		TC_INT_DEALER_NISM_CERT_RES				-1702

#define		TC_INT_DP_HOLDING_REQ					-7700
#define		TC_INT_DP_HOLDING_RESP					-7701
#define		TC_INT_HDR_DP_HOLDING_RESP				-7702

#define		TC_INT_ADMIN_DP_HOLDING_REQ				-8700
#define		TC_INT_ADMIN_DP_HOLDING_RESP				-8701
#define		TC_INT_ADMIN_HDR_DP_HOLDING_RESP			-8702

#define		TC_INT_ADMIN_NISM_CERT_REQ				-1800
#define		TC_INT_ADMIN_NISM_CERT_HDR_RES				-1801
#define		TC_INT_ADMIN_NISM_CERT_RES				-1802

#define		TC_INT_CO_MRG_CAL_REQ					-1900	
#define		TC_INT_BO_MRG_CAL_REQ					-1901	
#define		TC_INT_MRG_CAL_REQ					-1902	
#define		TC_INT_MRG_CAL_RESP					-1910

#define		TC_INT_MKT_STATUS_REQ					-1905
#define		TC_INT_MKT_STATUS_HDR_RES				-1906	
#define		TC_INT_MKT_STATUS_RES					-1907	

#define		TC_INT_ADMIN_LIMIT_DTL_REQ				-3406
#define		TC_INT_ADMIN_LIMIT_DTL_RSP				-3407

#define		TC_INT_VIEW_DEALER_ADHOC_LIMIT_REQ			-2210
#define		TC_INT_VIEW_DEALER_ADHOC_LIMIT_RESP			-2211

#define		TC_INT_ADD_DEALER_ADHOC_LIMIT_REQ			-2214
#define		TC_INT_ADD_DEALER_ADHOC_LIMIT_RESP			-2215

#define         TC_INT_ADDED_VIEW_CLIENT_ADHOC_LIMIT_REQ                -2218
#define         TC_INT_ADDED_VIEW_CLIENT_ADHOC_LIMIT_RESP               -2219

#define		TC_INT_ADDED_VIEW_BRANCH_ADHOC_LIMIT_HDR_RESP		-2220

#define		TC_ADMIN_CLI_CONTRN_RPT_REQ				-1950
#define		TC_ADMIN_CLI_CONTRN_RPT_HDR_RSP				-1951
#define		TC_ADMIN_CLI_CONTRN_RPT_RSP				-1952

#define		TC_ADMIN_BROK_CONTRN_RPT_REQ				-1953
#define		TC_ADMIN_BROK_CONTRN_RPT_HDR_RSP			-1954
#define		TC_ADMIN_BROK_CONTRN_RPT_RSP				-1955


//For Multileg Orders //

#define         TC_INT_2L_OE_REQ           				2102
#define 	TC_INT_2L_OE_ERR_RESP      				2155
#define 	TC_INT_2L_OE_CONF_RESP					2125
#define 	TC_INT_2L_OC_CONF_RESP					2131
#define 	TC_INT_MUL_ORDER_REJECTION				-1141
#define 	TC_INT_MUL_ORDER_RESPONSE				-2112

#define         TC_INT_3L_OE_REQ           				2104
#define         TC_INT_3L_OE_ERR_RESP                                   2156
#define         TC_INT_3L_OE_CONF_RESP                                  2126
#define         TC_INT_3L_OC_CONF_RESP                                  2132



#define 	TC_INT_ADMIN_FILE_REQ				-2228	
#define 	TC_INT_ADMIN_FILE_RES				-2229


#define         TC_INT_ADMIN_SPRD_ORD_BOOK_REQ                                -3322
#define         TC_INT_ADMIN_SPRD_ORD_BOOK_RESP                               -3323
#define         TC_INT_ADMIN_SPRD_ORD_BOOK_HDR_RESP                           -3343	



#define         TC_INT_RESTART_SHEDULER                           -1947
#define         TC_INT_RESTART_SHEDULER_RES                           -1948

#define 	TC_INT_SIP_ERROR_RESP                            3331
#define         TC_INT_SIP_SUCESS_RESP                           3073


#define		TC_ADMIN_DEBIT_CLI_HOLDING_REQ				-1956
#define		TC_ADMIN_DEBIT_CLI_HOLDING_HDR_RSP			-1957
#define		TC_ADMIN_DEBIT_CLI_HOLDING_RSP				-1958

#define		TC_INT_DL_PAYOUT_REQ					-1980
#define		TC_INT_DL_PAYOUT_HDR_RESP				-1981
#define		TC_INT_DL_PAYOUT_RESP					-1982

#define		TC_ADMIN_SHORT_OPT_MTM_REQ				-1983
#define		TC_ADMIN_SHORT_OPT_MTM_HDR_RESP				-1984
#define		TC_ADMIN_SHORT_OPT_MTM_RESP				-1985

#define         TC_INT_ADMIN_VIEW_BR_MASTER_HED_RESP                    -5631
#define 	TC_INT_AUTOBATCH_MSG_RESP				-2305

#define 	TC_INT_MTM_NET_POS_RESP 				-6701
#define         TC_INT_MTM_C2D_NETPOS_HEADER_RESP                       -6703
#define 	TC_INT_CKT_LIMIT_NET_POS_RESP 				-6704
#define         TC_INT_CKT_LIMIT_NETPOS_HEADER_RESP                     -6705
#define		TC_EQU_BSE_UMS_MASS_CAN					3233
#define         TC_EQU_BSE_UMS_MASS_CAN_REQ                             1087
#define         TC_EQU_BSE_ENDOF_UMS_MASS_CAN_RESP                      1088


#define         TC_EQU_NSE_ORD_ENTRY_REQ_TM                             20000
#define         TC_EQU_NSE_ORD_MOD_REQ_TM                               20040
#define         TC_EQU_NSE_ORD_CAN_REQ_TM                               20070
#define         TC_EQU_NSE_ORD_ENT_ERR_RSP_TM                           20231
#define         TC_EQU_NSE_ORD_MOD_ERR_RSP_TM                           20042
#define         TC_EQU_NSE_ORD_CAN_ERR_RSP_TM                           20072
#define         TC_EQU_NSE_ORD_ENT_CON_RSP_TM                           20073
#define         TC_EQU_NSE_ORD_MOD_CON_RSP_TM                           20074
#define         TC_EQU_NSE_ORD_CAN_CON_RSP_TM                           20075
#define         TC_EQU_NSE_MKT_TO_LMT_RSP_TM                            20012
#define         TC_EQU_NSE_TRADE_RSP_TM                                 20222

#define         TC_EQU_NSE_BOX_SIGN_OFF_TM                              20322


#define         TC_EQU_NSE_SIGN_OFF_REQ                                 2320
#define         TC_EQU_NSE_SIGN_OFF_RESP                                2321

#define         TC_EQU_NSE_BOX_SIGN_ON_REQ                              23000
#define         TC_EQU_NSE_BOX_SIGN_ON_RESP                             23001

#define         TC_EQU_NSE_GR_REQ                                       2400
#define         TC_EQU_NSE_GR_RESP                                      2401
#define         TC_EQU_NSE_HEART_BEATS                                  23506

#define		TC_BULK_CANCEL_ADMIN_REQ				4300		
#define		TC_BULK_SQUAREOFF_ADMIN_REQ				4100		
#define		TC_BULK_CO_EXIT_ADMIN_REQ				4400		
#define		TC_BULK_BO_EXIT_ADMIN_REQ				4500		

#define 	TC_INT_CLIENT_TO_SERVER_DAEMON 				-2306


#define 	TC_CONV_TO_DEL_DTL_REQ                                  -5656
#define 	TC_INT_CONV_TO_DEL_RES                                  5657
#define 	TC_INT_CONV_TO_DEL_HDR_RES                              5658

#define         TC_NOT_AUTHORIZED_RESP                                  -5659

#define         TC_INT_CC_SQUAREOFF_COVER_ORD_REQ                       -2306
#define         TC_INT_CC_SQUAREOFF_BRACKET_ORD_REQ                     -2307

#define         TC_INT_MTM_HISTORY_REQ                                  -5660
#define         TC_INT_MTM_HISTORY_RES                                  5661
#define         TC_INT_MTM_HISTORY_HDR_RES                              5662

#define 	TC_INT_CLIENT_ADDED_NOTIFICATION 			-2406

#define  	TC_EQU_BSE_QUERY_TRADERS_TRADES_RESPONSE         	1095
#define  	TC_EQU_BSE_QUERY_ORDERS_RESPONSE                    	1092
#define  	TC_EQU_BSE_QUERY_STOPLOSS_ORD_RESPONSE          	1097
#define  	TC_EQU_BSE_QUERY_CANCELLED_ORDER_RESPONSE           	1170
#define  	TC_EQU_BSE_QUERY_STOPLOSS_ORDERS_RESPONSE		1173

#define		TC_EQU_BSE_SERVICE_AVAILABILITY				2300

#define         TC_INT_GTT_ORDER_ENTRY                                  9112
#define         TC_INT_GTT_ORDER_MODIFY                                 9113
#define         TC_INT_GTT_ORDER_CANCEL                                 9114
#define         TC_INT_GTT_ORDER_TRIGGERED                              9115
#define         TC_INT_GTT_ORDER_ENTRY_RSP                              9520
#define         TC_INT_GTT_ORDER_MODIFY_RSP                             9521
#define         TC_INT_GTT_ORDER_CANCEL_RSP                             9522

#define         TC_INT_ADMIN_GTT_ORDER_BOOK_REQ                         3025
#define         TC_INT_ADMIN_GTT_ORDER_DETS_REQ                         3027

#define         TC_INT_ADMIN_GTT_ORDER_BOOK_HED_RESP                    -3389
#define         TC_INT_ADMIN_GTT_ORD_BOOK_RESP                          -3392

#define         TC_INT_ADMIN_GTT_ORDER_DETS_HED_RESP                    -3351
#define         TC_INT_ADMIN_GTT_ORDER_DETS_RESP                        -3352

#define         TC_INT_GTT_ORDER_BOOK_REQ                               3103
#define         TC_INT_GTT_ORDER_DETS_REQ                               3104

#define         TC_INT_GTT_ORDER_BOOK_HED_RESP                          -3341
#define         TC_INT_GTT_ORD_BOOK_RESP                                -3342

#define         TC_INT_GTT_ORDER_DETS_HED_RESP                          -3344
#define         TC_INT_GTT_ORDER_DETS_RESP                              -3345

//********  BSE ETI MSG OCDE ****** @Abhishek
#define         TC_BSE_ETI_NEW_ORDER_REQ                                10100
#define         TC_BSE_ETI_MOD_ORDER_REQ                                10106
#define         TC_BSE_ETI_CAN_ORDER_REQ                                10109

#define         TC_BSE_ETI_NEW_ORDER_RES                                10101
#define         TC_BSE_ETI_MOD_ORDER_RES                                10107
#define         TC_BSE_ETI_CAN_ORDER_RES                                10110
#define         TC_BSE_ETI_EXECUTOIN_RES                                10103
#define         TC_BSE_MASS_CANCEL_RES                                  10122

#define         TC_BSE_ETI_ORD_CONF_RESP                                10990
#define         TC_BSE_ETI_TRD_NOTIFI_RESP                              10500

#define         TC_BSE_REJECTION_RESP                                   10010
#define         TC_BSE_EXTENDED_ORD_INFO_RESP                           10117
#define         TC_BSE_ETI_BOOK_ORDER_RESP                              10104
#define         TC_BSE_CAN_NOTIFICATION_RESP                            10112
#define         TC_BSE_RRM_NOTIFICATION_RESP                            10033
#define         TC_BSE_RRM_COLLETRAL_NOTIFICATION_RESP                  10049
