#include    <stdio.h>
#include    <string.h>
#include    <signal.h>
#include    <pthread.h>
#include    <fcntl.h>

#include    <sys/types.h>
#include    <sys/select.h>
#include    <sys/socket.h>
#include    <sys/file.h>
#include    <sys/time.h>
#include    <sys/errno.h>
#include    <sys/wait.h>
#include    <sys/msg.h>
#include    <netinet/in.h>
#include    <netinet/tcp.h>


#include    "IPCS.h"

#define     SOCKET_CLOSE     					0
#define     SOCKET_EXIST     					-2
#define     MAX_NO_OF_USER_SOCKETS				1000
#define     MAX_NO_OF_OP						5
#define     MAX_PACKET_SIZE                                       2048
#define     ERROR 								-1
#define     NOT_TRUE            				-1
#define     UNUSED              			-1	
#define     MAX_READ_THREADS    				300 
#define     MAX_WRITE_THREADS   				300 
#define     MAX_WRITE_DLOAD_THREADS 				100  
#define     MAX_WRITE_IOR_THREADS 				200  
#define     MAX_NO_OF_PROCESS   				4 
#define     RESTART             				-3
#define     BREAK_COUNTER        				10
#define 	QUERYQPCNT_FREE		 				0.1 
#define		DLOADQPCNT_FREE		 				0.3
#define		DLOADDIRQPCNT_FREE	 				0.3
#define 	READ_THREAD			 				1
#define		WRITE_THREAD		 				2
#define		WRITE_DLOAD_THREAD	 				3
#define		WRITE_IOR_THREAD	 				4
#define		INIT								0
#define		INSERT								1
#define		DELETE								2
#define		SELECT								3
#define		REVSELECT							4	

struct  MESG_STRUCT     
{
	LONG32  Flag;
	CHAR    Mesg_Buf[MAX_PACKET_SIZE];
};


static void init_routine (void);
void 		InitUserSocketTable();
void 		PrintLookup ( );
void 		AssociateSocketSignal (LONG32 );
void 		InitLookup ( );
LONG32 		GetIndexForPacket ( CHAR * );
LONG32 		SearchIndex ( LONG32 );
void 		CleanSocketResour ( LONG32 );
LONG32 		SendPacketToUser (LONG32 ,CHAR * );
LONG32 		SendDloadPacketToUser (LONG32 ,CHAR * );
LONG32 		SearchUserId ( LONG32 ,CHAR [][6], CHAR [],LONG32 * );
LONG32  	SearchGlobalUserId ( LONG32 , CHAR [][6], CHAR [] );
void 		SetUserId (LONG32 , CHAR *);
LONG32 		SearchForFreeslot ( );
LONG32 		OpenPassiveSocket ( );
void 		GetPacketFromQueue ( CHAR * , LONG32 );
void 		*SignalThread();
void 		*ReadThread();
void 		ReadWorkerThread(void *);
void 		*WriteThread(LONG32 *);
void 		WriteWorkerThread(struct  MESG_STRUCT *);
void 		*ReadServerStartupThread(LONG32 );
LONG32        ProcessLogOnRequest(LONG32 *Index,CHAR *UserId);
void 		WaitForMaxThreadCond(LONG32);
void 		InitProcessTable();
void 		*SignalHandler(LONG32 *RelayId,sigset_t SignalSet);
void 		SignalHandlerSigio(LONG32 dummy);
void 		SignalHandlerSigTerm(LONG32 );
void 		SignalHandlerSigChldParent(LONG32 );
void 		SignalReadThreadKillCond(LONG32);
LONG32  GetMaxSocket();
void WriteToRms(LONG32 id,CHAR * cpMsgBuf,LONG32 Size);
void LockThreadMutex ( pthread_mutex_t *, CHAR * );
void UnLockThreadMutex ( pthread_mutex_t * , CHAR *);
void ConnectToOracle ( ) ;
void ProcessArguments ( ) ;
void SqlErrorFun ( ) ;
void InitOracleRelayData ( );
void UpdateOracleRelayData ( LONG32 );
void UpdateOracleUserData (LONG32 ,LONG32  ,CHAR [][6], CHAR Segment [],char);
LONG32 WriteSearchExchSegment(CHAR [][6] , CHAR [6], CHAR [], CHAR );
void AddShmRelayData ( LONG32 ,CHAR [][6], CHAR [], struct sockaddr_in * , char);
void DeleteShmRelayData ( LONG32 ,CHAR [][6], CHAR [] );
void DeleteRelayUserShm ( LONG32 );
void WaitForMaxThreadCond ( );
void WaitForMaxThreadCondWrite ( );
LONG32 ProcessOrderProcessorStrtRequest();
void WaitForMaxDloadThreadCondWrite ( );
void SendMaxThreadCondSig ( );
void SendMaxThreadCondSigWrite ( );
void SendMaxDloadThreadCondSigWrite ( );
LONG32  CheckUserIdPassword ( LONG32 , CHAR * );
void UpdateForkProcess (LONG32 ,LONG32 ,LONG32 );
void UpdateForkProcessForRestart (LONG32 );
void DeleteRelayMaster ( );
void ProcessIncomePacket ( CHAR *,LONG32 , LONG32 );
void SendErrorResponce ( CHAR * , LONG32 );
void SendLogonResponce ( CHAR * , LONG32 );
LONG32  GetTimeStamp ( );
void RelayLogFatal (CHAR * );
void RelayLogMessage (CHAR * );
void Sleep (LONG32 );
void CheckPeerAddr ( struct sockaddr *,LONG32 );
void UpdatePeerAddr ( struct sockaddr *,LONG32 ,LONG32 );
void CleanUserResour ( );
void catch_alarm ( LONG32 );
void SendLogonErrorResponce (CHAR *,LONG32 );
void FindUserClient	( LONG32 ,CHAR [][6], CHAR [] ,CHAR *);

struct USER_SOCKET_LOOKUP
{
	CHAR User[USER_ID_LEN]  ;
	CHAR ClientId[CLIENT_ID_LEN]  ;
	LONG32   Socket    ;
	pthread_mutex_t	UserSocketLock ;
};

struct PROCESS_LOOKUP 
{
	LONG32    RelayId;
	LONG32    ProcessId;
	LONG32    RelayPort;
	LONG32    NoOfUsers;
};


#pragma pack(4)
struct REQ_HEADER
{
	SHORT   iRequestLength  ;
	LONG32  iUserId         ;
	SHORT   iRequestCode    ;               /*1-LOGIN,2-OE,3-OM,4-OC,5-OB,6-TB,7-NP,8-FUNDLIMIT,9-HOLDING,10-PORTFOLIO,11-EXPIRY*/
	SHORT   iExchange       ;               /*1-NSE,2-BSE,3-MCX*/
	SHORT   iSegment        ;               /*1-E,2-D,3-C*/
	CHAR    cUserType       ;
};
#pragma pack()



#pragma pack(4)
struct INT_RESP_HEADER
{
	LONG32          iSeqNo                                   ;
	SHORT           iMsgLength                               ;
	SHORT           iMsgCode                                 ;
	CHAR            sExcgId[EXCHANGE_LEN]                    ;
	SHORT           iErrorId                                 ;
	LONG32          iUserIdOrLogPktId                        ;
	CHAR            cUserTypeOrLogInfoType                   ;
	LONG32          iTimeStamp                               ;
	CHAR            cSegment                                 ;
};
#pragma pack()


#pragma pack(4)
struct SUB_ORDER_PROCESSOR_START
{
	LONG32    RelayId;
	LONG32    RelayPort;
};
#pragma pack()

#pragma pack(4)
struct  ORDER_PROCESSOR_START_RESP
{
	struct INT_COMMON_RESP_HDR	IntRespHeader;
	LONG32		NoOfProcess;
	struct SUB_ORDER_PROCESSOR_START	sSubOrdPrcRsp[MAX_NO_OF_PROCESS];
};	
#pragma pack()

#pragma pack(4)
struct VIEW_COMMON_HDR_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	/*      LONG32  iNoofPkt;*/
	CHAR    sClientId[CLIENT_ID_LEN];
};
#pragma pack()


#pragma pack(4)
struct  INT_DWS_LOGON_REQ
{
	struct          REQ_HEADER	ReqHeader;
	CHAR		sLoginId[15];
	CHAR		sPassword[16];
	CHAR		sPanCard[20];
	CHAR		sMACAddr[15];
	LONG32		iFiller;
};
#pragma pack()

#pragma pack(4)
struct  INT_DWS_LOGON_RESP
{
	struct INT_COMMON_RESP_HDR	IntRespHeader;
	CHAR		sEntityId[12];
	CHAR		sName[60];
	CHAR		AccCode[12];
	CHAR		CurrDate[20];
	CHAR		ExpiryDate[20];
	CHAR		AllowedExch[10];	/** 1-NSE EQ,1-NSE DRV,1-BSE EQ,0-BSE DRV,0-NSE CUR,0-NCDEX,0-MCX ****/
	CHAR		cfprimaryip[16];
	CHAR		cffailoverip[16];
	CHAR		dsprimaryip[16];
	CHAR		failoverip[16];
	CHAR		TransPass[16];
	SHORT		Suscriptionlevel;
	/***	CHAR		srr_version[10];****/

};
#pragma pack()


#pragma pack(4)
struct DWS_ORDER_REQUEST
{
	struct  REQ_HEADER      ReqHeader       ;
	CHAR            sSecurityId[12]    ;
	CHAR            sEntityId[12]        ;
	CHAR            sClientId[12]        ;
	CHAR            cProductId                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	SHORT           iMarketType                     ;               /*1-NL*/
	SHORT           iBookType                       ;               /*1-RL, 2-SL*/
	SHORT           iBuySell                        ;                       /*1-BUY,2-SELL*/
	CHAR            sFlag[10]                       ;               /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli*/
	LONG32          iDiscQty                        ;
	LONG32          iDiscQtyRem                     ;
	LONG32          iTotalQtyRem                    ;
	LONG32          iTotalQty                       ;
	LONG32          iTradedQty                      ;
	DOUBLE64        fPrice                          ;
	DOUBLE64        fTriggerPrice                   ;
	DOUBLE64        fOrderNum                       ;
	SHORT           iSerialNum                      ;
	DOUBLE64        fAlgoOrderNo                    ;

};
#pragma pack()


#pragma pack(4)
struct  DWS_ORDER_RESP
{
	struct      INT_RESP_HEADER     IntRespHeader       ;
	DOUBLE64    fOrderNum                                ;
	CHAR        sAccCode[CLIENT_ID_LEN]                  ;
	INT16       iBuyOrSell                               ;
	LONG32      iDiscQty                                 ;
	LONG32      iDiscQtyRemaining                        ;
	LONG32      iTotalQtyRemaining                       ;
	LONG32      iTotalQty                                ;
	LONG32      iQtyFilledToday                          ;
	DOUBLE64    fPrice                                  ;
	DOUBLE64    fTriggerPrice                           ;
	CHAR        sEntityId[ENTITY_ID_LEN]                 ;
	INT16       iOrdSerialNo                             ;
	CHAR        sSecurityId[SECURITY_ID_LEN]             ;
	CHAR        sClientId[CLIENT_ID_LEN]                 ;
	CHAR        sExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	CHAR        cProductId                               ;
	CHAR        sFlag[10]                           ;       /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli*/
	LONG32          iTradeNumber                     ;
	LONG32          iQtyTraded                       ;
	DOUBLE64        fTradePrice                      ;
};
#pragma pack()

#pragma pack(4)
struct INT_ERRORRESPONCESEND
{
	struct INT_RESP_HEADER           IntRespHeader;
	CHAR   sErrorMessage         [ERROR_MESSAGE_LEN];
};
#pragma pack()
/*
#pragma pack(4)
struct DWS_MTM_BREACH_RESP
{
struct INT_RESP_HEADER           IntRespHeader;
DOUBLE64	fMTMPercent			  ; 
};
#pragma pack()
 */
#pragma pack(4)
struct VIEW_COMMON_QUERY_REQ
{
	struct  REQ_HEADER      ReqHeader;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_CLIENT_LIMIT_RESP
{
	struct      INT_RESP_HEADER     IntRespHeader       ;
	CHAR            sClientId[ENTITY_ID_LEN];
	DOUBLE64        fLimitSOD;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fReceivables;
	DOUBLE64        fBankHoldings;
	DOUBLE64        fCollaterals;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fSumofAll;
	DOUBLE64        fAvailableBal;
	DOUBLE64        fClearBalance;
};
#pragma pack()

#pragma pack(4)
struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ
{
	struct  REQ_HEADER      ReqHeader;
	DOUBLE64        fOrderNo;
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_CLIENT_LIMIT
{
	DOUBLE64        fLimitSOD;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fReceivables;
	DOUBLE64        fBankHoldings;
	DOUBLE64        fCollaterals;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fSumofAll;
	DOUBLE64        fAvailableBal;
	DOUBLE64        fClearBalance;
	CHAR            sLimitType[10];
};
#pragma pack()

#pragma pack(4)
struct VIEW_CLIENT_LIMIT_RESP_NEW
{
	struct      INT_RESP_HEADER     IntRespHeader       ;
	CHAR            sClientId[ENTITY_ID_LEN];
	struct  SUB_VIEW_CLIENT_LIMIT   sSubViewClientlimit[2];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_NET_POSITION
{
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchId[EXCHANGE_LEN];
	DOUBLE64        fBuyQty;
	DOUBLE64        fBuyVal;
	DOUBLE64        fSellQty;
	DOUBLE64        fSellVal;
	DOUBLE64        fBuyAvg;
	DOUBLE64        fSellAvg;
	DOUBLE64        fNetQty;
	DOUBLE64        fNetVal;
	DOUBLE64        fNetAvg;
	DOUBLE64        fGrossQty;
	DOUBLE64        fGrossVal;
	CHAR            cMktType[MARKET_LEN];
	CHAR            cProductId;
	DOUBLE64        fLTP;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fMTM;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
};
#pragma pack()

#pragma pack(4)
struct VIEW_NET_POSITION_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_NET_POSITION subnetpos[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_ORDER_BOOK
{
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	DOUBLE64        fTradeQty;
	CHAR            sProduct[10];
	CHAR            sValidity[5];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	LONG32          iTranscode;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];
	LONG32          iDateTime;

};
#pragma pack()

#pragma pack(4)
struct VIEW_ORDER_BOOK_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_ORDER_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_ORDER_BOOK_DETAIL_RESP
{
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	LONG32          iTranscode;
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sFlags[10];  /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli,7-SourceFlag*/
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradePrice;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	CHAR            sProduct;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_STRING_LENGTH];
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sBuySellInd[5];
	CHAR            sOrdReasonDesc[200];
};
#pragma pack()

#pragma pack(4)
struct VIEW_ORDER_BOOK_DETAIL_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_ORDER_BOOK_DETAIL_RESP suborderbookdtls[5];
};
#pragma pack()


#pragma pack(4)
struct SUB_VIEW_TRADE_BOOK
{
	DOUBLE64        fOrderNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sOrderType[8];
	CHAR            sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];
	LONG32          iDateTime;

};
#pragma pack()

#pragma pack(4)
struct VIEW_TRADE_BOOK_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_TRADE_BOOK subTradeBook[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_CLIENT_HOLDINGS
{
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sISINCode[15];
	CHAR            sSecuritySource[5];
	LONG32          iQty;
	LONG32          iQtyUtilized;
	LONG32          iRemQty;
	CHAR            sExcgId[EXCHANGE_LEN];
	CHAR            sSymbol[SECURITY_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_CLIENT_HOLDINGS_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	CHAR    sClientId[CLIENT_ID_LEN];
	struct SUB_VIEW_CLIENT_HOLDINGS subClientHoldings[5];
};
#pragma pack()


#pragma pack(4)
struct VIEW_NET_POSITION_DATA_DETAIL
{
	struct VIEW_COMMON_QUERY_REQ commonquery;
	CHAR    sSecurityID[SECURITY_ID_LEN];
	CHAR    cProductID;
};
#pragma pack()


#pragma pack(4)
struct SUB_CLIENT_CONVERT_TO_DELIVERY
{
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExcgId[EXCHANGE_LEN];
	CHAR            cProductSource;
	CHAR            cProductDest;
	CHAR            cSide;
	DOUBLE64        fConvertPrice;
	LONG32          iQty;
	CHAR            cSegment;
};
#pragma pack()

#pragma pack(4)
struct VIEW_CLIENT_CONVERT_TO_DELIVERY
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_CLIENT_CONVERT_TO_DELIVERY subCTOD[5];
};
#pragma pack()

#pragma pack(4)
struct SEND_MSG_TO_CLIENT_REQ
{
	struct  REQ_HEADER      ReqHeader;
	CHAR            sSender[CLIENT_ID_LEN];
	LONG32          iReceiverUserId[25];
	LONG32          iNoOfRec;
	CHAR            sMsg[SEND_MSG_LEN];
};
#pragma pack()

#pragma pack(4)
struct SEND_MSG_TO_CLIENT_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR            sSender[CLIENT_ID_LEN];
	CHAR            sMsg[SEND_MSG_LEN];
};
#pragma pack()

#pragma pack(4)
struct DWS_DNLD_SYS_MESGS_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR            cMsgType;
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sGenralMsg[SYSTEM_MSG_LEN];
	LONG32          iMsgCode;

};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_CLIENT_DEALER_LIMIT
{
	CHAR            sClientId[ENTITY_ID_LEN];
	DOUBLE64        fLimitSOD;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fReceivables;
	DOUBLE64        fBankHoldings;
	DOUBLE64        fCollaterals;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fSumofAll;
	DOUBLE64        fAvailableBal;
	DOUBLE64        fClearBalance;
	CHAR            sLimitType[10];
};
#pragma pack()



#pragma pack(4)
struct VIEW_CLIENT_LIMIT_DEALER_RESP
{
	struct      INT_RESP_HEADER     IntRespHeader       ;
	CHAR            cMsgType;
	struct  SUB_VIEW_CLIENT_DEALER_LIMIT   sSubClientDlrlimit[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_REJECTED_ORDERS
{
	DOUBLE64        fOrderNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sOrderType[8];
	CHAR            sProduct[10];
	LONG32          iQty;
	DOUBLE64        fOrdPrice;
	LONG32          iInSuffQty;
	DOUBLE64        fInSuffAmt;
	DOUBLE64        fAmtBlocked;
	CHAR		sRmsStatus[10];
	CHAR		cMktOrder;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];

};
#pragma pack()

#pragma pack(4)
struct VIEW_REJECTED_ORDERS_RESP
{
	struct INT_RESP_HEADER  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_REJECTED_ORDERS subRejOrdBook[5];
};
#pragma pack()


#pragma pack(4)
struct DWS_CON_TO_DELIVERY_REQUEST
{
	struct  REQ_HEADER          		ReqHeader       	;
	CHAR    sSecurityId             [12]       		;
	CHAR    sEntityId               [12]		        ;
	CHAR    sClientId               [12]		        ;
	CHAR    cBuyOrSell                                      ;
	CHAR    cProdIdFrom                                     ;
	CHAR    cProdIdTo                                       ;
	LONG32  iQty                                            ;
	LONG32  iMktType                                        ;
};
#pragma pack()

#pragma pack(4)
struct DWS_CON_TO_DELIVERY_RESPONSE
{
	struct 	INT_RESP_HEADER  		RespHeader		;
	CHAR    sSecurityId             [12]		        ;
	CHAR    sEntityId               [12]		        ;
	CHAR    sClientId               [12]		        ;
	CHAR    cBuyOrSell                                      ;
	CHAR    cProdIdFrom                                     ;
	CHAR    cProdIdTo                                       ;
	LONG32  iQty                                            ;
	LONG32  iMktType                                        ;
};
#pragma pack()

#pragma pack(4)
struct ALGO_ORDER_REQUEST
{
	struct  	REQ_HEADER      ReqHeader       ;
	CHAR            sSecurityId[12]    		;
	CHAR            sEntityId[12]        		;
	CHAR            sClientId[12]        		;
	CHAR            cProductId                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	SHORT           iMarketType                     ;               /*1-NL*/
	SHORT           iBuySell                        ;                       /*1-BUY,2-SELL*/
	SHORT           iOrderValidity			;                       /*1-BUY,2-SELL*/
	LONG32          iTotalQty                       ;
	DOUBLE64        fPrice				;
	DOUBLE64        fAlgoOrderNo                    ;
	DOUBLE64        fAlgoOrdGap                    	;
	DOUBLE64        fAlgoSLPrice                    ;
	DOUBLE64        fTakePrfPrice                   ;
	DOUBLE64        fAlgoLTP                    	;


};
#pragma pack()


#pragma pack(4)
struct  ALGO_ORDER_RESP
{
	struct      INT_RESP_HEADER     IntRespHeader       ;
	DOUBLE64    OrderNum                                ;
	CHAR        AccCode[CLIENT_ID_LEN]                  ;
	INT16       BuyOrSell                               ;
	LONG32      DiscQty                                 ;
	LONG32      DiscQtyRemaining                        ;
	LONG32      TotalQtyRemaining                       ;
	LONG32      TotalQty                                ;
	LONG32      QtyFilledToday                          ;
	DOUBLE64     Price                                  ;
	DOUBLE64     TriggerPrice                           ;
	CHAR        EntityId[ENTITY_ID_LEN]                 ;
	INT16       OrdSerialNo                             ;
	CHAR        SecurityId[SECURITY_ID_LEN]             ;
	CHAR        ClientId[CLIENT_ID_LEN]                 ;
	CHAR        BseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	CHAR        ProductId                               ;
	CHAR        sFlag[10]                           ;       /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli*/
	LONG32          TradeNumber                     ;
	LONG32          QtyTraded                       ;
	DOUBLE64        TradePrice                      ;
};
#pragma pack()

#pragma pack(4)
struct SUB_DEALER_MAPP
{
	CHAR    sClientString[CLI_STRING_LEN]           ;
};
#pragma pack()

#pragma pack(4)
struct DEALER_MAPP_RESP
{
	struct  INT_RESP_HEADER IntRespHeader   ;
	CHAR    cMsgType                        ;
	LONG32  iNoofRec                        ;
	struct  SUB_DEALER_MAPP subdeamapp[5]   ;
};
#pragma pack()

