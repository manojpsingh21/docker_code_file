typedef BOOL  (*P_TO_FUN)(CHAR * x);

#define         TWIDDLE(A)              Twiddle((char *) &A, sizeof(A))

struct TRANS_FUN_PAIR
{
	INT16  Transcode;
	P_TO_FUN  pToFun;
};
#pragma pack(2)
struct	BCAST_HEADER
{
	SHORT		iMsgCode					;
	CHAR		sExchID			[EXCHANGE_LEN]		;
};
#pragma pack()


#pragma pack(2)
struct 	NNF_MBP_DATA
{
	LONG32          iQty 						;
	LONG32          iPrice						;	
	SHORT           iNoOfOrders 					;
	SHORT           iBbBuySellFlg 					;
};
#pragma pack()

#pragma pack(2)
struct  NNF_MBO_MBP_TERMS
{
#ifdef  BIGENDIAN
	USHORT              uiAon                   : 1                     ;
	USHORT              uiMf                    : 1                     ;
	USHORT              uiFiller1               : 6                     ;
	USHORT              uiFiller2               : 8                     ;
#elif   LITTLEENDIAN
	USHORT              uiFiller1               : 6                     ;
	USHORT              uiAon                   : 1                     ;
	USHORT              uiMf                    : 1                     ;
	USHORT              uiFiller2               : 8                     ;
#endif
};
#pragma pack()


#pragma pack(2)
struct  NNF_MBO_DATA
{
	LONG32 		iTrdadeid					;
	LONG32          iQty                                            ;
	LONG32          iPrice                                          ;
	struct 		NNF_MBO_MBP_TERMS	pNnfMboMbpTerm		;
	LONG32		iMinFillQty					;
};


#pragma pack(2)
struct	NNF_SEC_INFO
{
	CHAR 		sSymbol			[SYMBOL_LEN]			;
	CHAR		sSeries			[SERIES_LEN]			;
};
#pragma pack()


#pragma pack(2)
struct	NNF_DESTINATION
{
#ifdef  BIGENDIAN
#define  MAX_NO_THREADS 3
	USHORT              uiTraderWs		: 1     		;
	USHORT              uiControlWs             : 1     		;
	USHORT              uiTandem                : 1     		;
	USHORT              uiFiller1               : 5     		;
	USHORT              uiFiller2               : 8     		;
#elif   LITTLEENDIAN
	USHORT              uiFiller1               : 5     		;
	USHORT              uiTandem                : 1     		;
	USHORT              uiControlWs             : 1     		;
	USHORT              uiTraderWs              : 1     		;
	USHORT              uiFiller2               : 8     		;
#endif
};
#pragma pack()


#pragma pack(2)
struct	NNF_INDICES_DATA
{
	CHAR		sIndexName		[INDEX_NAME_LEN]	;
	LONG32		iIndexVal					;
	LONG32		iHighIndexVal					;
	LONG32		iLowIndexVal					;
	LONG32		iOpeningIndex					;
	LONG32		iClosingIndex					;
	LONG32		iPercentChange					;
	LONG32		iYearlyHigh					;
	LONG32		iYearlyLow					;
	LONG32		iNoOfUpMoves					;
	LONG32		iNoOfDownMoves					;
	DOUBLE64	fMktCapitalisation				;
	CHAR		cNetChangeIndicator				;
};
#pragma pack()


#pragma pack(2)
struct    NNF_SEC_ELIGIBILITY_PER_MARKET
{
#ifdef  BIGENDIAN
	USHORT          uiEligibility   	:1			;
	USHORT          uiFiller                :7			;
	SHORT           iStatus						; 
#elif   LITTLEENDIAN
	USHORT          uiFiller                :7			;
	USHORT          uiEligibility   	:1			;
	SHORT           iStatus						; 
#endif
};
#pragma pack()

#pragma pack(2)
struct    NNF_SEC_ELIGIBILITY_PER_MARKET_TNDTC
{
#ifdef  BIGENDIAN
        USHORT          uiEligibility           :1                      ;
        USHORT          uiFiller                :7                      ;
        CHAR            Reserved                                        ;
        SHORT           iStatus                                         ;
#elif   LITTLEENDIAN
        USHORT          uiFiller                :7                      ;
        USHORT          uiEligibility           :1                      ;
        CHAR            Reserved                                        ;
        SHORT           iStatus                                         ;
#endif
};
#pragma pack()


#pragma pack(2)
struct    NNF_SEC_ELIGIBILITY_AUC
{
#ifdef  BIGENDIAN
	USHORT          uiEligibility           :1                      ;
	USHORT          uiFiller                :7                      ;
	CHAR           	cStatus                                         ;
#elif   LITTLEENDIAN
	USHORT          uiFiller                :7                      ;
	USHORT          uiEligibility           :1                      ;
	CHAR           cStatus                                         ;
#endif
};
#pragma pack()




#pragma pack(2)
struct NNF_STOCK_ELIGIBLE_INDICATORS
{
#ifdef  BIGENDIAN
	USHORT               uiParticipateInMktIndex :1      		;
	USHORT               uiAON           	:1              	;
	USHORT               uiMinFill       	:1              	;
	USHORT               uiFiller        	:5              	;
	USHORT       	uiFiller1       	:8              	;
#elif   LITTLEENDIAN
	USHORT               uiFiller        	:5              	;
	USHORT               uiMinFill       	:1              	;
	USHORT               uiAON           	:1              	;
	USHORT               uiParticipateInMktIndex :1      		;
	USHORT       	uiFiller1       	:8              	;
#endif
};
#pragma pack()



#pragma pack(2)
struct NNF_PURPOSE
{
#ifdef  BIGENDIAN
	USHORT    		uiDividend             	:1 			;
	USHORT    		uiRights               	:1 			;
	USHORT    		uiBonus                	:1 			;
	USHORT    		uiInterest             	:1 			;
	USHORT    		uiAGM                  	:1 			;
	USHORT    		uiEGM                  	:1 			;
	USHORT    		uiFiller               	:2 			;
	USHORT			uiFiller1              	:8 			;
#elif   LITTLEENDIAN
	USHORT    		uiFiller               	:2 			;
	USHORT    		uiEGM                  	:1 			;
	USHORT    		uiAGM                  	:1 			;
	USHORT    		uiInterest             	:1 			;
	USHORT    		uiBonus                	:1 			;
	USHORT    		uiRights               	:1			;
	USHORT    		uiDividend             	:1 			;
	USHORT    		uiFiller1              	:8			;
#endif
};
#pragma pack()



#pragma pack(2)
struct INT_BROADCAST_HEADER
{
	SHORT		iMsgLen					;
	SHORT		iMsgCode				;
	CHAR		sExchId			[EXCHANGE_LEN]	;
	CHAR		cSegment				;

};
#pragma pack()


#pragma pack(2)
struct NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS
{
#ifdef  BIGENDIAN
	USHORT               uiAON           :1              ;
	USHORT               uiMinFill       :1              ;
	USHORT               uiBooksMerged   :1              ;
	USHORT               uiFiller        :5              ;

	USHORT               uiFiller1       :8              ;
#elif   LITTLEENDIAN
	USHORT               uiFiller        :5              ;
	USHORT               uiBooksMerged   :1              ;
	USHORT               uiMinFill       :1              ;
	USHORT               uiAON           :1              ;
	USHORT               uiFiller1       :8              ;
#endif
};
#pragma pack()


#pragma pack(2)
struct NNF_INDICATOR
{
#ifdef  BIGENDIAN
	USHORT uiLastTradeMore                 : 1     ;
	USHORT uiLastTradeLess                 : 1     ;
	USHORT uiBuySTI                        : 1     ;
	USHORT uiSellSTI                       : 1     ;
	USHORT uiFiller1                       : 4     ;
	USHORT uiFiller2                       : 8     ;	/*Amar_Tndtc - https://static.nseindia.com//s3fs-public/inline-files/TP_CM_Trimmed_NNF_PROTOCOL_5.3_3.pdf - Page 120*/
#elif   LITTLEENDIAN
	USHORT uiFiller1                       : 4     ;
	USHORT uiSellSTI                       : 1     ;
	USHORT uiBuySTI                        : 1     ;
	USHORT uiLastTradeLess                 : 1     ;
	USHORT uiLastTradeMore                 : 1     ;
	USHORT uiFiller2                       : 8     ;	/*Amar_Tndtc - https://static.nseindia.com//s3fs-public/inline-files/TP_CM_Trimmed_NNF_PROTOCOL_5.3_3.pdf - Page 120*/
#endif
} ;
#pragma pack()




#pragma pack(2)
struct NNF_HEADER
{
	LONG32 		iReserved				;
	LONG32		iLogTimeStamp				;
	CHAR		sAlphaSplit	[ALPHA_SPLIT_LEN] 	;
	INT16		iMsgCode				;
	INT16		iErrorCode				;
	CHAR		sTimeStamp1	[NNF_DATE_TIME_LEN]	; /***DATE_TIME_LEN**/
	CHAR            sTimeStamp2     [NNF_DATE_TIME_LEN]     ;
	CHAR            sTimeStamp3     [NNF_DATE_TIME_LEN]     ;
	INT16		iMsgLen					;	
};
#pragma pack()


#pragma pack(2)
struct NNF_INTERACTIVE_MBP
{
	SHORT       	iToken					;
	SHORT           iBookType				;
	SHORT           iTradingStatus				; 
	LONG32          iVolTradedToday                         ;
	LONG32          iLastTradedPrice                        ;
	CHAR            cNetChangeIndicator                     ;
	LONG32          iNetPriceChange                         ;
	LONG32          iLastTradedQty                           ;
	LONG32          iLastTradeTime                          ;
	LONG32          iAvgTradePrice                      ;
	SHORT           iAuctionNumber                          ;
	SHORT           iAuctionStatus                          ;
	SHORT           iInitiatorType                          ;
	LONG32          iInitiatorPrice                         ;
	LONG32          iInitiatorQty                           ;
	LONG32          iAuctionPrice                           ;
	LONG32          iAuctionQty                             ;
	struct          NNF_MBP_DATA  pMBPRecords[MBP_NO_OF_RECS];
	SHORT           iBbTotalBuyFlg                          ;/*Added  on  to incorp MBO MBP broadcast changes*/
	SHORT           iBbTotalSellFlg                         ;/*Added  on  to incorp MBO MBP broadcast changes*/
	DOUBLE64        fTotalBuyQty                            ;
	DOUBLE64        fTotalSellQty                           ;
	struct          NNF_INDICATOR  pIndicators              ;
	LONG32      	iClosePrice                             ;
	LONG32      	iOpenPrice                              ;
	LONG32      	iHighPrice                              ;
	LONG32      	iLowPrice                               ;
};
#pragma pack()



#pragma pack(2)
struct  NNF_MBP_BCAST
{
	struct 		NNF_HEADER	pHeader				;
	SHORT		iNoOfRecs					;
	struct		NNF_INTERACTIVE_MBP pMBPInfo[MAX_INT_MBP_RECS]	;

};
#pragma pack()

#pragma pack(2)
struct NNF_INTERACTIVE_MBP_TNDTC
{
        LONG32          iToken                                  ;       /* Tndtc_Change in iToken - LONG32 */
        SHORT           iBookType                               ;
        SHORT           iTradingStatus                          ;
        LONG32          iVolTradedToday                         ;
        LONG32          iLastTradedPrice                        ;
        CHAR            cNetChangeIndicator                     ;
        CHAR            cFiller                                 ;       // 1  /* Tndtc_Add Filler 1 byte */
        LONG32          iNetPriceChange                         ;
        LONG32          iLastTradedQty                          ;
        LONG32          iLastTradeTime                          ;
        LONG32          iAvgTradePrice                          ;
        SHORT           iAuctionNumber                          ;
        SHORT           iAuctionStatus                          ;
        SHORT           iInitiatorType                          ;
        LONG32          iInitiatorPrice                         ;
        LONG32          iInitiatorQty                           ;
        LONG32          iAuctionPrice                           ;
        LONG32          iAuctionQty                             ;
        struct          NNF_MBP_DATA  pMBPRecords[MBP_NO_OF_RECS];
        SHORT           iBbTotalBuyFlg                          ;/*Added  on  to incorp MBO MBP broadcast changes*/
        SHORT           iBbTotalSellFlg                         ;/*Added  on  to incorp MBO MBP broadcast changes*/
        DOUBLE64        fTotalBuyQty                            ;
        DOUBLE64        fTotalSellQty                           ;
        struct          NNF_INDICATOR  pIndicators              ;
        LONG32          iClosePrice                             ;
        LONG32          iOpenPrice                              ;
        LONG32          iHighPrice                              ;
        LONG32          iLowPrice                               ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_MBP_BCAST_TNDTC
{
        struct          NNF_HEADER      pHeader                         ;
        SHORT           iNoOfRecs                                       ;
        struct          NNF_INTERACTIVE_MBP_TNDTC pMBPInfo[MAX_INT_MBP_RECS]  ;

};
#pragma pack()


/** Updating CA2 broadcast for Nse CM . @Nitish**/
#pragma pack(2)
struct NNF_INTERACTIVE_CALL_AUCTION_MBP
{
	SHORT           iToken                                  ;
	SHORT           iBookType                               ;
	SHORT           iTradingStatus                          ;
	LONG32          iVolTradedToday                         ;
	LONG32		indicativeTradedQty			;
	LONG32          iLastTradedPrice                        ;
	CHAR            cNetChangeIndicator                     ;
	LONG32          iNetPriceChange                         ;
	LONG32          iLastTradedQty                           ;
	LONG32          iLastTradeTime                          ;
	LONG32          iAvgTradePrice                      	;
	LONG32		iFirstOpenPrice				;
	struct          NNF_MBP_DATA  pMBPRecords[MBP_NO_OF_RECS];
	SHORT           iBbTotalBuyFlg                          ;/*Added  on  to incorp MBO MBP broadcast changes*/
	SHORT           iBbTotalSellFlg                         ;/*Added  on  to incorp MBO MBP broadcast changes*/
	DOUBLE64        fTotalBuyQty                            ;
	DOUBLE64        fTotalSellQty                           ;
	struct          NNF_INDICATOR  pIndicators              ;
	LONG32          iClosePrice                             ;
	LONG32          iOpenPrice                              ;
	LONG32          iHighPrice                              ;
	LONG32          iLowPrice                               ;
};
#pragma pack()

#pragma pack(2)
struct NNF_CALL_AUCTION_MBP
{
	struct          NNF_HEADER      pHeader                         ;
	SHORT           iNoOfRecs                                       ;
	//struct          NNF_INTERACTIVE_CALL_AUCTION_MBP pMBPInfo[MAX_INT_MBP_RECS]  ;
	struct          NNF_INTERACTIVE_CALL_AUCTION_MBP pCallAucMbp[MAX_INT_MBP_RECS]  ;

};
#pragma pack()


#pragma pack(2)
struct NNF_INTERACTIVE_CALL_AUCTION_MBP_TNDTC
{
        LONG32          iToken                                  ;       /* Tndtc_Change in iToken - LONG32 */
        SHORT           iBookType                               ;
        SHORT           iTradingStatus                          ;
        LONG32          iVolTradedToday                         ;
        LONG32          indicativeTradedQty                     ;
        LONG32          iLastTradedPrice                        ;
        CHAR            cNetChangeIndicator                     ;
        CHAR            cFiller                                 ;       /* Tndtc_Add Filler 1 byte */
        LONG32          iNetPriceChange                         ;
        LONG32          iLastTradedQty                          ;
        LONG32          iLastTradeTime                          ;
        LONG32          iAvgTradePrice                          ;
        LONG32          iFirstOpenPrice                         ;
        struct          NNF_MBP_DATA  pMBPRecords[MBP_NO_OF_RECS];
        SHORT           iBbTotalBuyFlg                          ;/*Added  on  to incorp MBO MBP broadcast changes*/
        SHORT           iBbTotalSellFlg                         ;/*Added  on  to incorp MBO MBP broadcast changes*/
        DOUBLE64        fTotalBuyQty                            ;
        DOUBLE64        fTotalSellQty                           ;
        struct          NNF_INDICATOR  pIndicators              ;
        LONG32          iClosePrice                             ;
        LONG32          iOpenPrice                              ;
        LONG32          iHighPrice                              ;
        LONG32          iLowPrice                               ;
};
#pragma pack()

#pragma pack(2)
struct NNF_CALL_AUCTION_MBP_TNDTC
{
        struct          NNF_HEADER      pHeader                         ;
        SHORT           iNoOfRecs                                       ;
        struct          NNF_INTERACTIVE_CALL_AUCTION_MBP_TNDTC pCallAucMbp[MAX_INT_MBP_RECS]  ;

};
#pragma pack()

#pragma pack(2)
struct  NNF_MULTIPLE_INDEX_BCAST
{
	struct  	NNF_HEADER      	pHeader					;
	INT16          	iNumberOfRecords						;
	struct  	NNF_INDICES_DATA        pIndicesData[MAX_RECORDS_FOR_INDICES]	;
};
#pragma pack()

#pragma pack(2)
struct ST_AUCTION_INQ_INFO 
{
	INT16 iToken;
	INT16 iAuctionNumber;
	INT16 iAuctionStatus;
	INT16 iInitiatorType;
	LONG32 iTotalBuyQty;
	LONG32 iBestBuyPrice;
	LONG32 iTotalSellQty;
	LONG32 iBestSellPrice;
	LONG32 iAuctionPrice;
	LONG32 iAuctionQty;
	INT16 iSettlementPeriod;

};
#pragma pack()


#pragma pack(2)
struct ST_AUCTION_INQ_INFO_TNDTC
{
        LONG32 iToken;	    /* Change in iToken - LONG32 */
        INT16 iAuctionNumber;
        INT16 iAuctionStatus;
        INT16 iInitiatorType;
        LONG32 iTotalBuyQty;
        LONG32 iBestBuyPrice;
        LONG32 iTotalSellQty;
        LONG32 iBestSellPrice;
        LONG32 iAuctionPrice;
        LONG32 iAuctionQty;
        INT16 iSettlementPeriod;

};
#pragma pack()

#pragma pack(2)
struct BC_AUCTION_STATUS_CHANGE
{
	struct          NNF_HEADER      pHeader                         ;
	struct          NNF_SEC_INFO  SecInfo                         	;	
	INT16 		iAuctionNumber				;
	CHAR 		cAuctionStatus				;
	CHAR 		sActionCode [3]				;
	struct    	NNF_SEC_ELIGIBILITY_AUC SecEligibiliAuc ;
	INT16 		iBroadcastMessageLength			;
	CHAR 		sBroadcastMessage [BCAST_MSG_LEN]	;

};
#pragma pack()

#pragma pack(2)
struct MS_AUCTION_INQ_DATA
{
	struct          NNF_HEADER      pHeader                         ;
	struct 		ST_AUCTION_INQ_INFO  pAucInqInfo		;

};
#pragma pack()

#pragma pack(2)
struct MS_AUCTION_INQ_DATA_TNDTC
{
        struct          NNF_HEADER      pHeader                         ;
        struct          ST_AUCTION_INQ_INFO_TNDTC  pAucInqInfo                ;

};
#pragma pack()

#pragma pack(2)
struct COMPRESSION_BRDCST_DATA
{
	short           temp;
	short           compression_len;
	char            broadcast_data[508];
};

#pragma pack()

#pragma pack(2)
struct  NNF_MARKET_STATUS
{
	INT16           Normal                          ;
	INT16           Oddlot                          ;
	INT16           Spot                            ;
	INT16           Auction                         ;
	INT16           CallAuction1                    ;
	INT16           CallAuction2                    ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_GEN_MESSAGE_BCAST
{
	struct          NNF_HEADER       sHeader                                        ;
	SHORT           BranchNumber                                                    ;
	CHAR            BrokerNumber [BROKER_CODE_LENGTH ]                 ;
	CHAR            ActionCode   [ACTION_CODE_LEN]          ;
	CHAR            Reserved     [4]                                                ;
	struct          NNF_DESTINATION      Dest                               ;
	SHORT           BcastMsgLength                                                  ;
	CHAR            BcastMsg [ BCAST_MSG_LEN ]              ;
};
#pragma pack()

#pragma pack(2)
struct NNF_SYSTEM_INFO_BCAST
{
	struct          NNF_HEADER       sHeader                                        ;
	struct          NNF_MARKET_STATUS  MarketStatus                 ;
	LONG32          MktIndex                                                                ;
	SHORT           DefaultSettNormal                                               ;
	SHORT       DefaultSettSpot                                                     ;
	SHORT           DefaultSettAuction                                              ;
	SHORT       CompetitorPeriod                                            ;
	SHORT           SolicitorPeriod                                                 ;
	SHORT       WarningPercent                                                      ;
	SHORT       VolFreezePercent                                            ;
	SHORT           Reserved1                                                               ;
	SHORT           Reserved2                                                               ;
	LONG32          BoardLotQty                                                             ;
	LONG32      TickSize                                                            ;
	SHORT       MaxGtcDays                                                          ;
	struct          NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS StockEligibilityIndicator;
	SHORT       DQPercentAllowed                                            ;
};
#pragma pack()

#pragma pack(2)
struct NNF_SECURITY_UPDATE_BCAST
{

	struct          NNF_HEADER       sHeader                                        ;
	SHORT               Token                                                                   ;
	struct          NNF_SEC_INFO  SecInfo                                   ;
	SHORT           InstrumentType                                                  ;
	SHORT           PermittedToTrade                                                ;
	DOUBLE64        IssuedCapital                                                   ;
	SHORT           WarningPercent                                                  ;
	SHORT           FreezePercent                                                   ;
	CHAR            CreditRating [CREDIT_RATING_SIZE]                ;

	struct    NNF_SEC_ELIGIBILITY_PER_MARKET SecEligibilityPerMkt [MARKET_TYPES];

	SHORT           IssueRate                                                               ;
	LONG32          IssueStartDate                                                  ;
	LONG32          IssuePDate                                                              ;
	LONG32          IssueMaturityDate                                               ;
	LONG32          BoardLotQty                                                             ;
	LONG32          TickSize                                                                ;
	CHAR            SecurityName[SEC_DESC_LEN]                              ;
	CHAR            Reserved1                                                               ;
	LONG32          ListingDate                                                             ;
	LONG32          ExpulsionDate                                                   ;
	LONG32          ReAdmissionDate                                                 ;
	LONG32          RecordDate                                                              ;
	LONG32          ExDate                                                                  ;
	LONG32          NoDeliveryStartDate                                             ;
	LONG32          NoDeliveryEndDate                                               ;
	struct      NNF_STOCK_ELIGIBLE_INDICATORS StockEligibleIndicator;
	LONG32          BookClosureStartDate                                    ;
	LONG32          BookClosureEndDate                                              ;
	struct          NNF_PURPOSE        Purpose                              ;
	LONG32          LocalUpdateDateTime                                             ;
	CHAR            DeleteFlag                                                              ;
	CHAR            Remark[OE_REMARKS_LEN]                                  ;
	CHAR        ISINNumber[ISIN_LEN]                    ;/** Userid related changes **/
};
#pragma pack()

#pragma pack(2)
struct NNF_SECURITY_UPDATE_BCAST_TNDTC
{

        struct          NNF_HEADER       sHeader                                        ;
        LONG32          Token                                                           ;       /* Tndtc_Change in iToken - LONG32 */
        struct          NNF_SEC_INFO  SecInfo                                           ;
        SHORT           InstrumentType                                                  ;
        SHORT           PermittedToTrade                                                ;
        DOUBLE64        IssuedCapital                                                   ;
        SHORT           WarningPercent                                                  ;
        SHORT           FreezePercent                                                   ;
        CHAR            CreditRating [CREDIT_RATING_SIZE]                               ;
        CHAR            Reserved                                                        ;
        struct    NNF_SEC_ELIGIBILITY_PER_MARKET_TNDTC SecEligibilityPerMkt [MARKET_TYPES];
        SHORT           IssueRate                                                               ; /*SurvInd*/
        LONG32          IssueStartDate                                                          ;
        LONG32          IssuePDate                                                              ;
        LONG32          IssueMaturityDate                                                       ;
        LONG32          BoardLotQty                                                             ;
        LONG32          TickSize                                                                ;
        CHAR            SecurityName[SEC_DESC_LEN]                                              ;
        CHAR            Reserved1                                                               ;
        LONG32          ListingDate                                                             ;
        LONG32          ExpulsionDate                                                           ;
        LONG32          ReAdmissionDate                                                         ;
        LONG32          RecordDate                                                              ;
        LONG32          ExDate                                                                  ;
        LONG32          NoDeliveryStartDate                                                     ;
        LONG32          NoDeliveryEndDate                                                       ;
        struct          NNF_STOCK_ELIGIBLE_INDICATORS StockEligibleIndicator                        ;
        LONG32          BookClosureStartDate                                                    ;
        LONG32          BookClosureEndDate                                                      ;
        struct          NNF_PURPOSE        Purpose                                              ;
        LONG32          LocalUpdateDateTime                                                     ;
        CHAR            DeleteFlag                                                              ;
        CHAR            Remark[OE_REMARKS_LEN]                                                  ;
        LONG32          FaceValue                                                               ;
        CHAR            ISINNumber[ISIN_LEN]                                                    ;/** Userid related changes **/
        LONG32          MktMakerSpread                                                          ;
        LONG32          MktMakerMinQty                                                          ;
        SHORT           CallAuction1Flag                                                        ;
};
#pragma pack()


#pragma pack(2)
struct NNF_SEC_STATUS_PER_MARKET
{
	SHORT       Status;
};
#pragma pack()

#pragma pack(2)
struct    NNF_TOKEN_AND_ELIGIBILITY
{
	SHORT               Token                                                                   ;
	struct          NNF_SEC_STATUS_PER_MARKET SecEligibilityPerMkt [MARKET_TYPES]   ;
} ;
#pragma pack()

#pragma pack(2)
struct NNF_SECURITY_STATUS_UPDATE_BCAST
{
	struct          NNF_HEADER       sHeader                                        ;
	SHORT           NoOfRecords                                                             ;
	struct          NNF_TOKEN_AND_ELIGIBILITY SecTokenAndEligibility[NOOF_SEC_STS_UPD_PER_PKT]                ;
};

#pragma pack()

#pragma pack(2)
struct    NNF_TOKEN_AND_ELIGIBILITY_TNDTC
{
        LONG32          Token                                                           ;  /* Tndtc Changes LONG32 */
        struct          NNF_SEC_STATUS_PER_MARKET SecEligibilityPerMkt [MARKET_TYPES]   ;
} ;
#pragma pack()

#pragma pack(2)
struct NNF_SECURITY_STATUS_UPDATE_BCAST_TNDTC
{
        struct          NNF_HEADER       sHeader                                                ;
        SHORT           NoOfRecords                                                             ;
        struct          NNF_TOKEN_AND_ELIGIBILITY_TNDTC SecTokenAndEligibility[NOOF_SEC_STS_UPD_PER_PKT]                ;
};

#pragma pack()


#pragma pack(2)
struct  NNF_MARKET_STATUS_CHANGE_BCAST
{


	struct          NNF_HEADER       sHeader                                        ;
	struct          NNF_SEC_INFO    SecInfo                 ;
	SHORT           MarketType                                                              ;
	struct          NNF_DESTINATION      Dest                               ;
	SHORT           BcastMsgLength                                                  ;
	CHAR            BcastMsg [BCAST_MSG_LEN]                                ;
} ;
#pragma pack()

# pragma pack(2)
struct  NNF_PARTICIPANT_INFO_RESP
{
	struct          NNF_HEADER           sHeader                            ;
	CHAR            ParticipantId [ PARTICIPANT_ID_LEN]             ;
	CHAR            ParticipantName [PARTICIPANT_NAME_LEN]  ;
	CHAR            ParticipantSts                                                  ;
	LONG32          LastUpdateTime                                                  ;
	CHAR            Delete                                                                  ;
};
#pragma pack()

#pragma pack(2)
struct NNF_SEC_OPEN_BCAST
{
	struct          NNF_HEADER             sHeader                          ;
	struct          NNF_SEC_INFO       SecInfo                              ;
	SHORT               Token                                                                   ;
	LONG32      OpeningPrice                                                        ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_TICKER_INDEX_INFO
{
	SHORT		iToken                                                                   ;
	SHORT           iMarketType                                                              ;
	LONG32          iTradePrice                                                              ;
	LONG32          iTradeVolume                                                             ;
	LONG32          iMarketIndexValue                                                ;
} ;
#pragma pack()

#pragma pack(2)
struct NNF_TICKER_TRADE_BCAST
{
	struct          NNF_HEADER      sHeader    	                                    ;
	SHORT           iNoOfRecords                                                             ;
	struct          NNF_TICKER_INDEX_INFO  TickerIndexInfo[EQU_NSE_TICKER_INFO_PER_PKT] ;
} ;
#pragma pack()

#pragma pack(2)
struct  NNF_TICKER_INDEX_INFO_TNDTC
{
        LONG32          iToken       		 	; /* Tndtc_Change in iToken - LONG32 */
        SHORT           iMarketType                	;
        LONG32          iTradePrice                  	;
        LONG32          iTradeVolume               	;
        LONG32          iMarketIndexValue   	    	;
} ;
#pragma pack()

#pragma pack(2)
struct NNF_TICKER_TRADE_BCAST_TNDTC
{
        struct          NNF_HEADER      sHeader                                                   ;
        SHORT           iNoOfRecords                                                              ;
        struct          NNF_TICKER_INDEX_INFO_TNDTC  TickerIndexInfo[EQU_NSE_TICKER_INFO_PER_PKT] ;
} ;
#pragma pack()


/*-------------------------------------------------------------------------------0
  Bhavcopy Header Transcode[1833]
  ------------------------------------------------------------------------------*/

#pragma pack(2)
struct NNF_MKT_STATS_RPT_HEADER_BCAST
{

	struct          NNF_HEADER  sHeader             ;
	CHAR            MsgType                         ;
	LONG32          RptDate                         ;
	INT16           UserType                        ;
	CHAR            BrokerCode[BROKER_CODE_LEN]     ;
	CHAR            BrokerName[BROKER_NAME_LEN]     ;
	LONG32           TraderNumber                    ;  /** Userid related changes **/
	CHAR            TraderName[TRADER_NAME_LEN]     ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_MKT_STATS_DATA
{

	struct               NNF_SEC_INFO    SecInfo              ;
	INT16                MktType                              ;
	LONG32               OpenPrice                            ;
	LONG32               HighPrice                            ;
	LONG32               LowPrice                             ;
	LONG32               ClosingPrice                         ;
	LONG32               TotalQtyTraded                       ;
	DOUBLE64             TotalValueTraded                     ;
	LONG32               PreviousClosePrice                   ;
	LONG32               FiftyTwoWeekHigh                        ;
	LONG32               FiftyTwoWeekLow                      ;
	CHAR                 CrptActnIndicator[CRPT_ACT_CONST_LEN];
};

#pragma pack()
#pragma pack(2)
struct  NNF_MKT_STATS_RPT_DATA_BCAST
{
	struct          NNF_HEADER       sHeader   ;
	CHAR            MsgType                    ;
	CHAR            Reserved                   ;
	INT16           nNumberOfRecords           ;
	struct          NNF_MKT_STATS_DATA  MktStatsData[DRV_MAX_RECORDS_FOR_MKT_STATS_RPT];

};
#pragma pack()

#pragma pack(2)
struct NNF_INTERACTIVE_MBO_DATA
{
	INT16 iToken            ;
	INT16 iBookType         ;
	INT16 iTradingStatus  ;
	LONG32 iVolumeTradedToday ;
	LONG32  iLastTradedPrice ;
	CHAR cNetChangeIndicator ;
	LONG32 iNetPriceChgFrmClosingPrice ;
	LONG32 iLastTradeQuantity ;
	LONG32 iLastTradeTime ;
	LONG32 iAverageTradePrice ;
	INT16 iAuctionNumber ;
	INT16 iAuctionStatus ;
	INT16 iInitiatorType ;
	LONG32 iInitiatorPrice ;
	LONG32 iInitiatorQuantity ;
	LONG32 iAuctionPrice ;
	LONG32 iAuctionQuantity ;
	struct NNF_MBO_DATA pMBORecords [MBP_NO_OF_RECS];

};
#pragma pack()


#pragma pack(2)
struct BCAST_MBO_MBP_UPDATE
{
	struct          NNF_HEADER       pHeader   ;
	struct 		NNF_INTERACTIVE_MBO_DATA pMboData ;
	struct          NNF_MBP_DATA  pMBPRecords[MBP_NO_OF_RECS];
	INT16 iBbTotalBuyFlag ; 
	INT16 iBbTotalSellFlag ; 
	DOUBLE64 fTotalBuyQuantity ; 
	DOUBLE64  fTotalSellQuantity ;
	struct          NNF_INDICATOR  pIndicators              ;	
	LONG32 iClosingPrice ;
	LONG32 iOpenPrice ; 
	LONG32 iHighPrice ;
	LONG32 iLowPrice ;
};
#pragma pack()

/* --------------------------------------------------------------------- */

#pragma pack(2)
struct NNF_INTERACTIVE_MBO_DATA_TNDTC
{
        LONG32 	iToken            	;	/* Tndtc_Change in iToken - LONG32 */
        INT16 	iBookType         	;
        INT16 	iTradingStatus  	;
        LONG32 	iVolumeTradedToday 	;
        LONG32  iLastTradedPrice 	;
        CHAR 	cNetChangeIndicator 	;
	CHAR    cFiller                 ;	/* Tndtc_Add Filler 1 byte */
        LONG32 	iNetPriceChgFrmClosingPrice ;
        LONG32 	iLastTradeQuantity 	;
        LONG32 	iLastTradeTime 		;
        LONG32 	iAverageTradePrice 	;
        INT16 	iAuctionNumber 		;
        INT16 	iAuctionStatus 		;
        INT16 	iInitiatorType 		;
        LONG32 	iInitiatorPrice 	;
        LONG32 	iInitiatorQuantity 	;
        LONG32 	iAuctionPrice 		;
        LONG32 	iAuctionQuantity 	;
        struct 	NNF_MBO_DATA pMBORecords [MBP_NO_OF_RECS];

};
#pragma pack()


#pragma pack(2)
struct BCAST_MBO_MBP_UPDATE_TNDTC
{
        struct          NNF_HEADER       pHeader   		;
        struct          NNF_INTERACTIVE_MBO_DATA_TNDTC pMboData ;
        struct          NNF_MBP_DATA  pMBPRecords[MBP_NO_OF_RECS];
        INT16 		iBbTotalBuyFlag 		;
        INT16 		iBbTotalSellFlag 		;
        DOUBLE64 	fTotalBuyQuantity 		;
        DOUBLE64  	fTotalSellQuantity	 	;
        struct          NNF_INDICATOR  pIndicators              ;
        LONG32 		iClosingPrice 			;
        LONG32 		iOpenPrice 			;
        LONG32 		iHighPrice 			;
        LONG32 		iLowPrice 			;
};
#pragma pack()



#pragma pack(2)
struct          NNF_MKT_STATS_RPT_TRLR_BCAST
{
	struct          NNF_HEADER      sHeader ;
	CHAR            MsgType                 ;
	LONG32          nNumberOfRecords        ;
	CHAR            Reserved                ;
};
#pragma packV_MAX_RECORDS_FOR_MKT_STATS_RPT

#pragma pack(2)
struct	REDIS_LTP_UPD
{
	LONG32		iToken	;	
	DOUBLE64	fLtp	;
};
#pragma pack()


typedef struct  NNF_MKT_STATS_RPT_DATA_BCAST    NNF_MKT_STATS_RPT_DATA_BCAST;
typedef struct  NNF_MKT_STATS_RPT_TRLR_BCAST    NNF_MKT_STATS_RPT_TRLR_BCAST;
typedef struct  NNF_MKT_STATS_RPT_HEADER_BCAST  NNF_MKT_STATS_RPT_HEADER_BCAST;


/*________________________________BHAVCOPY  ENDS HERE______________________________*/

typedef struct COMPRESSION_BRDCST_DATA		COMPRESSION_BRDCST_DATA ;
typedef struct NNF_MULTIPLE_INDEX_BCAST		NNF_MULTIPLE_INDEX_BCAST;
typedef	struct MS_AUCTION_INQ_DATA		MS_AUCTION_INQ_DATA;
typedef struct NNF_MBP_BCAST			NNF_MBP_BCAST;
typedef struct NNF_GEN_MESSAGE_BCAST            NNF_GEN_MESSAGE_BCAST;
typedef struct NNF_SYSTEM_INFO_BCAST            NNF_SYSTEM_INFO_BCAST;
typedef struct BC_AUCTION_STATUS_CHANGE 	BC_AUCTION_STATUS_CHANGE;
typedef	struct BCAST_MBO_MBP_UPDATE		BCAST_MBO_MBP_UPDATE ;

/*      TYPEDEF TNDTC*/
typedef	struct MS_AUCTION_INQ_DATA_TNDTC	MS_AUCTION_INQ_DATA_TNDTC;
typedef struct BCAST_MBO_MBP_UPDATE_TNDTC       BCAST_MBO_MBP_UPDATE_TNDTC ;
typedef struct NNF_MBP_BCAST_TNDTC              NNF_MBP_BCAST_TNDTC;

BOOL dTC_GENERAL_MSG_BCAST(CHAR *NNFData);
BOOL dTC_SYSTEM_INFORMATION_BCAST(CHAR *NNFData);
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST(CHAR *NNFData);
BOOL dTC_STOCK_STATUS_CHANGE_BCAST(CHAR *NNFData);
BOOL dTC_AUCTION_INQUIRY_MSG (CHAR *NNFData);
BOOL dTC_MARKET_OPEN_MSG_BCAST(CHAR *NNFData);
BOOL dTC_MARKET_OPEN_MSG_BCAST(CHAR *NNFData);
BOOL dTC_AUCTION_STATUS_CHNG(CHAR *NNFData);
BOOL dTC_MARKET_CLOSE_MSG_BCAST(CHAR *NNFData);
BOOL dTC_PREOPEN_SHUTDOWN_BCAST(CHAR *NNFData);
BOOL dTC_PRE_OPEN_ENDED_MSG_BCAST(CHAR *NNFData);
BOOL dTC_PARTICIPANT_INFO_RESP(CHAR *NNFData);
BOOL dTC_POSTCLOSE_BCAST(CHAR *NNFData);
BOOL dTC_MKT_STATS_RPT_BCAST(CHAR *NNFData);
BOOL dTC_SECURITY_OPEN_MSG_BCAST (CHAR *NNFData);
BOOL dTC_TICKER_INDEX_BCAST (CHAR *NNFData);
BOOL dTC_MBP_BCAST (CHAR *NNFData);
BOOL dTC_MKT_STATS_RPT_BCAST (CHAR *NNFData);
BOOL dTC_MBO_MBP_UPDATE_BCAST (CHAR *NNFData);
BOOL dTC_CALL_AUCTION_MBP (CHAR *NNFData);
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST (CHAR *NNFData);

/* -- -- -- -- : TNDTC CHANGES : -- -- -- -- */

BOOL dTC_AUCTION_INQUIRY_MSG_TNDTC (CHAR *NNFData);
BOOL dTC_MBO_MBP_UPDATE_BCAST_TNDTC (CHAR *NNFData);
BOOL dTC_TICKER_INDEX_BCAST_TNDTC (CHAR *NNFData);
BOOL dTC_MBP_BCAST_TNDTC (CHAR *NNFData);
BOOL dTC_CALL_AUCTION_MBP_TNDTC (CHAR *NNFData);
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST_TNDTC(CHAR *NNFData);
BOOL dTC_STOCK_STATUS_CHANGE_BCAST_TNDTC(CHAR *NNFData);


