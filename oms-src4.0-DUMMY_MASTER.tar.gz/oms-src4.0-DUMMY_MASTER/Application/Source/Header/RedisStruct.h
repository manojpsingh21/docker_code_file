#ifndef __REDIS_H__
#define __REDIS_H__


/*--------------------------======= RESPONSE =======--------------------------*/
#define		C_REDIS_OK		"OK"
#define		C_REDIS_QUED		"QUEUED"
#define		C_REDIS_MULTI		"MULTI"	
#define		C_REDIS_EXEC		"EXEC"	

/*--------------------------======= RESPONSE =======--------------------------*/

/*--------------------------======= REDIS BASIC SETS ======-------------------*/
#define		CLORDID_EQ		"CLORDID_EQ"
#define		CLORDID_FO		"CLORDID_FO"
#define		CLORDID_MX		"CLORDID_MX"

#define		SET_CLIENT		"CLIENT"
#define		SET_CLIENT_POS		"CLIENT_POS"
#define		SET_DEALER		"DEALER"


/*----------------------------------------------------------------------------*/

/*--------------------------======= REDIS SETS =======--------------------------*/

#define		SET_ORDERS		"ORD"
#define		SET_ORD_EQ		"EQ"
#define		SET_ORD_FO		"FO"
#define		SET_ORD_MX		"MX"
#define		SET_TRAIL		"TL"
#define		SET_POS			"POS"
#define		SET_BO_ORD		"BO"

#define		SET_EQ_EXCH_NO		"EQ_EXCH"
#define		SET_FO_EXCH_NO		"FO_EXCH"
#define		SET_MX_EXCH_NO		"MX_EXCH"

#define		SET_REQ_SEQ_EQ		"RQEQ"
#define		SET_REQ_SEQ_FO		"RQFO"
#define		SET_REQ_SEQ_MX		"RQMX"

//RMS

#define		SET_SM			"SM"
#define		SET_EQ_BHAVCOPY		"BHEQ"
#define		SET_ERR_MASTER		"ERR"
#define		SET_VAR			"VAR"
#define		SET_FUND_LIMIT		"FUND"
#define		SET_HOLDING		"HOLD"
#define		SET_PROD_MASTER		"PRODUCT"
#define		SET_PROFILE_MASTER	"PROFILE"
#define		SET_SCRIP_BLOCK		"SCRIP_BLOCK"
#define		SET_SEC_LIMIT		"SECLIM"
#define		SET_ENT_MASTER		"ENTM"
#define		SET_SYS_PARAM		"SYS"
#define		SET_FNO_EXP_MAR		"FNO_EXP_MAR"
#define		SET_FNO_SPAN_MAR	"FNO_SPAN_MAR"
#define		SET_RMS_BLCK_LOG	"RMS_BLCK_LOG"
#define		SET_BATCH_PROCESS	"BATCH_PROCESS"

/*--------------------------======= REDIS SETS =======--------------------------*/

/*--------------------------======= SECURITY DATA =======--------------------------*/
#define		SM_EXCHANGE		"SM_EXCHANGE"
#define        	SM_LTP			"SM_LTP" 
#define		SM_SEGMENT		"SM_SEGMENT"
#define		SM_SCRIP_CODE		"SM_SCRIP_CODE"
#define		SM_EXCH_SCRIP_CODE	"SM_EXCH_SCRIP_CODE"
#define		SM_ISIN_CODE		"SM_ISIN_CODE"
#define		SM_EXCH_SYMBOL		"SM_EXCH_SYMBOL"
#define		SM_SYMBOL_NAME		"SM_SYMBOL_NAME"
#define		SM_INSTRUMENT		"SM_INSTRUMENT"
#define		SM_OPTION_TYPE		"SM_OPTION_TYPE"
#define		SM_STRIKE_PRICE		"SM_STRIKE_PRICE"
#define		SM_SERIES		"SM_SERIES"
#define		SM_STATUS		"SM_STATUS"
#define		SM_EXCH_STATUS		"SM_EXCH_STATUS"
#define		SM_MATURITY_DAY		"SM_MATURITY_DAY"
#define		SM_MATURITY_MONYR	"SM_MATURITY_MONYR"
#define		SM_PREOPEN_FLAG		"SM_PREOPEN_FLAG"
#define		SM_PREOPEN_EXCH_FLAG	"SM_PREOPEN_EXCH_FLAG"
#define		SM_ITS_FLAG		"SM_ITS_FLAG"
#define		SM_ALGO_FLAG		"SM_ALGO_FLAG"
#define		SM_CA_FLAG		"SM_CA_FLAG"
#define		SM_FACE_VALUE		"SM_FACE_VALUE"
#define		SM_TICK_SIZE		"SM_TICK_SIZE"
#define		SM_LOT_SIZE		"SM_LOT_SIZE"
#define		SM_LOT_UNITS		"SM_LOT_UNITS"
#define		SM_UPPER_LIMIT		"SM_UPPER_LIMIT"
#define		SM_LOWER_LIMIT		"SM_LOWER_LIMIT"
#define		SM_UND_SCRIP		"SM_UND_SCRIP"

/*--------------------------======= SECURITY DATA =======--------------------------*/

/*--------------------------======= EQUITY REDIS FIELD =======--------------------------*/
#define         ORD_ORDER_NO 		"ORD_ORDER_NO"
#define         ORD_LEG_NO 		"ORD_LEG_NO"
#define         ORD_SERIAL_NO           "ORD_SERIAL_NO"
#define         ORD_SCRIP_CODE          "ORD_SCRIP_CODE"
#define         ORD_EXCH_ID             "ORD_EXCH_ID"
#define         ORD_SEGMENT             "ORD_SEGMENT"
#define         ORD_INSTRUMENT 		"ORD_INSTRUMENT"
#define         ORD_STRIKE_PRICE	"ORD_STRIKE_PRICE"
#define         ORD_ENTITY_ID           "ORD_ENTITY_ID"
#define         ORD_EXCH_ORDER_NO       "ORD_EXCH_ORDER_NO"
#define         ORD_CLIENT_ID           "ORD_CLIENT_ID"
#define         ORD_BUY_SELL_IND        "ORD_BUY_SELL_IND"
#define         ORD_BO_FLAG        	"ORD_BO_FLAG"
#define         ORD_LTP	        	"ORD_LTP"
#define         ORD_PRE_LTP        	"ORD_PRE_LTP"
#define         ORD_GAP        		"ORD_GAP"
#define         ORD_MSG_CODE            "ORD_MSG_CODE"
#define         ORD_ORD_STATUS          "ORD_ORD_STATUS"
#define         ORD_INTERNAL_ENTRY_DATE "ORD_INTERNAL_ENTRY_DATE"
#define         ORD_TOTAL_QTY           "ORD_TOTAL_QTY"
#define         ORD_REM_QTY             "ORD_REM_QTY"
#define         ORD_DISC_QTY            "ORD_DISC_QTY"
#define         ORD_DISC_REM_QTY        "ORD_DISC_REM_QTY"
#define         ORD_TOTAL_TRADED_QTY    "ORD_TOTAL_TRADED_QTY"
#define         ORD_ORDER_PRICE         "ORD_ORDER_PRICE"
#define         ORD_TRIGGER_PRICE       "ORD_TRIGGER_PRICE"
#define         ORD_VALIDITY            "ORD_VALIDITY"
#define         ORD_ORDER_TYPE          "ORD_ORDER_TYPE"
#define         ORD_GOOD_TILL_DAYS      "ORD_GOOD_TILL_DAYS"
#define         ORD_ACC_CODE            "ORD_ACC_CODE"
#define         ORD_USER_ID             "ORD_USER_ID"
#define         ORD_MIN_FILL_QTY        "ORD_MIN_FILL_QTY"
#define         ORD_REMARKS             "ORD_REMARKS"
#define         ORD_PRO_CLIENT          "ORD_PRO_CLIENT"
#define         ORD_ERROR_CODE          "ORD_ERROR_CODE"
#define         ORD_SOURCE_FLG          "ORD_SOURCE_FLG"
#define         ORD_ORDER_OFFON         "ORD_ORDER_OFFON"
#define         ORD_PRODUCT_ID          "ORD_PRODUCT_ID"
#define         ORD_LOC_CODE            "ORD_LOC_CODE"
#define         ORD_GROUP_ID            "ORD_GROUP_ID"
#define         ORD_REASON_CODE         "ORD_REASON_CODE"
#define         ORD_REASON_DESCRIPTION  "ORD_REASON_DESCRIPTION"
#define         ORD_TRD_EXCH_TRADE_NO   "ORD_TRD_EXCH_TRADE_NO"
#define         ORD_TRD_TRADE_TIME      "ORD_TRD_TRADE_TIME"
#define         ORD_TRD_SERIAL_NO       "ORD_TRD_SERIAL_NO"
#define         ORD_TRD_TRANS_CODE      "ORD_TRD_TRANS_CODE"
#define         ORD_TRD_STATUS          "ORD_TRD_STATUS"
#define         ORD_LAST_TRADE_QTY      "ORD_LAST_TRADE_QTY"
#define         ORD_TRD_TRADE_PRICE     "ORD_TRD_TRADE_PRICE"
#define         ORD_TRD_SEQ_NO          "ORD_TRD_SEQ_NO"
#define         ORD_HANDLE_INST         "ORD_HANDLE_INST"
#define         ORD_ALGO_ORDER_NO       "ORD_ALGO_ORDER_NO"
#define         ORD_STRATEGY_ID         "ORD_STRATEGY_ID"
#define         ORD_CLORDID             "ORD_CLORDID"
#define         ORD_ORIG_CLORDID        "ORD_ORIG_CLORDID"
#define         ORD_USER_TYPE           "ORD_USER_TYPE"
#define         ORD_SYMBOL              "ORD_SYMBOL"
#define         ORD_MKT_TYPE            "ORD_MKT_TYPE"
#define         ORD_EXCH_ORDER_TIME     "ORD_EXCH_ORDER_TIME"
#define         ORD_BLOCKED_PRICE	"ORD_BLOCKED_PRICE"
#define         ORD_PRE_ORDER_PRICE     "ORD_PRE_ORDER_PRICE"
#define         ORD_PRE_TRIGGER_PRICE   "ORD_PRE_TRIGGER_PRICE"
#define         ORD_PRE_DISC_QTY        "ORD_PRE_DISC_QTY"
#define         ORD_PRE_TOTAL_QTY       "ORD_PRE_TOTAL_QTY"
#define         ORD_PRE_ORDER_TYPE      "ORD_PRE_ORDER_TYPE"
#define         ORD_PRE_VALIDITY        "ORD_PRE_VALIDITY"
#define         ORD_PRE_MSG_CODE        "ORD_PRE_MSG_CODE"
#define		ORD_AVG_LTP_PRICE	"ORD_AVG_LTP_PRICE"
#define		ORD_AVG_LTP_FLAG	"ORD_AVG_LTP_FLAG"
#define		ORD_SL_AT_FLAG		"ORD_SL_AT_FLAG"
#define         ORD_SL_VAL		"ORD_SL_VAL"
#define		ORD_PB_AT_FLAG		"ORD_PB_AT_FLAG"
#define		ORD_PB_VAL		"ORD_PB_VAL"
/*--------------------------======= EQUITY REDIS FIELD =======--------------------------*/

/*--------------------------======= POSITIONS REDIS FIELD =======--------------------------*/
#define         POS_NET_QTY             "POS_NET_QTY"
#define         POS_NET_VAL             "POS_NET_VAL"
#define         POS_NET_AVG             "POS_NET_AVG"
#define         POS_BUY_QTY             "POS_BUY_QTY"
#define         POS_BUY_VAL             "POS_BUY_VAL"
#define         POS_SELL_QTY            "POS_SELL_QTY"
#define         POS_SELL_VAL            "POS_SELL_VAL"
#define         POS_AVG_BUY             "POS_AVG_BUY"
#define         POS_AVG_SELL            "POS_AVG_SELL"
#define         POS_CFBUY_QTY           "POS_CFBUY_QTY"
#define         POS_CFBUY_VAL           "POS_CFBUY_VAL"
#define         POS_CFSELL_QTY          "POS_CFSELL_QTY"
#define         POS_CFSELL_VAL          "POS_CFSELL_VAL"
#define         POS_CFAVG_BUY           "POS_CFAVG_BUY"
#define         POS_CFAVG_SELL          "POS_CFAVG_SELL"
#define         POS_SEC_EXCH		"POS_SEC_EXCH"
#define         POS_SEC_SEG		"POS_SEC_SEG"
#define         POS_SEC_CODE		"POS_SEC_CODE"
#define         POS_PRODUCT		"POS_PRODUCT"
#define         POS_SYMBOL		"POS_SYMBOL"
#define         POS_UND_SCRIP		"POS_UND_SCRIP"
#define        	POS_MKT_TYPE		"POS_MKT_TYPE"
#define        	POS_INS_NAME		"POS_INS_NAME"


/*--------------------------======= POSITIONS REDIS FIELD =======--------------------------*/

/*==================================BHAVCOPY FIELDS START======================================*/
#define		BC_LTP	                "BC_LTP"


/*==================================BHAVCOPY FIELDS END======================================*/
/*==================================ERROR_MASTER FIELDS======================================*/
#define		ERROR_CODE		"ERROR_CODE"

/*==================================ERROR_MASTER FIELDS======================================*/


/*==================================RMS_EQ_VAR_ELM FIELDS======================================*/

#define		VE_SEC_SYMBOL			"VE_SEC_SYMBOL"
#define		VE_SEC_SERIES_GRP		"VE_SEC_SERIES_GRP"
#define		VE_SCRIP_ID			"VE_SCRIP_ID"
#define		VE_ISIN				"VE_ISIN"
#define		VE_SECURITY_VAR			"VE_SECURITY_VAR"
#define		VE_INDEX_VAR			"VE_INDEX_VAR"
#define		VE_VAR_MARGIN			"VE_VAR_MARGIN"
#define		VE_EXTREME_LOSS_RATE 		"VE_EXTREME_LOSS_RATE"
#define		VE_ADHOC_MARGIN			"VE_ADHOC_MARGIN"
#define		VE_APPLICABLE_MARGIN_RATE 	"VE_APPLICABLE_MARGIN_RATE"
#define		VE_EXCH_ID			"VE_EXCH_ID"
#define		VE_SEM_MCX_LOT			"VE_SEM_MCX_LOT"


/*==================================RMS_EQ_VAR_ELM FIELDS======================================*/


/*==================================RMS_FUND_LIMIT FIELDS======================================*/

#define		FL_CLIENT_ID			"FL_CLIENT_ID"
#define		FL_CASH_BALANCE			"FL_CASH_BALANCE"
#define		FL_BANK_HOLD			"FL_BANK_HOLD"
#define		FL_ADHOC_LIMIT			"FL_ADHOC_LIMIT"
#define		FL_NSE_RECEIVABLES 		"FL_NSE_RECEIVABLES"
#define		FL_BSE_RECEIVABLES 		"FL_BSE_RECEIVABLES"
#define		FL_REALISED_PROFIT		"FL_REALISED_PROFIT"
#define		FL_CASH_UTILIZED		"FL_CASH_UTILIZED"
#define		FL_TYPE				"FL_TYPE"
#define         FL_COLLATERALS                  "FL_COLLATERALS"
/*==================================RMS_FUND_LIMIT FIELDS======================================*/

/*==================================RMS_PRODUCT_MASTER=======================================*/

#define		RMS_PROD_MS_STATUS		"RMS_PROD_MS_STATUS"

/*==================================RMS_PRODUCT_MASTER=======================================*/

/*===================================RMS_SCRIP_BLOCK========================================*/

#define		RMS_SB_STATUS		"RSB_STATUS"
#define		RMS_SB_PROFILE_ID	"RSB_PROFILE_ID"

/*===================================RMS_SCRIP_BLOCK========================================*/

/*====================================BATCH_PROCESS=======================================*/

#define		BP_MODE			"BP_MODE"
#define		BP_STATUS		"BP_STATUS"
#define		BP_REMARKS		"BP_REMARKS"
#define		BP_SCHEDULE_TIME	"BP_SCHEDULE_TIME"
#define		BP_LAST_RUN_DATE	"BP_LAST_RUN_DATE"
#define		BP_NEXT_SCHEDULE_DATE	"BP_NEXT_SCHEDULE_DATE"
#define		BP_DATE			"BP_DATE"
#define		BP_OFF_MKT_STATUS	"BP_OFF_MKT_STATUS"
#define		BP_UPDATED_BY		"BP_UPDATED_BY"

/*====================================BATCH_PROCESS=======================================*/

/*==================================RMS_RISK_PROFILE_MASTER=======================================*/
#define		RPM_CODE		"RPM_CODE"
#define		RPM_NAME		"RPM_NAME"
#define		RPM_ACTIVE		"RPM_ACTIVE"
#define		RPM_VALIDATE		"RPM_VALIDATE"
#define		RPM_MAX_ORD_QTY		"RPM_MAX_ORD_QTY"
#define		RPM_MAX_LOT		"RPM_MAX_LOT"
#define		RPM_MAX_ORD_VALUE	"RPM_MAX_ORD_VALUE"
#define		RPM_MTM_LOSSPER		"RPM_MTM_LOSSPER"
#define		RPM_CNC_SELL_BEN_PER	"RPM_CNC_SELL_BEN_PER"
#define		RPM_EXPO_MAR		"RPM_EXPO_MAR"
#define		RPM_REALIZE_PROFIT	"RPM_REALIZE_PROFIT"
#define		RPM_COLL_FO		"RPM_COLL_FO"
#define		RPM_FUNDLIMITTYPE	"RPM_FUNDLIMITTYPE"
#define		RPM_MTOMSQOFFPER	"RPM_MTOMSQOFFPER"
#define		RPM_MRGN_METHOD_EQ	"RPM_MRGN_METHOD_EQ"
#define		RPM_MRGN_METHOD_FO	"RPM_MRGN_METHOD_FO"
#define		RPM_GEN_MULT		"RPM_GEN_MULT"
#define		RPM_EQ_MAR_TYPE		"RPM_EQ_MAR_TYPE"
#define		RPM_DR_MAR_TYPE		"RPM_DR_MAR_TYPE"
#define		RPM_CD_MAR_TYPE		"RPM_CD_MAR_TYPE"
#define		RPM_COM_MAR_TYPE	"RPM_COM_MAR_TYPE"
#define		RPM_DR_MARGIN		"RPM_DR_MARGIN"
#define		RPM_CD_MARGIN		"RPM_CD_MARGIN"
#define		RPM_COM_MARGIN		"RPM_COM_MARGIN"
#define		RPM_EQ_MARGIN		"RPM_EQ_MARGIN"
#define		RPM_EQ_FACTOR		"RPM_EQ_FACTOR"
#define		RPM_DR_FACTOR		"RPM_DR_FACTOR"
#define		RPM_CD_FACTOR		"RPM_CD_FACTOR"
#define		RPM_COM_FACTOR		"RPM_COM_FACTOR"
#define		RPM_ELM_STATUS		"RPM_ELM_STATUS"
#define		MRGFACTCOM		"MRGFACTCOM"
#define		MRGFACTEQ		"MRGFACTEQ"
#define		MRGFACTDR		"MRGFACTDR"
#define		INTFACTCOM		"INTFACTCOM"
#define		INTFACTEQ		"INTFACTEQ"
#define		INTFACTDR		"INTFACTDR"
#define		RPM_EQ_BASKET		"RPM_EQ_BASKET"
#define		RPM_DR_BASKET		"RPM_DR_BASKET"
#define		RPM_CREATED_BY		"RPM_CREATED_BY"
#define		RPM_CREATED_DATE	"RPM_CREATED_DATE"
#define		INTFACTCD		"INTFACTCD"
#define		MRGFACTCD		"MRGFACTCD"
#define		RPM_PROD_CON_FLG	"RPM_PROD_CON_FLG"

/*==================================RMS_RISK_PROFILE_MASTER=======================================*/

/*==================================REQ SEQ FIELDS=======================================*/
#define		RSE_ORD_NO		"RSE_ORD_NO"
#define		RSE_SERIAL_NO		"RSE_SERIAL_NO"
#define		RSE_SCRIPT_CODE		"RSE_SCRIPT_CODE"
#define		RSE_CLIENT_ID		"RSE_CLIENT_ID"
#define		RSE_MSG_CODE		"RSE_MSG_CODE"
#define		RSE_PRODUCT_ID		"RSE_PRODUCT_ID"
#define		RSE_BUY_SELL_ID		"RSE_BUY_SELL_ID"
#define		RSE_EXCH_ID		"RSE_EXCH_ID"
#define		RSE_SEGMENT		"RSE_SEGMENT"

/*==================================REQ SEQ FIELDS=======================================*/


/*==================================RMS_SECURITY_LIMIT_PRIORITY=======================================*/

#define		SECURITY_SOURCE_TYPE	"SECURITY_SOURCE_TYPE"
#define		SECURITY_SOURCE_FROM	"SECURITY_SOURCE_FROM"
#define		PRIORITY		"PRIORITY"


/*==================================RMS_SECURITY_LIMIT_PRIORITY=======================================*/

/*==================================SYS_PARAMETERS=======================================*/

#define		SYS_PARAM_NAME		"SYS_PARAM_NAME"
#define		SYS_PARAM_VALUE		"SYS_PARAM_VALUE"
#define		SYS_DELETED		"SYS_DELETED"	

/*==================================SYS_PARAMETRS=======================================*/


/*==================================RMS_FNO_EXP_MARGIN=======================================*/

#define		FNOEX_MAR_RFEM_SECURITY_ID	"FNOEX_MAR_RFEM_SECURITY_ID"
#define		FNOEX_MAR_RFEM_SYMBOL_NAME	"FNOEX_MAR_RFEM_SYMBOL_NAME"
#define		FNOEX_MAR_RFEM_EFF_EXP_LIMIT	"FNOEX_MAR_RFEM_EFF_EXP_LIMIT"
#define		FNOEX_MAR_RFEM_UPDATED_DATE	"FNOEX_MAR_RFEM_UPDATED_DATE"
#define		FNOEX_MAR_RFEM_SEGMENT		"FNOEX_MAR_RFEM_SEGMENT"

/*==================================RMS_FNO_EXP_MARGIN=======================================*/


/*==================================RMS_FNO_SPAN_MARGIN=======================================*/

#define		FNOSP_RSM_SECURITY_ID		"FNOSP_RSM_SECURITY_ID"
#define		FNOSP_RSM_SYMBOL_NAME		"FNOSP_RSM_SYMBOL_NAME"
#define		FNOSP_RSM_SPAN_1		"FNOSP_RSM_SPAN_1"
#define		FNOSP_RSM_SPAN_2		"FNOSP_RSM_SPAN_2"
#define		FNOSP_RSM_SPAN_3		"FNOSP_RSM_SPAN_3"
#define		FNOSP_RSM_SPAN_4		"FNOSP_RSM_SPAN_4"
#define		FNOSP_RSM_SPAN_5		"FNOSP_RSM_SPAN_5"
#define		FNOSP_RSM_SPAN_6		"FNOSP_RSM_SPAN_6"
#define		FNOSP_RSM_SPAN_7		"FNOSP_RSM_SPAN_7"
#define		FNOSP_RSM_SPAN_8		"FNOSP_RSM_SPAN_8"
#define		FNOSP_RSM_SPAN_9		"FNOSP_RSM_SPAN_9"
#define		FNOSP_RSM_SPAN_10		"FNOSP_RSM_SPAN_10"
#define		FNOSP_RSM_SPAN_11		"FNOSP_RSM_SPAN_11"
#define		FNOSP_RSM_SPAN_12		"FNOSP_RSM_SPAN_12"
#define		FNOSP_RSM_SPAN_13		"FNOSP_RSM_SPAN_13"
#define		FNOSP_RSM_SPAN_14		"FNOSP_RSM_SPAN_14"
#define		FNOSP_RSM_SPAN_15		"FNOSP_RSM_SPAN_15"
#define		FNOSP_RSM_SPAN_16		"FNOSP_RSM_SPAN_16"
#define		FNOSP_RSM_DELTA			"FNOSP_RSM_DELTA"
#define		FNOSP_RSM_OPTION_PREMIUM	"FNOSP_RSM_OPTION_PREMIUM"
#define		FNOSP_RSP_UPDATED_DATE		"FNOSP_RSP_UPDATED_DATE"
#define		FNOSP_RSM_SPAN_MARGIN		"FNOSP_RSM_SPAN_MARGIN"
#define		FNOSP_RSM_EXPO_MARGIN		"FNOSP_RSM_EXPO_MARGIN"
#define		FNOSP_RSM_INSTRUMENT		"FNOSP_RSM_INSTRUMENT"
#define		FNOSP_RSM_EXPIRY_DATE		"FNOSP_RSM_EXPIRY_DATE"
#define		FNOSP_RSM_STRIKE_PRICE		"FNOSP_RSM_STRIKE_PRICE"
#define		FNOSP_RSM_OPTION_TYPE		"FNOSP_RSM_OPTION_TYPE"
#define		FNOSP_RSM_SOM			"FNOSP_RSM_SOM"
#define		FNOSP_RSM_UNDERLYING_SEC_ID	"FNOSP_RSM_UNDERLYING_SEC_ID"
#define		FNOSP_RSM_UNDERLYING_SYMBOL	"FNOSP_RSM_UNDERLYING_SYMBOL"
#define		FNOSP_RSM_SEGMENT		"FNOSP_RSM_SEGMENT"
#define		FNOSP_RSM_EXCHANGE		"FNOSP_RSM_EXCHANGE"
#define		FNOSP_RSM_DELTA_SPREAD		"FNOSP_RSM_DELTA_SPREAD"
#define		FNOSP_GREATEST			"FNOSP_GREATEST"
#define		FNOSP_SMALLEST			"FNOSP_SMALLEST"

/*==================================RMS_FNO_SPAN_MARGIN=======================================*/

/*==================================RMS_FNO_SPAN_MARGIN=======================================*/

/*==================================RMS_BLOCK_LOG FIELDS======================================*/
#define		RBL_CLIENT_ID 			"RBL_CLIENT_ID"
#define		RBL_SCRIP_CODE			"RBL_SCRIP_CODE"
#define		RBL_ORDBUYSELL			"RBL_ORDBUYSELL"
#define		RBL_ORDQTY			"RBL_ORDQTY"
#define		RBL_ORDERRATE			"RBL_ORDERRATE"
#define		RBL_PRODUCTCODE			"RBL_PRODUCTCODE"
#define		RBL_SEGMENT			"RBL_SEGMENT"
#define		RBL_EXCH_ID			"RBL_EXCH_ID"
#define		RBL_ORDNO			"RBL_ORDNO"
#define		RBL_ORDVERSIONNO		"RBL_ORDVERSIONNO"
#define		RBL_ORDERTYPE			"RBL_ORDERTYPE"
#define		RBL_ORDEXECUTIONSTATUS		"RBL_ORDEXECUTIONSTATUS"
#define		RBL_TRADE_DATE			"RBL_TRADE_DATE"
#define		RBL_MKT_TYPE			"RBL_MKT_TYPE"
#define		RBL_RMS_STATUS			"RBL_RMS_STATUS"
#define		RBL_AMOUNT_BLOCKED		"RBL_AMOUNT_BLOCKED"
#define		RBL_INSUFFICIENT_QTY		"RBL_INSUFFICIENT_QTY"
#define		RBL_INSUFFICIENT_AMT		"RBL_INSUFFICIENT_AMT"
#define		RBL_ORDER_TIMESTAMP		"RBL_ORDER_TIMESTAMP"
#define		RBL_MKT_ORDER			"RBL_MKT_ORDER"
#define		RBL_ORD_TRANS_CODE		"RBL_ORD_TRANS_CODE"
#define		RBL_DESCRIPTOR			"RBL_DESCRIPTOR"

/*=================================MASTERS=======================================*/

#define		ENTITY_CODE			"ENTITY_CODE"
#define		ENTITY_TYPE			"ENTITY_TYPE"
#define		ENTITY_NAME			"ENTITY_NAME"
#define		ENTITY_STATUS			"ENTITY_STATUS"
#define		ENTITY_PAN			"ENTITY_PAN"
#define		ENTITY_EMAIL			"ENTITY_EMAIL"
#define		ENTITY_DOB			"ENTITY_DOB"
#define		ENTITY_NSE_CODE			"ENTITY_NSE_CODE"
#define		ENTITY_RISK_PROFILE		"ENTITY_RISK_PROFILE"
#define		USER_CODE			"USER_CODE"
#define		USER_ENTITY_CODE		"USER_ENTITY_CODE"
#define		USER_STATUS			"USER_STATUS"
#define		USER_UP_PROFILE_ID		"USER_UP_PROFILE_ID"
#define		USER_LOGIN_CODE			"USER_LOGIN_CODE"
#define		USER_LOGOFF_TIME		"USER_LOGOFF_TIME"
#define		USER_LOGIN_TIME			"USER_LOGIN_TIME"
#define		USER_STATIC_IP			"USER_STATIC_IP"
#define		USER_PASSWORD_CNG_DATE		"USER_PASSWORD_CNG_DATE"
#define		USER_PRODUCT_ALLOWED		"USER_PRODUCT_ALLOWED"
#define		USER_EXCH_ALLOWED		"USER_EXCH_ALLOWED"
#define 	USER_INV_PSWD_CHNG_REQ_CNTR 	"USER_INV_PSWD_CHNG_REQ_CNTR"
#define 	USER_VAL_PSWD_CHNG_REQ_CNTR 	"USER_VAL_PSWD_CHNG_REQ_CNTR"
#define 	USER_UNLOCK_PWD_COUNTER		"USER_UNLOCK_PWD_COUNTER"
#define 	USER_INVALID_LOGIN_CTR		"USER_INVALID_LOGIN_CTR"
#define		USER_FORGOT_PWD_CTR		"USER_FORGOT_PWD_CTR"
#define		USER_UNLOCK_PWD_CTR		"USER_UNLOCK_PWD_CTR"
#define 	USER_OLD_PASSWORD		"USER_OLD_PASSWORD"
#define		USER_NEW_PASSWORD		"USER_NEW_PASSWORD"
#define 	USER_TRANS_PASSWORD 		"USER_TRANS_PASSWORD"
#define		USER_TOKEN_ID			"USER_TOKEN_ID"	
#define		ENTITY_SUBSCRIPTION_STATUS	"ENTITY_SUBSCRIPTION_STATUS"
#define		ENTITY_SUBSCRIPTION_EXPIRY	"ENTITY_SUBSCRIPTION_EXPIRY"
#define		ENTITY_DATE_DIFF		"ENTITY_DATE_DIFF"
/*=================================MASTERS=======================================*/
/*=================================RMS_BLOCK_LOG=======================================*/

#define		CLIENT_ID		"CLIENT_ID"
#define		SCRIP_CODE		"SCRIP_CODE"
#define		ORDBUYSELL		"ORDBUYSELL"
#define		ORDQTY			"ORDQTY"	
#define		ORDERRATE		"ORDERRATE"
#define		PRODUCTCODE		"PRODUCTCODE"
#define		SEGMENT			"SEGMENT"
#define		EXCHANGE		"EXCHANGE"
#define		ORDNO			"ORDNO"
#define		ORDVERSIONNO		"ORDVERSIONNO"
#define		ORDERTYPE		"ORDERTYPE"
#define		ORDEXECUTIONSTATUS	"ORDEXECUTIONSTATUS"
#define		TRADE_DATE		"TRADE_DATE"
#define		MKT_TYPE		"MKT_TYPE"
#define		RMS_STATUS		"RMS_STATUS"
#define		AMOUNT_BLOCKED		"AMOUNT_BLOCKED"
#define		INSUFFICIENT_QTY	"INSUFFICIENT_QTY"
#define		INSUFFICIENT_AMT	"INSUFFICIENT_AMT"
#define		ORDER_TIMESTAMP		"ORDER_TIMESTAMP"
#define		MKT_ORDER		"MKT_ORDER"
#define		ORD_TRANS_CODE		"ORD_TRANS_CODE"
/*=================================RMS_BLOCK_LOG=======================================*/
/*=================================RMS_HOLDING=======================================*/
#define		HLD_ISIN_CODE			"HLD_ISIN_CODE"
#define		HLD_EXCH_ID			"HLD_EXCH_ID"
#define		HLD_SECURITY_SOURCE_TYPE	"HLD_SECURITY_SOURCE_TYPE"
#define		HLD_QTY				"HLD_QTY"
#define		HLD_QTY_UTILIZED		"HLD_QTY_UTILIZED"
#define		HLD_CLIENT_ID			"HLD_CLIENT_ID"
#define		HLD_REM_QTY			"HLD_REM_QTY"
#define		HLD_SYMBOL			"HLD_SYMBOL"
#define		HLD_SEC_ID			"HLD_SEC_ID"
/*=================================RMS_HOLDING=======================================*/

/*=================================BANK_DETAIL================================*/
#define         ENTITY_BANK_DETAIL		"EBD"
#define         ACCT_TYPE                   	"ACCT_TYPE"
#define		ACC_NO 			    	"ACC_NO"
#define		EBD_ENTITY_ID			"EBD_ENTITY_ID"
#define		BANK_ID				"BANK_ID"
#define		BANK_NAME			"BANK_NAME"
#define		IFSC_CODE			"IFSC_CODE"
/*=================================BANK_DETAIL===============================*/

/*=================================DPR_DETAILS===============================*/
#define		SET_DPR				"DPR"
#define		SET_L1_WATCH			"SM_L1"	
/*=================================DPR_DETAILS===============================*/

#endif
