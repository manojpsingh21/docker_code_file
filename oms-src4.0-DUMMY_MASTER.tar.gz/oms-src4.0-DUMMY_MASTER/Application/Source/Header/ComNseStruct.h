
#ifndef __NNFDATA_H__
#define __NNFDATA_H__

#define MAX_NO_STREAMS 50 /*** TAP Reg Changes ***/

#define MSG_AREA_DLD_FO_DATA_LEN 436

#define         TWIDDLE(A)              Twiddle((char *) &A, sizeof(A))



/*_____________ALL BRAODCAST STRUCTRES STARTS HERE_________________*/               

/*-----------------------------------------------------------------------------------0
  COMMON STRUCTRES  IN BROADCAST
  0-------------------------------------------------------------------------------------*/


//typedef BOOL (*P_TO_FUN)(CHAR * x, CHAR * y,LONG32 GroupId);

//typedef BOOL (*P_TO_FUN)(CHAR * x);
//typedef BOOL (*P_TO_FUN)(CHAR * x, CHAR * y,LONG32 GroupId);
typedef BOOL  (*P_TO_FUN)(CHAR * x);
#pragma pack(2)
struct TAP_WRAPPER
{
	SHORT   iMsgLen;
	LONG32  iSeqNo;
	unsigned char sDigest[DIGEST_LEN];
};
#pragma pack()

#pragma pack(2)
struct COMPRESSION_BRDCST_DATA
{
	SHORT           temp;
	SHORT           compression_len;
	CHAR            broadcast_data[508];
};

#pragma pack()

typedef struct COMPRESSION_BRDCST_DATA    COMPRESSION_BRDCST_DATA ;


#pragma pack(2)
struct  NNF_HEADER
{
	LONG32          iReserved                     ; /*** Userid related changes ***/
	LONG32          iLogTimeStamp                 ;
	CHAR            sAlphaSplit [ALPHA_SPLIT_LEN] ;
	INT16           iMsgCode                      ;
	INT16           iErrorCode                    ;
	CHAR            sTimeStamp1 [NNF_DATE_TIME_LEN]   ;
	CHAR            sTimeStamp2 [NNF_DATE_TIME_LEN]   ;
	CHAR            sTimeStamp3 [NNF_DATE_TIME_LEN]   ;
	INT16           iMsgLength                    ;
};
#pragma pack()



#pragma pack(2)
struct INVITATION_PACKET
{
	struct	    TAP_WRAPPER tWrapper ;
	struct      NNF_HEADER  sHeader  ;
	SHORT       invitation_count     ;
};
#pragma pack()

#pragma pack(2)
struct NNF_BCAST_HEADER
{
	INT16           Filler                       ;
	INT16		 Filler3		      ; /*** Userid related changes ***/	
	LONG32          iLogTimeStamp                 ;
	CHAR            sAlphaSplit [ALPHA_SPLIT_LEN] ;
	INT16           iMsgCode                      ;
	INT16           iErrorCode                    ;
	LONG32          iBCSeqNo                      ;
	CHAR            cCRC                          ;
	CHAR            Filler1[3]                   ;
	CHAR            cTimeStamp2 [NNF_DATE_TIME_LEN]   ;
	CHAR            Filler2[8]                   ;
	INT16           iMsgLength                    ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_CONTRACT_DESC
{
	CHAR        sInstrumentName[INSTR_NAME_LEN]              ;
	CHAR        sSymbol[SYMBOL_LEN]                          ;
	LONG32      iExpiryDate                                  ;
	LONG32      iStrikePrice                                 ;
	CHAR        sOptionType[OPT_TYPE_LEN]                    ;
	SHORT       iCALevel                                     ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_DESTINATION
{
#ifdef  BIGENDIAN
	USHORT              uiTraderWs              : 1        ;
	USHORT              uiControlWs             : 1        ;
	USHORT              uiTandem                : 1        ;
	USHORT              uiJournalRqd            : 1        ;
	USHORT              uiFiller1               : 4        ;
	USHORT              uiFiller2               : 8        ;
#elif   LITTLEENDIAN
	USHORT              uiFiller1               : 4        ;
	USHORT              uiJournalRqd            : 1        ;
	USHORT              uiTandem                : 1        ;
	USHORT              uiControlWs             : 1        ;
	USHORT              uiTraderWs              : 1        ;
	USHORT              uiFiller2               : 8        ;
#endif
};
#pragma pack()


#pragma pack(2)
struct  NNF_SEC_INFO
{
	CHAR            sInstrumentName [INSTR_NAME_LEN]       ;
	CHAR            sSymbol [SYMBOL_LEN]                   ;
	//        CHAR            Series [SERIES_LEN]                   ;
	LONG32          iExpiryDate                            ;
	LONG32          iStrikePrice                           ;
	CHAR            sOptionType[OPT_TYPE_LEN]              ;
	INT16           iCALevel                               ;
};
#pragma pack()


#pragma pack(2)
struct NNF_INDICATOR
{
#ifdef  BIGENDIAN
	USHORT uiLastTradeMore                 : 1          ;
	USHORT uiLastTradeLess                 : 1          ;
	USHORT uiBuySTI                        : 1          ;
	USHORT uiSellSTI                       : 1          ; 
	USHORT uiFiller1                       : 4          ; 
	USHORT uiFiller2                       : 8          ;
#elif   LITTLEENDIAN
	USHORT uiFiller1                       : 4          ;
	USHORT uiSellSTI                       : 1          ;
	USHORT uiBuySTI                        : 1          ;
	USHORT uiLastTradeLess                 : 1          ;
	USHORT uiLastTradeMore                 : 1          ; 
	USHORT uiFiller2                       : 8          ;

#endif
};
#pragma pack()


/*--------------------------------------------------------------------------0
  1       GENERAL MESSAGE BROADCAST        TransCode(6501)
  0---------------------------------------------------------------------------*/



#pragma pack(2)
struct  NNF_GEN_MESSAGE_BCAST
{
	struct          NNF_HEADER       sHeader                ;
	INT16           iBranchNumber                            ;
	CHAR            sBrokerNumber [ BROKER_CODE_LEN]         ;
	CHAR            sActionCode   [ACTION_CODE_LEN]          ;
	CHAR            sReserved     [26]                       ; /*** TAP Reg Changes***/
	struct          NNF_DESTINATION      Dest               ;
	INT16           iBcastMsgLength                          ;
	CHAR            sBcastMsg [ BCAST_MSG_LEN ]              ;
};
#pragma pack()




/*----------------------------------------------------------------------------0
  2   SECURITY UPDATE INFORMATION        TransCode(7305)
  0------------------------------------------------------------------------------*/

#pragma pack(2)
struct NNF_STOCK_ELIGIBLE_INDICATORS
{
#ifdef  BIGENDIAN
	USHORT               uiParticipateInMktIndex   :1              ;
	USHORT               uiAON                     :1              ;
	USHORT               uiMinFill                 :1              ;
	USHORT               uiFiller                  :5              ;
	USHORT               uiFiller1                 :8              ;
#elif   LITTLEENDIAN
	USHORT               uiFiller                  :5              ;
	USHORT               uiMinFill                 :1              ;
	USHORT               uiAON                     :1              ;
	USHORT               uiParticipateInMktIndex   :1              ;
	USHORT               uiFiller1                 :8              ;
#endif
};
#pragma pack()





#pragma pack(2)
struct    NNF_SEC_ELIGIBILITY_PER_MARKET
{
#ifdef  BIGENDIAN
	USHORT          uiEligibility           :1              ;
	USHORT          uiFiller                :7              ;
	SHORT           iStatus                                 ;
#elif   LITTLEENDIAN
	USHORT          uiFiller                :7              ;
	USHORT          uiEligibility           :1              ;
	SHORT           iStatus                                 ;
#endif
};
#pragma pack()

#pragma pack(2)
struct NNF_PURPOSE
{
#ifdef  BIGENDIAN
	USHORT    uiDividend                         :1                 ;
	USHORT    uiRights                           :1                 ;
	USHORT    uiBonus                            :1                 ;
	USHORT    uiInterest                         :1                 ;
	USHORT    uiAGM                              :1                 ;
	USHORT    uiEGM                              :1                 ;
	USHORT    uiFiller                           :1                 ;
	USHORT    ExerciseStyle                      :1                 ;
	USHORT    ExAllowed                          :1                 ;
	USHORT    ExRejectionAllowed                 :1                 ;
	USHORT    PlAllowed                          :1                 ;
	USHORT    IsThisAsset                        :1                 ;
	USHORT    IsCorporateAdjusted                :1                 ;
	USHORT    uiFiller1                          :3                 ;
#elif   LITTLEENDIAN
	USHORT    ExerciseStyle                      :1                 ;
	USHORT    uiFiller                           :1                 ;
	USHORT    uiEGM                              :1                 ;
	USHORT    uiAGM                              :1                 ;
	USHORT    uiInterest                         :1                 ;
	USHORT    uiBonus                            :1                 ;
	USHORT    uiRights                           :1                 ;
	USHORT    uiDividend                         :1                 ;
	USHORT    uiFiller1                          :3                 ;
	USHORT    IsCorporateAdjusted                :1                 ;
	USHORT    IsThisAsset                        :1                 ;
	USHORT    PlAllowed                          :1                 ;
	USHORT    ExRejectionAllowed                 :1                 ;
	USHORT    ExAllowed                          :1                 ;
#endif
};
#pragma pack()




#pragma pack(2)
struct NNF_SECURITY_UPDATE_BCAST
{

	struct          NNF_HEADER       sHeader               ;
	LONG32          iToken                                  ;
	struct          NNF_SEC_INFO  SecInfo                  ;
	//        INT16           PermittedToTrade                       ;
	SHORT		iPermittedToTrade			;	
	DOUBLE64        fIssuedCapital                          ;
	LONG32          iWarningPercent                         ; 
	LONG32          iFreezePercent                          ;
	CHAR            sCreditRating [CREDIT_RATING_LEN]       ;
	struct          NNF_SEC_ELIGIBILITY_PER_MARKET  SecEligibilityPerMkt[MARKET_TYPES];
	SHORT           iIssueRate                               ;
	LONG32          iIssueStartDate                          ;
	LONG32          iIssuePDate                              ;
	LONG32          iIssueMaturityDate                       ;
	LONG32          iMarginPercentage                        ;
	LONG32          iMinLotQty                               ;
	LONG32          iBoardLotQty                             ;
	LONG32          iTickSize                                ;
	CHAR            sSecurityName[SEC_DESC_LEN]              ;
	CHAR            Filler                                  ;
	LONG32          iListingDate                             ;
	LONG32          iExpulsionDate                           ;
	LONG32          iReAdmissionDate                         ; 
	LONG32          iRecordDate                              ;
	LONG32          iLowPriceRange                           ;
	LONG32          iHighPriceRange                          ;
	LONG32          iExDate                                  ;
	LONG32          iNoDeliveryStartDate                     ;
	LONG32          iNoDeliveryEndDate                       ;
	struct         	NNF_STOCK_ELIGIBLE_INDICATORS  StockEligibleIndicator;
	LONG32          iBookClosureStartDate                    ;
	LONG32          iBookClosureEndDate                      ;
	LONG32          iExerciseStartDate                       ;
	LONG32          iExerciseEndDate                         ;
	LONG32           iOldToken                                ;
	CHAR            sAssetInstrument[INSTR_NAME_LEN]         ;
	CHAR            sAssetName[DRV_ASSET_NAME_LEN]               ;
	LONG32           iAssetToken                              ;
	LONG32          iIntrinisicValue                         ;
	LONG32          iExtrinisicValue                         ; 
	struct          NNF_PURPOSE        Purpose              ;
	LONG32          iLocalUpdateDateTime                     ;
	CHAR            cDeleteFlag                              ;
	CHAR            sRemark[OE_REMARKS_LEN]              	;
	LONG32     	iBasePrice                               ; 

};
#pragma pack()



#pragma pack(2)
struct NNF_COMM_SECURITY_UPDATE_BCAST
{

        struct          NNF_HEADER       sHeader               ;
        LONG32          iToken                                  ;
        struct          NNF_SEC_INFO  SecInfo                  ;
        //        INT16           PermittedToTrade                       ;
        SHORT           iPermittedToTrade                       ;
        DOUBLE64        fIssuedCapital                          ;
        LONG32          iWarningPercent                         ;
        LONG32          iFreezePercent                          ;
        CHAR            sCreditRating [CREDIT_RATING_LEN]       ;
        struct          NNF_SEC_ELIGIBILITY_PER_MARKET  SecEligibilityPerMkt[MARKET_TYPES];
        SHORT           iIssueRate                               ;
        LONG32          iIssueStartDate                          ;
        LONG32          iIssuePDate                              ;
        LONG32          iIssueMaturityDate                       ;
        LONG32          iMarginPercentage                        ;
        LONG32          iMinLotQty                               ;
        LONG32          iBoardLotQty                             ;
        LONG32          iTickSize                                ;
        CHAR            sSecurityName[SEC_DESC_LEN]              ;
        CHAR            Filler                                  ;
        LONG32          iListingDate                             ;
        LONG32          iExpulsionDate                           ;
        LONG32          iReAdmissionDate                         ;
        LONG32          iRecordDate                              ;
        LONG32          iLowPriceRange                           ;
        LONG32          iHighPriceRange                          ;
        LONG32          iExDate                                  ;
        LONG32          iNoDeliveryStartDate                     ;
        LONG32          iNoDeliveryEndDate                       ;
        struct          NNF_STOCK_ELIGIBLE_INDICATORS  StockEligibleIndicator;
        LONG32          iBookClosureStartDate                    ;
        LONG32          iBookClosureEndDate                      ;
        LONG32          iExerciseStartDate                       ;
        LONG32          iExerciseEndDate                         ;
        LONG32           iOldToken                                ;
        CHAR            sAssetInstrument[INSTR_NAME_LEN]         ;
        CHAR            sAssetName[DRV_ASSET_NAME_LEN]               ;
        LONG32           iAssetToken                              ;
	LONG32          iIntrinisicValue                         ;
        LONG32          iExtrinisicValue                         ;
        struct          NNF_PURPOSE        Purpose              ;
        LONG32          iLocalUpdateDateTime                     ;
        CHAR            cDeleteFlag                              ;
        CHAR            sRemark[OE_REMARKS_LEN]                 ;
        LONG32          iBasePrice                               ;

};
#pragma pack()

/*-----------------------------------------------------------------------------0
  3  SYSTEM INFORMATIOM DATA                TransCode(7206)
  0-------------------------------------------------------------------------------*/


#pragma pack(2)
struct  NNF_MARKET_STATUS
{
	INT16           iNormal                                       ;
	INT16           iOddlot                                       ;
	INT16           iSpot                                         ;
	INT16           iAuction                                      ;
};
#pragma pack()

#pragma pack(2)
struct   NNF_EX_MKT_STATUS
{
	INT16           iNormal                                       ;
	INT16           iOddlot                                       ;
	INT16           iSpot                                         ;
	INT16           iAuction                                      ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_PL_MKT_STATUS
{
	INT16           iNormal                                       ;
	INT16           iOddlot                                       ;
	INT16           iSpot                                         ;
	INT16           iAuction                                      ;
};
#pragma pack()

#pragma pack(2)
struct NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS
{
#ifdef  BIGENDIAN
	USHORT               uiAON           :1                         ;
	USHORT               uiMinFill       :1                         ;
	USHORT               uiBooksMerged   :1                         ;
	USHORT               uiFiller        :5                         ;
	USHORT               uiFiller1       :8                         ;
#elif   LITTLEENDIAN
	USHORT               uiFiller        :5                         ;
	USHORT               uiBooksMerged   :1                         ;
	USHORT               uiMinFill       :1                         ;
	USHORT               uiAON           :1                         ;
	USHORT               uiFiller1       :8                         ;
#endif
};
#pragma pack()

#pragma pack(2)
struct NNF_SYSTEM_INFO_BCAST 
{
	struct          NNF_HEADER sHeader                              ;
	struct          NNF_MARKET_STATUS MarketStatus                  ;
	struct          NNF_EX_MKT_STATUS   sExStatus                   ;
	struct          NNF_PL_MKT_STATUS   sPlStatus                   ;
	CHAR            cUpdatePortFolio                                 ; 
	LONG32          iMktIndex                                        ;
	INT16           iDefaultSettNormal                               ;
	INT16           iDefaultSettSpot                                 ;
	INT16           iDefaultSettAuction                              ;
	INT16           iCompetitorPeriod                                ;
	INT16           iSolicitorPeriod                                 ;
	INT16           iWarnigPercent                                   ;
	INT16           iVolFreezePercent                                ;
	LONG32          iReserved                                        ;
	LONG32          iBoardLotQty                                     ; 
	LONG32          iTickSize                                        ;
	INT16           iMaxGtcDays                                      ;
	struct          NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS     StockEligibilityInd;
	INT16           iDiscQty                                         ;
	LONG32         	iRiskFreeInterestRate                            ;
};
#pragma pack()




/*-----------------------------------------------------------------------------0
  4        PARTICIPANT_UPDATE_INFO   TransCode(7306)
  0-------------------------------------------------------------------------------*/


#pragma pack(2)
struct  NNF_PARTICIPANT_INFO_RESP
{
	struct          NNF_HEADER           sHeader                    ;
	CHAR            ParticipantId [ PARTICIPANT_ID_LEN]             ;
	CHAR            ParticipantName [PARTICIPANT_NAME_LEN]          ;
	CHAR            ParticipantSts                                  ;
	LONG32          LastUpdateTime                                  ;
	CHAR            Delete                                          ;
};
#pragma pack()
/*-----------------------------------------------------------------------------0
  5  SECUTITY STATUS UPDATE INFORMATION TransCode(7320,7322)
  0------------------------------------------------------------------------------*/


#pragma pack(2)
struct NNF_SEC_STATUS_PER_MARKET
{
	SHORT       Status                               ;
};
#pragma pack()

#pragma pack(2)
struct    NNF_TOKEN_AND_ELIGIBILITY
{
	LONG32          iToken                            ;
	struct          NNF_SEC_STATUS_PER_MARKET   SecEligibilityPerMkt[MARKET_TYPES]   ;
} ;
#pragma pack()


#pragma pack(2)
struct NNF_SECURITY_STATUS_UPDATE_BCAST
{
	struct          NNF_HEADER       sHeader                        ;
	SHORT           NoOfRecords                                     ;
	struct         NNF_TOKEN_AND_ELIGIBILITY   SecTokenAndEligibility[NOOF_SEC_STS_UPD_PER_PKT];
};
#pragma pack()


/*---------------------------------------------------------------------------------0
  6       TURN OVER LIMIT EXCEEDED/REACTIVATED  TransCode(9010,9011)
  0-----------------------------------------------------------------------------------*/



#pragma pack(2)
struct NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST
{
	struct          NNF_BCAST_HEADER       sHeader           ;
	CHAR            BrokerCode [ BROKER_CODE_LEN ]                ;
	CHAR            CounterBCode[ BROKER_CODE_LEN  ]              ;
	SHORT           WarningType                                   ;
	CHAR            Symbol [SYMBOL_LEN]                           ;
	CHAR            Series [SERIES_LEN]                           ;
	LONG32          TradeNum                                      ;
	LONG32          TradePrice                                    ;
	LONG32          TradeVol                                      ;
	CHAR            Final                                         ;
};
#pragma pack()


/*-------------------------------------------------------------------------------------0
  7           MARKET STATUS         TransCodes(6511,6521,6531,6571,6522) 
  0--------------------------------------------------------------------------------------*/


#pragma pack(2)
struct  NNF_MARKET_STATUS_CHANGE_BCAST
{


	struct          NNF_BCAST_HEADER       sBcastHeader     ;
	LONG32           iToken                                   ;
	struct          NNF_SEC_INFO    SecInfo                 ;
	SHORT           iMarketType                              ; 
	struct          NNF_DESTINATION      Dest               ;
	SHORT           iBcastMsgLength                          ;
	CHAR            sBcastMsg [BCAST_MSG_LEN]                ;
} ;
#pragma pack() 



/*--------------------------------------------------------------------------0
  8      TICKER AND MARKET INDEX         TransCode(7202)
  0----------------------------------------------------------------------------*/
#pragma pack(2)
struct  NNF_TICKER_INDEX_INFO
{
	LONG32           iToken                     ;
	SHORT           iMarketType                ; 
	LONG32          iTradePrice                ;
	LONG32          iTradeVolume               ;
	LONG32          iOpenInterest              ; 
	LONG32          iDayHiOpenInt              ;
	LONG32          iDayLowOpenInt              ;
} ;
#pragma pack()

#pragma pack(2)
struct NNF_TICKER_TRADE_BCAST
{
	struct          NNF_BCAST_HEADER     sHeader                ;
	SHORT           iNoOfRecords                                      ;
	struct          NNF_TICKER_INDEX_INFO  TickerIndexInfo[FO_NSE_TICKER_INFO_PER_PKT] ;
} ;
#pragma pack()


/*----------------------------------------------------------------------------0
  9           MBP/MBO UPDATE         TransCode(7200) 
  0-----------------------------------------------------------------------------*/

#pragma pack(2)
struct NNF_MBO_SP_TERMS
{
#ifdef  BIGENDIAN
	USHORT uiMf                           :1          ;
	USHORT uiAon                          :1          ;
	USHORT uiFiller1                      :6          ;
	USHORT uiFiller2                      :8          ;
#elif   LITTLEENDIAN
	USHORT uiFiller1                      :6          ;
	USHORT uiAon                          :1          ;
	USHORT uiMf                           :1          ;
	USHORT uiFiller2                      :8          ;
#endif
};
#pragma pack()


#pragma pack(2)
struct NNF_MBO_DATA
{
	LONG32           TraderId                       ;  /*** Userid related changes ***/
	LONG32          Qty                            ;
	LONG32          Price                          ;  
	struct          NNF_MBO_SP_TERMS MboSpTerms    ;                         
	LONG32          MinFillQty                     ;
};
#pragma pack()



#pragma pack(2)
struct NNF_MBO_COMMON_DATA
{
	LONG32           Token                               ;
	SHORT           BookType                            ;
	SHORT           TradingStatus                       ;
	LONG32          VolTradedToday                      ;
	LONG32          LastTradedPrice                     ;
	CHAR            NetChangeIndicator                  ;
	LONG32          NetPriceChange                      ;
	LONG32          LastTradeQty                        ;
	LONG32          LastTradeTime                       ;
	LONG32          AverageTradePrice                   ;
	SHORT           AuctionNumber                       ;
	SHORT           AuctionStatus                       ;
	SHORT           InitiatorType                       ;
	LONG32          InitiatorPrice                      ;
	LONG32          InitiatorQty                        ;
	LONG32          AuctionPrice                        ; 
	LONG32          AuctionQty                          ; 
	struct          NNF_MBO_DATA  MBORecords[MBO_NO_OF_RECS] ;
};
#pragma pack()

#pragma pack(2)
struct NNF_MBP_DATA
{
	LONG32          Qty                                ; 
	LONG32          Price                              ;
	SHORT           NoOfOrders                         ;
};
#pragma pack()

#pragma pack(2)
struct NNF_MBO_MBP_BCAST
{
	struct          NNF_HEADER     sHeader                     ;
	struct          NNF_MBO_COMMON_DATA MboCommonData          ;
	struct          NNF_MBP_DATA    MBPRecords[MBP_NO_OF_RECS] ;
	DOUBLE64        TotalBuyQty                                ;
	DOUBLE64        TotalSellQty                               ; 
	struct          NNF_INDICATOR  Indicators                  ;
	LONG32      	ClosePrice                                 ;
	LONG32      	OpenPrice                                  ;
	LONG32      	HighPrice                                  ;
	LONG32      	LowPrice                                   ;
};
#pragma pack()



/*-----------------------------------------------------------------------------0
  10         MKT WATCH UPDATE          TransCode(7201)
  0-------------------------------------------------------------------------------*/
#pragma pack(2)
struct       NNF_MKT_WISE_INFO
{
	struct               NNF_INDICATOR   Indicators     ;
	LONG32               BuyVolume                      ; 
	LONG32               BuyPrice                       ;
	LONG32               SellVolume                     ;
	LONG32               SellPrice                      ; 
	LONG32               LastTradePrice                 ;
	LONG32               LastTradeTime                  ;

};
#pragma pack()


#pragma pack(2)
struct  NNF_MKTWATCH_DATA
{
	LONG32        Token                         ; 
	struct       NNF_MKT_WISE_INFO MktWiseInfo[NOOF_MKTS_FOR_MW];
	LONG32       OpenInterest; 
};
#pragma pack()

#pragma pack(2)
struct  NNF_MKTWATCH_BCAST
{
	struct          NNF_BCAST_HEADER       sBcastHeader;
	SHORT           NoOfRecords                        ;
	struct          NNF_MKTWATCH_DATA MktWatchBcast[MKTWATCH_NO_OF_RECS];
};
#pragma pack()

/*--------------------------------------------------------------------------0
  11         SECURITY OPEN MESSAGES         TransCode(6013)         
  0---------------------------------------------------------------------------*/

#pragma pack(2)
struct NNF_SEC_OPEN_BCAST
{
	struct          NNF_HEADER             sHeader      ;
	CHAR            sSymbol [SYMBOL_LEN]                 ;
	CHAR            sSeries [SERIES_LEN]                 ;
	LONG32           iToken                               ;
	LONG32          iOpeningPrice                        ;
	LONG32          iFiller                              ;  
};
#pragma pack()

/*-----------------------------------------------------------------------------0
  12                BROADCAST CKT CHECK    TransCode(6541)
  0------------------------------------------------------------------------------*/

#pragma pack(2)
struct  NNF_BCAST_CKT_ALIVE

{
	struct          NNF_HEADER             sHeader      ;
};
#pragma pack()




/*--------------------------------------------------------------------------0
  13                  MULTIPLE INDEX INQUIRY  TransCode(7207)
  0---------------------------------------------------------------------------*/

#pragma pack(2)
struct  DRV_NNF_INDICES_DATA
{
	CHAR            IndexName[DRV_INDEX_NAME_LEN]        ;
	LONG32          IndexValue                       ;
	LONG32          HighIndexValue                   ;
	LONG32          LowIndexValue                    ;
	LONG32          OpeningIndex                     ;
	LONG32          ClosingIndex                     ;
	LONG32          PercentChange                    ;
	LONG32          YearlyHigh                       ;
	LONG32          YearlyLow                        ;
	LONG32          NoOfUpmoves                      ;
	LONG32          NoOfDownmoves                    ;
	DOUBLE64        MarketCapitalisation             ;
	CHAR            NetChangeIndicator               ;
};
#pragma pack()


#pragma pack(2)
struct  DRV_NNF_MULTIPLE_INDEX_BCAST
{
	struct  NNF_HEADER                      sHeader;
	INT16                                   nNumberOfRecords;
	struct  DRV_NNF_INDICES_DATA        sIndicesData[DRV_MAX_RECORDS_FOR_INDICES];
};
#pragma pack()


/*---------------------------------------------------------------------------0
  14           INDUSTRY  INDEX BROADCAST        Trans Code(7203)
  0----------------------------------------------------------------------------*/

#pragma pack(2)
struct NNF_INDUSTRY_INDICES
{
	CHAR            IndustryName [INDUSTRY_NAME_LEN]                ;
	LONG32          IndexValue                                      ;
};
#pragma pack()

#pragma pack(2)
struct NNF_INDUSTRY_INDICES_BCAST
{
	struct          NNF_HEADER       sHeader           ;
	SHORT           NoOfRecs                           ;
	struct          NNF_INDUSTRY_INDICES Industry[NOOF_IND_INDICES_PER_PKT ]     ; 
};
#pragma pack()

/*---------------------------------------------------------------------------0
  15           INSTRUMENT_UPDATE_INFO  INDEX BROADCAST        Trans Code(7324)
  0----------------------------------------------------------------------------*/
#pragma pack(2)
struct NNF_INSTRUMENT_UPDATE_INFO_BCAST
{
	struct          NNF_HEADER       sHeader           ;
	INT16           InstrumentId;
	CHAR            InstrumentName [INSTR_NAME_LEN]   ;
	CHAR            InstDescription [INSTR_DESC_LEN]   ;
	LONG32          InstUpdateTime;
	CHAR            DeleteFlag;
};
#pragma pack()


/*---------------------------------------------------------------------------0
  16           SPREAD MKT_BY_PRICE  Trans Code(7211)
  0----------------------------------------------------------------------------*/

#pragma pack(2)
struct  NNF_SPD_MBP_BUY
{
	INT16 	BuyNoOfOrders;
	LONG32  BuyQty;
	LONG32  BuyPrice;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SPD_MBP_SELL
{
	INT16 	SellNoOfOrders;
	LONG32  SellQty;
	LONG32  SellPrice;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SPD_TOTAL_ORD_VOL
{
	DOUBLE64  TotalBuyVol;
	DOUBLE64  TotalSellVol;
};
#pragma pack()

#pragma pack(2)
struct NNF_SUB_SPREAD_MBP
{
	struct NNF_BCAST_HEADER sHeader; 
	LONG32   	iTokenEarl;
	LONG32   	iTokenLat;
	SHORT   	MbpBuy;
	SHORT   	MbpSell;
	LONG32  	LastTradedTime;
	LONG32  	LastTradedVol;
	DOUBLE64    TotalTradedVol;
	struct      NNF_SPD_MBP_BUY 	sSpreadMbpBuy[NO_OF_SPD_RECS]   ;   
	struct      NNF_SPD_MBP_SELL    sSpreadMbpSell[NO_OF_SPD_RECS]  ;
	struct      NNF_SPD_TOTAL_ORD_VOL sSpreadTotalOrderVol      ;

	/***************** DAY SPREAD ORDER **************/
	LONG32      OpenPriceDiff ;
	LONG32      DayHighPriceDiff;
	LONG32      DayLowPriceDiff;
	LONG32      LastTradePriceDiff;	
	/************************************************/
	LONG32      LastUpdateTime;
};
#pragma pack()

#pragma pack(2)
struct NNF_SPREAD_MBP_BCAST
{

	/*	 struct     NNF_HEADER       sHeader           ; */
	struct     NNF_BCAST_HEADER  sHeader ;                             /** As Per the NNF Changes Doc SPREAD DAY ORD **/
	struct 	NNF_SUB_SPREAD_MBP        sSpreadMbp        ;

};
#pragma pack()

/*---------------------------------------------------------------------------0
  17           MKT_BY_PRICE  Trans Code(7208)
  0----------------------------------------------------------------------------*/
#pragma pack(2)
struct NNF_MBP_INFO
{
	LONG32      iQty                                     ;
	LONG32      iPrice                                   ;
	SHORT       iNoOfOrders                              ;
	SHORT       iBbBuySellFlg                            ;
};
#pragma pack()

#pragma pack(2)
struct NNF_MBP_INTERACTIVE
{
	LONG32       iToken                                   ;
	SHORT       iBookType                                ;
	SHORT       iTradingStatus                           ; 
	LONG32      iVolTradedToday                          ;
	LONG32      iLastTradedPrice                         ;
	CHAR        cNetChangeIndicator                      ;
	LONG32      iNetPriceChange                          ;
	LONG32      iLastTradeQty                            ;
	LONG32      iLastTradeTime                           ;
	LONG32      iAverageTradePrice                       ;
	SHORT       iAuctionNumber                           ;
	SHORT       iAuctionStatus                           ;
	SHORT       iInitiatorType                           ;
	LONG32      iInitiatorPrice                          ;
	LONG32      iInitiatorQty                            ;
	LONG32      iAuctionPrice                            ;
	LONG32      iAuctionQty                              ; 
	struct      NNF_MBP_INFO  MBPRecords[MBP_NO_OF_RECS];
	SHORT       iBbTotalBuyFlg                           ;
	SHORT       iBbTotalSellFlg                          ;
	DOUBLE64    fTotalBuyQty                             ;
	DOUBLE64    fTotalSellQty                            ;
	struct      NNF_INDICATOR  Indicators               ;
	LONG32      iClosePrice                              ; 
	LONG32      iOpenPrice                               ;
	LONG32      iHighPrice                               ;
	LONG32      iLowPrice                                ;
};
#pragma pack()

#pragma pack(2)
struct NNF_MBP_BCAST
{
	struct      NNF_HEADER      sHeader         ;
	SHORT       iNoOfRecords;
	struct      NNF_MBP_INTERACTIVE     MBPInfo[MAX_INT_MBP_RECS];
};
#pragma pack()

/*---------------------------------------------------------------------------0
  18           MKT_MVMT_OPEN_INTEREST_BCAST  Trans Code(7130)
  0----------------------------------------------------------------------------*/
#pragma pack(2)
struct  NNF_SUB_OI
{
	LONG32   Token;
	LONG32  CurrentOI;
};
#pragma pack()

#pragma pack(2)
struct  NNF_ASSET_OI
{
	struct      NNF_HEADER      sHeader     ;
	struct      NNF_SUB_OI      sOpenInt[77]; /*** TAP Reg Changes ***/
};
#pragma pack()


/*---------------------------------------------------------------------------0
  19           SPREAD_MASTER_CHG_BCAST  Trans Code(7309)  ** SPREAD DAY ORDER **
  0----------------------------------------------------------------------------*/

#pragma pack(2)
struct    NNF_SPD_ELIGIBILITY
{
#ifdef  BIGENDIAN
	USHORT          uiEligibility           :1              ;
	USHORT          uiFiller                :7              ;
#elif   LITTLEENDIAN
	USHORT          uiFiller                :7              ;
	USHORT          uiEligibility           :1              ;
#endif
};
#pragma pack()


#pragma pack(2)
struct NNF_SPREAD_MASTER_CHG_BCAST
{
	struct      NNF_HEADER      sHeader     ;
	LONG32        Token1;
	LONG32        Token2;
	struct        NNF_SEC_INFO  SecInfo1                  ;
	struct        NNF_SEC_INFO  SecInfo2                  ;
	LONG32        ReferencePrice                          ;
	LONG32        DayLowPriceDiffRange		      ;
	LONG32	      DayHighPriceDiffRange                   ;
	LONG32        OpLowPriceDiffRange                     ;
	LONG32        OpHighPriceDiffRange                    ;
	struct        NNF_SPD_ELIGIBILITY   SpdEligibility    ;
	CHAR 	      DeleteFlag ;
}; 
#pragma pack()

#pragma pack(2)
struct NNF_MS_BCAST_TRADE_EXECUTION_RANGE
{
	struct		NNF_BCAST_HEADER	sHeader		;
	struct		NNF_TRADE_EXECUTION_RANGE_DATA	*sTradeRange ; 
};
#pragma pack()

#pragma pack(2)
struct NNF_TRADE_EXECUTION_RANGE_DATA
{
	LONG32		iMsgCount			    ;
	struct		NNF_TRADE_EXECUTION_RANGE_DETAILS *sTrExcuRange[MAX_TRADE_RANGE_DATA] ;
};
#pragma pack()

#pragma pack(2)
struct NNF_TRADE_EXECUTION_RANGE_DETAILS
{
	LONG32		iTokenNumber		;
	LONG32		iHighExecBand		;
	LONG32		iLowExecBand		;
};
#pragma pack()


/************************** End of Addition for NNF Version 4.9.3 *************************/

typedef struct  NNF_HEADER                          NNF_HEADER                        ;
typedef struct  NNF_MBO_MBP_BCAST                   NNF_MBO_MBP_BCAST                 ;
typedef struct  NNF_MKTWATCH_BCAST                  NNF_MKTWATCH_BCAST                ;
typedef struct  NNF_SEC_OPEN_BCAST                  NNF_SEC_OPEN_BCAST                ;
typedef struct  NNF_BCAST_CKT_ALIVE                 NNF_BCAST_CKT_ALIVE               ;
typedef struct  NNF_SPREAD_MBP_BCAST                NNF_SPREAD_MBP_BCAST              ;
typedef struct  NNF_GEN_MESSAGE_BCAST     	    	NNF_GEN_MESSAGE_BCAST             ;
typedef struct  NNF_SYSTEM_INFO_BCAST               NNF_SYSTEM_INFO_BCAST             ;
typedef struct  NNF_TICKER_TRADE_BCAST              NNF_TICKER_TRADE_BCAST            ;
typedef struct  NNF_SECURITY_UPDATE_BCAST           NNF_SECURITY_UPDATE_BCAST         ;
typedef struct  NNF_PARTICIPANT_INFO_RESP           NNF_PARTICIPANT_INFO_RESP         ;
typedef struct  NNF_INDUSTRY_INDICES_BCAST          NNF_INDUSTRY_INDICES_BCAST        ; 
typedef struct  DRV_NNF_MULTIPLE_INDEX_BCAST        DRV_NNF_MULTIPLE_INDEX_BCAST      ;
typedef struct  NNF_MARKET_STATUS_CHANGE_BCAST      NNF_MARKET_STATUS_CHANGE_BCAST    ;
typedef struct  NNF_SECURITY_STATUS_UPDATE_BCAST    NNF_SECURITY_STATUS_UPDATE_BCAST  ;
typedef struct  NNF_INSTRUMENT_UPDATE_INFO_BCAST    NNF_INSTRUMENT_UPDATE_INFO_BCAST  ;
typedef struct	NNF_MS_BCAST_TRADE_EXECUTION_RANGE  NNF_MS_BCAST_TRADE_EXECUTION_RANGE ;
typedef struct  NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST NNF_TLIMIT_EXCEEDED_ACTIVATED_BCAST;
typedef struct  NNF_MBP_BCAST                       NNF_MBP_BCAST                     ;
typedef struct  NNF_ASSET_OI                        NNF_ASSET_OI                      ;
typedef struct  NNF_SPREAD_MASTER_CHG_BCAST         NNF_SPREAD_MASTER_CHG_BCAST       ; 


/*_________________________ALL BROADCAST STRUCTRES END HERE____________________________*/



/*________________________________BHAV COPY  STARTS HERE______________________________*/


/*----------------------------------------------------------------------------------------0
  BHAV COPY HEADER   Transcode(1833)
  0-----------------------------------------------------------------------------------------*/ 

#pragma pack(2)
struct NNF_MKT_STATS_RPT_HEADER_BCAST
{

	struct          NNF_HEADER  sHeader             ; 
	CHAR            MsgType                         ; 
	LONG32          RptDate                         ;
	INT16           UserType                        ;
	CHAR            BrokerCode[BROKER_CODE_LEN]     ;
	CHAR            BrokerName[BROKER_NAME_LEN]     ;
	LONG32           TraderNumber                    ;  /** Userid related changes **/
	CHAR            TraderName[TRADER_NAME_LEN]     ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_MKT_STATS_DATA
{

	struct               NNF_CONTRACT_DESC    SecInfo              ;
	INT16                iMktType                              ;
	LONG32               iOpenPrice                            ;
	LONG32               iHighPrice                            ;
	LONG32               iLowPrice                             ;
	LONG32               iClosingPrice                         ;
	LONG32               iTotalQtyTraded                       ;
	DOUBLE64             fTotalValueTraded                     ;
	LONG32               iPreviousClosePrice                   ;
	LONG32               iOpenIntersest                        ;
	LONG32               iChgOpenInterest                      ;
	CHAR                 sCrptActnIndicator[CRPT_ACT_CONST_LEN];
};

#pragma pack()


#pragma pack(2)
struct  NNF_MKT_STATS_RPT_DATA_BCAST
{
	struct          NNF_HEADER       sHeader   ;
	CHAR            iMsgType                    ;  
	CHAR            Reserved                   ;
	INT16           iNumberOfRecords           ;
	struct          NNF_MKT_STATS_DATA  MktStatsData[DRV_MAX_RECORDS_FOR_MKT_STATS_RPT];

};
#pragma pack()


#pragma pack(2)
struct          NNF_MKT_STATS_RPT_TRLR_BCAST
{
	struct          NNF_HEADER      sHeader ;
	CHAR            MsgType                 ;
	LONG32          nNumberOfRecords        ;
	CHAR            Reserved                ;
};
#pragma pack()

#pragma pack(2)
struct TESTTYPE
{
	struct NNF_HEADER sHeader  ;
	CHAR   MsgType             ;
};
#pragma pack()




typedef struct  NNF_MKT_STATS_RPT_DATA_BCAST    NNF_MKT_STATS_RPT_DATA_BCAST;
typedef struct  NNF_MKT_STATS_RPT_TRLR_BCAST    NNF_MKT_STATS_RPT_TRLR_BCAST;
typedef struct  NNF_MKT_STATS_RPT_HEADER_BCAST  NNF_MKT_STATS_RPT_HEADER_BCAST; 


/*________________________________BHAVCOPY  ENDS HERE______________________________*/




/*_______________________________INTERACTIVE STARTS HERE___________________________*/ 


#pragma pack(2)
struct  NNF_ERROR_RESP
{
	struct      NNF_HEADER  sHeader                 ;
	CHAR        Key[KEY_LEN]                        ;
	CHAR        ErrorString [ERROR_STRING_LEN]      ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_ORDER_TERMS
{
#ifdef  BIGENDIAN
	USHORT      ATO             : 1                         ;
	USHORT      Market          : 1                         ;
	USHORT      StopLossTerm    : 1                         ;
	USHORT      MIIT            : 1                         ;
	USHORT      DayTerm         : 1                         ;
	USHORT      GTCTerm         : 1                         ;
	USHORT      IOCTerm         : 1                         ;
	USHORT      AONTerm         : 1                         ;
	USHORT      MFTerm          : 1                         ;
	USHORT      MatchedInd      : 1                         ;
	USHORT      Traded          : 1                         ;
	USHORT      Modified        : 1                         ;
	USHORT      Frozen          : 1                         ;
	USHORT      Reserved1       : 1                         ;
	USHORT      Reserved2       : 1                         ;
	USHORT      Reserved3       : 1                         ;
#elif   LITTLEENDIAN
	USHORT      AONTerm         : 1                         ;
	USHORT      IOCTerm         : 1                         ;
	USHORT      GTCTerm         : 1                         ;
	USHORT      DayTerm         : 1                         ;
	USHORT      MIIT            : 1                         ;
	USHORT      StopLossTerm    : 1                         ;
	USHORT      Market          : 1                         ;
	USHORT      ATO             : 1                         ;
	USHORT      Reserved1       : 1                         ;
	USHORT      Reserved2       : 1                         ;
	USHORT      Reserved3       : 1                         ;
	USHORT      Frozen          : 1                         ;
	USHORT      Modified        : 1                         ;
	USHORT      Traded          : 1                         ;
	USHORT      MatchedInd      : 1                         ;
	USHORT      MFTerm          : 1                         ;
#endif
};
#pragma pack()



/*----------------------------------------------------------------------------------------------0
  L O G O N 
Transcodes:

1.   TC_SIGNON_REQ               2.   TC_SIGNON_RESP
3.   TC_SYS_INFO_REQ             4.   TC_SYS_INFO_RESP
5.   TC_UPDATE_LDB_DOWNLOAD_REQ  6.   TC_PARTIAL_SYS_INFO_RESP
7.   TC_UPDATE_LDB_HEADER_RESP   8.   TC_UPDATE_LDB_DATA_RESP
9.   TC_UPDATE_LDB_TRAILER_RESP  10.  TC_MSG_DOWNLOAD_REQ
11.  TC_MSG_DOWNLOAD_START_RESP  12.  TC_MSG_DOWNLOAD_DATA_RESP        
13.  TC_MSG_DOWNLOAD_END_RESP
0----------------------------------------------------------------------------------------------*/

struct  NNF_ELIGIBILITY_PER_MKT
{
#ifdef  BIGENDIAN
	USHORT          NormalMkt               : 1  ;
	USHORT          OddLotMkt               : 1  ;
	USHORT          SpotMkt                 : 1  ;
	USHORT          AuctionMkt              : 1  ;
	USHORT          Reserved                : 4  ;
	USHORT          Reserved1               : 8  ;
#elif   LITTLEENDIAN 
	USHORT          Reserved                : 4  ;
	USHORT          AuctionMkt              : 1  ;
	USHORT          SpotMkt                 : 1  ;
	USHORT          OddLotMkt               : 1  ;
	USHORT          NormalMkt               : 1  ;
	USHORT          Reserved1               : 8  ;
#endif
};


#pragma pack(2)
struct  NNF_SIGNON_REQ
{
	struct      NNF_HEADER  sHeader                         ;
	LONG32      iUserId                                      ;  /*** Userid related changes ****/
	CHAR        sReserved3  [8]                                 ;
	CHAR        sPassword[NSE_PASSWORD_LEN]                      ;
	CHAR        sReserved4  [8]                                 ;
	CHAR        sNewPassword[NSE_PASSWORD_LEN]                   ;
	CHAR        sTraderName[TRADER_NAME_LEN]                 ;
	LONG32      iLastPasswordChangeDate                      ;
	CHAR        sBrokerCode[BROKER_CODE_LENGTH]                 ;
	CHAR        cReserved1                                   ;
	SHORT       iBranchId                                    ;
	LONG32      iVersionNumber                               ;
	LONG32      iBatch2StartTime                             ;
	CHAR        cHostSwitchContext                           ;
	CHAR        sColour[COLOUR_LEN]                          ;
	CHAR        cReserved2                                   ;
	SHORT       iUserType                                    ;
	DOUBLE64    iSequenceNumber                              ;
	CHAR            sWorkstationAddr [WORK_STATION_ADDR_LEN];
	CHAR        cBrokerStatus                                ;
	CHAR        cShowIndex                                   ;
	struct      NNF_ELIGIBILITY_PER_MKT EligibilityPerMkt   ;
	SHORT       iMemberType                                  ;
	CHAR        sClearingStatus                              ;
	CHAR        sBrokerName[BROKER_NAME_LEN]                 ;
	CHAR        sReserved5  [16]                                 ;
	CHAR        sReserved6  [16]                                 ;
	CHAR        sReserved7  [16]                                 ;
};
#pragma pack()



#pragma pack(2)
struct  NNF_SIGNON_RESP
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      iUserId                                      ;  /*** Userid related changes ****/
	CHAR        sPassword[NSE_PASSWORD_LEN]                      ;
	CHAR        sNewPassword[NSE_PASSWORD_LEN]                   ;
	CHAR        sTraderName[TRADER_NAME_LEN]                 ;
	LONG32      iLastPasswordChange                          ;
	CHAR        sBrokerCode[BROKER_CODE_LEN]                 ;
	CHAR        cReserved                                    ;
	INT16       iBranchId                                    ;
	LONG32      iVersionNumber                               ;
	LONG32      iEndTime                                     ;
	CHAR        cReserved1 	                                ;/****Corrected during CloseOut changes ***/
	CHAR        sReserved2 [50]                              ;/****Corrected during CloseOut changes ***/
	CHAR        cReserved3 	                                ;/****Corrected during CloseOut changes ***/
	INT16       iUserType                                    ;
	DOUBLE64    fSeqNumber                                   ;
	CHAR        sReserved4 [14]                              ;
	CHAR        cBrokerStatus                                ;
	CHAR        cShowIndex                                   ;
	struct      NNF_ELIGIBILITY_PER_MKT EligibilityPerMkt   ;
	SHORT       iMemberType                                  ;
	CHAR        cClearingStatus                              ;
	CHAR        sBrokerName[BROKER_NAME_LEN]                 ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SIGNOFF_REQ
{
	struct      NNF_HEADER sHeader                          ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SIGNOFF_RESP
{
	struct      NNF_HEADER sHeader                          ;
	LONG32           UserId 					;/*** Userid related changes ***/
};
#pragma pack()

#pragma pack(2)
struct  NNF_SYS_INFO_REQ
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      LastUpdateTimePortfolio                     ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_REQ
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      iLastUpdateSecTime                           ;
	LONG32      iLastUpdatePartTime                          ;
	LONG32      iLastUpdateInstTime                          ;
	LONG32      iLastUpdateIndxTime                          ;
	CHAR        cReqForOpenOrders                            ;
	CHAR        cReserved                                    ;
	struct      NNF_MARKET_STATUS sMktStat             ;
	struct      NNF_EX_MKT_STATUS   sExStatus               ;
	struct      NNF_PL_MKT_STATUS   sPlStatus               ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_HDR_RESP
{
	struct      NNF_HEADER sHeader                          ;
	CHAR        Reserved[2]                                 ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_UPDATE_LDB_DATA_RESP
{
	struct      NNF_HEADER sHeader                          ;
	struct      NNF_HEADER sInnerHeader                     ;
	CHAR        Data [LDB_UPDATE_PACKET_LEN]                ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_TRAILER_RESP
{
	struct      NNF_HEADER sHeader                          ;
	CHAR        Reserved1[2]                                 ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_PORTFOLIO_REQ
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      lLastUpdateDtTime                           ;
};
#pragma pack()

#pragma pack(2)
struct   NNF_PORTFOLIO_DATA
{
	CHAR        cPortfolio[PORTFOLIO_LEN]                   ;
	LONG32       iToken                                      ;
	LONG32      lLastUpdtDtTime                             ;
	CHAR        cDeleteFlag                                 ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_PORTFOLIO_RESP
{
	struct      NNF_HEADER sHeader                          ;
	SHORT       iNoOfRecords                                ;
	CHAR        cMoreRecords                                ;
	CHAR        cFiller                                     ;
	struct      NNF_PORTFOLIO_DATA      sPortfolioData[MAX_NO_OF_PORTFOLIO] ;
};
#pragma pack()


/*-----------------------------------------------------------------------------------------0
  MESSAGE DOWNLOAD
  0------------------------------------------------------------------------------------------*/

#pragma pack(2)             /*  |Added for storing the 2 timestamps that needs to be */
struct NNF_DOUBLE_INT       /* sent to the exch for msg dowwnload. These 2 timestamps are  */
{                           /* inserted in ExchSeqNum of NNF_MSG_DOWNLOAD_REQ              */
	unsigned  int   iLogTime1;
	unsigned  int   iLogTime2;
};
#pragma pack()


#pragma pack(2)
struct  NNF_MSG_DOWNLOAD_REQ
{
	struct      NNF_HEADER sHeader                          ;
	DOUBLE64    fExchSeqNum                                  ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_MSG_DOWNLOAD_START_RESP
{
	struct      NNF_HEADER sHeader                          ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_MSG_DOWNLOAD_DATA_RESP
{
	struct      NNF_HEADER sHeader                          ;
	struct      NNF_HEADER sInnerHeader                     ;
	CHAR        sData [MSG_AREA_DLD_FO_DATA_LEN]           ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_MSG_DOWNLOAD_END_RESP
{
	struct      NNF_HEADER sHeader                          ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_FILLER_TERMS
{
	USHORT    b1    : 1 ;
	USHORT    b2    : 1 ;
	USHORT    b3    : 1 ;
	USHORT    b4    : 1 ;
	USHORT    b5    : 1 ;
	USHORT    b6    : 1 ;
	USHORT    b7    : 1 ;
	USHORT    b8    : 1 ;
	USHORT    b9    : 1 ;
	USHORT    b10   : 1 ;
	USHORT    b11   : 1 ;
	USHORT    b12   : 1 ;
	USHORT    b13   : 1 ;
	USHORT    b14   : 1 ;
	USHORT    b15   : 1 ;
	USHORT    b16   : 1 ;
};
#pragma pack()


/*--------------------------------------------------------------------------------------0
  ORDER MANAGEMENT 
  ORDER ENTRY/MOD/CAN/FREEZE/ERR_RES


  Transcodes
  1. TC_ORDER_ENTRY_REQ                  2. TC_ORDER_REQUESTED_RESP
  3. TC_OE_CONFIRMATION_RESP             4. TC_OE_FREEZE_RESP
  5. TC_OE_ERROR_RESP                    6. TC_ORDER_MOD_REQ
  7. TC_OM_CONFIRMATION_RESP             8. TC_OM_ERROR_RESP
  9. TC_OM_FREEZE_RESP                   10.TC_ORDER_CANCEL_REQ
  11.TC_OC_CONFIRMATION_RESP             12.TC_OC_ERROR_RESP 
  13.TC_ORDER_PRICE_FREEZE_APPROVE_RESP  14.TC_ORDER_PRICE_FREEZE_REJECT_RESP
  15.TC_ORDER_VOLUME_FREEZE_APPROVE_RESP 16.TC_ORDER_VOLUME_FREEZE_REJECT_RESP
  17.TC_STOP_LOSS_ORDER_TRIG_RESP

  0---------------------------------------------------------------------------------------*/




#pragma pack(2)
struct          NNF_ORDER_ENTRY
{
	struct      NNF_HEADER sHeader                          ;
	CHAR        cParticipantType                             ;
	CHAR        cReserved1                                   ;
	INT16       iCompititorPeriod                            ;
	INT16       iSolicitorPeriod                             ;
	CHAR        cModCanBy                                    ;
	CHAR        iReserved2                                   ;
	INT16       iReasonCode                                  ;
	CHAR        iReserved3[4]                                ;
	LONG32       iToken                                      ;  
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	CHAR        sCPBrokerCode [BROKER_CODE_LEN]              ;
	CHAR        cReserved4		                    ;/***** For CloseOut Changes ******/
	CHAR        cReserved5[2]	                            ;/***** For CloseOut Changes ******/
	CHAR	cCloseOutFlag				    ;/***** For CloseOut Changes ******/	
	CHAR	cReserved 				    ;
	SHORT       iOrderType                                   ;
	DOUBLE64    fOrderNum                                    ;
	CHAR        sAccCode[ACCOUNT_CODE_LEN]                   ;
	INT16       iBookType                                    ;
	INT16       iBuyOrSell                                   ;
	LONG32      iDiscQty                                     ;
	LONG32      iDiscQtyRemaining                            ;
	LONG32      iTotalQtyRemaining                           ;
	LONG32      iTotalQty                                    ;
	LONG32      iQtyFilledToday                              ;
	LONG32      iPrice                                       ;
	LONG32      iTriggerPrice                                ;
	LONG32      iGoodTillDate                                ;
	LONG32      iEntryTime                                   ;
	LONG32      iMinFillQty                                  ;
	LONG32      iLastModifiedTime                            ;
	struct      NNF_ORDER_TERMS OrderTerms                  ;
	INT16       iBranchId                                    ;
	/**    INT16       ExcgUserId                                  ; ***/
	LONG32      iExcgUserId                                 ; /*** Userid related changes ***/
	CHAR        sBrokerCode [ BROKER_CODE_LEN]               ;
	CHAR        sRemarks [ORDER_REMARKS_LEN]                 ;
	CHAR        cOpenClose                                   ;
	CHAR        sSettlor [SETTLOR_LEN]                       ;
	INT16       iProCli                                      ;
	INT16       iSettlementDays                              ;
	CHAR        cCoverUncover                                ;
	CHAR        cGiveupFlag                                  ;
	struct      NNF_FILLER_TERMS sExchRsrvdFlds             ;
	CHAR	sSeq[PRG_TRD_RESERVED_FIELD_LEN] 	    ;
	DOUBLE64    fUserInfo                                   ;
	DOUBLE64    fReservedPrgTrd                             ;
	CHAR	    sPanId	[NNF_PAN_NUM_LEN]		;
	LONG32	    iAlgoId					;
	SHORT	    iAlgoCategory				;
	CHAR	    sReserved5 [60]				;
	
};
#pragma pack()



/*-----------------------------------------------------------------------------------------0
  TRADE MANAGEMENT 
  TRADE MOD/CAN/CONFIRM/REJECT
  Transcodes
  1. TC_TRADE_MOD_REQ                2. TC_TRADE_MOD_CONF_RESP       
  3. TC_TRADE_MOD_REJECT_RESP        4. TC_TRADE_CAN_REQ 
  5. TC_TRADE_CAN_CONF_RESP          6. TC_TRADE_CAN_REJECT_RESP
  0-------------------------------------------------------------------------------------------*/

#pragma pack(2)
struct      NNF_TRADE
{
	struct      NNF_HEADER              sHeader             ;
	LONG32       TokenNo                                     ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	LONG32      TradeNumber                                 ;
	LONG32      TradeQty                                    ;
	LONG32      TradePrice                                  ;
	CHAR        MktType                                     ;
	CHAR        BuyOpenClose                                ;
	LONG32      NewTradeQty                                 ;
	CHAR        BuyBrokerCode[BROKER_CODE_LEN]              ;
	CHAR        SellBrokerCode[BROKER_CODE_LEN]             ;
	/***    INT16       TraderID                                    ; ****/
	LONG32       TraderID                                    ;  /*** Userid related changes ***/
	CHAR        RequestedByTraderID                         ;
	CHAR        SellOpenClose                               ;
	CHAR        BuyAcctNumber[BUY_ACC_LEN]                  ;
	CHAR        SellAcctNumber[SELL_ACC_LEN]                ;
	CHAR        BuyParticipant[SELL_PARTICIPANT_LEN]        ;
	CHAR        SellParticipant[SELL_PARTICIPANT_LEN]       ;
	CHAR        BuyCoverUncover                             ;
	CHAR        SellCoverUncover                            ;
	CHAR        BuyGiveupFlg                                ;
	CHAR        SellGiveupFlg                               ;
};
#pragma pack()

#pragma pack(4)
struct      TRADE
{
	struct      INT_COMMON_RESP_HDR IntRespHeader      ;
	LONG32      TradeNumber                            ;
	LONG32      TradeQty                               ;
	DOUBLE64     TradePrice                            ;
	SHORT       MarketType                             ;
	SHORT       BookType                               ;
	LONG32      NewTradeQty                            ;
	CHAR        BuySellInd                             ;
	CHAR        CoverUncoverFlg                        ;
	CHAR        OpenCloseFlg                           ;
	CHAR        GiveUpFlg                              ;
	CHAR        ParticipantCode[PARTICIPANT_CODE_LEN]  ;
	CHAR        CBrokerCode[BROKER_CODE_LEN]           ;
	LONG32      TraderID                               ;
	LONG32      RequestedByTraderID                    ;
	DOUBLE64    OrderNumber                            ;
	INT16       OrderSerialNumber                      ;
	INT16       TradeSerialNumber                      ;
	CHAR        ClientId[CLIENT_ID_LEN]                ;
	CHAR        EntityId[ENTITY_ID_LEN]                ;
	CHAR        Settler [SETTLOR_LEN]                  ;
	CHAR        SecurityId[SECURITY_ID_LEN]            ;
	CHAR        SourceFlag                             ;
	CHAR        D2C1Flag                               ;
	CHAR        RetailFIFlag                           ;
	DOUBLE64    InternalRefId                          ;
	DOUBLE64    BasketOrdNo                            ;
	CHAR        Reserved[ 4 ]                          ;
	CHAR        ProductId                              ;
	CHAR        OrderSessionType                       ;
	CHAR        HandlInst                              ;

};
#pragma pack()

#pragma pack(4)
struct  MS_TRADE_CONF_RESP
{
	struct          INT_COMMON_RESP_HDR IntRespHeader               ;
	DOUBLE64        fTradedOrdNumber                                 ;
	LONG32          iTradeNumber                                     ;
	CHAR            sAccountNumber [CLIENT_ID_LEN]                   ;
	INT16           iBuyOrSell                                       ;
	CHAR            cD2C1Flag                                        ;
	CHAR            cRetailFIFlag                                    ;
	LONG32          iOriginalQty                                     ;
	LONG32          iDiscQty                                         ;
	LONG32          iQtyTraded                                       ;
	LONG32          iQtyRemaining                                    ;
	LONG32          iDiscQtyRemaining                                ;
	LONG32          iQtyFilledToday                                  ;
	DOUBLE64        fOrderPrice                                      ;
	DOUBLE64        fTradePrice                                      ;
	struct          NNF_ORDER_TERMS OrderTerms                          ;
	LONG32          iGoodTillDate                                    ;
	CHAR            sActivityType [ACTIVITY_TYPE_LEN]                ;
	LONG32          iTradeTime                                       ;
	DOUBLE64        fCounterOrdNum                                   ;
	CHAR            sCPBrokerCode [BROKER_CODE_LEN]                  ;
	INT16           iBookType                                        ;
	INT16           iNewQty                                          ;
	DOUBLE64        fOrderNumber                                     ;
	INT16           iOrderSerialNumber                               ;
	INT16           iTradeSerialNumber                               ;
	CHAR            sClientId[CLIENT_ID_LEN]                         ;
	CHAR            sEntityId[ENTITY_ID_LEN]                         ;
	CHAR            sMktType [MARKET_LEN]                            ;
	CHAR            sSettler [SETTLOR_LEN]                           ;
	CHAR            sSecurityId[SECURITY_ID_LEN]                     ;
	LONG32          iUserId                                          ;
	CHAR            iSourceFlag                                      ;
	CHAR            iOpenClose                                       ;
	CHAR            cOldOpenClose                                    ;
	CHAR            cCoverUncover                                    ;
	CHAR            cOldCoverUncover                                 ;
	CHAR            cGiveUpFlag                                      ;
	CHAR            cPreOpenFlag                                     ;
	CHAR            sBseExchOrderNum [BSE_EXCH_ORDER_NO_LEN]         ;
	DOUBLE64        fInternalRefId                                   ;
	DOUBLE64        fBasketOrdNo                                     ;
	CHAR            sReserved[ 4 ]                                   ;
	CHAR            cProductId                                       ;
	CHAR            cOrderSessionType                                ;
	CHAR            cHandlInst                                       ;
	SHORT           iSettType                                        ;
};
#pragma pack()

#pragma pack(4)
struct  MS_EXCH_MSG_TO_TRADER_RESP
{
	struct          INT_COMMON_RESP_HDR IntRespHeader  ;
	LONG32          iTraderId                           ;
	CHAR            sActionCode[ACTION_CODE_LEN]        ;
	SHORT           iBcastMsgLength                     ;
	CHAR            sBcastMsg [ BCAST_MSG_LEN]          ;
} ;
#pragma pack()

/*-----------------------------------------------------------------------------------------0
  SPREAD MANAGEMENT
  0-----------------------------------------------------------------------------------------*/
#pragma pack(2)
struct			NNF_SUB_LEG_INFO
{
	LONG32		Token;
	struct      NNF_CONTRACT_DESC       ContractDesc           	;
	CHAR		CPBrokerCode[BROKER_CODE_LEN]					;
	CHAR        Reserved1	                                	;
	SHORT       OrderType                                   	;
	SHORT       BuyOrSell                                   	;
	LONG32      DiscQty                                     	;
	LONG32      DiscQtyRemaining                            	;
	LONG32      TotalQtyRemaining                           	;
	LONG32      TotalQty                                    	;
	LONG32      QtyFilledToday                              	;
	LONG32      Price                                       	;
	LONG32      TriggerPrice                                	;
	LONG32      MinFillQty                                  	;
	struct      NNF_ORDER_TERMS OrderTerms                  	;
	CHAR        OpenClose                                   	;
	CHAR        CoverUncover                                	;
	CHAR        GiveupFlag                                  	;
	CHAR        Reserved2                                  		;
};
#pragma pack()

#pragma pack(2)
struct          NNF_SPREAD_2L_3L_OE_REQ
{
	struct          NNF_ORDER_ENTRY     OrderEntry                 ;
	LONG32			PriceDiff									   ;
	struct          NNF_SUB_LEG_INFO	SubLegInfo[SPREAD_2L]	   ;
};
#pragma pack()


#pragma pack(2)
struct          NNF_SPREAD_OE_REQ
{
	struct          NNF_ORDER_ENTRY     OrderEntry[SPREAD_2L]                 ;
};
#pragma pack()


/*----------------------------------------------------------------------------------------0
  UNSOLICITIED MESSAGES
  NNF_TRADE_CONF_RESP(Transcode)
  0---------------------------------------------------------------------------------------*/

#pragma pack(2)
struct          NNF_TRADE_CONF_RESP
{
	struct      NNF_HEADER sHeader                          ;
	DOUBLE64    fTradedOrdNumber                             ;
	CHAR        sBrokerCode [BROKER_CODE_LEN]                ;
	CHAR        cReserved                                    ;
	/***    INT16       TraderId                                    ; ****/
	LONG32       iTraderId                                    ;   /*** Userid related changes ***/
	CHAR        sAccountNumber [ACCOUNT_CODE_LEN]            ;
	INT16       iBuyOrSell                                   ;
	LONG32      iOriginalQty                                 ;
	LONG32      iDiscQty                                     ;
	LONG32      iQtyRemaining                                ;
	LONG32      iDiscQtyRemaining                            ;
	LONG32      iPrice                                       ;
	struct      NNF_ORDER_TERMS OrderTerms                  ;
	LONG32      iGoodTillDate                                ;
	LONG32      iTradeNumber                                 ;
	LONG32      iQtyTraded                                   ;
	LONG32      iTradePrice                                  ;
	LONG32      iQtyFilledToday                              ;
	CHAR        cActivityType [ACTIVITY_TYPE_LEN]            ;
	LONG32      iTradeTime                                   ;
	DOUBLE64    fCounterOrdNum                               ;
	CHAR        sCPBrokerCode [BROKER_CODE_LEN]              ;
	LONG32       iToken                                       ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	CHAR        cOpenClose                                   ;
	CHAR        cOldOpenClose                                ;
	CHAR        cBookType                                    ;
	LONG32      iNewQty                                      ;
	CHAR        sOldAcctNum[ACCOUNT_CODE_LEN]                ;
	CHAR        sParticipant[PARTICIPANT_ID_LEN]             ;
	CHAR        sOldParticipant[PARTICIPANT_ID_LEN]          ;
	CHAR        cCoverUncover                                ;
	CHAR        cOldCoverUncover                             ;
	CHAR        cGiveUpTrade                                 ;
	CHAR	    sPanId [NNF_PAN_NUM_LEN]			 ;
	CHAR	    sOldPanId [NNF_PAN_NUM_LEN]			 ;
	LONG32	    iAlgoId					;
	SHORT	    iAlgoCategory				;
	CHAR	    sReserved2[60]				;
};
#pragma pack()



struct          NNF_GIVEUP
{
	DOUBLE64    OrdNumber                             		;
	LONG32      TradeNo                                     ;
	struct      NNF_CONTRACT_DESC       ContractDesc        ;
	LONG32      QtyTraded                                   ;
	LONG32      TradePrice                                  ;
	CHAR        BrokerCode [BROKER_CODE_LEN]                ;
	CHAR        Reserved                                    ;
	SHORT       BuyOrSell                                   ;
	SHORT       BookType                                    ;
	LONG32		LastModDate_Time							;
	CHAR 		InitByControl								;
	CHAR        OpenClose                                   ;
	CHAR        CoverUncover                                ;
	CHAR        Participant[PARTICIPANT_ID_LEN]             ;
	CHAR        GiveUpTrade                                 ;
	CHAR		Deleted										;
};
#pragma pack()

#pragma pack(2)
struct          NNF_GIVEUP_CONF_RESP
{
	struct      NNF_HEADER sHeader                          ;
	INT16		Reason_Code									;
	struct 		NNF_GIVEUP giveup							;
};
#pragma pack()




typedef struct  NNF_GIVEUP                      NNF_GIVEUP                            ;

typedef struct  NNF_GIVEUP_CONF_RESP            NNF_GIVEUP_APP_CONF_RESP              ;

typedef struct  NNF_GIVEUP_CONF_RESP            NNF_GIVEUP_REJ_CONF_RESP              ;


#pragma pack(2)
struct          NNF_EXCH_MSG_TO_TRADER_RESP
{
	struct      NNF_HEADER sHeader                          ;
	LONG32      iTraderId                                    ; /*** Userid related changes ***/
	CHAR        cReserved1                                   ;/***** For CloseOut Changes ******/
	CHAR        cReserved2[3]                                ;/***** For CloseOut Changes ******/
	SHORT       iBcastMsgLength                              ;
	CHAR        sBcastMsg [ BCAST_MSG_LEN]                   ;

};
#pragma pack()

/*---------------------------------------------------------------------------------------0
  LOGOFF / LOGON
  0---------------------------------------------------------------------------------------*/

#pragma pack(2)
struct  NNF_LOGOFF_REQ
{
	struct      NNF_HEADER      sHeader         ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_LOGOFF_RESP
{
	struct      NNF_HEADER      sHeader         ;
	LONG32      UserId                         ; /*** Userid related changes ***/
	CHAR        Reserved[145]                   ;
};
#pragma pack()

/**********************Girija for Exercise & Position ***********************************/
/*---------------------------------------------------------------------------------------0

  Exercise & Position Liquidation
  1. TC_EXPL_ENTRY_REQ                    2. TC_EXPL_REQUESTED_RESP
  3. TC_EXPL_CONFIRMATION_RESP            4. TC_EXPL_ERROR_RESP

  5. TC_EXPL_MOD_REQ                      6. TC_EXPL_MOD_REQUESTED_RESP
  7. TC_EXPL_MOD_CONFIRMATION_RESP        8. TC_EXPL_MOD_ERROR_RESP

  9. TC_EXPL_CANCEL_REQ                   10. TC_EXPL_CANCEL_REQUESTED_RESP
  11. TC_EXPL_CANCEL_CONFIRMATION_RESP    12. TC_EXPL_CANCEL_ERROR_RESP

  0---------------------------------------------------------------------------------------*/
#pragma pack(2)
struct  NNF_EXPL_INFO
{
	LONG32       Token                           ;
	CHAR        InstrumentName [INSTR_NAME_LEN] ;
	CHAR        Symbol [SYMBOL_LEN]             ;
	LONG32      ExpiryDate                      ;
	LONG32      StrikePrice                     ;
	CHAR        OptionType [OPT_TYPE_LEN ]      ;
	SHORT       CALevel                         ;
	SHORT       ExplFlag                        ;
	DOUBLE64    ExplNumber                      ;
	SHORT       MarketType                      ;
	CHAR        AccountNumber [ACCOUNT_CODE_LEN];
	LONG32      Quantity                        ;
	SHORT       ProCli                          ;
	SHORT       ExType                          ;
	LONG32      EntryTime                       ;
	SHORT       BranchId                        ;
	LONG32       TraderId                        ; /*** Userid related changes ***/
	CHAR        BrokerCode [BROKER_CODE_LEN]    ;
	CHAR        Remarks [EXPL_REMARKS_LEN]      ;
	CHAR        ParticipantId [PARTICIPANT_ID_LEN];
};
#pragma pack()

#pragma pack(2)
struct  NNF_EXPL_FLAG
{
#ifdef  BIGENDIAN
	USHORT          ExTypeFlg               : 1  ;
	USHORT          DeleteFlg               : 1  ;
	USHORT          SendToClg               : 1  ;
	USHORT          IntOrFin              	: 1  ;
	USHORT          EntByControl            : 1  ;
	USHORT          Original                : 1  ;
	USHORT			Reserved				: 2	 ;
	USHORT			Reservd					: 8	 ;
#elif   LITTLEENDIAN
	USHORT          Reserved                : 2  ;
	USHORT          Original                : 1  ;
	USHORT          EntByControl            : 1  ;
	USHORT          IntOrFin                : 1  ;
	USHORT          SendToClg               : 1  ;
	USHORT          DeleteFlg               : 1  ;
	USHORT          ExTypeFlg               : 1  ;
	USHORT          Reservd                	: 8  ;
#endif
};
#pragma pack()

/*******
#pragma pack(2)
struct  NNF_EXPL_INFO
{
LONG32       Token                           ;
CHAR        InstrumentName [INSTR_NAME_LEN] ;
CHAR        Symbol [SYMBOL_LEN]             ;
LONG32      ExpiryDate                      ;
LONG32      StrikePrice                     ;
CHAR        OptionType [OPT_TYPE_LEN ]      ;
SHORT       CALevel                         ;
SHORT       ExplFlag                        ;
DOUBLE64    ExplNumber                      ;
SHORT       MarketType                      ;
LONG32      Quantity                        ;
SHORT       ProCli                          ;
CHAR        AccountNumber [ACCOUNT_CODE_LEN];
CHAR        ForBrokerCode [BROKER_CODE_LEN] ;
SHORT       ForBranchId                     ;
SHORT       ForTraderId                     ;
CHAR        BrokerCode [BROKER_CODE_LEN]    ;
SHORT       BranchId                        ;
SHORT       TraderId                        ;
SHORT		ModCancelledBy					;
SHORT       ExType                          ;
struct 		NNF_EXPL_FLAG	ExPlFlag		;
CHAR        Remarks [EXPL_REMARKS_LEN]      ;
CHAR        Reserved [10]      				;
LONG32      EntryTime                       ;
LONG32      LastModifiedTime                ;
SHORT       ControlUserId					;
CHAR        ParticipantId [PARTICIPANT_ID_LEN];
};
#pragma pack()
 ********/


#pragma pack(2)
struct  NNF_EXPL_REQUEST
{
	struct      NNF_HEADER      sHeader         ;
	SHORT       ReasonCode                      ;
	struct      NNF_EXPL_INFO   ExPlInfo        ;
};
#pragma pack()
/*----------------------------------------------------------------------
  Update Local Database Download -Added by 
  ----------------------------------------------------------------------*/

/*--------------------------------------------------------------------
  Change in Index master :BCAST_INDEX_MSTR_CHNG
Transcode              :7325                         
---------------------------------------------------------------------**/

#pragma pack(2)
struct	NNF_INDEX_DETAIL
{
	CHAR		IndexName[NNF_INDEX_NAME_LEN];
	LONG32		Token;
	LONG32    	LastUpdateDateTime;
};
#pragma pack()

#pragma pack(2)
struct	NNF_INDEX_MSTR_CHNG_BCAST
{
	struct		NNF_HEADER sHeader;
	SHORT  		NoOfRecords;     
	struct		NNF_INDEX_DETAIL sIndices[NNF_MAX_NO_INDEX_DETAIL];
};
#pragma pack()   


/*--------------------------------------------------------------------
  Change in Index master :BCAST_BASE_PRICE
Transcode              :7327                         
---------------------------------------------------------------------**/
#pragma pack(2)
struct	NNF_DOWNLOAD_BP_TOK
{
	SHORT		Token;
	LONG32		BasePrice;
	LONG32		Reserved;
};
#pragma pack()

#pragma pack(2)
struct	NNF_BASE_PRICE_DOWNLOAD
{
	struct		NNF_HEADER sHeader;
	SHORT		NoOfRecords;
	struct		NNF_DOWNLOAD_BP_TOK sBaseP[NNF_MAX_NO_BASE_PRICE_DETAIL];
};
#pragma pack()


/*--------------------------------------------------------------------
  Change in Index master :BCAST_INDEX_MAP_TABLE
Transcode              :7326                         
---------------------------------------------------------------------**/
#pragma pack(2)
struct	NNF_DOWNLOAD_INDEX_MAP 
{
	CHAR		BcastName[NNF_INDEX_BCAST_NAME_LEN];
	CHAR		ChangedName[NNF_INDEX_CHANGE_NAME_LEN];
	CHAR		DeleteFlag;
	LONG32		LastUpdateDateTime;
};
#pragma pack()

#pragma pack(2)
struct	NNF_INDEX_MAP_DETAILS 
{
	struct 		NNF_HEADER sHeader;
	SHORT		NoOfRecords;	
	struct		NNF_DOWNLOAD_INDEX_MAP sIndicesMap[NNF_MAX_NO_INDEX_DLOAD_DETAIL];
};
#pragma pack()
#pragma pack(2)
struct NNF_AUCTION_INQUIRY_INFORMATION
{
	SHORT       AuctionNumber                           ;
	SHORT       AuctionStatus                           ;
	SHORT       InitiatorType                           ;
	LONG32      TotalBuyQty                             ;
	LONG32      BestBuyPrice                            ;
	LONG32      TotalSellQty                            ;
	LONG32      BestSellPrice                           ;
	LONG32      AuctionPrice                            ;
	LONG32      AuctionQty                              ;
	SHORT       SettlementPeriod                        ;
} ;
#pragma pack()
#pragma pack(2)
struct NNF_AUCTION_INQ_INFO_INTERACTIVE
{
	SHORT       Token                                   ;
	SHORT       AuctionNumber                           ;
	SHORT       AuctionStatus                           ;
	SHORT       InitiatorType                           ;
	LONG32      TotalBuyQty                             ;
	LONG32      BestBuyPrice                            ;
	LONG32      TotalSellQty                            ;
	LONG32      BestSellPrice                           ;
	LONG32      AuctionPrice                            ;
	LONG32      AuctionQty                              ;
	SHORT       SettlementPeriod                        ;
} ;
#pragma pack()
/*-------------------------------------------------------------------

  AUCTION  BCAST

  Transcodes
  1. TC_AUCTION_DATA_BCAST
  2. TC_AUCTION_STATUS_CHANGE_BCAST
  3. TC_AUCTION_INQUIRY_REQ

  -------------------------------------------------------------------*/
#pragma pack(2)
struct NNF_AUCTION_INQUIRY_REQ
{
	struct      NNF_HEADER          sHeader         ;
	struct      NNF_SEC_INFO        sSecInfo        ;
	SHORT       AuctionNumber                       ;
	CHAR        Filler                              ;
};
#pragma pack()

#pragma pack(2)
struct NNF_AUCTION_INQUIRY_RESP
{
	struct      NNF_HEADER                          sHeader         ;
	SHORT       NoOfRecords;
	struct      NNF_AUCTION_INQ_INFO_INTERACTIVE    sNnfAucInqInfo [NO_OF_AUCTION_INQUIRY_RECORDS]  ;
};


#pragma pack(2)
struct NNF_AUCTION_DATA_BCAST
{
	struct      NNF_HEADER                          sHeader         ;
	SHORT                                           Token           ;
	struct      NNF_AUCTION_INQUIRY_INFORMATION     sNnfAucInqInfo  ;
} ;
#pragma pack()


#pragma pack(2)
struct NNF_AUCTION_STATUS_BCAST
{
	struct      NNF_HEADER       sHeader                ;
	struct      NNF_SEC_INFO                sSecInfo    ;
	SHORT       AuctionNumber                           ;
	CHAR        AuctionStatus                           ;
	CHAR        ActionCode[ACTION_CODE_LEN]             ;
	struct      NNF_DESTINATION Dest                    ;
	SHORT       BcastMsgLength                          ;
	CHAR        BcastMsg [ BCAST_MSG_LEN ]              ;
} ;
#pragma pack()
//typedef BOOL (*P_TO_FUN)(char * x);


struct TRANS_FUN_PAIR
{
	INT16  Transcode;
	P_TO_FUN  pToFun;
};



/*------------------------------End of Add ------------------------------------*/


typedef struct  NNF_ERROR_RESP              NNF_ERROR_RESP;
typedef struct  NNF_SIGNON_REQ              NNF_SIGNON_REQ;
typedef struct  NNF_SIGNON_RESP             NNF_SIGNON_RESP;
typedef struct  NNF_UPDATE_LDB_REQ          NNF_UPDATE_LDB_REQ;
typedef struct  NNF_UPDATE_LDB_HDR_RESP     NNF_UPDATE_LDB_HDR_RESP;
typedef struct  NNF_UPDATE_LDB_DATA_RESP    NNF_UPDATE_LDB_DATA_RESP;
typedef struct  NNF_UPDATE_LDB_TRAILER_RESP NNF_UPDATE_LDB_TRAILER_RESP;
typedef struct  NNF_MSG_DOWNLOAD_REQ        NNF_MSG_DOWNLOAD_REQ;
typedef struct  NNF_MSG_DOWNLOAD_START_RESP NNF_MSG_DOWNLOAD_START_RESP;
typedef struct  NNF_MSG_DOWNLOAD_DATA_RESP  NNF_MSG_DOWNLOAD_DATA_RESP;
typedef struct  NNF_MSG_DOWNLOAD_END_RESP   NNF_MSG_DOWNLOAD_END_RESP;
typedef struct  NNF_PORTFOLIO_REQUEST       NNF_PORTFOLIO_REQUEST;
typedef struct  NNF_PORTFOLIO_RESP			NNF_PORTFOLIO_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_REQ;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_REQUESTED_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_MARKET_ORDER_PRICE_CONF_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_CONF_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_FREEZE_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_ENTRY_ERROR_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_MOD_REQ;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_MOD_CONF_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_MOD_FREEZE_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_MOD_ERROR_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_CANCELLATION_REQ;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_CANCEL_CONF_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_CANCEL_ERROR_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_FREEZE_RESOLVE_AT_EXCG_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_NEG_ORDER_CANCELLED_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_BATCH_ORDER_CANCEL_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_NEG_ORDER_ENTERED_BY_CP_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_NEG_ORDER_TO_REGULARLOT_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_MOD_REQUESTED_RESP;
typedef struct  NNF_ORDER_ENTRY             NNF_ORDER_CAN_REQUESTED_RESP;
typedef struct	NNF_SYS_INFO_REQ			NNF_SYS_INFO_REQ;
typedef struct  NNF_TRADE                   NNF_TRADE;
typedef struct  NNF_TRADE                   NNF_TRADE_MOD_REQ;
typedef struct  NNF_TRADE                   NNF_TRADE_CAN_REQ;
typedef struct  NNF_TRADE                   NNF_TRADE_MOD_CAN_ERROR_RESP;
typedef struct  NNF_TRADE                   NNF_TRADE_MOD_REQUESTED_BY_CP_RESP;
typedef struct  NNF_TRADE                   NNF_TRADE_CAN_REQUESTED_BY_CP_RESP;
typedef struct  NNF_TRADE                   NNF_TRADE_MOD_CAN_REQ_ACK_RESP;
typedef struct  NNF_TRADE                   NNF_TRADE_MOD_PARTICIPANT_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_3L_OE_REQ;



typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_OE_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_OE_CONF_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_OE_ERROR_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_CAN_RESP;

typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_MOD_REQ;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_MOD_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_MOD_CAN_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_MOD_CONF_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_MOD_ERROR_RESP;

typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_OE_REQ;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_OE_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_OE_CONF_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_OE_ERROR_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_2L_OE_CAN_RESP;


typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_3L_OE_REQ;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_3L_OE_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_3L_OE_CONF_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_3L_OE_ERROR_RESP;
typedef struct  NNF_SPREAD_2L_3L_OE_REQ     NNF_SPREAD_3L_OE_CAN_RESP;


typedef struct  NNF_TRADE_CONF_RESP         NNF_TRADE_CONF_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_TRADE_MOD_CONF_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_TRADE_MOD_REJECT_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_TRADE_CAN_CONF_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_TRADE_CAN_REJECT_RESP;
typedef struct  NNF_TRADE_CONF_RESP         NNF_STOP_LOSS_ORDER_TRIGGER_RESP;
typedef struct  NNF_EXCH_MSG_TO_TRADER_RESP NNF_EXCH_MSG_TO_TRADER_RESP;
typedef struct  MS_TRADE_CONF_RESP         MS_TRADE_CONF_RESP           ;
typedef struct  MS_EXCH_MSG_TO_TRADER_RESP  MS_EXCH_MSG_TO_TRADER_RESP;
typedef struct  NNF_EXPL_REQUEST 			NNF_EXPL_REQUEST;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_ENTRY_REQ;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_ENTRY_REQUESTED_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_ENTRY_CONF_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_ENTRY_ERROR_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_MOD_REQ;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_MOD_REQUEST_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_MOD_CONF_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_MOD_ERROR_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_CAN_REQ;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_CAN_REQUEST_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_CAN_CONF_RESP;
typedef struct  NNF_EXPL_REQUEST            NNF_EXPL_CAN_ERROR_RESP;
typedef	struct  NNF_INDEX_MSTR_CHNG_BCAST   NNF_INDEX_MSTR_CHNG_BCAST;
typedef struct	NNF_BASE_PRICE_DOWNLOAD		NNF_BASE_PRICE_DOWNLOAD;
typedef	struct  NNF_INDEX_MAP_DETAILS		NNF_INDEX_MAP_DETAILS;

extern BOOL fMAP_1L_ORDER_RESP(CHAR *,CHAR *);
extern BOOL fCMS_STOP_LOSS_ORDER_TRIGGER(  CHAR *,CHAR *);
extern BOOL fCMS_TRADE_CONF_MAP_RESP(CHAR *,CHAR *);
extern BOOL fCMS_EXCH_MSG_TO_TRADER_RESP(CHAR *,CHAR *);

extern BOOL fMAP_ORDER                              (CHAR *, CHAR *);
extern BOOL fCMS_STOP_LOSS_ORDER_TRIGGER            (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CONF_MAP_RESP                (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CAN_MAP_RESP                 (CHAR *, CHAR *);
extern BOOL fCMS_EXCH_MSG_TO_TRADER_RESP            (CHAR *, CHAR *);
extern BOOL fCMS_UPDATE_LDB_TRAILER_RESP            (CHAR *, CHAR *);



/*      USERTYPES

	TRADER                          0
	CONTROL0                        1
	CONTROL1                        2
	ENQUIRY                         3
	CORPORATE MANAGER               4
	BRANCH MANAGER                  5
 */

/**** TAP Reg Changes *****/

#pragma pack(2)
struct Download_Data
{
	LONG32  iStream_Id ;
	LONG32  iStream_Flag ; /**** Flag 1 for ON , 0 for OFF ********/
	ULONG32 iTimeStamp1;
	ULONG32 iTimeStamp2;
}Msg_Dow_Data[MAX_NO_STREAMS] ;
#pragma pack()

#pragma pack(2)
struct  NNF_SYS_INFO_RESP
{
	struct          NNF_HEADER sHeader                                         ;
	struct          NNF_MARKET_STATUS MarketStatus                             ;/*PreOpen transcode 1601 **/
	LONG32          iMarketIndex                                               ;
	INT16           iNormalMktDefSttlPeriod                                    ;
	INT16           iSpotMktDefSttlPeriod                                      ;
	INT16           iAuctionMktDefSttlPeriod                                   ;
	INT16           iDefCompititorPeriod                                       ;
	INT16           iDefSolicitorPeriod                                        ;
	INT16           iWarnigPercent                                             ;
	INT16           iVolFreezePercent                                          ;
	LONG32          iReserved                                                  ;
	LONG32          iBoardLotQty                                               ;
	LONG32          iTickSize                                                  ;
	INT16           iMaxGTCDays                                                ;
	struct          NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS    StockEligibilityInd;
	INT16           iDiscQty                                                   ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_ADDITIONAL_FLAG
{
	USHORT  iReserve1       :1;
	USHORT  iCOL1           :1;
	USHORT  iReserve2       :6;


};
#pragma pack()

#pragma pack(2)
struct  NNF_SPD_LEG_INFO
{
	LONG32          iToken2         ;
	struct          NNF_SEC_INFO    pSecInfo;
	CHAR            sBrokerID2[BROKER_CODE_LENGTH]          ;
	CHAR            cReserved2              ;
	INT16           iOrdType                ;
	INT16           iBuySell                ;
	LONG32          iDiscloseVol2           ;
	LONG32          iDisVolRem2             ;
	LONG32          iTotVolRem2             ;
	LONG32          iVolume2                ;
	LONG32          iVolFillToday2          ;
	LONG32          iPrice2         ;
	LONG32          iTriggerPrice2          ;
	LONG32          iMinFillAON2            ;
	struct          NNF_ORDER_TERMS pOrdTerm        ;
	CHAR            cOpenClose              ;
	struct          NNF_ADDITIONAL_FLAG     pAddFlg ;
	CHAR            cGiveUpFlag             ;
	CHAR            cReserved               ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_SPRD_ORD_ENTRY_REQ
{
	struct          NNF_HEADER pHeader              ;
	CHAR            cParticType1                    ;
	CHAR            cReserved1                      ;
	INT16           iCompetitorPeriod              ;
	INT16           iSolicitorPeriod               ;
	CHAR            cModCxlBy1                      ;
	CHAR            cReserved2                      ;
	INT16           iReasonCode1                    ;
	CHAR            sStartAlpha1[ALPHA_SPLIT_LEN] 	;
	CHAR            sEndAlpha1[ALPHA_SPLIT_LEN]   	;
	LONG32          iToken1                         ;
	struct          NNF_SEC_INFO    pSecInfo        ;
	CHAR            sOpBrokerID[BROKER_CODE_LENGTH]	;
	CHAR            cReserved3                      ;
	CHAR            sReserved4[3]                   ;
	CHAR            cReserved5                      ;
	INT16           iOptType                        ;
	DOUBLE64        fExchOrderNum                   ;
	CHAR            sAccNumber[ACCOUNT_CODE_LEN]	;
	INT16           iBookType                       ;
	INT16           iBuySellIndicator               ;
	LONG32          iDisclVol                       ;
	LONG32          iDisclVolRem                    ;
	LONG32          iTotVolRem                      ;
	LONG32          iVolume1                        ;
	LONG32          iVolFillToday1                  ;
	LONG32          iPrice                  	;
	LONG32          iTriggerPrice                   ;
	LONG32          iGoodTillDate                   ;
	LONG32          iEntryDateTime                  ;
	LONG32          iMinFillAON                     ;
	LONG32          iLastModifyTime                 ;
	struct          NNF_ORDER_TERMS OrderTerms      ;
	INT16           iBranchID1                      ;
	LONG32          iTraderID1                      ;
	CHAR            sBrokerID[BROKER_CODE_LENGTH]	;
	CHAR            sOrdFiller[24]                  ;
	CHAR            cOpenClose                      ;
	CHAR            sSettlor[NNF_SETTLOR_LEN] 	;
	INT16           iProClient                      ;
	INT16           iSettlePeriod                   ;
	struct          NNF_ADDITIONAL_FLAG     pAddFlg ;
	CHAR            cGiveUpFlag                     ;
	USHORT          iFiller1        :1              ;
	USHORT          iFiller2        :1              ;
	USHORT          iFiller3        :1              ;
	USHORT          iFiller4        :1              ;
	USHORT          iFiller5        :1              ;
	USHORT          iFiller6        :1              ;
	USHORT          iFiller7        :1              ;
	USHORT          iFiller8        :1              ;
	USHORT          iFiller9        :1              ;
	USHORT          iFiller10       :1              ;
	USHORT          iFiller11       :1              ;
	USHORT          iFiller12       :1              ;
	USHORT          iFiller13       :1              ;
	USHORT          iFiller14       :1              ;
	USHORT          iFiller15       :1              ;
	USHORT          iFiller16       :1              ;
	CHAR            cFiller17                       ;
	CHAR            cFiller18                       ;
	DOUBLE64        fNNFfield                       ;
	DOUBLE64        fMktReplay                      ;
	LONG32          iPriceDiff                      ;
	struct          NNF_SPD_LEG_INFO        pLeg2   ;
	struct          NNF_SPD_LEG_INFO        pLeg3   ;


};
#pragma pack()


#pragma pack(2)
struct 	NNF_SPRD_MBP
{
	struct          NNF_HEADER pHeader      ;
	LONG32		iToken1			;	
	LONG32		iToken2			;
	INT16		iMbpBuy			;
	INT16		iMbpSell		;
	LONG32		iLastActTime		;
	LONG32		iTradedVol		;
	DOUBLE64	fTotTradeValue		;
	CHAR		sReserved[116]		;
	LONG32		iOpenPriceDiff		;
	LONG32		iDayHighPriceDiff	;		
	LONG32		iDayLowPriceDiff	;		
	LONG32		iLastTrdPriceDiff	;		
	LONG32		iLastTrdTime		;		
};	
#pragma pack()

#pragma pack(2)
struct  DRV_REDIS_LTP_UPD
{
        LONG32          iToken  ;
        DOUBLE64        fLtp    ;
};
#pragma pack()

/**** TAP Reg Changes *****/

#endif
BOOL dTC_GENERAL_MSG_BCAST                  (CHAR *NNFData);
BOOL dTC_PARTICIPANT_INFO_RESP              (CHAR *NNFData);
BOOL dTC_MARKET_STATUS_CHANGE_BCAST            (CHAR *NNFData);
BOOL dTC_STOCK_STATUS_CHANGE_BCAST          (CHAR *NNFData);
BOOL dTC_STOCK_DETAILS_CHANGE_BCAST         (CHAR *NNFData);
BOOL dTC_SECURITY_OPEN_MSG_BCAST            (CHAR *NNFData);
BOOL dTC_BROKER_TURNOVER_EXCEEDED_BCAST       (CHAR *NNFData);
BOOL dTC_SYSTEM_INFORMATION_BCAST           (CHAR *NNFData);
BOOL dTC_BCAST_CKT_ALIVE                    (CHAR *NNFData);
BOOL dTC_MKT_STATS_RPT_BCAST                (CHAR *NNFData);
BOOL dTC_INSTRUMENT_UPDATE_BCAST            (CHAR *NNFData);
BOOL dTC_TRADE_EXECUTION_RANGE 		    (CHAR *NNFData);
BOOL dTC_TICKER_INDEX_BCAST		(CHAR *NNFData);
BOOL dTC_MBP_BCAST			(CHAR *NNFData);
BOOL dTC_MKT_STATS_RPT_BCAST (CHAR *NNFData);
BOOL dBCAST_SPREAD_MBP			(CHAR *NNFData);
