#pragma pack(4)
struct INT_ORDERS
{
	struct		INT_COMMON_REQUEST_HDR	ReqHeader			;
	struct          INT_COMMON_RESP_HDR     ResHeader                       ;	
	DOUBLE64	fOrdNo							;
	//SHORT		iSerialNo						;
	LONG32 		iSerialNo						;
	CHAR		sSecId			[DB_SECURITY_ID_LEN]		;
	CHAR            sEntityId		[DB_ENTITY_ID_LEN]            	;
	CHAR		sExchOrdNo		[DB_EXCH_ORD_NO_LEN]		;
	CHAR            sClientId		[DB_CLIENT_ID_LEN]            	;
	CHAR		cBuySellInd						;
	CHAR            cOrdStatus						;
	CHAR		sSymbol			[DB_SYM_LEN]			;
	CHAR		sSymbolName		[DB_SYM_NAME_LEN]		;
	CHAR		sSymbolSfx		[DB_SERIES_LEN]			;
	CHAR		sEntryDate		[DB_DATETIME_LEN]		;
	CHAR		sOrderTime		[DB_DATETIME_LEN]		;
	LONG32		iExpiryDate						;
	LONG32          iTotalQty					   	;
	LONG32          iRemQty						   	;
	LONG32          iDiscQty					   	;
	LONG32          iDiscRemQty					   	;
	LONG32          iTotalTradedQty			 		   	;
	DOUBLE64	fOrderPrice						;
	DOUBLE64	fTriggerPrice						;
	CHAR		sInstrumentType		[DB_INSTRU_LEN]			;
	SHORT		iValidity						;
	SHORT		iOrderType						;
	SHORT		iGoodTillDaysFlg					;
	CHAR		sGoodTillDaysDate	[DB_DATETIME_LEN]		;
	CHAR		sAccCode		[DB_ACC_CODE_LEN]		;
	LONG32          iMinFillQty					   	;
	CHAR            cProClient						;
	CHAR		sRemarks		[DB_REMARKS_LEN]		;
	LONG32		iErrorCode						;
	LONG32		iSettlementDays						;
	CHAR		cUserType						;
	CHAR		cOrderOffOn						;
	CHAR		cProductId						;
	CHAR		sUserInfo		[DB_USER_INFO_LEN]		;
	LONG32		iGrpId							;
	LONG32		iReasonCode						;
	CHAR		sReasonDesc		[DB_REASON_DESC_LEN]		;
	LONG32		iExchTrdNo						;
	LONG32		iTrdSerialNo						;
	LONG32		iTrdTransCode						;
	CHAR		cTrdStatus						;
	LONG32		iLstTrdQty						;
	DOUBLE64	fTrdPrice						;//Used as RBI rate for cross currency
	CHAR		sTrdTime		[DB_DATETIME_LEN]		;
	LONG32		iTrdSeqNo						;
	CHAR		cHandleInst						;
	DOUBLE64	fAlgoOrderNo						;
	SHORT		iStratergyId						;
	CHAR		sClOrdId		[CLORDID_LEN]			;
	CHAR		sOrigClOrdId		[CLORDID_LEN]			;
	CHAR		sLastModTime		[DB_DATETIME_LEN]		;
	CHAR		sMaturityMonYr		[DB_DATETIME_LEN]		;
	CHAR		sMaturityDay		[MAT_DAY]			;				
	DOUBLE64	fStrikePrice						;
	CHAR            sSeries                 [DB_SERIES_LEN]                 ;
	CHAR		sOptType		[DB_OPT_TYPE_LEN]		;
	LONG32          iAuctionNum                                             ;// INCASE OF MCX THIS FIELD IS USED FOR MCX_MULTIPLIER
	LONG32		iExchUserId						;
	LONG32		iBranchID						;
	CHAR		sBrokerCode		[BROKER_CODE_LEN]		;	
	CHAR		sSettlor		[SETTLOR_LEN]			;	
	LONG32		iMktType						;
	INT16		iLegValue 						;
	CHAR		cPreOpenFlag						;
	LONG32          iChildLegsUniqId                                        ;
	CHAR            sPanNo  [INT_PAN_LEN]                                   ;
        LONG32          iAlgoID                                                 ;
        INT16           iAlgoCat                                                ;
        CHAR            cMarkProFlag                                            ;
        DOUBLE64        fMarkProVal                                             ;
        CHAR            cParticipantType                                        ;
        CHAR            cGTCFlag                                                ;
        CHAR            cEncashFlag                                             ;
	CHAR		cCrossCurFlag						;
	DOUBLE64	fRBIRefRate						;
	CHAR		sLocCode		[BSE_LOC_CODE_LEN]		;
	CHAR		sCustomSym		[CUSTOM_SYM_LEN]		;/**From Here we added 3 members for cuatome name lotsize and isin insertion in db.**/
	DOUBLE64	fLotSize						;
	CHAR		sISINCode 		[DB_ISIN_CODE_LEN]		;		
	CHAR		sInstrumentTyp 		[INSTRUMENT_TYPE]		;		
	CHAR		sUnderlyingCode		[SCRIP_CODE_LEN]		;		
	DOUBLE64	fLtp;
	CHAR            sBse_Algo_id            [BSE_INT_ALGO_ID_LEN]           ;
	DOUBLE64	fTickSize						;		
	CHAR            sUndScripCode           [DB_SCRIP_CODE_LEN]             ;
        LONG32          iFreezeQty                                              ;
	DOUBLE64	fUnderlyPrice						;
	DOUBLE64	fRmsBlockAmt						;
	CHAR            sPlatform		[PLATFORM_LEN]             	;
	CHAR            sChannel		[CHANNEL_LEN]             	;
	CHAR            sFiller			[50]       		      	;
	/*INTEROPS CHANGES*/
	CHAR            sIntropScripCode        [DB_SECURITY_ID_LEN]                            ;
        CHAR            sIntropSymbol           [DB_SYM_LEN]                            ;
        CHAR            sNseScripCode           [DB_SECURITY_ID_LEN]                            ;
        CHAR            sBseScripCode           [DB_SECURITY_ID_LEN]            ;
 	CHAR		sSmExpiryFlag		[DB_EXPIRY_FLAG_LEN]		;
	DOUBLE64 	fOrdTriggerPrice					;

	CHAR            sNearFutScrptId         [DB_SECURITY_ID_LEN]    ;
        DOUBLE64        fMppOrdPrice                                    ;
        DOUBLE64        fSlMppOrdPrice                                  ;
        DOUBLE64        fMppBlkPrice                                    ;
        DOUBLE64        fSlMppBlkPrice                                  ;
};
#pragma pack()
//
#pragma pack(4)
struct SIP_INT_ORDERS
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader                       ;
	DOUBLE64        fOrdNo                                                  ;
	LONG32		iSerialNo                                               ;
	CHAR            sSecId                  [DB_SECURITY_ID_LEN]            ;
	CHAR            sEntityId               [DB_ENTITY_ID_LEN]              ;
	CHAR            sExchOrdNo              [DB_EXCH_ORD_NO_LEN]            ;
	CHAR            sClientId               [DB_CLIENT_ID_LEN]              ;
	CHAR            cBuySellInd                                             ;
	CHAR            cOrdStatus                                              ;
	CHAR            sSymbol                 [DB_SYM_LEN]                    ;
	CHAR            sSymbolName             [DB_SYM_NAME_LEN]               ;
	CHAR            sSymbolSfx              [DB_SERIES_LEN]                 ;
	CHAR            sEntryDate              [DB_DATETIME_LEN]               ;
	CHAR            sOrderTime              [DB_DATETIME_LEN]               ;
	CHAR		sLastTrdDate		[DB_DATETIME_LEN]		;
	LONG32          iTotalQty                                               ;
	LONG32          iRemQty                                                 ;
	LONG32          iDiscQty                                                ;
	LONG32          iDiscRemQty                                             ;
	LONG32          iTotalTradedQty                                         ;
	DOUBLE64        fOrderPrice                                             ;
	DOUBLE64        fTriggerPrice                                           ;
	CHAR            sInstrumentType         [DB_INS_LEN]                    ;
	SHORT           iValidity                                               ;
	SHORT           iOrderType                                              ;
	SHORT           iGoodTillDaysFlg                                        ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]               ;
	CHAR            sAccCode                [DB_ACC_CODE_LEN]               ;
	LONG32          iMinFillQty                                             ;
	CHAR            cProClient                                              ;
	CHAR            sRemarks                [DB_REMARKS_LEN]                ;
	LONG32          iErrorCode                                              ;
	CHAR            cUserType                                               ;
	CHAR            cOrderOffOn                                             ;
	CHAR            cProductId                                              ;
	CHAR            sUserInfo               [DB_USER_INFO_LEN]              ;
	LONG32          iGrpId                                                  ;
	LONG32          iReasonCode                                             ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]            ;
	LONG32          iExchTrdNo                                              ;
	LONG32          iTrdSerialNo                                            ;
	LONG32          iTrdTransCode                                           ;
	CHAR            cTrdStatus                                              ;
	LONG32          iLstTrdQty                                              ;
	DOUBLE64        fTrdPrice                                               ;
	CHAR            sTrdTime                [DB_DATETIME_LEN]               ;
	LONG32          iTrdSeqNo                                               ;
	CHAR            cHandleInst                                             ;
	DOUBLE64        fAlgoOrderNo                                            ;
	SHORT           iStratergyId                                            ;
	CHAR            sClOrdId                [CLORDID_LEN]                   ;
	CHAR            sOrigClOrdId            [CLORDID_LEN]                   ;
	CHAR            sLastModTime            [DB_DATETIME_LEN]               ;
	CHAR            sLocCode                [LOC_CODE_LEN]                  ;
	CHAR            sOptType                [DB_OPT_TYPE_LEN]               ;
	CHAR            sMaturityMonYr          [MAT_MONYR]                     ;
	CHAR            sMaturityDay            [MAT_DAY]                       ;
	DOUBLE64        fStrikePrice                                            ;
	CHAR            sSeries                 [DB_SERIES_LEN]                 ;
	LONG32          iMktType                                                ;
	CHAR            cFreq                                      		;
	CHAR            sDateStart              [DATE_LENGTH]           	;
	SHORT           iPeriod                                              	;
	CHAR            cMarkProFlag                                    	;
        DOUBLE64        fMarkProVal                                     	;
        CHAR            cParticipantType                                	;/*B- For Broker ID and S - Participant/Clearing firm ID eg :ILFS1273622 (if B use settlor variable from db selected else if S use from above settlor varirable)*/
        CHAR            sSettlor                [SETTLOR_LEN]   		;
        CHAR            cGTCFlag                                        	;
        CHAR            cEncashFlag                                     	;
        CHAR            sPanID                  [INT_PAN_LEN]           	;
	CHAR            sNxtTrdDate             [DB_DATETIME_LEN]               ;
	DOUBLE64        fLtp							;
        DOUBLE64        fTickSize                                               ;
	CHAR            sCustomSym              [CUSTOM_SYM_LEN]                ;/**From Here we added 3 members for cuatome name lotsize and isin insertion in db.**/
        DOUBLE64        fLotSize                                                ;
        CHAR            sISINCode               [DB_ISIN_CODE_LEN]              ;
        CHAR            sInstrumentTyp          [INSTRUMENT_TYPE]               ;
        CHAR            sPlatform               [PLATFORM_LEN]                  ;
        CHAR            sChannel                [CHANNEL_LEN]                   ;


};
#pragma pack()
/**/
#pragma pack(4)
struct  SPREAD_SEC_INFO
{
	LONG32		iLegNo							;
	CHAR            sSecId                  [DB_SECURITY_ID_LEN]         	;
	CHAR            sSymbol                   [DB_SYM_LEN]               	;
	CHAR            cBuySellInd                                          	;
	CHAR           	sInstrumentType         [DB_INS_LEN]                 	;
	CHAR            sMaturityDate           [DB_DATETIME_LEN]           	;
	LONG32		iMaturityDate					     	;
	LONG32          iStrikePrice                           			;
	CHAR            sOptionType[OPT_TYPE_LEN]              			;
	LONG32          iTotalQty                                               ;
	LONG32          iRemQty                                                 ;
        LONG32          iTotalTradedQty                                         ;
	DOUBLE64        fOrderPrice                                             ;
	LONG32          iMinFillQty                                             ;
};
#pragma pack()


#pragma pack(4)	
struct INT_SPREAD_ORDERS
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader                       ;
	struct          INT_COMMON_RESP_HDR     ResHeader                       ;	
	DOUBLE64        fOrdNo                                                  ;
	LONG32          iSerialNo                                               ;
	LONG32		iNoOfLeg						;

	struct		SPREAD_SEC_INFO		SpreadArray [LEG_LEN]		;
	CHAR            sEntityId               [DB_ENTITY_ID_LEN]              ;
	CHAR            sExchOrdNo              [DB_EXCH_ORD_NO_LEN]            ;
	CHAR            sClientId               [DB_CLIENT_ID_LEN]              ;
	CHAR            cOrdStatus                                              ;
	CHAR            sEntryDate              [DB_DATETIME_LEN]               ;
	CHAR            sOrderTime              [DB_DATETIME_LEN]               ;
	//      LONG32          iTotalQty                                               ;
	//      LONG32          iRemQty                                                 ;
//	LONG32          iTotalQty                                               ;
	LONG32          iRemQty                                                 ;
	LONG32          iTotalTradedQty                                         ;
	DOUBLE64        fOrderPrice                                             ;
	DOUBLE64        fTriggerPrice						;
	SHORT           iValidity                                               ;
	SHORT           iOrderType                                              ;
	SHORT           iGoodTillDaysFlg                                        ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]               ;
	CHAR            sAccCode                [DB_ACC_CODE_LEN]               ;
	LONG32          iMinFillQty                                             ;
	CHAR            cProClient                                              ;
	CHAR            sRemarks                [DB_REMARKS_LEN]                ;
	LONG32          iSettlementDays                                         ;
	CHAR            cUserType                                               ;
	CHAR            cOrderOffOn                                             ;
	CHAR            cProductId                                              ;
	CHAR            sUserInfo               [DB_USER_INFO_LEN]              ;
	LONG32          iGrpId                                                  ;
	LONG32          iReasonCode                                             ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]            ;
	LONG32          iExchTrdNo                                              ;
	LONG32          iTrdSerialNo                                            ;
	LONG32          iTrdTransCode                                           ;
	CHAR            cTrdStatus                                              ;
	LONG32          iLstTrdQty                                              ;
	DOUBLE64        fTrdPrice                                               ;
	CHAR            sTrdTime                [DB_DATETIME_LEN]               ;
	LONG32          iTrdSeqNo                                               ;
	CHAR            cHandleInst                                             ;
	DOUBLE64        fAlgoOrderNo                                            ;
	SHORT           iStratergyId                                            ;
	CHAR            sClOrdId                [CLORDID_LEN]                   ;
	CHAR            sOrigClOrdId            [CLORDID_LEN]                   ;
	CHAR            sLastModTime            [DB_DATETIME_LEN]               ;
	CHAR            sLocCode                [LOC_CODE_LEN]                  ;
	CHAR            sOptType                [DB_OPT_TYPE_LEN]               ;
	CHAR            sMaturityMonYr          [MAT_MONYR]                     ;
	DOUBLE64        fStrikePrice                                            ;
	LONG32          iExchUserId                                             ;
	LONG32          iBranchID                                               ;
	CHAR            sBrokerCode             [BROKER_CODE_LEN]               ;
	CHAR            sSettlor                [BROKER_CODE_LEN]               ;
	LONG32          iMktType                                                ;
	CHAR            cMarkProFlag                                            ;
        DOUBLE64        fMarkProVal                                             ;
        CHAR            cParticipantType                                        ;
        CHAR            cGTCFlag                                                ;
        CHAR            cEncashFlag						; 
	CHAR 		sPanNo			[INT_PAN_LEN]			;
	LONG32          iAlgoID							;
        SHORT           iAlgoCat						;
	CHAR            sUndScripCode           [DB_SCRIP_CODE_LEN]             ;
        LONG32          iFreezeQty                                              ;
        CHAR            sSeries                 [DB_SERIES_LEN]                 ;
	CHAR            sCustomSym              [CUSTOM_SYM_LEN]                ;
	DOUBLE64        fLtp                                                    ;
        DOUBLE64        fTickSize                                               ;
	DOUBLE64	fLotSize						;
	DOUBLE64        fUnderlyPrice                                           ;
        DOUBLE64        fRmsBlockAmt                                            ;
	CHAR            sPlatform               [PLATFORM_LEN]                  ;
        CHAR            sChannel                [CHANNEL_LEN]                   ;

};
#pragma pack()
/*******/
#pragma pack(4)
struct	INT_MFSS_ORD
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader              		;
	struct          INT_COMMON_RESP_HDR     ResHeader              		;
	DOUBLE64	fOrdNo							;
	LONG32		iSerialNo						;
	CHAR		sSecId			[DB_SECURITY_ID_LEN]		;
	CHAR		sExchOrdNo		[DB_EXCH_ORD_NO_LEN]		;
	CHAR		sClientID		[DB_CLIENT_ID_LEN]		;	
	CHAR		cActionIndicator					;
	CHAR		cOrdStatus						;
	CHAR            sScheme                 [DB_SCHM_LEN]            	;
	CHAR            sSchemeName             [DB_SCHM_NAME_LEN]             	;
	CHAR            sSeries              	[DB_SERIES_LEN]                 ;
	CHAR		sIsinCode		[DB_ISIN_CODE_LEN]		;		
	CHAR            sEntryDateTime          [DB_DATETIME_LEN]               ;
	LONG32		iTotalQty						;
	LONG32		iRemQty							;
	DOUBLE64	fOrdPrice						;
	CHAR		cSIPIndicator						;
	CHAR            sAccCode                [DB_ACC_CODE_LEN]               ;	
	LONG32		iReasonCode						;
	CHAR		sReasonDesc		[DB_REASON_DESC_LEN]		;
	CHAR		cSIPFrequency						;
	INT16		iSIPPeriod						;
	CHAR            sStartDate            	[DB_DATETIME_LEN]		;
	CHAR            sLastModTime            [DB_DATETIME_LEN]		;
	CHAR		sCategory		[DB_CATEGORY_LEN]		;
	CHAR		sAMCCode		[DB_AMC_CODE_LEN]		;
	CHAR		sAMCSchemeCode		[DB_AMC_SCHM_LEN]		;
	CHAR		sRTagent		[DB_RT_AGT_CODE_LEN]		;
	CHAR		sRTSchemeCode		[DB_RT_SCH_CODE_LEN]		;
	CHAR		cSchemeDepoFlag						;
	CHAR		cSchemeDepoManFlag					;	
	CHAR            sRemarks                [DB_REMARKS_LEN]                ;
	LONG32          iErrorCode                                              ;
	LONG32          iMktType                                                ;		
	CHAR            sClOrdId                [CLORDID_LEN]                   ;
	CHAR            sOrigClOrdId            [CLORDID_LEN]                   ;
	CHAR            cUserType                                               ;
	CHAR            cOrderOffOn                                             ;
	CHAR            sUserInfo               [DB_USER_INFO_LEN]              ;
	CHAR		sSIPRejNum		[DB_SIP_REJ_NO_LEN]		;
	CHAR		sEUIN			[DB_EUIN_LEN]			;
	LONG32		iSIPTrnhNum						;
	LONG32		iBookType						;


};
#pragma pack()
/*
   struct COBO_SEC_INFO
   {
   CHAR            sClOrdId                [CLORDID_LEN]                   ;
   DOUBLE64	fSqrOffPrice						;
   DOUBLE64        fTriggerPrice                                           ;
   CHAR            cBuySellInd                                             ;
   CHAR		sLegValue[3]						;
   };
 */

#pragma pack(4)
struct INT_COBO_ORDERS
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader                       ;
	struct          INT_COMMON_RESP_HDR     ResHeader                       ;
	DOUBLE64        fOrdNo                                                  ;
	LONG32		iSerialNo                                               ;
	CHAR            sSecId                  [DB_SECURITY_ID_LEN]            ;
	CHAR            sEntityId               [DB_ENTITY_ID_LEN]              ;
	CHAR            sExchOrdNo              [DB_EXCH_ORD_NO_LEN]            ;
	CHAR            sClientId               [DB_CLIENT_ID_LEN]              ;
	CHAR            cBuySellInd                                             ;
	CHAR            cOrdStatus                                              ;
	CHAR            sSymbol                 [DB_SYM_LEN]                    ;
	CHAR            sSymbolName             [DB_SYM_NAME_LEN]               ;
	CHAR            sSymbolSfx              [DB_SERIES_LEN]                 ;
	CHAR            sEntryDate              [DB_DATETIME_LEN]               ;
	CHAR            sOrderTime              [DB_DATETIME_LEN]               ;
	LONG32          iExpiryDate                                             ;
	LONG32          iTotalQty                                               ;
	LONG32          iRemQty                                                 ;
	LONG32          iDiscQty                                                ;
	LONG32          iDiscRemQty                                             ;
	LONG32          iTotalTradedQty                                         ;
	DOUBLE64        fOrderPrice                                             ;
	DOUBLE64        fTriggerPrice                                           ;
	CHAR            sInstrumentType         [DB_INS_LEN]                    ;
	SHORT           iValidity                                               ;
	SHORT           iOrderType                                              ;
	SHORT           iGoodTillDaysFlg                                        ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]               ;
	CHAR            sAccCode                [DB_ACC_CODE_LEN]               ;
	LONG32          iMinFillQty                                             ;
	CHAR            cProClient                                              ;
	CHAR            sRemarks                [DB_REMARKS_LEN]                ;
	LONG32          iSettlementDays                                         ;
	CHAR            cUserType                                               ;
	CHAR            cOrderOffOn                                             ;
	CHAR            cProductId                                              ;
	CHAR            sUserInfo               [DB_USER_INFO_LEN]              ;
	LONG32          iGrpId                                                  ;
	LONG32          iReasonCode                                             ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]            ;
	LONG32          iExchTrdNo                                              ;
	LONG32          iTrdSerialNo                                            ;
	LONG32          iTrdTransCode                                           ;
	CHAR            cTrdStatus                                              ;
	LONG32          iLstTrdQty                                              ;
	DOUBLE64        fTrdPrice                                               ;
	CHAR            sTrdTime                [DB_DATETIME_LEN]               ;
	LONG32          iTrdSeqNo                                               ;
	CHAR            cHandleInst                                             ;
	DOUBLE64        fAlgoOrderNo                                            ;
	SHORT           iStratergyId                                            ;
	CHAR            sClOrdId                [CLORDID_LEN]                   ;
	CHAR            sOrigClOrdId            [CLORDID_LEN]                   ;
	CHAR            sLastModTime            [DB_DATETIME_LEN]               ;
	CHAR            sLocCode                [LOC_CODE_LEN]                  ;
	CHAR            sOptType                [DB_OPT_TYPE_LEN]               ;
	CHAR            sMaturityMonYr          [DB_DATETIME_LEN]               ;
	CHAR            sMaturityDay            [MAT_DAY]                       ;
	DOUBLE64        fStrikePrice                                            ;
	CHAR            sSeries                 [DB_SERIES_LEN]                 ;
	LONG32          iAuctionNum                                             ;
	LONG32          iExchUserId                                             ;
	LONG32          iBranchID                                               ;
	CHAR            sBrokerCode             [BROKER_CODE_LEN]               ;
	CHAR            sSettlor                [BROKER_CODE_LEN]               ;
	LONG32          iMktType                                                ;
	INT16           iLegValue                                               ;
	INT16           iNoOfLeg                                                ;
	CHAR            cSLFlag                                                 ;
	CHAR            cPBFlag                                                 ;
	DOUBLE64        fSLTikAbsValue                                          ;
	DOUBLE64        fPBTikAbsValue                                          ;
	CHAR            cPreOpenFlag                                            ;
	LONG32		iChildLegsUniqId					;
	DOUBLE64	fTrailingSLValue					;
	CHAR            sPanNo  [INT_PAN_LEN]                                   ;
        LONG32          iAlgoID                                                 ;
        INT16           iAlgoCat                                                ;
        CHAR            cMarkProFlag                                            ;
        DOUBLE64        fMarkProVal                                             ;
        CHAR            cParticipantType                                        ;
        CHAR            cGTCFlag                                                ;
        CHAR            cEncashFlag                                             ;
        CHAR            cCrossCurFlag                                           ;
        DOUBLE64        fRBIRefRate                                             ;
	DOUBLE64	fLtp							;	
	CHAR		sCustomSym		[CUSTOM_SYM_LEN]		;
	DOUBLE64	fLotSize						;
	CHAR		sISINCode		[DB_ISIN_CODE_LEN]		;		
	CHAR		sInstrumentTyp 		[INSTRUMENT_TYPE]		;		
	CHAR            sBse_Algo_id            [BSE_INT_ALGO_ID_LEN]           ;
	DOUBLE64	fTickSize						;		
	CHAR            sUndScripCode           [DB_SCRIP_CODE_LEN]             ;
        LONG32          iFreezeQty                                              ;
	CHAR            sPlatform		[PLATFORM_LEN]             	;
	CHAR            sChannel		[CHANNEL_LEN]             	;
	CHAR            sFiller			[50]             		;
        /*INTEROPS CHANGES*/
        CHAR            sIntropScripCode        [DB_SECURITY_ID_LEN]                            ;
        CHAR            sIntropSymbol           [DB_SYM_LEN]                            ;
        CHAR            sNseScripCode           [DB_SECURITY_ID_LEN]                            ;
        CHAR            sBseScripCode           [DB_SECURITY_ID_LEN]                            ;

	CHAR            sSmExpiryFlag           [DB_EXPIRY_FLAG_LEN]            ;

	CHAR            sNearFutScrptId         [DB_SECURITY_ID_LEN]    ;
        DOUBLE64        fMppOrdPrice                                    ;
        DOUBLE64        fSlMppOrdPrice                                  ;
        DOUBLE64        fMppBlkPrice                                    ;
        DOUBLE64        fSlMppBlkPrice                                  ;
};
#pragma pack()


#pragma pack(4)
struct INT_BSE_STAR_ORDERS
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader                       ;
	struct          INT_COMMON_RESP_HDR     ResHeader                       ;			
	CHAR    sTransCode              [DB_TRANSCODE_LEN]          ;
	CHAR    sScripID                [DB_SCHEME_TOKEN_LEN]      ;
	CHAR    sScripCode              [DB_SCRIP_CODE_LEN]        ;
	CHAR    cBuySell                                        ;
	CHAR    sBuySellType            [DB_BUY_SELL_TYPE]         ;
	CHAR    sClientCode             [DB_CLIENT_CODE_LEN]       ;
	CHAR    sMemberId               [DB_MEMBER_ID_LEN]         ;
	CHAR    cRedemDestSource                                ;
	CHAR    sAmount                 [DB_AMOUNT_LEN]            ;
	CHAR    sOrigPurchaseAmnt       [DB_ORG_PURCHASE_AMOUNT_LEN];
	CHAR    sRedemQty               [DB_REDEM_QTY]             ;
	CHAR    sOrigRedemQty           [DB_ORG_REDEM_QTY]         ;
	CHAR    sFolioNo                [DB_FOLIO_NO_LEN]          ;
	CHAR    cKycStatus                                      ;
	CHAR    sRemarks                [DB_BSE_MF_REMARKS_LEN]            ;
	CHAR    sLoginId                [DB_LOGIN_ID_LEN]          ;
	CHAR    sBranchCode             [DB_BRANCH_CODE]           ;
	CHAR    sDealerId               [DB_DEALER_ID_LEN]         ;
	CHAR    sRefNo                  [DB_REFERENCE_NO]          ;
	CHAR    sSession                [DB_SESSION_LEN]           ;
	CHAR    sOrderNo                [DB_ORDER_NO_LEN]          ;
	CHAR    sLastModDate            [DB_LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [DB_LAST_MODIFIED_TIME_LEN];
	CHAR    sSubBrokerCode          [DB_SUB_BROK_CODE_LEN]     ;
	CHAR    sEuinCode               [DB_EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR    sMinRedemFlag           [DB_MIN_REDEM_FLAG]        ;
	CHAR    sSubBrokerArnCode       [DB_SUB_BROK_ARN_CODE]     ;
	CHAR	sActionCode		[DB_ACTION_CODE_LEN]       ;
	CHAR    sFiller2                [DB_FILLER_LEN_25]         ;
	CHAR    sFiller3                [DB_FILLER_LEN_25]         ;
	CHAR    sFiller4                [DB_FILLER_LEN_20]         ;
	CHAR    sFiller5                [DB_FILLER_LEN_20]         ;
	CHAR    sFiller6                [DB_FILLER_LEN_20]         ;
};
#pragma pack()

#pragma pack(4)
struct INT_MUL_LEG_SEC_DETAILS
{
	CHAR            sSecId                  [DB_SECURITY_ID_LEN]            ;
	CHAR            cBuySellInd												;
	CHAR            sEntryDate              [DB_DATETIME_LEN]               		;
	CHAR            sSymbol                 [DB_SYM_LEN]                    ;
	CHAR            sSymbolName             [DB_SYM_NAME_LEN]               ;
	CHAR            sSymbolSfx              [DB_SERIES_LEN]                 ;
	CHAR            cPreOpenFlag                                            ;
	DOUBLE64        fTriggerPrice                                           ;
	SHORT           iOrderType                                              ;
	LONG32          iExpiryDate                                             ;
	LONG32          iTotalQty                                               ;
	LONG32          iRemQty                                                 ;
	LONG32          iDiscQty                                                ;
	LONG32          iDiscRemQty                                             ;
	LONG32          iTotalTradedQty                                         ;
	DOUBLE64        fOrderPrice                                             ;
	DOUBLE64        fStrikePrice                                            ;
	CHAR            sOptType                [DB_OPT_TYPE_LEN]               ;
	CHAR            sInstrumentType         [DB_INSTRU_LEN]                 ;
	CHAR            sMaturityMonYr          [DB_DATETIME_LEN]               ;
	CHAR            sMaturityDay            [MAT_DAY]                       ;
	DOUBLE64        fTrdPrice                                               ;
	CHAR            cCrossCurFlag                                           ;
	LONG32          iLstTrdQty                                              ;
	LONG32          iMinFillQty                                             ;
	CHAR		sCustomSym		[CUSTOM_SYM_LEN]		;/**From Here we added 3 members for cuatome name lotsize and isin insertion in db.**/
	DOUBLE64	fLotSize						;
	CHAR		sIsinCode		[DB_ISIN_CODE_LEN]		;		
};
#pragma pack()

#pragma pack(4)
struct INT_MUL_LEG_ORDERS
{
	struct          INT_COMMON_REQUEST_HDR  ReqHeader                       ;
	struct          INT_COMMON_RESP_HDR     ResHeader                       ;
	LONG32		iNoOfLeg						;
	DOUBLE64        fOrdNo                                                  ;
	LONG32          iSerialNo                                               ;  
	CHAR            sEntityId               [DB_ENTITY_ID_LEN]              ;
	CHAR            sExchOrdNo              [DB_EXCH_ORD_NO_LEN]            ;
	CHAR            sClientId               [DB_CLIENT_ID_LEN]              ;

	struct 		INT_MUL_LEG_SEC_DETAILS SecDetails[LEG_LEN]			;

	CHAR            cOrdStatus                                              ;     
	CHAR            sOrderTime              [DB_DATETIME_LEN]               ; 
	SHORT           iValidity                                               ;   
	SHORT           iGoodTillDaysFlg                                        ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]               ;
	CHAR            sAccCode                [DB_ACC_CODE_LEN]               ;
	CHAR            cProClient                                              ;
	CHAR            sRemarks                [DB_REMARKS_LEN]                ;
	LONG32          iErrorCode                                              ;
	LONG32          iSettlementDays                                         ;
	CHAR            cUserType                                               ;
	CHAR            cOrderOffOn                                             ;
	CHAR            cProductId                                              ;
	CHAR            sUserInfo               [DB_USER_INFO_LEN]              ;
	LONG32          iGrpId                                                  ;
	LONG32          iReasonCode                                             ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]            ;
	LONG32          iExchTrdNo                                              ;
	LONG32          iTrdSerialNo                                            ;
	LONG32          iTrdTransCode                                           ;
	CHAR            cTrdStatus                                              ;
	CHAR            sTrdTime                [DB_DATETIME_LEN]               ;
	LONG32          iTrdSeqNo                                               ;
	CHAR            cHandleInst                                             ;
	DOUBLE64        fAlgoOrderNo                                            ;
	SHORT           iStratergyId                                            ;
	CHAR            sClOrdId                [CLORDID_LEN]                   ;
	CHAR            sOrigClOrdId            [CLORDID_LEN]                   ;
	CHAR            sLastModTime            [DB_DATETIME_LEN]               ;
	CHAR            sLocCode                [LOC_CODE_LEN]                  ;
	CHAR            sSeries                 [DB_SERIES_LEN]                 ;
	LONG32          iAuctionNum                                             ;
	LONG32          iExchUserId                                             ;
	LONG32          iBranchID                                               ;
	CHAR            sBrokerCode             [BROKER_CODE_LEN]               ;
	CHAR            sSettlor                [SETTLOR_LEN]                   ;
	LONG32          iMktType                                                ;
	INT16           iLegValue                                               ;
	LONG32          iChildLegsUniqId                                        ;
	CHAR            sPanNo  [INT_PAN_LEN]                                   ;
	LONG32          iAlgoID                                                 ;
	INT16           iAlgoCat                                                ;
	CHAR            cMarkProFlag                                            ;
	DOUBLE64        fMarkProVal                                             ;
	CHAR            cParticipantType                                        ;
	CHAR            cGTCFlag                                                ;
	CHAR            cEncashFlag                                             ;
	DOUBLE64        fRBIRefRate                                             ;
	CHAR		sCustomSym		[CUSTOM_SYM_LEN]		;
	DOUBLE64	fLotSize						;
};
#pragma pack()

