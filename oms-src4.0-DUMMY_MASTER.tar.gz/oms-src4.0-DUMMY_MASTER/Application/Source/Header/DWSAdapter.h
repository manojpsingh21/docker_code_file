#ifndef _DWS_COMMON_H__
#define _DWS_COMMON_H__

struct USER_SOCKET_LOOKUP
{
	CHAR User[USER_ID_LEN]  ;
	CHAR ClientId[CLIENT_ID_LEN]  ;
	LONG32   Socket    ;
	SSL* cSSL; //added this field for SSL 
	CHAR sIPAdd[IP_ADDR_LEN]  ;//declare this variavle to store ip address of clients
	pthread_mutex_t UserSocketLock ;
};

struct PROCESS_LOOKUP
{
	LONG32    RelayId;
	LONG32    ProcessId;
	LONG32    RelayPort;
	LONG32    NoOfUsers;
};

#pragma pack(4)
struct VIEW_COMMON_QUERY_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN];
	//	CHAR	sSymbol [SYMBOL_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_HOLDING_QUERY_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN];
	CHAR    sISINCode[DB_SYM_LEN];
};
#pragma pack()


#pragma pack(4)
struct SUB_VIEW_CLIENT_LIMIT
{
	DOUBLE64        fLimitSOD;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fReceivables;
	DOUBLE64        fBankHoldings;
	DOUBLE64        fCollaterals;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fSumofAll;
	DOUBLE64        fAvailableBal;
	DOUBLE64        fClearBalance;
	CHAR            sLimitType[12];
	CHAR		sSegment;
	DOUBLE64        fReqPayOutAmt;	
	DOUBLE64        fCFOptSellPrm;
        DOUBLE64        fCFOptSellPrmComm;
        CHAR            sClientName[ENTITY_NAME_LEN];
	DOUBLE64	fGrossHoldVal;
	DOUBLE64	fMtmValue;
};
#pragma pack()



#pragma pack(4)
struct VIEW_CLIENT_LIMIT_RESP_NEW
{
	struct      INT_COMMON_RESP_HDR     IntRespHeader       ;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR    	cMsgType;
	struct  SUB_VIEW_CLIENT_LIMIT   sSubViewClientlimit[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_NET_POSITION
{
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchId[EXCHANGE_LEN];
	LONG32        	iBuyQty;
	LONG32	        iBuyQtyCF;
	LONG32        	iBuyQtyDay;
	DOUBLE64        fBuyVal;
	DOUBLE64        fBuyValCF;
	DOUBLE64        fBuyValDay;
	DOUBLE64        fBuyAvg;
	LONG32	        iSellQty;
	LONG32        	iSellQtyCF;
	LONG32        	iSellQtyDay;
	DOUBLE64        fSellVal;
	DOUBLE64        fSellValCF;
	DOUBLE64        fSellValDay;
	DOUBLE64        fSellAvg;
	LONG32        	iNetQty;
	DOUBLE64        fNetVal;
	DOUBLE64        fNetAvg;
	DOUBLE64        fGrossQty;
	DOUBLE64        fGrossVal;
	CHAR            sMktType[MARKET_LEN];
	CHAR            cProductId;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fMTM;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	LONG32		iRef_ID;
	CHAR		cCross_Cur_Flag;
	DOUBLE64	fRBI_REF_RATE;
//	DOUBLE64	fGrossHoldVal;
};
#pragma pack()

#pragma pack(4)
struct VIEW_NET_POSITION_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_NET_POSITION subnetpos[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_ORDER_BOOK
{
	DOUBLE64        fOrderNo                                        ;
	LONG32          iSerialNo                                       ;
	CHAR            sBuySellInd[BUY_SELL_LEN]                       ;
	CHAR            sSecurityID[SECURITY_ID_LEN]                    ;
	CHAR            sOrderType[ORD_TYP_LEN]                        ;
	DOUBLE64        fQty                                            ;
	DOUBLE64        fRemQty                                         ;
	DOUBLE64        fDQQty                                          ;
	DOUBLE64        fDQQtyRem                                       ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTrgPrice                                       ;
	DOUBLE64        fTradeQty                                       ;
	CHAR            sProduct[PRODUCT_LEN]                           ;
	CHAR            sValidity[VALIDITY_LEN]                         ;
	CHAR            sExchOrderNumber[NSE_EXCH_ORDER_NO_LEN]         ;
	CHAR            sDatetime[DATE_LENGTH]                          ;
	LONG32          iTranscode                                      ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            cSegment                                        ;
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	LONG32          iDateTime                                       ;
	/*----------------Latest Changes-----------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]    ;
	CHAR            cProClient                                      ;
	DOUBLE64                fTrdPrice                               ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16		iLegValue					;
	DOUBLE64 	fAlgoOrderNo					;
	CHAR            sPanID                  [INT_PAN_LEN]           ;
        CHAR            cParticipantType                                ;
        CHAR            cMarkProFlag                                    ;
	DOUBLE64        fMarkProVal                                     ;
	CHAR            sSettlor                [SETTLOR_LEN]   		;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
	CHAR		sMktType		[MKT_TYPE_LEN]		;
//	LONG32		iGrpId						;
/**
	DOUBLE64	fSLAbsTick					;
	DOUBLE64	fPRAbsTick					;
	CHAR		cSLAtFlag					;
	CHAR		cPRStFlag					;
	DOUBLE64	fTrailingVal					;	
**/				
};
#pragma pack()

#pragma pack(4)
struct VIEW_ORDER_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
//	struct SUB_VIEW_ORDER_BOOK suborderbook[1];
	struct SUB_VIEW_ORDER_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_ORDER_BOOK_DETAIL_RESP
{
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	LONG32          iTranscode;
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sFlags[FLAG_LEN];  /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli,7-SourceFlag*/
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradePrice;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	CHAR            sProduct;
	CHAR            sExchOrderNumber[NSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_STRING_LENGTH];
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sBuySellInd[BUY_SELL_LEN];
	CHAR            sOrdReasonDesc[ORDER_REASON_LEN]		;
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            cProClient                                      ;
	// LONG32          fTrdPrice                                       ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	INT16		iLegValue	;
	LONG32		iChildLegsUniqId ;
	CHAR            sPanID                  [INT_PAN_LEN]           ;
        CHAR            cParticipantType                                ;
        CHAR            cMarkProFlag                                    ;
	DOUBLE64        fMarkProVal                                     ;
        CHAR            sSettlor                [SETTLOR_LEN]           ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
        CHAR            sMktType                [MKT_TYPE_LEN]          ;
};
#pragma pack()

#pragma pack(4)
struct VIEW_ORDER_BOOK_DETAIL_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_ORDER_BOOK_DETAIL_RESP suborderbookdtls[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_BRACKET_ORDER_BOOK_DETAIL_RESP
{
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	LONG32          iTranscode;
	CHAR            sSecurityID[SECURITY_ID_LEN];
	//        CHAR            sFlags[10];  /*0-DAY, 1-IOC,2-MKT,3-SL,4-AON,5-DQ,6-Pro/Cli,7-SourceFlag*/
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradePrice;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	CHAR            cProduct;
	CHAR            sExchOrderNumber[EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_STRING_LENGTH];
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sBuySellInd[BUY_SELL_LEN];
	CHAR            sOrdReasonDesc[200];
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            cProClient                                      ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	INT16           iLegValue       				;
	DOUBLE64 	fAlgoOrderNo					;
	SHORT           iOrderType                                      ;
	SHORT           iOrderValidity                                  ;
};
#pragma pack()



#pragma pack(4)
struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_BRACKET_ORDER_BOOK_DETAIL_RESP suborderbookdtls[5];
};
#pragma pack()



#pragma pack(4)
struct SUB_VIEW_TRADE_BOOK
{
	DOUBLE64        fOrderNo;
	CHAR            sBuySellInd[BUY_SELL_LEN];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExchOrderNumber[NSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sOrderType[ORD_TYP_LEN];
	CHAR            sProduct[PRODUCT_LEN];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];
	LONG32          iDateTime;
	/*------------LAYESY CHANGES-------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16		iLegValue					;
	CHAR            sPanID                  [INT_PAN_LEN]           ;
        CHAR            cParticipantType                                ;
        CHAR            cMarkProFlag                                    ;
	DOUBLE64        fMarkProVal                                     ;
	CHAR            sSettlor                [SETTLOR_LEN]   		;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
	CHAR		sMktType		[MKT_TYPE_LEN]		;	
};
#pragma pack()

#pragma pack(4)
struct VIEW_TRADE_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_TRADE_BOOK subTradeBook[5];
};
#pragma pack()
/**
#pragma pack(4)
struct SUB_VIEW_CLIENT_HOLDINGS
{
CHAR            sSecurityID[SECURITY_ID_LEN];
CHAR            sISINCode[15];
CHAR            sSecuritySource[SEC_SOURCE_LEN];
LONG32          iQty;
LONG32          iQtyUtilized;
LONG32          iRemQty;
CHAR            sExcgId[EXCHANGE_LEN];
CHAR            sSymbol[SECURITY_ID_LEN];
};
#pragma pack()
 **/

#pragma pack(4)
struct SUB_VIEW_CLIENT_HOLDINGS
{
	CHAR            sNseSecurityID[SECURITY_ID_LEN];
	CHAR            sBseSecurityID[SECURITY_ID_LEN];
	CHAR            sISINCode[ISINCODE_LEN];
	CHAR            sSecuritySource[SEC_SOURCE_LEN];
	LONG32          iQty;
	LONG32          iQtyUtilized;
	LONG32          iRemQty;
	CHAR            sExcgId[EXCHANGE_LEN];
	CHAR            sNseSymbol[SECURITY_SYM_LEN];
	CHAR            sBseSymbol[SECURITY_SYM_LEN];
	CHAR            sClientId[CLIENT_ID_LEN];
	DOUBLE64        fLtp;
	DOUBLE64        fMarketValue;
	DOUBLE64        fCostPrice;
	CHAR            sNseSeries[HLD_SERIES_LEN];
        CHAR            sBseSeries[HLD_SERIES_LEN];
        DOUBLE64        fCollateral;

};
#pragma pack()

#pragma pack(4)
struct VIEW_CLIENT_HOLDINGS_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	//      CHAR    sClientId[CLIENT_ID_LEN];
	struct SUB_VIEW_CLIENT_HOLDINGS subClientHoldings[5];
};
#pragma pack()


#pragma pack(4)
struct VIEW_NET_POSITION_DATA_DETAIL
{
	struct VIEW_COMMON_QUERY_REQ commonquery;
	CHAR    sSecurityID[SECURITY_ID_LEN];
	CHAR    cProductID;
};

#pragma pack()



#pragma pack(4)
struct DWS_DNLD_SYS_MESGS_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR            cMsgType;
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sGenralMsg[SYSTEM_MSG_LEN];
	LONG32          iMsgCode;

};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_REJECTED_ORDERS
{
	DOUBLE64        fOrderNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	CHAR            sOrderType[8];
	CHAR            sProduct[10];
	LONG32          iQty;
	DOUBLE64        fOrdPrice;
	LONG32          iInSuffQty;
	DOUBLE64        fInSuffAmt;
	DOUBLE64        fAmtBlocked;
	CHAR            sRmsStatus[10];
	CHAR            cMktOrder;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            cSegment;
	CHAR            sExcgId[EXCHANGE_LEN];

};
#pragma pack()

#pragma pack(4)
struct VIEW_REJECTED_ORDERS_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_REJECTED_ORDERS subRejOrdBook[5];
};
#pragma pack()


#pragma pack(4)
struct SUB_DWS_ORD_REQ_SPREAD_2L_3L
{
	CHAR            sSecurityId[SECURITY_ID_LEN]      ;
	CHAR            cBuyOrSell                        ;
};
#pragma pack()

#pragma pack(4)
struct DWS_SPREAD_REQUEST
{
	struct          INT_COMMON_REQUEST_HDR              ReqHeader       ;
	CHAR            sEntityId[ENTITY_ID_LEN]                ;
	CHAR            sClientId[CLIENT_ID_LEN]                ;
	CHAR            cProductId                              ;
	SHORT           iOrderType                              ;
	CHAR            cProCli                                 ;
	DOUBLE64        fOrderNum                               ;
	LONG32          iTotalQtyRem                            ;
	LONG32          iTotalQty                               ;
	LONG32          iTotalTradedQty                         ;
	LONG32          iMinFillQty                             ;
	DOUBLE64        fPriceDiff                              ;
	SHORT           iOrderValidity                          ;
	INT16           iSerialNum                              ;
	CHAR            sRemarks[REMARKS_LEN]                   ;
	CHAR            sSettlor[SETTLOR_LEN]                   ;
	INT16           GoodTillDays                            ;
	CHAR            GoodTillDate[DATE_LEN]                  ;
	CHAR            cHandleInst                             ;
	LONG32          iNoOfLeg                                ;
	struct          SUB_DWS_ORD_REQ_SPREAD_2L_3L    sSprdLeg[LEG_LEN];
	CHAR            sCBrokerCode[BROKER_CODE_LEN]           ;
	DOUBLE64        fAlgoOrderNo                            ;
	SHORT           iStratergyId                            ;
	CHAR            cUserType                               ;
	LONG32          iMktType                                ;
	CHAR            cOffMarketFlg                           ;
};
#pragma pack()


#pragma pack(4)
struct DWS_SPREAD_RESPONSE
{
	struct          INT_COMMON_REQUEST_HDR      pRespHeader           ;
	CHAR            sEntityId       [ENTITY_ID_LEN]         ;
	CHAR            sClientId       [CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID    [EXCH_ORDER_NO_LEN]     ;
	CHAR            cProductId                              ;
	SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iLastTradedQty                                  ;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	struct          SUB_ORDER_REQUEST_SPREAD_2L_3L  sSpreadLeg[LEG_LEN];
	DOUBLE64        fOrderNum                                       ;
	SHORT           iSerialNum                                      ;
	CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]    ;
	DOUBLE64        fTradePrice                                     ;
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                       ;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32          iMktType                                        ;
};
#pragma pack()

#pragma pack(4)
struct  INT_DWS_LOGON_REQ
{
	struct          INT_COMMON_REQUEST_HDR	ReqHeader;
	CHAR            sLoginId[15];
/***	CHAR            sPassword[16];
	CHAR            sPanCard[20];
***/
	CHAR            sTokenId[51];
	LONG32          iFiller;
};



#pragma pack(4)
struct  INT_DWS_LOGON_RESP
{
	struct INT_COMMON_RESP_HDR      IntRespHeader;
	CHAR            sEntityId[30];
	CHAR            sName[60];
	CHAR            AccCode[12];
	CHAR            CurrDate[20];
	CHAR            ExpiryDate[20];
	CHAR            AllowedExch[10];        /** 1-NSE EQ,1-NSE DRV,1-BSE EQ,0-BSE DRV,0-NSE CUR,0-NCDEX,0-MCX ****/
	CHAR            cfprimaryip[16];
	CHAR            cffailoverip[16];
	CHAR            dsprimaryip[16];
	CHAR            failoverip[16];
	CHAR            TransPass[16];
	SHORT           Suscriptionlevel;
	/***    CHAR            srr_version[10];****/

};
#pragma pack()
#pragma pack(4)
struct SUB_ORDER_PROCESSOR_START
{
	LONG32    RelayId;
	LONG32    RelayPort;
};
#pragma pack()

#pragma pack(4)
struct  ORDER_PROCESSOR_START_RESP
{
	struct INT_COMMON_RESP_HDR      IntRespHeader;
	LONG32          NoOfProcess;
	struct SUB_ORDER_PROCESSOR_START        sSubOrdPrcRsp[MAX_NO_OF_PROCESS];
};
#pragma pack()

struct  MESG_STRUCT
{
	LONG32  Flag;
	CHAR    Mesg_Buf[RUPEE_MAX_PACKET_SIZE];
};
#pragma pack(4)


#pragma pack(4)
struct INT_RESP_HEADER
{
        LONG32          iSeqNo                                   ;
        SHORT           iMsgLength                               ;
        SHORT           iMsgCode                                 ;
        CHAR            sExcgId[EXCHANGE_LEN]                    ;
        SHORT           iErrorId                                 ;
        LONG32          iUserIdOrLogPktId                        ;
        CHAR            cUserTypeOrLogInfoType                   ;
        LONG32          iTimeStamp                               ;
        CHAR            cSegment                                 ;
};
#pragma pack()

#pragma pack(4)
struct INT_ERRORRESPONCESEND
{
        struct INT_RESP_HEADER           IntRespHeader;
        CHAR   sErrorMessage         [ERROR_MESSAGE_LEN];
};
#pragma pack()



struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	DOUBLE64        fOrderNo;
	INT16		iLegNo;
};
#pragma pack()

#pragma pack(4)
struct VIEW_COMMON_HDR_RESP
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	/*      LONG32  iNoofPkt;*/
	CHAR    sClientId[CLIENT_ID_LEN];
};
#pragma pack()
#pragma pack(4)
struct SUB_CLIENT_CONVERT_TO_DELIVERY
{
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sExcgId[EXCHANGE_LEN];
	CHAR            cProductSource;
	CHAR            cProductDest;
	CHAR            cSide;
	DOUBLE64        fConvertPrice;
	LONG32          iQty;
	CHAR            cSegment;
};
#pragma pack()

#pragma pack(4)
struct VIEW_CLIENT_CONVERT_TO_DELIVERY
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_CLIENT_CONVERT_TO_DELIVERY subCTOD[5];
};
#pragma pack()

#pragma pack(4)
struct SEND_MSG_TO_CLIENT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR            sSender[CLIENT_ID_LEN];
	LONG32          iReceiverUserId[25];
	LONG32          iNoOfRec;
	CHAR            sMsg[SEND_MSG_LEN];
};
#pragma pack()

#pragma pack(4)
struct SEND_MSG_TO_CLIENT_RESP
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR            sSender[CLIENT_ID_LEN];
	CHAR            sMsg[SEND_MSG_LEN];
};
#pragma pack()

#pragma pack(4)
struct SUB_DEALER_MAPP
{
	CHAR    sClientString[CLI_STRING_LEN]           ;
};
#pragma pack()

#pragma pack(4)
struct DEALER_MAPP_RESP
{
	struct  INT_COMMON_RESP_HDR IntRespHeader   ;
	CHAR    cMsgType                        ;
	LONG32  iNoofRec                        ;
	struct  SUB_DEALER_MAPP subdeamapp[5]   ;
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_SPRD_ORD_BOOK
{
	DOUBLE64        fOrderNo                                        ;
	LONG32          iSerialNo                                       ;
	CHAR            sBuySellInd[BUY_SELL_LEN]                                  ;
	CHAR            sSecurityID[SEC_SPRD_LEN]                    ;
	CHAR            sOrderType[ORD_TYP_LEN]                                   ;
	DOUBLE64        fQty                                            ;
	DOUBLE64        fRemQty                                         ;
	DOUBLE64        fDQQty                                          ;
	DOUBLE64        fDQQtyRem                                       ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTrgPrice                                       ;
	DOUBLE64        fTradeQty                                       ;
	CHAR            sProduct[PRODUCT_LEN]                                    ;
	CHAR            sValidity[VALIDITY_LEN]                                    ;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN]         ;
	CHAR            sDatetime[DATE_LENGTH]                          ;
	LONG32          iTranscode                                      ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            cSegment                                        ;
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	LONG32          iDateTime                                       ;
	/*----------------Latest Changes-----------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]    ;
	CHAR            cProClient                                      ;
	DOUBLE64        fTrdPrice                                       ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16           iLegValue       ;
        DOUBLE64        fAlgoOrderNo                                    ;
        CHAR            sPanID                  [INT_PAN_LEN]           ;
        CHAR            cParticipantType                                ;
        CHAR            cMarkProFlag                                    ;
        DOUBLE64        fMarkProVal                                     ;
        CHAR            sSettlor                [SETTLOR_LEN]           ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
	CHAR		sMktType		[MKT_TYPE_LEN]		;	

};
#pragma pack()

#pragma pack(4)
struct VIEW_SPRD_ORD_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_SPRD_ORD_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	LONG32	iMode;
	LONG32	iPercent;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    cUserType;
	LONG32	iShortFallFlag;
	CHAR	sManager_Code [CONTROLLER_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct	SUB_VIEW_MARGIN_MTM_COMMON_QUERY_RESP
{
	CHAR		sClientId[CLIENT_ID_LEN];
	DOUBLE64	fTotalBal;	
	DOUBLE64	fBankHodl;
	DOUBLE64	fAdhoc;
	DOUBLE64	fLimit_SOD;
	DOUBLE64	fMTMKT_EQ;
	DOUBLE64	fMTMKT_DR;
	DOUBLE64	fTotalMTM;
	DOUBLE64	fMTM_PER;
	DOUBLE64	fEXPO_EQ;
	DOUBLE64	fEXPO_EQ_GROSS;
	DOUBLE64	fEXPO_DR;
	DOUBLE64	fEXPO_DR_GROSS;
	DOUBLE64	fRealised_Profit;
	DOUBLE64	fSpan;
	DOUBLE64	fRealised_MTM;
	DOUBLE64	fShortfall_VAL;
};
#pragma pack()

#pragma pack(4)
struct	VIEW_MARGIN_MTM_COMMON_QUERY_RESP
{
	struct  INT_COMMON_RESP_HDR     IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct	SUB_VIEW_MARGIN_MTM_COMMON_QUERY_RESP	subViewMargin[5];
};
#pragma pack()

#pragma pack(4)
struct  SUB_VIEW_PERCENT_MTM_COMMON_QUERY_RESP
{
	CHAR 		sClientId[CLIENT_ID_LEN];
	DOUBLE64        fTotalBal;
	DOUBLE64        fBankHodl;
	DOUBLE64        fAdhoc;
	DOUBLE64        fLimit_SOD;
	DOUBLE64        fMTMKT_EQ;
	DOUBLE64        fMTMKT_DR;
	DOUBLE64        fTotalMTM;
	DOUBLE64        fMTM_PER;
	DOUBLE64        fEXPO_EQ;
	DOUBLE64        fEXPO_EQ_GROSS;
	DOUBLE64        fEXPO_DR;
	DOUBLE64        fEXPO_DR_GROSS;
	DOUBLE64        fRealised_Profit;
	DOUBLE64        fRealised_MTM;
	DOUBLE64        fMTM_cds;
        DOUBLE64        fExposure_cds;
        DOUBLE64        fExposure_cds_gross;
        DOUBLE64        fReceivables;
        DOUBLE64        fOpt_sell_prm;
        DOUBLE64        fCollaterals;
	DOUBLE64	fGrossHoldVal;	
	DOUBLE64        fMTMKT_COM;
	DOUBLE64	fExpo_COMM;
	DOUBLE64	fExpo_COMM_gross; 
};
#pragma pack()
#pragma pack(4)
struct VIEW_PERCENT_MTM_COMMON_QUERY_RESP
{
	struct INT_COMMON_RESP_HDR	IntRespHeader;
	CHAR	cMsgType;
	LONG32	iNoofRec;
	struct SUB_VIEW_PERCENT_MTM_COMMON_QUERY_RESP	subViewPercent[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_BO_ORDER_BOOK
{

	DOUBLE64        fOrderNo                                        ;
	LONG32          iSerialNo                                       ;
	CHAR            sBuySellInd[BUY_SELL_LEN]                                  ;
	CHAR            sSecurityID[SECURITY_ID_LEN]                    ;
	CHAR            sOrderType[ORD_TYP_LEN]                                   ;
	LONG32          iMainTranscode                                      ;
	LONG32        	iQty                                            ;
	LONG32        	iRemQty                                         ;
	DOUBLE64        fPrice                                          ;
	LONG32          iSLTranscode                                      ;
	LONG32        	iSLOrdQty                                            ;
	LONG32        	iSLRemQty                                         ;
	DOUBLE64        fSLPrice                                          ;
	LONG32          iProfTranscode                                      ;
	LONG32        	iProfQty                                            ;
	LONG32        	iProfRemQty                                         ;
	DOUBLE64        fProfPrice                                          ;
	DOUBLE64        fDQQty                                          ;
	DOUBLE64        fDQQtyRem                                       ;
	DOUBLE64        fTradeQty                                       ;
	CHAR            sProduct[PRODUCT_LEN]                                    ;
	CHAR            sValidity[VALIDITY_LEN]                                    ;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN]         ;
	CHAR            sDatetime[DATE_LENGTH]                          ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            cSegment                                        ;
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	LONG32          iDateTime                                       ;
	/*----------------Latest Changes-----------------------*/
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	LONG32          iStrategyId                                     ;
	CHAR            sReasonDesc             [DB_REASON_DESC_LEN]    ;
	CHAR            cProClient                                      ;
	DOUBLE64        fTrdPrice                                       ;
	CHAR            sGoodTillDaysDate       [DB_DATETIME_LEN]       ;
	//        CHAR            sLegValue [LEG_LEN];
	INT16           iLegValue       ;
	CHAR		sMktType[MKT_TYPE_LEN];

};
#pragma pack()

#pragma pack(4)
struct VIEW_BO_ORDER_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_BO_ORDER_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct SUB_DWS_GEN_MSG_BCAST 
{
	CHAR   sBcastMsg [ BCAST_MSG_LEN ]; 
	CHAR   sActionCode [ACTION_CODE_LEN]; 
};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_GEN_MSG_BCAST 
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_DWS_GEN_MSG_BCAST sExchmsg [2];
};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_COBO_RANGE_HDR_REQUEST
{
	struct	INT_COMMON_REQUEST_HDR 	pReqHeader;
	CHAR	sClientId[CLIENT_ID_LEN];
	CHAR	sEntityId[ENTITY_ID_LEN];
	CHAR	sScriptCode[SYMBOL_LEN];
	CHAR	cProductId	;
	CHAR	cBuySell;
};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_COBO_RANGE_HDR_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	DOUBLE64  fSLRange;
	DOUBLE64  fPLRange;
};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_ORDER_BASKET_REQUEST
{
	struct INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR		cFlag		;
	CHAR		sClientId	[CLIENT_ID_LEN];
	CHAR		sEntityId	[ENTITY_ID_LEN];
	CHAR		sBasketName	[CLIENT_NAME_LEN];
	LONG32		iBasketId	;
	CHAR		sExchId		[EXCHANGE_LEN];
	CHAR		cSegment		;
	CHAR		sScripCode	[SCRIP_CODE_LEN];
	LONG32		iQty		;
	DOUBLE64	fPrice		;
	LONG32		iOrderType	;
	CHAR		sCreateTime	[DATE_TIME_LEN];
	CHAR		cScriptStatus	;
	CHAR		cProduct	;
	CHAR		cBuySell	;
	CHAR		sUpdateTime	[DATE_TIME_LEN];
	LONG32		iOrdvalidity	;
	CHAR		sFiller1	[FILLER_LEN_20];
	CHAR		sFiller2	[FILLER_LEN_20];
	CHAR		sFiller3	[FILLER_LEN_20];
	LONG32		iSequenceId	;			
	LONG32		iMktType	;
	DOUBLE64	fTriggerPrice	;
	LONG32		iDiscQty	;
};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_ORDER_BASKET_RESPONSE
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR            cFlag           ;
	CHAR            sClientId       [CLIENT_ID_LEN];
	CHAR            sEntityId       [ENTITY_ID_LEN];
	CHAR            sBasketName     [CLIENT_NAME_LEN];
	LONG32          iBasketId       ;
	CHAR            sExchId         [EXCHANGE_LEN];
	CHAR		cSegment	;
	CHAR            sScripCode      [SCRIP_CODE_LEN];
	LONG32          iQty            ;
	DOUBLE64        fPrice          ;
	LONG32          iOrderType      ;
	CHAR            sCreateTime     [DATE_TIME_LEN];
	CHAR            cScriptStatus   ;
	CHAR            cProduct        ;
	CHAR            cBuySell        ;
	CHAR            sUpdateTime     [DATE_TIME_LEN];
	LONG32          iOrdvalidity    ;
	CHAR            sFiller1        [FILLER_LEN_20];
	CHAR            sFiller2        [FILLER_LEN_20];
	CHAR            sFiller3        [FILLER_LEN_20];
	LONG32          iSequenceId     ;
	LONG32          iMktType        ;
	DOUBLE64        fTriggerPrice   ;
	LONG32          iDiscQty        ;

};
#pragma pack()


#pragma pack(4)
struct SUB_VIEW_DWS_ORDER_BASKET_RESP
{
	CHAR            sEntityId       [ENTITY_ID_LEN];
	CHAR            sBasketName     [CLIENT_NAME_LEN];
	LONG32          iBasketId       ;
	CHAR            sExchId         [EXCHANGE_LEN];
	CHAR            sScripCode      [SCRIP_CODE_LEN];
	CHAR		cSegment	;
	LONG32          iQty            ;
	DOUBLE64        fPrice          ;
	CHAR            iOrderType      ;
	CHAR            sCreateTime     [DATE_TIME_LEN];
	CHAR            cScriptStatus   ;
	CHAR            cProduct        ;
	CHAR            cBuySell        ;
	CHAR            sUpdateTime     [DATE_TIME_LEN];
	LONG32          iOrdvalidity    ;
	CHAR            sFiller1        [FILLER_LEN_20];
	CHAR            sFiller2        [FILLER_LEN_20];
	CHAR            sFiller3        [FILLER_LEN_20];
	LONG32		iSequenceId	;
	LONG32          iMktType        ;
	DOUBLE64        fTriggerPrice   ;
	LONG32          iDiscQty        ;

};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_ORDER_BASKET_RESP
{
	struct  INT_COMMON_RESP_HDR IntRespHeader;
	struct SUB_VIEW_DWS_ORDER_BASKET_RESP suborderbasket[5];
	CHAR     cMsgType;
	LONG32   iNoOfRec;
	CHAR	 sClientId	[CLIENT_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_DWS_BASKET_NAME_RESP
{
	CHAR	sBasketName	[CLIENT_NAME_LEN];
	LONG32	iBasketId	;
	CHAR	cDelFlag	;
	CHAR	sCreateTime	;
	CHAR	cSource		;
	CHAR	sDescription	[BASKET_DESC_LEN];	
	CHAR	cBasketTyp	;
	CHAR	cAssigncat	;
	CHAR	sRiskId		[RISK_PROF_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_DWS_BASKET_NAME_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	struct SUB_VIEW_DWS_BASKET_NAME_RESP  subordername[5];
	CHAR     cMsgType;
	LONG32   iNoOfRec;
	CHAR     sClientId      [CLIENT_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_USER_DWS_BASKET_REQUEST
{
	struct INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR	cFlag		;
	CHAR	sClientId	[CLIENT_ID_LEN];
	CHAR	sBasketName	[CLIENT_NAME_LEN];
	LONG32	iBasketId	;
	CHAR	cDelFlag	;
	CHAR	sCreateTime	[DATE_TIME_LEN];
	CHAR	sDescription	[BASKET_DESC_LEN];
	CHAR    cBasketTyp      ;
	CHAR    cAssigncat      ;
	CHAR    sRiskId         [RISK_PROF_LEN];	

};
#pragma pack()

#pragma pack(4)
struct VIEW_USER_DWS_BASKET_RESPONSE
{
	struct INT_COMMON_RESP_HDR IntRespHeader;
	CHAR    cFlag           ;
	CHAR    sClientId       [CLIENT_ID_LEN];
	CHAR    sBasketName     [CLIENT_NAME_LEN];
	LONG32  iBasketId       ;
	CHAR    cDelFlag        ;
	CHAR    sCreateTime     [DATE_TIME_LEN];
	CHAR    sDescription    [BASKET_DESC_LEN];
	CHAR    cBasketTyp      ;
	CHAR    cAssigncat      ;
	CHAR    sRiskId         [RISK_PROF_LEN];

};
#pragma pack()

#pragma pack(4)
struct	SUB_VIEW_MKT_STATUS	
{
	CHAR	sExchId		[EXCHANGE_LEN]	;
	CHAR	cSegment			;
	CHAR	sMktType	[MKT_TYPE_LEN]	;				
	CHAR	sMktDesc	[MKT_DESC_LEN]	;
	CHAR	sMktStat	[STATUS_LEN]	;
};
#pragma pack()

#pragma pack(4)
struct	VIEW_MKT_STATUS
{
	struct INT_COMMON_RESP_HDR pResHeader;
	CHAR    cMsgType;
        LONG32  iNoofRec;
        struct SUB_VIEW_MKT_STATUS subMktType[5];
};
#pragma pack()

#pragma pack(4)
struct VIEW_SIP_ORDER_BOOK_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sSymbol[SECURITY_ID_LEN];
	CHAR    sStatus[SYMBOL_LEN];
	CHAR    sStartDate[DATE_TIME_LEN];
	CHAR    sExpiryDate[DATE_TIME_LEN];
	CHAR    cProduct;
	CHAR    sClientId[CLIENT_ID_LEN];
	CHAR    sPlacedBy[ENTITY_ID_LEN];
	CHAR    sEntityId[ENTITY_ID_LEN];
	CHAR    sSource[SOURCE_FLG_LEN];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_SIP_ORD_BOOK
{
	DOUBLE64        fOrderNo                                        ;
	CHAR            sSecurityID[SECURITY_ID_LEN]                    ;
	CHAR            sSymbol[SECURITY_ID_LEN];
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	CHAR            cSegment                                        ;
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            sBuySellInd[BUY_SELL_LEN]                       ;
	CHAR            sProduct[PRODUCT_LEN]                           ;
	CHAR            sStatus[ORDER_STATUS]                           ;
	CHAR            sInternalDate[DATE_LENGTH]                      ;
	DOUBLE64        fQty                                            ;
	CHAR            sValidity[VALIDITY_LEN]                         ;
	CHAR            sUserType[USER_TYPE_LEN]                        ;
	CHAR            sSourceFlg[SOURCE_FLG_LEN]                      ;
	CHAR            sReasonDesc[DB_REASON_DESC_LEN]                 ;
	CHAR            sfrequency[FREQUENCY_LEN]                       ;
	CHAR            sStartDate[DATE_LENGTH]                         ;
	CHAR            sStartEnd[DATE_LENGTH]                          ;
	SHORT           iForPeriod                                      ;
	SHORT           iSerialNo                                       ;
	CHAR            sLastTriggerDate[DATE_LENGTH]                   ;
	CHAR            sNextTriggerDate[DATE_LENGTH]                   ;
	CHAR            cMarkProFlag                                    ;
        DOUBLE64        fMarkProVal                                     ;
        CHAR            cParticipantType                                ;
        CHAR            sSettlor                [SETTLOR_LEN]           ;
        CHAR            cGTCFlag                                        ;
        CHAR            cEncashFlag                                     ;
        CHAR            sPanID                  [INT_PAN_LEN]           ;
        DOUBLE64        fPrice                                          ;

};
#pragma pack()

#pragma pack(4)
struct VIEW_SIP_ORDER_BOOK_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_VIEW_SIP_ORD_BOOK suborderbook[5];
};
#pragma pack()

#pragma pack(4)
struct VIEW_SIP_ORDER_DETAILS_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	DOUBLE64        fOrderNo                        ;
	CHAR            sClientId[CLIENT_ID_LEN]        ;
};
#pragma pack()

#pragma pack(4)
struct  VIEW_SIP_ORDER_TRAILS_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	DOUBLE64        fOrderNo;
};
#pragma pack()

#pragma pack(4)
struct SUB_SIP_ORD_TARILS_RESP
{
	DOUBLE64        fOrderNo                                        ;
	LONG32          iSerialNo                                       ;
	LONG32          iTranscode                                      ;
	CHAR            sSecurityID[SECURITY_ID_LEN]                    ;
	CHAR            sValidity[VALIDITY_LEN]                         ;
	CHAR            cProClient                                      ;
	CHAR            sSourceFlg[SOURCE_FLG_LEN]                      ;
	DOUBLE64        fQty                                            ;
	DOUBLE64        fRemQty                                         ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTradeQty                                       ;
	DOUBLE64        fTradePrice                                     ;
	DOUBLE64        fTotalTradeQty                                  ;
	LONG32          iExchTradeNo                                    ;
	CHAR            sProduct[PRODUCT_LEN]                           ;
	CHAR            sExchOrderNumber[NSE_EXCH_ORDER_NO_LEN]         ;
	CHAR            sDatetime[DATE_STRING_LENGTH]                   ;
	CHAR            sClientId[CLIENT_ID_LEN]                        ;
	CHAR            sEntityId[ENTITY_ID_LEN]                        ;
	CHAR            sBuySellInd[BUY_SELL_LEN]                       ;
	CHAR            sExcgId[EXCHANGE_LEN]                           ;
	CHAR            sOrdReasonDesc[ORDER_REASON_LEN]                ;
	CHAR            sStatus[ORDER_STATUS]                           ;
	CHAR            sSymbol[SECURITY_ID_LEN]                        ;
	CHAR            sOrderType[ORD_TYP_LEN]                         ;
	DOUBLE64        fAlgoOrderNo                                    ;
};
#pragma pack()

#pragma pack(4)
struct VIEW_SIP_ORDER_TRAILS_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR    cMsgType;
	LONG32  iNoofRec;
	struct SUB_SIP_ORD_TARILS_RESP subordertrails[5];
};
#pragma pack()


#pragma pack(4)
struct	VIEW_CLIENT_LIMIT_DTLS
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR            sClientId       [CLIENT_ID_LEN];
	DOUBLE64        fEqCNCPending   ;
	DOUBLE64        fEqMRGPending   ;
	DOUBLE64        fEqINTPending   ;
	DOUBLE64        fEqHYBPending   ;
	DOUBLE64        fEqMTFPending   ;
	DOUBLE64        fEqCNC          ;
	DOUBLE64        fEqMRGVar   ;
	DOUBLE64        fEqINTVar   ;
	DOUBLE64        fEqHYBVar               ;
	DOUBLE64        fEqMTFVar   ;
	DOUBLE64        fEquCO   ;
	DOUBLE64        fEquBO   ;
	DOUBLE64        fEqTotUtilized   ;
	DOUBLE64        fDrvMRGPending   ;
	DOUBLE64        fDrvINTPending   ;
	DOUBLE64        fDrvInt   ;
	DOUBLE64        fDrvMRG   ;
	DOUBLE64        fDrvExpoINT   ;
	DOUBLE64        fDrvExpoMRG   ;
	DOUBLE64        fDrvCO   ;
	DOUBLE64        fDrvBO   ;
	DOUBLE64        fDrvTotUtilized   ;
	DOUBLE64        fCurrMRGPending   ;
	DOUBLE64        fCurrINTPending   ;
	DOUBLE64        fCurrINT   ;
	DOUBLE64        fCurrMRG   ;
	DOUBLE64        fCurrExpoINT   ;
	DOUBLE64        fCurrExpoMRG   ;
	DOUBLE64        fCurrCO   ;
	DOUBLE64        fCurrBO   ;
	DOUBLE64        fCurrTotUtilized   ;
	DOUBLE64        fCommMRGPend;
	DOUBLE64        fCommINTPend;
	DOUBLE64        fCommINTR;
	DOUBLE64        fCommMRG;
	DOUBLE64        fCommExpoINT;
	DOUBLE64        fCommExpoMRG;
	DOUBLE64       	fCommExpoCO;
	DOUBLE64        fCommExpoBO;
	DOUBLE64        fCommTotUtiliz;
	DOUBLE64        fNseCNCRecvable   ;
	DOUBLE64        fBseCNCRecvable   ;
	DOUBLE64        fEquINTRPNL   ;
	DOUBLE64        fEquMRGRPNL   ;
	DOUBLE64        fEquCNCRPNL   ;
	DOUBLE64        fEquCORPNL   ;
	DOUBLE64        fEquBORPNL   ;
	DOUBLE64        fEqHYBRPNL   ;
	DOUBLE64        fEqMTFRPNL   ;
	DOUBLE64        fDrvINTRPNL   ;
	DOUBLE64        fDrvMRGRPNL   ;
	DOUBLE64        fDrvCORPNL   ;
	DOUBLE64        fDrvBORPNL   ;
	DOUBLE64        fCurrINTRPNL;
	DOUBLE64        fCurrMRGRPNL   ;
	DOUBLE64        fCurrCORPNL   ;
	DOUBLE64        fCurrBORPNL   ;
	DOUBLE64        fCommINTRPNL;
	DOUBLE64        fCommMRGRPNL;
	DOUBLE64        fCommCORPNL   ;
	DOUBLE64        fCommBORPNL   ;
	DOUBLE64        fSPAN1   ;
	DOUBLE64        fSPAN2   ;
	DOUBLE64        fSPAN3   ;
	DOUBLE64        fSPAN4   ;
	DOUBLE64        fSPAN5   ;
	DOUBLE64        fSPAN6   ;
	DOUBLE64        fOptSellPremiDrv   ;
	DOUBLE64        fOptSellPremiCurr   ;
	DOUBLE64        fCommSellOptPremi   ;
        DOUBLE64        fDrvHybPend ;
        DOUBLE64        fCurrHybPend;
        DOUBLE64        fDrvHybrid;
        DOUBLE64        fCurrHybrid;
        DOUBLE64        fSpanb7;
        DOUBLE64        fSpanb8;
        DOUBLE64        fDrvExpoHyb;
        DOUBLE64        fCurrExpoHyb;
        DOUBLE64        fDrvHybRpnl;
        DOUBLE64        fCurrHybRpnl;
        DOUBLE64        fCommHyb;
        DOUBLE64        fSpanb9;
        DOUBLE64        fCommHybPend;
        DOUBLE64        fCommHybRpnl;
        DOUBLE64        fCommExpoHyb;
	/**Adding 45 more parameters*/
	DOUBLE64        fTrdEqCncBroVal;
        DOUBLE64        fTrdEqMtfBroVal;
        DOUBLE64        fTrdEqMrgBroVal;
        DOUBLE64        fTrdEqIntBroVal;
        DOUBLE64        fTrdEqNrmBroVal;
        DOUBLE64        fTrdEqCoBroVal;
        DOUBLE64        fTrdEqBoBroVal;
        DOUBLE64        fTrdDrMrgBroVal;
        DOUBLE64        fTrdDrIntBroVal;
        DOUBLE64        fTrdDrNrmBroVal;
        DOUBLE64        fTrdDrCoBroVal;
        DOUBLE64        fTrdDrBoBroVal;
        DOUBLE64        fTrdCurMrgBroVal;
        DOUBLE64        fTrdCurIntBroVal;
        DOUBLE64        fTrdCurNrmBroVal;
        DOUBLE64        fTrdCurCoBroVal;
        DOUBLE64        fTrdCurBoBroVal;
        DOUBLE64        fTrdComMrgBroVal;
        DOUBLE64        fTrdComIntBroVal;
        DOUBLE64        fTrdComNrmBroVal;
        DOUBLE64        fTrdComCoBroVal;
        DOUBLE64        fTrdComBoBroVal;
        DOUBLE64        fPendEqCncBroVal;
        DOUBLE64        fPendEqMtfBroVal;
        DOUBLE64        fPendEqMrgBroVal;
        DOUBLE64        fPendEqIntBroVal;
        DOUBLE64        fPendEqNrmBroVal;
        DOUBLE64        fPendEqCoBroVal;
        DOUBLE64        fPendEqBoBroVal;
        DOUBLE64        fPendDrMrgBroVal;
        DOUBLE64        fPendDrIntBroVal;
        DOUBLE64        fPendDrNrmBroVal;
        DOUBLE64        fPendDrCoBroVal;
        DOUBLE64        fPendDrBoBroVal;
        DOUBLE64        fPendCurMrgBroVal;
        DOUBLE64        fPendCurIntBroVal;
        DOUBLE64        fPendCurNrmBroVal;
	DOUBLE64        fPendCurCoBroVal;
        DOUBLE64        fPendCurBoBroVal;
        DOUBLE64        fPendComMrgBroVal;
        DOUBLE64        fPendComIntBroVal;
        DOUBLE64        fPendComNrmBroVal;
        DOUBLE64        fPendComCoBroVal;
        DOUBLE64        fPendComBoBroVal;
        DOUBLE64        fTotalBrokVal;


};
#pragma pack()

#pragma pack(4)
struct VIEW_BRANCH_ADHOC_LIMIT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sBranchID[BRANCH_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct  VIEW_BRANCH_ADHOC_LIMIT_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	DOUBLE64        fMaxClnt;
	DOUBLE64        fMaxLmtPrClnt;
	DOUBLE64        fMaxTtlLmt;
	DOUBLE64        fAmt;
	DOUBLE64        fRemAmt;
};
#pragma pack()

#pragma pack(4)
struct ADD_BRANCH_ADHOC_LIMIT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR		sClientID[BRANCH_ID_LEN];
	CHAR    	sBranchID[BRANCH_ID_LEN];
	DOUBLE64	fAmt;
	CHAR		cTransactType;	
};
#pragma pack()

#pragma pack(4)
struct ADD_BRANCH_ADHOC_LIMIT_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR  	sStatus[DB_REASON_DESC_LEN];
};
#pragma pack()

#pragma pack(4)
struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_REQ
{
	struct  INT_COMMON_REQUEST_HDR ReqHeader;
	CHAR    sBranchID[BRANCH_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_ADDED_BRANCH_ADHOC 
{
	CHAR            sClientID[BRANCH_ID_LEN];
	CHAR            sBranchID[BRANCH_ID_LEN];
	DOUBLE64        fAmt;
	CHAR		cSegment;
};
#pragma pack()

#pragma pack(4)
struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_RESP
{
	struct INT_COMMON_RESP_HDR  IntRespHeader;
	CHAR            cMsgType;
	LONG32          iNoofRec;
	struct SUB_VIEW_ADDED_BRANCH_ADHOC  subviewBranchLimit[5];

};
#pragma pack()

#pragma pack(4)
struct INT_REQUEST_HEADER
{
	LONG32          iSeqNo                           ;
	SHORT           iMsgLength                       ;
	SHORT           iInternalTransCode               ;
	CHAR            sExcgId[EXCHANGE_LEN]            ;
	LONG32          iUserIdOrLogPktId                ;
	CHAR            cUserTypeOrLogInfoType           ;
	CHAR            cSegment                         ;
};
#pragma pack()

#pragma pack(4)
struct  VIEW_DL_PAYOUT_REPORT_REQ
{
        struct  INT_COMMON_REQUEST_HDR ReqHeader;
        CHAR    sClientId[CLIENT_ID_LEN];
        CHAR    sEntity[ENTITY_ID_LEN];
        CHAR    cPayStatus;
	CHAR    sDateFrom[DATE_TIME_LEN];
        CHAR    sDateTo[DATE_TIME_LEN];
        CHAR    sAccType[ACC_TYPE_LEN];

};
#pragma pack()

#pragma pack(4)
struct SUB_DL_VIEW_PAYOUT_REPORT_RESP
{
        LONG32          iPaymentID;
        CHAR            sClientId[CLIENT_ID_LEN];
        DOUBLE64        fPayAmount;
        CHAR            sAccountNo[BANK_ACC_NUM_LEN];
        CHAR            sIFSC_Code[IFSC_CODE_LEN];
        CHAR            sPayMode[PAY_MODE_LEN];
        CHAR            sPayStatus[ORDER_STATUS];
        CHAR            sPayStatusMsg[PAY_MODE_MSG_LEN];
        CHAR            sRequestDate[DATE_TIME_LEN];
        CHAR            sAccType[ACC_TYPE_LEN];
        CHAR            sLmtType[LIMIT_TYPE_LEN];
        CHAR            sBankName[BANK_NAME_LEN];
        CHAR            sRemark[REMARKS_LEN];
};
#pragma pack()

#pragma pack(4)
struct  VIEW_DL_PAYOUT_REPORT_RESP
{
        struct  INT_COMMON_RESP_HDR  IntRespHeader;
        CHAR    cMsgType;
        LONG32  iNoofRec;
        struct  SUB_DL_VIEW_PAYOUT_REPORT_RESP subPayoutReport[5];
};
#pragma pack()


#pragma pack(4)
struct VIEW_DP_HOLDING_QUERY_REQ
{
        struct  INT_COMMON_REQUEST_HDR ReqHeader;
        CHAR    sClientId[CLIENT_ID_LEN];
        CHAR    sEntityId[ENTITY_ID_LEN];
};
#pragma pack()

#pragma pack(4)
struct SUB_VIEW_DP_HOLDING_RESP
{
	CHAR            sRecordType[RECORD_TYPE];
        CHAR            sLineNumber[LINE_NUMBER];
        CHAR            sBranchCode[BRANCH_CODE_LEN];
        CHAR            sDPId[DP_ID_LEN];
        CHAR            sBenCategory[BEN_CATEGORY];
        CHAR            sIsin[DB_ISIN_CODE_LEN];
        CHAR            sBenAccType[BEN_ACC_TYP_LEN];
        CHAR            sBenAccPosition[BEN_ACC_POSITION_LEN];
        CHAR            sIsinStatus[ISIN_STATUS_LEN];
        CHAR            sIsinType[ISIN_TYPE_LEN];
        CHAR            sLockIn_Release_Date[DATE_TIME_LEN];
        CHAR            sBlock_Lock_code[BLOCK_LOCK_CODE];
        LONG32          iHoldQty;
        LONG32          iUnderHoldQty;
        CHAR            sClientId[CLIENT_ID_LEN];
        CHAR            cBlock_Lock_Flag;
	CHAR            sSymbol[DB_SYMBOL_LEN];

};
#pragma pack()

#pragma pack(4)
struct  VIEW_DP_HOLDING_RESP
{
        struct  INT_COMMON_RESP_HDR  IntRespHeader;
        CHAR    cMsgType;
        LONG32  iNoofRec;
        struct  SUB_VIEW_DP_HOLDING_RESP subdpHolding[5];
};
#pragma pack()

//These are structures for file download request and resopnse @suraj Start
#pragma pack(4)
struct FILE_DOWNLOAD_REQ
{
        struct      INT_COMMON_REQUEST_HDR 	IntReqHeader       ;
        CHAR        sEntityId[ENTITY_ID_LEN]			; 
        CHAR        cUserType;
};
#pragma pack()


#pragma pack(4)
struct FILE_DOWNLOAD_RESP
{
        struct      INT_COMMON_RESP_HDR     IntRespHeader       ;
        CHAR        sFileData[FILE_DATA_SIZE];
        CHAR        cMsgType;
	LONG32	    iNoofRec;
};
#pragma pack()

//END
static void init_routine (void);
void            InitUserSocketTable();
void            PrintLookup ( );
void            AssociateSocketSignal (LONG32 );
void            InitLookup ( );
LONG32          GetIndexForPacket ( CHAR * );
LONG32          SearchIndex ( LONG32 );
void            CleanSocketResour ( LONG32 );
LONG32          SendPacketToUser (LONG32 ,CHAR * );
LONG32          SendDloadPacketToUser (LONG32 ,CHAR * );
LONG32          SearchUserId ( LONG32 ,CHAR [][6], CHAR [],LONG32 * );
LONG32          SearchGlobalUserId ( LONG32 , CHAR [][6], CHAR [] );
void            SetUserId (LONG32 , CHAR *);
LONG32          SearchForFreeslot ( );
LONG32          OpenPassiveSocket ( );
void            GetPacketFromQueue ( CHAR * , LONG32 );
void            *SignalThread();
void            *ReadThread();
void            ReadWorkerThread(void *);
void            *WriteThread(LONG32 *);
void            WriteWorkerThread(struct  MESG_STRUCT *);
void            *ReadServerStartupThread(LONG32 );
LONG32        ProcessLogOnRequest(LONG32 *Index,CHAR *UserId);
void            WaitForMaxThreadCond(LONG32);
void            InitProcessTable();
void            *SignalHandler(LONG32 *RelayId,sigset_t SignalSet);
void            SignalHandlerSigio(LONG32 dummy);
void            SignalHandlerSigTerm(LONG32 );
void            SignalHandlerSigChldParent(LONG32 );
void            SignalReadThreadKillCond(LONG32);
LONG32  GetMaxSocket();
void WriteToRms(LONG32 id,CHAR * cpMsgBuf,LONG32 Size);
void LockThreadMutex ( pthread_mutex_t *, CHAR * );
void UnLockThreadMutex ( pthread_mutex_t * , CHAR *);
void ConnectToOracle ( ) ;
void ProcessArguments ( ) ;
void SqlErrorFun ( ) ;
void InitOracleRelayData ( );
void UpdateOracleRelayData ( LONG32 );
void UpdateOracleUserData (LONG32 ,LONG32  ,CHAR [][6], CHAR Segment [],char);
LONG32 WriteSearchExchSegment(CHAR [][6] , CHAR [6], CHAR [], CHAR );
void AddShmRelayData ( LONG32 ,CHAR [][6], CHAR [], struct sockaddr_in * , char);
void DeleteShmRelayData ( LONG32 ,CHAR [][6], CHAR [] );
void DeleteRelayUserShm ( LONG32 );
void WaitForMaxThreadCond ( );
void WaitForMaxThreadCondWrite ( );
LONG32 ProcessOrderProcessorStrtRequest();
void WaitForMaxDloadThreadCondWrite ( );
void SendMaxThreadCondSig ( );
void SendMaxThreadCondSigWrite ( );
void SendMaxDloadThreadCondSigWrite ( );
LONG32  CheckUserIdPassword ( LONG32 , CHAR * );
void UpdateForkProcess (LONG32 ,LONG32 ,LONG32 );
void UpdateForkProcessForRestart (LONG32 );
void DeleteRelayMaster ( );
void ProcessIncomePacket ( CHAR *,LONG32 , LONG32 );
void SendErrorResponce ( CHAR * , LONG32 );
void SendLogonResponce ( CHAR * , LONG32 );
LONG32  GetTimeStamp ( );
void RelayLogFatal (CHAR * );
void RelayLogMessage (CHAR * );
void Sleep (LONG32 );
void CheckPeerAddr ( struct sockaddr *,LONG32 );
void UpdatePeerAddr ( struct sockaddr *,LONG32 ,LONG32 );
void CleanUserResour ( );
void catch_alarm ( LONG32 );
void SendLogonErrorResponce (CHAR *,LONG32 );
void FindUserClient     ( LONG32 ,CHAR [][6], CHAR [] ,CHAR *);

#endif
