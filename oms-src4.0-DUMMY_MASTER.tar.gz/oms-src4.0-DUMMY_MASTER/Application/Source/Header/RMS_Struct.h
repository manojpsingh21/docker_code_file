#ifndef __RMS_SPAN_H__
#define __RMS_SPAN_H__

#pragma pack(4)
struct RMS_Span_Margin
{
	DOUBLE64        fSpan1                                          ;
	DOUBLE64        fSpan2                                          ;
	DOUBLE64        fSpan3                                          ;
	DOUBLE64        fSpan4                                          ;
	DOUBLE64        fSpan5                                          ;
	DOUBLE64        fSpan6                                          ;
	DOUBLE64        fSpan7                                          ;
	DOUBLE64        fSpan8                                          ;
	DOUBLE64        fSpan9                                          ;
	DOUBLE64        fSpan10                                         ;
	DOUBLE64        fSpan11                                         ;
	DOUBLE64        fSpan12                                         ;
	DOUBLE64        fSpan13                                         ;
	DOUBLE64        fSpan14                                         ;
	DOUBLE64        fSpan15                                         ;
	DOUBLE64        fSpan16                                         ;
	DOUBLE64        fDelta                                          ;
	DOUBLE64        fOpt_Premium                                    ;
	CHAR            sUpdated_Date           [DB_DATETIME_LEN]       ;
	DOUBLE64        fSpanMargin                                     ;
	DOUBLE64        fExpoMargin                                     ;
	DOUBLE64        fSOM                                            ;
	CHAR            sUnderlying_SecID       [DB_SECURITY_ID_LEN]    ;
	CHAR            sUnderlying_Sym         [DB_SYM_NAME_LEN]       ;
	DOUBLE64	fDelta_Spread					;		
	DOUBLE64 	fDrv_LTP					;

};
#pragma pack()





#pragma pack(4)
struct RMS_Security
{
	struct          RMS_Span_Margin         RmsSpan                         ;
	CHAR            sExch                   [DB_EXCH_ID_LEN]                ;
	CHAR            cSeg                                                    ;
	LONG32          iScripCode              			        ;
	CHAR            sExchScripCode          [DB_SCRIP_CODE_LEN]             ;
	CHAR            sSym                    [DB_SYM_LEN]                    ;
	CHAR            sSymName                [DB_SYM_NAME_LEN]               ;
	CHAR            sInsName                [DB_INS_LEN]                    ;
	CHAR            sExpiryDate             [DB_DATETIME_LEN]               ;
	DOUBLE64        fStrikePrice                                            ;
	CHAR            sOptType                [DB_OPT_TYPE_LEN]               ;
	CHAR            sUndScripCode           [DB_SCRIP_CODE_LEN]             ;
	UT_hash_handle  H_By_ID                                         	;
};

#pragma pack()

#pragma pack(4)
struct Hash
{
	CHAR            cSeg;
	CHAR            cStatus;
	LONG32          iSecID;
	CHAR            sSymbol[DB_SYM_NAME_LEN];
	UT_hash_handle  hh;
	//UT_hash_handle  H_By_ID;
};
#pragma pack()
#endif

