#ifndef      __BSEBCAST__
#define      __BSEBCAST__

#define         MAX_SIZE                        100
#define         MAX_PACKET_SIZE_COMPRESS        1600
#define   	MCX_CONST_PRICE_FACTOR       	100

#define     	TC_MCX_MBP_BCAST        	31038
#define 	TC_MKT_STATS_RPT_BCAST		1833
#define 	TC_MCX_EXCH_MSGS		6501


//typedef BOOL  (*P_TO_FUN)(CHAR * x);

BOOL dTC_MBP_BCAST 	(char * NNFData);
BOOL dTC_MKT_STATS_RPT_BCAST (char * NNFData);
struct TRANS_FUN_PAIR
{
	INT16  Transcode;
//	P_TO_FUN  pToFun;
};
#pragma pack(1)

struct  MCX_BCAST_HEADER
{
	CHAR	cResved1		;
	CHAR	cResved2		;
	CHAR	cResved3		;
	CHAR	cResved4		;
	CHAR	cResved5		;
	LONG32	iExchTime	;
	SHORT	iMsgCode	;
	SHORT 	iReserved	;
	LONG32	iReserved1	;
	SHORT	iMsgLegth	;
	SHORT	iReserved2	;
	
//	LONG32	iMsgLegth	;
//	LONG32	iMsgCode	;
//	CHAR	sExchId	[EXCHANGE_LEN]	;
//	CHAR	cSegment	;
	
};
#pragma pack()

#pragma pack(1)
struct  SUB_MCX_MBP
{
	LONG32          iTotalQty;      /*** Total Qty for which orders are available in mkt***/
	LONG32          iOrderPrice;
	LONG32          iTotalNoOrders;
	SHORT           iReserved4;
};
#pragma pack()

#pragma pack(1)
struct MCX_OPEN_INTREST_DTLS
{
	LONG32          iOpenIntrest;
};
#pragma pack()

#pragma pack(1)
struct  BCAST_INSTRU_INFO
{
	CHAR	sReserved1 [7];
	CHAR	sIntruCode[11];
	CHAR	sReserved[5];
	LONG32	sExpiryDate;
	CHAR   	sReserved2[11] ;
};
#pragma pack()


#pragma pack(1)
struct MKT_CLOSE_STATISTICS
{
	struct  	MCX_BCAST_HEADER        sHeader ;
	CHAR		sReserved1	[2];
	struct 		BCAST_INSTRU_INFO	sBcastInstruInfo;
	SHORT		sReserved2	;
	LONG32 		iOpenPrice	;
	LONG32  	iHighPrice	;
	LONG32		iLowPrice	;
	LONG32		iClosePrice	;
	LONG32		iTotalQtyTraded ;
	DOUBLE64	fTotValTraded	;
	LONG32		iPreDayClosePrice ;
	LONG32		iHighestPriceEvr ;		
	LONG32		iLowestPriceEvr ;
	CHAR		sReserved3 [5];
	LONG32		iInstruIdentifier ;
	LONG32		iReserved4 ;
	LONG32		LstUpdateTime ;
	LONG32		iTotalTrades ;
	LONG32		iCurrentOpnInterest ;
	LONG32		iReserved5 ;
	LONG32 		iReserved6 ;
	LONG32		iAvgTradePrice ;
	LONG32		iDateOfMktStat ;
	INT16		iSessionId	;
};
#pragma pack()
#pragma pack(1)
struct SUB_MBP_TOUCH_LINE_BCAST
{
	LONG32		iBuyqty;
	LONG32		iSellqty;
	LONG32		iBuyordno;
	LONG32		iSellordno;
	DOUBLE64	fBuyprice;
	DOUBLE64	fSellprice;
	
};	
#pragma pack()

#pragma pack(1)
struct SUB_ORD_BUY_PRICE
{
        LONG32          iQty                    ;
        LONG32        	iOrdprice               ;
        LONG32          iTotNoOfOrders          ;
        SHORT           iReserved               ;
};
#pragma pack()

#pragma pack(1)
struct SUB_ORD_SELL_PRICE
{
        LONG32          iQty                    ;
        LONG32        	iOrdprice               ;
        LONG32          iTotNoOfOrders          ;
        SHORT           iReserved               ;
};
#pragma pack()

#pragma pack(1)
struct SUB_OPEN_INTEREST_DTLS
{
        LONG32          iCurrntOpnIntst         ;
};
#pragma pack()

/*#pragma pack(1)
struct  MCX_MBP_BCAST
{
	struct  MCX_BCAST_HEADER        sHeader ;
	SHORT16		iOpnPriceVol		;
	LONG32		iInsIdentifier		;
	CHAR		cInxFlag		;
	LONG32		iTolQtytraded		;

	LONG32		iNoofTrades		;
	DOUBLE64	fPrvClosePrice		;
	DOUBLE64	fATP			;
	DOUBLE64	fLTP			;
	DOUBLE64	fNoofTrades		;
	DOUBLE64	fHighestPriceEver	;
	DOUBLE64	fLowestPriceEver	;
	DOUBLE64	fTotalTradeValue	;
	LONG32		iTotalTradeQty		;
	LONG32		iLastTradeQty		;
	LONG32          iTotalBuyQty            ;
        LONG32          iTotalSellQty 		;
	
	LONG32		iSecurityID		;
	DOUBLE64	fLastTradePrice		;
	DOUBLE64	fNetPriceChange		;
	DOUBLE64	fAverageTradePrice	;
	DOUBLE64	fClosePrice		;
	DOUBLE64	fOpenPrice		;
	DOUBLE64	fHighPrice		;
	DOUBLE64	fLowPrice		;
//	DOUBLE64	fTouchBuyPrice		;
//	DOUBLE64	fTouchSellPricei	;
//	LONG32		iTouchBuyQty		;
//	LONG32		iTouchSellQty		;
//	LONG32		iVolTradedToday		;
//	LONG32		iLastTradeQty		;
//	LONG32		iTotalBuyQty		;
//	LONG32		iTotalSellQty		;
	CHAR		sLastTradeTime	[MCX_DATE_TIME_LEN]	;
	CHAR		sLastUpdateTime[MCX_DATE_TIME_LEN]	;
//	struct SUB_MBP_TOUCH_LINE_BCAST pTouchLine	[5]	;
//	CHAR		sMarketType	[MCX_MKT_TYPE_LEN]	;
//	LONG32		iExchSecurityId		;
//	CHAR		cIsPostClosing		;		
					
	struct SUB_ORD_BY_PRICE pOrdByPrice	[5];
	LONG32		iQty			;
	DOUBLE64	fOrdprice		;
	LONG32		iTotNoOfOrders		;
	
	struct SUB_OPEN_INTEREST_DTLS pOpnIntrstDtls ;
	LONG32		iCurrntOpnIntst		;
};
#pragma pack()
*/
#pragma pack(1)
struct  MCX_MBP_BCAST
{
        struct  MCX_BCAST_HEADER        sHeader ;
        CHAR         	cOpnPriceVol            ;
        LONG32          iInsIdentifier          ;
	CHAR            cReserved1      	;
	CHAR            cInxFlag                ;
	LONG32          iTotalTradeQty          ;
	LONG32        	iLastTradePrice         ;
	LONG32          iLastTradeQty           ;
	LONG32          iLastTradeTime     	;
	LONG32        	iAverageTradePrice      ;
	struct SUB_ORD_BUY_PRICE sOrdBuyPrice  [5];
	struct SUB_ORD_SELL_PRICE sOrdSellrice  [5];
	DOUBLE64        fTotalBuyQty            ;
        DOUBLE64        fTotalSellQty           ;
	CHAR            sReserved2 [2]     	;
	LONG32		iClosePrice             ;
        LONG32		iOpenPrice              ;
	LONG32		iHighPrice		;
       	LONG32 		iLowPrice               ;
	SHORT           iReserved3    	 	;
	struct SUB_OPEN_INTEREST_DTLS sOpnIntrstDtls ;
	LONG32          iNoofTrades             ;
	LONG32		iHighestPriceEver       ;
        LONG32		iLowestPriceEver        ;
	DOUBLE64	fTotalTradeValue        ;
	

};
#pragma pack()

#pragma pack(1)
struct MCX_EXCH_MSGS
{
	struct  MCX_BCAST_HEADER        sHeader ;
	CHAR	sReserved [12]  		;
	CHAR	sReserved1 [34]			;
	SHORT	iMsgLength			;
	CHAR	sMsg	[MCX_EXCH_MSG_LEN]	;	
};
#pragma pack()

#pragma pack(2)
struct  COMM_REDIS_LTP_UPD
{
        LONG32          iToken  ;
        DOUBLE64        fLtp    ;
};
#pragma pack()


#endif

