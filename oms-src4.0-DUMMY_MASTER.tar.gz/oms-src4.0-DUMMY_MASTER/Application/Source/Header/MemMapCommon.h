
#include    <sys/types.h>   /* basic system data types */
#include    <sys/time.h>    /* timeval{} for select() */
#include    <time.h>        /* timespec{} for pselect() */
#include    <errno.h>
#include    <fcntl.h>       /* for nonblocking */
#include    <limits.h>      /* PIPE_BUF */
#include    <signal.h>
#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>
#include    <sys/stat.h>    /* for S_xxx file mode constants */
#include    <unistd.h>
#include    <sys/wait.h>
#include    <stdarg.h>

#include    <sys/mman.h>    /* Posix shared memory */
#include    <poll.h>
/**#include    <rpc/rpc.h>***/
#include    <sys/ioctl.h>
#include    <sys/ipc.h>
#include    <sys/msg.h> 
#include    <sys/sem.h>
#include    <sys/shm.h>
#include    <sys/select.h>
#include    <unistd.h>
#include    <sys/resource.h>
#include    <sys/types.h>
#include	"IPCS.h"

# include   <strings.h>
#include   <pthread.h>

/*
 * In our wrappers for open(), mq_open(), and sem_open() we handle the
 * optional arguments using the va_XXX() macros.  But one of the optional
 * arguments is of type "mode_t" and this breaks under BSD/OS because it
 * uses a 16-bit integer for this datatype.  But when our wrapper function
 * is called, the compiler expands the 16-bit short integer to a 32-bit
 * integer.  This breaks our call to va_arg().  All we can do is the
 * following hack.  Other systems in addition to BSD/OS might have this
 * problem too ...
 */

#ifdef  __bsdi__
#define va_mode_t   int
#else
#define va_mode_t   mode_t
#endif

#define        FILE_MODE       (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
/* $$.ix [va_mode_t]~datatype,~definition~of$$ */
