#ifndef __EQUNSESTRUCTS_H__
#define __EQUNSESTRUCTS_H__

typedef BOOL (*P_TO_FUN)(CHAR * x, CHAR * y,LONG32 GroupId);

typedef struct  NNF_ORDER_ENTRY             	NNF_ORDER_ENTRY_CONF_RESP               ;
typedef struct  NNF_TRADE_CONF_RESP         	NNF_TRADE_CONF_RESP                     ;
typedef struct  NNF_TRADE_CONF_RESP         	NNF_STOP_LOSS_ORDER_TRIGGER_RESP	;
typedef struct  NNF_TRADE                   	NNF_TRADE_CAN_REQUESTED_BY_CP_RESP      ;
typedef	struct  TRADE		    	    	MS_TRADE_CAN_REQUESTED_BY_CP_RESP       ;
typedef struct  NNF_INDEX_ORDER_ENTRY      	NNF_INDEX_ORDER_ENTRY_REQUESTED_RESP    ;
typedef struct  NNF_EXCH_MSG_TO_TRADER_RESP  	NNF_EXCH_MSG_TO_TRADER_RESP 		;
typedef struct  NNF_UPDATE_LDB_TRAILER_RESP  	NNF_UPDATE_LDB_TRAILER_RESP 		;
typedef struct  ORDER                           MS_STOP_LOSS_ORDER_TRIGGER		;
typedef struct  MS_TRADE_CONF_RESP              MS_TRADE_CONF_RESP			;

#pragma pack(2)
struct TAP_WRAPPER
{
	SHORT   iMsgLen;
	LONG32  iSeqNo;
	unsigned char sDigest[DIGEST_LEN];
};
#pragma pack()
#pragma pack(2)
struct  NNF_ELIGIBILITY_PER_MKT
{
#ifdef  BIGENDIAN
	USHORT          NormalMkt               : 1     ;
	USHORT          OddLotMkt               : 1     ;
	USHORT          SpotMkt                 : 1     ;
	USHORT          AuctionMkt              : 1     ;
	USHORT          CallAuction1            : 1;
	USHORT          CallAuction2             : 1;
	USHORT          Reserved                : 4     ;
	USHORT          Reserved1               : 7; /** changed for PreOpen changes transcode 2300 **/
	USHORT          PreOpen                 : 1; /** added for PreOpen changes transcode 2300  **/

#elif   LITTLEENDIAN
	USHORT          Reserved                : 4     ;
	USHORT          CallAuction2             : 1;
	USHORT          CallAuction1            : 1;
	USHORT          AuctionMkt              : 1     ;
	USHORT          SpotMkt                 : 1     ;
	USHORT          OddLotMkt               : 1     ;
	USHORT          NormalMkt               : 1     ;
	USHORT          PreOpen                 : 1; /** added for PreOpen changes transcode 2300  **/
	USHORT          Reserved1               : 7; /** changed for PreOpen changes transcode 2300  **/
#endif
};
#pragma pack()
#pragma pack(2)
struct  NNF_SIGNON_ELIGTY_PER_MKT
{
#ifdef  LITTLEENDIAN 
	USHORT          Reserved                : 2     ;
	USHORT          CallAuction1            : 1;
	USHORT          CallAuction2             : 1;
	USHORT          SpotMkt                 : 1     ;
	USHORT          AuctionMkt              : 1     ;
	USHORT          OddLotMkt               : 1     ;
	USHORT          NormalMkt               : 1     ;
	USHORT          PreOpen                 : 1; /** added for PreOpen changes transcode 2300  **/
	USHORT          Reserved1               : 7; /** changed for PreOpen changes transcode 2300 **/

#elif   BIGENDIAN
	USHORT          NormalMkt               : 1     ;
	USHORT          OddLotMkt               : 1     ;
	USHORT          SpotMkt                 : 1     ;
	USHORT          AuctionMkt              : 1     ;
	USHORT          CallAuction1            : 1;
	USHORT          CallAuction2             : 1;
	USHORT          Reserved                : 2     ;
	USHORT          Reserved1               : 7; /** changed for PreOpen changes transcode 2300 **/
	USHORT          PreOpen                 : 1; /** added for PreOpen changes transcode 2300  **/

#endif
};
#pragma pack()

#pragma pack(2)
struct  NNF_HEADER
{
	LONG32          iReserved                       ;
	LONG32          iLogTimeStamp                    ;
	CHAR            sAlphaSplit [ALPHA_SPLIT_LEN]    ;
	INT16           iMsgCode                         ;
	INT16           iErrorCode                       ;
	CHAR            sTimeStamp1 [NNF_DATE_TIME_LEN]  ;
	CHAR            sTimeStamp2 [NNF_DATE_TIME_LEN]  ;
	CHAR            sTimeStamp3 [NNF_DATE_TIME_LEN]  ;
	INT16           iMsgLength                       ;
} ;
#pragma pack()

#pragma pack()

struct TRANS_FUN_PAIR
{
	INT16        Transcode;
	P_TO_FUN     pToFun;
};
/*
#pragma pack(4)
struct INT_RESP_HEADER
{
	LONG32          iSeqNo                                   ;
	SHORT           iMsgLength                               ;
	SHORT           iMsgCode                                 ;
	CHAR            sExcgId[EXCHANGE_LEN]                    ;
	SHORT           iErrorId                                 ;
	LONG32          iUserIdOrLogPktId                        ;
	CHAR            cUserTypeOrLogInfoType                   ;
	LONG32          iTimeStamp                               ;
	CHAR            cSegment                                 ;
};
#pragma pack()
*/
#pragma pack(2)
struct  NNF_SEC_INFO
{
	CHAR            sSymbol [SYMBOL_LEN]             ;
	CHAR            sSeries [SERIES_LEN]              ;
}  ;
#pragma pack()


#pragma pack(2)
struct  NNF_ORDER_TERMS
{
	USHORT          MFTerm                  : 1     ;
	USHORT          AONTerm                 : 1     ;
	USHORT          IOCTerm                 : 1     ;
	USHORT          GTCTerm                 : 1     ;
	USHORT          DayTerm                 : 1     ;
	USHORT          StopLossTerm            : 1     ;
	USHORT          Market                  : 1     ;
	USHORT          ATO                     : 1     ;
	USHORT          Reserved                : 3     ;       
	USHORT          PreOpen                 : 1     ;      
	USHORT          Frozen                  : 1     ;
	USHORT          Modified                : 1     ;
	USHORT          Traded                  : 1     ;
	USHORT          MatchedInd              : 1     ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_FILLER_TERMS
{
	USHORT    b1            : 1 ;
	USHORT    b2            : 1 ;
	USHORT    b3            : 1 ;
	USHORT    b4            : 1 ;
	USHORT    b5            : 1 ;
	USHORT    b6            : 1 ;
	USHORT    b7            : 1 ;
	USHORT    b8            : 1 ;
	USHORT    b9            : 1 ;
	USHORT    b10           : 1 ;
	USHORT    b11           : 1 ;
	USHORT    b12           : 1 ;
	USHORT    b13           : 1 ;
	USHORT    b14           : 1 ;
	USHORT    b15           : 1 ;
	USHORT    b16           : 1 ;
};
#pragma pack()

#pragma pack(4)
struct  MS_TRADE_CONF_RESP
{
	struct          INT_RESP_HEADER     IntRespHeader;
	DOUBLE64        fTradedOrdNumber                               ;
	LONG32          iTradeNumber                                   ;
	CHAR            sAccountNumber [CLIENT_ID_LEN]                     ;
	INT16           iBuyOrSell                                     ;
	CHAR            cD2C1Flag                                          ;
	CHAR            cRetailFIFlag                                      ;
	LONG32          iOriginalQty                                   ;
	LONG32          iDiscQty                                       ;
	LONG32          iQtyTraded                                     ;
	LONG32          iQtyRemaining                                  ;
	LONG32          iDiscQtyRemaining                              ;
	LONG32          iQtyFilledToday                                ;
	DOUBLE64        fOrderPrice                                    ;
	DOUBLE64        fTradePrice                                    ;
	struct          NNF_ORDER_TERMS 	pOrderTerms                        ;
	LONG32          iGoodTillDate                                  ;
	CHAR            sActivityType [ACTIVITY_TYPE_LEN]              ;
	LONG32          iTradeTime                                     ;
	DOUBLE64        fCounterOrdNum                                 ;
	CHAR            sCPBrokerCode [BROKER_CODE_LEN]                ;
	INT16           iBookType                                      ;
	INT16           iNewQty                                        ;
	DOUBLE64        fOrderNumber                                   ;
	INT16           iOrderSerialNumber                             ;
	INT16           iTradeSerialNumber                             ;
	CHAR            sClientId[CLIENT_ID_LEN]                       ;
	CHAR            sEntityId[ENTITY_ID_LEN]                       ;
	CHAR            sMktType [MARKET_LEN]                          ;
	CHAR            Settler [NNF_SETTLOR_LEN]                         ;
	CHAR            sSecurityId[SECURITY_ID_LEN]                   ;
	LONG32          iUserId                                        ;
	CHAR            cSourceFlag                                                                                ;
	CHAR            cOpenClose                                                                                 ;
	CHAR            cOldOpenClose                                                                      ;
	CHAR            cCoverUncover                                                                      ;
	CHAR            cOldCoverUncover                                                                   ;
	CHAR            cGiveUpFlag                                                                                ;
	CHAR            cPreOpenFlag                       ;
	CHAR            cBseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	DOUBLE64        fInternalRefId                   ;
	DOUBLE64        fBasketOrdNo;
	CHAR            sReserved[ 4 ];
	CHAR            cProductId;
	CHAR            cOrderSessionType;
	CHAR            cHandlInst ;
	SHORT           iSettType;
};
#pragma pack()

#pragma pack(4)
struct  ORDER
{
	struct      INT_RESP_HEADER     IntRespHeader           ;
	CHAR        cParticipantType                         ;
	CHAR        sCPBrokerCode [BROKER_CODE_LEN]          ;
	CHAR        cSecSuspInd                              ;
	DOUBLE64    fOrderNum                                ;
	CHAR        sAccCode[CLIENT_ID_LEN]                  ;
	INT16       iBookType                                ;
	INT16       iBuyOrSell                               ;
	LONG32      iDiscQty                                 ;
	LONG32      iDiscQtyRemaining                        ;
	LONG32      iTotalQtyRemaining                       ;
	LONG32      iTotalQty                                ;
	LONG32      iQtyFilledToday                          ;
	LONG32      iMinFillQty                              ;
	DOUBLE64     fPrice                                  ;
	DOUBLE64     fTriggerPrice                           ;
	LONG32      iGoodTillDate                            ;
	LONG32      iEntryTime                               ;
	LONG32      iLastModifiedTime                        ;
	struct      NNF_ORDER_TERMS pOrderTerms                  ;
	CHAR        sBrokerCode[BROKER_CODE_LEN]             ;
	CHAR        sRemrks[OE_REMARKS_LEN]                  ;
	CHAR        sSettlor[NNF_SETTLOR_LEN]                    ;
	INT16       iProCli                                  ;
	INT16       iSettlementDays                          ;
	SHORT       iReasonCode                              ;
	CHAR        sEntityId[ENTITY_ID_LEN]                 ;
	DOUBLE64    fExchOrderNum                            ;
	INT16       iOrdSerialNo                             ;
	CHAR        sSecurityId[SECURITY_ID_LEN]             ;
	CHAR        sClientId[CLIENT_ID_LEN]                 ;
	CHAR        cCoverUncoverFlg                         ;
	CHAR        cOpenCloseFlg                            ;
	CHAR        cSourceFlag                              ;
	CHAR        sBseExchOrderNum [BSE_EXCH_ORDER_NO_LEN] ;
	CHAR        cD2C1Flag                                                                ;
	CHAR        cRetailFIFlag                                                    ;
	DOUBLE64        fInternalRefId                                                   ;
	CHAR            sReserved[ 4 ]                                                   ;
	DOUBLE64        fBasketOrderNo                                                   ;
	CHAR            cOrderCheck                                                              ;
	CHAR        cProductId                                                           ;
	CHAR        cOrderSessionType                                            ;
	CHAR        sReplyText [ REPLY_TEXT_LEN ]                        ;
	CHAR        cSecSeriesInd                                                ;
	LONG32          iAuctionNum ;
	CHAR            cHandlInst ;
	SHORT           iMktProt ;
	SHORT           iCaClientType;
	SHORT           iSettType;
};
#pragma pack()


#pragma pack(2)
struct                  NNF_ORDER_ENTRY
{
	struct          NNF_HEADER      pHeader                         ;
	CHAR            cParticipantType                                ;
	CHAR            cReserved                                               ;
	INT16           iCompititorPeriod                                ;
	INT16           iSolicitorPeriod                                 ;
	CHAR            cModCanBy                                       ;
	CHAR            cReserved1                                      ;
	INT16           iReasonCode                                     ;
	CHAR            sStartAlpha [ALPHA_SPLIT_LEN]                   ;
	CHAR            sEndAlpha [ALPHA_SPLIT_LEN]                     ;
	struct          NNF_SEC_INFO    pSecInfo                ;
	INT16           iAuctionNum                                      ;
	CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]                  ;
	CHAR            cSecSuspInd                                      ;
	DOUBLE64        fOrderNum                                        ;
	CHAR            sAccCode[ACCOUNT_CODE_LEN]                       ;
	INT16           iBookType                                        ;
	INT16           iBuyOrSell                                       ;
	LONG32          iDiscQty                                         ;
	LONG32          iDiscQtyRemaining                                ;
	LONG32          iTotalQtyRemaining                               ;
	LONG32          iTotalQty                                        ;
	LONG32          iQtyFilledToday                                  ;
	LONG32          iPrice                                           ;
	LONG32          iTriggerPrice                                    ;
	LONG32          iGoodTillDate                                    ;
	LONG32          iEntryTime                                       ;
	LONG32          iMinFillQty                                      ;
	LONG32          iLastModifiedTime                                ;
	struct          NNF_ORDER_TERMS pOrderTerms                      ;
	INT16           iBranchId                                        ;
	LONG32          iExcgUserId                                     ;
	CHAR            sBrokerCode [BROKER_CODE_LENGTH]                   ;
	CHAR            sRemarks[OE_REMARKS_LEN]                         ;
	CHAR            sSettlor [NNF_SETTLOR_LEN]                           ;
	INT16           iProCli                                          ;
	INT16           iSettlementDays                                  ;
	DOUBLE64        fUserInfo                                       ;
	DOUBLE64        fReservedPrgTrd                                 ;
	struct          NNF_FILLER_TERMS                pExchRsrvdFlds  ;
	CHAR            sSeq[PRG_TRD_RESERVED_FIELD_LEN]                ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_TRAILER_RESP
{
	struct          NNF_HEADER pHeader                                                      ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_TRADE_CONF_RESP
{
	struct          NNF_HEADER pHeader                     ;
	DOUBLE64        fTradedOrdNumber                       ;
	CHAR            sBrokerCode [BROKER_CODE_LENGTH]          ;
	CHAR            cReserved                              ;
	/*      INT16           TraderId                                                                        ;*/
	LONG32          iTraderId                              ;/** Userid related changes **/
	CHAR            sAccountNumber [ACCOUNT_CODE_LEN]      ;
	INT16           iBuyOrSell                             ;
	LONG32          iOriginalQty                           ;
	LONG32          iDiscQty                               ;
	LONG32          iQtyRemaining                          ;
	LONG32          iDiscQtyRemaining                      ;
	LONG32          iPrice                                 ;
	struct          NNF_ORDER_TERMS pOrderTerms            ;
	LONG32          iGoodTillDate                          ;
	LONG32          iTradeNumber                           ;
	LONG32          iQtyTraded                             ;
	LONG32          iTradePrice                            ;
	LONG32          iQtyFilledToday                        ;
	CHAR            sActivityType [ACTIVITY_TYPE_LEN]      ;
	LONG32          iTradeTime                             ;
	DOUBLE64        fCounterOrdNum                         ;
	CHAR            sCPBrokerCode [BROKER_CODE_LENGTH]        ;
	struct          NNF_SEC_INFO                 pSecInfo  ;
	CHAR            cReserved1                             ;
	INT16           iBookType                              ;
	LONG32          iNewQty                                ;
	INT16		iProCli					;
};
#pragma pack()

#pragma pack(2)
struct          NNF_TRADE
{
	struct          NNF_HEADER        pHeader               ;
	struct          NNF_SEC_INFO      pSecInfo              ;
	LONG32          iTradeNumber                            ;
	LONG32          iTradeQty                               ;
	LONG32          iTradePrice                             ;
	INT16           iMarketType                             ;
	LONG32          iNewTradeQty                            ;
	CHAR            sBuyParticipantCode[PARTICIPANT_ID_LEN]     ;
	CHAR            sSellParticipantCode[PARTICIPANT_ID_LEN]    ;
	CHAR            sBuyBrokerCode[BROKER_CODE_LEN]             ;
	CHAR            sSellBrokerCode[BROKER_CODE_LEN]            ;
	/*      INT16           TraderID                                                                        ;*/
	LONG32          iTraderID                                   ;/** Userid related changes **/
	INT16           iRequestedByTraderID                        ;
};
#pragma pack()

#pragma pack(4)
struct      TRADE
{
	struct      INT_RESP_HEADER     IntRespHeader      ;
	LONG32      iTradeNumber                            ;
	LONG32      iTradeQty                               ;
	DOUBLE64    fTradePrice                             ;
	SHORT       iMarketType                             ;
	SHORT       iBookType                               ;
	LONG32      iNewTradeQty                            ;
	CHAR        cBuySellInd                             ;
	CHAR        cCoverUncoverFlg                        ;
	CHAR        cOpenCloseFlg                           ;
	CHAR        cGiveUpFlg                              ;
	CHAR        sParticipantCode[PARTICIPANT_ID_LEN]  ;
	CHAR        sCBrokerCode[BROKER_CODE_LEN]           ;
	LONG32      iTraderID                               ;
	LONG32      iRequestedByTraderID                    ;
	DOUBLE64    fOrderNumber                            ;
	INT16       iOrderSerialNumber                      ;
	INT16       iTradeSerialNumber                      ;
	CHAR        sClientId[CLIENT_ID_LEN]                ;
	CHAR        sEntityId[ENTITY_ID_LEN]                ;
	CHAR        sSettler [NNF_SETTLOR_LEN]                  ;
	CHAR        sSecurityId[SECURITY_ID_LEN]            ;
	CHAR        cSourceFlag                             ;
	CHAR        cD2C1Flag                                                                ;
	CHAR        cRetailFIFlag                                                    ;
	DOUBLE64    fInternalRefId                                                   ;
	DOUBLE64    fBasketOrdNo                                     ;
	CHAR        sReserved[ 4 ]                                                   ;
	CHAR        cProductId                                                               ;
	CHAR        cOrderSessionType                                                ;
	CHAR        cHandlInst ;

};
#pragma pack()

#pragma pack(2)
struct  NNF_INDEX_ORDER_ENTRY
{
	struct      NNF_HEADER pHeader                         ;
	INT16           iBranchId                              ;
	INT16           iExcgUserId                            ;
	LONG32          iLastModifiedTime                      ;
	INT16           iReasonCode                            ;
	INT16           iIndustryCode                          ;
	INT16           iSectorCode                            ;
	INT16           iSubSectorCode                         ;
	CHAR            sIndexName       [ INDEX_NAME_LEN]     ;
	CHAR            sBrokerCode [BROKER_CODE_LEN]          ;
	INT16           iBuyOrSell                             ;
	DOUBLE64        fLimitPrice                            ;
	struct          NNF_ORDER_TERMS pOrderTerms            ;
	INT16           iProCli                                ;
	CHAR            sAccountNumber [ACCOUNT_CODE_LEN]      ;
	CHAR            sParticipantId [ PARTICIPANT_ID_LEN]   ;
	CHAR            sRemarks[OE_REMARKS_LEN]               ;
	CHAR            cReserved                              ;
	DOUBLE64        fReserved                              ;
	DOUBLE64        fUserInfo                              ;
};

#pragma pack(2)
struct  NNF_EXCH_MSG_TO_TRADER_RESP
{
	struct              NNF_HEADER pHeader                      ;
	/*    SHORT             TraderId                                                                        ; */
	LONG32              iTraderId                               ;/** Userid related changes **/
	CHAR                sActionCode[ ACTION_CODE_LEN]           ;
	CHAR                cReserved                               ;/***Addded while closeout changes*****/
	SHORT               iBcastMsgLength                         ;
	CHAR                sBcastMsg [ BCAST_MSG_LEN]              ;
} ;
#pragma pack()
/****
#pragma pack(2)
struct  NNF_SIGNON_REQ
{
struct          NNF_HEADER      sHeader                 ;
LONG32          iUserId                                 ;
CHAR            sPassword[NSE_PASSWORD_LEN]             ;
CHAR            sNewPassword[NSE_PASSWORD_LEN]          ;
CHAR            sTraderName[TRADER_NAME_LEN]            ;
LONG32		iLastPassChgTime			;
CHAR            sBrokerCode[BROKER_CODE_LENGTH]            ;
CHAR            cReserved1                           ;
INT16		iBranchId				;
LONG32          iVersionNumber                          ;
CHAR            sReserved2 [56]                         ;
INT16		iUserType				;
DOUBLE64	fSeqNum					;	
CHAR            sWorkstationAddr [WORK_STATION_ADDR_LEN];
CHAR		cBrokerStat				;
CHAR		cShowIndex				;
struct   NNF_SIGNON_ELIGTY_PER_MKT pElgMkt		;
CHAR		sBrokerName	[TRADER_NAME_LEN]	;
};
#pragma pack()
 ***/
#pragma pack(2)
struct  NNF_SIGNON_REQ
{
	struct          NNF_HEADER      sHeader                                                 ;
	LONG32          iUserId                                      ;/** Userid related changes **/
	CHAR            sPassword[NSE_PASSWORD_LEN]                                              ;
	CHAR            sNewPassword[NSE_PASSWORD_LEN]                                   ;
	CHAR            sReserved [30]                                                           ;
	CHAR            sBrokerCode[BROKER_CODE_LENGTH]                                     ;
	CHAR            sReserved1 [3]                                                           ;
	LONG32          iVersionNumber                                                           ;
	CHAR            sReserved2 [66]                                                          ;
	CHAR            sWorkstationAddr [WORK_STATION_ADDR_LEN]         ;
	CHAR            sReserved3 [4]                                                           ;
	CHAR            sBrokerName[BROKER_NAME_LEN]                 ;
	CHAR            cReserved4                                   ;
};
#pragma pack()


#pragma pack(2)
struct  NNF_SIGNON_RESP
{
	struct          NNF_HEADER sHeader                              ;
	LONG32          iUserId                                         ;/** Userid related changes **/
	CHAR            sPassword[NSE_PASSWORD_LEN]                     ;
	CHAR            sNewPassword[NSE_PASSWORD_LEN]                  ;
	CHAR            sTraderName[TRADER_NAME_LEN]                    ;
	LONG32          iLastPasswordChange                             ;
	CHAR            sBrokerCode[BROKER_CODE_LENGTH]                 ;
	CHAR            cReserved                                       ;
	INT16           iBranchId                                       ;
	CHAR            sReserved1 [4]                                  ;
	LONG32          iEndTime                                        ;
	CHAR            sReserved2 [52]                                 ;
	INT16           iUserType                                       ;
	CHAR            sSeqNumber[EXCHANGE_SEQ_NUM_LEN]                ;
	CHAR            sReserved3 [14]                                 ;
	CHAR            cBrokerStatus                                   ;
	CHAR            cReserved4                                      ;
	struct          NNF_ELIGIBILITY_PER_MKT EligibilityPerMkt       ;
	CHAR            sBrokerName[BROKER_NAME_LEN]                    ;
	CHAR            cReserved5                                      ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_SYS_INFO_REQ
{
	struct          NNF_HEADER sHeader              ;
	//LONG32		iLastUpdPortfliTime		;						
};
#pragma pack()

#pragma pack(2)
struct  NNF_MARKET_STATUS
{
	INT16           iNormal                          ;
	INT16           iOddlot                          ;
	INT16           iSpot                            ;
	INT16           iAuction                         ;
	INT16           iCallAuction1                    ;
	INT16           iCallAuction2                    ;
};
#pragma pack()

#pragma pack(2)
struct NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS
{
#ifdef  BIGENDIAN
	USHORT               uiAON           :1              ;
	USHORT               uiMinFill       :1              ;
	USHORT               uiBooksMerged   :1              ;
	USHORT               uiFiller        :5              ;

	USHORT               uiFiller1       :8              ;
#elif   LITTLEENDIAN
	USHORT               uiFiller        :5              ;
	USHORT               uiBooksMerged   :1              ;
	USHORT               uiMinFill       :1              ;
	USHORT               uiAON           :1              ;
	USHORT               uiFiller1       :8              ;
#endif
};
#pragma pack()

#pragma pack(2)
struct  NNF_SYS_INFO_RESP
{
	struct          NNF_HEADER sHeader                                      	;
	struct          NNF_MARKET_STATUS MarketStatus                             	;/*PreOpen transcode 1601 **/
	LONG32          iMarketIndex                                               	;
	INT16           iNormalMktDefSttlPeriod                                    	;
	INT16           iSpotMktDefSttlPeriod                                      	;
	INT16           iAuctionMktDefSttlPeriod                                   	;
	INT16           iDefCompititorPeriod                                       	;
	INT16           iDefSolicitorPeriod                                        	;
	INT16           iWarnigPercent                                             	;
	INT16           iVolFreezePercent                                          	;
	LONG32          iReserved                                                  	;
	INT16		iTerminalIdleTime						;
	LONG32          iBoardLotQty                                               	;
	LONG32          iTickSize                                                  	;
	INT16           iMaxGTCDays                                                	;
	struct          NNF_SYSTEM_STOCK_ELIGIBLE_INDICATORS    StockEligibilityInd	;
	INT16           iDiscQty                                                   	;
	LONG32		iReserved2						   	;	
};
#pragma pack()

#pragma pack(2)
struct INVITATION_PACKET
{
	struct          TAP_WRAPPER tWrapper  ; /********** ANKIT ADDED FOR TAP ***********/
	struct          NNF_HEADER  sHeader   ;
	SHORT           iInvitation_count     ;
};
#pragma pack()

#pragma pack(2)
struct  NNF_UPDATE_LDB_REQ
{
	struct          NNF_HEADER sHeader        ;
	LONG32          iLastUpdateSecTime        ;
	LONG32          iLastUpdatePartTime       ;
	CHAR            cReqForOpenOrders         ;
	CHAR            cReserved                 ;
	struct          NNF_MARKET_STATUS sMktStat;
};
#pragma pack()

#pragma pack(2)
struct Download_Data
{
	LONG32  iStream_Id ;
	LONG32  iStream_Flag ; /**** Flag 1 for ON , 0 for OFF ********/
	ULONG32 iTimeStamp1;
	ULONG32 iTimeStamp2;
}Msg_Dow_Data[MAX_NO_STREAMS] ;
#pragma pack()

#pragma pack(2)
struct  NNF_MSG_DOWNLOAD_REQ
{
	struct          NNF_HEADER sHeader                                                      ;
	DOUBLE64        fExchSeqNum                                                                      ;
	/*      CHAR        ExchSeqNum[8];*/
};
#pragma pack()


#pragma pack(2)
struct  NNF_UPDATE_LDB_DATA_RESP
{
	struct          NNF_HEADER sHeader                                                      ;
	struct          NNF_HEADER sInnerHeader                                         ;
	CHAR            Data [LDB_UPDATE_PACKET_LEN]                            ;
};
#pragma pack()

#pragma pack(2)
struct NNF_DOUBLE_INT
{
	unsigned  int   iLogTime1;
	unsigned  int   iLogTime2;
};
#pragma pack()

#pragma pack(2)
struct                  NNF_MSG_DOWNLOAD_DATA_RESP
{
	struct          NNF_HEADER sHeader                ;
	struct          NNF_HEADER sInnerHeader           ;
	CHAR            sData [MSG_AREA_EQ_DLD_DATA_LEN]  ;
};
#pragma pack()

#pragma pack(2)
struct          NNF_ADDITIONAL_FLAG
{
	USHORT  iReserve1       :1;
	USHORT  iCOL1           :1;
	USHORT  iReserve2       :6;


};
#pragma pack()

#pragma pack(2)
struct	NNF_SPD_LEG_INFO
{
	LONG32		iToken2		;
	struct          NNF_SEC_INFO    pSecInfo;
	CHAR		sBrokerID2[BROKER_CODE_LENGTH]		;
	CHAR		cReserved2		;	
	INT16		iOrdType		;
	INT16		iBuySell		;
	LONG32		iDiscloseVol2		;
	LONG32		iDisVolRem2		;
	LONG32		iTotVolRem2		;
	LONG32		iVolume2		;
	LONG32		iVolFillToday2		;
	LONG32		iPrice2		;
	LONG32		iTriggerPrice2		;
	LONG32		iMinFillAON2		;
	struct          NNF_ORDER_TERMS pOrdTerm        ;
	CHAR		cOpenClose		;
	struct		NNF_ADDITIONAL_FLAG	pAddFlg	;	
	CHAR		cGiveUpFlag		;
	CHAR		cReserved		;
};
#pragma pack()


#pragma pack(2)
struct	NNF_SPRD_ORD_ENTRY_REQ
{
	struct          NNF_HEADER pHeader              ;	
	CHAR		cParticType1			;
	CHAR		cReserved1			;
	INT16		iCompetitorPeriod1		;
	INT16		iSolicitorPeriod1		;
	CHAR		cModCxlBy1			;
	CHAR		cReserved2			;
	INT16		iReasonCode1			;
	CHAR		sStartAlpha1[ALPHA_SPLIT_LEN]			;
	CHAR		sEndAlpha1[ALPHA_SPLIT_LEN]			;
	LONG32		iToken1				;
	struct          NNF_SEC_INFO    pSecInfo        ;
	CHAR		sOpBrokerID[BROKER_CODE_LENGTH]			;
	CHAR		cReserved3			;
	CHAR		sReserved4[3]			;
	CHAR		cReserved5			;
	INT16		iOptType			;
	DOUBLE64	fExchOrderNum			;
	CHAR		sAccNumber[ACCOUNT_CODE_LEN]			;
	INT16		iBookType			;
	INT16		iBuySellIndicator		;
	LONG32		iDisclVol			;
	LONG32		iDisclVolRem			;
	LONG32		iTotVolRem			;
	LONG32		iVolume1			;
	LONG32		iVolFillToday1			;
	LONG32		iPrice			;
	LONG32		iTriggerPrice			;
	LONG32		iGoodTillDate			;
	LONG32		iEntryDateTime			;
	LONG32		iMinFillAON			;
	LONG32		iLastModifyTime			;
	struct  	NNF_ORDER_TERMS	pOrdTerm	;
	INT16		iBranchID1			;
	LONG32		iTraderID1			;
	CHAR		sBrokerID[BROKER_CODE_LENGTH]			;
	CHAR		sOrdFiller[24]			;		
	CHAR		cOpenClose			;
	CHAR		sSettlor[NNF_SETTLOR_LEN]			;
	INT16		iProClient			;
	INT16		iSettlePeriod			;
	struct		NNF_ADDITIONAL_FLAG	pAddFlg	;	
	CHAR		cGiveUpFlag			;
	USHORT		iFiller1	:1		;		
	USHORT		iFiller2	:1		;		
	USHORT		iFiller3	:1		;		
	USHORT		iFiller4	:1		;		
	USHORT		iFiller5	:1		;		
	USHORT		iFiller6	:1		;		
	USHORT		iFiller7	:1		;		
	USHORT		iFiller8	:1		;		
	USHORT		iFiller9	:1		;		
	USHORT		iFiller10	:1		;		
	USHORT		iFiller11	:1		;		
	USHORT		iFiller12	:1		;		
	USHORT		iFiller13	:1		;		
	USHORT		iFiller14	:1		;		
	USHORT		iFiller15	:1		;		
	USHORT		iFiller16	:1		;		
	CHAR		cFiller17			;	
	CHAR		cFiller18			;	
	DOUBLE64	fNNFfield			;
	DOUBLE64	fMktReplay			;
	LONG32		iPriceDiff			;
	struct		NNF_SPD_LEG_INFO	pLeg2	;
	struct		NNF_SPD_LEG_INFO	pLeg3	;


};			
#pragma pack()


extern BOOL fMAP_ORDER                              (CHAR *, CHAR *);
extern BOOL fCMS_STOP_LOSS_ORDER_TRIGGER            (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CONF_MAP_RESP                (CHAR *, CHAR *);
extern BOOL fCMS_TRADE_CAN_MAP_RESP         	    (CHAR *, CHAR *);
extern BOOL fCMS_EXCH_MSG_TO_TRADER_RESP            (CHAR *, CHAR *);
extern BOOL fCMS_UPDATE_LDB_TRAILER_RESP            (CHAR *, CHAR *);



#endif

