#ifndef	__BSE_STRUCT__
#define	__BSE_STRUCT__

#pragma pack(2)
struct	OMS_HEADER
{
	LONG32	iSlotNo;
	LONG32	iMsgLen;
};
#pragma pack()

#pragma pack(2)
struct OMB_EXCH_USER_REG_REQ
{
	struct OMB_HEADER   pOmbHeader;
	LONG32   iMsgType;
	LONG32   iSlotNo;
	LONG32   iMmbrId;
	LONG32   iTraderId;
};
#pragma pack()

#pragma pack(2)
struct OMB_REG_RESP_MSG
{
	struct OMB_HEADER   pOmbHeader;
	LONG32              iMsgType;
	LONG32              iSlotNo;
	LONG32              iMsgTag;
	LONG32              iErrorNo;
	CHAR                sErrText [BSE_ERR_LEN ];      /****** 81 ******/
};
#pragma pack( )


#pragma pack(2)
struct OMB_LOG_ON_OFF_REQUEST
{
	struct OMB_HEADER       pOmbHeader;
	LONG32    iMsgType;
	CHAR      sPasswd [ BSE_PASSWORD_LEN ];
	CHAR      cFiller;
	LONG32    iMsgTag;
};
#pragma pack()

#pragma pack(2)
struct OMB_BSE_DATE
{
	CHAR            cYear;
	CHAR            cMonth;
	CHAR            cDay;
};
#pragma pack( )

#pragma pack(2)
struct OMB_BSE_TIME
{
	CHAR            cHour;
	CHAR            cMinute;
	CHAR            cSecond;
};
#pragma pack( )


#pragma pack(2)
struct OMB_LOG_ON_REPLY
{
	struct OMB_HEADER   pOmbHeader;
	LONG32              iMsgType;
	INT16               iRepCode;
	LONG32              iSession;
	CHAR                sRepMsg[ BSE_REPLY_TEXT_LEN ];
	CHAR                sMotd[BSE_NEWS_DATA_LEN ];
	CHAR                cCentury;
	struct OMB_BSE_DATE pLogInDate;
	struct OMB_BSE_TIME pLogInTime;
	struct OMB_BSE_DATE pLastLogInDate;
	struct OMB_BSE_TIME pLastLogInTime;
	CHAR                cSecVersion;
	CHAR                cSecRelease;
	CHAR                sBcastIndexId[BSE_INDEX_ID_LEN];
	INT16               iSettleNo;
	LONG32              iMsgTag;
};
#pragma pack( )

#pragma pack(2)
struct OMB_ADD_UPDATE_ORDER_REQ
{
	struct	OMB_HEADER      pOmbHeader;
	LONG32		 	iMsgType;
	LONG32		 	iScripCode;
	LONG32		  	iMsgTag;
	LONG32			iQty;
	LONG32			iAvaQty;
	LONG32 			iRate;
	SPARCLONG64		iOrderId;
	CHAR			cClientId;
	SHORT			iRetention;
	LONG32			iMiniOty;
	LONG32			iCustCode;
	SHORT			iCAClass;
	SPARCLONG64		iLocationId;
}			
#pragma pack( )

#pragma pack(2)
struct OMB_ADD_UPD_DEL_MKT_SL_ORD_REQ
{
	struct  OMB_HEADER 	pOmbHeader;
	LONG32			iMsgType;
	LONG32			iScripCode;
	LONG32			iMsgTag1;
	LONG32			iQty;
	LONG32			iRevealedQty;
	LONG32			iLmtRate;
	LONG32			iTriRate;
	LONG32			iReserveFiled1;
	LONG32			iReserveFiled2;
	LONG32			iFiller1;
	LONG32			iFiller2;
	LONG32			iMsgTag2;
	SPARCLONG64		iOrderId;
	SPARCLONG64		iLocationId;
	LONG32			iFiller3;
	SHORT			iFiller4;
	SHORT			iFiller5;
	CHAR			cClientId[12];
	CHAR			cReserveFiled3[13];
	CHAR			cMsgTag[14];
	CHAR			cFiller[4];
	CHAR			cOrdActionCode;
	CHAR			cBuy/Sell;
	CHAR			cOrderType;
	CHAR			cFiller7;
	SHORT			iClientType;
	SHORT			iMktProtect;
	SHORT			iRetention;
	SHORT			iFiller8			
}
#pragma pack( )

#pragma pack(2)
struct	OMB_ADD_UP_DEL_ORD_RLY
{
	struct	OMB_BSE_DATE  	pRecDate;
	struct 	OMB_BSE_TIME	pRecTime;
	LONG32			iMsgType;
	LONG32			iMsgTag1;
	SHORT			iRlyCode;
	SHORT			iFiller;
	LONG32			iAmendedQty;
	SPARCLONG64		iOrderId;
	CHAR			cMillSec[4];
	UCHAR			cOrdActionCode;
	UCHAR			cBuy/Cell;
	UCHAR			cOrderType;
	CHAR			cFiller1[3];
	CHAR			cRelyText[50];
	CHAR			cFill[2];
	CHAR			cReserveFiled[13];
	CHAR			cMsgTag3[15];
	LONG32			iMsgTag2;
	LONG32			iPendingQty;
	LONG32			iFiller2;
	SHORT			iFiller3;
	SHORT			iFiller4;

}
#pragma pack()

#endif
