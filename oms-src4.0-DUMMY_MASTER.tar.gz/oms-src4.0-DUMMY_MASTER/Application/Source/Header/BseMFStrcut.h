#ifndef __BSES_MF_STRUCTS_H__
#define __BSES_MF_STRUCTS_H__

#pragma pack(4)
struct BSE_MF_LOGIN_REQ
{
	CHAR	sTransCode	[TRANSCODE_LEN]	;
	CHAR	sLoginId	[LOGIN_ID_LEN]	;
	CHAR	sMemberId	[MEMBER_ID_LEN]	;
	CHAR	sPassword	[BSE_MF_PASSWORD_LEN]	;
	CHAR	sNewPassword	[BSE_MF_PASSWORD_LEN]	;
	CHAR	sStarMFId	[STAR_MFID_LEN]	;
};
#pragma pack()


#pragma pack(4)
struct BSE_MF_LOGIN_RESP
{
	CHAR  	sTransCode 	[TRANSCODE_LEN]		;
	CHAR 	sLoginId	[LOGIN_ID_LEN]		;
	CHAR	sMemberId       [MEMBER_ID_LEN]		;
	CHAR	sDealerId	[DEALER_ID_LEN]		;
	CHAR	sBranch_Code	[BRANCH_CODE_LEN]	;
	CHAR	sReply_Code	[REPLY_CODE_LEN]	;
	CHAR	sSession	[SESSION_LEN]		;
	CHAR	sSettlement_No  [SETTLEMENT_NO_LEN]	;
	CHAR	sTrade_Date	[TRADE_DATE_LEN]	;
	CHAR	sCurrent_Time	[CURRENT_TIME_LEN]	;
	CHAR	sMessage	[LOGON_RESP_MESSG_LEN]	;
};
#pragma pack()

#pragma pack(2)
struct  ForkProcess
{
	int     ProcessId;
	int     ProcessStatus;
};
#pragma pack( )


#pragma pack(4)
struct BSE_HEARTBEAT_REQ_RESP
{
	CHAR    sTransCode      [TRANSCODE_LEN]	;
	CHAR	sTag		[TAG_LEN]	;
};
#pragma pack()

#pragma pack(4)
struct	BSE_MF_LOGOFF_REQ
{
	CHAR    sTransCode      [TRANSCODE_LEN]	;
	CHAR    sLoginId        [LOGIN_ID_LEN]	;
	CHAR    sMemberId       [MEMBER_ID_LEN]	;
	CHAR    sDealerId       [DEALER_ID_LEN] ;
	CHAR    sBranch_Code    [BRANCH_CODE_LEN] ;
	CHAR    sSession        [SESSION_LEN]  	;
};
#pragma pack()


#pragma pack(4)
struct  BSE_MF_LOGOFF_RESP
{
	CHAR    sTransCode      [TRANSCODE_LEN]  	;
	CHAR    sReply_Code     [REPLY_CODE_LEN] 	;	
	CHAR    sTrade_Date     [TRADE_DATE_LEN]  	;
	CHAR    sCurrent_Time   [CURRENT_TIME_LEN] 	;
	CHAR    sMessage        [LOGOFF_RESP_MESSG_LEN]	;
};
#pragma pack()


#pragma pack(4)
struct	BSE_STAR_ORDER_ENTRY_REQ
{
	CHAR    sTransCode      	[TRANSCODE_LEN]  	;	
	CHAR	sScripID		[SCHEME_TOKEN_LEN]	;
	CHAR	sScripCode		[SCRIP_CODE_LEN]	;
	CHAR	cBuySell		  			;
	CHAR	sBuySellType		[BUY_SELL_TYPE]		;
	CHAR	sClientCode		[CLIENT_CODE_LEN]	;
	CHAR	sMemberId		[MEMBER_ID_LEN]		;
	CHAR	sRedemDestSource 	  			;
	CHAR	sAmount			[AMOUNT_LEN]		;
	CHAR	sOrigPurchaseAmnt 	[ORG_PURCHASE_AMOUNT_LEN];
	CHAR	sRedemQty		[REDEM_QTY]		;
	CHAR	sOrigRedemQty		[ORG_REDEM_QTY]		;
	CHAR	sFolioNo		[FOLIO_NO_LEN]		;			
	CHAR	cKycStatus		  			;
	CHAR	sRemarks		[BSE_MF_REMARKS_LEN]	;
	CHAR	sLoginId		[LOGIN_ID_LEN]		;
	CHAR	sBranchCode		[BRANCH_CODE]		; 
	CHAR	sDealerId		[DEALER_ID_LEN]		;
	CHAR	sRefNo			[REFERENCE_NO]		;
	CHAR	sSession		[SESSION_LEN]		;
	CHAR	sOrderNo		[ORDER_NO_LEN]		;
	CHAR	sLastModDate		[LAST_MODIFIED_DATE_LEN];
	CHAR	sLastModTime		[LAST_MODIFIED_TIME_LEN];
	CHAR	sSubBrokerCode		[SUB_BROK_CODE_LEN]	;
	CHAR	sEuinCode		[EUIN_LEN]		;
	CHAR	cEuinDecl					;
	CHAR	sMinRedemFlag		[MIN_REDEM_FLAG]	;
	CHAR	sFiller2		[FILLER_LEN_25]		;
	CHAR	sFiller3		[FILLER_LEN_25]		;
	CHAR	sSubBrokerArnCode	[SUB_BROK_ARN_CODE]	;
	CHAR	sFiller4		[FILLER_LEN_20]		;
	CHAR	sFiller5		[FILLER_LEN_20]		;
	CHAR	sFiller6		[FILLER_LEN_20]		;	
	LONG32	iSerialNo					;
};
#pragma pack()

#pragma pack(4)
struct  BSE_MF_ORDER_ENTRY_RESP
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sScripID                [SCHEME_TOKEN_LEN]      ;
	CHAR    sScripCode              [SCRIP_CODE_LEN]        ;
	CHAR    cBuySell                                        ;
	CHAR    sBuySellType            [BUY_SELL_TYPE]         ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR    sMemberId               [MEMBER_ID_LEN]         ;
	CHAR    cRedemDestSource                                ;
	CHAR    sAmount                 [AMOUNT_LEN]            ;
	CHAR    sOrigPurchaseAmnt       [ORG_PURCHASE_AMOUNT_LEN];
	CHAR    sRedemQty               [REDEM_QTY]             ;
	CHAR    sOrigRedemQty           [ORG_REDEM_QTY]         ;
	CHAR    sFolioNo                [FOLIO_NO_LEN]          ;
	CHAR    cKycStatus                                      ;
	CHAR    sRemarks                [BSE_MF_REMARKS_LEN]   	;
	CHAR    sLoginId                [LOGIN_ID_LEN]          ;
	CHAR	sRefNo			[REFERENCE_NO]		;
	CHAR    sDealerId               [DEALER_ID_LEN]         ;
	CHAR    sBranchCode             [BRANCH_CODE]           ; 
	CHAR    sSession                [SESSION_LEN]           ;
	CHAR    sOrderNo                [ORDER_NO_LEN]          ;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR    sSubBrokerCode          [SUB_BROK_CODE_LEN]     ;
	CHAR    sEuinCode               [EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR    sMinRedemFlag           [MIN_REDEM_FLAG]        ;
	CHAR    sFiller3                [FILLER_3_LEN]          ;
	CHAR	sReplyCode		[REPLY_CODE_LEN]	;
	CHAR	sOrdResMsg		[ORD_RESP_MESSG_LEN]	;
	CHAR	sActionCode		[ACTION_CODE_LEN]	;
	CHAR    sSubBrokerArnCode       [SUB_BROK_ARN_CODE]     ;
	CHAR    sFiller4                [FILLER_LEN_20]         ;
	CHAR    sFiller5                [FILLER_LEN_20]         ;
	CHAR    sFiller6                [FILLER_LEN_20]         ;

};
#pragma pack()

#pragma pack(4)
struct BSE_SIP_REGISTRATION_REQ
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR	sAmcCode		[BSE_AMC_CODE_LEN]	;
	CHAR	sSchemeCode		[SCHEME_CODE_LEN]	;
	CHAR	sIntRefNo		[INT_REFERENCE_NO]	;
	CHAR	cTransactionMode				;
	CHAR	cDpTransactionMode				;
	CHAR	sFolioNo		[SIP_FOLIO_NO_LEN]	;
	CHAR	sFreqType		[FREQUENCY_TYPE]	;
	LONG32	iFreqAllowed					;
	LONG32	iInstallationAmnt				;	/*------Just Check in Doc------*/
	CHAR	cFirst_Ord_Ofday_Flg				;
	CHAR	sStartDate		[SIP_START_DATE]	;
	LONG32	iNoOfInstallments				;
	CHAR    sEuinCode               [EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR	sRemarks		[SIP_REMARKS_LEN]	;
	CHAR	cDpcFlg						;	
	CHAR	sMemberId		[MEMBER_ID_LEN]		;
	CHAR	sLoginId		[LOGIN_ID_LEN]		;
	CHAR	sSession		[SESSION_LEN]		;
	CHAR	sSipRegNo		[SIP_REGISTRATION_NO_LEN];
	CHAR	sBranchCode		[BRANCH_CODE_LEN]	;
	CHAR	sDealerId		[DEALER_ID_LEN]		;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR	sFiller1		[FILLER_LEN_20]		;
	CHAR	sFiller2		[FILLER_LEN_20]		;
	CHAR	sFiller3		[FILLER_LEN_20]		;
	CHAR	sFiller4		[FILLER_LEN_20]		;
};
#pragma pack()

#pragma pack(4)
struct BSE_SIP_REGISTRATION_RESP
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR    sSchemeCode             [SCHEME_CODE_LEN]	;
	CHAR    sIntRefNo               [INT_REFERENCE_NO]	;
	CHAR    sFolioNo                [SIP_FOLIO_NO_LEN]	;
	CHAR	sSipRegstrationDate	[SIP_REGISTRATION_DATE_LEN];
	CHAR    sStartDate              [SIP_START_DATE]	;
	LONG32	iInstalmentNo					;
	CHAR	sEndDate		[SIP_END_DATE]		;
	LONG32	iInstalmentAmnt					;
	CHAR    cFirst_Ord_Ofday_Flg    			;
	CHAR    sRemarks                [SIP_REMARKS_LEN]	;
	CHAR    cDpcFlg                 			;
	CHAR    sMemberId               [MEMBER_ID_LEN]		;
	CHAR    sLoginId                [LOGIN_ID_LEN]		;
	CHAR    sSession                [SESSION_LEN]		;
	CHAR    sSipRegNo               [SIP_REGISTRATION_NO_LEN];
	CHAR    sBranchCode             [BRANCH_CODE_LEN]	;
	CHAR    sDealerId               [DEALER_ID_LEN]		;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR	sReplyCode		[REPLY_CODE_LEN]	;
	CHAR	sMessage		[ORD_RESP_MESSG_LEN]	;
	CHAR    sFiller1                [FILLER_LEN_20]		;
	CHAR    sFiller2                [FILLER_LEN_20]		;
	CHAR    sFiller3                [FILLER_LEN_20]		;
	CHAR    sFiller4                [FILLER_LEN_20]		;

};
#pragma pack()

#pragma pack(4)
struct BSE_DELTA_DOWNLOAD_REQ
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sLoginId                [LOGIN_ID_LEN]		;
	CHAR    sMemberId               [MEMBER_ID_LEN]		;
	CHAR    sDealerId               [DEALER_ID_LEN]		;
	CHAR    sBranchCode             [BRANCH_CODE_LEN]	;
	CHAR    sSession                [SESSION_LEN]		;
	CHAR	sLastDate		[DELTA_LAST_DATE]	;
	CHAR	sLastTime		[DELTA_LAST_TIME]	;
	CHAR    sSubBrokerCode          [SUB_BROK_CODE_LEN]     ;
	CHAR    sEuinCode               [EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR    sFiller1                [FILLER_LEN_25]		;
	CHAR    sFiller2                [FILLER_LEN_25]		;
	CHAR    sFiller3                [FILLER_LEN_25]		;
};
#pragma pack()


#pragma pack(4)
struct BSE_DELTA_DOWNLOAD_RESP
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sScripID                [SCHEME_TOKEN_LEN]      ;
	CHAR    sScripCode              [SCRIP_CODE_LEN]        ;
	CHAR    sBuySellType            [BUY_SELL_TYPE]         ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR    sMemberId1              [MEMBER_ID_LEN]      	;
	CHAR    cRedemDestSource                                ;
	CHAR    sPurchaseAmnt       [ORG_PURCHASE_AMOUNT_LEN]	;
	CHAR    sRedemQty               [REDEM_QTY]             ;
	CHAR    sFolioNo                [FOLIO_NO_LEN]          ;
	CHAR    cKycStatus                                      ;
	CHAR    sRemarks                [BSE_MF_REMARKS_LEN]  	;
	CHAR    sLoginId                [LOGIN_ID_LEN]          ;
	CHAR    sMemberId2               [MEMBER_ID_LEN]        ;
	CHAR    sDealerId               [DEALER_ID_LEN]         ;
	CHAR    sBranchCode             [BRANCH_CODE]           ;
	CHAR    sSession                [SESSION_LEN]           ;
	CHAR    sOrderNo                [ORDER_NO_LEN]          ;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR    sSubBrokerCode          [SUB_BROK_CODE_LEN]     ;
	CHAR    sEuinCode               [EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR    sMinRedemFlag           [MIN_REDEM_FLAG]        ;
	CHAR    sFiller2                [FILLER_LEN_25]         ;
	CHAR    sFiller3                [FILLER_LEN_25]         ;
	CHAR    sActionCode             [ACTION_CODE_LEN]       ;
	CHAR    sRefNo                  [REFERENCE_NO]          ;
	CHAR    sReplyCode              [REPLY_CODE_LEN]        ;
	CHAR    sErrorMsg              [ORD_RESP_MESSG_LEN]    	;
};
#pragma pack()

#pragma pack(4)
struct BSE_XSIP_REGISTRATION_REQ
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR    sAmcCode                [BSE_AMC_CODE_LEN]	;
	CHAR    sSchemeCode             [SCHEME_CODE_LEN]	;
	CHAR    sIntRefNo               [INT_REFERENCE_NO]	;
	CHAR    cTransactionMode        			;
	CHAR    cDpTransactionMode      			;
	CHAR    sFolioNo                [SIP_FOLIO_NO_LEN]	;
	CHAR    sFreqType               [FREQUENCY_TYPE]	;
	LONG32  iFreqAllowed            			;
	LONG32  iInstallationAmnt       			;       /*------Just Check in Doc------*/
	LONG32	iBrokerage					; /*Just verify It */
	LONG32	iXSipMandateId					; 
	CHAR    cFirst_Ord_Ofday_Flg    			;
	CHAR    sStartDate              [SIP_START_DATE]	;
	LONG32  iNoOfInstallments       			;
	CHAR    sEuinCode               [EUIN_LEN]              ;
	CHAR    cEuinDecl                                       ;
	CHAR    sRemarks                [SIP_REMARKS_LEN]	;	
	CHAR    cDpcFlg                 			;
	CHAR    sMemberId               [MEMBER_ID_LEN]		;
	CHAR    sLoginId                [LOGIN_ID_LEN]		;
	CHAR    sSession                [SESSION_LEN]		;
	CHAR    sXSipRegNo             [SIP_REGISTRATION_NO_LEN];
	CHAR    sBranchCode             [BRANCH_CODE_LEN]	;
	CHAR    sDealerId               [DEALER_ID_LEN]		;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR    sFiller1                [FILLER_LEN_20]		;
	CHAR    sFiller2                [FILLER_LEN_20]		;
	CHAR    sFiller3                [FILLER_LEN_20]		;
	CHAR    sFiller4                [FILLER_LEN_20]		;
};
#pragma pack()


#pragma pack(4)
struct BSE_XSIP_REGISTRATION_RESP
{
	CHAR    sTransCode              [TRANSCODE_LEN]          ;
	CHAR    sClientCode             [CLIENT_CODE_LEN]       ;
	CHAR    sSchemeCode             [SCHEME_CODE_LEN]       ;
	CHAR    sIntRefNo               [INT_REFERENCE_NO]      ;
	CHAR	sSipRegNo1		[SIP_REGISTRATION_NO_LEN];
	CHAR    sFolioNo                [SIP_FOLIO_NO_LEN]      ;
	CHAR    sSipRegstrationDate     [SIP_REGISTRATION_DATE_LEN];
	CHAR    sStartDate              [SIP_START_DATE]        ;
	LONG32  iInstalmentNo                                   ;
	CHAR    sEndDate                [SIP_END_DATE]          ;
	LONG32  iInstalmentAmnt                                 ;
	CHAR    cFirst_Ord_Ofday_Flg                            ;
	CHAR    sRemarks                [SIP_REMARKS_LEN]       ;
	CHAR    cDpcFlg                                         ;
	CHAR    sMemberId               [MEMBER_ID_LEN]		;
	CHAR    sLoginId                [LOGIN_ID_LEN]		;
	CHAR    sSession                [SESSION_LEN]		;
	CHAR    sXSipRegNo             [SIP_REGISTRATION_NO_LEN];
	CHAR    sBranchCode             [BRANCH_CODE_LEN]	;
	CHAR    sDealerId               [DEALER_ID_LEN]		;
	CHAR    sLastModDate            [LAST_MODIFIED_DATE_LEN];
	CHAR    sLastModTime            [LAST_MODIFIED_TIME_LEN];
	CHAR    sReplyCode              [REPLY_CODE_LEN]	;
	CHAR    sMessage                [ORD_RESP_MESSG_LEN]	;
	CHAR    sFiller1                [FILLER_LEN_20]		;
	CHAR    sFiller2                [FILLER_LEN_20]		;
	CHAR    sFiller3                [FILLER_LEN_20]		;
	CHAR    sFiller4                [FILLER_LEN_20]		;

};
#pragma pack()


#endif	
