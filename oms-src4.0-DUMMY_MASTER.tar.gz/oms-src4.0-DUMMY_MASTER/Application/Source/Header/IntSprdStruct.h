#ifndef __COMMON_H__
#define __COMMON_H__
#include "SystemSprdStructs.h"
#include "IntMsgCodes.h"

#pragma pack(4)
struct INT_COMMON_RESP_HDR
{
	LONG32		iSeqNo				;
	SHORT		iMsgLength			; 
	SHORT 		iMsgCode			;
	CHAR		sExcgId[EXCHANGE_LEN]		;
	SHORT		iErrorId			;	
	LONG32		iUserId				;  
	CHAR		cSource				;	
	LONG32          iTimeStamp			;
	CHAR		cSegment			;

};
#pragma pack()


#pragma pack(4)	
struct INT_COMMON_REQUEST_HDR
{
	LONG32		iSeqNo				;
	SHORT		iMsgLength			;
	SHORT     	iMsgCode			;
	CHAR		sExcgId[EXCHANGE_LEN]		;
	LONG32 		iUserId				; 
	CHAR		cSource				; 	
	CHAR		cSegment			;
};
#pragma pack()


#pragma pack(4)
struct ORDER_REQUEST
{
	struct  INT_COMMON_REQUEST_HDR      ReqHeader	;
	CHAR		sSecurityId		[SECURITY_ID_LEN]	;
	CHAR		sEntityId		[ENTITY_ID_LEN]		;
	CHAR		sClientId		[CLIENT_ID_LEN]		;
	CHAR		cProductId					;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	CHAR		cBuyOrSell					;
	SHORT		iOrderType					;                               /***** SAME AS TAG 40 *****/
	SHORT		iOrderValidity					;                               /*** SAME AS TAG 59 *******/            
	LONG32		iDiscQty					;
	LONG32		iDiscQtyRem					;
	LONG32		iTotalQtyRem					;
	LONG32		iTotalQty					;
	LONG32		iTotalTradedQty					;
	LONG32		iMinFillQty					;
	DOUBLE64	fPrice						;
	DOUBLE64	fTriggerPrice					;
	DOUBLE64	fOrderNum					;
	SHORT		iSerialNum					;
	CHAR		cHandleInst					;
	DOUBLE64	fAlgoOrderNo					;
	SHORT		iStratergyId					;
	CHAR		cOffMarketFlg					;
	CHAR		cProCli						;
	CHAR		cUserType					;
	CHAR            sRemarks		[REMARKS_LEN]		;
	LONG32          iMktType                                        ;
	LONG32          iAuctionNum                                     ;
};
#pragma pack()

#pragma pack(4)
struct ORDER_RESPONSE
{
	struct  INT_COMMON_RESP_HDR      IntRespHeader   ;
	CHAR            sSecurityId             [SECURITY_ID_LEN]       ;
	CHAR            sEntityId               [ENTITY_ID_LEN]         ;
	CHAR            sClientId               [CLIENT_ID_LEN]         ;
	CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]     ;
	CHAR            cProductId                                      ;       /*C-CNC,M-MARGIN .I-INTRADAY .F-MARGIN FUNDING*/
	CHAR            cBuyOrSell                                      ;
	SHORT           iOrderType                                      ;                               /***** SAME AS TAG 40 *****/
	SHORT           iOrderValidity                                  ;                               /*** SAME AS TAG 59 *******/
	LONG32          iDiscQty					;
	LONG32          iDiscQtyRem                                     ;
	LONG32          iTotalQtyRem                                    ;
	LONG32          iTotalQty                                       ;
	LONG32          iLastTradedQty					;
	LONG32          iTotalTradedQty                                 ;
	LONG32          iMinFillQty                                     ;
	DOUBLE64        fPrice                                          ;
	DOUBLE64        fTriggerPrice                                   ;
	DOUBLE64        fOrderNum                                       ;
	SHORT           iSerialNum                                      ;
	CHAR		sTradeNo		[DB_EXCH_TRD_NO_LEN]	;
	DOUBLE64	fTradePrice					;		
	CHAR            cHandleInst                                     ;
	DOUBLE64        fAlgoOrderNo                                    ;
	SHORT           iStratergyId                                    ;
	CHAR            cOffMarketFlg                                   ;
	CHAR            cProCli                                         ;
	CHAR            cUserType                                      	;
	CHAR            sOrdEntryTime           [DATE_TIME_LEN]         ;
	CHAR            sTransacTime            [DATE_TIME_LEN]         ;
	CHAR            sRemarks                [REMARKS_LEN]           ;
	LONG32		iMktType    					;
};
#pragma pack()
/*
#pragma pack(4)
struct ORDER_SPREAD_REQUEST
{
struct  INT_COMMON_REQUEST_HDR            ReqHeader               ;
CHAR            sSecurityId_1             [SECURITY_ID_LEN]       ;
CHAR            sSecurityId_2             [SECURITY_ID_LEN]       ;
CHAR            sEntityId                 [ENTITY_ID_LEN]         ;
CHAR            sClientId                 [CLIENT_ID_LEN]         ;
CHAR            cProductId                                        ;
CHAR            cBuyOrSell                                        ;
SHORT           iOrderType                                        ;                               /***** SAME AS TAG 40 ***** /
SHORT           iOrderValidity                                    ;
LONG32          iDiscQty                                          ;
LONG32          iDiscQtyRem                                       ;
LONG32          iTotalQtyRem                                      ;
LONG32          iTotalQty                                         ;
LONG32          iTotalTradedQty                                   ;
LONG32          iMinFillQty                                       ;
DOUBLE64        fPrice                                            ;
DOUBLE64        fOrderNum                                         ;
SHORT           iSerialNum                                        ;
CHAR            cHandleInst                                       ;
DOUBLE64        fAlgoOrderNo                                      ;
SHORT           iStratergyId                                      ;
CHAR            cOffMarketFlg                                     ;
CHAR            cProCli                                           ;
CHAR            cUserType                                         ;
CHAR            sRemarks                [REMARKS_LEN]             ;
LONG32          iMktType                                          ;
};
#pragma pack()

#pragma pack(4)
struct ORDER_SPREAD_RESPONSE
{
struct  	INT_COMMON_RESP_HDR      IntRespHeader   ;
CHAR            sSecurityId_1             [SECURITY_ID_LEN]       ;
CHAR            sSecurityId_2             [SECURITY_ID_LEN]       ;
CHAR            sEntityId               [ENTITY_ID_LEN]           ;
CHAR            sClientId               [CLIENT_ID_LEN]           ;	
CHAR            sExchOrderID            [EXCH_ORDER_NO_LEN]       ;
CHAR            cProductId                                        ;
CHAR            cBuyOrSell 	                                  ;
SHORT           iOrderType                                        ;
SHORT           iOrderValidity                                    ;                               /*** SAME AS TAG 59 ******* /
LONG32          iDiscQty                                          ;
LONG32          iDiscQtyRem                                       ;
LONG32          iTotalQtyRem                                      ;
LONG32          iTotalQty                                         ;
LONG32          iLastTradedQty                                    ;
LONG32          iTotalTradedQty                                   ;
LONG32          iMinFillQty                                       ;
DOUBLE64        fPrice                                            ;
DOUBLE64        fOrderNum                                         ;
SHORT           iSerialNum                                        ;
CHAR            sTradeNo                [DB_EXCH_TRD_NO_LEN]      ;
DOUBLE64        fTradePrice                                       ;
CHAR            cHandleInst                                       ;
DOUBLE64        fAlgoOrderNo                                      ;
SHORT           iStratergyId                                      ;	
CHAR            cOffMarketFlg                                     ;
CHAR            cProCli                                           ;
CHAR            cUserType                                         ;
CHAR            sOrdEntryTime           [DATE_TIME_LEN]           ;
CHAR            sTransacTime            [DATE_TIME_LEN]           ;
CHAR            sRemarks                [REMARKS_LEN]             ;
LONG32          iMktType                                          ;	
};
#pragma pack()
 */
/*
#pragma pack(4)
struct SUB_ORDER_REQUEST_SPREAD_2L_3L
{
CHAR        	sSecurityId[SECURITY_ID_LEN]      ;
CHAR        	cBuyOrSell			  ;
};
#pragma pack()

#pragma pack(4)
struct ORDER_REQUEST_SPREAD_2L
{
struct          INT_COMMON_REQUEST_HDR     IntReqHeader ;
LONG32          iNoOfLeg                		;
CHAR            sEntityId[ENTITY_ID_LEN]                ;
CHAR            sClientId[CLIENT_ID_LEN]                ;
CHAR            cProductId                              ;
SHORT           iOrderType                              ;
CHAR            cProCli                                 ;
DOUBLE64        fOrderNum                               ;
LONG32      	iTotalQtyRemaining       	        ;
LONG32      	iTotalQty                       	;
LONG32      	iTotalTradedQty				;
LONG32      	iMinFillQty                     	;
DOUBLE64        fPriceDiff                              ;              
SHORT      	iOrderValidity                    	;
INT16           iSerialNum                        	;
CHAR            sRemarks[REMARKS_LEN]             	;
CHAR            sSettlor[SETTLOR_LEN]                   ;
INT16           GoodTillDays                            ;
CHAR            GoodTillDate[DATE_LEN]                  ;
CHAR            cHandleInst                             ;
struct          SUB_ORDER_REQUEST_SPREAD_2L_3L  sSpreadLeg[LEG_LEN];
CHAR            sParticipantType[PARTICIPANT_LEN]       ;
CHAR            sParticipantCode[PARTICIPANT_LEN]      	;
CHAR            sCBrokerCode[BROKER_CODE_LEN]        	;
DOUBLE64        fAlgoOrderNo                            ;
SHORT           iStratergyId                            ;
CHAR            cUserType                               ;
};
#pragma pack()

 */

#pragma pack(4)
struct INT_ERROR_FE_RESP
{
	struct INT_COMMON_RESP_HDR	IntRespHeader				;
	CHAR		sSecurityId_1[SECURITY_ID_LEN]			;
	CHAR		sSecurityId_2[SECURITY_ID_LEN]			;
	CHAR            sClientId[CLIENT_ID_LEN]			;
	CHAR            cProductId					;	
	CHAR		cBuyOrSell					;	
	LONG32          iTotalQty					;
	DOUBLE64	fPrice						;
	CHAR		sErrorMsg		[ERROR_MSG_LEN]		;
};
#pragma pack()


#endif
