#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

redisContext *c;
redisContext *c1;
redisReply *reply;
redisReply *reply1;
redisReply *reply2;
MYSQL   *DNMbp_con;

main(int argc,char **argv)
{
        setbuf(stdout,0);
        logTimestamp("ENTRY [Main]");
	c = RDConnect();
        c1 = RDConnect();
        DNMbp_con=DB_Connect();
        ReceiveReplyPacketsBcast();
        return 0;
	logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
        logTimestamp("ENTRY [UPDATE LTP IN DB]");
        CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN] ;
        BOOL flag;
        int count=0;
        int iCount ;
        CHAR sKeyValue[RADIS_KEY_LEN];
        DOUBLE64   fTempLtp=0.00;
	LONG32	TempDayHiOpenInt,TempDayLowOpenInt;
        LONG32          iTempScripCode =0 ,iMsgCode;
	LONG32	iBcastMonCountr = 0;
        CHAR    NormlMkt [MKT_TYPE_LEN];
        CHAR    sExch [10];
        CHAR    cSegment;
        CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR    sUpdateQry[MAX_QUERY_SIZE];
        CHAR    supdate [MAX_QUERY_SIZE];
        CHAR    sBroadcastMon[COMMAND_LEN];
	LONG32  iRowsAffcted = 0;

        sprintf(sCommand,"SUBSCRIBE OMSMCXCOM");
        logDebug2("sCommand -> %s",sCommand);
        reply = redisCommand(c,sCommand);
        logDebug2("INCR counter: %lld", reply->integer);
        while(redisGetReply(c,(void**)&reply) == REDIS_OK)
        {
		logTimestamp("Recive Publish Key");
                memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
                memset(&supdate,'\0',MAX_QUERY_SIZE);
                memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
                if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3)
                {
                        logDebug2(stderr, "Error:  Malformed subscribe response!");
                        exit(-1);
                }

                logDebug2("Channel: %s", reply->element[1]->str);
                logDebug2("Received message: %s", reply->element[2]->str);
                sprintf(sKeyValue,"%s",reply->element[2]->str);
                freeReplyObject(reply);
		
		memset(sCommand1,'\0',COMMAND_LEN);
                sprintf(sCommand1,"TTL %s",sKeyValue);
                logDebug2("sCommand1 -> %s",sCommand1);
                reply = redisCommand(c1,sCommand1);
                logDebug2("INCR counter: %lld", reply->integer);
		
		if(reply->integer != 0 && reply->integer != -2)
                {
                	memset(sCommand,'\0',COMMAND_LEN);
	                sprintf(sCommand,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT DRVOILOW DRVOIHIGH ",sKeyValue);
	                logDebug2("sCommand -> %s",sCommand);
	                reply1 = redisCommand(c1,sCommand);
	                iCount = reply1->elements;
	                logDebug2("ELEMENT COUNT =%d ",iCount);
	                logDebug2("Received message LTP : %s", reply1->element[0]->str);
	                logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
	                logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
	                logDebug2("Received message EXCH: %s", reply1->element[3]->str);
	                logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
	                logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
	                fTempLtp = atof(reply1->element[0]->str);
	                iTempScripCode = atoi(reply1->element[1]->str);
	                iMsgCode = atoi(reply1->element[4]->str);
	                sprintf(NormlMkt,"%s",reply1->element[2]->str);
			logDebug2("Received message OILOW: %s", reply1->element[6]->str);
	                logDebug2("Received message OIHIGH: %s", reply1->element[7]->str);
	                TempDayHiOpenInt = atoi(reply1->element[7]->str);
	                TempDayLowOpenInt = atoi(reply1->element[6]->str);
			
		
			sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
		                (DL1_EXCHANGE ,\
	        	        DL1_SEGMENT,\
		                DL1_SCRIP_CODE,\
		                DL1_EXCH_SCRIP_CODE,\
		                DL1_MARKET_TYPE,\
		                DL1_ENTRY_TIME,\
		                DL1_LTP,\
				DL1_OPEN_INTEREST,\
		                DL1_OI_HIGH ,\
		                DL1_OI_LOW)\
		                VALUES(\"%s\",\'%c\',%d,%d,\"%s\",NOW(),%lf,%d,%d,%d)\
		                on duplicate key \
		                UPDATE \
		                DL1_EXCHANGE = VALUES(DL1_EXCHANGE) ,\
		                DL1_SEGMENT = VALUES(DL1_SEGMENT),\
		                DL1_SCRIP_CODE = VALUES(DL1_SCRIP_CODE),\
	        	        DL1_EXCH_SCRIP_CODE = VALUES(DL1_EXCH_SCRIP_CODE),\
		                DL1_MARKET_TYPE = VALUES(DL1_MARKET_TYPE),\
		                DL1_ENTRY_TIME = VALUES(DL1_ENTRY_TIME),\
		                DL1_LTP = VALUES(DL1_LTP),\
				DL1_OPEN_INTEREST = VALUES(DL1_OPEN_INTEREST),\
		                DL1_OI_HIGH = VALUES(DL1_OI_HIGH),\
		                DL1_OI_LOW  = VALUES(DL1_OI_LOW);",MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode,iTempScripCode,MKT_TYPE_NL,fTempLtp,TempDayHiOpenInt,TempDayHiOpenInt,TempDayLowOpenInt);
	
		        logDebug2("sInsertQry:%s:",sInsertQry);
	        	if(mysql_query(DNMbp_con,sInsertQry) != SUCCESS)
	        	{
	                	logSqlFatal("ERROR IN UPDATING In Function fTC_MBP_BCAST ");
	                	sql_Error(DNMbp_con);
	        	}
	        	else
		        {
	
		                logDebug2("------SUCCESS IN UPDATE QUERY-----");
		                iRowsAffcted = mysql_affected_rows(DNMbp_con);
		                logDebug2("%d rows updated!!",iRowsAffcted);
				mysql_commit(DNMbp_con);
		                iRowsAffcted = mysql_affected_rows(DNMbp_con);
		                logDebug2("%d rows updated!!",iRowsAffcted);
				iBcastMonCountr ++;
                        	logDebug3("iBcastMonCountr :%d:",iBcastMonCountr);
                        	memset(sBroadcastMon,'\0',COMMAND_LEN);
                        	sprintf(sBroadcastMon,"HMSET BCAST:MON MCX:M:COUNT %d ",iBcastMonCountr);
                        	logTimestamp("sCommand -> %s",sBroadcastMon);
                        	reply2 = redisCommand(c1,sBroadcastMon);
                        	freeReplyObject(reply2);
		        }
	
		        sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET L1_LTP = %lf WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",fTempLtp,MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode);

		        logDebug1("supdate :%s:",supdate);

		        if(mysql_query(DNMbp_con,supdate) != SUCCESS)
		        {
		                logDebug2(" Update Query[%s]",supdate);
		                logSqlFatal("In Function [TC_MBP_BCAST]-->ERROR IN LTP UPDATE-->L1_WATCH_ACTIVE");
		                sql_Error(DNMbp_con);
		        }
		        else
		        {
		                mysql_commit(DNMbp_con);
		                logDebug2("------SUCCESS IN LTP UPDATE-----");
	        	}
			freeReplyObject(reply1);

		}


		logTimestamp("#####EXIT####");


        }
        logTimestamp("EXIT [UPDATE LTP IN DB]");

}

