#include <stdlib.h>
#include <errno.h>
#include "IPCS.h"
#include "IcexBcastDef.h"



#define MCX_MAX_BCAST_MSG_LEN 4096


BOOL	OpenSocket(CHAR ServiceType,LONG32 *sockfd);
LONG32	sockfd1,sockfdBroad , sockfdMulti;
BOOL	OpenBcastSocket();
BOOL	SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 portno);
BOOL 	ReceiveReplyPackets(LONG32 sfdBcastRecv);
BOOL	GetQStatus( int MsgQuery);

SHORT   fTrimMCX( CHAR * Str_In ,SHORT MaxLen );

CHAR	cReadFlag;

BOOL 	fTC_ICEX_MBP_BCAST(CHAR *recvBuffer,CHAR *recvBuffer1,LONG32 *MsgLength,LONG32 *MsgLength1);
BOOL 	fTC_MKT_CLOSE_STATISTICS(CHAR *recvBuffer , CHAR *recvBuffer1,LONG32 *MsgLength ,LONG32 *MsgLength1);

main(LONG32 argc,CHAR **argv)
{
	struct	sockaddr_in cli_addr;


	CHAR    cService;
	CHAR    temp[MAX_SIZE];
	LONG32  val;
	LONG32  sfdBcastRecv;
	LONG32 	iRecvPort;
	CHAR 	mbpport[10];
	CHAR    sTempPort[10];

	logInfo("argc :%d:",argc);
	if ( argc != 5 )
	{
		logDebug2("Argument Mismstch ");
		logDebug2("USAGE : <ICEXBcastAdapter>   <Recv Port> <L LIVE/D DUMP>    <Service {M Multicast/B Broadcast}> <MCXBcastAdapter> ");
		exit(0);
	}


	setbuf(stdout,0);

	iRecvPort = atoi(argv[1]);		
	cReadFlag = argv[2][0];
	cService  = argv[3][0];

	logDebug2(" _________P A R A M E T E R E S____________ ");

	logDebug2(" Recv Portno  is  : %d ",iRecvPort);
	logDebug2(" ReadFlag     is  : %c ",cReadFlag);
	logDebug2(" Service type is  : %c ",cService);

	logDebug2(" __________________________________________ ");


	cli_addr.sin_family     = AF_INET;
	cli_addr.sin_addr.s_addr= INADDR_ANY;
	cli_addr.sin_port       = htons(iRecvPort);



	for( ; ; )
	{
		if ( cReadFlag =='L')
		{

			if(OpenSocket(cService,&sfdBcastRecv))
			{
				if (val = (bind(sfdBcastRecv,(struct sockaddr *)&cli_addr,sizeof(struct sockaddr))) <0)
				{
					logDebug2("Client : Error in Binding...is:%d",errno);
					memcpy(temp,strerror(errno),100);
					exit(1);
				}
			}
		}


		logDebug2("Connection to ICEX Broadcast Circuit successful");

		ReceiveReplyPackets(sfdBcastRecv);
	}

}/*** END Of main() ***/

BOOL ReceiveReplyPackets(LONG32 sfdBcastRecv)
{
	logTimestamp("ENTRY :ReceiveReplyPackets:");
	int     fileCounter = 0;
	CHAR    tempdata[4000];
	CHAR    temp[MCX_MAX_BCAST_MSG_LEN];
	CHAR    temp1[MCX_MAX_BCAST_MSG_LEN];
	CHAR 	temp2[4];
	CHAR 	temp3[MCX_MAX_BCAST_MSG_LEN];
	LONG32  sfdMultiBroad,qidnormal;
	LONG32  ReadByte,write_status,clilen;
	LONG32  iTranscode,flag,i,iMsgLegth=0,MsgLength1=0,iTemp = 0;
	LONG32  MinPackSize = 10,Count=0;
	LONG32  PacketCounter,szCompressed,szUncompressed,szPercentCompression;
	struct  sockaddr_in serv_addr;
	USHORT  ErrorCode;
	USHORT  Len,complen;
	USHORT  LenSpeed ; 
	struct  sockaddr_in cli_addr ;
	SHORT   TempLen;
	LONG32 	ShmAddrsfd;
	struct 	sockaddr_in Serv_Addr_Shm;
	LONG32  status = TRUE   ;
	CHAR    tempflag= FALSE ;
	LONG32  counter = 0     ;
	LONG32 	iBcasttoIndex;
	struct 	MCX_MBP_BCAST *pMcxHdr;
	struct  MKT_CLOSE_STATISTICS *pMcxRptBcast;
	
	LONG32          iSecurityID             ;
        DOUBLE64        fLastTradePrice         ;

	if(!OpenBcastSocket())
	{
		perror("Error creating Shm  socket");
		exit(0);
	}

	qidnormal = OpenMsgQ(ICEXAdapToUpdtr);
	if ( qidnormal < 0 )
	{
		perror(" Error in  Opening  MCXAdapToUpdtr");
		exit(0);
	}
	else
	{
		logDebug2("Normal Queue opened and ready..... ");
		logDebug2(" The QId is %d",qidnormal);
	}


	while (TRUE)
	{
		memset (&temp,'\0',MCX_MAX_BCAST_MSG_LEN);
		memset (&temp1,'\0',MCX_MAX_BCAST_MSG_LEN);
		memset (&pMcxHdr,'\0',sizeof(struct ICEX_MBP_BCAST ));
	//	memset (&pMcxRptBcast,'\0',sizeof(struct MKT_CLOSE_STATISTICS ));

		logDebug2(" ***************** Loop %d *****************",++Count);


		clilen = sizeof(struct sockaddr);

		if ((ReadByte = recvfrom(sfdBcastRecv,&temp,MCX_MAX_BCAST_MSG_LEN,0,(struct sockaddr *)&serv_addr,&clilen)) < 0 )
		{
			logFatal("Unable to receive the data from sfdBcastRecv, id:%d",sfdBcastRecv);
			break;
		}
		/*****
		  SendBroadcast(&temp,MCX_MAX_BCAST_MSG_LEN,bcastanalytic,iAnlyMCXport);
		  This is comment bcoz noe there is no use of sending to FE*********/

		logDebug2(" Before Getting Msg len ");

		iMsgLegth = ((struct ICEX_BCAST_HEADER *)&temp)->iMsgLegth;
		logDebug2(" Msglegth Recieved :%d:",((struct ICEX_BCAST_HEADER *)&temp)->iMsgLegth);
		logDebug2(" After Getting Msg len ");
		logDebug2(" MsgCode Recieved :%d:",((struct ICEX_BCAST_HEADER *)&temp)->iMsgCode);

		if(((struct ICEX_BCAST_HEADER *)&temp)->iMsgCode == TC_ICEX_MBP_BCAST)
		{
			logDebug2(" ((struct ICEX_MBP_BCAST *)&temp)->fLastTradedPrice:%lf:",((struct ICEX_MBP_BCAST *)&temp)->fLastTradedPrice);
			logDebug2(" ((struct ICEX_MBP_BCAST *)&temp)->iSecurityID:%d:",((struct ICEX_MBP_BCAST *)&temp)->iSecurityID);
			logDebug2(" ((struct ICEX_MBP_BCAST *)&temp)->iMsgCode:%d:",((struct ICEX_MBP_BCAST *)&temp)->bHeader.iMsgCode);
		}
		else if (((struct ICEX_BCAST_HEADER *)&temp)->iMsgCode == TC_OPEN_INTEREST_BCAST)
		{
			logDebug2(" struct INT_ASSET_OI *)&temp)->iNoOfRecs :%d:",((struct INT_ASSET_OI *)&temp)->iNoOfRecs);
						
		}	
		/*FOR EXCH MESSAGES */
		else if(((struct ICEX_BCAST_HEADER *)&temp)->iMsgCode == TC_ICEX_EXCH_MSGS)
		{
			logDebug2("In TC_ICEX_EXCH_MSGS");
		}

		/*FOR DPR CHANGES*/	
		else if (((struct ICEX_BCAST_HEADER *)&temp)->iMsgCode == TC_ICEX_CIRCUIT_LIMIT_BCAST)
		{
			logDebug2("IN INT_CIRCUIT_LIMIT_BCAST");
		}
		else	
		{
			continue;
		}

		status = GetQStatus(qidnormal);
		if ( status == FALSE)
		{
			tempflag = TRUE;
			counter++;
			logFatal(" QUEUE IS FULL");
			system("date");
		}
		else
		{
		//	write_status = WriteMsgQ(qidnormal,&temp,iMsgLegth,1);
			/*Hardcoding is removed*/
			write_status = WriteMsgQ(qidnormal,&temp,iMsgLegth,1);
			logDebug2("Mesage Length is %d",iMsgLegth);
			if ( write_status == ERROR)
			{
				logDebug2("Error in writing to  ICEX_BCAST_Q....");
				continue;
			}
			logDebug2(" Written to Queue Properly ");
		}


	}

	close(sfdMultiBroad);
	close(sfdBcastRecv);
	logTimestamp("EXIT :ReceiveReplyPackets:");
	return;
}

BOOL OpenSocket(CHAR ServiceType,LONG32 *sockfd)
{
	LONG32 sfd;
	LONG32 optval=1;
	LONG32 val=1;
	CHAR ttl=254;

	if ( (sfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("OpenSocket:Error in opening the socket");
		exit(0);
	}

	switch (ServiceType)
	{
		case    'B':
		case    'b':
			if((val =setsockopt(sfd,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval)))< 0)
				perror("OpenSocket: Error in setsockopt for Bcast Socket ");
			logDebug2(" In serivet type B");
			break;

		case    'M':
		case    'm':
			if (( val = setsockopt(sfd,IPPROTO_IP,IP_MULTICAST_TTL,&ttl,sizeof(ttl) ) ) < 0 )
				perror("OpenSocket: Error in setsockopt for Multicast socket");
			logDebug2(" In serivet type M");
			break;

		default :
			if (ServiceType != 'N')
				logDebug2("OpenSocket: Received ServiceType id invalid :%c",ServiceType);
	}

	*sockfd = sfd;

	if (val < 0)
		return FALSE;
	else
		return TRUE;
}

BOOL  OpenBcastSocket()
{
	LONG32 optval=1;
	LONG32  val;
	if ( (sockfdBroad = socket(AF_INET, SOCK_DGRAM, 0)) <0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}
	val = setsockopt(sockfdBroad,SOL_SOCKET,SO_BROADCAST,(CHAR *)&optval,sizeof(optval));
	if ( val < 0 )
	{
		perror(" Broadcast Socket Error ");
		return FALSE;
	}
	return TRUE;
}

BOOL  SendBroadcast(CHAR *cpMsgBuf,LONG32 MsgLen,CHAR *bcastaddress,LONG32 portno)
{
	struct     sockaddr_in cli_addr ;
	cli_addr.sin_family         = AF_INET;
	cli_addr.sin_addr.s_addr    = inet_addr(bcastaddress);
	cli_addr.sin_port           = htons(portno);

	if(sendto(sockfdBroad,cpMsgBuf,MsgLen,0,(struct sockaddr *) &cli_addr,sizeof( struct sockaddr))< 0)
	{
		perror("Server : Error in Sending");
		return FALSE;
	}
	logDebug2(" SENDING BROADCAST IP [%s] PORT [%d]",bcastaddress,portno);

	return TRUE;
}

BOOL GetQStatus( int MsgQuery)
{
	struct msqid_ds sStatQ;
	DOUBLE64        checkbytes = 0.0;

	if(msgctl(MsgQuery,IPC_STAT,&sStatQ) == 0)
	{
		checkbytes      =       (sStatQ.msg_qbytes * 0.066);

		logDebug2(" From MsgQueryQ TotalBytes            = %d, CurrentBytes=%d ", sStatQ.msg_qbytes,sStatQ.msg_cbytes);
		logDebug2(" From MsgQueryQ Availablebytes        = %d", (sStatQ.msg_qbytes - sStatQ.msg_cbytes));
		logDebug2(" From MsgQueryQ CheckPointBytes       = %lf", checkbytes );


		if ((sStatQ.msg_qbytes - sStatQ.msg_cbytes) <= (sStatQ.msg_qbytes * 0.066))
		{
			logFatal(" Queue is 90 Percentage Full:%d", MsgQuery );
			return FALSE ;
		}
		else
		{
			logDebug2("Queue Check : Passed");
			return TRUE ;
		}
	}
} /*** End of GetQStatus *****/

