#include <stdlib.h> 
#include <my_global.h>
#include <mysql.h>
#include "IPCS.h"
#include "McxBcastDef.h"
//inserted by @pratik
#include "hiredis.h"

#define 	MAX_NO_OF_TRANSCODE_RECV 25 
#define 	MAX_NO_OF_TRANSCODE   27 
#define 	TRANSCODE_NOT_DATA  2 
#define 	LOCAL_MAX_PACKET_SIZE  1050 
/*#define ORACLE_CONNECT_STR_LEN   30*/ 
#define    	TERMS_LEN                       3 
#define    	DATE_STRING_LENGTH              20 
#define    	ADMIN_MSG_LEN                   512 
#define    	USERID_LEN                       30 
#define    	MSG_LEN                      200 

//typedef BOOL (*P_TO_FUN)(char * x,struct THREAD_PARAMS *parameter); 

LONG32 iStartupTime;
/**** 
  struct TRANS_FUN_PAIR 
  { 
  INT16  Transcode; 
  P_TO_FUN  pToFun; 
  }; 
 ****/
struct THREAD_PARAMS 
{
	MYSQL	*DB_Con; 
	LONG32 thread_id; 
}; 

INT16 iMbpCount = 0 ;
BOOL  BroadDataUpdate(void *parameter);
LONG32  iSendQ;
MYSQL_RES *result;
MYSQL_ROW rowdata;
LONG32  rcvQ;

MYSQL   	*DNDB_Con; 
//BOOL  BroadDataUpdate(); 

//BOOL 		dTC_MBP_BCAST (char *NNFData,struct THREAD_PARAMS *parameter);
// inserted by @pratik for radis
redisContext *c;
redisReply *reply;
INT16   TranscodeLocal;
INT16   iExpSec;

main(int argc,char *argv[]) 
{ 
	LONG32 	flag; 
	LONG32 	i,iNseRecordCount; 
	CHAR    cMaxNoThread;
	LONG32  iMaxNoThread;

	cMaxNoThread  = argv[1][0];

	iMaxNoThread = cMaxNoThread - '0';

	logDebug3("iMaxNoThread :%d: cMaxNoThread :%c:",iMaxNoThread,cMaxNoThread);


	struct THREAD_PARAMS params[iMaxNoThread]; 
	pthread_t thread_id[iMaxNoThread]; 


	setbuf(stdout,0); 

	DNDB_Con  = DB_Connect();


	if(mysql_autocommit(DNDB_Con,1))
	{
		sql_Error(DNDB_Con);
	}
	else
	{
		logFatal("AutoCommit Enable");
	}
	c = RDConnect();
	// inserted by @pratik for fatching sec value from env
	if(getenv("RADIS_KEY_EXP_SEC")== NULL)
        {
                iExpSec = 10;
                logFatal("Error : Environment variables missing : RADIS_KEY_EXP_SEC ");
        }
        else
        {

                iExpSec = atoi(getenv("RADIS_KEY_EXP_SEC"));
        }
	
	if((rcvQ=OpenMsgQ(MCXAdapToUpdtr)) == ERROR)  
	{ 
		perror("\n Error in opening MCXAdapToUpdtr ...."); 
		exit(ERROR); 
	}  
	logDebug2("Message Queue opened MCXAdapToUpdtr :%d:" ,MCXAdapToUpdtr);
	GetStartupTimeofDay(); 

	if((iSendQ=OpenMsgQ(ComMbpToLtpUdr))==ERROR)
        {
                perror("\n Error in Opening ComMbpToLtpUdr....");
                exit(ERROR);
        }
        logDebug2("Message Queue opened ComMbpToLtpUdr : %d:",iSendQ);

	for(i=0;i<iMaxNoThread;i++) 
	{ 
		params[i].thread_id=i;
		params[i].DB_Con = DB_Connect();	 
		if ((pthread_create(&thread_id[i],NULL,BroadDataUpdate,(void *)&params[i]))!=0) 
			logFatal("Cant create thread %d",i); 
		else 
			logDebug2("Created"); 
	} 

	for(i=0;i<iMaxNoThread;i++) 
	{ 
		/*wait for thread to end */ 

		logDebug2("Thread %d ....",i); 

		if (pthread_join(thread_id[i],NULL)) 
			logFatal("Error when waiting for thread % to terminate", i); 
		else 
			logDebug2("Stopped"); 

		logDebug2("Detach thread..."); 

		if (pthread_detach(&thread_id[i])) 
			logFatal("Error detaching thread!"); 
		else 
			logDebug2("Detached!"); 

		logDebug2("Stop Session %d....",i); 


		logDebug2("Logged Off"); 
	} 


}  

BOOL   BroadDataUpdate(void *parameter) 
{ 
	INT16   i; 
	CHAR   RcvMsg[LOCAL_MAX_PACKET_SIZE];  

	struct MCX_BCAST_HEADER *pForRecTransCode; 
	LONG32 count; 
	BOOL ReturnValue; 
	struct THREAD_PARAMS *l_parameter = parameter; 


	struct TRANS_FUN_PAIR TransFunPair[MAX_NO_OF_TRANSCODE] = 
	{ 	
		TC_MBP_BCAST,                         dTC_MBP_BCAST 
	}; 


	logDebug2("ALOKK U R HERE "); 
	while(TRUE) 
	{ 
		memset(&RcvMsg,SPACE,LOCAL_MAX_PACKET_SIZE); 
		logDebug2("w8ing on read Q :%d:",rcvQ);
		if((ReadMsgQ(rcvQ,&RcvMsg,LOCAL_MAX_PACKET_SIZE, 1)) != TRUE) 
		{ 
			perror("Error Read Q "); 
			logDebug2("id %d",rcvQ); 
			exit(ERROR); 
		} 
		logDebug2(" DATA Received on queue %d",rcvQ);

		pForRecTransCode  = (struct MCX_BCAST_HEADER *) RcvMsg; 
		TranscodeLocal = pForRecTransCode->iMsgCode; 
		logDebug2(" TranscodeLocal Received on queue %d",TranscodeLocal);

		if(TranscodeLocal ==  TC_MCX_MBP_BCAST)
		{
			logDebug2("printing in IF");
			//			dTC_MBP_BCAST(RcvMsg,l_parameter);
			dTC_MBP_BCAST(RcvMsg);			
		}
		/*else if(TranscodeLocal == TC_MKT_STATS_RPT_BCAST)
		{
//			dTC_MKT_STATS_RPT_BCAST(RcvMsg);
		}*/
		else if(TranscodeLocal == TC_MCX_EXCH_MSGS)
                {
			logDebug2("printing Exchange messages");
                        dTC_MCX_EXCH_MSG(RcvMsg);
                }		
		else
		{
			logDebug2("Wrong Message Code :%d:",TranscodeLocal);
		}
	} 
} 






//BOOL dTC_MBP_BCAST(CHAR *NNFData,struct THREAD_PARAMS *l_parameter) 
BOOL dTC_MBP_BCAST(CHAR *NNFData)
{ 
	logTimestamp("ENTRY :dTC_MBP_BCAST:");
//	BOOL   	ReturnValue; 
	struct 	MCX_MBP_BCAST *pPacket = (struct MCX_MBP_BCAST *) NNFData; 
	//	NNF_MBP_BCAST
	BOOL    i,NoOfRecs; 
	//CHAR    supdate = malloc(sizeof(CHAR)*MAX_QUERY_SIZE);
	LONG32	iRowsAffcted = 0;
        DOUBLE64 fLowerCktlmt = 0.00 ;
        DOUBLE64 fupperCktlmt = 0.00 ;
        LONG32  iSecurityId=0;
	LONG32 	iTempScripCode=0 ;
	LONG32          iClosePrice  =0 ,iOpenPrice =0 ,iHighPrice =0 ,iLowPrice =0 ;
	//LONG32 iTempLtp=0;
	DOUBLE64 	fTempLtp = 0.00, fLtpRedis;	
	CHAR            sInsertQry [MAX_QUERY_SIZE];
	//CHAR    tempLastTradeTime[DATE_STRING_LENGTH]; 
	//CHAR    tempSecurityId[SECURITY_ID_LEN]; 

	//CHAR	*InsQuery= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	
	//CHAR	*ActUpQuery= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR	supdate[MAX_QUERY_SIZE];
	CHAR            sUpdQry[MAX_QUERY_SIZE];
	memset(&sUpdQry,'\0',MAX_QUERY_SIZE);	
	memset(&supdate,'\0',MAX_QUERY_SIZE);	
	memset(&sInsertQry ,'\0',MAX_QUERY_SIZE);

	// insert by @pratik
	CHAR sCommand[COMMAND_LEN],sCommand1[COMMAND_LEN];
        CHAR sKeyValue[RADIS_KEY_LEN];
        LONG32 iCount;
	
	NoOfRecs = pPacket->iNoofTrades; 

	logDebug2("Inside function UpdateMBPRes function, The Number Of Records are %d", NoOfRecs); 
	logDebug2("pPacket->iLastTradePrice fTempLtp :%d: ",pPacket->iLastTradePrice);
	iTempScripCode = pPacket->iInsIdentifier;
	fTempLtp = ((DOUBLE64)pPacket->iLastTradePrice)/MCX_CONST_PRICE_FACTOR;
	//iTempLtp = pPacket->iLastTradePrice/MCX_CONST_PRICE_FACTOR;
	iOpenPrice = pPacket->iOpenPrice/MCX_CONST_PRICE_FACTOR;
	iClosePrice = pPacket->iClosePrice/MCX_CONST_PRICE_FACTOR;
	iHighPrice = pPacket->sOpnIntrstDtls.iCurrntOpnIntst;// pPacket->iHighPrice/MCX_CONST_PRICE_FACTOR;
	iLowPrice = 0;//pPacket->iLowPrice;
	logDebug2("iTempScripCode :%d:",iTempScripCode);
	logDebug2("fTempLtp :%lf:",fTempLtp);
	logDebug2("iOpenPrice :%d:",iOpenPrice);
	logDebug2("iClosePrice:%d:",iClosePrice);
	logDebug2("iHighPrice :%d:",iHighPrice);
	logDebug2("iLowPrice :%d:",iLowPrice);

	logDebug2("Rohit Printing iExchTime :%d:",pPacket->sHeader.iExchTime);
	logDebug2("Rohit Printing iMsgCode:%d:",pPacket->sHeader.iMsgCode);
	logDebug2("Rohit Printing iMsgLegth:%d:",pPacket->sHeader.iMsgLegth);
	logDebug2("Rohit Printing cOpnPriceVol:%c:",pPacket->cOpnPriceVol);
	logDebug2("Rohit Printing iInsIdentifier:%d:",pPacket->iInsIdentifier);
	logDebug2("Rohit Printing cInxFlag :%c:",pPacket->cInxFlag);
	logDebug2("Rohit Printing iTotalTradeQty:%d:",pPacket->iTotalTradeQty);
	logDebug2("Rohit Printing iLastTradePrice:%d:",pPacket->iLastTradePrice/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing iLastTradeQty:%d:",pPacket->iLastTradeQty);
	logDebug2("Rohit Printing iLastTradeTime:%d:",pPacket->iLastTradeTime);
	logDebug2("Rohit Printing iAverageTradePrice:%d:",pPacket->iAverageTradePrice/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing fTotalBuyQty:%lf:",pPacket->fTotalBuyQty);
	logDebug2("Rohit Printing fTotalSellQty:%lf:",pPacket->fTotalSellQty);
	logDebug2("Rohit Printing iClosePrice:%d:",pPacket->iClosePrice/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing iOpenPrice:%d:",pPacket->iOpenPrice/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing iHighPrice:%d:",pPacket->iHighPrice);
	logDebug2("Rohit Printing iLowPrice:%d:",pPacket->iLowPrice/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing iCurrntOpnIntst :%d:",pPacket->sOpnIntrstDtls.iCurrntOpnIntst );
	logDebug2("Rohit Printing iNoofTrades:%d:",pPacket->iNoofTrades);
	logDebug2("Rohit Printing iHighestPriceEver:%d:",pPacket->iHighestPriceEver/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing iLowestPriceEver:%d:",pPacket->iLowestPriceEver/MCX_CONST_PRICE_FACTOR);
	logDebug2("Rohit Printing fTotalTradeValue:%lf:",pPacket->fTotalTradeValue);

	if(fTempLtp == 0 || fTempLtp == -20000000)/*In case of inactive script */
	{
		logInfo("fTempLtp :%lf:",fTempLtp);
		return FALSE;	
	}
/**	
	sprintf(sUpdQry,"UPDATE DRV_L1_WATCH SET\
			DL1_ENTRY_TIME= NOW() ,\
			DL1_EXCH_SCRIP_CODE = %d,\
			DL1_LTP = %lf,\
			DL1_OPEN = %d,\
			DL1_CLOSE= %d,\
			DL1_OI_HIGH= %d,\
			DL1_OI_LOW= %d\
			WHERE DL1_EXCHANGE =\"%s\" AND DL1_SEGMENT =\'%c\' AND DL1_EXCH_SCRIP_CODE = \'%d\';",iTempScripCode,\
			fTempLtp,iOpenPrice,\
			iClosePrice,iHighPrice,iLowPrice,\
			MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode);
***/

/*	sprintf(sUpdQry,"INSERT INTO DRV_L1_WATCH \
		(DL1_EXCHANGE ,\
		DL1_SEGMENT,\
		DL1_SCRIP_CODE,\
		DL1_EXCH_SCRIP_CODE,\
		DL1_MARKET_TYPE,\
		DL1_ENTRY_TIME,\
		DL1_LTP,\
		DL1_OI_HIGH ,\
		DL1_OI_LOW)\
		VALUES(\"%s\",\'%c\',%d,%d,\"%s\",NOW(),%lf,%d,%d)\
		on duplicate key \
		UPDATE \
		DL1_EXCHANGE = VALUES(DL1_EXCHANGE) ,\
		DL1_SEGMENT = VALUES(DL1_SEGMENT),\
		DL1_SCRIP_CODE = VALUES(DL1_SCRIP_CODE),\
		DL1_EXCH_SCRIP_CODE = VALUES(DL1_EXCH_SCRIP_CODE),\
		DL1_MARKET_TYPE = VALUES(DL1_MARKET_TYPE),\
		DL1_ENTRY_TIME = VALUES(DL1_ENTRY_TIME),\
		DL1_LTP = VALUES(DL1_LTP),\
		DL1_OI_HIGH = VALUES(DL1_OI_HIGH),\
		DL1_OI_LOW  = VALUES(DL1_OI_LOW);",MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode,iTempScripCode,MKT_TYPE_NL,fTempLtp,iHighPrice,iLowPrice);

	logDebug2("sUpdQry :%s:",sUpdQry);
	if(mysql_query(DNDB_Con,sUpdQry) != SUCCESS)
	{
        	logSqlFatal("ERROR IN UPDATING In Function fTC_MBP_BCAST ");
                sql_Error(DNDB_Con);
        }
        else
        {

                logDebug2("------SUCCESS IN UPDATE QUERY-----");
		iRowsAffcted = mysql_affected_rows(DNDB_Con);
                logDebug2("%d rows updated!!",iRowsAffcted); */
/***

		if(iRowsAffcted == 0)
		{
			sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
                        (DL1_ENTRY_TIME,DL1_SCRIP_CODE,DL1_EXCH_SCRIP_CODE ,DL1_LTP,DL1_OPEN ,DL1_CLOSE ,DL1_OI_HIGH,DL1_OI_LOW,DL1_EXCHANGE,DL1_SEGMENT,\
			DL1_MARKET_TYPE )\
			VALUES(now(),%d,%d,%lf,%d,%d,%d,%d,\"%s\",\'%c\','NL');",\
			iTempScripCode,iTempScripCode,\
                        fTempLtp,iOpenPrice,\
                        iClosePrice,iHighPrice,iLowPrice,\
                        MCX_EXCH,COMMODITY_SEGMENT);
			
			logDebug2("%s",sInsertQry);
                        if(mysql_query(DNDB_Con, sInsertQry) != SUCCESS)
                        {
                        	logSqlFatal("###### SQL Failed  ######");
	                        sql_Error(DNDB_Con);
        	                return FALSE;
                        }
                        else
                        {
                	        mysql_commit(DNDB_Con);
                        	logInfo(" Insert Sucess");
                        }

		}
		else
                {
  	              logDebug2("------SUCCESS UPDATE QUERY-----");
                }
	****/
       /* 	mysql_commit(DNDB_Con);
		iRowsAffcted = mysql_affected_rows(DNDB_Con);
                logDebug2("%d rows updated!!",iRowsAffcted);
        }        

        sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET L1_LTP = %lf WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE =%d ;",fTempLtp,MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode);

	logDebug1("supdate :%s:",supdate);

        if(mysql_query(DNDB_Con,supdate) != SUCCESS)
        {
        	logDebug2(" Update Query[%s]",supdate);
        	logSqlFatal("In Function [TC_MBP_BCAST]-->ERROR IN LTP UPDATE-->L1_WATCH_ACTIVE");
        	sql_Error(DNDB_Con);
        }
        else
        {
        	mysql_commit(DNDB_Con);
        	logDebug2("------SUCCESS IN LTP UPDATE-----");
        }
        
	fSendLTPtoRed(iTempScripCode,fTempLtp);*/

	
	sprintf(sKeyValue,"%s:%c:%d",MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode,TranscodeLocal);
        memset(sCommand,'\0',COMMAND_LEN);
        sprintf(sCommand,"HMGET %s LTP",sKeyValue);
       	logDebug2("KEY VALUE %s",sKeyValue);
       	reply = redisCommand(c,sCommand);
       	logDebug2("reply->len %d",reply->len);
        logDebug2("Received message LTP : %s",reply->element[0]->str);

        if(reply->element[0]->str != NULL)
        {
        	iCount = reply->elements;
                logDebug2("ELEMENT COUNT =%d ",iCount);
               	logDebug2("Received message LTP : %s",reply->element[0]->str);
                fLtpRedis = atof(reply->element[0]->str);
                freeReplyObject(reply);

                if(fLtpRedis == fTempLtp)
                {
                	logDebug2("No Need To Update LTP in DB");
                }else{
                	memset(sCommand,'\0',COMMAND_LEN);
                        sprintf(sCommand,"HMSET %s LTP %lf SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c DRVOILOW %d DRVOIHIGH %d ",sKeyValue,fTempLtp,iTempScripCode,MKT_TYPE_NL,MCX_EXCH,TranscodeLocal,COMMODITY_SEGMENT,iLowPrice,iHighPrice);
                        logDebug2("sCommand -> %s",sCommand);
                        reply = redisCommand(c,sCommand);
                        freeReplyObject(reply);
			
			sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                        logDebug2("sCommand1 -> %s",sCommand1);
                        reply = redisCommand(c,sCommand1);
                        freeReplyObject(reply);
			
                        memset(sCommand,'\0',COMMAND_LEN);
                      	sprintf(sCommand,"PUBLISH OMSMCXCOM %s",sKeyValue);
                        logDebug2("sCommand -> %s",sCommand);
                        reply = redisCommand(c,sCommand);
                        logDebug2("INCR counter: %lld", reply->integer);
                        freeReplyObject(reply);
              	}
	}else{
		memset(sCommand,'\0',COMMAND_LEN);
		sprintf(sCommand,"HMSET %s LTP %lf SCRIPT %d MKTTYPE %s EXCH %s MSGCODE %d SEGMENT %c DRVOILOW %d DRVOIHIGH %d ",sKeyValue,fTempLtp,iTempScripCode,MKT_TYPE_NL,MCX_EXCH,TranscodeLocal,COMMODITY_SEGMENT,iLowPrice,iHighPrice);
              	logDebug2("sCommand -> %s",sCommand);
                reply = redisCommand(c,sCommand);
                freeReplyObject(reply);

		sprintf(sCommand1,"EXPIRE %s %d",sKeyValue,iExpSec);
                logDebug2("sCommand1 -> %s",sCommand1);
                reply = redisCommand(c,sCommand1);
                freeReplyObject(reply);

                memset(sCommand,'\0',COMMAND_LEN);
                sprintf(sCommand,"PUBLISH OMSMCXCOM %s",sKeyValue);
                logDebug2("sCommand -> %s",sCommand);
                reply = redisCommand(c,sCommand);
                logDebug2("INCR counter: %lld", reply->integer);
	}
		
        
	
	logTimestamp("EXIT :dTC_MBP_BCAST:");
	return TRUE; 
} 

BOOL dTC_MCX_EXCH_MSG(CHAR *NNFData)
{
        logTimestamp("ENTRY :dTC_MCX_EXCH_MSG:");
        BOOL    ReturnValue;
        struct  MCX_EXCH_MSGS *pPacket = (struct MCX_MBP_BCAST *) NNFData;

        CHAR    sInsertQry[MAX_QUERY_SIZE];
	memset(sInsertQry,'\0',MAX_QUERY_SIZE);
	
	logDebug2("Rohit Printing iExchTime :%d:",pPacket->sHeader.iExchTime);
        logDebug2("Rohit Printing iMsgCode:%d:",pPacket->sHeader.iMsgCode);
        logDebug2("Rohit Printing iMsgLegth:%d:",pPacket->sHeader.iMsgLegth);
	logDebug2("Rohit Printing MsgLength :%d:",pPacket->iMsgLength);
        logDebug2("Rohit Printing message:%s:",pPacket->sMsg);

	sprintf(sInsertQry,"INSERT INTO EXCH_MESGS\
                        (EXMS_EXM_EXCH_ID,\
                         EXMS_EXM_SEGMENT,\
                         EXMS_TIME,\
                         EXMS_GENERAL_MESG)\
                         VALUES (\"%s\",\'%c\',\
                               now(),\"%s\");"\
                        ,MCX_EXCH,COMMODITY_SEGMENT, \
                        pPacket->sMsg);
	
	logDebug2("sInsertQry[%s]",sInsertQry);
        if (mysql_query(DNDB_Con,sInsertQry)!= SUCCESS)
        {
                logDebug2("ERROR IN INSERT QUERY");
                sql_Error(DNDB_Con);
                return FALSE;

        }
        else
	{
        	logDebug2("Insert Query Successfully Commited");
	}
        logTimestamp("EXIT [MCX_EXCH_MSG]");
	return TRUE;

}






dTC_MKT_STATS_RPT_BCAST(char *NNFData)
{
	DOUBLE64	TempOpnPrice;
	DOUBLE64	TempHighPrice;
	DOUBLE64	TempLowPrice;
	DOUBLE64	TempClosePrice;
	LONG32		TempTotqtyTraded;
	DOUBLE64	PreDyClosePrice;
	DOUBLE64	TempHighPriceevr;
	DOUBLE64	TempLowPriceevr;
	DOUBLE64	TempInstruIden;
	LONG32		TempTotTrades;
	DOUBLE64	TempCurrOpnIntrst;
	DOUBLE64	TempAvgTradePrice;
	DOUBLE64	TempSessionId;
	CHAR	TempInstruCode	[INSTRU_CODE_LEN];
	CHAR    sInsertQry[MAX_QUERY_SIZE];
	memset(sInsertQry,'\0',MAX_QUERY_SIZE);
//	CHAR  *sInsertQry = malloc(sizeof(CHAR)* MAX_QUERY_SIZE);
	CHAR    cLastUpdateDate[DATE_STRING_LENGTH];	

	logDebug2("Entry [Bhavcopy Report Nishant_1833]");
	struct MKT_CLOSE_STATISTICS *spMktStatus = (struct  MKT_CLOSE_STATISTICS *)NNFData;


	TempOpnPrice 	= 	((DOUBLE64)spMktStatus->iOpenPrice)/CONST_PRICE_FACTOR;
	TempHighPrice = 	((DOUBLE64)spMktStatus->iHighPrice)/CONST_PRICE_FACTOR;
	TempLowPrice =  	((DOUBLE64)spMktStatus->iLowPrice)/CONST_PRICE_FACTOR;
	TempClosePrice = 	((DOUBLE64)spMktStatus->iClosePrice)/CONST_PRICE_FACTOR;
	TempTotqtyTraded = spMktStatus->iTotalQtyTraded;
	PreDyClosePrice = 	((DOUBLE64)spMktStatus->iPreDayClosePrice)/CONST_PRICE_FACTOR;
	TempHighPriceevr = 	((DOUBLE64)spMktStatus->iHighestPriceEvr)/CONST_PRICE_FACTOR;
	TempLowPriceevr = 	((DOUBLE64)spMktStatus->iLowestPriceEvr)/CONST_PRICE_FACTOR;
	TempInstruIden = 	((DOUBLE64)spMktStatus->iInstruIdentifier)/CONST_PRICE_FACTOR;
	TempTotTrades =		spMktStatus->iTotalTrades;
	TempCurrOpnIntrst =	((DOUBLE64)spMktStatus->iCurrentOpnInterest)/CONST_PRICE_FACTOR;
	TempAvgTradePrice =	((DOUBLE64)spMktStatus->iAvgTradePrice)/CONST_PRICE_FACTOR;
	TempSessionId  = 	((DOUBLE64)spMktStatus->iSessionId)/CONST_PRICE_FACTOR; 
	strncpy(TempInstruCode,spMktStatus->sBcastInstruInfo.sIntruCode,INSTRU_CODE_LEN);
	convert_seconds_to_date(spMktStatus->sBcastInstruInfo.sExpiryDate,cLastUpdateDate);

	logDebug2("TempOpnPrice[%lf]",TempOpnPrice);
	logDebug2("TempHighPrice[%lf]",TempHighPrice);
	logDebug2("TempLowPrice[%lf]",TempLowPrice);
	logDebug2("TempClosePrice[%lf]",TempClosePrice);
	logDebug2("TempTotqtyTraded[%d]",TempTotqtyTraded);
	logDebug2("PreDyClosePrice[%lf]",PreDyClosePrice);
	logDebug2("TempHighPriceevr[%lf]",TempHighPriceevr);
	logDebug2("TempLowPriceevr[%lf]",TempLowPriceevr);
	logDebug2("TempInstruIden [%lf]",TempInstruIden);
	logDebug2("TempTotTrades[%d]",TempTotTrades);
	logDebug2("TempCurrOpnIntrst[%lf]",TempCurrOpnIntrst);
	logDebug2("TempAvgTradePrice[%lf]",TempAvgTradePrice);
	logDebug2("TempSessionId[%d]",TempSessionId);
	logDebug2("TempInstruCode[%s]",TempInstruCode);

	sprintf(sInsertQry,"INSERT INTO COM_BHAV_COPY \
			(CBC_EXCHANGE ,\
			 CBC_SEGMENT,\		
			 CBC_INSTRUMENT_CODE ,\
			 CBC_EXPIRY_DATE ,\
			 CBC_OPEN_PRICE ,\	
			 CBC_HIGH_PRICE ,\
			 CBC_LOW_PRICE ,\
			 CBC_CLOSE_PRICE ,\
			 CBC_TOTAL_QTY_TRADED,\
			 CBC_PREDAY_CLOSE_PRICE ,\
			 CBC_HIGHEST_PRICE_EVER ,\
			 CBC_LOWEST_PRICE_EVER ,\
			 CBC_INSTRU_IDENTIFIER ,\
			 CBC_TOTAL_TRADES ,\
			 CBC_CURRENT_OPEN_INTEREST ,\
			 CBC_AVG_TRADE_PRICE ,\
			 CBC_SESSION_ID )\
			VALUES (\"%s\",\'%c\',\
				\"%s\",STR_TO_DATE( \"%s\",'%%d%%m%%Y-%%h:%%i:%%s'),\
				%lf,%lf,\
				%lf,%lf,\
				%d,%lf,\
				%lf,%lf,\
				\"%s\",%d,\
				%lf,%lf,%d);"\
			,MCX_EXCH,COMMODITY_SEGMENT \
			,TempInstruCode,cLastUpdateDate \
			,TempOpnPrice,TempHighPrice \
			,TempLowPrice,TempClosePrice \
			,TempTotqtyTraded,PreDyClosePrice \
			,TempHighPriceevr,TempLowPriceevr \
			,TempInstruIden,TempTotTrades \
			,TempCurrOpnIntrst,TempAvgTradePrice,TempSessionId);


	logDebug2("sInsertQry[%s]",sInsertQry);
	if (mysql_query(DNDB_Con,sInsertQry)!= SUCCESS)
	{
		logDebug2("ERROR IN INSERT QUERY");
		sql_Error(DNDB_Con);
		return FALSE;

	}
	//if (mysql_commit()!=0);
	//	logFatal("Failed to commit");
	else
	{
		logDebug2("Insert Query Successfully Commited");
	}
	return TRUE;
	logTimestamp("EXIT [[Bhavcopy Report Nishant_1833]");

}


BOOL GetStartupTimeofDay()
{
	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
	gettimeofday(&StartPoint1, &tzp);

	iStartupTime = StartPoint1.tv_sec - OFFSET;
	logDebug2("Time of entry is :%d: iStartupTime:%d:",StartPoint1.tv_sec,iStartupTime);

}

BOOL fSendLTPtoRed(LONG32 iToken , DOUBLE64 fLTP)
{

        logTimestamp("ENTRY [fSendLTPtoRed]");
        struct          COMM_REDIS_LTP_UPD pRedLTP;
        logDebug2("This is 1 ");

        memset(&pRedLTP,'\0',sizeof(struct COMM_REDIS_LTP_UPD ));
        logDebug2("This is 2 :%d: :%lf:",iToken,fLTP);

        pRedLTP.iToken = iToken;
        logDebug2("This is 3 ");
        pRedLTP.fLtp = fLTP;
        logDebug2("This is 4 ");
        logDebug2("iToken :%d: fLtp :%lf: ",pRedLTP.iToken,pRedLTP.fLtp);
        logDebug2("This is 5 ");

        if((WriteMsgQ(iSendQ,(CHAR *)&pRedLTP, sizeof(struct COMM_REDIS_LTP_UPD), 1)) != TRUE  )
        {
                logFatal("Error : failed while sending to Queue ENMbpToLTPUpd");
                //exit(ERROR);
        }
        logDebug2("This is 1 ");


        logTimestamp("EXIT [fSendLTPtoRed]");

}

