#include "IPCS.h"
#include "hiredis.h"
#include <mysql.h>

//redisContext *c;
redisContext *RdConn;

MYSQL   *DNMbp_con;
LONG32  iSleepTime;
main(int argc,char **argv)
{
        setbuf(stdout,0);
        logTimestamp("ENTRY [Main]");
//	c = RDConnect();
        RdConn = RDConnect();
        DNMbp_con=DB_Connect();
	iSleepTime = atoi(argv[2]);
        if ( argc != 3 )
        {
                logDebug2("Argument Mismstch ");
                logDebug2("USAGE : NseFOSMemMbpUpd iSubInstance iSleepTime NseFOSMemMbpUpd ");
                iSleepTime = 3 ;
        }

	if(iSleepTime <= 0)
	{
		iSleepTime = 3 ;
	}		

        ReceiveReplyPacketsBcast();
        return 0;
	logTimestamp("EXIT [MAin]");
}

void ReceiveReplyPacketsBcast()//, CHAR *bcastaddress , LONG32 portno,CHAR *mcastaddress , LONG32 mportno)
{
        logTimestamp("ENTRY [UPDATE LTP IN DB]");
        CHAR sSMemCommd[COMMAND_LEN],sHgetComm[COMMAND_LEN],sRSRem[COMMAND_LEN] ;
        BOOL flag;
        LONG32 iNoRecord=0,i = 0;
        int iCount ;
        CHAR sKeyValue[RADIS_KEY_LEN];
        DOUBLE64   fTempLtp=0.00;
	LONG32	TempDayHiOpenInt,TempDayLowOpenInt;
        LONG32          iTempScripCode =0 ,iMsgCode;
	LONG32	iBcastMonCountr = 0;
        CHAR    NormlMkt [MKT_TYPE_LEN];
        CHAR    sExch [10];
        CHAR    cSegment;
        CHAR    sInsertQry[MAX_QUERY_SIZE];  //malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        CHAR    sUpdateQry[MAX_QUERY_SIZE];
        CHAR    supdate [MAX_QUERY_SIZE];
        CHAR    sBroadcastMon[COMMAND_LEN];
	LONG32  iRowsAffcted = 0;
	redisReply *reply;
	redisReply *reply1;
	redisReply *reply2;
	redisReply *repRem;
/***
        sprintf(sSMemCommd,"SUBSCRIBE OMSMCXCOM");
        logDebug2("sSMemCommd -> %s",sSMemCommd);
        reply = redisCommand(c,sSMemCommd);
        logDebug2("INCR counter: %lld", reply->integer);
        while(redisGetReply(c,(void**)&reply) == REDIS_OK)
****/
        while(TRUE)
        {
		logTimestamp("Recive SMembers Key");
                memset(&sInsertQry,'\0',MAX_QUERY_SIZE);
                memset(&supdate,'\0',MAX_QUERY_SIZE);
                memset(&sUpdateQry,'\0',MAX_QUERY_SIZE);
		iNoRecord = 0;
/***
                if (reply->type != REDIS_REPLY_ARRAY || reply->elements != 3)
                {
                        logDebug2(stderr, "Error:  Malformed subscribe response!");
                        exit(-1);
                }

                logDebug2("Channel: %s", reply->element[1]->str);
                logDebug2("Received message: %s", reply->element[2]->str);
                sprintf(sKeyValue,"%s",reply->element[2]->str);
                freeReplyObject(reply);
*****/		
		memset(sSMemCommd,'\0',COMMAND_LEN);
                //sprintf(sHgetComm,"TTL %s",sKeyValue);
                sprintf(sSMemCommd,"SMEMBERS MCX:M:BCAST");
                //logDebug2("sSMemCommd -> %s",sSMemCommd);
                reply = redisCommand(RdConn,sSMemCommd);
                //logDebug2("INCR counter: %d", reply->elements);
		iNoRecord = reply->elements;	
		//if(reply->integer != 0 && reply->integer != -2)
		for(i = 0 ; i < iNoRecord ;i++)
                {
                	memset(sSMemCommd,'\0',COMMAND_LEN);
	                sprintf(sSMemCommd,"HMGET %s LTP SCRIPT MKTTYPE EXCH MSGCODE SEGMENT DRVOILOW DRVOIHIGH ",reply->element[i]->str);
	                logDebug2("sSMemCommd -> %s",sSMemCommd);
	                reply1 = redisCommand(RdConn,sSMemCommd);
	                iCount = reply1->elements;
	                logDebug2("ELEMENT COUNT =%d ",iCount);
	                logDebug2("Received message LTP : %s", reply1->element[0]->str);
	                logDebug2("Received message SCRIPT : %s", reply1->element[1]->str);
	                logDebug2("Received message MKTTYPE: %s", reply1->element[2]->str);
	                logDebug2("Received message EXCH: %s", reply1->element[3]->str);
	                logDebug2("Received message MSGCODE: %s", reply1->element[4]->str);
	                logDebug2("Received message SEGMENT: %s", reply1->element[5]->str);
	                fTempLtp = atof(reply1->element[0]->str);
	                iTempScripCode = atoi(reply1->element[1]->str);
	                iMsgCode = atoi(reply1->element[4]->str);
	                sprintf(NormlMkt,"%s",reply1->element[2]->str);
			logDebug2("Received message OILOW: %s", reply1->element[6]->str);
	                logDebug2("Received message OIHIGH: %s", reply1->element[7]->str);
	                TempDayHiOpenInt = atoi(reply1->element[7]->str);
	                TempDayLowOpenInt = atoi(reply1->element[6]->str);
			
		
			sprintf(sInsertQry,"INSERT INTO DRV_L1_WATCH \
		                (DL1_EXCHANGE ,\
	        	        DL1_SEGMENT,\
		                DL1_SCRIP_CODE,\
		                DL1_EXCH_SCRIP_CODE,\
		                DL1_MARKET_TYPE,\
		                DL1_ENTRY_TIME,\
		                DL1_LTP,\
				DL1_OPEN_INTEREST,\
		                DL1_OI_HIGH ,\
		                DL1_OI_LOW)\
		                VALUES(\"%s\",\'%c\',\"%d\",%d,\"%s\",NOW(),%lf,%d,%d,%d)\
		                on duplicate key \
		                UPDATE \
		                DL1_EXCHANGE = VALUES(DL1_EXCHANGE) ,\
		                DL1_SEGMENT = VALUES(DL1_SEGMENT),\
		                DL1_SCRIP_CODE = VALUES(DL1_SCRIP_CODE),\
	        	        DL1_EXCH_SCRIP_CODE = VALUES(DL1_EXCH_SCRIP_CODE),\
		                DL1_MARKET_TYPE = VALUES(DL1_MARKET_TYPE),\
		                DL1_ENTRY_TIME = VALUES(DL1_ENTRY_TIME),\
		                DL1_LTP = VALUES(DL1_LTP),\
				DL1_OPEN_INTEREST = VALUES(DL1_OPEN_INTEREST),\
		                DL1_OI_HIGH = VALUES(DL1_OI_HIGH),\
		                DL1_OI_LOW  = VALUES(DL1_OI_LOW);",MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode,iTempScripCode,MKT_TYPE_NL,fTempLtp,TempDayHiOpenInt,TempDayHiOpenInt,TempDayLowOpenInt);
	
		        logDebug2("sInsertQry:%s:",sInsertQry);
	        	if(mysql_query(DNMbp_con,sInsertQry) != SUCCESS)
	        	{
	                	logSqlFatal("ERROR IN UPDATING In Function fTC_MBP_BCAST ");
	                	sql_Error(DNMbp_con);
	        	}
	        	else
		        {
	
		                logDebug2("------SUCCESS IN UPDATE QUERY-----");
		                iRowsAffcted = mysql_affected_rows(DNMbp_con);
		                logDebug2("%d rows updated!!",iRowsAffcted);
				mysql_commit(DNMbp_con);
		                iRowsAffcted = mysql_affected_rows(DNMbp_con);
		                logDebug2("%d rows updated!!",iRowsAffcted);
				iBcastMonCountr ++;
                        	logDebug3("iBcastMonCountr :%d:",iBcastMonCountr);
                        	memset(sBroadcastMon,'\0',COMMAND_LEN);
                        	sprintf(sBroadcastMon,"HMSET BCAST:MON MCX:M:COUNT %d ",iBcastMonCountr);
                        	logTimestamp("sSMemCommd -> %s",sBroadcastMon);
                        	reply2 = redisCommand(RdConn,sBroadcastMon);
                        	freeReplyObject(reply2);
		        }
	
		        sprintf(supdate,"UPDATE L1_WATCH_ACTIVE SET L1_LTP = %lf ,L1_LUT = NOW() WHERE L1_EXCHANGE = \'%s\' AND L1_SEGMENT = \'%c\' AND L1_SCRIP_CODE = \"%d\" ;",fTempLtp,MCX_EXCH,COMMODITY_SEGMENT,iTempScripCode);

		        logDebug1("supdate :%s:",supdate);

		        if(mysql_query(DNMbp_con,supdate) != SUCCESS)
		        {
		                logDebug2(" Update Query[%s]",supdate);
		                logSqlFatal("In Function [TC_MBP_BCAST]-->ERROR IN LTP UPDATE-->L1_WATCH_ACTIVE");
		                sql_Error(DNMbp_con);
		        }
		        else
		        {
		                mysql_commit(DNMbp_con);
		                logDebug2("------SUCCESS IN LTP UPDATE-----");
	        	}
			freeReplyObject(reply1);
			memset(&sRSRem,'\0',COMMAND_LEN);
			sprintf(sRSRem,"SREM MCX:M:BCAST  %s",reply->element[i]->str);

			logDebug2("sRSRem :%s:",sRSRem);
			repRem = redisCommand(RdConn,sRSRem);

			if(repRem->type == REDIS_REPLY_INTEGER)
			{
				logInfo("Remove Success");
				logDebug2("STATUS ->  %d",reply->integer);
			}
                        else
                        {
                        	logFatal("Error in adding values to CLIENT HASH. :%s:",repRem->str);
                        }


                        freeReplyObject(repRem);

		}
                freeReplyObject(reply);
		sleep(iSleepTime);
		logTimestamp("#####EXIT####");


        }
        logTimestamp("EXIT [UPDATE LTP IN DB]");

}

