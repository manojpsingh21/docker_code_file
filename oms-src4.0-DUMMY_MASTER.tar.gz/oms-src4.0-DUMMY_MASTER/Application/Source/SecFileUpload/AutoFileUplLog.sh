LOGDIR="../Log"
export LOGDIR;

#StartAutoSystem=`AutoFileUplaoad.sh`
#echo $StartAutoSystem>>$LOGDIR/log.AutoFileUplaoad
#echo $StartAutoSystem 
if test "$1 " = " "; then
        AutoFileUpload.sh >> $LOGDIR/log.AutoFileUpload 2>&1&
fi;
echo "done" 
