append=`date "+%Y-%m-%d_%H:%M"`
append1=`date "+%Y%m%d"`
if [ $# -ne 7 ];then
        echo "Invalid Argument"
        exit
fi;
FileType=$1
BucketName=$2
FileName=$3
AwsPath=$4
req_id=$5
call_url=$6
operation=$7
ShellPath="$HOME/Application/Exec/SecFileUpload"
UploadPath="$HOME/UPLOADS"
echo "=========== START UPLOAD [$append] ===========" >>$UploadPath/LOGS/log.AwsFile
echo  "FileType:$1 BucketName:$2 FileName:$3 AwsPath:$4 req_id:$5 call_url:$6 operation:$7" >>$UploadPath/LOGS/log.AwsFile
if [ $FileType == "dpholding" ];then
        echo "-------------------------------DPHOLDING FILE---------------------------------" >>$UploadPath/LOGS/log.AwsFile
        cd $ShellPath/HLD_UPLOAD
	if [ "$operation" == "D" ];then
		rm -f $UploadPath/DP/*
        	test=`aws s3 cp s3://$BucketName/$AwsPath/$FileName $UploadPath/DP >>$UploadPath/LOGS/log.AwsFile`
                f_cnt=`ls $UploadPath/DP/ -1 | wc -l`
		if [ $f_cnt -gt 0 ];then	
			echo "$FileName File Download success"
                	echo "$FileName File Download success" >>$UploadPath/LOGS/log.AwsFile
		else
			echo "$FileName File Download fail"
                        echo "$FileName File Download fail" >>$UploadPath/LOGS/log.AwsFile
        	fi;
	elif [ "$operation" == "U" ];then
        	test=`./UploadDP.sh`
        	status=`echo $?`
        	if test "$status" != "0";then
                	echo "Upload Fail !"
                	echo "Upload Fail !" >>$UploadPath/LOGS/log.AwsFile
        	else
                	echo $test
                	echo $test >>$UploadPath/LOGS/log.AwsFile
			succ_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/DP_$append1* | cut -d\| -f2`
			fail_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/DP_$append1* | cut -d\| -f3`
			echo SUCCESS-$succ_cnt REJECTED-$fail_cnt >>$UploadPath/LOGS/log.AwsFile
                        echo "curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"$req_id","success_count":"$succ_cnt","rejected_count":"$fail_cnt","file_name":"$FileName" }'" >>$UploadPath/LOGS/log.AwsFile
                        crl=`curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"'"$req_id"'","success_count":"'"$succ_cnt"'","rejected_count":"'"$fail_cnt"'","file_name":"'"$FileName"'" }' >>$UploadPath/LOGS/log.AwsFile`
        	fi;
	else
		echo "Invalid Operation"
		echo "Invalid Operation" >>$UploadPath/LOGS/log.AwsFile
	fi;
elif [ $FileType == "limit" ];then
        echo "-------------------------------LIMIT FILE---------------------------------" >>$UploadPath/LOGS/log.AwsFile
        cd $ShellPath/LIMIT_UPLOAD
        if [ "$operation" == "D" ];then
                rm -f $UploadPath/LIMIT/CAPITAL/CAP_LMT/*
		test=`aws s3 cp s3://$BucketName/$AwsPath/$FileName $UploadPath/LIMIT/CAPITAL/CAP_LMT >>$UploadPath/LOGS/log.AwsFile`
		f_cnt=`ls $UploadPath/LIMIT/CAPITAL/CAP_LMT/ -1 | wc -l`
                if [ $f_cnt -gt 0 ];then
                        echo "$FileName File Download success"
                        echo "$FileName File Download success" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo "$FileName File Download fail"
                        echo "$FileName File Download fail" >>$UploadPath/LOGS/log.AwsFile
                fi;
        elif [ "$operation" == "U" ];then
                test=`./UploadCapLmt.sh`
                status=`echo $?`
                if test "$status" != "0";then
                        echo "Upload Fail !"
                        echo "Upload Fail !" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo $test
                        echo $test >>$UploadPath/LOGS/log.AwsFile
			succ_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/CAPLMT_$append1* | cut -d\| -f2`
			fail_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/CAPLMT_$append1* | cut -d\| -f3`
                        echo SUCCESS-$succ_cnt REJECTED-$fail_cnt >>$UploadPath/LOGS/log.AwsFile
                        echo "curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"$req_id","success_count":"$succ_cnt","rejected_count":"$fail_cnt","file_name":"$FileName" }'" >>$UploadPath/LOGS/log.AwsFile
                        crl=`curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"'"$req_id"'","success_count":"'"$succ_cnt"'","rejected_count":"'"$fail_cnt"'","file_name":"'"$FileName"'" }' >>$UploadPath/LOGS/log.AwsFile`
                fi;
        else
                echo "Invalid Operation"
                echo "Invalid Operation" >>$UploadPath/LOGS/log.AwsFile
        fi;
elif [ $FileType == "obbholding" ];then
        echo "-------------------------------OBB HOLDING FILE---------------------------------" >>$UploadPath/LOGS/log.AwsFile
        cd $ShellPath/HLD_UPLOAD
	if [ "$operation" == "D" ];then
                rm -f $UploadPath/OBB/*
        	test=`aws s3 cp s3://$BucketName/$AwsPath/$FileName $UploadPath/OBB >>$UploadPath/LOGS/log.AwsFile`
		f_cnt=`ls $UploadPath/OBB/ -1 | wc -l`
                if [ $f_cnt -gt 0 ];then
                        echo "$FileName File Download success"
                        echo "$FileName File Download success" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo "$FileName File Download fail"
                        echo "$FileName File Download fail" >>$UploadPath/LOGS/log.AwsFile
                fi;
        elif [ "$operation" == "U" ];then
                test=`./UploadOBB.sh`
                status=`echo $?`
                if test "$status" != "0";then
                        echo "Upload Fail !"
                        echo "Upload Fail !" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo $test
                        echo $test >>$UploadPath/LOGS/log.AwsFile
			succ_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/OBB_$append1* | cut -d\| -f2`
			fail_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/OBB_$append1* | cut -d\| -f3`
                        echo SUCCESS-$succ_cnt REJECTED-$fail_cnt >>$UploadPath/LOGS/log.AwsFile
                        echo "curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"$req_id","success_count":"$succ_cnt","rejected_count":"$fail_cnt","file_name":"$FileName" }'" >>$UploadPath/LOGS/log.AwsFile
                        crl=`curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"'"$req_id"'","success_count":"'"$succ_cnt"'","rejected_count":"'"$fail_cnt"'","file_name":"'"$FileName"'" }' >>$UploadPath/LOGS/log.AwsFile`
                fi;
        else
                echo "Invalid Operation"
                echo "Invalid Operation" >>$UploadPath/LOGS/log.AwsFile
        fi;
elif [ $FileType == "benholding" ];then
        echo "-------------------------------BEN HOLDING FILE---------------------------------" >>$UploadPath/LOGS/log.AwsFile
        cd $ShellPath/HLD_UPLOAD
	if [ "$operation" == "D" ];then
                rm -f $UploadPath/BEN/*
        	test=`aws s3 cp s3://$BucketName/$AwsPath/$FileName $UploadPath/BEN >>$UploadPath/LOGS/log.AwsFile`
		f_cnt=`ls $UploadPath/BEN/ -1 | wc -l`
                if [ $f_cnt -gt 0 ];then
                        echo "$FileName File Download success"
                        echo "$FileName File Download success" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo "$FileName File Download fail"
                        echo "$FileName File Download fail" >>$UploadPath/LOGS/log.AwsFile
                fi;
        elif [ "$operation" == "U" ];then
                test=`./UploadBEN.sh`
                status=`echo $?`
                if test "$status" != "0";then
                        echo "Upload Fail !"
                        echo "Upload Fail !" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo $test
                        echo $test >>$UploadPath/LOGS/log.AwsFile
			succ_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/BEN_$append1* | cut -d\| -f2`
			fail_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/BEN_$append1* | cut -d\| -f3`
                        echo SUCCESS-$succ_cnt REJECTED-$fail_cnt >>$UploadPath/LOGS/log.AwsFile
                        echo "curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"$req_id","success_count":"$succ_cnt","rejected_count":"$fail_cnt","file_name":"$FileName" }'" >>$UploadPath/LOGS/log.AwsFile
                        crl=`curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"'"$req_id"'","success_count":"'"$succ_cnt"'","rejected_count":"'"$fail_cnt"'","file_name":"'"$FileName"'" }' >>$UploadPath/LOGS/log.AwsFile`
                fi;
        else
                echo "Invalid Operation"
                echo "Invalid Operation" >>$UploadPath/LOGS/log.AwsFile
        fi;
elif [ $FileType == "costprice" ];then
        echo "-------------------------------COST PRICE FILE---------------------------------" >>$UploadPath/LOGS/log.AwsFile
        cd $ShellPath/HLD_UPLOAD
        if [ "$operation" == "D" ];then
                rm -f $UploadPath/COST_PRICE/*
                test=`aws s3 cp s3://$BucketName/$AwsPath/$FileName $UploadPath/COST_PRICE >>$UploadPath/LOGS/log.AwsFile`
                f_cnt=`ls $UploadPath/COST_PRICE/ -1 | wc -l`
                if [ $f_cnt -gt 0 ];then
                        echo "$FileName File Download success"
                        echo "$FileName File Download success" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo "$FileName File Download fail"
                        echo "$FileName File Download fail" >>$UploadPath/LOGS/log.AwsFile
                fi;
        elif [ "$operation" == "U" ];then
                test=`./UploadCost.sh`
                status=`echo $?`
                if test "$status" != "0";then
                        echo "Upload Fail !"
                        echo "Upload Fail !" >>$UploadPath/LOGS/log.AwsFile
                else
                        echo $test
                        echo $test >>$UploadPath/LOGS/log.AwsFile
			succ_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/COST_$append1* | cut -d\| -f2`
			fail_cnt=`sed -n 2p $ShellPath/PROCESS_LOG/COST_$append1* | cut -d\| -f3`
                        echo SUCCESS-$succ_cnt REJECTED-$fail_cnt >>$UploadPath/LOGS/log.AwsFile
                        echo "curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"$req_id","success_count":"$succ_cnt","rejected_count":"$fail_cnt","file_name":"$FileName" }'" >>$UploadPath/LOGS/log.AwsFile
                        crl=`curl -X POST  $call_url  -H 'Content-Type: application/json'   -d '{  "request_id":"'"$req_id"'","success_count":"'"$succ_cnt"'","rejected_count":"'"$fail_cnt"'","file_name":"'"$FileName"'" }' >>$UploadPath/LOGS/log.AwsFile`
                fi;
        else
                echo "Invalid Operation"
                echo "Invalid Operation" >>$UploadPath/LOGS/log.AwsFile
        fi;
else
        echo "No Such File Support $FileName"
fi;
echo "=========== END UPLOAD [$append] ===========" >>$UploadPath/LOGS/log.AwsFile
