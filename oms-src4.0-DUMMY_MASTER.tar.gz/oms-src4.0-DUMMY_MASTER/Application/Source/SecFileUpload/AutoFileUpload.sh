cd $UPLOAD_DIR/CLIENT_UPLOAD/
AllBatchUpldCli.sh
sleep 10
cd $UPLOAD_DIR
NseEqScrStatus=`SCRIPT_UPLOAD/UploadNSEEQ.sh`
if test "$NseEqScrStatus" = "SUCCESS";then
	echo "start to upload Bhav Copy FIle For EQ Segment"
	NseEqBcStatus=`BC_UPLOAD/UploadNseEqBC.sh`
	echo $NseEqBcStatus
	if test "$NseEqBcStatus" != "SUCCESS";then
		echo "exit through BHAV COPY(EQ)"
		#exit
	fi;
	cd $UPLOAD_DIR/HLD_UPLOAD/
	AllBatchUpldHLD.sh
else
	echo "exit [NSE EQ Security File]"
	#exit
fi;

cd $UPLOAD_DIR
NseFOScrStatus=`SCRIPT_UPLOAD/UploadNSEDrv.sh` 
if test "$NseFOScrStatus" = "SUCCESS";then
	echo "start to Upload BHAV COPY File for FO Segment"
	NseFOBcStatus=`BC_UPLOAD/UploadNseDrvBC.sh`
	echo $NseFOBcStatus
	if test "$NseFOBcStatus" != "SUCCESS";then
		echo "exit through BHAV COPY(FO)"
	#	exit
	fi;
	cd $UPLOAD_DIR/POSITION_UPLOAD/
	UploadPS03.sh
else
	echo "exit [NSE FO Security File]"
	#exit
fi;

cd $UPLOAD_DIR
NseCDScrStatus=`SCRIPT_UPLOAD/UploadNSECur.sh` 
if test "$NseCDScrStatus" = "SUCCESS";then
	echo "start to Upload BHAV COPY File For CD segment"
	NseCDBcStatus=`BC_UPLOAD/UploadNseCDBC.sh`
	echo $NseCDBcStatus
	if test "$NseCDBcStatus" != "SUCCESS";then
		echo "exit through BHAV COPY(CD)"
	#	exit
	fi;
	cd $UPLOAD_DIR/POSITION_UPLOAD/
	UploadCPS03.sh
else
	echo "exit [NSE CD Security File]"
	#exit
fi;

#if ["$NseEqScrStatus" = "SUCCESS"] && ["$NseFOScrStatus" = "SUCCESS"] && ["$NseCDScrStatus" = "SUCCESS"]; then
#	echo "Start to upload Position file"
	#PosUpldStatus=`POSITION_UPLOAD/AllBatchUpldPos.sh`
#	cd $UPLOAD_DIR/POSITION_UPLOAD/
#	AllBatchUpldPos.sh
	#sleep 10
	#cd $UPLOAD_DIR/HLD_UPLOAD/
	#AllBatchUpldHLD.sh
#fi;
	
cd $UPLOAD_DIR/VAR_UPLOAD/
AllBatchUpldVar.sh
sleep 10
cd $UPLOAD_DIR/EXPO_UPLOAD/
UploadExpoMar.sh
sleep 10
cd $UPLOAD_DIR/SPAN_UPLOAD/
UploadSpan.sh
sleep 10
cd $UPLOAD_DIR/SPAN_UPLOAD/
UploadCurSpan.sh
#sleep 10
#cd $UPLOAD_DIR/POSITION_UPLOAD/
#AllBatchUpldPos.sh
#sleep 10
#cd $UPLOAD_DIR/HLD_UPLOAD/
#AllBatchUpldHLD.sh
sleep 10
cd $UPLOAD_DIR/ELM/
UploadELM.sh

