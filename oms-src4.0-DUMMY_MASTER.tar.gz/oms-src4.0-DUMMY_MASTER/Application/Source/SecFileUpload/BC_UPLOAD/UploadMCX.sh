append=`date "+%Y%m%d_%H%M"`
f_cnt=`ls $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/ -1 | wc -l`
if [ $f_cnt -gt 1 ];then
        f_letest=`ls $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/ -t1 |  head -n 1`
        mv $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/$f_letest $HOME/UPLOADS/BHAVCOPY/MCX/
        rm -f $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/*
        mv $HOME/UPLOADS/BHAVCOPY/MCX/$f_letest $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/
fi;

mv $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/*.csv $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/mcx_bc.csv
stats=`echo $?`
#if test "$stats" != "0"; then
if [ ! -f "$HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/mcx_bc.csv" ]; then
        echo "File Already Exist...Kindly Tranfer Again And Upload Manually "
        rm -f $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/*
	exit
else
	export CLASSPATH=$CLASSPATH:$UPLOAD_DIR/lib/sqlserverjdbc.jar:$UPLOAD_DIR/lib/mysql-connector-java-5.1.36-bin.jar;
	cd $UPLOAD_DIR/BC_UPLOAD/
	$JAVA_PATH/javac Upload_COM_BC.java Unscramble.java
	Output="`$JAVA_PATH/java Upload_COM_BC ../config.txt`"
	if test "$Output" = "SUCCESS";then
                mv $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/mcx_bc.csv  $HOME/UPLOADS/ACC/BHAVCOPY/MCX/COMMODITY/mcx_bc.csv_$append
        else
                mv $HOME/UPLOADS/BHAVCOPY/MCX/COMMODITY/mcx_bc.csv  $HOME/UPLOADS/NACC/BHAVCOPY/MCX/COMMODITY/mcx_bc.csv_$append
        fi;
	echo $Output
fi;
