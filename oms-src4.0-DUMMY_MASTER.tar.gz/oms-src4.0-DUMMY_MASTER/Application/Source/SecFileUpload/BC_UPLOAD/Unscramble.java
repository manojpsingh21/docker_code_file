import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;
import java.io.PrintWriter;

public class Unscramble
{	
	public static void main(String args[])
	{
	//	Scanner sc = new Scanner(System.in);
	//	String b = sc.next();

//		Unscramble obj = new Unscramble(args[0]);
		Unscramble ob = new Unscramble();
		ob.Unscram(args[0]);
	}
	public String Unscram(String a)
	{
		int i;
		int min =40,max=125;
		int Val;

		char[] c = a.toCharArray();

//		LogPrint("a-----> "+a+"  "+a.length());

                for(i = (a.length()) - 1; i >= 0; i--)
                {
//			LogPrint("a-----> "+a);
			Val = (int)c[i]; 		
			//if((c[i] - i) < min)
//			LogPrint("Val "+Val+"  c "+c[i]+"  i "+i);	
			if((Val - i) < min)
                        {

				Val = max - (min - (Val - i));
				c[i] = (char) Val;

			}
                        else
                        {
                               Val  = Val - i;
				c[i] = (char) Val;
                        }

//			LogPrint("asdadsasd :"+c[i]);

                }

//		LogPrint("FInal OP");
/*		for(i = 0 ;i<a.length();i++)
		{
			LogPrint(c[i]);

		}
*/
		//LogPrint();
//		LogPrint("DOne");

	/*	for(i= 0; i<c.length; i++)
		{
			String str = c.toString().join("", c[i]);
			System.out.print(str);	
		}
*/
		String ab = String.valueOf(c);
//		LogPrint(ab);
		return ab;

	}

}
