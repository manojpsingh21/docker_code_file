append=`date "+%Y%m%d_%H%M"`
f_cnt=`ls $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/ -1 | wc -l`
if [ $f_cnt -gt 1 ];then
        f_letest=`ls $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/ -t1 |  head -n 1`
        mv $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/$f_letest $HOME/UPLOADS/BHAVCOPY/BSE/
        rm -f $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/*
        mv $HOME/UPLOADS/BHAVCOPY/BSE/$f_letest $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/
fi;

mv $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/*  $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/bse_eq_bc.csv
stats=`echo $?`
#if test "$stats" != "0"; then
if [ ! -f "$HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/bse_eq_bc.csv" ]; then
        echo "File Does Not  Exist...Kindly Tranfer Again And Upload Manually "
        rm -f $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/*
	exit
else
	export CLASSPATH=$CLASSPATH:$UPLOAD_DIR/lib/sqlserverjdbc.jar:$UPLOAD_DIR/lib/mysql-connector-java-5.1.36-bin.jar;
	cd $UPLOAD_DIR/BC_UPLOAD/
	rm -fr Upload_BSE_EQ_BC.class
	$JAVA_PATH/javac Upload_BSE_EQ_BC.java Unscramble.java
	Output="`$JAVA_PATH/java Upload_BSE_EQ_BC ../config.txt`"
	if test "$Output" = "SUCCESS";then
                mv $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/bse_eq_bc.csv  $HOME/UPLOADS/ACC/BHAVCOPY/BSE/EQUITY/bse_eq_bc.csv_$append
        else
                mv $HOME/UPLOADS/BHAVCOPY/BSE/EQUITY/bse_eq_bc.csv  $HOME/UPLOADS/NACC/BHAVCOPY/BSE/EQUITY/bse_eq_bc.csv_$append
        fi;
	echo $Output
fi;
