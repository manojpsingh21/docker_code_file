#!/bin/ksh
esc=""
RED="${esc}[31m";
GREEN="${esc}[32m";
YELLOW="${esc}[33m"
BLUE="${esc}[34m"
NORMAL="${esc}[0m";
HEADING="${esc}[1;37;44m"
BOLD="${esc}[1m"
UNDERLINE="${esc}[4m"
WHITE='\e[0;37m';

s=`tput smso`
b=`tput bold`
p=`tput rmso`
bold='tput smso'
offbold='tput rmso'
NseEqStatus='--------'
NseFOStatus='--------'
NseCDStatus='--------'
BseEqStatus='--------'
MCXStatus='--------'
ALLStatus='--------'
NseEqLastUpdDate=''
NseFOLastUpdDate=''
NseCDLastUpdDate=''
BseEqLastUpdDate=''
MCXLastUpdDate=''
clear
while true
do
	NseEqLastUpdDate=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_DATE from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYNEQ'" )
        NseFOLastUpdDate=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se"select PROCESS_DATE from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYNFO'" )
        NseCDLastUpdDate=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se"select PROCESS_DATE from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYNCUR'" )
        BseEqLastUpdDate=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se"select PROCESS_DATE from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYBEQ'" )
        MCXLastUpdDate=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_DATE from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYMCOM'" )
        NseEqStatus=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_STATUS from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYNEQ'" )
        NseFOStatus=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_STATUS from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYNFO'" )
        NseCDStatus=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_STATUS from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYNCUR'" )
        BseEqStatus=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_STATUS from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYBEQ'" )
        MCXStatus=$( mysql -D$SCHEMA -h$MYSQL_HOST -u$MYSQL_USER -p$PASS -se "select PROCESS_STATUS from RMS_PROCESS_LOG s where s.PROCESS = 'BCOPYMCOM'" )
	clear
	print "\n"
       	print "\n"
	echo -e $GREEN$BOLD$UNDERLINE"\t\t\t$OutPut"
	OutPut=""
       	print "\n"
       	print           "\t\t\t"
       	echo -e $YELLOW$BOLD$UNDERLINE"\t\t\tBHAVCOPY FILE MENU"
       	echo $NORMAL""
	print "\n"
        echo -e $BOLD$UNDERLINE"\t\t\tEXCH_SEGMENT \t\t\t STATUS \t\t\t LAST UPLOAD"
        echo $NORMAL""	
	print "\n"
	print           "\t\t\t1) NSE EQ    \t\t\t`echo $NseEqStatus`  \t\t\t`echo $NseEqLastUpdDate`"
	print "\n"
	print           "\t\t\t2) NSE FO    \t\t\t`echo $NseFOStatus`  \t\t\t`echo $NseFOLastUpdDate`"
	print "\n"
	print           "\t\t\t3) NSE CD    \t\t\t`echo $NseCDStatus`  \t\t\t`echo $NseCDLastUpdDate`"
	print "\n"
	print           "\t\t\t4) BSE EQ    \t\t\t`echo $BseEqStatus`  \t\t\t`echo $BseEqLastUpdDate`"
	print "\n"
	print           "\t\t\t5) MCX       \t\t\t`echo $MCXStatus`    \t\t\t`echo $MCXLastUpdDate`"
	print "\n"
	print           "\t\t\t6) ALL       \t\t\t`echo $ALLStatus`"
	print "\n"
	print           "\t\t\t0) Previous Menu"
	print "\n"
	print           "\t\t\t Enter Choice    : \c"
	cd $UPLOAD_DIR/BC_UPLOAD
	read OPTION_10
	case "$OPTION_10" in	
	1) clear
		OutPut="`UploadNseEqBC.sh`"
		;;
	2) clear
		OutPut="`UploadNseDrvBC.sh`"
		;;
	3) clear
		OutPut="`UploadNseCDBC.sh`"
		;;
	4) clear
		OutPut="`UploadBseEqBC.sh`"
		;;
	5) clear
		OutPut="`UploadMCX.sh`"
		;;
	6) clear
		OutPut="`AllBatchUpldBC.sh`"
		;;
	0)break
		;;
	*) print "\n"
		print "\t\tInvalid Option.... Please Press ENTER to continue"
		read key0
		;;
	esac
done
