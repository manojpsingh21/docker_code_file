cd $UPLOAD_DIR/BC_UPLOAD/
UploadNseEqBC.sh
sleep 10
UploadNseDrvBC.sh
sleep 10
UploadNseCDBC.sh
sleep 10
UploadBseEqBC.sh
sleep 10
UploadMCX.sh
