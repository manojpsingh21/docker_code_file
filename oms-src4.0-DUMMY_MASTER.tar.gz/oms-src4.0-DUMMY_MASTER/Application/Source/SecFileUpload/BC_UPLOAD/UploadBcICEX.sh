append=`date "+%Y%m%d_%H%M"`
mv $HOME/UPLOADS/BHAVCOPY/ICEX/COMMODITY/* $HOME/UPLOADS/BHAVCOPY/ICEX/COMMODITY/icex_bc.csv
stats=`echo $?`
#if test "$stats" != "0"; then
if [ ! -f "$HOME/UPLOADS/BHAVCOPY/ICEX/COMMODITY/icex_bc.csv" ]; then
        echo "File Already Exist...Kindly Tranfer Again And Upload Manually "
        rm -f $HOME/UPLOADS/BHAVCOPY/ICEX/COMMODITY/*
	exit
else
	export CLASSPATH=$CLASSPATH:$UPLOAD_DIR/lib/sqlserverjdbc.jar:$UPLOAD_DIR/lib/mysql-connector-java-5.1.36-bin.jar;
	cd $UPLOAD_DIR/BC_UPLOAD/
	$JAVA_PATH/javac Upload_ICEX_BC.java Unscramble.java
	Output="`$JAVA_PATH/java Upload_ICEX_BC ../config.txt`"
	if test "$Output" = "SUCCESS";then
                mv $HOME/UPLOADS/BHAVCOPY/ICEX/COMMODITY/icex_bc.csv  $HOME/UPLOADS/ACC/BHAVCOPY/ICEX/COMMODITY/icex_bc.csv_$append
        else
                mv $HOME/UPLOADS/BHAVCOPY/ICEX/COMMODITY/icex_bc.csv  $HOME/UPLOADS/NACC/BHAVCOPY/ICEX/COMMODITY/icex_bc.csv_$append
        fi;
	echo $Output
fi;
