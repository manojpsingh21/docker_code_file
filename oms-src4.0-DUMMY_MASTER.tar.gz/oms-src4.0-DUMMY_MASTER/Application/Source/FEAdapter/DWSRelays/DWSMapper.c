#include <string.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
/***#include "Queue.h"
#include "Common.h"
#include "IntTCodes.h"****/
#include "IPCS.h"
#include "DWSRelay.h"

LONG32	iRelToOrdRtr ;
LONG32	DWSRelayToMapperQ ;

//EXEC    SQL INCLUDE sqlca.h;
SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen );

main (int argc, char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	fOpenMessgQ();
	fMapper();

}

BOOL fMapper()
{
	struct	ORDER_REQUEST	pOE_REQUEST    ;
	struct	REQ_HEADER	*pReqHeader;
	struct	DWS_ORDER_REQUEST *pORDER_REQUEST;
	struct	CON_TO_DELIVERY_REQUEST pConvDel;

	CHAR	RcvMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    SndMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    BasicError[ERROR_MSG_LEN]	;


	while ( 1 )
	{
		memset( &RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &SndMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &BasicError,'\0', ERROR_MSG_LEN);
		memset(&pOE_REQUEST,'\0',sizeof(struct ORDER_REQUEST));
		memset(&pConvDel,'\0',sizeof(struct CON_TO_DELIVERY_REQUEST));
		memset(&pORDER_REQUEST,'\0',sizeof(struct DWS_ORDER_REQUEST));

		logInfo(" #########Waiting in while loop to get the data ################# %d",DWSRelayToMapperQ);

		if((ReadMsgQ( DWSRelayToMapperQ, &RcvMsg, LOCAL_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			logDebug2("(DWSMapper)Error Read Q :Qid %d", DWSRelayToMapperQ);
			exit(ERROR);
		}

		pORDER_REQUEST=(struct DWS_ORDER_REQUEST *) &RcvMsg ;

		logDebug3("-----------Printing DWS_ORDER_REQUEST Structure  From Front End------------------------------");
		logDebug3(" pORDER_REQUEST->ReqHeader.iRequestLength:%d:",pORDER_REQUEST->ReqHeader.iRequestLength);
		logDebug3(" pORDER_REQUEST->ReqHeader.iUserId:%d:",pORDER_REQUEST->ReqHeader.iUserId);
		logDebug3(" pORDER_REQUEST->ReqHeader.iRequestCode:%d:",pORDER_REQUEST->ReqHeader.iRequestCode);
		logDebug3(" pORDER_REQUEST->ReqHeader.iExchange:%d:",pORDER_REQUEST->ReqHeader.iExchange);
		logDebug3(" pORDER_REQUEST->ReqHeader.iSegment:%d:",pORDER_REQUEST->ReqHeader.iSegment);
		logDebug3(" pORDER_REQUEST->ReqHeader.cUserType:%c:",pORDER_REQUEST->ReqHeader.cUserType);
		logDebug3(" pORDER_REQUEST->ReqHeader.sSecurityId:%s: strlen(pORDER_REQUEST->sSecurityId)[%d]",pORDER_REQUEST->sSecurityId,strlen(pORDER_REQUEST->sSecurityId));
		logDebug3(" pORDER_REQUEST->sEntityId:%s: strlen(pORDER_REQUEST->sEntityId)[%d]",pORDER_REQUEST->sEntityId,strlen(pORDER_REQUEST->sEntityId));
		logDebug3(" pORDER_REQUEST->sClientId:%s: strlen(pORDER_REQUEST->sClientId) [%d] ",pORDER_REQUEST->sClientId,strlen(pORDER_REQUEST->sClientId));
		logDebug3(" pORDER_REQUEST->cProductId:%c:",pORDER_REQUEST->cProductId);
		logDebug3(" pORDER_REQUEST->iMarketType:%d:",pORDER_REQUEST->iMarketType);
		logDebug3(" pORDER_REQUEST->iBookType:%d:",pORDER_REQUEST->iBookType);
		logDebug3(" pORDER_REQUEST->iBuySell:%d:",pORDER_REQUEST->iBuySell);
		logDebug3(" pORDER_REQUEST->sFlag:%s:",pORDER_REQUEST->sFlag);
		logDebug3(" pORDER_REQUEST->iDiscQty:%d:",pORDER_REQUEST->iDiscQty);
		logDebug3(" pORDER_REQUEST->iDiscQtyRem:%d:",pORDER_REQUEST->iDiscQtyRem);
		logDebug3(" pORDER_REQUEST->iTotalQtyRem:%d:",pORDER_REQUEST->iTotalQtyRem);
		logDebug3(" pORDER_REQUEST->iTotalQty:%d:",pORDER_REQUEST->iTotalQty);
		logDebug3(" pORDER_REQUEST->iTradedQty:%d:",pORDER_REQUEST->iTradedQty);
		logDebug3(" pORDER_REQUEST->fPrice:%lf:",pORDER_REQUEST->fPrice);
		logDebug3(" pORDER_REQUEST->fTriggerPrice:%lf:",pORDER_REQUEST->fTriggerPrice);
		logDebug3(" pORDER_REQUEST->fOrderNum:%lf:",pORDER_REQUEST->fOrderNum);
		logDebug3(" pORDER_REQUEST->iSerialNum:%d:",pORDER_REQUEST->iSerialNum);
		logDebug3(" pORDER_REQUEST->fAlgoOrderNo:%lf:",pORDER_REQUEST->fAlgoOrderNo);
		/**	logDebug3(" pORDER_REQUEST->iStratergyId :%d:",pORDER_REQUEST->iStratergyId);
		  logDebug3(" pORDER_REQUEST->sGoodTillDaysDate :%s:",pORDER_REQUEST->sGoodTillDaysDate);
		 **/
		logDebug3("---------------------------------END-----------------------------------------------------------");


		/*****************Start:Populating the structure*******************/
		/******* Populating Req Header******/
		pOE_REQUEST.ReqHeader.iSeqNo		= 0;
		pOE_REQUEST.ReqHeader.iMsgLength	= sizeof(struct  ORDER_REQUEST);
		pOE_REQUEST.ReqHeader.iMsgCode		= pORDER_REQUEST->ReqHeader.iRequestCode;

		if(pORDER_REQUEST->ReqHeader.iExchange == 1)
		{
			strncpy(pOE_REQUEST.ReqHeader.sExcgId,NSE_EXCH,EXCHANGE_LEN);	
		}
		else if(pORDER_REQUEST->ReqHeader.iExchange == 2)
		{
			strncpy(pOE_REQUEST.ReqHeader.sExcgId,BSE_EXCH,EXCHANGE_LEN);
		}
		else if(pORDER_REQUEST->ReqHeader.iExchange == 3)
		{
			strncpy(pOE_REQUEST.ReqHeader.sExcgId,MCX_EXCH,EXCHANGE_LEN);
			/**
			  if(pORDER_REQUEST->sFlag[7] == '1')
			  {		
			  strncpy(pOE_REQUEST.sGoodTillDaysDate , pORDER_REQUEST->sGoodTillDaysDate , DB_DATETIME_LEN);
			  }
			 **/

		}
		else
		{
			logDebug2("Printing in else");
		}

		logDebug2("Here 0");
		/*
		   if(pORDER_REQUEST->ReqHeader.iExchange != 3)
		   {
		   logDebug2("Here 1");
		   strncpy(pOE_REQUEST.sGoodTillDaysDate ,'\0', DB_DATETIME_LEN);
		   }
		 */

		logDebug2("Here 2");
		if(pORDER_REQUEST->ReqHeader.iSegment == 1)	
		{
			pOE_REQUEST.ReqHeader.cSegment	= EQUITY_SEGMENT;
		}
		else if (pORDER_REQUEST->ReqHeader.iSegment == 2)
		{
			pOE_REQUEST.ReqHeader.cSegment	= DERIVATIVE_SEGMENT;
		}
		else if (pORDER_REQUEST->ReqHeader.iSegment == 3)
		{
			pOE_REQUEST.ReqHeader.cSegment	= CURRENCY_SEGMENT;
		}
		else if (pORDER_REQUEST->ReqHeader.iSegment == 4)
		{
			pOE_REQUEST.ReqHeader.cSegment	= COMMODITY_SEGMENT;
		}
		else
		{
			logDebug2("iSegment Received 0");
		}

		pOE_REQUEST.ReqHeader.iUserId	= pORDER_REQUEST->ReqHeader.iUserId;
		logDebug2("pOE_REQUEST.ReqHeader.iUserId = %d ",pOE_REQUEST.ReqHeader.iUserId);
		pOE_REQUEST.cUserType 		= pORDER_REQUEST->ReqHeader.cUserType;

		logDebug2("Request Code Received is :%d",pORDER_REQUEST->ReqHeader.iRequestCode);

		switch(pORDER_REQUEST->ReqHeader.iRequestCode)
		{	
			case TC_INT_EQU_ORDER_ENTRY:
			case TC_INT_DRV_ORDER_ENTRY:
				pOE_REQUEST.ReqHeader.iMsgCode = TC_INT_ORDER_ENTRY_REQ;
				break;

			case TC_INT_EQU_ORDER_MODIFY:
			case TC_INT_DRV_ORDER_MODIFY:
				pOE_REQUEST.ReqHeader.iMsgCode= TC_INT_ORDER_MODIFY;
				break;

			case TC_INT_EQU_ORDER_CANCEL:
			case TC_INT_DRV_ORDER_CANCEL:
				pOE_REQUEST.ReqHeader.iMsgCode= TC_INT_ORDER_CANCEL;
				break;
				/*****/
			case TC_INT_CONVT_TO_DELV_REQ:
				pOE_REQUEST.ReqHeader.iMsgCode= TC_INT_CON_DEL_REQ;
				break;
				/*****/
			case TC_INT_OFF_ORDER_ENTRY:
			case TC_INT_OFF_ORDER_MODIFY:
			case TC_INT_OFF_ORDER_CANCEL:
			case TC_INT_NOTIFICATION_REQ:
				pOE_REQUEST.ReqHeader.iMsgCode = pORDER_REQUEST->ReqHeader.iRequestCode;
				break;

			case TC_INT_SQUAREOFF_INTRADAY_REQ:
				pOE_REQUEST.ReqHeader.iMsgCode = TC_INT_SQUAREOFF_INTRADAY_REQ;
				break;

			case TC_INT_PUMPOFFLINE_REQ:
				pOE_REQUEST.ReqHeader.iMsgCode = TC_INT_PUMPOFFLINE_REQ;
				break;

			case TC_INT_ADMIN_EXPIRY_REQ:
				pOE_REQUEST.ReqHeader.iMsgCode = TC_INT_ADMIN_EXPIRY_REQ;
				break;

			default:
				logDebug2(" CASE default Pls check the argument passed [%d]",pORDER_REQUEST->ReqHeader.iRequestCode);
				continue;

		}
		logDebug2("pOE_REQUEST.ReqHeader.iMsgCode [%d]",pOE_REQUEST.ReqHeader.iMsgCode);
		memset(pOE_REQUEST.sSecurityId,'\0',12);	
		logDebug2(" strlen(pOE_REQUEST.SecurityId):%d:",strlen(pOE_REQUEST.sSecurityId));
		strncpy(pOE_REQUEST.sSecurityId,pORDER_REQUEST->sSecurityId,12);

		logDebug2("pOE_REQUEST.SecurityId:%s: pORDER_REQUEST->sSecurityId:%d:",pOE_REQUEST.sSecurityId,strlen(pORDER_REQUEST->sSecurityId));
		fTrim(pORDER_REQUEST->sEntityId,strlen(pORDER_REQUEST->sEntityId));
		fTrim(pORDER_REQUEST->sClientId,strlen(pORDER_REQUEST->sClientId));
		fTrim(pOE_REQUEST.sSecurityId,strlen(pOE_REQUEST.sSecurityId));
		logDebug2("pOE_REQUEST.SecurityId:%s: pORDER_REQUEST->sSecurityId:%d:",pOE_REQUEST.sSecurityId,strlen(pORDER_REQUEST->sSecurityId));

		strncpy(pOE_REQUEST.sEntityId,pORDER_REQUEST->sEntityId,CLIENT_ID_LEN);
		strncpy(pOE_REQUEST.sClientId,pORDER_REQUEST->sClientId,CLIENT_ID_LEN);


		/****
		  if(pORDER_REQUEST->sFlag[6] == 1)
		  {
		  strncpy(pOE_REQUEST.ProCli,"C",PRO_CLI_LEN);
		  logDebug2("pOE_REQUEST.ProCli :%s:",pOE_REQUEST.ProCli);
		  }
		  else if(pORDER_REQUEST->sFlag[6] == 1)
		  {
		  strncpy(pOE_REQUEST.ProCli,"P",PRO_CLI_LEN);
		  }****/


		//strncpy(pOE_REQUEST.cProCli,"C",PRO_CLI_LEN);



		//			strncpy(pOE_REQUEST.ParticipantCode,"08814",PARTICIPANT_CODE_LEN);
		/**	strncpy(pOE_REQUEST.CBrokerCode,"08814  ",INT_BROKER_CODE_LEN);***/
		//		strncpy(pOE_REQUEST.CBrokerCode,"      ",INT_BROKER_CODE_LEN);
		pOE_REQUEST.fOrderNum= pORDER_REQUEST->fOrderNum;
		pOE_REQUEST.iSerialNum= pORDER_REQUEST->iSerialNum;
		strncpy(pOE_REQUEST.sClientId,pORDER_REQUEST->sClientId,CLIENT_ID_LEN);
		/****
		  if(pORDER_REQUEST->iBookType == 1)
		  {
		  memset(pOE_REQUEST.BookType,'\0',BOOK_TYPE_LEN);
		  strncpy(pOE_REQUEST.BookType,"RL",2);
		  }
		  else if (pORDER_REQUEST->iBookType == 2)
		  {
		  strncpy(pOE_REQUEST.BookType,"SL",BOOK_TYPE_LEN);
		  }
		 *****/			
		if(pORDER_REQUEST->iBuySell == 1)
		{
			pOE_REQUEST.cBuyOrSell = INT_BUY;
		}
		else if(pORDER_REQUEST->iBuySell == 2)
		{
			pOE_REQUEST.cBuyOrSell = INT_SELL;
		}

		pOE_REQUEST.iDiscQty		= pORDER_REQUEST->iDiscQty;
		pOE_REQUEST.iDiscQtyRem		= pORDER_REQUEST->iDiscQtyRem;
		pOE_REQUEST.iTotalQtyRem	= pORDER_REQUEST->iTotalQtyRem;
		pOE_REQUEST.iTotalQty		= pORDER_REQUEST->iTotalQty;

		/*---------------New Changes By Nishant-------------------------------------*/

		//		pOE_REQUEST.iStratergyId	= pORDER_REQUEST->iStratergyId;

		if(pORDER_REQUEST->sFlag[6] == '1')
		{
			pOE_REQUEST.cProCli = NNF_CLI ;	
		}
		else
		{
			pOE_REQUEST.cProCli = NNF_PRO ;
		}
		logDebug2("pOE_REQUEST.cProCli :%c:",pOE_REQUEST.cProCli);
		logDebug2("pOE_REQUEST.iStratergyId :%d:",pOE_REQUEST.iStratergyId);
		logDebug2("pOE_REQUEST.sGoodTillDaysDate :%s:",pOE_REQUEST.sGoodTillDaysDate);

		/*---------------t-------------------------------------*/

		logDebug2("pORDER_REQUEST->iTotalQtyRem :%d: pORDER_REQUEST->iTotalQty:%d:",pORDER_REQUEST->iTotalQtyRem,pORDER_REQUEST->iTotalQty);
		/**
		  if(pORDER_REQUEST->ReqHeader.iRequestCode == TC_INT_EQU_ORDER_MODIFY && pORDER_REQUEST->ReqHeader.iExchange == 2)
		  {
		  logDebug2(" I am in modification");
		  pOE_REQUEST.iTotalQtyRem	= pORDER_REQUEST->iTotalQty;
		  pOE_REQUEST.iTotalQty		= pORDER_REQUEST->iTotalQty;
		  }
		 ***/
		pOE_REQUEST.iTotalTradedQty		= pORDER_REQUEST->iTradedQty;
		pOE_REQUEST.iMinFillQty			= 0;
		pOE_REQUEST.fPrice			= pORDER_REQUEST->fPrice;
		logDebug2("pOE_REQUEST.Price:%lf,pORDER_REQUEST->fPrice:%lf:",pOE_REQUEST.fPrice,pORDER_REQUEST->fPrice);
		pOE_REQUEST.fTriggerPrice		= pORDER_REQUEST->fTriggerPrice;
		pOE_REQUEST.cOffMarketFlg 		= '0';

		if(pOE_REQUEST.fPrice == 0)
		{
			if(pORDER_REQUEST->sFlag[3] == '1')
			{
				pOE_REQUEST.iOrderType = ORD_TYPE_STOP_LOSS_MKT;
			}
			else
			{
				pOE_REQUEST.iOrderType = ORD_TYPE_MKT;
			}
		}
		else if(pOE_REQUEST.fPrice > 0)
		{
			if(pORDER_REQUEST->sFlag[3] == '1')
			{
				pOE_REQUEST.iOrderType = ORD_TYPE_STOP_LIMIT;
			}
			else
			{
				pOE_REQUEST.iOrderType = ORD_TYPE_LIMIT;	
			}	

		}
		logDebug2(" pOE_REQUEST.iOrderType :%d:",pOE_REQUEST.iOrderType);
		/***	pOE_REQUEST.MFFlag = '0';
		  pOE_REQUEST.AONFlag = pORDER_REQUEST->sFlag[4];
		  pOE_REQUEST.IOCFlag = pORDER_REQUEST->sFlag[1];
		  pOE_REQUEST.GTCFlag = '0';
		  pOE_REQUEST.DayFlag = pORDER_REQUEST->sFlag[0];
		  pOE_REQUEST.StopLossFlag = pORDER_REQUEST->sFlag[3];***/
		logDebug2(" pORDER_REQUEST->sFlag[0] :%c:",pORDER_REQUEST->sFlag[0]);
		logDebug2(" pORDER_REQUEST->sFlag[1] :%c:",pORDER_REQUEST->sFlag[1]);

		if(pORDER_REQUEST->sFlag[0] == '1')
		{
			pOE_REQUEST.iOrderValidity = VALIDITY_DAY ;
		}
		else if(pORDER_REQUEST->sFlag[1] == '1')
		{
			pOE_REQUEST.iOrderValidity = VALIDITY_IOC;
		}
		else
		{
			pOE_REQUEST.iOrderValidity = VALIDITY_EOS;
			logDebug2("pOE_REQUEST.iOrderValidity = %d",pOE_REQUEST.iOrderValidity);
		}	

		/***	if( pOE_REQUEST.StopLossFlag == '1')
		  {
		  strncpy(pOE_REQUEST.BookType,"SL",BOOK_TYPE_LEN);
		  }****/
		//pOE_REQUEST.MITFlag = '0';
		/***			if(pORDER_REQUEST->iMarketType == 1);
		  {
		  strncpy(pOE_REQUEST.MarketType,"NL   ",MARKET_LEN);
		  }****/
		pOE_REQUEST.iMktType = pORDER_REQUEST->iMarketType;

		logDebug2("\n pOE_REQUEST.iMktType:%d:",pOE_REQUEST.iMktType);
		pOE_REQUEST.fAlgoOrderNo= pORDER_REQUEST->fAlgoOrderNo;

		pOE_REQUEST.cProductId= pORDER_REQUEST->cProductId;
		pOE_REQUEST.cHandleInst= '1';
		pOE_REQUEST.ReqHeader.cSource = SOURCE_RAPIDRUPEE;/****** HARD CODED CHANGE BY NISHANT*********/

		if(( WriteMsgQ( iRelToOrdRtr , (CHAR *)&pOE_REQUEST,sizeof(struct ORDER_REQUEST) ,1 ) != TRUE ))
		{
			perror("Error WriteQ: ");
			logDebug2("Write Q id %d", iRelToOrdRtr);
			exit(ERROR);
		}
		logDebug2("**************** OE REQ*********************/");

	}
}

BOOL fOpenMessgQ()
{
	if( ( DWSRelayToMapperQ = OpenMsgQ( (RelToDWSMap))) == ERROR )
	{
		perror("Open DWSRelayToMapper :");
		exit( 1 );
	}
	if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	return TRUE;

}

SHORT   fAddSpace( CHAR * Str_In ,SHORT MaxLen )
{
	SHORT Strlen=0;

	if ( MaxLen <= 0 )
	{
		return FALSE ;
	}

	for( ; Str_In[Strlen] != ' ' && Strlen < MaxLen ; Strlen++ )
	{
		continue;
	}
	Str_In[Strlen]='\0';
	return Strlen  ;
}

SHORT   fTrim( CHAR * Str_In ,SHORT MaxLen )
{
	SHORT Strlen=0;

	if ( MaxLen <= 0 )
	{
		return FALSE ;
	}

	for( ; Str_In[Strlen] != ' ' && Strlen < MaxLen ; Strlen++ )
	{
		continue;
	}
	Str_In[Strlen]='\0';
	return Strlen  ;
}
