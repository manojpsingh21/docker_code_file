include "IPCS.h"
#include "DWSAdapter.h"
#include <errno.h>


#define ISSET                1
#define UNSET                0
#define WRITEISSET           1
#define WRITEUNSET           0
#define DLDISSET             1
#define DLDUNSET             0

void ProcessIncomeBuffer ( void * );
void ProcessOutDloadBuff ( void * );
void ProcessOutBoundBuff ( void * );
void sig_segv_handler();

main( int argc , char ** argv )
{

	int             Index , count ,i;
	int             ForkInd = 1;


	signal (SIGHUP, SIG_IGN);
	signal (SIGSEGV,sig_segv_handler);
	sigemptyset ( &MainSignalSet );
	sigaddset ( &MainSignalSet , SIGTERM);
	sigaddset ( &MainSignalSet , SIGCHLD);
	sigprocmask (SIG_BLOCK,&MainSignalSet , NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );


	if ( argc < 3 )
	{
		logDebug3( " Usage Prog_name Relaytype RelayPort ");
		exit (1);
	}

	ProcessArguments ( argv );
	InitForkProcess ( );
	/** ConnectToMYSQL ( );***/   /***** Nitish need t put that ********************/

	if ( 0 != pthread_once (&OnceInit,init_routine))
	{
		perror("pthread_once");
	}

	logDebug3(" MAX_NO_OF_PROCESS is[%d] ",MAX_NO_OF_PROCESS);
	logDebug3(" MAX_THREADS_WRITE is [%d]",MAX_THREADS_WRITE);
	logDebug3(" MAX_DLOAD_THREADS_WRITE [%d]",MAX_DLOAD_THREADS_WRITE);

	for (i=0 ; i < MAX_NO_OF_PROCESS && ForkInd != 0 ; i++)
	{
		ForkInd = fork ( );
		RelayPort = RelayPort + i;
		RelayId = i + 1;
		if ( ForkInd != 0)
		{
			UpdateForkProcess (ForkInd ,RelayPort,RelayId);
		}
	}

	if ( ForkInd != 0 )
	{
		ConnectToOracle ( );
		sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
		signal(SIGTERM,SignalHandlerSigTermParent);
		signal(SIGCHLD,SignalHandlerSigChldParent);
		for (;;)
		{
			sleep (3);
			for ( i=0; i < MAX_NO_OF_PROCESS  && ForkInd != 0 ; i++ )
			{
				if ( ForkProcess[i].ProcessId == RESTART )
				{
					sleep(3);
					sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
					ForkInd = fork ();
					if( ForkInd != 0)               
					{
						RelayPort = ForkProcess[i].RelayPort;
						RelayId   = ForkProcess[i].RelayId ;
						ForkProcess[i].ProcessId = ForkInd;
					}
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					signal(SIGTERM,SignalHandlerSigTermParent);
					signal(SIGCHLD,SignalHandlerSigChldParent);
				}
			}

			if ( ForkInd == 0 )
			{
				logDebug3 (" New Fork Process Started ");
				break;
			}
		}                                           /* End of infinite for */
	}                                               /* End of Parent loop */
	LockThreadMutex ( &LookupMutex );
	InitLookup( );
	UnLockThreadMutex ( &LookupMutex );

	if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	logDebug1(" iRelToOrdRtr created sucesfully wid Qid :%d:",iRelToOrdRtr);


	if( ( iRelToQuery = OpenMsgQ( (RelToQuery))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug1(" iRelToQuery queue opened sucessfully with queuue id :%d:",iRelToQuery);

	if( (iTrdRtrToRel= OpenMsgQ(TrdRtrToRel)) == ERROR)
	{
		perror("Open DirToSTWRelQ :");
		exit( 1 );
	}

	logDebug1(" iTrdRtrToRel :%d:",iTrdRtrToRel);

	if( pipe(PipeFds) != 0 )
	{
		exit( 1);
	}
	if( pipe(oms_filedes) != 0 )                    
	{
		perror("Error in pipe creation");
		exit( 1);
	}
	sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);

	sigemptyset ( &ChildSignalSet );
	sigaddset ( &ChildSignalSet , SIGTERM);
	sigaddset ( &ChildSignalSet , SIGUSR1);

	sigaddset ( &ChildSignalSet , SIGUSR2);

	pthread_sigmask ( SIG_BLOCK,&ChildSignalSet,NULL);
	pthread_create(&SignalTid, NULL, SignalThread, NULL);
	/** ConnectToMYSQL ( );**/   /***** Nitish need t put that ********************/
	pthread_create(&ReadTid, NULL, ReadThread, NULL);

	pthread_create(&WriteTid, NULL, WriteThread, (void *)Queue);
	pthread_create(&WriteTid_intorderresp, NULL, WriteThread, (void *)Queue_int);
	pthread_create(&WriteDloadTid, NULL, WriteDloadThread, NULL);

	pthread_join(ReadTid, NULL);
	pthread_join(WriteTid, NULL);
	pthread_join(WriteTid_intorderresp, NULL);
	pthread_join(WriteDloadTid, NULL);
}

/***********
  Function Name: InitForkProcess 
Arguments: NULL
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments: This function will make the relay ID as unused .
 **********/
void InitForkProcess ( )
{
	int i;
	for ( i =0 ; i < MAX_NO_OF_PROCESS ; i++ )
	{
		ForkProcess [i].RelayId = UNUSED;
		ForkProcess [i].ProcessId = UNUSED;
		ForkProcess [i].RelayPort = UNUSED;
	}
}


/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/

void init_routine ()
{
	int       i;
	for ( i = 0;i < MAX_NO_OF_USERS ; i++ )
	{
		if ( pthread_mutex_init (&Lookup[i].SendMutex,NULL) != 0)
		{
			perror("pthread_mutex_init:SendMutex");
			exit (1);
		}
	}
	if(  pthread_mutex_init ( &LookupMutex,NULL) != 0)
	{
		perror("pthread_mutex_init:LookupMutex");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&ActiveSocLock,NULL ) != 0)
	{
		perror("pthread_mutex_init:ActiveSocLock");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&PipeLock,NULL ) != 0)
	{
		perror("pthread_mutex_init:PipeLock");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&OracleMutex,NULL ) != 0)
	{
		perror("pthread_mutex_init:OracleMutex");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&SendMutexSeq,NULL ) != 0)
	{
		perror("pthread_mutex_init:SendMutexSeq");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&MaxThreadMutex,NULL ) != 0)
	{
		perror("pthread_mutex_init:MaxThreadMutex");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&MaxThreadMutexWrite,NULL ) != 0)
	{
		perror("pthread_mutex_init:MaxThreadMutexWrite");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	if(  pthread_mutex_init (&MaxDloadThreadMutexWrite,NULL ) != 0)
	{
		perror("pthread_mutex_init:MaxDloadThreadMutexWrite");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}

	if(  pthread_attr_init (&ThreadAttr) != 0)
	{
		perror("pthread_attr_init:ThreadAttr");
		/*        printf("\n Error in intialising Mutex \n"),exit(1);*/
	}
	pthread_attr_setdetachstate(&ThreadAttr,PTHREAD_CREATE_DETACHED);
}

/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/
void PrintLookup( void )
{
	register int i ;
	for( i = 0 ; i < MAX_NO_OF_USERS ; i++ )
	{
		printf("\nLookup[%d].Socket = %d\tLookup[%d].UserId = %d\t" "Lookup[%d].UserType = %d" , i , Lookup[i].Socket ,i , Lookup[i].user.UserId , i , Lookup[i].user.UserType );
		printf("\t Lookup[%d].PeerAddr %s",i,inet_ntoa(Lookup[i].PeerAddr.sin_addr));
	}
}


/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/

void AssociateSocketSignal( int Socket )
{
	int flag = 1 ;

	if( setsockopt( Socket , SOL_SOCKET , SO_KEEPALIVE , ( char * )&flag , sizeof( flag ) ) < 0 )
	{
		perror("Error In setsockopt() ErrorMsg");
		exit ( 1 );
	}

	printf("Associating Socket = %d And SIGIO \n" , Socket );
}


/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/
void InitLookup( void )
{
	register int i,j;

	for( i = 0 ; i < MAX_NO_OF_USERS ; i ++ )
	{
		Lookup[ i ].Socket        = UNUSED ;
		Lookup[ i ].user.UserId  = UNUSED ;
		Lookup[ i ].user.UserType= UNUSED ;
		memset(&(Lookup[i].PeerAddr),NULL,sizeof(struct sockaddr_in));
	}
}



/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/
int GetIndexForPacket( char *cpMsgBuf )
{
	register int i ,k;

	/*	PrintLookup();*/
	for( i = 0 ; i < MAX_NO_OF_USERS ; i++ )
	{
		if( Lookup[i].Socket   != ( int )UNUSED  && Lookup[i].user.UserId==((struct INT_RESP_HEADER * )cpMsgBuf )->UserIdOrLogPktId )
		{
			/*************************
			  printf("In GetIndexForPacket() Socket = %d\n", Lookup[i].Socket);
			 *************************/
			logDebug2("Index:User %d:%d", i, ((struct INT_RESP_HEADER * )cpMsgBuf )->UserIdOrLogPktId );
			return  i;
		}
	}
	return NOT_TRUE ;
}

/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/

void CleanSocketResour( int Socket )
{
	register int Index ,j;
	printf("\n\t\t INSIDE CleanSocketResour ");
	if( ( Index = SearchIndex( Socket ) ) == NOT_TRUE || Socket == UNUSED )
		return ;
	DeleteShmRelayData(Lookup[Index].user.UserId);

	Lookup[ Index ].user.UserId     = UNUSED ;
	Lookup[ Index ].user.UserType   = UNUSED ;
	Lookup[ Index ].Socket      = UNUSED ;

	memset(&(Lookup[ Index ].PeerAddr),NULL,sizeof(struct sockaddr_in));
	close( Socket );
	LockThreadMutex ( &ActiveSocLock) ;
	FD_CLR( Socket , &ActiveSocket );
	UnLockThreadMutex ( &ActiveSocLock) ;
	printf("In CleanSocketResour() Socket = %d \n" , Socket );
}


/***********
  Function Name:
Arguments:
Return Values:
Tables Used:
Dependencies:
Functions Called By:
Comments:
 **********/

int SendPacketToUser( int Socket , char *cpMsgBuf )
{

	logDebug3("In SendPacketToUser");

	struct MsgSocketStruct *MsgStruct;

	MsgStruct = (struct MsgSocketStruct *) malloc ( sizeof (struct MsgSocketStruct));
	MsgStruct->Socket = Socket;
	memcpy(MsgStruct->cpMsgBuf,cpMsgBuf,BSS_MESSAGE_SIZE);

	if ( MonitorWriteFlag == WRITEISSET )
	{
		ProcessOutBoundBuff ( MsgStruct );
		LockThreadMutex ( &MaxThreadMutexWrite );
		NoOfThreadsWrite -- ;
		UnLockThreadMutex ( &MaxThreadMutexWrite );
		return;
	}

	WaitForMaxThreadCondWrite ( );
	LockThreadMutex ( &SendMutexSeq );
	pthread_create (&WriteUserTid,&ThreadAttr,WriteUserThread,(void *)(MsgStruct));
	logDebug3("Out SendPacketToUser");
	return TRUE ;
}

