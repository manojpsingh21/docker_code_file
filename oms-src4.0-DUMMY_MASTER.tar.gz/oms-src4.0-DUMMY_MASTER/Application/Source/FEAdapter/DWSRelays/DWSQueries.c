#include <my_global.h>
#include <string.h>
#include <mysql.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include "IPCS.h"
//#include "DWSAdapter.h"

/***#include "Queue.h"
#include "Common.h"
#include "IntTCodes.h"***/

#define LOCAL_MAX_PACKET_SIZE   4096
LONG32	iSTWRelToQueryQ;
LONG32	iIntActiveToRelDirQ;
LONG32	iTrdRout2SurvlMapperQ;
MYSQL *DBQueries;

main (int argc, char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	DBQueries = DB_Connect();
	OpenMessgQ();
	Mapper();

}/*** End of main***/

BOOL Mapper()
{
	struct	INT_COMMON_REQUEST_HDR *pReqHeader;

	CHAR	RcvMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR    SndMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR    BasicError[ERROR_MSG_LEN];

	LONG32	iMsgCode;
	LONG32	iRetVal;


	while ( 1 )
	{
		memset( &RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &SndMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &BasicError,'\0', ERROR_MSG_LEN);


		logInfo(" #########Waiting in while loop to get the data ################# %d",iSTWRelToQueryQ);

		if((ReadMsgQ( iSTWRelToQueryQ, &RcvMsg, LOCAL_MAX_PACKET_SIZE, 1)) != 1)
		{
			perror("Error Read Q : ");
			logFatal("(DWSMapper)Error Read Q :Qid %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


		pReqHeader=(struct INT_COMMON_REQUEST_HDR *) &RcvMsg ;

		iMsgCode = pReqHeader->iMsgCode;

		logDebug2("-----------iMsgCode = :%d:----------------",iMsgCode); 	

		switch ( iMsgCode )

		{
			case	TC_INT_VIEW_CLIENT_LIMIT_REQ:
				/**	iRetVal = fViewClientLimit(&RcvMsg);		****/
				/***/	iRetVal = fViewClientLimitNEW(&RcvMsg);		/****/
				break;


				/**		case	TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
				  iRetVal = fViewClientLimitDealer(&RcvMsg);		
				  break;
				 ****/

			case	TC_INT_NET_POS_REQ:
				iRetVal = fViewNetPosition(&RcvMsg);		
				break;

			case	TC_INT_ORDER_BOOK_REQ:
				iRetVal = fGetOrderBook(&RcvMsg);		
				break;

			case	TC_INT_ORDER_BOOK_DTLS_REQ:
				logDebug2(" hey u ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.iSegment :%d:",((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment);
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == EQUITY_SEGMENT)
				{
					iRetVal = fEquOrderBookDtls(&RcvMsg);
				}
				else if (((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == DERIVATIVE_SEGMENT || ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == CURRENCY_SEGMENT)
				{
					iRetVal = fDrvOrderBookDtls(&RcvMsg);
				}
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == COMMODITY_SEGMENT)
				{
					iRetVal = fCOMMOrderBookDtls(&RcvMsg);
				}

				break;

			case	TC_INT_TRADE_BOOK_REQ:
				iRetVal = fGetTradeBook(&RcvMsg);		
				break;

			case	TC_INT_ADMIN_TRADE_BOOK_REQ:
				iRetVal = fSurvillenceTradeBook(&RcvMsg);		
				break;

			case	TC_INT_CLINET_HOLDING_REQ:
				iRetVal = fClientHoldings(&RcvMsg);		
				break;

			case	TC_INT_NETPOS_DTL_REQ:
				iRetVal = fNetPositionDetail(&RcvMsg);		
				break;

			case	TC_INT_CARRY_FWD_POS_REQ:
				iRetVal = fClientCarryFwdPosition(&RcvMsg);		
				break;
				/***
				  case	TC_INT_CONVT_TO_DELV_REQ:
				//iRetVal = fClientConvetToDel(&RcvMsg);		
				iRetVal = fGetConvetToDel(&RcvMsg);		
				break;
				 ***/

			case	TC_INT_ADMIN_CONVT_TO_DELV_REQ:
				iRetVal = fSurvillenceConvetToDel(&RcvMsg);		
				break;
				/***
				  case	TC_INT_SEND_MSG_TO_CLIENT_REQ:
				  iRetVal = fSendMsgtoClient(&RcvMsg);		
				  break;
				 ********/

			/**/			case	TC_INT_DNLD_SYSTEM_MSG_REQ:   
				iRetVal = fDNLDSystemMsg(&RcvMsg);		
				break;
				/*			commented by Nishant
				 */


			case     TC_INT_REJECTED_ORDERS_REQ :

				iRetVal = fRejectedOrders(&RcvMsg);
				break;

			case    TC_INT_DEA_CLIENT_MAPP_REQ :
				iRetVal = fDeaClientMapp(&RcvMsg);
				break;


			default :
				logFatal(" Invalid Transcode :%d:",iMsgCode);
				iRetVal = FALSE;
				break;



		} /*** END of Switch****/


	}/** End of While**/

}

BOOL OpenMessgQ()
{

	if( ( iSTWRelToQueryQ = OpenMsgQ( (RelToQuery))) == ERROR )
	{
		perror("Open RelToQuery :");
		exit( 1 );
	}
	if( ( iIntActiveToRelDirQ = OpenMsgQ( (OrdSrvToTrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	/*****	 if( ( iTrdRout2SurvlMapperQ = OpenMsgQ( (TrdRout2SurvlMapperQ))) == ERROR )
	  {
	  perror("Open DWSRelayToMapper :");
	  exit( 1 );
	  }
	 *********/
	return TRUE;

}/** End of OpenMsgQ**/
/****
  SHORT   fAddSpace( CHAR * Str_In ,SHORT MaxLen )
  {
  OpenMessgQ();


  SHORT Strlen=0;

  it( 1 );
  ( MaxLen <= 0 )
  {
  return FALSE ;
  }

  for( ; Str_In[Strlen] != ' '  && Strlen < MaxLen ; Strlen++ )
  {
  continue;
  }
  Str_In[Strlen]='\0';
  return Strlen  ;
  }
 ****/
BOOL fViewClientLimitNEW(CHAR *RcvMsg)
{
	struct  VIEW_COMMON_QUERY_REQ   *pViewLimitReq;
	struct	VIEW_CLIENT_LIMIT_RESP_NEW	pViewLimitResp    ;

	LONG32 iErrorId=0,i=0,j=0;
	CHAR         sClientId[ENTITY_ID_LEN];
	DOUBLE64        fLimitSOD;
	DOUBLE64        fAdhocLimit;
	DOUBLE64        fReceivables;
	DOUBLE64        fBankHoldings;
	DOUBLE64        fCollaterals;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fAmountUtilised;
	DOUBLE64        fSumofAll;
	DOUBLE64        fAvailableBal;
	DOUBLE64	fClearBalance;
	CHAR		sLimitType[10];
	pViewLimitReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	MYSQL_RES 	*Res;
	MYSQL_ROW	Row;
	CHAR *sClntLmt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	memset(sClientId,'\0',ENTITY_ID_LEN);


	strncpy(sClientId,pViewLimitReq->sClientId,ENTITY_ID_LEN);

	logDebug1(" sClientId :%s:",sClientId);


	sprintf(sClntLmt,"SELECT LIMIT_SOD,ADHOC_LIMIT, RECEIVABLES, BANK_HOLDING, COLLATERALS,REALISED_PROFITS, AMOUNT_UTILIZED, SUM_OF_ALL,\
			AVAILABLE_BALANCE, ifnull(CLEAR_BALANCE,0), LIMIT_TYPE \
			FROM VIEW_CLIENT_LIMIT \
			WHERE CLIENT_ID = ltrim(trim(\"%s\"));	",sClientId);

	logDebug3(" fViewClientLimitNEW :%s:",sClntLmt);

	if((mysql_query(DBQueries,sClntLmt)) != SUCCESS)
	{
		logSqlFatal("ERROR IN view Client Limit Query.");
		sql_Error(DBQueries);
	}

	pViewLimitResp.IntRespHeader.iSeqNo = 0;
	pViewLimitResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_LIMIT_RESP_NEW);
	pViewLimitResp.IntRespHeader.iMsgCode = TC_INT_VIEW_CLIENT_LIMIT_RESP;
	pViewLimitResp.IntRespHeader.iErrorId = iErrorId;
	pViewLimitResp.IntRespHeader.iUserId = pViewLimitReq->ReqHeader.iUserId;
	//		pViewLimitResp.IntRespHeader.cUserTypeOrLogInfoType = 'C';
	strncpy(pViewLimitResp.sClientId,sClientId,ENTITY_ID_LEN);

	Res = mysql_store_result(DBQueries);


	//for(i=0;i<2;i++)
	while((Row = mysql_fetch_row(Res)))
	{

		pViewLimitResp.sSubViewClientlimit[i].fLimitSOD = atof(Row[0]);
		pViewLimitResp.sSubViewClientlimit[i].fAdhocLimit = atof(Row[1]);
		pViewLimitResp.sSubViewClientlimit[i].fReceivables = atof(Row[2]);
		pViewLimitResp.sSubViewClientlimit[i].fBankHoldings = atof(Row[3]);
		pViewLimitResp.sSubViewClientlimit[i].fCollaterals = atof(Row[4]);
		pViewLimitResp.sSubViewClientlimit[i].fRelaisedProfit = atof(Row[5]);
		pViewLimitResp.sSubViewClientlimit[i].fAmountUtilised = atof(Row[6]);
		pViewLimitResp.sSubViewClientlimit[i].fSumofAll = atof(Row[7]);
		pViewLimitResp.sSubViewClientlimit[i].fAvailableBal = atof(Row[8]);
		pViewLimitResp.sSubViewClientlimit[i].fClearBalance = atof(Row[9]);
		strncpy(pViewLimitResp.sSubViewClientlimit[i].sLimitType,Row[10],10);

		logDebug3(" pViewLimitResp.fLimitSOD:%lf:,pViewLimitResp.fAdhocLimit:%lf:,pViewLimitResp.fReceivables:%lf:,:%lf:,pViewLimitResp.fCollaterals:%lf:,pViewLimitResp.fRelaisedProfit:%lf:,pViewLimitResp.fAmountUtilised:%lf:,pViewLimitResp.fSumofAll:%lf:,pViewLimitResp.fAvailableBal:%lf:,pViewLimitResp.fClearBalance:%lf sLimitType :%s::",pViewLimitResp.sSubViewClientlimit[i].fLimitSOD,pViewLimitResp.sSubViewClientlimit[i].fAdhocLimit,pViewLimitResp.sSubViewClientlimit[i].fReceivables,pViewLimitResp.sSubViewClientlimit[i].fBankHoldings,pViewLimitResp.sSubViewClientlimit[i].fCollaterals,pViewLimitResp.sSubViewClientlimit[i].fRelaisedProfit,pViewLimitResp.sSubViewClientlimit[i].fAmountUtilised,pViewLimitResp.sSubViewClientlimit[i].fSumofAll,pViewLimitResp.sSubViewClientlimit[i].fAvailableBal,pViewLimitResp.sSubViewClientlimit[i].fClearBalance,pViewLimitResp.sSubViewClientlimit[i].sLimitType);
		i++;

	}/*** End of for loop ****/

	mysql_free_result(Res);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewLimitResp,sizeof(struct VIEW_CLIENT_LIMIT_RESP_NEW) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}



}/**** END Of fViewClientLimitNEW*****/




BOOL fViewNetPosition(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fViewNetPosition]");
	struct VIEW_COMMON_QUERY_REQ *pViewNetPosReq;
	struct VIEW_NET_POSITION_RESP pViewNetPosResp;
	struct VIEW_COMMON_HDR_RESP pViewNetPosHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR *sNetPstion = malloc (sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR		sClientId[CLIENT_ID_LEN];
	CHAR		sEntityId[ENTITY_ID_LEN];
	CHAR		sRespClientId[CLIENT_ID_LEN];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchId[EXCHANGE_LEN];
	DOUBLE64        fBuyQty;
	DOUBLE64        fBuyVal;
	DOUBLE64        fSellQty;
	DOUBLE64        fSellVal;
	DOUBLE64        fBuyAvg;
	DOUBLE64        fSellAvg;
	DOUBLE64        fNetQty;
	DOUBLE64        fNetVal;
	DOUBLE64        fNetAvg;
	DOUBLE64        fGrossQty;
	DOUBLE64        fGrossVal;
	CHAR         cMktType[MARKET_LEN];
	CHAR            cProductId;
	DOUBLE64        fLTP;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fMTM;
	LONG32		iNoOfRec=0;
	DOUBLE64	fNoOfRec;
	LONG32		iTempNoOfRec;
	LONG32		iNoOfPkt;
	CHAR            cSegment;

	memset(sClientId,'\0',CLIENT_ID_LEN);

	memset(sSecurityID,'\0',SECURITY_ID_LEN);

	memset(sExchId ,'\0',EXCHANGE_LEN);

	memset(cMktType ,'\0',MARKET_LEN);

	pViewNetPosReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewNetPosReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewNetPosReq->sEntityId,CLIENT_ID_LEN);

	logDebug2(" sClientId  :%s: , pViewNetPosReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewNetPosReq->sClientId,strlen(sClientId));
	logDebug2(" sEntityId  :%s: , pViewNetPosReq->sEntityId :%s: , sEntityId.len:%d:",sEntityId ,pViewNetPosReq->sEntityId,strlen(sEntityId));

	sprintf(sNetPstion,"SELECT SECURITY_ID, EXCH_ID,\
			TOT_BUY_QTY,\
			TOT_BUY_VAL,\
			BUY_AVG,\
			TOT_SELL_QTY,\
			TOT_SELL_VAL,\
			SELL_AVG,\
			NET_QTY,\
			NET_VAL,\
			NET_AVG,\
			GROSS_QTY,\
			GROSS_VAL,\
			PROD_ID,\
			REALISED_PROFIT,\
			SEGMNT,\
			CLIENT_ID\
			from VIEW_NET_POSITION_NON_I\
			WHERE CLIENT_ID = ltrim(rtrim(\"%s\"))\
			AND NOT ( GROSS_QTY = 0 AND REALISED_PROFIT = 0)\
			ORDER BY  SECURITY_ID asc;",sClientId);

	logDebug2(" fViewNetPosition :%s: ",sNetPstion);

	if(mysql_query(DBQueries,sNetPstion) != SUCCESS)
	{
		logSqlFatal("ERROR in VIEW net Position Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);


	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pViewNetPosHdrResp.IntRespHeader.iSeqNo = 0;
	pViewNetPosHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pViewNetPosHdrResp.IntRespHeader.iErrorId = 0;
	pViewNetPosHdrResp.IntRespHeader.iMsgCode = TC_INT_NET_POS_HDR_RESP;
	pViewNetPosHdrResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
	//                pViewNetPosHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewNetPosReq->ReqHeader.cUserType;

	pViewNetPosHdrResp.cMsgType = 'H';
	pViewNetPosHdrResp.iNoofRec = iNoOfRec;
	/*		pViewNetPosHdrResp.iNoofPkt = iNoOfPkt;*/

	logDebug2(" pViewNetPosHdrResp.cMsgType:%c:,pViewNetPosHdrResp.iNoofRec:%d:",pViewNetPosHdrResp.cMsgType,pViewNetPosHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewNetPosHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}





	logDebug2(" iNoOfPkt :%d:",iNoOfPkt);
	for(i=0;i<iNoOfPkt;i++)
	{

		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{

				strncpy(pViewNetPosResp.subnetpos[j].sSecurityID,Row[0],SECURITY_ID_LEN);
				strncpy(pViewNetPosResp.subnetpos[j].sExchId,Row[1],EXCHANGE_LEN);
				//	strncpy(pViewNetPosResp.subnetpos[j].cMktType,Row[2],EXCHANGE_LEN);
				logDebug2("[%s][%f]",Row[4],atof(Row[4]));

				pViewNetPosResp.subnetpos[j].fBuyQty = atof(Row[2]);
				pViewNetPosResp.subnetpos[j].fBuyVal = atof(Row[3]);
				pViewNetPosResp.subnetpos[j].fBuyAvg = atof(Row[4]);
				pViewNetPosResp.subnetpos[j].fSellQty = atof(Row[5]);
				pViewNetPosResp.subnetpos[j].fSellVal = atof(Row[6]);
				pViewNetPosResp.subnetpos[j].fSellAvg = atof(Row[7]);
				pViewNetPosResp.subnetpos[j].fNetQty = atof(Row[8]);
				pViewNetPosResp.subnetpos[j].fNetVal = atof(Row[9]);
				pViewNetPosResp.subnetpos[j].fNetAvg = atof(Row[10]);
				pViewNetPosResp.subnetpos[j].fGrossQty = atof(Row[11]);
				pViewNetPosResp.subnetpos[j].fGrossVal = atof(Row[12]);
				pViewNetPosResp.subnetpos[j].cProductId = Row[13][0];
				//	pViewNetPosResp.subnetpos[j].fLTP = atof(Row[16]);
				pViewNetPosResp.subnetpos[j].fRelaisedProfit = atof(Row[14]);
				//				pViewNetPosResp.subnetpos[j].fMTM = atof(Row[18]);
				pViewNetPosResp.subnetpos[j].cSegment = Row[15][0];
				strncpy(pViewNetPosResp.subnetpos[j].sClientId,Row[16],CLIENT_ID_LEN);

				pViewNetPosResp.IntRespHeader.iSeqNo = 0;
				pViewNetPosResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_NET_POSITION_RESP);
				pViewNetPosResp.IntRespHeader.iErrorId = 0;
				pViewNetPosResp.IntRespHeader.iMsgCode = TC_INT_NET_POS_RESP;
				pViewNetPosResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
				//				pViewNetPosResp.IntRespHeader.cUserTypeOrLogInfoType = pViewNetPosReq->ReqHeader.cUserType;

				if(iTempNoOfRec <= 1)
				{
					pViewNetPosResp.cMsgType = 'T';
				}
				else
				{
					pViewNetPosResp.cMsgType = 'D';
				}
				logDebug3(" pViewNetPosResp.cMsgType :%c: iTempNoOfRec:%d:",pViewNetPosResp.cMsgType,iTempNoOfRec);
				logDebug3(" pViewNetPosResp.subnetpos[j].sSecurityID :%s:",pViewNetPosResp.subnetpos[j].sSecurityID);
				logDebug3(" pViewNetPosResp.subnetpos[j].fBuyAvg :%lf:",pViewNetPosResp.subnetpos[j].fBuyAvg);
				logDebug3(" pViewNetPosResp.subnetpos[j].fSellAvg:%lf:",pViewNetPosResp.subnetpos[j].fSellAvg);
				logDebug3("pViewNetPosResp.subnetpos[j].sExchId:%s:",pViewNetPosResp.subnetpos[j].sExchId);
				logDebug3("pViewNetPosResp.subnetpos[j].fBuyQty:%lf:",pViewNetPosResp.subnetpos[j].fBuyQty);

				logDebug3(" pViewNetPosResp.subnetpos[j].fBuyVal:%lf:",pViewNetPosResp.subnetpos[j].fBuyVal);
				logDebug3("pViewNetPosResp.subnetpos[j].fSellQty:%lf:",pViewNetPosResp.subnetpos[j].fSellQty);
				logDebug3("pViewNetPosResp.subnetpos[j].fSellVal:%lf:",pViewNetPosResp.subnetpos[j].fSellVal);
				logDebug3("pViewNetPosResp.subnetpos[j].fNetQty:%lf:",pViewNetPosResp.subnetpos[j].fNetQty);
				logDebug3("pViewNetPosResp.subnetpos[j].fNetVal:%lf:",pViewNetPosResp.subnetpos[j].fNetVal);
				logDebug3("pViewNetPosResp.subnetpos[j].fNetAvg:%lf:",pViewNetPosResp.subnetpos[j].fNetAvg);
				logDebug3("pViewNetPosResp.subnetpos[j].fGrossQty:%lf:",pViewNetPosResp.subnetpos[j].fGrossQty);
				logDebug3("pViewNetPosResp.subnetpos[j].fGrossVal:%lf:",pViewNetPosResp.subnetpos[j].fGrossVal);
				logDebug3("pViewNetPosResp.subnetpos[j].cProductId:%c:",pViewNetPosResp.subnetpos[j].cProductId);
				logDebug3("pViewNetPosResp.subnetpos[j].fRelaisedProfit:%lf:",pViewNetPosResp.subnetpos[j].fRelaisedProfit);
				logDebug3("pViewNetPosResp.subnetpos[j].cSegment:%c:",pViewNetPosResp.subnetpos[j].cSegment);
				logDebug3("pViewNetPosResp.subnetpos[j].sClientId:%s:",pViewNetPosResp.subnetpos[j].sClientId);



			}


			iTempNoOfRec--;
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewNetPosResp,sizeof(struct VIEW_NET_POSITION_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


	}	

	logTimestamp(" EXIT [fViewNetPosition]");

	return TRUE;

}/********* END of fViewNetPosition*****/
BOOL fOrderBook(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP     pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR         	sBuySellInd[5];
	CHAR         	sSecurityID[SECURITY_ID_LEN];
	CHAR          	sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;


	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR         	sProduct[10];
	CHAR         	sValidity[5];
	CHAR         	sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         	sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         	sClientId[CLIENT_ID_LEN];
	CHAR         	sRespClientId[CLIENT_ID_LEN];
	CHAR         	sEntityId[ENTITY_ID_LEN];
	CHAR         	ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32		iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;	
	LONG32		iOrderBookTime;


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("  client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);


	sprintf(sOrdBook,"SELECT  ORDER_NUMBER,\
			SERIALNO,\
			SEM_SECURITY_ID,\
			ORDER_TYPE,\
			QUANTITY,\
			REMAINING_QUANTITY,\
			DISCLOSE_QTY,\
			DQQTYREM,\
			ORDER_PRICE,\
			TRG_PRICE,\
			TRADEDQTY,\
			PRODUCT,\
			ORDER_VALIDITY,\
			EXCHORDERNO,\
			date_format(ORDER_DATE_TIME,\'%%d-%%m-%%Y  %%r'),\
			EXCH,\
			BUY_SELL,\
			SEGMENT,\
			TRANSCODE,\
			CLIENT_ID,\
			JULIDATE(ORDER_DATE_TIME),\
			STRATEGY_ID,\
			PLACEDBY,\
			REASON_DESCRIPTION,\
			PRO_CLIENT,\
			TRADE_PRICE,\
			GOOD_TILL_DATE ,\
			LEGVALUE \
			FROM  ORDERBOOK  WHERE  CLIENT_ID  = ltrim(rtrim(\"%s\"))ORDER BY ORDER_DATE_TIME DESC;",sClientId );

	logDebug3(" fOrderBook :%s:",sOrdBook);

	if(mysql_query(DBQueries,sOrdBook ) != SUCCESS)
	{
		logSqlFatal("ERROR in Order BOOK Query.");
		sql_Error(DBQueries);
	}


	Res = mysql_store_result(DBQueries);	
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	//	pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug1(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);




	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{	
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = 0;
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				//                		pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;



				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbook[j].fOrderNo =atof(Row[0]); 
				pOrderBookResp.suborderbook[j].iSerialNo =atoi(Row[1]); 
				strncpy(pOrderBookResp.suborderbook[j].sSecurityID,Row[2] ,SECURITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sOrderType,Row[3],8);
				pOrderBookResp.suborderbook[j].fQty = atof(Row[4]);
				pOrderBookResp.suborderbook[j].fRemQty = atof(Row[5]);
				pOrderBookResp.suborderbook[j].fDQQty = atof(Row[6]);
				pOrderBookResp.suborderbook[j].fDQQtyRem = atof(Row[7]);
				pOrderBookResp.suborderbook[j].fPrice = atof(Row[8]);
				pOrderBookResp.suborderbook[j].fTrgPrice = atof(Row[9]);
				pOrderBookResp.suborderbook[j].fTradeQty = atof(Row[10]);
				strncpy(pOrderBookResp.suborderbook[j].sProduct,Row[11],10);
				strncpy(pOrderBookResp.suborderbook[j].sValidity,Row[12],5);
				strncpy(pOrderBookResp.suborderbook[j].sExchOrderNumber,Row[13],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sDatetime,Row[14],DATE_LENGTH);
				strncpy(pOrderBookResp.suborderbook[j].sExcgId,Row[15],EXCHANGE_LEN);
				memset(pOrderBookResp.suborderbook[j].sBuySellInd,'\0',5);
				strncpy(pOrderBookResp.suborderbook[j].sBuySellInd,Row[16],5);
				pOrderBookResp.suborderbook[j].cSegment = Row[17][0];
				pOrderBookResp.suborderbook[j].iTranscode = atoi(Row[18]);

				strncpy(pOrderBookResp.suborderbook[j].sClientId,Row[19],CLIENT_ID_LEN);

				pOrderBookResp.suborderbook[j].iDateTime = atoi(Row[20]);


				pOrderBookResp.suborderbook[j].iStrategyId = atoi(Row[21]);
				strncpy(pOrderBookResp.suborderbook[j].sEntityId , Row[22],ENTITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sReasonDesc, Row[23],DB_REASON_DESC_LEN);
				pOrderBookResp.suborderbook[j].cProClient =  Row[24][0];
				pOrderBookResp.suborderbook[j].fTrdPrice  = atof(Row[25]);
				strncpy(pOrderBookResp.suborderbook[j].sGoodTillDaysDate, Row[26],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sLegValue,Row[27],LEG_LEN);
				//				pOrderBookHdrResp.IntRespHeader.iErrorId = atoi (Row[27]);

				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pOrderBookResp.IntRespHeader.iMsgLength :%d:",pOrderBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pOrderBookResp.IntRespHeader.iUserId:%d:",pOrderBookResp.IntRespHeader.iUserId);
				//				logDebug2(" pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType);

				logInfo(" -----------------Printing VALUES ------------------------------------");
				logDebug2(" pOrderBookResp.suborderbook[%i].sExcgId :%s: strlen(pOrderBookResp.suborderbook[j].sExcgId):%d:",pOrderBookResp.suborderbook[j].sExcgId,strlen(pOrderBookResp.suborderbook[j].sExcgId));
				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" pOrderBookResp.suborderbook[%i]].fOrderNo :%lf:",pOrderBookResp.suborderbook[j].fOrderNo);
				logDebug2(" pOrderBookResp.suborderbook[%i].fPrice :%lf:",pOrderBookResp.suborderbook[j].fPrice);
				logDebug2(" pOrderBookResp.suborderbook[%i].iSerialNo:%d:",pOrderBookResp.suborderbook[j].iSerialNo);
				logDebug2(" pOrderBookResp.suborderbook[%i].iTranscode:%d:",pOrderBookResp.suborderbook[j].iTranscode);
				logDebug2(" pOrderBookResp.suborderbook[%i].sBuySellInd:%s: strlen(pOrderBookResp.suborderbook.sBuySellInd):%d:",pOrderBookResp.suborderbook[j].sBuySellInd,strlen(pOrderBookResp.suborderbook[j].sBuySellInd));
				logDebug2(" pOrderBookResp.suborderbook.sSecurityID:%s: strlen(pOrderBookResp.suborderbook.sSecurityID):%d:",pOrderBookResp.suborderbook[j].sSecurityID,strlen(pOrderBookResp.suborderbook[j].sSecurityID));
				logDebug2(" pOrderBookResp.suborderbook.sOrderType :%s: strlen(pOrderBookResp.suborderbook.sOrderType):%d:",pOrderBookResp.suborderbook[j].sOrderType,strlen(pOrderBookResp.suborderbook[j].sOrderType));
				logDebug2(" pOrderBookResp.suborderbook.sProduct:%s: strlen(pOrderBookResp.suborderbook.sProduct):%d:",pOrderBookResp.suborderbook[j].sProduct,strlen(pOrderBookResp.suborderbook[j].sProduct));
				logDebug2(" pOrderBookResp.suborderbook.sValidity:%s: strlen(pOrderBookResp.suborderbook.sValidity):%d:",pOrderBookResp.suborderbook[j].sValidity,strlen(pOrderBookResp.suborderbook[j].sValidity));
				logDebug2(" pOrderBookResp.suborderbook.sDatetime:%s: strlen(pOrderBookResp.suborderbook.sDatetime):%d:",pOrderBookResp.suborderbook[j].sDatetime,strlen(pOrderBookResp.suborderbook[j].sDatetime));
				logDebug2(" pOrderBookResp.suborderbook[%i].cSegment :%c:",pOrderBookResp.suborderbook[j].cSegment);
				logDebug2(" pOrderBookResp.suborderbook[%i].iDateTime :%d:",pOrderBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrderBookResp.suborderbook[%i].sEntityId :%s:",pOrderBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbook[%i].iStrategyId :%d:",pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("strncpy(pOrderBookResp.suborderbook[%i].sReasonDesc :%s:",pOrderBookResp.suborderbook[j].sReasonDesc);
						logDebug2("pOrderBookResp.suborderbook[%i].cProClient :%c: ",pOrderBookResp.suborderbook[j].cProClient);
						logDebug2("pOrderBookResp.suborderbook[%i].fTrdPrice :%f:",pOrderBookResp.suborderbook[j].fTrdPrice) ;
						logDebug2("pOrderBookResp.suborderbook[%i].sGoodTillDaysDate :%s:",pOrderBookResp.suborderbook[j].sGoodTillDaysDate);
						logDebug2("pOrderBookResp.suborderbook[j].sLegValue :%s:",pOrderBookResp.suborderbook[j].sLegValue);
						}
						iTempNoOfRec--;
						}

						usleep(100);
						if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_RESP) ,1 ) != TRUE ))
						{
						perror("Error WriteMsgQ: ");
						logFatal("Write Q id %d", iSTWRelToQueryQ);
						exit(ERROR);
						}
						usleep(100); /** This is done to give a slow response to the Rapid Rupee **/



						}

	logTimestamp("EXIT [fOrderBook]");
	return TRUE;


}/************** END of fOrderBook ****/
/************************************************/
BOOL fEquOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fEquOrderBookDtls]");
	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sEqOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 i=0,j=0;

	DOUBLE64        fReqOrderNo;
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR          sFlags[10];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR		sProduct;
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_TIME_LEN];
	LONG32          iEquNoOfRec;
	LONG32          iDrvNoOfRec;
	LONG32		iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	DOUBLE64        fTradePrice;
	LONG32          iTranscode;
	CHAR		cDayFlg;
	CHAR		cIOCFlg;
	CHAR		cMKTFlg;
	CHAR		cSTOPLOSSFlg;
	CHAR		cAONFlg;
	CHAR		cDQFlg;
	CHAR		cProCliFlg;
	CHAR		cSource;
	LONG32		iErrorId;
	CHAR         sBuySellInd[5];
	CHAR		sBuySellIndTemp;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	CHAR         sOrdReasonDesc[200];
	CHAR	cProdId ;


	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;


	fReqOrderNo = pViewOrderBookReq->fOrderNo;	

	logDebug2("pViewOrderBookReq->ReqHeader.cSegment:%c:",pViewOrderBookReq->ReqHeader.cSegment);
	logDebug2("ReqOrderNo :%lf:",fReqOrderNo);

	sprintf(sEqOrdBook,"SELECT  EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_MSG_CODE,\
			EQ_SCRIP_CODE,\
			EQ_VALIDITY,\
			EQ_PRO_CLIENT,\
			EQ_SOURCE_FLG,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_LAST_TRADE_QTY,\
			EQ_TRD_TRADE_PRICE,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_TRD_EXCH_TRADE_NO,\
			EQ_PRODUCT_ID,\
			EQ_EXCH_ORDER_NO,\
			date_format(EQ_INTERNAL_ENTRY_DATE,\'%%d-%%m-%%Y %%r\'),\
			EQ_ERROR_CODE,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_EXCH_ID,\
			EQ_REASON_DESCRIPTION ,\
			EQ_ENTITY_ID ,\
			EQ_STRATEGY_ID ,\
			EQ_PRO_CLIENT ,\
			EQ_TRD_TRADE_PRICE ,\
			EQ_GOOD_TILL_DAYS ,\
			EQ_LEG_NO \
			FROM EQ_ORDERS \
			WHERE EQ_ORDER_NO = %lf \
			ORDER BY EQ_ORDER_NO , EQ_SERIAL_NO desc ;",fReqOrderNo);

	logDebug3(" fEquOrderBookDtls :%s:",sEqOrdBook);

	if(mysql_query(DBQueries,sEqOrdBook) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	//		pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	logInfo(" I am in Equity");	


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				memset(sOrdReasonDesc,'\0',200);
				//				memset(cProdId,'\0',2);

				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				iErrorId = atoi(Row[24]);
				logDebug2("atoi(Row[24]) :%d: iErrorId :%d:",atoi(Row[24]),iErrorId);
				pOrderBookResp.IntRespHeader.iErrorId = iErrorId;
				logDebug2("pOrderBookResp.IntRespHeader.iErrorId :%d: iErrorId :%d:",pOrderBookResp.IntRespHeader.iErrorId,iErrorId);

				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				//                		pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);


				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}


				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);


				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo	  =atoi(Row[16]);

				cProdId =  Row[17][0];
				pOrderBookResp.suborderbookdtls[j].sProduct =  Row[17][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18],BSE_EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_TIME_LEN);
				//pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[20]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21],CLIENT_ID_LEN);
				if(Row[22][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}



				if(strlen(Row[24]) != 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[24],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]); 
				pOrderBookResp.suborderbookdtls[j].cProClient	= Row[27][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice	= atof(Row[28]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sLegValue,Row[30],LEG_LEN);



				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s: ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("pOrderBookResp.suborderbookdtls[j].sEntityId :%s:",pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[j].iStrategyId :%d:",pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[j].cProClient :%c:",pOrderBookResp.suborderbookdtls[j].cProClient );
				//logDebug2("pOrderBookResp.suborderbookdtls[j].fTrdPrice  :%f:",pOrderBookResp.suborderbookdtls[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate :%s:",pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[j].sLegValue:%s:",pOrderBookResp.suborderbookdtls[j].sLegValue);
			}

			iTempNoOfRec--;
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


	}


	logTimestamp("EXIT [fEquOrderBookDtls]");
	return TRUE;


}/************** END of fOrderBook ****/
BOOL fTradeBook(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR *sTrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;




	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);


	sprintf(sTrdBook,"SELECT  ORDER_NUMBER,\
			SEM_SMST_SECURITY_ID,\
			BUY_SELL,\
			ORDER_TYPE,\
			EXCH_ORDER_NUMBER,\
			TRADE_NUMBER,\
			PRODUCT,\
			QUANTITY,\
			PRICE,\
			TRADE_VALUE,\
			date_format(str_to_date(ORDER_DATE_TIME,\'%%d-%%m-%%Y %%r\'),\'%%Y-%%m-%%d %%H:%%i:%%S\') as ORDER_DATE_TIME,\
			EXCHANGE,\
			SEGMENT,\
			CLIENT_ID,\
			julidate(date_format(str_to_date(ORDER_DATE_TIME,\'%%d-%%m-%%Y %%r\'),\'%%Y-%%m-%%d %%H:%%i:%%S\')),	\
			PLACEDBY ,\
			STRATEGY_ID, \					
			LEGVALUE \
			FROM TRADEBOOK\
			WHERE\
			CLIENT_ID = ltrim(rtrim(\"%s\"))\
			ORDER BY ORDER_DATE_TIME DESC;",sClientId);

	logDebug2(" fTradeBook :%s:",sTrdBook);


	if(mysql_query(DBQueries,sTrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in Trade BOOK Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);


	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);

	logDebug2(" pTradeBookHdrResp.IntRespHeader.iMsgLength :%d:",pTradeBookHdrResp.IntRespHeader.iMsgLength);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.iMsgLength :%d:",pTradeBookHdrResp.IntRespHeader.iMsgLength);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.iMsgCode	:%d:",pTradeBookHdrResp.IntRespHeader.iMsgCode);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.iUserId :%d:",pTradeBookHdrResp.IntRespHeader.iUserId);



	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}



	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pTradeBookResp,'\0',sizeof(struct VIEW_TRADE_BOOK_RESP) );
		for(j=0;j<5;j++)
		{
			logInfo(" Here is j :%d:",j);

			if((Row = mysql_fetch_row(Res)))
			{



				pTradeBookResp.IntRespHeader.iSeqNo = 0;
				pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
				pTradeBookResp.IntRespHeader.iErrorId = 0;
				pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_RESP;
				pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
				//                		pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;
				logDebug2(" Is this core :%c: :%s:",Row[12][0],Row[11]);
				//pTradeBookResp.IntRespHeader.cSegment = Row[12][0];
				//strncpy(pTradeBookResp.IntRespHeader.sExcgId,Row[11],EXCHANGE_LEN);


				if(iTempNoOfRec <= 1)
				{
					pTradeBookResp.cMsgType = 'T';
				}
				else
				{
					pTradeBookResp.cMsgType = 'D';
				}

				pTradeBookResp.subTradeBook[j].fOrderNo = atof(Row[0]); 
				strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,Row[1] ,SECURITY_ID_LEN);
				memset(pTradeBookResp.subTradeBook[j].sBuySellInd,'\0',5);
				strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,Row[2],5);
				strncpy(pTradeBookResp.subTradeBook[j].sOrderType,Row[3] ,8);
				strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,Row[4],BSE_EXCH_ORDER_NO_LEN);
				pTradeBookResp.subTradeBook[j].fTradeNo = atof(Row[5]);
				strncpy(pTradeBookResp.subTradeBook[j].sProduct,Row[6],10);
				pTradeBookResp.subTradeBook[j].fTradeQty = atof(Row[7]);
				pTradeBookResp.subTradeBook[j].fTradePrice = atof(Row[8]);
				pTradeBookResp.subTradeBook[j].fTradeVal = atof(Row[9]);
				strncpy(pTradeBookResp.subTradeBook[j].sDatetime,Row[10],DATE_LENGTH);


				strncpy(pTradeBookResp.subTradeBook[j].sExcgId,Row[11],EXCHANGE_LEN);
				pTradeBookResp.subTradeBook[j].cSegment = Row[12][0];
				strncpy(pTradeBookResp.subTradeBook[j].sClientId,Row[13],CLIENT_ID_LEN);

				pTradeBookResp.subTradeBook[j].iDateTime = atol(Row[14]);
				strncpy(pTradeBookResp.subTradeBook[j].sEntityId,Row[15],ENTITY_ID_LEN);
				pTradeBookResp.subTradeBook[j].iStrategyId = atoi (Row[16]);
				strncpy(pTradeBookResp.subTradeBook[j].sLegValue,Row[17],LEG_LEN);


				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%d:",pTradeBookResp.IntRespHeader.iUserId);
				//				logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
				logDebug2(" pTradeBookResp.subTradeBook[j].sExcgId :%s: strlen(pTradeBookResp.subTradeBook[j].sExcgId):%d:",pTradeBookResp.subTradeBook[j].sExcgId,strlen(pTradeBookResp.subTradeBook[j].sExcgId));
				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
				logDebug2(" pTradeBookResp.subTradeBook[j].fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
				logDebug2(" pTradeBookResp.subTradeBoo[j]k.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook[j].sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
				logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
				logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
				logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
				logDebug2(" pTradeBookResp.subTradeBook..sExchOrderNumber:%s: strlen(pTradeBookResp.subTradeBook..sExchOrderNumber):%d:",pTradeBookResp.subTradeBook[j].sExchOrderNumber,strlen(pTradeBookResp.subTradeBook[j].sExchOrderNumber));
				logDebug2(" pTradeBookResp.subTradeBook.fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);
				logDebug2(" pTradeBookResp.subTradeBook[j].fTradeNo :%lf:",pTradeBookResp.subTradeBook[j].fTradeNo);
				logDebug2(" pTradeBookResp.subTradeBook.sDatetime :%s:",pTradeBookResp.subTradeBook[j].sDatetime);
				logDebug2(" pTradeBookResp.subTradeBook.iDateTime :%d:",pTradeBookResp.subTradeBook[j].iDateTime);
				logDebug2("pTradeBookResp.subTradeBook[j].sEntityId :%s:",pTradeBookResp.subTradeBook[j].sEntityId);
				logDebug2("pTradeBookResp.subTradeBook[j].iStrategyId :%d:",pTradeBookResp.subTradeBook[j].iStrategyId);
				logDebug2("pTradeBookResp.subTradeBook[j].sLegValue :%s:",pTradeBookResp.subTradeBook[j].sLegValue);
			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/



	}
	free(sTrdBook);	

	return TRUE;

}/************** END of fTradeBook ****/
BOOL fClientHoldings(CHAR *RcvMsg)
{

	struct VIEW_COMMON_QUERY_REQ *pViewClientHoldingReq;
	struct VIEW_CLIENT_HOLDINGS_RESP     pClientHoldingResp;
	struct VIEW_COMMON_HDR_RESP     pClientHoldingHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sCliHlding = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR		sSecurityID[SECURITY_ID_LEN];
	CHAR		sSymbol[SECURITY_ID_LEN];
	CHAR		sISINCode[15];
	CHAR		sSecuritySource[5];
	LONG32		iQty;
	LONG32		iQtyUtilized;
	LONG32		iRemQty;
	CHAR		sExcgId[EXCHANGE_LEN];
	CHAR		sClientId[CLIENT_ID_LEN];
	LONG32		iNoOfRec=0;
	LONG32		iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;

	pViewClientHoldingReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewClientHoldingReq->sClientId,CLIENT_ID_LEN);
	logDebug2(" sClientId  is :%s: ",sClientId );

	/***  SELECT  count(1)
INTO :iNoOfRec
from VIEW_CLIENT_HOLDINGS
WHERE CLIENT_ID = ltrim(rtrim(:sClientId));******/

	sprintf(sCliHlding,"SELECT  SECURITY_ID,\
			EXCH,\
			ISIN_CODE,\
			SECURITY_SOURCE_TYPE,\
			QTY,\
			QTY_UTILIZED,\
			REM_QTY,\
			SYMBOL\
			FROM VIEW_CLIENT_HOLDINGS \
			WHERE CLIENT_ID = LTRIM(RTRIM(\'%s\'))",sClientId);

	logDebug2(" fClientHoldings :%s:",sCliHlding);

	if(mysql_query(DBQueries,sCliHlding) != SUCCESS)
	{
		logSqlFatal("ERROR in client Holding Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);


	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pClientHoldingHdrResp.IntRespHeader.iSeqNo = 0;
	pClientHoldingHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pClientHoldingHdrResp.IntRespHeader.iErrorId = 0;
	pClientHoldingHdrResp.IntRespHeader.iMsgCode = TC_INT_CLINET_HOLDING_HEADER_RESP;
	pClientHoldingHdrResp.IntRespHeader.iUserId = pViewClientHoldingReq->ReqHeader.iUserId;
	//		pClientHoldingHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewClientHoldingReq->ReqHeader.cUserType;

	pClientHoldingHdrResp.cMsgType = 'H';
	pClientHoldingHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pClientHoldingHdrResp.cMsgType:%c:,pClientHoldingHdrResp.iNoofRec:%d:",pClientHoldingHdrResp.cMsgType,pClientHoldingHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pClientHoldingHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}


	for(i=0;i<iNoOfPkt;i++)
	{			
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{


				pClientHoldingResp.IntRespHeader.iSeqNo = 0;
				pClientHoldingResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_HOLDINGS_RESP);
				pClientHoldingResp.IntRespHeader.iErrorId = 0;
				pClientHoldingResp.IntRespHeader.iMsgCode = TC_INT_CLINET_HOLDING_RESP;
				pClientHoldingResp.IntRespHeader.iUserId = pViewClientHoldingReq->ReqHeader.iUserId;
				//				pClientHoldingResp.IntRespHeader.cUserTypeOrLogInfoType = pViewClientHoldingReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pClientHoldingResp.cMsgType = 'T';
				}
				else
				{
					pClientHoldingResp.cMsgType = 'D';
				}

				strncpy(pClientHoldingResp.subClientHoldings[j].sISINCode,Row[2],15);
				strncpy(pClientHoldingResp.sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sSecurityID,Row[0],SECURITY_ID_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sSymbol,Row[7],SECURITY_ID_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sSecuritySource,Row[3],5);
				pClientHoldingResp.subClientHoldings[j].iQty = atoi(Row[4]);
				pClientHoldingResp.subClientHoldings[j].iQtyUtilized = atoi(Row[5]);
				pClientHoldingResp.subClientHoldings[j].iRemQty = atoi(Row[6]);
				strncpy(pClientHoldingResp.subClientHoldings[j].sExcgId,Row[1],EXCHANGE_LEN);


				logDebug2(" pClientHoldingResp.subClientHoldings[j].sExcgId :%s:",pClientHoldingResp.subClientHoldings[j].sExcgId);
				logDebug2(" pClientHoldingResp.sClientId:%s: pClientHoldingResp.subClientHoldings.sSecurityID:%s: pClientHoldingResp.subClientHoldings.sISINCode:%s: pClientHoldingResp.subClientHoldings.sSecuritySource:%s: pClientHoldingResp.subClientHoldings.iQty:%d: pClientHoldingResp.subClientHoldings.iQtyUtilized:%d: pClientHoldingResp.subClientHoldings.iRemQty:%d: pClientHoldingResp.cMsgType:%c: ", pClientHoldingResp.sClientId,pClientHoldingResp.subClientHoldings[j].sSecurityID,pClientHoldingResp.subClientHoldings[j].sISINCode,pClientHoldingResp.subClientHoldings[j].sSecuritySource,pClientHoldingResp.subClientHoldings[j].iQty,pClientHoldingResp.subClientHoldings[j].iQtyUtilized,pClientHoldingResp.subClientHoldings[j].iRemQty,pClientHoldingResp.cMsgType);

			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pClientHoldingResp,sizeof(struct VIEW_CLIENT_HOLDINGS_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}




	}

	free(sCliHlding);



	return TRUE;

}/** End of View Client Holdings***/
/**/
BOOL fNetPositionDetail(CHAR *RcvMsg)
{
	struct VIEW_NET_POSITION_DATA_DETAIL *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP     pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP     pTradeBookHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sNetPostion = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sReqSecurityID[SECURITY_ID_LEN];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR         sReqExcgId[EXCHANGE_LEN];
	SHORT         	iReqExcgId;
	CHAR            Segment;
	CHAR            cReqSegment;
	CHAR            cProductID;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;




	pViewTradeBookReq = (struct VIEW_NET_POSITION_DATA_DETAIL *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->commonquery.sClientId,CLIENT_ID_LEN);

	//	iReqExcgId = pViewTradeBookReq->commonquery.ReqHeader.iExchange;
	strncpy(sReqExcgId ,pViewTradeBookReq->commonquery.ReqHeader.sExcgId,EXCHANGE_LEN);

	strncpy(sReqSecurityID ,pViewTradeBookReq->sSecurityID,SECURITY_ID_LEN);

	cProductID = pViewTradeBookReq->cProductID;

	/***
	  if(iReqExcgId == 1)
	  {
	  strncpy(sReqExcgId ,"NSE",EXCHANGE_LEN);
	  }
	  else if(iReqExcgId == 2)
	  {
	  strncpy(sReqExcgId ,"BSE",EXCHANGE_LEN);
	  }
	  else if(iReqExcgId == 3)
	  {
	  strncpy(sReqExcgId ,"MCX",EXCHANGE_LEN);
	  }
	 ***/	


	logDebug2(" pViewTradeBookReq->sSecurityID :%s:pViewTradeBookReq->cProductID:%c: sClientId:%s: sReqExcgId :%s: sReqSecurityID.len ", pViewTradeBookReq->sSecurityID,pViewTradeBookReq->cProductID,sClientId ,sReqExcgId );

	/****
	  SELECT  count(1)
INTO :iNoOfRec
from TRADEBOOK
WHERE CLIENT_ID = ltrim(rtrim(:sClientId))
AND EXCHANGE = ltrim(rtrim(:sReqExcgId))
AND SEM_SMST_SECURITY_ID = ltrim(rtrim(:sReqSecurityID))
AND TRD_PRODUCT = :cProductID;
	 *********/

	logDebug2(" sClientId :%s: sReqExcgId :%s: sReqSecurityID:%s: cProductID:%c:",sClientId ,sReqExcgId,sReqSecurityID ,cProductID);

	sprintf(sNetPostion,"SELECT  ORDER_NUMBER,\
			SEM_SMST_SECURITY_ID,\
			BUY_SELL,\
			ORDER_TYPE,\
			EXCH_ORDER_NUMBER,\
			TRADE_NUMBER,\
			PRODUCT,\
			QUANTITY,\
			PRICE,\
			TRADE_VALUE,\
			date_format(str_to_date(ORDER_DATE_TIME,\'%%d-%%m-%%Y %%r\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
			EXCHANGE,\
			SEGMENT,\
			julidate(date_format(str_to_date(ORDER_DATE_TIME,\'%%d-%%m-%%Y %%r'),\'%%Y-%%m-%%d %%H:%%i:%%S\')),\
			LEGVALUE \
			FROM TRADEBOOK\
			WHERE CLIENT_ID = ltrim(rtrim(\"%s\"))\
			AND EXCHANGE = ltrim(rtrim(\"%s\"))\
			AND SEM_SMST_SECURITY_ID = ltrim(rtrim(\"%s\"))\
			AND TRD_PRODUCT = \'%c\' \
			ORDER BY ORDER_DATE_TIME DESC;",sClientId,sReqExcgId,sReqSecurityID,cProductID);	


			logDebug2(" sNetPostion :%s:",sNetPostion);

	if(mysql_query(DBQueries,sNetPostion) != SUCCESS)
	{
		logSqlFatal("ERROR IN Net Position Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_NETPOS_DTL_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->commonquery.ReqHeader.iUserId;
	//                pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->commonquery.ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{

				pTradeBookResp.IntRespHeader.iSeqNo = 0;
				pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
				pTradeBookResp.IntRespHeader.iErrorId = 0;
				pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_NETPOS_DTL_RESP;
				pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->commonquery.ReqHeader.iUserId;
				//                		pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->commonquery.ReqHeader.cUserType;
				logDebug2("  Segemetn :%c: Exch :%s:", Row[12][0], Row[11] );
				pTradeBookResp.IntRespHeader.cSegment = Row[12][0];
				strncpy(pTradeBookResp.IntRespHeader.sExcgId,Row[11],EXCHANGE_LEN);


				if(iTempNoOfRec <= 1)
				{
					pTradeBookResp.cMsgType = 'T';
				}
				else
				{
					pTradeBookResp.cMsgType = 'D';
				}

				pTradeBookResp.subTradeBook[j].fOrderNo = atof(Row[0]);
				strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sOrderType,Row[3],8);
				pTradeBookResp.subTradeBook[j].fTradeQty = atof(Row[7]);
				pTradeBookResp.subTradeBook[j].fTradePrice = atof(Row[8]);
				pTradeBookResp.subTradeBook[j].fTradeVal = atof(Row[9]);
				pTradeBookResp.subTradeBook[j].fTradeNo = atof(Row[5]);
				strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,Row[2],5);

				strncpy(pTradeBookResp.subTradeBook[j].sProduct,Row[6],10);
				strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,Row[4],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sDatetime,Row[10],DATE_LENGTH);
				strncpy(pTradeBookResp.subTradeBook[j].sClientId,sClientId ,CLIENT_ID_LEN);
				pTradeBookResp.subTradeBook[j].cSegment = Row[12][0];
				strncpy(pTradeBookResp.subTradeBook[j].sExcgId,Row[11],EXCHANGE_LEN);
				pTradeBookResp.subTradeBook[j].iDateTime = atol(Row[13]);
				strncpy(pTradeBookResp.subTradeBook[j].sLegValue,Row[14],LEG_LEN);


				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%d:",pTradeBookResp.IntRespHeader.iUserId);
				//                		logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
				logDebug2(" pTradeBookResp.IntRespHeader.sExcgId :%s: strlen(pTradeBookResp.IntRespHeader.sExcgId):%d:",pTradeBookResp.IntRespHeader.sExcgId,strlen(pTradeBookResp.IntRespHeader.sExcgId));
				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
				logDebug2(" pTradeBookResp.subTradeBook.fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
				logDebug2(" pTradeBookResp.subTradeBook.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook.sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
				logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
				logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
				logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
				logDebug2(" pTradeBookResp.subTradeBook[j].fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);
				logDebug2(" pTradeBookResp.subTradeBook[j].iDateTime :%d:",pTradeBookResp.subTradeBook[j].iDateTime);
				logDebug2(" pTradeBookResp.subTradeBook[j].sLegValue:%s:",pTradeBookResp.subTradeBook[j].sLegValue);

			}
			iTempNoOfRec--;
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}



	}

	free(sNetPostion);


	return TRUE;


}/** End of fNetPositionDetail **/
BOOL fDrvOrderBookDtls(CHAR *RcvMsg)
{
	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;

	LONG32 i=0,j=0;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sDrvOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	DOUBLE64        fReqOrderNo;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR		cOrdValidity;	

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;


	fReqOrderNo = pViewOrderBookReq->fOrderNo;	

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,fReqOrderNo);

	sprintf(sDrvOrdBook,"SELECT  DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_MSG_CODE,\
			DRV_SCRIP_CODE,\
			DRV_VALIDITY,\
			DRV_PRO_CLIENT,\
			DRV_SOURCE_FLG,\
			DRV_ORIG_CLORDID,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_TRD_TRADE_QTY,\
			DRV_TRD_TRADE_PRICE,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_TRD_EXCH_TRADE_NO,\
			DRV_PRODUCT_ID,\
			DRV_EXCH_ORDER_NO,\
			IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
			DRV_ERROR_CODE,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_EXCH_ID,\
			DRV_REASON_DESCRIPTION ,\
			DRV_ENTITY_ID ,\
			DRV_STRATEGY_ID ,\
			DRV_PRO_CLIENT ,\
			DRV_TRD_TRADE_PRICE ,\
			DRV_GOOD_TILL_DAYS \
			FROM DRV_ORDERS\
			WHERE DRV_ORDER_NO = %lf\
			ORDER BY DRV_ORDER_NO , DRV_SERIAL_NO desc ;",fReqOrderNo);

	logDebug2(" sDrvOrdBook :%s: ",sDrvOrdBook);

	if(mysql_query(DBQueries,sDrvOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in DrvOrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	//		pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	logInfo(" I am in Derivative");	


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{

			if(Row=mysql_fetch_row(Res))
			{

				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				//                		pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);


				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}


				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo	  =atoi(Row[17]);
				pOrderBookResp.suborderbookdtls[j].sProduct = Row[18][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

				if(strlen(Row[25])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				if(Row[23][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice    = atof(Row[29]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);



				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s:,ErrorID:%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);

				logDebug2("pOrderBookResp.suborderbookdtls[j].sEntityId :%s:",pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[j].iStrategyId :%d:",pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[j].cProClient :%c:",pOrderBookResp.suborderbookdtls[j].cProClient );
				//logDebug2("pOrderBookResp.suborderbookdtls[j].fTrdPrice  :%f:",pOrderBookResp.suborderbookdtls[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate :%s:",pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);

			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


	}


	return TRUE;


}/************** END of fOrderBook ****/
BOOL fCOMMOrderBookDtls(CHAR *RcvMsg)
{
	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;

	LONG32 i=0,j=0;

	DOUBLE64        fReqOrderNo;
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR          sFlags[10];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR		sProduct;
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_STRING_LENGTH];
	LONG32          iEquNoOfRec;
	LONG32          iDrvNoOfRec;
	LONG32		iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	DOUBLE64        fTradePrice;
	LONG32          iTranscode;
	CHAR		cDayFlg;
	CHAR		cIOCFlg;
	CHAR		cMKTFlg;
	CHAR		cSTOPLOSSFlg;
	CHAR		cAONFlg;
	CHAR		cDQFlg;
	CHAR		cProCliFlg;
	CHAR		cSource;
	LONG32		iErrorId;
	CHAR         sBuySellInd[5];
	CHAR		sBuySellIndTemp;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	CHAR		sOrdReasonDesc[200];


	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;


	fReqOrderNo = pViewOrderBookReq->fOrderNo;	

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,fReqOrderNo);


	/*****	SELECT  count(1)
INTO :iNoOfRec
from COMM_ORDERS
WHERE ORD_ORDER_NO = :fReqOrderNo;
	 ******/


	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	//		pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("\n pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	logDebug2("\n I am in Commodity");	
	/*******         SELECT  ORD_ORDER_NO,
	  ORD_SERIAL_NO,
	  ORD_TRANS_CODE,
	  ORD_SEM_SMST_SECURITY_ID,
	  ORD_DAY_FLG,
	  ORD_IOC_FLG,
	  ORD_MKT_FLG,
	  ORD_STOP_LOSS_FLG,
	  ORD_AON_FLG,
	  ORD_DISC_QTY_FLG,
	  ORD_PRO_CLIENT,
	  ORD_SOURCE_FLG,
	  ORD_QTY_ORIGINAL,
	  ORD_QTY_REMAINING,
	  ORD_QTY_DISC,
	  ORD_QTY_DISC_REMAINING,
	  ORD_ORDER_PRICE,
	  ORD_TRIGGER_PRICE,
	  ORD_TRD_TRADE_QTY,
	  ORD_TRD_TRADE_PRICE,
	  ORD_QTY_FILLED_TODAY,
	  ORD_TRD_EXCH_TRADE_NO,
	  ORD_PRODUCT_ID,
	  ORD_EXCH_ORDER_NO,
	  to_char(to_date(ORD_ORDER_TIME,'DD-MM-YYYY HH:MI:SS AM'),'DD-MM-YYYY HH:MI:SS AM'),
	  ORD_ERROR_CODE,
	  ORD_CLIENT_ID,
	  ORD_BUY_SELL_IND,
	  ORD_EXCH_ID,
	  ORD_REASON_DESCRIPTION
	  FROM COMM_ORDERS
	  WHERE ORD_ORDER_NO = :fReqOrderNo
	  ORDER BY ORD_ORDER_NO , ORD_SERIAL_NO desc ;
	 **********/



	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{

			fOrderNo=0;
			iSerialNo=0;
			fQty=0;
			fRemQty=0;
			fDQQty=0;
			fDQQtyRem=0;
			fTrgPrice=0;
			fTradeQty=0;


			memset(sBuySellInd ,'\0',5);

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);


			memset(sExchOrderNumber ,'\0',BSE_EXCH_ORDER_NO_LEN);

			memset(sDatetime ,'\0',DATE_STRING_LENGTH);

			memset(ExcgId ,'\0',EXCHANGE_LEN);

			memset(sOrdReasonDesc ,'\0',200);


			sProduct = '\0';


			Segment = '\0';	

			/**	:fOrderNo,
			  :iSerialNo,
			  :iTranscode,
			  :sSecurityID,
			  :cDayFlg,
			  :cIOCFlg,
			  :cMKTFlg,
			  :cSTOPLOSSFlg,
			  :cAONFlg,
			  :cDQFlg,
			  :cProCliFlg,
			  :cSource,
			  :fQty,
			  :fRemQty,
			  :fDQQty,
			  :fDQQtyRem,
			  :fPrice,
			  :fTrgPrice,
			  :fTradeQty,
			  :fTradePrice,
			  :fTotalTradeQty,
			  :iExchTradeNo,
			  :sProduct,
			  :sExchOrderNumber,
			  :sDatetime,
			  :iErrorId,
			  :sClientId,
			  :sBuySellIndTemp,
			  :ExcgId,
			  :sOrdReasonDesc;
			 ******/



			pOrderBookResp.IntRespHeader.iSeqNo = 0;
			pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
			pOrderBookResp.IntRespHeader.iErrorId = iErrorId;
			pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
			pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
			//                pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
			strncpy(pOrderBookResp.IntRespHeader.sExcgId,ExcgId ,EXCHANGE_LEN);


			if(iTempNoOfRec <= 1)
			{
				pOrderBookResp.cMsgType = 'T';
			}
			else
			{
				pOrderBookResp.cMsgType = 'D';
			}


			pOrderBookResp.suborderbookdtls[j].fOrderNo = fOrderNo;
			pOrderBookResp.suborderbookdtls[j].iSerialNo = iSerialNo;
			pOrderBookResp.suborderbookdtls[j].iTranscode = iTranscode;
			strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			pOrderBookResp.suborderbookdtls[j].sFlags[0] = cDayFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[1] = cIOCFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[2] = cMKTFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[3] = cSTOPLOSSFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[4] = cAONFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[5] = cDQFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[6] = cProCliFlg;
			pOrderBookResp.suborderbookdtls[j].sFlags[7] = cSource;

			pOrderBookResp.suborderbookdtls[j].fQty = fQty;
			pOrderBookResp.suborderbookdtls[j].fRemQty = fRemQty;
			pOrderBookResp.suborderbookdtls[j].fDQQty = fDQQty;
			pOrderBookResp.suborderbookdtls[j].fDQQtyRem = fDQQtyRem;
			pOrderBookResp.suborderbookdtls[j].fPrice = fPrice;
			pOrderBookResp.suborderbookdtls[j].fTradePrice = fTradePrice;
			pOrderBookResp.suborderbookdtls[j].fTrgPrice = fTrgPrice;
			pOrderBookResp.suborderbookdtls[j].fTradeQty = fTradeQty;
			pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = fTotalTradeQty;
			pOrderBookResp.suborderbookdtls[j].sProduct = sProduct;
			strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,sExchOrderNumber ,BSE_EXCH_ORDER_NO_LEN);
			strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,sDatetime ,DATE_STRING_LENGTH);
			strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,sClientId ,CLIENT_ID_LEN);
			strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,sOrdReasonDesc ,strlen(sOrdReasonDesc ));

			if(sBuySellIndTemp == 'B')
			{

				strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
			}
			else
			{

				strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
			}


			logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
			logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


	}


	return TRUE;


}/************** END of fOrderBook ****/
BOOL fGetOrderBook(CHAR *RcvMsg)
{
	logDebug2("ENTRY [fGetOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP     pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR		sUserType[3];
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sGetOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	memset(sEntityId ,'\0',ENTITY_ID_LEN);

	memset(sUserType ,'\0',3);


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);
	sprintf(sGetOrdBook,"SELECT  ENTITY_TYPE \ 
			from  ENTITY_MASTER \ 
			WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);

	logDebug2("Query[%s]",sGetOrdBook);

	/*** SELECT  em_entity_type
INTO :sUserType
from  entity_master em
WHERE em.em_entity_id = ltrim(rtrim(:sEntityId));
	 ******/

	if(mysql_query(DBQueries,sGetOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR IN  fGetOrderBook QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
	}


	logDebug2("USER TYPE is :%s:",sUserType );

	if(!strcmp(sUserType ,"D") && !strcmp(sClientId ,"-1"))
	{
		logDebug2("Going to call fDealerALLOrderBook");
		fDealerOrderBook(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"D" ) && strcmp(sClientId ,"-1"))
	{
		logDebug2("---- Going to call fOrderBook");
		fOrderBook(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("Going to call fClientOrderBook-----");
		fOrderBook(RcvMsg);
		return TRUE;

	}


	logDebug2("EXIT [fGetOrderBook]");
	return TRUE;

}/*** End of fGetOrderBook *****/
BOOL fDealerOrderBook(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetDealrOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR          sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR         sProduct[10];
	CHAR         sValidity[5];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32		iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;	
	LONG32		iDateTime;


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("fDealerOrderBook  client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);



	sprintf(sGetDealrOrdBook,"SELECT  ORDER_NUMBER,\
			SERIALNO,\
			SEM_SECURITY_ID,\
			ORDER_TYPE,\
			QUANTITY,\
			REMAINING_QUANTITY,\
			DISCLOSE_QTY,\
			DQQTYREM,\
			ORDER_PRICE,\
			TRG_PRICE,\
			TRADEDQTY,\
			PRODUCT,\
			ORDER_VALIDITY,\
			EXCHORDERNO,\
			date_format(ORDER_DATE_TIME,'%%d-%%m-%%Y  %%r'),\
			EXCH,\
			BUY_SELL,\
			SEGMENT,\
			TRANSCODE,\
			CLIENT_ID,\
			julidate(ORDER_DATE_TIME),\
			STRATEGY_ID,\
			PLACEDBY,\
			REASON_DESCRIPTION,\
			PRO_CLIENT,\
			TRADE_PRICE,\
			GOOD_TILL_DATE ,\
			LEGVALUE \
			from ORDERBOOK \
			WHERE CLIENT_ID IN (select e.ENTITY_CODE\
					FROM ENTITY_MASTER e\
					WHERE e.ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))\
					union\
					select c.EDM_CLIENT_ID\
					FROM rupeeSQLDB.ENTITY_DEALER_MAPPING c\
					WHERE c.EDM_DEALER_ID = ltrim(rtrim(\"%s\"))\
					)\
			order by ORDER_DATE_TIME DESC;",sEntityId,sEntityId);
	logDebug2(" sGetDealrOrdBook :%s:",sGetDealrOrdBook);

	if(mysql_query(DBQueries,sGetDealrOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR In GetDealrOrdBook Query.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	//		pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{


				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = 0;
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				//                		pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

				logDebug2("\n iTempNoOfRec :%d: Segment:%c:,ExcgId :%s:",iTempNoOfRec,Segment,ExcgId );


				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbook[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbook[j].iSerialNo = atoi(Row[1]);
				strncpy(pOrderBookResp.suborderbook[j].sSecurityID,Row[2] ,SECURITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sOrderType,Row[3] ,8);
				pOrderBookResp.suborderbook[j].fQty = atof(Row[4]);
				pOrderBookResp.suborderbook[j].fRemQty =atof(Row[5]) ;
				pOrderBookResp.suborderbook[j].fDQQty = atof(Row[6]);
				pOrderBookResp.suborderbook[j].fDQQtyRem = atof(Row[7]);
				pOrderBookResp.suborderbook[j].fPrice = atof(Row[8]);
				pOrderBookResp.suborderbook[j].fTrgPrice = atof(Row[9]);
				pOrderBookResp.suborderbook[j].fTradeQty = atof(Row[10]);
				strncpy(pOrderBookResp.suborderbook[j].sProduct,Row[11] ,10);
				strncpy(pOrderBookResp.suborderbook[j].sValidity,Row[12] ,5);
				strncpy(pOrderBookResp.suborderbook[j].sExchOrderNumber,Row[13] ,BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sDatetime,Row[14] ,DATE_LENGTH);
				strncpy(pOrderBookResp.suborderbook[j].sExcgId,Row[15] ,EXCHANGE_LEN);
				memset(pOrderBookResp.suborderbook[j].sBuySellInd,'\0',5);
				strncpy(pOrderBookResp.suborderbook[j].sBuySellInd,Row[16],5);
				pOrderBookResp.suborderbook[j].cSegment = Row[17][0];
				pOrderBookResp.suborderbook[j].iTranscode = atoi(Row[18]);

				strncpy(pOrderBookResp.suborderbook[j].sClientId,Row[19],CLIENT_ID_LEN);

				pOrderBookResp.suborderbook[j].iDateTime = Row[20];
				pOrderBookResp.suborderbook[j].iStrategyId = atoi(Row[21]);
				strncpy(pOrderBookResp.suborderbook[j].sEntityId , Row[22],ENTITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sReasonDesc, Row[23],DB_REASON_DESC_LEN);
				pOrderBookResp.suborderbook[j].cProClient =  Row[24][0];
				pOrderBookResp.suborderbook[j].fTrdPrice  = atof(Row[25]);
				strncpy(pOrderBookResp.suborderbook[j].sGoodTillDaysDate, Row[26],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sLegValue, Row[27],LEG_LEN);



				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pOrderBookResp.IntRespHeader.iMsgLength :%d:",pOrderBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pOrderBookResp.IntRespHeader.iUserId:%d:",pOrderBookResp.IntRespHeader.iUserId);
				//				logDebug2(" pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pOrderBookResp.suborderbook[j].sExcgId :%s: strlen(pOrderBookResp.suborderbook[j].sExcgId):%d:",pOrderBookResp.suborderbook[j].sExcgId,strlen(pOrderBookResp.suborderbook[j].sExcgId));
				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" pOrderBookResp.suborderbook[j].fOrderNo :%lf:",pOrderBookResp.suborderbook[j].fOrderNo);
				logDebug2(" pOrderBookResp.suborderbook[j].iSerialNo:%d:",pOrderBookResp.suborderbook[j].iSerialNo);
				logDebug2(" pOrderBookResp.suborderbook[j].iTranscode:%d:",pOrderBookResp.suborderbook[j].iTranscode);
				logDebug2(" pOrderBookResp.suborderbook[j].sBuySellInd:%s: strlen(pOrderBookResp.suborderbook.sBuySellInd):%d:",pOrderBookResp.suborderbook[j].sBuySellInd,strlen(pOrderBookResp.suborderbook[j].sBuySellInd));
				logDebug2(" pOrderBookResp.suborderbook.sSecurityID:%s: strlen(pOrderBookResp.suborderbook.sSecurityID):%d:",pOrderBookResp.suborderbook[j].sSecurityID,strlen(pOrderBookResp.suborderbook[j].sSecurityID));
				logDebug2(" pOrderBookResp.suborderbook.sOrderType :%s: strlen(pOrderBookResp.suborderbook.sOrderType):%d:",pOrderBookResp.suborderbook[j].sOrderType,strlen(pOrderBookResp.suborderbook[j].sOrderType));
				logDebug2(" pOrderBookResp.suborderbook.sProduct:%s: strlen(pOrderBookResp.suborderbook.sProduct):%d:",pOrderBookResp.suborderbook[j].sProduct,strlen(pOrderBookResp.suborderbook[j].sProduct));
				logDebug2(" pOrderBookResp.suborderbook.sValidity:%s: strlen(pOrderBookResp.suborderbook.sValidity):%d:",pOrderBookResp.suborderbook[j].sValidity,strlen(pOrderBookResp.suborderbook[j].sValidity));
				logDebug2(" pOrderBookResp.suborderbook.sDatetime:%s: strlen(pOrderBookResp.suborderbook.sDatetime):%d:",pOrderBookResp.suborderbook[j].sDatetime,strlen(pOrderBookResp.suborderbook[j].sDatetime));
				logDebug2(" pOrderBookResp.suborderbook[j].cSegment :%c:",pOrderBookResp.suborderbook[j].cSegment);
				logDebug2(" pOrderBookResp.suborderbook[j].iDateTime :%d:",pOrderBookResp.suborderbook[j].iDateTime);

				logDebug2("pOrderBookResp.suborderbook[j].sEntityId :%s:",pOrderBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbook[j].iStrategyId :%d:",pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("strncpy(pOrderBookResp.suborderbook[j].sReasonDesc :%d:",pOrderBookResp.suborderbook[j].sReasonDesc);
						logDebug2("pOrderBookResp.suborderbook[j].cProClient :%d: ",pOrderBookResp.suborderbook[j].cProClient);
						logDebug2("pOrderBookResp.suborderbook[j].fTrdPrice :%f:",pOrderBookResp.suborderbook[j].fTrdPrice) ;
						logDebug2("pOrderBookResp.suborderbook[j].sGoodTillDaysDate :%s:",pOrderBookResp.suborderbook[j].sGoodTillDaysDate);
						logDebug2("pOrderBookResp.suborderbook[j].sLegValue:%s:",pOrderBookResp.suborderbook[j].sLegValue);
						iTempNoOfRec--;
						}
						}


						if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_RESP) ,1 ) != TRUE ))
						{
						perror("Error WriteMsgQ: ");
						logDebug2("Write Q id %d", iSTWRelToQueryQ);
						exit(ERROR);
						}

						usleep(100); /** This is done to give a slow response to the Rapid Rupee **/



	}


	return TRUE;


}/************** END of fDealerOrderBook ****/


BOOL fGetTradeBook(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP     pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP     pTradeBookHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sUserType[3];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetTrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);
	logDebug2("sClientId :%s: sEntityId :%s:",sClientId,sEntityId);

	sprintf(sGetTrdBook,"SELECT  ENTITY_TYPE FROM  ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);

	logDebug2("sGetTrdBook :%s:",sGetTrdBook);
	if(mysql_query(DBQueries,sGetTrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in GetTrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
	}		



	logDebug2("USER TYPE is :%s:",sUserType );

	if(!strcmp(sUserType ,"D") && !strcmp(sClientId ,"-1"))
	{
		logDebug2("\n Going to call fDealerALLTRadebook");
		fDealerTradeBook(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"D" ) && strcmp(sClientId ,"-1"))
	{
		logDebug2("-----Going to call fTradeBook");
		fTradeBook(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2(" Going to call fTradeBook---------");
		fTradeBook(RcvMsg);
		return TRUE;

	}


	return TRUE;



}/** End of fGetTradeBook ***/


BOOL fGetConvetToDel(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sUserType[3];
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR *sGetCon2Del= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewCTODReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewCTODReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" pViewCTODReq->sClientId [%s]",pViewCTODReq->sClientId);
	logDebug2(" pViewCTODReq->sEntityId [%s]",pViewCTODReq->sEntityId);

	sprintf(sGetCon2Del,"SELECT  ENTITY_TYPE \
			from  ENTITY_MASTER \
			WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);


	if(mysql_query(DBQueries,sGetCon2Del) != SUCCESS)
	{
		logSqlFatal("ERROR in fGetConvetToDel QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
	}

	logDebug2(" USER TYPE is :%s:",sUserType );		

	if(!strcmp(sUserType ,"D") && !strcmp(sClientId ,"-1"))
	{
		logDebug2("\n Going to call fDealerConvetToDel");
		fDealerConvetToDel(RcvMsg);
		return TRUE;

	}

	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("\n Going to call fClientConvetToDel ");
		fClientConvetToDel(RcvMsg);
		return TRUE;

	}	

	logDebug2(" I m here too");


	return TRUE;


}

BOOL fDealerConvetToDel(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sDealrCnvtToDel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;	

	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR            cProductSource;
	CHAR            cProductDest;
	CHAR            cSide;
	LONG32          iQty;
	CHAR         sExcgId[EXCHANGE_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            cSegment;
	CHAR         sRespClientId[CLIENT_ID_LEN];


	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;	

	strncpy(sEntityId ,pViewCTODReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" fDealerConvetToDel sEntityId [%s] pViewCTODReq->sEntityId[%s]",sEntityId ,pViewCTODReq->sEntityId);


	sprintf(sDealrCnvtToDel,"SELECT  RCCD_SCRIP_CODE,\
			RCCD_EXCHANGE,\
			RCCD_PRODUCT_SOURCE,\
			RCCD_PRODUCT_DESTINATION,\
			RCCD_SIDE,\
			RCCD_QTY,\
			RCCD_CONVT_PRICE,\
			RCCD_SEGMENT,\
			RCCD_CLIENT_ID\
			FROM RMS_CLIENT_CONVT_TO_DEL tb\
			WHERE RCCD_CLIENT_ID in (select ENTITY_CODE\
				FROM ENTITY_MASTER\
				WHERE ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))\
				UNION\
				SELECT edm_client_id\
				FROM ENTITY_DEALER_MAPPING\
				WHERE edm_dealer_id = ltrim(rtrim(\"%s\")))\
			ORDER BY RCCD_CONVT_TIME;",sEntityId,sEntityId);

	logDebug2(" sDealrCnvtToDel :%s:",sDealrCnvtToDel);

	if(mysql_query(DBQueries,sDealrCnvtToDel) != SUCCESS)
	{
		logSqlFatal("ERROR in DealrCnvToDel Query.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;


	pCTODHdrResp.IntRespHeader.iSeqNo = 0;
	pCTODHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCTODHdrResp.IntRespHeader.iErrorId = 0;
	pCTODHdrResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_HEADER_RESP;
	pCTODHdrResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
	//                pCTODHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;

	pCTODHdrResp.cMsgType = 'H';
	pCTODHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pCTODHdrResp.cMsgType:%c:,pCTODHdrResp.iNoofRec:%d:",pCTODHdrResp.cMsgType,pCTODHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}



	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{

				pCTODResp.IntRespHeader.iSeqNo = 0;
				pCTODResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY);
				pCTODResp.IntRespHeader.iErrorId = 0;
				pCTODResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_RESP;
				pCTODResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
				//                		pCTODResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;	

				if(iTempNoOfRec <= 1)
				{
					pCTODResp.cMsgType = 'T';
				}
				else
				{
					pCTODResp.cMsgType = 'D';
				}

				strncpy(pCTODResp.subCTOD[j].sClientId,Row[8],CLIENT_ID_LEN);
				strncpy(pCTODResp.subCTOD[j].sSecurityID,Row[0],SECURITY_ID_LEN);
				pCTODResp.subCTOD[j].cProductSource = Row[2][0];
				pCTODResp.subCTOD[j].cProductDest = Row[3][0];
				pCTODResp.subCTOD[j].cSide = Row[4][0];
				pCTODResp.subCTOD[j].iQty = atoi(Row[5]);
				pCTODResp.subCTOD[j].fConvertPrice = atof(Row[6]);
				pCTODResp.subCTOD[j].cSegment = Row[7][0];
				strncpy(pCTODResp.subCTOD[j].sExcgId,Row[1],EXCHANGE_LEN);

				logDebug2(" pCTODResp.IntRespHeader.iSeqNo [%d]",pCTODResp.IntRespHeader.iSeqNo);
				logDebug2(" pCTODResp.IntRespHeader.iMsgLength [%d]",pCTODResp.IntRespHeader.iMsgLength);
				logDebug2(" pCTODResp.IntRespHeader.iErrorId [%d]",pCTODResp.IntRespHeader.iErrorId);
				logDebug2(" pCTODResp.IntRespHeader.iMsgCode [%d]",pCTODResp.IntRespHeader.iMsgCode);
				logDebug2(" pCTODResp.IntRespHeader.iUserId [%d]",pCTODResp.IntRespHeader.iUserId);
				//				logDebug2(" pCTODResp.IntRespHeader.cUserTypeOrLogInfoType [%d]",pCTODResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pCTODResp.cMsgType [%c]",pCTODResp.cMsgType);
				logDebug2(" pCTODResp.subCTOD[%d].sClientId [%s]",j,pCTODResp.subCTOD[j].sClientId);
				logDebug2(" pCTODResp.subCTOD[%d].sSecurityID [%s]",j,pCTODResp.subCTOD[j].sSecurityID);
				logDebug2(" pCTODResp.subCTOD[%d].cProductSource [%c]",j,pCTODResp.subCTOD[j].cProductSource);
				logDebug2(" pCTODResp.subCTOD[%d].cProductDest [%c]",j,pCTODResp.subCTOD[j].cProductDest);
				logDebug2(" pCTODResp.subCTOD[%d].cSide [%c]",j,pCTODResp.subCTOD[j].cSide);
				logDebug2(" pCTODResp.subCTOD[%d].iQty [%d]",j,pCTODResp.subCTOD[j].iQty);
				logDebug2(" pCTODResp.subCTOD[%d].fConvertPrice [%d]",j,pCTODResp.subCTOD[j].fConvertPrice);
				logDebug2(" pCTODResp.subCTOD[%d].cSegment [%c]",j,pCTODResp.subCTOD[j].cSegment);
				logDebug2(" pCTODResp.subCTOD[%d].sExcgId [%s]",j,pCTODResp.subCTOD[j].sExcgId);


				iTempNoOfRec--;
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODResp,sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


	}



	return TRUE;	

}




BOOL fDealerTradeBook(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetDealrTrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;	


	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);



	sprintf(sGetDealrTrdBook,"SELECT  ORDER_NUMBER,\
			SEM_SMST_SECURITY_ID,\
			BUY_SELL,\
			ORDER_TYPE,\
			EXCH_ORDER_NUMBER,\
			TRADE_NUMBER,\
			PRODUCT,\
			QUANTITY,\
			PRICE,\
			TRADE_VALUE,\
			date_format(str_to_date(ORDER_DATE_TIME,\'%%d-%%m-%%Y %%r\'),\'%%Y-%%m-%%d %%H:%%i:%%S\') as ORDER_DATE_TIME,\
			EXCHANGE,\
			SEGMENT,\
			CLIENT_ID,\
			julidate(date_format(str_to_date(ORDER_DATE_TIME,\'%%d-%%m-%%Y %%r\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'))  \
			from TRADEBOOK tb\
			WHERE CLIENT_ID in (select ENTITY_CODE\
				FROM ENTITY_MASTER\
				WHERE ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))\
				UNION\	
				SELECT edm_client_id\
				FROM ENTITY_DEALER_MAPPING\
				WHERE edm_dealer_id = ltrim(rtrim(\"%s\")))\
			ORDER BY ORDER_DATE_TIME DESC;",sEntityId,sEntityId);

	logDebug2("\n sGetDealrTrdBook :%s:",sGetDealrTrdBook);

	if(mysql_query(DBQueries,sGetDealrTrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in GetDealrTrdBook Query.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{
				pTradeBookResp.IntRespHeader.iSeqNo = 0;
				pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
				pTradeBookResp.IntRespHeader.iErrorId = 0;
				pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_RESP;
				pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
				//                		pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pTradeBookResp.cMsgType = 'T';
				}
				else
				{
					pTradeBookResp.cMsgType = 'D';
				}

				pTradeBookResp.subTradeBook[j].fOrderNo = atof(Row[0]);
				strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sOrderType,Row[3],8);
				pTradeBookResp.subTradeBook[j].fTradeQty = atof(Row[7]);
				pTradeBookResp.subTradeBook[j].fTradePrice = atof(Row[8]);
				pTradeBookResp.subTradeBook[j].fTradeVal = atof(Row[9]);
				pTradeBookResp.subTradeBook[j].fTradeNo = atof(Row[5]);
				pTradeBookResp.subTradeBook[j].cSegment = Row[12][0];
				memset(pTradeBookResp.subTradeBook[j].sBuySellInd,'\0',5);
				strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,Row[2],5);

				strncpy(pTradeBookResp.subTradeBook[j].sProduct,Row[6],10);
				strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,Row[4],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sDatetime,Row[10],DATE_LENGTH);
				strncpy(pTradeBookResp.subTradeBook[j].sClientId,Row[13],CLIENT_ID_LEN);

				strncpy(pTradeBookResp.subTradeBook[j].sExcgId,Row[11],EXCHANGE_LEN);
				pTradeBookResp.subTradeBook[j].iDateTime = atoi(Row[14]);

				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%d:",pTradeBookResp.IntRespHeader.iUserId);
				//				logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
				logDebug2(" pTradeBookResp.subTradeBook[j].sExcgId :%s: strlen(pTradeBookResp.subTradeBook[j].sExcgId):%d:",pTradeBookResp.subTradeBook[j].sExcgId,strlen(pTradeBookResp.subTradeBook[j].sExcgId));
				logDebug2(" pTradeBookResp.subTradeBook[j]..sExchOrderNumber :%s: strlen(pTradeBookResp.subTradeBook[j]..sExchOrderNumber):%d:",pTradeBookResp.subTradeBook[j].sExchOrderNumber,strlen(pTradeBookResp.subTradeBook[j].sExchOrderNumber));
				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
				logDebug2(" pTradeBookResp.subTradeBook[j].fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
				logDebug2(" pTradeBookResp.subTradeBoo[j]k.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook[j].sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
				logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
				logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
				logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
				logDebug2(" pTradeBookResp.subTradeBook.fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);
				logDebug2(" pTradeBookResp.subTradeBook.iDateTime :%d:",pTradeBookResp.subTradeBook[j].iDateTime);

				iTempNoOfRec--;
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}
		usleep(500); /** This is done to give a slow response to the Rapid Rupee **/


	}


	return TRUE;

}/************** END of fDealerTradeBook ****/
BOOL fClientCarryFwdPosition(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_STRING_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;


	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);


	/********
	  SELECT  count(1)
INTO :iNoOfRec
from VIEW_CARRY_FWD_POSITION , entity_master em
WHERE CLIENT_ID = em.em_entity_id
AND CLIENT_ID like decode(ltrim(rtrim(:sClientId)),'-1','%',ltrim(rtrim(:sClientId)));
	 ********/

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_CARRY_FWD_POS_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}
	/****
	  SELECT	ORDER_NUMBER,
	  SEM_SMST_SECURITY_ID,
	  BUY_SELL,
	  ORDER_TYPE,
	  EXCH_ORDER_NUMBER,
	  TRADE_NUMBER,
	  PRODUCT,
	  QUANTITY,
	  PRICE,
	  TRADE_VALUE,
	  ORDER_DATE_TIME,
	  EXCHANGE,
	  SEGMENT,
	  CLIENT_ID
	  FROM VIEW_CARRY_FWD_POSITION , entity_master em
	  WHERE CLIENT_ID = em.em_entity_id
	  AND CLIENT_ID like decode(ltrim(rtrim(:sClientId)),'-1','%',ltrim(rtrim(:sClientId)))
	  ORDER BY ORDER_DATE_TIME DESC;********/




	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			fOrderNo=0;
			fTradeQty=0;


			memset(sBuySellInd ,'\0',5);

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);

			memset(sOrderType ,'\0',8);

			memset(sExchOrderNumber ,'\0',BSE_EXCH_ORDER_NO_LEN);

			memset(sDatetime ,'\0',DATE_STRING_LENGTH);

			memset(ExcgId ,'\0',EXCHANGE_LEN);

			memset(sRespClientId ,'\0',CLIENT_ID_LEN);

			memset(sProduct ,'\0',10);


			Segment = '\0';	

			/*********

			  :fOrderNo,
			  :sSecurityID,
			  :sBuySellInd,
			  :sOrderType,
			  :sExchOrderNumber,
			  :fTradeNo,
			  :sProduct,
			  :fTradeQty,
			  :fTradePrice,
			  :fTradeVal,
			  :sDatetime,
			  :ExcgId,
			  :Segment,
			  :sRespClientId;
			 ********/



			pTradeBookResp.IntRespHeader.iSeqNo = 0;
			pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
			pTradeBookResp.IntRespHeader.iErrorId = 0;
			pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_CARRY_FWD_POS_RESP;
			pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
			//                pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pTradeBookResp.cMsgType = 'T';
			}
			else
			{
				pTradeBookResp.cMsgType = 'D';
			}

			pTradeBookResp.subTradeBook[j].fOrderNo = fOrderNo;
			strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sOrderType,sOrderType ,8);
			pTradeBookResp.subTradeBook[j].fTradeQty = fTradeQty;
			pTradeBookResp.subTradeBook[j].fTradePrice = fTradePrice;
			pTradeBookResp.subTradeBook[j].fTradeVal = fTradeVal;
			pTradeBookResp.subTradeBook[j].fTradeNo = fTradeNo;
			pTradeBookResp.subTradeBook[j].cSegment = Segment;
			memset(pTradeBookResp.subTradeBook[j].sBuySellInd,'\0',5);
			strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,sBuySellInd ,5);

			strncpy(pTradeBookResp.subTradeBook[j].sProduct,sProduct ,10);
			strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,sExchOrderNumber ,BSE_EXCH_ORDER_NO_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sDatetime,sDatetime ,DATE_STRING_LENGTH);
			strncpy(pTradeBookResp.subTradeBook[j].sClientId,sRespClientId ,CLIENT_ID_LEN);

			strncpy(pTradeBookResp.subTradeBook[j].sExcgId,ExcgId ,EXCHANGE_LEN);

			logDebug2(" ----------------- Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
			logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%d:",pTradeBookResp.IntRespHeader.iUserId);
			//		logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
			logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
			logDebug2(" pTradeBookResp.subTradeBook[j].sExcgId :%s: strlen(pTradeBookResp.subTradeBook[j].sExcgId):%d:",pTradeBookResp.subTradeBook[j].sExcgId,strlen(pTradeBookResp.subTradeBook[j].sExcgId));
			logDebug2(" ----------------- Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
			logDebug2(" pTradeBookResp.subTradeBook[j].fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
			logDebug2(" pTradeBookResp.subTradeBoo[j]k.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook[j].sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
			logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
			logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
			logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
			logDebug2(" pTradeBookResp.subTradeBook.fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/



	}


	return TRUE;

}/************** END of fTradeBook ****/
/***************************************************/
BOOL fClientConvetToDel(CHAR *RcvMsg)
{

	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sCltCnvtToDel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR		sSecurityID[SECURITY_ID_LEN];
	CHAR		cProductSource;
	CHAR		cProductDest;
	CHAR		cSide;
	LONG32		iQty;
	CHAR		sExcgId[EXCHANGE_LEN];
	CHAR		sClientId[CLIENT_ID_LEN];
	LONG32		iNoOfRec=0;
	LONG32		iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR		cSegment;	

	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewCTODReq->sClientId,CLIENT_ID_LEN);
	logDebug2(" sClientId  is n fClientConvetToDel :%s: ",sClientId );



	/*****
	  SELECT  count(1)
INTO :iNoOfRec
from RMS_CLIENT_CONVT_TO_DEL
WHERE RCCD_CLIENT_ID = ltrim(rtrim(:sClientId));
	 ********/
	sprintf(sCltCnvtToDel,"SELECT  RCCD_SCRIP_CODE,\
			RCCD_EXCHANGE,\
			RCCD_PRODUCT_SOURCE,\
			RCCD_PRODUCT_DESTINATION,\
			RCCD_SIDE,\
			RCCD_QTY,\
			RCCD_CONVT_PRICE,\
			RCCD_SEGMENT\
			FROM RMS_CLIENT_CONVT_TO_DEL\
			WHERE RCCD_CLIENT_ID = ltrim(rtrim(\"%s\")); ",sClientId);

	logDebug2("\n sCltCnvtToDel :%s:",sCltCnvtToDel);	
	if(mysql_query(DBQueries,sCltCnvtToDel) != SUCCESS)
	{
		logSqlFatal("ERROR in CltCnvtToDel Query.");			
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);


	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;


	pCTODHdrResp.IntRespHeader.iSeqNo = 0;
	pCTODHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCTODHdrResp.IntRespHeader.iErrorId = 0;
	pCTODHdrResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_HEADER_RESP;
	pCTODHdrResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
	//		pCTODHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;

	pCTODHdrResp.cMsgType = 'H';
	pCTODHdrResp.iNoofRec = iNoOfRec;

	logDebug2("\n pCTODHdrResp.cMsgType:%c:,pCTODHdrResp.iNoofRec:%d:",pCTODHdrResp.cMsgType,pCTODHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{

				pCTODResp.IntRespHeader.iSeqNo = 0;
				pCTODResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY);
				pCTODResp.IntRespHeader.iErrorId = 0;
				pCTODResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_RESP;
				pCTODResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
				//				pCTODResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pCTODResp.cMsgType = 'T';
				}
				else
				{
					pCTODResp.cMsgType = 'D';
				}

				strncpy(pCTODResp.subCTOD[j].sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pCTODResp.subCTOD[j].sSecurityID,Row[0],SECURITY_ID_LEN);
				pCTODResp.subCTOD[j].cProductSource = Row[2][0];
				pCTODResp.subCTOD[j].cProductDest = Row[3][0];
				pCTODResp.subCTOD[j].cSide = Row[4][0];
				pCTODResp.subCTOD[j].iQty = atoi(Row[5]);
				pCTODResp.subCTOD[j].fConvertPrice = atof(Row[6]);
				pCTODResp.subCTOD[j].cSegment = Row[7][0];
				strncpy(pCTODResp.subCTOD[j].sExcgId,Row[1],EXCHANGE_LEN);

				iTempNoOfRec--;
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODResp,sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}


	}



	return TRUE;
}

BOOL fSendMsgtoClient(CHAR *RcvMsg)
{
	struct SEND_MSG_TO_CLIENT_REQ *pSendMsgtoClientReq;
	struct SEND_MSG_TO_CLIENT_RESP     pSendMsgtoClientResp;

	LONG32 iNoOfRec=0;
	LONG32 i=0;

	pSendMsgtoClientReq = (struct SEND_MSG_TO_CLIENT *)RcvMsg;

	iNoOfRec = pSendMsgtoClientReq->iNoOfRec;

	logDebug2("\n pSendMsgtoClientReq->iNoOfRec :%d:",pSendMsgtoClientReq->iNoOfRec);
	logDebug2("\n pSendMsgtoClientReq->sMsg :%s",pSendMsgtoClientReq->sMsg);

	for(i=0;i<iNoOfRec;i++)
	{
		logDebug2("\n pSendMsgtoClientReq->iReceiverUserId[%d] :%d",i,pSendMsgtoClientReq->iReceiverUserId[i]);
		pSendMsgtoClientResp.IntRespHeader.iSeqNo = 0;
		pSendMsgtoClientResp.IntRespHeader.iMsgLength = sizeof(struct SEND_MSG_TO_CLIENT_RESP);
		pSendMsgtoClientResp.IntRespHeader.iErrorId = 0;
		pSendMsgtoClientResp.IntRespHeader.iMsgCode = TC_INT_SEND_MSG_TO_CLIENT_RESP;
		pSendMsgtoClientResp.IntRespHeader.iUserId = pSendMsgtoClientReq->iReceiverUserId[i];
		//		pSendMsgtoClientResp.IntRespHeader.cUserTypeOrLogInfoType = 'C';

		strncpy(pSendMsgtoClientResp.sSender,pSendMsgtoClientReq->sSender,CLIENT_ID_LEN);
		strncpy(pSendMsgtoClientResp.sMsg,pSendMsgtoClientReq->sMsg,SEND_MSG_LEN);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pSendMsgtoClientResp,sizeof(struct SEND_MSG_TO_CLIENT_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			exit(ERROR);
		}

	}


	pSendMsgtoClientResp.IntRespHeader.iUserId = pSendMsgtoClientReq->ReqHeader.iUserId;	
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pSendMsgtoClientResp,sizeof(struct SEND_MSG_TO_CLIENT_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iIntActiveToRelDirQ);
		exit(ERROR);
	}


	return TRUE;


}/** End fSendMsgtoClient ***/
BOOL fDNLDSystemMsg(CHAR *RcvMsg)
{

	logDebug2("\n [In fDNLDSystemMsg]");
	struct VIEW_COMMON_QUERY_REQ *pDNLDSystemMsgReq;
	struct DWS_DNLD_SYS_MESGS_RESP     pDNLDSystemMsgResp;
	struct VIEW_COMMON_HDR_RESP     pDNLDSystemMsgHdrResp;
	CHAR	*sSelQury = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sGenralMsg[SYSTEM_MSG_LEN];
	CHAR         sExcgId[EXCHANGE_LEN];
	LONG32          iNoOfRec;
	CHAR            cSegment;
	LONG32		iUserId;
	LONG32		iMsgCode;
	LONG32		iTempNoOfRec;

	pDNLDSystemMsgReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	iUserId = pDNLDSystemMsgReq->ReqHeader.iUserId;

	sprintf(sSelQury,"SELECT  SM_TRANS_CODE,\
			SM_EXCH_ID,\
			SM_SEGMENT,\
			DATE_FORMAT(SM_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
			SM_GENERAL_MESG\
			FROM SYSTEM_MESGS\
			WHERE SM_USER_ID = %d;",iUserId);

	logDebug2("sSelQury :%s:",sSelQury);	

	if(mysql_query(DBQueries,sSelQury) != SUCCESS)
	{
		logSqlFatal("ERROR in fDNLDSystemMsg QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iTempNoOfRec = iNoOfRec;

	pDNLDSystemMsgHdrResp.IntRespHeader.iSeqNo = 0;
	pDNLDSystemMsgHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pDNLDSystemMsgHdrResp.IntRespHeader.iErrorId = 0;
	pDNLDSystemMsgHdrResp.IntRespHeader.iMsgCode = TC_INT_DNLD_SYSTEM_MSG_HDR_RESP;
	pDNLDSystemMsgHdrResp.IntRespHeader.iUserId = pDNLDSystemMsgReq->ReqHeader.iUserId;
	//	pDNLDSystemMsgHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pDNLDSystemMsgReq->ReqHeader.cUserType;

	pDNLDSystemMsgHdrResp.cMsgType = 'H';
	pDNLDSystemMsgHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pDNLDSystemMsgHdrResp.cMsgType:%c:,pDNLDSystemMsgHdrResp.iNoofRec:%d:",pDNLDSystemMsgHdrResp.cMsgType,pDNLDSystemMsgHdrResp.iNoofRec);


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pDNLDSystemMsgHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	//for(i=0;i<iNoOfRec;i++)	
	while((Row=mysql_fetch_row(Res)))
	{


		pDNLDSystemMsgResp.IntRespHeader.iSeqNo = 0;
		pDNLDSystemMsgResp.IntRespHeader.iMsgLength = sizeof(struct DWS_DNLD_SYS_MESGS_RESP);
		pDNLDSystemMsgResp.IntRespHeader.iErrorId = 0;
		pDNLDSystemMsgResp.IntRespHeader.iMsgCode = TC_INT_DNLD_SYSTEM_MSG_RESP;
		strncpy(pDNLDSystemMsgResp.IntRespHeader.sExcgId,Row[1],EXCHANGE_LEN);
		pDNLDSystemMsgResp.IntRespHeader.iUserId = pDNLDSystemMsgReq->ReqHeader.iUserId;
		//			pDNLDSystemMsgResp.IntRespHeader.cUserTypeOrLogInfoType = pDNLDSystemMsgReq->ReqHeader.cUserType;
		pDNLDSystemMsgResp.IntRespHeader.cSegment = Row[2][0];


		if(iTempNoOfRec <= 1)
		{
			pDNLDSystemMsgResp.cMsgType = 'T';
		}
		else
		{
			pDNLDSystemMsgResp.cMsgType = 'D';
		}

		strncpy(pDNLDSystemMsgResp.sDatetime,Row[3],DATE_LENGTH);
		strncpy(pDNLDSystemMsgResp.sGenralMsg,Row[4],SYSTEM_MSG_LEN);
		pDNLDSystemMsgResp.iMsgCode = atoi(Row[0]);

		iTempNoOfRec--;

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pDNLDSystemMsgResp,sizeof(struct DWS_DNLD_SYS_MESGS_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			exit(ERROR);
		}

		usleep(100);



	}

	return TRUE;

}

BOOL fSurvillenceTradeBook(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;	


	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);


	/*****
	  SELECT  count(1)
INTO :iNoOfRec
from TRADEBOOK tb;
	 ****/

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_TRADE_BOOK_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("\n Survillenece Admin pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);


	if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}
	/*******
	  SELECT	ORDER_NUMBER,
	  SEM_SMST_SECURITY_ID,
	  BUY_SELL,
	  ORDER_TYPE,
	  EXCH_ORDER_NUMBER,
	  TRADE_NUMBER,
	  PRODUCT,
	  QUANTITY,
	  PRICE,
	  TRADE_VALUE,
	  to_char(to_date(ORDER_DATE_TIME,'DD-MM-YYYY HH:MI:SS AM'),'DD-MM-YYYY HH:MI:SS AM'),
	  EXCHANGE,
	  SEGMENT,
	  CLIENT_ID,
	  julidate(to_date(ORDER_DATE_TIME,'DD-MM-YYYY HH:MI:SS AM'))
	  FROM TRADEBOOK tb
	  ORDER BY ORDER_DATE_TIME DESC;*******/


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			fOrderNo=0;
			fTradeQty=0;


			memset(sBuySellInd ,'\0',5);

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);

			memset(sOrderType ,'\0',8);

			memset(sExchOrderNumber ,'\0',BSE_EXCH_ORDER_NO_LEN);

			memset(sDatetime ,'\0',DATE_LENGTH);

			memset(ExcgId ,'\0',EXCHANGE_LEN);

			memset(sRespClientId ,'\0',CLIENT_ID_LEN);

			memset(sProduct ,'\0',10);


			Segment = '\0';	
			iDateTime=0;


			/***********
			  :fOrderNo,
			  :sSecurityID,
			  :sBuySellInd,
			  :sOrderType,
			  :sExchOrderNumber,
			  :fTradeNo,
			  :sProduct,
			  :fTradeQty,
			  :fTradePrice,
			  :fTradeVal,
			  :sDatetime,
			  :ExcgId,
			  :Segment,
			  :sRespClientId,
			  :iDateTime;
			 ******/	



			pTradeBookResp.IntRespHeader.iSeqNo = 0;
			pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
			pTradeBookResp.IntRespHeader.iErrorId = 0;
			pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_TRADE_BOOK_RESP;
			pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
			//                pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pTradeBookResp.cMsgType = 'T';
			}
			else
			{
				pTradeBookResp.cMsgType = 'D';
			}

			pTradeBookResp.subTradeBook[j].fOrderNo = fOrderNo;
			strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sOrderType,sOrderType ,8);
			pTradeBookResp.subTradeBook[j].fTradeQty = fTradeQty;
			pTradeBookResp.subTradeBook[j].fTradePrice = fTradePrice;
			pTradeBookResp.subTradeBook[j].fTradeVal = fTradeVal;
			pTradeBookResp.subTradeBook[j].fTradeNo = fTradeNo;
			pTradeBookResp.subTradeBook[j].cSegment = Segment;
			memset(pTradeBookResp.subTradeBook[j].sBuySellInd,'\0',5);
			strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,sBuySellInd ,5);

			strncpy(pTradeBookResp.subTradeBook[j].sProduct,sProduct ,10);
			strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,sExchOrderNumber ,BSE_EXCH_ORDER_NO_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sDatetime,sDatetime ,DATE_LENGTH);
			strncpy(pTradeBookResp.subTradeBook[j].sClientId,sRespClientId ,CLIENT_ID_LEN);

			strncpy(pTradeBookResp.subTradeBook[j].sExcgId,ExcgId ,EXCHANGE_LEN);
			pTradeBookResp.subTradeBook[j].iDateTime = iDateTime;

			logDebug2(" ----------------- Survillenece Admin  Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
			logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%d:",pTradeBookResp.IntRespHeader.iUserId);
			//		logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
			logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
			logDebug2(" pTradeBookResp.subTradeBook[j].sExcgId :%s: strlen(pTradeBookResp.subTradeBook[j].sExcgId):%d:",pTradeBookResp.subTradeBook[j].sExcgId,strlen(pTradeBookResp.subTradeBook[j].sExcgId));
			logDebug2(" pTradeBookResp.subTradeBook[j]..sExchOrderNumber :%s: strlen(pTradeBookResp.subTradeBook[j]..sExchOrderNumber):%d:",pTradeBookResp.subTradeBook[j].sExchOrderNumber,strlen(pTradeBookResp.subTradeBook[j].sExchOrderNumber));
			logDebug2(" ----------------- Survillenece Admin Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
			logDebug2(" pTradeBookResp.subTradeBook[j].fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
			logDebug2(" pTradeBookResp.subTradeBoo[j]k.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook[j].sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
			logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
			logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
			logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
			logDebug2(" pTradeBookResp.subTradeBook.fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);
			logDebug2(" pTradeBookResp.subTradeBook.iDateTime :%d:",pTradeBookResp.subTradeBook[j].iDateTime);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRout2SurvlMapperQ);
			exit(ERROR);
		}
		usleep(500); /** This is done to give a slow response to the Rapid Rupee **/


	}


	return TRUE;
}


/************** END of fSurvillenceTradeBook ****/


BOOL fRejectedOrders(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
	struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
	struct 	VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp; 

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR *sRejectedOrders = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	LONG32          fNoOfRec=0.0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];


	pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


	/*	strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
		logdebug2(" sClientId :%s:", sClientId); */

	memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



	strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));


	/***

	  logDebug2(sRejectedOrders,"SELECT ORDNO,\
	  SCRIP_CODE,\
	  ORDBUYSELL,\
	  TRADE_DATE,\
	  ORDERTYPE,\
	  PRODUCTCODE,\
	  ORDQTY,\
	  ORDERRATE,\
	  INSUFFICIENT_QTY,\
	  INSUFFICIENT_AMT,\
	  AMOUNT_BLOCKED,\
	  RMS_STATUS,\
	  MKT_ORDER,\
	  SEGMENT,\
	  EXCH_ID\
	  FROM   RMS_REJECTED_ORDERS\
	  WHERE CLIENT_ID = LTRIM(RTRIM(\'%s\'))",sClientId);

	 *****/

	sprintf(sRejectedOrders,"SELECT ORDNO,\
			SCRIP_CODE,\
			ORDBUYSELL,\
			TRADE_DATE,\
			ORDERTYPE,\
			PRODUCTCODE,\
			ORDQTY,\
			ORDERRATE,\
			INSUFFICIENT_QTY,\
			INSUFFICIENT_AMT,\
			IFNULL(AMOUNT_BLOCKED,0),\
			RMS_STATUS,\
			MKT_ORDER,\
			ltrim(rtrim(CLIENT_ID)),\
			SEGMENT,\
			EXCH_ID\
			FROM   RMS_REJECTED_ORDERS") ;
	/***       WHERE	CLIENT_ID IN (select e.ENTITY_CODE\
	  FROM ENTITY_MASTER e\
	  WHERE e.ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))\
	  union\
	  select c.EDM_CLIENT_ID\
	  FROM ENTITY_DEALER_MAPPING c\
	  WHERE c.EDM_DEALER_ID = ltrim(rtrim(\"%s\"))\
	  )\
	  order by TRADE_DATE DESC;",sEntityId,sEntityId);	*******/


	logDebug2("fRejectedOrders :%s:",sRejectedOrders);

	if(mysql_query(DBQueries, sRejectedOrders) != SUCCESS)
	{
		logSqlFatal("ERROR in RejectOrd Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	fNoOfRec = mysql_num_rows(Res);

	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = fNoOfRec;

	pRejectedOrdersHdrResp.IntRespHeader.iSeqNo = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);

	pRejectedOrdersHdrResp.IntRespHeader.iErrorId = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_HEADER_RESP;
	pRejectedOrdersHdrResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
	//       	pRejectedOrdersHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;

	pRejectedOrdersHdrResp.cMsgType = 'H';
	pRejectedOrdersHdrResp.iNoofRec = fNoOfRec;


	logDebug2("pRejectedOrdersHdrResp.cMsgType:%c:, pRejectedOrdersHdrResp.iNoofRec:%d:", pRejectedOrdersHdrResp.cMsgType, pRejectedOrdersHdrResp.iNoofRec);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}
	logDebug2("iNoOfPkt :%d:",iNoOfPkt);

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pRejectedOrdersResp,'\0',sizeof( struct VIEW_REJECTED_ORDERS_RESP));
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				pRejectedOrdersResp.IntRespHeader.iSeqNo = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgLength = sizeof(struct  VIEW_REJECTED_ORDERS_RESP);
				pRejectedOrdersResp.IntRespHeader.iErrorId = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_RESP;
				pRejectedOrdersResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
				//                                 pRejectedOrdersResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pRejectedOrdersResp.cMsgType = 'T';
				}
				else
				{
					pRejectedOrdersResp.cMsgType = 'D';
				}


				pRejectedOrdersResp.subRejOrdBook[j].fOrderNo = atof(Row[0]);
				//  strncpy(pRejectedOrdersResp.sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,Row[1],strlen(Row[1]));
				if(Row[2][0] == INT_BUY)
				{
					/**	strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Buy",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_BUY,strlen(FE_BUY));
				}
				else if(Row[2][0] == INT_SELL)
				{
					/**					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Sell",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_SELL,strlen(FE_SELL));
				}
				/*	strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],DATE_LENGTH);	**/
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],strlen(Row[3]));	
				logDebug2("\n pRejectedOrdersResp.subRejOrdBook[j].sDatetime :%s: %d:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime,strlen(pRejectedOrdersResp.subRejOrdBook[j].sDatetime));
				if(Row[4][0] == 'N')
				{
					/** strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",8);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",3);
				}
				else if(Row[4][0] == 'M')
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"Modified",8);
				}

				if(Row[5][0] == PROD_INTRADAY)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_INTRADAY,strlen(FE_PROD_INTRADAY));
				}
				else if(Row[5][0] == PROD_MARGIN)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_MARGIN,strlen(FE_PROD_MARGIN));
				}
				else if(Row[5][0] == PROD_CNC)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_CNC,strlen(FE_PROD_CNC));
				}
				pRejectedOrdersResp.subRejOrdBook[j].iQty = atoi(Row[6]);
				pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice = atoi(Row[7]);
				pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty = atoi(Row[8]);
				pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt = atof(Row[9]);
				pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked = atof(Row[10]);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus,Row[11],10);
				pRejectedOrdersResp.subRejOrdBook[j].cMktOrder = Row[12][0];


				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sClientId,Row[13],strlen(Row[13]));

				logDebug2("\n -------------------------- Printing Data *********************");
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sClientId :%s: len :%d:",pRejectedOrdersResp.subRejOrdBook[j].sClientId,strlen(pRejectedOrdersResp.subRejOrdBook[j].sClientId));
				logDebug2("pRejectedOrdersHdrResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersHdrResp.IntRespHeader.iMsgCode);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrderNo:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrderNo);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sSecurityID:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd:%s:",pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime:%s:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sOrderType);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sProduct:%s:",pRejectedOrdersResp.subRejOrdBook[j].sProduct);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt:%f:",pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked:%f:",pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus:%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].cMktOrder:%c:",pRejectedOrdersResp.subRejOrdBook[j].cMktOrder);

				logDebug2("\n -------------------------- Printing Data *********************");

				pRejectedOrdersResp.subRejOrdBook[j].cSegment = Row[14][0];



				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sExcgId,Row[15],EXCHANGE_LEN);


				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sExcgId :%s:",pRejectedOrdersResp.subRejOrdBook[j].sExcgId);
				logDebug2(" pRejectedOrdersResp.cMsgType :%c:",pRejectedOrdersResp.cMsgType);
				logDebug2(" pRejectedOrdersResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersResp.IntRespHeader.iMsgCode);
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus :%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);

				logDebug2("pRejectedOrdersResp.subRejOrdBook.sSecurityID:%s: pRejectedOrdersResp.subRejOrdBook.sBuySellInd:%s: pRejectedOrdersResp.subRejOrdBook.sProduct:%s: pRejectedOrdersResp.subRejOrdBook.iQty:%d: pRejectedOrdersResp.subRejOrdBook.fOrdPrice:%f: pRejectedOrdersResp.subRejOrdBook.iInSuffQty:%d: pRejectedOrdersResp.subRejOrdBook.fInSuffAmt:%f: pRejectedOrdersResp.subRejOrdBook.fAmtBlocked:%f: pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,pRejectedOrdersResp.subRejOrdBook[j].sProduct,pRejectedOrdersResp.subRejOrdBook[j].iQty,pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice,pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty,pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt,pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked,pRejectedOrdersResp.subRejOrdBook[j].sOrderType);

			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersResp,sizeof(struct VIEW_REJECTED_ORDERS_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			exit(ERROR);
		}
	}


}

BOOL fSurvillenceConvetToDel(CHAR *RcvMsg)
{

	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR		sSecurityID[SECURITY_ID_LEN];
	CHAR		cProductSource;
	CHAR		cProductDest;
	CHAR		cSide;
	LONG32		iQty;
	CHAR		sExcgId[EXCHANGE_LEN];
	CHAR		sClientId[CLIENT_ID_LEN];
	LONG32		iNoOfRec=0;
	LONG32		iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR		cSegment;	

	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewCTODReq->sClientId,CLIENT_ID_LEN);
	logDebug2("\n sClientId  is n fSurvillenceConvetToDel :%s: ",sClientId );



	/****
	  SELECT  count(1)
INTO :iNoOfRec
from RMS_CLIENT_CONVT_TO_DEL;
	 ******/

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;


	pCTODHdrResp.IntRespHeader.iSeqNo = 0;
	pCTODHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCTODHdrResp.IntRespHeader.iErrorId = 0;
	pCTODHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CONVT_TO_DELV_HEADER_RESP;
	pCTODHdrResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
	//		pCTODHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;

	pCTODHdrResp.cMsgType = 'H';
	pCTODHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pCTODHdrResp.cMsgType:%c:,pCTODHdrResp.iNoofRec:%d:",pCTODHdrResp.cMsgType,pCTODHdrResp.iNoofRec);


	if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pCTODHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}

	/******
	  SELECT	RCCD_SCRIP_CODE,
	  RCCD_EXCHANGE,
	  RCCD_PRODUCT_SOURCE,
	  RCCD_PRODUCT_DESTINATION,
	  RCCD_SIDE,
	  RCCD_QTY,
	  RCCD_CONVT_PRICE,
	  RCCD_SEGMENT
	  FROM RMS_CLIENT_CONVT_TO_DEL;*******/



	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{



			iQty=0;

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);
			/*************
			  :sSecurityID,
			  :sExcgId,
			  :cProductSource,
			  :cProductDest,
			  :cSide,	
			  :iQty,
			  :fConvertPrice,
			  :cSegment;
			 *********/


			pCTODResp.IntRespHeader.iSeqNo = 0;
			pCTODResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY);
			pCTODResp.IntRespHeader.iErrorId = 0;
			pCTODResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CONVT_TO_DELV_RESP;
			pCTODResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
			//		pCTODResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pCTODResp.cMsgType = 'T';
			}
			else
			{
				pCTODResp.cMsgType = 'D';
			}

			strncpy(pCTODResp.subCTOD[j].sClientId,sClientId ,CLIENT_ID_LEN);
			strncpy(pCTODResp.subCTOD[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			pCTODResp.subCTOD[j].cProductSource = cProductSource;
			pCTODResp.subCTOD[j].cProductDest = cProductDest;
			pCTODResp.subCTOD[j].cSide = cSide;
			pCTODResp.subCTOD[j].iQty = iQty;
			pCTODResp.subCTOD[j].fConvertPrice = fConvertPrice;
			pCTODResp.subCTOD[j].cSegment = cSegment;
			strncpy(pCTODResp.subCTOD[j].sExcgId,sExcgId ,EXCHANGE_LEN);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pCTODResp,sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRout2SurvlMapperQ);
			exit(ERROR);
		}
	}
	return TRUE;
}/*** END Survillence Convet to del ******/

BOOL    fDeaClientMapp(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ    *pCliMappReq;
	struct VIEW_COMMON_HDR_RESP     pCliMappHdrRes;
	struct DEALER_MAPP_RESP         pCliMappRes;

	MYSQL_RES       *Res,*Res1;
	MYSQL_ROW       Row,Row1;
	LONG32          iTotalRow;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	CHAR    sEntityId[ENTITY_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	LONG32  i=0,j=0;

	CHAR    *sCliMap = malloc(sizeof(CHAR) *MAX_QUERY_SIZE );
	CHAR    *sQuery = malloc(sizeof(CHAR) *MAX_QUERY_SIZE );

	pCliMappReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;
	strncpy(sEntityId,pCliMappReq->sEntityId,ENTITY_ID_LEN);

	sprintf(sCliMap,"SELECT EDM_CLIENT_ID from ENTITY_DEALER_MAPPING_TEMP WHERE EDM_DEALER_ID = ltrim(rtrim(\"%s\"));",sEntityId);
	logDebug2("[%s]",sCliMap);

	if((mysql_query(DBQueries,sCliMap)) != SUCCESS)
	{
		logSqlFatal("ERROR IN select Client Id QRY");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);

	iTotalRow = mysql_num_rows(Res);
	logDebug2("Total no of Client = %d",iTotalRow);
	fNoOfRec = iTotalRow;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iTotalRow;

	pCliMappHdrRes.IntRespHeader.iSeqNo = 0;
	pCliMappHdrRes.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCliMappHdrRes.IntRespHeader.iErrorId = 0;
	pCliMappHdrRes.IntRespHeader.iMsgCode = TC_INT_DEA_CLIENT_MAPP_HEADER_RESP;
	pCliMappHdrRes.IntRespHeader.iUserId = pCliMappReq->ReqHeader.iUserId;
	//        pCliMappHdrRes.IntRespHeader.cUserTypeOrLogInfoType = pCliMappReq->ReqHeader.cUserType;
	pCliMappHdrRes.cMsgType = 'H';
	pCliMappHdrRes.iNoofRec = iTotalRow;

	if(( WriteMsgQ( iIntActiveToRelDirQ ,(CHAR *)&pCliMappHdrRes,sizeof(struct VIEW_COMMON_HDR_RESP),1) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		exit(ERROR);
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{
				pCliMappRes.IntRespHeader.iSeqNo = 0;
				pCliMappRes.IntRespHeader.iMsgLength = sizeof(struct DEALER_MAPP_RESP);
				pCliMappRes.IntRespHeader.iErrorId = 0;
				pCliMappRes.IntRespHeader.iMsgCode = TC_INT_DEA_CLIENT_MAPP_RESP;
				pCliMappRes.IntRespHeader.iUserId = pCliMappReq->ReqHeader.iUserId;
				//                                pCliMappRes.IntRespHeader.cUserTypeOrLogInfoType = pCliMappReq->ReqHeader.cUserType;

				if(iTempNoOfRec <= 1)
				{
					pCliMappRes.cMsgType = 'T';
				}
				else
				{
					pCliMappRes.cMsgType = 'D';
				}

				strncpy(sClientId,Row[0],12);
				sprintf(sQuery,"SELECT CONCAT(ENTITY_CODE,'|',ENTITY_NAME,'|',ENTITY_ADD_1,'|',ENTITY_ADD_2,'|',ENTITY_ADD_3,'|',\
					ENTITY_PHONE,'|',ENTITY_MOBILE,'|',ENTITY_DOB,'|',ENTITY_PAN,'|',ENTITY_NSE_CODE)AS v_string\
						FROM ENTITY_MASTER where ENTITY_CODE = \"%s\" ",sClientId);	
				logDebug2("sQuery = %s",sQuery);

				if((mysql_query(DBQueries,sQuery)) != SUCCESS)
				{
					logSqlFatal("ERR In fDeaClientMapp QRY.");
					sql_Error(DBQueries);
				}
				Res1 = mysql_store_result(DBQueries);

				if(Row1 = mysql_fetch_row(Res1))
				{
					strncpy(pCliMappRes.subdeamapp[j].sClientString,Row[0],CLI_STRING_LEN);
				}

				logDebug2(".................Printing value..................");
				logDebug3("pCliMappRes.IntRespHeader.iMsgLength = %d ",pCliMappRes.IntRespHeader.iMsgLength);
				logDebug3("pCliMappRes.IntRespHeader.iMsgCode = %d ",pCliMappRes.IntRespHeader.iMsgCode);
				logDebug3("pCliMappRes.IntRespHeader.iUserId = %d ",pCliMappRes.IntRespHeader.iUserId);
				//                                logDebug3("pCliMappRes.IntRespHeader.cUserTypeOrLogInfoType = %c ",pCliMappRes.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug3("pCliMappRes.cMsgType = %c ",pCliMappRes.cMsgType);
				logDebug3("pCliMappRes.subdeamapp[j].sClientString = %s ",pCliMappRes.subdeamapp[j].sClientString);

				free(Res1);
				iTempNoOfRec--;
			}

		}

		if(WriteMsgQ(iIntActiveToRelDirQ, (CHAR *)&pCliMappRes,sizeof(struct DEALER_MAPP_RESP),1) != TRUE)
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id = %d", iSTWRelToQueryQ);
			exit(ERROR);
		}

		usleep(100);

	}

	return TRUE;

}
