#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "IPCS.h"
#include "DWSRelay.h"

LONG32	STWRelToRmsDirQ ;
LONG32	iTrdRtrToRevMap ;
struct  DWS_ORDER_RESP		pDWS_RESP;
struct  DWS_CON_TO_DELIVERY_RESPONSE	pC2D_RESP;
//struct  INT_MTM_BREACH_RESP pBreachMTM; 

main (int argc, char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	fOpenMessgQ();
	fMapper();
}

BOOL fMapper()
{
	struct INT_COMMON_RESP_HDR 	*pRespHeader;
	struct 	ORDER_RESPONSE 		*pORDER_RESP ;	
	struct  INT_ERROR_FE_RESP	*pErrResp;
	struct  INT_ERRORRESPONCESEND 	pErrOut;

	LONG32  relayid         =       0;
	LONG32  UserRelayId     =       0;

	CHAR	RcvMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    SndMsg[LOCAL_MAX_PACKET_SIZE]	;
	CHAR    BasicError[ERROR_MSG_LEN]	;
	LONG32	iMsgCode;

	CHAR	sTempIPCS[7];
	CHAR	sTempShm[7];

	while ( 1 )
	{
		memset( &RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &SndMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &BasicError,'\0', ERROR_MSG_LEN);
		iMsgCode = 0;
		relayid = 0;
		UserRelayId =0;


		logDebug2("#########Waiting in while loop to get the data ################# %d",iTrdRtrToRevMap);

		if((ReadMsgQ( iTrdRtrToRevMap, &RcvMsg, LOCAL_MAX_PACKET_SIZE, 0)) != 1)
		{
			perror("Error ReadMsgQ Q : ");
			logDebug2("(DWSMapper)Error ReadMsgQ Q :Qid %d", iTrdRtrToRevMap);
			exit(ERROR);
		}

		pRespHeader=(struct INT_COMMON_RESP_HDR *) &RcvMsg ;	


		iMsgCode = pRespHeader->iMsgCode;
		logDebug2("iMsgCode :%d:",iMsgCode);

		switch (iMsgCode)
		{	
			case TC_INT_MKT_LMT_CONVT_RESP 	:
			case TC_INT_OE_CONF_RESP	:
			case TC_INT_OM_CONF_RESP	:
			case TC_INT_OC_CONF_RESP	:
			case TC_INT_OE_ERROR_RESP	:
			case TC_INT_OM_ERROR_RESP	:
			case TC_INT_OC_ERROR_RESP	:
			case TC_INT_OE_FREEZE_RESP	:
			case TC_INT_SL_ORDER_TRIG_RESP	:
			case TC_INT_NOTIFICATION_REQ    :


				pORDER_RESP	=(struct ORDER_RESPONSE *) &RcvMsg ;
				memset(&pDWS_RESP,'\0',sizeof(struct DWS_ORDER_RESP));


				logDebug2("pORDER_RESP->sExchOrderID :%s:",pORDER_RESP->sExchOrderID);

				//pDWS_RESP.IntRespHeader.cSource			= pORDER_RESP->IntRespHeader.cSource ;
				pDWS_RESP.IntRespHeader.iSeqNo 			= pORDER_RESP->IntRespHeader.iSeqNo;
				pDWS_RESP.IntRespHeader.iMsgLength 		= sizeof(struct DWS_ORDER_RESP);
				pDWS_RESP.IntRespHeader.iMsgCode 		= pORDER_RESP->IntRespHeader.iMsgCode;
				pDWS_RESP.IntRespHeader.iErrorId 		= pORDER_RESP->IntRespHeader.iErrorId;
				//				strncpy(pDWS_RESP.sReasonDesc,pORDER_RESP->sReasonDesc,REASON_DESC_LEN);
				//				strncpy(pDWS_RESP.sLegValue,pORDER_RESP->sLegValue,LEG_LEN);
				//				pDWS_RESP.sLegValue = pORDER_RESP->iLegValue ;
				pDWS_RESP.IntRespHeader.iUserIdOrLogPktId 	= pORDER_RESP->IntRespHeader.iUserId;
				UserRelayId 					= pORDER_RESP->IntRespHeader.iUserId;
				pDWS_RESP.IntRespHeader.cUserTypeOrLogInfoType 	= pORDER_RESP->cUserType;
				pDWS_RESP.IntRespHeader.iTimeStamp 		= pORDER_RESP->IntRespHeader.iTimeStamp;
				pDWS_RESP.IntRespHeader.cSegment 		= pORDER_RESP->IntRespHeader.cSegment;
				logDebug2("pORDER_RESP->IntRespHeader.cSegment :%c: pDWS_RESP.IntRespHeader.cSegment :%c:",pORDER_RESP->IntRespHeader.cSegment,pDWS_RESP.IntRespHeader.cSegment);

				strncpy(pDWS_RESP.IntRespHeader.sExcgId,pORDER_RESP->IntRespHeader.sExcgId,EXCHANGE_LEN);

				pDWS_RESP.fOrderNum = pORDER_RESP->fOrderNum;

				strncpy(pDWS_RESP.sAccCode,pORDER_RESP->sClientId,CLIENT_ID_LEN);
				logDebug2("pORDER_RESP->BuyOrSell :%c:",pORDER_RESP->cBuyOrSell);

				if(pORDER_RESP->cBuyOrSell == INT_BUY)
				{
					pDWS_RESP.iBuyOrSell = 1;
				}
				else if(pORDER_RESP->cBuyOrSell == INT_SELL)
				{
					pDWS_RESP.iBuyOrSell = 2;
				}
				pDWS_RESP.iDiscQty 		= pORDER_RESP->iDiscQty;
				pDWS_RESP.iDiscQtyRemaining 	= pORDER_RESP->iDiscQtyRem;
				pDWS_RESP.iTotalQtyRemaining	= pORDER_RESP->iTotalQtyRem;
				pDWS_RESP.iQtyFilledToday 	= pORDER_RESP->iTotalTradedQty;
				if((pORDER_RESP->IntRespHeader.iMsgCode == TC_INT_NOTIFICATION_REQ ) || (pORDER_RESP->IntRespHeader.iMsgCode == TC_INT_OC_CONF_RESP))
				{
					pDWS_RESP.iTotalQty  =  pORDER_RESP->iTotalQty ;
				}
				else
				{
					pDWS_RESP.iTotalQty 		= pORDER_RESP->iTotalTradedQty + pORDER_RESP->iTotalQtyRem;
				}
				pDWS_RESP.fPrice 		= pORDER_RESP->fPrice;
				pDWS_RESP.fTriggerPrice 	= pORDER_RESP->fTriggerPrice;
				pDWS_RESP.iOrdSerialNo 		= pORDER_RESP->iSerialNum;

				//				pDWS_RESP.iStratergyId		= pORDER_RESP->iStratergyId;
				//				pDWS_RESP.cProClient		= pORDER_RESP->cProCli;



				strncpy(pDWS_RESP.sEntityId,pORDER_RESP->sEntityId,CLIENT_ID_LEN);
				strncpy(pDWS_RESP.sSecurityId,pORDER_RESP->sSecurityId,SECURITY_ID_LEN);
				strncpy(pDWS_RESP.sClientId,pORDER_RESP->sClientId,CLIENT_ID_LEN);
				logDebug2("pDWS_RESP.sClientId :%s: pORDER_RESP->sClientId :%s:",pDWS_RESP.sClientId,pORDER_RESP->sClientId);
				strncpy(pDWS_RESP.sExchOrderNum,pORDER_RESP->sExchOrderID,BSE_EXCH_ORDER_NO_LEN);

				logDebug2("pDWS_RESP.sExchOrderNum :%s:  pORDER_RESP->sExchOrderID:%s:",pDWS_RESP.sExchOrderNum,pORDER_RESP->sExchOrderID);
				logDebug2(" pORDER_RESP->IntRespHeader.sExcgId:%s::%d:",pORDER_RESP->IntRespHeader.sExcgId,strlen(pORDER_RESP->IntRespHeader.sExcgId));

				logDebug2("pORDER_RESP->fPrice :%f",pORDER_RESP->fPrice);
				pDWS_RESP.cProductId = pORDER_RESP->cProductId;
				pDWS_RESP.sFlag[0] = '0';
				pDWS_RESP.sFlag[1] = '0';
				pDWS_RESP.sFlag[2] = '0';
				pDWS_RESP.sFlag[3] = '0';
				pDWS_RESP.sFlag[4] = '0';
				pDWS_RESP.sFlag[6] = '0';
				logDebug2("pORDER_RESP->iOrderType :%d:",pORDER_RESP->iOrderType);

				switch(pORDER_RESP->iOrderType)
				{

					case ORD_TYPE_STOP_LIMIT :
						pDWS_RESP.sFlag[3] = '1' ;
						pDWS_RESP.sFlag[2] = '0' ;	
						break;
					case ORD_TYPE_MKT :
						pDWS_RESP.sFlag[3] = '0' ;
						pDWS_RESP.sFlag[2] = '1' ;
						break;
					case ORD_TYPE_STOP_LOSS_MKT :
						pDWS_RESP.sFlag[3] = '1' ;
						pDWS_RESP.sFlag[2] = '1' ;
						break;

					case ORD_TYPE_LIMIT:
						pDWS_RESP.sFlag[3] = '0' ;
						pDWS_RESP.sFlag[2] = '0' ;
						break;
					default:
						logDebug2("Invalid OrderType");
				}

				if(pORDER_RESP->iOrderValidity == VALIDITY_DAY)
				{
					pDWS_RESP.sFlag[0] = '1';	
				}
				else if( pORDER_RESP->iOrderValidity == VALIDITY_IOC)
				{
					pDWS_RESP.sFlag[1] = '1';
				}

				pDWS_RESP.iTradeNumber 	= 0;
				pDWS_RESP.iQtyTraded 	= 0;
				pDWS_RESP.fTradePrice 	= 0;
				fPrintStruct();

				relayid = find_user_adapter(UserRelayId);	

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2("there is some problem with shared memory not sending the packet");
					continue;
				}
				if(( WriteMsgQ( STWRelToRmsDirQ , (CHAR *)&pDWS_RESP,sizeof(struct DWS_ORDER_RESP) ,relayid ) != TRUE ))
				{
					perror("Error WriteMsgQ : ");
					logDebug2("WriteMsgQ  id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}

				break;

			case TC_INT_ORDER_ENTRY_RSP:
			case TC_INT_ORDER_MODIFY_RSP:
			case TC_INT_ORDER_CANCEL_RSP:
			case TC_INT_ADMIN_EXPIRY_RESP:
			case TC_INT_OFF_ORDER_ENTRY_RSP:
			case TC_INT_OFF_ORDER_MODIFY_RSP:
			case TC_INT_OFF_ORDER_CANCEL_RSP:	

				pORDER_RESP	=(struct ORDER_RESPONSE *) &RcvMsg ;
				memset(&pDWS_RESP,'\0',sizeof(struct DWS_ORDER_RESP));


				//				pDWS_RESP.IntRespHeader.cSource			= pORDER_RESP->IntRespHeader.cSource;
				pDWS_RESP.IntRespHeader.iSeqNo 			= pORDER_RESP->IntRespHeader.iSeqNo;
				pDWS_RESP.IntRespHeader.iMsgLength 		= sizeof(struct DWS_ORDER_RESP);
				pDWS_RESP.IntRespHeader.iMsgCode 		= pORDER_RESP->IntRespHeader.iMsgCode;
				pDWS_RESP.IntRespHeader.iErrorId 		= pORDER_RESP->IntRespHeader.iErrorId;
				pDWS_RESP.IntRespHeader.iUserIdOrLogPktId 	= pORDER_RESP->IntRespHeader.iUserId;
				UserRelayId 					= pORDER_RESP->IntRespHeader.iUserId;
				pDWS_RESP.IntRespHeader.cUserTypeOrLogInfoType 	= pORDER_RESP->cUserType;
				pDWS_RESP.IntRespHeader.iTimeStamp 		= pORDER_RESP->IntRespHeader.iTimeStamp;
				pDWS_RESP.IntRespHeader.cSegment 		= pORDER_RESP->IntRespHeader.cSegment;

				strncpy(pDWS_RESP.IntRespHeader.sExcgId,pORDER_RESP->IntRespHeader.sExcgId,EXCHANGE_LEN);


				pDWS_RESP.fOrderNum 			= pORDER_RESP->fOrderNum;

				strncpy(pDWS_RESP.sAccCode,pORDER_RESP->sClientId,CLIENT_ID_LEN);
				logDebug2(" pORDER_RESP->BuyOrSell :%c:",pORDER_RESP->cBuyOrSell);

				if(pORDER_RESP->cBuyOrSell == INT_BUY)
				{
					pDWS_RESP.iBuyOrSell = 1;
				}
				else if(pORDER_RESP->cBuyOrSell == INT_SELL)
				{
					pDWS_RESP.iBuyOrSell = 2;
				}
				pDWS_RESP.iDiscQty 		= pORDER_RESP->iDiscQty;
				pDWS_RESP.iDiscQtyRemaining 	= pORDER_RESP->iDiscQtyRem;
				pDWS_RESP.iTotalQtyRemaining 	= pORDER_RESP->iTotalQtyRem;
				pDWS_RESP.iTotalQty 		= pORDER_RESP->iTotalQtyRem + pORDER_RESP->iTotalTradedQty;
				pDWS_RESP.iQtyFilledToday 	= pORDER_RESP->iTotalTradedQty;
				pDWS_RESP.fPrice 		= pORDER_RESP->fPrice;
				pDWS_RESP.fTriggerPrice 	= pORDER_RESP->fTriggerPrice;
				pDWS_RESP.iOrdSerialNo 		= pORDER_RESP->iSerialNum;
				pDWS_RESP.cProductId = pORDER_RESP->cProductId;

				strncpy(pDWS_RESP.sEntityId,pORDER_RESP->sEntityId,CLIENT_ID_LEN);
				strncpy(pDWS_RESP.sSecurityId,pORDER_RESP->sSecurityId,SECURITY_ID_LEN);
				strncpy(pDWS_RESP.sClientId,pORDER_RESP->sClientId,CLIENT_ID_LEN);
				strncpy(pDWS_RESP.sExchOrderNum," ",BSE_EXCH_ORDER_NO_LEN); 


				/****		pDWS_RESP.sFlag[0] = pORDER_RESP->DayFlag;
				  pDWS_RESP.sFlag[1] = pORDER_RESP->IOCFlag;
				  pDWS_RESP.sFlag[2] = pORDER_RESP->MKTFlag;
				  pDWS_RESP.sFlag[3] = pORDER_RESP->StopLossFlag;
				  pDWS_RESP.sFlag[4] = pORDER_RESP->AONFlag;
				  pDWS_RESP.sFlag[6] = pORDER_RESP->ProCli[0];*****/

				pDWS_RESP.sFlag[0] = '0';
				pDWS_RESP.sFlag[1] = '0';
				pDWS_RESP.sFlag[2] = '0';
				pDWS_RESP.sFlag[3] = '0';
				pDWS_RESP.sFlag[4] = '0';
				pDWS_RESP.sFlag[6] = '0';
				logDebug2("pORDER_RESP->iOrderType :%d:",pORDER_RESP->iOrderType);	
				switch(pORDER_RESP->iOrderType)
				{

					case ORD_TYPE_STOP_LIMIT :
						pDWS_RESP.sFlag[3] = '1' ;
						pDWS_RESP.sFlag[2] = '0' ;
						break;
					case ORD_TYPE_MKT :
						pDWS_RESP.sFlag[3] = '0' ;
						pDWS_RESP.sFlag[2] = '1' ;
						break;

					case ORD_TYPE_STOP_LOSS_MKT :
						pDWS_RESP.sFlag[3] = '1' ;
						pDWS_RESP.sFlag[2] = '1' ;
						break;

					case ORD_TYPE_LIMIT:
						pDWS_RESP.sFlag[3] = '0' ;
						pDWS_RESP.sFlag[2] = '0' ;
						break;
					default:
						logDebug2("Invalid OrderType");
				}

				if(pORDER_RESP->iOrderValidity == VALIDITY_DAY)
				{
					pDWS_RESP.sFlag[0] = '1';
				}
				else if( pORDER_RESP->iOrderValidity == VALIDITY_IOC)
				{
					pDWS_RESP.sFlag[1] = '1';
				}	
				else if(pORDER_RESP->iOrderValidity == VALIDITY_EOS)
				{
					pDWS_RESP.sFlag[8] = '1';
				}


				pDWS_RESP.iTradeNumber = 0;
				pDWS_RESP.iQtyTraded = 0;
				pDWS_RESP.fTradePrice = 0;

				logDebug2("pDWS_RESP.Price :%lf:  pORDER_RESP->Price :%lf:",pDWS_RESP.fPrice,pORDER_RESP->fPrice);

				fPrintStruct();

				relayid = find_user_adapter(UserRelayId);

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2("\n Relay No for this particular userid is not found :%d:",UserRelayId);
					continue;
				}

				if(( WriteMsgQ( STWRelToRmsDirQ , (CHAR *)&pDWS_RESP,sizeof(struct DWS_ORDER_RESP) ,relayid ) != TRUE ))
				{	
					perror("Error WriteMsgQ: ");
					logDebug2("Write Q id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}

				break; 


			case TC_INT_CON_DEL_RESP:

				logDebug2("Inside TC_INT_CON_DEL_RESP case");

				struct CON_TO_DELIVERY_RESPONSE  *pResp = (struct CON_TO_DELIVERY_RESPONSE *) &RcvMsg ;
				memset(&pC2D_RESP,'\0',sizeof(struct DWS_CON_TO_DELIVERY_RESPONSE));

				pC2D_RESP.RespHeader.iSeqNo 		= pResp->RespHeader.iSeqNo;
				pC2D_RESP.RespHeader.iMsgLength 		= sizeof(struct DWS_CON_TO_DELIVERY_RESPONSE);
				pC2D_RESP.RespHeader.iMsgCode 		= pResp->RespHeader.iMsgCode;
				pC2D_RESP.RespHeader.iErrorId	 	= pResp->RespHeader.iErrorId;
				pC2D_RESP.RespHeader.iUserIdOrLogPktId 	= pResp->RespHeader.iUserId;
				pC2D_RESP.RespHeader.cUserTypeOrLogInfoType = pResp->cUserType;
				pC2D_RESP.RespHeader.iTimeStamp 		= pResp->RespHeader.iTimeStamp;
				pC2D_RESP.RespHeader.cSegment 		= pResp->RespHeader.cSegment;
				UserRelayId 				= pResp->RespHeader.iUserId;

				strncpy(pC2D_RESP.sSecurityId,pResp->sSecurityId,SECURITY_ID_LEN);
				strncpy(pC2D_RESP.RespHeader.sExcgId,pResp->RespHeader.sExcgId,EXCHANGE_LEN);
				strncpy(pC2D_RESP.sEntityId,pResp->sEntityId,ENTITY_ID_LEN);
				strncpy(pC2D_RESP.sClientId,pResp->sClientId,CLIENT_ID_LEN);

				pC2D_RESP.cBuyOrSell 			= pResp->cBuyOrSell;
				pC2D_RESP.cProdIdFrom			= pResp->cProdIdFrom;
				pC2D_RESP.cProdIdTo 			= pResp->cProdIdTo;
				pC2D_RESP.iQty 				= pResp->iQty;
				pC2D_RESP.iMktType 			= pResp->iMktType;

				relayid = find_user_adapter(UserRelayId);

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2("Relay No for this particular userid is not found :%d:",UserRelayId);
					continue;
				}


				if(( WriteMsgQ( STWRelToRmsDirQ , (CHAR *)&pC2D_RESP,sizeof(struct DWS_CON_TO_DELIVERY_RESPONSE) ,relayid ) != TRUE ))
				{
					perror("Error WriteMsgQ: ");
					logDebug2("Write Q id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}

				break;



			case TC_INT_TRADE_RESP:

				pORDER_RESP=(struct ORDER_RESPONSE *) &RcvMsg ;
				memset(&pDWS_RESP,'\0',sizeof(struct DWS_ORDER_RESP));

				pDWS_RESP.IntRespHeader.iSeqNo 		= pORDER_RESP->IntRespHeader.iSeqNo;
				pDWS_RESP.IntRespHeader.iMsgLength 	= sizeof(struct DWS_ORDER_RESP);
				pDWS_RESP.IntRespHeader.iMsgCode 	= pORDER_RESP->IntRespHeader.iMsgCode;
				pDWS_RESP.IntRespHeader.iErrorId 	= pORDER_RESP->IntRespHeader.iErrorId;
				pDWS_RESP.IntRespHeader.iUserIdOrLogPktId = pORDER_RESP->IntRespHeader.iUserId;
				UserRelayId 				= pORDER_RESP->IntRespHeader.iUserId;
				pDWS_RESP.IntRespHeader.cUserTypeOrLogInfoType = pORDER_RESP->cUserType;
				pDWS_RESP.IntRespHeader.iTimeStamp 		= pORDER_RESP->IntRespHeader.iTimeStamp;
				pDWS_RESP.IntRespHeader.cSegment 		= pORDER_RESP->IntRespHeader.cSegment;


				strncpy(pDWS_RESP.IntRespHeader.sExcgId,pORDER_RESP->IntRespHeader.sExcgId,EXCHANGE_LEN);


				pDWS_RESP.fOrderNum = pORDER_RESP->fOrderNum;
				strncpy(pDWS_RESP.sAccCode,pORDER_RESP->sClientId,CLIENT_ID_LEN);
				logDebug2("pORDER_RESP->BuyOrSell :%c:",pORDER_RESP->cBuyOrSell);

				if(pORDER_RESP->cBuyOrSell == INT_BUY)
				{
					pDWS_RESP.iBuyOrSell = 1;
				}
				else if(pORDER_RESP->cBuyOrSell == INT_SELL)
				{
					pDWS_RESP.iBuyOrSell = 2;
				}
				pDWS_RESP.iDiscQty 		= pORDER_RESP->iDiscQty;
				pDWS_RESP.iDiscQtyRemaining 	= pORDER_RESP->iDiscQtyRem;
				pDWS_RESP.iTotalQtyRemaining 	= pORDER_RESP->iTotalQtyRem;
				/*	**  pDWS_RESP.TotalQty = pORDER_RESP->OriginalQty;***/ /** Changed to Show total Qty in system**/
				if((pORDER_RESP->iOrderValidity == VALIDITY_IOC )&&  (strncmp(pORDER_RESP->IntRespHeader.sExcgId,BSE_EXCH,EXCHANGE_LEN) == 0) )
				{
					pDWS_RESP.iTotalQty = pORDER_RESP->iTotalQty;	
				}
				else
				{
					pDWS_RESP.iTotalQty= pORDER_RESP->iTotalQtyRem + pORDER_RESP->iTotalTradedQty;
				}
				pDWS_RESP.iQtyFilledToday 	= pORDER_RESP->iTotalTradedQty;
				pDWS_RESP.fPrice 		= pORDER_RESP->fPrice;
				pDWS_RESP.fTriggerPrice 		=	 0;
				pDWS_RESP.iOrdSerialNo 		= pORDER_RESP->iSerialNum;
				//				pDWS_RESP.cProClient		= pORDER_RESP->cProCli;
				//				pDWS_RESP.iStratergyId		= pORDER_RESP->iStratergyId; 
				strncpy(pDWS_RESP.sEntityId,pORDER_RESP->sEntityId,CLIENT_ID_LEN);
				strncpy(pDWS_RESP.sSecurityId,pORDER_RESP->sSecurityId,SECURITY_ID_LEN);

				logDebug2("Nishant pDWS_RESP.SecurityId :%s: pORDER_RESP->sSecurityId:%s:",pDWS_RESP.sSecurityId,pORDER_RESP->sSecurityId);

				strncpy(pDWS_RESP.sClientId,pORDER_RESP->sClientId,CLIENT_ID_LEN);
				logDebug2("pDWS_RESP.sClientId :%s: pORDER_RESP->sClientId :%s:",pDWS_RESP.sClientId,pORDER_RESP->sClientId);
				strncpy(pDWS_RESP.sExchOrderNum,pORDER_RESP->sExchOrderID,NSE_EXCH_ORDER_NO_LEN);
				logDebug2("Nishant_sExchOrderNum pDWS_RESP.sExchOrderNum :%s:  pORDER_RESP->sExchOrderID :%s:",pDWS_RESP.sExchOrderNum,pORDER_RESP->sExchOrderID);

				pDWS_RESP.sFlag[0] = '0';
				pDWS_RESP.sFlag[1] = '0';
				pDWS_RESP.sFlag[2] = '0';
				pDWS_RESP.sFlag[3] = '0';
				pDWS_RESP.sFlag[4] = '0';
				pDWS_RESP.sFlag[6] = '0';

				switch(pORDER_RESP->iOrderType)
				{

					case ORD_TYPE_STOP_LIMIT :
						pDWS_RESP.sFlag[3] = '1' ;
						pDWS_RESP.sFlag[2] = '0' ;
						break;
					case ORD_TYPE_MKT :
						pDWS_RESP.sFlag[3] = '0' ;
						pDWS_RESP.sFlag[2] = '1' ;
						break;

					case ORD_TYPE_STOP_LOSS_MKT :
						pDWS_RESP.sFlag[3] = '1' ;
						pDWS_RESP.sFlag[2] = '1' ;
						break;

					case ORD_TYPE_LIMIT:
						pDWS_RESP.sFlag[3] = '0' ;
						pDWS_RESP.sFlag[2] = '0' ;
						break;
					default:
						logDebug2("Invalid OrderType :%d:",pORDER_RESP->iOrderType);
						break;
				}

				if(pORDER_RESP->iOrderValidity == VALIDITY_DAY)
				{
					pDWS_RESP.sFlag[0] = '1';
				}
				else if( pORDER_RESP->iOrderValidity == VALIDITY_IOC)
				{
					pDWS_RESP.sFlag[1] = '1';
				}

				pDWS_RESP.cProductId 	= pORDER_RESP->cProductId;
				logDebug2("pORDER_RESP->sTradeNo :%s:",pORDER_RESP->sTradeNo);
				pDWS_RESP.iTradeNumber 	= atoi(pORDER_RESP->sTradeNo);
				pDWS_RESP.iQtyTraded 	= pORDER_RESP->iLastTradedQty;
				pDWS_RESP.fTradePrice 	= pORDER_RESP->fTradePrice;

				fPrintStruct();

				relayid = find_user_adapter(UserRelayId);

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2("\n Relay No for this particular userid is not found :%d:",UserRelayId);
					continue;
				}




				if(( WriteMsgQ( STWRelToRmsDirQ , (CHAR *)&pDWS_RESP,sizeof(struct DWS_ORDER_RESP) ,relayid ) != TRUE ))
				{
					perror("Error WriteMsgQ: ");
					logDebug2("Write Q id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}
				break;

			case TC_INT_ORDER_REJECTION:
			case TC_INT_RMS_ORD_REJECTION:

				memset(&pErrOut,'\0',sizeof(struct INT_ERRORRESPONCESEND));

				pErrResp = (struct INT_ERROR_FE_RESP *)&RcvMsg ;

				//logDebug2("\n SeqNo :%d:  ",pErrResp->IntRespHeader.iSeqNo);	
				pErrOut.IntRespHeader.iSeqNo 		= pErrResp->IntRespHeader.iSeqNo;
				pErrOut.IntRespHeader.iMsgLength 	= sizeof(struct INT_ERRORRESPONCESEND);
				pErrOut.IntRespHeader.iMsgCode 		= pErrResp->IntRespHeader.iMsgCode;
				pErrOut.IntRespHeader.iErrorId 		= pErrResp->IntRespHeader.iErrorId;
				pErrOut.IntRespHeader.iUserIdOrLogPktId 	= pErrResp->IntRespHeader.iUserId;

				UserRelayId = pErrResp->IntRespHeader.iUserId;

				pErrOut.IntRespHeader.iTimeStamp 	= pErrResp->IntRespHeader.iTimeStamp;
				pErrOut.IntRespHeader.cSegment 		= pErrResp->IntRespHeader.cSegment;

				strncpy(pErrOut.IntRespHeader.sExcgId,pErrResp->IntRespHeader.sExcgId,EXCHANGE_LEN);	
				strncpy(pErrOut.sErrorMessage,pErrResp->sErrorMsg,ERROR_MESSAGE_LEN);
				logDebug2("UserRelayId  not error 12 UserRelayId :%d:",UserRelayId);


				relayid = find_user_adapter(UserRelayId);

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2(" UserRelayId No for this particular userid is not found :%d:",UserRelayId);
					continue;
				}


				if( WriteMsgQ( STWRelToRmsDirQ , (CHAR *)&pErrOut,sizeof(struct INT_ERRORRESPONCESEND) ,relayid ) != TRUE )
				{	
					perror("Error WriteMsgQ: ");
					logDebug2("Write Q id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}
				break;

			case TC_INT_MTM_BREACH_RSP:
				/*memset(&pBreachMTM,'\0',sizeof(struct INT_MTM_BREACH_RESP));

				//pORDER_RESP = (struct INT_MTM_BREACH_RESP *)&RcvMsg ;

				//logDebug2("\n SeqNo :%d:  ",pErrResp->IntRespHeader.iSeqNo);     
				pBreachMTM.IntRespHeader.SeqNo = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.iSeqNo;
				pBreachMTM.IntRespHeader.MsgLength = sizeof(struct INT_MTM_BREACH_RESP);
				pBreachMTM.IntRespHeader.MsgCode = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.iMsgCode;
				pBreachMTM.IntRespHeader.ErrorId = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.iErrorId;
				pBreachMTM.IntRespHeader.UserIdOrLogPktId = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.iUserId;
				pBreachMTM.IntRespHeader.TimeStamp = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.iTimeStamp;
				pBreachMTM.IntRespHeader.Segment = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.cSegment;
				strncpy(pBreachMTM.IntRespHeader.ExcgId,((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.sExcgId,EXCHANGE_LEN);
				pBreachMTM.fMTMPercent = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->fMTMPercent;*/
				UserRelayId = ((struct INT_MTM_BREACH_RESP *)&RcvMsg)->IntRespHeader.iUserId;

				logDebug2("\n iMsgCode :%d:",iMsgCode);

				logDebug2("\n THis is not error 12 :%d:",UserRelayId);

				relayid = find_user_adapter(UserRelayId);

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2("\n Relay No for this particular userid is not found :%d:",UserRelayId);
					continue;
				}


				if( WriteMsgQ( STWRelToRmsDirQ , (CHAR *)&RcvMsg, sizeof(struct INT_MTM_BREACH_RESP) ,relayid ) != TRUE )
				{
					perror("Error WriteMsgQ: ");
					logDebug2("Write Q id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}

				break;

			default:

				logDebug2("Here In Default Case");				
				pRespHeader = (struct INT_COMMON_RESP_HDR *) &RcvMsg ;

				UserRelayId = pRespHeader->iUserId;

				relayid = find_user_adapter(UserRelayId);

				if(relayid == FIND_USER_RELAY_ERROR)
				{
					logDebug2("Relay No for this particular userid is not found :%d:",UserRelayId);
					continue;
				}


				if(( WriteMsgQ( STWRelToRmsDirQ ,&RcvMsg,2048 ,relayid ) != TRUE ))
				{
					perror("Error WriteMsgQ: ");
					logDebug2("Write Q id %d", STWRelToRmsDirQ);
					exit(ERROR);
				}
				break;

		}


	}

}
BOOL fOpenMessgQ()
{
	logDebug2("TrdRtrToRel :%ld:",TrdRtrToRel);	

	if( ( iTrdRtrToRevMap = OpenMsgQ( (TrdRtrToRel))) == ERROR )
	{
		perror("Open DWSRelayToMapper :");
		exit( 1 );
	}
	if( ( STWRelToRmsDirQ = OpenMsgQ( (RevMapToDWSRel))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	return TRUE;

}
BOOL fPrintStruct()
{

	logDebug2("--------------------PRINTING  DWS_ORDER_RESPONCE----------------");
	logDebug2(" pDWS_RESP.IntRespHeader.iSeqNo 		:%d:",pDWS_RESP.IntRespHeader.iSeqNo);
	logDebug2(" pDWS_RESP.IntRespHeader.iMsgLength 		:%d:",pDWS_RESP.IntRespHeader.iMsgLength);
	logDebug2(" pDWS_RESP.IntRespHeader.iMsgCode 		:%d:",pDWS_RESP.IntRespHeader.iMsgCode);
	logDebug2(" pDWS_RESP.IntRespHeader.sExcgId 		:%s:",pDWS_RESP.IntRespHeader.sExcgId);
	logDebug2(" pDWS_RESP.IntRespHeader.iErrorId 		:%d:",pDWS_RESP.IntRespHeader.iErrorId);
	logDebug2(" pDWS_RESP.IntRespHeader.iUserIdOrLogPktId 	:%d:",pDWS_RESP.IntRespHeader.iUserIdOrLogPktId);
	logDebug2(" pDWS_RESP.IntRespHeader.cUserTypeOrLogInfoType :%c:",pDWS_RESP.IntRespHeader.cUserTypeOrLogInfoType);
	logDebug2(" pDWS_RESP.IntRespHeader.cSegment 		:%c:",pDWS_RESP.IntRespHeader.cSegment);
	logDebug2(" pDWS_RESP.IntRespHeader.iTimeStamp 		:%d:",pDWS_RESP.IntRespHeader.iTimeStamp);
	//	logDebug2(" pDWS_RESP.IntRespHeader.cSource 		:%c:",pDWS_RESP.IntRespHeader.cSource);


	logDebug2(" pDWS_RESP.fOrderNum 			:%lf:",pDWS_RESP.fOrderNum);
	logDebug2(" pDWS_RESP.sAccCode 			:%s:[%d]",pDWS_RESP.sAccCode,strlen(pDWS_RESP.sAccCode));
	logDebug2(" pDWS_RESP.iBuyOrSell 		:%d:",pDWS_RESP.iBuyOrSell);
	logDebug2(" pDWS_RESP.iDiscQty 			:%d:",pDWS_RESP.iDiscQty);
	logDebug2(" pDWS_RESP.iDiscQtyRemaining 		:%d:",pDWS_RESP.iDiscQtyRemaining);
	logDebug2(" pDWS_RESP.iTotalQtyRemaining 	:%d:",pDWS_RESP.iTotalQtyRemaining);
	logDebug2(" pDWS_RESP.iTotalQty 			:%d:",pDWS_RESP.iTotalQty);
	logDebug2(" pDWS_RESP.iQtyFilledToday 		:%d:",pDWS_RESP.iQtyFilledToday);
	logDebug2(" pDWS_RESP.fPrice 			:%lf:",pDWS_RESP.fPrice);
	logDebug2(" pDWS_RESP.fTriggerPrice 		:%lf:",pDWS_RESP.fTriggerPrice);
	logDebug2(" pDWS_RESP.sEntityId 		:%s:[%d]",pDWS_RESP.sEntityId,strlen(pDWS_RESP.sEntityId));
	logDebug2(" pDWS_RESP.iOrdSerialNo 		:%d:",pDWS_RESP.iOrdSerialNo);
	logDebug2(" pDWS_RESP.sSecurityId 		:%s:",pDWS_RESP.sSecurityId);
	logDebug2(" pDWS_RESP.sClientId 		:%s:[%d]",pDWS_RESP.sClientId,strlen(pDWS_RESP.sClientId));
	logDebug2(" pDWS_RESP.sExchOrderNum 		:%s:",pDWS_RESP.sExchOrderNum);
	logDebug2(" pDWS_RESP.iProductId 		:%c:",pDWS_RESP.cProductId);
	logDebug2(" pDWS_RESP.sFlag 			:%s:",pDWS_RESP.sFlag);
	logDebug2(" pDWS_RESP.iTradeNumber 		:%d:",pDWS_RESP.iTradeNumber);
	logDebug2(" pDWS_RESP.iQtyTraded 		:%d:",pDWS_RESP.iQtyTraded);
	logDebug2(" pDWS_RESP.fTradePrice 		:%lf:",pDWS_RESP.fTradePrice);
	//	logDebug2(" pDWS_RESP.iStratergyId		:%d:",pDWS_RESP.iStratergyId);	
	//	logDebug2("pDWS_RESP.cProClient			:%c:",pDWS_RESP.cProClient);        
	//	logDebug2("pDWS_RESP.sReasonDesc		:%s:",pDWS_RESP.sReasonDesc);
	//	logDebug2("pDWS_RESP.sLegValue			:%s:",pDWS_RESP.sLegValue);



}
