#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>
#include <unistd.h>

/* Typical include path would be <librdkafka/rdkafka.h>, but this program is builtin from within the librdkafka source tree and thus differs. */
#include "rdkafka.h"
#include "IPCS.h"

static volatile sig_atomic_t run = 1;

/* @brief Signal termination of program */
static void stop(int sig) {
        run = 0;
}

/* @returns 1 if all bytes are printable, else 0. */
static int is_printable(const char *buf, size_t size) {
        size_t i;

        for (i = 0; i < size; i++)
                if (!isprint((int)buf[i]))
                        return 0;

        return 1;
}

LONG32 iMmapToD2C1 = 0;
LONG32 iMmapToDWSTrdRtr = 0;
LONG32 iMmapToAdmnTrdRtr = 0 ; 

rd_kafka_t *rk;          /* Consumer instance handle */
rd_kafka_conf_t *conf;   /* Temporary configuration object */
rd_kafka_resp_err_t err; /* librdkafka API error code */
char errstr[512];        /* librdkafka API error reporting buffer */
const char *brokers;     /* Argument: broker list */
const char *groupid;     /* Argument: Consumer group id */
char **topics;           /* Argument: list of topics to subscribe to */
int topic_cnt;           /* Number of topics to subscribe to */
rd_kafka_topic_partition_list_t *subscription; /* Subscribed topics */
int i;
int iCnt = 0;
int   iCount = 0;
//bool fSendMsg(CHAR *RcvMsg);
int main(int argc, char **argv) {
        
	/* Argument validation*/
        if (argc < 4) {
                fprintf(stderr, "%% Usage: " "%s <broker> <group.id> <topic1> <topic2>..\n", argv[0]);
                return 1;
        }

        brokers   = argv[1];
        groupid   = argv[2];
        topics    = &argv[3];
        topic_cnt = argc - 3;
	
	setbuf(stdout  ,NULL);
        setbuf(stderr  ,NULL);


	logDebug2(" brokers 	:%s:",brokers);
	logDebug2(" groupid	:%s:",groupid);
	logDebug2(" topics	:%s:",&topics);
	logDebug2(" topic_cnt	:%d:",topic_cnt);

        /* Create Kafka client configuration place-holder */
        conf = rd_kafka_conf_new();

        /* Set bootstrap broker(s) as a comma-separated list of host or host:port (default port 9092).
 	 * librdkafka will use the bootstrap brokers to acquire the full set of brokers from the cluster. */
	logDebug3("Set bootstrap broker(s) as a comma-separated list of host or host:port");
        if (rd_kafka_conf_set(conf, "bootstrap.servers", brokers, errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

        /* Set the consumer group id. All consumers sharing the same group id will join the same group, and the subscribed topic' 
 	* partitions will be assigned according to the partition.assignment.strategy (consumer config property) to the consumers in the group. */
	logDebug3("Setting the consumer group id");
        if (rd_kafka_conf_set(conf, "group.id", groupid, errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

        /* If there is no previously committed offset for a partition the auto.offset.reset strategy will be used to decide where
 	 * in the partition to start fetching messages. By setting this to earliest the consumer will read all messages in the 
 	 * partition if there was no previously committed offset. */
	logDebug3("partitioning if there was no previously committed offset");
        if (rd_kafka_conf_set(conf, "auto.offset.reset", "earliest", errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

        /* Create consumer instance.
 	 * NOTE: rd_kafka_new() takes ownership of the conf object and the application must not reference it again after this call.*/
	logDebug3("Taking ownership of the conf object");
        rk = rd_kafka_new(RD_KAFKA_CONSUMER, conf, errstr, sizeof(errstr));
        if (!rk) {
                fprintf(stderr, "%% Failed to create new consumer: %s\n",
                        errstr);
                return 1;
        }

        conf = NULL; /* Configuration object is now owned, and freed, by the rd_kafka_t instance. */


        /* Redirect all messages from per-partition queues to the main queue so that messages can be consumed with one call from all assigned partitions.
 	 * The alternative is to poll the main queue (for events) and each partition queue separately, which requires setting                                         * up a rebalance callback and keeping track of the assignment: but that is more complex and typically not recommended. */
        rd_kafka_poll_set_consumer(rk);


        /* Convert the list of topics to a format suitable for librdkafka */
        logDebug2("Converting the list of topics to a format suitable for librdkafka");
	subscription = rd_kafka_topic_partition_list_new(topic_cnt);
        for (i = 0; i < topic_cnt; i++)
                rd_kafka_topic_partition_list_add(subscription, topics[i], RD_KAFKA_PARTITION_UA);
		rd_kafka_topic_partition_t *part;

	if ((part = rd_kafka_topic_partition_list_find(subscription, topics, 0)))
	{
		printf("\n Last  Offset read :%d:",part->offset);
		sleep(5);
	}
	else
	{
		printf("\n No  Offset read ::");
		sleep(5);
	}	
	fprintf(stderr,"%% Subscribed to %d topic(s),waiting for rebalance and messages...\n", subscription->cnt);
	
	logDebug3(" Subscribing to the list of topics ");
	err = rd_kafka_subscribe(rk, subscription);	/* Subscribe to the list of topics */
	if (err) {
                fprintf(stderr, "%% Failed to subscribe to %d topics: %s\n",
                        subscription->cnt, rd_kafka_err2str(err));
                rd_kafka_topic_partition_list_destroy(subscription);
                rd_kafka_destroy(rk);
                return 1;
        }

        rd_kafka_topic_partition_list_destroy(subscription);
	//signal(SIGINT, stop); /* Signal handler for clean shutdown */

	logDebug3(" ********* ");	
	fOpenMsgQue();
	ReadMsg();
	
	logTimestamp("Main [EXIT]");
}

BOOL ReadMsg()
{
	logTimestamp("ReadMessage [ENTRY]");

	CHAR    RcvMsg[LOCAL_MAX_PACKET_SIZE];

	while (run) 
	{

                rd_kafka_message_t *rkm;
		rkm = rd_kafka_consumer_poll(rk, 10);
                if (!rkm)
                        continue;
                if (rkm->err) {
                        printf("\nCaught Error\n");
                        rd_kafka_message_destroy(rkm);
                        continue;
                }
	
                /* Proper message. */
                printf("Message on %s [%" PRId32 "] at offset %" PRId64 ":\n",rd_kafka_topic_name(rkm->rkt), rkm->partition, rkm->offset);

                /* Print the message key. */
                if (rkm->key && is_printable(rkm->key, rkm->key_len))
                        printf(" Key: %.*s\n", (int)rkm->key_len,
                               (const char *)rkm->key);
                else if (rkm->key)
                        printf(" Key: (%d bytes)\n", (int)rkm->key_len);

                /* Print the message value/payload. */
                if (rkm->payload && is_printable(rkm->payload, rkm->len))
                {
                        printf("\n iCnt :%d:",iCnt++);
                }
                else if (rkm->payload)
                {
                        printf(" Value: (%d bytes)\n", (int)rkm->len);
                }
                
                memset(&RcvMsg,'\0' ,RUPEE_MAX_PACKET_SIZE);
		//struct Points* p2 = (struct Points*)(rkm->payload);
		//&RcvMsg = ;

        	//sending request to D2C1 and trade router
                //fSendMsg(&RcvMsg);
		memcpy(&RcvMsg,rkm->payload,LOCAL_MAX_PACKET_SIZE);
        	/*        if((fSendMsg(RcvMsg)) != TRUE  )
	        {
        	        logFatal("Error : Failed to write ");
        	}*/
		LONG32  iMsglen;
		iMsglen = ((struct INT_COMMON_RESP_HDR *) RcvMsg )->iMsgLength;

        	logDebug2(" Response msg length : %d : ",iMsglen);

        	//logDebug2(" msg %s",RcvMsg);
		if((WriteMsgQ(iMmapToD2C1,&RcvMsg , iMsglen, 1)) != TRUE  )
        	{
                	logFatal("Error : Failed to write on D2C1 router");
                	exit(ERROR);
        	}
        	logDebug3(" successfully written on D2C1 router : %d",iMmapToD2C1);
        	//if((WriteMsgQ(iMmapToDWSTrdRtr,RcvMsg , iMsglen, 1)) != TRUE  )
        	if((WriteMsgQ(iMmapToDWSTrdRtr,&RcvMsg , iMsglen, 1)) != TRUE  )
        	{
                	logFatal("Error : Failed to write on DWS trade router.");
                	exit(ERROR);
        	}
        	logDebug3(" successfully written on DWS trade router : %d",iMmapToDWSTrdRtr);
		/****
        	if((WriteMsgQ(iMmapToAdmnTrdRtr,RcvMsg , iMsglen, 1)) != TRUE  )
        	{
                	logFatal("Error : Failed to write on DWS trade router.");
                	exit(ERROR);
        	}
        	logDebug3(" successfully written on Admin trade router : %d",iMmapToAdmnTrdRtr);
		*****/

		rd_kafka_message_destroy(rkm);
        }

         /* Close the consumer: commit final offsets and leave the group. */
        fprintf(stderr, "%% Closing consumer\n");
        rd_kafka_consumer_close(rk);
        /* Destroy the consumer */
        rd_kafka_destroy(rk);

        return 0;
}

void fOpenMsgQue()
{
        logTimestamp("\n Entry : [fOpenMsgQue]");
	if((iMmapToD2C1=  OpenMsgQ(MmapToD2C1)) == ERROR)
        {
                logFatal("Error in Opening MmapToD2C1");
                exit(ERROR);
        }
        logDebug2("\n iMmapToD2C1 :%d:",iMmapToD2C1);
	
	if(( iMmapToDWSTrdRtr = OpenMsgQ(MmapToDWSTrdRtr)) == ERROR)
        {
                logFatal("OpenMsgQ : Error in opening MmapToDWSTrdRtr");
                exit(ERROR);
        }
	logDebug2(" iMmapToDWSTrdRtr :%d:",iMmapToDWSTrdRtr);

	if(( iMmapToAdmnTrdRtr= OpenMsgQ(MmapToAdmnTrdRtr)) == ERROR)
        {
                logFatal("OpenMsgQ : Error in opening MmapToAdmnTrdRtr ");
                exit(ERROR);
        }
	logDebug2(" iMmapToAdmnTrdRtr :%d:",iMmapToAdmnTrdRtr);
	logTimestamp(" Exit : [fOpenMsgQue]");
}

BOOL fSendMsg(CHAR *RcvMsg)
{
	logDebug2(" ** Entry : Sending Message function **");
		
	struct  ORDER_RESPONSE *pOrdRes;
	
	memset (&pOrdRes,'\0' ,sizeof (struct ORDER_RESPONSE));


        pOrdRes=(struct ORDER_RESPONSE *) &RcvMsg;

	LONG32  iMsgCode;
	LONG32	iMsglen;
	
	//logDebug2(" msg %s",RcvMsg);	
	iMsgCode=((struct INT_COMMON_RESP_HDR *) RcvMsg )->iMsgCode;;

        logDebug2(" pReqHeader->iMsgCode = %d",iMsgCode);

	iMsglen = ((struct INT_COMMON_RESP_HDR *) RcvMsg )->iMsgLength;

	logDebug2(" Response msg code = : %d : ",iMsgCode);
	logDebug2(" Response msg length : %d : ",iMsglen);

	if((WriteMsgQ(iMmapToD2C1,RcvMsg , iMsglen, 1)) != TRUE  )
	{
        	logFatal("Error : Failed to write on D2C1 router");
        	exit(ERROR);
        }
	logDebug3(" successfully written on D2C1 router : %d",iMmapToD2C1);
	
	if((WriteMsgQ(iMmapToDWSTrdRtr,RcvMsg , iMsglen, 1)) != TRUE  )
        {
                logFatal("Error : Failed to write on DWS trade router.");
                exit(ERROR);
        }
	logDebug3(" successfully written on DWS trade router : %d",iMmapToDWSTrdRtr);	
	
	if((WriteMsgQ(iMmapToAdmnTrdRtr,RcvMsg , iMsglen, 1)) != TRUE  )
        {
                logFatal("Error : Failed to write on DWS trade router.");
                exit(ERROR);
        }
        logDebug3(" successfully written on DWS trade router : %d",iMmapToAdmnTrdRtr);

	logDebug2(" ** Exit : Sending Message function **");
}


