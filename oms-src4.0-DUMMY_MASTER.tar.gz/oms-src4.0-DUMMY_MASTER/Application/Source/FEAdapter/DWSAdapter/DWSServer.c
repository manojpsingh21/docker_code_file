#include <sys/socket.h>
#include <pthread.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
void SocketToQueueThread ();
void QueueToSocketThread ();

LONG32                        iTrdRtrToRel;
LONG32                        iRelToOrdRtr ;
LONG32                        iRelToQuery ;

LONG32  isConnected = FALSE; 

pthread_t   th_id1;
pthread_t   th_id2;

LONG32  iSocket;
INT16	iMsgType;
CHAR	cSegment;

int main(LONG32 argc, CHAR **argv)
{
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	CHAR    RespString[RUPEE_MAX_PACKET_SIZE]; 
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iMasterSocket,iRetval, iMaster_Port;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logInfo(" PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;
	iMsgType     = atoi(argv[2]);	
	cSegment	= argv[3][0];


	logDebug3(" PORT : %d", iMaster_Port ) ;
	logDebug3(" Msg Type : %d", iMsgType) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);

	OpenMsgQue();

	if ((iMasterSocket=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		logFatal(" Error in creating the iMasterSocket");
		exit(ERROR);
	}
	logDebug3(" Socket Created : %d", iMasterSocket);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iMaster_Port);
	servadd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetval = 1;
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetval, sizeof(iRetval)) == ERROR)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_REUSEADDR:");
		exit(1);
	}
	/************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}


	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}
	/**************************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_KEEPALIVE, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}

	if( bind(iMasterSocket, (struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("bind: ");
		logFatal(" Error in binding to the iMasterSocket");
		exit(ERROR);
	}

	ConnectionDOWN();
	listen(iMasterSocket, 1);
	while(1)
	{
		memset((CHAR *)&cliadd, '\0', sizeof(struct sockaddr_in));
		ConnectionDOWN();

		printf("\n ============= Waiting for DWS Mediator to connect on port : %d ===========", iMaster_Port);
		iRetval = sizeof(struct sockaddr);
		printf("\n iSocket %d:",iSocket);
		if ((iSocket = accept(iMasterSocket, (struct sockaddr *)&cliadd, &iRetval)) < 0)
		{
			perror("accept: ");
			printf("\n Error in accepting the connection %d", errno);
			continue;
		}

		printf("\n New Socket Connection Established on : %d", iSocket);

		if((pthread_create(&th_id2,NULL,QueueToSocketThread,NULL)!= 0))
		{
			printf("\n pthread_create:QueueToSocketThread");
			exit(ERROR);
		}

		if((pthread_create(&th_id1,NULL,SocketToQueueThread,NULL)!= 0))
		{
			printf("\n pthread_create:SocketToQueueThread");
			exit(ERROR);
		}

		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while( TRUE )
		{
			printf("Waiting For Signal");
			mainwait = sigwait( &SequenceSet,&Signal);
			printf("\n Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				printf("\n SIGTERM in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				printf("\n SIGUSR1 in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Break from loop");
				break;
			}
			else
			{
				printf("\n Received some other signal");
				printf("\n Closing Socket");
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}

		}
		printf("\n Socket Connection closed on : %d", iSocket);
		printf("\n While Loop");
	}
}


void SocketToQueueThread()
{
	LONG32  iRetval=-1,iLen;
	CHAR    rcvStr[RUPEE_MAX_PACKET_SIZE], peekString[MAX_PEEK_SIZE+1],tempString[MAX_PEEK_SIZE+1];;
	CHAR    cMsgType, *tempPtr;
	LONG32  dcount = 0,i;
	LONG32 loopcount=0;

	while(1)
	{
		memset(rcvStr, '\0', RUPEE_MAX_PACKET_SIZE);
		memset(peekString, '\0', MAX_PEEK_SIZE+1);
		memset(tempString, '\0', MAX_PEEK_SIZE+1);

		iLen    =   MAX_PEEK_SIZE;
		printf("\n ================== Reading From socket %d ==============loopcount :%d iRetval:%d", iSocket,loopcount++,iRetval);

		if ((iRetval = Recv(iSocket, peekString, &iLen, MSG_PEEK)) == FALSE)
		{
			printf("\n Dropped Exchange Response while Peeking from Socket");
			printf("\n Error in receiving the Data from the Socket on PEEK");
			printf("\n iRetval in peek %d:",iRetval);
			RestartProcess();
			break;
		}

		memcpy(tempString,peekString,MAX_PEEK_SIZE);
		printf("\n iRetval in peek %d:",iRetval);
		printf("\nMSG_PEEK String :[%s]",tempString);

		iLen=  ((struct INT_COMMON_REQUEST_HDR *)tempString)->iMsgLength;
		printf("\nLen = %d iSocket=%d",iLen, iSocket);


		if ((iRetval = Recv(iSocket, rcvStr, &iLen, 0)) == -1)
		{
			printf("\n Dropped Exchange Response while Receiving on Socket");
			printf("\n Error in receiving the Data from the Socket");
			/*** We do not need to send to Fwd or Rev this message ***/
			RestartProcess();
			break;
		}

		ProcessIncomingPacket(&rcvStr);
	}
	close(iSocket);	
}

void QueueToSocketThread()
{
	LONG32  iRetval;
	CHAR    fwdStr[RUPEE_MAX_PACKET_SIZE];

	while(1)
	{
		printf("\n ================== Waiting on the Queue =====================");
		memset(fwdStr, '\0', RUPEE_MAX_PACKET_SIZE);
		if ((iRetval=ReadMsgQ(iTrdRtrToRel, &fwdStr, RUPEE_MAX_PACKET_SIZE, iMsgType))== ERROR)
		{
			printf("\n ERROR in receiving the Data from the Q %d", iTrdRtrToRel);
			exit(ERROR);
		}

		printf("\n Data Received from Queue");

		if ((iRetval = Send(iSocket, fwdStr, strlen(fwdStr), 0)) == FALSE)
		{
			printf("\n ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
			//SendBusinessRejectFor(FixString);
			RestartProcess();
			break;
		}
		printf("\n Sent to DWSServer");
	}
}

void ProcessIncomingPacket(CHAR *pkt)
{
	LONG32 iTransCode,iLen;
	iTransCode = (( struct INT_COMMON_REQUEST_HDR * ) pkt)->iMsgCode;
	iLen = (( struct INT_COMMON_REQUEST_HDR * ) pkt)->iMsgLength;

	logDebug2("Nishant TransCode received  here :%d:",iTransCode);
	switch(iTransCode)
	{
		/*
		 * INQUIRY TRANSCODES
		 */

		//              case    TC_INT_PASSWD_CHANGE_REQ:
		case    TC_INT_VIEW_CLIENT_LIMIT_REQ:
		case    TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
		case    TC_INT_NET_POS_REQ:
		case    TC_INT_ORDER_BOOK_REQ:
		case    TC_INT_SPRD_ORD_BOOK_REQ:
		case    TC_INT_ORDER_BOOK_DTLS_REQ:
		case    TC_INT_TRADE_BOOK_REQ:
			//              case    TC_INT_ADMIN_TRADE_BOOK_REQ:
		case    TC_INT_CLINET_HOLDING_REQ:
		case    TC_INT_NETPOS_DTL_REQ:
		case    TC_INT_CARRY_FWD_POS_REQ:
		case    TC_INT_DEA_CLIENT_MAPP_REQ:
			//              case    TC_INT_ADMIN_CONVT_TO_DELV_REQ:
		case    TC_INT_SEND_MSG_TO_CLIENT_REQ:
		case    TC_INT_DNLD_SYSTEM_MSG_REQ:
		case    TC_INT_REJECTED_ORDERS_REQ:
		case    TC_INT_BO_ORDER_BOOK_REQ:
			//      case    TC_INT_PERCENT_MTM_QUERY_REQ:
			//              case    TC_INT_MARGIN_SHORTFALL_REQ:

			logDebug2("Before Write Q");

			if((WriteMsgQ(iRelToQuery,pkt,iLen,1)) < 0)
			{
				logDebug2("Error While writing to Query Queue ");
			}

			logDebug2("Successfully Written To The Q : %d",iRelToQuery);

			break;

			/*

			 * ORDER TRANSCODES

			 */

		case    TC_INT_ORDER_ENTRY_REQ                  :
		case    TC_INT_ORDER_MODIFY                     :
		case    TC_INT_ORDER_CANCEL                     :

		case    TC_INT_SPREAD_OE_REQ                    :
		case    TC_INT_SPREAD_OM_REQ                    :
		case    TC_INT_SPREAD_OC_REQ                    :

		case    TC_INT_OFF_ORDER_ENTRY                  :
		case    TC_INT_OFF_ORDER_MODIFY                 :
		case    TC_INT_OFF_ORDER_CANCEL                 :
		case    TC_INT_NOTIFICATION_REQ                 :

		case    TC_INT_SQUAREOFF_INTRADAY_REQ           :
		case    TC_INT_PUMPOFFLINE_REQ                  :
		case    TC_INT_ADMIN_EXPIRY_REQ                 :
		case    TC_INT_CON_DEL_REQ                      :

		case    TC_INT_SIP_ORD_REQ                      :
		case    TC_INT_SIP_ORD_CANCEL                   :

		case    TC_INT_CREATE_ALL_FILE_REQ              :

		case    TC_INT_MTM_AUTO_SQR_OFF                 :
		case    TC_INT_CO_ORDER_REQ     :
		case    TC_INT_CO_ORDER_MODIFY  :
		case    TC_INT_CO_ORDER_EXIT    :
		case    TC_INT_BO_ORDER_REQ     :
		case    TC_INT_BO_ORDER_MODIFY  :
		case    TC_INT_BO_ORDER_EXIT    :

			if((WriteMsgQ(iRelToOrdRtr,pkt,iLen,1)) < 0)
			{
				logFatal("Error While writing to BcastQuery Queue ");
			}

			logDebug2("Successfully Written To The Q : %d",iRelToOrdRtr);

			break;

		default:
			logDebug2("Wrong TransCode recieved:%d: ",iTransCode);
			break;
	}
}

void RestartProcess()
{
	return;
}


/******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Send                                       	     **
 **                                                                           **
 **   DESCRIPTION       : Send doesnt guarantee that all the data in the      **
 **			 buffer will be sent in a single call to send, loop  **
 **			 around checking the return value till all the bytes **
 **			 are sent.					     **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc to which data will be sent.   **
 **			 SendData- Data to be sent.			     **
 **			 SendLen - Len of the data to be sent.		     **
 **			 Flags   - If any.				     **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{

		printf("\n sending fix msg :%d: socketid :%d:", TotalLen,Socketfd); 
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		printf("\n After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}


/*******************************************************************************
 *******************************************************************************
 **   FUNCTION NAME     : Recv                                                **
 **                                                                           **
 **   DESCRIPTION       : recv doesnt guarantee that all the data in the      **
 **			              buffer will be received in a single call, loop     **
 **			              around checking the return value till all the bytes **
 **			              are received.                                       **
 **                                                                           **
 **   ARGUMENTS PASSED  : Socketfd- Socket Desc from which data will be recvd.**
 **			              SendData- Data to be recvd.                         **
 **			              SendLen - Len of the data to be recvd.              **
 **			              Flags   - If any.                                   **
 **                                                                           **
 **   RETURN VALUE      : BOOL                                                **
 *******************************************************************************
 ******************************************************************************/
BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	printf("\n Trying to Recv = %d", *RecvLen); 
	while(TotalLen < *RecvLen)
	{
		printf("\n Trying to recv %d bytes socketid :%d:", BytesLeft,Socketfd);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		printf("\n After recv Bytes = %d", Bytes); 
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

void ConnectionUP()
{
	return;
}

void ConnectionDOWN()
{
	return;
}

	void OpenMsgQue(){
		if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
		{
			perror("Open RelToDirQ :");
			exit( 1 );
		}
		logDebug1(" iRelToOrdRtr created sucesfully wid Qid :%d:",iRelToOrdRtr);

		if( ( iRelToQuery = OpenMsgQ( (RelToQuery))) == ERROR )
		{
			perror("Open RelToDirQ :");
			exit( 1 );
		}
		logDebug1(" iRelToQuery queue opened sucessfully with queuue id :%d:",iRelToQuery);

		if( (iTrdRtrToRel= OpenMsgQ(TrdRtrToRel)) == ERROR)
		{
			perror("Open DirToSTWRelQ :");
			exit( 1 );
		}
		logDebug1(" iTrdRtrToRel :%d:",iTrdRtrToRel);
	}
