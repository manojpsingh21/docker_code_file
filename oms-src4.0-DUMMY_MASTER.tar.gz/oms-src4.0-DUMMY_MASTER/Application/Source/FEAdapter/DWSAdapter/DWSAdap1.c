#include "IPCS.h"
#include "DWSAdapter.h"
#include <errno.h>
#include <my_global.h>
#include <stdlib.h>
#include <mysql.h>


LONG32  RelayId;
LONG32	MsgType;
LONG32                        iDWSTrdRtrToDWSAdp;
LONG32                        iD2C1ToDWSAdap;
LONG32                        iDWSQryToAdap;
LONG32                        iRelToOrdRtr ;
LONG32                        iRelToQuery ;
LONG32                        iAdapToRQuery;
LONG32	QueueId;
struct ORDER_REQUEST * Mesg_Pkt;


void OpenMsgQueue ();
void fWriteToSock();
void fRecvfromSock();

MYSQL   *DBConNNF;
LONG32  iMainwait = -1;
LONG32 	iRRPort;
LONG32	iSockfd1;
CHAR 	sRRIp[CALLING_LENS];

main( LONG32 argc, CHAR **argv )
{
	logTimestamp("Entry : Main");
	CHAR    *cError;
	cError = (char *)malloc(sizeof(char)*SIZE);

	LONG32 	iPrimarySecondary=0;
	LONG32 	iRespChild,iTransChild,iInvitationChild,iStatus,iTransKill = -1;
	LONG32 	iSig1 = 0,iSig2 = 0; 
	LONG32 	iFlag;
	LONG32 	iFla;
	LONG32 	iFl;
	LONG32 	iMaxPacketCount,iInvFlag = FALSE; 
	LONG32 	iDummy;

	sigset_t	SequenceSet;  				/* Signal set containing SIGUSR1 , SIGUSR2 , SIGTERM */

	setbuf(stdout,NULL);
	setbuf(stderr,NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );    			/* Signal functions initialization */


	logTimestamp("--------------------------Started RR Connect-----------------------------------------------");

	if ( argc < 4 )
	{
		logTimestamp(" Invalid number of arguments");
		exit(ERROR);				
	}

	strcpy(sRRIp,argv[1]); 
	iRRPort = atoi ( argv[2]); 
	MsgType = atoi(argv[3]);
	RelayId = MsgType;
	logDebug2("RelayId of Process is %d",RelayId);

	logInfo("------------------- PARAMETERS PASSED ----------");
	logInfo("sRRIp 					: [%s]", sRRIp ) ; 
	logInfo("iRRPort: [%d]", iRRPort ) ; 
	logInfo("------------------------------------------------");

	OpenMsgQueue();
	DBConNNF = DB_Connect();
	CHAR DummyUser[USER_ID_LEN]="Suraj";
	logInfo("Connection to DB SUCCESS......"); 
	AccessUsrRlyShm(DummyUser,INIT);	
//	sigemptyset ( &SequenceSet );
//	sigaddset ( &SequenceSet , SIGTERM);
//	sigaddset ( &SequenceSet , SIGUSR1);



	for ( ; ; )						
	{
		signal(SIGPIPE,SIG_IGN);
		signal(SIGHUP,SIG_IGN);
		for ( ; ; )
		{
			iSockfd1  =tcpConnect();
			if (iSockfd1 <= 0 )
			{
				memset(cError,NULL,SIZE);
				strcpy(cError,"FATAL ERROR .... NO SOCKET CONNECTION .... ");
				sleep(2);
				iPrimarySecondary=(iPrimarySecondary==1)?0:1;
			}
			else
			{
				iFlag=100000;
				iFla=100000;
				iFl=1;
				if (setsockopt( iSockfd1 ,SOL_SOCKET,SO_RCVBUF,&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:SO_  RCVBUF");
					return FALSE;
				}
				if (setsockopt( iSockfd1 ,SOL_SOCKET,SO_SNDBUF,&iFlag,sizeof( iFlag ))<0)
				{
					logDebug2("Error in setting socket option:SO_SNDBUF");
					return FALSE;
				}
				if ( (iRespChild = fork()) == 0 )
				{
					iRespChild = getpid();
					logDebug2("RespChild PID :%d:",iRespChild);
					logDebug2("Parent PID :%d:",getppid());
					logDebug2("Creating Child To read from Socket");
					fRecvfromSock(iSockfd1);
				}
				else if( ( iTransChild = fork() ) == 0 )
				{	
					iTransChild = getpid();
					logDebug2("TransChild PID :%d:",iTransChild);
					logDebug2("Parent PID :%d:",getppid());
					logDebug2("Creating Child To write on Socket");
					fWriteToSock();
				}
				break;
			}
		}





		while( TRUE )
		{
			iTransKill = -1;
			iSig1 = 0;
			sigemptyset ( &SequenceSet );
			sigaddset ( &SequenceSet , SIGTERM);
			sigaddset ( &SequenceSet , SIGUSR1);
			sigaddset ( &SequenceSet , SIGUSR2);
			sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);

			logDebug2("Waiting for signal, in loop.");
			iMainwait = sigwait( &SequenceSet, &iSig1);
			logDebug2("=============Recv Signal : %d, Sig1:%d==============", iMainwait , iSig1 );
			logDebug2("==================Recv Signal : %d, Sig1:%d==============", iMainwait , iSig1 );
			logDebug2("================= Sockfd1 [%d] ============= ");

			//close(iSockfd1);    /*** Dicuss***/

			if (iMainwait >= 0 && iSig1 != SIGTERM)
			{
				logDebug2("Got Mainwait >= 0, Sig1: %d", iSig1 );
				iTransKill = kill(iTransChild,iSig1);
				logDebug2("Return value from KILL : %d", iTransKill );

				iTransKill = kill(iRespChild,iSig1);
				logDebug2("Return value from KILL : %d", iTransKill );
				perror ( "After kill to TransChild: ");
				if (iTransKill < 0)
				{
					logDebug2("DWSAdap.pc Fatal error in sending signal %d",iTransKill);
					memset(cError,NULL,SIZE);
					strcpy(cError,strerror(errno));
					exit(ERROR);
				}
			}	
			else if ( iSig1 == SIGTERM )	
			{
				logDebug2(" starting fall over mechanism ");

				logDebug2("Databse and shared memory updated and broadcast sent ");
				kill(iTransChild,SIGKILL);
				kill(iRespChild,SIGKILL);
				sleep(3);
				waitpid(iTransChild,&iStatus,WNOHANG);
				waitpid(iRespChild,&iStatus,WNOHANG);
				close(iSockfd1);
				break;
			}
			else if(iSig1 == SIGCHLD)
			{
				logDebug2(" Killing Children ");
				kill(iTransChild,SIGKILL);/* To exit from the program b'coz of signal error */
				kill(iRespChild,SIGKILL);
				exit(ERROR);
			}	
		}/** End of While loop ***/
	}	 /**End of for loop **/
	free(cError);
	logTimestamp("Exit : Main");
}

void 	fWriteToSock()
{
	logTimestamp("Entry : fWriteToSock");
	struct  MESG_STRUCT *Mesg_Pkt;
	LONG32 BytesSend, Len;
//	QueueId=iDWSTrdRtrToDWSAdp;
	
	QueueId=iDWSQryToAdap;
	while(TRUE)
	{
		Mesg_Pkt = malloc(sizeof(struct  MESG_STRUCT));

		memset(Mesg_Pkt,' ',sizeof(struct  MESG_STRUCT));

		if((ReadMsgQ(QueueId,&(Mesg_Pkt->Mesg_Buf),RUPEE_MAX_PACKET_SIZE,MsgType)) == ERROR)
			//              if((ReadMsgQ(iTrdRtrToRel,&(Mesg_Pkt->Mesg_Buf),RUPEE_MAX_PACKET_SIZE,1)) == ERROR)
		{

			logDebug2(" WRiteThread: Error In Reading from Queue Id = %d",QueueId);

			exit(1);

		}
		Len=(((struct INT_COMMON_RESP_HDR *) Mesg_Pkt->Mesg_Buf)->iMsgLength);
		Len =sizeof(struct  MESG_STRUCT);
		logDebug2(" After read Q QueueId :%d:",QueueId);
		if((BytesSend = Send(iSockfd1,&(Mesg_Pkt->Mesg_Buf),&Len)) == ERROR )
		{
			logDebug2("\n WWT:: Error while sending on the socket ");
			exit(1);
		}


	}
	logTimestamp("Exit :fWriteToSock");

}      

void 	fRecvfromSock()
{
	logTimestamp("Entry : fRecvfromSock");
	LONG32  BytesRead;
	LONG32 Len, TransCode;
	CHAR    Mesg_Buf[RUPEE_MAX_PACKET_SIZE];
//	memset(Mesg_Buf,' ',RUPEE_MAX_PACKET_SIZE);
	struct  INT_COMMON_REQUEST_HDR *pMesg_Pkt;



	static	LONG32 iPacketCounter =0 ;

	CHAR 	sProgTime[40];
	memset(sProgTime,'\0',40);
	CHAR    UserId[USER_ID_LEN];
	memset( UserId,'\0',USER_ID_LEN);
	while(TRUE)
	{
		
		memset(Mesg_Buf,' ',RUPEE_MAX_PACKET_SIZE);
		if((BytesRead = Recv(iSockfd1,Mesg_Buf,&Len)) == ERROR )

		{

			logDebug2("Error while receiving from the socket:%d ",errno);
			kill(getppid(),SIGTERM);
			usleep(500);
			return;
		}
		pMesg_Pkt= (struct INT_COMMON_REQUEST_HDR * ) &Mesg_Buf;
		Mesg_Pkt = (struct ORDER_REQUEST *) &Mesg_Buf;
		TransCode = pMesg_Pkt->iMsgCode;

		logDebug2("----------------------DATA received-----------------------");
		logDebug2(" RWT:: Transcode         : %d",TransCode);
		logDebug2(" RWT:: iUserId   : %d",pMesg_Pkt-> iUserId);
		logDebug2(" RWT:: Segment   : %c",pMesg_Pkt->cSegment);
		logDebug2(" RWT:: ExchId    :%s:",pMesg_Pkt->sExcgId);
		logDebug2(" RWT:: MsgLength : %d",pMesg_Pkt->iMsgLength );
		logDebug2("----------------------DATA---------------------");
		sprintf(UserId,"%d",pMesg_Pkt-> iUserId);
		AccessUsrRlyShm(&UserId,INSERT);
		switch(TransCode)
		{
			case    TC_INT_VIEW_CLIENT_LIMIT_REQ:
			case    TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
			case    TC_INT_NET_POS_REQ:
			case    TC_INT_ORDER_BOOK_REQ:
			case    TC_INT_SPRD_ORD_BOOK_REQ:
			case    TC_INT_ORDER_BOOK_DTLS_REQ:
			case    TC_INT_BO_ORDER_BOOK_DTLS_REQ:
			case    TC_INT_TRADE_BOOK_REQ:
				//              case    TC_INT_ADMIN_TRADE_BOOK_REQ:
			case    TC_INT_CLINET_HOLDING_REQ:
			case    TC_INT_NETPOS_DTL_REQ:
			case    TC_INT_CARRY_FWD_POS_REQ:
			case    TC_INT_DEA_CLIENT_MAPP_REQ:
				//              case    TC_INT_ADMIN_CONVT_TO_DELV_REQ:
			case    TC_INT_SEND_MSG_TO_CLIENT_REQ:
			case    TC_INT_DNLD_SYSTEM_MSG_REQ:
			case    TC_INT_REJECTED_ORDERS_REQ:
			case    TC_INT_BO_ORDER_BOOK_REQ:
				//      case    TC_INT_PERCENT_MTM_QUERY_REQ:
				//              case    TC_INT_MARGIN_SHORTFALL_REQ:

			case    TC_INT_SIP_ORDER_BOOK_REQ:
			case    TC_INT_SIP_ORDER_DETS_REQ:
			case    TC_INT_SIP_ORDER_TRALS_REQ:
			case    TC_INT_MKT_STATUS_REQ   :
			case    TC_INT_VIEW_CLIENT_LIMIT_DET_REQ :

				logDebug2("Before Write Q");

				if((WriteMsgQ(iRelToQuery,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)

				{

					logDebug2(" Error While writing to Query Queue ");

				}

				logDebug2("Successfully Written To The Q : %d",iRelToQuery);

				break;
			case    TC_INT_ORDER_ENTRY_REQ                  :
			case    TC_INT_ORDER_MODIFY                     :
			case    TC_INT_ORDER_CANCEL                     :

			case    TC_INT_SPREAD_OE_REQ                    :
			case    TC_INT_SPREAD_OM_REQ                    :
			case    TC_INT_SPREAD_OC_REQ                    :

			case    TC_INT_OFF_ORDER_ENTRY                  :
			case    TC_INT_OFF_ORDER_MODIFY                 :
			case    TC_INT_OFF_ORDER_CANCEL                 :
			case    TC_INT_NOTIFICATION_REQ                 :

			case    TC_INT_SQUAREOFF_INTRADAY_REQ           :
			case    TC_INT_PUMPOFFLINE_REQ                  :
			case    TC_INT_ADMIN_EXPIRY_REQ                 :
			case    TC_INT_CON_DEL_REQ                      :

			case    TC_INT_SIP_ORD_REQ                      :
			case    TC_INT_SIP_ORD_CANCEL                   :
			case    TC_INT_SIP_ORD_PAUSE_REQ                :
			case    TC_INT_SIP_ORD_CONTINUE_REQ             :

			case    TC_INT_CREATE_ALL_FILE_REQ              :

			case    TC_INT_MTM_AUTO_SQR_OFF                 :

			case    TC_INT_CO_MRG_CAL_REQ           :
			case    TC_INT_BO_MRG_CAL_REQ           :
			case    TC_INT_MRG_CAL_REQ              :
			
					
//				logDebug2("Market type %d",mkt);
				if((WriteMsgQ(iRelToOrdRtr,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
				{
					logFatal("Error While writing to BcastQuery Queue ");
				}

				logDebug2("Successfully Written To The Q : %d",iRelToOrdRtr);
				break;


			case    TC_INT_CO_ORDER_REQ     :
			case    TC_INT_CO_ORDER_MODIFY  :
			case    TC_INT_CO_ORDER_EXIT    :
			case    TC_INT_BO_ORDER_REQ     :
			case    TC_INT_BO_ORDER_MODIFY  :
			case    TC_INT_BO_ORDER_EXIT    :

				if((WriteMsgQ(iRelToOrdRtr,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
				{
					logDebug2("Error While writing to BcastQuery Queue ");
				}
				logDebug2(" Cover Order Request MsgCode = %d",TC_INT_CO_ORDER_REQ);
				logDebug2("Successfully Written To The Q : %d",iRelToOrdRtr);

				break;
			default:

				logDebug2("\nWrong TransCode recieved::%d ",TransCode);

				usleep(500);
				break;

		}
	}
	logTimestamp("Exit : fRecvfromSock"); 
}

LONG32  tcpConnect()
{
	logTimestamp("Entry : [tcpConnect]");
	logInfo("Hey in tcpConnect ");
	struct  sockaddr_in     pServaddr;

	LONG32  iSockfd,                                /* this variable defines the socket connection descriptor */
		iDiditconnect,                          /* variable used as iFlag for testing connection */
		iSleeptime=1,                           /* incremental sleep time variable */
		iCount_to_error=1;                      /* this counter when exceeds 99 the function terminates */
	CHAR    *sError;
	LONG32  iCounterForConnect=0;
	sError = (CHAR *)malloc(sizeof(CHAR)*SIZE);
	logInfo("Suraj is here");

	do
	{
		if( (iSockfd = socket( PF_INET, SOCK_STREAM, 0 )) < 0 )
		{
			logDebug1("iSockfd = %d",iSockfd);
			memset(sError,NULL,SIZE);
			strcpy(sError,strerror(errno));
			sleep(iSleeptime);
		}
		logDebug1("iSockfd = %d", iSockfd);

		if ( iSockfd > 0 )
		{
			logInfo("Inside loop sopckfd > 0 ");
			memset(&pServaddr,0,sizeof(pServaddr));
			pServaddr.sin_family = AF_INET;
			/****           pServaddr.sin_addr.s_addr = inet_addr(IPaddr);
			  pServaddr.sin_port=htons(port);****/
			pServaddr.sin_addr.s_addr = inet_addr(sRRIp);
			pServaddr.sin_port=htons(iRRPort);

			/*------- Checking for socket connection -------*/

			do
			{
				iDiditconnect = connect( iSockfd, (struct sockaddr *) &pServaddr, sizeof(pServaddr) );
				logDebug2("iDiditconnect = %d ", iDiditconnect);
				if (iDiditconnect < 0)
				{
					iCounterForConnect++;
					logInfo("Connection to the server Denied......... Closing Socket Connection........");
					memset(sError,NULL,SIZE);
					strcpy(sError,strerror(errno));
					sleep(iSleeptime);
					iSleeptime++;
					close(iSockfd);                                         /* closing socket before termination */
					if( (iSockfd = socket( PF_INET, SOCK_STREAM, 0 )) < 0 )
					{
						logDebug1("iSockfd = %d", iSockfd);
						memset(sError,NULL,SIZE);
						strcpy(sError,strerror(errno));
						sleep(iSleeptime);
					}
					logDebug1("Outside loop <0, iSockfd = %d ", iSockfd);
				}
				if(iCounterForConnect == 3 )
				{
					close(iSockfd);                      /* closing socket before termination */
					break;
				}
			}while( iDiditconnect < 0 );
		}
		logInfo("outside loop of iSockfd >0");
		iSleeptime++;
		iCount_to_error++;
	}while(( iSockfd < 0 ) && (iCounterForConnect == 3));

	free(sError);

	if( iCounterForConnect == 3)
	{
		logInfo("Returned Failover Signal Successfully........");
		return (-1);
	}
	logInfo("Returned Sockfd Successfully........");
	logTimestamp("Exit : [tcpConnect]");
	return (iSockfd);
}



void OpenMsgQueue ()
{
	logTimestamp("Entry OpenMsgQueue");


	if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	logDebug1(" iRelToOrdRtr created sucesfully wid Qid :%d:",iRelToOrdRtr);


	if( ( iRelToQuery = OpenMsgQ( (RelToQuery))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug1(" iRelToQuery queue opened sucessfully with queuue id :%d:",iRelToQuery);



	if( (iDWSTrdRtrToDWSAdp= OpenMsgQ(DWSTrdRtrToDWSAdp)) == ERROR)
	{
		perror("Open DirToSTWRelQ :");
		exit( 1 );
	}

	logDebug1(" iDWSTrdRtrToDWSAdp :%d:",iDWSTrdRtrToDWSAdp);

	if( (iDWSQryToAdap= OpenMsgQ(DWSQryToAdap)) == ERROR)
	{
		perror("Open DWSQryToAdap:");
		exit( 1 );
	}

	logDebug1(" iDWSQryToAdap :%d:",iDWSQryToAdap);

	if( (iD2C1ToDWSAdap = OpenMsgQ(D2C1ToDWSAdap)) == ERROR)
	{
		perror("Open D2C1ToDWSAdap:");
		exit( 1 );
	}


	logDebug1(" iD2C1ToDWSAdap :%d:",iD2C1ToDWSAdap);


	if( (iAdapToRQuery= OpenMsgQ(AdapToRangeQry)) == ERROR)
	{
		perror("Open iAdapToQuery:");
		exit( 1 );
	}

	logDebug1(" iAdapToQuery:%d:",iAdapToRQuery);
	logTimestamp("Entry OpenMsgQueue");


}

LONG32 Send(LONG32 Socket,CHAR *Buf, LONG32 *Len)

{
	LONG32 BytesSend =0;
	LONG32  iRetVal;
	LONG32  TotalBytes = *Len;
	LONG32  BytesLeft = *Len;

	logDebug2(" Socket Send = [%d] BytesSend :%d: TotalBytes :%d:",Socket,BytesSend,TotalBytes);

	while(BytesSend < TotalBytes)
	{
		/***    if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,0)) <= 0)****/
		if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,MSG_NOSIGNAL)) <= 0)
		{
			logDebug2(" Error in Sending in SEND function need to check the issue");
			perror("in Send function");
			return ERROR;
		}

		BytesSend += iRetVal;
		BytesLeft -= iRetVal;
	}
	logDebug2("Total Bytes written to socket %d is %d",Socket,BytesSend);
	return BytesSend;
}


LONG32 Recv(LONG32 Socket,CHAR *Buf, LONG32 *Len)

{



	LONG32 BytesRead =0;
	LONG32  iRetVal;
	LONG32  TotalBytes = sizeof(struct INT_COMMON_REQUEST_HDR);
	LONG32  BytesLeft;
	char    Temp_Buf[sizeof(struct INT_COMMON_REQUEST_HDR)];


	memset(Temp_Buf,'\0',sizeof(struct INT_COMMON_REQUEST_HDR));
	BytesLeft = TotalBytes;
	while(BytesRead < TotalBytes)
	{

		if((iRetVal = recv(Socket,Temp_Buf+BytesRead,BytesLeft,MSG_PEEK )) <= 0 )
		{
			perror("Error In RECV : ");
			return ERROR;
		}

		BytesRead += iRetVal;
		BytesLeft -= iRetVal;
	}


	TotalBytes = BytesLeft = ((struct INT_COMMON_REQUEST_HDR *)Temp_Buf) ->iMsgLength;
	BytesRead = 0;
	logDebug2(" going to recv Message of bytes = %d",TotalBytes);
	while(BytesRead < TotalBytes)
	{


		logDebug2("SURAJ is waiting to receive the message");
		
		if((iRetVal = recv(Socket,Buf+BytesRead,BytesLeft,!MSG_WAITALL)) <= 0)
		{
			logDebug2("Error in RECV ...!!!!!");
			perror("Error In RECV with MSG_WAITALL : ");
			raise(SIGTERM);
			return ERROR;
		}

		BytesRead += iRetVal;
		BytesLeft -= iRetVal;
		logDebug2(" ALOK BytesRead :%d going to recv Message of bytes = %d iRetVal :%d: BytesLeft:%d",BytesRead,TotalBytes,iRetVal,BytesLeft);
	}


	*Len = BytesRead;
	return BytesRead;

}





LONG32  AccessUsrRlyShm(CHAR *User, LONG32 Flg) /*****  *******/

{

        struct  DWS_ADAPTER_USER_ARRAY *pSTWUsrRlyArryShm;
        struct  DWS_ADAPTER_USER        *pSTWUsrRly;

        LONG32  Count;
        LONG32  iRetVal         = FALSE;

        LockShm(DWSAdapterUserShm);

        logDebug2(" SURAJ in shared memory and Flg is :%d ",Flg);

        /************/
        if((pSTWUsrRlyArryShm = (struct DWS_ADAPTER_USER_ARRAY *) OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE)) == (struct DWS_ADAPTER_USER_ARRAY *) ERROR)
        {
                logDebug2(" RelayId %d: Error Opening STW User Relay Shared Memory ",RelayId);
                exit(1);
        }

        logDebug2(" alok in shared memory 2 ");
        pSTWUsrRly = pSTWUsrRlyArryShm;

        if ( Flg == INIT)
        {
                for ( Count=0; Count<MAX_DWS_USERS; Count++ )
                {
                        pSTWUsrRly->iRelayId =   UNUSED  ;
                        pSTWUsrRly->ProcessId    =   UNUSED  ;
                        memset(&(pSTWUsrRly->sUser),'\0',USER_ID_LEN);
                        pSTWUsrRly++;

                }
                logDebug2(" RelayId %d : Shared Memory Initialized",RelayId);
                iRetVal =       TRUE;
        }
        else if ( Flg == INSERT)
        
	{
		int i;
                logDebug2(" RelayId %d: UserId added is %s and length = %d", RelayId,User,strlen(User));
                for(Count = 0;Count < MAX_DWS_USERS; Count++)
                {
                        if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId != UNUSED)
                        {
                                pSTWUsrRly->iRelayId = RelayId;
                                pSTWUsrRly->ProcessId = getpid();
                                memcpy(&(pSTWUsrRly->sUser),User,strlen(User));

                                logDebug2(" RelayId %d: User Updated, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
                                iRetVal =       TRUE;
                                break;
                        }
                        pSTWUsrRly++;
                }
                if( iRetVal == FALSE)
                {
                        logDebug2(" AccessUsrRlyShm:: UserId: %s==Len %d Record Does Not Exist. Doing Fresh Insertion In Shm",User,strlen(User));
                        pSTWUsrRly = pSTWUsrRlyArryShm;
                        for(Count = 0;Count < MAX_DWS_USERS; Count++)
                        {
                                if(pSTWUsrRly->iRelayId == UNUSED)
                                {
                                        pSTWUsrRly->iRelayId = RelayId;
                                        pSTWUsrRly->ProcessId = getpid();
                                        memcpy(&(pSTWUsrRly->sUser),User,strlen(User));
                                        logDebug2(" RelayId %d: User Added, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
                                        iRetVal =       TRUE;
					logDebug2("%d",i);	
                                        break;

                                }
                                pSTWUsrRly++;
                        }

                }

        }
/*        else if ( Flg == DELETE  && User[0]!= NULL)
        {
                for(Count = 0;Count < MAX_DWS_USERS; Count++)
                {
                        if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId == RelayId && strlen(pSTWUsrRly->sUser)== strlen(User))
                        {
                                logDebug2(" RelayId %d: User Delete, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);

                                memset(&(pSTWUsrRly->sUser),'\0',USER_ID_LEN);
                                pSTWUsrRly->iRelayId = UNUSED;
                                pSTWUsrRly->ProcessId = UNUSED;

                                iRetVal =       TRUE;
                        }
                        pSTWUsrRly++;
                }
        }
       */ if((CloseSharedMemory((void *) pSTWUsrRlyArryShm)) == ERROR)
        {

                logDebug2(" RelayId %d: Error in closing STW User Relay Shared Memory Errno = %d",RelayId,errno);
                exit(1);

        }
        logDebug2(" Before Unlock DWSAdapterUserShm");
        UnLockShm(DWSAdapterUserShm);
        return iRetVal;

}
