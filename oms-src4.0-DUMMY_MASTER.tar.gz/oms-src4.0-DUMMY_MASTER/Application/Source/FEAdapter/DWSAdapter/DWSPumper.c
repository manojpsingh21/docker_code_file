#include "IPCS.h"
#include "DWSAdapter.h"
#include <errno.h>


LONG32  iSockFd;

struct	Thread_Param
{
	LONG32	iThrdId;
	LONG32	iSockfd;		
};

void PumpOrder( void *Param);
CHAR    sStrSec[20][10];
CHAR    sStrNTT[6000][20];
CHAR    sStrUserID[6000][20];

LONG32  iClient = 0,iSleep=0,iOrders=0;

int main(LONG32 argc , char **argv)
{
	logTimestamp("Entry [main]");

	FILE    *fp;
	CHAR    sSecID[15];
	CHAR    sUserID[30];
	CHAR    *sRetPtr;

	LONG32	i = 0;

	setbuf(stdin,0);
	setbuf(stdout,0);	

	logDebug2("argc :%d:",argc);

	logDebug2("Enter isleep timing ,Count");

	if(argc != 4)
	{
		logInfo("INvalid Number of Param");
		exit(ERROR);
	}

	iSleep = atoi(argv[1]);
	iClient = atoi(argv[2]);
	iOrders = atoi(argv[3]);

	struct Thread_Param paramsOffOrd[iClient];
	pthread_t DWSThrdID[iClient];

	if(GetConnection(7303) == FALSE)
	{
		logFatal("Got Connection Error");
		exit(ERROR);
	}
	logInfo("Got connection");		
	fp = fopen("SecFile","r");
	if(fp == NULL)
	{
		logFatal("Error in Opening File");
		exit(ERROR);
	}
	logDebug3("THis is 5");

	while(fgets(sSecID,11,fp) != NULL)
	{

		//fscanf(fp,"%[^\n]\n",sSecID);
		memset(sStrSec[i],'\0',10);
		sRetPtr = strtok(sSecID,":");
		strncpy(sStrSec[i],sRetPtr,9);
		logInfo("sStrSec :%s:",sStrSec[i]);
		memset(sSecID,'\0',15);
		i++;
	}
	fclose(fp);
	fp = fopen("ClientFP","r");
	if(fp == NULL)
	{
		logFatal("Error in Opening File");
		exit(ERROR);
	}
	i = 0;
	while(i <=  iClient)
	{
		fgets(sUserID,30,fp);
		//fscanf(fp,"%[^\n]\n",sSecID);
		memset(sStrUserID[i],'\0',20);
		memset(sStrNTT[i],'\0',20);
		sRetPtr = strtok(sUserID,",");
		strncpy(sStrUserID[i],sRetPtr,20);
		logInfo("sStrUserID :%s:",sStrUserID[i]);
		sRetPtr = strtok(NULL,":");
		strncpy(sStrNTT[i],sRetPtr,20);
		logInfo("sStrNTT :%s:",sStrNTT[i]);
		memset(sUserID,'\0',30);
		logInfo("count :%i:",i);
		i++;
	}
	fclose(fp);



	for(i = 0;i<=iClient;i++)
	{
		paramsOffOrd[i].iThrdId = i;		
		paramsOffOrd[i].iSockfd= iSockFd;		

		if((pthread_create(&DWSThrdID[i],NULL,PumpOrder,(void *)&paramsOffOrd[i]))!=0)
			logFatal(" Cant create thread [%d]",i);
		else
			logDebug1(" Created thread [%d]",i);

	}	

	for(i = 0;i<=iClient;i++)
	{

		if((pthread_join(&DWSThrdID[i],NULL))!=0)
			logFatal(" Cant create thread [%d]",i);
		else
			logDebug1(" Created thread [%d]",i);

	}	
	logTimestamp("Exit  [main]");
}

void PumpOrder( void *Param)
{
	struct ORDER_REQUEST  pOrdReq;
	memset(&pOrdReq,'\0',sizeof(struct ORDER_REQUEST));
	struct Thread_Param *l_parameter = Param;	
	CHAR    *sRetPtr;
	LONG32	iDx = 0;	
	LONG32	iSendSock = l_parameter->iSockfd;
	LONG32	iLen = sizeof(struct ORDER_REQUEST);
	LONG32	iCount;
	pOrdReq.ReqHeader.iSeqNo = 1;
	pOrdReq.ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST);
	pOrdReq.ReqHeader.iMsgCode=TC_INT_ORDER_ENTRY_REQ;
	strncpy(pOrdReq.ReqHeader.sExcgId,"NSE",EXCHANGE_LEN);
	pOrdReq.ReqHeader.iUserId = 3258;
	pOrdReq.ReqHeader.cSource = 'S';
	pOrdReq.ReqHeader.cSegment = 'E';
	//logDebug2("Client id from file:%s",sClient);
	strncpy(pOrdReq.sSecurityId,"11536",DB_SECURITY_ID_LEN);
	/**     strncpy(pOrdReq.sEntityId,"CL001",DB_ENTITY_ID_LEN);
	  strncpy(pOrdReq.sClientId,"CL001",DB_CLIENT_ID_LEN);
	 ***/
	pOrdReq.cProductId = 'I';
	pOrdReq.cBuyOrSell = 'B';
	pOrdReq.iOrderType      = 1;
	pOrdReq.iOrderValidity = 0;

	pOrdReq.iDiscQty = 0;
	pOrdReq.iDiscQtyRem = 0;
	pOrdReq.iTotalQtyRem = 6;
	pOrdReq.iTotalQty = 6;
	pOrdReq.iTotalTradedQty = 0;
	pOrdReq.iMinFillQty = 0;
	pOrdReq.fPrice= 0.00;
	pOrdReq.fTriggerPrice = 0.0000;
	pOrdReq.fOrderNum= 0;
	pOrdReq.iSerialNum =1;
	pOrdReq.cHandleInst = '1';
	pOrdReq.fAlgoOrderNo = 0.000;
	pOrdReq.iStratergyId = 1;
	pOrdReq.cOffMarketFlg = 'N';
	pOrdReq.cProCli = 'C';
	pOrdReq.cUserType = 'C';
	strncpy(pOrdReq.sRemarks,"1",REMARKS_LEN);
	pOrdReq.iMktType = 1;
	pOrdReq.iAuctionNum = 1;


	for(iCount = 1; iCount <= iOrders; iCount++)
	{
		memset(pOrdReq.sClientId,'\0',CLIENT_ID_LEN);

		iLen = rand()%19;
		iDx = iClient%iCount;
		logInfo("First Sec:%s: :%d:",sStrSec[iLen],strlen(sStrSec[iLen]));
		memset(sRetPtr,'\0',10);

		strncpy(sRetPtr,sStrSec[iLen],10);
		pOrdReq.ReqHeader.iUserId = atoi(sStrUserID[iDx]);
		strncpy(pOrdReq.sSecurityId,sRetPtr,strlen(sRetPtr));
		strncpy(pOrdReq.sEntityId,sStrNTT[iDx],ENTITY_ID_LEN);
		strncpy(pOrdReq.sClientId,sStrNTT[iDx],CLIENT_ID_LEN);

		if(iCount % 2 == 0)
		{
			pOrdReq.cProductId = 'I';
			pOrdReq.cBuyOrSell = 'B';
		}
		else
		{
			pOrdReq.cProductId = 'M';
			pOrdReq.cBuyOrSell = 'S';
		}       /**/
		pOrdReq.cProductId = 'M';
		pOrdReq.cBuyOrSell = 'B';
		logInfo("SecurityId :%s: ClientId :%s: UserId :%d: cProductId :%c: BuyOrSell :%c:",pOrdReq.sSecurityId,pOrdReq.sClientId,pOrdReq.ReqHeader.iUserId,pOrdReq.cProductId,pOrdReq.cBuyOrSell);


		usleep(iSleep);

		SendToDWS(iSendSock,(CHAR *)&pOrdReq,iLen);

	}

}

BOOL	SendToDWS(LONG32 iSocket,CHAR *sBuf, LONG32 iLen)
{
	INT16    iSendByte;	
	iSendByte = send(iSocket,sBuf,iLen,0);
	if(iSendByte > 0)
	{
		logInfo("Send Success");
	}
}

LONG32	GetConnection(LONG32 iPort)
{
	logTimestamp("Entry :GetConnection:");

	struct  sockaddr_in	pDWSsock;
	LONG32	iConnectionFlag;	
	if((iSockFd = socket(PF_INET, SOCK_STREAM, 0)) < 0)	
	{
		logFatal("Error in SocketFD");
		exit(ERROR);
	}

	if(iSockFd > 0)
	{
		memset(&pDWSsock,0,sizeof(struct  sockaddr_in));

		pDWSsock.sin_family = AF_INET;
		pDWSsock.sin_addr.s_addr = inet_addr("192.168.2.89");
		pDWSsock.sin_port=htons(7303);
	}

	iConnectionFlag = connect(iSockFd,(struct sockaddr *) &pDWSsock,sizeof(pDWSsock));
	perror("Error :");

	if(iConnectionFlag < 0)
	{
		logFatal("Error in Connection");
		return FALSE;
	}
	else
	{
		logInfo("Got connected");
	}

	return TRUE;
}

