#include <sys/socket.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
BOOL SendBusinessRejectFor(CHAR *In);

LONG32  iDWSRevToDWSAdap = 0;
LONG32  isConnected = FALSE;

LONG32  iSocket;
INT16   iMsgType;
CHAR    cSegment;

int main(LONG32 argc, CHAR **argv)
{
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	CHAR    FixString[FIX_MAX_STRING_LEN];
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iMasterSocket,iRetval, iMaster_Port;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logInfo(" PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;
	iMsgType     = atoi(argv[2]);
	cSegment        = argv[3][0];

	logDebug3(" PORT : %d", iMaster_Port ) ;
	logDebug3(" Msg Type : %d", iMsgType) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);

	OpenMsgQue();

	if ((iMasterSocket=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		logFatal(" Error in creating the iMasterSocket");
		exit(ERROR);
	}
	logDebug3(" Socket Created : %d", iMasterSocket);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iMaster_Port);
	servadd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetval = 1;
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetval, sizeof(iRetval)) == ERROR)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_REUSEADDR:");
		exit(1);
	}
	/************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}

	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}
	/**************************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_KEEPALIVE, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}

	if( bind(iMasterSocket, (struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("bind: ");
		logFatal(" Error in binding to the iMasterSocket");
		exit(ERROR);
	}

	ConnectionDOWN();
	listen(iMasterSocket, 1);
	while(1)
	{
		memset((CHAR *)&cliadd, '\0', sizeof(struct sockaddr_in));
		ConnectionDOWN();

		printf("\n ============= Waiting for DWS Rev Client to connect on port : %d ===========", iMaster_Port);
		iRetval = sizeof(struct sockaddr);
		printf("\n iSocket %d:",iSocket);
		if ((iSocket = accept(iMasterSocket, (struct sockaddr *)&cliadd, &iRetval)) < 0)
		{
			perror("accept: ");
			printf("\n Error in accepting the connection %d", errno);
			continue;
		}

		printf("\n New Socket Connection Established on : %d", iSocket);

		isConnected = TRUE ;
		ConnectionUP();
		RecievePackets();

		printf("\n Socket Connection closed on : %d", iSocket);
		printf("\n While Loop");
	}
}

void RecievePackets()
{
	LONG32  iRetval=-1,iLen;
	CHAR    rcvStr[RUPEE_MAX_PACKET_SIZE], peekString[MAX_PEEK_SIZE+1],tempString[MAX_PEEK_SIZE+1];;
	CHAR    cMsgType, *tempPtr;
	LONG32  dcount = 0,i;
	LONG32 loopcount=0;

	while(1)
	{
		memset(rcvStr, '\0', RUPEE_MAX_PACKET_SIZE);
		memset(peekString, '\0', MAX_PEEK_SIZE+1);
		memset(tempString, '\0', MAX_PEEK_SIZE+1);

		iLen    =   MAX_PEEK_SIZE;
		printf("\n ================== Reading From socket %d ==============loopcount :%d iRetval:%d", iSocket,loopcount++,iRetval);

		if ((iRetval = Recv(iSocket, peekString, &iLen, MSG_PEEK)) == FALSE)
		{
			printf("\n Dropped Exchange Response while Peeking from Socket");
			printf("\n Error in receiving the Data from the Socket on PEEK");
			printf("\n iRetval in peek %d:",iRetval);
			RestartProcess();
			break;
		}

		memcpy(tempString,peekString,MAX_PEEK_SIZE);
		printf("\n iRetval in peek %d:",iRetval);
		printf("\nMSG_PEEK String :[%s]",tempString);

		iLen=  ((struct INT_COMMON_REQUEST_HDR *)tempString)->iMsgLength;
		printf("\nLen = %d iSocket=%d",iLen, iSocket);


		if ((iRetval = Recv(iSocket, rcvStr, &iLen, 0)) == -1)
		{
			printf("\n Dropped Exchange Response while Receiving on Socket");
			printf("\n Error in receiving the Data from the Socket");
			/*** We do not need to send to Fwd or Rev this message ***/
			RestartProcess();
			break;
		}

		if ((iRetval=WriteMsgQ(iDWSRevToDWSAdap,rcvStr,iLen,1))== ERROR)
		{
			printf("\n Dropped Response while Sending it to RevMap");
			RestartProcess();
			break;
		}
	}
	close(iSocket);
}

void RestartProcess()
{
	return;
}

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	printf("\n Trying to Recv = %d", *RecvLen);
	while(TotalLen < *RecvLen)
	{
		printf("\n Trying to recv %d bytes socketid :%d:", BytesLeft,Socketfd);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		printf("\n After recv Bytes = %d", Bytes);
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

void ConnectionUP()
{
	return;
}

void ConnectionDOWN()
{
	return;
}

	void OpenMsgQue(){
		if((iDWSRevToDWSAdap = OpenMsgQ(DWSMediatorToDWSAdap)) == ERROR)
		{
			perror("OpenMsgQ ...DWSMediatorToDWSAdap");
			exit(ERROR);
		}
		printf("\n DWSAdapToDWSFwd opened successfully with id = %d", iDWSAdapToDWSFwd);
	}

