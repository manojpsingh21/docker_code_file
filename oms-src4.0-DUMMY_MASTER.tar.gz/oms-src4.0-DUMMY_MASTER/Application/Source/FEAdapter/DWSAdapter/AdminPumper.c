#include <my_global.h>
#include "IPCS.h"
#include "AdminAdaptor.h"

LONG32 iAdapToQry;

main()
{
	struct VIEW_IPO_ORDERBOOK_DETAIL_REQUEST pIpodetail;
	memset(&pIpodetail,'\0',sizeof(struct VIEW_IPO_ORDERBOOK_DETAIL_REQUEST));

	if((iAdapToQry = OpenMsgQ(AdaptorToQuery)) == ERROR)
	{
		perror("OpenMsgQ ...AdapToQry");
		exit(ERROR);
	}
	printf("\n AdapToQry opened successfully with id = %d", iAdapToQry);
	strncpy(pIpodetail.sClientId,"MM001",CLIENT_ID_LEN);
	pIpodetail.ReqHeader.iMsgCode = TC_INT_ADMIN_IPO_ORDER_BOOK_REQ;
	pIpodetail.ReqHeader.iUserId = 3790; 
	pIpodetail.ReqHeader.cSource = 'A';
	//	pIpodetail.cFlag = 'V';			
	strncpy(pIpodetail.sCmpyId,"221",COMPANY_ID_LEN);


	if(WriteMsgQ( iAdapToQry,(CHAR *)&pIpodetail, sizeof(struct VIEW_IPO_ORDERBOOK_DETAIL_REQUEST),1) != 1)
	{
		perror("write to Q failed : ");
		exit(ERROR);
	}
	printf("\n write successful \n");	
}







