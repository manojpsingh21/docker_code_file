#include "IPCS.h"
#include "DWSAdapter.h"
#include <errno.h>

LONG32                        iAdminQueriesToAdaptor;
LONG32                        iD2C1ToAdminAdap;
LONG32                        iAdmTrdRtrToAdmAdap;
LONG32                        iRelToOrdRtr ;
LONG32                        iAdaptorToQuery;
LONG32                        iAdaptorToAdminQry;


LONG32          RelayPort;
LONG32          RelayId;
LONG32          dMaxUser;
LONG32          MasterSocket;
sigset_t        SignalSet ;
LONG32		NewSocket;


struct                  USER_SOCKET_LOOKUP UserSocketTable[ MAX_NO_OF_USER_SOCKETS ];

void OpenMsgQueue ();
void ReadFromSocket();
void ReadFromQueue ();





void InsertProcessTable         (pid_t ProcessId, LONG32 RelayPort, LONG32 RelayId);
void CleanSocketResources       (LONG32 Index);
void Str_Trim(CHAR *String);
void SignalHandlerSigTermParent (int dummy);

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
void    fConvertSeqNO(CHAR *, CHAR *);
//#define       CALLING_LENS    20
//#define TWIDDLE(A)      Twiddle ((char *) &A, sizeof(A))
void    fUpdateTimeStamp(struct  NNF_DOUBLE_INT                  *pTempTimeStamp ) ;
void    fExit( LONG32 );
BOOL    fUpdateConnectStatus(SHORT,LONG32);//,LONG32,BOOL);
void    fInitSharedMemory(LONG32);
LONG32  iGlobGroupId;
key_t   iGlobQueueId;
LONG32  iSockfd1;
LONG32  iConnectToExchange =1;
FILE    *fpOrderNum;

SHORT   iConnectionCounter=0;
SHORT   iCounterTotalInvite=0;
SHORT   iCounterTotalTransmit=0;

SHORT   iTotalStream = 0;
LONG32  iTransmitSeq =0, iRecieveSeq =0 ;
CHAR    sKey[DB_KEY_LEN];
CHAR    sProgName[15] = "NseCMConnect";
LONG32  iMainwait = -1;
LONG32  iRespChild,iransChild;
LONG32  iSleepTime;
LONG32  iRespChild,iTransChild;

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

main( LONG32 argc, CHAR **argv )
{

	logTimestamp("Entry [main]");


	LONG32                  Index , Count ,i;
	LONG32                  WriteFlag,WriteIORFlag,WriteDloadFlag;
	LONG32                  iRetval=0,Signal=0,Status=0;
	pid_t                   ForkInd = 1;
	LONG32                  TempRelayPort;
	LONG32                  RstrtFlg = FALSE;
	CHAR                    DummyUser[USER_ID_LEN]="DummyUser";
	CHAR                    DummyClientId[CLIENT_ID_LEN]="DummyClientId";
	pid_t                   ProcessId=0;
	LONG32                  iInputRelayId=0;
	CHAR                    sMAXUSER[10];
	LONG32			SockFlg, flag;	

	setvbuf(stdout,NULL,_IONBF,0);

	if(argc < 4)
	{
		logFatal(" Usage: DWSAdaptor  AdaptorPort AdaptorId");
		exit(1);
	}


	RelayPort = atoi (argv[2]);
	if( RelayPort <=0 )
	{
		logFatal(" Wrong Relay Port ");
		exit(1);
	}
	else
	{
		TempRelayPort = RelayPort;
	}

	RelayId	= atoi (argv[3]);
	if( iInputRelayId <0 )
	{
		logFatal(" Wrong iInputRelayId ");
		exit(1);
	}
	else
	{
		logDebug2(" iInputRelayId is :%d:",iInputRelayId);
	}

	OpenMsgQueue();	

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset(&SignalSet);
	sigaddset(&SignalSet,SIGTERM);
	sigaddset(&SignalSet,SIGCHLD);
	sigaddset(&SignalSet,SIGSEGV);
	sigprocmask(SIG_BLOCK,&SignalSet,NULL);
	//	InitProcessTable();
	AccessUsrRlyShm(DummyUser,INIT); /*****  *******/
	if((SockFlg = CreateSocket()) != TRUE)
	{
		logDebug2("failed To Create Socket ");
		exit(1);
	}
	else
	{
		logDebug2("Socket is Created");
	}


	for(; ;)
	{

		for(; ;)
		{
			NewSocket = accept(MasterSocket, NULL, NULL);
			if(NewSocket < 0)
			{
				logDebug2("No connection found");


			}
			else
			{
				flag = 1;
				if((setsockopt(NewSocket,SOL_SOCKET,SO_KEEPALIVE, ( CHAR *) &flag,sizeof(flag)))< 0)
				{
					perror("SetSockOption:");
					logDebug2("readThread::RelayId %d: Unable to set options for new socket",RelayId);
					close(NewSocket);
					/**     shutdown(NewSocket,2);  ***/
				}
				logDebug2("  after  setsockopt NewSocket= %d ",NewSocket);
				if ( (iRespChild = fork()) == 0 )
				{
					iRespChild = getppid();
					logDebug2("ReadfromsocketChild PID :%d:",iRespChild);
					logDebug2("one chiled is created for reading");
					ReadFromSocket();
				}
				else if( ( iTransChild = fork() ) == 0 )
				{
					iTransChild = getppid();
					logDebug2("ReadfromQueueChild PID :%d:",iTransChild);
					logDebug2("one chiled is created for writing");
					ReadFromQueue();
				}
				break;

			}				

		}

	}




}

void ReadFromSocket()
{


	LONG32 Len, TransCode;
	LONG32  BytesRead;
	LONG32  Dummy;
	LONG32  Index;
	LONG32  Socket;
	LONG32  LocalSoc;
	LONG32  iLogonStatus=0;
	LONG32  Count=ERROR;
	LONG32  iRetVal;
	CHAR    UserId[USER_ID_LEN];
	CHAR    ClientId[CLIENT_ID_LEN];
	LONG32  ClientIdLen =0;
	LONG32  iRetCurrUser=0;
	LONG32  CurrentUser=0;

	struct  INT_DWS_LOGON_REQ   *Mesg_Pkt1;
	CHAR    Mesg_Buf[RUPEE_MAX_PACKET_SIZE];
	struct  INT_COMMON_REQUEST_HDR *pMesg_Pkt;
	struct  INT_COMMON_RESP_HDR     sMesg_Rsp;
	struct  INT_DWS_LOGON_RESP      pLogonResp;
	struct  ORDER_PROCESSOR_START_RESP      sOrdProStrt;


	struct timespec TimeSpec;
	time_t tsec;

	for(; ;)
	{
		logDebug2("Suraj is going to receive 5");
		memset( UserId,'\0',USER_ID_LEN);
		memset( ClientId,'\0',CLIENT_ID_LEN);
		memset(Mesg_Buf,' ',RUPEE_MAX_PACKET_SIZE);
		logDebug2("ReadThread::RelayId %d:-----Waiting on Select-----",RelayId);

		logDebug2(" Return Value  :%d",iRetVal);
		if(( Index = GetSlotInUserSocketTable(NewSocket,INSERT)) == NOT_TRUE)
		{

			logDebug1("RadThread::RelayId %d: No of Users Limit Reached. Will close the new socket established(INSERT) ",RelayId);
			continue;

		}
		for(Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS; Count++)
		{

			/***                    usleep(1); *****/
			logDebug2("Suraj is waiting to receive 2");
			if(UserSocketTable[Count].Socket != UNUSED)
			{
				logDebug2("Suraj is waiting to receive 3");
				logDebug2("\nReadThread:: RelayId %d: UserSocketTable[Count].Socket = %d set at Index = %d ",RelayId,UserSocketTable[Count].Socket,Count);
				logDebug2("\n Before thread_create\n");
				logDebug2("Suraj is waiting to receive 5");
				if((BytesRead = Recv(NewSocket,Mesg_Buf,&Len)) == ERROR )

				{

					logDebug2(" RelayId %d: Error while receiving on the socket:%d ",RelayId,errno);
					usleep(500);
					CleanSocketResources(Index);
					logDebug2(" Alok before SignalReadThreadKillCond in Recv");
					usleep(500);
					return;
				}
				struct  timeval StartPoint1 , EndPoint1 ;
				struct  timezone tzp;
				StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
				gettimeofday(&StartPoint1, &tzp);
				StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
				logDebug2(" Time of entry in ReadWorkerThread :%d:",StartPoint1.tv_sec);
				tsec = time(NULL);
				TimeSpec.tv_sec = 0;
				TimeSpec.tv_nsec = 250000000;
				pMesg_Pkt= ( struct INT_COMMON_REQUEST_HDR * ) &Mesg_Buf;
				Mesg_Pkt1 = ( struct INT_DWS_LOGON_REQ * ) &Mesg_Buf;

				TransCode = pMesg_Pkt->iMsgCode;

				logDebug2("----------------------DATA received-----------------------");
				logDebug2(" RWT:: RelayId %d: Transcode         : %d",RelayId,TransCode);
				logDebug2(" RWT:: RelayId %d: iUserId   : %d",RelayId,pMesg_Pkt-> iUserId);
				logDebug2(" RWT:: RelayId %d: Segment   : %c",RelayId,pMesg_Pkt->cSegment);
				logDebug2(" RWT:: RelayId %d: ExchId    :%s:",RelayId,pMesg_Pkt->sExcgId);
				logDebug2(" RWT:: RelayId %d: MsgLength : %d",RelayId,pMesg_Pkt->iMsgLength );
				logDebug2("----------------------DATA---------------------");



				sprintf(UserId,"%d",pMesg_Pkt-> iUserId);

				iRetVal = Is_Valid_User(UserId,&Count);

				logDebug2(" RWT::RelayId %d: Is_Valid_User returns %d and the count is %d and Index = %d",RelayId,iRetVal,Count, Index);

				if(iRetVal == SOCKET_EXIST  && TransCode != TC_INT_LOGON_REQ)
				{

					logDebug2(" RWT::RelayId %d: Wrong Request recieved on New socket Closing both the socket",RelayId);
					usleep(500);
					CleanSocketResources(Count);
					if(Count != Index)
						CleanSocketResources(Index);

					return;
				}
				else if((iRetVal == SOCKET_EXIST || iRetVal == TRUE)  && (TransCode == TC_INT_LOGON_REQ || TransCode == TC_INT_RECONNECT_REQ))
				{
					logDebug2(" RWT::RelayId %d: Request recieved on New socket Closing old socket",RelayId);
					usleep(500);
					CleanSocketResources(Count);
					iRetVal = SOCKET_EXIST;

				}
				else if(iRetVal == TRUE && TransCode != TC_INT_LOGON_REQ && Count != Index)

				{

					logDebug2(" RWT::RelayId %d: Wrong Request received on New Socket Closing New Socket");
					usleep(500);
					CleanSocketResources(Index);
					return;
				}

				struct  timeval EndPoint2 ;


				logDebug2("Nishant TransCode received  here :%d:",TransCode);
				switch(TransCode)
				{
					case TC_INT_LOGON_REQ:



						if(iRetVal != TRUE )
						{

							if((iRetVal = ProcessLogOnRequest(&Index,UserId)) == FALSE)
							{
								logDebug2(" RelayId %d: Unable to process LogOn Request on RelayId ",RelayId);

								usleep(500);
								CleanSocketResources(Index);

								break;

							}

						}

						pLogonResp.IntRespHeader.iErrorId = 0;



						iRetCurrUser =Find_Max_User(&CurrentUser);

						logDebug2("MaxUser = [%d] CurrentUser = [%d]",dMaxUser,CurrentUser);
						if(CurrentUser >= dMaxUser)
						{
							pLogonResp.IntRespHeader.iErrorId= 4200;
							logDebug2(" Max user violated :%d:",pLogonResp.IntRespHeader.iErrorId);
						}

						pLogonResp.IntRespHeader.iMsgLength = sizeof(struct  INT_DWS_LOGON_RESP);
						pLogonResp.IntRespHeader.iMsgCode = TC_INT_LOGON_RSP;
						pLogonResp.IntRespHeader.iTimeStamp= 0;
						pLogonResp.IntRespHeader.iUserId= pMesg_Pkt-> iUserId;

						logDebug2(" pLogonResp.IntRespHeader.iErrorId:%d:",pLogonResp.IntRespHeader.iErrorId);

						logDebug2(" pLogonResp.IntRespHeader.iUserId:%d:",pLogonResp.IntRespHeader.iUserId);

						strncpy(pLogonResp.sEntityId,"",12);
						strncpy(pLogonResp.AccCode,"",12);
						strncpy(pLogonResp.sName,"",60);
						strncpy(pLogonResp.CurrDate,"20120930",20);

						strncpy(pLogonResp.ExpiryDate,"20120930",20);
						strncpy(pLogonResp.AllowedExch,"1111000",10);
						strncpy(pLogonResp.cfprimaryip,"121.241.245.76",16);
						strncpy(pLogonResp.cffailoverip,"121.241.245.76",16);
						strncpy(pLogonResp.dsprimaryip,"121.241.245.76",16);
						strncpy(pLogonResp.failoverip,"121.241.245.76",16);
						strncpy(pLogonResp.TransPass,"abc123",16);
						pLogonResp.Suscriptionlevel = 7;



						Len = pLogonResp.IntRespHeader.iMsgLength;
						logDebug2(" iUserId%d",pLogonResp.IntRespHeader.iUserId);
						logDebug2(" iMsgLength %d",pLogonResp.IntRespHeader.iMsgLength);
						logDebug2(" iMsgCode %d",pLogonResp.IntRespHeader.iMsgCode);
						logDebug2(" sEntityId %s",pLogonResp.sEntityId);
						logDebug2(" AccCode %s",pLogonResp.AccCode);
						logDebug2(" sName %s",pLogonResp.sName);
						logDebug2(" pLogonResp.CurrDate %s",pLogonResp.CurrDate);
						logDebug2(" pLogonResp.ExpiryDate %s",pLogonResp.ExpiryDate);
						logDebug2(" pLogonResp.cfprimaryip %s",pLogonResp.cfprimaryip);
						logDebug2(" pLogonResp.cffailoverip %s",pLogonResp.cffailoverip);
						logDebug2(" pLogonResp.dsprimaryip %s",pLogonResp.dsprimaryip);
						logDebug2(" pLogonResp.failoverip %s",pLogonResp.failoverip);
						logDebug2(" pLogonResp.AllowedExch %s",pLogonResp.AllowedExch);
						logDebug2(" pLogonResp.Suscriptionlevel %d",pLogonResp.Suscriptionlevel);
						logDebug2(" pLogonResp.TransPass :%s:",pLogonResp.TransPass );



						logDebug2(" Socket FD = [%d]", LocalSoc);


						if((Send(NewSocket,&pLogonResp,&Len ))== ERROR)
						{
							logDebug2(" RelayId %d: Error While sending logon response to user TC_INT_LOGON_REQ ",RelayId);
							CleanSocketResources(Index);
						}

						logDebug2(" RWT::RelayId %d: LogOn Resp being sent to user:%d, iMsgLength = %d",RelayId,sMesg_Rsp.iUserId,sMesg_Rsp.iMsgLength);


						break;

					case TC_INT_KEEP_ALIVE_REQ:

						sMesg_Rsp.iUserId= pMesg_Pkt-> iUserId;
						sMesg_Rsp.cSegment = pMesg_Pkt->cSegment;
						sMesg_Rsp.iMsgLength= sizeof(struct INT_COMMON_RESP_HDR);
						sMesg_Rsp.iErrorId= 0;
						sMesg_Rsp.iTimeStamp= 0;
						sMesg_Rsp.iMsgCode= TC_INT_KEEP_ALIVE_RESP;
						Len = sMesg_Rsp.iMsgLength;

						// LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

						if((Send(NewSocket,&sMesg_Rsp,&Len ))== ERROR)
						{
							// UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
							logDebug2(" RelayId %d: Error While sending response to user TC_INT_KEEP_ALIVE_REQ ",RelayId);
							// LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
							CleanSocketResources(Index);
							// UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

						}

						//   UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
						logDebug2(" RWT::RelayId %d: LogOn Resp being sent to user TC_INT_KEEP_ALIVE_REQ:%d, iMsgLength= %d",RelayId, sMesg_Rsp.iUserId, sMesg_Rsp.iMsgLength);
						break;





					case TC_INT_RECONNECT_REQ :


						logDebug2(" I am in reconnect");
						if(iRetVal != TRUE )
						{

							logDebug2(" iRetVal is [%d] in TC_INT_RECONNECT_REQ going to ProcessLogOnRequest",iRetVal);
							if((iRetVal = ProcessLogOnRequest(&Index,UserId)) == FALSE)
							{
								logDebug2(" RelayId %d: Unable to process LogOn Request on RelayId ",RelayId);
								usleep(500);
								// LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")       ;
								CleanSocketResources(Index);
								// UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

								break;

							}
						}

						logDebug2(" ALOK here after reconnect");

						sMesg_Rsp.iMsgLength= sizeof(struct INT_COMMON_RESP_HDR);
						sMesg_Rsp.iUserId=  pMesg_Pkt->iUserId;
						sMesg_Rsp.iMsgCode= TC_INT_RECONNECT_RESP ;

						Len = sMesg_Rsp.iMsgLength;

						//			logDebug2(" ALOK here after reconnect 2 UserSocketTable[Index].Socket :%d:",UserSocketTable[Index].Socket);

						//  LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
						logDebug2(" Socket FD = [%d]", LocalSoc);


						if((Send(NewSocket,&sMesg_Rsp,&Len))== ERROR)

						{
							// UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
							logDebug2(" RelayId %d: Error While sending logon response to user TC_INT_RECONNECT_REQ Index[%d]",RelayId,Index);
							// LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")       ;
							CleanSocketResources(Index);
							// UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

						}

						//   UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

						logDebug2(" ALOK here after reconnect 3");

						break;




					case    TC_INT_LOGOFF_REQ :

						logDebug2(" RelayId %d: Handling LogOff Transcode : %d",RelayId,TransCode);
						logDebug2(" RelayId %d: In TC_INT_LOGOFF_REQ : %d ,sleeping for 500 ms ",RelayId,TransCode);

						usleep(500);

						// LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")       ;
						CleanSocketResources(Index);
						// UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

						break;

					case    TC_INT_VIEW_CLIENT_LIMIT_REQ:
					case    TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
					case    TC_INT_NET_POS_REQ:
					case    TC_INT_ADMIN_ORDER_BOOK_REQ:
					case    TC_INT_ADMIN_BO_ORDER_BOOK_REQ:
					case    TC_INT_ADMIN_TRADE_BOOK_REQ:
					case    TC_INT_ADMIN_NET_POS_REQ:
					case    TC_INT_SPRD_ORD_BOOK_REQ:
					case    TC_INT_ORDER_BOOK_DTLS_REQ:
					case    TC_INT_TRADE_BOOK_REQ:
					case    TC_INT_CLINET_HOLDING_REQ:
					case    TC_INT_NETPOS_DTL_REQ:
					case    TC_INT_CARRY_FWD_POS_REQ:
					case    TC_INT_DEA_CLIENT_MAPP_REQ:
					case    TC_INT_SEND_MSG_TO_CLIENT_REQ:
					case    TC_INT_DNLD_SYSTEM_MSG_REQ:
					case    TC_INT_REJECTED_ORDERS_REQ:
					case    TC_INT_ADMIN_MARGIN_SHORTFALL_REQ :
					case    TC_INT_ADMIN_VIEW_CLIENT_LIMIT_REQ:
					case    TC_INT_ADMIN_CLINET_HOLDING_REQ:
					case    TC_INT_ADMIN_REJECTED_ORDERS_REQ:
					case    TC_INT_ADMIN_PERCENT_MTM_QUERY_REQ:
					case    TC_INT_ADMIN_CIRCUIT_LIMIT_REQ :
					case    TC_INT_ADMIN_PROFILE_MASTER_REQ :
					case    TC_INT_BATCH_PROCESS_REQ        :
					case    TC_INT_ADMIN_VIEW_PAYOUT_REPORT_REQ :
					case    TC_INT_ADMIN_ORDER_REPORT_REQUEST:
					case    TC_INT_ADMIN_TRADE_REPORT_REQUEST:
					case    TC_INT_ADMIN_IPO_ORDER_BOOK_REQ:
					case    TC_INT_ADMIN_SIP_ORDER_BOOK_REQ:
					case    TC_INT_ADMIN_SIP_ORDER_DETS_REQ:
					case    TC_INT_ADMIN_SIP_ORDER_TRALS_REQ:
					case    TC_INT_ADMIN_CKT_HITTING_HOLDING_REQ:
					case    TC_INT_ADMIN_CKT_HITTING_NETPOS_REQ:
					case    TC_INT_ADMIN_LIMIT_DTL_REQ:

						logDebug2("Before Write Q");

						if((WriteMsgQ(iAdaptorToQuery,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)

						{

							logDebug2(" RelayId %d: Error While writing to Query Queue ",RelayId);

						}

						logDebug2(" RelayId %d: Successfully Written To The Q : %d",RelayId,iAdaptorToQuery);

						break;

					case    TC_INT_RUN_BATCH_PROCESS_REQ       :
					case    TC_INT_ADMIN_EDIT_CLIENT_LIMIT_REQ :
					case    TC_INT_ADMIN_ADD_CLIENT_LIMIT_REQ  :
					case    TC_INT_UPDATE_BATCH_PROCESS_REQ    :
					case    TC_INT_ADMIN_UPDATE_HOLDING_REQ    :
					case    TC_INT_ADMIN_IPO_SEC_DETAILS_REQ  :

						if((WriteMsgQ(iAdaptorToAdminQry,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
						{
							logDebug2(" RelayId :%d: Error While writing to Query Queue.. ",RelayId);
						}
						logDebug2(" RelayId :%d: Successfully Written To The queue :%d:",RelayId,iAdaptorToAdminQry);
						break;

					case    TC_INT_ORDER_ENTRY_REQ                  :
					case    TC_INT_ORDER_MODIFY                     :
					case    TC_INT_ORDER_CANCEL                     :

					case    TC_INT_SPREAD_OE_REQ                    :
					case    TC_INT_SPREAD_OM_REQ                    :
					case    TC_INT_SPREAD_OC_REQ                    :

					case    TC_INT_OFF_ORDER_ENTRY                  :
					case    TC_INT_OFF_ORDER_MODIFY                 :
					case    TC_INT_OFF_ORDER_CANCEL                 :
					case    TC_INT_NOTIFICATION_REQ                 :

					case    TC_INT_SQUAREOFF_INTRADAY_REQ           :
					case    TC_INT_PUMPOFFLINE_REQ                  :
					case    TC_INT_ADMIN_EXPIRY_REQ                 :
					case    TC_INT_CON_DEL_REQ                      :

					case    TC_INT_SIP_ORD_REQ                      :
					case    TC_INT_SIP_ORD_CANCEL                   :
					case    TC_INT_SIP_ORD_PAUSE_REQ                :
					case    TC_INT_SIP_ORD_CONTINUE_REQ             :

					case    TC_INT_CREATE_ALL_FILE_REQ              :
					case    TC_INT_DEALER_CLIENT_SUSPENSION_REQ     :

						if((WriteMsgQ(iRelToOrdRtr,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
						{
							logFatal(" RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
						}

						gettimeofday(&EndPoint2, &tzp);
						EndPoint2.tv_sec = EndPoint2.tv_sec+19800;
						logDebug2(" Time of exit is ReadWorkerThread :%d:",EndPoint2.tv_sec);
						logDebug2(" RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToOrdRtr);

						break;


					case    TC_INT_CO_ORDER_REQ     :
					case    TC_INT_CO_ORDER_MODIFY  :
					case    TC_INT_CO_ORDER_EXIT    :
					case    TC_INT_BO_ORDER_REQ     :
					case    TC_INT_BO_ORDER_MODIFY  :
					case    TC_INT_BO_ORDER_EXIT    :

						if((WriteMsgQ(iRelToOrdRtr,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
						{
							logDebug2(" RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
						}

						gettimeofday(&EndPoint2, &tzp);
						EndPoint2.tv_sec = EndPoint2.tv_sec+19800;
						logDebug2(" Time of exit is ReadWorkerThread :%d:",EndPoint2.tv_sec);
						logDebug2(" Cover Order Request MsgCode = %d",TC_INT_CO_ORDER_REQ);
						logDebug2(" RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToOrdRtr);

						break;
					default:

						logDebug2(" RelayId %d: Wrong TransCode recieved::%d ",RelayId,TransCode);

						usleep(500);

						//   LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongTransCode")      ;

						CleanSocketResources(Index);

						// UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongTransCode")   ;

						break;

				}


				logDebug2(" Alok here before SignalReadThreadKillCond 1");

				// SignalReadThreadKillCond(READ_THREAD);
				logDebug2(" Alok here after SignalReadThreadKillCond 1");

				//     LockThreadMutex(&DummyPipeLock,"WriteToPipe");
				logDebug2(" Alok here after LockThreadMutex 1");

				// write(DummyPipe[1],&Dummy,sizeof(LONG32));
				logDebug2(" Alok here after write in dummy pipe 1");

				//   UnLockThreadMutex(&DummyPipeLock,"WriteToPipe");
				logDebug2(" Alok here after UnLockThreadMutex 1");
			}
		}	
	}
}


void ReadFromQueue ()
{


}

int CreateSocket()
{
	struct sockaddr_in Serv_Addr;
	struct sockaddr_in Cli_Addr;
	fd_set  ReadSocketSet;
	LONG32 flag=1;



	//        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	//        pthread_setcanceltype (PTHREAD_CANCEL_DEFERRED, NULL);




	memset((CHAR *) &Serv_Addr,0,sizeof(Serv_Addr));

	Serv_Addr.sin_family = AF_INET;
	Serv_Addr.sin_addr.s_addr = htonl(INADDR_ANY);
	Serv_Addr.sin_port = htons(RelayPort);




	logDebug2(" Read Thread for RelayId = %d, RelayPort = %d",RelayId,RelayPort);



	//        LockThreadMutex ( &UserSocketTableLock, "InitUserSocketTable" );
	//        InitUserSocketTable( );
	//        UnLockThreadMutex ( &UserSocketTableLock, "InitUserSocketTable" );



	if((MasterSocket = socket ( AF_INET,SOCK_STREAM ,0 ) ) == ERROR)
	{
		perror("Socket:");
		logFatal(" RelayId %d: Unable to make a socket",RelayId);
		exit(1);
	}

	logDebug1("----- I am here socket [%d] -----",MasterSocket);

	if((setsockopt(MasterSocket,SOL_SOCKET,SO_REUSEADDR, ( CHAR *) &flag,sizeof(flag)))< 0)
	{
		perror("SetSockOption:");
		logDebug2(" RelayId %d: Unable to set options for socket",RelayId);
		close(MasterSocket);
		/**     shutdown(MasterSocket,2);***/
		exit(1);
	}



	if((bind(MasterSocket,(struct sockaddr *) &Serv_Addr, sizeof(Serv_Addr))) == ERROR)
	{
		perror("Bind:");
		logDebug1(" RelayId %d: Unable to bind a socket",RelayId);
		close(MasterSocket);
		/***            shutdown(MasterSocket,2);****/
		exit(1);
	}



	if((listen(MasterSocket,5)) < 0 )
	{
		perror("Listen:");
		logFatal(" Unable to listen on socket");
		close(MasterSocket);
		/***    shutdown(MasterSocket,2); ****/
		exit(1);
	}
	return TRUE;

}


LONG32  AccessUsrRlyShm(CHAR *User, LONG32 Flg) /*****  *******/

{

	struct  ADMIN_ADAPTER_USER_ARRAY *pSTWUsrRlyArryShm;
	struct  ADMIN_ADAPTER_USER      *pSTWUsrRly;

	LONG32  Count;
	LONG32  iRetVal         = FALSE;

	LockShm(AdminAdapterUserShm);

	logDebug2(" alok in shared memory (INIT=0,INSERT=1,DELETE=2,SELECT=3)  Flg is :%d ",Flg);

	/************/
	if((pSTWUsrRlyArryShm = (struct ADMIN_ADAPTER_USER_ARRAY *) OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE)) == (struct ADMIN_ADAPTER_USER_ARRAY *) ERROR)
	{
		logDebug2(" RelayId %d: Error Opening STW User Relay Shared Memory ",RelayId);
		exit(1);
	}
	/***************/
	/******
	  pSTWUsrRlyArryShm = OpenSharedMemory(AdminAdapterUserShm,AdminAdapterUserShm_SIZE) ;

	  logDebug2("\n ALok here %d: ERROR is :%d:",*( (int *) pSTWUsrRlyArryShm),ERROR);

	  if ( *( (int *) pSTWUsrRlyArryShm) == ERROR )
	  {
	  logDebug2("\n RelayId %d: Error Opening STW User Relay Shared Memory ",RelayId);
	  }
	 *******/

	logDebug2(" alok in shared memory 2 ");
	pSTWUsrRly = pSTWUsrRlyArryShm;
	if ( Flg == INIT)
	{
		for ( Count=0; Count<MAX_DWS_USERS; Count++ )
		{
			pSTWUsrRly->iRelayId =   UNUSED  ;
			pSTWUsrRly->ProcessId    =   UNUSED  ;
			memset(&(pSTWUsrRly->sUser),'\0',USER_ID_LEN);
			pSTWUsrRly++;

		}
		logDebug2(" RelayId %d : Shared Memory Initialized",RelayId);
		iRetVal = TRUE;
	}
	else if ( Flg == INSERT)
	{
		logDebug2(" RelayId %d: UserId added is %s and length = %d", RelayId,User,strlen(User));
		for(Count = 0;Count < MAX_DWS_USERS; Count++)
		{
			if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId != UNUSED)
			{
				pSTWUsrRly->iRelayId = RelayId;
				pSTWUsrRly->ProcessId = getpid();
				memcpy(&(pSTWUsrRly->sUser),User,strlen(User));

				logDebug2(" RelayId %d: User Updated, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
				iRetVal =       TRUE;
				break;
			}
			pSTWUsrRly++;
		}
		if( iRetVal == FALSE)
		{
			logDebug2(" AccessUsrRlyShm:: UserId: %s==Len %d Record Does Not Exist. Doing Fresh Insertion In Shm",User,strlen(User));
			pSTWUsrRly = pSTWUsrRlyArryShm;
			for(Count = 0;Count < MAX_DWS_USERS; Count++)
			{
				if(pSTWUsrRly->iRelayId == UNUSED)
				{
					pSTWUsrRly->iRelayId = RelayId;
					pSTWUsrRly->ProcessId = getpid();
					memcpy(&(pSTWUsrRly->sUser),User,strlen(User));
					logDebug2(" RelayId %d: User Added, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
					iRetVal =       TRUE;
					break;

				}
				pSTWUsrRly++;
			}

		}

	}
	else if ( Flg == DELETE  && User[0]!= NULL)
	{
		for(Count = 0;Count < MAX_DWS_USERS; Count++)
		{
			if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId == RelayId && strlen(pSTWUsrRly->sUser)== strlen(User))
			{
				logDebug2(" RelayId %d: User Delete, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);

				memset(&(pSTWUsrRly->sUser),'\0',USER_ID_LEN);
				pSTWUsrRly->iRelayId = UNUSED;
				pSTWUsrRly->ProcessId = UNUSED;

				iRetVal =       TRUE;
			}
			pSTWUsrRly++;
		}
	}
	else if (Flg == SELECT && User[0]!= NULL)
	{

		for(Count = 0;Count < MAX_DWS_USERS; Count++)
		{
			if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId == RelayId && strlen(pSTWUsrRly->sUser)== strlen(User) )
			{
				logDebug2(" RelayId %d: User Selected, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
				iRetVal =       TRUE;
				break;
			}
			pSTWUsrRly++;
		}
	}

	if((CloseSharedMemory((void *) pSTWUsrRlyArryShm)) == ERROR)
	{

		logDebug2(" RelayId %d: Error in closing STW User Relay Shared Memory Errno = %d",RelayId,errno);
		exit(1);

	}
	logDebug2(" Before Unlock AdminAdapterUserShm");
	UnLockShm(AdminAdapterUserShm);
	return iRetVal;

}

void OpenMsgQueue ()
{
	logTimestamp("Entry OpenMsgQueue");	

	if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ  iRelToOrdRtr :");
		exit( 1 );
	}

	logDebug1(" iRelToOrdRtr created sucesfully wid Qid :%d:",iRelToOrdRtr);


	if( ( iAdaptorToQuery= OpenMsgQ( (AdaptorToQuery))) == ERROR )
	{
		perror("Open RelToDirQ iAdaptorToQuery :");
		exit( 1 );
	}
	logDebug1(" iAdaptorToQuery queue opened sucessfully with queuue id :%d:",iAdaptorToQuery);

	if((iAdaptorToAdminQry = OpenMsgQ(AdaptorToAdminQry)) == ERROR )
	{
		perror("Open RelToDirQ iAdaptorToAdminQry :");
		exit( 1 );
	}
	logDebug1("iAdaptorToAdminQry queue opened sucessfully with queuue id :%d:",iAdaptorToAdminQry);

	if( (iAdminQueriesToAdaptor = OpenMsgQ(AdminQueriesToAdaptor)) == ERROR)
	{
		perror("Open iAdminQueriesToAdaptor :");
		exit( 1 );
	}

	logDebug1(" AdminQueriesToAdaptor :%d:",iAdminQueriesToAdaptor);

	if( (iD2C1ToAdminAdap = OpenMsgQ(D2C1ToAdminAdap)) == ERROR)
	{
		perror("Open iD2C1ToAdminAdap:");
		exit( 1 );
	}

	logDebug1(" iD2C1ToAdminAdap:%d:",iD2C1ToAdminAdap);

	if( (iAdmTrdRtrToAdmAdap= OpenMsgQ(AdmTrdRtrToAdmAdap)) == ERROR)
	{
		perror("Open iAdmTrdRtrToAdmAdap:");
		exit( 1 );
	}

	logDebug1(" iAdmTrdRtrToAdmAdap :%d:",iAdmTrdRtrToAdmAdap);

	logTimestamp("Exit OpenMsgQueue");
}




void CleanSocketResources(  LONG32 lIndex)

{
	LONG32  Len;
	LONG32  lRetval;
	LONG32  lSocket=0;
	LONG32  Dummy;
	CHAR    Mesg_Buf[RUPEE_MAX_PACKET_SIZE];
	if(UserSocketTable[lIndex].User != SPACE)
	{
		AccessUsrRlyShm(&(UserSocketTable[lIndex].User),DELETE);/* */
	}
	logDebug2(" CSR::RelayId %d: Index Got : %d", RelayId,lIndex);
	memset(&UserSocketTable[lIndex].User,'\0',USER_ID_LEN);
	if ( UserSocketTable[lIndex].Socket > 2)  /* Other than STDIN, STDOUT and STDERR fd's */
	{
		lSocket         =       UserSocketTable[lIndex].Socket;

	}
	else
	{
		logDebug2("Incorrect UserSocketTable[lIndex].Socket : %d",UserSocketTable[lIndex].Socket);
		return;
	}

	logDebug2(" CSR::RelayId %d: Going To Close The Socket : %d,lSocket: %d , UserSocketTable[lIndex].User:%s:",RelayId,UserSocketTable[lIndex].Socket,lSocket,UserSocketTable[lIndex].User);

	logDebug2(" After LockThreadMutex before closing socket :");
	if ( lSocket != 0 )
	{
		/***            logDebug2("\n Alok Before   shutdown socket in CleanSocket Resour");
		  lRetval = shutdown(lSocket,2);**********************/
		logDebug2(" Alok Before   closing socket in CleanSocket Resour");
		lRetval = close(lSocket);
		logDebug2(" Alok After   closing socket in CleanSocket Resour lRetval is :%d: ",lRetval);
		/***    lRetval = shutdown(lSocket,2);          ***/
		usleep(500);
	}
	else
	{
		logDebug2(" ERROR:2167: lSocket [%d]",lSocket);
	}
	logDebug2(" After before making that socket as unused :");
	UserSocketTable[lIndex].Socket = UNUSED;
	logDebug2(" Alok After   UserSocketTable.Socket = UNUSED  CleanSocket Resour Index %d",lIndex);


}


