BOOL	fAddHoldings(CHAR *RcvMsg)
{
	logTimestamp("Entry : fAddHoldings");
	struct  ADD_HOLDING_REQ        *pAddHoldingReq;
	struct  ADMIN_VIEW_COMMON_HDR_RESP      pAddHoldingResp;

	pAddHoldingReq = (struct ADD_HOLDING_REQ *)RcvMsg;

	CHAR            sWhere_Clause[QUERY_SIZE];
	CHAR 		sAddHoldingQry[QUERY_SIZE];
	CHAR		sEntityTypeQry[QUERY_SIZE];
	CHAR		sChkCntQry[QUERY_SIZE];
	CHAR		Entity_Type[5];
	CHAR		sInsHoldQry[QUERY_SIZE];
	CHAR		sUpdHoldQry[QUERY_SIZE];

	logDebug2("pAddClLimtReq->sEntityId = %s",pAddClLimtReq->sEntityId);
	logDebug2("pAddClLimtReq->sClientId = %s",pAddClLimtReq->sClientId);

	memset(sAddHoldingQry,'\0',QUERY_SIZE;
			memset (sEntityTypeQry,'\0',QUERY_SIZE);
			memset (sChkCntQry,'\0',QUERY_SIZE);
			memset (sInsHoldQry,'\0',QUERY_SIZE);
			memset (sUpdHoldQry,'\0',QUERY_SIZE);

			sprintf(sEntityTypeQry, "select ENTITY_TYPE from ENTITY_MASTER where ENTITY_CODE = \"%s\"",pAddHoldingReq->sClientId);

			logDebug2("sEntityTypeQry = %s",sEntityTypeQry);

			if(mysql_query(DBQury,sEntityTypeQry) != SUCCESS)
			{
			logSqlFatal("Error in sChkMaxAdhocLimit Query.");
			sql_Error(DBQury);
			}
			Res = mysql_store_result(DBQury);
			iNoOfRec = mysql_num_rows(Res);
			logDebug2("iNoOfRec = %d",iNoOfRec);

			if(Row = mysql_fetch_row(Res))
			{
				Entity_Type = atoi(Row[0][0]);
				logDebug2("Entity_Type = ",Entity_Type);
			}

			if(Entity_Type == SUPER_ADMIN)
			{
				sprintf(sWhere_Clause,"");
			}
			else
			{
				sprintf(sWhere_Clause,"AND CLIENT_ID = ENTITY_CODE AND ENTITY_MANAGER_CODE = \"%s\"",pAddHoldingReq->sClientId);
			}

			sprintf(sChkCntQry,"select count(*) CNT from RMS_CLIENT_SECURITY_LIMIT t,ENTITY_MASTER b where t.ISIN_CODE = \"%s\" and t.CLIENT_ID = \"%s\" and t.EXCH_ID = \"%s\" and t.SECURITY_SOURCE_TYPE = \"%s\" %s",pAddHoldingReq->sISINCode,pAddHoldingReq->sClientId,pAddHoldingReq.ReqHeader->sExcgId,pAddHoldingReq->sSecSource,sWhere_Clause);

			if(mysql_query(DBQury,sChkCntQry) != SUCCESS)
			{
				logSqlFatal("Error in sChkCntQry Query.");
				sql_Error(DBQury);
			}

			Res1 = mysql_store_result(DBQury);
			iNoOfrec = mysql_num_rows(Res1);
			logDebug2("iNoOfRec = %d",iNoOfRec);

			if(Row = mysql_fetch_row(Res1))
			{
				iNoOfCnt = atoi(Row[0][0]);
				logDebug2("iNoOfCnt = ",iNoOfCnt);

			}

			if(iNoOfCnt == 0)
			{
				sprintf(sInsHoldQry,"INSERT INTO RMS_CLIENT_SECURITY_LIMIT \
						(ISIN_CODE,\
						 EXCH_ID,\
						 SECURITY_SOURCE_TYPE,\
						 QTY,\
						 QTY_UTILIZED,\
						 CLIENT_ID)\
						VALUES(\"%s\",\"%s\",\"%s\",%d,%d,\"%s\")\
						on duplicate key \
						UPDATE \
						QTY = VALUES(QTY + %d) ,\
						ISIN_CODE = VALUES(ISIN_CODE) ,\
						CLIENT_ID = VALUES(CLIENT_ID), \
						EXCH_ID = VALUES (EXCH_ID) ,\
						SECURITY_SOURCE_TYPE = VALUES (SECURITY_SOURCE_TYPE)	
						",pAddHoldingReq->sISINCode,pAddHoldingReq.ReqHeader->sExcgId,pAddHoldingReq->sSecSource,pAddHoldingReq->fQty,pAddHoldingReq->fQtyUtlized,pAddHoldingReq->sClientId,pAddHoldingReq->fQty);

				logDebug2("sInsHoldQry = %s",sInsHoldQry);

			}

			if(mysql_query(DBQury,sInsHoldQry) != SUCCESS)
			{
				logSqlFatal("Error in sChkCntQry Query.");
				sql_Error(DBQury);

				pAddHoldingResp.IntRespHeader.iErrorId = 1;
				pAddHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_HOLDING_ERR_RESP;
				logDebug2("Msg Code = %d",pAddHoldingResp.IntRespHeader.iMsgCode);
				strcpy(pAddCliLmtResp.sErrorMsg,"Something Went Wrong !!!");
				logDebug2("pAddHoldingResp.sErrorMsg = %s",pAddHoldingResp.sErrorMsg);



			}
			else
			{
				pAddHoldingResp.IntRespHeader.iErrorId = 0;
				pAddHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_HOLDING_SSC_RESP;
				logDebug2("Msg Code = %d",pAddHoldingResp.IntRespHeader.iMsgCode);
				strcpy(pAddCliLmtResp.sErrorMsg,"Holding Added Successfully");
				logDebug2("pAddHoldingResp.sErrorMsg = %s",pAddHoldingResp.sErrorMsg);

			}	
			if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pAddHoldingResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
			{
				logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
				exit(ERROR);
			}
}
