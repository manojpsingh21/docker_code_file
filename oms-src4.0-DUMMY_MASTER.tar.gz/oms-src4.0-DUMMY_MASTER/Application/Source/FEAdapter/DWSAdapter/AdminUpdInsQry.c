#include <my_global.h>
#include <string.h>
#include <mysql.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include "IPCS.h"
#include "AdminAdaptor.h"

LONG32  iAdapToQry;
LONG32  iTrdRtrToRel;
LONG32  iRelayID;
MYSQL   *DBQury;

MYSQL_RES       *Res;
MYSQL_ROW       Row;
CHAR    sRRPath[100];
LONG32  i=0,j=0;
main (int argc, char **argv)
{
	logTimestamp("Entry : Main");
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	DBQury = DB_Connect();

/*	if(mysql_set_server_option(DBQury,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		return FALSE;
	}
*/

	memset(sRRPath,'\0',100);
        fLoadEnv();
        logDebug2("sRRPath |%s|",sRRPath);
	fOpenMesgQ();
	fMapper();

	logTimestamp("Exit : Main");
}

BOOL    fMapper()
{
	logTimestamp("Entry : Mapper");

	struct  INT_COMMON_REQUEST_HDR *pReqHeader;
	struct  VIEW_COMMON_QUERY_REQ   *pReq;

	CHAR    RcvMsg[LOCAL_MAX_PACKET_SIZE];
	LONG32  iMsgCode;
	LONG32  iRetVal;
	LONG32  iRelayID;
        struct VIEW_COMMON_HDR_RESP pRoleChkResp;
        CHAR    sCommand[COMMAND_LEN];

	while(1)
	{
		logInfo("--============== Ready To Ready Req :%d ==============--",iAdapToQry);
		
		memset(&RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE);

		if((ReadMsgQ(iAdapToQry, &RcvMsg, LOCAL_MAX_PACKET_SIZE,0)) != TRUE)
		{
			logFatal("Error : MsgQId is %d",iAdapToQry);
			exit(ERROR);
		}
		
		if(mysql_set_server_option(DBQury,CLIENT_MULTI_STATEMENTS) == 0)
                 {
                        logDebug2(" mysql_set_server_option SUCCESS");
                 }
                 else
                 {
                        logDebug2(" mysql_set_server_option FAILed");
                        return FALSE;
                 }


	
		pReqHeader=(struct INT_COMMON_REQUEST_HDR *) &RcvMsg ;


		logDebug2("pReqHeader->iSeqNo = %d",pReqHeader->iSeqNo);
		logDebug2("pReqHeader->iMsgLength= %d",pReqHeader->iMsgLength);
		logDebug2("pReqHeader->iMsgCode= %d",pReqHeader->iMsgCode);
		logDebug2("pReqHeader->sExcgId= %s",pReqHeader->sExcgId);
		logDebug2("pReqHeader->iUserId= %d",pReqHeader->iUserId);
		logDebug2("pReqHeader->cSource= %c",pReqHeader->cSource);
		logDebug2("pReqHeader->cSegment= %c",pReqHeader->cSegment);


		iMsgCode = pReqHeader->iMsgCode;
		logDebug2("iMsgCode = %d",iMsgCode);

		switch ( iMsgCode )
		{
			case    TC_INT_ADMIN_EDIT_CLIENT_LIMIT_REQ :
				iRetVal = fEditCliLimit(&RcvMsg);
				break;

			case    TC_INT_ADMIN_ADD_CLIENT_LIMIT_REQ :
				iRetVal = fAddClientLimit(&RcvMsg);
				break;

			case 	TC_INT_UPDATE_BATCH_PROCESS_REQ :
			case	TC_INT_RUN_BATCH_PROCESS_REQ	:
				iRetVal = fUpdateBatch (&RcvMsg);
				break;

			case    TC_INT_ADMIN_IPO_SEC_DETAILS_REQ :
				iRetVal = fIpoSecDetail(&RcvMsg);
				break;

			case	TC_INT_ADMIN_ADD_PROFILE_MASTER_REQ :
			case	TC_INT_ADMIN_EDIT_PROFILE_MASTER_REQ :
				iRetVal = fAddEditProfileMaster(&RcvMsg);
				break;

			case	TC_INT_ADMIN_UPDATE_HOLDING_REQ :
			case    TC_INT_ADMIN_ADD_HOLDING_REQ :
				iRetVal = fUpdateHoldings(&RcvMsg);
				break;

			case TC_INT_CREATE_ALL_FILE_REQ :
                                pReq =(struct VIEW_COMMON_QUERY_REQ *) &RcvMsg ;

                                logDebug2("Creating All File for Dealer id :%s:",pReq->sEntityId);
                                if(strcmp(pReq->sEntityId,"-1") != 0)
                                {
                                        logDebug2("Creating RRFILE Normal For Branch Level Dealer");
                                        sprintf(sCommand,"$HOME/Application/Exec/ShellScripts/CreateClientList.sh G %s ",pReq->sEntityId);
                                        logInfo("sCommand :%s:",sCommand);
                                        system(sCommand);
                                }
                                else
                                {
                                        logDebug2("Creating RRFILE Broker Level dealer");
                                        sprintf(sCommand,"$HOME/Application/Exec/ShellScripts/CreateClientList.sh  B ");
                                        logInfo("sCommand :%s:",sCommand);
                                        system(sCommand);
                                }
                                        fSendRspAdmin(&RcvMsg);
                                break ;

			
			case    TC_INT_ADMIN_IPO_ORDER_REPORT_REQUEST:
				iRetVal = fIpoOrderReport(&RcvMsg);
				break;	
		
			default :
				logFatal(" Invalid Transcode :%d:",iMsgCode);
				iRetVal = FALSE;
				break;
		}
	}

	logTimestamp("Exit : Mapper");
}

fOpenMesgQ()
{
	logTimestamp("Entry : fOpenMesgQ");

	if((iAdapToQry = OpenMsgQ(AdaptorToAdminQry)) == ERROR)
	{
		perror("Open AdaptorToQuery");
		exit(ERROR);
	}
	if((iTrdRtrToRel= OpenMsgQ(AdminQueriesToAdaptor)) == ERROR)
	{
		perror("Open TrdRtrToRel");
		exit(ERROR);
	}

	logTimestamp("Exit  : fOpenMesgQ");
}

BOOL    fAddEditProfileMaster(CHAR *RcvMsg)
{
	logTimestamp("Entry : fAddEditProfileMaster");

	struct  ADD_EDIT_PROFILE_MASTER_REQ     *pAddProfileReq;
	struct  ADMIN_VIEW_COMMON_HDR_RESP      pAddEditProfileResp;

	pAddProfileReq = (struct  ADD_EDIT_PROFILE_MASTER_REQ *)RcvMsg;

	CHAR    sRmsCodeQry[QUERY_SIZE];
	CHAR    sRPMCode[RPM_CODE_LEN];
	CHAR    sAddEditProfileQry[DOUBLE_MAX_QUERY_SIZE];

	memset(sRmsCodeQry,'\0',QUERY_SIZE);
	memset(sAddEditProfileQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sRPMCode,'\0',RPM_CODE_LEN);
	logDebug2("pAddProfileReq->ReqHeader.iMsgCode = %d",pAddProfileReq->ReqHeader.iMsgCode);

	if(pAddProfileReq->ReqHeader.iMsgCode == TC_INT_ADMIN_ADD_PROFILE_MASTER_REQ)
	{
		sprintf(sRmsCodeQry,"select CONCAT(\'%c\',NextVal(\"%s\")) CODE FROM dual",PROFILE_ADD_R,ADD_RP);
		logDebug2("sRmsCodeQry = %s",sRmsCodeQry);

		if(mysql_query(DBQury,sRmsCodeQry) != SUCCESS)
		{
			logSqlFatal("Error in sRmsCodeQry Query.");
			sql_Error(DBQury);
		}
		Res = mysql_store_result(DBQury);

		if(Row = mysql_fetch_row(Res))
		{
			strcpy(sRPMCode,Row[0]);
			logDebug2("sRPMCode = %s",sRPMCode);
		}

		sprintf(sAddEditProfileQry,"INSERT INTO RMS_RISK_PROFILE_MAST \
				(RPM_CODE,RPM_NAME,RPM_VALIDATE,RPM_MRGN_METHOD_EQ,RPM_MRGN_METHOD_FO,RPM_GEN_MULT, \
				 RPM_EQ_MAR_TYPE,RPM_DR_MAR_TYPE,RPM_CD_MAR_TYPE,RPM_COM_MAR_TYPE,RPM_EQ_MARGIN,RPM_DR_MARGIN,RPM_CD_MARGIN,\
				 RPM_COM_MARGIN, RPM_EQ_FACTOR,RPM_DR_FACTOR,RPM_CD_FACTOR,RPM_COM_FACTOR,RPM_EQ_BASKET,RPM_DR_BASKET,\
				 RPM_MAX_ORD_QTY,RPM_MAX_LOT,RPM_MAX_ORD_VALUE, RPM_MTM_LOSSPER,RPM_CNC_SELL_BEN_PER,RPM_EXPO_MAR,RPM_COLLATERAL_FLG,\
				 RPM_REALIZE_PROFIT,RPM_COLL_FO,MRGFACTEQ, MRGFACTDR,MRGFACTCOM, INTFACTEQ,INTFACTDR,INTFACTCOM,RPM_CREATED_BY,\
				 RPM_CREATED_DATE,RPM_ACTIVE,RPM_FUNDLIMITTYPE,RPM_MTOMSQOFFPER,INTFACTCD,MRGFACTCD, RPM_OPT_MKT_ORDER_FLAG,\
				 RPM_PRODUCT_ENABLED,RPM_SCRIP_BLOCK_BASKET, RPM_EQ_CO_FACTOR,RPM_FNO_CO_FACTOR,RPM_CDS_CO_FACTOR,RPM_COM_CO_FACTOR,\
				 RPM_EQ_CO_SL_PRC_RANGE,RPM_FNO_CO_SL_PRC_RANGE, RPM_CDS_CO_SL_PRC_RANGE,RPM_COM_CO_SL_PRC_RANGE,RPM_EQ_CO_SL_MIN_TRG_PRC,\
				 RPM_FNO_CO_SL_MIN_TRG_PRC,RPM_CDS_CO_SL_MIN_TRG_PRC, RPM_COM_CO_SL_MIN_TRG_PRC,RPM_EQ_BO_FACTOR,RPM_FNO_BO_FACTOR,\
				 RPM_CDS_BO_FACTOR,RPM_COM_BO_FACTOR,RPM_EQ_BO_SL_PRC_RANGE, RPM_FNO_BO_SL_PRC_RANGE,RPM_CDS_BO_SL_PRC_RANGE,\
				 RPM_COM_BO_SL_PRC_RANGE,RPM_EQ_BO_SL_MIN_TRG_PRC,RPM_FNO_BO_SL_MIN_TRG_PRC, RPM_CDS_BO_SL_MIN_TRG_PRC,\
				 RPM_COM_BO_SL_MIN_TRG_PRC,RPM_EQ_SQOFF_PRC_RANGE,RPM_FNO_SQOFF_PRC_RANGE,RPM_CDS_SQOFF_PRC_RANGE, RPM_COM_SQOFF_PRC_RANGE,\
				 RPM_MIN_TRAIL_GAP,RPM_GROSS_BUY_QTY,RPM_GROSS_SELL_QTY,RPM_GROSS_BUY_VALUE,RPM_GROSS_SELL_VALUE,RPM_NET_QTY,RPM_NET_LOT,\
				 RPM_NET_BUY_VALUE,RPM_NET_SELL_VALUE,RPM_TURNOVER,RPM_MIN_ORD_QTY,RPM_MIN_ORD_VALUE,RPM_PENDING_BUY_ORD_VALUE,\
				 RPM_PENDING_SELL_ORD_VALUE,RPM_PENDING_ORD_VAL,RPM_DUPLICATE_ORD_FLG,RPM_TOP_UP_MARGIN,RPM_BUY_OPTION_MULTIPLY,\
				 RPM_MTM_ALERT_PERC,RPM_MTM_SQ_OFF_PERC,RPM_CO_BASKET,RPM_BO_BASKET )\
				values(\"%s\",\"%s\",\'%c\',\"%s\",\"%s\",%d,\'%c\',\'%c\',\'%c\',\'%c\',%d,%d,%d,%d,%d,%d,%d,%d, \
					\"%s\",\"%s\",%d,%d,%d,%d,%d,\'%c\',\'%c\',\'%c\',\'%c\',%lf,%lf,%lf,%lf,%lf,%lf,\"%s\",now(),\'%c\',\'%c\', \
					%d,%lf,%lf,\'%c\',\"%s\",\"%s\",%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf, \
					%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%d,%d,%lf,%lf,%d,%d,%lf,%lf,%lf,%d,%lf,%lf,%lf,%lf,\'%c\',\
					%lf,%lf,%lf,%lf,\"%s\",\"%s\")",sRPMCode,pAddProfileReq->sRpmName,pAddProfileReq->cRpmValidate, \
				pAddProfileReq->sRpmMrgnMethodEq,pAddProfileReq->sRpmMrgnMethodFo,pAddProfileReq->iRpmGenMult,pAddProfileReq->cRpmEqMarType,\
				pAddProfileReq->cRpmDrMarType,pAddProfileReq->cRpmCdMarType,pAddProfileReq->cRpmComMarType,pAddProfileReq->iRpmEqMargin,\
				pAddProfileReq->iRpmDrMargin,pAddProfileReq->iRpmCdMargin,pAddProfileReq->iRpm_Com_Margin,pAddProfileReq->iRpm_Eq_Factor,\
				pAddProfileReq->iRpm_Dr_Factor,pAddProfileReq->iRpm_Cd_Factor,pAddProfileReq->iRpm_Com_Factor,pAddProfileReq->sRpm_Eq_Basket,\
				pAddProfileReq->sRpm_Dr_Basket,pAddProfileReq->iRpm_Max_Ord_Qty,pAddProfileReq->iRpm_max_lot,pAddProfileReq->iRpm_max_ord_value,\
				pAddProfileReq->iRpm_mtm_lossper,pAddProfileReq->iRpm_cnc_sell_ben_per,pAddProfileReq->cRpm_expo_mar,\
				pAddProfileReq->cRpm_collateral_flg,pAddProfileReq->cRpm_realize_profit,pAddProfileReq->cRpm_coll_fo,pAddProfileReq->fMrgfacteq,\
				pAddProfileReq->fMrgfactdr,pAddProfileReq->fMrgfactcom,pAddProfileReq->fIntfacteq,pAddProfileReq->fIntfactdr,\
				pAddProfileReq->fIntfactcom,pAddProfileReq->sRpm_created_by,pAddProfileReq->cRpm_active,\
				pAddProfileReq->cRpm_fundlimittype,pAddProfileReq->iRpm_mtomsqoffper,pAddProfileReq->fIntfactcd,pAddProfileReq->fMrgfactcd,\
				pAddProfileReq->cRpm_opt_mkt_order_flag,pAddProfileReq->sRpm_product_enabled,pAddProfileReq->sRpm_scrip_block_basket,\
				pAddProfileReq->fRpm_eq_co_factor,pAddProfileReq->fRpm_fno_co_factor,pAddProfileReq->fRpm_cds_co_factor,\
				pAddProfileReq->fRpm_com_co_factor,pAddProfileReq->fRpm_eq_co_sl_prc_range,pAddProfileReq->fRpm_fno_co_sl_prc_range,\
				pAddProfileReq->fRpm_cds_co_sl_prc_range,pAddProfileReq->fRpm_com_co_sl_prc_range,pAddProfileReq->fRpm_eq_co_sl_min_trg_prc,\
				pAddProfileReq->fRpm_fno_co_sl_min_trg_prc,pAddProfileReq->fRpm_cds_co_sl_min_trg_prc,pAddProfileReq->fRpm_com_co_sl_min_trg_prc,\
				pAddProfileReq->fRpm_eq_bo_factor,pAddProfileReq->fRpm_fno_bo_factor,pAddProfileReq->fRpm_cds_bo_factor,\
				pAddProfileReq->fRpm_com_bo_factor,pAddProfileReq->fRpm_eq_bo_sl_prc_range,pAddProfileReq->fRpm_fno_bo_sl_prc_range,\
				pAddProfileReq->fRpm_cds_bo_sl_prc_range,pAddProfileReq->fRpm_com_bo_sl_prc_range,pAddProfileReq->fRpm_eq_bo_sl_min_trg_prc,\
				pAddProfileReq->fRpm_fno_bo_sl_min_trg_prc,pAddProfileReq->fRpm_cds_bo_sl_min_trg_prc,pAddProfileReq->fRpm_com_bo_sl_min_trg_prc,\
				pAddProfileReq->fRpm_eq_sqoff_prc_range,pAddProfileReq->fRpm_fno_sqoff_prc_range,pAddProfileReq->fRpm_cds_sqoff_prc_range,\
				pAddProfileReq->fRpm_com_sqoff_prc_range,pAddProfileReq->fRpm_min_trail_gap,pAddProfileReq->iRpm_gross_buy_qty,\
				pAddProfileReq->iRpm_gross_sell_qty,pAddProfileReq->fRpm_gross_buy_value,pAddProfileReq->fRpm_gross_sell_value,\
				pAddProfileReq->iRpm_net_qty,pAddProfileReq->iRpm_net_lot,pAddProfileReq->fRpm_net_buy_value,pAddProfileReq->fRpm_net_sell_value,\
				pAddProfileReq->fRpm_turnover,pAddProfileReq->iRpm_min_ord_qty,pAddProfileReq->fRpm_min_ord_value,\
				pAddProfileReq->fRpm_pending_buy_ord_value,pAddProfileReq->fRpm_pending_sell_ord_value,pAddProfileReq->fRpm_pending_ord_val,\
				pAddProfileReq->cRpm_duplicate_ord_flg,pAddProfileReq->fRpm_top_up_margin,pAddProfileReq->fRpm_buy_option_multiply,\
				pAddProfileReq->fRpm_mtm_alert_perc,pAddProfileReq->fRpm_mtm_sq_off_perc,pAddProfileReq->sRpm_co_basket,\
				pAddProfileReq->sRpm_bo_basket);

		logDebug2("sAddProfileQry = %s",sAddEditProfileQry);

	}
	else if(pAddProfileReq->ReqHeader.iMsgCode == TC_INT_ADMIN_EDIT_PROFILE_MASTER_REQ)
	{
		sprintf(sAddEditProfileQry," UPDATE RMS_RISK_PROFILE_MAST SET RPM_NAME = \"%s\", RPM_VALIDATE = \'%c\', RPM_MRGN_METHOD_EQ = \"%s\",\
				RPM_MRGN_METHOD_FO = \"%s\", RPM_GEN_MULT = %d, RPM_EQ_MAR_TYPE = \'%c\', RPM_DR_MAR_TYPE = \'%c\', RPM_CD_MAR_TYPE = \'%c\',\
				RPM_COM_MAR_TYPE = \'%c\', RPM_EQ_MARGIN = %d, RPM_DR_MARGIN = %d, RPM_CD_MARGIN = %d, RPM_COM_MARGIN = %d,\
				RPM_EQ_FACTOR = %d, RPM_DR_FACTOR = %d, RPM_CD_FACTOR = %d, RPM_COM_FACTOR = %d, RPM_EQ_BASKET = \"%s\",\
				RPM_DR_BASKET = \"%s\", RPM_MAX_ORD_QTY = %d, RPM_MAX_LOT = %d, RPM_MAX_ORD_VALUE = %d, RPM_MTM_LOSSPER = %d,\
				RPM_CNC_SELL_BEN_PER = %d, RPM_EXPO_MAR = \'%c\', RPM_COLLATERAL_FLG = \'%c\', RPM_REALIZE_PROFIT = \'%c\', RPM_COLL_FO = \'%c\',\
				MRGFACTEQ = %lf, MRGFACTDR = %lf, MRGFACTCOM = %lf, INTFACTEQ = %lf, INTFACTDR = %lf, INTFACTCOM = %lf, RPM_ACTIVE = \'%c\',\
				RPM_FUNDLIMITTYPE = \'%c\', RPM_MTOMSQOFFPER = %d, INTFACTCD = %lf, MRGFACTCD = %lf, RPM_OPT_MKT_ORDER_FLAG = \'%c\',\
				RPM_PRODUCT_ENABLED = \"%s\", RPM_SCRIP_BLOCK_BASKET = \"%s\", RPM_EQ_CO_FACTOR = %lf, RPM_FNO_CO_FACTOR = %lf,\
				RPM_CDS_CO_FACTOR = %lf, RPM_COM_CO_FACTOR = %lf, RPM_EQ_CO_SL_PRC_RANGE = %lf, RPM_FNO_CO_SL_PRC_RANGE = %lf,\
				RPM_CDS_CO_SL_PRC_RANGE = %lf, RPM_COM_CO_SL_PRC_RANGE = %lf, RPM_EQ_CO_SL_MIN_TRG_PRC = %lf, RPM_FNO_CO_SL_MIN_TRG_PRC = %lf,\
				RPM_CDS_CO_SL_MIN_TRG_PRC = %lf, RPM_COM_CO_SL_MIN_TRG_PRC = %lf, RPM_EQ_BO_FACTOR = %lf, RPM_FNO_BO_FACTOR = %lf,\
				RPM_CDS_BO_FACTOR = %lf, RPM_COM_BO_FACTOR = %lf, RPM_EQ_BO_SL_PRC_RANGE = %lf, RPM_FNO_BO_SL_PRC_RANGE = %lf,\
				RPM_CDS_BO_SL_PRC_RANGE = %lf, RPM_COM_BO_SL_PRC_RANGE = %lf, RPM_EQ_BO_SL_MIN_TRG_PRC = %lf, RPM_FNO_BO_SL_MIN_TRG_PRC = %lf,\
				RPM_CDS_BO_SL_MIN_TRG_PRC = %lf, RPM_COM_BO_SL_MIN_TRG_PRC = %lf, RPM_EQ_SQOFF_PRC_RANGE = %lf, RPM_FNO_SQOFF_PRC_RANGE = %lf,\
				RPM_CDS_SQOFF_PRC_RANGE = %lf, RPM_COM_SQOFF_PRC_RANGE = %lf, RPM_MIN_TRAIL_GAP = %lf, RPM_GROSS_BUY_QTY = %d,\
				RPM_GROSS_SELL_QTY = %d, RPM_GROSS_BUY_VALUE = %lf, RPM_GROSS_SELL_VALUE = %lf, RPM_NET_QTY = %d, RPM_NET_LOT = %d,\
				RPM_NET_BUY_VALUE = %lf, RPM_NET_SELL_VALUE = %lf, RPM_TURNOVER = %lf, RPM_MIN_ORD_QTY = %d, RPM_MIN_ORD_VALUE = %lf,\
				RPM_PENDING_BUY_ORD_VALUE = %lf, RPM_PENDING_SELL_ORD_VALUE = %lf, RPM_PENDING_ORD_VAL = %lf, RPM_DUPLICATE_ORD_FLG = \'%c\',\
				RPM_TOP_UP_MARGIN = %lf, RPM_BUY_OPTION_MULTIPLY = %lf, RPM_MTM_ALERT_PERC = %lf, RPM_MTM_SQ_OFF_PERC = %lf,\
				RPM_CO_BASKET = \"%s\", RPM_BO_BASKET = \"%s\" WHERE RPM_CODE = \"%s\" ",pAddProfileReq->sRpmName,pAddProfileReq->cRpmValidate, \
				pAddProfileReq->sRpmMrgnMethodEq,pAddProfileReq->sRpmMrgnMethodFo,pAddProfileReq->iRpmGenMult,pAddProfileReq->cRpmEqMarType,\
				pAddProfileReq->cRpmDrMarType,pAddProfileReq->cRpmCdMarType,pAddProfileReq->cRpmComMarType,pAddProfileReq->iRpmEqMargin,\
				pAddProfileReq->iRpmDrMargin,pAddProfileReq->iRpmCdMargin,pAddProfileReq->iRpm_Com_Margin,pAddProfileReq->iRpm_Eq_Factor,\
				pAddProfileReq->iRpm_Dr_Factor,pAddProfileReq->iRpm_Cd_Factor,pAddProfileReq->iRpm_Com_Factor,pAddProfileReq->sRpm_Eq_Basket,\
				pAddProfileReq->sRpm_Dr_Basket,pAddProfileReq->iRpm_Max_Ord_Qty,pAddProfileReq->iRpm_max_lot,pAddProfileReq->iRpm_max_ord_value,\
				pAddProfileReq->iRpm_mtm_lossper,pAddProfileReq->iRpm_cnc_sell_ben_per,pAddProfileReq->cRpm_expo_mar,\
				pAddProfileReq->cRpm_collateral_flg,pAddProfileReq->cRpm_realize_profit,pAddProfileReq->cRpm_coll_fo,pAddProfileReq->fMrgfacteq,\
				pAddProfileReq->fMrgfactdr,pAddProfileReq->fMrgfactcom,pAddProfileReq->fIntfacteq,pAddProfileReq->fIntfactdr,\
				pAddProfileReq->fIntfactcom,pAddProfileReq->cRpm_active,\
				pAddProfileReq->cRpm_fundlimittype,pAddProfileReq->iRpm_mtomsqoffper,pAddProfileReq->fIntfactcd,pAddProfileReq->fMrgfactcd,\
				pAddProfileReq->cRpm_opt_mkt_order_flag,pAddProfileReq->sRpm_product_enabled,pAddProfileReq->sRpm_scrip_block_basket,\
				pAddProfileReq->fRpm_eq_co_factor,pAddProfileReq->fRpm_fno_co_factor,pAddProfileReq->fRpm_cds_co_factor,\
				pAddProfileReq->fRpm_com_co_factor,pAddProfileReq->fRpm_eq_co_sl_prc_range,pAddProfileReq->fRpm_fno_co_sl_prc_range,\
				pAddProfileReq->fRpm_cds_co_sl_prc_range,pAddProfileReq->fRpm_com_co_sl_prc_range,pAddProfileReq->fRpm_eq_co_sl_min_trg_prc,\
				pAddProfileReq->fRpm_fno_co_sl_min_trg_prc,pAddProfileReq->fRpm_cds_co_sl_min_trg_prc,pAddProfileReq->fRpm_com_co_sl_min_trg_prc,\
				pAddProfileReq->fRpm_eq_bo_factor,pAddProfileReq->fRpm_fno_bo_factor,pAddProfileReq->fRpm_cds_bo_factor,\
				pAddProfileReq->fRpm_com_bo_factor,pAddProfileReq->fRpm_eq_bo_sl_prc_range,pAddProfileReq->fRpm_fno_bo_sl_prc_range,\
				pAddProfileReq->fRpm_cds_bo_sl_prc_range,pAddProfileReq->fRpm_com_bo_sl_prc_range,pAddProfileReq->fRpm_eq_bo_sl_min_trg_prc,\
				pAddProfileReq->fRpm_fno_bo_sl_min_trg_prc,pAddProfileReq->fRpm_cds_bo_sl_min_trg_prc,pAddProfileReq->fRpm_com_bo_sl_min_trg_prc,\
				pAddProfileReq->fRpm_eq_sqoff_prc_range,pAddProfileReq->fRpm_fno_sqoff_prc_range,pAddProfileReq->fRpm_cds_sqoff_prc_range,\
				pAddProfileReq->fRpm_com_sqoff_prc_range,pAddProfileReq->fRpm_min_trail_gap,pAddProfileReq->iRpm_gross_buy_qty,\
				pAddProfileReq->iRpm_gross_sell_qty,pAddProfileReq->fRpm_gross_buy_value,pAddProfileReq->fRpm_gross_sell_value,\
				pAddProfileReq->iRpm_net_qty,pAddProfileReq->iRpm_net_lot,pAddProfileReq->fRpm_net_buy_value,pAddProfileReq->fRpm_net_sell_value,\
				pAddProfileReq->fRpm_turnover,pAddProfileReq->iRpm_min_ord_qty,pAddProfileReq->fRpm_min_ord_value,\
				pAddProfileReq->fRpm_pending_buy_ord_value,pAddProfileReq->fRpm_pending_sell_ord_value,pAddProfileReq->fRpm_pending_ord_val,\
				pAddProfileReq->cRpm_duplicate_ord_flg,pAddProfileReq->fRpm_top_up_margin,pAddProfileReq->fRpm_buy_option_multiply,\
				pAddProfileReq->fRpm_mtm_alert_perc,pAddProfileReq->fRpm_mtm_sq_off_perc,pAddProfileReq->sRpm_co_basket,\
				pAddProfileReq->sRpm_bo_basket,pAddProfileReq->sRpmCode );

		logDebug2("sEditProfileQry = %s",sAddEditProfileQry);

	}

	if(mysql_query(DBQury,sAddEditProfileQry) != SUCCESS)
	{
		logSqlFatal("Error in sAddEditProfileQry.");
		sql_Error(DBQury);
		pAddEditProfileResp.IntRespHeader.iErrorId = 1;
		pAddEditProfileResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_EDIT_PROFILE_MASTER_ERR_PESP;
		logDebug2("Msg Code = %d",pAddEditProfileResp.IntRespHeader.iMsgCode);
		strcpy(pAddEditProfileResp.sErrorMsg,"Profile can not be Added/Updated.");
		logDebug2("pAddEditProfileResp.sErrorMsg = %s",pAddEditProfileResp.sErrorMsg);
	}
	else
	{
		pAddEditProfileResp.IntRespHeader.iErrorId = 0;
		pAddEditProfileResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_EDIT_PROFILE_MASTER_PESP;
		logDebug2("Msg Code = %d",pAddEditProfileResp.IntRespHeader.iMsgCode);
		strcpy(pAddEditProfileResp.sErrorMsg,"Profile Added/Updated Successfully.");
		logDebug2("pAddEditProfileResp.sErrorMsg = %s",pAddEditProfileResp.sErrorMsg);
	}

	logDebug2("pAddProfileReq->ReqHeader.iUserId %d",pAddProfileReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pAddProfileReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	pAddEditProfileResp.IntRespHeader.iSeqNo = 0;
	pAddEditProfileResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
	pAddEditProfileResp.IntRespHeader.iUserId = pAddProfileReq->ReqHeader.iUserId;
	pAddEditProfileResp.IntRespHeader.cSource = pAddProfileReq->ReqHeader.cSource;
	pAddEditProfileResp.cMsgType = 'H';
	pAddEditProfileResp.iNoofRec = 1;

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pAddEditProfileResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		exit(ERROR);
	}

	logTimestamp("Exit : fAddEditProfileMaster");
}



BOOL    fAddClientLimit(CHAR *RcvMsg)
{
	logTimestamp("Entry : fAddClientLimit ");

	struct  ADD_CLIENT_LIMIT_REQ            *pAddClLimtReq;
	struct  ADMIN_VIEW_COMMON_HDR_RESP      pAddCliLmtResp;

	pAddClLimtReq = (struct  ADD_CLIENT_LIMIT_REQ *)RcvMsg;

	CHAR    sCheckClient[QUERY_SIZE];
	CHAR    sAddCliQry[MAX_QUERY_SIZE];
	CHAR    sQry[QUERY_SIZE];
	LONG32  iNoOfRec=0;
	CHAR    cEntityType;

	logDebug2("pAddClLimtReq->sEntityId = %s",pAddClLimtReq->sEntityId);
	logDebug2("pAddClLimtReq->sClientId = %s",pAddClLimtReq->sClientId);
	logDebug2("pAddClLimtReq->sLimitType = %s",pAddClLimtReq->sLimitType);

	memset(sCheckClient,'\0',QUERY_SIZE);
	memset(sAddCliQry,'\0',QUERY_SIZE);
	memset(sQry,'\0',QUERY_SIZE);

	sprintf(sCheckClient,"SELECT ENTITY_TYPE FROM ENTITY_MASTER  WHERE ENTITY_CODE = \"%s\" ",pAddClLimtReq->sClientId);
	logDebug2("sCheckClient = %s",sCheckClient);

	if(mysql_query(DBQury,sCheckClient) != SUCCESS)
	{
		logSqlFatal("Error in sCheckClient Query.");
		sql_Error(DBQury);
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	logDebug2("iNoOfRec = %d",iNoOfRec);

	if(Row = mysql_fetch_row(Res))
	{
		cEntityType = Row[0][0];
		logDebug2("cEntityType = %c",cEntityType);
	}

	logDebug2("pAddClLimtReq->ReqHeader.iUserId %d",pAddClLimtReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pAddClLimtReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	pAddCliLmtResp.IntRespHeader.iSeqNo = 0;
	pAddCliLmtResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
	pAddCliLmtResp.IntRespHeader.iUserId = pAddClLimtReq->ReqHeader.iUserId;
	pAddCliLmtResp.IntRespHeader.cSource = pAddClLimtReq->ReqHeader.cSource;
	pAddCliLmtResp.cMsgType = 'H';
	pAddCliLmtResp.iNoofRec = 1;

	if(iNoOfRec > 0 && cEntityType != DEALER_TYPE)
	{
		if(pAddClLimtReq->sLimitType == CAPITAL_TYPE)
		{
			sprintf(sAddCliQry,"INSERT INTO RMS_FUND_LIMIT (CLIENT_ID, C_CASH_BALANCE, C_BANK_HOLD, C_LIQUID_BALANCE,C_ADHOC_LIMIT,\
				NC_NSE_RECEIVABLES, NC_BSE_RECEIVABLES, NC_COLLATERALS,NC_OTHER_COLLATERALS, NC_REALISED_PROFIT, NC_EQ_UNREALISED_PROFITS,\
				NC_DRV_UNREALISED_PROFITS,TOTAL_CASH, TOTAL_CASH_UTILIZED, WITHDRAWAL_CASH, TOTAL_NON_CASH, TOTAL_NON_CASH_UTILIZED,\
				TOTAL_NON_CASH_AVAILABLE, TOTAL_LIMIT, TOTAL_UTILIZED, TOTAL_BALANCE, EXCH_ID, PRODUCT_CODE,SEGMENT, OPT_SELL_PREMIUM,\
				EXPOSURE_LIMIT, BUY_EXPOSURE_LIMIT, SELL_EXPOSURE_LIMIT, TURNOVER_LIMIT,LOSS_LIMIT, DEL_LIMIT, FINANCE_LIMIT,\
				SECURITY_QTY_LIMIT, CATEGORY, GROUP_VAL_INDICATOR,GROSS_EXPOSURE_FNO_LIMIT, ENTITY_MARGIN, CF_OPT_SELL_PREMIUM, CLEAR_BALANCE)\
					VALUES (\"%s\",'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','A',\                                                                    '0','A','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');",pAddClLimtReq->sClientId);
		}
		else if(pAddClLimtReq->sLimitType == COMMODITY_TYPE)
		{
			sprintf(sAddCliQry,"INSERT INTO RMS_FUND_LIMIT_COM (RMLC_CLIENT_ID, RMLC_C_CASH_BALANCE, RMLC_C_BANK_HOLD, RMLC_C_ADHOC_LIMIT,\
				RMLC_NC_REALISED_PROFIT, RMLC_TOTAL_CASH_UTILIZED, RMLC_WITHDRAWAL_CASH, RMLC_EXCHANGE,RMLC_PRODUCT_CODE,RMLC_SEGMENT,\
				CF_OPT_SELL_PREMIUM) VALUES (\"%s\",'0','0','0','0','0','0','A','0','A','0');",pAddClLimtReq->sClientId);
		}
		else if(pAddClLimtReq->sLimitType == ALL_TYPE)
		{
			sprintf(sAddCliQry,"INSERT INTO RMS_FUND_LIMIT (CLIENT_ID, C_CASH_BALANCE, C_BANK_HOLD, C_LIQUID_BALANCE, C_ADHOC_LIMIT,\
				NC_NSE_RECEIVABLES, NC_BSE_RECEIVABLES, NC_COLLATERALS, NC_OTHER_COLLATERALS,NC_REALISED_PROFIT, NC_EQ_UNREALISED_PROFITS,\
				NC_DRV_UNREALISED_PROFITS, TOTAL_CASH,TOTAL_CASH_UTILIZED, WITHDRAWAL_CASH, TOTAL_NON_CASH, TOTAL_NON_CASH_UTILIZED,\
				TOTAL_NON_CASH_AVAILABLE, TOTAL_LIMIT, TOTAL_UTILIZED, TOTAL_BALANCE, EXCH_ID,PRODUCT_CODE, SEGMENT, OPT_SELL_PREMIUM,\
				EXPOSURE_LIMIT, BUY_EXPOSURE_LIMIT, SELL_EXPOSURE_LIMIT,TURNOVER_LIMIT, LOSS_LIMIT, DEL_LIMIT, FINANCE_LIMIT, SECURITY_QTY_LIMIT,\
				CATEGORY, GROUP_VAL_INDICATOR, GROSS_EXPOSURE_FNO_LIMIT, ENTITY_MARGIN, CF_OPT_SELL_PREMIUM, CLEAR_BALANCE)\
					VALUES (\"%s\",'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',\
						'0','0','0','A','0','A','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');\
					INSERT INTO RMS_FUND_LIMIT_COM(RMLC_CLIENT_ID, RMLC_C_CASH_BALANCE, RMLC_C_BANK_HOLD, RMLC_C_ADHOC_LIMIT,RMLC_NC_REALISED_PROFIT,\
						RMLC_TOTAL_CASH_UTILIZED, RMLC_WITHDRAWAL_CASH, RMLC_EXCHANGE, RMLC_PRODUCT_CODE,RMLC_SEGMENT,CF_OPT_SELL_PREMIUM) \
					VALUES (\"%s\",'0','0','0','0','0','0','A','0','A','0');",pAddClLimtReq->sClientId,pAddClLimtReq->sClientId);
		}
		logDebug2("sAddCliQry = %s",sAddCliQry);

		if(cEntityType != SUPER_ADMIN)
		{
			memset(sQry,'\0',QUERY_SIZE);
			sprintf(sQry,"select count(*) as count from ENTITY_MASTER where ENTITY_CODE = \"%s\" and ENTITY_MANAGER_CODE = %d",\
					pAddClLimtReq->sClientId,pAddClLimtReq->ReqHeader.iUserId);
			logDebug2("sQry = %s",sQry);
		}
		if(mysql_query(DBQury,sQry) != SUCCESS)
		{
			logSqlFatal("Error in sQry.");
			sql_Error(DBQury);
		}
		Res = mysql_store_result(DBQury);
		iNoOfRec = mysql_num_rows(Res);
		logDebug2("iNoOfRec..... = %d",iNoOfRec);

		if(iNoOfRec > 0)
		{
			if(mysql_query(DBQury,sAddCliQry) != SUCCESS)
			{
				logSqlFatal("Error in sAddCliQry.");
				sql_Error(DBQury);
			}

			pAddCliLmtResp.IntRespHeader.iErrorId = 0;
			pAddCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_CLIENT_LIMIT_SCC_RESP;
			logDebug2("Msg Code = %d",pAddCliLmtResp.IntRespHeader.iMsgCode);
			strcpy(pAddCliLmtResp.sErrorMsg,"User inserted Successfully");
			logDebug2("pAddCliLmtResp.sErrorMsg = %s",pAddCliLmtResp.sErrorMsg);

		}
		else
		{
			pAddCliLmtResp.IntRespHeader.iErrorId = 1;
			pAddCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_CLIENT_LIMIT_ERR_RESP;
			logDebug2("Msg Code = %d",pAddCliLmtResp.IntRespHeader.iMsgCode);
			strcpy(pAddCliLmtResp.sErrorMsg,"You Are Not Authorised.");
			logDebug2("pAddCliLmtResp.sErrorMsg = %s",pAddCliLmtResp.sErrorMsg);
		}

	}
	else
	{
		pAddCliLmtResp.IntRespHeader.iErrorId = 1;
		pAddCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_CLIENT_LIMIT_ERR_RESP;
		logDebug2("MSG CODE = %d",pAddCliLmtResp.IntRespHeader.iMsgCode);

		if(cEntityType == DEALER_TYPE)
		{
			strcpy(pAddCliLmtResp.sErrorMsg,"Can not Add Limit For Dealer.");
			logDebug2("pAddCliLmtResp.sErrorMsg = %s",pAddCliLmtResp.sErrorMsg);
		}
		else
		{
			strcpy(pAddCliLmtResp.sErrorMsg,"USER DOES NOT EXIST.");
			logDebug2("pAddCliLmtResp.sErrorMsg = %s",pAddCliLmtResp.sErrorMsg);
		}
	}

	logDebug2("MSG CODE.. = %d",pAddCliLmtResp.IntRespHeader.iMsgCode);

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pAddCliLmtResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		exit(ERROR);
	}

	logTimestamp("Exit : fAddClientLimit");
}


BOOL fUpdateBatch(CHAR *RcvMsg)
{
	logTimestamp("Entry :fUpdateBatch");
	struct VIEW_ADMIN_BATCH_PROCESS_REQ        	*pBatchReq;
	struct VIEW_ADMIN_BATCH_PROCESS_RESP		pBatchResp;
	struct VIEW_COMMON_HDR_RESP             	pHdrResp;

	CHAR    sUpdtQry[QUERY_SIZE];

	CHAR    sBatchQry [QUERY_SIZE];
	CHAR 	sScheduleDate[DB_DATETIME_LEN]       ;
	CHAR  	sWhere_Clause[QUERY_SIZE];
	CHAR 	sSltQuery[QUERY_SIZE];
	memset(sSltQuery,'\0',QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sBatchQry,'\0',QUERY_SIZE);
	memset(sScheduleDate,'\0',DB_DATETIME_LEN);
	SHORT	iMsgCode = 0;
	CHAR	sRemarks[DB_REMARKS_LEN];	
	LONG32	iNoOfRow = 0;
	INT16	iResult = 0;
	CHAR	sBpDate[DB_DATETIME_LEN];
	CHAR	sNextScheduleDate[DB_DATETIME_LEN];
	CHAR	cBPMode;
	memset(sRemarks,'\0',DB_REMARKS_LEN);	
	memset(sBpDate,'\0',DB_DATETIME_LEN);
	memset(sNextScheduleDate,'\0',DB_DATETIME_LEN);
	pBatchReq = (struct VIEW_ADMIN_BATCH_PROCESS_REQ *)RcvMsg;

	logDebug2("pBatchReq->sBatch_name       :%s:",pBatchReq->sBatch_name);
	logDebug2("pBatchReq->sScheduleTime     :%s:",pBatchReq->sScheduleTime);
	logDebug2("pBatchReq->sNextScheduleDate :%s:",pBatchReq->sNextScheduleDate);
	logDebug2("pBatchReq->sBpDate           :%s:",pBatchReq->sBpDate);
	logDebug2("pBatchReq->sOffMktStatus     :%c:",pBatchReq->cOffMktStatus);
	logDebug2("pBatchReq->cBPMode           :%c:",pBatchReq->cBPMode);
	logDebug2("pBatchReq->sUpdatedBy        :%s:",pBatchReq->sUpdatedBy);
	logDebug2("pBatchReq->sIPAddress	:%s:",pBatchReq->sIPAddress);

	/**	if(mysql_set_server_option(DBQury,CLIENT_MULTI_STATEMENTS) == 0)
	  {
	  logDebug2(" mysql_set_server_option SUCCESS");
	  }
	  else
	  {
	  logDebug2(" mysql_set_server_option FAILED");
	  return FALSE;
	  }
	 **/
/*	 sprintf(sSltQuery,"select BP_DATE,BP_NEXT_SCHEDULE_DATE,BP_MODE from BATCH_PROCESS WHERE BP_BATCH_NAME=\"%s\" and BP_EXCH_ID=\"%s\" AND \
			BP_SEGMENT=\'%c\'AND CONCAT(DATE(bp_date), ' ', DATE_FORMAT(bp_schedule_time, '%%H:%%i:%%s')) <= NOW();", pBatchReq->sBatch_name,\
			pBatchReq->ReqHeader.sExcgId,pBatchReq->ReqHeader.cSegment);
	
	
	logDebug2("sSltQuery :%s:",sSltQuery);
	 	if(mysql_query(DBQury,sSltQuery) != SUCCESS)
                {
                        logSqlFatal("###### SQL Failed for Select in Batch Process  ######");
                        sql_Error(DBQury);
                        return FALSE;
                }
		Res = mysql_store_result(DBQury);
		iNoOfRow = mysql_num_rows(Res);
		logDebug2("NO OF ROW :%d:",iNoOfRow);
        	if(iNoOfRow == 0)
        	{
                	mysql_free_result(Res);
                	//free(sSltQuery);
                	logInfo("NO RECORD FOUND");
			sprintf(sRemarks,"E0D_BOD ALREADY DONE");
                        logDebug2("Remarks = %s",sRemarks);
	//		return FALSE;
        	}
        	else
		{
			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(sBpDate,Row[0],DB_DATETIME_LEN);
				strncpy(sNextScheduleDate,Row[1],DB_DATETIME_LEN);
				cBPMode = Row[2][0];

			}

		}
	logDebug2("sBpDate :%s:",sBpDate);
	logDebug2("sNextScheduleDate:%s:",sNextScheduleDate);
	logDebug2("cBPMode:%c:",cBPMode); */


	if(strcmp(pBatchReq->sBatch_name ,SELECT_ALL))
	{
		memset(sBatchQry,'\0',QUERY_SIZE);
		sprintf(sBatchQry,"AND BP_BATCH_NAME = \"%s\"",pBatchReq->sBatch_name);
		logDebug2("sBatchQry= %s",sBatchQry);
		strcat(sWhere_Clause,sBatchQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pBatchReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sBatchQry,'\0',QUERY_SIZE);
		sprintf(sBatchQry," AND BP_SEGMENT = \'%c\' ",pBatchReq->ReqHeader.cSegment);	
		logDebug2("sBatchQry= %s",sBatchQry);
		strcat(sWhere_Clause,sBatchQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pBatchReq->ReqHeader.sExcgId ,SELECT_ALL))
	{
		memset(sBatchQry,'\0',QUERY_SIZE);
		sprintf(sBatchQry," AND BP_EXCH_ID = \"%s\"",pBatchReq->ReqHeader.sExcgId);
		logDebug2("sBatchQry= %s",sBatchQry);
		strcat(sWhere_Clause,sBatchQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}

	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	if( pBatchReq->ReqHeader.iMsgCode == TC_INT_RUN_BATCH_PROCESS_REQ )
	{
	/**	sprintf(sUpdtQry, "CALL PR_EOD_BOD(STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),\"%s\",\'%c\',\"%s\",\'%c\',STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),@ZSTATUS );\
					 SELECT  @ZSTATUS ;",\
			sNextScheduleDate,pBatchReq->sBatch_name,pBatchReq->ReqHeader.cSegment,pBatchReq->ReqHeader.sExcgId,pBatchReq->cBPMode,sBpDate);
	**/
         sprintf(sSltQuery,"select BP_DATE,BP_NEXT_SCHEDULE_DATE,BP_MODE from BATCH_PROCESS WHERE BP_BATCH_NAME=\"%s\" and BP_EXCH_ID=\"%s\" AND \
                        BP_SEGMENT=\'%c\'AND CONCAT(DATE(bp_date), ' ', DATE_FORMAT(bp_schedule_time, '%%H:%%i:%%s')) <= NOW();", pBatchReq->sBatch_name,\
                        pBatchReq->ReqHeader.sExcgId,pBatchReq->ReqHeader.cSegment);


        logDebug2("sSltQuery :%s:",sSltQuery);
                if(mysql_query(DBQury,sSltQuery) != SUCCESS)
                {
                        logSqlFatal("###### SQL Failed for Select in Batch Process  ######");
                        sql_Error(DBQury);
                        return FALSE;
                }
                Res = mysql_store_result(DBQury);
                iNoOfRow = mysql_num_rows(Res);
                logDebug2("NO OF ROW :%d:",iNoOfRow);
                if(iNoOfRow == 0)
                {
                        mysql_free_result(Res);
                        //free(sSltQuery);
                        logInfo("NO RECORD FOUND");
			iMsgCode = TC_INT_RUN_BATCH_PROCESS_RESP;
                        logDebug2("MsgCode = %d",iMsgCode);
                        sprintf(sRemarks,"E0D_BOD ALREADY DONE");
                        logDebug2("Remarks = %s",sRemarks);
        //              return FALSE;
                }
                else
                {
                        if((Row = mysql_fetch_row(Res)))
                        {
                                strncpy(sBpDate,Row[0],DB_DATETIME_LEN);
                                strncpy(sNextScheduleDate,Row[1],DB_DATETIME_LEN);
                                cBPMode = Row[2][0];

                        }

        		logDebug2("sBpDate :%s:",sBpDate);
        		logDebug2("sNextScheduleDate:%s:",sNextScheduleDate);
        		logDebug2("cBPMode:%c:",cBPMode);
                
	
			memset(sUpdtQry,'\0',QUERY_SIZE);
			sprintf(sUpdtQry, "CALL PR_EOD_BOD(STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\"%s\",\'%c\',\"%s\",\'%c\',\ 
				STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),@ZSTATUS ); SELECT  @ZSTATUS ;",\
                        	sNextScheduleDate,pBatchReq->sBatch_name,pBatchReq->ReqHeader.cSegment,pBatchReq->ReqHeader.sExcgId,pBatchReq->cBPMode,sBpDate);
	//              sprintf(sScheduleDate,"select STR_TO_DATE(\"%s\",'%%d/%%m/%%Y %%T')",pBatchReq->sNextScheduleDate);
		//              logDebug2("sScheduleDate = %s",sScheduleDate);

		//              sprintf(sUpdtQry, "call  PR_EOD_BOD(\"%s\",\"%s\",\'%c\',\"%s\",\'%c\',@ZSTATUS); SELECT @ZSTATUS;",\
		sScheduleDate,pBatchReq->sBatch_name,pBatchReq->ReqHeader.cSegment,pBatchReq->ReqHeader.sExcgId,pBatchReq->cBPMode);

			logDebug2("Run EOD_BOD = %s",sUpdtQry);

			if(mysql_query(DBQury,sUpdtQry) != SUCCESS)
			{
				logSqlFatal("###### SQL Failed for Run Batch Process  ######");
				sql_Error(DBQury);
				return FALSE;
			}
			do
			{
				logDebug2("###########");
				Res = mysql_store_result(DBQury);
				logDebug2("********");
				if(Res)
				{
					logDebug2("^^^^^^");
					if(Row = mysql_fetch_row(Res));
					{
						strncpy(sRemarks,Row[0],DB_REMARKS_LEN);
						logDebug2("sRemarks = %s",sRemarks);
						if(!strcmp(sRemarks,PRO_SUCCESS))
						{
							sprintf(sRemarks,"SUCCESSFULLY DONE E0D_BOD");
							logDebug2("Remarks = %s",sRemarks);
						}
						else
						{
							logDebug2("sRemarks = %s",sRemarks);
						}
					}
					iMsgCode = TC_INT_RUN_BATCH_PROCESS_RESP;
					logDebug2("MsgCode = %d",iMsgCode);
				}
				else
				{
					logDebug2("No Result");
				}
				if((iResult = mysql_next_result(DBQury)) > 0)
				{
					logDebug3("Could not execute statement :%d:",iResult);
				}

			//                	iMsgCode = TC_INT_RUN_BATCH_PROCESS_RESP;
			//                	logDebug2("MsgCode = %d",iMsgCode);
			}while(iResult == 0);
		}
	}
	if(pBatchReq->ReqHeader.iMsgCode == TC_INT_UPDATE_BATCH_PROCESS_REQ )
	{

		memset(sUpdtQry,'\0',QUERY_SIZE);
		sprintf(sUpdtQry,"	UPDATE   BATCH_PROCESS SET BP_SCHEDULE_TIME = CONCAT(CURDATE(),\" %s\" ), BP_MODE = \'%c\', BP_OFF_MKT_STATUS = \'%c\' , \
				BP_UPDATED_BY_IP = \"%s\" ,BP_UPDATED_BY = \"%s\" ,BP_NEXT_SCHEDULE_DATE=\"%s\" ,BP_DATE=\"%s\" WHERE 1=1 AND BP_MKT_TYPE_NO = %d %s  ",\
				pBatchReq->sScheduleTime,pBatchReq->cBPMode,pBatchReq->cOffMktStatus,pBatchReq->sIPAddress,pBatchReq->sUpdatedBy,pBatchReq->sNextScheduleDate,pBatchReq->sNextScheduleDate,\
				pBatchReq->iMktType,sWhere_Clause);

		logDebug2("sUpdtQry     :%s:",sUpdtQry);

		if(mysql_query(DBQury,sUpdtQry) != SUCCESS)
		{
			logSqlFatal("###### SQL Failed for Updating Batch Process  ######");
			sql_Error(DBQury);
			return FALSE;
		}
		else
		{
			mysql_commit(DBQury);
			logInfo(" Updatee Commit sucessful");
		}

		iMsgCode = TC_INT_UPDATE_BATCH_PROCESS_RESP;
		logDebug2("iMsgCode = %d...",iMsgCode);
		//		strncpy(pBatchResp.sRemarks,"Batch Updated Sucessfully,Please refresh your batch process.",DB_REMARKS_LEN);
		//		logDebug2("sRemarks = %s",pBatchResp.sRemarks);
		strncpy(sRemarks,"Batch Updated Sucessfully,Please refresh your batch process.",DB_REMARKS_LEN);
		logDebug2("sRemarks = %s",sRemarks);
	}
	/**	else if( pBatchReq->ReqHeader.iMsgCode == TC_INT_RUN_BATCH_PROCESS_REQ )
	  {
	  sprintf(sUpdtQry, "CALL PR_EOD_BOD(STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),\"%s\",\'%c\',\"%s\",\'%c\',@ZSTATUS );\
	  SELECT  @ZSTATUS ;",\
	  pBatchReq->sNextScheduleDate,pBatchReq->sBatch_name,pBatchReq->ReqHeader.cSegment,pBatchReq->ReqHeader.sExcgId,pBatchReq->cBPMode);

	//		sprintf(sScheduleDate,"select STR_TO_DATE(\"%s\",'%%d/%%m/%%Y %%T')",pBatchReq->sNextScheduleDate);	
	//		logDebug2("sScheduleDate = %s",sScheduleDate);

	//		sprintf(sUpdtQry, "call  PR_EOD_BOD(\"%s\",\"%s\",\'%c\',\"%s\",\'%c\',@ZSTATUS); SELECT @ZSTATUS;",\
	sScheduleDate,pBatchReq->sBatch_name,pBatchReq->ReqHeader.cSegment,pBatchReq->ReqHeader.sExcgId,pBatchReq->cBPMode);

	logDebug2("Run EOD_BOD = %s",sUpdtQry);

	if(mysql_query(DBQury,sUpdtQry) != SUCCESS)
	{
	logSqlFatal("###### SQL Failed for Run Batch Process  ######");
	sql_Error(DBQury);
	return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRow = mysql_num_rows(Res);
	logDebug2("iNoOfRow = %d",iNoOfRow);		
	logDebug2("$$$$$$$******");
	while((Row = mysql_fetch_row(Res)));	
	{
	logDebug2("$$$$$$$$$$$");
	strncpy(sRemarks,Row[0],DB_REMARKS_LEN);
	logDebug2("Remarks = %s",sRemarks);				
	}
	iMsgCode = TC_INT_RUN_BATCH_PROCESS_RESP;
	logDebug2("MsgCode = %d",iMsgCode);
	}
	 **/
	pHdrResp.IntRespHeader.iSeqNo = 0;
	pHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pHdrResp.IntRespHeader.iErrorId = 0;
	pHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_BATCH_PROCESS_HEADER_RESP;
	pHdrResp.IntRespHeader.iUserId = pBatchReq->ReqHeader.iUserId;
	pHdrResp.IntRespHeader.cSource = pBatchReq->ReqHeader.cSource ;
	pHdrResp.cMsgType = 'H';
	pHdrResp.iNoofRec = 1;
	logDebug2("pHdrResp.IntRespHeader.iUserId = %d",pHdrResp.IntRespHeader.iUserId);
	iRelayID = find_admin_adapter(pHdrResp.IntRespHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		exit(ERROR);
	}

	memset(&pBatchResp,'\0',sizeof(struct VIEW_ADMIN_BATCH_PROCESS_RESP));
	pBatchResp.IntRespHeader.iSeqNo = 0;
	pBatchResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_BATCH_PROCESS_RESP);
	pBatchResp.IntRespHeader.iMsgCode = iMsgCode ;
	logDebug2("pBatchResp.IntRespHeader.iMsgCode = %d",pBatchResp.IntRespHeader.iMsgCode);
	pBatchResp.IntRespHeader.iErrorId = 0;
	pBatchResp.IntRespHeader.iUserId = pBatchReq->ReqHeader.iUserId;
	pBatchResp.IntRespHeader.cSource = pBatchReq->ReqHeader.cSource ;
	strcpy(pBatchResp.sRemarks,sRemarks);
	logDebug2("pBatchResp.sRemarks = %s",pBatchResp.sRemarks);

	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pBatchResp,sizeof(struct VIEW_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
		exit(ERROR);
	}
	logTimestamp("EXIT fUpdateBatch");
	return TRUE ;
}

BOOL    fEditCliLimit(CHAR *RcvMsg)
{
	logTimestamp("Entry : fEditCliLimit");
	struct  EDIT_CLIENT_LIMIT_REQ           *pEditCliLmtReq;
	struct  ADMIN_VIEW_COMMON_HDR_RESP      pEditCliLmtResp;

	pEditCliLmtReq = (struct EDIT_CLIENT_LIMIT_REQ *)RcvMsg;

	CHAR            sChkMaxAdhocLimit[QUERY_SIZE];
	CHAR            sUpdateCliLimt[MAX_QUERY_SIZE];
	DOUBLE64        fAdhocLimit = 0;
	LONG32          iTotalRow;

	memset(sChkMaxAdhocLimit,'\0',QUERY_SIZE);
	memset(sUpdateCliLimt,'\0',MAX_QUERY_SIZE);

	sprintf(sChkMaxAdhocLimit,"select ifnull(trim(s.PARAM_VALUE),0) as VALUE from SYS_PARAMETERS s where Trim(s.PARAM_NAME)= \"%s\";",MAX_ADHOC_VALUE);
	logDebug2("sChkMaxAdhocLimit = %s",sChkMaxAdhocLimit);

	if(mysql_query(DBQury,sChkMaxAdhocLimit) != SUCCESS)
	{
		logSqlFatal("Error in sChkMaxAdhocLimit Query.");
		sql_Error(DBQury);
	}

	Res = mysql_store_result(DBQury);
	if(Row = mysql_fetch_row(Res))
	{
		fAdhocLimit = atof(Row[0]);
		logDebug2("fAdhocLimit = %lf",fAdhocLimit);
	}

	logDebug2("pEditCliLmtReq->sClientId = %s",pEditCliLmtReq->sClientId);
	logDebug2("pEditCliLmtReq->sLimitType = %s",pEditCliLmtReq->sLimitType);
	logDebug2("pEditCliLmtReq->fAmountUtilised = %lf",pEditCliLmtReq->fAmountUtilised);
	logDebug2("pEditCliLmtReq->fAdhocLimit = %lf",pEditCliLmtReq->fAdhocLimit);
	logDebug2("pEditCliLmtReq->fBankHoldings = %lf",pEditCliLmtReq->fBankHoldings);

	/*      if(pEditCliLmtReq->fAmountUtilised > fAdhocLimit )
		{
		logDebug2("Cannot exceed maxium adhoc value i:e = %lf",fAdhocLimit);
		pEditCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EDIT_CLIENT_LIMIT_ERR_RESP;
		return FLASE;
		}
	 */
	logDebug2("pEditCliLmtReq->ReqHeader.iUserId %d",pEditCliLmtReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pEditCliLmtReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	pEditCliLmtResp.IntRespHeader.iSeqNo = 0;
	pEditCliLmtResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
	pEditCliLmtResp.IntRespHeader.iUserId = pEditCliLmtReq->ReqHeader.iUserId;
	pEditCliLmtResp.IntRespHeader.cSource = pEditCliLmtReq->ReqHeader.cSource;
	pEditCliLmtResp.cMsgType = 'H';
	pEditCliLmtResp.iNoofRec = 1;


	if(pEditCliLmtReq->fAmountUtilised < fAdhocLimit )
	{
		if(!strcmp(pEditCliLmtReq->sLimitType,CAPITAL_TYPE))
		{
			sprintf(sUpdateCliLimt,"update RMS_FUND_LIMIT set C_ADHOC_LIMIT = ifnull(C_ADHOC_LIMIT,0) + %lf,\
					C_BANK_HOLD = ifnull(C_BANK_HOLD,0) + %lf,TOTAL_CASH_UTILIZED = ifnull(TOTAL_CASH_UTILIZED,0) + %lf \
					where CLIENT_ID = \"%s\" AND EXCH_ID = \"%s\" ;",pEditCliLmtReq->fAdhocLimit,pEditCliLmtReq->fBankHoldings,\
					pEditCliLmtReq->fAmountUtilised,pEditCliLmtReq->sClientId,pEditCliLmtReq->ReqHeader.sExcgId);
		}
		else if(!strcmp(pEditCliLmtReq->sLimitType,COMMODITY_TYPE))
		{
			sprintf(sUpdateCliLimt,"update RMS_FUND_LIMIT_COM set RMLC_C_ADHOC_LIMIT = ifnull(RMLC_C_ADHOC_LIMIT,0) + %lf,\
					RMLC_C_BANK_HOLD = ifnull(RMLC_C_BANK_HOLD,0) + %lf,\
					RMLC_TOTAL_CASH_UTILIZED = ifnull(RMLC_TOTAL_CASH_UTILIZED,0) + %lf where RMLC_CLIENT_ID = \"%s\" AND \
					RMLC_EXCHANGE = \"%s\" ;",pEditCliLmtReq->fAdhocLimit,pEditCliLmtReq->fBankHoldings,\
					pEditCliLmtReq->fAmountUtilised,pEditCliLmtReq->sClientId,pEditCliLmtReq->ReqHeader.sExcgId);
		}

		if(mysql_query(DBQury,sUpdateCliLimt) != SUCCESS)
		{
			logSqlFatal("Error in sChkMaxAdhocLimit Query.");
			sql_Error(DBQury);
			pEditCliLmtResp.IntRespHeader.iErrorId = 1;
			pEditCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EDIT_CLIENT_LIMIT_ERR_RESP;
			strcpy(pEditCliLmtResp.sErrorMsg,"User limit cannnot update.");
			logDebug2("pEditCliLmtResp.sErrorMsg = %s",pEditCliLmtResp.sErrorMsg);

			if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pEditCliLmtResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
			{
				logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
				exit(ERROR);
			}

			return FALSE;
		}
		pEditCliLmtResp.IntRespHeader.iErrorId = 0;
		pEditCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EDIT_CLIENT_LIMIT_SCC_RESP;
		logDebug2("iMsgCode = %d",pEditCliLmtResp.IntRespHeader.iMsgCode);
		strcpy(pEditCliLmtResp.sErrorMsg,"User limit updated Successfully.");
		logDebug2("pEditCliLmtResp.sErrorMsg = %s",pEditCliLmtResp.sErrorMsg);
	}
	else
	{
		pEditCliLmtResp.IntRespHeader.iErrorId = 1;
		pEditCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EDIT_CLIENT_LIMIT_ERR_RESP;
		logDebug2("MSG CODE = %d",pEditCliLmtResp.IntRespHeader.iMsgCode);
		sprintf(pEditCliLmtResp.sErrorMsg,"Cannot exceed maxium adhoc value i:e = %lf",fAdhocLimit);
		logDebug2("pEditCliLmtResp.sErrorMsg = %s",pEditCliLmtResp.sErrorMsg);

	}

	logDebug2("pEditCliLmtResp.IntRespHeader.iMsgCode = %d",pEditCliLmtResp.IntRespHeader.iMsgCode);
	//      Res = mysql_store_result(DBQury);
	//      iTotalRow = mysql_num_rows(Res);
	//      pEditCliLmtResp.iNoofRec = iTotalRow;

	//      pEditCliLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_EDIT_CLIENT_LIMIT_SCC_RESP;


	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pEditCliLmtResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		exit(ERROR);
	}

	logTimestamp("Exit : fEditCliLimit");
	return  TRUE;
}


BOOL    fAddHoldings(CHAR *RcvMsg)
{
	logTimestamp("Entry : fAddHoldings");
	struct  ADD_HOLDING_REQ        *pAddHoldingReq;
	struct  ADMIN_VIEW_COMMON_HDR_RESP      pAddHoldingResp;

	pAddHoldingReq = (struct ADD_HOLDING_REQ *)RcvMsg;

	CHAR            sWhere_Clause[QUERY_SIZE];
	CHAR            sAddHoldingQry[QUERY_SIZE];
	CHAR            sEntityTypeQry[QUERY_SIZE];
	CHAR            sChkCntQry[QUERY_SIZE];
	CHAR            Entity_Type;
	CHAR            sInsHoldQry[QUERY_SIZE];
	CHAR            sUpdHoldQry[QUERY_SIZE];
	LONG32		iNoOfRec;
	LONG32		iNoOfCnt;

	logDebug2("pAddHoldingReq->sEntityId = %s",pAddHoldingReq->sEntityId);
	logDebug2("pAddHoldingReq->sClientId = %s",pAddHoldingReq->sClientId);

	memset(sAddHoldingQry,'\0',QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset (sEntityTypeQry,'\0',QUERY_SIZE);
	memset (sChkCntQry,'\0',QUERY_SIZE);
	memset (sInsHoldQry,'\0',QUERY_SIZE);
	memset (sUpdHoldQry,'\0',QUERY_SIZE);

	sprintf(sEntityTypeQry, "select ENTITY_TYPE from ENTITY_MASTER where ENTITY_CODE = \"%s\"",pAddHoldingReq->sClientId);

	logDebug2("sEntityTypeQry = %s",sEntityTypeQry);

	if(mysql_query(DBQury,sEntityTypeQry) != SUCCESS)
	{
		logSqlFatal("Error in sChkMaxAdhocLimit Query.");
		sql_Error(DBQury);
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	logDebug2("iNoOfRec = %d",iNoOfRec);

	if(Row = mysql_fetch_row(Res))
	{
		Entity_Type = atoi(Row[0][0]);
		logDebug2("Entity_Type = %c",Entity_Type);
	}
	if(Entity_Type == SUPER_ADMIN)
	{
		sprintf(sWhere_Clause,"");
	}
	else
	{
		sprintf(sWhere_Clause,"AND CLIENT_ID = ENTITY_CODE AND ENTITY_MANAGER_CODE = \"%s\"",pAddHoldingReq->sClientId);
	}

	sprintf(sChkCntQry,"select count(*) CNT from RMS_CLIENT_SECURITY_LIMIT t,ENTITY_MASTER b where t.ISIN_CODE = \"%s\" and t.CLIENT_ID = \"%s\" and t.EXCH_ID = \"%s\" and t.SECURITY_SOURCE_TYPE = \"%s\" %s",pAddHoldingReq->sISINCode,pAddHoldingReq->sClientId,pAddHoldingReq->ReqHeader.sExcgId,pAddHoldingReq->sSecSource,sWhere_Clause);

	if(mysql_query(DBQury,sChkCntQry) != SUCCESS)
	{
		logSqlFatal("Error in sChkCntQry Query.");
		sql_Error(DBQury);
	}

	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	logDebug2("iNoOfRec = %d",iNoOfRec);

	if(Row = mysql_fetch_row(Res))
	{
		iNoOfCnt = atoi(Row[0][0]);
		logDebug2("iNoOfCnt = ",iNoOfCnt);

	}

	if(iNoOfCnt == 0)
	{
		sprintf(sInsHoldQry,"INSERT INTO RMS_CLIENT_SECURITY_LIMIT \
				(ISIN_CODE,\
				 EXCH_ID,\
				 SECURITY_SOURCE_TYPE,\
				 QTY,\
				 QTY_UTILIZED,\
				 CLIENT_ID)\
				VALUES(\"%s\",\"%s\",\"%s\",%d,%d,\"%s\")\
				on duplicate key \
				UPDATE \
				QTY = VALUES(QTY + %d) ,\
				ISIN_CODE = VALUES(ISIN_CODE) ,\
				CLIENT_ID = VALUES(CLIENT_ID), \
				EXCH_ID = VALUES (EXCH_ID) ,\
				SECURITY_SOURCE_TYPE = VALUES (SECURITY_SOURCE_TYPE);"
				,pAddHoldingReq->sISINCode,pAddHoldingReq->ReqHeader.sExcgId,pAddHoldingReq->sSecSource,pAddHoldingReq->iQty,pAddHoldingReq->iQtyUtlized,pAddHoldingReq->sClientId,pAddHoldingReq->iQty);

		logDebug2("sInsHoldQry = %s",sInsHoldQry);

	}

	if(mysql_query(DBQury,sInsHoldQry) != SUCCESS)
	{
		logSqlFatal("Error in sChkCntQry Query.");
		sql_Error(DBQury);

		pAddHoldingResp.IntRespHeader.iErrorId = 1;
		pAddHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_HOLDING_ERR_RESP;
		logDebug2("Msg Code = %d",pAddHoldingResp.IntRespHeader.iMsgCode);
		strcpy(pAddHoldingResp.sErrorMsg,"Something Went Wrong !!!");
		logDebug2("pAddHoldingResp.sErrorMsg = %s",pAddHoldingResp.sErrorMsg);



	}
	else
	{
		pAddHoldingResp.IntRespHeader.iErrorId = 0;
		pAddHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_HOLDING_SCC_RESP;
		logDebug2("Msg Code = %d",pAddHoldingResp.IntRespHeader.iMsgCode);
		strcpy(pAddHoldingResp.sErrorMsg,"Holding Added Successfully");
		logDebug2("pAddHoldingResp.sErrorMsg = %s",pAddHoldingResp.sErrorMsg);

	}
	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pAddHoldingResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		exit(ERROR);
	}
	logTimestamp("fAddHoldings [EXIT]");
}

BOOL    fUpdateHoldings(CHAR *RcvMsg)
{
	logTimestamp("Entry : fUpdateHoldings ");
	struct  ADD_HOLDING_REQ        *pAddHoldingReq;
	struct  ADMIN_VIEW_COMMON_HDR_RESP      pAddHoldingResp;
	CHAR            sUpdateHoldingQry[MAX_QUERY_SIZE];	
	LONG32          iNoOfRec;
	CHAR 		cAUFlag;
	LONG32          iNoOfCnt;
	CHAR    	sRemarks[DB_REMARKS_LEN];	
	LONG32		iResult = 0 ;

	pAddHoldingReq = (struct ADD_HOLDING_REQ *)RcvMsg;
        memset(sUpdateHoldingQry,'\0',MAX_QUERY_SIZE);
        memset(sRemarks,'\0',DB_REMARKS_LEN);


	
        logDebug2("Holdin Msgcode :%d:" ,pAddHoldingReq->ReqHeader.iMsgCode);
	
	if(pAddHoldingReq->ReqHeader.iMsgCode == TC_INT_ADMIN_ADD_HOLDING_REQ)
	{
		cAUFlag = 'A';
                logDebug2("Add Holding");
	}
        if(pAddHoldingReq->ReqHeader.iMsgCode == TC_INT_ADMIN_UPDATE_HOLDING_REQ)
	{
		cAUFlag = 'U';
                logDebug2("Update Holding");
	}


//	fTrim(pAddHoldingReq->sEntityId,strlen(pAddHoldingReq->sEntityId));
//	fTrim(pAddHoldingReq->sClientId,strlen(pAddHoldingReq->sClientId));
//	fTrim(pAddHoldingReq->sISINCode,strlen(pAddHoldingReq->sISINCode));
//	fTrim(pAddHoldingReq->sSecSource,strlen(pAddHoldingReq->sSecSource));
	
	logDebug2("pAddHoldingReq->sEntityId = %s",pAddHoldingReq->sEntityId);
	logDebug2("cAUFlag = %c",cAUFlag);
	logDebug2("pAddHoldingReq->ReqHeader.sExcgId 	= %s",pAddHoldingReq->ReqHeader.sExcgId);
	logDebug2("pAddHoldingReq->sISINCode 		= %s",pAddHoldingReq->sISINCode);
	logDebug2("pAddHoldingReq->sClientId 		= %s",pAddHoldingReq->sClientId);
	logDebug2("pAddHoldingReq->sSecSource 		= %s",pAddHoldingReq->sSecSource);
	logDebug2("pAddHoldingReq->fCostPrice 		= %lf",pAddHoldingReq->fCostPrice);
	logDebug2("pAddHoldingReq->iQty      		= %d",pAddHoldingReq->iQty);
	logDebug2("pAddHoldingReq->ReqHeader.iUserId    = %d",pAddHoldingReq->ReqHeader.iUserId);
	logDebug2("pAddHoldingReq->cCollateralflag      = %c",pAddHoldingReq->cCollateralflag);
	logDebug2("pAddHoldingReq->iTotalQty      	= %d",pAddHoldingReq->iTotalQty);
	logDebug2("pAddHoldingReq->fHairCutPer 		= %f",pAddHoldingReq->fHairCutPer);
	logDebug2("pAddHoldingReq->iCollateralQty	= %d",pAddHoldingReq->iCollateralQty);
/*	if(mysql_set_server_option(DBQury,CLIENT_MULTI_STATEMENTS) == 0)
        {
                logDebug2(" mysql_set_server_option SUCCESS");
        }
        else
        {
                logDebug2(" mysql_set_server_option FAILed");
                return FALSE;
        }
*/
	/*logDebug2("*************");
	memset(sUpdateHoldingQry,'\0',QUERY_SIZE);
	logDebug2("^^^^^^^^^^^^^^");*/	

//	memset(&sUpdateHoldingQry,'\0',MAX_QUERY_SIZE);
//	memset(sRemarks,'\0',DB_REMARKS_LEN);
	sprintf(sUpdateHoldingQry,"CALL PR_ADMIN_HOLDING_ADD(\'%c\',\"%s\",\"%s\",\"%s\",\"%s\",%lf,%d,\'%c\',\"%s\",%d,%f,%d,@ZSTATUS);SELECT @ZSTATUS ;",cAUFlag,pAddHoldingReq->ReqHeader.sExcgId,pAddHoldingReq->sISINCode,pAddHoldingReq->sClientId,pAddHoldingReq->sSecSource,pAddHoldingReq->fCostPrice,pAddHoldingReq->iQty,pAddHoldingReq->cCollateralflag,pAddHoldingReq->sEntityId,pAddHoldingReq->iTotalQty,pAddHoldingReq->fHairCutPer,pAddHoldingReq->iCollateralQty);
	logDebug2("sUpdateHoldingQry = :%s:",sUpdateHoldingQry);

	if(mysql_query(DBQury,sUpdateHoldingQry) != SUCCESS)
        {
        	logSqlFatal("###### SQL Failed for sUpdateHoldingQry ######");
                sql_Error(DBQury);
                return FALSE;
        }
        do
        {
        	logDebug2("###########");
                Res = mysql_store_result(DBQury);
                logDebug2("********");
                if(Res)
                {
	                logDebug2("^^^^^^");
                        if(Row = mysql_fetch_row(Res));
                        {
                        	strncpy(sRemarks,Row[0],DB_REMARKS_LEN);
                                logDebug2("sRemarks = %s",sRemarks);
                        }
		}
                else
                {
                        logDebug2("No Result");
                }
                if((iResult = mysql_next_result(DBQury)) > 0)
                {
                        logDebug3("Could not execute statement :%d:",iResult);
                }
	}while(iResult == 0);
	

	/*	if(strncmp(pAddHoldingReq->sSecSource,"INT",3) || strncmp(pAddHoldingReq->sSecSource,"T1",3) || strncmp(pAddHoldingReq->sSecSource,"MRG",3))
	if(strncmp(pAddHoldingReq->sSecSource,"INT",3))
	{

		//		sprintf(sAddHoldingQry,"UPDATE  RMS_CLIENT_SECURITY_LIMIT t SET  t.QTY = t.QTY  +  %d  WHERE t.ISIN_CODE  = \"%s\"   AND  t.CLIENT_ID  = \"%s\" \
		AND t.EXCH_ID = \"%s\"   and t.SECURITY_SOURCE_TYPE =  \"%s\" ",pAddHoldingReq->iQty,pAddHoldingReq->sISINCode,pAddHoldingReq->sClientId,pAddHoldingReq->ReqHeader.sExcgId,pAddHoldingReq->sSecSource);
		if( pAddHoldingReq->iQtyUtlized  <=  pAddHoldingReq->iQty )
		{	
			sprintf(sAddHoldingQry,"UPDATE  RMS_CLIENT_SECURITY_LIMIT t SET  t.QTY = %d  WHERE t.ISIN_CODE  = \"%s\"   AND  t.CLIENT_ID  = \"%s\" \
					AND t.EXCH_ID = \"%s\"   and t.SECURITY_SOURCE_TYPE =  \"%s\" ",pAddHoldingReq->iQty,pAddHoldingReq->sISINCode, \
					pAddHoldingReq->sClientId,pAddHoldingReq->ReqHeader.sExcgId,pAddHoldingReq->sSecSource);

			logDebug2("sAddHoldingQry :%s:",sAddHoldingQry);

			if(mysql_query(DBQury,sAddHoldingQry) != SUCCESS)
			{
				logSqlFatal("###### SQL Failed for Updating RMS_CLIENT_SECURITY_LIMIT  ######");
				strcpy(pAddHoldingResp.sErrorMsg,"UPDATION FAILED");
				sql_Error(DBQury);
			}
			else
			{
				mysql_commit(DBQury);
				logInfo(" Updatee Commit sucessful");
				//                      strcpy(pAddHoldingResp.sErrorMsg ,"Holding Updated Successfully For ClientId");
				sprintf(pAddHoldingResp.sErrorMsg ,"Holding Updated Successfully For ClientId %s ",pAddHoldingReq->sClientId);
			}

		}
		else
		{
			logDebug2("Qty Cannnot be Modified  less than Utilized Qty");
			strcpy(pAddHoldingResp.sErrorMsg,"Qty Cannnot Be Modified Less Than Utilized Qty");
		}

	}
	else
	{
		logDebug2(" Quantity Updation Not Allowed For Source INT");
		strcpy(pAddHoldingResp.sErrorMsg,"Quantity Updation Not Allowed For Source INT");
	}
	*/


	if(cAUFlag =='A')
                {
      		 	pAddHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ADD_HOLDING_RESP ;        
	       		logDebug2("Add Holding");
                }
	 if(cAUFlag =='U')
                {
                        pAddHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_UPDATE_HOLDING_RESP ;
                        logDebug2("Update Holding");
                }

	pAddHoldingResp.IntRespHeader.iErrorId = 0 ;
	pAddHoldingResp.IntRespHeader.iSeqNo = 0;
	pAddHoldingResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
	pAddHoldingResp.IntRespHeader.iUserId =pAddHoldingReq->ReqHeader.iUserId;
	pAddHoldingResp.cMsgType = 'H';
	pAddHoldingResp.iNoofRec = 1;
	strncpy(pAddHoldingResp.sErrorMsg,sRemarks,DB_REMARKS_LEN);

	strncpy(pAddHoldingResp.sClientId,pAddHoldingReq->sClientId,CLIENT_ID_LEN);
	iRelayID = find_admin_adapter(pAddHoldingReq->ReqHeader.iUserId);

	logDebug2("iRelayID = %d",iRelayID);
	logDebug2(" Response Msg Code = %d",pAddHoldingResp.IntRespHeader.iMsgCode);
	logDebug2("pAddHoldingResp.sErrorMsg = %s",pAddHoldingResp.sErrorMsg);

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pAddHoldingResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		exit(ERROR);
	}

	logTimestamp("Exit : fUpdateHoldings ");


}

/******
  BOOL    fAddClient(CHAR *RcvMsg)
  {
  logTimestamp("Entry : fAddClient");
  struct  ADMIN_ADD_CLIENT_REQ        *pAddClientReq;
  struct  ADMIN_VIEW_COMMON_HDR_RESP      pAddClientResp;

  pAddClientReq = (struct ADMIN_ADD_CLIENT_REQ *)RcvMsg;	

  CHAR            sSysParamQry		[QUERY_SIZE];
  CHAR		sGetPassQry		[QUERY_SIZE];
  CHAR		sGetUserIdQry		[QUERY_SIZE];
  CHAR		sUserInsertQry		[QUERY_SIZE];
  CHAR		sEntityInsertQry	[QUERY_SIZE];
  CHAR		sLimitInsertQry		[QUERY_SIZE];
  CHAR		sEntityDelMapQry	[QUERY_SIZE];
  CHAR		sEntityDelMapTempQry	[QUERY_SIZE];

  memset(sSysParamQry,'\0',QUERY_SIZE);
  memset(sGetPassQry,'\0',QUERY_SIZE);
  memset(sGetUserIdQry,'\0',QUERY_SIZE);
  memset(sUserInsertQry,'\0',QUERY_SIZE);
  memset(sEntityInsertQry,'\0',QUERY_SIZE);
  memset(sLimitInsertQry,'\0',QUERY_SIZE);
  memset(sEntityDelMapQry,'\0',QUERY_SIZE);
  memset(sEntityDelMapTempQry,'\0',QUERY_SIZE);

  sprintf(sSysParamQry,"SELECT PARAM_VALUE FROM SYS_PARAMETER WHERE PARAM_NAME = 'default_profile'");
  logDebug2("sSysParamQry = %s",sSysParamQry);

  if(mysql_query(DBQury,sSysParamQry) != SUCCESS)
  {
  logSqlFatal("Error in sSysParamQry Query.");
  sql_Error(DBQury);
  }
  Res = mysql_store_result(DBQury);
  iNoOfRec = mysql_num_rows(Res);
  logDebug2("iNoOfRec = %d",iNoOfRec);

  if(Row = mysql_fetch_row(Res))
  {
  sRiskProf = atoi(Row[0][0]);
  logDebug2("RiskProf= %s",sRiskProf);
  }	
  if(strcmp(pAddClientReq->sRiskProfile,NO))
  {
  pAddClientReq->sRiskProfile = sRiskProf;
  }
  if(strcmp(pAddClientReq->sPassType,RANDOM))
  {
  sprintf(sGetPassQry,"SELECT FN_RANDOM_PASSWORD(10) PASS FROM dual");
  logDebug2("sGetPassQry = %s",sGetPassQry);
  }
  else if(strcmp(pAddClientReq->sPassType,DEFAULT))
  {
  sprintf(sGetPassQry,"SELECT PARAM_VALUE PASS FROM sys_parameter WHERE PARAM_NAME='default_password'");
  logDebug2("sGetPassQry = %s",sGetPassQry);
  }
  if(mysql_query(DBQury,sGetPassQry) != SUCCESS)
  {
  logSqlFatal("Error in sGetPassQry Query.");
  sql_Error(DBQury);
  }		
  sprintf(sGetUserIdQry,"SELECT NEXTVAL('USER_ID') USER_ID FROM dual");
  logDebug2("sGetUserIdQry = %s",sGetUserIdQry);

  if(mysql_query(DBQury,sGetUserIdQry) != SUCCESS)
  {
  logSqlFatal("Error in sGetUserId Query.");
  sql_Error(DBQury);
  }

sprintf(sEntityInsertQry,"INSERT INTO ENTITY_MASTER
		(ENTITY_CODE ,\
		 ENTITY_NAME ,\
		 ENTITY_TYPE,\
		 ENTITY_MANAGER_CODE,\
		 ENTITY_ADD_1,\
		 ENTITY_ADD_2,\
		 ENTITY_ADD_3,\
		 ENTITY_STATUS,\ 
		 ENTITY_PHONE,\
		 ENTITY_MOBILE,\
		 ENTITY_SUB_TYPE,\
		 ENTITY_CREATED_BY,\
		 ENTITY_CREATED_DATE,\
		 ENTITY_UPDATE_BY,\
		 ENTITY_UPDATE_DATE,\
		 ENTITY_RISK_PROFILE,\
		 ENTITY_DOB,\
		 ENTITY_PAN,\
		 ENTITY_NSE_CODE,\
		 ENTITY_EMAIL,\
		 ENTITY_PINCODE,\
		 ENTITY_MCX_CODE,\
		 ENTITY_MANAGER_TYPE)\
		 VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%c\",\"%s\",\"%s\",\"%s\",\"%s\",NOW(),\"%s\",NOW(),\"%s\",DATE(STR_TO_DATE(\"%s\",%%Y-%%m-%%d)),\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\")",pAddClientReq->sEntityId,pAddClientReq->sClientName,pAddClientReq->sEntityManCode,pAddClientReq->sFirstAddr,pAddClientReq->sSecondAddr,pAddClientReq->sThirdAddr,pAddClientReq->--,pAddClientReq->sLandLineNo,pAddClientReq->sMobileNo,pAddClientReq->--,pAddClientReq->sClientId,--,pAddClientReq->sRiskProf,pAddClientReq->sDob,pAddClientReq->sPan,pAddClientReq->sNseEQCode,pAddClientReq->sEmailId,pAddClientReq->sPinCode,pAddClientReq->sMCXCode,pAddClientReq->sEntityType);

logDebug2("sEntityInsertQry = %s",sEntityInsertQry);

if(mysql_query(DBQury,sEntityInsertQry) != SUCCESS)
{
	logSqlFatal("Error in sEntityInsertQry Query.");
	sql_Error(DBQury);
}	

sprintf(sEntityDelMapQry,"INSERT INTO ENTITY_DEALER_MAPPING
		(EDM_CLIENT_ID,\
		 EDM_DEALER_ID,\
		 EDM_REPORTING_BRANCH)\
		VALUES(\"%s\",\"%s\",\"%s\") ",pAddClientReq->sEntityId,pAddClientReq->sControllerId,BROKER);

logDebug2("sEntityDelMapQry = %s",sEntityDelMapQry);

if(mysql_query(DBQury,sEntityInsertQry) != SUCCESS)
{
	logSqlFatal("Error in sEntityInsertQry Query.");
	sql_Error(DBQury);
}

sprintf(sEntityDelMapTempQry,"INSERT INTO ENTITY_DEALER_MAPPING_TEMP
		(EDM_CLIENT_ID,\
		 EDM_DEALER_ID,\
		 EDM_REPORTING_BRANCH)\
		VALUES(\"%s\",\"%s\",\"%s\") ",pAddClientReq->sEntityId,pAddClientReq->sControllerId,BROKER);

logDebug2("sEntityDelMapTempQry = %s",sEntityDelMapTempQry);

if(mysql_query(DBQury,sEntityDelMapTempQry) != SUCCESS)
{
	logSqlFatal("Error in sEntityInsertQry Query.");
	sql_Error(DBQury);
}

sprintf(sUserInsertQry,"INSERT INTO USER_MASTER
		(USER_CODE,\
		 USER_ENTITY_CODE, \
		 USER_CREATED_BY ,\
		 USER_CREATED_DATE, \
		 USER_UPDATE_BY ,\
		 USER_PIN_CODE ,\
		 USER_EQU_NSE_LOC_CODE ,\
		 USER_DRV_NSE_LOC_CODE ,\
		 USER_EQU_BSE_LOC_CODE ,\
		 USER_DRV_BSE_LOC_CODE,\
		 USER_LOGIN_CODE ,\
		 USER_INV_PSWD_CHNG_REQ_CNTR,\
		 USER_VAL_PSWD_CHNG_REQ_CNTR, \
		 USER_UNLOCK_PWD_COUNTER ,\
		 USER_ROLE_ID ,\
		 USER_STATIC_IP ,\
		 USER_UP_PROFILE_ID ,\
		 USER_STATUS ,\
		 USER_INVALID_LOGIN_CTR ,\
		 USER_TRANS_PASSWORD ,\
		 USER_TOKEN_ID ,\
		 USER_FORGOT_PWD_CTR ,\
		 USER_UNLOCK_PWD_CTR ,\
		 USER_COM_MCX_LOC_CODE ,\
		 USER_EXCH_ALLOWED ,\
		 USER_CURR_NSE_LOC_CODE ,\
		 USER_REMARK1 ,\
		 USER_REMARK2 ,\
		 USER_REMARK3 ,\
		 USER_PRODUCT_ALLOWED ,\
		 USER_PASSWORD_CNG_DATE ,\
		 UM_SALT)\
		 VALUES(\"%s\",\"%s\",\"%s\",NOW(),\"%s\",%d,%d,%d,%d,%d,\"%s\",%d,%d,%d,%lf,\"%s\",\"%s\",\"%s\",\"%s)")

		 *******/



BOOL fIpoSecDetail(CHAR *RcvMsg)
{
	logTimestamp("Entry : fIpoSecDetail");
	struct ADMIN_IPO_SEC_DETAILS_REQ   	*pIpodetail;

	struct ADMIN_VIEW_COMMON_HDR_RESP	pIpoHdrResp;

	struct ADMIN_IPO_SEC_DETAILS_RESP   pIpo_Resp;

	CHAR    sDelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sUpdQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sInsQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    cChkFlag;

	memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sDelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sUpdQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sInsQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(&pIpo_Resp,'\0',sizeof (struct ADMIN_IPO_SEC_DETAILS_RESP));
	memset(&pIpodetail,'\0',sizeof (struct ADMIN_IPO_SEC_DETAILS_REQ));
	memset(&pIpoHdrResp,'\0',sizeof (struct ADMIN_VIEW_COMMON_HDR_RESP));

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;


	pIpodetail = (struct ADMIN_IPO_SEC_DETAILS_REQ *)RcvMsg;

	logDebug2("pIpodetail->cAUFlag :%c:",pIpodetail->cFlag);
	cChkFlag = pIpodetail->cFlag;
	logDebug2("cChkFlag :%c:",pIpodetail->cFlag);
	logDebug2("sClientId :%s:",pIpodetail->sClientId);
	if (cChkFlag == VIEW_IPO_DETAILS)
	{
		logTimestamp("Entry : fViewIPODetail");

		sprintf(sSelQry,"SELECT CMPY_ID,CMPY_NAME,SYMBOL,SYMBOL_NAME,SERIES,IPO_TYPE,ISSUE_TYPE,FACE_VAL,LOW_BAND,HIGH_BAND,MIN_BID_LOT,QTY_MUL,IPO_SIZE,IPO_START_DATE,IPO_END_DATE,FINAL_MOD_DATE,IPO_STATUS,CATEGORY_ALLOWED,CONTACT_PERSON,COMPLIANCE_OFFICER,STREET1,STREET2,STATE,CITY,COUNTRY,PIN,EMAIL_ID,MOBILE,TELEPHONE,WEBSITE,ISSUE_NOTES,COMMENT,IPO_START_APP_NO,IPO_END_APP_NO,BID_CLOSING_TIME,INSTRUMENT_TYPE,CLIENT_ID FROM IPO_SECURITY_MASTER ");
		if(mysql_query(DBQury,sSelQry) != SUCCESS)
		{
			logSqlFatal("Error in sOrdBkQry.");
			sql_Error(DBQury);
		}

		Res = mysql_store_result(DBQury);
		iNoOfRec= mysql_num_rows(Res);
		fNoOfRec = iNoOfRec;
		iNoOfPkt = ceil(fNoOfRec/5);
		iTempNoOfRec = iNoOfPkt;
		logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

		pIpoHdrResp.IntRespHeader.iSeqNo = 0;
		pIpoHdrResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
		pIpoHdrResp.IntRespHeader.iErrorId = 0;
		pIpoHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_DETAIL_VIEW_HDR_RESP ;
		pIpoHdrResp.IntRespHeader.iUserId = pIpodetail->ReqHeader.iUserId;
		pIpoHdrResp.IntRespHeader.cSource = pIpodetail->ReqHeader.cSource ;
		pIpoHdrResp.cMsgType = 'H';
		pIpoHdrResp.iNoofRec = iNoOfRec;

		strncpy(pIpoHdrResp.sClientId,pIpodetail->sClientId,CLIENT_ID_LEN);

		logDebug2(" pIpoHdrResp.ResHeader.iSeqNo :%d:" , pIpoHdrResp.IntRespHeader.iSeqNo);
		logDebug2(" pIpoHdrResp.ResHeader.iMsgLength :%d: ", pIpoHdrResp.IntRespHeader.iMsgLength);
		logDebug2(" pIpoHdrResp.ResHeader.iErrorId :%d:" , pIpoHdrResp.IntRespHeader.iErrorId);
		logDebug2("pIpoHdrResp.ResHeader.iMsgCode :%d:" , pIpoHdrResp.IntRespHeader.iMsgCode);
		logDebug2(" pIpoHdrResp.ResHeader.iUserId :%d:" , pIpoHdrResp.IntRespHeader.iUserId);
		logDebug2(" pIpoHdrResp.ResHeader.cSource:%c:" , pIpoHdrResp.IntRespHeader.cSource);
		logDebug2(" pIpoHdrResp.ResHeader.sClientId :%s:" , pIpoHdrResp.sClientId);

		iRelayID = find_admin_adapter(pIpodetail->ReqHeader.iUserId);
		logDebug2("iRelayID :%d:",iRelayID);

		if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pIpoHdrResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
			exit(ERROR);
		}

		for(i=0;i<iNoOfPkt;i++)
		{
			logDebug2("******************** i = %d *************************",i);
			pIpo_Resp.IntRespHeader.iSeqNo = 0;
			pIpo_Resp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_IPO_SEC_DETAILS_RESP);
			pIpo_Resp.IntRespHeader.iErrorId = 0;
			pIpo_Resp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_VIEW_DETAIL_RESP ;
			pIpo_Resp.IntRespHeader.iUserId = pIpodetail->ReqHeader.iUserId;
			pIpo_Resp.IntRespHeader.cSource = pIpodetail->ReqHeader.cSource ;	
			pIpo_Resp.iNoOfRec = iNoOfRec; 	
			if(iTempNoOfRec <= 1)
			{
				pIpo_Resp.cMsgType = 'T';
			}
			else
			{
				pIpo_Resp.cMsgType = 'D';
			}
			strncpy(pIpo_Resp.sClientId,pIpodetail->sClientId,CLIENT_ID_LEN);	
			logDebug2("pIpo_Resp.sClientId :%s:",pIpo_Resp.sClientId);

			//for(j=0;j<iNoOfPkt;j++)
			for(j=0;j<5;j++)
			{
				logDebug2("============== j = %d ==============",j);
				if(Row = mysql_fetch_row(Res))
				{
					strncpy(pIpo_Resp.subipodetail[j].sCmpyId,Row[0],COMPANY_ID_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sCmpyId :%s:",j,pIpo_Resp.subipodetail[j].sCmpyId);
					strncpy(pIpo_Resp.subipodetail[j].sCmpyName,Row[1],DB_SYM_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sCmpyName:%s:",j,pIpo_Resp.subipodetail[j].sCmpyName);
					strncpy(pIpo_Resp.subipodetail[j].sSymbol,Row[2],SYMBOL_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sSymbol:%s:",j,pIpo_Resp.subipodetail[j].sSymbol);
					strncpy(pIpo_Resp.subipodetail[j].sSymbolName,Row[3],DB_SYM_NAME_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sSymbolName:%s:",j,pIpo_Resp.subipodetail[j].sSymbolName);
					strncpy(pIpo_Resp.subipodetail[j].sSeries,Row[4],DB_SERIES_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sSeries:%s:",j,pIpo_Resp.subipodetail[j].sSeries);
					pIpo_Resp.subipodetail[j].iIPOType = atoi(Row[5]);
					logDebug2("pIpo_Resp.subipodetail[%d].iIPOType:%d:",j,pIpo_Resp.subipodetail[j].iIPOType);
					pIpo_Resp.subipodetail[j].iIssueType = atoi(Row[6]);
					logDebug2("pIpo_Resp.subipodetail[%d].iIssueType:%d:",j,pIpo_Resp.subipodetail[j].iIssueType);
					pIpo_Resp.subipodetail[j].fFaceValue = atof(Row[7]);
					logDebug2("pIpo_Resp.subipodetail[%d].fFaceValue:%f:",j,pIpo_Resp.subipodetail[j].fFaceValue);
					pIpo_Resp.subipodetail[j].fLowBand = atof(Row[8]);
					logDebug2("pIpo_Resp.subipodetail[%d].fLowBand:%f:",j,pIpo_Resp.subipodetail[j].fLowBand);
					pIpo_Resp.subipodetail[j].fHighBand = atof(Row[9]);
					logDebug2("pIpo_Resp.subipodetail[%d].fHighBand%f:",j,pIpo_Resp.subipodetail[j].fHighBand);
					pIpo_Resp.subipodetail[j].iMinBidlot = atoi(Row[10]);
					logDebug2("pIpo_Resp.subipodetail[%d].iMinBidlot:%d:",j,pIpo_Resp.subipodetail[j].iMinBidlot);
					pIpo_Resp.subipodetail[j].iQtyMul = atoi(Row[11]);
					logDebug2("pIpo_Resp.subipodetail[%d].iQtyMul:%d:",j,pIpo_Resp.subipodetail[j].iQtyMul);
					pIpo_Resp.subipodetail[j].iIpoSize = atoi(Row[12]);
					logDebug2("pIpo_Resp.subipodetail[%d].iIpoSize:%d:",j,pIpo_Resp.subipodetail[j].iIpoSize);
					strncpy(pIpo_Resp.subipodetail[j].sStartDate,Row[13],DATE_LENGTH);
					logDebug2("pIpo_Resp.subipodetail[%d].sStartDate:%s:",j,pIpo_Resp.subipodetail[j].sStartDate);
					strncpy(pIpo_Resp.subipodetail[j].sEndDate,Row[14],DATE_LENGTH);
					logDebug2("pIpo_Resp.subipodetail[%d].sEndDate:%s:",j,pIpo_Resp.subipodetail[j].sEndDate);
					strncpy(pIpo_Resp.subipodetail[j].sFinalModDate,Row[15],DATE_LENGTH);
					logDebug2("pIpo_Resp.subipodetail[%d].sFinalModDate:%s:",j,pIpo_Resp.subipodetail[j].sFinalModDate);
					pIpo_Resp.subipodetail[j].iStatus= atoi(Row[16]);
					logDebug2("pIpo_Resp.subipodetail[%d].iStatus:%d:",j,pIpo_Resp.subipodetail[j].iStatus);
					strncpy(pIpo_Resp.subipodetail[j].sCategory,Row[17],CATEGORY_CODE_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sCategory:%s:",j,pIpo_Resp.subipodetail[j].sCategory);
					strncpy(pIpo_Resp.subipodetail[j].sContctPrsn,Row[18],MOBILE_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sContctPrsn:%s:",j,pIpo_Resp.subipodetail[j].sContctPrsn);
					strncpy(pIpo_Resp.subipodetail[j].sCompOffc,Row[19],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sCompOffc:%s:",j,pIpo_Resp.subipodetail[j].sCompOffc);
					strncpy(pIpo_Resp.subipodetail[j].sStreet1,Row[20],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sStreet1:%s:",j,pIpo_Resp.subipodetail[j].sStreet1);
					strncpy(pIpo_Resp.subipodetail[j].sStreet2,Row[21],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sStreet2:%s:",j,pIpo_Resp.subipodetail[j].sStreet2);
					strncpy(pIpo_Resp.subipodetail[j].sState,Row[22],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sState:%s:",j,pIpo_Resp.subipodetail[j].sState);
					strncpy(pIpo_Resp.subipodetail[j].sCity,Row[23],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sCity:%s:",j,pIpo_Resp.subipodetail[j].sCity);
					strncpy(pIpo_Resp.subipodetail[j].sCountry,Row[24],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sCountry:%s:",j,pIpo_Resp.subipodetail[j].sCountry);
					pIpo_Resp.subipodetail[j].iPin= atoi(Row[25]);
					logDebug2("pIpo_Resp.subipodetail[%d].iPin:%d:",j,pIpo_Resp.subipodetail[j].iPin);
					strncpy(pIpo_Resp.subipodetail[j].sEmailId,Row[26],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sEmailId:%s:",j,pIpo_Resp.subipodetail[j].sEmailId);
					strncpy(pIpo_Resp.subipodetail[j].sMobile,Row[27],MOBILE_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sMobile:%s:",j,pIpo_Resp.subipodetail[j].sMobile);
					strncpy(pIpo_Resp.subipodetail[j].sTelephone,Row[28],MOBILE_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sTelephone:%s",j,pIpo_Resp.subipodetail[j].sTelephone);
					strncpy(pIpo_Resp.subipodetail[j].sWebsite,Row[29],ADDRESS_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sWebsite:%s:",j,pIpo_Resp.subipodetail[j].sWebsite);
					strncpy(pIpo_Resp.subipodetail[j].sNotes,Row[30],NOTES_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sNotes:%s:",j,pIpo_Resp.subipodetail[j].sNotes);
					strncpy(pIpo_Resp.subipodetail[j].sComment,Row[31],COMMENT_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sComment:%s:",j,pIpo_Resp.subipodetail[j].sComment);
					pIpo_Resp.subipodetail[j].iSApplicationNo = atoi(Row[32]);
					logDebug2("pIpo_Resp.subipodetail[%d].iSApplicationNo :%d:",j,pIpo_Resp.subipodetail[j].iSApplicationNo);
					pIpo_Resp.subipodetail[j].iEApplicationNo = atoi(Row[33]);
					logDebug2("pIpo_Resp.subipodetail[%d].iEApplicationNo:%d:",j,pIpo_Resp.subipodetail[j].iEApplicationNo);
					//		pIpo_Resp.iMsgCode = TC_INT_ADMIN_IPO_SEC_DETAILS_RESP;
					strncpy(pIpo_Resp.subipodetail[j].sBidClosingtime,Row[34],DATE_LENGTH);
					logDebug2("pIpo_Resp.subipodetail[%d].sBidClosingtime:%s:",j,pIpo_Resp.subipodetail[j].sBidClosingtime);
					strncpy(pIpo_Resp.subipodetail[j].sInstrumentType,Row[35],DB_INSTRU_LEN);
					logDebug2("pIpo_Resp.subipodetail[%d].sInstrumentType:%s:",j,pIpo_Resp.subipodetail[j].sInstrumentType);
					strncpy(pIpo_Resp.sClientId,Row[36],CLIENT_ID_LEN);
					logDebug2("pIpo_Resp.sClientId:%s:",pIpo_Resp.sClientId);

				} 
			}	

			logDebug2("pIpo_Resp.cMsgType = %c",pIpo_Resp.cMsgType);
			iTempNoOfRec -- ;
			if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pIpo_Resp,sizeof(struct ADMIN_IPO_SEC_DETAILS_RESP) ,iRelayID) != TRUE ))
			{
				logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
				exit(ERROR);
			}

		}

		logTimestamp("Exit : fViewIPODetail");	
	}
	if(cChkFlag == ADD_IPO_DETAILS)
	{
		logTimestamp("Entry : fAddIPODetail");
		logDebug2("pIpodetail->sCmpyId :%s:",pIpodetail->sCmpyId);
		logDebug2("pIpodetail->sCmpyName:%s:",pIpodetail->sCmpyName);
		logDebug2("pIpodetail->sSymbol:%s:",pIpodetail->sSymbol);
		logDebug2("pIpodetail->sSymbolName:%s:",pIpodetail->sSymbolName);
		logDebug2("pIpodetail->sSeries:%s:",pIpodetail->sSeries);
		logDebug2("pIpodetail->IPOType:%d:",pIpodetail->iIPOType);
		logDebug2("pIpodetail->iIssueType:%d:",pIpodetail->iIssueType);
		logDebug2("pIpodetail->fFaceValue:%f:",pIpodetail->fFaceValue);
		logDebug2("pIpodetail->fLowBand:%f:",pIpodetail->fLowBand);
		logDebug2("pIpodetail->fHighBand%f:",pIpodetail->fHighBand);
		logDebug2("pIpodetail->iMinBidlot:%d:",pIpodetail->iMinBidlot);
		logDebug2("pIpodetail->iQtyMul:%d:",pIpodetail->iQtyMul);
		logDebug2("pIpodetail->iIpoSize:%d:",pIpodetail->iIpoSize);
		logDebug2("pIpodetail->sStartDate:%s:",pIpodetail->sStartDate);
		logDebug2("pIpodetail->sEndDate:%s:",pIpodetail->sEndDate);
		logDebug2("pIpodetail->sFinalModDate:%s:",pIpodetail->sFinalModDate);
		logDebug2("pIpodetail->iStatus:%d:",pIpodetail->iStatus);
		logDebug2("pIpodetail->sCategory:%s:",pIpodetail->sCategory);
		logDebug2("pIpodetail->sContctPrsn:%s:",pIpodetail->sContctPrsn);
		logDebug2("pIpodetail->sCompOffc:%s:",pIpodetail->sCompOffc);
		logDebug2("pIpodetail->sStreet1:%s:",pIpodetail->sStreet1);
		logDebug2("pIpodetail->sStreet2:%s:",pIpodetail->sStreet2);
		logDebug2("pIpodetail->sState:%s:",pIpodetail->sState);
		logDebug2("pIpodetail->sCity:%s:",pIpodetail->sCity);
		logDebug2("pIpodetail->sCountry:%s:",pIpodetail->sCountry);
		logDebug2("pIpodetail->iPin:%d:",pIpodetail->iPin);
		logDebug2("pIpodetail->sEmailId:%s:",pIpodetail->sEmailId);
		logDebug2("pIpodetail->sMobile:%s:",pIpodetail->sMobile);
		logDebug2("pIpodetail->sTelephone:%s",pIpodetail->sTelephone);
		logDebug2("pIpodetail->sWebsite:%s:",pIpodetail->sWebsite);
		logDebug2("pIpodetail->sNotes:%s:",pIpodetail->sNotes);
		logDebug2("pIpodetail->sComment:%s:",pIpodetail->sComment);
		logDebug2("pIpodetail->iSApplicationNo :%d:",pIpodetail->iSApplicationNo);
		logDebug2("pIpodetail->iEApplicationNo:%d:",pIpodetail->iEApplicationNo);
		logDebug2("pIpodetail->sBidClosingtime:%s:",pIpodetail->sBidClosingtime);
		logDebug2("pIpodetail->sInstrumentType:%s:",pIpodetail->sInstrumentType);
		logDebug2("pIpodetail->sClientId:%s:",pIpodetail->sClientId);

		sprintf(sInsQry,"INSERT INTO IPO_SECURITY_MASTER \
				(CMPY_ID,CMPY_NAME,SYMBOL,SYMBOL_NAME,SERIES,IPO_TYPE,ISSUE_TYPE,FACE_VAL,LOW_BAND,HIGH_BAND,\
				 MIN_BID_LOT,QTY_MUL,IPO_SIZE,IPO_START_DATE,IPO_END_DATE,FINAL_MOD_DATE,IPO_STATUS,CATEGORY_ALLOWED,\
				 CONTACT_PERSON,COMPLIANCE_OFFICER,STREET1,STREET2,STATE,CITY,COUNTRY,PIN,EMAIL_ID,MOBILE,TELEPHONE,WEBSITE,ISSUE_NOTES,\
				 COMMENT,IPO_START_APP_NO,IPO_END_APP_NO,BID_CLOSING_TIME,INSTRUMENT_TYPE,CLIENT_ID)\
				VALUES \
				(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%d,%d,%f,%f,%f,%d,%d,%d,STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),\
				 STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),%d,\"%s\",\"%s\",\"%s\",\"%s\",\
				 \"%s\",\"%s\",\"%s\",\"%s\",%d,\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%d,%d,STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\"%s\",\"%s\")",\
				pIpodetail->sCmpyId,pIpodetail->sCmpyName,pIpodetail->sSymbol,pIpodetail->sSymbolName,pIpodetail->sSeries,pIpodetail->iIPOType,\
				pIpodetail->iIssueType,pIpodetail->fFaceValue,pIpodetail->fLowBand,pIpodetail->fHighBand,pIpodetail->iMinBidlot,\
				pIpodetail->iQtyMul,pIpodetail->iIpoSize,pIpodetail->sStartDate,pIpodetail->sEndDate,pIpodetail->sFinalModDate,\
				pIpodetail->iStatus,pIpodetail->sCategory,pIpodetail->sContctPrsn,pIpodetail->sCompOffc,pIpodetail->sStreet1,\
				pIpodetail->sStreet2,pIpodetail->sState,pIpodetail->sCity,pIpodetail->sCountry,pIpodetail->iPin,pIpodetail->sEmailId,\
				pIpodetail->sMobile,pIpodetail->sTelephone,pIpodetail->sWebsite,pIpodetail->sNotes,pIpodetail->sComment,pIpodetail->iSApplicationNo,\
				pIpodetail->iEApplicationNo,pIpodetail->sBidClosingtime,pIpodetail->sInstrumentType,pIpodetail->sClientId);

		logDebug2("sInsQry :%s:",sInsQry);
		if(mysql_query(DBQury,sInsQry) != SUCCESS)
		{
			logSqlFatal("Error in sInsQry.");
			sql_Error(DBQury);
			strncpy(pIpoHdrResp.sErrorMsg,"Company Can Not Added.",ERROR_MESSAGE_LEN);
			pIpoHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_ADD_DETAIL_ERR_RESP;
			pIpoHdrResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			logDebug2("Success in Insert Query :");
			strncpy(pIpoHdrResp.sErrorMsg,"Company Added SuccessFully",ERROR_MESSAGE_LEN);
			logDebug2("sErrorMsg = %s",pIpoHdrResp.sErrorMsg);
			pIpoHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_DETAIL_HDR_RESP;
			pIpoHdrResp.IntRespHeader.iErrorId = 0;
		}


		pIpoHdrResp.IntRespHeader.iSeqNo = 0;
		pIpoHdrResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
		pIpoHdrResp.IntRespHeader.iUserId = pIpodetail->ReqHeader.iUserId ;
		pIpoHdrResp.IntRespHeader.cSource = pIpodetail->ReqHeader.cSource;
		strncpy(pIpoHdrResp.sClientId,pIpodetail->sClientId,CLIENT_ID_LEN);
		logDebug2("pIpoHdrResp.sClientId :%s:",pIpoHdrResp.sClientId);
		pIpoHdrResp.cMsgType = 'H';
		pIpoHdrResp.iNoofRec = 1;
		logDebug2("Added successfully :");

		logDebug2("pIpoHdrReq->ReqHeader.iUserId :%d:",pIpodetail->ReqHeader.iUserId);
		iRelayID = find_admin_adapter(pIpodetail->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pIpoHdrResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
			exit(ERROR);
		}
		logTimestamp("Exit : fAddIPODetail");

	}
	if(cChkFlag == EDIT_IPO_DETAILS)
	{
		logTimestamp("Entry : fEditIpoDetail ");

		logDebug2("pIpodetail->sCmpyId :%s:",pIpodetail->sCmpyId);
		logDebug2("pIpodetail->sCmpyName:%s:",pIpodetail->sCmpyName);
		logDebug2("pIpodetail->sSymbol:%s:",pIpodetail->sSymbol);
		logDebug2("pIpodetail->sSymbolName:%s:",pIpodetail->sSymbolName);
		logDebug2("pIpodetail->sSeries:%s:",pIpodetail->sSeries);
		logDebug2("pIpodetail->IPOType:%d:",pIpodetail->iIPOType);
		logDebug2("pIpodetail->iIssueType:%d:",pIpodetail->iIssueType);
		logDebug2("pIpodetail->fFaceValue:%f:",pIpodetail->fFaceValue);
		logDebug2("pIpodetail->fLowBand:%f:",pIpodetail->fLowBand);
		logDebug2("pIpodetail->fHighBand%f:",pIpodetail->fHighBand);
		logDebug2("pIpodetail->iMinBidlot:%d:",pIpodetail->iMinBidlot);
		logDebug2("pIpodetail->iQtyMul:%d:",pIpodetail->iQtyMul);
		logDebug2("pIpodetail->iIpoSize:%d:",pIpodetail->iIpoSize);
		logDebug2("pIpodetail->sStartDate:%s:",pIpodetail->sStartDate);
		logDebug2("pIpodetail->sEndDate:%s:",pIpodetail->sEndDate);
		logDebug2("pIpodetail->sFinalModDate:%s:",pIpodetail->sFinalModDate);
		logDebug2("pIpodetail->iStatus:%d:",pIpodetail->iStatus);
		logDebug2("pIpodetail->sCategory:%s:",pIpodetail->sCategory);
		logDebug2("pIpodetail->sContctPrsn:%s:",pIpodetail->sContctPrsn);
		logDebug2("pIpodetail->sCompOffc:%s:",pIpodetail->sCompOffc);
		logDebug2("pIpodetail->sStreet1:%s:",pIpodetail->sStreet1);
		logDebug2("pIpodetail->sStreet2:%s:",pIpodetail->sStreet2);
		logDebug2("pIpodetail->sState:%s:",pIpodetail->sState);
		logDebug2("pIpodetail->sCity:%s:",pIpodetail->sCity);
		logDebug2("pIpodetail->sCountry:%s:",pIpodetail->sCountry);
		logDebug2("pIpodetail->iPin:%d:",pIpodetail->iPin);
		logDebug2("pIpodetail->sEmailId:%s:",pIpodetail->sEmailId);
		logDebug2("pIpodetail->sTelephone:%s:",pIpodetail->sTelephone);
		logDebug2("pIpodetail->sWebsite:%s:",pIpodetail->sWebsite);
		logDebug2("pIpodetail->sNotes:%s:",pIpodetail->sNotes);
		logDebug2("pIpodetail->sComment:%s:",pIpodetail->sComment);
		logDebug2("pIpodetail->iSApplicationNo :%d:",pIpodetail->iSApplicationNo);
		logDebug2("pIpodetail->iEApplicationNo:%d:",pIpodetail->iEApplicationNo);
		logDebug2("pIpodetail->sBidClosingtime:%s:",pIpodetail->sBidClosingtime);
		logDebug2("pIpodetail->InstrumentType :%s:",pIpodetail->sInstrumentType);
		logDebug2("pIpodetail->sClientId :%s:",pIpodetail->sClientId);

		sprintf(sUpdQry,"INSERT INTO IPO_SECURITY_MASTER(\
			CMPY_ID ,\
			CMPY_NAME,\
			SYMBOL,\
			SYMBOL_NAME,\
			SERIES ,\
			IPO_TYPE ,\
			ISSUE_TYPE ,\
			FACE_VAL ,\
			LOW_BAND,\
			HIGH_BAND,\
			MIN_BID_LOT,\
			QTY_MUL,\
			IPO_SIZE,\
			IPO_START_DATE,\
			IPO_END_DATE,\
			FINAL_MOD_DATE,\
			IPO_STATUS,\
			CATEGORY_ALLOWED,\
			CONTACT_PERSON,\
			COMPLIANCE_OFFICER,\
			STREET1,\
			STREET2,\
			STATE,\
			CITY,\
			COUNTRY,\
			PIN,\
			EMAIL_ID,\
			MOBILE,\
			TELEPHONE,\
			WEBSITE,\
			ISSUE_NOTES,\
			COMMENT,\
			IPO_START_APP_NO,\
			IPO_END_APP_NO,\
			BID_CLOSING_TIME,\
			INSTRUMENT_TYPE,\
			CLIENT_ID)\
			VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%d,%d,%f,%f,%f,%d,%d,%d,STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),\
					STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),%d,\"%s\",\"%s\",\"%s\",\"%s\",\
					\"%s\",\"%s\",\"%s\",\"%s\",%d,\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%d,%d,STR_TO_DATE(\"%s\",\'%%Y-%%m-%%d %%H:%%i:%%S\'),\"%s\",\"%s\" )\
			on duplicate key \
			UPDATE \
			CMPY_ID = VALUES (CMPY_ID),\
			CMPY_NAME = VALUES (CMPY_NAME),\
			SYMBOL = VALUES (SYMBOL),\
			SYMBOL_NAME = VALUES (SYMBOL_NAME),\
			SERIES = VALUES (SERIES),\
			IPO_TYPE = VALUES (IPO_TYPE),\
			ISSUE_TYPE = VALUES (ISSUE_TYPE),\
			FACE_VAL = VALUES (FACE_VAL),\
			LOW_BAND = VALUES (LOW_BAND),\
			HIGH_BAND = VALUES (HIGH_BAND),\
			MIN_BID_LOT = VALUES (MIN_BID_LOT),\
			QTY_MUL = VALUES (QTY_MUL),\
			IPO_SIZE = VALUES (IPO_SIZE),\
			IPO_START_DATE = VALUES (IPO_START_DATE),\
			IPO_END_DATE = VALUES (IPO_END_DATE),\
			FINAL_MOD_DATE = VALUES (FINAL_MOD_DATE),\
			IPO_STATUS = VALUES (IPO_STATUS),\
			CATEGORY_ALLOWED = VALUES (CATEGORY_ALLOWED),\
			CONTACT_PERSON = VALUES (CONTACT_PERSON),\
			COMPLIANCE_OFFICER = VALUES (COMPLIANCE_OFFICER),\
			STREET1 = VALUES (STREET1),\
			STREET2 = VALUES (STREET2),\
			STATE = VALUES (STATE) ,\
			CITY = VALUES (CITY),\
			COUNTRY = VALUES (COUNTRY),\
			PIN = VALUES (PIN),\
			EMAIL_ID = VALUES (EMAIL_ID),\
			MOBILE = VALUES (MOBILE),\
			TELEPHONE = VALUES (TELEPHONE),\
			WEBSITE = VALUES (WEBSITE),\
			ISSUE_NOTES = VALUES (ISSUE_NOTES),\
			COMMENT = VALUES (COMMENT),\
			IPO_START_APP_NO = VALUES (IPO_START_APP_NO),\
			IPO_END_APP_NO = VALUES (IPO_START_APP_NO),\
			BID_CLOSING_TIME = VALUES (BID_CLOSING_TIME),\
			INSTRUMENT_TYPE = VALUES (INSTRUMENT_TYPE),\
			CLIENT_ID = VALUES (CLIENT_ID); "\
			,pIpodetail->sCmpyId,pIpodetail->sCmpyName,pIpodetail->sSymbol,pIpodetail->sSymbolName,pIpodetail->sSeries,\
			pIpodetail->iIPOType,pIpodetail->iIssueType,pIpodetail->fFaceValue,pIpodetail->fLowBand,pIpodetail->fHighBand,pIpodetail->iMinBidlot,\
			pIpodetail->iQtyMul,pIpodetail->iIpoSize,pIpodetail->sStartDate,pIpodetail->sEndDate,pIpodetail->sFinalModDate,\
			pIpodetail->iStatus,pIpodetail->sCategory,pIpodetail->sContctPrsn,pIpodetail->sCompOffc,pIpodetail->sStreet1,\
			pIpodetail->sStreet2,pIpodetail->sState,pIpodetail->sCity,pIpodetail->sCountry,pIpodetail->iPin,pIpodetail->sEmailId,\
			pIpodetail->sMobile,pIpodetail->sTelephone,pIpodetail->sWebsite,pIpodetail->sNotes,pIpodetail->sComment,pIpodetail->iSApplicationNo,\
			pIpodetail->iEApplicationNo,pIpodetail->sBidClosingtime,pIpodetail->sInstrumentType,pIpodetail->sClientId);
		logDebug2("sUpdQry :%s:",sUpdQry);
		if(mysql_query(DBQury,sUpdQry) != SUCCESS)
		{
			logSqlFatal("Error in sInsQry.");
			sql_Error(DBQury);
			strncpy(pIpoHdrResp.sErrorMsg,"Security Can Not Updated.",ERROR_MESSAGE_LEN);
			pIpoHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_EDIT_DETAIL_ERR_RESP; 
			pIpoHdrResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			logDebug2("Success in Insert Query :");
			strncpy(pIpoHdrResp.sErrorMsg,"Security  Updated SuccessFully",ERROR_MESSAGE_LEN);
			pIpoHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_DETAIL_HDR_RESP;
			pIpoHdrResp.IntRespHeader.iErrorId = 0;
		}

		pIpoHdrResp.IntRespHeader.iSeqNo = 0;
		pIpoHdrResp.IntRespHeader.iMsgLength = sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP);
		pIpoHdrResp.IntRespHeader.iUserId = pIpodetail->ReqHeader.iUserId ;
		pIpoHdrResp.IntRespHeader.cSource = pIpodetail->ReqHeader.cSource;
		strncpy(pIpoHdrResp.sClientId,pIpodetail->sClientId,CLIENT_ID_LEN);
		logDebug2("pIpoHdrResp.sClientId :%s:",pIpoHdrResp.sClientId);
		pIpoHdrResp.cMsgType = 'H';
		pIpoHdrResp.iNoofRec = 1;
		logDebug2("update successfully :");

		logDebug2("pIpoHdrReq->ReqHeader.iUserId :%d:",pIpodetail->ReqHeader.iUserId);
		iRelayID = find_admin_adapter(pIpodetail->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pIpoHdrResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
			exit(ERROR);
		}
		logTimestamp("Exit : fEditIpoDetail ");

	}

	/** if(cChkFlag == DEL_IPO_DETAILS)
	  {
	  logTimestamp("Entry : fDelIpoDetail ");

	  logDebug2("pIpodetail->sCmpyId :%s:",pIpodetail->sCmpyId);
	  sprintf(sDelQry,"DELETE FROM IPO_SECURITY_MASTER WHERE CMPY_ID = \"%s\" ",pIpodetail->sCmpyId);

	  logDebug2("sDelQry :%s:",sDelQry);
	  if(mysql_query(DBQury,sDelQry) != SUCCESS)
	  {
	  logSqlFatal("Error in sDelQry.");
	  sql_Error(DBQury);
	  strncpy(pIpoHdrResp.sRemark,"Error in Delete Query ",ERROR_STRING_LEN);
	  pIpoHdrResp.ResHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_DEL_DETAIL_ERR_RESP;
	  }
	  else
	  {
	  logDebug2("Success in Insert Query :");
	  strncpy(pIpoHdrResp.sRemark,"Security  Deleted SuccessFully",REMARKS_LEN);
	  pIpoHdrResp.ResHeader.iMsgCode = TC_INT_ADMIN_IPO_SEC_DETAIL_HDR_RESP;
	  }
	  iRelayID = find_admin_adapter(pIpodetail->ReqHeader.iUserId);
	  logDebug2("pIpoHdrReq->ReqHeader.iUserId :%d:",pIpodetail->ReqHeader.iUserId);

	  pIpoHdrResp.ResHeader.iMsgLength = sizeof(struct ADMIN_IPO_SEC_HDR_RSP );
	  pIpoHdrResp.ResHeader.iErrorId = 0;

	  if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pIpoHdrResp,sizeof(struct ADMIN_IPO_SEC_HDR_RSP) ,iRelayID ) != TRUE ))
	  {
	  logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
	  exit(ERROR);
	  }
	  logTimestamp("Exit : fDelIpoDetail ");
	  }**/

}

BOOL fSendRspAdmin(CHAR *sResp)
{
        logTimestamp("ENTRY [fSendResToFE]");
        struct  ORDER_RESPONSE  Ord_Res;
        struct ORDER_REQUEST *Ord_Reque;
        memset(&Ord_Res, '\0', sizeof(struct ORDER_RESPONSE));
        LONG32  iTempUserID;
        BOOL    iRetVal;
        LONG32  iRelayID= 0;

        Ord_Reque = (struct ORDER_REQUEST *)sResp;

        Ord_Res.IntRespHeader.iSeqNo            = Ord_Reque->ReqHeader.iSeqNo;
        Ord_Res.IntRespHeader.iMsgLength        = sizeof(struct ORDER_RESPONSE);

        logDebug2(" Request iMsgCode = :%d:",Ord_Reque->ReqHeader.iMsgCode);
        if(Ord_Reque->ReqHeader.iMsgCode == TC_INT_NOTIFICATION_REQ)
        {
                Ord_Res.IntRespHeader.iMsgCode = TC_INT_NOTIFICATION_RES;
        }
        else if(Ord_Reque->ReqHeader.iMsgCode == TC_INT_CREATE_ALL_FILE_REQ)
        {
                Ord_Res.IntRespHeader.iMsgCode = TC_INT_CREATE_ALL_FILE_RES;
        }
        logDebug2(" Responce Ord_Res.IntRespHeader.iMsgCode = :%d:",Ord_Res.IntRespHeader.iMsgCode);

        strncpy(Ord_Res.IntRespHeader.sExcgId,Ord_Reque->ReqHeader.sExcgId,EXCHANGE_LEN);

        Ord_Res.IntRespHeader.iErrorId = 0;

        Ord_Res.IntRespHeader.iUserId           = Ord_Reque->ReqHeader.iUserId;

        Ord_Res.IntRespHeader.cSource           = Ord_Reque->ReqHeader.cSource;

        Ord_Res.IntRespHeader.iTimeStamp = 0;
        Ord_Res.IntRespHeader.cSegment          = Ord_Reque->ReqHeader.cSegment;

        strncpy(Ord_Res.sEntityId,Ord_Reque->sEntityId,ENTITY_ID_LEN);
        strncpy(Ord_Res.sClientId,Ord_Reque->sClientId,CLIENT_ID_LEN);

        Ord_Res.iTotalQty                       = Ord_Reque->iTotalQty ;
        logDebug2("------------Printing Responce-----------");
        logDebug2("Seq No       [%d] ",Ord_Res.IntRespHeader.iSeqNo);
        logDebug2("MSG Code     [%d] ",Ord_Res.IntRespHeader.iMsgCode);
        logDebug2("sExcgId      [%s] ",Ord_Res.IntRespHeader.sExcgId);
        logDebug2("User id      [%d] ",Ord_Res.IntRespHeader.iUserId);
        logDebug2("Source       [%c] ",Ord_Res.IntRespHeader.cSource);
        logDebug2("Segment      [%c] ",Ord_Res.IntRespHeader.cSegment);
        logDebug2("Entity Id    [%s] ",Ord_Res.sEntityId);
        logDebug2("sClientId    [%s] ",Ord_Res.sClientId);
        logDebug2("Total Clients Mapped [%d]",Ord_Res.iTotalQty);
        logDebug2("--------------END------------------------");

        /*Issue Id 0047597*/
        iRelayID = find_admin_adapter(Ord_Res.IntRespHeader.iUserId); //find relay id
 	logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if((WriteMsgQ(iTrdRtrToRel,(CHAR *)&Ord_Res , sizeof(struct  ORDER_RESPONSE),iRelayID)) != TRUE  )
        {
                logFatal("Error : WriteMsgQ failed in SendRespToFE.");
                exit(ERROR);
        }
        logTimestamp("EXIT [SendResToFE]");

        return TRUE;
}


BOOL fIpoOrderReport(CHAR *RcvMsg)
{
        logTimestamp("Entry : [fIpoOrderReport]");

        struct  IPO_ORDER_BOOK_EXPORT_REQUEST   *pIpoOrdBookReq;
        struct  ORDER_BOOK_REPORT_RESPONSE      pIpoOrdBookRes;

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        MYSQL_RES       *Res1;
        MYSQL_ROW       Row1;
        MYSQL_RES       *Res2;
        MYSQL_ROW       Row2;

        LONG32  iRelayID;
        FILE   *fpFile;

        CHAR    sFileName [FILE_NAME_LEN];
        CHAR    sIpoReportQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sFuncQry[QUERY_SIZE];
        CHAR    sCommand[200];
        CHAR    sCurTime[SYS_TIME_LEN];
        CHAR    sTypeQry[QUERY_SIZE];
        CHAR    sEntityType[5];

        time_t t;
        t = time(NULL);
        memset(sCurTime,'\0',SYS_TIME_LEN);
        struct tm tm = *localtime(&t);
        sprintf(sCurTime,"%d%d%d",tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday);
        logDebug2("Current Time is |%s|",sCurTime);

        memset (sFileName,'\0',FILE_NAME_LEN);
        memset (sFuncQry,'\0',QUERY_SIZE);
        memset (sIpoReportQry,'\0',DOUBLE_MAX_QUERY_SIZE);
        memset (&sCommand,'\0',200);
        memset (sTypeQry,'\0',QUERY_SIZE);
        memset (sEntityType,'\0',5);

        pIpoOrdBookReq = (struct ORDER_BOOK_REPORT_REQUEST *)RcvMsg;

        logDebug2("pIpoOrdBookReq->sClientId    |%s| ",pIpoOrdBookReq->sClientId);
        logDebug2("pIpoOrdBookReq->sEntityId    |%s| ",pIpoOrdBookReq->sEntityId);
        logDebug2("pIpoOrdBookReq->sStatus      |%s| ",pIpoOrdBookReq->sStatus);
        logDebug2("pIpoOrdBookReq->iStartRow    |%d| ",pIpoOrdBookReq->iStartRow);
        logDebug2("pIpoOrdBookReq->iEndRow      |%d| ",pIpoOrdBookReq->iEndRow);

        sprintf(sTypeQry,"select ENTITY_TYPE from ENTITY_MASTER where ENTITY_CODE = \"%s\";",pIpoOrdBookReq->sEntityId);
        logDebug2("Typequery = %s",sTypeQry);
        if(mysql_query(DBQury,sTypeQry) != SUCCESS)
        {
                logSqlFatal("ERROR in IPO Order Book.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res2  =  mysql_store_result(DBQury);
        while((Row2 = mysql_fetch_row(Res2)))
        {
                strncpy(sEntityType,Row2[0],5);
        }
        mysql_free_result(Res2);

        sprintf(sFuncQry,"SELECT FN_QRY_IPO_ORDERBOOK(\"%s\",\"%s\",\"%s\",\"%s\",\"%d\",\"%d\");",pIpoOrdBookReq->sStatus,pIpoOrdBookReq->sClientId,pIpoOrdBookReq->sEntityId,sEntityType,pIpoOrdBookReq->iStartRow,pIpoOrdBookReq->iEndRow);
        logDebug2("final sFuncQry = %s",sFuncQry);

        if(mysql_query(DBQury,sFuncQry) != SUCCESS)
        {
                logSqlFatal("ERROR in IPO Order Book.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);

        while((Row = mysql_fetch_row(Res)))
        {
                strncpy(sIpoReportQry,Row[0],DOUBLE_MAX_QUERY_SIZE);
        }
        mysql_free_result(Res);

        printf("sIpoReportQry   %s \n",   sIpoReportQry);

        if (mysql_query(DBQury, sIpoReportQry) != SUCCESS)
        {
                logSqlFatal("Error in sIpoReportQry.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res1 = mysql_store_result(DBQury);

        sprintf(sFileName,"%s/%s%s.csv",sRRPath,pIpoOrdBookReq->sEntityId,sCurTime);
        logDebug2("sFileName  |%s| ", sFileName);
        logDebug2("sRRPath  |%s| ",sRRPath);
        fpFile = fopen(sFileName,"w+");
        if(fpFile == NULL)
        {
                logFatal("Not able to Open File in write mode");
                return FALSE;
        }

        fprintf(fpFile,"CLIENT_ID, PLACED_BY, ORDER_DATE_TIME, ORDER_NUMBER, APPLICATION_NO, EXCH, SEGMENT, COMPANY_ID, SYMBOL, CMPY_NAME, SYMBOL_NAME, ALLOTMENT, ORD_STATUS, BID1_QTY, BID1_PRICE, BID1_AMOUNT, BID1_REF_NO, BID1_TYPE, BID1_CUTOFF, BID1_STATUS, BID1_REASON, BID2_QTY, BID2_PRICE, BID2_AMOUNT, BID2_REF_NO, BID2_TYPE, BID2_CUTOFF, BID2_STATUS, BID2_REASON, BID3_QTY, BID3_PRICE, BID3_AMOUNT, BID3_REF_NO, BID3_TYPE, BID3_CUTOFF, BID3_STATUS, BID3_REASON, REASON, CUTOFF, SOURCE_FLG, INSTRUMENT_NAME, SERIES, PRO_CLIENT, LOW_BAND, HIGH_BAND, MIN_BID_LOT, UPI_ID, ISSUE_ID, ISSUE_TYPE, QTY_MUL, LOCATIONCODE, BANKCODE, BANKNAME, LOCNAME, RETAILFLAG, CATEGORY, PAYMENT_STATUS_REASON, UPI_STATUS, UPI_AMT_BLOCK, CLIENT_NAME, ALLOTED_QTY \n");

        if(mysql_num_rows(Res1) == 0)
        {
                logDebug2("Zero rows selected");
        }
        else
        {
                while((Row1 = mysql_fetch_row(Res1)))
                {
                        logDebug2("[CLIENT_ID]                  Row[ 0] |%s|",Row1[0]);
                        logDebug2("[PLACED_BY]                  Row[ 1] |%s|",Row1[1]);
                        logDebug2("[ORDER_DATE_TIME]            Row[ 2] |%s|",Row1[2]);
                        logDebug2("[ORDER_NUMBER]               Row[ 3] |%s|",Row1[3]);
                        logDebug2("[APPLICATION_NO]             Row[ 4] |%s|",Row1[4]);
                        logDebug2("[EXCH]                       Row[ 5] |%s|",Row1[5]);
                        logDebug2("[SEGMENT]                    Row[ 6] |%s|",Row1[6]);
                        logDebug2("[COMPANY_ID]                 Row[ 7] |%s|",Row1[7]);
                        logDebug2("[SYMBOL]                     Row[ 8] |%s|",Row1[8]);
                        logDebug2("[CMPY_NAME]                  Row[ 9] |%s|",Row1[9]);
                        logDebug2("[SYMBOL_NAME]                Row[10] |%s|",Row1[10]);
                        logDebug2("[ALLOTMENT]                  Row[11] |%s|",Row1[11]);
                        logDebug2("[ORD_STATUS]                 Row[12] |%s|",Row1[12]);
                        logDebug2("[BID1_QTY]                   Row[13] |%s|",Row1[13]);
                        logDebug2("[BID1_PRICE]                 Row[14] |%s|",Row1[14]);
                        logDebug2("[BID1_AMOUNT]                Row[15] |%s|",Row1[15]);
                        logDebug2("[BID1_REF_NO]                Row[16] |%s|",Row1[16]);
                        logDebug2("[BID1_TYPE]                  Row[17] |%s|",Row1[17]);
                        logDebug2("[BID1_CUTOFF]                Row[18] |%s|",Row1[18]);
                        logDebug2("[BID1_STATUS]                Row[19] |%s|",Row1[19]);
                        logDebug2("[BID1_REASON]                Row[20] |%s|",Row1[20]);
                        logDebug2("[BID2_QTY]                   Row[21] |%s|",Row1[21]);
                        logDebug2("[BID2_PRICE]                 Row[22] |%s|",Row1[22]);
                        logDebug2("[BID2_AMOUNT]                Row[23] |%s|",Row1[23]);
                        logDebug2("[BID2_REF_NO]                Row[24] |%s|",Row1[24]);
                        logDebug2("[BID2_TYPE]                  Row[25] |%s|",Row1[25]);
                        logDebug2("[BID2_CUTOFF]                Row[26] |%s|",Row1[26]);
                        logDebug2("[BID2_STATUS]                Row[27] |%s|",Row1[27]);
                        logDebug2("[BID2_REASON]                Row[28] |%s|",Row1[28]);
                        logDebug2("[BID3_QTY]                   Row[29] |%s|",Row1[29]);
                        logDebug2("[BID3_PRICE]                 Row[30] |%s|",Row1[30]);
                        logDebug2("[BID3_AMOUNT]                Row[31] |%s|",Row1[31]);
                        logDebug2("[BID3_REF_NO]                Row[32] |%s|",Row1[32]);
                        logDebug2("[BID3_TYPE]                  Row[33] |%s|",Row1[33]);
                        logDebug2("[BID3_CUTOFF]                Row[34] |%s|",Row1[34]);
                        logDebug2("[BID3_STATUS]                Row[35] |%s|",Row1[35]);
                        logDebug2("[BID3_REASON]                Row[36] |%s|",Row1[36]);
                        logDebug2("[REASON]                     Row[37] |%s|",Row1[37]);
                        logDebug2("[CUTOFF]                     Row[38] |%s|",Row1[38]);
                        logDebug2("[SOURCE_FLG]                 Row[39] |%s|",Row1[39]);
                        logDebug2("[INSTRUMENT_NAME]            Row[40] |%s|",Row1[40]);
                        logDebug2("[SERIES]                     Row[41] |%s|",Row1[41]);
                        logDebug2("[PRO_CLIENT]                 Row[42] |%s|",Row1[42]);
                        logDebug2("[LOW_BAND]                   Row[43] |%s|",Row1[43]);
                        logDebug2("[HIGH_BAND]                  Row[44] |%s|",Row1[44]);
                        logDebug2("[MIN_BID_LOT]                Row[45] |%s|",Row1[45]);
                        logDebug2("[UPI_ID]                     Row[46] |%s|",Row1[46]);
                        logDebug2("[ISSUE_ID]                   Row[47] |%s|",Row1[47]);
                        logDebug2("[ISSUE_TYPE]                 Row[48] |%s|",Row1[48]);
                        logDebug2("[QTY_MUL]                    Row[49] |%s|",Row1[49]);
                        logDebug2("[LOCATIONCODE]               Row[50] |%s|",Row1[50]);
                        logDebug2("[BANKCODE]                   Row[51] |%s|",Row1[51]);
                        logDebug2("[BANKNAME]                   Row[52] |%s|",Row1[52]);
                        logDebug2("[LOCNAME]                    Row[53] |%s|",Row1[53]);
                        logDebug2("[RETAILFLAG]                 Row[54] |%s|",Row1[54]);
                        logDebug2("[CATEGORY]                   Row[55] |%s|",Row1[55]);
                        logDebug2("[PAYMENT_STATUS_REASON]      Row[56] |%s|",Row1[56]);
                        logDebug2("[UPI_STATUS]                 Row[57] |%s|",Row1[57]);
                        logDebug2("[UPI_AMT_BLOCK]              Row[58] |%s|",Row1[58]);
                        logDebug2("[CLIENT_NAME]                Row[59] |%s|",Row1[59]);
                        logDebug2("[ALLOTED_QTY]                Row[60] |%s|",Row1[60]);

                        fprintf(fpFile,"%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s \n", Row1[0],Row1[1],Row1[2],Row1[3],Row1[4],Row1[5],Row1[6],Row1[7],Row1[8],Row1[9],Row1[10],Row1[11],Row1[12],Row1[13],Row1[14],Row1[15],Row1[16],Row1[17],Row1[18],Row1[19],Row1[20],Row1[21],Row1[22],Row1[23],Row1[24],Row1[25],Row1[26],Row1[27],Row1[28],Row1[29],Row1[30],Row1[31],Row1[32],Row1[33],Row1[34],Row1[35],Row1[36],Row1[37],Row1[38],Row1[39],Row1[40],Row1[41],Row1[42],Row1[43],Row1[44],Row1[45],Row1[46],Row1[47],Row1[48],Row1[49],Row1[50],Row1[51],Row1[52],Row1[53],Row1[54],Row1[55],Row1[56],Row1[57],Row1[58],Row1[59],Row1[60]);

                }
        }
        mysql_free_result(Res1);

        fprintf(fpFile,"*");
        fclose(fpFile);

        sprintf(sCommand,"rm  %s/%s%s.zip",sRRPath,pIpoOrdBookReq->sEntityId,sCurTime);
        logDebug2("sCommand 1:%s:",sCommand);
        system(sCommand);

        memset(&sCommand,'\0',200);
        sprintf(sCommand,"zip -P %s %s/%s%s.zip %s",ZIP_PASSWORD,sRRPath,pIpoOrdBookReq->sEntityId,sCurTime,sFileName);
        logDebug2("sCommand 2:%s:",sCommand);
        system(sCommand);

        memset(&sCommand,'\0',200);
        sprintf(sCommand,"rm  %s",sFileName);
        logDebug2("sCommand 3:%s:",sCommand);
        system(sCommand);

        sprintf(pIpoOrdBookRes.sFilename,"%s%s.zip",pIpoOrdBookReq->sEntityId,sCurTime);
        pIpoOrdBookRes.IntRespHeader.iSeqNo = 0;
        pIpoOrdBookRes.IntRespHeader.iMsgLength = sizeof(struct ORDER_BOOK_REPORT_RESPONSE);
        pIpoOrdBookRes.IntRespHeader.iErrorId = 0;
        pIpoOrdBookRes.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_ORDER_REPORT_RESP;
        pIpoOrdBookRes.IntRespHeader.iUserId = pIpoOrdBookReq->ReqHeader.iUserId;
        strncpy(pIpoOrdBookRes.sPath,sRRPath,PATH_LEN);

        logDebug2("pIpoOrdBookRes.IntRespHeader.iMsgLength = |%d|",pIpoOrdBookRes.IntRespHeader.iMsgLength);
        logDebug2("pIpoOrdBookRes.IntRespHeader.iMsgCode = |%d|", pIpoOrdBookRes.IntRespHeader.iMsgCode);
        logDebug2("pIpoOrdBookRes.IntRespHeader.iUserId = |%d|",pIpoOrdBookRes.IntRespHeader.iUserId);
        logDebug2("pIpoOrdBookRes.sPath = |%s|",pIpoOrdBookRes.sPath);
        logDebug2("pIpoOrdBookRes.sFilename = |%s|",pIpoOrdBookRes.sFilename);

        iRelayID = find_admin_adapter(pIpoOrdBookRes.IntRespHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if((WriteMsgQ(iTrdRtrToRel,(CHAR *)&pIpoOrdBookRes, sizeof(struct ORDER_BOOK_REPORT_RESPONSE ), iRelayID)) != TRUE )
        {
                logFatal("Error : WriteMsgQ failed in SendRespToFE.");
                exit(ERROR);
        }

        logTimestamp("Exit : [fIpoOrderReport]");
        return TRUE;
}

BOOL fLoadEnv()
{
        logTimestamp("Entry : fLoadEnv");
        if(getenv("RRFILE_PATH")==NULL)
        {
                logFatal("Error : Environment variables missing : RRFILE_PATH");
                exit(ERROR);
        }
        else
        {
                strcpy ( sRRPath , getenv("RRFILE_PATH"));
                logDebug2("sRRPath :%s:",sRRPath);
        }
        logTimestamp("Exit : fLoadEnv");
        return TRUE;
}
