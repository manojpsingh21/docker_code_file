#include <sys/socket.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
BOOL SendBusinessRejectFor(CHAR *In);
void ProcessPackets();
void RecievePackets();

LONG32		iDWSMediatorToDWSAdap;
LONG32     	iDWSAdapToDWSMediator;

pthread_t   th_id1;
pthread_t   th_id2;
pthread_t   th_id3;


LONG32  iSocket;
INT16   iMsgType;
BOOL	isConnected;

int main(LONG32 argc, CHAR **argv)
{
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iRetval, iPort;
	LONG32  Signal;
	LONG32	iSockfd, iFlag;
	CHAR	sServerIp[IP_ADDR_LEN];

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logInfo(" PARAMETERS COUNT : %d", argc ) ;
	iPort = atoi(argv[1]) ;
	iMsgType     = atoi(argv[2]);
	strncpy(sServerIp,argv[3],IP_ADDR_LEN);

	logDebug3(" PORT : %d", iPort ) ;
	logDebug3(" Msg Type : %d", iMsgType) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);

	OpenMsgQue();

	ConnectionDOWN();

	if ((iSockfd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		logFatal(" Error in creating the iSocket");
		exit(ERROR);
	}
	logDebug3(" Socket Created : %d", iSockfd);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iPort);
	servadd.sin_addr.s_addr = inet_addr(sServerIp);

	for ( ; ; )
	{
		signal(SIGPIPE,SIG_IGN);
		signal(SIGHUP,SIG_IGN);

		if((pthread_create(&th_id1,NULL,ProcessPackets,NULL)!= 0))
		{
			printf("\n pthread_create:ProcessPackets");
			exit(ERROR);
		}
		for ( ; ; )
		{
			ConnectionDOWN();
			//iSockfd =CONNECT( sServerIp , iServerPort );
			if (connect(iSockfd,&servadd,sizeof(servadd)) < 0)	
				if (iSockfd <= 0 )
				{
					logError("Failed To connect.");
					sleep(2);
				}
				else
				{
					iFlag=100000;
					if (setsockopt( iSockfd ,SOL_SOCKET,SO_RCVBUF,&iFlag,sizeof( iFlag ))<0)
					{
						logDebug2("Error in setting socket option:SO_  RCVBUF");
						return FALSE;
					}
					if (setsockopt( iSockfd ,SOL_SOCKET,SO_SNDBUF,&iFlag,sizeof( iFlag ))<0)
					{
						logDebug2("Error in setting socket option:SO_SNDBUF");
						return FALSE;
					}

					ConnectionUP();
					if((pthread_create(&th_id2,NULL,RecievePackets,NULL)!= 0))
					{
						printf("\n pthread_create:SocketToQueueThread");
						exit(ERROR);
					}

				} /**End of else **/

		} /**end of inner for loop **/

		sigprocmask ( SIG_BLOCK, &SequenceSet, NULL);
		while( TRUE )
		{
			printf("Waiting For Signal");
			mainwait = sigwait( &SequenceSet,&Signal);
			printf("\n Caught Signal : %d", Signal);
			if ( Signal == SIGTERM )
			{
				printf("\n SIGTERM in Main");
				ConnectionDOWN();
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sleep(2);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}
			else if(Signal == SIGUSR1)
			{
				printf("\n SIGUSR1 in Main");
				pthread_cancel(th_id1);
				pthread_cancel(th_id2);
				pthread_join(th_id1,NULL);
				pthread_join(th_id2,NULL);
				sigprocmask ( SIG_UNBLOCK, &SequenceSet, NULL);
				close(iSocket);
				printf("\n Break from loop");
				break;
			}
			else
			{
				printf("\n Received some other signal");
				printf("\n Closing Socket");
				ConnectionDOWN();
				close(iSocket);
				printf("\n Exiting");
				exit(ERROR);
			}
		}/** End of While loop ***/
	}        /**End of for loop **/
	logTimestamp("Exit : Main");
} 

void ProcessPackets()
{
	LONG32  iRetval;
	CHAR    fwdStr[RUPEE_MAX_PACKET_SIZE];

	while(1)
	{
		printf("\n ================== Waiting on the Queue =====================");
		memset(fwdStr, '\0', RUPEE_MAX_PACKET_SIZE);
		if ((iRetval=ReadMsgQ(iDWSAdapToDWSMediator, &fwdStr, RUPEE_MAX_PACKET_SIZE, iMsgType))== ERROR)
		{
			printf("\n ERROR in receiving the Data from the Q %d", iDWSAdapToDWSMediator);
			exit(ERROR);
		}

		printf("\n Data Received from Queue");

		if(isConnected)
		{
			if ((iRetval = Send(iSocket, fwdStr, strlen(fwdStr), 0)) == FALSE)
			{
				printf("\n ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
				//SendBusinessRejectFor(FixString);
				RestartProcess();
				break;
			}
		}
		else
		{
			///Send Rejection
		}
		printf("\n Sent to DWSServer");
	}
}

void RecievePackets()
{
	LONG32  iRetval=-1,iLen;
	CHAR    rcvStr[RUPEE_MAX_PACKET_SIZE], peekString[MAX_PEEK_SIZE+1],tempString[MAX_PEEK_SIZE+1];;
	CHAR    cMsgType, *tempPtr;
	LONG32  dcount = 0,i;
	LONG32 loopcount=0;

	while(1)
	{
		memset(rcvStr, '\0', RUPEE_MAX_PACKET_SIZE);
		memset(peekString, '\0', MAX_PEEK_SIZE+1);
		memset(tempString, '\0', MAX_PEEK_SIZE+1);

		iLen    =   MAX_PEEK_SIZE;
		printf("\n ================== Reading From socket %d ==============loopcount :%d iRetval:%d", iSocket,loopcount++,iRetval);

		if ((iRetval = Recv(iSocket, peekString, &iLen, MSG_PEEK)) == FALSE)
		{
			printf("\n Dropped Exchange Response while Peeking from Socket");
			printf("\n Error in receiving the Data from the Socket on PEEK");
			printf("\n iRetval in peek %d:",iRetval);
			RestartProcess();
			break;
		}

		memcpy(tempString,peekString,MAX_PEEK_SIZE);
		printf("\n iRetval in peek %d:",iRetval);
		printf("\nMSG_PEEK String :[%s]",tempString);

		iLen=  ((struct INT_COMMON_REQUEST_HDR *)tempString)->iMsgLength;
		printf("\nLen = %d iSocket=%d",iLen, iSocket);

		if ((iRetval = Recv(iSocket, rcvStr, &iLen, 0)) == -1)
		{
			printf("\n Dropped Exchange Response while Receiving on Socket");
			printf("\n Error in receiving the Data from the Socket");
			/*** We do not need to send to Fwd or Rev this message ***/
			RestartProcess();
			break;
		}

		if ((iRetval=WriteMsgQ(iDWSMediatorToDWSAdap,rcvStr,iLen,1))== ERROR)
		{
			printf("\n Dropped Response while Sending it to RevMap");
			RestartProcess();
			break;
		}
	}
	close(iSocket);
}

void RestartProcess()
{
	isConnected = FALSE ;
	ConnectionDOWN();
	printf("getpid :%d:",getpid());
	kill(getpid(), SIGUSR1);
	printf("\n Sent Signal %d To pid %d", SIGUSR1, getpid());
	return;
}

BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{

		printf("\n sending fix msg :%d: socketid :%d:", TotalLen,Socketfd);
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		printf("\n After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	printf("\n Trying to Recv = %d", *RecvLen);
	while(TotalLen < *RecvLen)
	{
		printf("\n Trying to recv %d bytes socketid :%d:", BytesLeft,Socketfd);
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("recv: Error is");
			return FALSE;
		}
		printf("\n After recv Bytes = %d", Bytes);
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	/***** logDebug1("Recv Successful Return True"); *****/
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

void ConnectionUP()
{
	isConnected = TRUE;
	return;
}

void ConnectionDOWN()
{	
	isConnected = FALSE;
	return;
}

	void OpenMsgQue(){
		if( ( iDWSAdapToDWSMediator = OpenMsgQ( (DWSAdapToDWSMediator))) == ERROR )
		{
			perror("Open RelToDirQ :");
			exit( 1 );
		}
		logDebug1(" iDWSAdapToDWSMediator created sucesfully wid Qid :%d:",iDWSAdapToDWSMediator);

		if( ( iDWSMediatorToDWSAdap = OpenMsgQ( (DWSMediatorToDWSAdap))) == ERROR )
		{
			perror("Open RelToDirQ :");
			exit( 1 );
		}
		logDebug1(" iDWSMediatorToDWSAdap queue opened sucessfully with queuue id :%d:",iDWSMediatorToDWSAdap);

	}
