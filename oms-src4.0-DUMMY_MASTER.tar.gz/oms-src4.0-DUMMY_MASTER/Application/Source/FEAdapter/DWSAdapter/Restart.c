#include<stdio.h>
int main()
{

	char c_aCommand[150];
	FILE *fppopen;
	char sretval[500];
	int iretval = 0;

//	memset ( c_aCommand ,'\0',150);
//	memset ( sretval,'\0',500);

	

	printf(" Process is Going To restart \n");
	sprintf (c_aCommand ,"../../../Exec/MonitoringTools/RestartProcess.sh RupeeDaemon");
	printf(" c_aCommand :%s:\n",c_aCommand);
	fppopen = popen(c_aCommand, "r");
	fscanf(fppopen, "%s",sretval);
	pclose(fppopen);
	printf(" sretval = [%s]",sretval);


}
