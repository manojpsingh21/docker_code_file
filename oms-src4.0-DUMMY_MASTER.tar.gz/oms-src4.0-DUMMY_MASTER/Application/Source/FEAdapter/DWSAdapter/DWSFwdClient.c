#include <sys/socket.h>
#include <malloc.h>
#include <errno.h>
#include "IPCS.h"

BOOL    Recv(LONG32 Socketfd, CHAR *RecvData, LONG32 *RecvLen, SHORT Flags);
BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags);

void ConnectionUP();
void ConnectionDOWN();
void RestartProcess();
BOOL SendBusinessRejectFor(CHAR *In);

LONG32  iDWSAdapToDWSFwd = 0;
LONG32  isConnected = FALSE;

pthread_t   th_id1;
pthread_t   th_id2;

LONG32  iSocket;
INT16   iMsgType;
CHAR    cSegment;

int main(LONG32 argc, CHAR **argv)
{
	LONG32  size=512*1024;
	struct  sockaddr_in cliadd, servadd;
	CHAR    FixString[FIX_MAX_STRING_LEN];
	LONG32  mainwait = -1, sig1=0;

	sigset_t SequenceSet;
	LONG32  iMasterSocket,iRetval, iMaster_Port;
	LONG32  Signal;

	setbuf(stdout, NULL);
	setbuf(stdin, NULL );
	setvbuf( stdout, NULL, _IONBF, 0 );

	logInfo(" PARAMETERS COUNT : %d", argc ) ;
	iMaster_Port = atol(argv[1]) ;
	iMsgType     = atoi(argv[2]);
	cSegment        = argv[3][0];

	logDebug3(" PORT : %d", iMaster_Port ) ;
	logDebug3(" Msg Type : %d", iMsgType) ;

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset ( &SequenceSet );
	sigaddset ( &SequenceSet, SIGTERM);
	sigaddset ( &SequenceSet, SIGUSR1);

	OpenMsgQue();

	if ((iMasterSocket=socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket: ");
		logFatal(" Error in creating the iMasterSocket");
		exit(ERROR);
	}
	logDebug3(" Socket Created : %d", iMasterSocket);

	memset((CHAR *)&servadd, '0', sizeof(struct sockaddr_in));
	servadd.sin_family      = AF_INET;
	servadd.sin_port        = htons(iMaster_Port);
	servadd.sin_addr.s_addr = htonl(INADDR_ANY);

	iRetval = 1;
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iRetval, sizeof(iRetval)) == ERROR)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_REUSEADDR:");
		exit(1);
	}
	/************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_RCVBUF:");
		exit(1);
	}

	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}
	/**************************************/
	if (setsockopt(iMasterSocket, SOL_SOCKET, SO_KEEPALIVE, (char *)&size, sizeof(size))<0)
	{
		perror("setsockopt: ");
		logFatal(" Error in setsockopt on the MasterSocket:SO_SNDBUF:");
		exit(1);
	}

	if( bind(iMasterSocket, (struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("bind: ");
		logFatal(" Error in binding to the iMasterSocket");
		exit(ERROR);
	}

	ConnectionDOWN();
	listen(iMasterSocket, 1);
	while(1)
	{
		memset((CHAR *)&cliadd, '\0', sizeof(struct sockaddr_in));
		ConnectionDOWN();

		printf("\n ============= Waiting for FIX Engine to connect on port : %d ===========", iMaster_Port);
		iRetval = sizeof(struct sockaddr);
		printf("\n iSocket %d:",iSocket);
		if ((iSocket = accept(iMasterSocket, (struct sockaddr *)&cliadd, &iRetval)) < 0)
		{
			perror("accept: ");
			printf("\n Error in accepting the connection %d", errno);
			continue;
		}

		printf("\n New Socket Connection Established on : %d", iSocket);

		isConnected = TRUE ;
		ConnectionUP();
		SendPackets();

		printf("\n Socket Connection closed on : %d", iSocket);
		printf("\n While Loop");
	}
}

void SendPackets()
{
	LONG32  iRetval;
	CHAR    fwdStr[RUPEE_MAX_PACKET_SIZE];

	while(1)
	{
		printf("\n ================== Waiting on the Queue =====================");
		memset(fwdStr, '\0', RUPEE_MAX_PACKET_SIZE);
		if ((iRetval=ReadMsgQ(iDWSAdapToDWSFwd, &fwdStr, RUPEE_MAX_PACKET_SIZE, iMsgType))== ERROR)
		{
			printf("\n ERROR in receiving the Data from the Q %d", iDWSAdapToDWSFwd);
			exit(ERROR);
		}

		printf("\n Data Received from Queue");

		if ((iRetval = Send(iSocket, fwdStr, strlen(fwdStr), 0)) == FALSE)
		{
			printf("\n ERROR IN SENDING THE DATA TO SOCKET iSocket :%d",iSocket);
			SendBusinessRejectFor(FixString);
			RestartProcess();
			break;
		}
		printf("\n Sent to DWSServer");
	}
}

void RestartProcess()
{
	isConnected = FALSE ;
	ConnectionDOWN();
	printf("getpid :%d:",getpid());
	kill(getpid(), SIGUSR1);
	printf("\n Sent Signal %d To pid %d", SIGUSR1, getpid());
	return;
}

BOOL    Send(LONG32 Socketfd, CHAR *SendData, LONG32 *SendLen, SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{

		printf("\n sending fix msg :%d: socketid :%d:", TotalLen,Socketfd);
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("send: Error is");
			return FALSE;
		}
		printf("\n After send Bytes = %d", Bytes);

		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;                                            /* return -1 on failure, 0 on success*/
}

void ConnectionUP()
{
	return;
}

void ConnectionDOWN()
{
	return;
}

	void OpenMsgQue(){
		if((iDWSAdapToDWSFwd = OpenMsgQ(DWSAdapToDWSMediator)) == ERROR)
		{
			perror("OpenMsgQ ...DWSAdapToDWSFwd");
			exit(ERROR);
		}
		printf("\n DWSAdapToDWSMediator opened successfully with id = %d", iDWSAdapToDWSMediator);

		if((iDWSFwdToDWSAdap = OpenMsgQ(DWSMediatorToDWSAdap)) == ERROR)
		{
			perror("OpenMsgQ ...DWSMediatorToDWSAdap");
			exit(ERROR);
		}
		printf("\n DWSMediatorToDWSAdap opened successfully with id = %d", iDWSFwdToDWSAdap);
	}
