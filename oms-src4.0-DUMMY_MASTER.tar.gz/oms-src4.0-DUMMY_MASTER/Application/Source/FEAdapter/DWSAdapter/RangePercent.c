#include <string.h>
#include <my_global.h>
#include <mysql.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include "IPCS.h"
#include "DWSAdapter.h"

LONG32  iAdapToQry;
LONG32  iQryToAdap;
LONG32  iRelayID;
MYSQL   *DBQury;

MYSQL_RES       *Res;
MYSQL_ROW       Row;

main (int argc, char *argv)
{
	logTimestamp("Entry : Main");
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	DBQury = DB_Connect();

	if(mysql_set_server_option(DBQury,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		return FALSE;
	}


	fOpenMesgQ();
	fMapper();
	logTimestamp("Exit : Main");
}

BOOL    fMapper()
{
	logTimestamp("Entry : Mapper");

	struct  VIEW_DWS_COBO_RANGE_HDR_REQUEST *pSlrangeHdr;
	struct VIEW_DWS_COBO_RANGE_HDR_RESP   pSlrangeRespHdr;
	CHAR 	sSelQry1[MAX_QUERY_SIZE];
	CHAR    sSelQry2[MAX_QUERY_SIZE];
	CHAR    RcvMsg[LOCAL_MAX_PACKET_SIZE];
	LONG32  iMsgCode;
	LONG32  iRetVal;
	CHAR	sBasketCode[BASKET_LEN];
	memset(sBasketCode,'\0',BASKET_LEN);
	memset(sSelQry1,'\0',MAX_QUERY_SIZE);
	memset(sSelQry2,'\0',MAX_QUERY_SIZE);
	memset(pSlrangeHdr,'\0',sizeof(struct  VIEW_DWS_COBO_RANGE_HDR_REQUEST));
	memset(&pSlrangeRespHdr,'\0',sizeof(struct VIEW_DWS_COBO_RANGE_HDR_RESP));


	memset(&RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE);

	if((ReadMsgQ(iAdapToQry, &RcvMsg, LOCAL_MAX_PACKET_SIZE,0)) != TRUE)
	{
		logFatal("Error : MsgQId is %d",iAdapToQry);
		exit(ERROR);
	}

	pSlrangeHdr =(struct VIEW_DWS_COBO_RANGE_HDR_REQUEST *) &RcvMsg ;

	logDebug2("pSlrangeHdr.pReqHeader->iSeqNo = %d",pSlrangeHdr->pReqHeader.iSeqNo);
	logDebug2("pSlrangeHdr.pReqHeader->iMsgLength= %d",pSlrangeHdr->pReqHeader.iMsgLength);
	logDebug2("pSlrangeHdr.pReqHeader->iMsgCode= %d",pSlrangeHdr->pReqHeader.iMsgCode);
	logDebug2("pSlrangeHdr.pReqHeader->sExcgId= %s",pSlrangeHdr->pReqHeader.sExcgId);
	logDebug2("pSlrangeHdr.pReqHeader->iUserId= %d",pSlrangeHdr->pReqHeader.iUserId);
	logDebug2("pSlrangeHdr.pReqHeader->cSource= %c",pSlrangeHdr->pReqHeader.cSource);
	logDebug2("pSlrangeHdr.pReqHeader->cSegment= %d",pSlrangeHdr->pReqHeader.cSegment);
	logDebug2("pSlrangeHdr->sClientId = %s",pSlrangeHdr->sClientId);
	logDebug2("pSlrangeHdr->sEntityId = %s",pSlrangeHdr->sEntityId);
	logDebug2("pSlrangeHdr->sScriptCode = %s",pSlrangeHdr->sScriptCode);	

	sprintf(sSelQry1,"SELECT(CASE \'%c'\ when 'V' then RPM_CO_BASKET \ 
		When 'B' then RPM_BO_BASKET END) FROM RMS_RISK_PROFILE_MAST R, ENTITY_MASTER,\ 
			WHERE R.RPM_CODE = ENTITY_RISK_PROFILE \
			AND ENTITY_CODE = LTRIM(RTRIM(\"%s\"));",pSlrangeHdr->cProductId,pSlrangeHdr->sClientId);

	logDebug2("SelQry1 = %s",sSelQry1);
	if (mysql_query(DBQury, sSelQry1) != SUCCESS)
	{
		logSqlFatal("Error in select Qry1");
		sql_Error(DBQury);
		exit(ERROR);;
	}
	Res = mysql_store_result(DBQury);
	Row = mysql_fetch_row(Res);
	logDebug2("Row[0] = %s",Row[0]);
	strncpy(sBasketCode,Row[0],BASKET_LEN);
	logDebug2("sBasketCode = %s",sBasketCode);


	if(pSlrangeHdr->cProductId == PROD_COVER)
	{
		sprintf(sSelQry2,"SELECT RSMB_SL_RANGE FROM RMS_SCRIP_MARGIN_BASKET WHERE RSMB_BASKET_CODE = \"%s\" and RSMB_SEGMENT = \'%c\' \
				and RSMB_SCRIP_CODE = \"%s\" and RSMB_EXCH_ID = \"%s\" and RSMB_BUY_SELL = \'%c\' ",sBasketCode,pSlrangeHdr->pReqHeader.cSegment,\
				pSlrangeHdr->sScriptCode,pSlrangeHdr->pReqHeader.sExcgId,pSlrangeHdr->cBuySell);

		logDebug2("SelQry2 = %s",sSelQry2);

		if (mysql_query(DBQury, sSelQry1) != SUCCESS)
		{
			logSqlFatal("Error in select Qry1");
			sql_Error(DBQury);
			pSlrangeRespHdr.IntRespHeader.iMsgCode = TC_INT_COBO_RANGE_ERROR_RESP;
			exit(ERROR);
		}
		logDebug2("Success In Select Query");
		Res = mysql_store_result(DBQury);
		Row = mysql_fetch_row(Res);
		logDebug2("Row[0] = %f",atof(Row[0]));
		pSlrangeRespHdr.fSLRange = atof(Row[0]);
		logDebug2(" pSlrangeRespHdr.fSLRange= %f", pSlrangeRespHdr.fSLRange);		
		pSlrangeRespHdr.IntRespHeader.iMsgCode = TC_INT_COBO_RANGE_RESP;

	}
	else if(pSlrangeHdr->cProductId == PROD_BRACKET)
	{
		sprintf(sSelQry2,"SELECT RSMB_SL_RANGE,RSMB_PROFIT_RANGE FROM RMS_SCRIP_MARGIN_BASKET WHERE RSMB_BASKET_CODE = \"%s\" and RSMB_SEGMENT = \'%c\' \
				and RSMB_SCRIP_CODE = \"%s\" and RSMB_EXCH_ID = \"%s\" and RSMB_BUY_SELL = \'%c\' ",sBasketCode,pSlrangeHdr->pReqHeader.cSegment,\
				pSlrangeHdr->sScriptCode,pSlrangeHdr->pReqHeader.sExcgId,pSlrangeHdr->cBuySell);

		logDebug2("SelQry2 = %s",sSelQry2);
		if (mysql_query(DBQury, sSelQry2) != SUCCESS)
		{
			logSqlFatal("Error in select SelQry2");
			sql_Error(DBQury);
			pSlrangeRespHdr.IntRespHeader.iMsgCode = TC_INT_COBO_RANGE_ERROR_RESP;
			exit(ERROR);

		}
		else
		{
			logDebug2("Success In Select Query");

		}
		Res = mysql_store_result(DBQury);
		Row = mysql_fetch_row(Res);
		logDebug2("Row[0] = %f",atof(Row[0]));
		pSlrangeRespHdr.fSLRange = atof(Row[0]);
		pSlrangeRespHdr.fPLRange = atof(Row[1]);
		logDebug2(" pSlrangeRespHdr.fSLRange = %f", pSlrangeRespHdr.fSLRange);							
		logDebug2(" pSlrangeRespHdr.fPLRange = %f", pSlrangeRespHdr.fPLRange);							
		pSlrangeRespHdr.IntRespHeader.iMsgCode = TC_INT_COBO_RANGE_RESP;
	}
	pSlrangeRespHdr.IntRespHeader.iSeqNo = pSlrangeHdr->pReqHeader.iSeqNo;
	pSlrangeRespHdr.IntRespHeader.iMsgLength= pSlrangeHdr->pReqHeader.iMsgLength;
	strncpy(pSlrangeRespHdr.IntRespHeader.sExcgId,pSlrangeHdr->pReqHeader.sExcgId,EXCHANGE_LEN);
	pSlrangeRespHdr.IntRespHeader.iUserId = pSlrangeHdr->pReqHeader.iUserId;
	pSlrangeRespHdr.IntRespHeader.cSource = pSlrangeHdr->pReqHeader.cSource;
	pSlrangeRespHdr.IntRespHeader.cSegment = pSlrangeHdr->pReqHeader.cSegment;

	logDebug2("pSlrangeRespHdr.IntRespHeader.iSeqNo = %d",pSlrangeRespHdr.IntRespHeader.iSeqNo);
	logDebug2("pSlrangeRespHdr.IntRespHeader.iMsgLength= %d",pSlrangeRespHdr.IntRespHeader.iMsgLength);
	logDebug2("pSlrangeRespHdr.IntRespHeader.iMsgCode= %d",pSlrangeRespHdr.IntRespHeader.iMsgCode);
	logDebug2("pSlrangeRespHdr.IntRespHeader.sExcgId= %s",pSlrangeRespHdr.IntRespHeader.sExcgId);
	logDebug2("pSlrangeRespHdr.IntRespHeader.iUserId= %d",pSlrangeRespHdr.IntRespHeader.iUserId);
	logDebug2("pSlrangeRespHdr.IntRespHeader.cSource= %c",pSlrangeRespHdr.IntRespHeader.cSource);
	logDebug2("pSlrangeRespHdr.IntRespHeader.cSegment= %d",pSlrangeRespHdr.IntRespHeader.cSegment);	


	if((WriteMsgQ(iQryToAdap,(CHAR *)&pSlrangeRespHdr, sizeof(struct VIEW_DWS_COBO_RANGE_HDR_RESP) ,1 ) != TRUE ))
	{
		// perror("Error : WriteMsgQ = %d ",iQryToAdap);
		exit(ERROR);
	}


	logTimestamp("Exit : Mapper");
}

fOpenMesgQ()
{
	logTimestamp("Entry : fOpenMesgQ");

	if((iAdapToQry = OpenMsgQ(AdapToRangeQry)) == ERROR)
	{
		perror("Open AdapToRangeQry");
		exit(ERROR);
	}
	if((iQryToAdap= OpenMsgQ(RangeQryToAdap)) == ERROR)
	{
		perror("Open RangeQryToAdap");
		exit(ERROR);
	}

	logTimestamp("Exit  : fOpenMesgQ");
}

