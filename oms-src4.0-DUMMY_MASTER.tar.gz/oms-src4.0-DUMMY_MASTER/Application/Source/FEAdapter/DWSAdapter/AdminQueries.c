#include <my_global.h>
#include <string.h>
#include <mysql.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include "IPCS.h"
#include "AdminAdaptor.h"

//#define LOCAL_MAX_PACKET_SIZE   4096
//#define	QUERY_SIZE		500

LONG32	iAdapToQuery;
LONG32	iTrdRtrToRel;
LONG32	iRelayID;
MYSQL 	*DBQury;

MYSQL_RES       *Res;
MYSQL_ROW       Row;

BOOL    fChckAdminContrlr(CHAR  *sAdminId,CHAR  *sBrcnhId);

FILE *fpFile;
CHAR   sFile[20];
CHAR    sRRPath[100];

LONG32 	i=0,j=0;
main (int argc, char **argv)
{
	logTimestamp("Entry : Main");
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );

	DBQury = DB_Connect();
	fOpenMesgQ();
	fLoadEnv();
	if(argv[1][0] == 'N')
        {
                CreateNeatFile();
        }
        if(argv[1][0] == 'W')
        {
                CreateNowFile();
        }

	fMapper();	        
	logTimestamp("Exit : Main");
}

BOOL 	fMapper()
{
	logTimestamp("Entry : Mapper");

	struct  INT_COMMON_REQUEST_HDR *pReqHeader;

	CHAR    RcvMsg[LOCAL_MAX_PACKET_SIZE];
	LONG32	iMsgCode;
	LONG32  iRetVal;
	while(1)
	{
		logInfo("--============== Ready To Ready Req :%d ==============--",iAdapToQuery);
		//CreateClientFile(&RcvMsg);
		memset(&RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE);
		if((ReadMsgQ(iAdapToQuery, &RcvMsg, LOCAL_MAX_PACKET_SIZE,0)) != TRUE)
		{
			logFatal("Error : MsgQId is %d",iAdapToQuery);
			return FALSE;
		}
		pReqHeader=(struct INT_COMMON_REQUEST_HDR *) &RcvMsg ;

		logDebug2("pReqHeader->iSeqNo = %d",pReqHeader->iSeqNo);
		logDebug2("pReqHeader->iMsgLength= %d",pReqHeader->iMsgLength);
		logDebug2("pReqHeader->iMsgCode= %d",pReqHeader->iMsgCode);
		logDebug2("pReqHeader->sExcgId= %s",pReqHeader->sExcgId);
		logDebug2("pReqHeader->iUserId= %llu",pReqHeader->iUserId);
		logDebug2("pReqHeader->cSource= %c",pReqHeader->cSource);
		logDebug2("pReqHeader->cSegment= %c",pReqHeader->cSegment);


		iMsgCode = pReqHeader->iMsgCode;
		logDebug2("iMsgCode = %d",iMsgCode);

		switch ( iMsgCode )
		{
			case	TC_INT_ADMIN_ORDER_BOOK_REQ	:
			case	TC_INT_ADMIN_BO_ORDER_BOOK_REQ	:
				iRetVal = fOrderBook(&RcvMsg);
				break;

			case	TC_INT_ADMIN_TRADE_BOOK_REQ	:
				iRetVal = fTradBook(&RcvMsg);
				break;

			case	TC_INT_ADMIN_NET_POS_REQ	:
				iRetVal = fNetPosition(&RcvMsg);
				break;
				
			case    TC_INT_ADMIN_SPRD_ORD_BOOK_REQ:
                                iRetVal = fOrderSprdBook(&RcvMsg);
                                break;

			case	TC_INT_ADMIN_VIEW_CLIENT_LIMIT_REQ :
				iRetVal = fViewClientLimit(&RcvMsg);
				break;

			case	TC_INT_ADMIN_CLINET_HOLDING_REQ :
				iRetVal = fClientHolding(&RcvMsg);
				break;

				/**			case	TC_INT_ADMIN_REJECTED_ORDERS_REQ :
				  iRetVal = fRejectedOrders(&RcvMsg);	
				  break;
				 ***/			
			case	TC_INT_ADMIN_MARGIN_SHORTFALL_REQ :
				iRetVal = fMarginShortFall(&RcvMsg);
				break;

			case	TC_INT_ADMIN_PERCENT_MTM_QUERY_REQ :
				iRetVal = fPercentMTM(&RcvMsg);
				break;

			case    TC_INT_ORDER_BOOK_DTLS_REQ :
				logDebug2("Segment :%c:",((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment);
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == EQUITY_SEGMENT)
				{
					iRetVal = fEquOrderBookDtls(&RcvMsg);
				}
				else if (((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == DERIVATIVE_SEGMENT || 
						((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == CURRENCY_SEGMENT)
				{
					iRetVal = fDrvOrderBookDtls(&RcvMsg);
				}
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == COMMODITY_SEGMENT)
				{
					iRetVal = fCOMMOrderBookDtls(&RcvMsg);
				} 
				break;


			case	TC_INT_SPRD_ORDER_BOOK_DTLS_REQ :
				logDebug2("Segment :%c:",((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment);
				if (((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == DERIVATIVE_SEGMENT ||
                                                ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == CURRENCY_SEGMENT)
                                {
                                        iRetVal = fDrvSprdOrderBookDtls(&RcvMsg);
                                }
                                else if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == COMMODITY_SEGMENT)
                                {
                                        iRetVal = fCOMMSprdOrderBookDtls(&RcvMsg);
                                }
                                break;


			case   	TC_INT_ADMIN_ORDER_REPORT_DETAILS_REQUEST :
				logDebug2(" hey u ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.iSegment :%d:",((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment);
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == EQUITY_SEGMENT)
				{
					iRetVal = fEquOrderReportDetails(&RcvMsg);
				}
				else if (((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == DERIVATIVE_SEGMENT || ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == CURRENCY_SEGMENT)
				{
					iRetVal = fDrvOrderReportDetails(&RcvMsg);
				}
				break;	

			case	TC_INT_ADMIN_CIRCUIT_LIMIT_REQ :
				iRetVal = fViewCircuitLimit(&RcvMsg);
				break;

			case	TC_INT_BATCH_PROCESS_REQ :
				iRetVal = fBatchProcess_Req (&RcvMsg);
				break;

			case	TC_INT_ADMIN_PROFILE_MASTER_REQ :
				iRetVal = fProfileMaster(&RcvMsg);
				break;

			case	TC_INT_ADMIN_VIEW_PAYOUT_REPORT_REQ :
				iRetVal = fViewPayOut(&RcvMsg);
				break;

			case	TC_INT_ADMIN_ORDER_REPORT_REQUEST :
				iRetVal = fOrderReport(&RcvMsg);
				break;

			case	TC_INT_ADMIN_TRADE_REPORT_REQUEST:
				iRetVal = fTradeReport(&RcvMsg);
				break;

			case  	TC_INT_ADMIN_IPO_ORDER_BOOK_REQ :
				iRetVal = fIpoOrderBook(&RcvMsg);
				break;

			case	TC_INT_ADMIN_SIP_ORDER_BOOK_REQ :
				iRetVal = fSIPOrderBook(&RcvMsg);
				break;

			case	TC_INT_ADMIN_SIP_ORDER_DETS_REQ :
				iRetVal = fSIPOrderDetails(&RcvMsg);
				break;

			case	TC_INT_ADMIN_SIP_ORDER_TRALS_REQ :
				iRetVal = fSIPOrderTrails(&RcvMsg);
				break;	

			case    TC_INT_ADMIN_CKT_HITTING_HOLDING_REQ:
				iRetVal = fCktHittingHolding(&RcvMsg);
				break;

			case   	TC_INT_ADMIN_CKT_HITTING_NETPOS_REQ :
				iRetVal = fCktHittingNetPosition(&RcvMsg);
				break;

			case	TC_INT_ADMIN_VIEW_CL_MASTER_REQ :
				iRetVal = fViewClientMaster(&RcvMsg);
				break;

			case	TC_INT_ADMIN_LIMIT_DTL_REQ:
				iRetVal = fViewLimitDtls(&RcvMsg);
				break;

			case	TC_INT_ADMIN_FILE_REQ:
				iRetVal = CreateFile(&RcvMsg);
				break;

			case	TC_INT_RESTART_SHEDULER:
				RestartProceess(&RcvMsg);
				break;
			case	TC_INT_ADMIN_VIEW_BR_MASTER_REQ :
				iRetVal = fViewBranchMaster(&RcvMsg);
                                break;
			case 	TC_ADMIN_CLI_CONTRN_RPT_REQ:
				fCliWiseContrationRpt(&RcvMsg);
				break;
			case 	TC_ADMIN_BROK_CONTRN_RPT_REQ:
				fBrokWiseContrationRpt(&RcvMsg);
				break;
			case	TC_ADMIN_DEBIT_CLI_HOLDING_REQ:
				fDebitCliHolding(&RcvMsg);
				break;				
			case	TC_ADMIN_SHORT_OPT_MTM_REQ:
				fShortOptMtm(&RcvMsg);	
				break;
			case    TC_INT_ADMIN_VIEW_SCRIPT_BLOCK_REQ:
                                iRetVal = fViewScriptBlock(&RcvMsg);
                                break;	
			case    TC_INT_ADMIN_DP_HOLDING_REQ:
                                iRetVal = fClientDpHolding(&RcvMsg);
                                break;	
			case    TC_CONV_TO_DEL_DTL_REQ:
                                iRetVal = fViewConvToDelDtl(&RcvMsg);
                                break;

			default :
				logFatal(" Invalid Transcode :%d:",iMsgCode);
				iRetVal = FALSE;
				break;
		}

	}

	logTimestamp("Exit : Mapper");
}

fOpenMesgQ()
{
	logTimestamp("Entry : fOpenMesgQ");

	if((iAdapToQuery = OpenMsgQ(AdaptorToQuery)) == ERROR)	
	{
		perror("Open AdaptorToQuery");
		exit(ERROR);
	}
	if((iTrdRtrToRel= OpenMsgQ(AdminQueriesToAdaptor)) == ERROR)
	{
		perror("Open TrdRtrToRel");
		exit(ERROR);
	}

	logTimestamp("Exit  : fOpenMesgQ");
}

BOOL	fProfileMaster(CHAR *RcvMsg)
{	
	logTimestamp("Entry : fProfileMaster");

	struct	VIEW_PROFILE_MASTER_REQ		*pViewProfileReq;
	struct	VIEW_COMMON_HDR_RESP		pProfileHdrResp;
	struct  VIEW_PROFILE_MASTER_RESP        pViewProfiResp;

	pViewProfileReq = (struct VIEW_PROFILE_MASTER_REQ *)RcvMsg;

	CHAR	sViewProfileQry[MAX_QUERY_SIZE];
	CHAR	sWhere_Clause[QUERY_SIZE]; 
	memset(sViewProfileQry,'\0',MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;	

	logDebug2("pViewProfileReq->sMode = %s",pViewProfileReq->sMode);	
	logDebug2("pViewProfileReq->sProfileID = %s",pViewProfileReq->sProfileID);	

	if(!strcmp(pViewProfileReq->sMode,EDIT_PROFILE))
	{
		sprintf(sWhere_Clause," AND RTRIM (RPM_CODE) = RTRIM (\"%s\") AND RPM_ACTIVE = \'%c\'",pViewProfileReq->sProfileID,YES);
		logDebug2("sWhere_Clause... = %s",sWhere_Clause);	
	}
	else
	{
		sprintf(sWhere_Clause,"AND RPM_ACTIVE = \'%c\'",YES);
		logDebug2("sWhere_Clause = %s",sWhere_Clause);
	}

	sprintf(sViewProfileQry,"SELECT RPM_CODE,RPM_NAME,ifnull(nullif(RPM_VALIDATE,' '),'N') AS RPM_VALIDATE,RPM_ACTIVE,\
			CASE RPM_MRGN_METHOD_EQ WHEN 'MRGN' THEN 'Margin Based' WHEN 'MULT' THEN 'Multiplier Based' END RPM_MRGN_METHOD_EQ,\
			CASE RPM_MRGN_METHOD_FO WHEN 'MRGN' THEN 'Margin Based' WHEN 'MULT' THEN  'Multiplier Based' END RPM_MRGN_METHOD_FO,\ 
			RPM_GEN_MULT,RPM_EQ_MAR_TYPE,RPM_DR_MAR_TYPE,RPM_CD_MAR_TYPE,RPM_COM_MAR_TYPE,RPM_EQ_MARGIN,RPM_DR_MARGIN,RPM_CD_MARGIN,\
			RPM_COM_MARGIN,RPM_EQ_FACTOR,RPM_DR_FACTOR,RPM_CD_FACTOR,RPM_COM_FACTOR,ifnull(nullif(RPM_EQ_BASKET,' '),'NA') AS RPM_EQ_BASKET,\
			ifnull(nullif(RPM_DR_BASKET,' '),'NA') AS RPM_DR_BASKET,RPM_MAX_ORD_QTY,RPM_MAX_LOT,RPM_MAX_ORD_VALUE,RPM_MTM_LOSSPER,\
			RPM_CNC_SELL_BEN_PER,RPM_EXPO_MAR,RPM_COLLATERAL_FLG,RPM_REALIZE_PROFIT,RPM_COLL_FO,MRGFACTEQ,MRGFACTDR,MRGFACTCOM,\
			INTFACTEQ,INTFACTDR,INTFACTCOM,RPM_FUNDLIMITTYPE,RPM_MTOMSQOFFPER,MRGFACTCD,INTFACTCD,RPM_OPT_MKT_ORDER_FLAG,\
			ifnull(RPM_PRODUCT_ENABLED,'0') AS RPM_PRODUCT_ENABLED,ifnull(RPM_SCRIP_BLOCK_BASKET,'NA') AS RPM_SCRIP_BLOCK_BASKET,\
			ifnull(RPM_EQ_CO_FACTOR,'0') AS RPM_EQ_CO_FACTOR,ifnull(RPM_FNO_CO_FACTOR,'0') AS RPM_FNO_CO_FACTOR,\
			ifnull(RPM_CDS_CO_FACTOR,'0') AS RPM_CDS_CO_FACTOR,ifnull(RPM_COM_CO_FACTOR,'0') AS RPM_COM_CO_FACTOR,\
			ifnull(RPM_EQ_CO_SL_PRC_RANGE,'0') AS RPM_EQ_CO_SL_PRC_RANGE,ifnull(RPM_FNO_CO_SL_PRC_RANGE,'0') AS RPM_FNO_CO_SL_PRC_RANGE,\
			ifnull(RPM_CDS_CO_SL_PRC_RANGE,'0') AS RPM_CDS_CO_SL_PRC_RANGE,ifnull(RPM_COM_CO_SL_PRC_RANGE,'0') AS RPM_COM_CO_SL_PRC_RANGE,\ 
			ifnull(RPM_EQ_CO_SL_MIN_TRG_PRC,'0')AS RPM_EQ_CO_SL_MIN_TRG_PRC,ifnull(RPM_FNO_CO_SL_MIN_TRG_PRC,'0') AS RPM_FNO_CO_SL_MIN_TRG_PRC,\
			ifnull(RPM_CDS_CO_SL_MIN_TRG_PRC,'0') AS RPM_CDS_CO_SL_MIN_TRG_PRC,ifnull(RPM_COM_CO_SL_MIN_TRG_PRC,'0') AS RPM_COM_CO_SL_MIN_TRG_PRC,\
			ifnull(RPM_EQ_BO_FACTOR,'0') AS RPM_EQ_BO_FACTOR,ifnull(RPM_FNO_BO_FACTOR,'0') AS RPM_FNO_BO_FACTOR,\
			ifnull(RPM_CDS_BO_FACTOR,'0') AS RPM_CDS_BO_FACTOR,ifnull(RPM_COM_BO_FACTOR,'0') AS RPM_COM_BO_FACTOR,\
			ifnull(RPM_EQ_BO_SL_PRC_RANGE,'0') AS RPM_EQ_BO_SL_PRC_RANGE,ifnull(RPM_FNO_BO_SL_PRC_RANGE,'0') AS RPM_FNO_BO_SL_PRC_RANGE,\
			ifnull(RPM_CDS_BO_SL_PRC_RANGE,'0') AS RPM_CDS_BO_SL_PRC_RANGE,ifnull(RPM_COM_BO_SL_PRC_RANGE,'0') AS RPM_COM_BO_SL_PRC_RANGE,\
			ifnull(RPM_EQ_BO_SL_MIN_TRG_PRC,'0') AS RPM_EQ_BO_SL_MIN_TRG_PRC,ifnull(RPM_FNO_BO_SL_MIN_TRG_PRC,'0') AS RPM_FNO_BO_SL_MIN_TRG_PRC,\
			ifnull(RPM_CDS_BO_SL_MIN_TRG_PRC,'0') AS RPM_CDS_BO_SL_MIN_TRG_PRC,ifnull(RPM_COM_BO_SL_MIN_TRG_PRC,'0') AS RPM_COM_BO_SL_MIN_TRG_PRC,\
			ifnull(RPM_EQ_SQOFF_PRC_RANGE,'0') AS RPM_EQ_SQOFF_PRC_RANGE,ifnull(RPM_FNO_SQOFF_PRC_RANGE,'0') AS RPM_FNO_SQOFF_PRC_RANGE,\
			ifnull(RPM_CDS_SQOFF_PRC_RANGE,'0') AS RPM_CDS_SQOFF_PRC_RANGE,ifnull(RPM_COM_SQOFF_PRC_RANGE,'0') AS RPM_COM_SQOFF_PRC_RANGE,\
			ifnull(RPM_MIN_TRAIL_GAP,'0') AS RPM_MIN_TRAIL_GAP,ifnull(RPM_GROSS_BUY_QTY,'0') AS RPM_GROSS_BUY_QTY,\
			ifnull(RPM_GROSS_SELL_QTY,'0') AS RPM_GROSS_SELL_QTY,ifnull(RPM_GROSS_BUY_VALUE,'0') AS RPM_GROSS_BUY_VALUE,\
			ifnull(RPM_GROSS_SELL_VALUE,'0') AS RPM_GROSS_SELL_VALUE,ifnull(RPM_NET_QTY,'0') AS RPM_NET_QTY,\
			ifnull(RPM_NET_LOT,'0') AS RPM_NET_LOT,ifnull(RPM_NET_BUY_VALUE,'0') AS RPM_NET_BUY_VALUE,\
			ifnull(RPM_NET_SELL_VALUE,'0') AS RPM_NET_SELL_VALUE,ifnull(RPM_TURNOVER,'0') AS RPM_TURNOVER,\
			ifnull(RPM_MIN_ORD_QTY,'0') AS RPM_MIN_ORD_QTY,ifnull(RPM_MIN_ORD_VALUE,'0') AS RPM_MIN_ORD_VALUE,\
			ifnull(RPM_PENDING_BUY_ORD_VALUE,'0') AS RPM_PENDING_BUY_ORD_VALUE,\
			ifnull(RPM_PENDING_SELL_ORD_VALUE,'0') AS RPM_PENDING_SELL_ORD_VALUE,ifnull(RPM_PENDING_ORD_VAL,'0') AS RPM_PENDING_ORD_VAL,\
			ifnull(RPM_DUPLICATE_ORD_FLG,'NA') AS RPM_DUPLICATE_ORD_FLG,ifnull(RPM_TOP_UP_MARGIN,'0') AS RPM_TOP_UP_MARGIN,\
			ifnull(RPM_BUY_OPTION_MULTIPLY,'0') AS RPM_BUY_OPTION_MULTIPLY,RPM_MTM_ALERT_PERC,RPM_MTM_SQ_OFF_PERC,\
			ifnull(nullif(RPM_CO_BASKET,' '),'NA') AS RPM_CO_BASKET,ifnull(nullif(RPM_BO_BASKET,' '), 'NA') AS RPM_BO_BASKET\
			FROM RMS_RISK_PROFILE_MAST where 1=1 %s order by RPM_CODE",sWhere_Clause);

	logDebug2("sViewProfileQry = %s",sViewProfileQry);

	if(mysql_query(DBQury,sViewProfileQry) != SUCCESS)
	{
		logSqlFatal("Error in sViewProfileQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pProfileHdrResp.IntRespHeader.iSeqNo = 0;
	pProfileHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pProfileHdrResp.IntRespHeader.iErrorId = 0;
	pProfileHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_PROFILE_MASTER_HED_RESP;
	pProfileHdrResp.IntRespHeader.iUserId = pViewProfileReq->ReqHeader.iUserId;
	pProfileHdrResp.IntRespHeader.cSource = pViewProfileReq->ReqHeader.cSource;
	pProfileHdrResp.cMsgType = 'H';
	pProfileHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pProfileHdrResp.IntRespHeader.iMsgLength = %d",pProfileHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pProfileHdrResp.IntRespHeader.iMsgCode = %d",pProfileHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pProfileHdrResp.IntRespHeader.iUserId = %llu",pProfileHdrResp.IntRespHeader.iUserId);
	logDebug2("pProfileHdrResp.IntRespHeader.cSource = %c",pProfileHdrResp.IntRespHeader.cSource);
	logDebug2("pProfileHdrResp.iNoofRec = %d",pProfileHdrResp.iNoofRec);

	logDebug2("pViewProfileReq->ReqHeader.iUserId = %llu",pViewProfileReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewProfileReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pProfileHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
	//	return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pViewProfiResp,'\0',sizeof(struct VIEW_PROFILE_MASTER_RESP));
		pViewProfiResp.IntRespHeader.iSeqNo = 0;
		pViewProfiResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_PROFILE_MASTER_RESP);
		pViewProfiResp.IntRespHeader.iErrorId = 0;
		pViewProfiResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_PAYOUT_REPORT_RESP;
		pViewProfiResp.IntRespHeader.iUserId = pViewProfileReq->ReqHeader.iUserId;
		pViewProfiResp.IntRespHeader.cSource = pViewProfileReq->ReqHeader.cSource;

		logDebug2("pViewProfiResp.IntRespHeader.iMsgCode = %d",pViewProfiResp.IntRespHeader.iMsgCode);

		if(iTempNoOfRec <= 1)
		{
			pViewProfiResp.cMsgType = 'T';
		}
		else
		{
			pViewProfiResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{
				strncpy(pViewProfiResp.subProfile[j].sRpmCode,Row[0],RPM_CODE_LEN);
				strncpy(pViewProfiResp.subProfile[j].sRpmName,Row[1],CLIENT_NAME_LEN);
				pViewProfiResp.subProfile[j].cRpmValidate = Row[2][0];	
				strncpy(pViewProfiResp.subProfile[j].sRpmMrgnMethodEq,Row[3],MARGIN_METHOD_LEN);
				strncpy(pViewProfiResp.subProfile[j].sRpmMrgnMethodFo,Row[4],MARGIN_METHOD_LEN);
				pViewProfiResp.subProfile[j].iRpmGenMult = atoi(Row[5]);
				pViewProfiResp.subProfile[j].cRpmEqMarType = Row[6][0];	
				pViewProfiResp.subProfile[j].cRpmDrMarType = Row[7][0];	
				pViewProfiResp.subProfile[j].cRpmCdMarType = Row[8][0];	
				pViewProfiResp.subProfile[j].cRpmComMarType = Row[9][0];	
				pViewProfiResp.subProfile[j].iRpmEqMargin = atoi(Row[10]);
				pViewProfiResp.subProfile[j].iRpmDrMargin = atoi(Row[11]);
				pViewProfiResp.subProfile[j].iRpmCdMargin = atoi(Row[12]);
				pViewProfiResp.subProfile[j].iRpm_Com_Margin = atoi(Row[13]);
				pViewProfiResp.subProfile[j].iRpm_Eq_Factor = atoi(Row[14]);
				pViewProfiResp.subProfile[j].iRpm_Dr_Factor = atoi(Row[15]);
				pViewProfiResp.subProfile[j].iRpm_Cd_Factor = atoi(Row[16]);
				pViewProfiResp.subProfile[j].iRpm_Com_Factor = atoi(Row[17]);
				strncpy(pViewProfiResp.subProfile[j].sRpm_Eq_Basket,Row[18],BASKET_LEN);
				strncpy(pViewProfiResp.subProfile[j].sRpm_Dr_Basket,Row[19],BASKET_LEN);
				pViewProfiResp.subProfile[j].iRpm_Max_Ord_Qty = atoi(Row[20]);
				pViewProfiResp.subProfile[j].iRpm_max_lot = atoi(Row[21]);
				pViewProfiResp.subProfile[j].iRpm_max_ord_value = atoi(Row[22]);
				pViewProfiResp.subProfile[j].iRpm_mtm_lossper = atoi(Row[23]);
				pViewProfiResp.subProfile[j].iRpm_cnc_sell_ben_per = atoi(Row[24]);
				pViewProfiResp.subProfile[j].cRpm_expo_mar = Row[25][0];	
				pViewProfiResp.subProfile[j].cRpm_collateral_flg = Row[26][0];	
				pViewProfiResp.subProfile[j].cRpm_realize_profit = Row[27][0];	
				pViewProfiResp.subProfile[j].cRpm_coll_fo = Row[28][0];	
				pViewProfiResp.subProfile[j].fMrgfacteq = atof(Row[29]);
				pViewProfiResp.subProfile[j].fMrgfactdr = atof(Row[30]);
				pViewProfiResp.subProfile[j].fMrgfactcom = atof(Row[31]);
				pViewProfiResp.subProfile[j].fIntfacteq = atof(Row[32]);
				pViewProfiResp.subProfile[j].fIntfactdr = atof(Row[33]);
				pViewProfiResp.subProfile[j].fIntfactcom = atof(Row[34]);
				pViewProfiResp.subProfile[j].cRpm_active = Row[35][0];	
				pViewProfiResp.subProfile[j].cRpm_fundlimittype = Row[36][0];	
				pViewProfiResp.subProfile[j].iRpm_mtomsqoffper = atoi(Row[37]);
				pViewProfiResp.subProfile[j].fIntfactcd = atof(Row[38]);
				pViewProfiResp.subProfile[j].fMrgfactcd = atof(Row[39]);
				pViewProfiResp.subProfile[j].cRpm_opt_mkt_order_flag = Row[40][0];	
				strncpy(pViewProfiResp.subProfile[j].sRpm_product_enabled,Row[41],PRODUCT_ENABLE_LEN);
				strncpy(pViewProfiResp.subProfile[j].sRpm_scrip_block_basket,Row[42],BASKET_LEN);
				pViewProfiResp.subProfile[j].fRpm_eq_co_factor = atof(Row[43]);
				pViewProfiResp.subProfile[j].fRpm_fno_co_factor = atof(Row[44]);
				pViewProfiResp.subProfile[j].fRpm_cds_co_factor = atof(Row[45]);
				pViewProfiResp.subProfile[j].fRpm_com_co_factor = atof(Row[46]);
				pViewProfiResp.subProfile[j].fRpm_eq_co_sl_prc_range = atof(Row[47]);
				pViewProfiResp.subProfile[j].fRpm_fno_co_sl_prc_range = atof(Row[48]);
				pViewProfiResp.subProfile[j].fRpm_cds_co_sl_prc_range = atof(Row[49]);
				pViewProfiResp.subProfile[j].fRpm_com_co_sl_prc_range = atof(Row[50]);
				pViewProfiResp.subProfile[j].fRpm_eq_co_sl_min_trg_prc = atof(Row[51]);
				pViewProfiResp.subProfile[j].fRpm_fno_co_sl_min_trg_prc = atof(Row[52]);
				pViewProfiResp.subProfile[j].fRpm_cds_co_sl_min_trg_prc = atof(Row[53]);
				pViewProfiResp.subProfile[j].fRpm_com_co_sl_min_trg_prc = atof(Row[54]);
				pViewProfiResp.subProfile[j].fRpm_eq_bo_factor = atof(Row[55]);
				pViewProfiResp.subProfile[j].fRpm_fno_bo_factor = atof(Row[56]);
				pViewProfiResp.subProfile[j].fRpm_cds_bo_factor = atof(Row[57]);
				pViewProfiResp.subProfile[j].fRpm_com_bo_factor = atof(Row[58]);
				pViewProfiResp.subProfile[j].fRpm_eq_bo_sl_prc_range = atof(Row[59]);
				pViewProfiResp.subProfile[j].fRpm_fno_bo_sl_prc_range = atof(Row[60]);
				pViewProfiResp.subProfile[j].fRpm_cds_bo_sl_prc_range = atof(Row[61]);
				pViewProfiResp.subProfile[j].fRpm_com_bo_sl_prc_range = atof(Row[62]);
				pViewProfiResp.subProfile[j].fRpm_eq_bo_sl_min_trg_prc = atof(Row[63]);
				pViewProfiResp.subProfile[j].fRpm_fno_bo_sl_min_trg_prc = atof(Row[64]);
				pViewProfiResp.subProfile[j].fRpm_cds_bo_sl_min_trg_prc = atof(Row[65]);
				pViewProfiResp.subProfile[j].fRpm_com_bo_sl_min_trg_prc = atof(Row[66]);
				pViewProfiResp.subProfile[j].fRpm_eq_sqoff_prc_range = atof(Row[67]);
				pViewProfiResp.subProfile[j].fRpm_fno_sqoff_prc_range = atof(Row[68]);
				pViewProfiResp.subProfile[j].fRpm_cds_sqoff_prc_range = atof(Row[69]);
				pViewProfiResp.subProfile[j].fRpm_com_sqoff_prc_range = atof(Row[70]);
				pViewProfiResp.subProfile[j].fRpm_min_trail_gap = atof(Row[71]);
				pViewProfiResp.subProfile[j].iRpm_gross_buy_qty = atoi(Row[72]);
				pViewProfiResp.subProfile[j].iRpm_gross_sell_qty = atoi(Row[73]);
				pViewProfiResp.subProfile[j].fRpm_gross_buy_value = atof(Row[74]);
				pViewProfiResp.subProfile[j].fRpm_gross_sell_value = atof(Row[75]);
				pViewProfiResp.subProfile[j].iRpm_net_qty = atoi(Row[76]);
				pViewProfiResp.subProfile[j].iRpm_net_lot = atoi(Row[77]);
				pViewProfiResp.subProfile[j].fRpm_net_buy_value = atof(Row[78]);
				pViewProfiResp.subProfile[j].fRpm_net_sell_value = atof(Row[79]);
				pViewProfiResp.subProfile[j].fRpm_turnover = atof(Row[80]);
				pViewProfiResp.subProfile[j].iRpm_min_ord_qty = atoi(Row[81]);
				pViewProfiResp.subProfile[j].fRpm_min_ord_value = atof(Row[82]);
				pViewProfiResp.subProfile[j].fRpm_pending_buy_ord_value = atof(Row[83]);
				pViewProfiResp.subProfile[j].fRpm_pending_sell_ord_value = atof(Row[84]);
				pViewProfiResp.subProfile[j].fRpm_pending_ord_val = atof(Row[85]);
				pViewProfiResp.subProfile[j].cRpm_duplicate_ord_flg = Row[86][0];
				pViewProfiResp.subProfile[j].fRpm_top_up_margin = atof(Row[87]);
				pViewProfiResp.subProfile[j].fRpm_buy_option_multiply = atof(Row[88]);
				pViewProfiResp.subProfile[j].fRpm_mtm_alert_perc = atof(Row[89]);
				pViewProfiResp.subProfile[j].fRpm_mtm_sq_off_perc = atof(Row[90]);
				strncpy(pViewProfiResp.subProfile[j].sRpm_co_basket,Row[91],BASKET_LEN);
				strncpy(pViewProfiResp.subProfile[j].sRpm_bo_basket,Row[92],BASKET_LEN);

				logDebug2("<<<<<<<<<<<<<<<<<<<<<<<<< ...start... >>>>>>>>>>>>>>>>>>>>>>>>>>");
				logDebug2("pViewProfiResp.subProfile[%d].sRpmCode = %s",j,pViewProfiResp.subProfile[j].sRpmCode);
				logDebug2("pViewProfiResp.subProfile[%d].sRpmName = %s",j,pViewProfiResp.subProfile[j].sRpmName);
				logDebug2("pViewProfiResp.subProfile[%d].cRpmValidate = %c",j,pViewProfiResp.subProfile[j].cRpmValidate);
				logDebug2("pViewProfiResp.subProfile[%d].sRpmMrgnMethodEq = %s",j,pViewProfiResp.subProfile[j].sRpmMrgnMethodEq);
				logDebug2("pViewProfiResp.subProfile[%d].sRpmMrgnMethodFo = %s",j,pViewProfiResp.subProfile[j].sRpmMrgnMethodFo);
				logDebug2("pViewProfiResp.subProfile[%d].iRpmGenMult = %d",j,pViewProfiResp.subProfile[j].iRpmGenMult);
				logDebug2("pViewProfiResp.subProfile[%d].cRpmEqMarType = %c",j,pViewProfiResp.subProfile[j].cRpmEqMarType);
				logDebug2("pViewProfiResp.subProfile[%d].cRpmDrMarType = %c",j,pViewProfiResp.subProfile[j].cRpmDrMarType);
				logDebug2("pViewProfiResp.subProfile[%d].cRpmCdMarType = %c",j,pViewProfiResp.subProfile[j].cRpmCdMarType);
				logDebug2("pViewProfiResp.subProfile[%d].cRpmComMarType = %c",j,pViewProfiResp.subProfile[j].cRpmComMarType);
				logDebug2("pViewProfiResp.subProfile[%d].iRpmEqMargin = %d",j,pViewProfiResp.subProfile[j].iRpmEqMargin);
				logDebug2("pViewProfiResp.subProfile[%d].iRpmDrMargin = %d",j,pViewProfiResp.subProfile[j].iRpmDrMargin);
				logDebug2("pViewProfiResp.subProfile[%d].iRpmCdMargin = %d",j,pViewProfiResp.subProfile[j].iRpmCdMargin);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_Com_Margin = %d",j,pViewProfiResp.subProfile[j].iRpm_Com_Margin);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_Eq_Factor = %d",j,pViewProfiResp.subProfile[j].iRpm_Eq_Factor);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_Dr_Factor = %d",j,pViewProfiResp.subProfile[j].iRpm_Dr_Factor);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_Cd_Factor = %d",j,pViewProfiResp.subProfile[j].iRpm_Cd_Factor);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_Com_Factor = %d",j,pViewProfiResp.subProfile[j].iRpm_Com_Factor);
				logDebug2("pViewProfiResp.subProfile[%d].sRpm_Eq_Basket = %s",j,pViewProfiResp.subProfile[j].sRpm_Eq_Basket);
				logDebug2("pViewProfiResp.subProfile[%d].sRpm_Dr_Basket = %s",j,pViewProfiResp.subProfile[j].sRpm_Dr_Basket);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_Max_Ord_Qty = %d",j,pViewProfiResp.subProfile[j].iRpm_Max_Ord_Qty);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_max_lot = %d",j,pViewProfiResp.subProfile[j].iRpm_max_lot);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_max_ord_value = %d",j,pViewProfiResp.subProfile[j].iRpm_max_ord_value);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_mtm_lossper = %d",j,pViewProfiResp.subProfile[j].iRpm_mtm_lossper);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_cnc_sell_ben_per = %d",j,pViewProfiResp.subProfile[j].iRpm_cnc_sell_ben_per);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_expo_mar = %c",j,pViewProfiResp.subProfile[j].cRpm_expo_mar);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_collateral_flg = %c",j,pViewProfiResp.subProfile[j].cRpm_collateral_flg);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_realize_profit = %c",j,pViewProfiResp.subProfile[j].cRpm_realize_profit);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_coll_fo = %c",j,pViewProfiResp.subProfile[j].cRpm_coll_fo);
				logDebug2("pViewProfiResp.subProfile[%d].fMrgfacteq = %lf",j,pViewProfiResp.subProfile[j].fMrgfacteq);
				logDebug2("pViewProfiResp.subProfile[%d].fMrgfactdr = %lf",j,pViewProfiResp.subProfile[j].fMrgfactdr);
				logDebug2("pViewProfiResp.subProfile[%d].fMrgfactcom = %lf",j,pViewProfiResp.subProfile[j].fMrgfactcom);
				logDebug2("pViewProfiResp.subProfile[%d].fIntfacteq = %lf",j,pViewProfiResp.subProfile[j].fIntfacteq);
				logDebug2("pViewProfiResp.subProfile[%d].fIntfactdr = %lf",j,pViewProfiResp.subProfile[j].fIntfactdr);
				logDebug2("pViewProfiResp.subProfile[%d].fIntfactcom = %lf",j,pViewProfiResp.subProfile[j].fIntfactcom);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_active = %c",j,pViewProfiResp.subProfile[j].cRpm_active);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_fundlimittype = %c",j,pViewProfiResp.subProfile[j].cRpm_fundlimittype);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_mtomsqoffper = %d",j,pViewProfiResp.subProfile[j].iRpm_mtomsqoffper);
				logDebug2("pViewProfiResp.subProfile[%d].fIntfactcd = %lf",j,pViewProfiResp.subProfile[j].fIntfactcd);
				logDebug2("pViewProfiResp.subProfile[%d].fMrgfactcd = %lf",j,pViewProfiResp.subProfile[j].fMrgfactcd);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_opt_mkt_order_flag = %c",j,pViewProfiResp.subProfile[j].cRpm_opt_mkt_order_flag);
				logDebug2("pViewProfiResp.subProfile[%d].sRpm_product_enabled = %s",j,pViewProfiResp.subProfile[j].sRpm_product_enabled);
				logDebug2("pViewProfiResp.subProfile[%d].sRpm_scrip_block_basket = %s",j,pViewProfiResp.subProfile[j].sRpm_scrip_block_basket);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_co_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_co_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_co_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_co_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_co_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_co_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_co_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_co_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_co_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_co_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_co_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_co_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_co_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_co_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_co_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_co_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_co_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_co_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_co_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_co_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_co_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_co_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_co_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_co_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_bo_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_bo_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_bo_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_bo_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_bo_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_bo_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_bo_factor = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_bo_factor);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_bo_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_bo_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_bo_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_bo_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_bo_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_bo_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_bo_sl_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_bo_sl_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_bo_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_bo_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_bo_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_bo_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_bo_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_bo_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_bo_sl_min_trg_prc = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_bo_sl_min_trg_prc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_eq_sqoff_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_eq_sqoff_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_fno_sqoff_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_fno_sqoff_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_cds_sqoff_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_cds_sqoff_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_com_sqoff_prc_range = %lf",j,pViewProfiResp.subProfile[j].fRpm_com_sqoff_prc_range);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_min_trail_gap = %lf",j,pViewProfiResp.subProfile[j].fRpm_min_trail_gap);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_gross_buy_qty = %d",j,pViewProfiResp.subProfile[j].iRpm_gross_buy_qty);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_gross_sell_qty = %d",j,pViewProfiResp.subProfile[j].iRpm_gross_sell_qty);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_gross_buy_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_gross_buy_value);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_gross_sell_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_gross_sell_value);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_net_qty = %d",j,pViewProfiResp.subProfile[j].iRpm_net_qty);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_net_lot = %d",j,pViewProfiResp.subProfile[j].iRpm_net_lot);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_net_buy_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_net_buy_value);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_net_sell_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_net_sell_value);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_turnover = %lf",j,pViewProfiResp.subProfile[j].fRpm_turnover);
				logDebug2("pViewProfiResp.subProfile[%d].iRpm_min_ord_qty = %d",j,pViewProfiResp.subProfile[j].iRpm_min_ord_qty);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_min_ord_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_min_ord_value);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_pending_buy_ord_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_pending_buy_ord_value);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_pending_sell_ord_value = %lf",j,pViewProfiResp.subProfile[j].fRpm_pending_sell_ord_value);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_pending_ord_val = %lf",j,pViewProfiResp.subProfile[j].fRpm_pending_ord_val);
				logDebug2("pViewProfiResp.subProfile[%d].cRpm_duplicate_ord_flg = %c",j,pViewProfiResp.subProfile[j].cRpm_duplicate_ord_flg);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_top_up_margin = %lf",j,pViewProfiResp.subProfile[j].fRpm_top_up_margin);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_buy_option_multiply = %lf",j,pViewProfiResp.subProfile[j].fRpm_buy_option_multiply);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_mtm_alert_perc = %lf",j,pViewProfiResp.subProfile[j].fRpm_mtm_alert_perc);
				logDebug2("pViewProfiResp.subProfile[%d].fRpm_mtm_sq_off_perc = %lf",j,pViewProfiResp.subProfile[j].fRpm_mtm_sq_off_perc);
				logDebug2("pViewProfiResp.subProfile[%d].sRpm_co_basket = %s",j,pViewProfiResp.subProfile[j].sRpm_co_basket);
				logDebug2("pViewProfiResp.subProfile[%d].sRpm_bo_basket = %s",j,pViewProfiResp.subProfile[j].sRpm_bo_basket);
			}
		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewProfiResp,sizeof(struct VIEW_PROFILE_MASTER_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}

		iTempNoOfRec--;
		//	usleep(5000);
	}	

	logTimestamp("Exit : fProfileMaster");
	return TRUE;
}

BOOL	fViewPayOut(CHAR *RcvMsg)
{
	logTimestamp("Entry : fViewPayOut");
	struct  VIEW_PAYOUT_REPORT_REQ		*PViewPayoutReq;
	struct  VIEW_COMMON_HDR_RESP 		pPayOutHdrResp;
	struct	VIEW_PAYOUT_REPORT_RESP		pViewPayOutResp;

	PViewPayoutReq = (struct  VIEW_PAYOUT_REPORT_REQ *)RcvMsg;

	CHAR    sWhere_Clause[QUERY_SIZE];
	CHAR	sSubPayOutQry[QUERY_SIZE];
	CHAR	sPayOutQry[MAX_QUERY_SIZE];
	memset(sPayOutQry,'\0',MAX_QUERY_SIZE);
	 /*sWhere_Clause memset is added bcs it takes junk value */
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;	

	logDebug2("PViewPayoutReq->sClientId = %s",PViewPayoutReq->sClientId);
	logDebug2("PViewPayoutReq->cPayStatus = %c",PViewPayoutReq->cPayStatus);
	logDebug2("PViewPayoutReq->sDateFrom = %s",PViewPayoutReq->sDateFrom);
	logDebug2("PViewPayoutReq->sDateTo = %s",PViewPayoutReq->sDateTo);
	logDebug2("PViewPayoutReq->sAccType = %s",PViewPayoutReq->sAccType);

	if(strcmp(PViewPayoutReq->sClientId,SELECT_ALL))
	{
		memset(sSubPayOutQry,'\0',QUERY_SIZE);
		sprintf(sSubPayOutQry," AND RPD_CLIENT_ID LIKE \"%s\"",PViewPayoutReq->sClientId);
		logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
		strcat(sWhere_Clause,sSubPayOutQry);
		logDebug2("sWhere_Clause 1 = %s",sWhere_Clause);
	}
	if(PViewPayoutReq->cPayStatus != SEL_ALL)
	{
		memset(sSubPayOutQry,'\0',QUERY_SIZE);
		sprintf(sSubPayOutQry," AND RPD_PAY_STATUS = \'%c\'",PViewPayoutReq->cPayStatus);
		logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
		strcat(sWhere_Clause,sSubPayOutQry);
		logDebug2("sWhere_Clause 2 = %s",sWhere_Clause);
	}
	if((strcmp(PViewPayoutReq->sDateFrom,SELECT_ALL)) && (strcmp(PViewPayoutReq->sDateTo,SELECT_ALL)))
	{
		memset(sSubPayOutQry,'\0',QUERY_SIZE);
		sprintf(sSubPayOutQry,"AND DATE(RPD_REQUEST_DATE) BETWEEN STR_TO_DATE(\"%s\", '%%d/%%m/%%Y') AND STR_TO_DATE(\"%s\", '%%d/%%m/%%Y')",
				PViewPayoutReq->sDateFrom,PViewPayoutReq->sDateTo);
		logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
		strcat(sWhere_Clause,sSubPayOutQry);
		logDebug2("sWhere_Clause 3 = %s",sWhere_Clause);
	}
	if(strcmp(PViewPayoutReq->sAccType,SELECT_ALL))
	{
		memset(sSubPayOutQry,'\0',QUERY_SIZE);
		sprintf(sSubPayOutQry," AND RPD_ACC_TYPE = \"%s\"",PViewPayoutReq->sAccType);
		logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
		strcat(sWhere_Clause,sSubPayOutQry);
		logDebug2("sWhere_Clause 4 = %s",sWhere_Clause);
	}	

	sprintf(sPayOutQry,"	select RPD_PAYMENT_ID,RPD_CLIENT_ID,RPD_PAY_AMOUNT,RPD_ACC_NO,RPD_IFSC_CODE,\
			case RPD_PAY_STATUS WHEN 'S' THEN 'Submitted' WHEN 'R' THEN 'Rejected' WHEN 'A' THEN 'Approved' END AS RPD_PAY_STATUS,\
			ifnull(RPD_PAY_STATUS_MSG,'NA') AS RPD_PAY_STATUS_MSG,\
			RPD_REQUEST_DATE,RPD_ACC_TYPE,RPD_BANK_NAME,RPD_REMARK from REQUEST_PAYOUT_DETAILS \
			where 1=1 %s order by RPD_PAYMENT_ID;",sWhere_Clause );

	logDebug2("sPayOutQry = %s",sPayOutQry);

	if(mysql_query(DBQury,sPayOutQry) != SUCCESS)
	{
		logSqlFatal("Error in sPayOutQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pPayOutHdrResp.IntRespHeader.iSeqNo = 0;
	pPayOutHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pPayOutHdrResp.IntRespHeader.iErrorId = 0;
	pPayOutHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_PAYOUT_REPORT_HEADER_RESP;
	pPayOutHdrResp.IntRespHeader.iUserId = PViewPayoutReq->ReqHeader.iUserId;
	pPayOutHdrResp.IntRespHeader.cSource = PViewPayoutReq->ReqHeader.cSource;
	pPayOutHdrResp.cMsgType = 'H';
	pPayOutHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pPayOutHdrResp.IntRespHeader.iMsgLength = %d",pPayOutHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pPayOutHdrResp.IntRespHeader.iMsgCode = %d",pPayOutHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pPayOutHdrResp.IntRespHeader.iUserId = %llu",pPayOutHdrResp.IntRespHeader.iUserId);
	logDebug2("pPayOutHdrResp.IntRespHeader.cSource = %c",pPayOutHdrResp.IntRespHeader.cSource);
	logDebug2("pPayOutHdrResp.iNoofRec = %d",pPayOutHdrResp.iNoofRec);

	logDebug2("PViewPayoutReq->ReqHeader.iUserId = %llu",PViewPayoutReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(PViewPayoutReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);	

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pPayOutHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pViewPayOutResp,'\0',sizeof(struct VIEW_PAYOUT_REPORT_RESP));
		pViewPayOutResp.IntRespHeader.iSeqNo = 0;
		pViewPayOutResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_PAYOUT_REPORT_RESP);
		pViewPayOutResp.IntRespHeader.iErrorId = 0;
		pViewPayOutResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_PAYOUT_REPORT_RESP;
		pViewPayOutResp.IntRespHeader.iUserId = PViewPayoutReq->ReqHeader.iUserId;
		pViewPayOutResp.IntRespHeader.cSource = PViewPayoutReq->ReqHeader.cSource;

		logDebug2("pViewPayOutResp.IntRespHeader.iMsgCode = %d",pViewPayOutResp.IntRespHeader.iMsgCode);

		if(iTempNoOfRec <= 1)
		{
			pViewPayOutResp.cMsgType = 'T';
		}
		else
		{
			pViewPayOutResp.cMsgType = 'D';
		}
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{ 
				pViewPayOutResp.subPayoutReport[j].iPaymentID = atoi(Row[0]);
				strncpy(pViewPayOutResp.subPayoutReport[j].sClientId,Row[1],CLIENT_ID_LEN);
				pViewPayOutResp.subPayoutReport[j].fPayAmount = atof(Row[2]);
				strncpy(pViewPayOutResp.subPayoutReport[j].sAccountNo,Row[3],BANK_ACC_NUM_LEN);
				strncpy(pViewPayOutResp.subPayoutReport[j].sIFSC_Code,Row[4],IFSC_CODE_LEN);
				strncpy(pViewPayOutResp.subPayoutReport[j].sPayStatus,Row[5],ORDER_STATUS);	
				strncpy(pViewPayOutResp.subPayoutReport[j].sPayStatusMsg,Row[6],PAY_MODE_MSG_LEN);
				strncpy(pViewPayOutResp.subPayoutReport[j].sRequestDate,Row[7],DATE_TIME_LEN);
				strncpy(pViewPayOutResp.subPayoutReport[j].sLmtType,Row[8],LIMIT_TYPE_LEN);		
				strncpy(pViewPayOutResp.subPayoutReport[j].sBankName,Row[9],BANK_NAME_LEN);		
				strncpy(pViewPayOutResp.subPayoutReport[j].sRemark,Row[10],REMARKS_LEN);

				logDebug2("************<<<<<<<<<<<<< start >>>>>>>>>>>>>************");
				logDebug2("pViewPayOutResp.subPayoutReport[%d].iPaymentID = %d",j,pViewPayOutResp.subPayoutReport[j].iPaymentID);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sClientId = %s",j,pViewPayOutResp.subPayoutReport[j].sClientId);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].iPayAmount = %lf",j,pViewPayOutResp.subPayoutReport[j].fPayAmount);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sAccountNo = %s",j,pViewPayOutResp.subPayoutReport[j].sAccountNo);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sIFSC_Code = %s",j,pViewPayOutResp.subPayoutReport[j].sIFSC_Code);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sPayStatus = %s",j,pViewPayOutResp.subPayoutReport[j].sPayStatus);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sPayStatusMsg = %s",j,pViewPayOutResp.subPayoutReport[j].sPayStatusMsg);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sRequestDate = %s",j,pViewPayOutResp.subPayoutReport[j].sRequestDate);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sLmtType = %s",j,pViewPayOutResp.subPayoutReport[j].sLmtType);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sBankName = %s",j,pViewPayOutResp.subPayoutReport[j].sBankName);		
				logDebug2("pViewPayOutResp.subPayoutReport[%d].sRemark = %s",j,pViewPayOutResp.subPayoutReport[j].sRemark);		
			}
		}
		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewPayOutResp,sizeof(struct VIEW_PAYOUT_REPORT_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}

		iTempNoOfRec--;
		//	usleep(5000);
	}
	mysql_free_result(Res);
	logTimestamp("Exit : fViewPayOut");
	return TRUE;
}

BOOL	fViewClientMaster(CHAR	*RcvMsg)
{

	/**
	  logTimestamp("Entry : fViewClientMaster");
	  struct	VIEW_CL_MASTER_ADMIN_REQ	*pViewClMasReq;
	  struct	VIEW_COMMON_HDR_RESP		pClMasHdrResp;
	  struct	VIEW_CL_MASTER_ADMIN_RESP	pClMasResp;

	  pViewClMasReq = (struct  VIEW_CL_MASTER_ADMIN_REQ *)RcvMsg;

	  CHAR    sWhere_Clause[QUERY_SIZE];
	  CHAR	sClMasSubQry[QUERY_SIZE];
	  CHAR	sClitMasQry[DOUBLE_MAX_QUERY_SIZE];

	  LONG32          iNoOfRec=0;
	  DOUBLE64        fNoOfRec;
	  LONG32          iNoOfPkt;
	  LONG32          iTempNoOfRec;

	  logDebug2("pViewClMasReq->ReqHeader.iUserId = :%d:",pViewClMasReq->ReqHeader.iUserId);
	  logDebug2("pViewClMasReq->sEntityId = :%s:",pViewClMasReq->sEntityId);
	  logDebug2("pViewClMasReq->sEntityName = :%s:",pViewClMasReq->sEntityName);
	  logDebug2("pViewClMasReq->cStatus = :%c:",pViewClMasReq->cStatus);
	  logDebug2("pViewClMasReq->cLoginStatus = :%c:",pViewClMasReq->cLoginStatus);
	  logDebug2("pViewClMasReq->sFromDate = :%s:",pViewClMasReq->sFromDate);
	  logDebug2("pViewClMasReq->sToDate = :%s:",pViewClMasReq->sToDate);
	  logDebug2("pViewClMasReq->cEntityType = :%c:",pViewClMasReq->cEntityType);
	  logDebug2("pViewClMasReq->sController = :%s:",pViewClMasReq->sController);
	  logDebug2("pViewClMasReq->sBranchType = :%s:",pViewClMasReq->sBranchType);

	  memset(sWhere_Clause,'\0',QUERY_SIZE);
	  memset(sCircuitLmtQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	  if(strcmp(pViewClMasReq->ReqHeader.sEntityId,SELECT_ALL))
	  {
	  memset(sClMasSubQry,'\0',QUERY_SIZE);
	  sprintf(sClMasSubQry," AND ENTITY_ID like \"%s\"",pViewClMasReq->ReqHeader.sEntityId);
	  logDebug2("sClMasSubQry = %s",sClMasSubQry);
	  strcat(sWhere_Clause,sClMasSubQry);
	  logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	  }
	  if(strcmp(pViewClMasReq->ReqHeader.sEntityName,SELECT_ALL))
	  {
	  memset(sClMasSubQry,'\0',QUERY_SIZE);
	  sprintf(sClMasSubQry," AND USER_NAME like \"%s\"",pViewClMasReq->ReqHeader.sEntityName);
	  logDebug2("sClMasSubQry = %s",sClMasSubQry);
	  strcat(sWhere_Clause,sClMasSubQry);
	  logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	  }
	  if(pViewClMasReq->ReqHeader.cStatus != SEL_ALL)
	  {
	  memset(sClMasSubQry,'\0',QUERY_SIZE);
	  sprintf(sClMasSubQry," AND STATUS = \'%c\'",pViewClMasReq->ReqHeader.cStatus);
	  logDebug2("sClMasSubQry = %s",sClMasSubQry);
	  strcat(sWhere_Clause,sClMasSubQry);
	  logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	  }
	  if(pViewClMasReq->ReqHeader.cLoginStatus != SEL_ALL)
	  {
	  memset(sClMasSubQry,'\0',QUERY_SIZE);
	  sprintf(sClMasSubQry," AND LOGIN_STATUS = \'%c\'",pViewClMasReq->ReqHeader.cLoginStatus);
	  logDebug2("sClMasSubQry = %s",sClMasSubQry);
	  strcat(sWhere_Clause,sClMasSubQry);
	  logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	  }
	  if(pViewClMasReq->ReqHeader.cEntityType != SEL_ALL)
	  {
	  memset(sClMasSubQry,'\0',QUERY_SIZE);
	  sprintf(sClMasSubQry," AND CLIENT_TYPE = \'%c\'",pViewClMasReq->ReqHeader.cEntityType);
	  logDebug2("sClMasSubQry = %s",sClMasSubQry);
	  strcat(sWhere_Clause,sClMasSubQry);
	  logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	  }
	if(strcmp(pViewClMasReq->ReqHeader.sController,SELECT_ALL))
	{
		memset(sClMasSubQry,'\0',QUERY_SIZE);
		sprintf(sClMasSubQry," AND CONTROLLER = \"%s\"",pViewClMasReq->ReqHeader.sController);
		logDebug2("sClMasSubQry = %s",sClMasSubQry);
		strcat(sWhere_Clause,sClMasSubQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}

	***/
		logTimestamp("Exit : fViewClientMaster");
}

BOOL	fViewCircuitLimit(CHAR *RcvMsg)
{

	logTimestamp("Entry : fViewCircuitLimit");

	struct	VIEW_CIRCUIT_LIMIT_REQ		*pViewCirLmtReq;
	struct 	VIEW_COMMON_HDR_RESP            pCirLmtHdrResp;	
	struct	VIEW_CIRCUIT_LIMIT_RESP		pCirLmtResp;

	pViewCirLmtReq = (struct  VIEW_CIRCUIT_LIMIT_REQ *)RcvMsg;

	CHAR	sWhere_Clause[QUERY_SIZE];
	CHAR	sCirLmtSubQry[QUERY_SIZE];
	CHAR	sCircuitLmtQry[DOUBLE_MAX_QUERY_SIZE];

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;	

	logDebug2("pViewCirLmtReq->ReqHeader.sExcgId = :%s:",pViewCirLmtReq->ReqHeader.sExcgId);
	logDebug2("pViewCirLmtReq->ReqHeader.cSegment = :%c:",pViewCirLmtReq->ReqHeader.cSegment);
	logDebug2("pViewCirLmtReq->ReqHeader.iUserId = :%llu:",pViewCirLmtReq->ReqHeader.iUserId);
	logDebug2("pViewCirLmtReq->sSymbol = :%s:",pViewCirLmtReq->sSymbol);
	logDebug2("pViewCirLmtReq->sInstrument = :%s:",pViewCirLmtReq->sInstrument);
	logDebug2("pViewCirLmtReq->sOptions = :%s:",pViewCirLmtReq->sOptions);

	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sCircuitLmtQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	if(strcmp(pViewCirLmtReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sCirLmtSubQry,'\0',QUERY_SIZE);
		sprintf(sCirLmtSubQry," AND EXCH = \"%s\"",pViewCirLmtReq->ReqHeader.sExcgId);
		logDebug2("sCirLmtSubQry = %s",sCirLmtSubQry);
		strcat(sWhere_Clause,sCirLmtSubQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pViewCirLmtReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sCirLmtSubQry,'\0',QUERY_SIZE);
		sprintf(sCirLmtSubQry," AND SEGMENT = \'%c\'",pViewCirLmtReq->ReqHeader.cSegment);
		logDebug2("sCirLmtSubQry = %s",sCirLmtSubQry);
		strcat(sWhere_Clause,sCirLmtSubQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}	
	if(strcmp(pViewCirLmtReq->sInstrument,SELECT_ALL))
	{
		memset(sCirLmtSubQry,'\0',QUERY_SIZE);
		sprintf(sCirLmtSubQry," AND INSTRUMENT = \"%s\"",pViewCirLmtReq->sInstrument);
		logDebug2("sCirLmtSubQry = %s",sCirLmtSubQry);
		strcat(sWhere_Clause,sCirLmtSubQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(strcmp(pViewCirLmtReq->sSymbol,SELECT_ALL))
	{
		memset(sCirLmtSubQry,'\0',QUERY_SIZE);
		sprintf(sCirLmtSubQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pViewCirLmtReq->sSymbol);
		logDebug2("sCirLmtSubQry = %s",sCirLmtSubQry);
		strcat(sWhere_Clause,sCirLmtSubQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pViewCirLmtReq->sOptions,SELECT_ALL))
	{
		memset(sCirLmtSubQry,'\0',QUERY_SIZE);
		sprintf(sCirLmtSubQry," AND OPTION_TYPE = \"%s\"",pViewCirLmtReq->sOptions);
		logDebug2("sCirLmtSubQry = %s",sCirLmtSubQry);
		strcat(sWhere_Clause,sCirLmtSubQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}

	sprintf(sCircuitLmtQry,"SELECT SM_SYMBOL AS SYMBOL,SM_Scrip_code AS SEC_ID,SM_SEGMENT AS SEGMENT,SM_EXCHANGE AS EXCH,\
			ifnull(SM_SYMBOL_NAME,'NA') AS SYMBOL_NAME,ifnull(SM_SERIES,'NA') AS SERIES,SM_STATUS AS STATUS,\
			ifnull(SM_EXPIRY_DATE,'NA') AS EXPIRY_DATE, ifnull(SM_STRIKE_PRICE,0) AS STRIK_PRICE,\
			ifnull(nullif(SM_OPTION_TYPE,''),'NA') AS OPTION_TYPE,SM_LOT_SIZE AS LOT,SM_TICK_SIZE AS TICK_SIZE,\
			ifnull(SM_ISIN_CODE,'NA') AS ISIN_CODE,SM_UPPER_LIMIT AS UPPER_LIMIT,SM_LOWER_LIMIT AS LOWER_LIMIT,\
			ifnull(nullif(SM_UNDERLAYING_SCRIP_CODE,''),0) AS UNDERLYING_ASSET,\
			SM_INSTRUMENT_NAME AS INSTRUMENT FROM SECURITY_MASTER WHERE 1 = 1 %s ORDER BY SEC_ID;",sWhere_Clause);

	logDebug2("sCircuitLmtQry = %s",sCircuitLmtQry);

	if(mysql_query(DBQury,sCircuitLmtQry) != SUCCESS)
	{
		logSqlFatal("Error in sCircuitLmtQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);	
	iTempNoOfRec = iNoOfRec;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pCirLmtHdrResp.IntRespHeader.iSeqNo = 0;
	pCirLmtHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCirLmtHdrResp.IntRespHeader.iErrorId = 0;
	pCirLmtHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CIRCUIT_LIMIT_HEADER_RESP;
	pCirLmtHdrResp.IntRespHeader.iUserId = pViewCirLmtReq->ReqHeader.iUserId;
	pCirLmtHdrResp.IntRespHeader.cSource = pViewCirLmtReq->ReqHeader.cSource;
	pCirLmtHdrResp.cMsgType = 'H';
	pCirLmtHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pCirLmtHdrResp.IntRespHeader.iMsgLength = %d",pCirLmtHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pCirLmtHdrResp.IntRespHeader.iMsgCode = %d",pCirLmtHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pCirLmtHdrResp.IntRespHeader.iUserId = %llu",pCirLmtHdrResp.IntRespHeader.iUserId);
	logDebug2("pCirLmtHdrResp.IntRespHeader.cSource = %c",pCirLmtHdrResp.IntRespHeader.cSource);
	logDebug2("pCirLmtHdrResp.iNoofRec = %d",pCirLmtHdrResp.iNoofRec);

	logDebug2("pViewCirLmtReq->ReqHeader.iUserId = %llu",pViewCirLmtReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewCirLmtReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pCirLmtHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt..(i) = %d",i);
		memset(&pCirLmtResp,'\0',sizeof(struct VIEW_ORDER_BOOK_RESP));
		pCirLmtResp.IntRespHeader.iSeqNo = 0;
		pCirLmtResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_RESP);
		pCirLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CIRCUIT_LIMIT_RESP;
		pCirLmtResp.IntRespHeader.iErrorId = 0;
		pCirLmtResp.IntRespHeader.iUserId = pViewCirLmtReq->ReqHeader.iUserId;
		pCirLmtResp.IntRespHeader.cSource = pViewCirLmtReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pCirLmtResp.cMsgType = 'T';
		}
		else
		{
			pCirLmtResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pCirLmtResp.subcricuitlimit[j].sSymbol,Row[0],DB_SYMBOL_LEN);
				strncpy(pCirLmtResp.subcricuitlimit[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				pCirLmtResp.subcricuitlimit[j].cSegment = Row[2][0];
				strncpy(pCirLmtResp.subcricuitlimit[j].sExcgId,Row[3],EXCHANGE_LEN);
				strncpy(pCirLmtResp.subcricuitlimit[j].sSymbolName,Row[4],DB_SYM_LEN);
				strncpy(pCirLmtResp.subcricuitlimit[j].sSeries,Row[5],SERIES_LEN);
				pCirLmtResp.subcricuitlimit[j].cStatus = Row[6][0];
				strncpy(pCirLmtResp.subcricuitlimit[j].sExpiryDate,Row[7],DATE_TIME_LEN);
				pCirLmtResp.subcricuitlimit[j].fStrickPrice = atof(Row[8]);
				strncpy(pCirLmtResp.subcricuitlimit[j].sOptType,Row[9],OPT_TYPE_LEN);
				pCirLmtResp.subcricuitlimit[j].iLot = atoi(Row[10]);
				pCirLmtResp.subcricuitlimit[j].fTikeSize = atof(Row[11]);	
				strncpy(pCirLmtResp.subcricuitlimit[j].sISINCode,Row[12],ISINCODE_LEN);
				pCirLmtResp.subcricuitlimit[j].fUpeerLimit = atof(Row[13]);
				pCirLmtResp.subcricuitlimit[j].fLowerLimit = atof(Row[14]);
				pCirLmtResp.subcricuitlimit[j].fUnderLyingAssest = atof(Row[15]);	
				strncpy(pCirLmtResp.subcricuitlimit[j].sInstrument,Row[16],INSTRUMENT_LEN);

				logDebug2("pCirLmtResp.subcricuitlimit[%d].sSymbol = %s",j,pCirLmtResp.subcricuitlimit[j].sSymbol);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sSecurityID = %s",j,pCirLmtResp.subcricuitlimit[j].sSecurityID);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].cSegment = %s",j,pCirLmtResp.subcricuitlimit[j].cSegment);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sExcgId = %s",j,pCirLmtResp.subcricuitlimit[j].sExcgId);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sSymbolName = %s",j,pCirLmtResp.subcricuitlimit[j].sSymbolName);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sSeries = %s",j,pCirLmtResp.subcricuitlimit[j].sSeries);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].cStatus = %s",j,pCirLmtResp.subcricuitlimit[j].cStatus);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sExpiryDate = %s",j,pCirLmtResp.subcricuitlimit[j].sExpiryDate);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].fStrickPrice = %lf",j,pCirLmtResp.subcricuitlimit[j].fStrickPrice);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sOptType = %s",j,pCirLmtResp.subcricuitlimit[j].sOptType);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].iLot = %d",j,pCirLmtResp.subcricuitlimit[j].iLot);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].fTikeSize = %lf",j,pCirLmtResp.subcricuitlimit[j].fTikeSize);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sISINCode = %s",j,pCirLmtResp.subcricuitlimit[j].sISINCode);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].fUpeerLimit = %lf",j,pCirLmtResp.subcricuitlimit[j].fUpeerLimit);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].fLowerLimit = %lf",j,pCirLmtResp.subcricuitlimit[j].fLowerLimit);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].fUnderLyingAssest = %lf",j,pCirLmtResp.subcricuitlimit[j].fUnderLyingAssest);	
				logDebug2("pCirLmtResp.subcricuitlimit[%d].sInstrument = %s",j,pCirLmtResp.subcricuitlimit[j].sInstrument);	
			}
		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pCirLmtResp,sizeof(struct VIEW_CIRCUIT_LIMIT_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}
		iTempNoOfRec--;
		//	usleep(5000);

	}
	logTimestamp("Exit : fViewCircuitLimit");	
	return TRUE;
}


BOOL fOrderReport(CHAR *RcvMsg)
{
	logTimestamp("Entry :forderReport:");

	struct ORDER_BOOK_REPORT_REQUEST  *pOrdBookReq;
	struct ORDER_BOOK_REPORT_RESPONSE  pOrdBookRes;	

	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR	sOrdReportQry[DOUBLE_MAX_QUERY_SIZE];
	memset (sOrdReportQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;	
	CHAR		sClientId [CLIENT_ID_LEN];
	CHAR		sSubOrdBookQry[QUERY_SIZE];
	CHAR		sWhere_Clause[QUERY_SIZE];

	pOrdBookReq = (struct ORDER_BOOK_REPORT_REQUEST *)RcvMsg;

	logDebug2("pOrdBookReq->sClientId :%s:",pOrdBookReq->sClientId);
	logDebug2("pOrdBookReq->sDateFrom :%s:",pOrdBookReq->sDateFrom);
	logDebug2("pOrdBookReq->sDateTo :%s:",pOrdBookReq->sDateTo);
	logDebug2("pOrdBookReq->sPlacedBy :%s:",pOrdBookReq->sPlacedBy);
	logDebug2("pOrdBookReq->cSource :%c:",pOrdBookReq->cSource);
	logDebug2("pOrdBookReq->sSymbol:%s:",pOrdBookReq->sSymbol);

	strncpy(sClientId,pOrdBookReq->sEntityId,ENTITY_ID_LEN);
	if(strcmp(pOrdBookReq->sClientId,SELECT_ALL))
	{
		memset(sSubOrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBookQry," AND CLIENT_ID LIKE \"%s\"",pOrdBookReq->sClientId);
		logDebug2("sSubOrdBKQry9 = %s",sSubOrdBookQry);
		strcat(sWhere_Clause,sSubOrdBookQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if((strcmp(pOrdBookReq->sDateFrom,SELECT_ALL)) && (strcmp(pOrdBookReq->sDateTo,SELECT_ALL)))
	{
		memset(sSubOrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBookQry,"AND DATE(Order_DateTime) BETWEEN STR_TO_DATE(\"%s\", '%%d/%%m/%%Y') AND STR_TO_DATE(\"%s\", '%%d/%%m/%%Y')",
				pOrdBookReq->sDateFrom,pOrdBookReq->sDateTo);
		logDebug2("sSubOrdBookQry = %s",sSubOrdBookQry);
		strcat(sWhere_Clause,sSubOrdBookQry);
		logDebug2("sWhere_Clause 3 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sSubOrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBookQry," AND EXCH_ID = \"%s\"",pOrdBookReq->ReqHeader.sExcgId);
		logDebug2("sSubOrdBKQry1 = %s",sSubOrdBookQry);
		strcat(sWhere_Clause,sSubOrdBookQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pOrdBookReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sSubOrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBookQry," AND SEGMENT = \'%c\'",pOrdBookReq->ReqHeader.cSegment);
		logDebug2("sSubOrdBookQry = %s",sSubOrdBookQry);
		strcat(sWhere_Clause,sSubOrdBookQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sSubOrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBookQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pOrdBookReq->sSymbol);
		logDebug2("sSubOrdookQry = %s",sSubOrdBookQry);
		strcat(sWhere_Clause,sSubOrdBookQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(pOrdBookReq->cSource != SEL_ALL)
	{
		memset(sSubOrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBookQry," AND DB_SOURCE = \"%s\"",pOrdBookReq->cSource);
		logDebug2("sSubOrdBookQry11 = %s",sSubOrdBookQry);
		strcat(sWhere_Clause,sSubOrdBookQry);
		logDebug2("sWhere_Clause11 = %s",sWhere_Clause);
	}


	logDebug2("Final Where = %s",sWhere_Clause);

	sprintf(sOrdReportQry,"SELECT CONCAT(CLIENT_ID,',',User_Id,',',DB_SORUCE,',',Product,',',StopLoss_Indicator,',',StopLoss_Indicator,',',\
		Order_Number,',',Buy_Sell,',',Symbol,',',Volume_Original,',',Volume_Disclosed,',',Limit_Price,',',Trg_Price,',',\
			Day_IndiCator,',',Order_DateTime,',',Activity_Type,',',\
			PlacedBy,',',EXCH_ID,',',SEGMENT,',',SCRIP_CODE,',',ORDER_TYPE,',',CTCLId,',',Order_Time,','Algo_ID,','OrderFlag) FROM ( \
				SELECT\
				Ord_rep.*,\
				DATE_FORMAT(Ord_rep.Order_DateTime, \'%%Y%%m%%d %%H:%%i:%%S\') AS 'Order_Time'\
				FROM \
				(SELECT \
				 a.EQ_CLIENT_ID AS 'CLIENT_ID',\
				 a.EQ_USER_ID AS 'User_Id',\
				 CASE a.EQ_SOURCE_FLG \
				 WHEN 'M' THEN 'Mobile' \
				 WHEN 'W' THEN 'Web' \
				 WHEN 'A' THEN 'Admin' \
				 WHEN 'H' THEN 'HelpDesk'\
				 ELSE 'RapidRupee' \
				 END AS 'Source',\
				 a.EQ_SOURCE_FLG as DB_SORUCE,\
				 CASE a.EQ_PRODUCT_ID \ 
				 WHEN 'C' THEN 'CnC' \
				 WHEN 'M' THEN 'Margin' \
				 WHEN 'L' THEN 'MLB' \
				 WHEN 'S' THEN 'Collateral' \
				 WHEN 'I' THEN 'Intraday' \
				 WHEN 'V' THEN 'CO' \
				 WHEN 'B' THEN 'BO' \
				 ELSE a.EQ_PRODUCT_ID \
				 END AS 'Product', \
				 CASE a.EQ_ORDER_TYPE \
				 WHEN '3' OR '4' THEN 'Y' \
				 ELSE 'N' \
				 END AS 'StopLoss_Indicator', \
				 a.EQ_ORDER_NO AS 'Order_Number', \
				 CASE a.EQ_BUY_SELL_IND \
				 WHEN 'B' THEN 'Buy' \
				 WHEN 'S' THEN 'Sell' \
				 END AS 'Buy_Sell', \
				 a.EQ_SYMBOL AS 'Symbol', \
				 a.EQ_TOTAL_QTY AS 'Volume_Original', \
				 a.EQ_DISC_QTY AS 'Volume_Disclosed', \
				 CASE a.EQ_ORDER_TYPE\
				 WHEN '1' THEN 'MKT' \
				 WHEN '3' THEN 'SL-M' \
				 WHEN '2' THEN a.EQ_ORDER_PRICE \
				 WHEN '4' THEN a.EQ_ORDER_PRICE \
				 END AS 'Limit_Price', \
				 CASE a.EQ_ORDER_TYPE \
				 WHEN '1' THEN '0.00'\ 
				 WHEN '2' THEN '0.00' \
				 WHEN '3' THEN '0.00' \
				 WHEN '4' THEN a.EQ_TRIGGER_PRICE \
				 END AS 'Trg_Price',\
				 CASE a.EQ_VALIDITY\
				 WHEN '0' THEN 'DAY' \
				 WHEN '3' THEN 'IOC' \
				 ELSE 'DAY' \
				 END AS 'Day_IndiCator', \
				 a.EQ_INTERNAL_ENTRY_DATE AS Order_DateTime,\ 
				 CASE \
				 WHEN \
				 a.EQ_MSG_CODE = '2073' \ 
				 AND a.EQ_REM_QTY <> a.EQ_TOTAL_QTY \
				 THEN \
				 'PTRAD' \
				 WHEN \
				 a.EQ_MSG_CODE = '2074' \
				 AND a.EQ_REM_QTY > a.EQ_TOTAL_QTY \
				 THEN \
				 'PTRAD' \
				 WHEN (a.EQ_MSG_CODE = '2073') THEN 'Pending' \
				 WHEN (a.EQ_MSG_CODE = '2000') THEN 'Transit' \
				 WHEN (a.EQ_MSG_CODE = '2040') THEN 'Transit' \
				 WHEN (a.EQ_MSG_CODE = '2070') THEN 'Transit' \
				 WHEN (a.EQ_MSG_CODE = '2231') THEN 'Rejected' \
				 WHEN (a.EQ_MSG_CODE = '2042') THEN 'Rejected' \ 
				 WHEN (a.EQ_MSG_CODE = '2170') THEN 'Frozen' \
				 WHEN (a.EQ_MSG_CODE = '2074') THEN 'Modified' \
				 WHEN (a.EQ_MSG_CODE = '2075') THEN 'Cancelled' \
				 WHEN (a.EQ_MSG_CODE = '2222') THEN 'Traded' \
				 WHEN (a.EQ_MSG_CODE = '9002') THEN 'Expired' \
				 WHEN (a.EQ_MSG_CODE = '5112') THEN 'O-Pending' \
				 WHEN (a.EQ_MSG_CODE = '5113') THEN 'O-Modified' \
				 WHEN (a.EQ_MSG_CODE = '5114') THEN 'O-Cancelled' \
				 WHEN (a.EQ_MSG_CODE = '2212') THEN 'Triggered' \
				 WHEN (a.EQ_MSG_CODE = '1111') THEN 'Rejected' \
				 WHEN (a.EQ_MSG_CODE = '1113') THEN 'Rejected' \
				 WHEN (a.EQ_MSG_CODE = '1115') THEN 'Rejected' \
				 WHEN (a.EQ_MSG_CODE = '4444') THEN 'Rejected' \
				 WHEN (a.EQ_MSG_CODE = '4445') THEN 'Rejected' \
				 WHEN (a.EQ_MSG_CODE = '4446') THEN 'Rejected' \
				 END AS 'Activity_Type', \
				 a.EQ_ENTITY_ID AS PlacedBy,\
				 a.EQ_EXCH_ID AS EXCH_ID, \
				 a.EQ_SEGMENT AS SEGMENT, \
				 CASE a.EQ_ORDER_TYPE \
				 WHEN '1' THEN 'MARKET' \
				 WHEN '2' THEN 'LIMIT'\ 
				 WHEN '3' THEN 'SL-M'\
				 WHEN '4' THEN 'SL' \
				 END AS 'ORDER_TYPE', \
				 a.EQ_SCRIP_CODE AS SCRIP_CODE, \
				 8371 CTCLId, \
				 a.EQ_ALGO_ID AS Algo_ID,\
				 CASE a.EQ_STRATEGY_ID \
				 WHEN '101' THEN 'INTRADAY_SQR_OFF' \
                                 WHEN '102' THEN 'CO_SQ_OFF'\
                                 WHEN '103' THEN 'BO_SQ_OFF'\
                                 WHEN '104' THEN 'OFF_ORD_PUMP' \
                                 WHEN '105' THEN 'SIP_ORD_PUMP' \
                                 WHEN '106' THEN 'MTM_SQR_OFF' \
				 ELSE 'NA' END AS 'OrderFlag', \
				 FROM \
				 EQ_ORDERS_ARCHIVE a, ENTITY_MASTER b \
				 WHERE\
				 a.EQ_CLIENT_ID = b.ENTITY_CODE\
				 AND a.EQ_SERIAL_NO = (SELECT \
						 MAX(c.EQ_SERIAL_NO) \
						 FROM \
						 EQ_ORDERS_ARCHIVE c \
						 WHERE \
						 c.EQ_ORDER_NO = a.EQ_ORDER_NO) \
				 AND a.EQ_ALGO_ORDER_NO = '0' UNION ALL SELECT \
				 a.DRV_CLIENT_ID AS 'CLIENT_ID', \
				 a.DRV_USER_ID AS 'User_Id', \
				 CASE a.DRV_SOURCE_FLG \
				 WHEN 'M' THEN 'Mobile'\
				 WHEN 'W' THEN 'Web'\
				 WHEN 'A' THEN 'Admin'\
				 WHEN 'H' THEN 'HelpDesk'\
				 ELSE 'RapidRupee'\
				 END AS 'Source',a.DRV_SOURCE_FLG as DB_SORUCE,\
				 CASE a.DRV_PRODUCT_ID\
				 WHEN 'C' THEN 'CnC'\
				 WHEN 'M' THEN 'Margin'\
				 WHEN 'L' THEN 'MLB'\
				 WHEN 'S' THEN 'Collateral'\
				 WHEN 'I' THEN 'Intraday'\
				 WHEN 'V' THEN 'CO'\
				 WHEN 'B' THEN 'BO'\
				 ELSE a.DRV_PRODUCT_ID\
				 END AS 'Product',\
				 CASE a.DRV_ORDER_TYPE \
				 WHEN '3' OR '4' THEN 'Y' \
				 ELSE 'N' \
				 END AS 'StopLoss_Indicator',\
				 a.DRV_ORDER_NO AS 'Order_Number',\
				 CASE a.DRV_BUY_SELL_IND \
				 WHEN 'B' THEN 'Buy'\
				 WHEN 'S' THEN 'Sell'\
				 END AS 'Buy_Sell',\
				 a.DRV_SYMBOL AS 'Symbol',\
				 a.DRV_TOTAL_QTY AS 'Volume_Original',\
				 a.DRV_DISC_QTY AS 'Volume_Disclosed',\
				 CASE a.DRV_ORDER_TYPE \	
				 WHEN '1' THEN 'MKT' \
				 WHEN '3' THEN 'SL-M' \
				 WHEN '2' THEN a.DRV_ORDER_PRICE \
				 WHEN '4' THEN a.DRV_ORDER_PRICE \
				 END AS 'Limit_Price',\
				 CASE a.DRV_ORDER_TYPE \
				 WHEN '1' THEN '0.00' \
				 WHEN '2' THEN '0.00' \
				 WHEN '3' THEN '0.00' \ 
				 WHEN '4' THEN a.DRV_TRIGGER_PRICE \
				 END AS 'Trg_Price',\
				 CASE a.DRV_VALIDITY \
				 WHEN '0' THEN 'DAY' \
				 WHEN '3' THEN 'IOC' \
				 ELSE 'DAY' \
				 END AS 'Day_IndiCator',\
				 a.DRV_INTERNAL_ENTRY_DATE AS Order_DateTime,\
				 CASE\
				 WHEN\
				 a.DRV_MSG_CODE = '2073'\
				 AND a.DRV_REM_QTY <> a.DRV_TOTAL_QTY\
				 THEN\
				 'PTRAD'\
				 WHEN\
				 a.DRV_MSG_CODE = '2074'\
				 AND a.DRV_REM_QTY > a.DRV_TOTAL_QTY\
				 THEN\
				 'PTRAD'\
				 WHEN (a.DRV_MSG_CODE = '2073') THEN 'Pending'\
				 WHEN (a.DRV_MSG_CODE = '2000') THEN 'Transit'\
				 WHEN (a.DRV_MSG_CODE = '2040') THEN 'Transit'\
				 WHEN (a.DRV_MSG_CODE = '2070') THEN 'Transit'\
				 WHEN (a.DRV_MSG_CODE = '2231') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '2042') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '2170') THEN 'Frozen'\
				 WHEN (a.DRV_MSG_CODE = '2074') THEN 'Modified'\
				 WHEN (a.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
				 WHEN (a.DRV_MSG_CODE = '2222') THEN 'Traded'\
				 WHEN (a.DRV_MSG_CODE = '9002') THEN 'Expired'\
				 WHEN (a.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
				 WHEN (a.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
				 WHEN (a.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
				 WHEN (a.DRV_MSG_CODE = '2212') THEN 'Triggered'\
				 WHEN (a.DRV_MSG_CODE = '1111') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '1113') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '1115') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '4444') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '4445') THEN 'Rejected'\
				 WHEN (a.DRV_MSG_CODE = '4446') THEN 'Rejected'\
				 END AS 'Activity_Type',\
				 a.DRV_ENTITY_ID AS PlacedBy,\
				 a.DRV_EXCH_ID AS EXCH_ID,\
				 a.DRV_SEGMENT AS SEGMENT,\
				 CASE a.DRV_ORDER_TYPE\
				 WHEN '1' THEN 'MARKET'\
				 WHEN '2' THEN 'LIMIT'\
				 WHEN '3' THEN 'SL-M'\
				 WHEN '4' THEN 'SL'\
				 END AS 'ORDER_TYPE',\
				 a.DRV_SCRIP_CODE AS SCRIP_CODE,\
				 8371 CTCLId,\
				 a.DRV_ALGO_ID AS Algo_ID,\
                                 CASE a.DRV_STRATEGY_ID \
                                 WHEN '101' THEN 'INTRADAY_SQR_OFF' \
                                 WHEN '102' THEN 'CO_SQ_OFF'\
                                 WHEN '103' THEN 'BO_SQ_OFF'\
                                 WHEN '104' THEN 'OFF_ORD_PUMP' \
                                 WHEN '105' THEN 'SIP_ORD_PUMP' \
                                 WHEN '106' THEN 'MTM_SQR_OFF' \
                                 ELSE 'NA' END AS 'OrderFlag' \
				 FROM \
				 DRV_ORDERS_ARCHIVE a, ENTITY_MASTER b\
				 WHERE\
				 a.DRV_CLIENT_ID = b.ENTITY_CODE\
				 AND a.DRV_SERIAL_NO = (SELECT \
						 MAX(c.DRV_SERIAL_NO) \
						 FROM \
						 DRV_ORDERS_ARCHIVE c \
						 WHERE \
						 c.DRV_ORDER_NO = a.DRV_ORDER_NO) \
				 AND a.DRV_OMS_ALGO_ORD_NO = '0') Ord_rep ) OrderReport where 1=1 %s order by Order_DateTime desc;",sWhere_Clause);

	printf("\n sOrdReportQry :%s:",sOrdReportQry);
	if(mysql_query(DBQury,sOrdReportQry) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;

	}

	Res = mysql_store_result(DBQury);

	while (Row = mysql_fetch_row(Res))
	{
		logDebug2("No of Rows Selected = %d",Row);
		sprintf(sFileName,"%s/%s.csv",FILE_LOCATION,sClientId);
		logDebug2("sFileName = %s",sFileName);
		logDebug2("FILE_LOCATION = %s ",FILE_LOCATION);
		fpFile = fopen(sFileName,"w+");
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in write mode");
			//	IntRespHeader.iMsgCode =  
			//exit(0);
			return FALSE;
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				logDebug2("Row :%s:",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);
			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
		fclose(fpFile);
		fConvTopwdPrtect(sFileName,CLIENT_FILE_NM,sClientId);
		//strncpy(pOrdBookRes.sFilename,sFileName,FILE_NAME_LEN);
		sprintf(pOrdBookRes.sFilename,"%s.zip",sClientId);

	}
	pOrdBookRes.IntRespHeader.iSeqNo = 0;
	pOrdBookRes.IntRespHeader.iMsgLength = sizeof(struct ORDER_BOOK_REPORT_RESPONSE);
	pOrdBookRes.IntRespHeader.iErrorId = 0;
	pOrdBookRes.IntRespHeader.iMsgCode = TC_INT_ADMIN_ORDER_REPORT_RESP;
	pOrdBookRes.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
	pOrdBookRes.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;
	strncpy(pOrdBookRes.sPath,FILE_LOCATION,PATH_LEN);

	logDebug2("IntRespHeader.iMsgLength = %d",pOrdBookRes.IntRespHeader.iMsgLength);
	logDebug2("IntRespHeader.iMsgCode = %d", pOrdBookRes.IntRespHeader.iMsgCode);
	logDebug2("IntRespHeader.iUserId = %llu",pOrdBookRes.IntRespHeader.iUserId);
	logDebug2("IntRespHeader.cSource = %c",pOrdBookRes.IntRespHeader.cSource);

	iRelayID = find_admin_adapter(pOrdBookRes.IntRespHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrdBookRes,sizeof(struct ORDER_BOOK_REPORT_RESPONSE) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

}

BOOL fTradeReport(CHAR *RcvMsg)
{
	logTimestamp("Entry :fTradeReport:");

	struct TRADE_BOOK_REPORT_REQUEST *pTrdBookReq;
	struct ORDER_BOOK_REPORT_RESPONSE pOrdBookResp;

	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sTrdBookQry[DOUBLE_MAX_QUERY_SIZE];
	memset (sTrdBookQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;
	CHAR            sClientId [CLIENT_ID_LEN];
	CHAR            sSubTrdBookQry[QUERY_SIZE];
	CHAR		sWhere_Clause[QUERY_SIZE];

	pTrdBookReq= (struct ORDER_BOOK_REPORT_REQUEST *)RcvMsg;

	logDebug2("pTrdBookReq->sClientId :%s:",pTrdBookReq->sClientId);
	logDebug2("pTrdBookReq->sDateFrom :%s:",pTrdBookReq->sDateFrom);
	logDebug2("pTrdBookReq->sDateTo :%s:",pTrdBookReq->sDateTo);
	logDebug2("pTrdBookReq->sPlacedBy :%s:",pTrdBookReq->sPlacedBy);
	logDebug2("pTrdBookReq->cSource :%c:",pTrdBookReq->cSource);
	logDebug2("pTrdBookReq->sSymbol:%s:",pTrdBookReq->sSymbol);

	strncpy(sClientId,pTrdBookReq->sClientId,CLIENT_ID_LEN);
	if(strcmp(pTrdBookReq->sClientId,SELECT_ALL))
	{
		memset(sSubTrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubTrdBookQry," AND CLIENT_ID LIKE \"%s\"",pTrdBookReq->sClientId);
		logDebug2("sSubTrdBookQry= %s",sSubTrdBookQry);
		strcat(sWhere_Clause,sSubTrdBookQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if((strcmp(pTrdBookReq->sDateFrom,SELECT_ALL)) && (strcmp(pTrdBookReq->sDateTo,SELECT_ALL)))
	{
		memset(sSubTrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubTrdBookQry,"AND DATE(Order_DateTime) BETWEEN STR_TO_DATE(\"%s\", '%%d/%%m/%%Y') AND STR_TO_DATE(\"%s\", '%%d/%%m/%%Y')",
				pTrdBookReq->sDateFrom,pTrdBookReq->sDateTo);
		logDebug2("sSubTrdBookQry= %s",sSubTrdBookQry);
		strcat(sWhere_Clause,sSubTrdBookQry);
		logDebug2("sWhere_Clause 3 = %s",sWhere_Clause);
	}
	if(strcmp(pTrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sSubTrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubTrdBookQry," AND EXCH_ID = \"%s\"",pTrdBookReq->ReqHeader.sExcgId);
		logDebug2("sSubTrdBookQry= %s",sSubTrdBookQry);
		strcat(sWhere_Clause,sSubTrdBookQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pTrdBookReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sSubTrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubTrdBookQry," AND SEGMENT = \'%c\'",pTrdBookReq->ReqHeader.cSegment);
		logDebug2("sSubTrdBookQry= %s",sSubTrdBookQry);
		strcat(sWhere_Clause,sSubTrdBookQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pTrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sSubTrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubTrdBookQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pTrdBookReq->sSymbol);
		logDebug2("sSubTrdBookQry= %s",sSubTrdBookQry);
		strcat(sWhere_Clause,sSubTrdBookQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pTrdBookReq->cSource,SELECT_ALL))
	{
		memset(sSubTrdBookQry,'\0',QUERY_SIZE);
		sprintf(sSubTrdBookQry," AND DB_SOURCE = \"%c\"",pTrdBookReq->cSource);
		logDebug2("sSubTrdBookQry= %s",sSubTrdBookQry);
		strcat(sWhere_Clause,sSubTrdBookQry);
		logDebug2("sWhere_Clause11 = %s",sWhere_Clause);
	}

	sprintf(sTrdBookQry,"SELECT \
			CONCAT(Trade_Number,',',Symbol,',',User_Id,',',Client_Id,',',Buy_Sell,',',Product,',',Trade_Quantity,',', \
				Trade_Price,',',Source,',',DB_SORUCE,',',Order_number,',',TRADE_VALUE,',',Order_DateTime,',',PlacedBy,',', \
				EXCH_ID,',',SEGMENT,',',ORDER_TYPE,',',SCRIP_CO,',',CTCLId,',',Order_Time,','Algo_ID,','OrderFlag) \
			FROM \
			(SELECT \
			 Trd_rep.*,\
			 DATE_FORMAT(Trd_rep.Order_DateTime, '%d %b %Y %r') AS 'Order_Time' \
			 FROM \
			 (SELECT \
			  a.EQ_TRD_EXCH_TRADE_NO AS 'Trade_Number',\
			  a.EQ_SYMBOL AS 'Symbol',\
			  a.EQ_USER_ID AS 'User_Id',\
			  a.EQ_CLIENT_ID AS 'Client_Id',\
			  CASE a.EQ_BUY_SELL_IND \
			  WHEN 'B' THEN 'Buy' \
			  WHEN 'S' THEN 'Sell' \
			  END AS 'Buy_Sell',\
			  CASE a.EQ_PRODUCT_ID \
			  WHEN 'C' THEN 'CnC' \
			  WHEN 'M' THEN 'Margin' \
			  WHEN 'L' THEN 'MLB' \
			  WHEN 'S' THEN 'Collateral' \
			  WHEN 'I' THEN 'Intraday' \
			  WHEN 'V' THEN 'CO' \
			  WHEN 'B' THEN 'BO' \
			  ELSE a.EQ_PRODUCT_ID \
			  END AS 'Product',\
			  a.EQ_TOTAL_TRADED_QTY AS 'Trade_Quantity',\
			  CASE TRIM(FORMAT(IFNULL(a.EQ_TRD_TRADE_PRICE, 0), 2)) \ 
			  WHEN '-.01' THEN '0.00' \
			  ELSE TRIM(FORMAT(IFNULL(a.EQ_TRD_TRADE_PRICE, 0), 2)) \
			  END AS 'Trade_Price',\
			  CASE a.EQ_SOURCE_FLG \
			  WHEN 'M' THEN 'Mobile' \
			  WHEN 'W' THEN 'Web' \
			  WHEN 'A' THEN 'Admin' \
			  WHEN 'H' THEN 'HelpDesk' \
			  WHEN 'R' THEN 'RapidRupee' \
			  WHEN 'S' THEN 'RRNext' \
			  WHEN 'I' THEN 'ITS' \
			  END AS 'Source',\
			  a.EQ_SOURCE_FLG as DB_SORUCE,\
			  a.EQ_EXCH_ORDER_NO AS 'Order_number',\
			  ROUND(a.EQ_TRD_TRADE_PRICE * a.EQ_TOTAL_TRADED_QTY, 2) AS 'TRADE_VALUE',\
			  a.EQ_INTERNAL_ENTRY_DATE AS Order_DateTime,\
			  a.EQ_ENTITY_ID AS PlacedBy,\
			  a.EQ_EXCH_ID AS EXCH_ID,\
			  a.EQ_SEGMENT AS SEGMENT,\
			  CASE a.EQ_ORDER_TYPE \
			  WHEN '1' THEN 'MARKET' \
			  WHEN '2' THEN 'LIMIT' \
			  WHEN '3' THEN 'SL-M' \
			  WHEN '4' THEN 'SL' \
			  END AS 'ORDER_TYPE',\
			  a.EQ_SCRIP_CODE AS SCRIP_CO,\
			  8371 CTCLId,\
			  a.EQ_ALGO_ID AS Algo_ID,\
                          CASE a.EQ_STRATEGY_ID\
                          WHEN '101' THEN 'INTRADAY_SQR_OFF' \
                          WHEN '102' THEN 'CO_SQ_OFF'\
                          WHEN '103' THEN 'BO_SQ_OFF'\
                          WHEN '104' THEN 'OFF_ORD_PUMP' \
                          WHEN '105' THEN 'SIP_ORD_PUMP' \
                          WHEN '106' THEN 'MTM_SQR_OFF' \
                          ELSE 'NA' END AS 'OrderFlag' \
			  FROM \
			  EQ_ORDERS_ARCHIVE a, ENTITY_MASTER b \
			  WHERE \
			  a.EQ_CLIENT_ID = b.ENTITY_CODE \
			  AND a.EQ_ALGO_ORDER_NO <> - 1 \
			  AND a.EQ_ORD_STATUS = 'T' UNION ALL SELECT \
			  a.DRV_TRD_EXCH_TRADE_NO AS 'Trade Number',\
			  a.DRV_SYMBOL AS 'Symbol',\           
			  a.DRV_USER_ID AS 'User Id',\
			  a.DRV_CLIENT_ID AS 'Client_Id',\
			  CASE a.DRV_BUY_SELL_IND \
			  WHEN 'B' THEN 'Buy' \
			  WHEN 'S' THEN 'Sell' \
			  END AS 'Buy/Sell',\
			  CASE a.DRV_PRODUCT_ID \
			  WHEN 'C' THEN 'CNC' \
			  WHEN 'M' THEN 'Margin' \
			  WHEN 'L' THEN 'MLB' \
			  WHEN 'S' THEN 'Collateral' \
			  WHEN 'I' THEN 'Intraday' \
			  WHEN 'V' THEN 'CO' \
			  WHEN 'B' THEN 'BO' \
			  ELSE a.DRV_PRODUCT_ID \
			  END AS 'Product',\
			  a.DRV_TOTAL_TRADED_QTY AS 'Trade Quantity',\
			  CASE TRIM(FORMAT(IFNULL(a.DRV_TRD_TRADE_PRICE, 0), 2)) \
			  WHEN '-.01' THEN '0.00' \
			  ELSE TRIM(FORMAT(IFNULL(a.DRV_TRD_TRADE_PRICE, 0), 2)) \
			  END AS 'Trade Price',\
			  CASE a.DRV_SOURCE_FLG \
			  WHEN 'M' THEN 'Mobile' \
			  WHEN 'W' THEN 'Web' \
			  WHEN 'A' THEN 'Admin' \
			  WHEN 'H' THEN 'HelpDesk' \
			  WHEN 'R' THEN 'RapidRupee' \
			  WHEN 'S' THEN 'RRNext' \
			  WHEN 'I' THEN 'ITS' \
			  END AS 'Source',\
			  a.DRV_SOURCE_FLG as DB_SORUCE,\
			  a.DRV_EXCH_ORDER_NO AS 'Order number',\
			  ROUND(a.DRV_TRD_TRADE_PRICE * a.DRV_TOTAL_TRADED_QTY, 2) AS 'TRADE_VALUE',\
			  a.DRV_INTERNAL_ENTRY_DATE AS Order_DateTime,\
			  a.DRV_ENTITY_ID AS PlacedBy,\
			  a.DRV_EXCH_ID AS EXCH_ID,\
			  a.DRV_SEGMENT AS SEGMENT,\
			  CASE a.DRV_ORDER_TYPE \
			  WHEN '1' THEN 'MARKET' \
			  WHEN '2' THEN 'LIMIT' \
			  WHEN '3' THEN 'SL-M' \
			  WHEN '4' THEN 'SL' \
			  END AS 'ORDER_TYPE',\
			  a.DRV_SCRIP_CODE AS SCRIP_CODE,\
			  8371 CTCLId,\
			  a.DRV_ALGO_ID AS Algo_ID,\
                          CASE a.DRV_STRATEGY_ID \
                          WHEN '101' THEN 'INTRADAY_SQR_OFF' \
                          WHEN '102' THEN 'CO_SQ_OFF'\
                          WHEN '103' THEN 'BO_SQ_OFF'\
                          WHEN '104' THEN 'OFF_ORD_PUMP' \
                          WHEN '105' THEN 'SIP_ORD_PUMP' \
                          WHEN '106' THEN 'MTM_SQR_OFF' \
                          ELSE 'NA' END AS 'OrderFlag' \
			  FROM \
			  DRV_ORDERS_ARCHIVE a, ENTITY_MASTER b \
			  WHERE \
			  a.DRV_CLIENT_ID = b.ENTITY_CODE \
			  AND a.DRV_OMS_ALGO_ORD_NO <> - 1 \
			  AND a.DRV_CF_FLAG <> -1 \
			  AND a.DRV_STATUS = 'T') Trd_rep \
			  ORDER BY Trd_rep.Order_DateTime) abv where 1=1 %s order by Order_Time desc;",sWhere_Clause);

	if(mysql_query(DBQury,sTrdBookQry) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}

	Res = mysql_store_result(DBQury);

	while (Row = mysql_fetch_row(Res))
	{
		logDebug2("No of Rows Selected = %d",Row);
		sprintf(sFileName,"%s/%s.csv",FILE_LOCATION,sClientId);
		logDebug2("sFileName = %s",sFileName);
		logDebug2("FILE_LOCATION = %s ",FILE_LOCATION);
		fpFile = fopen(sFileName,"w+");
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in write mode");
			//exit(0);
			return FALSE;
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				logDebug2("Row :%s:",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);
			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
		fclose(fpFile);
		fConvTopwdPrtect(sFileName,CLIENT_FILE_NM,sClientId);
		//strncpy(pOrdBookResp.sFilename,sFileName,FILE_NAME_LEN);
		sprintf(pOrdBookResp.sFilename,"%s.zip",sClientId);
	}
	pOrdBookResp.IntRespHeader.iSeqNo = 0;
	pOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct ORDER_BOOK_REPORT_RESPONSE);
	pOrdBookResp.IntRespHeader.iErrorId = 0;
	pOrdBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CIRCUIT_LIMIT_HEADER_RESP;
	pOrdBookResp.IntRespHeader.iUserId = pTrdBookReq->ReqHeader.iUserId;
	pOrdBookResp.IntRespHeader.cSource = pTrdBookReq->ReqHeader.cSource;
	strncpy(pOrdBookResp.sPath,FILE_LOCATION,PATH_LEN);

	logDebug2("pOrdBookResp.IntRespHeader.iMsgLength = %d",pOrdBookResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdBookResp.IntRespHeader.iMsgCode = %d",pOrdBookResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdBookResp.IntRespHeader.iUserId = %llu",pOrdBookResp.IntRespHeader.iUserId);
	logDebug2("pOrdBookResp.IntRespHeader.cSource = %c",pOrdBookResp.IntRespHeader.cSource);
	logDebug2("pOrdBookResp.sPath = %s",pOrdBookResp.sPath);
	logDebug2("pOrdBookResp.sFileName = %s",pOrdBookResp.sFilename);
	if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrdBookResp,sizeof(struct ORDER_BOOK_REPORT_RESPONSE) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}



}


BOOL	fEquOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("Entry : fEquOrderBookDtls");

	struct 	VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ 	*pViewOrderBookReq;
	struct 	VIEW_ORDER_BOOK_DETAIL_RESP      	pOrderBookResp;
	struct 	VIEW_COMMON_HDR_RESP     		pOrderBookHdrResp;

	CHAR    sEqOrdBook[MAX_QUERY_SIZE];
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	logDebug2("pViewOrderBookReq->fOrderNo = %lf",pViewOrderBookReq->fOrderNo);
	logDebug2("pViewOrderBookReq->iLegNo = %d",pViewOrderBookReq->iLegNo);

	sprintf(sEqOrdBook,"SELECT  EQ_ORDER_NO,EQ_SERIAL_NO,EQ_MSG_CODE,EQ_SCRIP_CODE,EQ_VALIDITY,EQ_PRO_CLIENT,EQ_SOURCE_FLG,EQ_TOTAL_QTY,EQ_REM_QTY,\
			EQ_DISC_QTY,EQ_DISC_REM_QTY,EQ_ORDER_PRICE,EQ_TRIGGER_PRICE,EQ_LAST_TRADE_QTY,EQ_TRD_TRADE_PRICE,EQ_TOTAL_TRADED_QTY,\
			EQ_TRD_EXCH_TRADE_NO,EQ_PRODUCT_ID,EQ_EXCH_ORDER_NO,date_format(EQ_INTERNAL_ENTRY_DATE,\'%%d-%%m-%%Y %%r\'),\
			EQ_ERROR_CODE,EQ_CLIENT_ID,EQ_BUY_SELL_IND,EQ_EXCH_ID,EQ_REASON_DESCRIPTION ,EQ_ENTITY_ID,EQ_STRATEGY_ID,\
			EQ_PRO_CLIENT ,EQ_TRD_TRADE_PRICE ,EQ_GOOD_TILL_DAYS ,EQ_LEG_NO,IFNULL(EQ_PAN_NO,'NA'),EQ_PARTICIPANT_TYPE,EQ_MKT_PROTECT_FLG,\
			EQ_MKT_PROTECT_VAL,EQ_GTC_FLG,EQ_ENCASH_FLG FROM EQ_ORDERS \
			WHERE EQ_ORDER_NO = %lf AND EQ_LEG_NO = %d ORDER BY EQ_ORDER_NO , EQ_SERIAL_NO desc ;",\
			pViewOrderBookReq->fOrderNo,pViewOrderBookReq->iLegNo);

	logDebug3(" fEquOrderBookDtls :%s:",sEqOrdBook);

	if(mysql_query(DBQury,sEqOrdBook) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;

	logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	logDebug2("pOrderBookHdrResp.iNoofRec = %d",pOrderBookHdrResp.iNoofRec);

	if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				//                                iErrorId = atoi(Row[24]);
				//                                logDebug2("atoi(Row[24]) :%d: iErrorId :%d:",atoi(Row[24]),iErrorId);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[24]);
				logDebug2("pOrderBookResp.IntRespHeader.iErrorId :%d:",pOrderBookResp.IntRespHeader.iErrorId);

				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
				pOrderBookResp.IntRespHeader.cSource = Row[6][0];;
				logDebug2("pOrderBookResp.IntRespHeader.cSource = %c",pOrderBookResp.IntRespHeader.cSource);				

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[16]);

				pOrderBookResp.suborderbookdtls[j].sProduct =  Row[17][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18],BSE_EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_TIME_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21],CLIENT_ID_LEN);
				if(Row[22][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				if(strlen(Row[24]) != 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[24],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}
				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);
				if(strlen(Row[31]) == 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
				}
				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
				pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
				pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
				pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
				pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];
				//strncpy(pOrderBookResp.suborderbook[j].sMktType,Row[37],MKT_TYPE_LEN);
				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s: ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
				logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
				logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);
				//logDebug2("pOrderBookResp.suborderbook[%d].sMktType = %s",j,pOrderBookResp.suborderbook[j].sMktType);
			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}
	}  

	logTimestamp("Exit : fEquOrderBookDtls");
	return TRUE;
}


BOOL fDrvOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("Entry : fDrvOrderBookDtls");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ	*pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP      	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     		pOrderBookHdrResp;

	CHAR    sDrvOrdBook[MAX_QUERY_SIZE];
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            cOrdValidity;

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,pViewOrderBookReq->fOrderNo);

	sprintf(sDrvOrdBook,"SELECT  DRV_ORDER_NO,DRV_SERIAL_NO,DRV_MSG_CODE,DRV_SCRIP_CODE,DRV_VALIDITY,DRV_PRO_CLIENT,DRV_SOURCE_FLG,DRV_ORIG_CLORDID,\
			DRV_TOTAL_QTY,DRV_REM_QTY,DRV_DISC_QTY,DRV_DISC_REM_QTY,DRV_ORDER_PRICE,DRV_TRIGGER_PRICE,DRV_TRD_TRADE_QTY,\
			DRV_TRD_TRADE_PRICE,DRV_TOTAL_TRADED_QTY,DRV_TRD_EXCH_TRADE_NO,DRV_PRODUCT_ID,DRV_EXCH_ORDER_NO,\
			IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
			DRV_ERROR_CODE,DRV_CLIENT_ID,DRV_BUY_SELL_IND,DRV_EXCH_ID,DRV_REASON_DESCRIPTION ,DRV_ENTITY_ID ,DRV_STRATEGY_ID ,\
			DRV_PRO_CLIENT ,DRV_TRD_TRADE_PRICE ,DRV_GOOD_TILL_DAYS,IFNULL(DRV_PAN_NO,'NA'),IFNULL(DRV_PARTICIPANT_TYPE,'B'),DRV_MKT_PROTECT_FLG,\
			DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG FROM DRV_ORDERS\
			WHERE DRV_ORDER_NO = %lf\
			AND  DRV_LEG_NO = %d\
			ORDER BY DRV_ORDER_NO , DRV_SERIAL_NO desc ;",pViewOrderBookReq->fOrderNo,pViewOrderBookReq->iLegNo);

	logDebug2(" sDrvOrdBook :%s: ",sDrvOrdBook);

	if(mysql_query(DBQury,sDrvOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in DrvOrdBook Query.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;

	logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				pOrderBookResp.IntRespHeader.cSource = Row[6][0];
				logDebug2("pOrderBookResp.IntRespHeader.cSource = %c",pOrderBookResp.IntRespHeader.cSource);
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[17]);
				pOrderBookResp.suborderbookdtls[j].sProduct = Row[18][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

				if(strlen(Row[25])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				if(Row[23][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice    = atof(Row[29]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);
				if(strlen(Row[31]) == 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
				}

				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
				pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
				pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
				pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
				pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];

				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s:,ErrorID:%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);

				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				//logDebug2("pOrderBookResp.suborderbookdtls[j].fTrdPrice  :%f:",pOrderBookResp.suborderbookdtls[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate:%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType:%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag:%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
				logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
				logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);

			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRtrToRel);
			//return FALSE;
			return FALSE;			
		}
	}

	logTimestamp("Exit : fDrvOrderBookDtls");
	return TRUE;
}


BOOL 	fCOMMOrderBookDtls(CHAR *RcvMsg)
{
	logDebug2("Entry : fCOMMOrderBookDtls");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ 	*pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP      	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     		pOrderBookHdrResp;

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;
	CHAR            *sCOMMOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,pViewOrderBookReq->fOrderNo);

	logDebug2("pViewOrderBookReq->iLegNo = %d",pViewOrderBookReq->iLegNo);

	sprintf(sCOMMOrdBook,"SELECT    COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_MSG_CODE,\
			COMM_SCRIP_CODE,\
			COMM_VALIDITY,\
			COMM_PRO_CLIENT,\
			COMM_SOURCE_FLG,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_TRD_TRADE_QTY,\
			COMM_TRD_TRADE_PRICE,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_TRD_EXCH_TRADE_NO,\
			COMM_PRODUCT_ID,\
			COMM_EXCH_ORDER_NO,\
			COMM_INTERNAL_ENTRY_DATE,\
			COMM_ERROR_CODE,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_EXCH_ID,\
			COMM_REASON_DESCRIPTION ,\
			COMM_ENTITY_ID ,\
			COMM_STRATEGY_ID ,\
			COMM_PRO_CLIENT ,\
			COMM_TRD_TRADE_PRICE ,\
			COMM_GOOD_TILL_DATE, \
			COMM_LEG_NO,\
			IFNULL(COMM_PAN_NO,\"NA\"),\
			IFNULL(COMM_PARTICIPANT_TYPE,'N'),\
			IFNULL(COM_MKT_PROTECT_FLG,'N'),\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG \
			FROM COMM_ORDERS\
			WHERE COMM_ORDER_NO = %lf \
			AND COMM_LEG_NO = %d\
			ORDER BY COMM_ORDER_NO , COMM_SERIAL_NO desc ;",pViewOrderBookReq->fOrderNo,pViewOrderBookReq->iLegNo);
	logDebug2(" sCOMMOrdBook :%s: ",sCOMMOrdBook);

	if(mysql_query(DBQury,sCOMMOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in COMMOrdBook Query.");
		sql_Error(DBQury);
	}

	Res = mysql_store_result(DBQury);

	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;

	/*
	   pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	   pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	   pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	   pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	   pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	   pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;
	//              pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
	 */
	logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ(iTrdRtrToRel , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}
	logInfo("I am in Commodity");	
	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				/*fOrderNo=0;
				  iSerialNo=0;
				  fQty=0;
				  fRemQty=0;
				  fDQQty=0;
				  fDQQtyRem=0;
				  fTrgPrice=0;
				  fTradeQty=0;

				  memset(sBuySellInd ,'\0',5);
				  memset(sSecurityID ,'\0',SECURITY_ID_LEN);
				  memset(sExchOrderNumber ,'\0',BSE_EXCH_ORDER_NO_LEN);
				  memset(sDatetime ,'\0',DATE_STRING_LENGTH);
				  memset(ExcgId ,'\0',EXCHANGE_LEN);
				  memset(sOrdReasonDesc ,'\0',200);
				  sProduct = '\0';
				  Segment = '\0';
				 */
				//	memset(&pOrderBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP));
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				logDebug2("pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				//			strncpy(pOrderBookResp.IntRespHeader.sExcgId,ExcgId ,EXCHANGE_LEN);	
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[24]);
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
				pOrderBookResp.IntRespHeader.cSource = Row[6][0];
				//strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24] ,EXCHANGE_LEN);
				//                pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				//strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24] ,EXCHANGE_LEN);
				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3] ,SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   = atoi(Row[16]);

				pOrderBookResp.suborderbookdtls[j].sProduct = Row[17][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18] ,BSE_EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21] ,CLIENT_ID_LEN);
				//			strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24] ,EXCHANGE_LEN);
				//strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc, Row[25],strlen(sOrdReasonDesc ));
				/*
				   if(sBuySellIndTemp == 'B')
				   {

				   strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				   }
				   else
				   {

				   strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				   }
				 */	
				if(Row[22][0]== 'B')
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				if(strlen(Row[24])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);

				if(strlen(Row[31]) == 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
				}

				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
				pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
				pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
				pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
				pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];                        


				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" pOrderBookResp.IntRespHeader.sExcgId :%s:",pOrderBookResp.IntRespHeader.sExcgId);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
				logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
				logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);
			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ(iTrdRtrToRel , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}

	}
	logTimestamp("Exit :  fCOMMOrderBookDtls");
	return TRUE;

}				

BOOL    fPercentMTM_PR(CHAR *RcvMsg)
{
	logTimestamp("Entry :fPercentMTM_PR");

	struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ	*pReq;
	CHAR    sQry[MAX_QUERY_SIZE];

	pReq = (struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;	 

	logDebug2("pReq->iMode = %d",pReq->iMode);
	logDebug2("pReq->iPercent = %d",pReq->iPercent);
	logDebug2("pReq->ReqHeader.cSegment = %c",pReq->ReqHeader.cSegment);

	sprintf(sQry,"CALL PR_MTM_WATCH(%d,%d,\'%c\')",pReq->iMode,pReq->iPercent,pReq->ReqHeader.cSegment);

	logDebug2("sQry = %s",sQry);

	if(mysql_query(DBQury,sQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN CALL PR_MTM_WATCH sQry.");
		sql_Error(DBQury);
		return  FALSE;
	}

	return TRUE;
	logTimestamp("Exit : fPercentMTM_PR");
}



BOOL	fPercentMTM(CHAR *RcvMsg)
{

	logTimestamp("Entry : fPercentMTM");

        struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ          *pPercentMTMReq;
        struct  VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP        pPerMTMResp;
        struct  VIEW_COMMON_HDR_RESP                            pPerMTMHdrResp;

        CHAR    sPercentQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sMTM_Qry[QUERY_SIZE];
        CHAR    sJoinTable[QUERY_SIZE];

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

        BOOL    ChkFlag = FALSE;

        memset(sWhere_Clause,'\0',QUERY_SIZE);
        memset(sJoinTable,'\0',QUERY_SIZE);
        memset(sPercentQry,'\0',DOUBLE_MAX_QUERY_SIZE);

        pPercentMTMReq = (struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

        logDebug2("pPercentMTMReq->iMode = %d",pPercentMTMReq->iMode);
        logDebug2("pPercentMTMReq->iPercent = %d",pPercentMTMReq->iPercent);
        logDebug2("pPercentMTMReq->iPercent_Value= %f",pPercentMTMReq->iPercent_Value);
        logDebug2("pPercentMTMReq->ReqHeader.cSegment = %c",pPercentMTMReq->ReqHeader.cSegment);
	if(pPercentMTMReq->cUserType == SUPER_ADMIN)
        {
                logDebug2("call fPercentMTM for SUPER_ADMIN");
                if(strcmp(pPercentMTMReq->sClientId,SELECT_ALL))
                {
                        sprintf(sMTM_Qry,"AND NPT_CLIENT_ID LIKE \"%s\"",pPercentMTMReq->sClientId);
                        logDebug2("sMTM_Qry = %s",sMTM_Qry);
                        strcat(sWhere_Clause,sMTM_Qry);
                        logDebug2("sWhere_Clause = %s",sWhere_Clause);
                }



        }
        else if(pPercentMTMReq->cUserType == ADMIN_TYPE)
        {
                logDebug2("call fPercentMTM for ADMIN");
                strcpy(sJoinTable,",ENTITY_MASTER");
                logDebug2("sJoinTable= %s",sJoinTable);
                sprintf(sMTM_Qry,"AND NPT_CLIENT_ID=ENTITY_CODE AND ENTITY_MANAGER_CODE= \"%s\"",pPercentMTMReq->sManager_Code);
                logDebug2("sMTM_Qry = %s",sMTM_Qry);
                strcat(sWhere_Clause,sMTM_Qry);
                logDebug2("sWhere_Clause = %s",sWhere_Clause);
        }

        logDebug2("sJoinTable :%s:",sJoinTable);
        logDebug2("sMTM_Qry   :%s:",sMTM_Qry);
        if(pPercentMTMReq->ReqHeader.cSegment != COMMODITY_SEGMENT)
        {
	
        sprintf(sPercentQry," SELECT X.*FROM (SELECT  CLIENT_ID, TOTAL_BALANCE, BANK_HOLD, ADHOC, SOD, EQ_MTM , DRV_MTM, CUR_MTM, COM_MTM, NET_MTM, MTM, EXPOSURE_EQ , EXPOSURE_EQ_GROSS, EXPOSURE_DR, EXPOSURE_DR_GROSS, EXPOSURE_CDS, EXPOSURE_CDS_GROSS, EXPOSURE_COM, EXPOSURE_COM_GROSS, REALIZE_PROFIT, TOTAL_MTM, RECIEVABLE, OPT_SELL_PREM, IF(INP_SEG IN('A','P'),'A',SEGMENT), OPT_BUY_PREM_CFS, CNC_BUY_VAL, OPT_BUY_VAL, BROK_TRADE, BROK_PEND FROM (SELECT POS.NPT_CLIENT_ID AS CLIENT_ID,@INP_SEG:=\"%c\" AS INP_SEG,      @TOTAL_MTM:=0, @TOTAL_BALANCE:=0, @TOTAL_MTM:=ROUND(FN_MTM_CONSIDER(POS.NET_MTM, IFNULL(POS.NC_REALISED_PROFIT + POS.NC_REALISED_PROFIT_COMM,0), IFNULL(POS.BROKERAGE_TRADE + POS.BROKERAGE_TRADE_COMM,0), IFNULL(POS.BROKERAGE_PEND + POS.BROKERAGE_PEND_COMM,0), POS.RPM_MTM_CONSD_FLAG),2) AS TOTAL_MTM, @TOTAL_BALANCE:=ROUND(FN_TOT_BAL_MTM(POS.C_CASH_BALANCE, (POS.NC_NSE_RECEIVABLES + POS.NC_BSE_RECEIVABLES), POS.C_ADHOC_LIMIT, POS.C_BANK_HOLD, ifnull(POS.OPT_BUY_PREM_CFS + POS.OPT_BUY_PREM_COMM_CFS,0), ifnull(POS.OPT_SELL_PREMIUM + POS.OPT_SELL_PREM_COMM_DAY,0), ifnull(POS.CF_OPT_SELL_PREMIUM + POS.CF_OPT_SELL_PREMIUM_COMM,0), POS.NET_MTM, (POS.NC_REALISED_PROFIT + POS.NC_REALISED_PROFIT_COMM), ifnull(POS.BROKERAGE_TRADE + POS.BROKERAGE_TRADE_COMM,0), ifnull(POS.BROKERAGE_PEND + POS.BROKERAGE_PEND_COMM,0), POS.REQUEST_PAYOUT_AMOUNT,IF(@INP_SEG IN('A','P','E'),ifnull(RCCV.RCCV_COLLATERAL_VALUE,0),0), (POS.TOTAL_CASH_UTILIZED + POS.TOTAL_CASH_UTILIZED_COMM), OPT_BUY_VAL, CNC_BUY_VAL, POS.EQ_CF_MRGN_UTLZ, RPM_TOT_BAL_MTM_FLAG,POS.C_BANK_HOLD_UNCLEAR,IF(@INP_SEG IN('A','P','E'),ifnull(RCCV.RCCV_GROSS_HOLD,0),0)),2) AS TOTAL_BALANCE, CNC_BUY_VAL, OPT_BUY_VAL, IFNULL((POS.C_BANK_HOLD), 0) AS BANK_HOLD, IFNULL(POS.C_ADHOC_LIMIT,0) as ADHOC, IFNULL((POS.C_CASH_BALANCE), 0)AS SOD, POS.EQ_MTM , POS.DRV_MTM , POS.CUR_MTM , POS.COM_MTM, POS.NET_MTM, ROUND((@TOTAL_MTM/@TOTAL_BALANCE)*100,2) AS MTM, POS.EXPOSURE_EQ , POS.EXPOSURE_EQ_GROSS, POS.EXPOSURE_DR, POS.EXPOSURE_DR_GROSS, POS.EXPOSURE_CDS, POS.EXPOSURE_CDS_GROSS, POS.EXPOSURE_COM, POS.EXPOSURE_COM_GROSS, (POS.NC_REALISED_PROFIT + POS.NC_REALISED_PROFIT_COMM) AS REALIZE_PROFIT, (POS.NET_MTM + (POS.NC_REALISED_PROFIT + POS.NC_REALISED_PROFIT_COMM)) AS TOTAL_PNL, IFNULL((POS.NC_NSE_RECEIVABLES), 0) + IFNULL((POS.NC_BSE_RECEIVABLES), 0) AS RECIEVABLE, IFNULL(POS.OPT_SELL_PREMIUM,0) + IFNULL(POS.OPT_SELL_PREM_COMM_DAY,0) AS OPT_SELL_PREM, IFNULL(POS.OPT_BUY_PREM_CFS,0) + IFNULL(POS.OPT_BUY_PREM_COMM_CFS,0) AS OPT_BUY_PREM_CFS, POS.RPM_MTM_ALERT_PERC AS MTM_LEVEL, POS.NPT_EXCH_ID AS EXCH_ID, POS.NPT_SEGMENT AS SEGMENT, POS.RPM_MAX_ORD_VALUE AS SOVL, POS.RPM_MAX_ORD_QTY AS SOQL, POS.RPM_MAX_LOT AS SOLL, POS.RPM_EXCLUDE_CNC_BUY, POS.RPM_EXCLUDE_CNC_SELL, POS.RPM_EXCLUDE_OPT_BUY, POS.RPM_EXCLUDE_OPT_CF_BUY, (POS.BROKERAGE_TRADE + POS.BROKERAGE_TRADE_COMM) AS BROK_TRADE, (POS.BROKERAGE_PEND + POS.BROKERAGE_PEND_COMM) AS BROK_PEND FROM (SELECT NP.NPT_CLIENT_ID, (NP.EQ_MTM + NP.DRV_MTM + NP.CUR_MTM + NP.COM_MTM) AS NET_MTM, NP.EQ_MTM, NP.DRV_MTM, NP.CUR_MTM, NP.COM_MTM, NP.NPT_PROD_ID, NP.NPT_EXCH_ID, NP.NPT_SEGMENT, NP.LIMT_TYPE, NP.RPM_REALIZE_PROFIT, NP.RPM_MTM_ALERT_PERC, NP.RPM_MTM_SQ_OFF_PERC, NP.RPM_MAX_ORD_QTY, NP.RPM_MAX_LOT, NP.RPM_MAX_ORD_VALUE, RFL.C_CASH_BALANCE, RFL.C_LIQUID_BALANCE, RFL.C_ADHOC_LIMIT, RFL.NC_NSE_RECEIVABLES, RFL.NC_BSE_RECEIVABLES, RFL.C_BANK_HOLD, RFL.NC_COLLATERALS, RFL.NC_REALISED_PROFIT_COMM, RFL.NC_REALISED_PROFIT, RFL.REQUEST_PAYOUT_AMOUNT, RFL.BROKERAGE_TRADE, RFL.BROKERAGE_TRADE_COMM, RFL.BROKERAGE_PEND, RFL.BROKERAGE_PEND_COMM, RFL.CF_OPT_SELL_PREMIUM, RFL.OPT_BUY_PREM_CFS, RFL.OPT_SELL_PREMIUM, RFL.CF_OPT_SELL_PREMIUM_COMM, RFL.OPT_SELL_PREM_COMM_DAY, RFL.OPT_BUY_PREM_COMM_CFS, RFL.EQ_CF_MRGN_UTLZ, RFL.TOTAL_CASH_UTILIZED , RFL.TOTAL_CASH_UTILIZED_COMM,RFL.C_BANK_HOLD_UNCLEAR, CNC_BUY_VAL, OPT_BUY_VAL, RPM_DEDUCT_CNC_MARG, RPM_DEDUCT_OPT_MARG, NP.RPM_EXCLUDE_CNC_BUY, NP.RPM_EXCLUDE_CNC_SELL, NP.RPM_EXCLUDE_OPT_BUY, NP.RPM_EXCLUDE_OPT_CF_BUY, NP.RPM_MTM_CONSD_FLAG, NP.RPM_TOT_BAL_MTM_FLAG, NP.EXPOSURE_EQ , NP.EXPOSURE_EQ_GROSS, NP.EXPOSURE_DR, NP.EXPOSURE_DR_GROSS, NP.EXPOSURE_CDS, NP.EXPOSURE_CDS_GROSS, NP.EXPOSURE_COM, NP.EXPOSURE_COM_GROSS FROM (SELECT NPT.NPT_CLIENT_ID, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'E' THEN (CASE WHEN NPT.NPT_NET_QTY > 0 THEN (CASE WHEN RPM.RPM_EXCLUDE_CNC_BUY='Y' AND NPT.NPT_PROD_ID = 'C' THEN 0 ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG) END) ELSE (CASE WHEN RPM.RPM_EXCLUDE_CNC_SELL='Y' AND NPT.NPT_PROD_ID = 'C' THEN 0 ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG) END) END) ELSE 0 END),0) AS EQ_MTM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'D' THEN (CASE WHEN NPT.NPT_NET_QTY > 0 THEN (CASE WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%' THEN (CASE WHEN RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0 THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0 END) + (CASE WHEN RPM.RPM_EXCLUDE_OPT_CF_BUY='N' AND NPT_TOT_BUY_QTY_CF >0 THEN (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0 END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG) END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG) END) ELSE 0 END),0)AS DRV_MTM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'C' THEN (CASE WHEN NPT.NPT_NET_QTY > 0 THEN (CASE WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%' THEN (CASE WHEN RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0 THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0 END) + (CASE WHEN RPM.RPM_EXCLUDE_OPT_CF_BUY='N' AND NPT_TOT_BUY_QTY_CF >0 THEN (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0 END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG) END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG) END) * 1000 ELSE 0 END),0)AS CUR_MTM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'M' THEN (CASE WHEN NPT.NPT_NET_QTY > 0 THEN (CASE WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%' THEN (CASE WHEN RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0 THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0 END) + (CASE WHEN RPM.RPM_EXCLUDE_OPT_CF_BUY='N' AND NPT_TOT_BUY_QTY_CF >0 THEN (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0 END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG) END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG) END) * NPT.NPT_MCX_MULTIPLIER ELSE 0 END),0) AS COM_MTM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'E' THEN NPT.NPT_NET_VAL ELSE '0' END),0) AS EXPOSURE_EQ, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'E' THEN abs(NPT.NPT_NET_VAL) ELSE 0 END),0) AS EXPOSURE_EQ_GROSS, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'D' THEN NPT.NPT_NET_VAL ELSE '0' END),0) AS EXPOSURE_DR, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'D' THEN ABS(NPT.NPT_NET_VAL) ELSE 0 END),0) AS EXPOSURE_DR_GROSS, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'C' THEN NPT.NPT_NET_VAL ELSE '0' END),0) AS EXPOSURE_CDS, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'C' THEN ABS(NPT.NPT_NET_VAL) ELSE 0 END),0) AS EXPOSURE_CDS_GROSS, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'M' THEN NPT.NPT_NET_VAL ELSE '0' END),0) AS EXPOSURE_COM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'M' THEN ABS(NPT.NPT_NET_VAL) ELSE 0 END),0) AS EXPOSURE_COM_GROSS, NPT.NPT_PROD_ID, NPT.NPT_EXCH_ID, NPT.NPT_SEGMENT, (CASE WHEN NPT.NPT_SEGMENT = 'M' THEN 'COMMODITY' ELSE 'CAPITAL' END) AS LIMT_TYPE, RPM.RPM_REALIZE_PROFIT, RPM.RPM_MTM_ALERT_PERC, RPM.RPM_MTM_SQ_OFF_PERC, RPM.RPM_REALIZE_PROFIT_SUBS, RPM.RPM_MAX_ORD_QTY, RPM.RPM_MAX_LOT, RPM.RPM_MAX_ORD_VALUE, RPM.RPM_EXCLUDE_CNC_BUY, RPM.RPM_EXCLUDE_CNC_SELL, RPM.RPM_EXCLUDE_OPT_BUY, RPM.RPM_EXCLUDE_OPT_CF_BUY, RPM.RPM_DEDUCT_CNC_MARG, RPM.RPM_DEDUCT_OPT_MARG, RPM.RPM_MTM_CONSD_FLAG, RPM.RPM_TOT_BAL_MTM_FLAG, SUM(CASE WHEN NPT_PROD_ID = 'C' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) > 0 THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) * (NPT.NPT_TOT_BUY_VAL_DAY/NPT.NPT_TOT_BUY_QTY_DAY) ELSE 0 END) AS CNC_BUY_VAL, SUM(CASE WHEN NPT_INSTRUMENT LIKE 'OPT%%' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) > 0 AND NPT_PROD_ID not in( 'I','V','B') THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) *(NPT.NPT_TOT_BUY_VAL_DAY/NPT.NPT_TOT_BUY_QTY_DAY) ELSE 0 END) AS OPT_BUY_VAL FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE) LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE) WHERE NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT AND (NPT.NPT_SEGMENT NOT LIKE(CASE \"%c\" WHEN 'P' THEN 'M' when 'A' then 'aaaaa' ELSE '%%' END) or NPT.NPT_SEGMENT LIKE (CASE WHEN \"%c\" NOT IN('P','A') THEN \"%c\" ELSE 'AAAAA' END)) GROUP BY NPT.NPT_CLIENT_ID) AS NP, RMS_FUND_LIMIT RFL %s WHERE NP.NPT_CLIENT_ID = RFL.CLIENT_ID %s AND RFL.SEGMENT=IF(\"%c\" IN('P','A'),'A',NP.NPT_SEGMENT)) AS POS LEFT JOIN RMS_CLIENT_COLLATERAL_VALUE RCCV ON (POS.NPT_CLIENT_ID = RCCV.RCCV_CLIENT_ID)) AS COM_LIM WHERE (MTM < -1 * (%d) or MTM like if(%d=0,'%%','NA') and abs(MTM)<>0) AND (TOTAL_MTM < -1 * (%f) OR TOTAL_MTM LIKE IF(%f = 0,'%%','NA'))) X;",pPercentMTMReq->ReqHeader.cSegment,pPercentMTMReq->ReqHeader.cSegment,pPercentMTMReq->ReqHeader.cSegment,pPercentMTMReq->ReqHeader.cSegment,sJoinTable,sWhere_Clause,pPercentMTMReq->ReqHeader.cSegment,pPercentMTMReq->iPercent,pPercentMTMReq->iPercent,pPercentMTMReq->iPercent_Value,pPercentMTMReq->iPercent_Value);
        }
	else
        {
		sprintf(sPercentQry," SELECT X.*FROM (SELECT   CLIENT_ID, TOTAL_BALANCE, BANK_HOLD, ADHOC, SOD, 0 AS EQ_MTM , 0 AS DRV_MTM , 0 AS CUR_MTM , COM_MTM, NET_MTM, MTM, 0 AS EXPOSURE_EQ ,  0 AS EXPOSURE_EQ_GROSS, 0 AS EXPOSURE_DR, 0 AS EXPOSURE_DR_GROSS, 0 AS EXPOSURE_CDS,  0 AS EXPOSURE_CDS_GROSS,  EXPOSURE_COM, EXPOSURE_COM_GROSS, REALIZE_PROFIT, TOTAL_MTM, RECIEVABLE, OPT_SELL_PREM, SEGMENT, OPT_BUY_PREM_CFS, CNC_BUY_VAL, OPT_BUY_VAL, BROK_TRADE, BROK_PEND FROM (SELECT POS.NPT_CLIENT_ID AS CLIENT_ID, @TOTAL_MTM:=0,  @TOTAL_BALANCE:=0,  @TOTAL_MTM:=FN_MTM_CONSIDER(POS.NET_MTM,  IFNULL(POS.RMLC_NC_REALISED_PROFIT,0), IFNULL(POS.RMLC_BROKERAGE_TRADE,0), IFNULL(POS.RMLC_BROKERAGE_PEND,0), POS.RPM_MTM_CONSD_FLAG) AS TOTAL_MTM, @TOTAL_BALANCE:=FN_TOT_BAL_MTM(POS.RMLC_C_CASH_BALANCE,  0,  POS.RMLC_C_ADHOC_LIMIT,  POS.RMLC_C_BANK_HOLD, ifnull( POS.RMLC_OPT_BUY_PREM_CFS,0), ifnull( POS.RMLC_OPT_SELL_PREM_DAY,0), ifnull( POS.RMLC_CF_OPT_SELL_PREMIUM,0),  POS.NET_MTM, ( POS.RMLC_NC_REALISED_PROFIT), ifnull(POS.RMLC_BROKERAGE_TRADE,0), ifnull( POS.RMLC_BROKERAGE_PEND,0), POS.RMLC_REQUEST_PAYOUT_AMOUNT,  0, ( POS.RMLC_TOTAL_CASH_UTILIZED), OPT_BUY_VAL, CNC_BUY_VAL, 0, RPM_TOT_BAL_MTM_FLAG,POS.C_BANK_HOLD_UNCLEAR,0) AS TOTAL_BALANCE, CNC_BUY_VAL,  OPT_BUY_VAL,  IFNULL((POS.RMLC_C_BANK_HOLD), 0) AS BANK_HOLD, IFNULL(POS.RMLC_C_ADHOC_LIMIT,0) as ADHOC, IFNULL((POS.RMLC_C_CASH_BALANCE), 0)AS SOD, POS.COM_MTM, POS.NET_MTM,  ROUND((@TOTAL_MTM/@TOTAL_BALANCE)*100,2) AS MTM,  POS.EXPOSURE_COM, POS.EXPOSURE_COM_GROSS, (POS.RMLC_NC_REALISED_PROFIT) AS REALIZE_PROFIT, (POS.NET_MTM + POS.RMLC_NC_REALISED_PROFIT) AS TOTAL_PNL,  0 AS RECIEVABLE, IFNULL(POS.RMLC_OPT_SELL_PREM_DAY,0)  AS OPT_SELL_PREM, IFNULL(POS.RMLC_OPT_BUY_PREM_CFS,0)  AS OPT_BUY_PREM_CFS, POS.RPM_MTM_ALERT_PERC AS MTM_LEVEL, POS.NPT_EXCH_ID AS EXCH_ID, POS.NPT_SEGMENT AS SEGMENT, POS.RPM_MAX_ORD_VALUE AS SOVL, POS.RPM_MAX_ORD_QTY AS SOQL, POS.RPM_MAX_LOT AS SOLL, POS.RPM_EXCLUDE_CNC_BUY, POS.RPM_EXCLUDE_CNC_SELL, POS.RPM_EXCLUDE_OPT_BUY, POS.RPM_EXCLUDE_OPT_CF_BUY, IFNULL(POS.RMLC_BROKERAGE_TRADE,0) AS BROK_TRADE, IFNULL(POS.RMLC_BROKERAGE_PEND,0) AS BROK_PEND FROM (SELECT NP.NPT_CLIENT_ID, (NP.COM_MTM) AS NET_MTM, NP.COM_MTM, NP.NPT_PROD_ID, NP.NPT_EXCH_ID, NP.NPT_SEGMENT, NP.LIMT_TYPE, NP.RPM_REALIZE_PROFIT, NP.RPM_MTM_ALERT_PERC, NP.RPM_MTM_SQ_OFF_PERC, NP.RPM_MAX_ORD_QTY, NP.RPM_MAX_LOT, NP.RPM_MAX_ORD_VALUE, RFL.RMLC_C_CASH_BALANCE, RFL.RMLC_C_ADHOC_LIMIT, RFL.RMLC_C_BANK_HOLD, RFL.RMLC_NC_REALISED_PROFIT, RFL.RMLC_REQUEST_PAYOUT_AMOUNT, RFL.RMLC_BROKERAGE_TRADE, RFL.RMLC_BROKERAGE_PEND, RFL.RMLC_CF_OPT_SELL_PREMIUM, RFL.RMLC_OPT_BUY_PREM_CFS, RFL.RMLC_OPT_SELL_PREM_DAY, RFL.RMLC_TOTAL_CASH_UTILIZED,RFL.C_BANK_HOLD_UNCLEAR , CNC_BUY_VAL, OPT_BUY_VAL, RPM_DEDUCT_CNC_MARG, RPM_DEDUCT_OPT_MARG, NP.RPM_EXCLUDE_CNC_BUY, NP.RPM_EXCLUDE_CNC_SELL, NP.RPM_EXCLUDE_OPT_BUY, NP.RPM_EXCLUDE_OPT_CF_BUY, NP.RPM_MTM_CONSD_FLAG, NP.RPM_TOT_BAL_MTM_FLAG, NP.EXPOSURE_COM,  NP.EXPOSURE_COM_GROSS FROM (SELECT NPT.NPT_CLIENT_ID, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'M' THEN (CASE WHEN NPT.NPT_NET_QTY > 0 THEN (CASE  WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'  THEN  (CASE WHEN RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0 THEN  (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0  END) +  (CASE WHEN  RPM.RPM_EXCLUDE_OPT_CF_BUY='N'  AND NPT_TOT_BUY_QTY_CF >0 THEN  (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)  ELSE 0  END)  ELSE  NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)  END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG) END) * NPT.NPT_MCX_MULTIPLIER ELSE 0 END),0) AS COM_MTM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'M' THEN  NPT.NPT_NET_VAL ELSE '0' END),0)  AS EXPOSURE_COM, IFNULL(SUM(CASE WHEN NPT.NPT_SEGMENT = 'M' THEN  ABS(NPT.NPT_NET_VAL) ELSE 0 END),0) AS EXPOSURE_COM_GROSS, NPT.NPT_PROD_ID, NPT.NPT_EXCH_ID, NPT.NPT_SEGMENT, (CASE WHEN NPT.NPT_SEGMENT = 'M' THEN 'COMMODITY' ELSE 'CAPITAL' END) AS LIMT_TYPE, RPM.RPM_REALIZE_PROFIT, RPM.RPM_MTM_ALERT_PERC, RPM.RPM_MTM_SQ_OFF_PERC, RPM.RPM_REALIZE_PROFIT_SUBS, RPM.RPM_MAX_ORD_QTY, RPM.RPM_MAX_LOT, RPM.RPM_MAX_ORD_VALUE, RPM.RPM_EXCLUDE_CNC_BUY, RPM.RPM_EXCLUDE_CNC_SELL, RPM.RPM_EXCLUDE_OPT_BUY, RPM.RPM_EXCLUDE_OPT_CF_BUY, RPM.RPM_DEDUCT_CNC_MARG, RPM.RPM_DEDUCT_OPT_MARG, RPM.RPM_MTM_CONSD_FLAG, RPM.RPM_TOT_BAL_MTM_FLAG, SUM(CASE WHEN NPT_PROD_ID = 'C' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) > 0 THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) * (NPT.NPT_TOT_BUY_VAL_DAY/NPT.NPT_TOT_BUY_QTY_DAY) ELSE 0 END) AS CNC_BUY_VAL, SUM(CASE WHEN NPT_INSTRUMENT LIKE 'OPT%%' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) > 0 AND NPT_PROD_ID not in( 'I','V','B') THEN (NPT.NPT_TOT_BUY_QTY_DAY-NPT_TOT_SELL_QTY) *(NPT.NPT_TOT_BUY_VAL_DAY/NPT.NPT_TOT_BUY_QTY_DAY) ELSE 0 END) AS OPT_BUY_VAL FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE) LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON (NPT.NPT_RPM_CODE = RPM.RPM_CODE) WHERE NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT and NPT.NPT_SEGMENT=\"%c\" GROUP BY NPT.NPT_CLIENT_ID,NPT.NPT_SEGMENT ) AS NP, RMS_FUND_LIMIT_COM RFL %s WHERE NP.NPT_CLIENT_ID = RFL.RMLC_CLIENT_ID %s ) AS POS LEFT JOIN RMS_CLIENT_COLLATERAL_VALUE RCCV ON (POS.NPT_CLIENT_ID = RCCV.RCCV_CLIENT_ID)) AS COM_LIM WHERE (MTM < -1 * (%d) or MTM like if(%d=0,'%%','NA') and abs(MTM)<>0) AND (TOTAL_MTM < -1 * (%f) OR TOTAL_MTM LIKE IF(%f = 0,'%%','NA'))) X;",pPercentMTMReq->ReqHeader.cSegment,sJoinTable,sWhere_Clause,pPercentMTMReq->iPercent,pPercentMTMReq->iPercent,pPercentMTMReq->iPercent_Value,pPercentMTMReq->iPercent_Value);
        }

        printf("sMarginQry = %s \n",sPercentQry);
	if(mysql_query(DBQury,sPercentQry ) != SUCCESS)
        {
                logSqlFatal("ERROR in sPercentQry.");
                sql_Error(DBQury);
		return FALSE;
        }
	Res = mysql_store_result(DBQury);

        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
	 iTempNoOfRec = iNoOfPkt;

        pPerMTMHdrResp.IntRespHeader.iSeqNo = 0;
        pPerMTMHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pPerMTMHdrResp.IntRespHeader.iErrorId = 0;
        pPerMTMHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_PERCENT_MTM_HEADER_RESP;
        pPerMTMHdrResp.IntRespHeader.iUserId = pPercentMTMReq->ReqHeader.iUserId;
        pPerMTMHdrResp.IntRespHeader.cSource = pPercentMTMReq->ReqHeader.cSource ;
        pPerMTMHdrResp.cMsgType = 'H';
        pPerMTMHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pPerMTMHdrResp.IntRespHeader.iMsgLength = %d",pPerMTMHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pPerMTMHdrResp.IntRespHeader.iMsgCode = %d",pPerMTMHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pPerMTMHdrResp.IntRespHeader.iUserId = %d",pPerMTMHdrResp.IntRespHeader.iUserId);
        logDebug2("pPerMTMHdrResp.IntRespHeader.cSource = %c",pPerMTMHdrResp.IntRespHeader.cSource);
        logDebug2("pPerMTMHdrResp.iNoofRec = %d",pPerMTMHdrResp.iNoofRec);

        logDebug2("pPercentMTMReq->ReqHeader.iUserId = %d",pPercentMTMReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pPercentMTMReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }
        if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pPerMTMHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logFatal("Write Q id %d", iTrdRtrToRel);	
		return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                logDebug2("no of pkt ( i ) = %d",i);
                memset(&pPerMTMResp,'\0',sizeof(struct VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP));
                pPerMTMResp.IntRespHeader.iSeqNo = 0;
                pPerMTMResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP);
                pPerMTMResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_PERCENT_MTM_QUERY_RESP;
                pPerMTMResp.IntRespHeader.iErrorId = 0;
                pPerMTMResp.IntRespHeader.iUserId = pPercentMTMReq->ReqHeader.iUserId;
                pPerMTMResp.IntRespHeader.cSource = pPercentMTMReq->ReqHeader.cSource ;
                pPerMTMResp.IntRespHeader.cSegment = pPercentMTMReq->ReqHeader.cSegment;

                logDebug2("pPerMTMResp.IntRespHeader.cSegment = %c",pPerMTMResp.IntRespHeader.cSegment);

                if(iTempNoOfRec <= 1)
                {
                        pPerMTMResp.cMsgType = 'T';
                }
                else
                {
                        pPerMTMResp.cMsgType = 'D';
                }


                for(j=0;j<5;j++)
                {
                        if((Row = mysql_fetch_row(Res)))
                        {
			 strncpy( pPerMTMResp.subViewPercent[j].sClientId,Row[0],CLIENT_ID_LEN);
                                        pPerMTMResp.subViewPercent[j].fTotalBal = atof(Row[1]);
                                        pPerMTMResp.subViewPercent[j].fBankHodl = atof(Row[2]);
                                        pPerMTMResp.subViewPercent[j].fAdhoc = atof(Row[3]);
                                        pPerMTMResp.subViewPercent[j].fLimit_SOD = atof(Row[4]);
                                        pPerMTMResp.subViewPercent[j].fMTMKT_EQ = atof(Row[5]);
                                        pPerMTMResp.subViewPercent[j].fMTMKT_DR = atof(Row[6]);
                                        pPerMTMResp.subViewPercent[j].fMTM_cds= atof(Row[7]);
                                        pPerMTMResp.subViewPercent[j].fMTMKT_COMM = atof(Row[8]);
                                        pPerMTMResp.subViewPercent[j].fTotalMTM = atof(Row[9]);
                                        pPerMTMResp.subViewPercent[j].fMTM_PER = atof(Row[10]);
                                        pPerMTMResp.subViewPercent[j].fEXPO_EQ = atof(Row[11]);
                                        pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS = atof(Row[12]);
                                        pPerMTMResp.subViewPercent[j].fEXPO_DR = atof(Row[13]);
                                        pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS = atof(Row[14]);                                                                
					pPerMTMResp.subViewPercent[j].fExposure_cds = atof(Row[15]);
                                        pPerMTMResp.subViewPercent[j].fExposure_cds_gross = atof(Row[16]);
                                        pPerMTMResp.subViewPercent[j].fExpo_COMM = atof(Row[17]);
                                        pPerMTMResp.subViewPercent[j].fExpo_COMM_gross = atof(Row[18]);
                                        pPerMTMResp.subViewPercent[j].fRealised_Profit = atof(Row[19]);
                                        pPerMTMResp.subViewPercent[j].fRealised_MTM = atof(Row[20]);
                                        pPerMTMResp.subViewPercent[j].fReceivables = atof(Row[21]);
                                        pPerMTMResp.subViewPercent[j].fOpt_sell_prm = atof(Row[22]);
                                        pPerMTMResp.subViewPercent[j].fOpt_buy_prem = atof(Row[24]);
                                        pPerMTMResp.subViewPercent[j].fCnc_buy_val = atof(Row[25]);
                                        pPerMTMResp.subViewPercent[j].fOpt_buy_val = atof(Row[26]);
                                        pPerMTMResp.subViewPercent[j].fBrok_trade = atof(Row[27]);
                                        pPerMTMResp.subViewPercent[j].fBrok_pend = atof(Row[28]);


                                logDebug2(" pPerMTMResp.subViewPercent[%d].sClientId = %s",j,pPerMTMResp.subViewPercent[j].sClientId);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fTotalBal = %lf",j,pPerMTMResp.subViewPercent[j].fTotalBal);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fBankHodl = %lf",j,pPerMTMResp.subViewPercent[j].fBankHodl);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fAdhoc = %lf",j,pPerMTMResp.subViewPercent[j].fAdhoc);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fLimit_SOD = %lf",j,pPerMTMResp.subViewPercent[j].fLimit_SOD);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fMTMKT_EQ = %lf",j,pPerMTMResp.subViewPercent[j].fMTMKT_EQ);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fMTMKT_DR = %lf",j,pPerMTMResp.subViewPercent[j].fMTMKT_DR);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fTotalMTM = %lf",j,pPerMTMResp.subViewPercent[j].fTotalMTM);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fMTM_PER = %lf",j,pPerMTMResp.subViewPercent[j].fMTM_PER);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fEXPO_EQ = %lf",j,pPerMTMResp.subViewPercent[j].fEXPO_EQ);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fEXPO_EQ_GROSS = %lf",j,pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fEXPO_DR = %lf",j,pPerMTMResp.subViewPercent[j].fEXPO_DR);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fEXPO_DR_GROSS = %lf",j,pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fRealised_Profit = %lf",j,pPerMTMResp.subViewPercent[j].fRealised_Profit);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fRealised_MTM = %lf",j,pPerMTMResp.subViewPercent[j].fRealised_MTM);
				 logDebug2(" pPerMTMResp.subViewPercent[%d].fMTM_cds = %lf",j,pPerMTMResp.subViewPercent[j].fMTM_cds);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExposure_cds= %lf",j,pPerMTMResp.subViewPercent[j].fExposure_cds);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExposure_cds_gross= %lf",j,pPerMTMResp.subViewPercent[j].fExposure_cds_gross);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fReceivables = %lf",j,pPerMTMResp.subViewPercent[j].fReceivables);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fOpt_sell_prm = %lf",j,pPerMTMResp.subViewPercent[j].fOpt_sell_prm );
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fCollaterals = %lf",j,pPerMTMResp.subViewPercent[j].fCollaterals );
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fGrossHoldVal = %lf",j,pPerMTMResp.subViewPercent[j].fGrossHoldVal );
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fMTMKT_COMM= %lf",j,pPerMTMResp.subViewPercent[j].fMTMKT_COMM);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM= %lf",j,pPerMTMResp.subViewPercent[j].fExpo_COMM);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM_gross= %lf",j,pPerMTMResp.subViewPercent[j].fExpo_COMM_gross);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM_gross= %lf",j,pPerMTMResp.subViewPercent[j].fOpt_buy_prem);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM_gross= %lf",j,pPerMTMResp.subViewPercent[j].fCnc_buy_val);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM_gross= %lf",j,pPerMTMResp.subViewPercent[j].fOpt_buy_val);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM_gross= %lf",j,pPerMTMResp.subViewPercent[j].fBrok_trade);
                                logDebug2(" pPerMTMResp.subViewPercent[%d].fExpo_COMM_gross= %lf",j,pPerMTMResp.subViewPercent[j].fBrok_pend);
                                logDebug2(" pPerMTMResp.cMsgType = %c",pPerMTMResp.cMsgType);
                        }
                }

                if(( WriteMsgQ(iTrdRtrToRel , (CHAR *)& pPerMTMResp,sizeof(struct VIEW_ADMIN_PERCENT_MTM_COMMON_QUERY_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logDebug2("Write Q id %d", iTrdRtrToRel);
			return FALSE;
                }
                iTempNoOfRec--;
	 }

        logTimestamp("Exit : fPercentMTM");
        return TRUE;

}

BOOL    fMarginShortFall_PR(CHAR *RcvMsg)
{
	logTimestamp("Entry :fMarginShortFall_PR");

	struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *pMarginShortFallReq;

	pMarginShortFallReq = (struct VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

	CHAR    sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);
	sprintf(sQry,"CALL PR_MARGIN_SHORTFALL(%d,\'%c\')",pMarginShortFallReq->iMode,pMarginShortFallReq->ReqHeader.cSegment);

	logDebug2("sQry = %s",sQry);

	if(mysql_query(DBQury,sQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN PR_MARGIN_SHORTFALL_CAPITAL sQRY.");
		sql_Error(DBQury);
		return  FALSE;
	}



	logTimestamp("Exit : fMarginShortFall_PR");
	return TRUE;
}

BOOL    fMarginShortFall_PR_COM(CHAR *RcvMsg)
{
	logTimestamp("Entry :fMarginShortFall_PR_COM");

	struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *pMarginShortFallReq;

	pMarginShortFallReq = (struct VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

	CHAR    sQry[MAX_QUERY_SIZE];
	memset(sQry,'\0',MAX_QUERY_SIZE);
	sprintf(sQry,"CALL PR_MARGIN_SHORTFALL_COM(%d)",pMarginShortFallReq->iMode);

	logDebug2("sQry = %s",sQry);

	if(mysql_query(DBQury,sQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN PR_MARGIN_SHORTFALL_COM sQRY.");
		sql_Error(DBQury);
		return  FALSE;
	}



	logTimestamp("Exit : fMarginShortFall_PR_COM");
	return TRUE;
}

BOOL    fMarginShortFall(CHAR *RcvMsg)
{

	 logTimestamp("Entry : fMarginShortFall");

        struct  VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ        *pViewMarginShrtfallReq;
        struct  VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP       pMarginShrtfallResp;
        struct  VIEW_COMMON_HDR_RESP                    pMarShrtfallHdrResp;

        pViewMarginShrtfallReq = (struct VIEW_ADMIN_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

        CHAR    sMarginQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sMarg_Qry[QUERY_SIZE];

        LONG32          i=0,j=0;
        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec = 0.00 ;
        LONG32          iNoOfPkt = 0;
        LONG32          iTempNoOfRec = 0;

        BOOL ChkFlag = FALSE;

        memset(sWhere_Clause,'\0',QUERY_SIZE);
        memset(sMarginQry,'\0',DOUBLE_MAX_QUERY_SIZE);

        logDebug2("pViewMarginShrtfallReq->iMode = %d",pViewMarginShrtfallReq->iMode);
        logDebug2("pViewMarginShrtfallReq->sClientId = %s",pViewMarginShrtfallReq->sClientId);
        logDebug2("pViewMarginShrtfallReq->sClientName = %s",pViewMarginShrtfallReq->sClientName);

        logDebug2("pViewMarginShrtfallReq->ReqHeader.cSegment :%c:",pViewMarginShrtfallReq->ReqHeader.cSegment);

        BOOL    iChkBrcnh = FALSE;
        CHAR    sBrchId[BRANCH_ID_LEN];
        memset(sBrchId,'\0',BRANCH_ID_LEN);

        CHAR    sBrchClaus[QUERY_SIZE];
        memset(sBrchClaus,'\0',QUERY_SIZE);
        iChkBrcnh = fChckAdminContrlr(pViewMarginShrtfallReq->sEntityId,&sBrchId);

        if(iChkBrcnh == TRUE)
        {
                sprintf(sBrchClaus ," AND CLIENT_ID_A in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
        }
        else
        {
                sprintf(sBrchClaus ," ");
        }

        logDebug2(" sBrchClaus :%s:",sBrchClaus);
	 if(strcmp(pViewMarginShrtfallReq->sClientId,SELECT_ALL))
        {
                memset(sMarg_Qry,'\0',QUERY_SIZE);
                sprintf(sMarg_Qry,"AND CLIENT_ID LIKE \"%s\"",pViewMarginShrtfallReq->sClientId);
                logDebug2("sMarg_Qry = %s",sMarg_Qry);
                strcat(sWhere_Clause,sMarg_Qry);
                logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
        }
        if(pViewMarginShrtfallReq->iShortFallFlag == MARGIN_SHORTFALL_FLAG)
        {
                memset(sMarg_Qry,'\0',QUERY_SIZE);
                sprintf(sMarg_Qry,"AND SHORTFALL_VALUE < 0");
                logDebug2("sMarg_Qry = %s",sMarg_Qry);
                strcat(sWhere_Clause,sMarg_Qry);
                logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
        }

        logDebug2("final sWhere_Clause = %s",sWhere_Clause);

        logDebug2("pViewMarginShrtfallReq->cUserType = %c",pViewMarginShrtfallReq->cUserType);
        logDebug2("pViewMarginShrtfallReq->sManager_Code = %s",pViewMarginShrtfallReq->sManager_Code);
	if (pViewMarginShrtfallReq->ReqHeader.cSegment != COMMODITY_SEGMENT)
        {
	 sprintf(sMarginQry,"SELECT CLIENT_ID_A,  ROUND(SPAN_MARGIN,2) AS SPAN_MARGIN,  ROUND(EX.EXPO_MARGIN,2) AS EXPOSURE_MARGIN,   ROUND((SPAN_MARGIN + EX.EXPO_MARGIN),2) AS TOTAL_MARGIN,   NET_OPTION,   ROUND(SHORT_OPTION_PREMIUM,2) AS SELL_OPTION_PREMIUM,  ROUND(FN_TOT_BAL_MARGIN(OOOL.C_CASH_BALANCE,   0,   0,      (OOOL.NC_NSE_RECEIVABLES + OOOL.NC_BSE_RECEIVABLES),   OOOL.C_BANK_HOLD, if(OOOL.SEGMENT IN('E','A'),ifnull(RCCV.RCCV_COLLATERAL_VALUE,0),0),   (OOOL.NC_REALISED_PROFIT + OOOL.NC_REALISED_PROFIT_COMM),   ifnull(OOOL.OPT_BUY_PREM_CFS + OOOL.OPT_BUY_PREM_COMM_CFS,0),   ifnull(OOOL.OPT_SELL_PREMIUM + OOOL.OPT_SELL_PREM_COMM_DAY,0),   ifnull(OOOL.CF_OPT_SELL_PREMIUM + OOOL.CF_OPT_SELL_PREMIUM_COMM,0),   OOOL.REQUEST_PAYOUT_AMOUNT, 'L', 'L', 'L', 'L', 'L',   TOT_MARG_FLAG,OOOL.C_BANK_HOLD_UNCLEAR,if(OOOL.SEGMENT IN('E','A'),ifnull(RCCV.RCCV_GROSS_HOLD,0),0)) - (SPAN_MARGIN + NET_OPTION + EX.EXPO_MARGIN),2) AS SHORTFALL_VALUE,   ROUND(FN_TOT_BAL_MARGIN(OOOL.C_CASH_BALANCE,   0,   0,      (OOOL.NC_NSE_RECEIVABLES + OOOL.NC_BSE_RECEIVABLES),   OOOL.C_BANK_HOLD,   ifnull(RCCV.RCCV_COLLATERAL_VALUE,0),   (OOOL.NC_REALISED_PROFIT + OOOL.NC_REALISED_PROFIT_COMM),   ifnull(OOOL.OPT_BUY_PREM_CFS + OOOL.OPT_BUY_PREM_COMM_CFS,0),   ifnull(OOOL.OPT_SELL_PREMIUM + OOOL.OPT_SELL_PREM_COMM_DAY,0),   ifnull(OOOL.CF_OPT_SELL_PREMIUM + OOOL.CF_OPT_SELL_PREMIUM_COMM,0),   OOOL.REQUEST_PAYOUT_AMOUNT,  'L', 'L', 'L', 'L', 'L',   TOT_MARG_FLAG,OOOL.C_BANK_HOLD_UNCLEAR,if(OOOL.SEGMENT IN('E','A'),ifnull(RCCV.RCCV_GROSS_HOLD,0),0)),2) AS TOTAL_BALANCE,   IFNULL(ROUND((OOOL.TOTAL_CASH_UTILIZED+ OOOL.TOTAL_CASH_UTILIZED_COMM - SEGWISE_ADHOC_UTLZ),2),0) AS UTILIZED_CASH,   IFNULL(ROUND(OOOL.C_CASH_BALANCE,2),0) AS LIMIT_SOD,   ROUND(FN_TOT_BAL_MARGIN(OOOL.C_CASH_BALANCE,   OOOL.C_ADHOC_LIMIT,   ((OOOL.TOTAL_CASH_UTILIZED + OOOL.TOTAL_CASH_UTILIZED_COMM + IF(S.PARAM_VALUE='Y', ROUND(MTM_D,2),0))- SEGWISE_ADHOC_UTLZ),      (OOOL.NC_NSE_RECEIVABLES + OOOL.NC_BSE_RECEIVABLES),   OOOL.C_BANK_HOLD,   ifnull(RCCV.RCCV_COLLATERAL_VALUE,0),   (OOOL.NC_REALISED_PROFIT + OOOL.NC_REALISED_PROFIT_COMM),   ifnull(OOOL.OPT_BUY_PREM_CFS + OOOL.OPT_BUY_PREM_COMM_CFS,0),   ifnull(OOOL.OPT_SELL_PREMIUM + OOOL.OPT_SELL_PREM_COMM_DAY,0),   ifnull(OOOL.CF_OPT_SELL_PREMIUM + OOOL.CF_OPT_SELL_PREMIUM_COMM,0),   OOOL.REQUEST_PAYOUT_AMOUNT,  'L', 'L', 'L', 'L', 'L',   TOT_MARG_FLAG,OOOL.C_BANK_HOLD_UNCLEAR,if(OOOL.SEGMENT IN('E','A'),ifnull(RCCV.RCCV_GROSS_HOLD,0),0)),2) AS AVAILABLE_BAL,   ROUND(MTM_D) AS MTM,   ifnull(RCCV.RCCV_COLLATERAL_VALUE,0) AS COLLATERAL,   EXCH_SEGMENT    FROM  (SELECT  PPM.PPM_CLIENT_ID AS CLIENT_ID_A,   IFNULL(SUM(IFNULL(PPM.PPM_SPAN_MARGIN, 0)), 0) AS SPAN_MARGIN,     IFNULL(SUM(IFNULL(PPM.NET_OPTION_VALUE, 0)), 0) AS NET_OPTION,   EXCH AS EXCHANGE_ID,   SEGMENT AS EXCH_SEGMENT,   PRODUCT AS PRODUCT,   INSTRUMENT_NAME AS INSTRUMENT,   SUM(PPM_SELL_OPTION_PREMIUM) AS SHORT_OPTION_PREMIUM,   SUM(MTM_C) AS MTM_D,   PPM.MARG_FLAG AS TOT_MARG_FLAG   FROM(SELECT  P.PPRP_CLIENT_ID AS PPM_CLIENT_ID,   P.PPRP_UNDERLAYING AS PPM_UNDERLAYING,   P.PPRP_EXCHANGE AS EXCH,   P.PPRP_SEGMENT AS SEGMENT,   P.PPRP_PRODUCT AS PRODUCT,   P.PPRP_INSTRUMENT AS INSTRUMENT_NAME,   P.POS_COUNT AS POS_COUNT,   P.POS_OPT_BUY_COUNT AS POS_OPT_BUY_COUNT,   (CASE   WHEN (P.POS_COUNT = P.POS_OPT_BUY_COUNT) THEN 0   ELSE (GREATEST((GREATEST(SUM(P.PPRP_PARAM1),   SUM(P.PPRP_PARAM2),   SUM(P.PPRP_PARAM3),   SUM(P.PPRP_PARAM4),   SUM(P.PPRP_PARAM4),   SUM(P.PPRP_PARAM5),   SUM(P.PPRP_PARAM6),   SUM(P.PPRP_PARAM7),   SUM(P.PPRP_PARAM8),   SUM(P.PPRP_PARAM9),   SUM(P.PPRP_PARAM10),   SUM(P.PPRP_PARAM11),   SUM(P.PPRP_PARAM12),   SUM(P.PPRP_PARAM13),   SUM(P.PPRP_PARAM14),   SUM(P.PPRP_PARAM15),   SUM(P.PPRP_PARAM16)) + (CASE   WHEN (SUM(P.PPRP_POSITIVE_DELTA) > 0 AND SUM(P.PPRP_NEGATIVE_DELTA) < 0)  THEN  abs(LEAST(SUM(P.PPRP_NEGATIVE_DELTA),SUM(P.PPRP_POSITIVE_DELTA)))*PPRP_DELTA_SPREAD   ELSE 0   END)),  SUM((CASE   WHEN   ((P.PPRP_INSTRUMENT LIKE 'OPT%%')   AND (P.PPRP_NET_QTY < 0))   THEN   P.PPRP_RSM_SOM   ELSE 0   END))) - SUM(P.PPRP_OPTION_PREMIUM))   END) AS PPM_SPAN_MARGIN,   SUM((CASE   WHEN   ((P.PPRP_INSTRUMENT LIKE 'OPT%%')   AND (P.PPRP_NET_QTY > 0))   THEN   ABS(CAST(P.PPRP_NET_VALUE AS DECIMAL (10 , 0 )))   ELSE 0   END)) AS NET_OPTION_VALUE,   SUM(CASE  WHEN (P.PPRP_INSTRUMENT LIKE 'OPT%%') AND (P.PPRP_NET_QTY < 0) THEN (P.PPRP_OPTION_PREMIUM_SELL)   ELSE 0   END) AS PPM_SELL_OPTION_PREMIUM,   P.TOT_BAL_FLAG AS MARG_FLAG,   MTM_B AS MTM_C   FROM  ( SELECT  A.CLIENT_ID AS PPRP_CLIENT_ID,   A.SECURITY_ID AS PPRP_SECURITY_ID,   A.INSTRUMENT AS PPRP_INSTRUMENT,   A.SYMB_SECID AS PPRP_SECID,   A.UNDERLAYING AS PPRP_UNDERLAYING,   A.EXCH_ID AS PPRP_EXCHANGE,   A.SEGMNT AS PPRP_SEGMENT,   (CASE WHEN A.NET_QTY > 0 THEN 'B'   WHEN A.NET_QTY < 0 THEN 'S'   END) AS BUY_SELL,   A.NET_QTY AS PPRP_NET_QTY,   (CASE   WHEN (A.SEGMNT = 'C') THEN ((A.NET_QTY * A.BUY_AVG) * 1000 * SM_RBI_REFERENCE_RATE)   WHEN (A.SEGMNT = 'M') THEN ((A.NET_QTY * A.BUY_AVG) * MCX_MULTIPLIER )   ELSE (A.NET_QTY * A.BUY_AVG)   END) AS PPRP_NET_VALUE,   A.PROD_ID AS PPRP_PRODUCT,   A.SM_NSE_REGULAR_LOT AS PPRP_LOT_SIZE,   (A.NET_QTY * B.RSM_SPAN_1) AS PPRP_PARAM1,   (A.NET_QTY * B.RSM_SPAN_2) AS PPRP_PARAM2,   (A.NET_QTY * B.RSM_SPAN_3) AS PPRP_PARAM3,   (A.NET_QTY * B.RSM_SPAN_4) AS PPRP_PARAM4,   (A.NET_QTY * B.RSM_SPAN_5) AS PPRP_PARAM5,   (A.NET_QTY * B.RSM_SPAN_6) AS PPRP_PARAM6,   (A.NET_QTY * B.RSM_SPAN_7) AS PPRP_PARAM7,   (A.NET_QTY * B.RSM_SPAN_8) AS PPRP_PARAM8,   (A.NET_QTY * B.RSM_SPAN_9) AS PPRP_PARAM9,   (A.NET_QTY * B.RSM_SPAN_10) AS PPRP_PARAM10,   (A.NET_QTY * B.RSM_SPAN_11) AS PPRP_PARAM11,   (A.NET_QTY * B.RSM_SPAN_12) AS PPRP_PARAM12,   (A.NET_QTY * B.RSM_SPAN_13) AS PPRP_PARAM13,   (A.NET_QTY * B.RSM_SPAN_14) AS PPRP_PARAM14,   (A.NET_QTY * B.RSM_SPAN_15) AS PPRP_PARAM15,   (A.NET_QTY * B.RSM_SPAN_16) AS PPRP_PARAM16,   (CASE   WHEN ((A.NET_QTY * B.RSM_DELTA) < 0) THEN (A.NET_QTY * B.RSM_DELTA)   ELSE 0   END) AS PPRP_NEGATIVE_DELTA,   (CASE   WHEN ((A.NET_QTY * B.RSM_DELTA) > 0) THEN (A.NET_QTY * B.RSM_DELTA)   ELSE 0   END) AS PPRP_POSITIVE_DELTA,   CASE   WHEN (A.SEGMNT = 'C') THEN (A.NET_QTY * B.RSM_OPTION_PREMIUM * 1000 )   WHEN (A.SEGMNT = 'M') THEN (A.NET_QTY * B.RSM_OPTION_PREMIUM * MCX_MULTIPLIER )   ELSE (A.NET_QTY * B.RSM_OPTION_PREMIUM)   END AS PPRP_OPTION_PREMIUM,   (A.SELL_VAL_OPT) AS PPRP_OPTION_PREMIUM_SELL,   (ABS(A.NET_QTY) * B.RSM_SOM) AS PPRP_RSM_SOM,   IFNULL(b.POS_COUNT, 0) AS POS_COUNT,   IFNULL(POS_OPT_BUY_COUNT,0) AS POS_OPT_BUY_COUNT,   B.RSM_DELTA_SPREAD AS PPRP_DELTA_SPREAD,  A.V_TOT_BAL_MARG_FLAG AS TOT_BAL_FLAG,   MTM_A AS MTM_B  FROM    (((SELECT       NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   NPT_INSTRUMENT AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   NPT_UNDERLAYING_CODE AS UNDERLAYING,   NPT_RBI_REFERENCE_RATE AS SM_RBI_REFERENCE_RATE,   NPT_EXCH_ID AS EXCH_ID,   NPT_EXPIRY_DATE AS EXPIRY_DATE,   NPT_STRIKE_PRICE AS STRIKE_PRICE,   NPT_OPTION_TYPE AS OPTION_TYPE,   NPT_TOT_BUY_QTY AS TOT_BUY_QTY,   NPT_TOT_BUY_VAL AS TOT_BUY_VAL,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL  AS NET_VAL,   NPT_NET_AVG AS NET_AVG,   NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_SEGMENT AS SEGMNT,   NPT_PROD_ID AS PROD_ID,   NPT_LOT AS SM_NSE_REGULAR_LOT,   NPT_OPT_SELL_PREMIUM AS SELL_VAL_OPT,   NPT_RPM_CODE AS RISK_CODE,   NPT_MCX_MULTIPLIER AS MCX_MULTIPLIER,   RPM.TOT_BAL_MARG_FLAG AS V_TOT_BAL_MARG_FLAG,   (CASE WHEN NPT.NPT_SEGMENT = 'E'    THEN (CASE WHEN NPT.NPT_NET_QTY > 0      THEN    (CASE WHEN RPM.RPM_EXCLUDE_CNC_BUY='Y' AND  NPT.NPT_PROD_ID = 'C'   THEN 0   ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)     END)      ELSE     (CASE WHEN RPM.RPM_EXCLUDE_CNC_SELL='Y' AND  NPT.NPT_PROD_ID = 'C'   THEN 0   ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)      END)     END)   WHEN NPT.NPT_SEGMENT = 'D'  THEN (CASE WHEN NPT.NPT_NET_QTY > 0      THEN      (CASE  WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'   THEN   (CASE WHEN RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0    THEN(NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)     ELSE 0   END) +   (CASE WHEN RPM.RPM_EXCLUDE_OPT_CF_BUY='N'  AND NPT_TOT_BUY_QTY_CF >0    THEN (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)     ELSE 0   END)   ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)   END)           ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)   END)   WHEN NPT.NPT_SEGMENT = 'C'  THEN  (CASE   WHEN   NPT.NPT_NET_QTY > 0   THEN   (CASE  WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'   THEN      (CASE   WHEN    RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0  THEN   (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)   ELSE 0   END) +   (CASE   WHEN   RPM.RPM_EXCLUDE_OPT_CF_BUY='N'  AND NPT_TOT_BUY_QTY_CF >0  THEN   (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) *  (LWA.L1_LTP - NPT.NPT_BUY_AVG)   ELSE 0   END)   ELSE   NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)   END)   ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)   END) * 1000   WHEN NPT.NPT_SEGMENT = 'M'  THEN (CASE   WHEN   NPT.NPT_NET_QTY > 0   THEN  (CASE  WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'   THEN      (CASE   WHEN    RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0  THEN   (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG)   ELSE 0   END) +   (CASE   WHEN   RPM.RPM_EXCLUDE_OPT_CF_BUY='N'  AND NPT_TOT_BUY_QTY_CF >0  THEN   (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) *  (LWA.L1_LTP - NPT.NPT_BUY_AVG)   ELSE 0   END)   ELSE   NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)   END)   ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)   END) * NPT.NPT_MCX_MULTIPLIER   ELSE 0   END) AS MTM_A   FROM NET_POSITION_TABLE NPT  LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE   AND  NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE    AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT)   LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON ( NPT.NPT_RPM_CODE = RPM.RPM_CODE)   WHERE (NPT_SEGMENT NOT LIKE(CASE \'%c\' WHEN 'P' THEN 'M'when 'A' then 'aaaaa' ELSE '%%' END)   or NPT_SEGMENT LIKE (CASE WHEN \'%c\' NOT IN('P','A') THEN \'%c\' ELSE 'AAAAA' END))      ) AS A   JOIN (SELECT  COUNT(1) AS POS_COUNT,   a.CLIENT_ID AS CLIENT_ID,   a.UNDERLAYING AS UNDERLAYING,   SUM(IFNULL((CASE   WHEN   ((a.INSTRUMENT LIKE 'OPT%%')   AND (a.NET_QTY > 0))   THEN   1   END),   0)) AS POS_OPT_BUY_COUNT   FROM   (SELECT  NPT.NPT_CLIENT_ID AS CLIENT_ID,   NPT.NPT_INSTRUMENT AS INSTRUMENT,   NPT.NPT_UNDERLAYING_CODE AS UNDERLAYING,   NPT.NPT_NET_QTY AS NET_QTY   FROM NET_POSITION_TABLE NPT   WHERE (NPT.NPT_SEGMENT NOT LIKE(CASE \'%c\' WHEN 'P' THEN 'M' WHEN 'A' THEN 'aaaaa' ELSE '%%' END)   OR NPT.NPT_SEGMENT LIKE (CASE WHEN \'%c\' NOT IN('P','A') THEN \'%c\' ELSE 'AAAAA' END))     ) a GROUP BY a.CLIENT_ID) AS b  ON (A.CLIENT_ID = b.CLIENT_ID))   JOIN RMS_FNO_SPAN_MARGIN B)   WHERE   A.NET_QTY <> 0   AND A.SECURITY_ID = B.RSM_SECURITY_ID   AND A.EXCH_ID = B.RSM_EXCHANGE   AND A.SEGMNT = B.RSM_SEGMENT   ) P  WHERE   (P.PPRP_INSTRUMENT <> 'EQUITY')   AND (P.PPRP_INSTRUMENT LIKE (CASE WHEN %d = 2 THEN 'OPT%%' ELSE '%%' END) AND P.BUY_SELL LIKE (CASE WHEN %d = 2 THEN 'S' ELSE '%%' END))   AND (P.PPRP_INSTRUMENT LIKE (CASE WHEN %d = 3 THEN 'FUT%%' ELSE '%%' END))   GROUP BY P.PPRP_CLIENT_ID, P.PPRP_UNDERLAYING, P.PPRP_PRODUCT, P.POS_COUNT, P.POS_OPT_BUY_COUNT, P.PPRP_EXCHANGE, P.PPRP_SEGMENT)PPM   GROUP BY PPM.PPM_CLIENT_ID) AS SPAN   JOIN  ( SELECT   SUM(EXPO_MARGIN) AS EXPO_MARGIN,EX_CLIENT_ID FROM(select IFNULL(SUM(      CASE   WHEN pbc.instrument = 'FUTIDX'  THEN   case    when pbc.prod_id = 'M'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 4.25 / 100) * 0.34) + (pbc.SPD_NET_VAL * 4.25/100))    when  pbc.prod_id = 'I'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 4.25 / 100) * 0.34) + (pbc.SPD_NET_VAL * 4.25/100))    when pbc.prod_id = 'H'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 4.25 / 100) * 0.34) + (pbc.SPD_NET_VAL * 4.25/100))    end   WHEN pbc.instrument = 'FUTSTK'  THEN   case  when pbc.prod_id = 'M'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * RFEM.RFEM_EFF_EXP_LIMIT / 100) * 0.34) + (pbc.SPD_NET_VAL * RFEM.RFEM_EFF_EXP_LIMIT/100))    when  pbc.prod_id = 'I'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * RFEM.RFEM_EFF_EXP_LIMIT / 100) * 0.34) + (pbc.SPD_NET_VAL * RFEM.RFEM_EFF_EXP_LIMIT/100))    when pbc.prod_id = 'H'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * RFEM.RFEM_EFF_EXP_LIMIT / 100) * 0.34) + (pbc.SPD_NET_VAL * RFEM.RFEM_EFF_EXP_LIMIT/100))    END   WHEN pbc.instrument = 'OPTSTK'  THEN     case when pbc.prod_id = 'M'  THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *RFEM.RFEM_EFF_EXP_LIMIT / 100)   when  pbc.prod_id = 'I'  THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *RFEM.RFEM_EFF_EXP_LIMIT / 100)   when pbc.prod_id = 'H'  THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *RFEM.RFEM_EFF_EXP_LIMIT / 100)    END     WHEN pbc.instrument = 'OPTIDX'  THEN      case when pbc.prod_id = 'M'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) * 4.25 / 100 )      when  pbc.prod_id = 'I'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) * 4.25 / 100 )      when pbc.prod_id = 'H'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) * 4.25 / 100 )    END   WHEN pbc.instrument = 'FUTCUR'  THEN    CASE when pbc.CROSS_CUR_FLAG='Y'     THEN   case  when pbc.prod_id = 'M'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 1/100) * 0.34) + (pbc.SPD_NET_VAL * 1/100))    when  pbc.prod_id = 'I'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 1 /100) * 0.34) + (pbc.SPD_NET_VAL  * 1/100))    end     ELSE    case  when pbc.prod_id = 'M'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 1/100) * 0.34) + (pbc.SPD_NET_VAL * 1/100))    when  pbc.prod_id = 'I'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 1/100) * 0.34) + (pbc.SPD_NET_VAL * 1/100))    when pbc.prod_id = 'H'   THEN (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * 1/100) * 0.34) + (pbc.SPD_NET_VAL * 1/100))    end     END  WHEN pbc.instrument = 'OPTCUR'  THEN    CASE  when pbc.CROSS_CUR_FLAG='Y'   THEN  case  when pbc.prod_id = 'M'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *1.5 / 100 )      when  pbc.prod_id = 'I'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price))  * 1.5 / 100 )   END   ELSE   case  when pbc.prod_id = 'M'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price))  * 1.5 / 100 )      when  pbc.prod_id = 'I'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price))  * 1.5 / 100 )      when pbc.prod_id = 'H'     THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price))  * 1.5 / 100 )    END     END   WHEN pbc.instrument = 'FUTCOM' THEN   case   when pbc.PROD_ID = 'M' THEN          (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2)* (RMEM.RMEM_ELM_Long / 100)) * 0.34) + (pbc.SPD_NET_VAL * RMEM.RMEM_ELM_Long/100))   when pbc.PROD_ID = 'H' THEN           (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * (RMEM.RMEM_ELM_Long / 100)) * 0.34) + (pbc.SPD_NET_VAL * RMEM.RMEM_ELM_Long/100))   when pbc.PROD_ID = 'I' THEN          (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * (RMEM.RMEM_ELM_Long / 100)) * 0.34) + (pbc.SPD_NET_VAL * RMEM.RMEM_ELM_Long/100))   END   WHEN pbc.instrument LIKE 'OPTFUT' THEN   case   when pbc.PROD_ID = 'M' THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) * RMEM.RMEM_ELM_Long / 100)  when pbc.PROD_ID = 'H' THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) * RMEM.RMEM_ELM_Long / 100)  when pbc.PROD_ID = 'I' THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) * RMEM.RMEM_ELM_Long / 100)  END    END  ),0) AS EXPO_MARGIN,   pbc.client_id AS EX_CLIENT_ID   FROM (SELECT PBC1.*,     AVG(ABS(PBC1.NET_VAL)) AS SPD_AVG_VAL,    ABS(SUM(PBC1.NET_VAL)) AS SPD_NET_VAL,    SUM(ABS(PBC1.NET_VAL)) AS SPD_GROSS_VAL   FROM (SELECT  NPT_CLIENT_ID AS CLIENT_ID,   NPT_SECURITY_ID AS SECURITY_ID,   NPT_INSTRUMENT AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   NPT_UNDERLAYING_CODE AS UNDERLAYING,   NPT_EXCH_ID AS EXCH_ID,   NPT_EXPIRY_DATE AS EXPIRY_DATE,   NPT_STRIKE_PRICE AS STRIKE_PRICE,   NPT_OPTION_TYPE AS OPTION_TYPE,   NPT_TOT_BUY_QTY AS BUY_QTY,   NPT_TOT_BUY_VAL AS BUY_VAL,   NPT_BUY_AVG AS BUY_AVG,   NPT_TOT_SELL_QTY AS SELL_QTY,   NPT_TOT_SELL_VAL AS SELL_VAL,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY,   NPT_NET_VAL AS NET_VAL,   NPT_NET_AVG AS NET_AVG,     NPT_GROSS_QTY AS GROSS_QTY,   NPT_GROSS_VAL AS GROSS_VAL,   NPT_SEGMENT AS SEGMNT,   NPT_PROD_ID AS PROD_ID,   NPT_LOT AS SM_NSE_REGULAR_LOT,   NPT_RPM_CODE AS RISK_CODE,   NPT_RBI_REFERENCE_RATE AS RBI_REFERENCE_RATE,   NPT_CROSS_CUR_FLAG AS CROSS_CUR_FLAG,   NPT_MCX_MULTIPLIER AS MCX_MULTIPLIER   FROM NET_POSITION_TABLE  WHERE (NPT_SEGMENT NOT LIKE(CASE \'%c\' WHEN 'P' THEN 'M'when 'A' then 'aaaaa' ELSE '%%' END)    or NPT_SEGMENT LIKE (CASE WHEN \'%c\' NOT IN('P','A') THEN \'%c\' ELSE 'AAAAA' END))  GROUP BY NPT_CLIENT_ID,NPT_SEGMENT) PBC1    WHERE NOT (PBC1.INSTRUMENT LIKE 'OPT%%' AND PBC1.NET_QTY > 0)    AND PBC1.NET_QTY <> 0    AND PBC1.INSTRUMENT LIKE (CASE WHEN %d = 2 THEN 'OPT%%' ELSE '%%' END)    AND PBC1.INSTRUMENT  LIKE (CASE WHEN %d = 3 THEN 'FUT%%' ELSE '%%' END)    GROUP BY PBC1.UNDERLAYING, PBC1.INSTRUMENT, PBC1.STRIKE_PRICE, PBC1.PROD_ID, PBC1.CLIENT_ID)pbc    LEFT OUTER JOIN RMS_FNO_EXP_MARGIN RFEM    ON (RFEM.RFEM_SECURITY_ID = pbc.underlaying AND RFEM.RFEM_SEGMENT = pbc.segmnt)    LEFT OUTER JOIN  RMS_MCX_EXP_MARGIN RMEM    ON (RMEM.RMEM_SECURITY_ID = (CASE pbc.INSTRUMENT WHEN 'FUTCOM' THEN pbc.SECURITY_ID ELSE pbc.UNDERLAYING END)    AND RMEM.RMEM_SEGMENT = pbc.segmnt)    WHERE pbc.INSTRUMENT <> 'EQUITY'    AND pbc.net_qty <> 0    GROUP BY pbc.CLIENT_ID, pbc.UNDERLAYING, pbc.INSTRUMENT, pbc.STRIKE_PRICE, pbc.PROD_ID) AS PRE_EXP    GROUP BY EX_CLIENT_ID) EX ON (EX_CLIENT_ID = SPAN.CLIENT_ID_A) LEFT OUTER JOIN RMS_CLIENT_COLLATERAL_VALUE RCCV ON( SPAN.CLIENT_ID_A = RCCV.RCCV_CLIENT_ID)   LEFT OUTER JOIN RMS_FUND_LIMIT OOOL    ON(SPAN.CLIENT_ID_A = OOOL.CLIENT_ID AND OOOL.SEGMENT = IF(\'%c\' IN('P','A'),'A',SPAN.EXCH_SEGMENT)) LEFT OUTER JOIN SYS_PARAMETERS S ON(S.PARAM_NAME = 'SYS_MTM_LOSS_FLAG')  WHERE  SPAN.SPAN_MARGIN + SPAN.NET_OPTION > 0 %s;",pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->ReqHeader.cSegment,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->ReqHeader.cSegment,sBrchClaus);
        }
	 else
        {
                sprintf(sMarginQry,"SELECT  CLIENT_ID_A,   ROUND(SPAN_MARGIN,2) AS SPAN_MARGIN, ROUND(EX.EXPO_MARGIN,2) AS EXPOSURE_MARGIN,  ROUND((SPAN_MARGIN + EX.EXPO_MARGIN),2) AS TOTAL_MARGIN, NET_OPTION,  ROUND(SHORT_OPTION_PREMIUM,2) AS SELL_OPTION_PREMIUM,  ROUND(FN_TOT_BAL_MARGIN(OOOLM.RMLC_C_CASH_BALANCE,   0,   0, (0),   OOOLM.RMLC_C_BANK_HOLD,   0,   (OOOLM.RMLC_NC_REALISED_PROFIT ),   ifnull(OOOLM.RMLC_OPT_BUY_PREM_CFS ,0),   ifnull(OOOLM.OPT_SELL_PREMIUM ,0),   ifnull(OOOLM.RMLC_CF_OPT_SELL_PREMIUM ,0),   OOOLM.RMLC_REQUEST_PAYOUT_AMOUNT,   'L', 'L', 'L', 'L', 'L',   TOT_MARG_FLAG,OOOLM.C_BANK_HOLD_UNCLEAR,0) - (SPAN_MARGIN + NET_OPTION + EX.EXPO_MARGIN),2) AS SHORTFALL_VALUE, ROUND(FN_TOT_BAL_MARGIN(OOOLM.RMLC_C_CASH_BALANCE,   0,   0,    (0),   OOOLM.RMLC_C_BANK_HOLD,   0,   (OOOLM.RMLC_NC_REALISED_PROFIT ),   ifnull(OOOLM.RMLC_OPT_BUY_PREM_CFS ,0),   ifnull(OOOLM.OPT_SELL_PREMIUM ,0),   ifnull(OOOLM.RMLC_CF_OPT_SELL_PREMIUM ,0),   OOOLM.RMLC_REQUEST_PAYOUT_AMOUNT,   'L', 'L', 'L', 'L', 'L',   TOT_MARG_FLAG,OOOLM.C_BANK_HOLD_UNCLEAR,0),2)  AS TOTAL_BALANCE,  IFNULL(ROUND(OOOLM.RMLC_TOTAL_CASH_UTILIZED- OOOLM.RMLC_SEGWISE_ADHOC_UTLZ, 2),0) AS UTILIZED_CASH,    IFNULL(ROUND(OOOLM.RMLC_C_CASH_BALANCE,2),0)  AS LIMIT_SOD,  ROUND(FN_TOT_BAL_MARGIN(OOOLM.RMLC_C_CASH_BALANCE,   OOOLM.RMLC_C_ADHOC_LIMIT,   ((OOOLM.RMLC_TOTAL_CASH_UTILIZED + IF(S.PARAM_VALUE='Y', ROUND(MTM_D,2),0))- OOOLM.RMLC_SEGWISE_ADHOC_UTLZ),    (0),   OOOLM.RMLC_C_BANK_HOLD,   0,   (OOOLM.RMLC_NC_REALISED_PROFIT ),   ifnull(OOOLM.RMLC_OPT_BUY_PREM_CFS ,0),   ifnull(OOOLM.OPT_SELL_PREMIUM ,0),   ifnull(OOOLM.RMLC_CF_OPT_SELL_PREMIUM ,0),   OOOLM.RMLC_REQUEST_PAYOUT_AMOUNT,   'L', 'L', 'L', 'L', 'L',   TOT_MARG_FLAG,OOOLM.C_BANK_HOLD_UNCLEAR,0),2)  AS AVAILABLE_BAL,  ROUND(MTM_D) AS MTM, 0 AS COLLATERAL   FROM    (SELECT  PPM.PPM_CLIENT_ID AS CLIENT_ID_A, IFNULL(SUM(IFNULL(PPM.PPM_SPAN_MARGIN, 0)), 0) AS SPAN_MARGIN,   IFNULL(SUM(IFNULL(PPM.NET_OPTION_VALUE, 0)), 0) AS NET_OPTION, EXCH AS EXCHANGE_ID, SEGMENT AS EXCH_SEGMENT, PRODUCT AS PRODUCT, INSTRUMENT_NAME AS INSTRUMENT, SUM(PPM_SELL_OPTION_PREMIUM) AS SHORT_OPTION_PREMIUM, SUM(MTM_C) AS MTM_D, PPM.MARG_FLAG AS TOT_MARG_FLAG   FROM(SELECT `P`.`PPRP_CLIENT_ID` AS `PPM_CLIENT_ID`, `P`.`PPRP_UNDERLAYING` AS `PPM_UNDERLAYING`, `P`.`PPRP_EXCHANGE` AS `EXCH`, `P`.`PPRP_SEGMENT` AS `SEGMENT`, `P`.`PPRP_PRODUCT` AS `PRODUCT`,  P.PPRP_INSTRUMENT AS INSTRUMENT_NAME, `P`.`POS_COUNT` AS `POS_COUNT`, `P`.`POS_OPT_BUY_COUNT` AS `POS_OPT_BUY_COUNT`, (CASE  WHEN (`P`.`POS_COUNT` = `P`.`POS_OPT_BUY_COUNT`) THEN 0  ELSE (GREATEST((GREATEST(SUM(`P`.`PPRP_PARAM1`), SUM(`P`.`PPRP_PARAM2`), SUM(`P`.`PPRP_PARAM3`), SUM(`P`.`PPRP_PARAM4`), SUM(`P`.`PPRP_PARAM4`), SUM(`P`.`PPRP_PARAM5`), SUM(`P`.`PPRP_PARAM6`), SUM(`P`.`PPRP_PARAM7`), SUM(`P`.`PPRP_PARAM8`), SUM(`P`.`PPRP_PARAM9`), SUM(`P`.`PPRP_PARAM10`), SUM(`P`.`PPRP_PARAM11`), SUM(`P`.`PPRP_PARAM12`), SUM(`P`.`PPRP_PARAM13`), SUM(`P`.`PPRP_PARAM14`), SUM(`P`.`PPRP_PARAM15`), SUM(`P`.`PPRP_PARAM16`)) + (CASE WHEN (SUM(`P`.`PPRP_POSITIVE_DELTA`) > 0 AND SUM(`P`.`PPRP_NEGATIVE_DELTA`) < 0) THEN abs(LEAST(SUM(`P`.`PPRP_NEGATIVE_DELTA`),SUM(`P`.`PPRP_POSITIVE_DELTA`))) * PPRP_DELTA_SPREAD ELSE 0  END)),  SUM((CASE WHEN ((`P`.`PPRP_INSTRUMENT` LIKE 'OPT%%') AND (`P`.`PPRP_NET_QTY` < 0)) THEN `P`.`PPRP_RSM_SOM` ELSE 0  END))) - SUM(`P`.`PPRP_OPTION_PREMIUM`)) END) AS `PPM_SPAN_MARGIN`, SUM((CASE  WHEN  ((`P`.`PPRP_INSTRUMENT` LIKE 'OPT%%')  AND (`P`.`PPRP_NET_QTY` > 0))  THEN  ABS(CAST(`P`.`PPRP_NET_VALUE` AS DECIMAL (10 , 0 )))  ELSE 0 END)) AS `NET_OPTION_VALUE`, SUM(CASE    WHEN (P.PPRP_INSTRUMENT LIKE 'OPT%%') AND (P.PPRP_NET_QTY < 0) THEN (`P`.`PPRP_OPTION_PREMIUM_SELL`)    ELSE 0  END) AS PPM_SELL_OPTION_PREMIUM,    P.RISK_PROF AS CLIENT_RISK, P.TOT_BAL_FLAG AS MARG_FLAG,    MTM_B AS MTM_C FROM  ( SELECT   `A`.`CLIENT_ID` AS `PPRP_CLIENT_ID`, `A`.`SECURITY_ID` AS `PPRP_SECURITY_ID`, `A`.`INSTRUMENT` AS `PPRP_INSTRUMENT`, `A`.`SYMB_SECID` AS `PPRP_SECID`, `A`.`UNDERLAYING` AS `PPRP_UNDERLAYING`, `A`.`EXCH_ID` AS `PPRP_EXCHANGE`, `A`.`SEGMNT` AS `PPRP_SEGMENT`, (CASE WHEN A.NET_QTY > 0 THEN 'B' WHEN A.NET_QTY < 0 THEN 'S' END) AS BUY_SELL, `A`.`NET_QTY` AS `PPRP_NET_QTY`, ((`A`.`NET_QTY` * `A`.`BUY_AVG`) * `A`.`MCX_MULTIPLIER`) AS `PPRP_NET_VALUE`, `A`.`PROD_ID` AS `PPRP_PRODUCT`, `A`.`SM_NSE_REGULAR_LOT` AS `PPRP_LOT_SIZE`,  (`A`.`NET_QTY` * `B`.`RSM_SPAN_1`) AS `PPRP_PARAM1`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_2`) AS `PPRP_PARAM2`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_3`) AS `PPRP_PARAM3`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_4`) AS `PPRP_PARAM4`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_5`) AS `PPRP_PARAM5`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_6`) AS `PPRP_PARAM6`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_7`) AS `PPRP_PARAM7`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_8`) AS `PPRP_PARAM8`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_9`) AS `PPRP_PARAM9`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_10`) AS `PPRP_PARAM10`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_11`) AS `PPRP_PARAM11`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_12`) AS `PPRP_PARAM12`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_13`) AS `PPRP_PARAM13`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_14`) AS `PPRP_PARAM14`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_15`) AS `PPRP_PARAM15`, (`A`.`NET_QTY` * `B`.`RSM_SPAN_16`) AS `PPRP_PARAM16`, (CASE  WHEN ((`A`.`NET_QTY` * `B`.`RSM_DELTA`) < 0) THEN(`A`.`NET_QTY` * `B`.`RSM_DELTA`) ELSE 0 END) AS `PPRP_NEGATIVE_DELTA`, (CASE  WHEN ((`A`.`NET_QTY` * `B`.`RSM_DELTA`) > 0) THEN(`A`.`NET_QTY` * `B`.`RSM_DELTA`)  ELSE 0 END) AS `PPRP_POSITIVE_DELTA`,  (A.SELL_VAL_OPT) AS PPRP_OPTION_PREMIUM_SELL, ((`A`.`NET_QTY` * `B`.`RSM_OPTION_PREMIUM`) * `A`.`MCX_MULTIPLIER`) AS `PPRP_OPTION_PREMIUM`, ((ABS(`A`.`NET_QTY`) * `B`.`RSM_SOM`)) AS `PPRP_RSM_SOM`, IFNULL(`b`.`POS_COUNT`, 0) AS `POS_COUNT`,  IFNULL(POS_OPT_BUY_COUNT,0) AS POS_OPT_BUY_COUNT, B.RSM_DELTA_SPREAD AS PPRP_DELTA_SPREAD , A.RISK_CODE AS RISK_PROF, A.V_TOT_BAL_MARG_FLAG AS TOT_BAL_FLAG,  MTM_A AS MTM_B  FROM ((( SELECT NPT_CLIENT_ID AS CLIENT_ID, NPT_SECURITY_ID AS SECURITY_ID, NPT_INSTRUMENT AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   NPT_UNDERLAYING_CODE AS UNDERLAYING, NPT_RBI_REFERENCE_RATE AS SM_RBI_REFERENCE_RATE,   NPT_EXCH_ID AS EXCH_ID, NPT_EXPIRY_DATE AS EXPIRY_DATE, NPT_STRIKE_PRICE AS STRIKE_PRICE,   NPT_OPTION_TYPE AS OPTION_TYPE, NPT_TOT_BUY_QTY AS TOT_BUY_QTY, NPT_TOT_BUY_VAL AS TOT_BUY_VAL, NPT_BUY_AVG AS BUY_AVG, NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY, NPT_NET_VAL  AS NET_VAL,    NPT_NET_AVG AS NET_AVG, NPT_GROSS_QTY AS GROSS_QTY, NPT_GROSS_VAL AS GROSS_VAL, NPT_SEGMENT AS SEGMNT,  NPT_PROD_ID AS PROD_ID, NPT_LOT AS SM_NSE_REGULAR_LOT, NPT_OPT_SELL_PREMIUM AS SELL_VAL_OPT, NPT_MCX_MULTIPLIER AS MCX_MULTIPLIER, NPT_RPM_CODE AS RISK_CODE,   RPM.TOT_BAL_MARG_FLAG AS V_TOT_BAL_MARG_FLAG,   (CASE WHEN NPT.NPT_NET_QTY > 0 THEN  (CASE  WHEN NPT.NPT_PROD_ID not in( 'I','V','B') AND NPT.NPT_INSTRUMENT LIKE 'OPT%%'   THEN   (CASE    WHEN RPM.RPM_EXCLUDE_OPT_BUY='N' AND (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) > 0 THEN    (NPT.NPT_TOT_BUY_QTY_DAY-NPT.NPT_TOT_SELL_QTY) * (LWA.L1_LTP - NPT.NPT_BUY_AVG) ELSE 0   END) +   (CASE WHEN    RPM.RPM_EXCLUDE_OPT_CF_BUY='N'  AND NPT_TOT_BUY_QTY_CF >0   THEN    (NPT_TOT_BUY_QTY_CF - IF((NPT.NPT_TOT_BUY_QTY_DAY - NPT.NPT_TOT_SELL_QTY_DAY) <0,NPT.NPT_TOT_SELL_QTY_DAY - NPT.NPT_TOT_BUY_QTY_DAY,0)) *   (LWA.L1_LTP - NPT.NPT_BUY_AVG)  ELSE 0   END)   ELSE    NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_BUY_AVG)    END) ELSE NPT.NPT_NET_QTY * (LWA.L1_LTP - NPT.NPT_SELL_AVG)  END) * NPT.NPT_MCX_MULTIPLIER AS MTM_A FROM NET_POSITION_TABLE NPT LEFT JOIN L1_WATCH_ACTIVE LWA ON (NPT.NPT_SECURITY_ID = LWA.L1_SCRIP_CODE    AND  NPT.NPT_EXCH_ID = LWA.L1_EXCHANGE  AND NPT.NPT_SEGMENT = LWA.L1_SEGMENT)  LEFT JOIN RMS_RISK_PROFILE_MAST RPM ON ( NPT.NPT_RPM_CODE = RPM.RPM_CODE) WHERE NPT.NPT_SEGMENT='M') AS A JOIN (SELECT  COUNT(1) AS POS_COUNT, a.CLIENT_ID AS CLIENT_ID, a.UNDERLAYING AS UNDERLAYING, SUM(IFNULL((CASE  WHEN ((a.INSTRUMENT LIKE 'OPT%%') AND (a.NET_QTY > 0))  THEN 1  END),  0)) AS POS_OPT_BUY_COUNT FROM (SELECT  NPT.NPT_CLIENT_ID AS CLIENT_ID, NPT.NPT_INSTRUMENT AS INSTRUMENT, NPT.NPT_UNDERLAYING_CODE AS UNDERLAYING,   NPT.NPT_NET_QTY AS NET_QTY FROM NET_POSITION_TABLE NPT WHERE NPT.NPT_SEGMENT='M')a GROUP BY a.CLIENT_ID )AS b  ON ((`A`.`CLIENT_ID` = `b`.`CLIENT_ID`))) JOIN `RMS_FNO_SPAN_MARGIN` `B`) WHERE ((`A`.`NET_QTY` <> 0)  AND (`A`.`SECURITY_ID` = `B`.`RSM_SECURITY_ID`)  AND (`A`.`EXCH_ID` = `B`.`RSM_EXCHANGE`)  AND (`A`.`SEGMNT` = `B`.`RSM_SEGMENT`)  AND (`A`.`UNDERLAYING` = `b`.`UNDERLAYING`))) `P`  WHERE (P.PPRP_INSTRUMENT <> 'EQUITY') AND (P.PPRP_INSTRUMENT LIKE (CASE WHEN %d = 2 THEN 'OPT%%' ELSE '%%' END) AND P.BUY_SELL LIKE (CASE WHEN %d = 2 THEN 'S' ELSE '%%' END)) AND (P.PPRP_INSTRUMENT LIKE (CASE WHEN %d = 3 THEN 'FUT%%' ELSE '%%' END)) GROUP BY P.PPRP_CLIENT_ID, P.PPRP_UNDERLAYING, P.PPRP_PRODUCT, P.POS_COUNT, P.POS_OPT_BUY_COUNT, P.PPRP_EXCHANGE, P.PPRP_SEGMENT ) PPM    GROUP BY PPM.PPM_CLIENT_ID) AS SPAN  JOIN (SELECT SUM(EXPO_MARGIN) AS EXPO_MARGIN,EX_CLIENT_ID FROM(select IFNULL(sum(  CASE WHEN pbc.INSTRUMENT = 'FUTCOM' THEN    case   when pbc.PROD_ID = 'M' THEN    (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * (RFEM.RMEM_ELM_Long / 100)) * 0.34) + (pbc.SPD_NET_VAL* RFEM.RMEM_ELM_Long/100))   when pbc.PROD_ID = 'H' THEN   (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2)* (RFEM.RMEM_ELM_Long / 100)) * 0.34) + (pbc.SPD_NET_VAL* RFEM.RMEM_ELM_Long/100))   when pbc.PROD_ID = 'I' THEN    (((((pbc.SPD_GROSS_VAL - pbc.SPD_NET_VAL)/2) * (RFEM.RMEM_ELM_Long / 100)) * 0.34) + (pbc.SPD_NET_VAL* RFEM.RMEM_ELM_Long/100))   END WHEN pbc.INSTRUMENT LIKE 'OPT%%' THEN   case   when pbc.PROD_ID = 'M' THEN  ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *   RFEM.RMEM_ELM_Long / 100)   when pbc.PROD_ID = 'H' THEN ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *   RFEM.RMEM_ELM_Long / 100)  when pbc.PROD_ID = 'I' THEN  ((ABS(pbc.net_qty) * (pbc.sell_avg + pbc.strike_price)) *   RFEM.RMEM_ELM_Long / 100)  END    END),0) AS EXPO_MARGIN,  pbc.client_id AS EX_CLIENT_ID  FROM (SELECT PBC1.*,    AVG(ABS(PBC1.NET_VAL)) AS SPD_AVG_VAL,  ABS(SUM(PBC1.NET_VAL)) AS SPD_NET_VAL,  SUM(ABS(PBC1.NET_VAL)) AS SPD_GROSS_VAL from( SELECT   NPT_CLIENT_ID AS CLIENT_ID,    NPT_SECURITY_ID AS SECURITY_ID, NPT_INSTRUMENT AS INSTRUMENT,   NPT_SYMBOL AS SYMB_SECID,   NPT_UNDERLAYING_CODE AS UNDERLAYING, NPT_RBI_REFERENCE_RATE AS SM_RBI_REFERENCE_RATE,   NPT_EXCH_ID AS EXCH_ID, NPT_EXPIRY_DATE AS EXPIRY_DATE, NPT_STRIKE_PRICE AS STRIKE_PRICE,   NPT_OPTION_TYPE AS OPTION_TYPE, NPT_TOT_BUY_QTY AS TOT_BUY_QTY, NPT_TOT_BUY_VAL AS TOT_BUY_VAL, NPT_BUY_AVG AS BUY_AVG, NPT_TOT_SELL_QTY AS TOT_SELL_QTY,   NPT_TOT_SELL_VAL AS TOT_SELL_VAL,   NPT_SELL_AVG AS SELL_AVG,   NPT_NET_QTY AS NET_QTY, NPT_NET_VAL  AS NET_VAL,    NPT_NET_AVG AS NET_AVG, NPT_GROSS_QTY AS GROSS_QTY, NPT_GROSS_VAL AS GROSS_VAL, NPT_SEGMENT AS SEGMENT, NPT_PROD_ID AS PROD_ID, NPT_LOT AS SM_NSE_REGULAR_LOT, NPT_OPT_SELL_PREMIUM AS SELL_VAL_OPT, NPT_MCX_MULTIPLIER AS MCX_MULTIPLIER,  NPT_MTM AS MTM_A FROM NET_POSITION_TABLE NPT WHERE NPT.NPT_SEGMENT='M') AS PBC1 WHERE NOT (PBC1.INSTRUMENT LIKE 'OPT%%' AND PBC1.NET_QTY>0) AND PBC1.NET_QTY <> 0   AND (PBC1.INSTRUMENT LIKE (CASE WHEN %d = 2 THEN 'OPT%%' ELSE '%%' END))  AND (PBC1.INSTRUMENT LIKE (CASE WHEN %d = 3 THEN 'FUT%%' ELSE '%%' END))  GROUP BY PBC1.UNDERLAYING, PBC1.INSTRUMENT, PBC1.STRIKE_PRICE, PBC1.PROD_ID, PBC1.CLIENT_ID)pbc left outer join RMS_MCX_EXP_MARGIN RFEM on (RFEM.RMEM_SECURITY_ID = (CASE pbc.INSTRUMENT WHEN 'FUTCOM' THEN pbc.SECURITY_ID ELSE pbc.UNDERLAYING END)   and RFEM.RMEM_SEGMENT = pbc.SEGMENT)    WHERE  pbc.INSTRUMENT <> 'EQUITY'    GROUP BY pbc.CLIENT_ID, pbc.UNDERLAYING,pbc.INSTRUMENT, pbc.STRIKE_PRICE, pbc.PROD_ID) AS PRE_EXP  GROUP BY EX_CLIENT_ID) EX ON (EX_CLIENT_ID = SPAN.CLIENT_ID_A),  RMS_FUND_LIMIT_COM OOOLM ,SYS_PARAMETERS S WHERE SPAN.CLIENT_ID_A = OOOLM.RMLC_CLIENT_ID AND S.PARAM_NAME = 'SYS_MTM_LOSS_FLAG'  and  SPAN.SPAN_MARGIN + SPAN.NET_OPTION >0 %s;",pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,pViewMarginShrtfallReq->iMode,sBrchClaus);

        }
        printf("sMarginQry = %s",sMarginQry);
	
	if(mysql_query(DBQury,sMarginQry ) != SUCCESS)
        {
                logSqlFatal("ERROR in sMarginQry.");
                sql_Error(DBQury);
		return FALSE;
        }

        Res = mysql_store_result(DBQury);

        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);	
	iTempNoOfRec = iNoOfPkt;
	pMarShrtfallHdrResp.IntRespHeader.iSeqNo = 0;
        pMarShrtfallHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pMarShrtfallHdrResp.IntRespHeader.iErrorId = 0;
        pMarShrtfallHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_MARGIN_SHORTFALL_HEADER_RESP;
        pMarShrtfallHdrResp.IntRespHeader.iUserId = pViewMarginShrtfallReq->ReqHeader.iUserId;
        pMarShrtfallHdrResp.IntRespHeader.cSource = pViewMarginShrtfallReq->ReqHeader.cSource ;
        pMarShrtfallHdrResp.IntRespHeader.cSegment = pViewMarginShrtfallReq->ReqHeader.cSegment ;
        pMarShrtfallHdrResp.cMsgType = 'H';
        pMarShrtfallHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pMarShrtfallHdrResp.IntRespHeader.iMsgLength = %d",pMarShrtfallHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pMarShrtfallHdrResp.IntRespHeader.iMsgCode = %d",pMarShrtfallHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pMarShrtfallHdrResp.IntRespHeader.iUserId = %d",pMarShrtfallHdrResp.IntRespHeader.iUserId);
        logDebug2("pMarShrtfallHdrResp.IntRespHeader.cSource = %c",pMarShrtfallHdrResp.IntRespHeader.cSource);
        logDebug2("pMarShrtfallHdrResp.iNoofRec = %d",pMarShrtfallHdrResp.iNoofRec);

        logDebug2("pViewMarginShrtfallReq->ReqHeader.iUserId = %d",pViewMarginShrtfallReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewMarginShrtfallReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pMarShrtfallHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logFatal("Write Q id %d", iTrdRtrToRel);
		 return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                logDebug2("No 0f pkt (i) = %d",i);
                memset(&pMarginShrtfallResp,'\0',sizeof(struct VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP));

                pMarginShrtfallResp.IntRespHeader.iSeqNo = 0;
                pMarginShrtfallResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP);
                pMarginShrtfallResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_MARGIN_SHORTFALL_RESP;
                pMarginShrtfallResp.IntRespHeader.iErrorId = 0;
                pMarginShrtfallResp.IntRespHeader.iUserId = pViewMarginShrtfallReq->ReqHeader.iUserId;
                pMarginShrtfallResp.IntRespHeader.cSource = pViewMarginShrtfallReq->ReqHeader.cSource ;
                logDebug2(" iTempNoOfRec :%d:",iTempNoOfRec);

                if(iTempNoOfRec <= 1)
                {
                        pMarginShrtfallResp.cMsgType = 'T';
                }
                else
                {
                        pMarginShrtfallResp.cMsgType = 'D';
                }


                for(j=0;j<5;j++)
                {
                        logDebug2("******* j = %d ********",j);

                        if((Row = mysql_fetch_row(Res)))
                        {
			 strncpy(pMarginShrtfallResp.subViewMargin[j].sClientId,Row[0],CLIENT_ID_LEN);
                                pMarginShrtfallResp.subViewMargin[j].fSpan = atof(Row[1]);
                                pMarginShrtfallResp.subViewMargin[j].fExposure_Margin = atof(Row[2]);
                                pMarginShrtfallResp.subViewMargin[j].fTotalMTM = atof(Row[3]);
                                pMarginShrtfallResp.subViewMargin[j].fNet_option = atof(Row[4]);
                                pMarginShrtfallResp.subViewMargin[j].fSellOption_remium = atof(Row[5]);
                                pMarginShrtfallResp.subViewMargin[j].fShortfall_VAL = atof(Row[6]);
                                pMarginShrtfallResp.subViewMargin[j].fTotal_Balance = atof(Row[7]);
                                pMarginShrtfallResp.subViewMargin[j].fUtilized_cash = atof(Row[8]);
                                pMarginShrtfallResp.subViewMargin[j].fLimitSod = atof(Row[9]);;
                                pMarginShrtfallResp.subViewMargin[j].fAval_Bal = atof(Row[10]);;
                                pMarginShrtfallResp.subViewMargin[j].fMTM = atof(Row[11]);
                                pMarginShrtfallResp.subViewMargin[j].fColletral = atof(Row[12]);
                                pMarginShrtfallResp.subViewMargin[j].cSegment = Row[13][0];
                                pMarginShrtfallResp.subViewMargin[j].fFiller9 = 0;
                                pMarginShrtfallResp.subViewMargin[j].fFiller10 = 0;
                                pMarginShrtfallResp.subViewMargin[j].fFiller11 = 0;

                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].sClientId = %s",j,pMarginShrtfallResp.subViewMargin[j].sClientId);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fSpan = %lf",j,pMarginShrtfallResp.subViewMargin[j].fSpan);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fShortfall_VAL= %lf",j,pMarginShrtfallResp.subViewMargin[j].fShortfall_VAL);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fTotalMTM= %lf",j,pMarginShrtfallResp.subViewMargin[j].fTotalMTM);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fNet_option = %lf",j,pMarginShrtfallResp.subViewMargin[j].fNet_option);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fUtilized_cash= %lf",j,pMarginShrtfallResp.subViewMargin[j].fUtilized_cash);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fExposure_Margin = %lf",j,pMarginShrtfallResp.subViewMargin[j].fExposure_Margin);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fSellOption_remium = %lf",j,pMarginShrtfallResp.subViewMargin[j].fSellOption_remium);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fTotal_Balance = %lf",j,pMarginShrtfallResp.subViewMargin[j].fTotal_Balance);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fAval_Bal = %lf",j,pMarginShrtfallResp.subViewMargin[j].fAval_Bal);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fMTM = %lf",j,pMarginShrtfallResp.subViewMargin[j].fMTM);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fLimitSod = %lf",j,pMarginShrtfallResp.subViewMargin[j].fLimitSod);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].cSegment = %c",pMarginShrtfallResp.subViewMargin[j].cSegment);
                                logDebug2("pMarginShrtfallResp.subViewMargin[%d].fColletral = %lf",j,pMarginShrtfallResp.subViewMargin[j].fColletral);
                                logDebug2("pMarginShrtfallResp.cMsgType = %c",pMarginShrtfallResp.cMsgType);
                        }


                }

                if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pMarginShrtfallResp,sizeof(struct VIEW_ADMIN_MARGIN_COMMON_QUERY_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logDebug2("Write Q id %d", iTrdRtrToRel);
			return FALSE;
                }

                iTempNoOfRec--;
	}

        logTimestamp("Exit : fMarginShortFall");
	return TRUE;
	
}

BOOL	fClientHolding(CHAR *RcvMsg)
{
	logTimestamp("Entry : fClientHolding");
	struct	VIEW_CLIENT_HOLD_REQ		*pClientHoldReq;
	struct	VIEW_ADMIN_CLIENT_HOLDINGS_RESP pClientHoldResp; 
	struct	VIEW_COMMON_HDR_RESP		pClientHoldHdrResp;

	CHAR    sClentHoldQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sHoldQry[QUERY_SIZE];
	CHAR    sWhere_Clause[QUERY_SIZE];
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sClentHoldQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	pClientHoldReq = (struct  VIEW_CLIENT_HOLD_REQ *)RcvMsg;

	logDebug2("pClientHoldReq->ReqHeader.sExcgId = :%s:",pClientHoldReq->ReqHeader.sExcgId);
	logDebug2("pClientHoldReq->sSecuritySource = :%s:",pClientHoldReq->sSecuritySource);
	logDebug2("pClientHoldReq->sSymbol = :%s:",pClientHoldReq->sSymbol);
	logDebug2("pClientHoldReq->sClientId = :%s:",pClientHoldReq->sClientId);
	logDebug2("pClientHoldReq->sEntityId = :%s:",pClientHoldReq->sEntityId);

	BOOL    iChkBrcnh = FALSE;
	CHAR    sBrchId[BRANCH_ID_LEN];
	memset(sBrchId,'\0',BRANCH_ID_LEN);

	CHAR    sBrchClaus[QUERY_SIZE];
	memset(sBrchClaus,'\0',QUERY_SIZE);
	iChkBrcnh = fChckAdminContrlr(pClientHoldReq->sEntityId,&sBrchId);

	if(iChkBrcnh == TRUE)
	{
		sprintf(sBrchClaus ," AND client_id in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
	}
	else
	{
		sprintf(sBrchClaus ," ");
	}

	logDebug2(" sBrchClaus :%s:",sBrchClaus);	

	if(strcmp(pClientHoldReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry," AND exch_id = \"%s\"",pClientHoldReq->ReqHeader.sExcgId);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(strcmp(pClientHoldReq->sSecuritySource,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry," AND security_source_type = \"%s\"",pClientHoldReq->sSecuritySource);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pClientHoldReq->sSymbol,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry," AND (nse_symbol = \"%s\" OR bse_symbol = \"%s\")",pClientHoldReq->sSymbol,pClientHoldReq->sSymbol);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(strcmp(pClientHoldReq->sClientId,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry,"AND client_id like \"%s\"",pClientHoldReq->sClientId);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	logDebug2("final client holding sWhere_Clause = %s",sWhere_Clause);

	sprintf(sClentHoldQry,"SELECT CAST(@rn:=@rn + 1 AS UNSIGNED) ROW_NUM, hld.* FROM (SELECT XX.*,IFNULL(ROUND(ELW.L1_LTP, 2), 0) AS ltp,\
		TRIM(ROUND(((IFNULL(XX.QTY, 0) - IFNULL(XX.QTY_UTILIZED, 0)) * IFNULL(ELW.L1_LTP, 0)), 2)) AS market_value FROM \
			(SELECT    RCSL.CLIENT_ID AS client_id, RCSL.EXCH_ID AS exch_id,RCSL.ISIN_CODE AS isin_code,RCSL.SECURITY_SOURCE_TYPE AS security_source_type,\
			 RCSL.QTY AS qty,IFNULL(RCSL.QTY_UTILIZED, 0) AS qty_utilized,(IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED, 0)) AS rem_qty,\
			 (IFNULL(RCSL.NSE_SCRIP_CODE, 'NA')) AS nse_scrip_code, (IFNULL(RCSL.BSE_SCRIP_CODE, 'NA')) AS bse_scrip_code,\
			 (IFNULL(RCSL.NSE_SYMBOL, 'NA')) AS nse_symbol,(IFNULL(RCSL.BSE_SYMBOL, 'NA')) AS bse_symbol,IFNULL(RCSL.COST_PRICE, 0) AS cost_price,\
			 (CASE RCSL.COLLATERAL_FLAG   WHEN 'Y' THEN IFNULL(ROUND((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * \
										 (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 100)) / 100), 2), 0) ELSE 0 END) AS COLLATERAL,\
			 IFNULL(RCSL.NSE_SERIES, 'NA') AS NSE_SERIES,IFNULL(RCSL.BSE_SERIES, 'NA') AS BSE_SERIES FROM \
			 RMS_CLIENT_SECURITY_LIMIT RCSL   LEFT JOIN HAIRCUT_MASTER HM ON RCSL.ISIN_CODE = HM.HM_ISIN  LEFT JOIN SECURITY_MASTER SM \
			 ON RCSL.ISIN_CODE = SM.SM_ISIN_CODE   LEFT JOIN EQ_L1_WATCH LWA ON SM.SM_SCRIP_CODE = LWA.L1_SCRIP_CODE  WHERE   1 = 1 %s %s \
			 AND (CASE RCSL.EXCH_ID   WHEN 'ALL' THEN 'NSE' ELSE RCSL.EXCH_ID  END) = SM.SM_EXCHANGE  AND SM.SM_STATUS = 'A' \
			 AND SM.SM_EXCH_STATUS = 'A') AS XX LEFT OUTER JOIN EQ_L1_WATCH ELW ON (CASE  WHEN XX.EXCH_ID = 'NSE' THEN XX.NSE_SCRIP_CODE \
				 WHEN XX.EXCH_ID = 'BSE' THEN XX.BSE_SCRIP_CODE  WHEN XX.EXCH_ID = 'ALL' THEN XX.NSE_SCRIP_CODE  END = ELW.L1_SCRIP_CODE) \
			ORDER BY XX.CLIENT_ID) AS hld   CROSS JOIN   (SELECT @rn:=0) R; ",sBrchClaus,sWhere_Clause);
	logDebug2("sClentHoldQry = %s",sClentHoldQry);

	if(mysql_query(DBQury,sClentHoldQry) != SUCCESS)
	{
		logSqlFatal("Error in ClentHoldQry");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);

	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;

	pClientHoldHdrResp.IntRespHeader.iSeqNo = 0;
	pClientHoldHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pClientHoldHdrResp.IntRespHeader.iErrorId = 0;
	pClientHoldHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CLINET_HOLDING_HEADER_RESP;
	pClientHoldHdrResp.IntRespHeader.iUserId = pClientHoldReq->ReqHeader.iUserId;
	pClientHoldHdrResp.IntRespHeader.cSource = pClientHoldReq->ReqHeader.cSource ;
	pClientHoldHdrResp.cMsgType = 'H';
	pClientHoldHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pClientHoldHdrResp.IntRespHeader.iMsgLength = %d",pClientHoldHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pClientHoldHdrResp.IntRespHeader.iMsgCode = %d",pClientHoldHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pClientHoldHdrResp.IntRespHeader.iUserId = %llu",pClientHoldHdrResp.IntRespHeader.iUserId);
	logDebug2("pClientHoldHdrResp.IntRespHeader.cSource = %c",pClientHoldHdrResp.IntRespHeader.cSource);
	logDebug2("pClientHoldHdrResp.iNoofRec = %d",pClientHoldHdrResp.iNoofRec);	

	logDebug2("pClientHoldReq->ReqHeader.iUserId = %llu",pClientHoldReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pClientHoldReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pClientHoldHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No of Pkt (i) = %d",i);

		memset(&pClientHoldResp,'\0',sizeof(struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP));
		pClientHoldResp.IntRespHeader.iSeqNo = 0;
		pClientHoldResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP);
		logDebug2("...pClientHoldResp.IntRespHeader.iMsgLength = %d",pClientHoldResp.IntRespHeader.iMsgLength);
		pClientHoldResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CLINET_HOLDING_RESP;
		pClientHoldResp.IntRespHeader.iErrorId = 0;
		pClientHoldResp.IntRespHeader.iUserId = pClientHoldReq->ReqHeader.iUserId;
		pClientHoldResp.IntRespHeader.cSource = pClientHoldReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pClientHoldResp.cMsgType = 'T';
		}
		else
		{
			pClientHoldResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			logDebug2("No of row in pkt (j) = %d",j);
			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(pClientHoldResp.subClientHoldings[j].sNseSecurityID,Row[8],SECURITY_ID_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sBseSecurityID,Row[9],SECURITY_ID_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sISINCode,Row[3],ISINCODE_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sSecuritySource,Row[4],SEC_SOURCE_LEN);
				pClientHoldResp.subClientHoldings[j].iQty = atoi(Row[5]);
				pClientHoldResp.subClientHoldings[j].iQtyUtilized = atoi(Row[6]);
				pClientHoldResp.subClientHoldings[j].iRemQty = atoi(Row[7]);
				strncpy(pClientHoldResp.subClientHoldings[j].sExcgId,Row[2],EXCHANGE_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sNseSymbol,Row[10],SECURITY_SYM_LEN);			
				strncpy(pClientHoldResp.subClientHoldings[j].sBseSymbol,Row[11],SECURITY_SYM_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sClientId,Row[1],CLIENT_ID_LEN);
				pClientHoldResp.subClientHoldings[j].fCostPrice = atof(Row[12]);	
				pClientHoldResp.subClientHoldings[j].fCollateral = atof(Row[13]);
				strncpy(pClientHoldResp.subClientHoldings[j].sNseSeries,Row[14],HLD_SERIES_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sBseSeries,Row[15],HLD_SERIES_LEN);
				pClientHoldResp.subClientHoldings[j].fLtp = atof(Row[14]);
				pClientHoldResp.subClientHoldings[j].fMarketValue = atof(Row[15]);

				logDebug2("pClientHoldResp.subClientHoldings[%d].sClientId = %s",j,pClientHoldResp.subClientHoldings[j].sClientId);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sExcgId = %s",j,pClientHoldResp.subClientHoldings[j].sExcgId);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sISINCode = %s",j,pClientHoldResp.subClientHoldings[j].sISINCode);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sSecuritySource= %s",j,pClientHoldResp.subClientHoldings[j].sSecuritySource);
				logDebug2("pClientHoldResp.subClientHoldings[%d].iQty = %d",j,pClientHoldResp.subClientHoldings[j].iQty);
				logDebug2("pClientHoldResp.subClientHoldings[%d].iQtyUtilized = %d",j,pClientHoldResp.subClientHoldings[j].iQtyUtilized);
				logDebug2("pClientHoldResp.subClientHoldings[%d].iRemQty = %d",j,pClientHoldResp.subClientHoldings[j].iRemQty);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fLtp = %lf",j,pClientHoldResp.subClientHoldings[j].fLtp);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fMarketValue = %lf",j,pClientHoldResp.subClientHoldings[j].fMarketValue);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sNseSecurityID = %s",j,pClientHoldResp.subClientHoldings[j].sNseSecurityID);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sBseSecurityID = %s",j,pClientHoldResp.subClientHoldings[j].sBseSecurityID);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sNseSymbol = %s",j,pClientHoldResp.subClientHoldings[j].sNseSymbol);	
				logDebug2("pClientHoldResp.subClientHoldings[%d].sBseSymbol = %s",j,pClientHoldResp.subClientHoldings[j].sBseSymbol);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fCostPrice = %lf",j,pClientHoldResp.subClientHoldings[j].fCostPrice);	
				logDebug2("pClientHoldResp.subClientHoldings[%d].sNseSeries  = %s",j,pClientHoldResp.subClientHoldings[j].sNseSeries);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sBseSeries= %s",j,pClientHoldResp.subClientHoldings[j].sBseSeries);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fCollateral= %lf",j,pClientHoldResp.subClientHoldings[j].fCollateral);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fLtp = %lf",j,pClientHoldResp.subClientHoldings[j].fLtp);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fMarketValue = %lf",j,pClientHoldResp.subClientHoldings[j].fMarketValue);

				logDebug2("pClientHoldResp.cMsgType = %c",pClientHoldResp.cMsgType);
			}

		}

		if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pClientHoldResp,sizeof(struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
			//xit(ERROR);
			return FALSE;
		}
		iTempNoOfRec--;
		//	usleep(5000);

	}

	logTimestamp("Exit : fClientHolding");
	return TRUE ;
}

BOOL	fViewClientLimit(CHAR *RcvMsg)
{
	logTimestamp("Entry : fViewClientLimit");

	struct 	VIEW_CLIENT_LIMIT_REQ		*pViewLimReq;
	struct	VIEW_ADMIN_CLIENT_LIMIT_RESP	pViewLmtResp;
	struct	VIEW_COMMON_HDR_RESP		pLmtHdrResp;

	//	LONG32	iTempUserID = 0;

	//	CHAR    *sClentLimtQry = malloc(sizeof(CHAR) * QUERY_SIZE);
	//        CHAR    *sLimitQry = malloc(sizeof(CHAR) * QUERY_SIZE);
	CHAR    sClentLimtQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sLimitQry[QUERY_SIZE];
	CHAR    sWhere_Clause[QUERY_SIZE];
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sClentLimtQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec = 0.0;
	LONG32          iNoOfPkt = 0;
	LONG32          iTempNoOfRec = 0;

	pViewLimReq = (struct VIEW_CLIENT_LIMIT_REQ *)RcvMsg;

	logDebug2("pViewLimReq->sAccount = %s",pViewLimReq->sAccount);
	logDebug2("pViewLimReq->sClientId = %s",pViewLimReq->sClientId);
	logDebug2("pViewLimReq->sEntityId = %s",pViewLimReq->sEntityId);
	logDebug2("pViewLimReq->iDebitBalanceFlag = %d",pViewLimReq->iDebitBalanceFlag);

	BOOL    iChkBrcnh = FALSE;
	CHAR    sBrchId[BRANCH_ID_LEN];
	memset(sBrchId,'\0',BRANCH_ID_LEN);

	CHAR    sBrchClaus[QUERY_SIZE];
	memset(sBrchClaus,'\0',QUERY_SIZE);
	iChkBrcnh = fChckAdminContrlr(pViewLimReq->sEntityId,&sBrchId);

	if(iChkBrcnh == TRUE)
	{
		sprintf(sBrchClaus ," AND CLIENT_ID in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
	}
	else
	{
		sprintf(sBrchClaus ," ");
	}

	logDebug2(" sBrchClaus :%s:",sBrchClaus);

	if(strcmp(pViewLimReq->sAccount,SELECT_ALL))
	{
		memset(sLimitQry,'\0',QUERY_SIZE);
		sprintf(sLimitQry,"AND LIMIT_TYPE = \"%s\"",pViewLimReq->sAccount);
		logDebug2("sLimitQry1 = %s",sLimitQry);
		strcat(sWhere_Clause,sLimitQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);	
	}
	if(strcmp(pViewLimReq->sClientId,SELECT_ALL))
	{
		memset(sLimitQry,'\0',QUERY_SIZE);
		sprintf(sLimitQry,"AND CLIENT_ID like \"%s\"",pViewLimReq->sClientId);
		logDebug2("sLimitQry2 = %s",sLimitQry);
		strcat(sWhere_Clause,sLimitQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(pViewLimReq->iDebitBalanceFlag == DEBIT_BALANCE_FLAG)
	{
		memset(sLimitQry,'\0',QUERY_SIZE);
		//sprintf(sLimitQry," AND AVAILABLE_BALANCE < 0");
		sprintf(sLimitQry," AND LIMIT_SOD < 0");
		logDebug2("sLimitQry3 = %s",sLimitQry);
		strcat(sWhere_Clause,sLimitQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}

	logDebug2("final client limit Where_Clause = %s",sWhere_Clause);	
/**
	sprintf(sClentLimtQry,"SELECT  IFNULL(LIMIT_SOD, 0), IFNULL(ADHOC_LIMIT, 0), IFNULL(RECEIVABLES, 0), IFNULL(BANK_HOLDING, 0), IFNULL(COLLATERALS, 0), IFNULL(REALISED_PROFITS, 0), IFNULL(AMOUNT_UTILIZED, 0), IFNULL(COLLATERALS + SUM_OF_ALL, 0) AS SUM_OF_ALL, IFNULL(COLLATERALS + AVAILABLE_BALANCE, 0) AS AVAILABLE_BALANCE, IFNULL(CLEAR_BALANCE, 0), IFNULL(LIMIT_TYPE, 0), IFNULL(CLIENT_ID, 0), IFNULL(REQUEST_PAYOUT_AMOUNT, 0), IFNULL(SEGMENT, 0), IFNULL(CF_OPT_SELL_PREMIUM, 0), IFNULL(CF_OPT_SELL_PREMIUM_COMM, 0), IFNULL(CLIENT_NAME, 0), IFNULL(GROSS_HOLDING_VAL, 0) FROM (SELECT  X.limit_sod AS LIMIT_SOD, X.adhoc_limit AS ADHOC_LIMIT,   (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) AS RECEIVABLES, X.bank_holding AS BANK_HOLDING,  CASE RCSL.COLLATERAL_FLAG  WHEN 'Y' THEN ROUND(IFNULL(SUM((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 0)) / 100)), 0), 2)   ELSE 0 END AS COLLATERALS,   (X.realised_profits + X.realised_profits_Comm) AS REALISED_PROFITS,  (X.Amount_Utilized + X.Amount_Utilized_Comm) AS AMOUNT_UTILIZED,   ROUND((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) - X.Request_Payout_Amount), 2) AS SUM_OF_ALL,  ROUND(((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM) - (X.Amount_Utilized + X.Amount_Utilized_Comm)) - X.Request_Payout_Amount, 2) AS AVAILABLE_BALANCE, X.CLEAR_BALANCE AS CLEAR_BALANCE,  X.limit_type AS LIMIT_TYPE,   X.CLIENT_ID AS CLIENT_ID, X.Request_Payout_Amount AS Request_Payout_Amount,   X.SEGMENT AS SEGMENT,   X.CF_OPT_SELL_PREMIUM AS CF_OPT_SELL_PREMIUM, X.CF_OPT_SELL_PREMIUM_COMM AS CF_OPT_SELL_PREMIUM_COMM,   E.ENTITY_NAME AS CLIENT_NAME,   (CASE   WHEN  X.SEGMENT IN('E','A') THEN ROUND(IFNULL(SUM((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * IFNULL(LWA.L1_LTP, 0)), 0), 2)  ELSE 0   END) AS GROSS_HOLDING_VAL FROM  (SELECT  'CAPITAL' AS `limit_type`,  ROUND(IFNULL(`R`.`C_CASH_BALANCE`, 0), 2) AS `limit_sod`,  ROUND(IFNULL(`R`.`C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,   ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`, ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM_COMM`, 0), 2) AS `CF_OPT_SELL_PREMIUM_COMM`, ROUND(IFNULL(`R`.`NC_NSE_RECEIVABLES`, 0) + IFNULL(`R`.`NC_BSE_RECEIVABLES`, 0), 2) AS `receivables`,   ROUND(IFNULL(`R`.`C_BANK_HOLD`, 0), 2) AS `bank_holding`,   ROUND(IFNULL(`R`.`NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,  ROUND(IFNULL(`R`.`NC_REALISED_PROFIT_COMM`, 0), 2) AS `realised_profits_Comm`,   ROUND((IFNULL(`R`.`TOTAL_CASH_UTILIZED`, 0) + IFNULL(`R`.`TOTAL_NON_CASH_UTILIZED`, 0)), 2) AS `Amount_Utilized`,   ROUND(IFNULL(`R`.`TOTAL_CASH_UTILIZED_COMM`, 0), 2) AS `Amount_Utilized_Comm`, `R`.`CLIENT_ID` AS `CLIENT_ID`,  `R`.`EXCH_ID` AS `EXCH_ID`,  `R`.`SEGMENT` AS `segment`,  ROUND(`R`.`WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`, ROUND(`R`.`REQUEST_PAYOUT_AMOUNT`, 2) AS `Request_Payout_Amount` FROM `RMS_FUND_LIMIT` `R` WHERE R.CLIENT_ID LIKE \"%s\" UNION ALL SELECT 'COMMODITY' AS `limit_type`, ROUND(IFNULL(`R`.`RMLC_C_CASH_BALANCE`, 0), 2) AS `limit_sod`, ROUND(IFNULL(`R`.`RMLC_C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`, ROUND(IFNULL(`R`.`RMLC_CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`, 0 AS `CF_OPT_SELL_PREMIUM_COMM`, 0 AS `receivables`, ROUND(IFNULL(`R`.`RMLC_C_BANK_HOLD`, 0), 2) AS `bank_holding`, ROUND(IFNULL(`R`.`RMLC_NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`, 0 AS `realised_profits_Comm`, ROUND(IFNULL(`R`.`RMLC_TOTAL_CASH_UTILIZED`, 0), 2) AS `Amount_Utilized`, 0 AS `Amount_Utilized_Comm`,  `R`.`RMLC_CLIENT_ID` AS `CLIENT_ID`, `R`.`RMLC_EXCHANGE` AS `EXCH_ID`, `R`.`RMLC_SEGMENT` AS `SEGMENT`, ROUND(`R`.`RMLC_WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`, ROUND(`R`.`RMLC_REQUEST_PAYOUT_AMOUNT`, 2) AS `REQUEST_PAYOUT_AMOUNT` FROM `RMS_FUND_LIMIT_COM` `R` WHERE R.RMLC_CLIENT_ID LIKE \"%s\") X LEFT JOIN `ENTITY_MASTER` `E` ON ((`E`.`ENTITY_CODE` = `X`.`CLIENT_ID`)) LEFT JOIN `RMS_RISK_PROFILE_MAST` `D` ON ((`E`.`ENTITY_RISK_PROFILE` = `D`.`RPM_CODE`)) LEFT JOIN RMS_CLIENT_SECURITY_LIMIT RCSL ON ((RCSL.CLIENT_ID = X.CLIENT_ID AND RCSL.SECURITY_SOURCE_TYPE IN ('HLD' , 'T1', 'MRG'))) LEFT JOIN EQ_L1_WATCH LWA ON (CASE WHEN RCSL.EXCH_ID = 'ALL' THEN RCSL.NSE_SCRIP_CODE WHEN RCSL.EXCH_ID = 'NSE' THEN RCSL.NSE_SCRIP_CODE ELSE RCSL.BSE_SCRIP_CODE END = LWA.L1_SCRIP_CODE) LEFT JOIN HAIRCUT_MASTER HM ON (RCSL.ISIN_CODE = HM.HM_ISIN) GROUP BY X.SEGMENT) AS XX WHERE 1 = 1 %s %s;",pViewLimReq->sClientId,pViewLimReq->sClientId,sWhere_Clause,sBrchClaus);

***/
/**
	sprintf(sClentLimtQry,"SELECT  IFNULL(LIMIT_SOD, 0), IFNULL(ADHOC_LIMIT, 0), IFNULL(RECEIVABLES, 0), IFNULL(BANK_HOLDING, 0), CASE WHEN SEGMENT IN('E','A') THEN SUM(IFNULL(ROUND(COLLATERALS,2),0)) ELSE 0 END COLLATERALS, IFNULL(REALISED_PROFITS, 0), IFNULL(AMOUNT_UTILIZED, 0), IFNULL((CASE WHEN SEGMENT IN('E','A') THEN SUM(IFNULL(ROUND(COLLATERALS,2),0)) ELSE 0 END) + SUM_OF_ALL, 0) AS SUM_OF_ALL, IFNULL((CASE WHEN SEGMENT IN('E','A') THEN SUM(IFNULL(ROUND(COLLATERALS,2),0)) ELSE 0 END) + AVAILABLE_BALANCE, 0) AS AVAILABLE_BALANCE, IFNULL(CLEAR_BALANCE, 0), IFNULL(LIMIT_TYPE, 0), IFNULL(CLIENT_ID, 0), IFNULL(REQUEST_PAYOUT_AMOUNT, 0), IFNULL(SEGMENT, 0), IFNULL(CF_OPT_SELL_PREMIUM, 0), IFNULL(CF_OPT_SELL_PREMIUM_COMM, 0), IFNULL(CLIENT_NAME, 0), CASE WHEN SEGMENT IN('E','A') THEN SUM(IFNULL(ROUND(GROSS_HOLDING_VAL,2),0)) ELSE 0 END GROSS_HOLDING_VAL FROM ( SELECT  X.limit_sod AS LIMIT_SOD,    X.adhoc_limit AS ADHOC_LIMIT,    (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) AS RECEIVABLES,    X.bank_holding AS BANK_HOLDING, case  when  RCSL.COLLATERAL_FLAG='Y' THEN ((IFNULL(RCSL.QTY,0)- IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) *(IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 0)) / 100)) ELSE 0 END COLLATERALS,  (X.realised_profits + X.realised_profits_Comm) AS REALISED_PROFITS,  (X.Amount_Utilized + X.Amount_Utilized_Comm) AS AMOUNT_UTILIZED,  ROUND((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) - X.Request_Payout_Amount), 2) AS SUM_OF_ALL,  ROUND(((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM) - (X.Amount_Utilized + X.Amount_Utilized_Comm)) - X.Request_Payout_Amount, 2) AS AVAILABLE_BALANCE,  X.CLEAR_BALANCE AS CLEAR_BALANCE,  X.limit_type AS LIMIT_TYPE, X.CLIENT_ID AS CLIENT_ID,  X.Request_Payout_Amount AS Request_Payout_Amount,  X.SEGMENT AS SEGMENT,   X.CF_OPT_SELL_PREMIUM AS CF_OPT_SELL_PREMIUM,  X.CF_OPT_SELL_PREMIUM_COMM AS CF_OPT_SELL_PREMIUM_COMM,  E.ENTITY_NAME AS CLIENT_NAME, (IFNULL(RCSL.QTY,0)- IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) *(IFNULL(LWA.L1_LTP, 0)) AS GROSS_HOLDING_VAL FROM  (SELECT          'CAPITAL' AS `limit_type`,             ROUND(IFNULL(`R`.`C_CASH_BALANCE`, 0), 2) AS `limit_sod`,             ROUND(IFNULL(`R`.`C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,             ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,             ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM_COMM`, 0), 2) AS `CF_OPT_SELL_PREMIUM_COMM`,             ROUND(IFNULL(`R`.`NC_NSE_RECEIVABLES`, 0) + IFNULL(`R`.`NC_BSE_RECEIVABLES`, 0), 2) AS `receivables`,             ROUND(IFNULL(`R`.`C_BANK_HOLD`, 0), 2) AS `bank_holding`,             ROUND(IFNULL(`R`.`NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,             ROUND(IFNULL(`R`.`NC_REALISED_PROFIT_COMM`, 0), 2) AS `realised_profits_Comm`,             ROUND((IFNULL(`R`.`TOTAL_CASH_UTILIZED`, 0) + IFNULL(`R`.`TOTAL_NON_CASH_UTILIZED`, 0)), 2) AS `Amount_Utilized`,             ROUND(IFNULL(`R`.`TOTAL_CASH_UTILIZED_COMM`, 0), 2) AS `Amount_Utilized_Comm`,             `R`.`CLIENT_ID` AS `CLIENT_ID`,             `R`.`EXCH_ID` AS `EXCH_ID`,             `R`.`SEGMENT` AS `segment`,             ROUND(`R`.`WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,             ROUND(`R`.`REQUEST_PAYOUT_AMOUNT`, 2) AS `Request_Payout_Amount`     FROM         `RMS_FUND_LIMIT` `R`     WHERE         R.CLIENT_ID LIKE \"%s\"  UNION ALL SELECT          'COMMODITY' AS `limit_type`,             ROUND(IFNULL(`R`.`RMLC_C_CASH_BALANCE`, 0), 2) AS `limit_sod`,             ROUND(IFNULL(`R`.`RMLC_C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,             ROUND(IFNULL(`R`.`RMLC_CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,             0 AS `CF_OPT_SELL_PREMIUM_COMM`,             0 AS `receivables`,             ROUND(IFNULL(`R`.`RMLC_C_BANK_HOLD`, 0), 2) AS `bank_holding`,             ROUND(IFNULL(`R`.`RMLC_NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,             0 AS `realised_profits_Comm`,             ROUND(IFNULL(`R`.`RMLC_TOTAL_CASH_UTILIZED`, 0), 2) AS `Amount_Utilized`,             0 AS `Amount_Utilized_Comm`,             `R`.`RMLC_CLIENT_ID` AS `CLIENT_ID`,             `R`.`RMLC_EXCHANGE` AS `EXCH_ID`,             `R`.`RMLC_SEGMENT` AS `SEGMENT`,             ROUND(`R`.`RMLC_WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,             ROUND(`R`.`RMLC_REQUEST_PAYOUT_AMOUNT`, 2) AS `REQUEST_PAYOUT_AMOUNT`     FROM         `RMS_FUND_LIMIT_COM` `R`     WHERE         R.RMLC_CLIENT_ID LIKE \"%s\")X          LEFT JOIN `ENTITY_MASTER` `E` ON ((`E`.`ENTITY_CODE` = `X`.`CLIENT_ID`))     LEFT JOIN `RMS_RISK_PROFILE_MAST` `D` ON ((`E`.`ENTITY_RISK_PROFILE` = `D`.`RPM_CODE`))     LEFT JOIN RMS_CLIENT_SECURITY_LIMIT RCSL ON (RCSL.CLIENT_ID = X.CLIENT_ID         AND RCSL.SECURITY_SOURCE_TYPE IN ('HLD' , 'T1', 'MRG'))          LEFT JOIN EQ_L1_WATCH LWA ON (LWA.L1_SCRIP_CODE = CASE RCSL.EXCH_ID         WHEN 'ALL' THEN RCSL.NSE_SCRIP_CODE         WHEN 'NSE' THEN RCSL.NSE_SCRIP_CODE         ELSE RCSL.BSE_SCRIP_CODE     END         AND LWA.L1_SEGMENT = 'E'         AND LWA.L1_EXCHANGE = CASE         WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'         ELSE RCSL.EXCH_ID     END)     LEFT JOIN HAIRCUT_MASTER HM ON (RCSL.ISIN_CODE = HM.HM_ISIN         AND HM.HM_EXCHANGE = CASE         WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'         ELSE RCSL.EXCH_ID     END))D WHERE 1=1  %s %s GROUP BY SEGMENT,CLIENT_ID  ; ",pViewLimReq->sClientId,pViewLimReq->sClientId,sWhere_Clause,sBrchClaus);
***/ 
/***
 *	Adding MTM Value in Query and Structure
 *
 */

	sprintf(sClentLimtQry,"SELECT   IFNULL(LIMIT_SOD, 0),   IFNULL(ADHOC_LIMIT, 0),   IFNULL(RECEIVABLES, 0),   IFNULL(BANK_HOLDING, 0),   CASE     WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(COLLATERALS, 2), 0))     ELSE 0   END COLLATERALS,   IFNULL(REALISED_PROFITS, 0),   IFNULL(AMOUNT_UTILIZED, 0),   IFNULL((CASE         WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(COLLATERALS, 2), 0))         ELSE 0       END) + SUM_OF_ALL,       0) AS SUM_OF_ALL,   IFNULL((CASE         WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(COLLATERALS, 2), 0))         ELSE 0       END) + AVAILABLE_BALANCE + IF(IFNULL(MTM_COMB,0) < 0,IFNULL(MTM_COMB,0),0),       0) AS AVAILABLE_BALANCE,   IFNULL(CLEAR_BALANCE, 0),   IFNULL(LIMIT_TYPE, 0),   IFNULL(CLIENT_ID, 0),   IFNULL(REQUEST_PAYOUT_AMOUNT, 0),   IFNULL(SEGMENT, 0),   IFNULL(CF_OPT_SELL_PREMIUM, 0),   IFNULL(CF_OPT_SELL_PREMIUM_COMM, 0),   IFNULL(CLIENT_NAME, 0),   CASE     WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(GROSS_HOLDING_VAL, 2), 0))     ELSE 0   END GROSS_HOLDING_VAL,   IFNULL(MTM_COMB,0) FROM   (SELECT     X.limit_sod AS LIMIT_SOD,       X.adhoc_limit AS ADHOC_LIMIT,       (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) AS RECEIVABLES,       X.bank_holding AS BANK_HOLDING,       CASE         WHEN RCSL.COLLATERAL_FLAG = 'Y' THEN ((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 0)) / 100))         ELSE 0       END COLLATERALS,       (X.realised_profits + X.realised_profits_Comm) AS REALISED_PROFITS,       (X.Amount_Utilized + X.Amount_Utilized_Comm) AS AMOUNT_UTILIZED,       ROUND((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) - X.Request_Payout_Amount), 2) AS SUM_OF_ALL,       ROUND(((X.limit_sod + X.adhoc_limit + X.bank_holding + (case D.RPM_REALIZE_PROFIT when 'Y' then X.realised_profits else (case WHEN (D.RPM_REALIZE_PROFIT_SUBS='Y' AND X.realised_profits<0) THEN X.realised_profits ELSE 0 END) end)        +(case D.RPM_REALIZE_PROFIT when 'Y' then X.realised_profits_Comm else (case WHEN (D.RPM_REALIZE_PROFIT_SUBS='Y' AND X.realised_profits_Comm<0) THEN X.realised_profits_Comm ELSE 0 END) end) + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM) - (X.Amount_Utilized + X.Amount_Utilized_Comm)) - X.Request_Payout_Amount, 2) AS AVAILABLE_BALANCE,       X.CLEAR_BALANCE AS CLEAR_BALANCE,       X.limit_type AS LIMIT_TYPE,       X.CLIENT_ID AS CLIENT_ID,       X.Request_Payout_Amount AS Request_Payout_Amount,       X.SEGMENT AS SEGMENT,       X.CF_OPT_SELL_PREMIUM AS CF_OPT_SELL_PREMIUM,       X.CF_OPT_SELL_PREMIUM_COMM AS CF_OPT_SELL_PREMIUM_COMM,       E.ENTITY_NAME AS CLIENT_NAME,       (IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) AS GROSS_HOLDING_VAL   FROM     (SELECT     'CAPITAL' AS `limit_type`,       ROUND(IFNULL(`R`.`C_CASH_BALANCE`, 0), 2) AS `limit_sod`,       ROUND(IFNULL(`R`.`C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,       ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,       ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM_COMM`, 0), 2) AS `CF_OPT_SELL_PREMIUM_COMM`,       ROUND(IFNULL(`R`.`NC_NSE_RECEIVABLES`, 0) + IFNULL(`R`.`NC_BSE_RECEIVABLES`, 0), 2) AS `receivables`,       ROUND(IFNULL(`R`.`C_BANK_HOLD`, 0), 2) AS `bank_holding`,       ROUND(IFNULL(`R`.`NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,       ROUND(IFNULL(`R`.`NC_REALISED_PROFIT_COMM`, 0), 2) AS `realised_profits_Comm`,       ROUND((IFNULL(`R`.`TOTAL_CASH_UTILIZED`, 0) + IFNULL(`R`.`TOTAL_NON_CASH_UTILIZED`, 0)), 2) AS `Amount_Utilized`,       ROUND(IFNULL(`R`.`TOTAL_CASH_UTILIZED_COMM`, 0), 2) AS `Amount_Utilized_Comm`,       `R`.`CLIENT_ID` AS `CLIENT_ID`,       `R`.`EXCH_ID` AS `EXCH_ID`,       `R`.`SEGMENT` AS `segment`,       ROUND(`R`.`WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,       ROUND(`R`.`REQUEST_PAYOUT_AMOUNT`, 2) AS `Request_Payout_Amount`   FROM     `RMS_FUND_LIMIT` `R`   WHERE     R.CLIENT_ID LIKE \"%s\" UNION ALL SELECT     'COMMODITY' AS `limit_type`,       ROUND(IFNULL(`R`.`RMLC_C_CASH_BALANCE`, 0), 2) AS `limit_sod`,       ROUND(IFNULL(`R`.`RMLC_C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,       ROUND(IFNULL(`R`.`RMLC_CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,       0 AS `CF_OPT_SELL_PREMIUM_COMM`,       0 AS `receivables`,       ROUND(IFNULL(`R`.`RMLC_C_BANK_HOLD`, 0), 2) AS `bank_holding`,       ROUND(IFNULL(`R`.`RMLC_NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,       0 AS `realised_profits_Comm`,       ROUND(IFNULL(`R`.`RMLC_TOTAL_CASH_UTILIZED`, 0), 2) AS `Amount_Utilized`,       0 AS `Amount_Utilized_Comm`,       `R`.`RMLC_CLIENT_ID` AS `CLIENT_ID`,       `R`.`RMLC_EXCHANGE` AS `EXCH_ID`,       `R`.`RMLC_SEGMENT` AS `SEGMENT`,       ROUND(`R`.`RMLC_WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,       ROUND(`R`.`RMLC_REQUEST_PAYOUT_AMOUNT`, 2) AS `REQUEST_PAYOUT_AMOUNT`   FROM     `RMS_FUND_LIMIT_COM` `R`   WHERE     R.RMLC_CLIENT_ID LIKE \"%s\") X   LEFT JOIN `ENTITY_MASTER` `E` ON ((`E`.`ENTITY_CODE` = `X`.`CLIENT_ID`))   LEFT JOIN `RMS_RISK_PROFILE_MAST` `D` ON ((`E`.`ENTITY_RISK_PROFILE` = `D`.`RPM_CODE`))   LEFT JOIN RMS_CLIENT_SECURITY_LIMIT RCSL ON (RCSL.CLIENT_ID = X.CLIENT_ID     AND RCSL.SECURITY_SOURCE_TYPE IN ('HLD' , 'T1', 'MRG'))   LEFT JOIN EQ_L1_WATCH LWA ON (LWA.L1_SCRIP_CODE = CASE RCSL.EXCH_ID     WHEN 'ALL' THEN RCSL.NSE_SCRIP_CODE     WHEN 'NSE' THEN RCSL.NSE_SCRIP_CODE     ELSE RCSL.BSE_SCRIP_CODE   END     AND LWA.L1_SEGMENT = 'E'     AND LWA.L1_EXCHANGE = CASE     WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'     ELSE RCSL.EXCH_ID   END)   LEFT JOIN HAIRCUT_MASTER HM ON (RCSL.ISIN_CODE = HM.HM_ISIN     AND HM.HM_EXCHANGE = CASE     WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'     ELSE RCSL.EXCH_ID   END)) D   CROSS JOIN (SELECT SUM(MTM) AS MTM_COMB   FROM 	(SELECT (CASE 				WHEN 					(SM.SM_SEGMENT = 'E') 				THEN 					ROUND((CASE 								WHEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0) 								THEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY) 	WHEN 0 THEN 0 	ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY)) END), 2))) 								ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY) WHEN 0 THEN 0 ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY)) 	END), 	2))) 							END), 							2) 				WHEN 					(SM.SM_SEGMENT = 'D') 				THEN 					ROUND((CASE 								WHEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0) 								THEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY) 	WHEN 0 THEN 0 	ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY)) END), 2))) 								ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY) WHEN 0 THEN 0 ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY)) 	END), 	2))) 							END), 							2) 				WHEN 					(SM.SM_SEGMENT = 'C') 				THEN 					(ROUND((CASE 								WHEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0) 								THEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY) 	WHEN 0 THEN 0 	ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY)) END), 4))) 								ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY) WHEN 0 THEN 0 ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY)) 	END), 	4))) 							END), 							2) * 1000) 				WHEN 					(SM.SM_SEGMENT = 'M') 				THEN 					(ROUND((CASE           WHEN             ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0)           THEN             ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY)                   WHEN 0 THEN 0                   ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))                 END),                 2)))           ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY)                 WHEN 0 THEN 0                 ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY))               END),               2))) 					END), 					2) * SM.SM_MCX_MULTIPLIER) 				END) AS MTM 		FROM 			(SELECT 				DT.DRV_CLIENT_ID AS CLIENT_ID, 				DT.DRV_SCRIP_CODE AS SECURITY_ID, 				DT.DRV_EXCH_ID AS EXCH_ID, 			SUM((CASE 				WHEN (DT.DRV_BUY_SELL_IND = 'B') THEN DT.DRV_TRD_TRADE_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN 					(DT.DRV_BUY_SELL_IND = 'B') 				THEN 					(CASE 						WHEN (DT.DRV_CF_FLAG = '-1') THEN (DT.DRV_ORIGINAL_PRICE * DT.DRV_TRD_TRADE_QTY) 						ELSE (DT.DRV_TRD_TRADE_PRICE * DT.DRV_TRD_TRADE_QTY) 					END) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (DT.DRV_BUY_SELL_IND = 'S') THEN DT.DRV_TRD_TRADE_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (DT.DRV_BUY_SELL_IND = 'S') THEN (DT.DRV_TRD_TRADE_PRICE * DT.DRV_TRD_TRADE_QTY) 				ELSE 0 			END)) AS SELL_VAL, 			DT.DRV_SEGMENT AS EXCH_SEGMENT, 			DT.DRV_PRODUCT_ID AS PRODUCT, 			DT.DRV_CF_FLAG AS INT_REF_ID 		FROM 			DRV_ORDERS DT 		WHERE 			(DT.DRV_TRD_STATUS = 'C') 				AND (DT.DRV_MSG_CODE = '2222') 				AND (DT.DRV_CLIENT_ID = \"%s\") 		GROUP BY DT.DRV_CLIENT_ID , DT.DRV_SCRIP_CODE , DT.DRV_EXCH_ID , DT.DRV_PRODUCT_ID , DT.DRV_SEGMENT , DT.DRV_CF_FLAG 		UNION ALL SELECT 			T.EQ_CLIENT_ID AS EQ_CLIENT_ID, 			T.EQ_SCRIP_CODE AS EQ_SCRIP_CODE, 			T.EQ_EXCH_ID AS EQ_EXCH_ID, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'B') THEN T.EQ_LAST_TRADE_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'B') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'S') THEN T.EQ_LAST_TRADE_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'S') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY) 				ELSE 0 			END)) AS SELL_VAL, 			'E' AS E, 			T.EQ_PRODUCT_ID AS EQ_PRODUCT_ID, 			0 AS INT_REF_ID 		FROM 			EQ_ORDERS T 		WHERE 			(T.EQ_TRD_STATUS = 'C') 				AND (T.EQ_MSG_CODE = 2222) 				AND (T.EQ_CLIENT_ID = \"%s\") 		GROUP BY T.EQ_CLIENT_ID , T.EQ_SCRIP_CODE , T.EQ_EXCH_ID , T.EQ_PRODUCT_ID 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS BUY_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS BUY_VAL, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS SELL_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS BUY_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS BUY_VAL, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS SELL_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL_DR CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL_DR CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT     UNION ALL     SELECT     CT.COMM_CLIENT_ID AS CLIENT_ID,     CT.COMM_SCRIP_CODE AS SECURITY_ID,     CT.COMM_EXCH_ID AS EXCH_ID,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'B') THEN CT.COMM_TRD_TRADE_QTY       ELSE 0     END)) AS BUY_QTY,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'B') THEN (CT.COMM_TRD_TRADE_PRICE * CT.COMM_TRD_TRADE_QTY)       ELSE 0     END)) AS BUY_VAL,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'S') THEN CT.COMM_TRD_TRADE_QTY       ELSE 0     END)) AS SELL_QTY,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'S') THEN (CT.COMM_TRD_TRADE_PRICE * CT.COMM_TRD_TRADE_QTY)       ELSE 0     END)) AS SELL_VAL,     CT.COMM_SEGMENT AS EXCH_SEGMENT,     CT.COMM_PRODUCT_ID AS PRODUCT,     CT.COMM_CF_FLAG AS INT_REF_ID   FROM     COMM_ORDERS CT   WHERE     COMM_CLIENT_ID = \"%s\"   GROUP BY CT.COMM_CLIENT_ID , CT.COMM_SCRIP_CODE , CT.COMM_EXCH_ID , CT.COMM_PRODUCT_ID , CT.COMM_SEGMENT   UNION SELECT     CM.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,     CM.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,     CM.RCCD_EXCHANGE AS RCCD_EXCHANGE,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN CM.RCCD_QTY       ELSE 0     END))) AS BUY_QTY,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END))) AS BUY_VAL,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN CM.RCCD_QTY       ELSE 0     END))) AS SELL_QTY,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END))) AS SELL_VAL,     CM.RCCD_SEGMENT AS rccd_segment,     CM.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE,     0 AS '0'   FROM     RMS_CLIENT_CONVT_TO_DEL_COM CM 	WHERE RCCD_CLIENT_ID = \"%s\"   GROUP BY CM.RCCD_CLIENT_ID , CM.RCCD_SCRIP_CODE , CM.RCCD_EXCHANGE , CM.RCCD_MKT_TYPE , CM.RCCD_PRODUCT_SOURCE , CM.RCCD_SEGMENT   UNION SELECT     CM.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,     CM.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,     CM.RCCD_EXCHANGE AS RCCD_EXCHANGE,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN CM.RCCD_QTY       ELSE 0     END)) AS BUY_QTY,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END)) AS BUY_VAL,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN CM.RCCD_QTY       ELSE 0     END)) AS SELL_QTY,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END)) AS SELL_VAL,     CM.RCCD_SEGMENT AS RCCD_SEGMENT,     CM.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION,     0 AS '0'   FROM     RMS_CLIENT_CONVT_TO_DEL_COM CM 	WHERE RCCD_CLIENT_ID = \"%s\"   GROUP BY CM.RCCD_CLIENT_ID , CM.RCCD_SCRIP_CODE , CM.RCCD_EXCHANGE , CM.RCCD_PRODUCT_DESTINATION , CM.RCCD_SEGMENT) MBNP 			JOIN SEM_ACTIVE SM 			JOIN L1_WATCH_ACTIVE MW 		WHERE 			((MBNP.SECURITY_ID = SM.SM_SCRIP_CODE) 				AND (MBNP.EXCH_ID = SM.SM_EXCHANGE) 				AND (MBNP.EXCH_SEGMENT = SM.SM_SEGMENT) 				AND (MBNP.SECURITY_ID = MW.L1_SCRIP_CODE) 				AND (MBNP.EXCH_SEGMENT = MW.L1_SEGMENT) 				AND (MBNP.EXCH_ID = MW.L1_EXCHANGE)) 		GROUP BY MBNP.CLIENT_ID , MBNP.SECURITY_ID , SM.SM_INSTRUMENT_NAME , SM.SM_SYMBOL , SM.SM_UNDERLAYING_SCRIP_CODE , MBNP.EXCH_ID , SM.SM_EXPIRY_DATE , SM.SM_STRIKE_PRICE , SM.SM_OPTION_TYPE , SM.SM_SEGMENT , MBNP.PRODUCT , MW.L1_LTP , SM.SM_LOT_SIZE) AS POS_MTM) AS MTM WHERE   1 = 1 AND CLIENT_ID LIKE \"%s\"  %s %s GROUP BY SEGMENT , CLIENT_ID;",pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,pViewLimReq->sClientId,sWhere_Clause,sBrchClaus);

	printf("sClentLimtQry = %s \n",sClentLimtQry);

	if(mysql_query(DBQury,sClentLimtQry) != SUCCESS)
	{
		logSqlFatal("Error in sClentLimtQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);		

	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;	

	pLmtHdrResp.IntRespHeader.iSeqNo = 0;
	pLmtHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pLmtHdrResp.IntRespHeader.iErrorId = 0;
	pLmtHdrResp.IntRespHeader.iMsgCode = TC_INT_CLIENT_LIMIT_HEADER_RESP;
	pLmtHdrResp.IntRespHeader.iUserId = pViewLimReq->ReqHeader.iUserId;
	pLmtHdrResp.IntRespHeader.cSource = pViewLimReq->ReqHeader.cSource ;
	pLmtHdrResp.cMsgType = 'H';
	pLmtHdrResp.iNoofRec = iNoOfRec;
	//	iTempUserID = pLmtHdrResp.IntRespHeader.iUserId;

	logDebug2("pLmtHdrResp.IntRespHeader.iMsgLength = %d",pLmtHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pLmtHdrResp.IntRespHeader.iMsgCode = %d",pLmtHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pLmtHdrResp.IntRespHeader.iUserId = %llu",pLmtHdrResp.IntRespHeader.iUserId);
	logDebug2("pLmtHdrResp.IntRespHeader.cSource = %c",pLmtHdrResp.IntRespHeader.cSource);
	logDebug2("pLmtHdrResp.iNoofRec = %d",pLmtHdrResp.iNoofRec);

	logDebug2("pViewLimReq->ReqHeader.iUserId = %llu",pViewLimReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewLimReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pLmtHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt (i) = %d",i);
		memset(&pViewLmtResp,'\0',sizeof(struct VIEW_ADMIN_CLIENT_LIMIT_RESP));
		pViewLmtResp.IntRespHeader.iSeqNo = 0;
		pViewLmtResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_CLIENT_LIMIT_RESP);
		pViewLmtResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_CLIENT_LIMIT_RESP;
		pViewLmtResp.IntRespHeader.iErrorId = 0;
		pViewLmtResp.IntRespHeader.iUserId = pViewLimReq->ReqHeader.iUserId;
		//               	pViewLmtResp.IntRespHeader.iUserId = iTempUserID;
		logDebug2("pViewLmtResp.IntRespHeader.iUserId...... = %llu",pViewLmtResp.IntRespHeader.iUserId);
		pViewLmtResp.IntRespHeader.cSource = pViewLimReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pViewLmtResp.cMsgType = 'T';
		}
		else
		{
			pViewLmtResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			logDebug2("^^^^^^^^^^^ j = %d ^^^^^^^^^^^^^",j);

			if((Row = mysql_fetch_row(Res)))
			{
				logDebug2("pViewLimReq->ReqHeader.iUserId.... = %llu",pViewLimReq->ReqHeader.iUserId);
				pViewLmtResp.sSubViewClientlimit[j].fLimitSOD = atof(Row[0]);
				pViewLmtResp.sSubViewClientlimit[j].fAdhocLimit = atof(Row[1]);
				pViewLmtResp.sSubViewClientlimit[j].fReceivables = atof(Row[2]);
				pViewLmtResp.sSubViewClientlimit[j].fBankHoldings = atof(Row[3]);
				pViewLmtResp.sSubViewClientlimit[j].fCollaterals = atof(Row[4]);
				pViewLmtResp.sSubViewClientlimit[j].fRelaisedProfit = atof(Row[5]);
				pViewLmtResp.sSubViewClientlimit[j].fAmountUtilised = atof(Row[6]);
				pViewLmtResp.sSubViewClientlimit[j].fSumofAll = atof(Row[7]);
				pViewLmtResp.sSubViewClientlimit[j].fAvailableBal = atof(Row[8]);
				pViewLmtResp.sSubViewClientlimit[j].fClearBalance = atof(Row[9]);
				strncpy(pViewLmtResp.sSubViewClientlimit[j].sLimitType,Row[10],LIMIT_TYP_LEN);
				strncpy(pViewLmtResp.sSubViewClientlimit[j].sClientId,Row[11],CLIENT_ID_LEN);
				pViewLmtResp.sSubViewClientlimit[j].fReqPayOutAmt = atof(Row[12]);
				pViewLmtResp.sSubViewClientlimit[j].cSegment = Row[13][0];
				//pViewLmtResp.sSubViewClientlimit[j].fReqPayOutAmt = atof(Row[12]);
				pViewLmtResp.sSubViewClientlimit[j].fCFOptSellPrm= atof(Row[14]);
				pViewLmtResp.sSubViewClientlimit[j].fCFOptSellPrmComm= atof(Row[15]);
				strncpy(pViewLmtResp.sSubViewClientlimit[j].sClientName,Row[16],ENTITY_NAME_LEN);
				pViewLmtResp.sSubViewClientlimit[j].fGrossHoldVal = atof(Row[17]);
				pViewLmtResp.sSubViewClientlimit[j].fMtmValue= atof(Row[18]);

				logDebug2("pViewLmtResp.IntRespHeader.iUserId = %llu",pViewLmtResp.IntRespHeader.iUserId);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fLimitSOD = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fLimitSOD);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fAdhocLimit = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fAdhocLimit);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fReceivables = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fReceivables);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fBankHoldings = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fBankHoldings);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fCollaterals = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fCollaterals);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fRelaisedProfit= %lf",j,pViewLmtResp.sSubViewClientlimit[j].fRelaisedProfit);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fAmountUtilised= %lf",j,pViewLmtResp.sSubViewClientlimit[j].fAmountUtilised);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fSumofAll = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fSumofAll);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fAvailableBal = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fAvailableBal);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fClearBalance = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fClearBalance);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].sLimitType = %s",j,pViewLmtResp.sSubViewClientlimit[j].sLimitType);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].sClientId = %s",j,pViewLmtResp.sSubViewClientlimit[j].sClientId);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].cSegment = %c",j,pViewLmtResp.sSubViewClientlimit[j].cSegment);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fReqPayOutAmt = %lf",j,pViewLmtResp.sSubViewClientlimit[j].fReqPayOutAmt);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fCFOptSellPrm= %lf",j,pViewLmtResp.sSubViewClientlimit[j].fCFOptSellPrm);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fCFOptSellPrmComm= %lf",j,pViewLmtResp.sSubViewClientlimit[j].fCFOptSellPrmComm);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].sClientName= %s",j,pViewLmtResp.sSubViewClientlimit[j].sClientName);
				logDebug2("pViewLmtResp.cMsgType = %c",pViewLmtResp.cMsgType);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fGrossHoldVal= %lf",j,pViewLmtResp.sSubViewClientlimit[j].fGrossHoldVal);
				logDebug2("pViewLmtResp.sSubViewClientlimit[%d].fMtmValue= %lf",j,pViewLmtResp.sSubViewClientlimit[j].fMtmValue);
			}
		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewLmtResp,sizeof(struct VIEW_ADMIN_CLIENT_LIMIT_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}	
		iTempNoOfRec--;
		//		usleep(50000);	
	}
	logTimestamp("Exit : fViewClientLimit");
	return TRUE;
}

BOOL    fClientDpHolding(CHAR *RcvMsg)
{
        logTimestamp("Entry : fClientDpHolding ");
        struct  VIEW_ADMIN_DP_HOLDING_QUERY_REQ *pClientHoldReq;
        struct  VIEW_ADMIN_DP_HOLDING_RESP	pClientHoldingResp;
        struct  VIEW_COMMON_HDR_RESP            pClientHoldHdrResp;

        CHAR    sClentHoldQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sHoldQry[QUERY_SIZE];
        memset(sClentHoldQry,'\0',DOUBLE_MAX_QUERY_SIZE);

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

        pClientHoldReq = (struct  VIEW_ADMIN_DP_HOLDING_QUERY_REQ *)RcvMsg;

        logDebug2("pClientHoldReq->sClientId = :%s:",pClientHoldReq->sClientId);
        logDebug2("pClientHoldReq->sEntityId = :%s:",pClientHoldReq->sEntityId);


  	sprintf(sClentHoldQry,"SELECT  RECORD_TYPE,  LINE_NUMBER,  BRANCH_CODE, BEN_ACC_NUM,  BEN_CATEGORY,  ISIN,  (CASE BEN_ACC_TYPE  WHEN 01 THEN 'Beneficiary Freeze'    WHEN 11 THEN 'Beneficiary'   WHEN 12 THEN 'Pending Demat'   WHEN 13 THEN 'Pending Remat/Repurchase'   WHEN 14 THEN 'Pledge'   WHEN 16 THEN 'Pledge'   END) BEN_ACC_TYPE,  BEN_ACC_POSITION,  (CASE ISIN_STATUS WHEN 01 THEN 'Active'    WHEN 02 THEN 'Suspended'    WHEN 03 THEN 'Blocked due to ACA'    WHEN 04 THEN 'To be Closed'    WHEN 05 THEN 'Closed'   END) ISIN_STATUS,  (CASE ISIN_TYPE WHEN 01 THEN 'Equity'   WHEN 02 THEN 'Postal Savings Scheme'   WHEN 03 THEN 'Preferential Shares'   WHEN 04 THEN 'Bond'   WHEN 05 THEN 'Deep Discount Bond'   WHEN 06 THEN 'Floating Rate Bond'   WHEN 07 THEN 'Commercial Paper'   WHEN 08 THEN 'Step Discount Bond'   WHEN 09 THEN 'Regular Return Bond'   WHEN 10 THEN 'Certificate of Deposit'   WHEN 11 THEN 'Securitised Instruments'   WHEN 12 THEN 'Debenture'   WHEN 13 THEN 'Units'   WHEN 14 THEN 'Government Securities'   WHEN 15 THEN 'Warrants'   WHEN 16 THEN 'Commodity'   WHEN 17 THEN 'RBI Bonds'   WHEN 19 THEN 'Indian Depository Receipt'   WHEN 20 THEN 'Mutual Fund'   WHEN 21 THEN 'Alternative Investment Fund (AIF)'   WHEN 22 THEN 'Treasury Bills'   WHEN 24 THEN 'Municipal Bond'   WHEN 25 THEN 'Real Estate Investment Trusts (REIT)'   END) ISIN_TYPE,  BLOCK_LOCK_FLAG,  BLOCK_LOCK_CODE,  LOCK_IN_RELEASE_DATE,  HOLD_QUANTITY,  UNDER_PROCESS_QTY,  CLIENT_ID,  SM.SM_EXCH_SYMBOL   FROM  RMS_DP_ALL_HOLDING RDAH   LEFT JOIN  SECURITY_MASTER SM ON (RDAH.ISIN = SM.SM_ISIN_CODE)   WHERE  SM.SM_SEGMENT = 'E'   AND SM.SM_EXCH_STATUS = 'A'   AND SM.SM_STATUS = 'A'   AND SM.SM_EXCHANGE = (CASE   WHEN    SM.SM_EXCHANGE = 'NSE' AND SM.SM_EXCH_STATUS = 'A'   THEN    'NSE'   WHEN    SM.SM_EXCHANGE = 'NSE' AND SM.SM_EXCH_STATUS <> 'A'   THEN    'BSE'  END) AND CLIENT_ID = \"%s\"; ",pClientHoldReq->sClientId);
	
	
        logDebug2("sClentHoldQry = %s",sClentHoldQry);

        if(mysql_query(DBQury,sClentHoldQry) != SUCCESS)
        {
                logSqlFatal("Error in ClentHoldQry");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);

        iNoOfRec = mysql_num_rows(Res);

        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

        pClientHoldHdrResp.IntRespHeader.iSeqNo = 0;
        pClientHoldHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pClientHoldHdrResp.IntRespHeader.iErrorId = 0;
        pClientHoldHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_HDR_DP_HOLDING_RESP;
        pClientHoldHdrResp.IntRespHeader.iUserId = pClientHoldReq->ReqHeader.iUserId;
        pClientHoldHdrResp.IntRespHeader.cSource = pClientHoldReq->ReqHeader.cSource ;
        pClientHoldHdrResp.cMsgType = 'H';
        pClientHoldHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pClientHoldHdrResp.IntRespHeader.iMsgLength = %d",pClientHoldHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pClientHoldHdrResp.IntRespHeader.iMsgCode = %d",pClientHoldHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pClientHoldHdrResp.IntRespHeader.iUserId = %llu",pClientHoldHdrResp.IntRespHeader.iUserId);
        logDebug2("pClientHoldHdrResp.IntRespHeader.cSource = %c",pClientHoldHdrResp.IntRespHeader.cSource);
        logDebug2("pClientHoldHdrResp.iNoofRec = %d",pClientHoldHdrResp.iNoofRec);

        logDebug2("pClientHoldReq->ReqHeader.iUserId = %llu",pClientHoldReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pClientHoldReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pClientHoldHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
	}
	for(i=0;i<iNoOfPkt;i++)
        {
                logDebug2("No of Pkt (i) = %d",i);

                memset(&pClientHoldingResp ,'\0',sizeof(struct VIEW_ADMIN_DP_HOLDING_RESP));
                pClientHoldingResp.IntRespHeader.iSeqNo = 0;
                pClientHoldingResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_DP_HOLDING_RESP);
                logDebug2("...pClientHoldingResp.IntRespHeader.iMsgLength = %d",pClientHoldingResp.IntRespHeader.iMsgLength);
                pClientHoldingResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_DP_HOLDING_RESP;
                pClientHoldingResp.IntRespHeader.iErrorId = 0;
                pClientHoldingResp.IntRespHeader.iUserId = pClientHoldReq->ReqHeader.iUserId;
                pClientHoldingResp.IntRespHeader.cSource = pClientHoldReq->ReqHeader.cSource ;

                if(iTempNoOfRec <= 1)
                {
                        pClientHoldingResp.cMsgType = 'T';
                }
                else
                {
                        pClientHoldingResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        logDebug2("No of row in pkt (j) = %d",j);
                        if((Row = mysql_fetch_row(Res)))
                        {
				strncpy(pClientHoldingResp.subdpHolding[j].sRecordType,Row[0],RECORD_TYPE);
                                strncpy(pClientHoldingResp.subdpHolding[j].sLineNumber,Row[1],LINE_NUMBER);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBranchCode,Row[2],BRANCH_CODE_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sDPId,Row[3],DP_ID_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBenCategory,Row[4],BEN_CATEGORY);
                                strncpy(pClientHoldingResp.subdpHolding[j].sIsin,Row[5],DB_ISIN_CODE_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBenAccType,Row[6],BEN_ACC_TYP_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBenAccPosition,Row[7],BEN_ACC_POSITION_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sIsinStatus,Row[8],ISIN_STATUS_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sIsinType,Row[9],ISIN_TYPE_LEN);
                                pClientHoldingResp.subdpHolding[j].cBlock_Lock_Flag = Row[10][0];
                                strncpy(pClientHoldingResp.subdpHolding[j].sLockIn_Release_Date,Row[11],DATE_TIME_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBlock_Lock_code,Row[12],BLOCK_LOCK_CODE);
                                pClientHoldingResp.subdpHolding[j].iHoldQty = atoi(Row[13]);
                                pClientHoldingResp.subdpHolding[j].iUnderHoldQty = atoi(Row[14]);
                                strncpy(pClientHoldingResp.subdpHolding[j].sClientId,Row[15],CLIENT_ID_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sSymbol,Row[16],DB_SYMBOL_LEN);


                                logDebug2("-------------------Start Printing Record no = %d ------------------",j);
                                logDebug2("pClientHoldingResp.IntRespHeader.iMsgLength  = %d",pClientHoldingResp.IntRespHeader.iMsgLength);
                                logDebug2("pClientHoldingResp.IntRespHeader.iMsgCode    = %d",pClientHoldingResp.IntRespHeader.iMsgCode);
                                logDebug2("pClientHoldingResp.IntRespHeader.iUserId     = %llu",pClientHoldingResp.IntRespHeader.iUserId);
                                logDebug2("pClientHoldingResp.IntRespHeader.cSource     = %c",pClientHoldingResp.IntRespHeader.cSource);
                                logDebug2("pClientHoldingResp.cMsgType                  = %c",pClientHoldingResp.cMsgType);

                                logDebug2("pClientHoldingResp.subdpHolding[%d].sRecordType = %s",j,pClientHoldingResp.subdpHolding[j].sRecordType);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sExcgId     = %s",j,pClientHoldingResp.subdpHolding[j].sLineNumber);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBranchCode = %s",j,pClientHoldingResp.subdpHolding[j].sBranchCode);
                                logDebug2("pClientHolResp.subdpHolding[%d].sDPId = %s",j,pClientHoldingResp.subdpHolding[j].sDPId);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBenCategory = %s",j,pClientHoldingResp.subdpHolding[j].sBenCategory);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sIsin = %s",j,pClientHoldingResp.subdpHolding[j].sIsin);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBenAccType = %s",j,pClientHoldingResp.subdpHolding[j].sBenAccType);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBenAccPosition = %s",j,pClientHoldingResp.subdpHolding[j].sBenAccPosition);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sIsinStatus = %s",j,pClientHoldingResp.subdpHolding[j].sIsinStatus);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sIsinType = %s",j,pClientHoldingResp.subdpHolding[j].sIsinType);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sLockIn_Release_Date = %s",j,pClientHoldingResp.subdpHolding[j].sLockIn_Release_Date);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBlock_Lock_code = %s",j,pClientHoldingResp.subdpHolding[j].sBlock_Lock_code);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].iHoldQty = %d",j,pClientHoldingResp.subdpHolding[j].iHoldQty);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].iUnderHoldQty = %d",j,pClientHoldingResp.subdpHolding[j].iUnderHoldQty);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sClientId = %s",j,pClientHoldingResp.subdpHolding[j].sClientId);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].cBlock_Lock_Flag = %c",j,pClientHoldingResp.subdpHolding[j].cBlock_Lock_Flag);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sSymbol = %s",j,pClientHoldingResp.subdpHolding[j].sSymbol);

                        }
		}

                if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pClientHoldingResp,sizeof(struct VIEW_ADMIN_DP_HOLDING_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
			return FALSE;
                }
                iTempNoOfRec--;
	}
        
	logTimestamp("Exit : fClientHolding");
        return TRUE ;
}

BOOL	fNetPosition(CHAR *RcvMsg)
{
	logTimestamp("Entry : fNetPosition");

	struct	VIEW_NET_POSITION_QRY 		*pViewNetPosReq;
	struct	VIEW_ADMIN_NET_POSITION_RESP	pNetPosResp;
	struct	VIEW_COMMON_HDR_RESP		pNetPosHdrResp;

	pViewNetPosReq = (struct VIEW_NET_POSITION_QRY *)RcvMsg;
	CHAR	sNetPosQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR	sNetQry[QUERY_SIZE];
	CHAR    sWhere_Clause[QUERY_SIZE];	

	memset(sNetPosQry,'\0',DOUBLE_MAX_QUERY_SIZE);	
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;	

	logDebug2("pViewNetPosReq->ReqHeader.sExcgId = %s",pViewNetPosReq->ReqHeader.sExcgId);
	logDebug2("pViewNetPosReq->ReqHeader.cSegment = %c",pViewNetPosReq->ReqHeader.cSegment);
	logDebug2("pViewNetPosReq->sPosition = %s",pViewNetPosReq->sPosition);
	logDebug2("pViewNetPosReq->sInstrument = %s",pViewNetPosReq->sInstrument);
	logDebug2("pViewNetPosReq->sSymbol = %s",pViewNetPosReq->sSymbol);
	logDebug2("pViewNetPosReq->cProduct = %c",pViewNetPosReq->cProduct);
	logDebug2("pViewNetPosReq->sClientID = %s",pViewNetPosReq->sClientID);
	logDebug2("pViewNetPosReq->sEntityId = %s",pViewNetPosReq->sEntityId);
	logDebug2("pViewNetPosReq->cNetQty = %c",pViewNetPosReq->cNetQty);	

	BOOL    iChkBrcnh = FALSE;
	CHAR    sBrchId[BRANCH_ID_LEN];
	memset(sBrchId,'\0',BRANCH_ID_LEN);

	CHAR    sBrchClaus[QUERY_SIZE];
	memset(sBrchClaus,'\0',QUERY_SIZE);
	iChkBrcnh = fChckAdminContrlr(pViewNetPosReq->sEntityId,&sBrchId);

	if(iChkBrcnh == TRUE)
	{
		sprintf(sBrchClaus ," AND CLIENT_ID in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
	}
	else
	{
		sprintf(sBrchClaus ," ");
	}

	logDebug2(" sBrchClaus :%s:",sBrchClaus);

	if(strcmp(pViewNetPosReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND EXCH_ID = \"%s\"",pViewNetPosReq->ReqHeader.sExcgId);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pViewNetPosReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND SEGMNT = \'%c\'",pViewNetPosReq->ReqHeader.cSegment);
		logDebug2("NetQry2 = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pViewNetPosReq->sPosition,SELECT_ALL))
	{
		if(strcmp(pViewNetPosReq->sPosition,DAY_POSITION))
		{
			memset(sNetQry,'\0',QUERY_SIZE);
			sprintf(sNetQry," AND REF_ID >= 0");
			logDebug2("sNetQry = %s",sNetQry);
			strcat(sWhere_Clause,sNetQry);
			logDebug2("sWhere_Clause3.. = %s",sWhere_Clause);
		}
		if(strcmp(pViewNetPosReq->sPosition,CARRY_POSITION))
		{
			memset(sNetQry,'\0',QUERY_SIZE);
			sprintf(sNetQry," AND REF_ID < 0");
			logDebug2("sNetQry = %s",sNetQry);
			strcat(sWhere_Clause,sNetQry);
			logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
		}

	}
	if(strcmp(pViewNetPosReq->sInstrument,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND INSTRUMENT = \"%s\"",pViewNetPosReq->sInstrument);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pViewNetPosReq->sSymbol,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pViewNetPosReq->sSymbol);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(pViewNetPosReq->cProduct != SEL_ALL)
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND PROD_ID = \"%c\"",pViewNetPosReq->cProduct);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);
	}
	if(strcmp(pViewNetPosReq->sClientID,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND CLIENT_ID LIKE \"%s\"",pViewNetPosReq->sClientID);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
	}
	if(pViewNetPosReq->cNetQty != SEL_ALL)
	{
		logDebug2("&&&&&&");
		memset(sNetQry,'\0',QUERY_SIZE);
		if( pViewNetPosReq->cNetQty != NET_QTY) 
		{	logDebug2("%c",pViewNetPosReq->cNetQty);
			sprintf(sNetQry," AND NET_QTY <> %d",FALSE);
		}
		else	
		{
			sprintf(sNetQry," AND NET_QTY = %d",FALSE);
		}
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause8 = %s",sWhere_Clause);	
	}
	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	sprintf(sNetPosQry,"SELECT  CLIENT_ID,  SECURITY_ID,  EXCH_ID,  MKT_TYPE,  TOT_BUY_QTY,  TOT_BUY_QTY_CF,  TOT_BUY_QTY_DAY,  TOT_BUY_VAL,  TOT_BUY_VAL_CF,  TOT_BUY_VAL_DAY,  BUY_AVG,  TOT_SELL_QTY,  TOT_SELL_QTY_CF,  TOT_SELL_QTY_DAY,  TOT_SELL_VAL,  TOT_SELL_VAL_CF,  TOT_SELL_VAL_DAY,  SELL_AVG,  NET_QTY,  CF_NET_QTY,  DAY_NET_QTY,  NET_VAL,  CF_NET_VAL,  DAY_NET_VAL,  NET_AVG,  CF_NET_AVG,  DAY_NET_AVG,  GROSS_QTY,  GROSS_VAL,  SEGMNT,  PROD_ID,  REALISED_PROFIT,  REF_ID,  CROSS_CUR_FLAG,  RBI_REFERENCE_RATE FROM  (SELECT  `MBNP`.`CLIENT_ID` AS `CLIENT_ID`,   `MBNP`.`SECURITY_ID` AS `SECURITY_ID`,   `MBNP`.`EXCH_ID` AS `EXCH_ID`,   `MBNP`.`SYMBOL` AS `SYMBOL`,   `MBNP`.`INSTRUMENT` AS `INSTRUMENT`,   `MBNP`.`EXPIRY_DATE` AS `EXPIRY_DATE`,   'NL' AS `MKT_TYPE`,   SUM(`MBNP`.`BUY_QTY`) AS `TOT_BUY_QTY`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN - 1 THEN `MBNP`.`BUY_QTY`    ELSE 0   END) AS `TOT_BUY_QTY_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN 0 THEN `MBNP`.`BUY_QTY`    ELSE 0   END) AS `TOT_BUY_QTY_DAY`,   SUM(CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000    WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER    ELSE MBNP.BUY_VAL   END) AS TOT_BUY_VAL,   SUM(CASE MBNP.INT_REF_ID    WHEN     - 1    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER     ELSE MBNP.BUY_VAL     END)    ELSE 0   END) AS `TOT_BUY_VAL_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN     0    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER     ELSE MBNP.BUY_VAL     END)    ELSE 0   END) AS `TOT_BUY_VAL_DAY`,   ROUND((CASE    WHEN     (`MBNP`.`SEGMENT_CODE` = 'C')    THEN     ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))     END), 4)    ELSE ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))    END), 2)   END), 4) AS `BUY_AVG`,   SUM(`MBNP`.`SELL_QTY`) AS `TOT_SELL_QTY`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN - 1 THEN `MBNP`.`SELL_QTY`    ELSE 0   END) AS `TOT_SELL_QTY_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN 0 THEN `MBNP`.`SELL_QTY`    ELSE 0   END) AS `TOT_SELL_QTY_DAY`,   ROUND(SUM(CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000    WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER    ELSE (MBNP.SELL_VAL)   END), 2) AS TOT_SELL_VAL,   ROUND(SUM(CASE MBNP.INT_REF_ID    WHEN     - 1    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER     ELSE MBNP.SELL_VAL     END)    ELSE 0   END), 2) AS `TOT_SELL_VAL_CF`,   ROUND(SUM(CASE `MBNP`.`INT_REF_ID`    WHEN     0    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER     ELSE (MBNP.SELL_VAL)     END)    ELSE 0   END), 2) AS `TOT_SELL_VAL_DAY`,   ROUND((CASE    WHEN     (`MBNP`.`SEGMENT_CODE` = 'C')    THEN     ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))     END), 4)    ELSE ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))    END), 2)   END), 4) AS `SELL_AVG`,   (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)) AS `NET_QTY`,   (CASE MBNP.INT_REF_ID                                 WHEN -1 THEN SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)    ELSE 0 END) AS CF_NET_QTY,                       (CASE MBNP.INT_REF_ID                           WHEN 0 THEN SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)    ELSE 0 END) AS DAY_NET_QTY,   ROUND((CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)    WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)    ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))   END), 2) AS NET_VAL,   (CASE MBNP.INT_REF_ID   WHEN -1   THEN ROUND((CASE                                          WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)                                           WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)                                           ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))                                           END), 2)                        ELSE 0 END) AS CF_NET_VAL,                      (CASE MBNP.INT_REF_ID   WHEN -1   THEN ROUND((CASE                                              WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)                                           WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)                                           ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))                                           END), 2)                        ELSE 0 END) AS DAY_NET_VAL,   (CASE    WHEN     (`MBNP`.`SEGMENT_CODE` = 'C')    THEN     ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))     WHEN 0 THEN 0     ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))     END), 4)    ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))     WHEN 0 THEN 0     ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))    END), 2)   END) AS `NET_AVG`,   (CASE MBNP.INT_REF_ID   WHEN -1   THEN (CASE                               WHEN (`MBNP`.`SEGMENT_CODE` = 'C')                                     THEN                                            ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))                                                     WHEN 0 THEN 0                                                   ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))                                                      END), 4)                                       ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))                                                               WHEN 0 THEN 0                                                           ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))                                                              END), 2)                                        END)   ELSE 0 END) AS CF_NET_AVG,     (CASE MBNP.INT_REF_ID   WHEN 0   THEN (CASE                                WHEN (`MBNP`.`SEGMENT_CODE` = 'C')                                     THEN                                            ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))                                                     WHEN 0 THEN 0                                                   ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))                                                      END), 4)                                       ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))                                                               WHEN 0 THEN 0                                                           ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))                                                              END), 2)                                        END)   ELSE 0 END) AS DAY_NET_AVG,   (SUM(`MBNP`.`BUY_QTY`) + SUM(`MBNP`.`SELL_QTY`)) AS `GROSS_QTY`,   ROUND((CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * 1000)    WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * MBNP.COMM_MULTIPLIER)    ELSE (SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL))   END), 2) AS GROSS_VAL,   MBNP.SEGMENT_CODE AS SEGMNT,   MBNP.PRODUCT AS PROD_ID,   (CASE    WHEN     (MBNP.SEGMENT_CODE = 'C')    THEN     (CASE     WHEN      `MBNP`.`CROSS_CUR_FLAG` = 'Y'     THEN      (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)       WHEN 0 THEN 0       ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))      END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)       WHEN 0 THEN 0       ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))      END), 4))), 4) * 1000 * `MBNP`.`RBI_REFERENCE_RATE`)     ELSE (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)      WHEN 0 THEN 0      ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))     END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)      WHEN 0 THEN 0      ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))     END), 4))), 4) * 1000)     END)    WHEN     (`MBNP`.`SEGMENT_CODE` = 'M')    THEN     (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))     END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))     END), 2))), 2) * `MBNP`.`COMM_MULTIPLIER`)    ELSE ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))    END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))    END), 2))), 2)   END) AS `REALISED_PROFIT`,   `MBNP`.`INT_REF_ID` AS `REF_ID`,   `MBNP`.`CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   `MBNP`.`RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`  FROM   (SELECT  `DT`.`DRV_CLIENT_ID` AS `CLIENT_ID`,   `DT`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,   `DT`.`DRV_EXCH_ID` AS `EXCH_ID`,   `DT`.`DRV_SEGMENT` AS `SEGMENT_CODE`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN `DT`.`DRV_TRD_TRADE_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN ((`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`))    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN `DT`.`DRV_TRD_TRADE_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)    ELSE 0   END)) AS `SELL_VAL`,   `DT`.`DRV_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,   `DT`.`DRV_SEGMENT` AS `EXCH_SEGMENT`,   `DT`.`DRV_PRODUCT_ID` AS `PRODUCT`,   `DT`.`DRV_CF_FLAG` AS `INT_REF_ID`,   SUBSTR(`DT`.`DRV_SYMBOL`, 1, 6) AS `SYMBOL`,   `DT`.`DRV_INSTRUMENT_NAME` AS `INSTRUMENT`,   `DT`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,   `DT`.`DRV_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `DT`.`DRV_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `DRV_ORDERS` `DT`  WHERE   ((`DT`.`DRV_TRD_STATUS` = 'C')   AND (`DT`.`DRV_MSG_CODE` = '2222'))  GROUP BY `DT`.`DRV_CLIENT_ID` , `DT`.`DRV_SCRIP_CODE` , `DT`.`DRV_EXCH_ID` , `DT`.`DRV_PRODUCT_ID` , `DT`.`DRV_SEGMENT` , `DT`.`DRV_CF_FLAG` UNION ALL SELECT  `T`.`EQ_CLIENT_ID` AS `EQ_CLIENT_ID`,   `T`.`EQ_SCRIP_CODE` AS `EQ_SCRIP_CODE`,   `T`.`EQ_EXCH_ID` AS `EQ_EXCH_ID`,   `T`.`EQ_SEGMENT` AS `SEGMENT_CODE`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN `T`.`EQ_LAST_TRADE_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN `T`.`EQ_LAST_TRADE_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)    ELSE 0   END)) AS `SELL_VAL`,   `T`.`EQ_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,   'E' AS `E`,   `T`.`EQ_PRODUCT_ID` AS `EQ_PRODUCT_ID`,   0 AS `INT_REF_ID`,   `T`.`EQ_SYMBOL` AS `SYMBOL`,   `T`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,   'NA' AS `EXPIRY`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `EQ_ORDERS` `T`  WHERE   ((`T`.`EQ_TRD_STATUS` = 'C')   AND (`T`.`EQ_MSG_CODE` = 2222))  GROUP BY `T`.`EQ_CLIENT_ID` , `T`.`EQ_SCRIP_CODE` , `T`.`EQ_EXCH_ID` , `T`.`EQ_PRODUCT_ID` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `BUY_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `BUY_VAL`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `SELL_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,   'NA' AS `EXPIRY`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,   'NA' AS `EXPIRY`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `BUY_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `BUY_VAL`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `SELL_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `MT`.`COMM_CLIENT_ID` AS `CLIENT_ID`,   `MT`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,   `MT`.`COMM_EXCH_ID` AS `EXCH_ID`,   `MT`.`COMM_SEGMENT` AS `SEGMENT_CODE`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN `MT`.`COMM_TRD_TRADE_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN `MT`.`COMM_TRD_TRADE_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)    ELSE 0   END)) AS `SELL_VAL`,   `MT`.`COMM_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,   `MT`.`COMM_SEGMENT` AS `EXCH_SEGMENT`,   `MT`.`COMM_PRODUCT_ID` AS `PRODUCT`,   `MT`.`COMM_CF_FLAG` AS `INT_REF_ID`,   SUBSTR(`MT`.`COMM_SYMBOL`, 1, 6) AS `SYMBOL`,   `MT`.`COMM_INSTRUMENT_NAME` AS `INSTRUMENT`,   `MT`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   `MT`.`COMM_MULTIPLIER` AS `COMM_MULTIPLIER`  FROM   `COMM_ORDERS` `MT`  WHERE   ((`MT`.`COMM_TRD_STATUS` = 'C')   AND (`MT`.`COMM_MSG_CODE` = '2222'))  GROUP BY `MT`.`COMM_CLIENT_ID` , `MT`.`COMM_SCRIP_CODE` , `MT`.`COMM_EXCH_ID` , `MT`.`COMM_PRODUCT_ID` , `MT`.`COMM_SEGMENT` , `MT`.`COMM_CF_FLAG` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `BUY_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `BUY_VAL`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `SELL_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   `RCCD_COMM_MULTIPLIER` AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   `RCCD_COMM_MULTIPLIER` AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT`) AS MBNP  GROUP BY `MBNP`.`CLIENT_ID` , `MBNP`.`SECURITY_ID` , `MBNP`.`EXCH_ID` , `MBNP`.`SEGMENT_CODE` , `MBNP`.`PRODUCT`) AS NP WHERE  1 = 1    AND NOT (NP.GROSS_QTY = 0   AND NP.REALISED_PROFIT = 0) %s ",sBrchClaus,sWhere_Clause);

	printf("sNetPosQry = %s ",sNetPosQry);

	if(mysql_query(DBQury,sNetPosQry) != SUCCESS)
	{
		logSqlFatal("Error in sNetPosQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;	

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pNetPosHdrResp.IntRespHeader.iSeqNo = 0;
	pNetPosHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pNetPosHdrResp.IntRespHeader.iErrorId = 0;
	pNetPosHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_NET_POS_HDR_RESP;
	pNetPosHdrResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
	pNetPosHdrResp.IntRespHeader.cSource = pViewNetPosReq->ReqHeader.cSource ;
	pNetPosHdrResp.cMsgType = 'H';
	pNetPosHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pNetPosHdrResp.IntRespHeader.iMsgLength = %d",pNetPosHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pNetPosHdrResp.IntRespHeader.iMsgCode = %d",pNetPosHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pNetPosHdrResp.IntRespHeader.iUserId = %llu",pNetPosHdrResp.IntRespHeader.iUserId);
	logDebug2("pNetPosHdrResp.IntRespHeader.cSource = %c",pNetPosHdrResp.IntRespHeader.cSource);
	logDebug2("pNetPosHdrResp.iNoofRec = %d",pNetPosHdrResp.iNoofRec);	

	logDebug2("pViewNetPosReq->ReqHeader.iUserId = %llu",pViewNetPosReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewNetPosReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pNetPosHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{	
		logDebug2("No of Pkt (i) = %d",i);
		memset(&pNetPosResp,'\0',sizeof(struct VIEW_ADMIN_NET_POSITION_RESP));
		pNetPosResp.IntRespHeader.iSeqNo = 0;
		pNetPosResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_NET_POSITION_RESP);
		pNetPosResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_NET_POS_RESP;
		pNetPosResp.IntRespHeader.iErrorId = 0;
		pNetPosResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
		pNetPosResp.IntRespHeader.cSource = pViewNetPosReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pNetPosResp.cMsgType = 'T';
		}
		else
		{
			pNetPosResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			logDebug2("****** j = %d ******",j);

			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(pNetPosResp.subnetpos[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pNetPosResp.subnetpos[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				strncpy(pNetPosResp.subnetpos[j].sExchId,Row[2],EXCHANGE_LEN);
				strncpy(pNetPosResp.subnetpos[j].cMktType,Row[3],EXCHANGE_LEN);
				pNetPosResp.subnetpos[j].iBuyQty = atoi(Row[4]);
				pNetPosResp.subnetpos[j].iBuyQtyCF = atoi(Row[5]);
				pNetPosResp.subnetpos[j].iBuyQtyDay = atoi(Row[6]);
				pNetPosResp.subnetpos[j].fBuyVal = atof(Row[7]);
				pNetPosResp.subnetpos[j].fBuyValCF = atof(Row[8]);
				pNetPosResp.subnetpos[j].fBuyValDay = atof(Row[9]);
				pNetPosResp.subnetpos[j].fBuyAvg = atof(Row[10]);
				pNetPosResp.subnetpos[j].iSellQty = atoi(Row[11]);
				pNetPosResp.subnetpos[j].iSellQtyCF = atoi(Row[12]);
				pNetPosResp.subnetpos[j].iSellQtyDay = atoi(Row[13]);
				pNetPosResp.subnetpos[j].fSellVal = atof(Row[14]);
				pNetPosResp.subnetpos[j].fSellValCF = atof(Row[15]);
				pNetPosResp.subnetpos[j].fSellValDay = atof(Row[16]); 				
				pNetPosResp.subnetpos[j].fSellAvg = atof(Row[17]);
				pNetPosResp.subnetpos[j].iNetQty = atoi(Row[18]);
				pNetPosResp.subnetpos[j].fCf_net_qty = atof(Row[19]);
				pNetPosResp.subnetpos[j].fDay_net_qty = atof(Row[20]);
				pNetPosResp.subnetpos[j].fNetVal = atof(Row[21]);
				pNetPosResp.subnetpos[j].fCf_net_val = atof(Row[22]);
				pNetPosResp.subnetpos[j].fDay_net_val = atof(Row[23]);
				pNetPosResp.subnetpos[j].fNetAvg = atof(Row[24]);
				pNetPosResp.subnetpos[j].fCf_net_avg = atof(Row[25]);
				pNetPosResp.subnetpos[j].fDay_net_avg = atof(Row[26]);
				pNetPosResp.subnetpos[j].fGrossQty = atof(Row[27]);
				pNetPosResp.subnetpos[j].fGrossVal = atof(Row[28]);
				pNetPosResp.subnetpos[j].cSegment = Row[29][0];
				pNetPosResp.subnetpos[j].cProductId = Row[30][0];
				pNetPosResp.subnetpos[j].fRelaisedProfit = atof(Row[31]);
				pNetPosResp.subnetpos[j].iRef_ID = atoi(Row[32]);
				pNetPosResp.subnetpos[j].cCrossCur_Flag = Row[33][0];
				pNetPosResp.subnetpos[j].fRBIRefRate = atof(Row[34]);

				logDebug2("pNetPosResp.subnetpos[%d].sClientId = %s",j,pNetPosResp.subnetpos[j].sClientId);	
				logDebug2("pNetPosResp.subnetpos[%d].sSecurityID = %s",j,pNetPosResp.subnetpos[j].sSecurityID);
				logDebug2("pNetPosResp.subnetpos[%d].sExchId = %s",j,pNetPosResp.subnetpos[j].sExchId);	
				logDebug2("pNetPosResp.subnetpos[%d].cMktType = %s",j,pNetPosResp.subnetpos[j].cMktType);
				logDebug2("pNetPosResp.subnetpos[%d].iBuyQty = %d",j,pNetPosResp.subnetpos[j].iBuyQty);
				logDebug2("pNetPosResp.subnetpos[%d].iBuyQtyCF = %d",j,pNetPosResp.subnetpos[j].iBuyQtyCF);
				logDebug2("pNetPosResp.subnetpos[%d].iBuyQtyDay = %d",j,pNetPosResp.subnetpos[j].iBuyQtyDay);	
				logDebug2("pNetPosResp.subnetpos[%d].fBuyVal= %lf",j,pNetPosResp.subnetpos[j].fBuyVal);	
				logDebug2("pNetPosResp.subnetpos[%d].fBuyValCF = %lf",j,pNetPosResp.subnetpos[j].fBuyValCF);	
				logDebug2("pNetPosResp.subnetpos[%d].fBuyValDay = %lf",j,pNetPosResp.subnetpos[j].fBuyValDay);	
				logDebug2("pNetPosResp.subnetpos[%d].fBuyAvg = %lf",j,pNetPosResp.subnetpos[j].fBuyAvg);	
				logDebug2("pNetPosResp.subnetpos[%d].iSellQty = %d",j,pNetPosResp.subnetpos[j].iSellQty);	
				logDebug2("pNetPosResp.subnetpos[%d].iSellQtyCF = %d",j,pNetPosResp.subnetpos[j].iSellQtyCF);	
				logDebug2("pNetPosResp.subnetpos[%d].iSellQtyDay = %d",j,pNetPosResp.subnetpos[j].iSellQtyDay);	
				logDebug2("pNetPosResp.subnetpos[%d].fSellVal = %lf",j,pNetPosResp.subnetpos[j].fSellVal);	
				logDebug2("pNetPosResp.subnetpos[%d].fSellValCF = %lf",j,pNetPosResp.subnetpos[j].fSellValCF);	
				logDebug2("pNetPosResp.subnetpos[%d].fSellValDay = %lf",j,pNetPosResp.subnetpos[j].fSellValDay);	
				logDebug2("pNetPosResp.subnetpos[%d].fSellAvg = %lf",j,pNetPosResp.subnetpos[j].fSellAvg);	
				logDebug2("pNetPosResp.subnetpos[%d].iNetQty = %d",j,pNetPosResp.subnetpos[j].iNetQty);	
				logDebug2("pNetPosResp.subnetpos[%d].fNetVal = %lf",j,pNetPosResp.subnetpos[j].fNetVal);	
				logDebug2("pNetPosResp.subnetpos[%d].fNetAvg = %lf",j,pNetPosResp.subnetpos[j].fNetAvg);	
				logDebug2("pNetPosResp.subnetpos[%d].fGrossQty = %lf",j,pNetPosResp.subnetpos[j].fGrossQty);	
				logDebug2("pNetPosResp.subnetpos[%d].fGrossVal = %lf",j,pNetPosResp.subnetpos[j].fGrossVal);	
				logDebug2("pNetPosResp.subnetpos[%d].cSegment = %c",j,pNetPosResp.subnetpos[j].cSegment);	
				logDebug2("pNetPosResp.subnetpos[%d].cProductId = %c",j,pNetPosResp.subnetpos[j].cProductId);	
				logDebug2("pNetPosResp.subnetpos[%d].fRelaisedProfit = %lf",j,pNetPosResp.subnetpos[j].fRelaisedProfit);	
				logDebug2("pNetPosResp.subnetpos[%d].iRef_ID = %d",j,pNetPosResp.subnetpos[j].iRef_ID);	
				logDebug2("pNetPosResp.subnetpos[%d].cCrossCur_Flag = %c",j,pNetPosResp.subnetpos[j].cCrossCur_Flag);	
				logDebug2("pNetPosResp.subnetpos[%d].fRBIRefRate = %f",j,pNetPosResp.subnetpos[j].fRBIRefRate);
				logDebug2("pNetPosResp.subnetpos[%d].fDay_net_qty = %f",j,pNetPosResp.subnetpos[j].fDay_net_qty);
				logDebug2("pNetPosResp.subnetpos[%d].fCf_net_qty = %f",j,pNetPosResp.subnetpos[j].fCf_net_qty);
				logDebug2("pNetPosResp.subnetpos[%d].fDay_net_val = %lf",j,pNetPosResp.subnetpos[j].fDay_net_val);
				logDebug2("pNetPosResp.subnetpos[%d].fCf_net_val= %lf",j,pNetPosResp.subnetpos[j].fCf_net_val);
				logDebug2("pNetPosResp.subnetpos[%d].fDay_net_avg = %f",j,pNetPosResp.subnetpos[j].fDay_net_avg);
				logDebug2("pNetPosResp.subnetpos[%d].fCf_net_avg = %f",j,pNetPosResp.subnetpos[j].fCf_net_avg);	
				logDebug2("pNetPosResp.cMsgType = %c",pNetPosResp.cMsgType);
			}
		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pNetPosResp,sizeof(struct VIEW_ADMIN_NET_POSITION_RESP) ,iRelayID ) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}
		iTempNoOfRec--;
		//	usleep(5000);
	}

	logTimestamp("Exit : fNetPosition");
	return TRUE;
}


BOOL	fTradBook(CHAR	*RcvMsg)
{
	logTimestamp("Entry : fTradBook");

	struct	VIEW_TRADE_BOOK_REQ	*pViewTrdBookReq;
	struct	VIEW_TRADE_BOOK_RESP	pViewTrdBookResp;
	struct	VIEW_COMMON_HDR_RESP	pViewTrdBookHdrResp;

	pViewTrdBookReq	= (struct  VIEW_TRADE_BOOK_REQ *)RcvMsg;
	//	CHAR    *sTrdQry = malloc(sizeof(CHAR) * QUERY_SIZE);	
	//	CHAR    *sTrdBookQry = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	CHAR    sTrdBookQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sTrdQry[QUERY_SIZE];	
	CHAR	sWhere_Clause[QUERY_SIZE];

	memset(sTrdBookQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	LONG32		iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;	
	LONG32		sEdRow[QUERY_SIZE];	

	logDebug2("pViewTrdBookReq->ReqHeader.sExcgId = :%s:",pViewTrdBookReq->ReqHeader.sExcgId);
	logDebug2("pViewTrdBookReq->ReqHeader.cSegment = :%c:",pViewTrdBookReq->ReqHeader.cSegment);
	logDebug2("pViewTrdBookReq->sSymbol = :%s:",pViewTrdBookReq->sSymbol);
	logDebug2("pViewTrdBookReq->cProduct = :%c:",pViewTrdBookReq->cProduct);
	logDebug2("pViewTrdBookReq->sClientId = :%s:",pViewTrdBookReq->sClientId);
	logDebug2("pViewTrdBookReq->sEntityId = :%s:",pViewTrdBookReq->sEntityId);
	logDebug2("pViewTrdBookReq->iEndRow = :%d:",pViewTrdBookReq->iEndRow);

	BOOL    iChkBrcnh = FALSE;
	CHAR    sBrchId[BRANCH_ID_LEN];
	memset(sBrchId,'\0',BRANCH_ID_LEN);

	CHAR    sBrchClaus[QUERY_SIZE];
	memset(sBrchClaus,'\0',QUERY_SIZE);
	iChkBrcnh = fChckAdminContrlr(pViewTrdBookReq->sEntityId,&sBrchId);

	if(iChkBrcnh == TRUE)
	{
		sprintf(sBrchClaus ," AND CLIENT_ID in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
	}
	else
	{
		sprintf(sBrchClaus ," ");
	}

	logDebug2(" sBrchClaus :%s:",sBrchClaus);

	if(strcmp(pViewTrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sTrdQry,'\0',QUERY_SIZE);
		sprintf(sTrdQry,"AND EXCH = \"%s\"",pViewTrdBookReq->ReqHeader.sExcgId);
		logDebug2("sTrdQry1 = %s",sTrdQry);
		strcat(sWhere_Clause,sTrdQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pViewTrdBookReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sTrdQry,'\0',QUERY_SIZE);
		sprintf(sTrdQry,"AND SEGMENT = \'%c\'",pViewTrdBookReq->ReqHeader.cSegment);
		logDebug2("sTrdQry2 = %s",sTrdQry);
		strcat(sWhere_Clause,sTrdQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pViewTrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sTrdQry,'\0',QUERY_SIZE);
		sprintf(sTrdQry, "AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pViewTrdBookReq->sSymbol);
		logDebug2("sTrdQry3 = %s",sTrdQry);
		strcat(sWhere_Clause,sTrdQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(pViewTrdBookReq->cProduct != SEL_ALL)
	{
		logDebug2("************************");
		memset(sTrdQry,'\0',QUERY_SIZE);
		if(pViewTrdBookReq->cProduct == PROD_INTRADAY )
			sprintf(sTrdQry,"AND PRODUCT = \"%s\"",FE_PROD_INTRADAY);
		if(pViewTrdBookReq->cProduct == PROD_MARGIN )
			sprintf(sTrdQry,"AND PRODUCT = \"%s\"",FE_PROD_MARGIN);
		if(pViewTrdBookReq->cProduct == PROD_CNC )
			sprintf(sTrdQry,"AND PRODUCT = \"%s\"",FE_PROD_CNC);
		if(pViewTrdBookReq->cProduct == PROD_COVER )
			sprintf(sTrdQry,"AND PRODUCT = \"%s\"",FE_PROD_COVER);
		if(pViewTrdBookReq->cProduct == PROD_BRACKET )
			sprintf(sTrdQry,"AND PRODUCT = \"%s\"",FE_PROD_BRACKET);

		logDebug2("sTrdQry4 = %s",sTrdQry);
		strcat(sWhere_Clause,sTrdQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pViewTrdBookReq->sClientId,SELECT_ALL))
	{
		memset(sTrdQry,'\0',QUERY_SIZE);
		sprintf(sTrdQry,"AND CLIENT_ID LIKE \"%s\"",pViewTrdBookReq->sClientId);
		logDebug2("sTrdQry5 = %s",sTrdQry);
		strcat(sWhere_Clause,sTrdQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(strcmp(pViewTrdBookReq->sPlacedBy,SELECT_ALL))
	{
		memset(sTrdQry,'\0',QUERY_SIZE);
		sprintf(sTrdQry,"AND PLACEDBY LIKE \"%s\"",pViewTrdBookReq->sPlacedBy);
		logDebug2("sTrdQry6 = %s",sTrdQry);
		strcat(sWhere_Clause,sTrdQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);
	}

	/*        if(strcmp(pViewTrdBookReq->sEntityId,SELECT_ALL))
		  {
		  memset(sTrdQry,'\0',QUERY_SIZE);
		  sprintf(sTrdQry,"AND PLACEDBY = \"%s\"",pViewTrdBookReq->sEntityId);
		  logDebug2("sTrdQry6 = %s",sTrdQry);
		  strcat(sWhere_Clause,sTrdQry);
		  logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
		  }
	 */

	logDebug2("Final trad book Where_Clause = %s",sWhere_Clause);

	if(!pViewTrdBookReq->iEndRow <= 0)
	{
		sprintf(sEdRow,"LIMIT %d ;",pViewTrdBookReq->iEndRow);
		logDebug2("sEdRow = %s",sEdRow);
	}
	else
	{
		sprintf(sEdRow,";");
		logDebug2("sEdRow1 = %s",sEdRow);
	}

	sprintf(sTrdBookQry,"	SELECT ORDER_NUMBER,SEM_SMST_SECURITY_ID,BUY_SELL,ORDER_TYPE,EXCH_ORDER_NUMBER,TRADE_NUMBER,PRODUCT,QUANTITY,PRICE,TRADE_VALUE,\
			ORDER_DATE_TIME,EXCH,SEGMENT,CLIENT_ID,JDATE,PLACEDBY,IFNULL(STRATEGY_ID,0),SYMBOL,\
			LEGVALUE,IFNULL(PAN_NO,'NA'),IFNULL(PARTICIPANT_TYPE,'B'),IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'),IFNULL(GTC_FLG,'N'),\
			IFNULL(ENCASH_FLG,'N'),MKT_TYPE FROM(SELECT `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`, @rn:=@rn + 1 AS r,\
				`A`.`EQ_SCRIP_CODE` AS `SEM_SMST_SECURITY_ID`, DATE_FORMAT(`A`.`EQ_TRD_TRADE_TIME`, '%%d-%%m-%%Y %%T') AS `ORDER_DATE_TIME`,\
				`A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`, `A`.`EQ_EXCH_ORDER_NO` AS `EXCH_ORDER_NUMBER`, `A`.`EQ_TRD_EXCH_TRADE_NO` AS `TRADE_NUMBER`,\
				`A`.`EQ_EXCH_ID` AS `EXCH`, (CASE `A`.`EQ_BUY_SELL_IND` WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS `BUY_SELL`, 'E' AS `SEGMENT`,\
				(CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`, \
				`A`.`EQ_SYMBOL` AS `SYMBOL`, \
				(CASE `A`.`EQ_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' \
				 WHEN 'I' THEN 'INTRADAY' WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE `A`.`EQ_PRODUCT_ID` END) AS `PRODUCT`,\
				`A`.`EQ_LAST_TRADE_QTY` AS `QUANTITY`, \
				IFNULL(`A`.`EQ_TRD_TRADE_PRICE`, 0) AS `PRICE`, ROUND((`A`.`EQ_TRD_TRADE_PRICE` * `A`.`EQ_LAST_TRADE_QTY`), 4) AS `TRADE_VALUE`, \
				`A`.`EQ_SCRIP_CODE` AS `SECURITY_ID`, `A`.`EQ_PRODUCT_ID` AS `TRD_PRODUCT`,\
				JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,\
				`A`.`EQ_ENTITY_ID` AS `PLACEDBY`,`A`.`EQ_STRATEGY_ID` AS `STRATEGY_ID`,`A`.`EQ_LEG_NO` AS `LEGVALUE`,`A`.`EQ_PAN_NO` AS `PAN_NO`,\
				`A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,\
				`A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,\
				`A`.`EQ_SETTLOR` AS `SETTLOR`,`A`.`EQ_GTC_FLG` AS `GTC_FLG`,`A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,`A`.`EQ_MKT_TYPE` AS `MKT_TYPE` \
				FROM `EQ_ORDERS` `A` \
				CROSS JOIN (SELECT @rn:=0) r WHERE ((`A`.`EQ_MSG_CODE` = '2222') AND (`A`.`EQ_TRD_STATUS` = 'C')\
					) UNION ALL SELECT `B`.`DRV_CLIENT_ID` AS `CLIENT_ID`, @rn:=@rn + 1 AS r, \
				`B`.`DRV_SCRIP_CODE` AS `SEM_SMST_SECURITY_ID`, DATE_FORMAT(`B`.`DRV_TRD_TRADE_TIME`, '%%d-%%m-%%Y %%T') AS `ORDER_DATE_TIME`, \
				`B`.`DRV_ORDER_NO` AS `ORDER_NUMBER`, `B`.`DRV_EXCH_ORDER_NO` AS `EXCH_ORDER_NUMBER`, `B`.`DRV_TRD_EXCH_TRADE_NO` AS `TRADE_NUMBER`, \
				`B`.`DRV_EXCH_ID` AS `EXCH`, (CASE `B`.`DRV_BUY_SELL_IND` WHEN 'B' THEN 'BUY' WHEN 'S' THEN 'SELL' END) AS `BUY/SELL`, \
				`B`.`DRV_SEGMENT` AS `SEGMENT`, \
				(CASE `B`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`,\
				`B`.`DRV_SYMBOL` AS `SYMBOL`, \
				(CASE `B`.`DRV_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' \
				 WHEN 'I' THEN 'INTRADAY' WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE `B`.`DRV_PRODUCT_ID` END) AS `PRODUCT`,\
				`B`.`DRV_TRD_TRADE_QTY` AS `QTY`, IFNULL(`B`.`DRV_TRD_TRADE_PRICE`, 0) AS `PRICE`, (CASE WHEN (`B`.`DRV_SEGMENT` = 'C') \
						THEN ROUND(((`B`.`DRV_TRD_TRADE_PRICE` * `B`.`DRV_TRD_TRADE_QTY`) * 1000), 4) \
						ELSE ROUND((`B`.`DRV_TRD_TRADE_PRICE` * `B`.`DRV_TRD_TRADE_QTY`), 2) END) AS `TRADE_VALUE`, `B`.`DRV_SCRIP_CODE` AS `SECURITY_ID`, \
				`B`.`DRV_PRODUCT_ID` AS `TRD_PRODUCT`,JULIDATE(`B`.`DRV_INTERNAL_ENTRY_DATE`) AS `JDATE`,\
				`B`.`DRV_ENTITY_ID` AS `PLACEDBY`,`B`.`DRV_STRATEGY_ID` AS `STRATEGY_ID`,`B`.`DRV_LEG_NO` AS `LEGVALUE`,`B`.`DRV_PAN_NO` AS `PAN_NO`,\
				`B`.`DRV_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`B`.`DRV_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`, \
				`B`.`DRV_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,\
				`B`.`DRV_SETTLOR` AS `SETTLOR`,`B`.`DRV_GTC_FLG` AS `GTC_FLG`,`B`.`DRV_ENCASH_FLG` AS `ENCASH_FLGi`,`B`.`DRV_MKT_TYPE`  AS `MKT_TYPE` \
				FROM `DRV_ORDERS` `B` CROSS JOIN (SELECT @rn:=0) r WHERE ((`B`.`DRV_MSG_CODE` = '2222') AND (`B`.`DRV_TRD_STATUS` = 'C') AND (`B`.`DRV_CF_FLAG` <> -1) )\
				UNION ALL SELECT `C`.`COMM_CLIENT_ID` AS `CLIENT_ID`, @rn:=@rn + 1 AS r, `C`.`COMM_SCRIP_CODE` AS `SEM_SMST_SECURITY_ID`, \
				DATE_FORMAT(`C`.`COMM_TRD_TRADE_TIME`, '%%d-%%m-%%Y %%T') AS `ORDER_DATE_TIME`, `C`.`COMM_ORDER_NO` AS `ORDER_NUMBER`, \
				`C`.`COMM_EXCH_ORDER_NO` AS `EXCH_ORDER_NUMBER`, `C`.`COMM_TRD_EXCH_TRADE_NO` AS `TRADE_NUMBER`, `C`.`COMM_EXCH_ID` AS `EXCH`, \
				(CASE `C`.`COMM_BUY_SELL_IND` WHEN 'B' THEN 'BUY' WHEN 'S' THEN 'SELL' END) AS `BUY/SELL`, 'M' AS `SEGMENT`, \
				(CASE `C`.`COMM_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`,\
				`C`.`COMM_SYMBOL` AS `SYMBOL`, \
				(CASE `C`.`COMM_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' \
				 WHEN 'I' THEN 'INTRADAY' WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE `C`.`COMM_PRODUCT_ID` END) AS `PRODUCT`,\
				`C`.`COMM_TRD_TRADE_QTY` AS `QTY`,IFNULL(`C`.`COMM_TRD_TRADE_PRICE`, 0) AS `PRICE`, \
				ROUND(((`C`.`COMM_TRD_TRADE_PRICE` * `C`.`COMM_TRD_TRADE_QTY`) * `C`.`COMM_MULTIPLIER`), 2) AS `TRADE_VALUE`,\
				`C`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,`C`.`COMM_PRODUCT_ID` AS `TRD_PRODUCT`,\
				JULIDATE(`C`.`COMM_INTERNAL_ENTRY_DATE`) AS `JDATE`,\
				`C`.`COMM_ENTITY_ID` AS `PLACEDBY`, `C`.`COMM_STRATEGY_ID` AS `STRATEGY_ID`,`C`.`COMM_LEG_NO` AS `LEGVALUE`,`C`.`COMM_PAN_NO` AS `PAN_NO`,\
				`C`.`COMM_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`C`.`COM_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,\
				`C`.`COMM_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,`C`.`COMM_SETTLOR` AS `SETTLOR`,`C`.`COMM_GTC_FLG` AS `GTC_FLG`,\
				`C`.`COMM_ENCASH_FLG` AS `ENCASH_FLG`,`C`.`COMM_MKT_TYPE` AS `MKT_TYPE` \
				FROM `COMM_ORDERS` `C` \
				CROSS JOIN (SELECT @rn:=0) r WHERE ((`C`.`COMM_MSG_CODE` = '2222')\
						AND (`C`.`COMM_TRD_STATUS` = 'C') AND (`C`.`COMM_CF_FLAG` <> -1))) tradebook \
						WHERE 1=1  %s %s order by ORDER_DATE_TIME desc %s ",sBrchClaus,sWhere_Clause,sEdRow);

	printf("sTrdBookQry  = %s",sTrdBookQry);		

	if(mysql_query(DBQury,sTrdBookQry) != SUCCESS)
	{
		logSqlFatal("Error in sTrdBookQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;	

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pViewTrdBookHdrResp.IntRespHeader.iSeqNo = 0;
	pViewTrdBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pViewTrdBookHdrResp.IntRespHeader.iErrorId = 0;
	pViewTrdBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_TRADE_BOOK_HEADER_RESP;
	pViewTrdBookHdrResp.IntRespHeader.iUserId = pViewTrdBookReq->ReqHeader.iUserId;
	pViewTrdBookHdrResp.IntRespHeader.cSource = pViewTrdBookReq->ReqHeader.cSource ;
	pViewTrdBookHdrResp.cMsgType = 'H';
	pViewTrdBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pViewTrdBookHdrResp.IntRespHeader.iMsgLength = %d",pViewTrdBookHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pViewTrdBookHdrResp.IntRespHeader.iMsgCode = %d",pViewTrdBookHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pViewTrdBookHdrResp.IntRespHeader.iUserId = %llu",pViewTrdBookHdrResp.IntRespHeader.iUserId);
	logDebug2("pViewTrdBookHdrResp.IntRespHeader.cSource = %c",pViewTrdBookHdrResp.IntRespHeader.cSource);
	logDebug2("pViewTrdBookHdrResp.iNoofRec = %d",pViewTrdBookHdrResp.iNoofRec);

	logDebug2("pViewTrdBookReq->ReqHeader.iUserId = %llu",pViewTrdBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewTrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pViewTrdBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2(">>>>>>>> No of Pkt(i) <<<<<<<< = %d",i);
		memset(&pViewTrdBookResp,'\0',sizeof(struct VIEW_TRADE_BOOK_RESP));

		pViewTrdBookResp.IntRespHeader.iSeqNo = 0;
		pViewTrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
		pViewTrdBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_TRAD_BOOK_RESP;
		pViewTrdBookResp.IntRespHeader.iErrorId = 0;
		pViewTrdBookResp.IntRespHeader.iUserId = pViewTrdBookReq->ReqHeader.iUserId;
		pViewTrdBookResp.IntRespHeader.cSource = pViewTrdBookReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pViewTrdBookResp.cMsgType = 'T';
		}
		else
		{
			pViewTrdBookResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pViewTrdBookResp.subTradeBook[j].fOrderNo = atof(Row[0]);
				strncpy(pViewTrdBookResp.subTradeBook[j].sSecurityID,Row[1] ,SECURITY_ID_LEN);
				memset(pViewTrdBookResp.subTradeBook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pViewTrdBookResp.subTradeBook[j].sBuySellInd,Row[2],BUY_SELL_LEN);
				strncpy(pViewTrdBookResp.subTradeBook[j].sOrderType,Row[3] ,ORD_TYP_LEN);
				strncpy(pViewTrdBookResp.subTradeBook[j].sExchOrderNumber,Row[4],BSE_EXCH_ORDER_NO_LEN);
				pViewTrdBookResp.subTradeBook[j].fTradeNo = atof(Row[5]);
				strncpy(pViewTrdBookResp.subTradeBook[j].sProduct,Row[6],PRODUCT_LEN);
				pViewTrdBookResp.subTradeBook[j].fTradeQty = atof(Row[7]);
				pViewTrdBookResp.subTradeBook[j].fTradePrice = atof(Row[8]);
				pViewTrdBookResp.subTradeBook[j].fTradeVal = atof(Row[9]);
				strncpy(pViewTrdBookResp.subTradeBook[j].sDatetime,Row[10],DATE_LENGTH);
				strncpy(pViewTrdBookResp.subTradeBook[j].sExcgId,Row[11],EXCHANGE_LEN);
				pViewTrdBookResp.subTradeBook[j].cSegment = Row[12][0];
				strncpy(pViewTrdBookResp.subTradeBook[j].sClientId,Row[13],CLIENT_ID_LEN);
				pViewTrdBookResp.subTradeBook[j].iDateTime = atol(Row[14]);
				strncpy(pViewTrdBookResp.subTradeBook[j].sEntityId,Row[15],ENTITY_ID_LEN);
				pViewTrdBookResp.subTradeBook[j].iStrategyId = atoi (Row[16]);
				pViewTrdBookResp.subTradeBook[j].iLegValue = atoi(Row[17]);
				if(strlen(Row[19]) == 0)
				{
					strncpy(pViewTrdBookResp.subTradeBook[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pViewTrdBookResp.subTradeBook[j].sPanID,Row[19],INT_PAN_LEN);
				}

				pViewTrdBookResp.subTradeBook[j].cParticipantType = Row[20][0];
				pViewTrdBookResp.subTradeBook[j].cMarkProFlag = Row[21][0];				
				pViewTrdBookResp.subTradeBook[j].fMarkProVal = atof(Row[22]);
				if(strlen(Row[23]) == 0)
				{
					strncpy(pViewTrdBookResp.subTradeBook[j].sSettlor,"NA",SETTLOR_LEN);
				}
				else
				{
					strncpy(pViewTrdBookResp.subTradeBook[j].sSettlor,Row[23],SETTLOR_LEN);
				}

				pViewTrdBookResp.subTradeBook[j].cGTCFlag =  Row[24][0];
				pViewTrdBookResp.subTradeBook[j].cEncashFlag =  Row[25][0];
				logDebug2("--------------- TRADE BOOK ----------------");

				logDebug2("pViewTrdBookResp.subTradeBook[%d].fOrderNo = %lf",j,pViewTrdBookResp.subTradeBook[j].fOrderNo);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sSecurityID = %d",j,pViewTrdBookResp.subTradeBook[j].sSecurityID);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sBuySellInd = %s",j,pViewTrdBookResp.subTradeBook[j].sBuySellInd);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sOrderType = %s",j,pViewTrdBookResp.subTradeBook[j].sOrderType);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sExchOrderNumber = %d",j,pViewTrdBookResp.subTradeBook[j].sExchOrderNumber);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].fTradeNo = %lf",j,pViewTrdBookResp.subTradeBook[j].fTradeNo);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sProduct = %s",j,pViewTrdBookResp.subTradeBook[j].sProduct);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].fTradeQty = %d",j,pViewTrdBookResp.subTradeBook[j].fTradeQty);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].fTradePrice = %lf",j,pViewTrdBookResp.subTradeBook[j].fTradePrice);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].fTradeVal = %lf",j,pViewTrdBookResp.subTradeBook[j].fTradeVal);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sDatetime = %s",j,pViewTrdBookResp.subTradeBook[j].sDatetime);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sExcgId = %s",j,pViewTrdBookResp.subTradeBook[j].sExcgId);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].cSegment = %c",j,pViewTrdBookResp.subTradeBook[j].cSegment);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sClientId = %s",j,pViewTrdBookResp.subTradeBook[j].sClientId);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].iDateTime = %ld",j,pViewTrdBookResp.subTradeBook[j].iDateTime);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sEntityId = %s",j,pViewTrdBookResp.subTradeBook[j].sEntityId);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].iStrategyId = %d",j,pViewTrdBookResp.subTradeBook[j].iStrategyId);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].iLegValue = %d",j,pViewTrdBookResp.subTradeBook[j].iLegValue);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sPanID = %s",j,pViewTrdBookResp.subTradeBook[j].sPanID);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].cParticipantType = %c",j,pViewTrdBookResp.subTradeBook[j].cParticipantType);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].cMarkProFlag = %c",j,pViewTrdBookResp.subTradeBook[j].cMarkProFlag);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].fMarkProVal = %lf",j,pViewTrdBookResp.subTradeBook[j].fMarkProVal);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].sSettlor = %s",j,pViewTrdBookResp.subTradeBook[j].sSettlor);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].cGTCFlag = %c",j,pViewTrdBookResp.subTradeBook[j].cGTCFlag);
				logDebug2("pViewTrdBookResp.subTradeBook[%d].cEncashFlag = %c",j,pViewTrdBookResp.subTradeBook[j].cEncashFlag);
				logDebug2("pViewTrdBookResp.cMsgType = %c",pViewTrdBookResp.cMsgType);

			}
		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewTrdBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}

		iTempNoOfRec--;
		//	usleep(5000);
	}

	logTimestamp("Exit : fTradBook");
	return TRUE;

}


BOOL	fOrderBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fOrderBook");

	struct VIEW_ADMIN_ORDER_BOOK_REQ	*pOrdBookReq;
	struct VIEW_ORDER_BOOK_RESP		pOrdBookResp;
	struct VIEW_COMMON_HDR_RESP		pOrdBookHedResp;

	CHAR	sOrdBkQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSubOrdBKQry[QUERY_SIZE];
	pOrdBookReq = (struct VIEW_ADMIN_ORDER_BOOK_REQ *)RcvMsg;

	CHAR		sWhere_Clause[QUERY_SIZE];

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;
	CHAR		sEdRow[QUERY_SIZE];	

	memset(sOrdBkQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sEdRow,'\0',QUERY_SIZE);
	//memset(sExch,'\0',QUERY_SIZE);
	logDebug2("pOrdBookReq->ReqHeader.sExcgId = :%s:",pOrdBookReq->ReqHeader.sExcgId);
	logDebug2("pOrdBookReq->ReqHeader.cSegment = :%c:",pOrdBookReq->ReqHeader.cSegment);
	logDebug2("pOrdBookReq->ReqHeader.iUserId = :%llu:",pOrdBookReq->ReqHeader.iUserId);
	logDebug2("pOrdBookReq->sInstrument = :%s:",pOrdBookReq->sInstrument);
	logDebug2("pOrdBookReq->sSymbol = :%s:",pOrdBookReq->sSymbol);
	logDebug2("pOrdBookReq->sStatus = :%s:",pOrdBookReq->sStatus);
	logDebug2("pOrdBookReq->sExpiry = :%s:",pOrdBookReq->sExpiry);
	logDebug2("pOrdBookReq->sOptions = :%s:",pOrdBookReq->sOptions);
	logDebug2("pOrdBookReq->cProduct = :%c:",pOrdBookReq->cProduct);
	logDebug2("pOrdBookReq->sClientId = :%s:",pOrdBookReq->sClientId);
	logDebug2("pOrdBookReq->sEntityId = :%s:",pOrdBookReq->sEntityId);
	logDebug2("pOrdBookReq->sSource = :%s:",pOrdBookReq->sSource);
	logDebug2("pOrdBookReq->iEndRow = :%d:",pOrdBookReq->iEndRow);
	BOOL	iChkBrcnh = FALSE;
	CHAR	sBrchId[BRANCH_ID_LEN];
	memset(sBrchId,'\0',BRANCH_ID_LEN);

	CHAR	sBrchClaus[QUERY_SIZE];
	memset(sBrchClaus,'\0',QUERY_SIZE);
	iChkBrcnh = fChckAdminContrlr(pOrdBookReq->sEntityId,&sBrchId);	

	if(iChkBrcnh == TRUE)
	{
		sprintf(sBrchClaus ," AND CLIENT_ID in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
	}
	else
	{
		sprintf(sBrchClaus ," ");
	}	

	logDebug2(" sBrchClaus :%s:",sBrchClaus);	

	logDebug2("iMsgCode ;%d:",((struct INT_COMMON_REQUEST_HDR *)RcvMsg)->iMsgCode );
	if(((struct INT_COMMON_REQUEST_HDR *)RcvMsg)->iMsgCode == TC_INT_ADMIN_BO_ORDER_BOOK_REQ)
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_BRACKET);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{

		sprintf(sSubOrdBKQry," AND EXCH = \"%s\"",pOrdBookReq->ReqHeader.sExcgId);
		logDebug2("sSubOrdBKQry1 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);	
	}
	if(pOrdBookReq->ReqHeader.cSegment != SEL_ALL)
	{
		//		if(pOrdBookReq->ReqHeader.cSegment == EQUITY_SEGMENT || pOrdBookReq->ReqHeader.cSegment == DERIVATIVE_SEGMENT || pOrdBookReq->ReqHeader.cSegment == CURRENCY_SEGMENT || pOrdBookReq->ReqHeader.cSegment == COMMODITY_SEGMENT )
		//		{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND SEGMENT = \'%c\'",pOrdBookReq->ReqHeader.cSegment);
		logDebug2("sSubOrdBKQry2 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
		//		}
	}
	//	fTrim(pOrdBookReq->sInstrument,strlen(pOrdBookReq->sInstrument));
	if(strcmp(pOrdBookReq->sInstrument,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND INSTRUMENT = \"%s\"",pOrdBookReq->sInstrument);
		logDebug2("sSubOrdBKQry3 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);	
	}
	//	fTrim(pOrdBookReq->sSymbol,strlen(pOrdBookReq->sSymbol));
	if(strcmp(pOrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pOrdBookReq->sSymbol);
		logDebug2("sSubOrdBKQry4 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStatus,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		if(!strcmp(pOrdBookReq->sStatus,ORD_STATUS))
		{
			sprintf(sSubOrdBKQry," AND STATUS IN(\"%s\",\"%s\")",ORD_PEND,ORD_MODIFY);
		}
		else
		{
			sprintf(sSubOrdBKQry," AND STATUS = \"%s\"",pOrdBookReq->sStatus);
		}
		logDebug2("sSubOrdBKQry5 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sExpiry,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sExpiry = %s",pOrdBookReq->sExpiry);
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND DATE (EXPIRY_DATE) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sExpiry);
		logDebug2("sSubOrdBKQry6 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sOptions,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND OPTION_TYPE = \"%s\"",pOrdBookReq->sOptions);
		logDebug2("sSubOrdBKQry7 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
	}	
	if(pOrdBookReq->cProduct != SEL_ALL)
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		logDebug2("@@@@@@@@@@@@@@@");

		if(pOrdBookReq->cProduct == PROD_INTRADAY )
			sprintf(sSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_INTRADAY);
		if(pOrdBookReq->cProduct == PROD_MARGIN )
			sprintf(sSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_MARGIN);
		if(pOrdBookReq->cProduct == PROD_CNC )
			sprintf(sSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_CNC);
		if(pOrdBookReq->cProduct == PROD_COVER )
			sprintf(sSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_COVER);
		//		if(pOrdBookReq->cProduct == PROD_BRACKET )
		//                        sprintf(sSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_BRACKET);

		logDebug2("sSubOrdBKQry8 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause8 = %s",sWhere_Clause);

	}
	else
	{
		if(((struct INT_COMMON_REQUEST_HDR *)RcvMsg)->iMsgCode != TC_INT_ADMIN_BO_ORDER_BOOK_REQ)
		{
			sprintf(sSubOrdBKQry," AND PRODUCT <> \"%s\"",FE_PROD_BRACKET);
			strcat(sWhere_Clause,sSubOrdBKQry);
			logDebug2("Bracket Order Not Shown sSubOrdBKQry:%s:",sSubOrdBKQry);
		}
	}
	if(strcmp(pOrdBookReq->sClientId,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND CLIENT_ID LIKE \"%s\"",pOrdBookReq->sClientId);
		logDebug2("sSubOrdBKQry9 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause9 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sPlacedBy,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND PLACEDBY LIKE \"%s\"",pOrdBookReq->sPlacedBy);
		logDebug2("sSubOrdBKQry10 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause10 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSource,SELECT_ALL))
	{
		memset(sSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSubOrdBKQry," AND SOURCE_FLG = \"%s\"",pOrdBookReq->sSource);
		logDebug2("sSubOrdBKQry11 = %s",sSubOrdBKQry);
		strcat(sWhere_Clause,sSubOrdBKQry);
		logDebug2("sWhere_Clause11 = %s",sWhere_Clause);
	}
	/*
	   logDebug2("11");
	   if(strcmp(pOrdBookReq->sEntityId,SELECT_ALL))
	   {
	   memset(sExch,'\0',QUERY_SIZE);
	   sprintf(sExch,"AND PLACEDBY = \"%s\"",pOrdBookReq->sEntityId);
	   logDebug2("sExch11 = %s",sExch);
	   strcat(sWhere_Clause,sExch);
	   logDebug2("sWhere_Clause11 = %s",sWhere_Clause);
	   }
	 */	
	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	//if(!(pOrdBookReq->iEndRow <= 0))
	if(pOrdBookReq->iEndRow != 0)
	{
		sprintf(sEdRow,"LIMIT %d ;",pOrdBookReq->iEndRow);
		logDebug2("sEdRow = %s",sEdRow);
	}
	else
	{
		strncpy(sEdRow,";",QUERY_SIZE);
		//sprintf(sEdRow,";");
		logDebug2("sEdRow1 = %s",sEdRow);
	}

	logDebug2("&&&&&&&&&&&&&&&&");	
	sprintf(sOrdBkQry,"SELECT  ORDER_NUMBER,SERIALNO,SEM_SECURITY_ID,ORDER_TYPE,QUANTITY,REMAINING_QUANTITY,DISCLOSE_QTY,DQQTYREM,\
			PRICE,TRG_PRICE,TRADEDQTY,PRODUCT,ORDER_VALIDITY,EXCHORDERNO,ORDER_DATE_TIME,\
			EXCH,BUY_SELL,SEGMENT,TRANSCODE,CLIENT_ID,JDATE,IFNULL(STRATEGY_ID,0),PLACEDBY,REASON_DESCRIPTION,\
			PRO_CLIENT,TRADE_PRICE,GOOD_TILL_DATE,LEG_NO,IFNULL(EXPIRY_DATE,0),IFNULL(SOURCE_FLG,'NA'),IFNULL(ALGOORDERNO,0),IFNULL(PAN_NO,'NA'),IFNULL(PARTICIPANT_TYPE,'B'),\
			IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'), \
			IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),MKT_TYPE FROM (SELECT `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,\
				DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,`A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,\
				`A`.`EQ_EXCH_ID` AS `EXCH`,(CASE `A`.`EQ_BUY_SELL_IND` WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS `BUY_SELL`,\
				'E' AS `SEGMENT`,`A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`, `A`.`EQ_SYMBOL` AS `SYMBOL`,`A`.`EQ_LEG_NO` AS `LEG_NO`,\
				(CASE `A`.`EQ_PRODUCT_ID` WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' \
				 WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF'\
				 ELSE `A`.`EQ_PRODUCT_ID` END) AS `PRODUCT`,\
				(CASE WHEN ((`A`.`EQ_MSG_CODE` = '2073') AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`)) THEN 'Part-Traded' \
				 WHEN ((`A`.`EQ_MSG_CODE` = '2074') AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`)) THEN 'Part-Traded' \
				 WHEN ((`A`.`EQ_MSG_CODE` = '2212') AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`)) THEN 'Part-Traded' \
				 WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending' WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit' \
				 WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit' WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit' \
				 WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected' \
				 WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen' WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified' \
				 WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled' WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded' \
				 WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired' WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending' \
				 WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified' WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled' \ 
				 WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered' WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected' \
				 WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected' \
				 WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected' WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected' \
				 WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected' END) AS `STATUS`,\
				`A`.`EQ_TOTAL_QTY` AS `QUANTITY`, `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,\
				(CASE `A`.`EQ_SEGMENT` WHEN 'C' THEN REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE` \
										     WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0) END), 4), ',', '') \
				 ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
							 ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0) END), 2), ',', '') END) AS `PRICE`,\
				CASE `A`.`EQ_SEGMENT` WHEN 'C' THEN ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE` \
								WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) \
								ELSE 0 END), 0), 2) ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE` \
									WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0) \
									ELSE 0 END), 0), 2) END AS `TRG_PRICE`,\
								(CASE `A`.`EQ_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' \
								 WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`,\
								CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,\
								`A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`, `A`.`EQ_SERIAL_NO` AS `SERIALNO`,\
								`A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,`A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,\
								(CASE `A`.`EQ_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \
								 WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS `ORDER_VALIDITY`,\
								ifnull(`A`.`EQ_LOT_SIZE`,0) AS `SEM_NSE_REGULAR_LOT`, 0 AS `TAKE_PROFIT_TRAIL_GAP`,\
								`A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,`A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,\
								`A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,ifnull(NULLIF(`A`.`EQ_REASON_DESCRIPTION`,''),'NULL') AS `REASON_DESCRIPTION`,\
								`A`.`EQ_PRO_CLIENT` as `PRO_CLIENT`,`A`.`EQ_TRD_TRADE_PRICE` AS `TRADE_PRICE`,\
								ifnull(`A`.`EQ_GOOD_TILL_DATE`,NOW()) AS `GOOD_TILL_DATE`,`A`.`EQ_ENTITY_ID` AS `PLACEDBY`,\
								`A`.`EQ_STRATEGY_ID` AS `STRATEGY_ID`,JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,\
								`A`.`EQ_MSG_CODE` AS `TRANSCODE`,`A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`,`A`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,\
								(CASE `A`.`EQ_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' WHEN 'W' THEN 'WEB' WHEN 'A' THEN 'ADMIN'\
								 WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' WHEN 'H' THEN 'HELPDESK' \
								 WHEN 'E' THEN 'EXCHANGE' WHEN 'I' THEN 'ITS' WHEN 'B' THEN 'SYSTEM' END) AS `SOURCE_FLG` ,`A`.`EQ_ALGO_ORDER_NO` AS `ALGOORDERNO`,\
								`A`.`EQ_PAN_NO` AS `PAN_NO`,`A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`, \
								`A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,`A`.`EQ_SETTLOR` AS `SETTLOR`,`A`.`EQ_GTC_FLG` AS `GTC_FLG`,\
								`A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,`A`.`EQ_MKT_TYPE` AS `MKT_TYPE` \
								FROM `EQ_ORDERS` `A`\
								JOIN (SELECT @rn:=0) r WHERE `A`.`EQ_SERIAL_NO` = (SELECT MAX(`C`.`EQ_SERIAL_NO`) FROM `EQ_ORDERS` `C` \
										WHERE (`C`.`EQ_ORDER_NO` = `A`.`EQ_ORDER_NO`) AND (`A`.`EQ_CF_FLAG` <> -(1)) \
										AND (`A`.`EQ_LEG_NO` = `C`.`EQ_LEG_NO`) AND (`A`.`EQ_ORD_STATUS` <> 'B')) UNION ALL SELECT \
								`DO`.`DRV_CLIENT_ID` AS `CLIENT_ID`, DATE_FORMAT(`DO`.`DRV_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,\
								`DO`.`DRV_ORDER_NO` AS `ORDER NUMBER`,`DO`.`DRV_EXCH_ID` AS `EXCH`,\
								(CASE `DO`.`DRV_BUY_SELL_IND` WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS `BUY/SELL`,\
								`DO`.`DRV_SEGMENT` AS `SEGMENT`, `DO`.`DRV_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`,\
								`DO`.`DRV_SYMBOL` AS `SYMBOL`,`DO`.`DRV_LEG_NO` AS `LEG_NO`,\
								(CASE `DO`.`DRV_PRODUCT_ID` WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' \
								 WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF'\
								 ELSE `DO`.`DRV_PRODUCT_ID` END) AS `PRODUCT`,\
								(CASE WHEN ((`DO`.`DRV_MSG_CODE` = '2073') AND (`DO`.`DRV_REM_QTY` <> `DO`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' \
								 WHEN ((`DO`.`DRV_MSG_CODE` = '2074') AND (`DO`.`DRV_REM_QTY` > `DO`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' \
								 WHEN ((`DO`.`DRV_MSG_CODE` = '2212') AND (`DO`.`DRV_REM_QTY` <> `DO`.`DRV_TOTAL_QTY`)) THEN 'Part-Traded' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '2073') THEN 'Pending' WHEN (`DO`.`DRV_MSG_CODE` = '2000') THEN 'Transit' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '2040') THEN 'Transit' WHEN (`DO`.`DRV_MSG_CODE` = '2070') THEN 'Transit' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '2231') THEN 'Rejected' WHEN (`DO`.`DRV_MSG_CODE` = '2042') THEN 'Rejected' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '2170') THEN 'Frozen' WHEN (`DO`.`DRV_MSG_CODE` = '2074') THEN 'Modified' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '2075') THEN 'Cancelled' WHEN (`DO`.`DRV_MSG_CODE` = '2222') THEN 'Traded' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '9002') THEN 'Expired' WHEN (`DO`.`DRV_MSG_CODE` = '5112') THEN 'O-Pending' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '5113') THEN 'O-Modified' WHEN (`DO`.`DRV_MSG_CODE` = '5114') THEN 'O-Cancelled' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '2212') THEN 'Triggered' WHEN (`DO`.`DRV_MSG_CODE` = '1111') THEN 'Rejected' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '1113') THEN 'Rejected' WHEN (`DO`.`DRV_MSG_CODE` = '1115') THEN 'Rejected' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '4444') THEN 'Rejected' WHEN (`DO`.`DRV_MSG_CODE` = '4445') THEN 'Rejected' \
								 WHEN (`DO`.`DRV_MSG_CODE` = '4446') THEN 'Rejected' END) AS `STATUS`,\
								`DO`.`DRV_TOTAL_QTY` AS `QUANTITY`,`DO`.`DRV_REM_QTY` AS `REM QTY`,\
								CASE `DO`.`DRV_SEGMENT` WHEN 'C' THEN REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE` \
												WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0) END), 4), ',', '') \
								ELSE REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
												ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0) END), 2), ',', '') END AS `PRICE`, \
								CASE `DO`.`DRV_SEGMENT` WHEN 'C' THEN ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE` \
												WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) \
												ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE` \
													WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0) \
													ELSE 0 END), 0), 2) END AS TRG_PRICE,\
												(CASE `DO`.`DRV_ORDER_TYPE` WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS `ORDER_TYPE`,\
												CONCAT(`DO`.`DRV_REM_QTY`, '/', `DO`.`DRV_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,\
												`DO`.`DRV_DISC_QTY` AS `DISCLOSE_QTY`,`DO`.`DRV_SERIAL_NO` AS `SERIALNO`,\
												`DO`.`DRV_TOTAL_TRADED_QTY` AS `TRADEDQTY`,`DO`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,\
												(CASE `DO`.`DRV_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \
												 WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS `ORDER_VALIDITY`,\
												`DO`.`DRV_LOT_SIZE` AS `SM_LOT_SIZE`, 0 AS `TAKE_PROFIT_TRAIL_GAP`,\
												`DO`.`DRV_OMS_ALGO_ORD_NO` AS `ADV_GROUP_REF_NO`,`DO`.`DRV_DISC_REM_QTY` AS `DQQTYREM`,\
												`DO`.`DRV_EXCH_ORDER_NO` AS `EXCHORDERNO`,ifnull(NULLIF(`DO`.`DRV_REASON_DESCRIPTION`,''),'NULL') AS `REASON_DESCRIPTION`,\
												`DO`.`DRV_PRO_CLIENT` AS `PRO_CLIENT`, `DO`.`DRV_TRD_TRADE_PRICE` AS `TRADE_PRICE`,\
												ifnull(`DO`.`DRV_GOOD_TILL_DATE`,NOW()) AS `GOOD_TILL_DATE`, `DO`.`DRV_ENTITY_ID` AS `PLACEDBY`,\
												`DO`.`DRV_STRATEGY_ID` AS `STRATEGY_ID`,JULIDATE(`DO`.`DRV_INTERNAL_ENTRY_DATE`) AS `JDATE`,\
												`DO`.`DRV_MSG_CODE` AS `TRANSCODE`,`DO`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,`DO`.`DRV_OPTION_TYPE` AS `OPTION_TYPE`,\
												(CASE `DO`.`DRV_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' WHEN 'W' THEN 'WEB' WHEN 'A' THEN 'ADMIN' \
												 WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' WHEN 'H' THEN 'HELPDESK' \
												 WHEN 'E' THEN 'EXCHANGE' WHEN 'I' THEN 'ITS' WHEN 'B' THEN 'SYSTEM'  END) AS `SOURCE_FLG` ,`DO`.`DRV_OMS_ALGO_ORD_NO` AS `ALGOORDERNO`,\
												`DO`.`DRV_PAN_NO` AS `PAN_NO`,`DO`.`DRV_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,\
												`DO`.`DRV_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,\
												`DO`.`DRV_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,`DO`.`DRV_SETTLOR` AS `SETTLOR`,`DO`.`DRV_GTC_FLG` AS `GTC_FLG`,\
												`DO`.`DRV_ENCASH_FLG` AS `ENCASH_FLG`,`DO`.`DRV_MKT_TYPE` AS `MKT_TYPE` \
												FROM `DRV_ORDERS` `DO` \
												JOIN (SELECT @rn:=0) r WHERE `DO`.`DRV_SERIAL_NO` = (SELECT MAX(`DOO`.`DRV_SERIAL_NO`) FROM `DRV_ORDERS` `DOO` \
														WHERE (`DOO`.`DRV_ORDER_NO` = `DO`.`DRV_ORDER_NO`) AND (`DO`.`DRV_CF_FLAG` <> -(1) \
															AND (`DO`.`DRV_LEG_NO` = `DOO`.`DRV_LEG_NO`)) AND (`DO`.`DRV_STATUS` <> 'B') AND (`DO`.`DRV_MKT_TYPE` <> 'SP') \
														) UNION ALL SELECT     `CO`.`COMM_CLIENT_ID` AS `CLIENT_ID`,      DATE_FORMAT(`CO`.`COMM_INTERNAL_ENTRY_DATE`, '%%d-%%b-%%Y %%T') AS `ORDER_DATE_TIME`,      `CO`.`COMM_ORDER_NO` AS `ORDER NUMBER`,      `CO`.`COMM_EXCH_ID` AS `EXCH`,      (CASE `CO`.`COMM_BUY_SELL_IND`      WHEN 'B' THEN 'Buy'      WHEN 'S' THEN 'Sell'      END) AS `BUY/SELL`,      `CO`.`COMM_SEGMENT` AS `SEGMENT`,      `CO`.`COMM_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`,      `CO`.`COMM_SYMBOL` AS `SYMBOL`,      `CO`.`COMM_LEG_NO` AS `LEG_NO`,      (CASE `CO`.`COMM_PRODUCT_ID`      WHEN 'B' THEN 'BO'      WHEN 'V' THEN 'CO'      WHEN 'C' THEN 'CNC'      WHEN 'M' THEN 'MARGIN'      WHEN 'L' THEN 'MLB'      WHEN 'S' THEN 'COLLATERAL'      WHEN 'I' THEN 'INTRADAY'      WHEN 'H' THEN 'NORMAL'      WHEN 'F' THEN 'MTF'      ELSE `CO`.`COMM_PRODUCT_ID`      END) AS `PRODUCT`,      (CASE      WHEN        ((`CO`.`COMM_MSG_CODE` = '2073')          AND (`CO`.`COMM_REM_QTY` <> `CO`.`COMM_TOTAL_QTY`))      THEN        'Part-Traded'      WHEN        ((`CO`.`COMM_MSG_CODE` = '2074')          AND (`CO`.`COMM_REM_QTY` > `CO`.`COMM_TOTAL_QTY`))      THEN        'Part-Traded'      WHEN        ((`CO`.`COMM_MSG_CODE` = '2212')          AND (`CO`.`COMM_REM_QTY` <> `CO`.`COMM_TOTAL_QTY`))      THEN        'Part-Traded'      WHEN (`CO`.`COMM_MSG_CODE` = '2073') THEN 'Pending'      WHEN (`CO`.`COMM_MSG_CODE` = '2000') THEN 'Transit'      WHEN (`CO`.`COMM_MSG_CODE` = '2040') THEN 'Transit'      WHEN (`CO`.`COMM_MSG_CODE` = '2070') THEN 'Transit'      WHEN (`CO`.`COMM_MSG_CODE` = '2231') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '2042') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '2170') THEN 'Frozen'      WHEN (`CO`.`COMM_MSG_CODE` = '2074') THEN 'Modified'      WHEN (`CO`.`COMM_MSG_CODE` = '2075') THEN 'Cancelled'      WHEN (`CO`.`COMM_MSG_CODE` = '2222') THEN 'Traded'      WHEN (`CO`.`COMM_MSG_CODE` = '9002') THEN 'Expired'      WHEN (`CO`.`COMM_MSG_CODE` = '5112') THEN 'O-Pending'      WHEN (`CO`.`COMM_MSG_CODE` = '5113') THEN 'O-Modified'      WHEN (`CO`.`COMM_MSG_CODE` = '5114') THEN 'O-Cancelled'      WHEN (`CO`.`COMM_MSG_CODE` = '2212') THEN 'Triggered'      WHEN (`CO`.`COMM_MSG_CODE` = '1111') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '1113') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '1115') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '4444') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '4445') THEN 'Rejected'      WHEN (`CO`.`COMM_MSG_CODE` = '4446') THEN 'Rejected'      END) AS `STATUS`,      `CO`.`COMM_TOTAL_QTY` AS `QUANTITY`,      `CO`.`COMM_REM_QTY` AS `REM QTY`,      CASE `CO`.`COMM_SEGMENT`      WHEN        'C'      THEN        REPLACE(FORMAT((CASE `CO`.`COMM_ORDER_TYPE`          WHEN '1' THEN 'MKT'          WHEN '3' THEN 'MKT'          ELSE IFNULL(`CO`.`COMM_ORDER_PRICE`, 0)        END), 4), ',', '')      ELSE REPLACE(FORMAT((CASE `CO`.`COMM_ORDER_TYPE`        WHEN '1' THEN 'MKT'        WHEN '3' THEN 'MKT'        ELSE IFNULL(`CO`.`COMM_ORDER_PRICE`, 0)      END), 2), ',', '')      END AS `PRICE`,      CASE `CO`.`COMM_SEGMENT`      WHEN        'C'      THEN        ROUND(COALESCE((CASE `CO`.`COMM_ORDER_TYPE`          WHEN '3' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)          WHEN '4' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)          ELSE 0        END), 0), 4)      ELSE ROUND(COALESCE((CASE `CO`.`COMM_ORDER_TYPE`        WHEN '3' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)        WHEN '4' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)        ELSE 0      END), 0), 2)      END AS TRG_PRICE,      (CASE `CO`.`COMM_ORDER_TYPE`      WHEN '1' THEN 'MARKET'      WHEN '2' THEN 'LIMIT'      WHEN '3' THEN 'SL-M'      WHEN '4' THEN 'SL'      END) AS `ORDER_TYPE`,      CONCAT(`CO`.`COMM_REM_QTY`, '/', `CO`.`COMM_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,      `CO`.`COMM_DISC_QTY` AS `DISCLOSE_QTY`,      `CO`.`COMM_SERIAL_NO` AS `SERIALNO`,      `CO`.`COMM_TOTAL_TRADED_QTY` AS `TRADEDQTY`,      `CO`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,      (CASE `CO`.`COMM_VALIDITY`      WHEN '0' THEN 'DAY'      WHEN '1' THEN 'GTC'      WHEN '2' THEN 'ATO'      WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD'      ELSE 'EOS'      END) AS `ORDER_VALIDITY`,      `CO`.`COMM_LOT_SIZE` AS `SM_LOT_SIZE`,      0 AS `TAKE_PROFIT_TRAIL_GAP`,      `CO`.`COMM_OMS_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,      `CO`.`COMM_DISC_REM_QTY` AS `DQQTYREM`,      `CO`.`COMM_EXCH_ORDER_NO` AS `EXCHORDERNO`,      IFNULL(NULLIF(`CO`.`COMM_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,      `CO`.`COMM_PRO_CLIENT` AS `PRO_CLIENT`,      `CO`.`COMM_TRD_TRADE_PRICE` AS `TRADE_PRICE`,      IFNULL(`CO`.`COMM_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,      `CO`.`COMM_ENTITY_ID` AS `PLACEDBY`,      `CO`.`COMM_STRATEGY_ID` AS `STRATEGY_ID`,      JULIDATE(`CO`.`COMM_INTERNAL_ENTRY_DATE`) AS `JDATE`,      `CO`.`COMM_MSG_CODE` AS `TRANSCODE`,      `CO`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,      `CO`.`COMM_OPTION_TYPE` AS `OPTION_TYPE`,      (CASE `CO`.`COMM_SOURCE_FLG`      WHEN 'M' THEN 'MOBILE'      WHEN 'W' THEN 'WEB'      WHEN 'A' THEN 'ADMIN'      WHEN 'R' THEN 'RAPIDRUPEE'      WHEN 'S' THEN 'RUPEESMART'      WHEN 'F' THEN 'FALCON'      WHEN 'H' THEN 'HELPDESK'      WHEN 'E' THEN 'EXCHANGE'      WHEN 'I' THEN 'ITS'      WHEN 'B' THEN 'SYSTEM'      END) AS `SOURCE_FLG`,      `CO`.`COMM_OMS_ALGO_ORDER_NO` AS `ALGOORDERNO`,      `CO`.`COMM_PAN_NO` AS `PAN_NO`,      `CO`.`COMM_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,      `CO`.`COM_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,      `CO`.`COMM_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,      `CO`.`COMM_SETTLOR` AS `SETTLOR`,      `CO`.`COMM_GTC_FLG` AS `GTC_FLG`,      `CO`.`COMM_ENCASH_FLG` AS `ENCASH_FLG`,      `CO`.`COMM_MKT_TYPE` AS `MKT_TYPE`  FROM    `COMM_ORDERS` `CO`  JOIN (SELECT @rn:=0) r  WHERE    `CO`.`COMM_SERIAL_NO` = (SELECT       MAX(`COO`.`COMM_SERIAL_NO`)      FROM      `COMM_ORDERS` `COO`      WHERE      (`COO`.`COMM_ORDER_NO` = `CO`.`COMM_ORDER_NO`)        AND (`CO`.`COMM_CF_FLAG` <> -(1)        AND (`CO`.`COMM_LEG_NO` = `COO`.`COMM_LEG_NO`))        AND (`CO`.`COMM_STATUS` <> 'B')        AND (`CO`.`COMM_MKT_TYPE` <> 'SP'))) orderbook \
														WHERE 1=1 %s %s order by ORDER_DATE_TIME desc %s ",sBrchClaus,sWhere_Clause,sEdRow);

	printf("sOrdBkQry = %s : string length :%d",sOrdBkQry,strlen(sOrdBkQry));

	if(mysql_query(DBQury,sOrdBkQry) != SUCCESS)
	{
		logSqlFatal("Error in sOrdBkQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdBookHedResp.IntRespHeader.iSeqNo = 0;
	pOrdBookHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdBookHedResp.IntRespHeader.iErrorId = 0;
	pOrdBookHedResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ORDER_BOOK_HEADER_RESP;
	pOrdBookHedResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
	pOrdBookHedResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;
	pOrdBookHedResp.cMsgType = 'H';
	pOrdBookHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgLength = %d",pOrdBookHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgCode = %d",pOrdBookHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdBookHedResp.IntRespHeader.iUserId = %llu",pOrdBookHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdBookHedResp.IntRespHeader.cSource = %c",pOrdBookHedResp.IntRespHeader.cSource);
	logDebug2("pOrdBookHedResp.iNoofRec = %d",pOrdBookHedResp.iNoofRec);

	logDebug2("pOrdBookReq->ReqHeader.iUserId = %llu",pOrdBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pOrdBookHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_RESP));
		pOrdBookResp.IntRespHeader.iSeqNo = 0;
		pOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_RESP);
		logDebug2("pOrdBookResp.IntRespHeader.iMsgLength :%d:",pOrdBookResp.IntRespHeader.iMsgLength);
		pOrdBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_ORDER_BOOK_RESP;
		pOrdBookResp.IntRespHeader.iErrorId = 0;
		pOrdBookResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
		pOrdBookResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pOrdBookResp.cMsgType = 'T';
		}
		else
		{
			pOrdBookResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pOrdBookResp.suborderbook[j].fOrderNo = atof(Row[0]);
				pOrdBookResp.suborderbook[j].iSerialNo = atoi(Row[1]);
				strncpy(pOrdBookResp.suborderbook[j].sSecurityID,Row[2] ,SECURITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sOrderType,Row[3] ,ORD_TYP_LEN);
				pOrdBookResp.suborderbook[j].fQty = atof(Row[4]);
				pOrdBookResp.suborderbook[j].fRemQty =atof(Row[5]) ;
				pOrdBookResp.suborderbook[j].fDQQty = atof(Row[6]);
				pOrdBookResp.suborderbook[j].fDQQtyRem = atof(Row[7]);
				pOrdBookResp.suborderbook[j].fPrice = atof(Row[8]);
				pOrdBookResp.suborderbook[j].fTrgPrice = atof(Row[9]);
				pOrdBookResp.suborderbook[j].fTradeQty = atof(Row[10]);
				strncpy(pOrdBookResp.suborderbook[j].sProduct,Row[11] ,PRODUCT_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sValidity,Row[12] ,VALIDITY_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sExchOrderNumber,Row[13] ,BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sDatetime,Row[14] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sExcgId,Row[15] ,EXCHANGE_LEN);
				memset(pOrdBookResp.suborderbook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sBuySellInd,Row[16],BUY_SELL_LEN);
				pOrdBookResp.suborderbook[j].cSegment = Row[17][0];
				pOrdBookResp.suborderbook[j].iTranscode = atoi(Row[18]);	
				strncpy(pOrdBookResp.suborderbook[j].sClientId,Row[19],CLIENT_ID_LEN);
				pOrdBookResp.suborderbook[j].iDateTime = atoi(Row[20]);
				pOrdBookResp.suborderbook[j].iStrategyId = atoi(Row[21]);
				strncpy(pOrdBookResp.suborderbook[j].sEntityId , Row[22],ENTITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sReasonDesc, Row[23],DB_REASON_DESC_LEN);
				pOrdBookResp.suborderbook[j].cProClient =  Row[24][0];
				pOrdBookResp.suborderbook[j].fTrdPrice  = atof(Row[25]);
				strncpy(pOrdBookResp.suborderbook[j].sGoodTillDaysDate, Row[26],DB_DATETIME_LEN);
				pOrdBookResp.suborderbook[j].iLegValue = atoi(Row[27]);
				strncpy(pOrdBookResp.suborderbook[j].sSourceFlg, Row[29],SOURCE_FLG_LEN);
				logDebug2("Printing fAlgoOrderNo = %lf",pOrdBookResp.suborderbook[j].fOrderNo);

				pOrdBookResp.suborderbook[j].fAlgoOrderNo  = atof(Row[30]);
				logDebug2("Printing fAlgoOrderNo 1");
				if(strlen(Row[31]) == 0)
				{
					strncpy(pOrdBookResp.suborderbook[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrdBookResp.suborderbook[j].sPanID,Row[31],INT_PAN_LEN);
				}
				logDebug2("Printing fAlgoOrderNo2");

				pOrdBookResp.suborderbook[j].cParticipantType =  Row[32][0];
				logDebug2("Printing fAlgoOrderNo3");
				pOrdBookResp.suborderbook[j].cMarkProFlag =  Row[33][0];
				logDebug2("Printing fAlgoOrderNo4");
				pOrdBookResp.suborderbook[j].fMarkProVal = atof(Row[34]);
				logDebug2("Printing fAlgoOrderNo5");
				if(strlen(Row[35]) == 0)
				{
					strncpy(pOrdBookResp.suborderbook[j].sSettlor,"NA",SETTLOR_LEN);
				}
				else
				{
					strncpy(pOrdBookResp.suborderbook[j].sSettlor,Row[35],SETTLOR_LEN);
				}
				logDebug2("Printing fAlgoOrderNo6");
				pOrdBookResp.suborderbook[j].cGTCFlag =  Row[36][0];
				logDebug2("Printing fAlgoOrderNo7");
				pOrdBookResp.suborderbook[j].cEncashFlag =  Row[37][0];
				logDebug2("Printing fAlgoOrderNo8");
				strncpy(pOrdBookResp.suborderbook[j].sMktType,Row[38],MKT_TYPE_LEN);
				logDebug2("Printing fAlgoOrderNo9");


				logDebug2("pOrdBookResp.IntRespHeader.iMsgLength = %d",pOrdBookResp.IntRespHeader.iMsgLength);
				logDebug2("pOrdBookResp.IntRespHeader.iMsgCode = %d",pOrdBookResp.IntRespHeader.iMsgCode);
				logDebug2("pOrdBookResp.IntRespHeader.iUserId = %llu",pOrdBookResp.IntRespHeader.iUserId);
				logDebug2("pOrdBookResp.IntRespHeader.cSource = %c",pOrdBookResp.IntRespHeader.cSource);
				logDebug2("pOrdBookResp.suborderbook[%d].fOrderNo = %lf",j,pOrdBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrdBookResp.suborderbook[%d].iSerialNo = %d",j,pOrdBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sSecurityID = %s",j,pOrdBookResp.suborderbook[j].sSecurityID);
				logDebug2("pOrdBookResp.suborderbook[%dj].sOrderType = %s",j,pOrdBookResp.suborderbook[j].sOrderType);
				logDebug2("pOrdBookResp.suborderbook[%d].fQty = %d",j,pOrdBookResp.suborderbook[j].fQty);
				logDebug2("pOrdBookResp.suborderbook[%d].fRemQty = %d",j,pOrdBookResp.suborderbook[j].fRemQty);
				logDebug2("pOrdBookResp.suborderbook[%d].fDQQty = %d",j,pOrdBookResp.suborderbook[j].fDQQty);
				logDebug2("pOrdBookResp.suborderbook[%d].fDQQtyRem = %d",j,pOrdBookResp.suborderbook[j].fDQQtyRem);
				logDebug2("pOrdBookResp.suborderbook[%d].fPrice = %lf",j,pOrdBookResp.suborderbook[j].fPrice);
				logDebug2("pOrdBookResp.suborderbook[%d].fTrgPrice = %lf",j,pOrdBookResp.suborderbook[j].fTrgPrice);
				logDebug2("pOrdBookResp.suborderbook[%d].fTradeQty = %d",j,pOrdBookResp.suborderbook[j].fTradeQty);
				logDebug2("pOrdBookResp.suborderbook[%d].sProduct = %s",j,pOrdBookResp.suborderbook[j].sProduct);
				logDebug2("pOrdBookResp.suborderbook[%d].sValidity = %s",j,pOrdBookResp.suborderbook[j].sValidity);
				logDebug2("pOrdBookResp.suborderbook[%d].sExchOrderNumber = %s",j,pOrdBookResp.suborderbook[j].sExchOrderNumber);
				logDebug2("pOrdBookResp.suborderbook[%d].sDatetime = %s",j,pOrdBookResp.suborderbook[j].sDatetime);
				logDebug2("pOrdBookResp.suborderbook[%d].sExcgId = %s",j,pOrdBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrdBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrdBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdBookResp.suborderbook[%d].cSegment = %c",j,pOrdBookResp.suborderbook[j].cSegment);
				logDebug2("pOrdBookResp.suborderbook[%d].iTranscode = %d",j,pOrdBookResp.suborderbook[j].iTranscode);
				logDebug2("pOrdBookResp.suborderbook[%d].sClientId = %s",j,pOrdBookResp.suborderbook[j].sClientId);
				logDebug2("pOrdBookResp.suborderbook[%d].iDateTime = %d",j,pOrdBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrdBookResp.suborderbook[%d].sExcgId = %s",j,pOrdBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrdBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrdBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdBookResp.suborderbook[%d].cSegment = %c",j,pOrdBookResp.suborderbook[j].cSegment);
				logDebug2("pOrdBookResp.suborderbook[%d].iTranscode = %d",j,pOrdBookResp.suborderbook[j].iTranscode);
				logDebug2("pOrdBookResp.suborderbook[%d].sClientId = %s",j,pOrdBookResp.suborderbook[j].sClientId);
				logDebug2("pOrdBookResp.suborderbook[%d].iDateTime = %d",j,pOrdBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrdBookResp.suborderbook[%d].iStrategyId = %d",j,pOrdBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrdBookResp.suborderbook[%d].sEntityId = %s",j,pOrdBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrdBookResp.suborderbook[%d].sReasonDesc = %s",j,pOrdBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrdBookResp.suborderbook[%d].cProClient = %c",j,pOrdBookResp.suborderbook[j].cProClient);
				logDebug2("pOrdBookResp.suborderbook[%d].fTrdPrice = %lf",j,pOrdBookResp.suborderbook[j].fTrdPrice);
				logDebug2("pOrdBookResp.suborderbook[%d].sGoodTillDaysDate = %s",j,pOrdBookResp.suborderbook[j].sGoodTillDaysDate);
				logDebug2("pOrdBookResp.suborderbook[%d].iLegValue = %d",j,pOrdBookResp.suborderbook[j].iLegValue);
				logDebug2("pOrdBookResp.suborderbook[%d].sSourceFlg = %s",j,pOrdBookResp.suborderbook[j].sSourceFlg);
				logDebug2("pOrdBookResp.suborderbook[%d].fAlgoOrderNo = %f",j,pOrdBookResp.suborderbook[j].fAlgoOrderNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sPanID = %s",j,pOrdBookResp.suborderbook[j].sPanID);
				logDebug2("pOrdBookResp.suborderbook[%d].cParticipantType = %c",j,pOrdBookResp.suborderbook[j].cParticipantType);
				logDebug2("pOrdBookResp.suborderbook[%d].cMarkProFlag = %c",j,pOrdBookResp.suborderbook[j].cMarkProFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrdBookResp.suborderbook[j].fMarkProVal);
				logDebug2("pOrdBookResp.suborderbook[%d].sSettlor = %s",j,pOrdBookResp.suborderbook[j].sSettlor);
				logDebug2("pOrdBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrdBookResp.suborderbook[j].cGTCFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrdBookResp.suborderbook[j].cEncashFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].sMktType = %s",j,pOrdBookResp.suborderbook[j].sMktType);
				logDebug2("pOrdBookResp.cMsgType = %c",pOrdBookResp.cMsgType);

			}

		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pOrdBookResp,sizeof(struct VIEW_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;			
		}

		iTempNoOfRec--;
		//		usleep(5000);
	}
	//	free(sOrdBkQry);
	logTimestamp("Exit : fOrderBook");
	return TRUE;
}


BOOL    fBatchProcess_Req  (CHAR *RcvMsg)
{
	logTimestamp("Entry : fBatchProcess_Req ");

	struct VIEW_ADMIN_BATCH_PROCESS_REQ        *pBatchReq;
	struct VIEW_ADMIN_BATCH_PROCESS_RESP             pBatchResp;
	struct VIEW_COMMON_HDR_RESP             pHdrResp;

	CHAR    sQry[MAX_QUERY_SIZE];
	CHAR    sBatchQry[QUERY_SIZE];
	CHAR    sUpdtQry[MAX_QUERY_SIZE];


	CHAR            sWhere_Clause[QUERY_SIZE];
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;
	CHAR            sEdRow[QUERY_SIZE];
	CHAR		sSegment[SEGMENT_LENGTH];

	memset(sQry,'\0',MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);


	pBatchReq = (struct VIEW_ADMIN_BATCH_PROCESS_REQ *)RcvMsg;


	logDebug2("pBatchReq->ReqHeader.iMsgCode        :%d:",pBatchReq->ReqHeader.iMsgCode);
	logDebug2("pBatchReq->ReqHeader.sExcgId         :%s:",pBatchReq->ReqHeader.sExcgId);
	logDebug2("pBatchReq->ReqHeader.cSegment        :%c:",pBatchReq->ReqHeader.cSegment);
	logDebug2("pBatchReq->sBatch_name             	:%s:",pBatchReq->sBatch_name);
	logDebug2("pBatchReq->ReqHeader.cSegment :%c:   SEL_ALL :%c:",pBatchReq->ReqHeader.cSegment,SEL_ALL);


	if(strcmp(pBatchReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sBatchQry,'\0',QUERY_SIZE);
		sprintf(sBatchQry," AND BP_EXCH_ID = \"%s\"",pBatchReq->ReqHeader.sExcgId);
		logDebug2("sBatchQry= %s",sBatchQry);
		strcat(sWhere_Clause,sBatchQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pBatchReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sBatchQry,'\0',QUERY_SIZE);
		logDebug2("pBatchReq->ReqHeader.cSegment :%c:   SEL_ALL :%c:",pBatchReq->ReqHeader.cSegment,SEL_ALL);
		sprintf(sBatchQry," AND BP_SEGMENT = \'%c\'",pBatchReq->ReqHeader.cSegment);
		logDebug2("sBatchQry= %s",sBatchQry);
		strcat(sWhere_Clause,sBatchQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pBatchReq->sBatch_name,SELECT_ALL))
	{
		memset(sBatchQry,'\0',QUERY_SIZE);
		sprintf(sBatchQry," AND BP_BATCH_NAME = \"%s\"",pBatchReq->sBatch_name);
		logDebug2("sBatchQry= %s",sBatchQry);
		strcat(sWhere_Clause,sBatchQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	sprintf(sQry,"SELECT CASE x.bp_segment \
			WHEN 'C' THEN 'Currency' \
			WHEN 'D' THEN 'Derivative' \
			WHEN 'E' THEN 'Equity' \
			WHEN 'M' THEN 'Commodity' \
			ELSE 'All' \
			END SegName, \
			CASE x.bp_mode \
			WHEN 'M' THEN 'Manual' \
			ELSE 'Automatic' \	
			END OperationMode, \
			CASE x.bp_status \
			WHEN 'Y' THEN 'Completed' \
			ELSE 'Failed' \
			END Status, \
			DATE_FORMAT(x.bp_schedule_time, '%T') BatchTime, \
			CASE x.bp_off_mkt_status \
			WHEN 'Y' THEN 'Enable' \
			WHEN 'N' THEN 'Disable' \
			END MktStatus, \
			CASE \
			WHEN (x.bp_segment = 'M') \
			THEN \
			CASE x.bp_mkt_type_no \
			WHEN '1' THEN 'Morning Session' \
			WHEN '2' THEN 'Evening Session'\
			WHEN '3' THEN 'Special Session'\
			WHEN '4' THEN 'Normal Session'\
			END \
			ELSE CASE x.bp_mkt_type_no \
			WHEN '1' THEN 'NL' \
			WHEN '2' THEN 'NL'\
			WHEN '3' THEN 'NL'\
			WHEN '4' THEN 'NL'\
			END \
			END MktType,\
			x.bp_next_schedule_date,\ 
			x.BP_BATCH_NAME,\
			x.BP_LAST_RUN_DATE,\
			x.BP_DATE,\
			x.BP_UPDATED_BY ,\
			x.BP_REMARKS , x.BP_EXCH_ID,x.BP_MKT_TYPE_NO \
			FROM BATCH_PROCESS x WHERE 1=1 %s  ORDER BY BP_NEXT_SCHEDULE_DATE ",sWhere_Clause);

	logDebug2("sQry:%s:",sQry);

	if(mysql_query(DBQury,sQry) != SUCCESS)
	{
		logSqlFatal("Error in sOrdBkQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pHdrResp.IntRespHeader.iSeqNo = 0;
	pHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pHdrResp.IntRespHeader.iErrorId = 0;
	pHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_BATCH_PROCESS_HEADER_RESP;
	pHdrResp.IntRespHeader.iUserId = pBatchReq->ReqHeader.iUserId;
	pHdrResp.IntRespHeader.cSource = pBatchReq->ReqHeader.cSource ;
	pHdrResp.cMsgType = 'H';
	pHdrResp.iNoofRec = iNoOfRec;
	logDebug2("pHdrResp.IntRespHeader.iMsgLength    = %d",pHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pHdrResp.IntRespHeader.iMsgCode      = %d",pHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pHdrResp.IntRespHeader.iUserId       = %llu",pHdrResp.IntRespHeader.iUserId);
	logDebug2("pHdrResp.IntRespHeader.cSource       = %c",pHdrResp.IntRespHeader.cSource);
	logDebug2("pHdrResp.iNoofRec                    = %d",pHdrResp.iNoofRec);

	logDebug2("pHdrResp.IntRespHeader.iUserId = %llu",pHdrResp.IntRespHeader.iUserId);
	iRelayID = find_admin_adapter(pHdrResp.IntRespHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}
	for(i=0;i<iNoOfPkt;i++)
	{

		memset(&pBatchResp,'\0',sizeof(struct VIEW_ADMIN_BATCH_PROCESS_RESP));
		pBatchResp.IntRespHeader.iSeqNo = 0;
		pBatchResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_BATCH_PROCESS_RESP);
		pBatchResp.IntRespHeader.iMsgCode = TC_INT_BATCH_PROCESS_RESP;
		pBatchResp.IntRespHeader.iErrorId = 0;
		pBatchResp.IntRespHeader.iUserId = pBatchReq->ReqHeader.iUserId;
		pBatchResp.IntRespHeader.cSource = pBatchReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pBatchResp.cMsgType = 'T';
		}
		else
		{
			pBatchResp.cMsgType = 'D';
		}
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				logDebug2("SEGMENT_LENGTH [%d] | BATCH_OPERATION_MODE_LEN :%d: | BP_STATUS_LEN :%d:",SEGMENT_LENGTH,BATCH_OPERATION_MODE_LEN,BP_STATUS_LEN);
				strncpy(pBatchResp.subBatches[j].sSegment,Row[0],SEGMENT_LENGTH);	
				logDebug2("pBatchResp.subBatches[%d].sSegment 0           :%s:",j,pBatchResp.subBatches[j].sSegment);
				strncpy(pBatchResp.subBatches[j].sBpMode	,Row[1],BATCH_OPERATION_MODE_LEN);
				strncpy(pBatchResp.subBatches[j].sBpStatus	,Row[2],BP_STATUS_LEN);
				strncpy(pBatchResp.subBatches[j].sScheduleTime	,Row[3],BP_TIME_LEN);
				strncpy(pBatchResp.subBatches[j].sOffMktStatus	,Row[4],OFF_MKT_STATUS_LEN);
				strncpy(pBatchResp.subBatches[j].sBpMktType	,Row[5],BP_MKT_TYPE);
				strncpy(pBatchResp.subBatches[j].sNextScheduleDate,Row[6] ,DB_DATETIME_LEN);
				strncpy(pBatchResp.subBatches[j].sBatch_Name	,Row[7],BATCH_CODE_LEN);
				strncpy(pBatchResp.subBatches[j].sLastRunDate	,Row[8],DB_DATETIME_LEN);
				strncpy(pBatchResp.subBatches[j].sBpDate	,Row[9],DB_DATETIME_LEN );
				strncpy(pBatchResp.subBatches[j].sUpdatedBy	,Row[10],BP_ENTITY_ID_LEN);
				strncpy(pBatchResp.subBatches[j].sRemarks	,Row[11],BP_REMARKS_LEN);
				strncpy(pBatchResp.subBatches[j].sExchId 	,Row[12],EXCHANGE_LEN);
				pBatchResp.subBatches[j].iMktTypeNo = atoi(Row[13]);

				logDebug2("------------- Start Printing Batches record %d ----------- ",iTempNoOfRec);
				logDebug2("pBatchResp.subBatches[%d].sSegment = :%s:",j,pBatchResp.subBatches[j].sSegment);
				logDebug2("pBatchResp.subBatches[%d].sBpMode            :%s:",j,pBatchResp.subBatches[j].sBpMode);
				logDebug2("pBatchResp.subBatches[%d].sBpStatus          :%s:",j,pBatchResp.subBatches[j].sBpStatus);
				logDebug2("pBatchResp.subBatches[%d].sScheduleTime      :%s:",j,pBatchResp.subBatches[j].sScheduleTime);
				logDebug2("pBatchResp.subBatches[%d].sOffMktStatus      :%s:",j,pBatchResp.subBatches[j].sOffMktStatus);
				logDebug2("pBatchResp.subBatches[%d].sBpMktType		:%s:",j,pBatchResp.subBatches[j].sBpMktType);
				logDebug2("pBatchResp.subBatches[%d].sNextScheduleDate  :%s:",j,pBatchResp.subBatches[j].sNextScheduleDate);
				logDebug2("pBatchResp.subBatches[%d].sBatch_Name	:%s:",j,pBatchResp.subBatches[j].sBatch_Name);
				logDebug2("pBatchResp.subBatches[%d].sLastRunDate       :%s:",j,pBatchResp.subBatches[j].sLastRunDate);
				logDebug2("pBatchResp.subBatches[%d].sBpDate            :%s:",j,pBatchResp.subBatches[j].sBpDate);
				logDebug2("pBatchResp.subBatches[%d].sUpdatedBy		:%s:",j,pBatchResp.subBatches[j].sUpdatedBy);
				logDebug2("pBatchResp.subBatches[%d].sRemarks		:%s:",j,pBatchResp.subBatches[j].sRemarks);
				logDebug2("pBatchResp.subBatches[%d].sExchId            :%s:",j,pBatchResp.subBatches[j].sExchId);
				logDebug2("pBatchResp.subBatches[%d].iMktTypeNo		:%d:",j,pBatchResp.subBatches[j].iMktTypeNo);
				logDebug2("------------- END-----------");
			}

		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pBatchResp,sizeof(struct VIEW_ADMIN_BATCH_PROCESS_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//xit(ERROR);	
			return FALSE;
		}
		iTempNoOfRec--;
		//	usleep(100);
	}

	logTimestamp("Exit : fBatchProcess_Req ");
	return TRUE;
}


BOOL fIpoOrderBook(CHAR *RcvMsg)
{

	logTimestamp("Entry : fIpoOrderBook");
	struct VIEW_IPO_ORDERBOOK_DETAIL_REQUEST    *pIpoOrdBookReq;
	struct VIEW_IPO_ORDERBOOK_DETAIL_RESP	 pIpoOrdBookResp;
	struct VIEW_COMMON_HDR_RESP          pIpoOrdBookHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;
	CHAR		sClientId[CLIENT_ID_LEN];	
	CHAR		sCmpyId[COMPANY_ID_LEN];
	CHAR		sQry[QUERY_SIZE];
	CHAR		sWhere_Clause[MAX_QUERY_SIZE];
	CHAR *sOrdBookQry = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	pIpoOrdBookReq = (struct VIEW_IPO_ORDERBOOK_DETAIL_REQ *)RcvMsg;

	strncpy(sClientId ,pIpoOrdBookReq->sClientId,CLIENT_ID_LEN);
	logDebug2("sClientId= %s",sClientId);
	strncpy(sCmpyId,pIpoOrdBookReq->sCmpyId,COMPANY_ID_LEN);
	logDebug2("sCmpyId= %s",sCmpyId);

	if(strcmp(pIpoOrdBookReq->sCmpyId,SELECT_ALL))
	{
		memset(sQry,'\0',QUERY_SIZE);
		sprintf(sQry," AND IPO_CMPY_ID = \"%s\"",pIpoOrdBookReq->sCmpyId);
		logDebug2("sQry = %s",sQry);
		strcat(sWhere_Clause,sQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(strcmp(pIpoOrdBookReq->sClientId,SELECT_ALL))
	{
		memset(sQry,'\0',QUERY_SIZE);
		sprintf(sQry," AND IPO_CLIENT_ID = \"%s\"",pIpoOrdBookReq->sClientId);
		logDebug2("sQry = %s",sQry);
		strcat(sWhere_Clause,sQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);	
	}	

	logDebug2("sWhere_Clause : %s: ",sWhere_Clause);	
	sprintf(sOrdBookQry," SELECT IPO_ORD_NO,IPO_REFERENCE_NO,IPO_SERIAL_NO,IPO_SYM,IPO_CMPY_ID,IPO_CLIENT_ID,IPO_MSG_CODE,IPO_CAT,IPO_DATETIME,\
			IPO_ALLOTMENT,B1_QTY,B1_PRICE,B1_REF_NO,B1_TYPE,B1_CUTOFF,B1_STATUS,B1_REASON,B2_QTY,B2_PRICE,B2_REF_NO,B2_TYPE,B2_CUTOFF,\
			B2_STATUS,B2_REASON,B3_QTY,B3_PRICE,B3_REF_NO,B3_TYPE,B3_CUTOFF,B3_STATUS,B3_REASON,IPO_REASON,IPO_REASON,\
			IPO_USER_ID,IPO_CUT_OFF FROM IPO_ORDERS A\
			WHERE 1=1 %s AND A.IPO_SERIAL_NO = (SELECT MAX(T1.IPO_SERIAL_NO) FROM IPO_ORDERS T1 WHERE T1.IPO_ORD_NO = A.IPO_ORD_NO)",sWhere_Clause);


	logDebug2("sOrdBookQry = %s",sOrdBookQry);
	if(mysql_query(DBQury,sOrdBookQry) != SUCCESS)
	{
		logSqlFatal("Error in sOrdBookQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pIpoOrdBookHdrResp.IntRespHeader.iSeqNo = 0;
	pIpoOrdBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pIpoOrdBookHdrResp.IntRespHeader.iErrorId = 0;
	pIpoOrdBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_ORDER_BOOK_HDR_RESP;
	pIpoOrdBookHdrResp.IntRespHeader.iUserId = pIpoOrdBookReq->ReqHeader.iUserId;
	pIpoOrdBookHdrResp.IntRespHeader.cSource = pIpoOrdBookReq->ReqHeader.cSource;

	logDebug2("pIpoOrdBookHdrResp.IntRespHeader.iMsgLength = %d",pIpoOrdBookHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pIpoOrdBookHdrResp.IntRespHeader.iMsgCode = %d",pIpoOrdBookHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pIpoOrdBookHdrResp.IntRespHeader.iUserId = %llu",pIpoOrdBookHdrResp.IntRespHeader.iUserId);
	logDebug2("pIpoOrdBookHdrResp.IntRespHeader.cSource = %c",pIpoOrdBookHdrResp.IntRespHeader.cSource);

	iRelayID = find_admin_adapter(pIpoOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE; 
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pIpoOrdBookHdrResp,sizeof(struct ADMIN_VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}
	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pIpoOrdBookResp.IntRespHeader.iSeqNo = 0;
				pIpoOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct INT_COMMON_RESP_HDR);
				pIpoOrdBookResp.IntRespHeader.iErrorId = 0;
				pIpoOrdBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_IPO_ORDER_BOOK_RESP ;
				pIpoOrdBookResp.IntRespHeader.iUserId = pIpoOrdBookReq->ReqHeader.iUserId;
				pIpoOrdBookResp.IntRespHeader.cSource = pIpoOrdBookReq->ReqHeader.cSource; 

				logDebug2("$$$$$$$$");	
				if(iTempNoOfRec <= 1)
				{
					pIpoOrdBookResp.cMsgType = 'T';
				}
				else
				{
					pIpoOrdBookResp.cMsgType = 'D';
				}	
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sOrderNo,Row[0],DB_EXCH_ORD_NO_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sReferenceNo,Row[1],REFERENCE_NO_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].iSerialNo = atoi(Row[2]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sSymbol,Row[3],DB_SYM_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sCompanyId,Row[4],COMPANY_ID_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sClientId,Row[5],CLIENT_ID_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].iMsgCode = atoi(Row[6]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sCategory,Row[6],DB_CATEGORY_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sOrderTime,Row[7],DB_DATETIME_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sAllotment,Row[8],DB_SYM_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].i1Qty = atoi(Row[9]);
				pIpoOrdBookResp.subIpoOrderbook[j].f1Price = atof(Row[10]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s1ReferenceNo,Row[11],REFERENCE_NO_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s1Type,Row[12],IPOORDTYPE_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].i1Cuttoff = atoi(Row[13]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s1Status,Row[14],STATUS_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s1Reason,Row[15],REASON_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].i2Qty = atoi(Row[169]);
				pIpoOrdBookResp.subIpoOrderbook[j].f2Price = atof(Row[17]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s2ReferenceNo,Row[18],REFERENCE_NO_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s2Type,Row[19],IPOORDTYPE_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].i2Cuttoff = atoi(Row[20]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s2Status,Row[21],STATUS_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s2Reason,Row[22],REASON_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].i3Qty = atoi(Row[23]);
				pIpoOrdBookResp.subIpoOrderbook[j].f3Price = atof(Row[24]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s3ReferenceNo,Row[25],REFERENCE_NO_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s3Type,Row[26],IPOORDTYPE_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].i3Cuttoff = atoi(Row[27]);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s3Status,Row[28],STATUS_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].s3Reason,Row[29],REASON_LEN);
				strncpy(pIpoOrdBookResp.subIpoOrderbook[j].sIpoReason,Row[30],REASON_LEN);
				pIpoOrdBookResp.subIpoOrderbook[j].iUserId = strtoull(Row[31],NULL,10);
				pIpoOrdBookResp.subIpoOrderbook[j].iCuttOFF = atoi(Row[32]);

				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sOrderNo :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sOrderNo);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sReferenceNo :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sReferenceNo);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].iSerialNo :%d:",pIpoOrdBookResp.subIpoOrderbook[j].iSerialNo);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sSymbol :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sSymbol);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sCompanyId :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sCompanyId);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sClientId :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sClientId);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].iMsgCode :%d:",pIpoOrdBookResp.subIpoOrderbook[j].iMsgCode);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sCategory :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sCategory);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sOrderTime :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sOrderTime);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].sAllotment :%s:",pIpoOrdBookResp.subIpoOrderbook[j].sAllotment);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].i1Qty :%d:",pIpoOrdBookResp.subIpoOrderbook[j].i1Qty);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].f1Price :%f:",pIpoOrdBookResp.subIpoOrderbook[j].f1Price);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s1ReferenceNo :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s1ReferenceNo);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s1Type :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s1Type);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].i1Cuttoff :%d:",pIpoOrdBookResp.subIpoOrderbook[j].i1Cuttoff);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s1Status :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s1Status);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s1Reason :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s1Reason);	
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].i2Qty :%d:",pIpoOrdBookResp.subIpoOrderbook[j].i2Qty);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].f2Price :%f:",pIpoOrdBookResp.subIpoOrderbook[j].f2Price);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s2ReferenceNo :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s2ReferenceNo);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s2Type :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s2Type);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].i2Cuttoff :%d:",pIpoOrdBookResp.subIpoOrderbook[j].i2Cuttoff);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s2Status :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s2Status);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s2Reason :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s2Reason);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].i3Qty :%d:",pIpoOrdBookResp.subIpoOrderbook[j].i3Qty);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].f3Price :%f:",pIpoOrdBookResp.subIpoOrderbook[j].f3Price);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s3ReferenceNo :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s3ReferenceNo);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s3Type :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s3Type);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].i3Cuttoff :%d:",pIpoOrdBookResp.subIpoOrderbook[j].i3Cuttoff);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s3Status :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s3Status);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].s3Reason :%s:",pIpoOrdBookResp.subIpoOrderbook[j].s3Reason);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j].iUserId :%llu:",pIpoOrdBookResp.subIpoOrderbook[j].iUserId);
				logDebug2("pIpoOrdBookResp.subIpoOrderbook[j]CuttOfff :%d:",pIpoOrdBookResp.subIpoOrderbook[j].iCuttOFF);


			}				
			iTempNoOfRec--;								
		}	

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pIpoOrdBookResp,sizeof(struct VIEW_IPO_ORDERBOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}	
	}
}

void    fConvTopwdPrtect(CHAR *sFileName,CHAR *sPreFix,CHAR *sClientID)
{
	logTimestamp("Entry :fConvTopwdPrtect:");
	CHAR    sCommand[200];
	memset(&sCommand,'\0',200);

	sprintf(sCommand,"rm  %s/%s.zip",FILE_LOCATION,sClientID);
	logDebug2("sCommand 1:%s:",sCommand);
	system(sCommand);

	memset(&sCommand,'\0',200);


	logDebug2("sFileName :%s:%s:%s:",sFileName,sPreFix,sClientID);

	//sprintf(sCommand,"zip -P rupee123 %s_%s.rrs %s",sPreFix,sDealerID,sFileName);
	sprintf(sCommand,"zip -P %s %s/%s.zip %s",sClientID,FILE_LOCATION,sClientID,sFileName);
	logDebug2("sCommand 2:%s:",sCommand);
	system(sCommand);


	memset(&sCommand,'\0',200);

	sprintf(sCommand,"rm  %s",sFileName);
	logDebug2("sCommand 3:%s:",sCommand);
	system(sCommand);

	logTimestamp("Exit :fConvTopwdPrtect:");

}

BOOL fEquOrderReportDetails(CHAR *RcvMsg)
{

	logTimestamp("Entry :fEquOrderReportDetails:");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP      pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *sEqOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32          i=0,j=0;

	DOUBLE64	fReqOrderNo;
	LONG32          iNoOfPkt;
	LONG32          iErrorId;
	LONG32          iTempNoOfRec = 0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	CHAR            sOrdReasonDesc[200];
	CHAR            cProdId ;
	INT16           iLegVal = 0;

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	fReqOrderNo = pViewOrderBookReq->fOrderNo;
	iLegVal     = pViewOrderBookReq->iLegNo;

	logDebug2("pViewOrderBookReq->ReqHeader.cSegment:%c:",pViewOrderBookReq->ReqHeader.cSegment);
	logDebug2("ReqOrderNo :%lf:",fReqOrderNo);
	logDebug2("iLegVal    :%d:",iLegVal);

	sprintf(sEqOrdBook,"SELECT  EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_MSG_CODE,\
			EQ_SCRIP_CODE,\
			EQ_VALIDITY,\
			EQ_PRO_CLIENT,\
			EQ_SOURCE_FLG,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_LAST_TRADE_QTY,\
			EQ_TRD_TRADE_PRICE,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_TRD_EXCH_TRADE_NO,\
			EQ_PRODUCT_ID,\
			EQ_EXCH_ORDER_NO,\
			date_format(EQ_INTERNAL_ENTRY_DATE,\'%%d-%%m-%%Y %%r\'),\
			EQ_ERROR_CODE,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_EXCH_ID,\
			EQ_REASON_DESCRIPTION ,\
			EQ_ENTITY_ID ,\
			EQ_STRATEGY_ID ,\
			EQ_PRO_CLIENT ,\
			EQ_TRD_TRADE_PRICE ,\
			EQ_GOOD_TILL_DAYS ,\
			EQ_LEG_NO \
			FROM EQ_ORDERS_ARCHIVE \
			WHERE EQ_ORDER_NO = %lf \
			AND EQ_LEG_NO = %d \
			ORDER BY EQ_ORDER_NO , EQ_SERIAL_NO desc ;",fReqOrderNo,iLegVal);

	logDebug3(" fEquOrderReportDetails :%s:",sEqOrdBook);

	if(mysql_query(DBQury,sEqOrdBook) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQury);
	}

	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_REPORT_DETAILS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iTrdRtrToRel , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	logInfo(" I am in Equity");


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				memset(sOrdReasonDesc,'\0',200);
				//                              memset(cProdId,'\0',2);

				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				iErrorId = atoi(Row[24]);
				logDebug2("atoi(Row[24]) :%d: iErrorId :%d:",atoi(Row[24]),iErrorId);
				pOrderBookResp.IntRespHeader.iErrorId = iErrorId;
				logDebug2("pOrderBookResp.IntRespHeader.iErrorId :%d: iErrorId :%d:",pOrderBookResp.IntRespHeader.iErrorId,iErrorId);

				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_REPORT_DETAILS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
				pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);
				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[16]);

				cProdId =  Row[17][0];
				pOrderBookResp.suborderbookdtls[j].sProduct =  Row[17][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18],BSE_EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_TIME_LEN);
				//pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[20]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21],CLIENT_ID_LEN);
				if(Row[22][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				if(strlen(Row[24]) != 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[24],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice  = atof(Row[28]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);

				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" pOrderBookResp.suborderbookdtls[%d].iTranscode :%d:",j,pOrderBookResp.suborderbookdtls[j].iTranscode);
				logDebug2(" fOrderNo:%lf:,                                                                                                                                                              iSerialNo:%d:,                                                                                                                                                          sBuySellInd:%s:,                                                                                                                                                        sSecurityID:%s:,                                                                                                                                                        sFlags:%s:,                                                                                                                                                             fQty:%lf:,                                                                                                                                                              fRemQty:%lf:,                                                                                                                                                           fDQQty:%lf:,                                                                                                                                                            fDQQtyRem:%lf:,                                                                                                                                                         fPrice:%lf:,                                                                                                                                                            fTrgPrice:%lf:,                                                                                                                                                         fTradeQty:%lf:,                                                                                                                                                         sProduct:%c:,                                                                                                                                                           sExchOrderNumber:%s:,                                                                                                                                                   sDatetime:%s:,                                                                                                                                                          sClientId:%s: ReasonDesc:%s: ErrorId :%d:",
						pOrderBookResp.suborderbookdtls[j].fOrderNo,
						pOrderBookResp.suborderbookdtls[j].iSerialNo,
						pOrderBookResp.suborderbookdtls[j].sBuySellInd,
						pOrderBookResp.suborderbookdtls[j].sSecurityID,
						pOrderBookResp.suborderbookdtls[j].sFlags,
						pOrderBookResp.suborderbookdtls[j].fQty,
						pOrderBookResp.suborderbookdtls[j].fRemQty,
						pOrderBookResp.suborderbookdtls[j].fDQQty,
						pOrderBookResp.suborderbookdtls[j].fDQQtyRem,
						pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,
						pOrderBookResp.suborderbookdtls[j].fTradeQty,
						pOrderBookResp.suborderbookdtls[j].sProduct,
						pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,
						pOrderBookResp.suborderbookdtls[j].sDatetime,
						pOrderBookResp.suborderbookdtls[j].sClientId,
						pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,
						pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
			}
			iTempNoOfRec--;
		}
		if(( WriteMsgQ( iTrdRtrToRel , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}


	}

	logTimestamp("EXIT [fEquOrderReportDetails]");
	return TRUE;

}/************** END of fEquOrderReportDetails ****/

BOOL fDrvOrderReportDetails(CHAR *RcvMsg)
{
	logTimestamp("Entry : fDrvOrderReportDetails");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP      pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	LONG32 i=0,j=0;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    	*sDrvOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	DOUBLE64        fReqOrderNo;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            cOrdValidity;

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	fReqOrderNo = pViewOrderBookReq->fOrderNo;

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,fReqOrderNo);

	sprintf(sDrvOrdBook,"SELECT     DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_MSG_CODE,\
			DRV_SCRIP_CODE,\
			DRV_VALIDITY,\
			DRV_PRO_CLIENT,\
			DRV_SOURCE_FLG,\
			DRV_ORIG_CLORDID,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_TRD_TRADE_QTY,\
			DRV_TRD_TRADE_PRICE,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_TRD_TRADE_PRICE,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_TRD_EXCH_TRADE_NO,\
			DRV_PRODUCT_ID,\
			DRV_EXCH_ORDER_NO,\
			IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
			DRV_ERROR_CODE,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_EXCH_ID,\
			DRV_REASON_DESCRIPTION ,\
			DRV_ENTITY_ID ,\
			DRV_STRATEGY_ID ,\
			DRV_PRO_CLIENT ,\
			DRV_TRD_TRADE_PRICE ,\
			DRV_GOOD_TILL_DAYS \
			FROM DRV_ORDERS_ARCHIVE\
			WHERE DRV_ORDER_NO = %lf\
			ORDER BY DRV_ORDER_NO , DRV_SERIAL_NO desc ;",fReqOrderNo);

	logDebug2(" sDrvOrderReportDetails :%s: ",sDrvOrdBook);

	if(mysql_query(DBQury,sDrvOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in DrvOrdBook Query.");
		sql_Error(DBQury);
	}

	Res = mysql_store_result(DBQury);

	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_REPORT_DETAILS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iTrdRtrToRel , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	logInfo(" I am in Derivative");

	for(i=0;i<iNoOfPkt;i++)
	{

		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_REPORT_DETAILS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);


				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[17]);
				pOrderBookResp.suborderbookdtls[j].sProduct = Row[18][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

				if(strlen(Row[25])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				if(Row[23][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice    = atof(Row[29]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);

				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" fOrderNo:%lf:,                                                                                                                                                              iSerialNo:%d:,                                                                                                                                                          sBuySellInd:%s:,                                                                                                                                                        sSecurityID:%s:,                                                                                                                                                        sFlags:%s:,                                                                                                                                                             fQty:%lf:,                                                                                                                                                              fRemQty:%lf:,                                                                                                                                                           fDQQty:%lf:,                                                                                                                                                            fDQQtyRem:%lf:,                                                                                                                                                         fPrice:%lf:,                                                                                                                                                            fTrgPrice:%lf:,                                                                                                                                                         fTradeQty:%lf:,                                                                                                                                                         sProduct:%c:,                                                                                                                                                           sExchOrderNumber:%s:,                                                                                                                                                   sDatetime:%s:,                                                                                                                                                          sClientId:%s:,                                                                                                                                                          ReasonDesc:%s:,                                                                                                                                                         ErrorID:%d:",                                                                                                                                                           pOrderBookResp.suborderbookdtls[j].fOrderNo,                                                                                                                            pOrderBookResp.suborderbookdtls[j].iSerialNo,                                                                                                                           pOrderBookResp.suborderbookdtls[j].sBuySellInd,                                                                                                                         pOrderBookResp.suborderbookdtls[j].sSecurityID,                                                                                                                         pOrderBookResp.suborderbookdtls[j].sFlags,                                                                                                                              pOrderBookResp.suborderbookdtls[j].fQty,                                                                                                                                pOrderBookResp.suborderbookdtls[j].fRemQty,                                                                                                                             pOrderBookResp.suborderbookdtls[j].fDQQty,                                                                                                                              pOrderBookResp.suborderbookdtls[j].fDQQtyRem,                                                                                                                           pOrderBookResp.suborderbookdtls[j].fPrice,                                                                                                                              pOrderBookResp.suborderbookdtls[j].fTrgPrice,                                                                                                                           pOrderBookResp.suborderbookdtls[j].fTradeQty,                                                                                                                           pOrderBookResp.suborderbookdtls[j].sProduct,                                                                                                                            pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,                                                                                                                    pOrderBookResp.suborderbookdtls[j].sDatetime,                                                                                                                           pOrderBookResp.suborderbookdtls[j].sClientId,                                                                                                                           pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,                                                                                                                      pOrderBookResp.IntRespHeader.iErrorId);

				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				//logDebug2("pOrderBookResp.suborderbookdtls[j].fTrdPrice  :%f:",pOrderBookResp.suborderbookdtls[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);

			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iTrdRtrToRel , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}


	}

	logTimestamp("Exit : fDrvOrderReportDetails");
	return TRUE;


}/************** END of fDrvOrderReportDetails ****/


BOOL    fNISMNotifier(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fNISMNotifier]");

	struct VIEW_NISM_QUERY_REQ *pViewNISMCertiReq;
	struct VIEW_ADMIN_NISM_CERTI_EXP_DATE	pNISMCertiResp;
	struct VIEW_COMMON_HDR_RESP     pNISMCertiHdrResp;


	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            sSelQry[MAX_QUERY_SIZE];
	memset(sSelQry,'\0',MAX_QUERY_SIZE);
	CHAR            sWhereCls[MAX_QUERY_SIZE];
	memset(sWhereCls,'\0',MAX_QUERY_SIZE);

	LONG32  iNoOfRec = 0;
	LONG32  iRelayID = 0;
	LONG32  iNoOfPkt= 0;
	LONG32  iTempNoOfRec= 0;
	DOUBLE64	fNoOfRec = 0.00;


	pViewNISMCertiReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	logDebug2("pViewNISMCertiReq->sEntityId :%s:",pViewNISMCertiReq->sEntityId);
	logDebug2("pViewNISMCertiReq->sDealerId	:%s:",pViewNISMCertiReq->sDealerId);
	logDebug2("pViewNISMCertiReq->sDateTime	:%s:",pViewNISMCertiReq->sDateTime);

	if(strncmp(pViewNISMCertiReq->sDealerId,"-1",ENTITY_ID_LEN) != 0)
	{
		sprintf(sWhereCls," AND ENTITY_CODE = \"%s\" ",pViewNISMCertiReq->sDealerId);
	}
	else
	{
		sprintf(sWhereCls," ");
	}

	sprintf(sSelQry,"SELECT  ENTITY_LIS_EXP_DATE,ENTITY_NAME,IFNULL(ENTITY_EMAIL,\"NA\"),IFNULL(ENTITY_PHONE,\"NA\"),ifNULL(ENTITY_MOBILE,\"NA\"),\
			ENTITY_CODE FROM ENTITY_MASTER S WHERE  \
			S.ENTITY_TYPE = 'D'  AND S.ENTITY_LIS_EXP_DATE <= STR_TO_DATE(\"%s\",\'%%d-%%m-%%Y\') %s;",pViewNISMCertiReq->sDateTime,sWhereCls);

	logDebug1("sSelQry :%s:",sSelQry);

	if(mysql_query(DBQury,sSelQry) != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("Error in Query");
		return FALSE;
	}

	iNoOfRec = mysql_num_rows(DBQury);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pNISMCertiHdrResp.IntRespHeader.iSeqNo = 0;
	pNISMCertiHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pNISMCertiHdrResp.IntRespHeader.iErrorId = 0;
	pNISMCertiHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_NISM_CERT_HDR_RES;
	pNISMCertiHdrResp.IntRespHeader.iUserId = pViewNISMCertiReq->ReqHeader.iUserId;
	pNISMCertiHdrResp.IntRespHeader.cSource = pViewNISMCertiReq->ReqHeader.cSource;

	pNISMCertiHdrResp.cMsgType = 'H';
	pNISMCertiHdrResp.iNoofRec = iNoOfRec;

	logDebug1(" pNISMCertiHdrResp.cMsgType :%c:,pNISMCertiHdrResp.iNoofRec :%d:",pNISMCertiHdrResp.cMsgType,pNISMCertiHdrResp.iNoofRec);
	logDebug2("pViewNISMCertiReq->ReqHeader.iUserId = %llu",pViewNISMCertiReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pViewNISMCertiReq->ReqHeader.iUserId);

	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pNISMCertiHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}
	logDebug2("iNoOfRec :%d:",iNoOfRec);
	/**
	  if(iNoOfRec == 1)
	  {
	 **/
	Res = mysql_store_result(DBQury);


	for(i=0;i<iNoOfPkt;i++)
	{
		pNISMCertiResp.pResHeader.iSeqNo = 0;
		pNISMCertiResp.pResHeader.iMsgLength = sizeof(struct VIEW_ADMIN_NISM_CERTI_EXP_DATE);
		pNISMCertiResp.pResHeader.iErrorId = 0;
		pNISMCertiResp.pResHeader.iMsgCode = TC_INT_ADMIN_NISM_CERT_RES;
		pNISMCertiResp.pResHeader.iUserId = pViewNISMCertiReq->ReqHeader.iUserId;
		pNISMCertiResp.pResHeader.cSource = pViewNISMCertiReq->ReqHeader.cSource;
		for(j=0;j<5;j++)
		{	

			if(Row = mysql_fetch_row(Res))
			{

				if(iTempNoOfRec <= 1)
				{
					pNISMCertiResp.cMsgType = 'T';
				}
				else
				{
					pNISMCertiResp.cMsgType = 'D';
				}

				strncpy(pNISMCertiResp.subNISMCerti[j].sDealerId,Row[5],ENTITY_ID_LEN);
				strncpy(pNISMCertiResp.subNISMCerti[j].sExpiryDate,Row[0],DATE_TIME_LEN);
				if(strlen(Row[1]) > 0)
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sDealerName,Row[1],CLIENT_NAME_LEN);
				}
				else
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sDealerName,NOT_AVAILABLE,CLIENT_NAME_LEN);
				}

				if(strlen(Row[2]) > 0)
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sEmailAddr,Row[2],EMAIL_ADDR_LEN);
				}
				else
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sEmailAddr,NOT_AVAILABLE,EMAIL_ADDR_LEN);
				}

				if(strlen(Row[3]) > 0)
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sMobileNum,Row[3],MOBILE_LEN);
				}
				else
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sMobileNum,NOT_AVAILABLE,MOBILE_LEN);
				}

				if(strlen(Row[4]) > 0)
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sExpiryDate,Row[3],MOBILE_LEN);
				}
				else
				{
					strncpy(pNISMCertiResp.subNISMCerti[j].sExpiryDate,NOT_AVAILABLE,MOBILE_LEN);
				}	
			}
			iTempNoOfRec--;
		}
		if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pNISMCertiResp,sizeof(struct VIEW_ADMIN_NISM_CERTI_EXP_DATE) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}


	}


	logTimestamp("EXIT [fNISMNotifier]");
	return TRUE;
}

BOOL    fSIPOrderBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrderBook");

	struct	VIEW_SIP_ADMIN_ORDER_BOOK_REQ		*pOrdBookReq;
	struct	VIEW_SIP_ADMIN_ORDER_BOOK_RESP		pOrdBookResp;	
	struct 	VIEW_COMMON_HDR_RESP             	pOrdBookHedResp;

	CHAR    sSIPOrdBkQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSIPSubOrdBKQry[QUERY_SIZE];

	pOrdBookReq = (struct VIEW_SIP_ADMIN_ORDER_BOOK_REQ *)RcvMsg;

	CHAR            sWhere_Clause[QUERY_SIZE];
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdBkQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	logDebug2("pOrdBookReq->ReqHeader.sExcgId = :%s:",pOrdBookReq->ReqHeader.sExcgId);
	logDebug2("pOrdBookReq->ReqHeader.cSegment = :%c:",pOrdBookReq->ReqHeader.cSegment);
	logDebug2("pOrdBookReq->ReqHeader.iUserId = :%llu:",pOrdBookReq->ReqHeader.iUserId);
	logDebug2("pOrdBookReq->sSymbol = :%s:",pOrdBookReq->sSymbol);
	logDebug2("pOrdBookReq->sStatus = :%s:",pOrdBookReq->sStatus);
	logDebug2("pOrdBookReq->sStartDate = :%s:",pOrdBookReq->sStartDate);
	logDebug2("pOrdBookReq->sExpiry = :%s:",pOrdBookReq->sExpiryDate);
	logDebug2("pOrdBookReq->cProduct = :%c:",pOrdBookReq->cProduct);
	logDebug2("pOrdBookReq->sClientId = :%s:",pOrdBookReq->sClientId);
	logDebug2("pOrdBookReq->sPlacedBy = :%s:",pOrdBookReq->sPlacedBy);
	logDebug2("pOrdBookReq->sEntityId = :%s:",pOrdBookReq->sEntityId);
	logDebug2("pOrdBookReq->sSource = :%s:",pOrdBookReq->sSource);

	BOOL    iChkBrcnh = FALSE;
	CHAR    sBrchId[BRANCH_ID_LEN];
	memset(sBrchId,'\0',BRANCH_ID_LEN);

	CHAR    sBrchClaus[QUERY_SIZE];
	memset(sBrchClaus,'\0',QUERY_SIZE);
	iChkBrcnh = fChckAdminContrlr(pOrdBookReq->sEntityId,&sBrchId);

	if(iChkBrcnh == TRUE)
	{
		sprintf(sBrchClaus ," AND CLIENT_ID in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
	}
	else
	{
		sprintf(sBrchClaus ," ");
	}

	logDebug2(" sBrchClaus :%s:",sBrchClaus);

	if(strcmp(pOrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND EXCH = \"%s\"",pOrdBookReq->ReqHeader.sExcgId);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	/*        if(pOrdBookReq->ReqHeader.cSegment != SEL_ALL)
		  {
		  memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		  sprintf(sSIPSubOrdBKQry," AND SEGMENT = \'%c\'",pOrdBookReq->ReqHeader.cSegment);
		  logDebug2("sSIPSubOrdBKQry= %s",sSIPSubOrdBKQry);
		  strcat(sWhere_Clause,sSIPSubOrdBKQry);
		  logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
		  }*/
	if(strcmp(pOrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pOrdBookReq->sSymbol);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStatus,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND STATUS = \"%s\"",pOrdBookReq->sStatus);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStartDate,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sStartDate = %s",pOrdBookReq->sStartDate);
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND DATE (START_DATE_TIME) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sStartDate);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sExpiryDate,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sExpiryDate = %s",pOrdBookReq->sExpiryDate);
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND DATE (END_DATE_TIME) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sExpiryDate);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(pOrdBookReq->cProduct != SEL_ALL)
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		if(pOrdBookReq->cProduct == PROD_INTRADAY )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_INTRADAY);
		if(pOrdBookReq->cProduct == PROD_MARGIN )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_MARGIN);
		if(pOrdBookReq->cProduct == PROD_CNC )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_CNC);

		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);

	}
	if(strcmp(pOrdBookReq->sClientId,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND CLIENT_ID LIKE \"%s\"",pOrdBookReq->sClientId);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sPlacedBy,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND ENTITY_ID LIKE \"%s\"",pOrdBookReq->sPlacedBy);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause8 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSource,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND SOURCE_FLG = \"%s\"",pOrdBookReq->sSource);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause9 = %s",sWhere_Clause);
	}
	logDebug2("Final Where_Clause = %s",sWhere_Clause);	

	logDebug2("&&&&&&&&&&&&&&");
	sprintf(sSIPOrdBkQry,"SELECT CLIENT_ID, ORDER_NUMBER, EXCH, ORDER_DATE_TIME, START_DATE_TIME, END_DATE_TIME, FREQUENCY, \
			BUY_SELL, PRODUCT, SEGMENT, SCRIP_CODE, SYMBOL, PERIOD, TOTAL_QTY, ENTITY_ID, SOURCE_FLG, STATUS, ORDER_VALIDITY, \
			REASON_DESCRIPTION, USER_TYPE,SERIAL_NO,LAST_TRIGGER_DATE,NEXT_TRIGGER_DATE, \
			PAN_NO,PARTICIPANT_TYPE,SETTLOR,MKT_PROTECT_FLG,MKT_PROTECT_VAL,GTC_FLG,ENCASH_FLG,AMOUNT \
			FROM (SELECT `SIP_CLIENT_ID` AS `CLIENT_ID`,`SIP_ORDER_NO` AS `ORDER_NUMBER`,`SIP_EXCH_ID` AS `EXCH`,\
			DATE_FORMAT(`SIP_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`,DATE_FORMAT(`SIP_START_DATE`, '%%Y-%%m-%%d %%T') AS `START_DATE_TIME`,\
			DATE_FORMAT(`SIP_EXPIRE_DATE`, '%%Y-%%m-%%d %%T') AS `END_DATE_TIME`, (CASE `SIP_FREQUENCY` WHEN 'D' THEN 'Daily' WHEN 'W' THEN 'Weekly'\
			WHEN 'M' THEN 'Monthly' END) AS `FREQUENCY`,(CASE `SIP_BUY_SELL_IND` WHEN 'B' THEN 'SIP' WHEN 'S' THEN 'SWP' END) AS `BUY_SELL`,\
			(CASE `SIP_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'I' THEN 'INTRADAY' WHEN 'M' THEN 'MARGIN' END) AS `PRODUCT`\
			,`SIP_SEGMENT` AS `SEGMENT`,`SIP_SCRIP_CODE` AS `SCRIP_CODE`,`SIP_SYMBOL` AS `SYMBOL`,`SIP_PERIOD` AS `PERIOD`,\
			`SIP_TOTAL_QTY` AS `TOTAL_QTY`,`SIP_ENTITY_ID` AS `ENTITY_ID`,(CASE `SIP_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' WHEN 'W' THEN 'WEB' WHEN 'A' THEN 'ADMIN'\
			WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' WHEN 'H' THEN 'HELPDESK' WHEN 'E' THEN 'EXCHANGE' WHEN 'I' THEN 'ITS'\
			END) AS `SOURCE_FLG`,(CASE WHEN (`SIP_MSG_CODE` IN ('3000' , '3040')) THEN 'CONFIRM' WHEN (`SIP_MSG_CODE` = '3050') THEN 'CANCELLED'\
			WHEN (`SIP_MSG_CODE` = '3030') THEN 'PAUSED' END) AS `STATUS`,(CASE `SIP_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO'\
			WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS `ORDER_VALIDITY`,ifnull(nullif(`SIP_REASON_DESCRIPTION`,''),'NA') AS `REASON_DESCRIPTION`,\
			(CASE `SIP_USER_TYPE` WHEN 'C' THEN 'Client' WHEN 'D' THEN 'Dealer' WHEN 'A' THEN 'Admin' WHEN 'S' THEN 'Super Admin' END )AS `USER_TYPE`, \
			`SIP_SERIAL_NO` AS `SERIAL_NO`,ifnull(nullif(DATE_FORMAT(`SIP_LTD`,'%%Y-%%m-%%d %%T'),''),'NA') AS `LAST_TRIGGER_DATE`,\
			(CASE WHEN (`SIP_MSG_CODE` = '3030') THEN 'NA' WHEN (`SIP_MSG_CODE` = '3050') THEN 'NA' \
			 ELSE IFNULL(NULLIF(DATE_FORMAT(`SIP_NTD`,'%%Y-%%m-%%d %%T'), ''), 'NA') END) AS `NEXT_TRIGGER_DATE`, \
			`SIP_PAN_NO` AS `PAN_NO` ,`SIP_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`SIP_SETTLOR` AS `SETTLOR`, \
			`SIP_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,`SIP_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,\
			`SIP_GTC_FLG` AS `GTC_FLG`, `SIP_ENCASH_FLG` AS `ENCASH_FLG`,`SIP_AMOUNT` AS `AMOUNT` \ 
			FROM SIP_ORDERS AS `A` WHERE A.SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO) FROM SIP_ORDERS B WHERE B.SIP_ORDER_NO = A.SIP_ORDER_NO)) AS SipOrderBook \
			WHERE 1=1 %s %s ORDER BY ORDER_DATE_TIME DESC; ",sBrchClaus,sWhere_Clause);

	printf("sSIPOrdBkQry = %s",sSIPOrdBkQry);	

	if(mysql_query(DBQury,sSIPOrdBkQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdBkQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdBookHedResp.IntRespHeader.iSeqNo = 0;
	pOrdBookHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdBookHedResp.IntRespHeader.iErrorId = 0;
	pOrdBookHedResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SIP_ORDER_BOOK_HED_RESP;
	pOrdBookHedResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
	pOrdBookHedResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;
	pOrdBookHedResp.cMsgType = 'H';
	pOrdBookHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgLength = %d",pOrdBookHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgCode = %d",pOrdBookHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdBookHedResp.IntRespHeader.iUserId = %llu",pOrdBookHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdBookHedResp.IntRespHeader.cSource = %c",pOrdBookHedResp.IntRespHeader.cSource);
	logDebug2("pOrdBookHedResp.iNoofRec = %d",pOrdBookHedResp.iNoofRec);

	logDebug2("pOrdBookReq->ReqHeader.iUserId = %llu",pOrdBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pOrdBookHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdBookResp,'\0',sizeof(struct VIEW_SIP_ADMIN_ORDER_BOOK_RESP));
		pOrdBookResp.IntRespHeader.iSeqNo = 0;
		pOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ADMIN_ORDER_BOOK_RESP);
		pOrdBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SIP_ORD_BOOK_RESP;
		pOrdBookResp.IntRespHeader.iErrorId = 0;
		pOrdBookResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
		pOrdBookResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;

		logDebug2("pOrdBookResp.IntRespHeader.cSource = %c",pOrdBookResp.IntRespHeader.cSource);		

		if(iTempNoOfRec <= 1)
		{
			pOrdBookResp.cMsgType = 'T';
		}
		else
		{
			pOrdBookResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrdBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				pOrdBookResp.suborderbook[j].fOrderNo = atof(Row[1]);
				strncpy(pOrdBookResp.suborderbook[j].sExcgId,Row[2] ,EXCHANGE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sInternalDate,Row[3] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sStartDate,Row[4] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sStartEnd,Row[5] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sfrequency,Row[6] ,FREQUENCY_LEN);
				memset(pOrdBookResp.suborderbook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sBuySellInd,Row[7],BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sProduct,Row[8] ,PRODUCT_LEN);
				pOrdBookResp.suborderbook[j].cSegment = Row[9][0];
				strncpy(pOrdBookResp.suborderbook[j].sSecurityID,Row[10] ,SECURITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sSymbol,Row[11] ,DB_SYMBOL_LEN);
				pOrdBookResp.suborderbook[j].iForPeriod = atoi(Row[12]);
				pOrdBookResp.suborderbook[j].fQty = atof(Row[13]);
				strncpy(pOrdBookResp.suborderbook[j].sEntityId , Row[14],ENTITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sSourceFlg, Row[15],SOURCE_FLG_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sStatus,Row[16],ORDER_STATUS);
				strncpy(pOrdBookResp.suborderbook[j].sValidity,Row[17] ,VALIDITY_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sReasonDesc, Row[18],DB_REASON_DESC_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sUserType,Row[19],USER_TYPE_LEN);
				pOrdBookResp.suborderbook[j].iSerialNo = atoi(Row[20]);
				strncpy(pOrdBookResp.suborderbook[j].sLastTriggerDate,Row[21],USER_TYPE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sNextTriggerDate,Row[22],USER_TYPE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sPanID,Row[23],INT_PAN_LEN);
				pOrdBookResp.suborderbook[j].cParticipantType = Row[24][0];
				strncpy(pOrdBookResp.suborderbook[j].sSettlor,Row[25],SETTLOR_LEN);
				pOrdBookResp.suborderbook[j].cMarkProFlag = Row[26][0];
				pOrdBookResp.suborderbook[j].fMarkProVal = atof(Row[27]);
				pOrdBookResp.suborderbook[j].cGTCFlag = Row[28][0];
				pOrdBookResp.suborderbook[j].cEncashFlag = Row[29][0];
				pOrdBookResp.suborderbook[j].fPrice = atof(Row[30]);

				logDebug2("pOrdBookResp.suborderbook[%d].sClientId = %s",j,pOrdBookResp.suborderbook[j].sClientId);
				logDebug2("pOrdBookResp.suborderbook[%d].fOrderNo = %lf",j,pOrdBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sExcgId = %s",j,pOrdBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrdBookResp.suborderbook[%d].sInternalDate = %s",j,pOrdBookResp.suborderbook[j].sInternalDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sStartDate = %s",j,pOrdBookResp.suborderbook[j].sStartDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sStartEnd = %s",j,pOrdBookResp.suborderbook[j].sStartEnd);
				logDebug2("pOrdBookResp.suborderbook[%d].sfrequency = %s",j,pOrdBookResp.suborderbook[j].sfrequency);
				logDebug2("pOrdBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrdBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdBookResp.suborderbook[%d].sProduct = %s",j,pOrdBookResp.suborderbook[j].sProduct);
				logDebug2("pOrdBookResp.suborderbook[%d].cSegment = %c",j,pOrdBookResp.suborderbook[j].cSegment);
				logDebug2("pOrdBookResp.suborderbook[%d].sSecurityID = %s",j,pOrdBookResp.suborderbook[j].sSecurityID);
				logDebug2("pOrdBookResp.suborderbook[%d].sSymbol = %s",j,pOrdBookResp.suborderbook[j].sSymbol);
				logDebug2("pOrdBookResp.suborderbook[%d].iForPeriod = %d",j,pOrdBookResp.suborderbook[j].iForPeriod);
				logDebug2("pOrdBookResp.suborderbook[%d].fQty = %d",j,pOrdBookResp.suborderbook[j].fQty);
				logDebug2("pOrdBookResp.suborderbook[%d].sEntityId = %s",j,pOrdBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrdBookResp.suborderbook[%d].sSourceFlg = %s",j,pOrdBookResp.suborderbook[j].sSourceFlg);
				logDebug2("pOrdBookResp.suborderbook[%d].sStatus = %s",j,pOrdBookResp.suborderbook[j].sStatus);
				logDebug2("pOrdBookResp.suborderbook[%d].sValidity = %s",j,pOrdBookResp.suborderbook[j].sValidity);
				logDebug2("pOrdBookResp.suborderbook[%d].sReasonDesc = %s",j,pOrdBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrdBookResp.suborderbook[%d].sUserType = %s",j,pOrdBookResp.suborderbook[j].sUserType);
				logDebug2("pOrdBookResp.suborderbook[%d].iSerialNo = %d",j,pOrdBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sLastTriggerDate = %s",j,pOrdBookResp.suborderbook[j].sLastTriggerDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sNextTriggerDate = %s",j,pOrdBookResp.suborderbook[j].sNextTriggerDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sPanID = %s",j,pOrdBookResp.suborderbook[j].sPanID);
				logDebug2("pOrdBookResp.suborderbook[%d].cParticipantType = %c",j,pOrdBookResp.suborderbook[j].cParticipantType);
				logDebug2("pOrdBookResp.suborderbook[%d].sSettlor = %s",j,pOrdBookResp.suborderbook[j].sSettlor);
				logDebug2("pOrdBookResp.suborderbook[%d].cMarkProFlag = %c",j,pOrdBookResp.suborderbook[j].cMarkProFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrdBookResp.suborderbook[j].fMarkProVal);
				logDebug2("pOrdBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrdBookResp.suborderbook[j].cGTCFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrdBookResp.suborderbook[j].cEncashFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fPrice = %lf",j,pOrdBookResp.suborderbook[j].fPrice);
			}

		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pOrdBookResp,sizeof(struct VIEW_SIP_ADMIN_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}

		iTempNoOfRec--;
		//	usleep(5000);
	}

	logTimestamp("Exit : fSIPOrderBook");
	return TRUE;
}


BOOL	fSIPOrderDetails(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrderDetails");

	struct  VIEW_SIP_ADMIN_ORDER_DETAILS_REQ	*pOrdDetlsReq;
	struct  VIEW_SIP_ADMIN_ORDER_BOOK_RESP          pOrdDetlsResp;
	struct  VIEW_COMMON_HDR_RESP                    pOrdDetlsHedResp;

	CHAR    sSIPOrdDetlsQry[DOUBLE_MAX_QUERY_SIZE];

	pOrdDetlsReq = (struct VIEW_SIP_ADMIN_ORDER_DETAILS_REQ *)RcvMsg;

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdDetlsQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	logDebug2("pOrdDetlsReq->fOrderNo = %lf",pOrdDetlsReq->fOrderNo);
	logDebug2("pOrdDetlsReq->sClientId = %s",pOrdDetlsReq->sClientId);

	sprintf(sSIPOrdDetlsQry,"SELECT `SIP_CLIENT_ID` AS `CLIENT_ID`,`SIP_ORDER_NO` AS `ORDER_NUMBER`,`SIP_EXCH_ID` AS `EXCH`,\
			DATE_FORMAT(`SIP_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`,\
			DATE_FORMAT(`SIP_START_DATE`, '%%Y-%%m-%%d %%T') AS `START_DATE_TIME`,\
			DATE_FORMAT(`SIP_EXPIRE_DATE`, '%%Y-%%m-%%d %%T') AS `END_DATE_TIME`,(CASE `SIP_FREQUENCY` WHEN 'D' THEN 'Daily' \
				WHEN 'W' THEN 'Weekly' WHEN 'M' THEN 'Monthly' END) AS `FREQUENCY`,(CASE `SIP_BUY_SELL_IND` WHEN 'B' THEN 'SIP'\
					WHEN 'S' THEN 'SWP' END) AS `BUY_SELL`,(CASE `SIP_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'I' THEN 'INTRADAY'\
						WHEN 'M' THEN 'MARGIN' END) AS `PRODUCT`,`SIP_SEGMENT` AS `SEGMENT`,\
			`SIP_SCRIP_CODE` AS `SCRIP_CODE`,`SIP_SYMBOL` AS `SYMBOL`,`SIP_PERIOD` AS `PERIOD`,`SIP_TOTAL_QTY` AS `TOTAL_QTY`,\
			`SIP_ENTITY_ID` AS `ENTITY_ID`,(CASE `SIP_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' WHEN 'W' THEN 'WEB' WHEN 'A' THEN 'ADMIN'\
			WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' WHEN 'H' THEN 'HELPDESK' WHEN 'E' THEN 'EXCHANGE'\
			WHEN 'I' THEN 'ITS' END) AS `SOURCE_FLG`,(CASE WHEN (`SIP_MSG_CODE` IN ('3000' , '3040')) THEN 'CONFIRM'\
			WHEN (`SIP_MSG_CODE` = '3050') THEN 'CANCELLED' WHEN (`SIP_MSG_CODE` = '3030') THEN 'PAUSED' END) AS `STATUS`,\
			(CASE `SIP_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' WHEN '3' THEN 'IOC'\
			 ELSE 'EOS' END) AS `ORDER_VALIDITY`,IFNULL(NULLIF(`SIP_REASON_DESCRIPTION`, ''), 'NA') AS `REASON_DESCRIPTION`,\
			(CASE `SIP_USER_TYPE` WHEN 'C' THEN 'Client' WHEN 'D' THEN 'Dealer' WHEN 'A' THEN 'Admin' WHEN 'S' THEN 'Super Admin'\
			 END) AS `USER_TYPE`,`SIP_SERIAL_NO` AS `SERIAL_NO`,`SIP_AMOUNT` AS `AMOUNT` FROM SIP_ORDERS AS `A` \
			WHERE SIP_CLIENT_ID = \"%s\" AND SIP_ORDER_NO = %lf \
			ORDER BY ORDER_DATE_TIME ASC;",pOrdDetlsReq->sClientId,pOrdDetlsReq->fOrderNo);

	logDebug2("sSIPOrdDetlsQry = %s",sSIPOrdDetlsQry);

	if(mysql_query(DBQury,sSIPOrdDetlsQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdDetlsQry.");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdDetlsHedResp.IntRespHeader.iSeqNo = 0;
	pOrdDetlsHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdDetlsHedResp.IntRespHeader.iErrorId = 0;
	pOrdDetlsHedResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SIP_ORDER_DETS_HED_RESP;
	pOrdDetlsHedResp.IntRespHeader.iUserId = pOrdDetlsReq->ReqHeader.iUserId;
	pOrdDetlsHedResp.IntRespHeader.cSource = pOrdDetlsReq->ReqHeader.cSource;
	pOrdDetlsHedResp.cMsgType = 'H';
	pOrdDetlsHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdDetlsHedResp.IntRespHeader.iMsgLength = %d",pOrdDetlsHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdDetlsHedResp.IntRespHeader.iMsgCode = %d",pOrdDetlsHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdDetlsHedResp.IntRespHeader.iUserId = %llu",pOrdDetlsHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdDetlsHedResp.IntRespHeader.cSource = %c",pOrdDetlsHedResp.IntRespHeader.cSource);
	logDebug2("pOrdDetlsHedResp.iNoofRec = %d",pOrdDetlsHedResp.iNoofRec);

	logDebug2("pOrdDetlsReq->ReqHeader.iUserId = %llu",pOrdDetlsReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pOrdDetlsReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pOrdDetlsHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		//return FALSE;
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdDetlsResp,'\0',sizeof(struct VIEW_SIP_ADMIN_ORDER_BOOK_RESP));
		pOrdDetlsResp.IntRespHeader.iSeqNo = 0;
		pOrdDetlsResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ADMIN_ORDER_BOOK_RESP);
		pOrdDetlsResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SIP_ORDER_DETS_RESP;
		pOrdDetlsResp.IntRespHeader.iErrorId = 0;
		pOrdDetlsResp.IntRespHeader.iUserId = pOrdDetlsReq->ReqHeader.iUserId;
		pOrdDetlsResp.IntRespHeader.cSource = pOrdDetlsReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pOrdDetlsResp.cMsgType = 'T';
		}
		else
		{
			pOrdDetlsResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrdDetlsResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				pOrdDetlsResp.suborderbook[j].fOrderNo = atof(Row[1]);
				strncpy(pOrdDetlsResp.suborderbook[j].sExcgId,Row[2] ,EXCHANGE_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sInternalDate,Row[3] ,DATE_LENGTH);
				strncpy(pOrdDetlsResp.suborderbook[j].sStartDate,Row[4] ,DATE_LENGTH);
				strncpy(pOrdDetlsResp.suborderbook[j].sStartEnd,Row[5] ,DATE_LENGTH);
				strncpy(pOrdDetlsResp.suborderbook[j].sfrequency,Row[6] ,FREQUENCY_LEN);
				memset(pOrdDetlsResp.suborderbook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sBuySellInd,Row[7],BUY_SELL_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sProduct,Row[8] ,PRODUCT_LEN);
				pOrdDetlsResp.suborderbook[j].cSegment = Row[9][0];
				strncpy(pOrdDetlsResp.suborderbook[j].sSecurityID,Row[10] ,SECURITY_ID_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sSymbol,Row[11] ,DB_SYMBOL_LEN);
				pOrdDetlsResp.suborderbook[j].iForPeriod = atoi(Row[12]);
				pOrdDetlsResp.suborderbook[j].fQty = atof(Row[13]);
				strncpy(pOrdDetlsResp.suborderbook[j].sEntityId , Row[14],ENTITY_ID_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sSourceFlg, Row[15],SOURCE_FLG_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sStatus,Row[16],DB_STATUS_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sValidity,Row[17] ,VALIDITY_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sReasonDesc, Row[18],DB_REASON_DESC_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sUserType,Row[19],USER_TYPE_LEN);
				pOrdDetlsResp.suborderbook[j].iSerialNo = atoi(Row[20]);
				pOrdDetlsResp.suborderbook[j].fPrice = atof(Row[21]);

				logDebug2("pOrdDetlsResp.suborderbook[%d].sClientId = %s",j,pOrdDetlsResp.suborderbook[j].sClientId);
				logDebug2("pOrdDetlsResp.suborderbook[%d].fOrderNo = %lf",j,pOrdDetlsResp.suborderbook[j].fOrderNo);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sExcgId = %s",j,pOrdDetlsResp.suborderbook[j].sExcgId);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sInternalDate = %s",j,pOrdDetlsResp.suborderbook[j].sInternalDate);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sStartDate = %s",j,pOrdDetlsResp.suborderbook[j].sStartDate);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sStartEnd = %s",j,pOrdDetlsResp.suborderbook[j].sStartEnd);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sfrequency = %s",j,pOrdDetlsResp.suborderbook[j].sfrequency);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sBuySellInd = %s",j,pOrdDetlsResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sProduct = %s",j,pOrdDetlsResp.suborderbook[j].sProduct);
				logDebug2("pOrdDetlsResp.suborderbook[%d].cSegment = %c",j,pOrdDetlsResp.suborderbook[j].cSegment);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sSecurityID = %s",j,pOrdDetlsResp.suborderbook[j].sSecurityID);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sSymbol = %s",j,pOrdDetlsResp.suborderbook[j].sSymbol);
				logDebug2("pOrdDetlsResp.suborderbook[%d].iForPeriod = %d",j,pOrdDetlsResp.suborderbook[j].iForPeriod);
				logDebug2("pOrdDetlsResp.suborderbook[%d].fQty = %d",j,pOrdDetlsResp.suborderbook[j].fQty);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sEntityId = %s",j,pOrdDetlsResp.suborderbook[j].sEntityId);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sSourceFlg = %s",j,pOrdDetlsResp.suborderbook[j].sSourceFlg);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sStatus = %s",j,pOrdDetlsResp.suborderbook[j].sStatus);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sValidity = %s",j,pOrdDetlsResp.suborderbook[j].sValidity);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sReasonDesc = %s",j,pOrdDetlsResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sUserType = %s",j,pOrdDetlsResp.suborderbook[j].sUserType);
				logDebug2("pOrdDetlsResp.suborderbook[%d].iSerialNo = %d",j,pOrdDetlsResp.suborderbook[j].iSerialNo);
				logDebug2("pOrdDetlsResp.suborderbook[%d].fPrice = %lf",j,pOrdDetlsResp.suborderbook[j].fPrice);
			}

		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pOrdDetlsResp,sizeof(struct VIEW_SIP_ADMIN_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			//return FALSE;
			return FALSE;
		}

		iTempNoOfRec--;
		//	usleep(5000);
	}
	logTimestamp("Exit : fSIPOrderDetails");
	return TRUE;
}


BOOL  fCktHittingHolding(CHAR *RcvMsg)
{
	logTimestamp("Entry : fCktHittingHolding ");
	struct  VIEW_CLIENT_HOLD_REQ            *pClientHoldReq;
	struct  VIEW_ADMIN_CLIENT_HOLDINGS_RESP pClientHoldResp;
	struct  VIEW_COMMON_HDR_RESP            pClientHoldHdrResp;

	//      CHAR    *sClentHoldQry = malloc(sizeof(CHAR) * QUERY_SIZE);
	//        CHAR    *sHoldQry = malloc(sizeof(CHAR) * QUERY_SIZE);
	CHAR    sClentHoldQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sHoldQry[QUERY_SIZE];
	CHAR    sWhere_Clause[QUERY_SIZE];
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sClentHoldQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	pClientHoldReq = (struct  VIEW_CLIENT_HOLD_REQ *)RcvMsg;

	logDebug2("pClientHoldReq->ReqHeader.sExcgId = :%s:",pClientHoldReq->ReqHeader.sExcgId);
	logDebug2("pClientHoldReq->sSecuritySource = :%s:",pClientHoldReq->sSecuritySource);
	logDebug2("pClientHoldReq->sSymbol = :%s:",pClientHoldReq->sSymbol);
	logDebug2("pClientHoldReq->sClientId = :%s:",pClientHoldReq->sClientId);
	logDebug2("pClientHoldReq->sEntityId = :%s:",pClientHoldReq->sEntityId);

	if(strcmp(pClientHoldReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry," AND exch_id = \"%s\"",pClientHoldReq->ReqHeader.sExcgId);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(strcmp(pClientHoldReq->sSecuritySource,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry," AND security_source_type = \"%s\"",pClientHoldReq->sSecuritySource);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pClientHoldReq->sSymbol,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry," AND (nse_symbol = \"%s\" OR bse_symbol = \"%s\")",pClientHoldReq->sSymbol,pClientHoldReq->sSymbol);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(strcmp(pClientHoldReq->sClientId,SELECT_ALL))
	{
		memset(sHoldQry,'\0',QUERY_SIZE);
		sprintf(sHoldQry,"AND client_id like \"%s\"",pClientHoldReq->sClientId);
		logDebug2("sHoldQry = %s",sHoldQry);
		strcat(sWhere_Clause,sHoldQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	logDebug2("final client holding sWhere_Clause = %s",sWhere_Clause);

	sprintf(sClentHoldQry," SELECT    CAST(@rn:=@rn + 1 AS UNSIGNED) ROW_NUM, hld.* FROM   (SELECT    XX.*,     IFNULL(ROUND(ELW.L1_LTP, 2), 0) AS ltp,     TRIM(ROUND(((IFNULL(XX.QTY, 0) - IFNULL(XX.QTY_UTILIZED, 0)) * IFNULL(ELW.L1_LTP, 0)), 2)) AS market_value   FROM     (SELECT    RCSL.CLIENT_ID AS client_id,     RCSL.EXCH_ID AS exch_id,     RCSL.ISIN_CODE AS isin_code,     RCSL.SECURITY_SOURCE_TYPE AS security_source_type,     RCSL.QTY AS qty,     IFNULL(RCSL.QTY_UTILIZED, 0) AS qty_utilized,     (IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED, 0)) AS rem_qty, (IFNULL(RCSL.NSE_SCRIP_CODE, 'NA')) AS nse_scrip_code,     (IFNULL(RCSL.BSE_SCRIP_CODE, 'NA')) AS bse_scrip_code,     (IFNULL(RCSL.NSE_SYMBOL, 'NA')) AS nse_symbol,     (IFNULL(RCSL.BSE_SYMBOL, 'NA')) AS bse_symbol,     IFNULL(RCSL.COST_PRICE, 0) AS cost_price,     (CASE RCSL.COLLATERAL_FLAG       WHEN 'Y' THEN IFNULL(ROUND((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 100)) / 100), 2), 0) ELSE 0     END) AS COLLATERAL, (LWA.L1_LOWER_CKT+(LWA.L1_LOWER_CKT * 0.01)) as lower_alert, 			(LWA.L1_UPPER_CKT-(LWA.L1_UPPER_CKT * 0.01)) as upper_alert   FROM     RMS_CLIENT_SECURITY_LIMIT RCSL   LEFT JOIN HAIRCUT_MASTER HM ON RCSL.ISIN_CODE = HM.HM_ISIN   LEFT JOIN SECURITY_MASTER SM ON RCSL.ISIN_CODE = SM.SM_ISIN_CODE   LEFT JOIN EQ_L1_WATCH LWA ON SM.SM_SCRIP_CODE = LWA.L1_SCRIP_CODE    WHERE      1 = 1 %s AND (CASE RCSL.EXCH_ID     WHEN 'ALL' THEN 'NSE'     ELSE RCSL.EXCH_ID     END) = SM.SM_EXCHANGE     AND SM.SM_STATUS = 'A'     AND SM.SM_EXCH_STATUS = 'A') AS XX        LEFT OUTER JOIN EQ_L1_WATCH ELW ON (CASE     WHEN XX.EXCH_ID = 'NSE' THEN XX.NSE_SCRIP_CODE     WHEN XX.EXCH_ID = 'BSE' THEN XX.BSE_SCRIP_CODE     WHEN XX.EXCH_ID = 'ALL' THEN XX.NSE_SCRIP_CODE   END = ELW.L1_SCRIP_CODE)   WHERE ELW.L1_LTP<=XX.lower_alert OR ELW.L1_LTP>=XX.upper_alert      ORDER BY XX.CLIENT_ID) AS hld      CROSS JOIN   (SELECT @rn:=0) R;",sWhere_Clause);

	logDebug2("sClentHoldQry = %s",sClentHoldQry);

	if(mysql_query(DBQury,sClentHoldQry) != SUCCESS)
	{
		logSqlFatal("Error in ClentHoldQry");
		sql_Error(DBQury);
		//return FALSE;
		return FALSE;
	}
	Res = mysql_store_result(DBQury);

	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;

	pClientHoldHdrResp.IntRespHeader.iSeqNo = 0;
	pClientHoldHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pClientHoldHdrResp.IntRespHeader.iErrorId = 0;
	pClientHoldHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CKT_HITTING_HOLDING_HEADER_RESP ;
	pClientHoldHdrResp.IntRespHeader.iUserId = pClientHoldReq->ReqHeader.iUserId;
	pClientHoldHdrResp.IntRespHeader.cSource = pClientHoldReq->ReqHeader.cSource ;
	pClientHoldHdrResp.cMsgType = 'H';
	pClientHoldHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pClientHoldHdrResp.IntRespHeader.iMsgLength = %d",pClientHoldHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pClientHoldHdrResp.IntRespHeader.iMsgCode = %d",pClientHoldHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pClientHoldHdrResp.IntRespHeader.iUserId = %llu",pClientHoldHdrResp.IntRespHeader.iUserId);
	logDebug2("pClientHoldHdrResp.IntRespHeader.cSource = %c",pClientHoldHdrResp.IntRespHeader.cSource);
	logDebug2("pClientHoldHdrResp.iNoofRec = %d",pClientHoldHdrResp.iNoofRec);

	logDebug2("pClientHoldReq->ReqHeader.iUserId = %llu",pClientHoldReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pClientHoldReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pClientHoldHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No of Pkt (i) = %d",i);

		memset(&pClientHoldResp,'\0',sizeof(struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP));
		pClientHoldResp.IntRespHeader.iSeqNo = 0;
		pClientHoldResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP);
		logDebug2("...pClientHoldResp.IntRespHeader.iMsgLength = %d",pClientHoldResp.IntRespHeader.iMsgLength);
		pClientHoldResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CKT_HITTING_HOLDING_RESP;
		pClientHoldResp.IntRespHeader.iErrorId = 0;
		pClientHoldResp.IntRespHeader.iUserId = pClientHoldReq->ReqHeader.iUserId;
		pClientHoldResp.IntRespHeader.cSource = pClientHoldReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pClientHoldResp.cMsgType = 'T';
		}
		else
		{
			pClientHoldResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			logDebug2("No of row in pkt (j) = %d",j);
			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(pClientHoldResp.subClientHoldings[j].sNseSecurityID,Row[8],SECURITY_ID_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sBseSecurityID,Row[9],SECURITY_ID_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sISINCode,Row[3],ISINCODE_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sSecuritySource,Row[4],SEC_SOURCE_LEN);
				pClientHoldResp.subClientHoldings[j].iQty = atoi(Row[5]);
				pClientHoldResp.subClientHoldings[j].iQtyUtilized = atoi(Row[6]);
				pClientHoldResp.subClientHoldings[j].iRemQty = atoi(Row[7]);
				strncpy(pClientHoldResp.subClientHoldings[j].sExcgId,Row[2],EXCHANGE_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sNseSymbol,Row[10],SECURITY_SYM_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sBseSymbol,Row[11],SECURITY_SYM_LEN);
				strncpy(pClientHoldResp.subClientHoldings[j].sClientId,Row[1],CLIENT_ID_LEN);
				pClientHoldResp.subClientHoldings[j].fCostPrice = atof(Row[12]);
				pClientHoldResp.subClientHoldings[j].fCollateral = atof(Row[13]);
				pClientHoldResp.subClientHoldings[j].fLtp = atof(Row[14]);
				pClientHoldResp.subClientHoldings[j].fMarketValue = atof(Row[15]);

				logDebug2("pClientHoldResp.subClientHoldings[%d].sClientId = %s",j,pClientHoldResp.subClientHoldings[j].sClientId);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sExcgId = %s",j,pClientHoldResp.subClientHoldings[j].sExcgId);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sISINCode = %s",j,pClientHoldResp.subClientHoldings[j].sISINCode);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sSecuritySource= %s",j,pClientHoldResp.subClientHoldings[j].sSecuritySource);
				logDebug2("pClientHoldResp.subClientHoldings[%d].iQty = %d",j,pClientHoldResp.subClientHoldings[j].iQty);
				logDebug2("pClientHoldResp.subClientHoldings[%d].iQtyUtilized = %d",j,pClientHoldResp.subClientHoldings[j].iQtyUtilized);
				logDebug2("pClientHoldResp.subClientHoldings[%d].iRemQty = %d",j,pClientHoldResp.subClientHoldings[j].iRemQty);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fLtp = %lf",j,pClientHoldResp.subClientHoldings[j].fLtp);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fMarketValue = %lf",j,pClientHoldResp.subClientHoldings[j].fMarketValue);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sNseSecurityID = %s",j,pClientHoldResp.subClientHoldings[j].sNseSecurityID);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sBseSecurityID = %s",j,pClientHoldResp.subClientHoldings[j].sBseSecurityID);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sNseSymbol = %s",j,pClientHoldResp.subClientHoldings[j].sNseSymbol);
				logDebug2("pClientHoldResp.subClientHoldings[%d].sBseSymbol = %s",j,pClientHoldResp.subClientHoldings[j].sBseSymbol);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fCostPrice = %lf",j,pClientHoldResp.subClientHoldings[j].fCostPrice);
				logDebug2("pClientHoldResp.subClientHoldings[%d].fCollateral= %lf",j,pClientHoldResp.subClientHoldings[j].fCollateral);
				logDebug2("pClientHoldResp.cMsgType = %c",pClientHoldResp.cMsgType);
			}

		}

		if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pClientHoldResp,sizeof(struct VIEW_ADMIN_CLIENT_HOLDINGS_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
			return FALSE;
		}
		iTempNoOfRec--;
		//	usleep(5000);

	}

	logTimestamp("Exit : fCktHittingHolding ");
	return TRUE ;
}

BOOL    fCktHittingNetPosition(CHAR *RcvMsg)
{
	logTimestamp("Entry : fCktHittingNetPosition ");

	struct  VIEW_NET_POSITION_QRY           *pViewNetPosReq;
	struct  VIEW_ADMIN_NET_POSITION_RESP    pNetPosResp;
	struct  VIEW_COMMON_HDR_RESP            pNetPosHdrResp;

	pViewNetPosReq = (struct VIEW_NET_POSITION_QRY *)RcvMsg;
	CHAR    sNetPosQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sNetQry[QUERY_SIZE];
	CHAR    sWhere_Clause[QUERY_SIZE];

	memset(sNetPosQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	logDebug2("pViewNetPosReq->ReqHeader.sExcgId = %s",pViewNetPosReq->ReqHeader.sExcgId);
	logDebug2("pViewNetPosReq->ReqHeader.cSegment = %c",pViewNetPosReq->ReqHeader.cSegment);
	logDebug2("pViewNetPosReq->sPosition = %s",pViewNetPosReq->sPosition);
	logDebug2("pViewNetPosReq->sInstrument = %s",pViewNetPosReq->sInstrument);
	logDebug2("pViewNetPosReq->sSymbol = %s",pViewNetPosReq->sSymbol);
	logDebug2("pViewNetPosReq->cProduct = %c",pViewNetPosReq->cProduct);
	logDebug2("pViewNetPosReq->sClientID = %s",pViewNetPosReq->sClientID);
	logDebug2("pViewNetPosReq->sEntityId = %s",pViewNetPosReq->sEntityId);
	logDebug2("pViewNetPosReq->cNetQty = %c",pViewNetPosReq->cNetQty);

	if(strcmp(pViewNetPosReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND EXCH_ID = \"%s\"",pViewNetPosReq->ReqHeader.sExcgId);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pViewNetPosReq->ReqHeader.cSegment != SEL_ALL)
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND SEGMNT = \'%c\'",pViewNetPosReq->ReqHeader.cSegment);
		logDebug2("NetQry2 = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pViewNetPosReq->sPosition,SELECT_ALL))
	{
		if(strcmp(pViewNetPosReq->sPosition,DAY_POSITION))
		{
			memset(sNetQry,'\0',QUERY_SIZE);
			sprintf(sNetQry," AND REF_ID >= 0");
			logDebug2("sNetQry = %s",sNetQry);
			strcat(sWhere_Clause,sNetQry);
			logDebug2("sWhere_Clause3.. = %s",sWhere_Clause);
		}
		if(strcmp(pViewNetPosReq->sPosition,CARRY_POSITION))
		{
			memset(sNetQry,'\0',QUERY_SIZE);
			sprintf(sNetQry," AND REF_ID < 0");
			logDebug2("sNetQry = %s",sNetQry);
			strcat(sWhere_Clause,sNetQry);
			logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
		}

	}
	if(strcmp(pViewNetPosReq->sInstrument,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND INSTRUMENT = \"%s\"",pViewNetPosReq->sInstrument);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pViewNetPosReq->sSymbol,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pViewNetPosReq->sSymbol);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(pViewNetPosReq->cProduct != SEL_ALL)
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND PROD_ID = \"%c\"",pViewNetPosReq->cProduct);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);
	}
	if(strcmp(pViewNetPosReq->sClientID,SELECT_ALL))
	{
		memset(sNetQry,'\0',QUERY_SIZE);
		sprintf(sNetQry," AND CLIENT_ID LIKE \"%s\"",pViewNetPosReq->sClientID);
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
	}
	if(pViewNetPosReq->cNetQty != SEL_ALL)
	{
		logDebug2("&&&&&&");
		memset(sNetQry,'\0',QUERY_SIZE);
		if( pViewNetPosReq->cNetQty != NET_QTY)
		{       logDebug2("%c",pViewNetPosReq->cNetQty);
			sprintf(sNetQry," AND NET_QTY <> %d",FALSE);
		}
		else
		{
			sprintf(sNetQry," AND NET_QTY = %d",FALSE);
		}
		logDebug2("sNetQry = %s",sNetQry);
		strcat(sWhere_Clause,sNetQry);
		logDebug2("sWhere_Clause8 = %s",sWhere_Clause);
	}
	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	sprintf(sNetPosQry," SELECT    CLIENT_ID,   SECURITY_ID,   EXCH_ID,   MKT_TYPE,   TOT_BUY_QTY,   TOT_BUY_QTY_CF,   TOT_BUY_QTY_DAY,   TOT_BUY_VAL,   TOT_BUY_VAL_CF,   TOT_BUY_VAL_DAY,   BUY_AVG,   TOT_SELL_QTY,   TOT_SELL_QTY_CF,   TOT_SELL_QTY_DAY,   TOT_SELL_VAL,   TOT_SELL_VAL_CF,   TOT_SELL_VAL_DAY,   SELL_AVG,   NET_QTY,   CF_NET_QTY,   DAY_NET_QTY,   NET_VAL,   CF_NET_VAL,   DAY_NET_VAL,   NET_AVG,   CF_NET_AVG,   DAY_NET_AVG,   GROSS_QTY,   GROSS_VAL,   SEGMNT,   PROD_ID,   REALISED_PROFIT,   REF_ID,   CROSS_CUR_FLAG,   RBI_REFERENCE_RATE FROM   (SELECT    `MBNP`.`CLIENT_ID` AS `CLIENT_ID`,     `MBNP`.`SECURITY_ID` AS `SECURITY_ID`,     `MBNP`.`EXCH_ID` AS `EXCH_ID`,     `MBNP`.`SYMBOL` AS `SYMBOL`,     `MBNP`.`INSTRUMENT` AS `INSTRUMENT`,     `MBNP`.`EXPIRY_DATE` AS `EXPIRY_DATE`,     'NL' AS `MKT_TYPE`,     SUM(`MBNP`.`BUY_QTY`) AS `TOT_BUY_QTY`,     SUM(CASE `MBNP`.`INT_REF_ID`       WHEN - 1 THEN `MBNP`.`BUY_QTY`       ELSE 0     END) AS `TOT_BUY_QTY_CF`,     SUM(CASE `MBNP`.`INT_REF_ID`       WHEN 0 THEN `MBNP`.`BUY_QTY`       ELSE 0     END) AS `TOT_BUY_QTY_DAY`,     SUM(CASE       WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000       WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER       ELSE MBNP.BUY_VAL     END) AS TOT_BUY_VAL,     SUM(CASE MBNP.INT_REF_ID       WHEN         - 1       THEN         (CASE         WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000         WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER         ELSE MBNP.BUY_VAL         END)       ELSE 0     END) AS `TOT_BUY_VAL_CF`,     SUM(CASE `MBNP`.`INT_REF_ID`       WHEN         0       THEN         (CASE         WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000         WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER         ELSE MBNP.BUY_VAL         END)       ELSE 0     END) AS `TOT_BUY_VAL_DAY`,     ROUND((CASE       WHEN         (`MBNP`.`SEGMENT_CODE` = 'C')       THEN         ROUND((CASE SUM(`MBNP`.`BUY_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))         END), 4)       ELSE ROUND((CASE SUM(`MBNP`.`BUY_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))       END), 2)     END), 4) AS `BUY_AVG`,     SUM(`MBNP`.`SELL_QTY`) AS `TOT_SELL_QTY`,     SUM(CASE `MBNP`.`INT_REF_ID`       WHEN - 1 THEN `MBNP`.`SELL_QTY`       ELSE 0     END) AS `TOT_SELL_QTY_CF`,     SUM(CASE `MBNP`.`INT_REF_ID`       WHEN 0 THEN `MBNP`.`SELL_QTY`       ELSE 0     END) AS `TOT_SELL_QTY_DAY`,     ROUND(SUM(CASE       WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000       WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER       ELSE (MBNP.SELL_VAL)     END), 2) AS TOT_SELL_VAL,     ROUND(SUM(CASE MBNP.INT_REF_ID       WHEN         - 1       THEN         (CASE         WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000         WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER         ELSE MBNP.SELL_VAL         END)       ELSE 0     END), 2) AS `TOT_SELL_VAL_CF`,     ROUND(SUM(CASE `MBNP`.`INT_REF_ID`       WHEN         0       THEN         (CASE         WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000         WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER         ELSE (MBNP.SELL_VAL)         END)       ELSE 0     END), 2) AS `TOT_SELL_VAL_DAY`,     ROUND((CASE       WHEN         (`MBNP`.`SEGMENT_CODE` = 'C')       THEN         ROUND((CASE SUM(`MBNP`.`SELL_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))         END), 4)       ELSE ROUND((CASE SUM(`MBNP`.`SELL_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))       END), 2)     END), 4) AS `SELL_AVG`,     (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)) AS `NET_QTY`,     (CASE MBNP.INT_REF_ID       WHEN - 1 THEN SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)       ELSE 0     END) AS CF_NET_QTY,     (CASE MBNP.INT_REF_ID       WHEN 0 THEN SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)       ELSE 0     END) AS DAY_NET_QTY,     ROUND((CASE       WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)       WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)       ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))     END), 2) AS NET_VAL,     (CASE MBNP.INT_REF_ID       WHEN         - 1       THEN         ROUND((CASE         WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)         WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)         ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))         END), 2)       ELSE 0     END) AS CF_NET_VAL,     (CASE MBNP.INT_REF_ID       WHEN         - 1       THEN         ROUND((CASE         WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)         WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)         ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))         END), 2)       ELSE 0     END) AS DAY_NET_VAL,     (CASE       WHEN         (`MBNP`.`SEGMENT_CODE` = 'C')       THEN         ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))         WHEN 0 THEN 0         ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))         END), 4)       ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))         WHEN 0 THEN 0         ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))       END), 2)     END) AS `NET_AVG`,     (CASE MBNP.INT_REF_ID       WHEN         - 1       THEN         (CASE         WHEN           (`MBNP`.`SEGMENT_CODE` = 'C')         THEN           ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))             WHEN 0 THEN 0             ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))           END), 4)         ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))           WHEN 0 THEN 0           ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))         END), 2)         END)       ELSE 0     END) AS CF_NET_AVG,     (CASE MBNP.INT_REF_ID       WHEN         0       THEN         (CASE         WHEN           (`MBNP`.`SEGMENT_CODE` = 'C')         THEN           ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))             WHEN 0 THEN 0             ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))           END), 4)         ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))           WHEN 0 THEN 0           ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))         END), 2)         END)       ELSE 0     END) AS DAY_NET_AVG,     (SUM(`MBNP`.`BUY_QTY`) + SUM(`MBNP`.`SELL_QTY`)) AS `GROSS_QTY`,     ROUND((CASE       WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * 1000)       WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * MBNP.COMM_MULTIPLIER)       ELSE (SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL))     END), 2) AS GROSS_VAL,     MBNP.SEGMENT_CODE AS SEGMNT,     MBNP.PRODUCT AS PROD_ID,     (CASE       WHEN         (MBNP.SEGMENT_CODE = 'C')       THEN         (CASE         WHEN           `MBNP`.`CROSS_CUR_FLAG` = 'Y'         THEN           (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)             WHEN 0 THEN 0             ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))           END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)             WHEN 0 THEN 0             ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))           END), 4))), 4) * 1000 * `MBNP`.`RBI_REFERENCE_RATE`)         ELSE (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)           WHEN 0 THEN 0           ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))         END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)           WHEN 0 THEN 0           ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))         END), 4))), 4) * 1000)         END)       WHEN         (`MBNP`.`SEGMENT_CODE` = 'M')       THEN         (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))         END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))         END), 2))), 2) * 1)       ELSE ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))       END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)         WHEN 0 THEN 0         ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))       END), 2))), 2)     END) AS `REALISED_PROFIT`,     `MBNP`.`INT_REF_ID` AS `REF_ID`,     `MBNP`.`CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,     `MBNP`.`RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`   FROM     (SELECT    `DT`.`DRV_CLIENT_ID` AS `CLIENT_ID`,     `DT`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,     `DT`.`DRV_EXCH_ID` AS `EXCH_ID`,     `DT`.`DRV_SEGMENT` AS `SEGMENT_CODE`,     SUM((CASE       WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN `DT`.`DRV_TRD_TRADE_QTY`       ELSE 0     END)) AS `BUY_QTY`,     SUM((CASE       WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN ((`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`))       ELSE 0     END)) AS `BUY_VAL`,     SUM((CASE       WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN `DT`.`DRV_TRD_TRADE_QTY`       ELSE 0     END)) AS `SELL_QTY`,     SUM((CASE       WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)       ELSE 0     END)) AS `SELL_VAL`,     `DT`.`DRV_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,     `DT`.`DRV_SEGMENT` AS `EXCH_SEGMENT`,     `DT`.`DRV_PRODUCT_ID` AS `PRODUCT`,     `DT`.`DRV_CF_FLAG` AS `INT_REF_ID`,     SUBSTR(`DT`.`DRV_SYMBOL`, 1, 6) AS `SYMBOL`,     `DT`.`DRV_INSTRUMENT_NAME` AS `INSTRUMENT`,     `DT`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,     `DT`.`DRV_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,     `DT`.`DRV_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `DRV_ORDERS` `DT`   WHERE     ((`DT`.`DRV_TRD_STATUS` = 'C')     AND (`DT`.`DRV_MSG_CODE` = '2222'))   GROUP BY `DT`.`DRV_CLIENT_ID` , `DT`.`DRV_SCRIP_CODE` , `DT`.`DRV_EXCH_ID` , `DT`.`DRV_PRODUCT_ID` , `DT`.`DRV_SEGMENT` , `DT`.`DRV_CF_FLAG` UNION ALL SELECT    `T`.`EQ_CLIENT_ID` AS `EQ_CLIENT_ID`,     `T`.`EQ_SCRIP_CODE` AS `EQ_SCRIP_CODE`,     `T`.`EQ_EXCH_ID` AS `EQ_EXCH_ID`,     `T`.`EQ_SEGMENT` AS `SEGMENT_CODE`,     SUM((CASE       WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN `T`.`EQ_LAST_TRADE_QTY`       ELSE 0     END)) AS `BUY_QTY`,     SUM((CASE       WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)       ELSE 0     END)) AS `BUY_VAL`,     SUM((CASE       WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN `T`.`EQ_LAST_TRADE_QTY`       ELSE 0     END)) AS `SELL_QTY`,     SUM((CASE       WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)       ELSE 0     END)) AS `SELL_VAL`,     `T`.`EQ_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,     'E' AS `E`,     `T`.`EQ_PRODUCT_ID` AS `EQ_PRODUCT_ID`,     0 AS `INT_REF_ID`,     `T`.`EQ_SYMBOL` AS `SYMBOL`,     `T`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,     'NA' AS `EXPIRY`,     1 AS `RBI_REFERENCE_RATE`,     'N' AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `EQ_ORDERS` `T`   WHERE     ((`T`.`EQ_TRD_STATUS` = 'C')     AND (`T`.`EQ_MSG_CODE` = 2222))   GROUP BY `T`.`EQ_CLIENT_ID` , `T`.`EQ_SCRIP_CODE` , `T`.`EQ_EXCH_ID` , `T`.`EQ_PRODUCT_ID` UNION ALL SELECT    `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,     `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,     `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`       ELSE 0     END))) AS `BUY_QTY`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END))) AS `BUY_VAL`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`       ELSE 0     END))) AS `SELL_QTY`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END))) AS `SELL_VAL`,     '0' AS `SL_TRIGGER_PRICE`,     `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,     `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,     0 AS `0`,     `CD`.`RCCD_SYMBOL` AS `SYMBOL`,     `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,     'NA' AS `EXPIRY`,     `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,     `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `RMS_CLIENT_CONVT_TO_DEL` `CD`   GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT    `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,     `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,     `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`       ELSE 0     END)) AS `BUY_QTY`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END)) AS `BUY_VAL`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`       ELSE 0     END)) AS `SELL_QTY`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END)) AS `SELL_VAL`,     '0' AS `SL_TRIGGER_PRICE`,     `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,     `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,     0 AS `0`,     `CD`.`RCCD_SYMBOL` AS `SYMBOL`,     `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,     'NA' AS `EXPIRY`,     `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,     `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `RMS_CLIENT_CONVT_TO_DEL` `CD`   GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT    `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,     `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,     `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`       ELSE 0     END))) AS `BUY_QTY`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END))) AS `BUY_VAL`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`       ELSE 0     END))) AS `SELL_QTY`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END))) AS `SELL_VAL`,     '0' AS `SL_TRIGGER_PRICE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,     0 AS `0`,     `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,     `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,     `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,     `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,     `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`   GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT    `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,     `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,     `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`       ELSE 0     END)) AS `BUY_QTY`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END)) AS `BUY_VAL`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`       ELSE 0     END)) AS `SELL_QTY`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END)) AS `SELL_VAL`,     '0' AS `SL_TRIGGER_PRICE`,     `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,     `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,     0 AS `0`,     `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,     `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,     `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,     `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,     `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`   GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT    `MT`.`COMM_CLIENT_ID` AS `CLIENT_ID`,     `MT`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,     `MT`.`COMM_EXCH_ID` AS `EXCH_ID`,     `MT`.`COMM_SEGMENT` AS `SEGMENT_CODE`,     SUM((CASE       WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN `MT`.`COMM_TRD_TRADE_QTY`       ELSE 0     END)) AS `BUY_QTY`,     SUM((CASE       WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)       ELSE 0     END)) AS `BUY_VAL`,     SUM((CASE       WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN `MT`.`COMM_TRD_TRADE_QTY`       ELSE 0     END)) AS `SELL_QTY`,     SUM((CASE       WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)       ELSE 0     END)) AS `SELL_VAL`,     `MT`.`COMM_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,     `MT`.`COMM_SEGMENT` AS `EXCH_SEGMENT`,     `MT`.`COMM_PRODUCT_ID` AS `PRODUCT`,     `MT`.`COMM_CF_FLAG` AS `INT_REF_ID`,     SUBSTR(`MT`.`COMM_SYMBOL`, 1, 6) AS `SYMBOL`,     `MT`.`COMM_INSTRUMENT_NAME` AS `INSTRUMENT`,     `MT`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,     1 AS `RBI_REFERENCE_RATE`,     'N' AS `CROSS_CUR_FLAG`,     `MT`.`COMM_MULTIPLIER` AS `COMM_MULTIPLIER`   FROM     `COMM_ORDERS` `MT`   WHERE     ((`MT`.`COMM_TRD_STATUS` = 'C')     AND (`MT`.`COMM_MSG_CODE` = '2222'))   GROUP BY `MT`.`COMM_CLIENT_ID` , `MT`.`COMM_SCRIP_CODE` , `MT`.`COMM_EXCH_ID` , `MT`.`COMM_PRODUCT_ID` , `MT`.`COMM_SEGMENT` , `MT`.`COMM_CF_FLAG` UNION ALL SELECT    `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,     `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,     `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`       ELSE 0     END))) AS `BUY_QTY`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END))) AS `BUY_VAL`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`       ELSE 0     END))) AS `SELL_QTY`,     (-(1) * SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END))) AS `SELL_VAL`,     '0' AS `SL_TRIGGER_PRICE`,     `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,     `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,     0 AS `0`,     `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,     `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,     `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,     1 AS `RBI_REFERENCE_RATE`,     'N' AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`   GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT    `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,     `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,     `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,     `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`       ELSE 0     END)) AS `BUY_QTY`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END)) AS `BUY_VAL`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`       ELSE 0     END)) AS `SELL_QTY`,     SUM((CASE       WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)       ELSE 0     END)) AS `SELL_VAL`,     '0' AS `SL_TRIGGER_PRICE`,     `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,     `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,     0 AS `0`,     `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,     `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,     `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,     1 AS `RBI_REFERENCE_RATE`,     'N' AS `CROSS_CUR_FLAG`,     1 AS `COMM_MULTIPLIER`   FROM     `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`   GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT`) AS MBNP   GROUP BY `MBNP`.`CLIENT_ID` , `MBNP`.`SECURITY_ID` , `MBNP`.`EXCH_ID` , `MBNP`.`SEGMENT_CODE` , `MBNP`.`PRODUCT`) AS NP JOIN `L1_WATCH_ACTIVE` `MW`  ON (`NP`.`SECURITY_ID` = `MW`.`L1_SCRIP_CODE`)  WHERE `MW`.`L1_LTP`<=(`MW`.`L1_LOWER_CKT`+(`L1_LOWER_CKT`* 0.01 )) 		OR`MW`.`L1_LTP`>=(`MW`.`L1_UPPER_CKT`-(`L1_UPPER_CKT`* 0.01 ))     AND  1 = 1 %s AND NOT (NP.GROSS_QTY = 0     AND NP.REALISED_PROFIT = 0)",sWhere_Clause);

	printf("sNetPosQry = %s ",sNetPosQry);

	if(mysql_query(DBQury,sNetPosQry) != SUCCESS)
	{
		logSqlFatal("Error in sNetPosQry.");
		sql_Error(DBQury);
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//        iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pNetPosHdrResp.IntRespHeader.iSeqNo = 0;
	pNetPosHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pNetPosHdrResp.IntRespHeader.iErrorId = 0;
	pNetPosHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CKT_HITTING_NET_POS_HDR_RESP;
	pNetPosHdrResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
	pNetPosHdrResp.IntRespHeader.cSource = pViewNetPosReq->ReqHeader.cSource ;
	pNetPosHdrResp.cMsgType = 'H';
	pNetPosHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pNetPosHdrResp.IntRespHeader.iMsgLength = %d",pNetPosHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pNetPosHdrResp.IntRespHeader.iMsgCode = %d",pNetPosHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pNetPosHdrResp.IntRespHeader.iUserId = %llu",pNetPosHdrResp.IntRespHeader.iUserId);
	logDebug2("pNetPosHdrResp.IntRespHeader.cSource = %c",pNetPosHdrResp.IntRespHeader.cSource);
	logDebug2("pNetPosHdrResp.iNoofRec = %d",pNetPosHdrResp.iNoofRec);

	logDebug2("pViewNetPosReq->ReqHeader.iUserId = %llu",pViewNetPosReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewNetPosReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pNetPosHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No of Pkt (i) = %d",i);
		memset(&pNetPosResp,'\0',sizeof(struct VIEW_ADMIN_NET_POSITION_RESP));
		pNetPosResp.IntRespHeader.iSeqNo = 0;
		pNetPosResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_NET_POSITION_RESP);
		pNetPosResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CKT_HITTING_NET_POS_RESP;
		pNetPosResp.IntRespHeader.iErrorId = 0;
		pNetPosResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
		pNetPosResp.IntRespHeader.cSource = pViewNetPosReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pNetPosResp.cMsgType = 'T';
		}
		else
		{
			pNetPosResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			logDebug2("****** j = %d ******",j);

			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(pNetPosResp.subnetpos[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pNetPosResp.subnetpos[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				strncpy(pNetPosResp.subnetpos[j].sExchId,Row[2],EXCHANGE_LEN);
				strncpy(pNetPosResp.subnetpos[j].cMktType,Row[3],EXCHANGE_LEN);
				pNetPosResp.subnetpos[j].iBuyQty = atoi(Row[4]);
				pNetPosResp.subnetpos[j].iBuyQtyCF = atoi(Row[5]);
				pNetPosResp.subnetpos[j].iBuyQtyDay = atoi(Row[6]);
				pNetPosResp.subnetpos[j].fBuyVal = atof(Row[7]);
				pNetPosResp.subnetpos[j].fBuyValCF = atof(Row[8]);
				pNetPosResp.subnetpos[j].fBuyValDay = atof(Row[9]);
				pNetPosResp.subnetpos[j].fBuyAvg = atof(Row[10]);
				pNetPosResp.subnetpos[j].iSellQty = atoi(Row[11]);
				pNetPosResp.subnetpos[j].iSellQtyCF = atoi(Row[12]);
				pNetPosResp.subnetpos[j].iSellQtyDay = atoi(Row[13]);
				pNetPosResp.subnetpos[j].fSellVal = atof(Row[14]);
				pNetPosResp.subnetpos[j].fSellValCF = atof(Row[15]);
				pNetPosResp.subnetpos[j].fSellValDay = atof(Row[16]);
				pNetPosResp.subnetpos[j].fSellAvg = atof(Row[17]);
				pNetPosResp.subnetpos[j].iNetQty = atoi(Row[18]);
				pNetPosResp.subnetpos[j].fCf_net_qty = atof(Row[19]);
				pNetPosResp.subnetpos[j].fDay_net_qty = atof(Row[20]);
				pNetPosResp.subnetpos[j].fNetVal = atof(Row[21]);
				pNetPosResp.subnetpos[j].fCf_net_val = atof(Row[22]);
				pNetPosResp.subnetpos[j].fDay_net_val = atof(Row[23]);
				pNetPosResp.subnetpos[j].fNetAvg = atof(Row[24]);
				pNetPosResp.subnetpos[j].fCf_net_avg = atof(Row[25]);
				pNetPosResp.subnetpos[j].fDay_net_avg = atof(Row[26]);
				pNetPosResp.subnetpos[j].fGrossQty = atof(Row[27]);
				pNetPosResp.subnetpos[j].fGrossVal = atof(Row[28]);
				pNetPosResp.subnetpos[j].cSegment = Row[29][0];
				pNetPosResp.subnetpos[j].cProductId = Row[30][0];
				pNetPosResp.subnetpos[j].fRelaisedProfit = atof(Row[31]);
				pNetPosResp.subnetpos[j].iRef_ID = atoi(Row[32]);
				pNetPosResp.subnetpos[j].cCrossCur_Flag = Row[33][0];
				pNetPosResp.subnetpos[j].fRBIRefRate = atof(Row[34]);

				logDebug2("pNetPosResp.subnetpos[%d].sClientId = %s",j,pNetPosResp.subnetpos[j].sClientId);
				logDebug2("pNetPosResp.subnetpos[%d].sSecurityID = %s",j,pNetPosResp.subnetpos[j].sSecurityID);
				logDebug2("pNetPosResp.subnetpos[%d].sExchId = %s",j,pNetPosResp.subnetpos[j].sExchId);
				logDebug2("pNetPosResp.subnetpos[%d].cMktType = %s",j,pNetPosResp.subnetpos[j].cMktType);
				logDebug2("pNetPosResp.subnetpos[%d].iBuyQty = %d",j,pNetPosResp.subnetpos[j].iBuyQty);
				logDebug2("pNetPosResp.subnetpos[%d].iBuyQtyCF = %d",j,pNetPosResp.subnetpos[j].iBuyQtyCF);
				logDebug2("pNetPosResp.subnetpos[%d].iBuyQtyDay = %d",j,pNetPosResp.subnetpos[j].iBuyQtyDay);
				logDebug2("pNetPosResp.subnetpos[%d].fBuyVal= %lf",j,pNetPosResp.subnetpos[j].fBuyVal);
				logDebug2("pNetPosResp.subnetpos[%d].fBuyValCF = %lf",j,pNetPosResp.subnetpos[j].fBuyValCF);
				logDebug2("pNetPosResp.subnetpos[%d].fBuyValDay = %lf",j,pNetPosResp.subnetpos[j].fBuyValDay);
				logDebug2("pNetPosResp.subnetpos[%d].fBuyAvg = %lf",j,pNetPosResp.subnetpos[j].fBuyAvg);
				logDebug2("pNetPosResp.subnetpos[%d].iSellQty = %d",j,pNetPosResp.subnetpos[j].iSellQty);
				logDebug2("pNetPosResp.subnetpos[%d].iSellQtyCF = %d",j,pNetPosResp.subnetpos[j].iSellQtyCF);
				logDebug2("pNetPosResp.subnetpos[%d].iSellQtyDay = %d",j,pNetPosResp.subnetpos[j].iSellQtyDay);
				logDebug2("pNetPosResp.subnetpos[%d].fSellVal = %lf",j,pNetPosResp.subnetpos[j].fSellVal);
				logDebug2("pNetPosResp.subnetpos[%d].fSellValCF = %lf",j,pNetPosResp.subnetpos[j].fSellValCF);
				logDebug2("pNetPosResp.subnetpos[%d].fSellValDay = %lf",j,pNetPosResp.subnetpos[j].fSellValDay);
				logDebug2("pNetPosResp.subnetpos[%d].fSellAvg = %lf",j,pNetPosResp.subnetpos[j].fSellAvg);
				logDebug2("pNetPosResp.subnetpos[%d].iNetQty = %d",j,pNetPosResp.subnetpos[j].iNetQty);
				logDebug2("pNetPosResp.subnetpos[%d].fNetVal = %lf",j,pNetPosResp.subnetpos[j].fNetVal);
				logDebug2("pNetPosResp.subnetpos[%d].fNetAvg = %lf",j,pNetPosResp.subnetpos[j].fNetAvg);
				logDebug2("pNetPosResp.subnetpos[%d].fGrossQty = %lf",j,pNetPosResp.subnetpos[j].fGrossQty);
				logDebug2("pNetPosResp.subnetpos[%d].fGrossVal = %lf",j,pNetPosResp.subnetpos[j].fGrossVal);
				logDebug2("pNetPosResp.subnetpos[%d].cSegment = %c",j,pNetPosResp.subnetpos[j].cSegment);
				logDebug2("pNetPosResp.subnetpos[%d].cProductId = %c",j,pNetPosResp.subnetpos[j].cProductId);
				logDebug2("pNetPosResp.subnetpos[%d].fRelaisedProfit = %lf",j,pNetPosResp.subnetpos[j].fRelaisedProfit);
				logDebug2("pNetPosResp.subnetpos[%d].iRef_ID = %d",j,pNetPosResp.subnetpos[j].iRef_ID);
				logDebug2("pNetPosResp.subnetpos[%d].cCrossCur_Flag = %c",j,pNetPosResp.subnetpos[j].cCrossCur_Flag);
				logDebug2("pNetPosResp.subnetpos[%d].fRBIRefRate = %f",j,pNetPosResp.subnetpos[j].fRBIRefRate);
				logDebug2("pNetPosResp.subnetpos[%d].fDay_net_qty = %f",j,pNetPosResp.subnetpos[j].fDay_net_qty);
				logDebug2("pNetPosResp.subnetpos[%d].fCf_net_qty = %f",j,pNetPosResp.subnetpos[j].fCf_net_qty);
				logDebug2("pNetPosResp.subnetpos[%d].fDay_net_val = %lf",j,pNetPosResp.subnetpos[j].fDay_net_val);
				logDebug2("pNetPosResp.subnetpos[%d].fCf_net_val= %lf",j,pNetPosResp.subnetpos[j].fCf_net_val);
				logDebug2("pNetPosResp.subnetpos[%d].fDay_net_avg = %f",j,pNetPosResp.subnetpos[j].fDay_net_avg);
				logDebug2("pNetPosResp.subnetpos[%d].fCf_net_avg = %f",j,pNetPosResp.subnetpos[j].fCf_net_avg);
				logDebug2("pNetPosResp.cMsgType = %c",pNetPosResp.cMsgType);
			}
		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pNetPosResp,sizeof(struct VIEW_ADMIN_NET_POSITION_RESP) ,iRelayID ) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			return FALSE;
		}
		iTempNoOfRec--;
		//	usleep(5000);
	}

	logTimestamp("Exit : fCktHittingNetPosition ");
	return TRUE;
}

BOOL	fSIPOrderTrails(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrderTrails");

	struct  VIEW_SIP_ADMIN_ORDER_TRAILS_REQ		*pOrdTrlsReq;
	struct	VIEW_SIP_ADMIN_ORDER_TRAILS_RESP	pOrdTrlsResp;
	struct	VIEW_COMMON_HDR_RESP                    pOrdTrlsHedResp;

	CHAR    sSIPOrdTrlsQry[DOUBLE_MAX_QUERY_SIZE];

	pOrdTrlsReq = (struct VIEW_SIP_ADMIN_ORDER_TRAILS_REQ *)RcvMsg;

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdTrlsQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	logDebug2("pOrdTrlsReq->fOrderNo = %lf",pOrdTrlsReq->fOrderNo);

	sprintf(sSIPOrdTrlsQry,"SELECT ORDER_NO,ORD_SERIAL_NO,MSG_CODE,SCRIP_CODE,ORDER_VALIDITY,PRO_CLIENT,SOURCE,\
                                QTY_ORIGINAL,QTY_REMAINING,PRICE,LAST_TRADE_QTY,TRD_TRADE_PRICE,QTY_TRADED,EXCH_TRADE_NO,PRODUCT,EXCH_ORDER_NO,\
                                ORD_TRD_TRADE_TIME,CLIENT_ID,ENTITY_ID,BUY_SELL,EXCH_ID,ERROR_MESSAGE,STATUS,SEM_SYMBOL,ORDER_TYPE,\
                                ALGO_ORDER_NO FROM (SELECT  EQ_ORDER_NO AS ORDER_NO,  EQ_SERIAL_NO AS ORD_SERIAL_NO,  EQ_MSG_CODE AS MSG_CODE,\
                                EQ_SCRIP_CODE AS SCRIP_CODE,  (CASE EQ_VALIDITY  WHEN 0 THEN 'DAY'  WHEN 3 THEN 'IOC'  END) AS ORDER_VALIDITY,\
                                EQ_PRO_CLIENT AS PRO_CLIENT,  EQ_SOURCE_FLG AS SOURCE,  EQ_TOTAL_QTY AS QTY_ORIGINAL,  EQ_REM_QTY AS QTY_REMAINING,\
                                EQ_ORDER_PRICE AS PRICE,  EQ_LAST_TRADE_QTY AS LAST_TRADE_QTY,  EQ_TRD_TRADE_PRICE AS TRD_TRADE_PRICE,\
                                EQ_TOTAL_TRADED_QTY AS QTY_TRADED,  EQ_TRD_EXCH_TRADE_NO AS EXCH_TRADE_NO, (CASE EQ_PRODUCT_ID  WHEN 'B' \
                                THEN 'BO'  WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC'  WHEN 'M' THEN 'MARGIN'  WHEN 'L' THEN 'MLB'  WHEN 'S' \
                                THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY'  WHEN 'V' THEN 'CO'  WHEN 'B' THEN 'BO'  ELSE EQ_PRODUCT_ID  END) AS PRODUCT,\
                                EQ_EXCH_ORDER_NO AS EXCH_ORDER_NO,  DATE_FORMAT(EQ_INTERNAL_ENTRY_DATE, '%%d-%%m-%%Y %%r') AS ORD_TRD_TRADE_TIME,\
                                EQ_CLIENT_ID AS CLIENT_ID,  EQ_ENTITY_ID AS ENTITY_ID,  (CASE EQ_BUY_SELL_IND  WHEN 'B' THEN 'SIP'  \
                                WHEN 'S' THEN 'SWP'  END) AS BUY_SELL,  EQ_EXCH_ID AS EXCH_ID,  EQ_REASON_DESCRIPTION AS ERROR_MESSAGE,\
                                CASE EQ_MSG_CODE  WHEN '2073' THEN 'Pending'  WHEN '2000' THEN 'Transit'  WHEN '2231' THEN 'Rejected'  \
                                WHEN '2042' THEN 'Rejected'  WHEN '2170' THEN 'Frozen'  WHEN '2074' THEN 'Modified'  WHEN '2075' THEN 'Cancelled'  \
                                WHEN '2222' THEN 'Traded'  WHEN '2072' THEN 'Rejected'  WHEN '2040' THEN 'Transit'  WHEN '2070' \
                                THEN 'Transit'  WHEN '9002' THEN 'Expired'  WHEN '5112' THEN 'O-Pending'  WHEN '5113' THEN 'O-Modified'  \
                                WHEN '5114' THEN 'O-Cancelled'  WHEN '2212' THEN 'Triggered'  WHEN '1111' THEN 'Rejected'  WHEN '1113' \
                                THEN 'Rejected'  WHEN '1115' THEN 'Rejected'  WHEN '4444' THEN 'Rejected'  WHEN '4445' THEN 'Rejected'  \
                                WHEN '4446' THEN 'Rejected'  WHEN '3073' THEN 'Pending' WHEN '3331' THEN 'Rejected' END AS STATUS,\
				EQ_SYMBOL AS SEM_SYMBOL,  (CASE EQ_ORDER_TYPE  WHEN '1' THEN 'MARKET'  \
                                WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'  WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,  EQ_ALGO_ORDER_NO AS \
                                ALGO_ORDER_NO  FROM EQ_ORDERS_ARCHIVE UNION ALL SELECT  EQ_ORDER_NO AS ORDER_NO,  EQ_SERIAL_NO AS ORD_SERIAL_NO,\
                                EQ_MSG_CODE AS MSG_CODE,  EQ_SCRIP_CODE AS SCRIP_CODE,  (CASE EQ_VALIDITY  WHEN 0 THEN 'DAY'  WHEN 3 THEN 'IOC'  END) \
                                AS ORDER_VALIDITY,  EQ_PRO_CLIENT AS PRO_CLIENT,  EQ_SOURCE_FLG AS SOURCE,  EQ_TOTAL_QTY AS QTY_ORIGINAL,\
                                EQ_REM_QTY AS QTY_REMAINING,  EQ_ORDER_PRICE AS PRICE,  EQ_LAST_TRADE_QTY AS LAST_TRADE_QTY,  \
                                EQ_TRD_TRADE_PRICE AS TRD_TRADE_PRICE,  EQ_TOTAL_TRADED_QTY AS QTY_TRADED,  EQ_TRD_EXCH_TRADE_NO AS EXCH_TRADE_NO,\
                                (CASE EQ_PRODUCT_ID  WHEN 'B' THEN 'BO'  WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC'  WHEN 'M' THEN 'MARGIN' \
                                WHEN 'L' THEN 'MLB'  WHEN 'S' THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY'  WHEN 'V' THEN 'CO'  WHEN 'B' \
                                THEN 'BO'  ELSE EQ_PRODUCT_ID  END) AS PRODUCT,  EQ_EXCH_ORDER_NO AS EXCH_ORDER_NO,  \
                                DATE_FORMAT(EQ_INTERNAL_ENTRY_DATE, '%%d-%%m-%%Y %%r') AS ORD_TRD_TRADE_TIME,  EQ_CLIENT_ID AS CLIENT_ID,\
                                EQ_ENTITY_ID AS ENTITY_ID,  (CASE EQ_BUY_SELL_IND  WHEN 'B' THEN 'SIP'  WHEN 'S' THEN 'SWP'  END) AS BUY_SELL,\
                                EQ_EXCH_ID AS EXCH_ID,  EQ_REASON_DESCRIPTION AS ERROR_MESSAGE,  CASE EQ_MSG_CODE  WHEN '2073' THEN 'Pending'  \
                                WHEN '2000' THEN 'Transit'  WHEN '2231' THEN 'Rejected'  WHEN '2042' THEN 'Rejected'  WHEN '2170' THEN 'Frozen'  \
                                WHEN '2074' THEN 'Modified'  WHEN '2075' THEN 'Cancelled'  WHEN '2222' THEN 'Traded'  WHEN '2072' THEN 'Rejected'  \
                                WHEN '2040' THEN 'Transit'  WHEN '2070' THEN 'Transit'  WHEN '9002' THEN 'Expired'  WHEN '5112' THEN 'O-Pending'  \
                                WHEN '5113' THEN 'O-Modified'  WHEN '5114' THEN 'O-Cancelled'  WHEN '2212' THEN 'Triggered'  WHEN '1111' \
                                THEN 'Rejected'  WHEN '1113' THEN 'Rejected'  WHEN '1115' THEN 'Rejected'  WHEN '4444' THEN 'Rejected'  \
                                WHEN '4445' THEN 'Rejected'  WHEN '4446' THEN 'Rejected'  WHEN '3073' THEN 'Pending' WHEN '3331' THEN 'Rejected' \
				END AS STATUS,  EQ_SYMBOL AS SEM_SYMBOL, \
                                (CASE EQ_ORDER_TYPE  WHEN '1' THEN 'MARKET'  WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'  WHEN '4' THEN 'SL'  END)\
                                AS ORDER_TYPE,  EQ_ALGO_ORDER_NO AS ALGO_ORDER_NO  FROM EQ_ORDERS UNION ALL SELECT  SIP_ORDER_NO AS ORDER_NO,\
                                SIP_SERIAL_NO AS ORD_SERIAL_NO,  SIP_MSG_CODE AS MSG_CODE,  SIP_SCRIP_CODE AS SCRIP_CODE, \
                                (CASE SIP_VALIDITY  WHEN 0 THEN 'DAY'  WHEN 3 THEN 'IOC'  END) AS ORDER_VALIDITY,  SIP_PRO_CLIENT AS PRO_CLIENT, \
				SIP_SOURCE_FLG AS SOURCE,  SIP_TOTAL_QTY AS QTY_ORIGINAL,  0 AS QTY_REMAINING,  SIP_AMOUNT AS PRICE,\
                                0 AS LAST_TRADE_QTY,  0 AS TRD_TRADE_PRICE,  0 AS QTY_TRADED,  0 AS EXCH_TRADE_NO,  (CASE SIP_PRODUCT_ID  WHEN 'B'\
                                THEN 'BO'  WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC'  WHEN 'M' THEN 'MARGIN'  WHEN 'L' THEN 'MLB'  WHEN 'S'\
                                THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY'  WHEN 'V' THEN 'CO'  WHEN 'B' THEN 'BO'  ELSE SIP_PRODUCT_ID  END) AS PRODUCT,\
                                0 AS EXCH_ORDER_NO,  DATE_FORMAT(SIP_INTERNAL_ENTRY_DATE, '%%d-%%m-%%Y %%r') AS ORD_TRD_TRADE_TIME,\
                                SIP_CLIENT_ID AS CLIENT_ID,  SIP_ENTITY_ID AS ENTITY_ID,  (CASE SIP_BUY_SELL_IND  WHEN 'B' THEN 'SIP' \
                                WHEN 'S' THEN 'SWP'  END) AS BUY_SELL,  SIP_EXCH_ID AS EXCH_ID,  SIP_REMARKS AS ERROR_MESSAGE,  CASE SIP_MSG_CODE \
                                WHEN '2073' THEN 'Pending'  WHEN '2000' THEN 'Transit'  WHEN '2231' THEN 'Rejected'  WHEN '2042' THEN 'Rejected' \
                                WHEN '2170' THEN 'Frozen'  WHEN '2074' THEN 'Modified'  WHEN '2075' THEN 'Cancelled'  WHEN '2222' THEN 'Traded'\
                                WHEN '2072' THEN 'Rejected'  WHEN '2040' THEN 'Transit'  WHEN '2070' THEN 'Transit'  WHEN '9002' THEN 'Expired'\
                                WHEN '5112' THEN 'O-Pending'  WHEN '5113' THEN 'O-Modified'  WHEN '5114' THEN 'O-Cancelled'  WHEN '2212' THEN 'Triggered'\
                                WHEN '1111' THEN 'Rejected'  WHEN '1113' THEN 'Rejected'  WHEN '1115' THEN 'Rejected'  WHEN '4444' THEN 'Rejected' \
                                WHEN '4445' THEN 'Rejected'  WHEN '4446' THEN 'Rejected'  WHEN '3073' THEN 'Pending' WHEN '3331' THEN 'Rejected' \
				END AS STATUS,  SIP_SYMBOL AS SEM_SYMBOL,\
                                (CASE SIP_ORDER_TYPE  WHEN '1' THEN 'MARKET'  WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'  WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,\
                                SIP_ORDER_NO AS ALGO_ORDER_NO  FROM SIP_ORDERS_ARCHIVE  WHERE SIP_TOTAL_QTY = 0)\
                                AS EQ WHERE  ALGO_ORDER_NO = %lf ORDER BY ORD_TRD_TRADE_TIME DESC , ORDER_NO DESC , ORD_SERIAL_NO DESC;",pOrdTrlsReq->fOrderNo);

	printf("sSIPOrdTrlsQry = %s",sSIPOrdTrlsQry);

	if(mysql_query(DBQury,sSIPOrdTrlsQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdTrlsQry.");
		sql_Error(DBQury);
		return FALSE;
	}
	Res = mysql_store_result(DBQury);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdTrlsHedResp.IntRespHeader.iSeqNo = 0;
	pOrdTrlsHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdTrlsHedResp.IntRespHeader.iErrorId = 0;
	pOrdTrlsHedResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SIP_ORDER_TRALS_HED_RESP;
	pOrdTrlsHedResp.IntRespHeader.iUserId = pOrdTrlsReq->ReqHeader.iUserId;
	pOrdTrlsHedResp.IntRespHeader.cSource = pOrdTrlsReq->ReqHeader.cSource;
	pOrdTrlsHedResp.cMsgType = 'H';
	pOrdTrlsHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdTrlsHedResp.IntRespHeader.iMsgLength = %d",pOrdTrlsHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdTrlsHedResp.IntRespHeader.iMsgCode = %d",pOrdTrlsHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdTrlsHedResp.IntRespHeader.iUserId = %llu",pOrdTrlsHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdTrlsHedResp.IntRespHeader.cSource = %c",pOrdTrlsHedResp.IntRespHeader.cSource);
	logDebug2("pOrdTrlsHedResp.iNoofRec = %d",pOrdTrlsHedResp.iNoofRec);

	logDebug2("pOrdTrlsReq->ReqHeader.iUserId = %llu",pOrdTrlsReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pOrdTrlsReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pOrdTrlsHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdTrlsResp,'\0',sizeof(struct VIEW_SIP_ADMIN_ORDER_TRAILS_RESP));
		pOrdTrlsResp.IntRespHeader.iSeqNo = 0;
		pOrdTrlsResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ADMIN_ORDER_TRAILS_RESP);
		pOrdTrlsResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SIP_ORDER_TRALS_RESP;
		pOrdTrlsResp.IntRespHeader.iErrorId = 0;
		pOrdTrlsResp.IntRespHeader.iUserId = pOrdTrlsReq->ReqHeader.iUserId;
		pOrdTrlsResp.IntRespHeader.cSource = pOrdTrlsReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pOrdTrlsResp.cMsgType = 'T';
		}
		else
		{
			pOrdTrlsResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pOrdTrlsResp.subordertrails[j].fOrderNo = atof(Row[0]);
				pOrdTrlsResp.subordertrails[j].iSerialNo = atoi(Row[1]);
				pOrdTrlsResp.subordertrails[j].iTranscode = atoi(Row[2]);
				strncpy(pOrdTrlsResp.subordertrails[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sValidity,Row[4],VALIDITY_LEN);
				pOrdTrlsResp.subordertrails[j].cProClient = Row[5][0];
				strncpy(pOrdTrlsResp.subordertrails[j].sSourceFlg,Row[6],SOURCE_FLG_LEN);
				pOrdTrlsResp.subordertrails[j].fQty = atof(Row[7]);
				pOrdTrlsResp.subordertrails[j].fRemQty = atof(Row[8]);
				pOrdTrlsResp.subordertrails[j].fPrice = atof(Row[9]);
				pOrdTrlsResp.subordertrails[j].fTradeQty = atof(Row[10]);
				pOrdTrlsResp.subordertrails[j].fTradePrice = atof(Row[11]);
				pOrdTrlsResp.subordertrails[j].fTotalTradeQty = atof(Row[12]);
				pOrdTrlsResp.subordertrails[j].iExchTradeNo = atoi(Row[13]);
				strncpy(pOrdTrlsResp.subordertrails[j].sProduct,Row[14],PRODUCT_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sExchOrderNumber,Row[15],NSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sDatetime,Row[16],DATE_STRING_LENGTH);
				strncpy(pOrdTrlsResp.subordertrails[j].sClientId,Row[17],CLIENT_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sEntityId,Row[18],ENTITY_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sBuySellInd,Row[19],BUY_SELL_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sExcgId,Row[20],EXCHANGE_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sOrdReasonDesc,Row[21],ORDER_REASON_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sStatus,Row[22],DB_STATUS_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sSymbol,Row[23],DB_SYMBOL_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sOrderType,Row[24],ORD_TYP_LEN);
				pOrdTrlsResp.subordertrails[j].fAlgoOrderNo = atof(Row[25]);

				logDebug2("pOrdTrlsResp.subordertrails[%d].fOrderNo = %lf",j,pOrdTrlsResp.subordertrails[j].fOrderNo);
				logDebug2("pOrdTrlsResp.subordertrails[%d].iSerialNo = %d",j,pOrdTrlsResp.subordertrails[j].iSerialNo);
				logDebug2("pOrdTrlsResp.subordertrails[%d].iTranscode = %d",j,pOrdTrlsResp.subordertrails[j].iTranscode);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sSecurityID = %s",j,pOrdTrlsResp.subordertrails[j].sSecurityID);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sValidity = %s",j,pOrdTrlsResp.subordertrails[j].sValidity);
				logDebug2("pOrdTrlsResp.subordertrails[%d].cProClient = %c",j,pOrdTrlsResp.subordertrails[j].cProClient);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sSourceFlg = %s",j,pOrdTrlsResp.subordertrails[j].sSourceFlg);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fQty = %lf",j,pOrdTrlsResp.subordertrails[j].fQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fRemQty = %lf",j,pOrdTrlsResp.subordertrails[j].fRemQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fPrice = %lf",j,pOrdTrlsResp.subordertrails[j].fPrice);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fTradeQty = %lf",j,pOrdTrlsResp.subordertrails[j].fTradeQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fTradePrice = %lf",j,pOrdTrlsResp.subordertrails[j].fTradePrice);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fTotalTradeQty = %lf",j,pOrdTrlsResp.subordertrails[j].fTotalTradeQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].iExchTradeNo = %d",j,pOrdTrlsResp.subordertrails[j].iExchTradeNo);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sProduct = %s",j,pOrdTrlsResp.subordertrails[j].sProduct);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sExchOrderNumber = %s",j,pOrdTrlsResp.subordertrails[j].sExchOrderNumber);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sDatetime = %s",j,pOrdTrlsResp.subordertrails[j].sDatetime);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sClientId = %s",j,pOrdTrlsResp.subordertrails[j].sClientId);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sEntityId = %s",j,pOrdTrlsResp.subordertrails[j].sEntityId);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sBuySellInd = %s",j,pOrdTrlsResp.subordertrails[j].sBuySellInd);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sExcgId = %s",j,pOrdTrlsResp.subordertrails[j].sExcgId);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sOrdReasonDesc = %s",j,pOrdTrlsResp.subordertrails[j].sOrdReasonDesc);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sStatus = %s",j,pOrdTrlsResp.subordertrails[j].sStatus);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sSymbol = %s",j,pOrdTrlsResp.subordertrails[j].sSymbol);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sOrderType = %s",j,pOrdTrlsResp.subordertrails[j].sOrderType);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fAlgoOrderNo = %lf",j,pOrdTrlsResp.subordertrails[j].fAlgoOrderNo);

			}

		}

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pOrdTrlsResp,sizeof(struct VIEW_SIP_ADMIN_ORDER_TRAILS_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
			return FALSE;
		}

		iTempNoOfRec--;
		//	usleep(5000);
	}
	logTimestamp("Exit : fSIPOrderTrails");
	return TRUE;
}


BOOL    fViewLimitDtls(CHAR *RcvMsg)
{
	logTimestamp("Entry : fViewLimitDtls");
	struct  VIEW_LIMIT_DTLS_REQ	*pViewDetLmtReq;
	struct  VIEW_ADMIN_CLIENT_LIMIT_DTLS pDetLmtRes;

	pViewDetLmtReq = (struct  VIEW_COMMON_QUERY_REQ *)RcvMsg;

	INT16 iStatus,iError ;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR    sViewDetLimit      [DOUBLE_MAX_QUERY_SIZE];
	memset(sViewDetLimit,'\0',DOUBLE_MAX_QUERY_SIZE);

	if(mysql_set_server_option(DBQury,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		return FALSE;
	}
//	sprintf(pViewDetLmtReq->sClientId , "01A002");
	logDebug2("pViewDetLmtReq->sClientId = %s",pViewDetLmtReq->sClientId);
	/**
	  sprintf(sViewDetLimit,"CALL PR_DETAILED_LIMIT(\"%s\",@V_EQ_CNC_PEND ,@V_EQ_MRG_PEND,@V_EQ_INT_PEND ,@V_DR@V_MRG_PEND,@V_DR@V_INT_PEND,@V_CURR_MRG_PEND ,@V_CURR_INT_PEND ,@V_EQ_HYB_PEND ,@V_EQ_MTF_PEND ,@V_EQ_CNC ,@V_NSE_CNC_RECEIVABLE ,@V_BSE_CNC_RECEIVABLE ,@V_EQ_MRG_VAR ,@V_EQ_INT_VAR ,@V_EQ_HYB_VAR ,@V_EQ_MTF_VAR ,@V_DR@V_INTRADAY ,@V_DR@V_MARGIN ,@V_CURR_INTRADAY ,@V_CURR_MARGIN ,@V_SPANB1 ,@V_SPANB2 ,@V_SPANB3 ,@V_SPANB4 ,@V_OPTION_SELL_PREMIUM      ,@V_DR@V_EXPO_INT ,@V_DR@V_EXPO_MARGIN ,@V_CURR_EXPO_INT ,@V_CURR_EXPO_MARGIN ,@V_EQ_CO ,@V_DR@V_CO ,@V_CURR_CO ,@V_EQ_BO ,@V_DR@V_BO ,@V_CURR_BO ,@V_EQ_INT_RPNL ,@V_EQ_MRG_RPNL ,@V_EQ_CNC_RPNL ,@V_DR@V_INT_RPNL ,@V_DR@V_MRG_RPNL ,@V_CURR_INT_RPNL ,@V_CURR_MRG_RPNL ,@V_EQ_HYB_RPNL ,@V_EQ_MTF_RPNL ,@V_EQ_TOTAL_UTLZ ,@V_DR@V_TOTAL_UTLZ ,@V_CURR_TOTAL_UTLZ ,@V_COMM_MRG_PEND                    ,@V_COMM_INT_PEND ,@V_COMM_INTRADAY ,@V_COMM_MARGIN ,@V_SPANB5 ,@V_SPANB6 ,@V_COMM_EXPO_INT ,@V_COMM_EXPO_MARGIN ,@V_COMM_CO ,@V_COMM_BO  ,@V_COMM_INT_RPNL ,@V_COMM_MRG_RPNL  ,@V_COMM_TOTAL_UTLZ ,@V_OPTION_SELL_PREMIUM_COM DOUBLE );\
	  SELECT @V_EQ_CNC_PEND ,@V_EQ_MRG_PEND,@V_EQ_INT_PEND ,@V_DR@V_MRG_PEND,@V_DR@V_INT_PEND,@V_CURR_MRG_PEND ,@V_CURR_INT_PEND ,@V_EQ_HYB_PEND ,@V_EQ_MTF_PEND ,@V_EQ_CNC ,@V_NSE_CNC_RECEIVABLE ,@V_BSE_CNC_RECEIVABLE ,@V_EQ_MRG_VAR ,@V_EQ_INT_VAR ,@V_EQ_HYB_VAR ,@V_EQ_MTF_VAR ,@V_DR@V_INTRADAY ,@V_DR@V_MARGIN ,@V_CURR_INTRADAY ,@V_CURR_MARGIN ,@V_SPANB1 ,@V_SPANB2 ,@V_SPANB3 ,@V_SPANB4 ,@V_OPTION_SELL_PREMIUM      ,@V_DR@V_EXPO_INT ,@V_DR@V_EXPO_MARGIN ,@V_CURR_EXPO_INT ,@V_CURR_EXPO_MARGIN ,@V_EQ_CO ,@V_DR@V_CO ,@V_CURR_CO ,@V_EQ_BO ,@V_DR@V_BO ,@V_CURR_BO ,@V_EQ_INT_RPNL ,@V_EQ_MRG_RPNL ,@V_EQ_CNC_RPNL ,@V_DR@V_INT_RPNL ,@V_DR@V_MRG_RPNL ,@V_CURR_INT_RPNL ,@V_CURR_MRG_RPNL ,@V_EQ_HYB_RPNL ,@V_EQ_MTF_RPNL ,@V_EQ_TOTAL_UTLZ ,@V_DR@V_TOTAL_UTLZ ,@V_CURR_TOTAL_UTLZ ,@V_COMM_MRG_PEND                    ,@V_COMM_INT_PEND ,@V_COMM_INTRADAY ,@V_COMM_MARGIN ,@V_SPANB5 ,@V_SPANB6 ,@V_COMM_EXPO_INT ,@V_COMM_EXPO_MARGIN ,@V_COMM_CO ,@V_COMM_BO  ,@V_COMM_INT_RPNL ,@V_COMM_MRG_RPNL  ,@V_COMM_TOTAL_UTLZ ,@V_OPTION_SELL_PREMIUM_COM DOUBLE ;",pViewDetLmtReq->sClientId);
	 **/

	sprintf(sViewDetLimit,"CALL PR_DETAILED_LIMIT(\"%s\",@V_EQ_CNC_PEND ,@V_EQ_MRG_PEND,@V_EQ_INT_PEND,  @V_MRG_PEND ,@V_INT_PEND,@V_CURR_MRG_PEND ,\
		@V_CURR_INT_PEND ,@V_EQ_HYB_PEND ,@V_EQ_MTF_PEND ,@V_EQ_CNC ,@V_NSE_CNC_RECEIVABLE ,@V_BSE_CNC_RECEIVABLE ,@V_EQ_MRG_VAR ,@V_EQ_INT_VAR ,\
			@V_EQ_HYB_VAR ,@V_EQ_MTF_VAR , @V_INTRADAY , @V_MARGIN ,@V_CURR_INTRADAY ,@V_CURR_MARGIN ,@V_SPANB1 ,@V_SPANB2 ,@V_SPANB3 ,@V_SPANB4 ,\
			@V_OPTION_SELL_PREMIUM ,      @V_EXPO_INT , @V_EXPO_MARGIN ,@V_CURR_EXPO_INT ,@V_CURR_EXPO_MARGIN ,@V_EQ_CO,  @V_CO ,@V_CURR_CO ,@V_EQ_BO ,\
			@V_BO ,@V_CURR_BO ,@V_EQ_INT_RPNL ,@V_EQ_MRG_RPNL ,@V_EQ_CNC_RPNL , @V_INT_RPNL , @V_MRG_RPNL ,@V_CURR_INT_RPNL ,@V_CURR_MRG_RPNL ,\
			@V_EQ_HYB_RPNL ,@V_EQ_MTF_RPNL ,@V_EQ_TOTAL_UTLZ , @V_TOTAL_UTLZ ,@V_CURR_TOTAL_UTLZ ,@V_COMM_MRG_PEND ,@V_COMM_INT_PEND ,@V_COMM_INTRADAY ,\
			@V_COMM_MARGIN ,@V_SPANB5 ,@V_SPANB6 ,@V_COMM_EXPO_INT ,@V_COMM_EXPO_MARGIN ,@V_COMM_CO ,@V_COMM_BO  ,@V_COMM_INT_RPNL ,@V_COMM_MRG_RPNL  ,\
			@V_COMM_TOTAL_UTLZ ,@V_OPTION_SELL_PREMIUM_COM,@V_EQ_CO_RPNL, @V_DRV_CO_RPNL, @V_CURR_CO_RPNL, @V_EQ_BO_RPNL, @V_DRV_BO_RPNL,\
			@V_CURR_BO_RPNL, @V_COMM_CO_RPNL ,@V_COMM_BO_RPNL ,@V_OPTION_SELL_PREMIUM_CURR );\
		SELECT  IFNULL(@V_EQ_CNC_PEND , 0), IFNULL(@V_EQ_MRG_PEND, 0), IFNULL(@V_EQ_INT_PEND  ,  0), IFNULL(@V_MRG_PEND , 0), \
		IFNULL(@V_INT_PEND, 0), IFNULL(@V_CURR_MRG_PEND , 0), IFNULL(@V_CURR_INT_PEND , 0), IFNULL(@V_EQ_HYB_PEND , 0), \
		IFNULL(@V_EQ_MTF_PEND , 0), IFNULL(@V_EQ_CNC , 0), IFNULL(@V_NSE_CNC_RECEIVABLE , 0), IFNULL(@V_BSE_CNC_RECEIVABLE , 0), \
		IFNULL(@V_EQ_MRG_VAR , 0), IFNULL(@V_EQ_INT_VAR , 0),		 IFNULL(@V_EQ_HYB_VAR , 0), IFNULL(@V_EQ_MTF_VAR ,  0),\
		IFNULL(@V_INTRADAY,   0), IFNULL(@V_MARGIN , 0), IFNULL(@V_CURR_INTRADAY , 0), IFNULL(@V_CURR_MARGIN , 0), \
		IFNULL(@V_SPANB1 , 0), IFNULL(@V_SPANB2 , 0), IFNULL(@V_SPANB3 , 0), IFNULL(@V_SPANB4 , 0), IFNULL(@V_OPTION_SELL_PREMIUM     ,   0), \
		IFNULL(@V_EXPO_INT ,  0), IFNULL(@V_EXPO_MARGIN , 0), IFNULL(@V_CURR_EXPO_INT , 0), IFNULL(@V_CURR_EXPO_MARGIN , 0), IFNULL(@V_EQ_CO ,0),\
		IFNULL( @V_CO,  0), \
		IFNULL(@V_CURR_CO , 0), IFNULL(@V_EQ_BO , 0), IFNULL(@V_BO , 0), IFNULL(@V_CURR_BO , 0), IFNULL(@V_EQ_INT_RPNL , 0), IFNULL(@V_EQ_MRG_RPNL , 0),\
		IFNULL(@V_EQ_CNC_RPNL,   0), IFNULL(@V_INT_RPNL ,  0), IFNULL(@V_MRG_RPNL , 0), IFNULL(@V_CURR_INT_RPNL , 0), IFNULL(@V_CURR_MRG_RPNL , 0),\
		IFNULL(@V_EQ_HYB_RPNL , 0), IFNULL(@V_EQ_MTF_RPNL , 0), IFNULL(@V_EQ_TOTAL_UTLZ ,  0), IFNULL(@V_TOTAL_UTLZ , 0), IFNULL(@V_CURR_TOTAL_UTLZ , 0), \
		IFNULL(@V_COMM_MRG_PEND  , 0), IFNULL(@V_COMM_INT_PEND , 0), IFNULL(@V_COMM_INTRADAY , 0), IFNULL(@V_COMM_MARGIN , 0), IFNULL(@V_SPANB5 , 0), \
		IFNULL(@V_SPANB6 , 0), IFNULL(@V_COMM_EXPO_INT , 0), IFNULL(@V_COMM_EXPO_MARGIN , 0), IFNULL(@V_COMM_CO , 0), IFNULL(@V_COMM_BO  , 0),\ 
		IFNULL(@V_COMM_INT_RPNL , 0), IFNULL(@V_COMM_MRG_RPNL  , 0), IFNULL(@V_COMM_TOTAL_UTLZ , 0), IFNULL(@V_OPTION_SELL_PREMIUM_COMi, 0), \
		IFNULL(@V_EQ_CO_RPNL,  0), IFNULL(@V_DRV_CO_RPNL, 0), IFNULL(@V_CURR_CO_RPNL,  0), IFNULL(@V_EQ_BO_RPNL,  0), IFNULL(@V_DRV_BO_RPNL,  0), \
		IFNULL(@V_CURR_BO_RPNL,  0), IFNULL(@V_COMM_CO_RPNL , 0), IFNULL(@V_COMM_BO_RPNL , 0), IFNULL(@V_OPTION_SELL_PREMIUM_CURRi, 0)  ;",pViewDetLmtReq->sClientId);

	printf("\n sViewDetLimit :%s: \n",sViewDetLimit);

	if(mysql_query(DBQury,sViewDetLimit) != SUCCESS)
	{
		sql_Error(DBQury);
		iError  = mysql_errno(DBQury);
		logDebug2("ERROR Received While Calling Procedure :%d:",iError);
		return ERROR;
	}


	do{

		Res = mysql_store_result(DBQury);
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{

				pDetLmtRes.IntRespHeader.iSeqNo = 0;
				pDetLmtRes.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_CLIENT_LIMIT_DTLS);
				logDebug2("pDetLmtRes.IntRespHeader.iMsgLength = %d",pDetLmtRes.IntRespHeader.iMsgLength);
				pDetLmtRes.IntRespHeader.iMsgCode = TC_INT_ADMIN_LIMIT_DTL_RSP;
				pDetLmtRes.IntRespHeader.iErrorId = 0;
				pDetLmtRes.IntRespHeader.iUserId = pViewDetLmtReq->ReqHeader.iUserId;
				pDetLmtRes.IntRespHeader.cSource = pViewDetLmtReq->ReqHeader.cSource ;

				strncpy(pDetLmtRes.sClientId,pViewDetLmtReq->sClientId,CLIENT_ID_LEN);
				pDetLmtRes.fEqCNCPending=atof(Row[0]);
				pDetLmtRes.fEqMRGPending  =atof(Row[1]);
				pDetLmtRes.fEqINTPending  =atof(Row[2]);
				pDetLmtRes.fDrvMRGPending =atof(Row[3]);
				pDetLmtRes.fDrvINTPending =atof(Row[4]);
				pDetLmtRes.fCurrMRGPending=atof(Row[5]);
				pDetLmtRes.fCurrINTPending=atof(Row[6]);
				pDetLmtRes.fEqHYBPending  =atof(Row[7]);
				pDetLmtRes.fEqMTFPending  =atof(Row[8]);
				pDetLmtRes.fEqCNC   =atof(Row[9]);
				pDetLmtRes.fNseCNCRecvable=atof(Row[10]);
				pDetLmtRes.fBseCNCRecvable=atof(Row[11]);
				pDetLmtRes.fEqMRGVar=atof(Row[12]);
				pDetLmtRes.fEqINTVar=atof(Row[13]);
				pDetLmtRes.fEqHYBVar=atof(Row[14]);
				pDetLmtRes.fEqMTFVar=atof(Row[15]);
				pDetLmtRes.fDrvInt  =atof(Row[16]);
				pDetLmtRes.fDrvMRG  =atof(Row[17]);
				pDetLmtRes.fCurrINT =atof(Row[18]);
				pDetLmtRes.fCurrMRG =atof(Row[19]);
				pDetLmtRes.fSPAN1   =atof(Row[20]);
				pDetLmtRes.fSPAN2   =atof(Row[21]);
				pDetLmtRes.fSPAN3   =atof(Row[22]);
				pDetLmtRes.fSPAN4   =atof(Row[23]);
				pDetLmtRes.fOptSellPremiDrv  =atof(Row[24]);
				pDetLmtRes.fDrvExpoINT    =atof(Row[25]);
				pDetLmtRes.fDrvExpoMRG    =atof(Row[26]);
				pDetLmtRes.fCurrExpoINT   =atof(Row[27]);
				pDetLmtRes.fCurrExpoMRG   =atof(Row[28]);
				pDetLmtRes.fEquCO   =atof(Row[29]);
				pDetLmtRes.fDrvCO   =atof(Row[30]);
				pDetLmtRes.fCurrCO  =atof(Row[31]);
				pDetLmtRes.fEquBO   =atof(Row[32]);
				pDetLmtRes.fDrvBO   =atof(Row[33]);
				pDetLmtRes.fCurrBO  =atof(Row[34]);
				pDetLmtRes.fEquINTRPNL    =atof(Row[35]);
				pDetLmtRes.fEquMRGRPNL    =atof(Row[36]);
				pDetLmtRes.fEquCNCRPNL    =atof(Row[37]);
				pDetLmtRes.fDrvINTRPNL    =atof(Row[38]);
				pDetLmtRes.fDrvMRGRPNL    =atof(Row[39]);
				pDetLmtRes.fCurrINTRPNL   =atof(Row[40]);
				pDetLmtRes.fCurrMRGRPNL   =atof(Row[41]);
				pDetLmtRes.fEqHYBRPNL     =atof(Row[42]);
				pDetLmtRes.fEqMTFRPNL     =atof(Row[43]);
				pDetLmtRes.fEqTotUtilized =atof(Row[44]);
				pDetLmtRes.fDrvTotUtilized=atof(Row[45]);
				pDetLmtRes.fCurrTotUtilized     =atof(Row[46]);
				pDetLmtRes.fCommMRGPend   =atof(Row[47]);
				pDetLmtRes.fCommINTPend   =atof(Row[48]);
				pDetLmtRes.fCommINTR=atof(Row[49]);
				pDetLmtRes.fCommMRG =atof(Row[50]);
				pDetLmtRes.fSPAN5   =atof(Row[51]);
				pDetLmtRes.fSPAN6   =atof(Row[52]);
				pDetLmtRes.fCommExpoINT   =atof(Row[53]);
				pDetLmtRes.fCommExpoMRG   =atof(Row[54]);
				pDetLmtRes.fCommExpoCO    =atof(Row[55]);
				pDetLmtRes.fCommExpoBO    =atof(Row[56]);
				pDetLmtRes.fCommINTRPNL   =atof(Row[57]);
				pDetLmtRes.fCommMRGRPNL   =atof(Row[58]);
				pDetLmtRes.fCommTotUtiliz =atof(Row[59]);
				pDetLmtRes.fCommSellOptPremi=atof(Row[60]);
				pDetLmtRes.fEquCORPNL =atof(Row[61]);
				pDetLmtRes.fDrvCORPNL =atof(Row[62]);
				pDetLmtRes.fCurrCORPNL =atof(Row[63]);
				pDetLmtRes.fEquBORPNL=atof(Row[64]);
				pDetLmtRes.fDrvBORPNL=atof(Row[65]);
				pDetLmtRes.fCurrBORPNL=atof(Row[66]);
				pDetLmtRes.fCommCORPNL=atof(Row[67]);
				pDetLmtRes.fCommBORPNL=atof(Row[68]);
				pDetLmtRes.fOptSellPremiCurr=atof(Row[69]);

				mysql_free_result(Res);

			}
		}
		else
		{
			logDebug2("No Result Set ");
		}

		if((iStatus =mysql_next_result(DBQury)) > 0)
		{
			logDebug3("Could not execute statement :%d:",iStatus);
		}

		logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBQury));

	}while(iStatus == 0);

	iRelayID = find_admin_adapter(pViewDetLmtReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logInfo("Invalid Relayid");
		return FALSE;
	}

	if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pDetLmtRes,sizeof(struct VIEW_ADMIN_CLIENT_LIMIT_DTLS) ,iRelayID ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		return FALSE;
	}


	logTimestamp("Exit : fViewLimitDtls");

}


BOOL	fChckAdminContrlr(CHAR	*sAdminId,CHAR	*sBrcnhId)
{
	logTimestamp("Entry : fChckAdminContrlr");

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR		sSelQyr[MAX_QUERY_SIZE];
	BOOL    iMrgType = FALSE;
	memset(sSelQyr,'\0',MAX_QUERY_SIZE);

	sprintf(sSelQyr,"SELECT  ENTITY_TYPE,ENTITY_MANAGER_TYPE,ENTITY_MANAGER_CODE  from  ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));",sAdminId);

	logDebug2("sSelQyr :%s:",sSelQyr);
	if(mysql_query(DBQury,sSelQyr) != SUCCESS)
	{
		logSqlFatal("ERROR IN fGetOrderBook QUERY.");
		sql_Error(DBQury);
	}

	Res = mysql_store_result(DBQury);

	if(Row = mysql_fetch_row(Res))
	{
		//strncpy(sUserType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
			strcpy(sBrcnhId,Row[2]);
			logDebug2("sBrcnhId :%s:",sBrcnhId);
		}
		else
		{
			iMrgType = FALSE;
		}
	}
	logDebug2("Returning iMrgType :%d:",iMrgType);
	return iMrgType;
	logTimestamp("Exit : fChckAdminContrlr");
}
BOOL CreateFile(CHAR *RcvMsg)
{
	logTimestamp("Entry : CreateFile");
	LONG32 filecode;
	struct INT_CREATE_FILE_REQ *pReqHdr;
	pReqHdr=(struct INT_CREATE_FILE_REQ *)RcvMsg ;	
	logDebug2("pReqHdr->IntReqHeader.iSeqNo = :%d:",pReqHdr->IntReqHeader.iSeqNo);
	logDebug2("pReqHdr->IntReqHeader.iMsgLength = :%d:",pReqHdr->IntReqHeader.iMsgLength);
	logDebug2("pReqHdr->IntReqHeader.iMsgCode = :%d:",pReqHdr->IntReqHeader.iMsgCode);
	logDebug2("pReqHdr->IntReqHeader.sExcgId = :%s:",pReqHdr->IntReqHeader.sExcgId);
	logDebug2("pReqHdr->IntReqHeader.iUserId = :%llu:",pReqHdr->IntReqHeader.iUserId);
	logDebug2("pReqHdr->IntReqHeader.cSource = :%c:",pReqHdr->IntReqHeader.cSource);
	logDebug2("pReqHdr->IntReqHeader.cSegment = :%c:",pReqHdr->IntReqHeader.cSegment);
	logDebug2("pReqHdr->iFileCode = :%d:",pReqHdr->iFileCode);
	filecode  = pReqHdr->iFileCode;
	switch(filecode)
	{
		case FILE_CLIENT_MASTER: 
			CreateClientFile(RcvMsg);
			break;
		case FILE_ORDER_REPORT: 
			CreateOrderReportFile(RcvMsg);
			break;
		case FILE_TRADE_REPORT: 
			CreateTradeReport(RcvMsg);
			break;
		case FILE_CLIENT_LIMIT: 
			CreateClientLimitFile(RcvMsg);
			break;
		case FILE_NEAT:
                        NeatFileFormat(RcvMsg);
                        break;
                case FILE_NOW:
                        NowFileFormat(RcvMsg);
                        break;
                case FILE_BOLT:
                        BoltFileFormat(RcvMsg);
                        break;

		default:
			logDebug2("Got Wrong Request");
			break;


	}

	logTimestamp("Exit : CreateFile");

}
BOOL CreateClientFile(CHAR *RcvMsg)
{
	logTimestamp("Entry : CreateClientFile");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR		 sSeq[30];
	memset (sSeq,'\0',30);
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [MAX_QUERY_SIZE];
	LONG32 iRow;
	FILE *fpFile;
	//	struct INT_COMMON_REQUEST_HDR *pReqHdr;
	struct INT_CREATE_FILE_RES	pResp;	

	struct INT_CREATE_FILE_REQ *pReq;
	pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
	logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
	logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
	logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
	logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
	logDebug2("pReq->IntReqHeader.iUserId = :%llu:",pReq->IntReqHeader.iUserId);
	logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
	logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);
	logDebug2("pReq->iFileCode = :%d:",pReq->iFileCode);


	/*	pReqHdr=(struct INT_COMMON_REQUEST_HDR *)RcvMsg ;
		logDebug2("pReqHdr->iSeqNo = :%d:",pReqHdr->iSeqNo);
		logDebug2("pReqHdr->iMsgLength = :%d:",pReqHdr->iMsgLength);
		logDebug2("pReqHdr->iMsgCode = :%d:",pReqHdr->iMsgCode);
		logDebug2("pReqHdr->sExcgId = :%s:",pReqHdr->sExcgId);
		logDebug2("pReqHdr->iUserId = :%d:",pReqHdr->iUserId);
		logDebug2("pReqHdr->cSource = :%c:",pReqHdr->cSource);
		logDebug2("pReqHdr->cSegment = :%c:",pReqHdr->cSegment);

	 */
	if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	while((Row = mysql_fetch_row(Res)))
	{	
		logDebug2("Row[0] = :%s:",Row[0]);

		//	sprintf(sSeq,"%s",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	sprintf(sFileName,"%s/%s%s",sRRPath,CLIENT_MASTER_FILE_NM,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);
	sprintf(sSelectQry,"SELECT concat(IFNULL(ROW_NUM,''), ' , ', IFNULL(entity_id,''), ' , ', IFNULL(USER_id,''), ' , ', \
		IFNULL(User_Name,''), ' , ', IFNULL(login_id,''), ' , ', IFNULL(status,''), ' , ', IFNULL(login_status,''), ' , ', \
			IFNULL(PROFILE,''), ' , ', IFNULL(profile_id,''), ' , ', IFNULL(clnt_type,''), ' , ',IFNULL(entity_type,''), ' , ', IFNULL(email_id,''), ' , ', \
			IFNULL(DOB,''), ' , ', IFNULL(REPLACE(Address, ',', ';'),''), ' , ', IFNULL(mobile_no,''), ' , ', IFNULL(REPLACE(EM_ADDRESS_LINE_1, ',', ';'),''), ' , ',\
			IFNULL(REPLACE(EM_ADDRESS_LINE_2, ',', ';'),''), ' , ', IFNULL(REPLACE(EM_ADDRESS_LINE_3, ',', ';'),''), ' , ', IFNULL(RRSubStatus,''), ' , ', \
			IFNULL(em_created_date,''), ' , ', IFNULL(McxClientId,''), ' , ', IFNULL(ExchClientId,''), ' , ', IFNULL(NseEqCode,''), ' , ', \
			IFNULL(NseFoCode,''), ' , ', IFNULL(BseEqCode,''), ' , ', IFNULL(BseFoCode,''), ' , ', IFNULL(NseCurCode,''), ' , ', \
			IFNULL(ExchAllowed,''), ' , ', IFNULL(McxUserCode,''), ' , ', IFNULL(Remark1,''), ' , ', IFNULL(Remark2,''), ' , ', \
			IFNULL(Remark3,''), ' , ', IFNULL(static_ip,''), ' , ', IFNULL(PANNO,''), ' , ', IFNULL(um_product_allowed,''), ' , ',\
			IFNULL(SETTLOR_CODE,''), ' , ', IFNULL(controller,''), ' , ', IFNULL(NULLIF(TRIM(offline_flag),''),'N'), ' , ', IFNULL(ql_profile_name,'NA'), ' , ',\
			IFNULL(ENTITY_SETTLOR,''), ' , ', IFNULL(ENTITY_SETTLOR_DRV,''), ' , ', IFNULL(ENTITY_SETTLOR_CURR,''), ' , ')FROM (SELECT\
			CAST(@rn:=@rn + 1 AS UNSIGNED) ROW_NUM, e.ENTITY_CODE entity_id,u.USER_CODE USER_id,e.ENTITY_NAME User_Name,\
			u.USER_LOGIN_CODE login_id, CASE ENTITY_STATUS WHEN 'E' THEN 'Enabled' WHEN 'S' THEN 'Suspended' WHEN 'D' THEN 'Disabled'\
			ELSE ENTITY_STATUS END status, IFNULL(CASE USER_STATUS WHEN 'I' THEN 'In Active' WHEN 'A' THEN 'Active' WHEN 'L' THEN 'Locked' \
				WHEN 'R' THEN 'Reset'             END, 'In Active') login_status,             RPM_NAME PROFILE,             RPM_CODE profile_id,\
			CASE ENTITY_SUB_TYPE WHEN '2' THEN 'NRI' WHEN '7' THEN 'Client' WHEN '5' THEN 'FII' WHEN '8' THEN 'Parent NRI' ELSE 'NA' END clnt_type,CASE ENTITY_TYPE WHEN 'C' THEN 'Client' WHEN 'D' THEN 'Dealer' WHEN 'BR' THEN 'Broker' WHEN 'A' THEN 'Admin' WHEN 'B' THEN 'Branch' WHEN 'S' THEN 'Sys Admin' ELSE 'NA' END entity_type,e.ENTITY_EMAIL email_id,DATE_FORMAT(e.ENTITY_DOB, '%%d/%%m/%%Y') DOB,CONCAT(ENTITY_ADD_1, ' ', ENTITY_ADD_2, \
				' ', ENTITY_ADD_3) Address,e.ENTITY_MOBILE mobile_no,ENTITY_ADD_1 EM_ADDRESS_LINE_1,ENTITY_ADD_2 EM_ADDRESS_LINE_2,ENTITY_ADD_3 \
			EM_ADDRESS_LINE_3, CASE es.esd_subscription_status WHEN 'Y' THEN 'Subscribed' ELSE 'Unsubscribed' END RRSubStatus, \
			DATE_FORMAT(e.ENTITY_UPDATE_DATE, '%%d/%%m/%%Y') em_created_date, e.ENTITY_MCX_CODE McxClientId, e.ENTITY_NSE_CODE ExchClientId,\
			u.USER_EQU_NSE_LOC_CODE NseEqCode, u.USER_DRV_NSE_LOC_CODE NseFoCode, u.USER_EQU_BSE_LOC_CODE BseEqCode, u.USER_DRV_BSE_LOC_CODE \
			BseFoCode, u.USER_CURR_NSE_LOC_CODE NseCurCode, u.USER_EXCH_ALLOWED ExchAllowed, u.USER_COM_MCX_LOC_CODE McxUserCode,\
			u.USER_REMARK1 Remark1, u.USER_REMARK2 Remark2, u.USER_REMARK3 Remark3, u.USER_STATIC_IP static_ip, e.ENTITY_PAN PANNO,\
			u.USER_PRODUCT_ALLOWED um_product_allowed, e.ENTITY_SETTLOR AS SETTLOR_CODE, e.ENTITY_MANAGER_CODE controller,e.ENTITY_OFFLINE_FLAG \
			offline_flag, q.RPD_PROFILE_NAME ql_profile_name, ENTITY_SETTLOR, ENTITY_SETTLOR_DRV, ENTITY_SETTLOR_CURR FROM ENTITY_MASTER AS e\
			LEFT OUTER JOIN USER_MASTER u ON e.ENTITY_CODE = u.USER_ENTITY_CODE     LEFT OUTER JOIN RMS_RISK_PROFILE_MAST r ON\
			e.ENTITY_RISK_PROFILE = r.RPM_CODE     LEFT OUTER JOIN RMS_RISK_PROFILE_DET q ON e.ENTITY_QL_PROFILE = q.RPD_PROFILE_CODE\
			LEFT OUTER JOIN ENTITY_SUBSCRIPTION_DETAILS es ON e.ENTITY_CODE = es.ESD_EM_ENTITY_ID     CROSS JOIN (SELECT @rn:=0) AS rn\
			WHERE ENTITY_TYPE IN ('A' , 'D', 'C', 'S') AND e.ENTITY_CODE LIKE '%%' \
			AND e.ENTITY_MANAGER_CODE LIKE '%%'    \
			GROUP BY e.ENTITY_CODE) AS a");
	logDebug2("sSelectQry = %s",sSelectQry);



	if (mysql_query(DBQury, sSelectQry) != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("Error While Fetching the client details.");
		return FALSE;
	}


	Res = mysql_store_result(DBQury);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		fpFile = fopen(sFileName1,"wr");
		fprintf(fpFile ,"ROW_NUM, ENTITY_ID, USER_ID, USER_NAME, LOGIN_ID, STATUS, LOGIN_STATUS, PROFILE, PROFILE_ID, CLIENT_TYPE, ENTITY_TYPE, EMAIL_ID,\
				DOB, ADDRESS, MOBILE_NO, EM_ADDRESS_LINE_1, EM_ADDRESS_LINE_2, EM_ADDRESS_LINE_3, RRSUBSTATUS, EM_CREATED_DATE, MCXCLIENTID, \
				EXCHCLIENTID, NSEEQCODE, NSEFOCODE,BSEEQCODE,BSEFOCODE,NSECURCODE,EXCHALLOWED,MCXUSERCODE,REMARK1,REMARK2,REMARK3,STATIC_IP,PANNO,\
				UM_PRODUCT_ALLOWED,SETTLOR_CODE,CONTROLLER,OFFLINE_FLAG,QL_PROFILE_NAME,ENTITY_SETTLOR,ENTITY_SETTLOR_DRV,ENTITY_SETTLOR_CURR \n");
		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				//	logDebug2("Row :%s:",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
		fclose(fpFile);
	}
	fConvToPwdPrtect(sFileName,sFileName1);


	logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
	pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
	pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
	pResp.IntRespHeader.iErrorId = 0;
	pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES; 
	pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
	pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
	sprintf(pResp.sFilename,"%s%s.rrs",CLIENT_MASTER_FILE_NM,sSeq);
	logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
	logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
	logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
	logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
	logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
	logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
	logDebug2("pResp.sFilename = %s", pResp.sFilename);

	iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
		return FALSE;
	}




	logTimestamp("Exit : CreateClientFile");

}

void fConvToPwdPrtect(CHAR sFileName[FILE_NAME_LEN], CHAR sFileName1[FILE_NAME_LEN])
{
	logTimestamp("Entry : fConvToPwdPrtect");
	CHAR    sCommand[200];
	memset(&sCommand,'\0',200);
	logDebug2("sFileName:%s:",sFileName);
	logDebug2("sFileName1:%s:",sFileName1);
	sprintf(sCommand,"zip -P %s %s.rrs %s",ZIP_PASSWORD,sFileName,sFileName1);
	//	logDebug2("sCommand :%s:",sCommand);
	system(sCommand);
	sprintf(sFileName,"%s.rrs",sFileName);
	memset(&sCommand,'\0',200);
	sprintf(sCommand,"rm %s",sFileName1);
	logDebug2("sCommand :%s:",sCommand);
	system(sCommand);
	logTimestamp("Exit : fConvToPwdPrtect");

}



BOOL CreateOrderReportFile (CHAR *RcvMsg)
{
	logTimestamp("Entry : CreateOrderReportFile");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR		 sSeq[30];
	memset (sSeq,'\0',30);
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	LONG32 iRow;
	FILE *fpFile;
	//	struct INT_COMMON_REQUEST_HDR *pReqHdr;
	struct INT_CREATE_FILE_RES	pResp;	

	struct INT_CREATE_FILE_REQ *pReq;
	pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
	logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
	logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
	logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
	logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
	logDebug2("pReq->IntReqHeader.iUserId = :%llu:",pReq->IntReqHeader.iUserId);
	logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
	logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);
	logDebug2("pReq->iFileCode = :%d:",pReq->iFileCode);
	logDebug2("pReq->sDateFrom = :%s:",pReq->sDateFrom);
	logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);


	/*	pReqHdr=(struct INT_COMMON_REQUEST_HDR *)RcvMsg ;
		logDebug2("pReqHdr->iSeqNo = :%d:",pReqHdr->iSeqNo);
		logDebug2("pReqHdr->iMsgLength = :%d:",pReqHdr->iMsgLength);
		logDebug2("pReqHdr->iMsgCode = :%d:",pReqHdr->iMsgCode);
		logDebug2("pReqHdr->sExcgId = :%s:",pReqHdr->sExcgId);
		logDebug2("pReqHdr->iUserId = :%d:",pReqHdr->iUserId);
		logDebug2("pReqHdr->cSource = :%c:",pReqHdr->cSource);
		logDebug2("pReqHdr->cSegment = :%c:",pReqHdr->cSegment);

	 */
	if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	while((Row = mysql_fetch_row(Res)))
	{	
		logDebug2("Row[0] = :%s:",Row[0]);

		//	sprintf(sSeq,"%s",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	sprintf(sFileName,"%s/%s%s",sRRPath,ORDER_REPORT_FILE_NM,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);
/***
	sprintf(sSelectQry,"SELECT  CONCAT(IFNULL(CLIENT_ID, ''), ' , ', IFNULL(User_Id,''), ' , ', IFNULL(Source,''), ' , ', IFNULL(Product,''), ' , ',\
		IFNULL(StopLoss_Indicator,''), ' , ', IFNULL(Order_Number,''), ' , ', IFNULL(Buy_Sell,''), ' , ', IFNULL(Symbol,''), ' , ',\
			IFNULL(Volume_Original,''), ' , ', IFNULL(Volume_Disclosed,''), ' , ', IFNULL(Limit_Price,''), ' , ', IFNULL(Trg_Price,''), ' , ',\
			IFNULL(Day_IndiCator,''), ' , ', IFNULL(Order_DateTime,''), ' , ', IFNULL(Activity_Type,''), ' , ', IFNULL(PlacedBy,  ''),' , ',\
			IFNULL(EXCH_ID,  ''),' , ', IFNULL(SEGMENT,  ''),' , ', IFNULL(SCRIP_CODE,''), ' , ', IFNULL(ORDER_TYPE,''), ' , ', IFNULL(CTCLId, ''),\
			' , ', IFNULL(Order_Time, ''), ' , ', IFNULL(ID, ''), ' , ', IFNULL(id , '')) FROM     (SELECT          Ord_rep.*, \            
			DATE_FORMAT(Ord_rep.Order_DateTime, '%%d %%b %%Y %%r') AS 'Order_Time',             CAST(@rn:=@rn + 1 AS UNSIGNED) ID     FROM  \       
			(SELECT          a.EQ_CLIENT_ID AS 'CLIENT_ID', a.EQ_USER_ID AS 'User_Id', CASE a.EQ_SOURCE_FLG  WHEN 'M' THEN 'Mobile' WHEN 'W' \
			 THEN 'Web' WHEN 'A' THEN 'Admin' WHEN 'H' THEN 'HelpDesk' ELSE 'RapidRupee' END AS 'Source', CASE a.EQ_PRODUCT_ID WHEN 'C' THEN 'CnC'\          
			 WHEN 'M' THEN 'Margin' WHEN 'L' THEN 'MLB' WHEN 'H' THEN 'Normal' WHEN 'F' THEN 'MTF' WHEN 'S' THEN 'Collateral' WHEN 'I' THEN 'Intraday'\ 
			 WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' ELSE a.EQ_PRODUCT_ID END AS 'Product', CASE a.EQ_ORDER_TYPE  WHEN '3' OR '4' THEN 'Y' ELSE 'N'\
			 END AS 'StopLoss_Indicator', a.EQ_ORDER_NO AS 'Order_Number', CASE a.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END AS\
			 'Buy_Sell', a.EQ_SYMBOL AS 'Symbol', a.EQ_TOTAL_QTY AS 'Volume_Original', a.EQ_DISC_QTY AS 'Volume_Disclosed', CASE a.EQ_ORDER_TYPE \
			 WHEN '1' OR '3' THEN 'MKT'                 WHEN '2' OR '4' OR '5' THEN a.EQ_ORDER_PRICE END AS 'Limit_Price', CASE a.EQ_ORDER_TYPE \       
			 WHEN '3' THEN '0.00' WHEN '4' THEN a.EQ_TRIGGER_PRICE END AS 'Trg_Price', CASE a.EQ_VALIDITY  WHEN '0' THEN 'DAY' WHEN '3' THEN 'IOC'\ 
			 END AS 'Day_IndiCator', a.EQ_INTERNAL_ENTRY_DATE AS Order_DateTime, CASE WHEN a.EQ_MSG_CODE = '2073' AND a.EQ_REM_QTY <> a.EQ_TOTAL_QTY \
			 THEN 'PTRAD' WHEN a.EQ_MSG_CODE = '2074' AND a.EQ_REM_QTY > a.EQ_TOTAL_QTY THEN  'PTRAD' WHEN a.EQ_MSG_CODE = '2073' THEN 'PENDING'\           
			 WHEN a.EQ_MSG_CODE = '2000' THEN 'TRANS' WHEN a.EQ_MSG_CODE = '2040' THEN 'TRANS' WHEN a.EQ_MSG_CODE = '2070' THEN 'TRANS'\
			 WHEN a.EQ_MSG_CODE = '2231' THEN 'REJ' WHEN a.EQ_MSG_CODE = '2042' THEN 'REJ' WHEN a.EQ_MSG_CODE = '2170' THEN 'PRFRZ' \
			 WHEN a.EQ_MSG_CODE = '2074' THEN 'OMOD'  WHEN a.EQ_MSG_CODE = '2075' THEN 'OCXL' WHEN a.EQ_MSG_CODE = '2222' THEN 'PTRAD'\
			 WHEN a.EQ_MSG_CODE = '9002' THEN 'SYSCXL' WHEN a.EQ_MSG_CODE = '5113' THEN 'O-PENDING' WHEN a.EQ_MSG_CODE = '5114' THEN \
			 'O-MOD' WHEN a.EQ_MSG_CODE = '5112' THEN 'O-CAN'  WHEN a.EQ_MSG_CODE = '2072' THEN 'CAN-REJ'  END AS 'Activity_Type', a.EQ_ENTITY_ID AS\
			 PlacedBy, a.EQ_EXCH_ID AS EXCH_ID, a.EQ_SEGMENT AS SEGMENT, a.EQ_SCRIP_CODE AS SCRIP_CODE, CASE a.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET'\                 		 WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END AS 'ORDER_TYPE', 8371 CTCLId  FROM EQ_ORDERS_ARCHIVE a, ENTITY_MASTER \
			 b WHERE a.EQ_CLIENT_ID = b.ENTITY_CODE AND a.EQ_EXCH_ID LIKE CASE '' WHEN '' THEN '%%' ELSE '' END AND a.EQ_CLIENT_ID LIKE CASE '' WHEN \
			 '' THEN '%%' ELSE CONCAT('', '%%') END AND a.EQ_ENTITY_ID LIKE CASE '' WHEN '' THEN '%%' ELSE CONCAT('', '%%') END AND a.EQ_SYMBOL LIKE \
			 CASE '' WHEN '' THEN '%%' ELSE CONCAT('', '%%') END AND a.EQ_SEGMENT LIKE CASE '' WHEN '' THEN '%%' ELSE ''  END AND \
			 DATE(a.EQ_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE('%s', '%%d/%%m/%%Y') AND STR_TO_DATE('%s', '%%d/%%m/%%Y') \
			 AND a.EQ_SERIAL_NO = (SELECT MAX(c.EQ_SERIAL_NO) FROM EQ_ORDERS_ARCHIVE c WHERE c.EQ_ORDER_NO = a.EQ_ORDER_NO) AND (a.EQ_ORD_STATUS <> 'B') \
			 UNION ALL SELECT a.DRV_CLIENT_ID AS 'CLIENT_ID', a.DRV_USER_ID AS 'User_Id', CASE a.DRV_SOURCE_FLG\
			 WHEN 'M' THEN 'Mobile' WHEN 'W' THEN 'Web' WHEN 'A' THEN 'Admin' WHEN 'H' THEN 'HelpDesk' ELSE 'RapidRupee' END AS 'Source',\             
			 CASE a.DRV_PRODUCT_ID  WHEN 'C' THEN 'CnC' WHEN 'M' THEN 'Margin' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'Collateral' WHEN 'I' \
			 THEN 'Intraday' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' WHEN 'H' THEN 'Normal' WHEN 'F' THEN 'MTF' ELSE a.DRV_PRODUCT_ID END AS 'Product',\
			 CASE a.DRV_ORDER_TYPE  WHEN '3' OR '4' THEN 'Y' ELSE 'N' END AS 'StopLoss_Indicator',  a.DRV_ORDER_NO AS 'Order_Number',\
			 CASE a.DRV_BUY_SELL_IND  WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END AS 'Buy_Sell', a.DRV_SYMBOL AS 'Symbol', a.DRV_TOTAL_QTY AS \
			 'Volume_Original', a.DRV_DISC_QTY AS 'Volume_Disclosed', CASE a.DRV_ORDER_TYPE WHEN '1' OR '3' THEN 'MKT' WHEN '2' OR '4' OR '5'\
			 THEN a.DRV_ORDER_PRICE END AS 'Limit_Price',  CASE a.DRV_ORDER_TYPE WHEN '3' THEN '0.00' WHEN '4' THEN a.DRV_TRIGGER_PRICE END AS 'Trg_Price',\
			 CASE a.DRV_VALIDITY WHEN '0' THEN 'DAY' WHEN '3' THEN 'IOC' END AS 'Day_IndiCator', a.DRV_INTERNAL_ENTRY_DATE AS Order_DateTime,\
			 CASE WHEN  a.DRV_MSG_CODE = '2073' AND a.DRV_REM_QTY <> a.DRV_TOTAL_QTY THEN  'PTRAD' WHEN a.DRV_MSG_CODE = '2074'\
			 AND a.DRV_REM_QTY > a.DRV_TOTAL_QTY THEN 'PTRAD' WHEN a.DRV_MSG_CODE = '2073' THEN 'PENDING'  WHEN a.DRV_MSG_CODE = '2000' \
			 THEN 'TRANS' WHEN a.DRV_MSG_CODE = '2040' THEN 'TRANS' WHEN a.DRV_MSG_CODE = '2070' THEN 'TRANS'  WHEN a.DRV_MSG_CODE = '2231' \
			 THEN 'REJ' WHEN a.DRV_MSG_CODE = '2042' THEN 'REJ' WHEN a.DRV_MSG_CODE = '2170' THEN 'PRFRZ' WHEN a.DRV_MSG_CODE = '2074' THEN 'OMOD'\
			 WHEN a.DRV_MSG_CODE = '2075' THEN 'OCXL' WHEN a.DRV_MSG_CODE = '2222' THEN 'PTRAD'  WHEN a.DRV_MSG_CODE = '9002' THEN 'SYSCXL'\
			 WHEN a.DRV_MSG_CODE = '5113' THEN 'O-PENDING' WHEN a.DRV_MSG_CODE = '5114' THEN 'O-MOD' WHEN a.DRV_MSG_CODE = '5112' THEN 'O-CAN'\
			 WHEN a.DRV_MSG_CODE = '2072' THEN 'CAN-REJ' END AS 'Activity_Type', a.DRV_ENTITY_ID AS PlacedBy, a.DRV_EXCH_ID AS EXCH_ID,\
			 a.DRV_SEGMENT AS SEGMENT, a.DRV_SCRIP_CODE AS SCRIP_CODE,  CASE a.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' \
			 WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END AS 'ORDER_TYPE', 8371 CTCLId FROM DRV_ORDERS_ARCHIVE a, ENTITY_MASTER b CROSS JOIN\
			 (SELECT @rn:=0) r  WHERE a.DRV_CLIENT_ID = b.ENTITY_CODE AND a.DRV_EXCH_ID LIKE CASE '' WHEN '' THEN '%%' ELSE '' END  AND a.DRV_CLIENT_ID \
			 LIKE CASE '' WHEN '' THEN '%%' ELSE CONCAT('', '%%') END AND a.DRV_ENTITY_ID LIKE CASE ''   WHEN '' THEN '%%' ELSE CONCAT('', '%%')\
			 END AND a.DRV_SYMBOL LIKE CASE '' WHEN '' THEN '%%' ELSE CONCAT('', '%%') END  AND a.DRV_SEGMENT LIKE CASE '' WHEN '' THEN '%%' ELSE ''\
			 END AND DATE(a.DRV_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE('%s', '%%d/%%m/%%Y') AND STR_TO_DATE('%s', '%%d/%%m/%%Y')\
			 AND a.DRV_SERIAL_NO = (SELECT  MAX(c.DRV_SERIAL_NO) FROM DRV_ORDERS_ARCHIVE c  WHERE c.DRV_ORDER_NO = a.DRV_ORDER_NO) AND (a.DRV_STATUS <> 'B')\
			  UNION ALL SELECT a.COMM_CLIENT_ID AS 'CLIENT_ID', a.COMM_USER_ID AS 'User_Id', CASE a.COMM_SOURCE_FLG \
			 WHEN 'M' THEN 'Mobile' WHEN 'W' THEN 'Web'  WHEN 'A' THEN 'Admin' WHEN 'H' THEN 'HelpDesk' ELSE 'RapidRupee' END AS 'Source', \
			 CASE a.COMM_PRODUCT_ID WHEN 'C' THEN 'CnC' WHEN 'M' THEN 'Margin' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'Collateral'\
			 WHEN 'I' THEN 'Intraday' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' WHEN 'H' THEN 'Normal'  WHEN 'F' THEN 'MTF' ELSE a.COMM_PRODUCT_ID\
			 END AS 'Product', CASE a.COMM_ORDER_TYPE  WHEN '3' OR '4' THEN 'Y' ELSE 'N' END AS 'StopLoss_Indicator', a.COMM_ORDER_NO AS 'Order_Number',\
			 CASE a.COMM_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END AS 'Buy_Sell',  a.COMM_SYMBOL AS 'Symbol', a.COMM_TOTAL_QTY AS\
			 'Volume_Original', a.COMM_DISC_QTY AS 'Volume_Disclosed', CASE a.COMM_ORDER_TYPE WHEN '1' OR '3' THEN 'MKT' WHEN '2' OR '4' OR '5' \
			 THEN a.COMM_ORDER_PRICE  END AS 'Limit_Price', CASE a.COMM_ORDER_TYPE WHEN '3' THEN '0.00' WHEN '4' THEN a.COMM_TRIGGER_PRICE  END AS \
			 'Trg_Price', CASE a.COMM_VALIDITY  WHEN '0' THEN 'DAY' WHEN '3' THEN 'IOC' END AS 'Day_IndiCator', a.COMM_INTERNAL_ENTRY_DATE AS \
			 Order_DateTime, CASE WHEN  a.COMM_MSG_CODE = '2073' AND a.COMM_REM_QTY <> a.COMM_TOTAL_QTY THEN 'PTRAD' WHEN a.COMM_MSG_CODE = '2074'\        
			 AND a.COMM_REM_QTY > a.COMM_TOTAL_QTY THEN 'PTRAD' WHEN a.COMM_MSG_CODE = '2073' THEN 'PENDING'\
			 WHEN a.COMM_MSG_CODE = '2000' THEN 'TRANS' WHEN a.COMM_MSG_CODE = '2040' THEN 'TRANS' WHEN a.COMM_MSG_CODE = '2070' THEN 'TRANS'\  
			 WHEN a.COMM_MSG_CODE = '2231' THEN 'REJ' WHEN a.COMM_MSG_CODE = '2042' THEN 'REJ' WHEN a.COMM_MSG_CODE = '2170' THEN 'PRFRZ'\       
			 WHEN a.COMM_MSG_CODE = '2074' THEN 'OMOD' WHEN a.COMM_MSG_CODE = '2075' THEN 'OCXL' WHEN a.COMM_MSG_CODE = '2222' THEN 'PTRAD'\        
			 WHEN a.COMM_MSG_CODE = '9002' THEN 'SYSCXL' WHEN a.COMM_MSG_CODE = '5113' THEN 'O-PENDING' WHEN a.COMM_MSG_CODE = '5114' THEN 'O-MOD'\
			 WHEN a.COMM_MSG_CODE = '5112' THEN 'O-CAN' WHEN a.COMM_MSG_CODE = '2072' THEN 'CAN-REJ' END AS 'Activity_Type',          \
			 a.COMM_ENTITY_ID AS PlacedBy, a.COMM_EXCH_ID AS EXCH_ID, a.COMM_SEGMENT AS SEGMENT, a.COMM_SCRIP_CODE AS SCRIP_CODE, CASE a.COMM_ORDER_TYPE\
			 WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END AS 'ORDER_TYPE', 8371 CTCLId FROM \
			 COMM_ORDERS_ARCHIVE a, ENTITY_MASTER b CROSS JOIN (SELECT @rn:=0) r  WHERE a.COMM_CLIENT_ID = b.ENTITY_CODE AND a.COMM_EXCH_ID LIKE \
			 CASE '' WHEN '' THEN '%%' ELSE '' END  AND a.COMM_CLIENT_ID LIKE CASE '' WHEN '' THEN '%%' ELSE CONCAT('', '%%') END AND a.COMM_ENTITY_ID\
			 LIKE CASE '' WHEN '' THEN '%%'  ELSE CONCAT('', '%%')  END  AND a.COMM_SYMBOL LIKE CASE ''  WHEN '' THEN '%%'  ELSE CONCAT('', '%%') END \
			 AND a.COMM_SEGMENT LIKE CASE '' WHEN '' THEN '%%' ELSE '' END AND DATE(a.COMM_INTERNAL_ENTRY_DATE)  BETWEEN STR_TO_DATE('%s',\
					 '%%d/%%m/%%Y')\
			 AND STR_TO_DATE('%s', '%%d/%%m/%%Y') AND a.COMM_SERIAL_NO = (SELECT  MAX(c.COMM_SERIAL_NO) FROM COMM_ORDERS_ARCHIVE c WHERE\
					 c.COMM_ORDER_NO = a.COMM_ORDER_NO) AND a.COMM_STATUS <> 'B') Ord_rep) asd",pReq->sDateFrom,pReq->sDateTo,pReq->sDateFrom,pReq->sDateTo,pReq->sDateFrom,pReq->sDateTo);
****/
	sprintf(sSelectQry," SELECT   CONCAT(ORDER_NUMBER,',',   SERIALNO,',',   SEM_SECURITY_ID,',',   ORDER_TYPE,',',   QUANTITY,',',   REMAINING_QUANTITY,',',   DISCLOSE_QTY,',',   DQQTYREM,',',   PRICE,',',   TRG_PRICE,',',   TRADEDQTY,',',   PRODUCT,',',   ORDER_VALIDITY,',',   EXCHORDERNO,',',STATUS,',',   ORDER_DATE_TIME,',',   EXCH,',',IFNULL(SYMBOL,'NA'),',',IFNULL(OPTION_TYPE,'NA'),',',INSTRUMENT,',',substring_index(SYMBOL,'-',1),',', BUY_SELL,',',   SEGMENT,',',   TRANSCODE,',',   CLIENT_ID,',',   JDATE,',',   STRATEGY_ID,',',   PLACEDBY,',',  '\"', REASON_DESCRIPTION, '\"',',',   PRO_CLIENT,',',   TRADE_PRICE,',',   GOOD_TILL_DATE,',',   LEG_NO,',',   IFNULL(EXPIRY_DATE, 0),',',   IFNULL(SOURCE_FLG, 'NA'),',',   IFNULL(ALGOORDERNO, 0),',',   IFNULL(PAN_NO, 'NA'),',',   IFNULL(PARTICIPANT_TYPE, 'B'),',',   IFNULL(MKT_PROTECT_FLG, 'N'),',',   IFNULL(MKT_PROTECT_VAL, 1),',',   IFNULL(SETTLOR, 'NA'),',',   IFNULL(GTC_FLG, 'N'),',',   IFNULL(ENCASH_FLG, 'N'),',',   MKT_TYPE,',',ALGO_ID) as StringCat FROM   (SELECT     `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,       DATE_FORMAT(`A`.`EQ_INTERNAL_ENTRY_DATE`, \'%%d-%%b-%%Y %%T\') AS `ORDER_DATE_TIME`,       `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,       `A`.`EQ_EXCH_ID` AS `EXCH`,       (CASE `A`.`EQ_BUY_SELL_IND`         WHEN 'B' THEN 'Buy'         WHEN 'S' THEN 'Sell'       END) AS `BUY_SELL`,       'E' AS `SEGMENT`,       `A`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,       `A`.`EQ_SYMBOL` AS `SYMBOL`,       `A`.`EQ_LEG_NO` AS `LEG_NO`,       (CASE `A`.`EQ_PRODUCT_ID`         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'H' THEN 'NORMAL'         WHEN 'F' THEN 'MTF'         ELSE `A`.`EQ_PRODUCT_ID`       END) AS `PRODUCT`,       (CASE         WHEN           ((`A`.`EQ_MSG_CODE` = '2073')             AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN           ((`A`.`EQ_MSG_CODE` = '2074')             AND (`A`.`EQ_REM_QTY` > `A`.`EQ_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN           ((`A`.`EQ_MSG_CODE` = '2212')             AND (`A`.`EQ_REM_QTY` <> `A`.`EQ_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN (`A`.`EQ_MSG_CODE` = '2073') THEN 'Pending'         WHEN (`A`.`EQ_MSG_CODE` = '2000') THEN 'Transit'         WHEN (`A`.`EQ_MSG_CODE` = '2040') THEN 'Transit'         WHEN (`A`.`EQ_MSG_CODE` = '2070') THEN 'Transit'         WHEN (`A`.`EQ_MSG_CODE` = '2231') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '2042') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '2170') THEN 'Frozen'         WHEN (`A`.`EQ_MSG_CODE` = '2074') THEN 'Modified'         WHEN (`A`.`EQ_MSG_CODE` = '2075') THEN 'Cancelled'         WHEN (`A`.`EQ_MSG_CODE` = '2222') THEN 'Traded'         WHEN (`A`.`EQ_MSG_CODE` = '9002') THEN 'Expired'         WHEN (`A`.`EQ_MSG_CODE` = '5112') THEN 'O-Pending'         WHEN (`A`.`EQ_MSG_CODE` = '5113') THEN 'O-Modified'         WHEN (`A`.`EQ_MSG_CODE` = '5114') THEN 'O-Cancelled'         WHEN (`A`.`EQ_MSG_CODE` = '2212') THEN 'Triggered'         WHEN (`A`.`EQ_MSG_CODE` = '1111') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '1113') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '1115') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '4444') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '4445') THEN 'Rejected'         WHEN (`A`.`EQ_MSG_CODE` = '4446') THEN 'Rejected'       END) AS `STATUS`,       `A`.`EQ_TOTAL_QTY` AS `QUANTITY`,       `A`.`EQ_REM_QTY` AS `REMAINING_QUANTITY`,       (CASE `A`.`EQ_SEGMENT`         WHEN           'C'         THEN           REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`             WHEN '1' THEN 'MKT'             WHEN '3' THEN 'MKT'             ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)           END), 4), ',', '')         ELSE REPLACE(FORMAT((CASE `A`.`EQ_ORDER_TYPE`           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(`A`.`EQ_ORDER_PRICE`, 0)         END), 2), ',', '')       END) AS `PRICE`,       CASE `A`.`EQ_SEGMENT`         WHEN           'C'         THEN           ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`             WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)             WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)             ELSE 0           END), 0), 2)         ELSE ROUND(COALESCE((CASE `A`.`EQ_ORDER_TYPE`           WHEN '3' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)           WHEN '4' THEN IFNULL(`A`.`EQ_TRIGGER_PRICE`, 0)           ELSE 0         END), 0), 2)       END AS `TRG_PRICE`,       (CASE `A`.`EQ_ORDER_TYPE`         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS `ORDER_TYPE`,       CONCAT(`A`.`EQ_REM_QTY`, '/', `A`.`EQ_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,       `A`.`EQ_DISC_QTY` AS `DISCLOSE_QTY`,       `A`.`EQ_SERIAL_NO` AS `SERIALNO`,       `A`.`EQ_TOTAL_TRADED_QTY` AS `TRADEDQTY`,       `A`.`EQ_SCRIP_CODE` AS `SEM_SECURITY_ID`,       (CASE `A`.`EQ_VALIDITY`         WHEN '0' THEN 'DAY'         WHEN '1' THEN 'GTC'         WHEN '2' THEN 'ATO'         WHEN '3' THEN 'IOC'         WHEN '6' THEN 'GTD'         ELSE 'EOS'       END) AS `ORDER_VALIDITY`,       IFNULL(`A`.`EQ_LOT_SIZE`, 0) AS `SEM_NSE_REGULAR_LOT`,       0 AS `TAKE_PROFIT_TRAIL_GAP`,       `A`.`EQ_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,       `A`.`EQ_DISC_REM_QTY` AS `DQQTYREM`,       `A`.`EQ_EXCH_ORDER_NO` AS `EXCHORDERNO`,       IFNULL(NULLIF(`A`.`EQ_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,       `A`.`EQ_PRO_CLIENT` AS `PRO_CLIENT`,       `A`.`EQ_TRD_TRADE_PRICE` AS `TRADE_PRICE`,       IFNULL(`A`.`EQ_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,       `A`.`EQ_ENTITY_ID` AS `PLACEDBY`,     (CASE `A`.`EQ_STRATEGY_ID` WHEN '101' THEN 'INTRADAY_SQR_OFF' WHEN '102' THEN 'CO_SQ_OFF' WHEN '103' THEN 'BO_SQ_OFF' WHEN '104' THEN 'OFF_ORD_PUMP' WHEN '105' THEN 'SIP_ORD_PUMP' WHEN '106' THEN 'MTM_SQR_OFF' WHEN '107' THEN 'CKT_SQR_OFF' ELSE 'NA' END) AS STRATEGY_ID,       JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,       `A`.`EQ_MSG_CODE` AS `TRANSCODE`,       `A`.`EQ_EXPIRY_DATE` AS `EXPIRY_DATE`,       `A`.`EQ_OPTION_TYPE` AS `OPTION_TYPE`,       (CASE `A`.`EQ_SOURCE_FLG`         WHEN 'M' THEN 'MOBILE'         WHEN 'W' THEN 'WEB'         WHEN 'A' THEN 'ADMIN'         WHEN 'R' THEN 'RAPIDRUPEE'         WHEN 'S' THEN 'RUPEESMART'         WHEN 'F' THEN 'FALCON'         WHEN 'H' THEN 'HELPDESK'         WHEN 'E' THEN 'EXCHANGE'         WHEN 'I' THEN 'ITS'         WHEN 'B' THEN 'SYSTEM'       END) AS `SOURCE_FLG`,       `A`.`EQ_ALGO_ORDER_NO` AS `ALGOORDERNO`,       `A`.`EQ_PAN_NO` AS `PAN_NO`,       `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,       `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,       `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,       `A`.`EQ_SETTLOR` AS `SETTLOR`,       `A`.`EQ_GTC_FLG` AS `GTC_FLG`,       `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,       `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,`A`.`EQ_ALGO_ID` AS ALGO_ID   FROM     `EQ_ORDERS_ARCHIVE` `A`   JOIN (SELECT @rn:=0) r   WHERE DATE(A.EQ_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\') AND STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\')    AND `A`.`EQ_SERIAL_NO` = (SELECT         MAX(`C`.`EQ_SERIAL_NO`)       FROM         `EQ_ORDERS_ARCHIVE` `C`       WHERE         (`C`.`EQ_ORDER_NO` = `A`.`EQ_ORDER_NO`)           AND (`A`.`EQ_CF_FLAG` <> -(1))           AND (`A`.`EQ_LEG_NO` = `C`.`EQ_LEG_NO`)           AND (`A`.`EQ_ORD_STATUS` <> 'B')) UNION ALL SELECT     `DO`.`DRV_CLIENT_ID` AS `CLIENT_ID`,       DATE_FORMAT(`DO`.`DRV_INTERNAL_ENTRY_DATE`, \'%%d-%%b-%%Y %%T\') AS `ORDER_DATE_TIME`,       `DO`.`DRV_ORDER_NO` AS `ORDER NUMBER`,       `DO`.`DRV_EXCH_ID` AS `EXCH`,       (CASE `DO`.`DRV_BUY_SELL_IND`         WHEN 'B' THEN 'Buy'         WHEN 'S' THEN 'Sell'       END) AS `BUY/SELL`,       `DO`.`DRV_SEGMENT` AS `SEGMENT`,       `DO`.`DRV_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`,       `DO`.`DRV_SYMBOL` AS `SYMBOL`,       `DO`.`DRV_LEG_NO` AS `LEG_NO`,       (CASE `DO`.`DRV_PRODUCT_ID`         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'H' THEN 'NORMAL'         WHEN 'F' THEN 'MTF'         ELSE `DO`.`DRV_PRODUCT_ID`       END) AS `PRODUCT`,       (CASE         WHEN           ((`DO`.`DRV_MSG_CODE` = '2073')             AND (`DO`.`DRV_REM_QTY` <> `DO`.`DRV_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN           ((`DO`.`DRV_MSG_CODE` = '2074')             AND (`DO`.`DRV_REM_QTY` > `DO`.`DRV_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN           ((`DO`.`DRV_MSG_CODE` = '2212')             AND (`DO`.`DRV_REM_QTY` <> `DO`.`DRV_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN (`DO`.`DRV_MSG_CODE` = '2073') THEN 'Pending'         WHEN (`DO`.`DRV_MSG_CODE` = '2000') THEN 'Transit'         WHEN (`DO`.`DRV_MSG_CODE` = '2040') THEN 'Transit'         WHEN (`DO`.`DRV_MSG_CODE` = '2070') THEN 'Transit'         WHEN (`DO`.`DRV_MSG_CODE` = '2231') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '2042') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '2170') THEN 'Frozen'         WHEN (`DO`.`DRV_MSG_CODE` = '2074') THEN 'Modified'         WHEN (`DO`.`DRV_MSG_CODE` = '2075') THEN 'Cancelled'         WHEN (`DO`.`DRV_MSG_CODE` = '2222') THEN 'Traded'         WHEN (`DO`.`DRV_MSG_CODE` = '9002') THEN 'Expired'         WHEN (`DO`.`DRV_MSG_CODE` = '5112') THEN 'O-Pending'         WHEN (`DO`.`DRV_MSG_CODE` = '5113') THEN 'O-Modified'         WHEN (`DO`.`DRV_MSG_CODE` = '5114') THEN 'O-Cancelled'         WHEN (`DO`.`DRV_MSG_CODE` = '2212') THEN 'Triggered'         WHEN (`DO`.`DRV_MSG_CODE` = '1111') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '1113') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '1115') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '4444') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '4445') THEN 'Rejected'         WHEN (`DO`.`DRV_MSG_CODE` = '4446') THEN 'Rejected'       END) AS `STATUS`,       `DO`.`DRV_TOTAL_QTY` AS `QUANTITY`,       `DO`.`DRV_REM_QTY` AS `REM QTY`,       CASE `DO`.`DRV_SEGMENT`         WHEN           'C'         THEN           REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE`             WHEN '1' THEN 'MKT'             WHEN '3' THEN 'MKT'             ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0)           END), 4), ',', '')         ELSE REPLACE(FORMAT((CASE `DO`.`DRV_ORDER_TYPE`           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(`DO`.`DRV_ORDER_PRICE`, 0)         END), 2), ',', '')       END AS `PRICE`,       CASE `DO`.`DRV_SEGMENT`         WHEN           'C'         THEN           ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE`             WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)             WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)             ELSE 0           END), 0), 4)         ELSE ROUND(COALESCE((CASE `DO`.`DRV_ORDER_TYPE`           WHEN '3' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)           WHEN '4' THEN IFNULL(`DO`.`DRV_TRIGGER_PRICE`, 0)           ELSE 0         END), 0), 2)       END AS TRG_PRICE,       (CASE `DO`.`DRV_ORDER_TYPE`         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS `ORDER_TYPE`,       CONCAT(`DO`.`DRV_REM_QTY`, '/', `DO`.`DRV_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,       `DO`.`DRV_DISC_QTY` AS `DISCLOSE_QTY`,       `DO`.`DRV_SERIAL_NO` AS `SERIALNO`,       `DO`.`DRV_TOTAL_TRADED_QTY` AS `TRADEDQTY`,       `DO`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,       (CASE `DO`.`DRV_VALIDITY`         WHEN '0' THEN 'DAY'         WHEN '1' THEN 'GTC'         WHEN '2' THEN 'ATO'         WHEN '3' THEN 'IOC'         WHEN '6' THEN 'GTD'         ELSE 'EOS'       END) AS `ORDER_VALIDITY`,       `DO`.`DRV_LOT_SIZE` AS `SM_LOT_SIZE`,       0 AS `TAKE_PROFIT_TRAIL_GAP`,       `DO`.`DRV_OMS_ALGO_ORD_NO` AS `ADV_GROUP_REF_NO`,       `DO`.`DRV_DISC_REM_QTY` AS `DQQTYREM`,       `DO`.`DRV_EXCH_ORDER_NO` AS `EXCHORDERNO`,       IFNULL(NULLIF(`DO`.`DRV_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,       `DO`.`DRV_PRO_CLIENT` AS `PRO_CLIENT`,       `DO`.`DRV_TRD_TRADE_PRICE` AS `TRADE_PRICE`,       IFNULL(`DO`.`DRV_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,       `DO`.`DRV_ENTITY_ID` AS `PLACEDBY`,       (CASE `DO`.`DRV_STRATEGY_ID` WHEN '101' THEN 'INTRADAY_SQR_OFF' WHEN '102' THEN 'CO_SQ_OFF' WHEN '103' THEN 'BO_SQ_OFF' WHEN '104' THEN 'OFF_ORD_PUMP' WHEN '105' THEN 'SIP_ORD_PUMP' WHEN '106' THEN 'MTM_SQR_OFF' ELSE 'NA' END) AS STRATEGY_ID,       JULIDATE(`DO`.`DRV_INTERNAL_ENTRY_DATE`) AS `JDATE`,       `DO`.`DRV_MSG_CODE` AS `TRANSCODE`,       `DO`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,       `DO`.`DRV_OPTION_TYPE` AS `OPTION_TYPE`,       (CASE `DO`.`DRV_SOURCE_FLG`         WHEN 'M' THEN 'MOBILE'         WHEN 'W' THEN 'WEB'         WHEN 'A' THEN 'ADMIN'         WHEN 'R' THEN 'RAPIDRUPEE'         WHEN 'S' THEN 'RUPEESMART'         WHEN 'F' THEN 'FALCON'         WHEN 'H' THEN 'HELPDESK'         WHEN 'E' THEN 'EXCHANGE'         WHEN 'I' THEN 'ITS'         WHEN 'B' THEN 'SYSTEM'       END) AS `SOURCE_FLG`,       `DO`.`DRV_OMS_ALGO_ORD_NO` AS `ALGOORDERNO`,       `DO`.`DRV_PAN_NO` AS `PAN_NO`,       `DO`.`DRV_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,       `DO`.`DRV_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,       `DO`.`DRV_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,       `DO`.`DRV_SETTLOR` AS `SETTLOR`,       `DO`.`DRV_GTC_FLG` AS `GTC_FLG`,       `DO`.`DRV_ENCASH_FLG` AS `ENCASH_FLG`,       `DO`.`DRV_MKT_TYPE` AS `MKT_TYPE`,`DO`.`DRV_ALGO_ID` AS ALGO_ID   FROM     `DRV_ORDERS_ARCHIVE` `DO`   JOIN (SELECT @rn:=0) r   WHERE DATE(`DO`.DRV_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\') AND STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\')       AND     `DO`.`DRV_SERIAL_NO` = (SELECT         MAX(`DOO`.`DRV_SERIAL_NO`)       FROM         `DRV_ORDERS_ARCHIVE` `DOO`       WHERE         (`DOO`.`DRV_ORDER_NO` = `DO`.`DRV_ORDER_NO`)           AND (`DO`.`DRV_CF_FLAG` <> -(1)           AND (`DO`.`DRV_LEG_NO` = `DOO`.`DRV_LEG_NO`))           AND (`DO`.`DRV_STATUS` <> 'B')           AND (`DO`.`DRV_MKT_TYPE` <> 'SP')) UNION ALL SELECT     `CO`.`COMM_CLIENT_ID` AS `CLIENT_ID`,       DATE_FORMAT(`CO`.`COMM_INTERNAL_ENTRY_DATE`, \'%%d-%%b-%%Y %%T\') AS `ORDER_DATE_TIME`,       `CO`.`COMM_ORDER_NO` AS `ORDER NUMBER`,       `CO`.`COMM_EXCH_ID` AS `EXCH`,       (CASE `CO`.`COMM_BUY_SELL_IND`         WHEN 'B' THEN 'Buy'         WHEN 'S' THEN 'Sell'       END) AS `BUY/SELL`,       `CO`.`COMM_SEGMENT` AS `SEGMENT`,       `CO`.`COMM_INSTRUMENT_NAME` AS `SM_INSTRUMENT_NAME`,       `CO`.`COMM_SYMBOL` AS `SYMBOL`,       `CO`.`COMM_LEG_NO` AS `LEG_NO`,       (CASE `CO`.`COMM_PRODUCT_ID`         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'H' THEN 'NORMAL'         WHEN 'F' THEN 'MTF'         ELSE `CO`.`COMM_PRODUCT_ID`       END) AS `PRODUCT`,       (CASE         WHEN           ((`CO`.`COMM_MSG_CODE` = '2073')             AND (`CO`.`COMM_REM_QTY` <> `CO`.`COMM_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN           ((`CO`.`COMM_MSG_CODE` = '2074')             AND (`CO`.`COMM_REM_QTY` > `CO`.`COMM_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN           ((`CO`.`COMM_MSG_CODE` = '2212')             AND (`CO`.`COMM_REM_QTY` <> `CO`.`COMM_TOTAL_QTY`))         THEN           'Part-Traded'         WHEN (`CO`.`COMM_MSG_CODE` = '2073') THEN 'Pending'         WHEN (`CO`.`COMM_MSG_CODE` = '2000') THEN 'Transit'         WHEN (`CO`.`COMM_MSG_CODE` = '2040') THEN 'Transit'         WHEN (`CO`.`COMM_MSG_CODE` = '2070') THEN 'Transit'         WHEN (`CO`.`COMM_MSG_CODE` = '2231') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '2042') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '2170') THEN 'Frozen'         WHEN (`CO`.`COMM_MSG_CODE` = '2074') THEN 'Modified'         WHEN (`CO`.`COMM_MSG_CODE` = '2075') THEN 'Cancelled'         WHEN (`CO`.`COMM_MSG_CODE` = '2222') THEN 'Traded'         WHEN (`CO`.`COMM_MSG_CODE` = '9002') THEN 'Expired'         WHEN (`CO`.`COMM_MSG_CODE` = '5112') THEN 'O-Pending'         WHEN (`CO`.`COMM_MSG_CODE` = '5113') THEN 'O-Modified'         WHEN (`CO`.`COMM_MSG_CODE` = '5114') THEN 'O-Cancelled'         WHEN (`CO`.`COMM_MSG_CODE` = '2212') THEN 'Triggered'         WHEN (`CO`.`COMM_MSG_CODE` = '1111') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '1113') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '1115') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '4444') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '4445') THEN 'Rejected'         WHEN (`CO`.`COMM_MSG_CODE` = '4446') THEN 'Rejected'       END) AS `STATUS`,       `CO`.`COMM_TOTAL_QTY` AS `QUANTITY`,       `CO`.`COMM_REM_QTY` AS `REM QTY`,       CASE `CO`.`COMM_SEGMENT`         WHEN           'C'         THEN           REPLACE(FORMAT((CASE `CO`.`COMM_ORDER_TYPE`             WHEN '1' THEN 'MKT'             WHEN '3' THEN 'MKT'             ELSE IFNULL(`CO`.`COMM_ORDER_PRICE`, 0)           END), 4), ',', '')         ELSE REPLACE(FORMAT((CASE `CO`.`COMM_ORDER_TYPE`           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(`CO`.`COMM_ORDER_PRICE`, 0)         END), 2), ',', '')       END AS `PRICE`,       CASE `CO`.`COMM_SEGMENT`         WHEN           'C'         THEN           ROUND(COALESCE((CASE `CO`.`COMM_ORDER_TYPE`             WHEN '3' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)             WHEN '4' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)             ELSE 0           END), 0), 4)         ELSE ROUND(COALESCE((CASE `CO`.`COMM_ORDER_TYPE`           WHEN '3' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)           WHEN '4' THEN IFNULL(`CO`.`COMM_TRIGGER_PRICE`, 0)           ELSE 0         END), 0), 2)       END AS TRG_PRICE,       (CASE `CO`.`COMM_ORDER_TYPE`         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS `ORDER_TYPE`,       CONCAT(`CO`.`COMM_REM_QTY`, '/', `CO`.`COMM_TOTAL_QTY`) AS `REM_QTY_TOT_QTY`,       `CO`.`COMM_DISC_QTY` AS `DISCLOSE_QTY`,       `CO`.`COMM_SERIAL_NO` AS `SERIALNO`,       `CO`.`COMM_TOTAL_TRADED_QTY` AS `TRADEDQTY`,       `CO`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,       (CASE `CO`.`COMM_VALIDITY`         WHEN '0' THEN 'DAY'         WHEN '1' THEN 'GTC'         WHEN '2' THEN 'ATO'         WHEN '3' THEN 'IOC'         WHEN '6' THEN 'GTD'         ELSE 'EOS'       END) AS `ORDER_VALIDITY`,       `CO`.`COMM_LOT_SIZE` AS `SM_LOT_SIZE`,       0 AS `TAKE_PROFIT_TRAIL_GAP`,       `CO`.`COMM_OMS_ALGO_ORDER_NO` AS `ADV_GROUP_REF_NO`,       `CO`.`COMM_DISC_REM_QTY` AS `DQQTYREM`,       `CO`.`COMM_EXCH_ORDER_NO` AS `EXCHORDERNO`,       IFNULL(NULLIF(`CO`.`COMM_REASON_DESCRIPTION`, ''), 'NULL') AS `REASON_DESCRIPTION`,       `CO`.`COMM_PRO_CLIENT` AS `PRO_CLIENT`,       `CO`.`COMM_TRD_TRADE_PRICE` AS `TRADE_PRICE`,       IFNULL(`CO`.`COMM_GOOD_TILL_DATE`, NOW()) AS `GOOD_TILL_DATE`,       `CO`.`COMM_ENTITY_ID` AS `PLACEDBY`,       (CASE `CO`.`COMM_STRATEGY_ID` WHEN '101' THEN 'INTRADAY_SQR_OFF' WHEN '102' THEN 'CO_SQ_OFF' WHEN '103' THEN 'BO_SQ_OFF' WHEN '104' THEN 'OFF_ORD_PUMP' WHEN '105' THEN 'SIP_ORD_PUMP' WHEN '106' THEN 'MTM_SQR_OFF' ELSE 'NA' END) AS STRATEGY_ID,       JULIDATE(`CO`.`COMM_INTERNAL_ENTRY_DATE`) AS `JDATE`,       `CO`.`COMM_MSG_CODE` AS `TRANSCODE`,       `CO`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,       `CO`.`COMM_OPTION_TYPE` AS `OPTION_TYPE`,       (CASE `CO`.`COMM_SOURCE_FLG`         WHEN 'M' THEN 'MOBILE'         WHEN 'W' THEN 'WEB'         WHEN 'A' THEN 'ADMIN'         WHEN 'R' THEN 'RAPIDRUPEE'         WHEN 'S' THEN 'RUPEESMART'         WHEN 'F' THEN 'FALCON'         WHEN 'H' THEN 'HELPDESK'         WHEN 'E' THEN 'EXCHANGE'         WHEN 'I' THEN 'ITS'         WHEN 'B' THEN 'SYSTEM'       END) AS `SOURCE_FLG`,       `CO`.`COMM_OMS_ALGO_ORDER_NO` AS `ALGOORDERNO`,       `CO`.`COMM_PAN_NO` AS `PAN_NO`,       `CO`.`COMM_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,       `CO`.`COM_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,       `CO`.`COMM_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,       `CO`.`COMM_SETTLOR` AS `SETTLOR`,       `CO`.`COMM_GTC_FLG` AS `GTC_FLG`,       `CO`.`COMM_ENCASH_FLG` AS `ENCASH_FLG`,       `CO`.`COMM_MKT_TYPE` AS `MKT_TYPE` ,`CO`.`COMM_ALGO_ID` AS ALGO_ID   FROM     `COMM_ORDERS_ARCHIVE` `CO`   JOIN (SELECT @rn:=0) r   WHERE DATE(`CO`.COMM_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\') AND STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\')       AND     `CO`.`COMM_SERIAL_NO` = (SELECT         MAX(`COO`.`COMM_SERIAL_NO`)       FROM         `COMM_ORDERS_ARCHIVE` `COO`       WHERE         (`COO`.`COMM_ORDER_NO` = `CO`.`COMM_ORDER_NO`)           AND (`CO`.`COMM_CF_FLAG` <> -(1)           AND (`CO`.`COMM_LEG_NO` = `COO`.`COMM_LEG_NO`))           AND (`CO`.`COMM_STATUS` <> 'B')           AND (`CO`.`COMM_MKT_TYPE` <> 'SP'))) orderbook WHERE   1 = 1 ORDER BY ORDER_DATE_TIME DESC; ",pReq->sDateFrom,pReq->sDateTo,pReq->sDateFrom,pReq->sDateTo,pReq->sDateFrom,pReq->sDateTo);			
	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBQury, sSelectQry) != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("Error While Fetching the client details.");
		return FALSE;
	}


	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
/**
	fprintf(fpFile ,"CLIENT_ID, USER_ID, SOURCE, PRODUCT, STOPLOSS_INDICATOR, ORDER_NUMBER, BUY_SELL, SYMBOL, VOLUME_ORIGINAL, \
			VOLUME_DISCLOSED, LIMIT_PRICE, TRG_PRICE, DAY_INDICATOR, ORDER_DATETIME, ACTIVITY_TYPE, PLACEDBY, \
			EXCH_ID, SEGMENT, SCRIP_CODE, ORDER_TYPE, CTCLID, ORDER_TIME, ID, ID \n");
***/
	fprintf(fpFile ,"ORDER_NUMBER,SERIALNO,SEM_SECURITY_ID,ORDER_TYPE,QUANTITY,REMAINING_QUANTITY,DISCLOSE_QTY,DQQTYREM,PRICE,TRG_PRICE,TRADEDQTY,PRODUCT,ORDER_VALIDITY,EXCHORDERNO,STATUS,ORDER_DATE_TIME,EXCH,EXPIRY_DATE,OPTION_TYPE,INSTRUMENT,UNDERLYING,BUY_SELL,SEGMENT,TRANSCODE,CLIENT_ID,JDATE,STRATEGY_ID,PLACEDBY,REASON_DESCRIPTION,PRO_CLIENT,TRADE_PRICE,GOOD_TILL_DATE,LEG_NO,EXPIRY_DATE,SOURCE_FLG,ALGOORDERNO,PAN_NO,PARTICIPANT_TYPE,MKT_PROTECT_FLG,MKT_PROTECT_VAL,SETTLOR,GTC_FLG,ENCASH_FLG,MKT_TYPE,ALGO_ID\n");
	fclose(fpFile);
	Res = mysql_store_result(DBQury);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		fpFile = fopen(sFileName1,"wr");
/**
		fprintf(fpFile ,"CLIENT_ID, USER_ID, SOURCE, PRODUCT, STOPLOSS_INDICATOR, ORDER_NUMBER, BUY_SELL, SYMBOL, VOLUME_ORIGINAL, \
				VOLUME_DISCLOSED, LIMIT_PRICE, TRG_PRICE, DAY_INDICATOR, ORDER_DATETIME, ACTIVITY_TYPE, PLACEDBY, \
				EXCH_ID, SEGMENT, SCRIP_CODE, ORDER_TYPE, CTCLID, ORDER_TIME, ID, ID \n");
**/
		fprintf(fpFile ,"ORDER_NUMBER,SERIALNO,SEM_SECURITY_ID,ORDER_TYPE,QUANTITY,REMAINING_QUANTITY,DISCLOSE_QTY,DQQTYREM,PRICE,TRG_PRICE,TRADEDQTY,PRODUCT,ORDER_VALIDITY,EXCHORDERNO,STATUS,ORDER_DATE_TIME,EXCH,EXPIRY_DATE,OPTION_TYPE,INSTRUMENT,UNDERLYING,BUY_SELL,SEGMENT,TRANSCODE,CLIENT_ID,JDATE,STRATEGY_ID,PLACEDBY,REASON_DESCRIPTION,PRO_CLIENT,TRADE_PRICE,GOOD_TILL_DATE,LEG_NO,EXPIRY_DATE,SOURCE_FLG,ALGOORDERNO,PAN_NO,PARTICIPANT_TYPE,MKT_PROTECT_FLG,MKT_PROTECT_VAL,SETTLOR,GTC_FLG,ENCASH_FLG,MKT_TYPE,ALGO_ID\n");

		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				//	logDebug2("Row :%s:",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
		fclose(fpFile);
	}
	fConvToPwdPrtect(sFileName,sFileName1);


	logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
	pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
	pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
	pResp.IntRespHeader.iErrorId = 0;
	pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES; 
	pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
	pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
	sprintf(pResp.sFilename,"%s%s.rrs",ORDER_REPORT_FILE_NM,sSeq);
	logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
	logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
	logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
	logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
	logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
	logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
	logDebug2("pResp.sFilename = %s", pResp.sFilename);

	iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
		return FALSE;
	}




	logTimestamp("Exit : CreateOrderReportFile ");
}


BOOL fOrderSprdBook(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fOrderSprdBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewSprdOrdBookReq;
	struct VIEW_ADMIN_SPRD_ORD_BOOK_RESP pSprdOrdBookResp;
	struct VIEW_COMMON_HDR_RESP     pSprdOrdBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	//CHAR *sOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	CHAR sOrdBook  [DOUBLE_MAX_QUERY_SIZE];
	memset(sOrdBook,'\0',DOUBLE_MAX_QUERY_SIZE);

	DOUBLE64        fOrderNo = 0.00;
	LONG32          iSerialNo;
	LONG32          iLegValue = 0;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;


	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR            sProduct[10];
	CHAR            sValidity[5];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sRespClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];
	CHAR            ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;


	LONG32          iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iOrderBookTime;
	CHAR            sWhere_Clause[QUERY_SIZE];

	memset(sWhere_Clause,'\0',QUERY_SIZE);
	pViewSprdOrdBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewSprdOrdBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewSprdOrdBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("  client:%s: sEntityId :%s: ",sClientId ,pViewSprdOrdBookReq->sEntityId);

	if(strcmp(sClientId,ALL_SELECT))
	{
		sprintf(sWhere_Clause,"AND DO.DRV_CLIENT_ID = LTRIM(RTRIM(\'%s\'))",sClientId);
		logDebug2("sWhere_Clause = %s",sWhere_Clause);
	}

//	sprintf(sOrdBook,"SELECT       ORDER_NUMBER,      SERIALNO,      SECURITY_ID,      ORDER_TYPE,      QUANTITY,      REM_QTY,      DISCLOSE_QTY,      DQQTYREM,      PRICE,      TRG_PRICE,      TRADEDQTY,      PRODUCT,      ORDER_VALIDITY,      EXCHORDERNO,      ORDER_DATE_TIME,      EXCH,      BUY_SELL,      SEGMENT,      TRANSCODE,      CLIENT_ID,      JDATE,      STRATEGY_ID,      PLACEDBY,      REASON_DESCRIPTION,      PRO_CLIENT,      TRADE_PRICE,      IFNULL(GOOD_TILL_DATE, NOW()),      LEGVALUE,      IFNULL(PAN_NO, 'NA'),      IFNULL(PARTICIPANT_TYPE, 'B'),      IFNULL(SETTLOR, 'NA'),      IFNULL(MKT_PROTECT_FLG, 'N'),      IFNULL(MKT_PROTECT_VAL, 1),      IFNULL(GTC_FLG, 'N'),      IFNULL(ENCASH_FLG, 'N'),      ALGO_ORD_NO,      MKT_TYPE  FROM      (SELECT           DO.DRV_CLIENT_ID AS CLIENT_ID,              DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE, NOW()) AS ORDER_DATE_TIME,              DO.DRV_ORDER_NO AS ORDER_NUMBER,              DO.DRV_EXCH_ID AS EXCH,              (CASE DO.DRV_BUY_SELL_IND                  WHEN 'B' THEN 'Buy'                  WHEN 'S' THEN 'Sell'              END) AS BUY_SELL,              DO.DRV_SEGMENT AS SEGMENT,              DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,              DO.DRV_SYMBOL AS SYMBOL,              DO.DRV_LEG_NO AS LEG_NO,              (CASE DO.DRV_PRODUCT_ID                  WHEN 'B' THEN 'BO'                  WHEN 'V' THEN 'CO'                  WHEN 'C' THEN 'CNC'                  WHEN 'M' THEN 'MARGIN'                  WHEN 'L' THEN 'MLB'                  WHEN 'S' THEN 'COLLATERAL'                  WHEN 'I' THEN 'INTRADAY'         WHEN 'H' THEN 'NORMAL'         ELSE DO.DRV_PRODUCT_ID              END) AS PRODUCT,              (CASE                  WHEN                      ((DO.DRV_MSG_CODE = '2073')                          AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))                  THEN                      'Part-Traded'                  WHEN                      ((DO.DRV_MSG_CODE = '2074')                          AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY))                  THEN                      'Part-Traded'                  WHEN                      ((DO.DRV_MSG_CODE = '2212')                          AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))                  THEN                      'Part-Traded'                  WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending'                  WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit'                  WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit'                  WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit'                  WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen'                  WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified'                  WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled'                  WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded'                  WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired'                  WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending'                  WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified'                  WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'                  WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered'                  WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected'                  WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected'              END) AS STATUS,              DO.DRV_TOTAL_QTY AS QUANTITY,              DO.DRV_REM_QTY AS REM_QTY,              CASE DO.DRV_SEGMENT                  WHEN                      'C'                  THEN                      REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE                          WHEN '1' THEN 'MKT'                          WHEN '3' THEN 'MKT'                          ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)                      END), 4), ',', '')                  ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE                      WHEN '1' THEN 'MKT'                      WHEN '3' THEN 'MKT'                      ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)                  END), 2), ',', '')              END AS PRICE,              CASE DO.DRV_SEGMENT                  WHEN                      'C'                  THEN                      ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE                          WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)                          WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)                          ELSE 0                      END), 0), 4)                  ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE                      WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)                      WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)                      ELSE 0                  END), 0), 2)              END AS TRG_PRICE,              (CASE DO.DRV_ORDER_TYPE                  WHEN '1' THEN 'MARKET'                  WHEN '2' THEN 'LIMIT'                  WHEN '3' THEN 'SL-M'                  WHEN '4' THEN 'SL'              END) AS ORDER_TYPE,              CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,              DO.DRV_DISC_QTY AS DISCLOSE_QTY,              DO.DRV_SERIAL_NO AS SERIALNO,              DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,              DO.DRV_SCRIP_CODE AS SECURITY_ID,              (CASE DO.DRV_VALIDITY                  WHEN '0' THEN 'DAY'                  WHEN '1' THEN 'GTC'                  WHEN '2' THEN 'ATO'                  WHEN '3' THEN 'IOC'                  ELSE 'EOS'              END) AS ORDER_VALIDITY,              DO.DRV_LOT_SIZE AS SM_LOT_SIZE,              0 AS TAKE_PROFIT_TRAIL_GAP,              DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,              DO.DRV_DISC_REM_QTY AS DQQTYREM,              DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO,              IFNULL(DO.DRV_REASON_DESCRIPTION, 'NULL') AS REASON_DESCRIPTION,              DO.DRV_PRO_CLIENT AS PRO_CLIENT,              DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,              IFNULL(DO.DRV_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,              DO.DRV_ENTITY_ID AS PLACEDBY,              DO.DRV_STRATEGY_ID AS STRATEGY_ID,              JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,              DO.DRV_MSG_CODE AS TRANSCODE,              DO.DRV_LEG_NO AS LEGVALUE,              DO.DRV_PAN_NO AS PAN_NO,              DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,              DO.DRV_SETTLOR AS SETTLOR,              DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,              DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,              DO.DRV_GTC_FLG AS GTC_FLG,              DO.DRV_ENCASH_FLG AS ENCASH_FLG,              DO.DRV_OMS_ALGO_ORD_NO AS ALGO_ORD_NO,              DO.DRV_MKT_TYPE AS MKT_TYPE      FROM          DRV_ORDERS DO      JOIN (SELECT @rn:=0) r      WHERE          1 = 1 AND DO.DRV_MKT_TYPE = 'SP'              AND DO.DRV_SERIAL_NO = (SELECT                   MAX(DOO.DRV_SERIAL_NO)              FROM                  DRV_ORDERS DOO              WHERE                  (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO)                      AND (DO.DRV_OMS_ALGO_ORD_NO <> -(1)                      AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO)                      AND DO.DRV_MKT_TYPE = DOO.DRV_MKT_TYPE)                      AND (DO.DRV_STATUS <> 'B'))) orderbook  WHERE      1 = 1  ORDER BY ORDER_DATE_TIME , ORDER_NUMBER , LEGVALUE;   ",sWhere_Clause);

	sprintf(sOrdBook,"SELECT      ORDER_NUMBER,     SERIALNO,     SECURITY_ID,     ORDER_TYPE,     QUANTITY,     REM_QTY,     DISCLOSE_QTY,     DQQTYREM,     PRICE,     TRG_PRICE,     TRADEDQTY,     PRODUCT,     ORDER_VALIDITY,     EXCHORDERNO,     ORDER_DATE_TIME,     EXCH,     BUY_SELL,     SEGMENT,     TRANSCODE,     CLIENT_ID,     JDATE,     STRATEGY_ID,     PLACEDBY,     REASON_DESCRIPTION,     PRO_CLIENT,     TRADE_PRICE,     IFNULL(GOOD_TILL_DATE, NOW()),     LEGVALUE,     IFNULL(PAN_NO, 'NA'),     IFNULL(PARTICIPANT_TYPE, 'B'),     IFNULL(SETTLOR, 'NA'),     IFNULL(MKT_PROTECT_FLG, 'N'),     IFNULL(MKT_PROTECT_VAL, 1),     IFNULL(GTC_FLG, 'N'),     IFNULL(ENCASH_FLG, 'N'),     ALGO_ORD_NO,     MKT_TYPE FROM     (SELECT          DO.DRV_CLIENT_ID AS CLIENT_ID,  DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE, NOW()) AS ORDER_DATE_TIME,  DO.DRV_ORDER_NO AS ORDER_NUMBER,  DO.DRV_EXCH_ID AS EXCH,  (CASE DO.DRV_BUY_SELL_IND   WHEN 'B' THEN 'Buy'   WHEN 'S' THEN 'Sell'  END) AS BUY_SELL,  DO.DRV_SEGMENT AS SEGMENT,  DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,  DO.DRV_SYMBOL AS SYMBOL,  DO.DRV_LEG_NO AS LEG_NO,  (CASE DO.DRV_PRODUCT_ID   WHEN 'B' THEN 'BO'   WHEN 'V' THEN 'CO'   WHEN 'C' THEN 'CNC'   WHEN 'M' THEN 'MARGIN'   WHEN 'L' THEN 'MLB'   WHEN 'S' THEN 'COLLATERAL'   WHEN 'I' THEN 'INTRADAY'   WHEN 'H' THEN 'NORMAL'   ELSE DO.DRV_PRODUCT_ID  END) AS PRODUCT,  (CASE   WHEN       ((DO.DRV_MSG_CODE = '2073')           AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))   THEN       'Part-Traded'   WHEN       ((DO.DRV_MSG_CODE = '2074')           AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY))   THEN       'Part-Traded'   WHEN       ((DO.DRV_MSG_CODE = '2212')           AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))   THEN       'Part-Traded'   WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending'   WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit'   WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit'   WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit'   WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen'   WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified'   WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled'   WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded'   WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired'   WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending'   WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified'   WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'   WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered'   WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected'   WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected'  END) AS STATUS,  DO.DRV_TOTAL_QTY AS QUANTITY,  DO.DRV_REM_QTY AS REM_QTY,  CASE DO.DRV_SEGMENT   WHEN       'C'   THEN       REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)       END), 4), ',', '')   ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE       WHEN '1' THEN 'MKT'       WHEN '3' THEN 'MKT'       ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)   END), 2), ',', '')  END AS PRICE,  CASE DO.DRV_SEGMENT   WHEN       'C'   THEN       ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE           WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)           WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)           ELSE 0       END), 0), 4)   ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE       WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)       WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)       ELSE 0   END), 0), 2)  END AS TRG_PRICE,  (CASE DO.DRV_ORDER_TYPE   WHEN '1' THEN 'MARKET'   WHEN '2' THEN 'LIMIT'   WHEN '3' THEN 'SL-M'   WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,  CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,  DO.DRV_DISC_QTY AS DISCLOSE_QTY,  DO.DRV_SERIAL_NO AS SERIALNO,  DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,  DO.DRV_SCRIP_CODE AS SECURITY_ID,  (CASE DO.DRV_VALIDITY   WHEN '0' THEN 'DAY'   WHEN '1' THEN 'GTC'   WHEN '2' THEN 'ATO'   WHEN '3' THEN 'IOC'   ELSE 'EOS'  END) AS ORDER_VALIDITY,  DO.DRV_LOT_SIZE AS SM_LOT_SIZE,  0 AS TAKE_PROFIT_TRAIL_GAP,  DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,  DO.DRV_DISC_REM_QTY AS DQQTYREM,  DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO,  IFNULL(DO.DRV_REASON_DESCRIPTION, 'NULL') AS REASON_DESCRIPTION,  DO.DRV_PRO_CLIENT AS PRO_CLIENT,  DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,  IFNULL(DO.DRV_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,  DO.DRV_ENTITY_ID AS PLACEDBY,  DO.DRV_STRATEGY_ID AS STRATEGY_ID,  JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,  DO.DRV_MSG_CODE AS TRANSCODE,  DO.DRV_LEG_NO AS LEGVALUE,  DO.DRV_PAN_NO AS PAN_NO,  DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,  DO.DRV_SETTLOR AS SETTLOR,  DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,  DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,  DO.DRV_GTC_FLG AS GTC_FLG,  DO.DRV_ENCASH_FLG AS ENCASH_FLG,  DO.DRV_OMS_ALGO_ORD_NO AS ALGO_ORD_NO,  DO.DRV_MKT_TYPE AS MKT_TYPE     FROM         DRV_ORDERS DO     JOIN (SELECT @rn:=0) r     WHERE         1 = 1 AND DO.DRV_MKT_TYPE = 'SP'  AND DO.DRV_SERIAL_NO = (SELECT    MAX(DOO.DRV_SERIAL_NO)  FROM   DRV_ORDERS DOO  WHERE   (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO)       AND (DO.DRV_OMS_ALGO_ORD_NO <> -(1)       AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO)       AND DO.DRV_MKT_TYPE = DOO.DRV_MKT_TYPE)       AND (DO.DRV_STATUS <> 'B')) UNION ALL       SELECT          CO.COMM_CLIENT_ID AS CLIENT_ID,  DATE_FORMAT(CO.COMM_INTERNAL_ENTRY_DATE, NOW()) AS ORDER_DATE_TIME,  CO.COMM_ORDER_NO AS ORDER_NUMBER,  CO.COMM_EXCH_ID AS EXCH,  (CASE CO.COMM_BUY_SELL_IND   WHEN 'B' THEN 'Buy'   WHEN 'S' THEN 'Sell'  END) AS BUY_SELL,  CO.COMM_SEGMENT AS SEGMENT,  CO.COMM_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,  CO.COMM_SYMBOL AS SYMBOL,  CO.COMM_LEG_NO AS LEG_NO,  (CASE CO.COMM_PRODUCT_ID   WHEN 'B' THEN 'BO'   WHEN 'V' THEN 'CO'   WHEN 'C' THEN 'CNC'   WHEN 'M' THEN 'MARGIN'   WHEN 'L' THEN 'MLB'   WHEN 'S' THEN 'COLLATERAL'   WHEN 'I' THEN 'INTRADAY'   WHEN 'H' THEN 'NORMAL'   ELSE CO.COMM_PRODUCT_ID  END) AS PRODUCT,  (CASE   WHEN       ((CO.COMM_MSG_CODE = '2073')           AND (CO.COMM_REM_QTY <> CO.COMM_TOTAL_QTY))   THEN       'Part-Traded'   WHEN       ((CO.COMM_MSG_CODE = '2074')           AND (CO.COMM_REM_QTY > CO.COMM_TOTAL_QTY))   THEN       'Part-Traded'   WHEN       ((CO.COMM_MSG_CODE = '2212')           AND (CO.COMM_REM_QTY <> CO.COMM_TOTAL_QTY))   THEN       'Part-Traded'   WHEN (CO.COMM_MSG_CODE = '2073') THEN 'Pending'   WHEN (CO.COMM_MSG_CODE = '2000') THEN 'Transit'   WHEN (CO.COMM_MSG_CODE = '2040') THEN 'Transit'   WHEN (CO.COMM_MSG_CODE = '2070') THEN 'Transit'   WHEN (CO.COMM_MSG_CODE = '2231') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '2042') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '2170') THEN 'Frozen'   WHEN (CO.COMM_MSG_CODE = '2074') THEN 'Modified'   WHEN (CO.COMM_MSG_CODE = '2075') THEN 'Cancelled'   WHEN (CO.COMM_MSG_CODE = '2222') THEN 'Traded'   WHEN (CO.COMM_MSG_CODE = '9002') THEN 'Expired'   WHEN (CO.COMM_MSG_CODE = '5112') THEN 'O-Pending'   WHEN (CO.COMM_MSG_CODE = '5113') THEN 'O-Modified'   WHEN (CO.COMM_MSG_CODE = '5114') THEN 'O-Cancelled'   WHEN (CO.COMM_MSG_CODE = '2212') THEN 'Triggered'   WHEN (CO.COMM_MSG_CODE = '1111') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '1113') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '1115') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '4444') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '4445') THEN 'Rejected'   WHEN (CO.COMM_MSG_CODE = '4446') THEN 'Rejected'  END) AS STATUS,  CO.COMM_TOTAL_QTY AS QUANTITY,  CO.COMM_REM_QTY AS REM_QTY,  CASE CO.COMM_SEGMENT   WHEN       'C'   THEN       REPLACE(FORMAT((CASE CO.COMM_ORDER_TYPE           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(CO.COMM_ORDER_PRICE, 0)       END), 4), ',', '')   ELSE REPLACE(FORMAT((CASE CO.COMM_ORDER_TYPE       WHEN '1' THEN 'MKT'       WHEN '3' THEN 'MKT'       ELSE IFNULL(CO.COMM_ORDER_PRICE, 0)   END), 2), ',', '')  END AS PRICE,  CASE CO.COMM_SEGMENT   WHEN       'C'   THEN       ROUND(COALESCE((CASE CO.COMM_ORDER_TYPE           WHEN '3' THEN IFNULL(CO.COMM_TRIGGER_PRICE, 0)           WHEN '4' THEN IFNULL(CO.COMM_TRIGGER_PRICE, 0)           ELSE 0       END), 0), 4)   ELSE ROUND(COALESCE((CASE CO.COMM_ORDER_TYPE       WHEN '3' THEN IFNULL(CO.COMM_TRIGGER_PRICE, 0)       WHEN '4' THEN IFNULL(CO.COMM_TRIGGER_PRICE, 0)       ELSE 0   END), 0), 2)  END AS TRG_PRICE,  (CASE CO.COMM_ORDER_TYPE   WHEN '1' THEN 'MARKET'   WHEN '2' THEN 'LIMIT'   WHEN '3' THEN 'SL-M'   WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,  CONCAT(CO.COMM_REM_QTY, '/', CO.COMM_TOTAL_QTY) AS REM_QTY_TOT_QTY,  CO.COMM_DISC_QTY AS DISCLOSE_QTY,  CO.COMM_SERIAL_NO AS SERIALNO,  CO.COMM_TOTAL_TRADED_QTY AS TRADEDQTY,  CO.COMM_SCRIP_CODE AS SECURITY_ID,  (CASE CO.COMM_VALIDITY   WHEN '0' THEN 'DAY'   WHEN '1' THEN 'GTC'   WHEN '2' THEN 'ATO'   WHEN '3' THEN 'IOC'   ELSE 'EOS'  END) AS ORDER_VALIDITY,  CO.COMM_LOT_SIZE AS SM_LOT_SIZE,  0 AS TAKE_PROFIT_TRAIL_GAP,  CO.COMM_OMS_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,  CO.COMM_DISC_REM_QTY AS DQQTYREM,  CO.COMM_EXCH_ORDER_NO AS EXCHORDERNO,  IFNULL(CO.COMM_REASON_DESCRIPTION, 'NULL') AS REASON_DESCRIPTION,  CO.COMM_PRO_CLIENT AS PRO_CLIENT,  CO.COMM_TRD_TRADE_PRICE AS TRADE_PRICE,  IFNULL(CO.COMM_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,  CO.COMM_ENTITY_ID AS PLACEDBY,  CO.COMM_STRATEGY_ID AS STRATEGY_ID,  JULIDATE(CO.COMM_INTERNAL_ENTRY_DATE) AS JDATE,  CO.COMM_MSG_CODE AS TRANSCODE,  CO.COMM_LEG_NO AS LEGVALUE,  CO.COMM_PAN_NO AS PAN_NO,  CO.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,  CO.COMM_SETTLOR AS SETTLOR,  CO.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,  CO.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,  CO.COMM_GTC_FLG AS GTC_FLG,  CO.COMM_ENCASH_FLG AS ENCASH_FLG,  CO.COMM_OMS_ALGO_ORDER_NO AS ALGO_ORD_NO,  CO.COMM_MKT_TYPE AS MKT_TYPE     FROM         COMM_ORDERS CO     JOIN (SELECT @rn:=0) r     WHERE         1 = 1 AND CO.COMM_MKT_TYPE = 'SP'  AND CO.COMM_SERIAL_NO = (SELECT    MAX(COO.COMM_SERIAL_NO)  FROM     COMM_ORDERS COO  WHERE   (COO.COMM_ORDER_NO = CO.COMM_ORDER_NO)       AND (CO.COMM_OMS_ALGO_ORDER_NO <> -(1)       AND (CO.COMM_LEG_NO = COO.COMM_LEG_NO)       AND CO.COMM_MKT_TYPE = COO.COMM_MKT_TYPE)       AND (CO.COMM_STATUS <> 'B'))) orderbook WHERE     1 = 1 ORDER BY ORDER_DATE_TIME , ORDER_NUMBER , LEGVALUE;    ",sWhere_Clause);


	printf(" fOrderSprdBook :%s: \n",sOrdBook);

	if(mysql_query(DBQury,sOrdBook ) != SUCCESS)
	{
		logFatal("ERROR in Order BOOK Query.");
		sql_Error(DBQury);
	}



	Res = mysql_store_result(DBQury);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec/2;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pSprdOrdBookHdrResp.IntRespHeader.iSeqNo = 0;
	pSprdOrdBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pSprdOrdBookHdrResp.IntRespHeader.iErrorId = 0;
	pSprdOrdBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SPRD_ORD_BOOK_HDR_RESP;
	pSprdOrdBookHdrResp.IntRespHeader.iUserId = pViewSprdOrdBookReq->ReqHeader.iUserId;
	pSprdOrdBookHdrResp.IntRespHeader.cSource = pViewSprdOrdBookReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewSprdOrdBookReq->ReqHeader.cUserType;

	pSprdOrdBookHdrResp.cMsgType = 'H';
	pSprdOrdBookHdrResp.iNoofRec = iNoOfRec/2;

	logDebug1(" pSprdOrdBookHdrResp.cMsgType:%c:,pSprdOrdBookHdrResp.iNoofRec:%d:",pSprdOrdBookHdrResp.cMsgType,pSprdOrdBookHdrResp.iNoofRec);

	logDebug1("pViewSprdOrdBookReq->ReqHeader.iUserId = %llu",pViewSprdOrdBookReq->ReqHeader.iUserId);
	iRelayID = find_admin_adapter(pViewSprdOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pSprdOrdBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iTrdRtrToRel);
		return FALSE;
	}
	logDebug2("Here 1");


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			//if(Row=mysql_fetch_row(Res))
			while(Row=mysql_fetch_row(Res))
			{
				logDebug2("THisi is before If :%f: :%d:",fOrderNo,iLegValue);
				//if(fOrderNo == atof(Row[0]) && iLegValue ==1)
				if(fOrderNo == 0.00 && iLegValue == 0)
				{
					logDebug2("THisi is inside If");

					fOrderNo = atof(Row[0]);
					iLegValue = atoi(Row[27]);


					pSprdOrdBookResp.IntRespHeader.iSeqNo = 0;
					pSprdOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_SPRD_ORD_BOOK_RESP);
					pSprdOrdBookResp.IntRespHeader.iErrorId = 0;
					pSprdOrdBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_SPRD_ORD_BOOK_RESP;
					pSprdOrdBookResp.IntRespHeader.iUserId = pViewSprdOrdBookReq->ReqHeader.iUserId;
					pSprdOrdBookResp.IntRespHeader.cSource  = pViewSprdOrdBookReq->ReqHeader.cSource ;
					//                                      pSprdOrdBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewSprdOrdBookReq->ReqHeader.cUserType;

					logDebug2(" iTempNoOfRec :%d: ",iTempNoOfRec);


					if(iTempNoOfRec <= 2)
					{
						pSprdOrdBookResp.cMsgType = 'T';
					}
					else
					{
						pSprdOrdBookResp.cMsgType = 'D';
					}
					pSprdOrdBookResp.suborderbook[j].fOrderNo = atof(Row[0]);
					pSprdOrdBookResp.suborderbook[j].iSerialNo = atoi(Row[1]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sSecurityID,Row[2] ,SECURITY_ID_LEN);
					strncpy(pSprdOrdBookResp.suborderbook[j].sOrderType,Row[3] ,8);
					pSprdOrdBookResp.suborderbook[j].fQty = atof(Row[4]);
					pSprdOrdBookResp.suborderbook[j].fRemQty =atof(Row[5]) ;
					pSprdOrdBookResp.suborderbook[j].fDQQty = atof(Row[6]);
					//pSprdOrdBookResp.suborderbook[j].fDQQtyRem = atof(Row[7]);
					pSprdOrdBookResp.suborderbook[j].fPrice = atof(Row[8]);
					pSprdOrdBookResp.suborderbook[j].fTrgPrice = atof(Row[9]);
					pSprdOrdBookResp.suborderbook[j].fTradeQty = atof(Row[10]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sProduct,Row[11] ,10);
					strncpy(pSprdOrdBookResp.suborderbook[j].sValidity,Row[12] ,5);
					strncpy(pSprdOrdBookResp.suborderbook[j].sExchOrderNumber,Row[13] ,BSE_EXCH_ORDER_NO_LEN);
					strncpy(pSprdOrdBookResp.suborderbook[j].sDatetime,Row[14] ,DATE_LENGTH);
					strncpy(pSprdOrdBookResp.suborderbook[j].sExcgId,Row[15] ,EXCHANGE_LEN);
					memset(pSprdOrdBookResp.suborderbook[j].sBuySellInd,'\0',5);
					strncpy(pSprdOrdBookResp.suborderbook[j].sBuySellInd,Row[16],5);
					pSprdOrdBookResp.suborderbook[j].cSegment = Row[17][0];
					pSprdOrdBookResp.suborderbook[j].iTranscode = atoi(Row[18]);

					strncpy(pSprdOrdBookResp.suborderbook[j].sClientId,Row[19],CLIENT_ID_LEN);

					pSprdOrdBookResp.suborderbook[j].iDateTime = atoi(Row[20]);


					pSprdOrdBookResp.suborderbook[j].iStrategyId = atoi(Row[21]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sEntityId , Row[22],ENTITY_ID_LEN);
					strncpy(pSprdOrdBookResp.suborderbook[j].sReasonDesc, Row[23],DB_REASON_DESC_LEN);
					pSprdOrdBookResp.suborderbook[j].cProClient =  Row[24][0];
					pSprdOrdBookResp.suborderbook[j].fTrdPrice  = atof(Row[25]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sGoodTillDaysDate, Row[26],DB_DATETIME_LEN);
					pSprdOrdBookResp.suborderbook[j].iLegValue = atoi(Row[27]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sPanID, Row[28],INT_PAN_LEN);
					pSprdOrdBookResp.suborderbook[j].cParticipantType= Row[29][0];
					strncpy(pSprdOrdBookResp.suborderbook[j].sSettlor, Row[30],SETTLOR_LEN);
					pSprdOrdBookResp.suborderbook[j].cMarkProFlag = Row[31][0];
					pSprdOrdBookResp.suborderbook[j].fMarkProVal = atof(Row[32]);
					pSprdOrdBookResp.suborderbook[j].cGTCFlag = Row[33][0];
					pSprdOrdBookResp.suborderbook[j].cEncashFlag = Row[34][0];
					pSprdOrdBookResp.suborderbook[j].fAlgoOrderNo = atof(Row[35]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sMktType,Row[36],MKT_TYPE_LEN);



					logInfo(" ----------------- Printing Header ------------------------------------");
					logDebug2(" pSprdOrdBookResp.IntRespHeader.iMsgLength :%d:",pSprdOrdBookResp.IntRespHeader.iMsgLength);
					logDebug2(" pSprdOrdBookResp.IntRespHeader.iMsgCode :%d:",pSprdOrdBookResp.IntRespHeader.iMsgCode);
					logDebug2(" pSprdOrdBookResp.IntRespHeader.iUserId:%llu:",pSprdOrdBookResp.IntRespHeader.iUserId);
					logDebug2(" pSprdOrdBookResp.IntRespHeader.cSource :%c:",pSprdOrdBookResp.IntRespHeader.cSource);
					//                                      logDebug2(" pSprdOrdBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pSprdOrdBookResp.IntRespHeader.cUserTypeOrLogInfoType);

					logInfo(" -----------------Printing VALUES ------------------------------------");
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].sExcgId :%s: strlen(pSprdOrdBookResp.suborderbook[j].sExcgId):%d:",j,pSprdOrdBookResp.suborderbook[j].sExcgId,strlen(pSprdOrdBookResp.suborderbook[j].sExcgId));
					logDebug2(" pSprdOrdBookResp.cMsgType :%c:",pSprdOrdBookResp.cMsgType);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].fOrderNo :%lf:",j,pSprdOrdBookResp.suborderbook[j].fOrderNo);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].fPrice :%lf:",j,pSprdOrdBookResp.suborderbook[j].fPrice);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].iSerialNo:%d:",j,pSprdOrdBookResp.suborderbook[j].iSerialNo);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].iTranscode:%d:",j,pSprdOrdBookResp.suborderbook[j].iTranscode);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].sBuySellInd:%s: strlen(pSprdOrdBookResp.suborderbook.sBuySellInd):%d:",j,pSprdOrdBookResp.suborderbook[j].sBuySellInd,strlen(pSprdOrdBookResp.suborderbook[j].sBuySellInd));
					logDebug2(" pSprdOrdBookResp.suborderbook.sSecurityID:%s: strlen(pSprdOrdBookResp.suborderbook.sSecurityID):%d:",pSprdOrdBookResp.suborderbook[j].sSecurityID,strlen(pSprdOrdBookResp.suborderbook[j].sSecurityID));
					logDebug2(" pSprdOrdBookResp.suborderbook.sOrderType :%s: strlen(pSprdOrdBookResp.suborderbook.sOrderType):%d:",pSprdOrdBookResp.suborderbook[j].sOrderType,strlen(pSprdOrdBookResp.suborderbook[j].sOrderType));
					logDebug2(" pSprdOrdBookResp.suborderbook.sProduct:%s: strlen(pSprdOrdBookResp.suborderbook.sProduct):%d:",pSprdOrdBookResp.suborderbook[j].sProduct,strlen(pSprdOrdBookResp.suborderbook[j].sProduct));
					logDebug2(" pSprdOrdBookResp.cMsgType :%c:",pSprdOrdBookResp.cMsgType);
					logDebug2(" pSprdOrdBookResp.iLegValue :%d:",pSprdOrdBookResp.suborderbook[j].iLegValue);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].PanID :%s:",j,pSprdOrdBookResp.suborderbook[j].sPanID);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cParticipantType :%c:",j,pSprdOrdBookResp.suborderbook[j].cParticipantType);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].sSettlor:%s:",j,pSprdOrdBookResp.suborderbook[j].sSettlor);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cMarkProFlag:%c:",j,pSprdOrdBookResp.suborderbook[j].cMarkProFlag);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].fMarkProVal:%f:",j,pSprdOrdBookResp.suborderbook[j].fMarkProVal);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cGTCFlag:%c:",j,pSprdOrdBookResp.suborderbook[j].cGTCFlag);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cEncashFlag:%c:",j,pSprdOrdBookResp.suborderbook[j].cEncashFlag);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].fAlgoOrderNo:%f:",j,pSprdOrdBookResp.suborderbook[j].fAlgoOrderNo);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].sMktType:%f:",j,pSprdOrdBookResp.suborderbook[j].sMktType);
				}
				else
				{
					memset(pSprdOrdBookResp.suborderbook[j].sBuySellInd,'\0',5);
					strncpy(pSprdOrdBookResp.suborderbook[j].sBuySellInd,Row[16],5);
					logDebug2("THisi is inside else Leg:%d:",atoi(Row[27]));
					logDebug2("pSprdOrdBookResp.suborderbook[j].sSecurityID :%s: Row[2] :%s:",pSprdOrdBookResp.suborderbook[j].sSecurityID,Row[2]);
					sprintf(pSprdOrdBookResp.suborderbook[j].sSecurityID,"%s-%s",pSprdOrdBookResp.suborderbook[j].sSecurityID,Row[2] );

					logDebug2("pSprdOrdBookResp.suborderbook[j].sSecurityID :%s:",pSprdOrdBookResp.suborderbook[j].sSecurityID);
					fOrderNo = 0.00;
					iLegValue = 0;
					break;
				}
			}
			//iTempNoOfRec--;
			iTempNoOfRec = iTempNoOfRec - 2;
		}

		if(( WriteMsgQ( iTrdRtrToRel, (CHAR *)&pSprdOrdBookResp,sizeof(struct VIEW_ADMIN_SPRD_ORD_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRtrToRel);
			return FALSE;
		}


	}


	return TRUE;


}                                                                 


BOOL RestartProceess(CHAR *RcvMsg)
{
	logTimestamp("Entry RestartProceess");
	CHAR c_aCommand[150];
	FILE *fppopen;
	struct INT_COMMON_REQUEST_HDR *pReq;
	CHAR sretval[500];
	LONG32 iretval = 0;
	struct INT_RD_RESTART_RES pResp;
	pReq=(struct INT_COMMON_REQUEST_HDR *)RcvMsg ;
	//      memset ( c_aCommand ,'\0',150);
	//      memset ( sretval,'\0',500);
	logDebug2("pReq->iSeqNo = :%d:",pReq->iSeqNo);
	logDebug2("pReq->iMsgLength = :%d:",pReq->iMsgLength);
	logDebug2("pReq->iMsgCode = :%d:",pReq->iMsgCode);
	logDebug2("pReq->sExcgId = :%s:",pReq->sExcgId);
	logDebug2("pReq->iUserId = :%llu:",pReq->iUserId);
	logDebug2("pReq->cSource = :%c:",pReq->cSource);
	logDebug2("pReq->cSegment = :%c:",pReq->cSegment);



	logDebug2("Process is Going To restart ");
	sprintf (c_aCommand ,"../MonitoringTools/RestartProcess.sh RupeeDaemon");
	logDebug2("c_aCommand :%s:",c_aCommand);
	fppopen = popen(c_aCommand, "r");
	fscanf(fppopen, "%s",sretval);
	pclose(fppopen);
	logDebug2(" sretval = [%s]",sretval);

	pResp.IntRespHeader.iSeqNo = pReq->iSeqNo ;
	pResp.IntRespHeader.iMsgLength = sizeof(struct INT_RD_RESTART_RES);
	pResp.IntRespHeader.iErrorId = 0;
	pResp.IntRespHeader.iMsgCode = TC_INT_RESTART_SHEDULER_RES;
	pResp.IntRespHeader.iUserId = pReq->iUserId;
	pResp.IntRespHeader.cSource = pReq->cSource;
	sprintf(pResp.sResponse,"RupeeDeamon Successfully Restarted");
	logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
	logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
	logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
	logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
	logDebug2("pResp.IntRespHeader.iUserId= %d", pResp.IntRespHeader.iUserId);
	logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
	logDebug2("pResp.sResponse = %s", pResp.sResponse);

	iRelayID = find_admin_adapter(pReq->iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_RD_RESTART_RES) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
		return FALSE;
	}




	logTimestamp("Exit RestartProceess");


}






BOOL CreateTradeReport (CHAR *RcvMsg)
{
	logTimestamp("Entry : CreateTradeReport");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR		 sSeq[30];
	memset (sSeq,'\0',30);
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	LONG32 iRow;
	FILE *fpFile;
	//	struct INT_COMMON_REQUEST_HDR *pReqHdr;
	struct INT_CREATE_FILE_RES	pResp;	

	struct INT_CREATE_FILE_REQ *pReq;
	pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
	//	sprintf(pReq->sDateFrom,"01/09/2018");
	//	sprintf(pReq->sDateTo,"01/11/2018");
	logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
	logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
	logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
	logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
	logDebug2("pReq->IntReqHeader.iUserId = :%llu:",pReq->IntReqHeader.iUserId);
	logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
	logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);
	logDebug2("pReq->iFileCode = :%d:",pReq->iFileCode);
	logDebug2("pReq->sDateFrom = :%s:",pReq->sDateFrom);
	logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);


	/*	pReqHdr=(struct INT_COMMON_REQUEST_HDR *)RcvMsg ;
		logDebug2("pReqHdr->iSeqNo = :%d:",pReqHdr->iSeqNo);
		logDebug2("pReqHdr->iMsgLength = :%d:",pReqHdr->iMsgLength);
		logDebug2("pReqHdr->iMsgCode = :%d:",pReqHdr->iMsgCode);
		logDebug2("pReqHdr->sExcgId = :%s:",pReqHdr->sExcgId);
		logDebug2("pReqHdr->iUserId = :%d:",pReqHdr->iUserId);
		logDebug2("pReqHdr->cSource = :%c:",pReqHdr->cSource);
		logDebug2("pReqHdr->cSegment = :%c:",pReqHdr->cSegment);

	 */
	if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	while((Row = mysql_fetch_row(Res)))
	{	
		logDebug2("Row[0] = :%s:",Row[0]);

		//	sprintf(sSeq,"%s",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	sprintf(sFileName,"%s/%s%s",sRRPath,TRADE_REPORT_FILE_NM,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);
	logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);
/***
	sprintf(sSelectQry,"SELECT \
			CONCAT(Trade_Number,\
				',',\
				Symbol,\
				',',   \
				User_Id,\
				',',    \
				Client_Id,\
				',',      \
				Buy_Sell, \
				',',      \
				Product,  \
				',',      \
				Trade_Quantity, \
				',',            \
				Trade_Price,\
				',', \
				Source,\
				',',  \
				DB_SORUCE,\
				',',   \
				Order_number,\
				',',         \
				TRADE_VALUE,\
				',', \
				Order_DateTime,\
				',',\
				PlacedBy,\
				',',\
				EXCH_ID,\
				',', \
				SEGMENT,\
				',', \
				ORDER_TYPE,\
				',', \
				SCRIP_CO,\
				',', \
				CTCLId,\
				',', \
				Order_Time)\
				FROM \
				(SELECT \
				 Trd_rep.*,\
				 DATE_FORMAT(Trd_rep.Order_DateTime, '%%d %%b %%Y %%r') AS 'Order_Time'\
				 FROM \
				 (SELECT\
				  a.EQ_TRD_EXCH_TRADE_NO AS 'Trade_Number',\
				  a.EQ_SYMBOL AS 'Symbol', \
				  a.EQ_USER_ID AS 'User_Id',\
				  a.EQ_CLIENT_ID AS 'Client_Id', \
				  CASE a.EQ_BUY_SELL_IND \
				  WHEN 'B' THEN 'Buy'\
				  WHEN 'S' THEN 'Sell'\
				  END AS 'Buy_Sell', \
				  CASE a.EQ_PRODUCT_ID\
				  WHEN 'C' THEN 'CnC' \
				  WHEN 'M' THEN 'Margin'\
				  WHEN 'L' THEN 'MLB' \
				  WHEN 'S' THEN 'Collateral' \
				  WHEN 'I' THEN 'Intraday' \
				  WHEN 'V' THEN 'CO'\
				  WHEN 'B' THEN 'BO'\
				  ELSE a.EQ_PRODUCT_ID \
				  END AS 'Product', \
				  a.EQ_TOTAL_TRADED_QTY AS 'Trade_Quantity',\
				  CASE TRIM(FORMAT(IFNULL(a.EQ_TRD_TRADE_PRICE, 0), 2))\
				  WHEN '-.01' THEN '0.00'\
				  ELSE TRIM(FORMAT(IFNULL(a.EQ_TRD_TRADE_PRICE, 0), 2)) \
				  END AS 'Trade_Price',\
				  CASE a.EQ_SOURCE_FLG \
				  WHEN 'M' THEN 'Mobile'\
				  WHEN 'W' THEN 'Web'\
				  WHEN 'A' THEN 'Admin'\
				  WHEN 'H' THEN 'HelpDesk'\
				  WHEN 'R' THEN 'RapidRupee'\
				  WHEN 'S' THEN 'RRNext'\
				  WHEN 'I' THEN 'ITS'\
				  END AS 'Source',\
				  a.EQ_SOURCE_FLG AS DB_SORUCE,\
				  a.EQ_EXCH_ORDER_NO AS 'Order_number',\
				  ROUND(a.EQ_TRD_TRADE_PRICE * a.EQ_TOTAL_TRADED_QTY, 2) AS 'TRADE_VALUE',\
				  a.EQ_INTERNAL_ENTRY_DATE AS Order_DateTime,\
				  a.EQ_ENTITY_ID AS PlacedBy, \
				  a.EQ_EXCH_ID AS EXCH_ID,\
				  a.EQ_SEGMENT AS SEGMENT,\
				  CASE a.EQ_ORDER_TYPE \
				  WHEN '1' THEN 'MARKET'\
				  WHEN '2' THEN 'LIMIT'\
				  WHEN '3' THEN 'SL-M'\
				  WHEN '4' THEN 'SL' \
				  END AS 'ORDER_TYPE',\
				  a.EQ_SCRIP_CODE AS SCRIP_CO, \
				  8371 CTCLId \
				  FROM \
				  EQ_ORDERS_ARCHIVE a, ENTITY_MASTER b\
				  WHERE \
				  a.EQ_CLIENT_ID = b.ENTITY_CODE \
				  AND a.EQ_ALGO_ORDER_NO <> - 1 \
				  AND a.EQ_ORD_STATUS = 'T' UNION ALL SELECT \
				  a.DRV_TRD_EXCH_TRADE_NO AS 'Trade Number',\
				  a.DRV_SYMBOL AS 'Symbol',\
				  a.DRV_USER_ID AS 'User Id',\
				  a.DRV_CLIENT_ID AS 'Client_Id',\
				  CASE a.DRV_BUY_SELL_IND \
				  WHEN 'B' THEN 'Buy' \
				  WHEN 'S' THEN 'Sell'\
				  END AS 'Buy/Sell',  \
				  CASE a.DRV_PRODUCT_ID \
				  WHEN 'C' THEN 'CNC'   \
				  WHEN 'M' THEN 'Margin'\
				  WHEN 'L' THEN 'MLB'   \
				  WHEN 'S' THEN 'Collateral'\
				  WHEN 'I' THEN 'Intraday'  \
				  WHEN 'V' THEN 'CO' \
				  WHEN 'B' THEN 'BO' \
				  ELSE a.DRV_PRODUCT_ID\
				  END AS 'Product', \
				  a.DRV_TOTAL_TRADED_QTY AS 'Trade Quantity',\
				  CASE TRIM(FORMAT(IFNULL(a.DRV_TRD_TRADE_PRICE, 0), 2))\
				  WHEN '-.01' THEN '0.00'\
				  ELSE TRIM(FORMAT(IFNULL(a.DRV_TRD_TRADE_PRICE, 0), 2))\
				  END AS 'Trade Price',\
				  CASE a.DRV_SOURCE_FLG \
				  WHEN 'M' THEN 'Mobile'\
				  WHEN 'W' THEN 'Web'   \
				  WHEN 'A' THEN 'Admin' \
				  WHEN 'H' THEN 'HelpDesk'\
				  WHEN 'R' THEN 'RapidRupee'\
				  WHEN 'S' THEN 'RRNext' \
				  WHEN 'I' THEN 'ITS' \
				  END AS 'Source', \
				  a.DRV_SOURCE_FLG AS DB_SORUCE,\
				  a.DRV_EXCH_ORDER_NO AS 'Order number',\
				  ROUND(a.DRV_TRD_TRADE_PRICE * a.DRV_TOTAL_TRADED_QTY, 2) AS 'TRADE_VALUE', \
				  a.DRV_INTERNAL_ENTRY_DATE AS Order_DateTime, \
				  a.DRV_ENTITY_ID AS PlacedBy,\
				  a.DRV_EXCH_ID AS EXCH_ID,\
				  a.DRV_SEGMENT AS SEGMENT,\
				  CASE a.DRV_ORDER_TYPE\
				  WHEN '1' THEN 'MARKET'\
				  WHEN '2' THEN 'LIMIT'\
				  WHEN '3' THEN 'SL-M'\
				  WHEN '4' THEN 'SL'\
				  END AS 'ORDER_TYPE',\
				  a.DRV_SCRIP_CODE AS SCRIP_CODE,\
				  8371 CTCLId \
				  FROM \
				  DRV_ORDERS_ARCHIVE a, ENTITY_MASTER b \
				  WHERE \
				  a.DRV_CLIENT_ID = b.ENTITY_CODE  \
				  AND a.DRV_OMS_ALGO_ORD_NO <> - 1\
				  AND a.DRV_CF_FLAG <> - 1 \
				  AND a.DRV_STATUS = 'T') Trd_rep\
				  ORDER BY Trd_rep.Order_DateTime) abv\
				  WHERE \
				  1 = 1 \
				  AND DATE(Order_DateTime) BETWEEN STR_TO_DATE('%s', '%%d/%%m/%%Y') AND STR_TO_DATE('%s', '%%d/%%m/%%Y')  \
				  ORDER BY Order_Time DESC;",pReq->sDateFrom,pReq->sDateTo);
***/
	sprintf(sSelectQry,"SELECT   CONCAT(ORDER_NUMBER,',', SEM_SMST_SECURITY_ID,',', BUY_SELL,',', ORDER_TYPE,',', EXCH_ORDER_NUMBER,',', TRADE_NUMBER,',', PRODUCT,',', QUANTITY,',', PRICE,',', TRADE_VALUE,',', ORDER_DATE_TIME,',', EXCH,',', SEGMENT,',', CLIENT_ID,',', JDATE,',', PLACEDBY,',', STRATEGY_ID,',', SYMBOL,',', LEGVALUE,',', IFNULL(PAN_NO, 'NA'),',', IFNULL(PARTICIPANT_TYPE, 'B'),',', IFNULL(MKT_PROTECT_FLG, 'N'),',', IFNULL(MKT_PROTECT_VAL, 1),',', IFNULL(SETTLOR, 'NA'),',', IFNULL(GTC_FLG, 'N'),',', IFNULL(ENCASH_FLG, 'N'),',', MKT_TYPE ,',', ALGO_ORDER_NUM,',',ALGO_ID) AS StringTrade FROM   (SELECT     `A`.`EQ_CLIENT_ID` AS `CLIENT_ID`,       @rn:=@rn + 1 AS r,       `A`.`EQ_SCRIP_CODE` AS `SEM_SMST_SECURITY_ID`,       DATE_FORMAT(`A`.`EQ_TRD_TRADE_TIME`, \'%%d-%%m-%%Y %%T\') AS `ORDER_DATE_TIME`,       `A`.`EQ_ORDER_NO` AS `ORDER_NUMBER`,       `A`.`EQ_EXCH_ORDER_NO` AS `EXCH_ORDER_NUMBER`,       `A`.`EQ_TRD_EXCH_TRADE_NO` AS `TRADE_NUMBER`,       `A`.`EQ_EXCH_ID` AS `EXCH`,       (CASE `A`.`EQ_BUY_SELL_IND`         WHEN 'B' THEN 'Buy'         WHEN 'S' THEN 'Sell'       END) AS `BUY_SELL`,       'E' AS `SEGMENT`,       (CASE `A`.`EQ_ORDER_TYPE`         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS `ORDER_TYPE`,       `A`.`EQ_SYMBOL` AS `SYMBOL`,       (CASE `A`.`EQ_PRODUCT_ID`         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'H' THEN 'NORMAL'         WHEN 'F' THEN 'MTF'         ELSE `A`.`EQ_PRODUCT_ID`       END) AS `PRODUCT`,       `A`.`EQ_LAST_TRADE_QTY` AS `QUANTITY`,       IFNULL(`A`.`EQ_TRD_TRADE_PRICE`, 0) AS `PRICE`,       ROUND((`A`.`EQ_TRD_TRADE_PRICE` * `A`.`EQ_LAST_TRADE_QTY`), 4) AS `TRADE_VALUE`,       `A`.`EQ_SCRIP_CODE` AS `SECURITY_ID`,       `A`.`EQ_PRODUCT_ID` AS `TRD_PRODUCT`,       JULIDATE(`A`.`EQ_INTERNAL_ENTRY_DATE`) AS `JDATE`,       `A`.`EQ_ENTITY_ID` AS `PLACEDBY`, (CASE `A`.`EQ_STRATEGY_ID` WHEN '101' THEN 'INTRADAY_SQR_OFF' WHEN '102' THEN 'CO_SQ_OFF' WHEN '103' THEN 'BO_SQ_OFF' WHEN '104' THEN 'OFF_ORD_PUMP' WHEN '105' THEN 'SIP_ORD_PUMP' WHEN '106' THEN 'MTM_SQR_OFF' WHEN '107' THEN 'CKT_SQR_OFF' ELSE 'NA' END) AS `STRATEGY_ID`,`A`.`EQ_LEG_NO` AS `LEGVALUE`,       `A`.`EQ_PAN_NO` AS `PAN_NO`,       `A`.`EQ_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,       `A`.`EQ_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,       `A`.`EQ_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,       `A`.`EQ_SETTLOR` AS `SETTLOR`,       `A`.`EQ_GTC_FLG` AS `GTC_FLG`,       `A`.`EQ_ENCASH_FLG` AS `ENCASH_FLG`,       `A`.`EQ_MKT_TYPE` AS `MKT_TYPE`,       `A`.EQ_ALGO_ORDER_NO AS ALGO_ORDER_NUM, `A`.`EQ_ALGO_ID` AS ALGO_ID  FROM     `EQ_ORDERS_ARCHIVE` `A`   CROSS JOIN (SELECT @rn:=0) r   WHERE DATE(`A`.EQ_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y') AND STR_TO_DATE(\'%s\', '%%d/%%m/%%Y')       AND     ((`A`.`EQ_MSG_CODE` = '2222')       AND (`A`.`EQ_TRD_STATUS` = 'C')) UNION ALL SELECT     `B`.`DRV_CLIENT_ID` AS `CLIENT_ID`,       @rn:=@rn + 1 AS r,       `B`.`DRV_SCRIP_CODE` AS `SEM_SMST_SECURITY_ID`,       DATE_FORMAT(`B`.`DRV_TRD_TRADE_TIME`, \'%%d-%%m-%%Y %%T\') AS `ORDER_DATE_TIME`,       `B`.`DRV_ORDER_NO` AS `ORDER_NUMBER`,       `B`.`DRV_EXCH_ORDER_NO` AS `EXCH_ORDER_NUMBER`,       `B`.`DRV_TRD_EXCH_TRADE_NO` AS `TRADE_NUMBER`,       `B`.`DRV_EXCH_ID` AS `EXCH`,       (CASE `B`.`DRV_BUY_SELL_IND`         WHEN 'B' THEN 'BUY'         WHEN 'S' THEN 'SELL'       END) AS `BUY/SELL`,       `B`.`DRV_SEGMENT` AS `SEGMENT`,       (CASE `B`.`DRV_ORDER_TYPE`         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS `ORDER_TYPE`,       `B`.`DRV_SYMBOL` AS `SYMBOL`,       (CASE `B`.`DRV_PRODUCT_ID`         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'H' THEN 'NORMAL'         WHEN 'F' THEN 'MTF'         ELSE `B`.`DRV_PRODUCT_ID`       END) AS `PRODUCT`,       `B`.`DRV_TRD_TRADE_QTY` AS `QTY`,       IFNULL(`B`.`DRV_TRD_TRADE_PRICE`, 0) AS `PRICE`,       (CASE         WHEN (`B`.`DRV_SEGMENT` = 'C') THEN ROUND(((`B`.`DRV_TRD_TRADE_PRICE` * `B`.`DRV_TRD_TRADE_QTY`) * 1000), 4)         ELSE ROUND((`B`.`DRV_TRD_TRADE_PRICE` * `B`.`DRV_TRD_TRADE_QTY`), 2)       END) AS `TRADE_VALUE`,       `B`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,       `B`.`DRV_PRODUCT_ID` AS `TRD_PRODUCT`,       JULIDATE(`B`.`DRV_INTERNAL_ENTRY_DATE`) AS `JDATE`,       `B`.`DRV_ENTITY_ID` AS `PLACEDBY`, (CASE `B`.`DRV_STRATEGY_ID` WHEN '101' THEN 'INTRADAY_SQR_OFF' WHEN '102' THEN 'CO_SQ_OFF' WHEN '103' THEN 'BO_SQ_OFF' WHEN '104' THEN 'OFF_ORD_PUMP' WHEN '105' THEN 'SIP_ORD_PUMP' WHEN '106' THEN 'MTM_SQR_OFF' ELSE 'NA' END) AS `STRATEGY_ID`,       `B`.`DRV_LEG_NO` AS `LEGVALUE`,       `B`.`DRV_PAN_NO` AS `PAN_NO`,       `B`.`DRV_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,       `B`.`DRV_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,       `B`.`DRV_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,       `B`.`DRV_SETTLOR` AS `SETTLOR`,       `B`.`DRV_GTC_FLG` AS `GTC_FLG`,       `B`.`DRV_ENCASH_FLG` AS `ENCASH_FLGi`,       `B`.`DRV_MKT_TYPE` AS `MKT_TYPE`,       `B`.DRV_OMS_ALGO_ORD_NO AS ALGO_ORDER_NUM,`B`.`DRV_ALGO_ID` AS ALGO_ID FROM     `DRV_ORDERS_ARCHIVE` `B`   CROSS JOIN (SELECT @rn:=0) r   WHERE DATE(`B`.DRV_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\') AND STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\')       AND     ((`B`.`DRV_MSG_CODE` = '2222')       AND (`B`.`DRV_TRD_STATUS` = 'C')       AND (`B`.`DRV_CF_FLAG` <> - 1)) UNION ALL SELECT     `C`.`COMM_CLIENT_ID` AS `CLIENT_ID`,       @rn:=@rn + 1 AS r,       `C`.`COMM_SCRIP_CODE` AS `SEM_SMST_SECURITY_ID`,       DATE_FORMAT(`C`.`COMM_TRD_TRADE_TIME`, \'%%d-%%m-%%Y %%T\') AS `ORDER_DATE_TIME`,       `C`.`COMM_ORDER_NO` AS `ORDER_NUMBER`,       `C`.`COMM_EXCH_ORDER_NO` AS `EXCH_ORDER_NUMBER`,       `C`.`COMM_TRD_EXCH_TRADE_NO` AS `TRADE_NUMBER`,       `C`.`COMM_EXCH_ID` AS `EXCH`,       (CASE `C`.`COMM_BUY_SELL_IND`         WHEN 'B' THEN 'BUY'         WHEN 'S' THEN 'SELL'       END) AS `BUY/SELL`,       'M' AS `SEGMENT`,       (CASE `C`.`COMM_ORDER_TYPE`         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS `ORDER_TYPE`,       `C`.`COMM_SYMBOL` AS `SYMBOL`,       (CASE `C`.`COMM_PRODUCT_ID`         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'H' THEN 'NORMAL'         WHEN 'F' THEN 'MTF'         ELSE `C`.`COMM_PRODUCT_ID`       END) AS `PRODUCT`,       `C`.`COMM_TRD_TRADE_QTY` AS `QTY`,       IFNULL(`C`.`COMM_TRD_TRADE_PRICE`, 0) AS `PRICE`,       ROUND(((`C`.`COMM_TRD_TRADE_PRICE` * `C`.`COMM_TRD_TRADE_QTY`) * `C`.`COMM_MULTIPLIER`), 2) AS `TRADE_VALUE`,       `C`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,       `C`.`COMM_PRODUCT_ID` AS `TRD_PRODUCT`,       JULIDATE(`C`.`COMM_INTERNAL_ENTRY_DATE`) AS `JDATE`,       `C`.`COMM_ENTITY_ID` AS `PLACEDBY`,   (CASE `C`.`COMM_STRATEGY_ID` WHEN '101' THEN 'INTRADAY_SQR_OFF' WHEN '102' THEN 'CO_SQ_OFF' WHEN '103' THEN 'BO_SQ_OFF' WHEN '104' THEN 'OFF_ORD_PUMP' WHEN '105' THEN 'SIP_ORD_PUMP' WHEN '106' THEN 'MTM_SQR_OFF' ELSE 'NA' END) AS `STRATEGY_ID`,       `C`.`COMM_LEG_NO` AS `LEGVALUE`,       `C`.`COMM_PAN_NO` AS `PAN_NO`,       `C`.`COMM_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,       `C`.`COM_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,       `C`.`COMM_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,       `C`.`COMM_SETTLOR` AS `SETTLOR`,       `C`.`COMM_GTC_FLG` AS `GTC_FLG`,       `C`.`COMM_ENCASH_FLG` AS `ENCASH_FLG`,       `C`.`COMM_MKT_TYPE` AS `MKT_TYPE`,       `C`.COMM_OMS_ALGO_ORDER_NO AS ALGO_ORDER_NUM,`C`.`COMM_ALGO_ID` AS ALGO_ID   FROM     `COMM_ORDERS_ARCHIVE` `C`   CROSS JOIN (SELECT @rn:=0) r   WHERE DATE(`C`.COMM_INTERNAL_ENTRY_DATE) BETWEEN STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\') AND STR_TO_DATE(\'%s\', \'%%d/%%m/%%Y\')       AND     ((`C`.`COMM_MSG_CODE` = '2222')       AND (`C`.`COMM_TRD_STATUS` = 'C')       AND (`C`.`COMM_CF_FLAG` <> -1))) tradebook WHERE   1 = 1 ORDER BY ORDER_DATE_TIME DESC; ",pReq->sDateFrom,pReq->sDateTo,pReq->sDateFrom,pReq->sDateTo,pReq->sDateFrom,pReq->sDateTo);
	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBQury, sSelectQry) != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("Error While Fetching the client details.");
		return FALSE;
	}


	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
/**
	fprintf(fpFile ,"TRADE_NUMBER, SYMBOL, USER_ID, CLIENT_ID, BUY_SELL, PRODUCT, TRADE_QUANTITY, TRADE_PRICE, SOURCE, \
			DB_SORUCE, ORDER_NUMBER, TRADE_VALUE, ORDER_DATETIME, PLACEDBY, \
			EXCH_ID, SEGMENT, ORDER_TYPE, SCRIP_CO, CTCLID, ORDER_TIME, ID \n");
***/
	fprintf(fpFile ,"ORDER_NUMBER,SEM_SMST_SECURITY_ID,BUY_SELL,ORDER_TYPE,EXCH_ORDER_NUMBER,TRADE_NUMBER,PRODUCT,QUANTITY,PRICE,TRADE_VALUE,ORDER_DATE_TIME,EXCH,SEGMENT,CLIENT_ID,JDATE,PLACEDBY,STRATEGY_ID, SYMBOL,LEGVALUE,PAN_NO,PARTICIPANT_TYPE,MKT_PROTECT_FLG,MKT_PROTECT_VAL,SETTLOR,GTC_FLG,ENCASH_FLG,MKT_TYPE,ALGO_ORDER_NUM,ALGO_ID\n");
	fclose(fpFile);
	Res = mysql_store_result(DBQury);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		fpFile = fopen(sFileName1,"a");
		//	fprintf(fpFile ,"TRADE_NUMBER, SYMBOL, USER_ID, CLIENT_ID, BUY_SELL, PRODUCT, TRADE_QUANTITY, TRADE_PRICE, SOURCE, \
		DB_SORUCE, ORDER_NUMBER, TRADE_VALUE, ORDER_DATETIME, PLACEDBY, \
			EXCH_ID, SEGMENT, ORDER_TYPE, SCRIP_CO, CTCLID, ORDER_TIME, ID \n");

		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				//	logDebug2("Row :%s:",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
		fclose(fpFile);
	}
	fConvToPwdPrtect(sFileName,sFileName1);


	logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
	pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
	pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
	pResp.IntRespHeader.iErrorId = 0;
	pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES; 
	pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
	pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
	sprintf(pResp.sFilename,"%s%s.rrs",TRADE_REPORT_FILE_NM,sSeq);
	logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
	logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
	logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
	logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
	logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
	logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
	logDebug2("pResp.sFilename = %s", pResp.sFilename);

	iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
		return FALSE;
	}




	logTimestamp("Exit : CreateTradeReport ");
}



BOOL CreateClientLimitFile (CHAR *RcvMsg)
{
	logTimestamp("Entry : CreateClientLimitFile");
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR		 sSeq[30];
	memset (sSeq,'\0',30);
	CHAR    sFileName [FILE_NAME_LEN];
	memset (sFileName,'\0',FILE_NAME_LEN);
	CHAR    sFileName1 [FILE_NAME_LEN];
	memset (sFileName1,'\0',FILE_NAME_LEN);
	CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
	LONG32 iRow;
	FILE *fpFile;
	//	struct INT_COMMON_REQUEST_HDR *pReqHdr;
	struct INT_CREATE_FILE_RES	pResp;	

	struct INT_CREATE_FILE_REQ *pReq;
	pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
	//	sprintf(pReq->sDateFrom,"01/09/2018");
	//	sprintf(pReq->sDateTo,"01/11/2018");
	logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
	logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
	logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
	logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
	logDebug2("pReq->IntReqHeader.iUserId = :%llu:",pReq->IntReqHeader.iUserId);
	logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
	logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);


	/*	pReqHdr=(struct INT_COMMON_REQUEST_HDR *)RcvMsg ;
		logDebug2("pReqHdr->iSeqNo = :%d:",pReqHdr->iSeqNo);
		logDebug2("pReqHdr->iMsgLength = :%d:",pReqHdr->iMsgLength);
		logDebug2("pReqHdr->iMsgCode = :%d:",pReqHdr->iMsgCode);
		logDebug2("pReqHdr->sExcgId = :%s:",pReqHdr->sExcgId);
		logDebug2("pReqHdr->iUserId = :%d:",pReqHdr->iUserId);
		logDebug2("pReqHdr->cSource = :%c:",pReqHdr->cSource);
		logDebug2("pReqHdr->cSegment = :%c:",pReqHdr->cSegment);

	 */
	if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("error in select Time.");
		return FALSE;
	}

	Res = mysql_store_result(DBQury);
	while((Row = mysql_fetch_row(Res)))
	{	
		logDebug2("Row[0] = :%s:",Row[0]);

		//	sprintf(sSeq,"%s",Row[0]);
		strncpy(sSeq,Row[0],strlen(Row[0]));
		logDebug2("Time is : %s", sSeq);
	}

	mysql_free_result(Res);
	sprintf(sFileName,"%s/%s%s",sRRPath,CLIENT_LIMIT_FILE_NM,sSeq);
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
	logDebug2("sFileName1 = %s", sFileName1);
	logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);
	sprintf(sSelectQry,"SELECT concat(IFNULL(LIMIT_SOD, 0),  ' , ', IFNULL(ADHOC_LIMIT, 0),  ' , ',   IFNULL(RECEIVABLES, 0), ' , ', \
		IFNULL(BANK_HOLDING, 0),  ' , ', IFNULL(COLLATERALS, 0), ' , ',   IFNULL(REALISED_PROFITS, 0),   ' , ', \
			IFNULL(AMOUNT_UTILIZED, 0),  ' , ', IFNULL(COLLATERALS + SUM_OF_ALL, 0),  ' , ',  IFNULL(COLLATERALS + AVAILABLE_BALANCE, 0) , \
			' , ',  IFNULL(CLEAR_BALANCE, 0),    ' , ',   IFNULL(LIMIT_TYPE, 0),  ' , ',  IFNULL(CLIENT_ID, 0), ' , ',  IFNULL(REQUEST_PAYOUT_AMOUNT, 0),  ' , ', \
			IFNULL(SEGMENT, 0), ' , ', IFNULL(CF_OPT_SELL_PREMIUM, 0), ' , ',   IFNULL(CF_OPT_SELL_PREMIUM_COMM, 0),  ' , ', IFNULL(CLIENT_NAME, 0),\
			' , ',   IFNULL(GROSS_HOLDING_VAL, 0)) FROM    (SELECT  X.limit_sod AS LIMIT_SOD,   X.adhoc_limit AS ADHOC_LIMIT,   \
			(X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) AS RECEIVABLES,  X.bank_holding AS BANK_HOLDING,  CASE RCSL.COLLATERAL_FLAG \
			WHEN 'Y' THEN ROUND(IFNULL(SUM((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * \ 
						((100 - IFNULL(HM.HM_HAIRCUT_PERC, 0)) / 100)), 0), 2)   ELSE 0    END AS COLLATERALS,   (X.realised_profits + X.realised_profits_Comm) \
			AS REALISED_PROFITS,  (X.Amount_Utilized + X.Amount_Utilized_Comm) AS AMOUNT_UTILIZED,  ROUND((X.limit_sod + X.adhoc_limit + \
					X.bank_holding + X.realised_profits + X.realised_profits_Comm + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM + \ 
					X.receivables - X.Request_Payout_Amount), 2) AS SUM_OF_ALL,  ROUND(((X.limit_sod + X.adhoc_limit + X.bank_holding + \ 
							X.realised_profits + X.realised_profits_Comm + X.receivables + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM) - \ 
						(X.Amount_Utilized + X.Amount_Utilized_Comm)) - X.Request_Payout_Amount, 2) AS AVAILABLE_BALANCE,  X.CLEAR_BALANCE AS CLEAR_BALANCE, \
			X.limit_type AS LIMIT_TYPE,  X.CLIENT_ID AS CLIENT_ID,   X.Request_Payout_Amount AS Request_Payout_Amount,  X.SEGMENT AS SEGMENT, \
			X.CF_OPT_SELL_PREMIUM AS CF_OPT_SELL_PREMIUM,  X.CF_OPT_SELL_PREMIUM_COMM AS CF_OPT_SELL_PREMIUM_COMM,  E.ENTITY_NAME AS CLIENT_NAME, \
			(CASE X.SEGMENT   WHEN 'E' THEN ROUND(IFNULL(SUM((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * IFNULL(LWA.L1_LTP, 0)), 0), 2) \
			 ELSE 0 END) AS GROSS_HOLDING_VAL  FROM  (SELECT  'CAPITAL' AS `limit_type`, ROUND(IFNULL(`R`.`C_CASH_BALANCE`, 0), 2) AS `limit_sod`, \
				 ROUND(IFNULL(`R`.`C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,   ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,\
				 ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM_COMM`, 0), 2) AS `CF_OPT_SELL_PREMIUM_COMM`,  ROUND(IFNULL(`R`.`NC_NSE_RECEIVABLES`, 0) + \
					 IFNULL(`R`.`NC_BSE_RECEIVABLES`, 0), 2) AS `receivables`,  ROUND(IFNULL(`R`.`C_BANK_HOLD`, 0), 2) AS `bank_holding`, \
				 ROUND(IFNULL(`R`.`NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,  ROUND(IFNULL(`R`.`NC_REALISED_PROFIT_COMM`, 0), 2) \
				 AS `realised_profits_Comm`,  ROUND((IFNULL(`R`.`TOTAL_CASH_UTILIZED`, 0) + IFNULL(`R`.`TOTAL_NON_CASH_UTILIZED`, 0)), 2) AS \
				 `Amount_Utilized`,  ROUND(IFNULL(`R`.`TOTAL_CASH_UTILIZED_COMM`, 0), 2) AS `Amount_Utilized_Comm`,  `R`.`CLIENT_ID` AS `CLIENT_ID`,\
				 `R`.`EXCH_ID` AS `EXCH_ID`, `R`.`SEGMENT` AS `segment`,  ROUND(`R`.`WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,  ROUND(`R`.`REQUEST_PAYOUT_AMOUNT`, 2) \
				 AS `Request_Payout_Amount`  FROM  `RMS_FUND_LIMIT` `R`  UNION ALL SELECT  'COMMODITY' AS `limit_type`,  ROUND(IFNULL(`R`.`RMLC_C_CASH_BALANCE`, 0), 2) \
				 AS `limit_sod`,  ROUND(IFNULL(`R`.`RMLC_C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`, ROUND(IFNULL(`R`.`RMLC_CF_OPT_SELL_PREMIUM`, 0), 2) AS \
				 `CF_OPT_SELL_PREMIUM`,  0 AS `CF_OPT_SELL_PREMIUM_COMM`, 0 AS `receivables`, ROUND(IFNULL(`R`.`RMLC_C_BANK_HOLD`, 0), 2) AS `bank_holding`,\
				 ROUND(IFNULL(`R`.`RMLC_NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,  0 AS `realised_profits_Comm`,  ROUND(IFNULL(`R`.`RMLC_TOTAL_CASH_UTILIZED`, 0) \
					 , 2) AS `Amount_Utilized`,   0 AS `Amount_Utilized_Comm`,  `R`.`RMLC_CLIENT_ID` AS `CLIENT_ID`,  `R`.`RMLC_EXCHANGE` AS `EXCH_ID`,  \
				 `R`.`RMLC_SEGMENT` AS `SEGMENT`,  ROUND(`R`.`RMLC_WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`, ROUND(`R`.`RMLC_REQUEST_PAYOUT_AMOUNT`, 2) AS `REQUEST_PAYOUT_AMOUNT` \
				 FROM `RMS_FUND_LIMIT_COM` `R`     ) X   LEFT JOIN `ENTITY_MASTER` `E` ON ((`E`.`ENTITY_CODE` = `X`.`CLIENT_ID`))  LEFT JOIN `RMS_RISK_PROFILE_MAST` `D` \
			 ON ((`E`.`ENTITY_RISK_PROFILE` = `D`.`RPM_CODE`))     LEFT JOIN RMS_CLIENT_SECURITY_LIMIT RCSL ON ((RCSL.CLIENT_ID = X.CLIENT_ID \
						 AND RCSL.SECURITY_SOURCE_TYPE IN ('HLD' , 'T1', 'MRG')))     LEFT JOIN EQ_L1_WATCH LWA ON (CASE   \
					 WHEN RCSL.EXCH_ID = 'ALL' THEN RCSL.NSE_SCRIP_CODE    WHEN RCSL.EXCH_ID = 'NSE' THEN RCSL.NSE_SCRIP_CODE    ELSE RCSL.BSE_SCRIP_CODE \
					 END = LWA.L1_SCRIP_CODE)     LEFT JOIN HAIRCUT_MASTER HM ON (RCSL.ISIN_CODE = HM.HM_ISIN)   GROUP BY X.SEGMENT,X.CLIENT_ID) AS XX WHERE     1 = 1;");

	printf("sSelectQry = %s\n",sSelectQry);
	logDebug2("Going for Query");
	if (mysql_query(DBQury, sSelectQry) != SUCCESS)
	{
		sql_Error(DBQury);
		logSqlFatal("Error While Fetching the client details.");
		return FALSE;
	}


	logDebug2("After Query");
	fpFile = fopen(sFileName1,"wr");
	fprintf(fpFile ,"LIMIT_SOD,  ADHOC_LIMIT,  RECEIVABLES,  BANK_HOLDING,  COLLATERALS,  REALISED_PROFITS,  AMOUNT_UTILIZED, \
			SUM_OF_ALL, AVAILABLE_BALANCE, CLEAR_BALANCE,  LIMIT_TYPE, CLIENT_ID, REQUEST_PAYOUT_AMOUNT, SEGMENT, \
			CF_OPT_SELL_PREMIUM, CF_OPT_SELL_PREMIUM_COMM, CLIENT_NAME, GROSS_HOLDING_VAL \n");
	fclose(fpFile);
	Res = mysql_store_result(DBQury);
	iRow = mysql_num_rows(Res);
	if(iRow == 0)
	{

		mysql_free_result(Res);
		logDebug2("Zero rows selected");
	}
	else
	{
		logDebug2("Rows Selected %d",iRow);
		fpFile = fopen(sFileName1,"a");
		//	fprintf(fpFile ,"TRADE_NUMBER, SYMBOL, USER_ID, CLIENT_ID, BUY_SELL, PRODUCT, TRADE_QUANTITY, TRADE_PRICE, SOURCE, \
		DB_SORUCE, ORDER_NUMBER, TRADE_VALUE, ORDER_DATETIME, PLACEDBY, \
			EXCH_ID, SEGMENT, ORDER_TYPE, SCRIP_CO, CTCLID, ORDER_TIME, ID \n");

		if (fpFile == NULL)
		{
			logFatal("Not able to Open File in append mode");
			exit(0);
		}
		else
		{
			while((Row = mysql_fetch_row(Res)))
			{
				//	logDebug2("Row :%s:",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);

			}
		}
		mysql_free_result(Res);
		fprintf(fpFile,"*");
		fclose(fpFile);
	}
	fConvToPwdPrtect(sFileName,sFileName1);


	logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
	pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
	pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
	pResp.IntRespHeader.iErrorId = 0;
	pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES; 
	pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
	pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
	sprintf(pResp.sFilename,"%s%s.rrs",CLIENT_LIMIT_FILE_NM,sSeq);
	logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
	logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
	logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
	logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
	logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
	logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
	logDebug2("pResp.sFilename = %s", pResp.sFilename);

	iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
		return FALSE;
	}




	logTimestamp("Exit : CreateClientLimitFile ");
}

BOOL    fCliWiseContrationRpt(CHAR *RcvMsg)
{
        logTimestamp("Entry : fCliWiseContrationRpt");

        struct  VIEW_CLI_CONCENTR_RPT_REQ	*pViewCliContrReq;
        struct  VIEW_COMMON_HDR_RESP            pHdrResp;
        struct  VIEW_CLI_CONCTR_RPT_RESP	pViewCliContrResp;

        pViewCliContrReq = (struct VIEW_CLI_CONCENTR_RPT_REQ *)RcvMsg;

        CHAR    sViewProfileQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sProdClause[QUERY_SIZE];
        CHAR    sSrcClause[QUERY_SIZE];
        memset(sProdClause,'\0',QUERY_SIZE);
        memset(sSrcClause,'\0',QUERY_SIZE);
        memset(sViewProfileQry,'\0',DOUBLE_MAX_QUERY_SIZE);
        memset(sWhere_Clause,'\0',QUERY_SIZE);

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

        logDebug2("pViewCliContrReq->sClientId = %s",pViewCliContrReq->sClientId);
        logDebug2("pViewCliContrReq->sEntityId= %s",pViewCliContrReq->sEntityId);
        logDebug2("pViewCliContrReq->cProductId	= %c",pViewCliContrReq->cProductId);

	if(pViewCliContrReq->cProductId == ALL)
        {
                sprintf(sProdClause, " ('M','F','H') ");
                sprintf(sSrcClause," ('MRG','MTF')");
        }
        else if(pViewCliContrReq->cProductId == PROD_MARGIN)
        {
                sprintf(sProdClause, " ('M') ");
                sprintf(sSrcClause," ('MRG')");
        }
        else if(pViewCliContrReq->cProductId == PROD_MTF)
        {
                sprintf(sProdClause, " ('F') ");
                sprintf(sSrcClause," ('MTF')");
        }
        else if(pViewCliContrReq->cProductId == PROD_NORMAL)
        {
                sprintf(sProdClause, " ('H') ");
                sprintf(sSrcClause," ('NRM')");
        }
        else
        {
                sprintf(sProdClause, " ('M','F','H') ");
                sprintf(sSrcClause," ('MRG','MTF')");
        }

        logDebug2("sProdClause :%s:",sProdClause);
        logDebug2("sSrcClause   :%s:",sSrcClause);

        sprintf(sViewProfileQry,"select SYMBOL,QTY,LTP,cast(VALUATION as decimal(17,2)),cast((VALUATION * 100)/@rn as decimal(15,2)) AS CONCENTRATION from (SELECT @rn:=a.VALUATION + @rn AS VAL, a.* from( SELECT  X.CLIENT_ID AS CLIENT_ID, X.SECURITY_ID AS SECURITY_ID, sum(X.QTY) AS QTY, X.SYMBOL AS SYMBOL, IFNULL(L.L1_LTP,0) AS LTP, IFNULL(L.L1_LTP,0) * sum(X.QTY) AS VALUATION FROM (SELECT  R.CLIENT_ID AS CLIENT_ID, (CASE R.EXCH_ID WHEN 'BSE' THEN R.BSE_SCRIP_CODE ELSE R.NSE_SCRIP_CODE END) AS SECURITY_ID, sum(R.QTY - R.QTY_UTILIZED) as QTY,  (CASE R.EXCH_ID WHEN 'BSE' THEN R.BSE_SYMBOL ELSE R.NSE_SYMBOL END) AS SYMBOL FROM RMS_CLIENT_SECURITY_LIMIT R WHERE R.SECURITY_SOURCE_TYPE IN %s AND R.CLIENT_ID = \'%s\' GROUP BY SECURITY_ID UNION ALL SELECT CLIENT_ID, SECURITY_ID, NET_QTY, EXCH_SYMB FROM (SELECT     MBNP.`CLIENT_ID` AS `CLIENT_ID`,     MBNP.`SECURITY_ID` AS `SECURITY_ID`,     (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)) AS `NET_QTY`,     SUBSTRING_INDEX(`SM`.`SM_SYMBOL`, '-', 1) AS `EXCH_SYMB` FROM 			(SELECT 			T.EQ_CLIENT_ID AS CLIENT_ID, 			T.EQ_SCRIP_CODE AS SECURITY_ID, 			T.EQ_EXCH_ID AS EXCH_ID, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'B') THEN T.EQ_LAST_TRADE_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'B') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'S') THEN T.EQ_LAST_TRADE_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'S') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY) 				ELSE 0 			END)) AS SELL_VAL, 			'E' AS EXCH_SEGMENT, 			T.EQ_PRODUCT_ID AS PRODUCT, 			0 AS INT_REF_ID 		FROM 			EQ_ORDERS T 		WHERE 			(T.EQ_TRD_STATUS = 'C') 				AND (T.EQ_MSG_CODE = 2222) 				AND (T.EQ_CLIENT_ID = \'%s\')         AND (T.EQ_SEGMENT='E')         AND T.EQ_PRODUCT_ID IN %s 		GROUP BY T.EQ_CLIENT_ID , T.EQ_SCRIP_CODE , T.EQ_EXCH_ID , T.EQ_PRODUCT_ID 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS BUY_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS BUY_VAL, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS SELL_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL CD 		WHERE CD.RCCD_CLIENT_ID = \'%s\'     AND CD.RCCD_SEGMENT='E'     AND CD.RCCD_PRODUCT_SOURCE IN %s 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL CD 		WHERE CD.RCCD_CLIENT_ID = \'%s\'     AND CD.RCCD_SEGMENT='E'     AND CD.RCCD_PRODUCT_DESTINATION IN %s 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT ) MBNP 			JOIN SEM_ACTIVE SM 		WHERE 			((MBNP.SECURITY_ID = SM.SM_SCRIP_CODE) 				AND (MBNP.EXCH_ID = SM.SM_EXCHANGE) 				AND (MBNP.EXCH_SEGMENT = SM.SM_SEGMENT)) 		GROUP BY MBNP.CLIENT_ID , MBNP.SECURITY_ID , SM.SM_INSTRUMENT_NAME , SM.SM_SYMBOL , SM.SM_UNDERLAYING_SCRIP_CODE , MBNP.EXCH_ID , SM.SM_EXPIRY_DATE , SM.SM_STRIKE_PRICE , SM.SM_OPTION_TYPE , SM.SM_SEGMENT , MBNP.PRODUCT , SM.SM_LOT_SIZE)Z     WHERE Z.NET_QTY>0) AS X LEFT JOIN EQ_L1_WATCH L ON (L.L1_SCRIP_CODE = X.SECURITY_ID AND L1_SEGMENT='E') group by X.SECURITY_ID)a CROSS JOIN (SELECT @rn:=0)R)d cross join    (select @rn)b;    ",sSrcClause,pViewCliContrReq->sClientId,pViewCliContrReq->sClientId,sProdClause,pViewCliContrReq->sClientId,sProdClause,pViewCliContrReq->sClientId,sProdClause);

	logDebug2("sViewProfileQry = %s",sViewProfileQry);

        if(mysql_query(DBQury,sViewProfileQry) != SUCCESS)
        {
                logSqlFatal("Error in sViewProfileQry.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);
        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

        pHdrResp.IntRespHeader.iSeqNo = 0;
        pHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pHdrResp.IntRespHeader.iErrorId = 0;
        pHdrResp.IntRespHeader.iMsgCode = TC_ADMIN_CLI_CONTRN_RPT_HDR_RSP;
        pHdrResp.IntRespHeader.iUserId = pViewCliContrReq->ReqHeader.iUserId;
        pHdrResp.IntRespHeader.cSource = pViewCliContrReq->ReqHeader.cSource;
        pHdrResp.cMsgType = 'H';
        pHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pHdrResp.IntRespHeader.iMsgLength = %d",pHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pHdrResp.IntRespHeader.iMsgCode = %d",pHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pHdrResp.IntRespHeader.iUserId = %llu",pHdrResp.IntRespHeader.iUserId);
        logDebug2("pHdrResp.IntRespHeader.cSource = %c",pHdrResp.IntRespHeader.cSource);
        logDebug2("pHdrResp.iNoofRec = %d",pHdrResp.iNoofRec);

        logDebug2("pViewCliContrReq->ReqHeader.iUserId = %llu",pViewCliContrReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewCliContrReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                memset(&pViewCliContrResp,'\0',sizeof(struct VIEW_CLI_CONCTR_RPT_RESP));
                pViewCliContrResp.IntRespHeader.iSeqNo = 0;
                pViewCliContrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLI_CONCTR_RPT_RESP);
                pViewCliContrResp.IntRespHeader.iErrorId = 0;
                pViewCliContrResp.IntRespHeader.iMsgCode = TC_ADMIN_CLI_CONTRN_RPT_RSP;
                pViewCliContrResp.IntRespHeader.iUserId = pViewCliContrReq->ReqHeader.iUserId;
                pViewCliContrResp.IntRespHeader.cSource = pViewCliContrReq->ReqHeader.cSource;

                logDebug2("pViewCliContrResp.IntRespHeader.iMsgCode = %d",pViewCliContrResp.IntRespHeader.iMsgCode);

                if(iTempNoOfRec <= 1)
                {
                        pViewCliContrResp.cMsgType = 'T';
                }
                else
                {
                        pViewCliContrResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        if(Row = mysql_fetch_row(Res))
                        {

                                strncpy(pViewCliContrResp.subRpt[j].sSYMBOL,Row[0] ,DB_SYMBOL_LEN);
				pViewCliContrResp.subRpt[j].iQty= atoi(Row[1]);
				pViewCliContrResp.subRpt[j].fLtp= atof(Row[2]);
				pViewCliContrResp.subRpt[j].fValuation= atof(Row[3]);
				pViewCliContrResp.subRpt[j].fConcentrn= atof(Row[4]);

				logDebug2("pViewCliContrResp.subRpt[%d].sSYMBOL :%s:",j,pViewCliContrResp.subRpt[j].sSYMBOL);
				logDebug2("pViewCliContrResp.subRpt[%d].iQty:%d:",j,pViewCliContrResp.subRpt[j].iQty);
				logDebug2("pViewCliContrResp.subRpt[%d].fLtp:%lf:",j,pViewCliContrResp.subRpt[j].fLtp);
				logDebug2("pViewCliContrResp.subRpt[%d].fValuation:%lf:",j,pViewCliContrResp.subRpt[j].fValuation);
				logDebug2("pViewCliContrResp.subRpt[%d].fConcentrn:%lf:",j,pViewCliContrResp.subRpt[j].fConcentrn);

			}
                }

                if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewCliContrResp,sizeof(struct VIEW_CLI_CONCTR_RPT_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }

                iTempNoOfRec--;
	}
	
        logTimestamp("Exit : fCliWiseContrationRpt");
        return TRUE;
}

BOOL    fBrokWiseContrationRpt(CHAR *RcvMsg)
{
        logTimestamp("Entry : fBrokWiseContrationRpt");

        struct  VIEW_BROK_CONCENTR_RPT_REQ	*pViewCliContrReq;
        struct  VIEW_COMMON_HDR_RESP            pHdrResp;
        struct  VIEW_BROKER_CONCTR_RPT_RESP	pViewCliContrResp;

        pViewCliContrReq = (struct VIEW_CLI_CONCENTR_RPT_REQ *)RcvMsg;

        CHAR    sViewProfileQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sProdClause[QUERY_SIZE];
        CHAR    sSrcClause[QUERY_SIZE];
        memset(sViewProfileQry,'\0',DOUBLE_MAX_QUERY_SIZE);
        memset(sWhere_Clause,'\0',QUERY_SIZE);
        memset(sProdClause,'\0',QUERY_SIZE);
        memset(sSrcClause,'\0',QUERY_SIZE);

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

	
        logDebug2("pViewCliContrReq->sClientId = %s",pViewCliContrReq->sClientId);
        logDebug2("pViewCliContrReq->sEntityId= %s",pViewCliContrReq->sEntityId);
        logDebug2("pViewCliContrReq->sSYMBOL= %s",pViewCliContrReq->sSYMBOL);
        logDebug2("pViewCliContrReq->cProductId	= %c",pViewCliContrReq->cProductId);

	if(pViewCliContrReq->cProductId == ALL)
	{
		sprintf(sProdClause, " ('M','F','H') ");		
		sprintf(sSrcClause," ('MRG','MTF')");
	}
	else if(pViewCliContrReq->cProductId == PROD_MARGIN)
        {
                sprintf(sProdClause, " ('M') ");
		sprintf(sSrcClause," ('MRG')");
        }
	else if(pViewCliContrReq->cProductId == PROD_MTF)
        {
                sprintf(sProdClause, " ('F') ");
		sprintf(sSrcClause," ('MTF')");
        }
	else if(pViewCliContrReq->cProductId == PROD_NORMAL)
        {
                sprintf(sProdClause, " ('H') ");
		sprintf(sSrcClause," ('NRM')");
        }
	else
	{
		sprintf(sProdClause, " ('M','F','H') ");
		sprintf(sSrcClause," ('MRG','MTF')");
	}
	
	logDebug2("sProdClause :%s:",sProdClause);
	logDebug2("sSrcClause	:%s:",sSrcClause);


/**
	sprintf(sViewProfileQry,"select CLIENT_ID,QTY,cast(VALUATION as decimal(20,2)) VALUATION,cast((VALUATION * 100)/@rn as decimal(15,2)) AS CONCENTRATION from (SELECT @rn:=a.VALUATION + @rn AS VAL, a.* from (SELECT CLIENT_ID, SUM(Y.QTY) AS QTY, SUM(Y.VALUATION) AS VALUATION FROM (SELECT  X.CLIENT_ID AS CLIENT_ID, X.SECURITY_ID AS SECURITY_ID, sum(X.QTY) AS QTY, X.SYMBOL AS SYMBOL, IFNULL(L.L1_LTP,0) AS LTP, IFNULL(L.L1_LTP,0) * sum(X.QTY) AS VALUATION FROM (SELECT  R.CLIENT_ID AS CLIENT_ID, (CASE R.EXCH_ID WHEN 'BSE' THEN R.BSE_SCRIP_CODE ELSE R.NSE_SCRIP_CODE END) AS SECURITY_ID, sum(R.QTY - R.QTY_UTILIZED) as QTY,  (CASE R.EXCH_ID WHEN 'BSE' THEN R.BSE_SYMBOL ELSE R.NSE_SYMBOL END) AS SYMBOL FROM RMS_CLIENT_SECURITY_LIMIT R WHERE R.SECURITY_SOURCE_TYPE = 'MRG' GROUP BY SECURITY_ID,CLIENT_ID UNION ALL SELECT CLIENT_ID, SECURITY_ID, NET_QTY, EXCH_SYMB FROM (SELECT     MBNP.`CLIENT_ID` AS `CLIENT_ID`,     MBNP.`SECURITY_ID` AS `SECURITY_ID`,     (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)) AS `NET_QTY`,     SUBSTRING_INDEX(`SM`.`SM_SYMBOL`, '-', 1) AS `EXCH_SYMB`      FROM       (SELECT       T.EQ_CLIENT_ID AS CLIENT_ID,       T.EQ_SCRIP_CODE AS SECURITY_ID,       T.EQ_EXCH_ID AS EXCH_ID,       SUM((CASE         WHEN (T.EQ_BUY_SELL_IND = 'B') THEN T.EQ_LAST_TRADE_QTY         ELSE 0       END)) AS BUY_QTY,       SUM((CASE         WHEN (T.EQ_BUY_SELL_IND = 'B') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY)         ELSE 0       END)) AS BUY_VAL,       SUM((CASE         WHEN (T.EQ_BUY_SELL_IND = 'S') THEN T.EQ_LAST_TRADE_QTY         ELSE 0       END)) AS SELL_QTY,       SUM((CASE         WHEN (T.EQ_BUY_SELL_IND = 'S') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY)         ELSE 0       END)) AS SELL_VAL,       'E' AS EXCH_SEGMENT,       T.EQ_PRODUCT_ID AS PRODUCT,       0 AS INT_REF_ID     FROM       EQ_ORDERS T     WHERE       (T.EQ_TRD_STATUS = 'C')         AND (T.EQ_MSG_CODE = 2222)         AND (T.EQ_SEGMENT='E')         AND T.EQ_PRODUCT_ID IN('M','F')     GROUP BY T.EQ_CLIENT_ID , T.EQ_SCRIP_CODE , T.EQ_EXCH_ID , T.EQ_PRODUCT_ID     UNION ALL SELECT       CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,       CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,       CD.RCCD_EXCHANGE AS RCCD_EXCHANGE,       (-(1) * SUM((CASE         WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY         ELSE 0       END))) AS BUY_QTY,       (-(1) * SUM((CASE         WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)         ELSE 0       END))) AS BUY_VAL,       (-(1) * SUM((CASE         WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY         ELSE 0       END))) AS SELL_QTY,       (-(1) * SUM((CASE         WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)         ELSE 0       END))) AS SELL_VAL,       CD.RCCD_SEGMENT AS RCCD_SEGMENT,       CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE,       0 AS '0'     FROM       RMS_CLIENT_CONVT_TO_DEL CD     WHERE CD.RCCD_SEGMENT='E'     AND CD.RCCD_PRODUCT_SOURCE IN('M','F')     GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT     UNION ALL SELECT       CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,       CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,       CD.RCCD_EXCHANGE AS RCCD_EXCHANGE,       SUM((CASE         WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY         ELSE 0       END)) AS BUY_QTY,       SUM((CASE         WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)         ELSE 0       END)) AS BUY_VAL,       SUM((CASE         WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY         ELSE 0       END)) AS SELL_QTY,       SUM((CASE         WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)         ELSE 0       END)) AS SELL_VAL,       CD.RCCD_SEGMENT AS RCCD_SEGMENT,       CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION,       0 AS '0'     FROM       RMS_CLIENT_CONVT_TO_DEL CD     WHERE CD.RCCD_SEGMENT='E'     AND CD.RCCD_PRODUCT_DESTINATION IN('M','F')     GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT     ) MBNP       JOIN SEM_ACTIVE SM     WHERE       ((MBNP.SECURITY_ID = SM.SM_SCRIP_CODE)         AND (MBNP.EXCH_ID = SM.SM_EXCHANGE)         AND (MBNP.EXCH_SEGMENT = SM.SM_SEGMENT))     GROUP BY MBNP.CLIENT_ID , MBNP.SECURITY_ID , SM.SM_INSTRUMENT_NAME , SM.SM_SYMBOL , SM.SM_UNDERLAYING_SCRIP_CODE , MBNP.EXCH_ID , SM.SM_EXPIRY_DATE , SM.SM_STRIKE_PRICE , SM.SM_OPTION_TYPE , SM.SM_SEGMENT , MBNP.PRODUCT , SM.SM_LOT_SIZE)Z     WHERE Z.NET_QTY>0     ) AS X LEFT JOIN EQ_L1_WATCH L ON (L.L1_SCRIP_CODE = X.SECURITY_ID AND L1_SEGMENT='E') group by X.SECURITY_ID,X.CLIENT_ID)Y GROUP BY Y.CLIENT_ID)a CROSS JOIN (SELECT @rn:=0)R)d cross join    (select @rn)b;");
****/
	sprintf(sViewProfileQry,"select CLIENT_ID,QTY,cast(VALUATION as decimal(20,2)) VALUATION,cast((VALUATION * 100)/@rn as decimal(15,2)) AS CONCENTRATION from (SELECT  @rn:=a.VALUATION + @rn AS VAL,  a.* from (SELECT CLIENT_ID, SUM(Y.QTY) AS QTY, SUM(Y.VALUATION) AS VALUATION FROM (SELECT   X.CLIENT_ID AS CLIENT_ID, X.SECURITY_ID AS SECURITY_ID,  sum(X.QTY) AS QTY,  X.SYMBOL AS SYMBOL,  IFNULL(L.L1_LTP,0) AS LTP,  IFNULL(L.L1_LTP,0) * sum(X.QTY) AS VALUATION FROM (SELECT   R.CLIENT_ID AS CLIENT_ID,  (CASE R.EXCH_ID WHEN 'BSE' THEN R.BSE_SCRIP_CODE ELSE R.NSE_SCRIP_CODE END) AS SECURITY_ID,  sum(R.QTY - R.QTY_UTILIZED) as QTY,   (CASE R.EXCH_ID WHEN 'BSE' THEN R.BSE_SYMBOL ELSE R.NSE_SYMBOL END) AS SYMBOL FROM RMS_CLIENT_SECURITY_LIMIT R WHERE R.SECURITY_SOURCE_TYPE IN %s and (R.NSE_SYMBOL = \'%s\' or R.BSE_SYMBOL = \'%s\') GROUP BY SECURITY_ID,CLIENT_ID UNION ALL SELECT CLIENT_ID, SECURITY_ID, NET_QTY, EXCH_SYMB FROM  (SELECT          MBNP.`CLIENT_ID` AS `CLIENT_ID`,         MBNP.`SECURITY_ID` AS `SECURITY_ID`,         (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)) AS `NET_QTY`,         SUBSTRING_INDEX(`SM`.`SM_SYMBOL`, '-', 1) AS `EXCH_SYMB`           FROM             (SELECT              T.EQ_CLIENT_ID AS CLIENT_ID,             T.EQ_SCRIP_CODE AS SECURITY_ID,             T.EQ_EXCH_ID AS EXCH_ID,             SUM((CASE                 WHEN (T.EQ_BUY_SELL_IND = 'B') THEN T.EQ_LAST_TRADE_QTY                 ELSE 0             END)) AS BUY_QTY,             SUM((CASE                 WHEN (T.EQ_BUY_SELL_IND = 'B') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY)                 ELSE 0             END)) AS BUY_VAL,             SUM((CASE                 WHEN (T.EQ_BUY_SELL_IND = 'S') THEN T.EQ_LAST_TRADE_QTY                 ELSE 0             END)) AS SELL_QTY,             SUM((CASE                 WHEN (T.EQ_BUY_SELL_IND = 'S') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY)                 ELSE 0             END)) AS SELL_VAL,             'E' AS EXCH_SEGMENT,             T.EQ_PRODUCT_ID AS PRODUCT,             0 AS INT_REF_ID         FROM             EQ_ORDERS T         WHERE             (T.EQ_TRD_STATUS = 'C')                 AND (T.EQ_MSG_CODE = 2222)                 AND (T.EQ_SEGMENT='E')                 AND T.EQ_PRODUCT_ID IN %s                 AND T.EQ_SYMBOL = \'%s\'         GROUP BY T.EQ_CLIENT_ID , T.EQ_SCRIP_CODE , T.EQ_EXCH_ID , T.EQ_PRODUCT_ID          UNION ALL SELECT              CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,             CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,             CD.RCCD_EXCHANGE AS RCCD_EXCHANGE,             (-(1) * SUM((CASE                 WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY                 ELSE 0             END))) AS BUY_QTY,             (-(1) * SUM((CASE                 WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)                 ELSE 0             END))) AS BUY_VAL,             (-(1) * SUM((CASE                 WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY                 ELSE 0             END))) AS SELL_QTY,             (-(1) * SUM((CASE                 WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)                 ELSE 0             END))) AS SELL_VAL,             CD.RCCD_SEGMENT AS RCCD_SEGMENT,             CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE,             0 AS '0'         FROM             RMS_CLIENT_CONVT_TO_DEL CD         WHERE CD.RCCD_SEGMENT='E'         AND CD.RCCD_PRODUCT_SOURCE IN %s         AND RCCD_SYMBOL = \'%s\'         GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT          UNION ALL SELECT              CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,             CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,             CD.RCCD_EXCHANGE AS RCCD_EXCHANGE,             SUM((CASE                 WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY                 ELSE 0             END)) AS BUY_QTY,             SUM((CASE                 WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)                 ELSE 0             END)) AS BUY_VAL,             SUM((CASE                 WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY                 ELSE 0             END)) AS SELL_QTY,             SUM((CASE                 WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE)                 ELSE 0             END)) AS SELL_VAL,             CD.RCCD_SEGMENT AS RCCD_SEGMENT,             CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION,             0 AS '0'         FROM             RMS_CLIENT_CONVT_TO_DEL CD         WHERE  CD.RCCD_SEGMENT='E'         AND CD.RCCD_PRODUCT_DESTINATION IN %s         AND RCCD_SYMBOL = \'%s\'         GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT          ) MBNP             JOIN SEM_ACTIVE SM         WHERE             ((MBNP.SECURITY_ID = SM.SM_SCRIP_CODE)                 AND (MBNP.EXCH_ID = SM.SM_EXCHANGE)                 AND (MBNP.EXCH_SEGMENT = SM.SM_SEGMENT))         GROUP BY MBNP.CLIENT_ID , MBNP.SECURITY_ID , SM.SM_INSTRUMENT_NAME , SM.SM_SYMBOL , SM.SM_UNDERLAYING_SCRIP_CODE , MBNP.EXCH_ID , SM.SM_EXPIRY_DATE , SM.SM_STRIKE_PRICE , SM.SM_OPTION_TYPE , SM.SM_SEGMENT , MBNP.PRODUCT , SM.SM_LOT_SIZE)Z         WHERE Z.NET_QTY>0         ) AS X LEFT JOIN EQ_L1_WATCH L ON (L.L1_SCRIP_CODE = X.SECURITY_ID AND L1_SEGMENT='E') group by X.SECURITY_ID,X.CLIENT_ID)Y GROUP BY Y.CLIENT_ID)a CROSS JOIN (SELECT @rn:=0)R)d cross join       (select @rn)b;",sSrcClause,pViewCliContrReq->sSYMBOL,pViewCliContrReq->sSYMBOL,sProdClause,pViewCliContrReq->sSYMBOL,sProdClause,pViewCliContrReq->sSYMBOL,sProdClause,pViewCliContrReq->sSYMBOL);

	printf("sViewProfileQry = %s\n",sViewProfileQry);

        if(mysql_query(DBQury,sViewProfileQry) != SUCCESS)
        {
                logSqlFatal("Error in sViewProfileQry.");
        }
        Res = mysql_store_result(DBQury);
        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

        pHdrResp.IntRespHeader.iSeqNo = 0;
        pHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pHdrResp.IntRespHeader.iErrorId = 0;
        pHdrResp.IntRespHeader.iMsgCode = TC_ADMIN_BROK_CONTRN_RPT_HDR_RSP;
        pHdrResp.IntRespHeader.iUserId = pViewCliContrReq->ReqHeader.iUserId;
        pHdrResp.IntRespHeader.cSource = pViewCliContrReq->ReqHeader.cSource;
        pHdrResp.cMsgType = 'H';
        pHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pHdrResp.IntRespHeader.iMsgLength = %d",pHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pHdrResp.IntRespHeader.iMsgCode = %d",pHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pHdrResp.IntRespHeader.iUserId = %llu",pHdrResp.IntRespHeader.iUserId);
        logDebug2("pHdrResp.IntRespHeader.cSource = %c",pHdrResp.IntRespHeader.cSource);
        logDebug2("pHdrResp.iNoofRec = %d",pHdrResp.iNoofRec);

        logDebug2("pViewCliContrReq->ReqHeader.iUserId = %llu",pViewCliContrReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewCliContrReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                memset(&pViewCliContrResp,'\0',sizeof(struct VIEW_BROKER_CONCTR_RPT_RESP));
                pViewCliContrResp.IntRespHeader.iSeqNo = 0;
                pViewCliContrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BROKER_CONCTR_RPT_RESP);
                pViewCliContrResp.IntRespHeader.iErrorId = 0;
                pViewCliContrResp.IntRespHeader.iMsgCode = TC_ADMIN_BROK_CONTRN_RPT_RSP;
                pViewCliContrResp.IntRespHeader.iUserId = pViewCliContrReq->ReqHeader.iUserId;
                pViewCliContrResp.IntRespHeader.cSource = pViewCliContrReq->ReqHeader.cSource;

                logDebug2("pViewCliContrResp.IntRespHeader.iMsgCode = %d",pViewCliContrResp.IntRespHeader.iMsgCode);

                if(iTempNoOfRec <= 1)
                {
                        pViewCliContrResp.cMsgType = 'T';
                }
                else
                {
                        pViewCliContrResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        if(Row = mysql_fetch_row(Res))
                        {

                                strncpy(pViewCliContrResp.subRpt[j].sClientId,Row[0] ,CLIENT_ID_LEN);
                                pViewCliContrResp.subRpt[j].iQty= atoi(Row[1]);
                                pViewCliContrResp.subRpt[j].fValuation= atof(Row[2]);
                                pViewCliContrResp.subRpt[j].fConcentrn= atof(Row[3]);
			}
                }

                if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewCliContrResp,sizeof(struct VIEW_BROKER_CONCTR_RPT_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }
                iTempNoOfRec--;
        }

        logTimestamp("Exit : fBrokWiseContrationRpt");
        return TRUE;
}	

BOOL    fDebitCliHolding(CHAR *RcvMsg)
{
        logTimestamp("Entry : fDebitCliHolding");

        struct  VIEW_ADMIN_DEBIT_CLI_HOLDING_REQ	*pDebitHldReq;
        struct  VIEW_COMMON_HDR_RESP            pHdrResp;
        struct  VIEW_ADMIN_DEBIT_CLI_HOLDING_RESP	pViewDbtHldResp;

        pDebitHldReq= (struct VIEW_ADMIN_DEBIT_CLI_HOLDING_REQ *)RcvMsg;

        CHAR    sViewProfileQry[MAX_QUERY_SIZE];
        CHAR    sCallProc[QUERY_SIZE];
        memset(sViewProfileQry,'\0',MAX_QUERY_SIZE);
        memset(sCallProc,'\0',QUERY_SIZE);

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

        logDebug2("pDebitHldReq->sClientId = %s",pDebitHldReq->sClientId);
        logDebug2("pDebitHldReq->sEntityId= %s",pDebitHldReq->sEntityId);
        logDebug2("pDebitHldReq->fDebitAmt= %lf",pDebitHldReq->fDebitAmt);
        logDebug2("pDebitHldReq->ReqHeader.cSegment= %c",pDebitHldReq->ReqHeader.cSegment);
	sprintf(sCallProc,"CALL PR_DEBIT_CLIENT_HOLDING(\"%s\",\'%c\',@FILLER_1,@FILLER_2,@FILLER_3,@FILLER_4);",pDebitHldReq->sClientId,pDebitHldReq->ReqHeader.cSegment);

        logDebug2("sCallProc = %s",sCallProc);

        if(mysql_query(DBQury,sCallProc) != SUCCESS)
        {
                logSqlFatal("Error in sViewProfileQry.");
                sql_Error(DBQury);
                return FALSE;
        }

        sprintf(sViewProfileQry,"select s.DCH_CLIENT_ID,s.DCH_EXCH_ID,IFNULL(s.DCH_NSE_SYMBOL,\'NA\'),s.DCH_HLD_AMT,s.DCH_SQ_QTY,s.DCH_ISIN_CODE,IFNULL(s.DCH_NSE_SCRIP_CODE,\'NA\'),IFNULL(s.DCH_BSE_SCRIP_CODE,\'NA\'),IFNULL(s.DCH_BSE_SYMBOL,\'NA\'),IFNULL(s.DCH_NSE_SERIES,\'NA\'),IFNULL(s.DCH_BSE_SERIES,\'NA\'),IFNULL(s.DCH_HLD_TYPE,\'NA\'),IFNULL(s.DCH_REM_QTY,0) from DEBIT_CLIENT_HOLDING s where DCH_CLIENT_ID=\"%s\" ORDER BY s.DCH_NSE_SYMBOL;",pDebitHldReq->sClientId);
	
	logDebug2("sViewProfileQry = %s",sViewProfileQry);

        if(mysql_query(DBQury,sViewProfileQry) != SUCCESS)
        {
                logSqlFatal("Error in sViewProfileQry.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);
        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

        pHdrResp.IntRespHeader.iSeqNo = 0;
        pHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pHdrResp.IntRespHeader.iErrorId = 0;
        pHdrResp.IntRespHeader.iMsgCode = TC_ADMIN_DEBIT_CLI_HOLDING_HDR_RSP;
        pHdrResp.IntRespHeader.iUserId = pDebitHldReq->ReqHeader.iUserId;
        pHdrResp.IntRespHeader.cSource = pDebitHldReq->ReqHeader.cSource;
        pHdrResp.cMsgType = 'H';
        pHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pHdrResp.IntRespHeader.iMsgLength = %d",pHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pHdrResp.IntRespHeader.iMsgCode = %d",pHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pHdrResp.IntRespHeader.iUserId = %llu",pHdrResp.IntRespHeader.iUserId);
        logDebug2("pHdrResp.IntRespHeader.cSource = %c",pHdrResp.IntRespHeader.cSource);
        logDebug2("pHdrResp.iNoofRec = %d",pHdrResp.iNoofRec);

        logDebug2("pDebitHldReq->ReqHeader.iUserId = %llu",pDebitHldReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pDebitHldReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

	if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                memset(&pViewDbtHldResp,'\0',sizeof(struct VIEW_ADMIN_DEBIT_CLI_HOLDING_RESP));
                pViewDbtHldResp.IntRespHeader.iSeqNo = 0;
                pViewDbtHldResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_DEBIT_CLI_HOLDING_RESP);
                pViewDbtHldResp.IntRespHeader.iErrorId = 0;
	        pViewDbtHldResp.IntRespHeader.iMsgCode = TC_ADMIN_DEBIT_CLI_HOLDING_RSP;
                pViewDbtHldResp.IntRespHeader.iUserId = pDebitHldReq->ReqHeader.iUserId;
                pViewDbtHldResp.IntRespHeader.cSource = pDebitHldReq->ReqHeader.cSource;

                logDebug2("pViewDbtHldResp.IntRespHeader.iMsgCode = %d",pViewDbtHldResp.IntRespHeader.iMsgCode);

                if(iTempNoOfRec <= 1)
                {
                        pViewDbtHldResp.cMsgType = 'T';
                }
                else
                {
                        pViewDbtHldResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        if(Row = mysql_fetch_row(Res))
                        {
                                strncpy(pViewDbtHldResp.subRpt[j].sClientId,Row[0] ,CLIENT_ID_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sExchangeID,Row[1] ,EXCHANGE_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sNseSymbol,Row[2] ,DB_SYMBOL_LEN);
                                pViewDbtHldResp.subRpt[j].fAmount= atof(Row[3]);
                                pViewDbtHldResp.subRpt[j].iQty= atoi(Row[4]);
                                strncpy(pViewDbtHldResp.subRpt[j].sISINCode,Row[5] ,ISINCODE_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sNseSecurityID,Row[6] ,SECURITY_ID_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sBseSecurityID,Row[7] ,SECURITY_ID_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sBseSymbol,Row[8] ,DB_SYMBOL_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sNSEseries,Row[9] ,HLD_SERIES_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sBSEseries,Row[10] ,HLD_SERIES_LEN);
                                strncpy(pViewDbtHldResp.subRpt[j].sSrcType,Row[11] ,SEC_SOURCE_LEN);
                                pViewDbtHldResp.subRpt[j].iRemQty= atoi(Row[12]);

                        }
                }	

		if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pViewDbtHldResp,sizeof(struct VIEW_ADMIN_DEBIT_CLI_HOLDING_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }

                iTempNoOfRec--;
        }

        logTimestamp("Exit : fDebitCliHolding");
        return TRUE;
}

BOOL    fShortMtmOptPr(CHAR *RcvMsg)
{
        logTimestamp("Entry :fShortMtmOptPr");

        struct  VIEW_SHORT_OPT_MTM_REQ	*pReq;

        logDebug2("sQry 1= ");
        MYSQL_RES    *Res;
        MYSQL_ROW     Row;
	
	pReq = (struct VIEW_SHORT_OPT_MTM_REQ *)RcvMsg;	
        logDebug2("sQry 2= ");
        logDebug2("pReq->iMtmPercent= %d",pReq->iMtmPercent);
	
        logDebug2("sQry 3= ");
        CHAR    *sQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

        sprintf(sQry,"CALL PR_SHORT_OPT_MTM(%d,\'%c\')",pReq->iMtmPercent,pReq->ReqHeader.cSegment);

        logDebug2("sQry = %s",sQry);

        if(mysql_query(DBQury,sQry) != SUCCESS)
        {
                logSqlFatal("ERROR IN CALL PR_SHORT_OPT_MTM sQry.");
                sql_Error(DBQury);
                return  FALSE;
        }

        return TRUE;
        logTimestamp("Exit : fShortMtmOptPr");
}

BOOL    fShortOptMtm(CHAR *RcvMsg)
{
        logTimestamp("Entry : fShortOptMtm");

        struct  VIEW_SHORT_OPT_MTM_REQ	*pViewShrtMtmReq;
        struct  VIEW_ADMIN_SHORT_OPT_MTM_RESP	pShrtMtmResp;
        struct  VIEW_COMMON_HDR_RESP                    pShrtMtmHdrResp;

        pViewShrtMtmReq= (struct VIEW_SHORT_OPT_MTM_REQ *)RcvMsg;

        CHAR    sMarginQry[DOUBLE_MAX_QUERY_SIZE];
        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sMarg_Qry[QUERY_SIZE];

        LONG32          i=0,j=0;
        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec = 0.00 ;
        LONG32          iNoOfPkt = 0;
        LONG32          iTempNoOfRec = 0;

        BOOL ChkFlag = FALSE;

        memset(sWhere_Clause,'\0',QUERY_SIZE);
        memset(sMarginQry,'\0',DOUBLE_MAX_QUERY_SIZE);

        logDebug2("pViewShrtMtmReq->sClientId = %s",pViewShrtMtmReq->sClientId);

        logDebug2("pViewShrtMtmReq->ReqHeader.cSegment :%c:",pViewShrtMtmReq->ReqHeader.cSegment);

        ChkFlag = fShortMtmOptPr(RcvMsg);

	if(ChkFlag == FALSE)
        {
                logDebug3(" Error in fShortMtmOptPr");
                return  FALSE;
        }


        logDebug2("final sWhere_Clause = %s",sWhere_Clause);

/**
        if(pViewShrtMtmReq->cUserType == SUPER_ADMIN)
        {
                logDebug2("call fShortOptMtm for SUPER_ADMIN ");	

	}
        else if(pViewShrtMtmReq->cUserType == ADMIN_TYPE)
        {
                logDebug2("call fMarginSrtFall for ADMIN_TYPE ");

	}
***/
	sprintf(sMarginQry,"SELECT OSM_CLIENT_ID, OSM_LIMIT_SOD, OSM_BANK_HOLD, OSM_ADHOC, OSM_RECEIVABLES, OSM_OPT_SELL_PREMIUM, OSM_COLLATERALS, OSM_TOT_LIMIT, OSM_MTM, OSM_MTM_PER, OSM_REALISED_PROFIT, OSM_TREALISEDMTM, OSM_SEGMENT FROM OPT_SELL_MTM WHERE OSM_SEGMENT=\'%c\';",pViewShrtMtmReq->ReqHeader.cSegment);
	
	logDebug2("sMarginQry = %s",sMarginQry);

        if(mysql_query(DBQury,sMarginQry ) != SUCCESS)
        {
                logSqlFatal("ERROR in sMarginQry.");
                sql_Error(DBQury);
                return FALSE;
        }

        Res = mysql_store_result(DBQury);

        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);

	iTempNoOfRec = iNoOfPkt;

        pShrtMtmHdrResp.IntRespHeader.iSeqNo = 0;
        pShrtMtmHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pShrtMtmHdrResp.IntRespHeader.iErrorId = 0;
        pShrtMtmHdrResp.IntRespHeader.iMsgCode = TC_ADMIN_SHORT_OPT_MTM_HDR_RESP;
        pShrtMtmHdrResp.IntRespHeader.iUserId = pViewShrtMtmReq->ReqHeader.iUserId;
        pShrtMtmHdrResp.IntRespHeader.cSource = pViewShrtMtmReq->ReqHeader.cSource ;
        pShrtMtmHdrResp.IntRespHeader.cSegment = pViewShrtMtmReq->ReqHeader.cSegment ;
        pShrtMtmHdrResp.cMsgType = 'H';
        pShrtMtmHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pShrtMtmHdrResp.IntRespHeader.iMsgLength = %d",pShrtMtmHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pShrtMtmHdrResp.IntRespHeader.iMsgCode = %d",pShrtMtmHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pShrtMtmHdrResp.IntRespHeader.iUserId = %llu",pShrtMtmHdrResp.IntRespHeader.iUserId);
        logDebug2("pShrtMtmHdrResp.IntRespHeader.cSource = %c",pShrtMtmHdrResp.IntRespHeader.cSource);
        logDebug2("pShrtMtmHdrResp.iNoofRec = %d",pShrtMtmHdrResp.iNoofRec);

        logDebug2("pViewShrtMtmReq->ReqHeader.iUserId = %llu",pViewShrtMtmReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewShrtMtmReq->ReqHeader.iUserId);

	if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pShrtMtmHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                memset(&pShrtMtmResp,'\0',sizeof(struct VIEW_ADMIN_SHORT_OPT_MTM_RESP));
                pShrtMtmResp.IntRespHeader.iSeqNo = 0;
                pShrtMtmResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADMIN_SHORT_OPT_MTM_RESP);
                pShrtMtmResp.IntRespHeader.iErrorId = 0;
                pShrtMtmResp.IntRespHeader.iMsgCode = TC_ADMIN_SHORT_OPT_MTM_RESP;
                pShrtMtmResp.IntRespHeader.iUserId = pViewShrtMtmReq->ReqHeader.iUserId;
                pShrtMtmResp.IntRespHeader.cSource = pViewShrtMtmReq->ReqHeader.cSource;

                logDebug2("pShrtMtmResp.IntRespHeader.iMsgCode = %d",pShrtMtmResp.IntRespHeader.iMsgCode);

                if(iTempNoOfRec <= 1)
                {
                        pShrtMtmResp.cMsgType = 'T';
                }
                else
                {
                        pShrtMtmResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        if(Row = mysql_fetch_row(Res))
                        {

				strncpy(pShrtMtmResp.subRpt[j].sClientId,Row[0],CLIENT_ID_LEN);
				pShrtMtmResp.subRpt[j].fLimitSOD = atof(Row[1]);
				pShrtMtmResp.subRpt[j].fBankHold= atof(Row[2]);
				pShrtMtmResp.subRpt[j].fAdhocLimit= atof(Row[3]);
				pShrtMtmResp.subRpt[j].fReceivable= atof(Row[4]);
				pShrtMtmResp.subRpt[j].fOptSellPremium= atof(Row[5]);
				pShrtMtmResp.subRpt[j].fColletral= atof(Row[6]);
				pShrtMtmResp.subRpt[j].fTotLimit= atof(Row[7]);
				pShrtMtmResp.subRpt[j].fMtm= atof(Row[8]);
				pShrtMtmResp.subRpt[j].fMtmPercent= atof(Row[9]);
				pShrtMtmResp.subRpt[j].fRealisProfit= atof(Row[10]);
				pShrtMtmResp.subRpt[j].fTotRealzMtm= atof(Row[11]);
				pShrtMtmResp.subRpt[j].cSegment = Row[12][0];
		
				logDebug2("pShrtMtmResp.subRpt[%d].sClientId :%s:",j,pShrtMtmResp.subRpt[j].sClientId);
				logDebug2("pShrtMtmResp.subRpt[%d].fLimitSOD	:%lf:",j,pShrtMtmResp.subRpt[j].fLimitSOD);
				logDebug2("pShrtMtmResp.subRpt[%d].fBankHold	:%lf:",j,pShrtMtmResp.subRpt[j].fBankHold);
				logDebug2("pShrtMtmResp.subRpt[%d].fAdhocLimit	:%lf:",j,pShrtMtmResp.subRpt[j].fAdhocLimit);
				logDebug2("pShrtMtmResp.subRpt[%d].fReceivable	:%lf:",j,pShrtMtmResp.subRpt[j].fReceivable);
				logDebug2("pShrtMtmResp.subRpt[%d].fOptSellPremium	:%lf:",j,pShrtMtmResp.subRpt[j].fOptSellPremium);
				logDebug2("pShrtMtmResp.subRpt[%d].fColletral:%lf:",j,pShrtMtmResp.subRpt[j].fColletral);
				logDebug2("pShrtMtmResp.subRpt[%d].fTotLimit:%lf:",j,pShrtMtmResp.subRpt[j].fTotLimit);
				logDebug2("pShrtMtmResp.subRpt[%d].fMtm	:%lf:",j,pShrtMtmResp.subRpt[j].fMtm);
				logDebug2("pShrtMtmResp.subRpt[%d].fMtmPercent:%lf:",j,pShrtMtmResp.subRpt[j].fMtmPercent);
				logDebug2("pShrtMtmResp.subRpt[%d].fRealisProfit	:%lf:",j,pShrtMtmResp.subRpt[j].fRealisProfit);
				logDebug2("pShrtMtmResp.subRpt[%d].fTotRealzMtm	:%lf:",j,pShrtMtmResp.subRpt[j].fTotRealzMtm);
				logDebug2("pShrtMtmResp.subRpt[%d].cSegment	:%c:",j,pShrtMtmResp.subRpt[j].cSegment);
					
	
			}
                }

                if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pShrtMtmResp,sizeof(struct VIEW_ADMIN_SHORT_OPT_MTM_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }

                iTempNoOfRec--;
        }

        logTimestamp("Exit : fDebitCliHolding");
        return TRUE;
}	
BOOL    fViewBranchMaster(CHAR  *RcvMsg)
{
        logTimestamp("Entry : fViewBranchMaster");
        struct        VIEW_BR_MASTER_ADMIN_REQ        *pViewBrMasReq;
        struct        VIEW_COMMON_HDR_RESP            pBrMasHdrResp;
        struct        VIEW_BR_MASTER_ADMIN_RESP       pBrMasResp;

        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR  sBrMasSelQry[QUERY_SIZE];
	
	pViewBrMasReq= (struct VIEW_BR_MASTER_ADMIN_REQ *)RcvMsg;	
        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

        logDebug2("pViewClMasReq->ReqHeader.iUserId = :%llu:",pViewBrMasReq->ReqHeader.iUserId);
        logDebug2("pViewClMasReq->sEntityId = :%s:",pViewBrMasReq->sEntityId);
        logDebug2("pViewClMasReq->sEntityName = :%s:",pViewBrMasReq->sEntityName);
        logDebug2("pViewClMasReq->cStatus = :%c:",pViewBrMasReq->cStatus);
        logDebug2("pViewClMasReq->cLoginStatus = :%c:",pViewBrMasReq->cLoginStatus);
        logDebug2("pViewClMasReq->sFromDate = :%s:",pViewBrMasReq->sFromDate);
        logDebug2("pViewClMasReq->sToDate = :%s:",pViewBrMasReq->sToDate);
        logDebug2("pViewClMasReq->cEntityType = :%c:",pViewBrMasReq->cEntityType);
        logDebug2("pViewClMasReq->sController = :%s:",pViewBrMasReq->sController);
        logDebug2("pViewClMasReq->sBranchType = :%s:",pViewBrMasReq->sBranchType);

	memset(&sWhere_Clause,'\0',QUERY_SIZE);
        memset(&sBrMasSelQry,'\0',QUERY_SIZE);
	if(strcmp(pViewBrMasReq->sEntityId,SELECT_ALL))
        {
                sprintf(sWhere_Clause,"AND ENTITY_CODE = '%s'",pViewBrMasReq->sEntityId);
        }
        if (strcmp(pViewBrMasReq->sEntityName,SELECT_ALL))
        {
                sprintf(sWhere_Clause,"AND ENTITY_NAME = '%s'",pViewBrMasReq->sEntityName);
        }


        sprintf(sBrMasSelQry,"select IFNULL(NULLIF(ENTITY_CODE,''),'NA'), IFNULL(NULLIF(ENTITY_NAME,''),'NA'), IFNULL(NULLIF(ENTITY_TYPE,''),'NA'),\
		 IFNULL(ENTITY_DOB,'NA'), IFNULL(NULLIF(ENTITY_ADD_1,''),'NA'), IFNULL(NULLIF(ENTITY_ADD_2,''),'NA'),\
		 IFNULL(NULLIF(ENTITY_ADD_3,''),'NA'), IFNULL(NULLIF(ENTITY_PINCODE,''),'NA'), IFNULL(nullif(ENTITY_EMAIL,''),'NA'),\
		 IFNULL(NULLIF(ENTITY_PHONE,''),'NA'), IFNULL(NULLIF(ENTITY_MOBILE,''),'NA'), IFNULL(NULLIF(ENTITY_CREATED_BY,''),'NA'),\
		 IFNULL(ENTITY_CREATED_DATE,'NA'), IFNULL(NULLIF(RR.RPD_PROFILE_NAME,''), 'NA')\
		 from ENTITY_MASTER EM LEFT JOIN RMS_RISK_PROFILE_DET RR ON (RR.RPD_PROFILE_CODE = EM.ENTITY_QL_PROFILE) where ENTITY_TYPE = 'BR' %s \
		 GROUP BY EM.ENTITY_CODE;",sWhere_Clause );

        logDebug2("SELECT QUERY = %s",sBrMasSelQry);

        if(mysql_query(DBQury,sBrMasSelQry) != SUCCESS)
        {
                logSqlFatal("Error in sBrMasSelQry.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);
        iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

        pBrMasHdrResp.IntRespHeader.iSeqNo = 0;
        pBrMasHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pBrMasHdrResp.IntRespHeader.iErrorId = 0;
        pBrMasHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_BR_MASTER_HED_RESP;
        pBrMasHdrResp.IntRespHeader.iUserId = pViewBrMasReq->ReqHeader.iUserId;
        pBrMasHdrResp.IntRespHeader.cSource = pViewBrMasReq->ReqHeader.cSource;
        pBrMasHdrResp.cMsgType = 'H';
        pBrMasHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pBrMasHdrResp.IntRespHeader.iMsgLength = %d",pBrMasHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pBrMasHdrResp.IntRespHeader.iMsgCode = %d",pBrMasHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pBrMasHdrResp.IntRespHeader.iUserId = %llu",pBrMasHdrResp.IntRespHeader.iUserId);
        logDebug2("pBrMasHdrResp.IntRespHeader.cSource = %c",pBrMasHdrResp.IntRespHeader.cSource);
        logDebug2("pBrMasHdrResp.iNoofRec = %d",pBrMasHdrResp.iNoofRec);

        logDebug2("pViewCirLmtReq->ReqHeader.iUserId = %llu",pViewBrMasReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewBrMasReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }
        if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pBrMasHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                logDebug2("No 0f Pkt..(i) = %d",i);
                memset(&pBrMasResp,'\0',sizeof(struct VIEW_BR_MASTER_ADMIN_RESP));
                pBrMasResp.IntRespHeader.iSeqNo = 0;
		pBrMasResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BR_MASTER_ADMIN_RESP);
                pBrMasResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_BR_MASTER_RESP;
                pBrMasResp.IntRespHeader.iErrorId = 0;
                pBrMasResp.IntRespHeader.iUserId = pViewBrMasReq->ReqHeader.iUserId;
                pBrMasResp.IntRespHeader.cSource = pViewBrMasReq->ReqHeader.cSource;

                if(iTempNoOfRec <= 1)
                {
                        pBrMasResp.cMsgType = 'T';
                }
                else
                {
                        pBrMasResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        if(Row=mysql_fetch_row(Res))
                        {
                                strncpy(pBrMasResp.subViewBrMas[j].sEntityId,Row[0],ENTITY_ID_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sUserName,Row[1],ENTITY_NAME_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].cClntType,Row[2],CLIENT_TYPE_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sEmailId,Row[8],EMAIL_ADDR_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sDOB,Row[3],DATE_LENGTH);
                                strncpy(pBrMasResp.subViewBrMas[j].sTelPhone,Row[9],MOBILE_NUM_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sMobileNo,Row[10],MOBILE_NUM_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sEM_ADDRESS_LINE_1,Row[4],SUB_ADD_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sEM_ADDRESS_LINE_2,Row[5],SUB_ADD_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sEM_ADDRESS_LINE_3,Row[6],SUB_ADD_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sEM_PINCODE,Row[7],PIN_CODE_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sCreatedDate,Row[12],DATE_LENGTH);
                                strncpy(pBrMasResp.subViewBrMas[j].sCreatedName,Row[11],ENTITY_NAME_LEN);
                                strncpy(pBrMasResp.subViewBrMas[j].sQlName,Row[13],QL_NAME_LEN);

                                logDebug2("pBrMasResp.subViewBrMas[%d].sEntityId= %s",j,pBrMasResp.subViewBrMas[j].sEntityId);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sUserName= %s",j,pBrMasResp.subViewBrMas[j].sUserName);
                                logDebug2("pBrMasResp.subViewBrMas[%d].cClntType= %s",j,pBrMasResp.subViewBrMas[j].cClntType);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sEmailId= %s",j,pBrMasResp.subViewBrMas[j].sEmailId);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sDOB= %s",j,pBrMasResp.subViewBrMas[j].sDOB);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sTelPhone= %s",j,pBrMasResp.subViewBrMas[j].sTelPhone);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sMobileNo= %s",j,pBrMasResp.subViewBrMas[j].sMobileNo);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sEM_ADDRESS_LINE_1= %s",j,pBrMasResp.subViewBrMas[j].sEM_ADDRESS_LINE_1);
				logDebug2("pBrMasResp.subViewBrMas[%d].sEM_ADDRESS_LINE_2= %s",j,pBrMasResp.subViewBrMas[j].sEM_ADDRESS_LINE_2);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sEM_ADDRESS_LINE_3= %s",j,pBrMasResp.subViewBrMas[j].sEM_ADDRESS_LINE_3);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sEM_PINCODE= %s",j,pBrMasResp.subViewBrMas[j].sEM_PINCODE);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sCreatedDate= %s",j,pBrMasResp.subViewBrMas[j].sCreatedDate);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sCreatedName= %s",j,pBrMasResp.subViewBrMas[j].sCreatedName);
                                logDebug2("pBrMasResp.subViewBrMas[%d].sQlName= %s",j,pBrMasResp.subViewBrMas[j].sQlName);


                        }
                }

                if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pBrMasResp,sizeof(struct VIEW_BR_MASTER_ADMIN_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }
                iTempNoOfRec--;


        }
         logTimestamp("Exit : fViewBranchMaster");
}


BOOL    fViewScriptBlock(CHAR  *RcvMsg)
{
        logTimestamp("Entry : fViewScriptBlock");
        struct        VIEW_SCRIPT_BLOCK_ADMIN_REQ        *pViewSBReq;
        struct        VIEW_COMMON_HDR_RESP            pSBHdrResp;
        struct        VIEW_SCRIPT_BLOCK_ADMIN_RESP       pSBResp;

        CHAR  sSBSelQry[DOUBLE_MAX_QUERY_SIZE];
	
	MYSQL_RES       *Res;
        MYSQL_ROW       Row;

        pViewSBReq= (struct VIEW_SCRIPT_BLOCK_ADMIN_REQ *)RcvMsg;
        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

	CHAR    *token;
	CHAR    sSeries[SB_SERIES_LEN];
        CHAR    sSerRow[SB_SERIES_LEN+3];
        logDebug2("pViewSBReq-->ReqHeader.iUserId = :%llu:",pViewSBReq->ReqHeader.iUserId);
        logDebug2("pViewSBReq-->sEntityId = :%s:",pViewSBReq->sEntityId);
	logDebug2("pViewSBReq-->sClientId = :%s:",pViewSBReq->sClientId);

        memset(&sSBSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	

	
        sprintf(sSBSelQry,"SELECT \
                            X.V_SCRIP_CODE, \
                            X.V_EXCH, \
                            X.V_SEGMENT, \
                            IFNULL(SM.SM_EXCH_SYMBOL, 'ALL') AS V_SYMBOL, \
                            IFNULL(SM.SM_INSTRUMENT_NAME, 'ALL') AS V_INSTRUMENT, \
                            IFNULL(SM.SM_EXPIRY_DATE, 'NA') AS V_EXPIRY_DATE, \
                            IFNULL(SM.SM_STRIKE_PRICE, 'NA') AS V_STRIKE_PRICE, \
                            IFNULL(NULLIF(SM_OPTION_TYPE, ''), 'NA') AS V_OPTION_TYPE, \
                            X.V_BUY_SELL, \
                            X.V_PRODUCT, \
                            X.BASKET_NAME, \
                            X.BLOCK_INFO, \
                            IFNULL(IFNULL(NULLIF(PROFILE_QL_CODE, 'NA'), \
                                            RM.RPM_CODE), \
                                    'NA') AS PROFILE_CODE, \
                            IFNULL(IFNULL(NULLIF(PROFILE_QL_NAME, 'NA'), \
                                            RM.RPM_NAME), \
                                    'NA') AS PROFILE_NAME, \
                            IFNULL(X.CLIENT_ID, 'ALL') AS CLIENT_ID, \
                            IFNULL(X.SERIES, 'ALL') AS SERIES, \
                            IFNULL(X.REMARK, 'ALL') AS REMARK, \
                            IFNULL(X.UPDATED_BY, 'NA') AS UPDATED_BY, \
                            IFNULL(X.UPDATED_TIME, 'NA') AS UPDATED_TIME \
                        FROM \
                            (SELECT \
                            SB.RRSB_SCRIP_CODE AS V_SCRIP_CODE, \
                            SB.RRSB_EXCHANGE AS V_EXCH, \
                            SB.RRSB_SEGMENT AS V_SEGMENT, \
                            (CASE \
                                WHEN SB.RRSB_BUYSELL = 'B' THEN 'Buy' \
                                WHEN SB.RRSB_BUYSELL = 'S' THEN 'Sell' \
                                WHEN SB.RRSB_BUYSELL = 'A' THEN 'All' \
                                ELSE 'NA' \
                             END) AS V_BUY_SELL, \
                            (CASE \
                                WHEN SB.RRSB_PRODUCT = 'C' THEN 'Cnc' \
                                WHEN SB.RRSB_PRODUCT = 'M' THEN 'Margin' \
                                WHEN SB.RRSB_PRODUCT = 'I' THEN 'Intraday' \
                                WHEN SB.RRSB_PRODUCT = 'H' THEN 'Normal' \
                                WHEN SB.RRSB_PRODUCT = 'F' THEN 'Mtf' \
                                WHEN SB.RRSB_PRODUCT = 'A' THEN 'All' \
                                ELSE 'NA' \
                            END) AS V_PRODUCT, \
                            SB.RRSB_SCRIP_BLOCK_BASKET AS BASKET_NAME, \
                            (CASE \
                                WHEN RRSB_CLIENT_ID <> 'A' THEN 'Script is block for client at profile basket' \
                                ELSE 'Profile Block' \
                                END) AS BLOCK_INFO, \
                            'NA' AS PROFILE_QL_CODE, \
                            'NA' AS PROFILE_QL_NAME, \
                            (CASE SB.RRSB_CLIENT_ID \
                                WHEN 'A' THEN 'ALL' \
                                ELSE RRSB_CLIENT_ID \
                            END) AS CLIENT_ID, \
                            (CASE SB.SERIES \
                                WHEN 'A' THEN 'ALL' \
                                ELSE SB.SERIES \
                            END) AS SERIES, \
                            SB.RRSB_REMARKS AS REMARK, \
                            SB.RRSB_UPDATED_BY AS UPDATED_BY, \
                            SB.RRSB_UPDATED_TIME AS UPDATED_TIME \
                    FROM \
                        RMS_RISK_SCRIP_BLOCK SB UNION ALL SELECT \
                        BD.SCRIP_CODE AS V_SCRIP_CODE, \
                            BD.EXCH_ID AS V_EXCH, \
                            BD.SEGMENT AS V_SEGMENT, \
                            (CASE \
                                WHEN BD.ORDERBUYSELL = 'B' THEN 'Buy' \
                                WHEN BD.ORDERBUYSELL = 'S' THEN 'Sell' \
                                WHEN BD.ORDERBUYSELL = 'A' THEN 'All' \
                                ELSE 'NA' \
                            END) AS V_BUY_SELL, \
                            (CASE \
                                WHEN BD.PRODUCT = 'C' THEN 'Cnc' \
                                WHEN BD.PRODUCT = 'M' THEN 'Margin' \
                                WHEN BD.PRODUCT = 'I' THEN 'Intraday' \
                                WHEN BD.PRODUCT = 'H' THEN 'Normal' \
                                WHEN BD.PRODUCT = 'F' THEN 'Mtf' \
                                WHEN BD.PRODUCT = 'A' THEN 'All' \
                                ELSE 'NA' \
                            END) AS V_PRODUCT, \
                            'NA' AS BASKET_NAME, \
                            (CASE \
                                WHEN EXCH_BAN_FLAG = 'Y' THEN 'FNO Block' \
                                WHEN EXCH_BAN_FLAG = 'P' THEN 'Physical Settlement Block' \
                                WHEN GSM_FLAG = 'Y' THEN 'GSM Block' \
                                WHEN GSM_FLAG = 'A' THEN 'ASM Block' \
                                WHEN SERIES_BLOCK_FLAG = 'Y' THEN 'Series Block' \
                                WHEN CLIENT_ID <> 'A' THEN 'Script is block for client at Global level' \
                                ELSE 'GLOBAL Block' \
                            END) AS BLOCK_INFO, \
                            'NA' AS PROFILE_QL_CODE, \
                            'NA' AS PROFILE_QL_NAME, \
                            (CASE CLIENT_ID \
                                WHEN 'A' THEN 'ALL' \
                                ELSE CLIENT_ID \
                            END) AS CLIENT_ID, \
                        (CASE BD.SERIES \
                                WHEN 'A' THEN 'ALL' \
                                ELSE BD.SERIES \
                            END) AS SERIES, \
                            REMARKS AS REMARK, \
                            BD.UPDATED_BY AS UPDATED_BY, \
                            BD.UPDATED_DATE AS UPDATED_TIME \
                    FROM \
                        SECURITY_RMS_BLOCK_DETAIL BD UNION ALL SELECT \
                        SM.SM_SCRIP_CODE AS V_SCRIP_CODE, \
                            SM.SM_EXCHANGE AS V_EXCH, \
                            SM.SM_SEGMENT AS V_SEGMENT, \
                            'NA' AS V_BUY_SELL, \
                            'NA' AS V_PRODUCT, \
                            'NA' AS BASKET_NAME, \
                            (CASE \
                                WHEN SUBSTRING(SM_CHECKS, 1, 1) = 1 THEN 'Inactive Options Block' \
                            END) AS BLOCK_INFO, \
                            'NA' AS PROFILE_QL_CODE, \
                            'NA' AS PROFILE_QL_NAME, \
                            'ALL' AS CLIENT_ID, \
                            (CASE SM.SM_SERIES \
                                WHEN NULL THEN 'N/A' \
                                ELSE SM.SM_SERIES \
                            END) AS SERIES, \
                            'NA' AS REMARK, \
                            'FILE-UPLOAD' AS UPDATED_BY, \
                            SM_UPDATE_DATE AS UPDATED_TIME \
                    FROM \
                        SECURITY_MASTER SM \
                    WHERE \
                        SUBSTRING(SM_CHECKS, 1, 1) = 1 UNION ALL SELECT \
                        RP.RPD_SCRIP_CODE AS V_SCRIP_CODE, \
                            RP.RPD_EXCHANGE AS V_EXCH, \
                            RP.RPD_SEGMENT AS V_SEGMENT, \
                            'NA' AS V_BUY_SELL, \
                            (CASE \
                                WHEN RP.RPD_PRODUCT = 'C' THEN 'Cnc' \
                                WHEN RP.RPD_PRODUCT = 'M' THEN 'Margin' \
                                WHEN RP.RPD_PRODUCT = 'I' THEN 'Intraday' \
                                WHEN RP.RPD_PRODUCT = 'H' THEN 'Normal' \
                                WHEN RP.RPD_PRODUCT = 'F' THEN 'Mtf' \
                                WHEN RP.RPD_PRODUCT = 'ALL' THEN 'All' \
                                ELSE 'NA' \
                            END) AS V_PRODUCT, \
                            'NA' AS BASKET_NAME, \
                        (CASE \
                                WHEN RP.RPD_MAX_ORD_VAL = 0 THEN 'Max order value for QL set to 0' \
                                WHEN RP.RPD_MAX_SPD_ORD_VAL = 0 THEN 'Max spread order value for QL set to 0' \
                                WHEN RP.RPD_MAX_ORD_QTY = 0 THEN 'Max order qty for QL set to 0' \
                                WHEN RP.RPD_MAX_LOT = 0 THEN 'Max lot for QL set to 0' \
                                WHEN RP.RPD_MIN_ORD_QTY = 0 THEN 'Min order qty for QL set to 0' \
                                WHEN RP.RPD_MIN_ORD_VALUE = 0 THEN 'Min order value for QL set to 0' \
                                WHEN RP.RPD_GROSS_BUY_QTY = 0 THEN 'Gross buy qty for QL set to 0' \
                                WHEN RP.RPD_GROSS_SELL_QTY = 0 THEN 'Gross sell qty for QL set to 0' \
                                WHEN RP.RPD_GROSS_BUY_VAL = 0 THEN 'Gross buy value for QL set to 0' \
                                WHEN RP.RPD_GROSS_SELL_VAL = 0 THEN 'Gross sell value for QL set to 0' \
                                WHEN RP.RPD_TURNOVER = 0 THEN 'Turnover for QL set to 0' \
                                WHEN RP.RPD_PENDING_BUY_ORD_VAL = 0 THEN 'Pending buy order value for QL set to 0' \
                                WHEN RP.RPD_PENDING_SELL_ORD_VAL = 0 THEN 'Pending sell order for QL set to 0' \
                                WHEN RP.RPD_TOTAL_PENDING_ORD_VAL = 0 THEN 'Total pending order for QL set to 0' \
                                WHEN RP.RPD_NET_VALUE = 0 THEN 'Net value for QL set to 0' \
                                WHEN RP.RPD_MTM = 0 THEN 'MTM for QL set to 0' \
                                WHEN RP.RPD_NET_LOT = 0 THEN 'Net lot  for QL set to 0' \
                                WHEN RP.RPD_NET_QTY = 0 THEN 'Net qty for QL set to 0' \
                                WHEN RP.RPD_NET_SELL_VAL = 0 THEN 'Net sell value for QL set to 0' \
                                WHEN RP.RPD_NET_BUY_VAL = 0 THEN 'Net buy value for QL set to 0' \
                            END) AS BLOCK_INFO, \
                            RP.RPD_PROFILE_CODE AS PROFILE_QL_CODE, \
                            RP.RPD_PROFILE_NAME AS PROFILE_QL_NAME, \
                            'ALL' AS CLIENT_ID, \
                            IFNULL(RP.RPD_SERIES, 'ALL') AS SERIES, \
                            'NA' AS REMARK, \
                            'NA' AS UPDATED_BY, \
                            'NA' AS UPDATED_TIME \
                     FROM \
                        RMS_RISK_PROFILE_DET RP \
                            WHERE \
                         RP.RPD_MAX_ORD_VAL = 0 \
                            OR RP.RPD_MAX_SPD_ORD_VAL = 0 \
                            OR RP.RPD_MAX_ORD_QTY = 0 \
                            OR RP.RPD_MAX_LOT = 0 \
                            OR RP.RPD_MIN_ORD_QTY = 0 \
                            OR RP.RPD_MIN_ORD_VALUE = 0 \
                            OR RP.RPD_GROSS_BUY_QTY = 0 \
                            OR RP.RPD_GROSS_SELL_QTY = 0 \
                            OR RP.RPD_GROSS_BUY_VAL = 0 \
                            OR RP.RPD_GROSS_SELL_VAL = 0 \
                            OR RP.RPD_TURNOVER = 0 \
                            OR RP.RPD_PENDING_BUY_ORD_VAL = 0 \
                            OR RP.RPD_PENDING_SELL_ORD_VAL = 0 \
                            OR RP.RPD_TOTAL_PENDING_ORD_VAL = 0 \
                            OR RP.RPD_NET_VALUE = 0 \
                            OR RP.RPD_MTM = 0 \
                            OR RP.RPD_NET_LOT = 0 \
                        OR RP.RPD_NET_QTY = 0 \
                            OR RP.RPD_NET_SELL_VAL = 0 \
                            OR RP.RPD_NET_BUY_VAL = 0 UNION ALL SELECT \
                            RPD.RPDR_SCRIP_CODE AS V_SCRIP_CODE, \
                            RPD.RPDR_EXCHANGE AS V_EXCH, \
                            RPD.RPDR_SEGMENT AS V_SEGMENT, \
                            'NA' AS V_BUY_SELL, \
                            (CASE \
                                WHEN RPD.RPDR_PRODUCT = 'C' THEN 'Cnc' \
                                WHEN RPD.RPDR_PRODUCT = 'M' THEN 'Margin' \
                                WHEN RPD.RPDR_PRODUCT = 'I' THEN 'Intraday' \
                                WHEN RPD.RPDR_PRODUCT = 'H' THEN 'Normal' \
                                WHEN RPD.RPDR_PRODUCT = 'F' THEN 'Mtf' \
                                WHEN RPD.RPDR_PRODUCT = 'ALL' THEN 'All' \
                                ELSE 'NA' \
                            END) AS V_PRODUCT, \
                            'NA' AS BASKET_NAME, \
                            (CASE \
                                WHEN RPD.RPDR_MAX_ORD_VAL = 0 THEN 'Max order value for QL set to 0' \
                                WHEN RPD.RPDR_MAX_SPD_ORD_VAL = 0 THEN 'Max spread order value for QL set to 0' \
                                WHEN RPD.RPDR_MAX_ORD_QTY = 0 THEN 'Max order qty for QL set to 0' \
                                WHEN RPD.RPDR_MAX_LOT = 0 THEN 'Max lot for QL set to 0' \
                                WHEN RPD.RPDR_MIN_ORD_QTY = 0 THEN 'Min order qty for QL set to 0' \
                                WHEN RPD.RPDR_MIN_ORD_VALUE = 0 THEN 'Min order value for QL set to 0' \
                                WHEN RPD.RPDR_GROSS_BUY_QTY = 0 THEN 'Gross buy qty for QL set to 0' \
                                WHEN RPD.RPDR_GROSS_SELL_QTY = 0 THEN 'Gross sell qty for QL set to 0' \
                                WHEN RPD.RPDR_GROSS_BUY_VAL = 0 THEN 'Gross buy value for QL set to 0' \
                                WHEN RPD.RPDR_GROSS_SELL_VAL = 0 THEN 'Gross sell value for QL set to 0' \
                                WHEN RPD.RPDR_TURNOVER = 0 THEN 'Turnover for QL set to 0' \
                                WHEN RPD.RPDR_PENDING_BUY_ORD_VAL = 0 THEN 'Pending buy order value for QL set to 0' \
                                WHEN RPD.RPDR_PENDING_SELL_ORD_VAL = 0 THEN 'Pending sell order for QL set to 0' \
                                WHEN RPD.RPDR_TOTAL_PENDING_ORD_VAL = 0 THEN 'Total pending order for QL set to 0' \
                                WHEN RPD.RPDR_NET_VALUE = 0 THEN 'Net value for QL set to 0' \
                                WHEN RPD.RPDR_MTM = 0 THEN 'MTM for QL set to 0' \
                                WHEN RPD.RPDR_NET_LOT = 0 THEN 'Net lot  for QL set to 0' \
                                WHEN RPD.RPDR_NET_QTY = 0 THEN 'Net qty for QL set to 0' \
                                WHEN RPD.RPDR_NET_SELL_VAL = 0 THEN 'Net sell value for QL set to 0' \
                                WHEN RPD.RPDR_NET_BUY_VAL = 0 THEN 'Net buy value for QL set to 0' \
                            END) AS BLOCK_INFO, \
                            RPD.RPDR_PROFILE_CODE AS PROFILE_QL_CODE, \
                            RPD.RPDR_PROFILE_NAME AS PROFILE_QL_NAME, \
                            (CASE \
                                WHEN RPD.RPDR_CLIENT_ID IN ('NA' , 'A') THEN 'ALL' \
                                ELSE RPD.RPDR_CLIENT_ID \
                            END) AS CLIENT_ID, \
                            IFNULL(RPD.RPDR_SERIES, 'ALL') AS SERIES, \
                                        'NA' AS REMARK, \
                                        'NA' AS UPDATED_BY, \
                                        'NA' AS UPDATED_TIME \
                                FROM \
                        RMS_RISK_PROFILE_DET_RET RPD \
                    WHERE \
                        RPD.RPDR_MAX_ORD_VAL = 0 \
                            OR RPD.RPDR_MAX_SPD_ORD_VAL = 0 \
                            OR RPD.RPDR_MAX_ORD_QTY = 0 \
                            OR RPD.RPDR_MAX_LOT = 0 \
                            OR RPD.RPDR_MIN_ORD_QTY = 0 \
                            OR RPD.RPDR_MIN_ORD_VALUE = 0 \
                            OR RPD.RPDR_GROSS_BUY_QTY = 0 \
                            OR RPD.RPDR_GROSS_SELL_QTY = 0 \
                            OR RPD.RPDR_GROSS_BUY_VAL = 0 \
                            OR RPD.RPDR_GROSS_SELL_VAL = 0 \
                            OR RPD.RPDR_TURNOVER = 0 \
                            OR RPD.RPDR_PENDING_BUY_ORD_VAL = 0 \
                            OR RPD.RPDR_PENDING_SELL_ORD_VAL = 0 \
                            OR RPD.RPDR_TOTAL_PENDING_ORD_VAL = 0 \
                            OR RPD.RPDR_NET_VALUE = 0 \
                            OR RPD.RPDR_MTM = 0 \
                            OR RPD.RPDR_NET_LOT = 0 \
                            OR RPD.RPDR_NET_QTY = 0 \
                            OR RPD.RPDR_NET_SELL_VAL = 0 \
                            OR RPD.RPDR_NET_BUY_VAL = 0) AS X \
                        LEFT OUTER JOIN \
                    RMS_RISK_PROFILE_MAST RM ON (X.BASKET_NAME = (CASE \
                                WHEN X.V_SEGMENT = 'E' THEN RM.RPM_EQ_BASKET \
                                WHEN X.V_SEGMENT IN ('D' , 'C') THEN RM.RPM_DR_BASKET \
                            END)) \
                        LEFT OUTER JOIN \
                    SECURITY_MASTER SM ON (SM.SM_SCRIP_CODE = X.V_SCRIP_CODE \
                        AND SM.SM_SEGMENT = X.V_SEGMENT \
                        AND SM.SM_EXCHANGE = X.V_EXCH); ");

 
	printf("SELECT QUERY = %s",sSBSelQry);

        if(mysql_query(DBQury,sSBSelQry) != SUCCESS)
        {
                logSqlFatal("Error in Script block selectQry  (sSBSelQry ).");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);
        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

        pSBHdrResp.IntRespHeader.iSeqNo = 0;
        pSBHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pSBHdrResp.IntRespHeader.iErrorId = 0;
        pSBHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_SCRIPT_BLOCK_HED_RESP;
        pSBHdrResp.IntRespHeader.iUserId = pViewSBReq->ReqHeader.iUserId;
        pSBHdrResp.IntRespHeader.cSource = pViewSBReq->ReqHeader.cSource;
        pSBHdrResp.cMsgType = 'H';
        pSBHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pSBHdrResp.IntRespHeader.iMsgLength = %d",pSBHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pSBHdrResp.IntRespHeader.iMsgCode = %d",pSBHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pSBHdrResp.IntRespHeader.iUserId = %llu",pViewSBReq->ReqHeader.iUserId);
        logDebug2("pSBHdrResp.IntRespHeader.cSource = %c",pViewSBReq->ReqHeader.cSource);
        logDebug2("pSBHdrResp.iNoofRec = %d",pSBHdrResp.iNoofRec);
        logDebug2("pViewCirLmtReq->ReqHeader.iUserId = %llu",pViewSBReq->ReqHeader.iUserId);



        iRelayID = find_admin_adapter(pViewSBReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);


	if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }
        if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pSBHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }


        for(i=0;i<iNoOfPkt;i++)
        {
                logDebug2("No 0f Pkt..(i) = %d",i);
                memset(&pSBResp,'\0',sizeof(struct VIEW_SCRIPT_BLOCK_ADMIN_RESP));
                pSBResp.IntRespHeader.iSeqNo = 0;
                pSBResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SCRIPT_BLOCK_ADMIN_RESP);
                pSBResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_SCRIPT_BLOCK_RESP;
                pSBResp.IntRespHeader.iErrorId = 0;
                pSBResp.IntRespHeader.iUserId = pViewSBReq->ReqHeader.iUserId;
                pSBResp.IntRespHeader.cSource = pViewSBReq->ReqHeader.cSource;


		logDebug2("pSBResp.IntRespHeader.iMsgLength = %d",pSBResp.IntRespHeader.iMsgLength);
		logDebug2("iTempNoOfRec = %d",iTempNoOfRec);
                if(iTempNoOfRec <= 1)
                {
                        pSBResp.cMsgType = 'T';
                }
                else
                {
                        pSBResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {
                        if(Row=mysql_fetch_row(Res))
                        {	
				/**
				pSBResp.sSubViewScriptBlock[j].iScriptCode = atoi(Row[0]);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sExchng,Row[1],EXCHANGE_LEN);
				pSBResp.sSubViewScriptBlock[j].cSegment = Row[2][0];
                                strncpy(pSBResp.sSubViewScriptBlock[j].sSymbol,Row[3],DB_SYMBOL_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sBuySell,Row[4],BUY_SELL_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sProduct,Row[5],PRODUCT_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sBasket,Row[6],BASKET_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sBlockInfo,Row[7],BLOCK_INFO_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sProfileCode,Row[8],PROFILE_CODE);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sProfileName,Row[9],PROFILE_NAME);
				**/			
	
				pSBResp.sSubViewScriptBlock[j].iScriptCode = atoi(Row[0]);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sExchng,Row[1],EXCHANGE_LEN);
                                pSBResp.sSubViewScriptBlock[j].cSegment = Row[2][0];
                                strncpy(pSBResp.sSubViewScriptBlock[j].sSymbol,Row[3],DB_SYMBOL_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sInstrument,Row[4],INSTRUMENT_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sExpiryDate,Row[5],DB_DATETIME_LEN);
                                pSBResp.sSubViewScriptBlock[j].iStrikePrice = atoi(Row[6]);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sOptionType,Row[7],OPTION_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sBuySell,Row[8],BUY_SELL_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sProduct,Row[9],PRODUCT_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sBasket,Row[10],BASKET_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sBlockInfo,Row[11],BLOCK_INFO_LEN);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sProfileCode,Row[12],PROFILE_CODE);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sProfileName,Row[13],PROFILE_NAME);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sClientId,Row[14],CLIENT_ID_LEN);
                                memset(sSeries,'\0',SB_SERIES_LEN);
                                memset(sSerRow,'\0',SB_SERIES_LEN+3);
                                strncpy(sSerRow,Row[15],SB_SERIES_LEN+3);
                                token = strtok(Row[15],"/");
                                while (token != NULL)
                                {
                                        strcat(sSeries,token);
                                        token = strtok(NULL,"/");
                                }
                                strncpy(pSBResp.sSubViewScriptBlock[j].sSeries,sSeries,SB_SERIES_LEN);
                                logDebug2("sSerRow and sSeries |%s| |%s|",sSerRow,sSeries);
                                strncpy(pSBResp.sSubViewScriptBlock[j].sRemarks,Row[16],ADMIN_REMARKS_LEN);
				strncpy(pSBResp.sSubViewScriptBlock[j].sUpdatedBy,Row[17],BP_ENTITY_ID_LEN);
				strncpy(pSBResp.sSubViewScriptBlock[j].sUpdatedTime,Row[18],DB_DATETIME_LEN);
		
				logDebug2("-----------RESPONSE FROM DATABASE----");
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].iScriptCode= %d",j,pSBResp.sSubViewScriptBlock[j].iScriptCode);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sExchng= %s",j,pSBResp.sSubViewScriptBlock[j].sExchng);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].cSegment= %c",j,pSBResp.sSubViewScriptBlock[j].cSegment);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sSymbol= %s",j,pSBResp.sSubViewScriptBlock[j].sSymbol);
				logDebug2("pSBResp.sSubViewScriptBlock[%d].sInstrument= %s",j,pSBResp.sSubViewScriptBlock[j].sInstrument);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sExpiryDate= %s",j,pSBResp.sSubViewScriptBlock[j].sExpiryDate);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].iStrikePrice= %d",j,pSBResp.sSubViewScriptBlock[j].iStrikePrice);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sOptionType= %s",j,pSBResp.sSubViewScriptBlock[j].sOptionType);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sBuySell= %s",j,pSBResp.sSubViewScriptBlock[j].sBuySell);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sProduct= %s",j,pSBResp.sSubViewScriptBlock[j].sProduct);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sBasket= %s",j,pSBResp.sSubViewScriptBlock[j].sBasket);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sBlockInfo= %s",j,pSBResp.sSubViewScriptBlock[j].sBlockInfo);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sProfileCode= %s",j,pSBResp.sSubViewScriptBlock[j].sProfileCode);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sProfileName= %s",j,pSBResp.sSubViewScriptBlock[j].sProfileName);
				logDebug2("pSBResp.sSubViewScriptBlock[%d].sClientId= %s",j,pSBResp.sSubViewScriptBlock[j].sClientId);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sSeries= %s",j,pSBResp.sSubViewScriptBlock[j].sSeries);
                                logDebug2("pSBResp.sSubViewScriptBlock[%d].sRemarks = |%s|",j,pSBResp.sSubViewScriptBlock[j].sRemarks);
				logDebug2("pSBResp.sSubViewScriptBlock[%d].sUpdatedBy = :%s:",j,pSBResp.sSubViewScriptBlock[j].sUpdatedBy);
				logDebug2("pSBResp.sSubViewScriptBlock[%d].sUpdatedTime= |%s|",j,pSBResp.sSubViewScriptBlock[j].sUpdatedTime);
                        }
                }
                if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pSBResp,sizeof(struct VIEW_SCRIPT_BLOCK_ADMIN_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }
                iTempNoOfRec--;

        }
	mysql_free_result(Res);
	logTimestamp("Exit : fViewScriptBlock--------");
	return TRUE;
}


BOOL fDrvSprdOrderBookDtls(CHAR *RcvMsg)
{
        logTimestamp("Entry : fDrvSprdOrderBookDtls");

        struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ    *pViewOrderBookReq;
        struct VIEW_ORDER_BOOK_DETAIL_RESP              pOrderBookResp;
        struct VIEW_COMMON_HDR_RESP                     pOrderBookHdrResp;

        CHAR    sDrvOrdBook[MAX_QUERY_SIZE];
        LONG32          iNoOfPkt;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfRec=0;
        LONG32          iTempNoOfRec;
        CHAR            cOrdValidity;

        pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

        logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,pViewOrderBookReq->fOrderNo);

        sprintf(sDrvOrdBook,"SELECT  DRV_ORDER_NO,DRV_SERIAL_NO,DRV_MSG_CODE,DRV_SCRIP_CODE,DRV_VALIDITY,DRV_PRO_CLIENT,DRV_SOURCE_FLG,DRV_ORIG_CLORDID,\
                        DRV_TOTAL_QTY,DRV_REM_QTY,DRV_DISC_QTY,DRV_DISC_REM_QTY,DRV_ORDER_PRICE,DRV_TRIGGER_PRICE,DRV_TRD_TRADE_QTY,\
                        DRV_TRD_TRADE_PRICE,DRV_TOTAL_TRADED_QTY,DRV_TRD_EXCH_TRADE_NO,DRV_PRODUCT_ID,DRV_EXCH_ORDER_NO,\
                        IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
                        DRV_ERROR_CODE,DRV_CLIENT_ID,DRV_BUY_SELL_IND,DRV_EXCH_ID,DRV_REASON_DESCRIPTION ,DRV_ENTITY_ID ,DRV_STRATEGY_ID ,\
                        DRV_PRO_CLIENT ,DRV_TRD_TRADE_PRICE ,DRV_GOOD_TILL_DAYS,DRV_PAN_NO,DRV_PARTICIPANT_TYPE,DRV_MKT_PROTECT_FLG,\
                        DRV_MKT_PROTECT_VAL,DRV_GTC_FLG,DRV_ENCASH_FLG FROM DRV_ORDERS\
                        WHERE DRV_ORDER_NO = %lf\
                        ORDER BY DRV_ORDER_NO , DRV_SERIAL_NO desc ;",pViewOrderBookReq->fOrderNo);

        logDebug2(" sDrvOrdBook :%s: ",sDrvOrdBook);

        if(mysql_query(DBQury,sDrvOrdBook) != SUCCESS)
        {
                logSqlFatal("ERROR in DrvOrdBook Query.");
                sql_Error(DBQury);
                return FALSE;
        }

        Res = mysql_store_result(DBQury);
        iNoOfRec = mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
   	iTempNoOfRec = iNoOfRec;

        logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
        pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
        pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
        pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;

        pOrderBookHdrResp.cMsgType = 'H';
        pOrderBookHdrResp.iNoofRec = iNoOfRec;

        logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

        logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewOrderBookReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logFatal("Write Q id %d",iTrdRtrToRel);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                for(j=0;j<5;j++)
                {
                        if(Row=mysql_fetch_row(Res))
                        {
                                pOrderBookResp.IntRespHeader.iSeqNo = 0;
                                pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
                                pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
                                pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				 pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
                                pOrderBookResp.IntRespHeader.cSource = Row[6][0];
                                logDebug2("pOrderBookResp.IntRespHeader.cSource = %c",pOrderBookResp.IntRespHeader.cSource);
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);

                                if(iTempNoOfRec <= 1)
                                {
                                        pOrderBookResp.cMsgType = 'T';
                                }
                                else
                                {
                                        pOrderBookResp.cMsgType = 'D';
                                }

                                pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
                                pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
                                pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

                                if(atoi(Row[4]) == VALIDITY_DAY)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
                                }
                                else if(atoi(Row[4]) == VALIDITY_IOC)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
                                }

                                pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
                                pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
                                pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
                                pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
                                pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
                                pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
                                pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
                                pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
                                pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[17]);
                                pOrderBookResp.suborderbookdtls[j].sProduct = Row[18][0];
                                strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

                                if(strlen(Row[25])!= 0 )
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
                                }

                                if(Row[23][0]== 'B')
                                {

                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
                                }
                                else
                                {

                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
                                }

                                strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
                                pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);
                                if(strlen(Row[31]) == 0)
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
                                }

                                pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
                                pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
                                pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
                                pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
                                pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];

                                logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
                                logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s:,ErrorID:%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);

                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate:%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType:%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag:%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
                                logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
                                logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
                                logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
                                logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);

                        }
                        iTempNoOfRec--;
                }

                if(( WriteMsgQ(iTrdRtrToRel, (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logDebug2("Write Q id %d", iTrdRtrToRel);
                        return FALSE;
                }
        }

        logTimestamp("Exit : fDrvSprdOrderBookDtls");
        return TRUE;
}

BOOL    fCOMMSprdOrderBookDtls(CHAR *RcvMsg)
{
        logDebug2("Entry : fCOMMSprdOrderBookDtls");

        struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ    *pViewOrderBookReq;
        struct VIEW_ORDER_BOOK_DETAIL_RESP              pOrderBookResp;
        struct VIEW_COMMON_HDR_RESP                     pOrderBookHdrResp;

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;
        CHAR            *sCOMMOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

        pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

        logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,pViewOrderBookReq->fOrderNo);


        sprintf(sCOMMOrdBook,"SELECT    COMM_ORDER_NO,\
                        COMM_SERIAL_NO,\
                        COMM_MSG_CODE,\
                        COMM_SCRIP_CODE,\
                        COMM_VALIDITY,\
                        COMM_PRO_CLIENT,\
                        COMM_SOURCE_FLG,\
                        COMM_TOTAL_QTY,\
                        COMM_REM_QTY,\
                        COMM_DISC_QTY,\
                        COMM_DISC_REM_QTY,\
                        COMM_ORDER_PRICE,\
                        COMM_TRIGGER_PRICE,\
                        COMM_TRD_TRADE_QTY,\
                        COMM_TRD_TRADE_PRICE,\
                        COMM_TOTAL_TRADED_QTY,\
                        COMM_TRD_EXCH_TRADE_NO,\
                        COMM_PRODUCT_ID,\
                        COMM_EXCH_ORDER_NO,\
                        COMM_INTERNAL_ENTRY_DATE,\
                        COMM_ERROR_CODE,\
                        COMM_CLIENT_ID,\
                        COMM_BUY_SELL_IND,\
        		COMM_EXCH_ID,\
                        COMM_REASON_DESCRIPTION ,\
                        COMM_ENTITY_ID ,\
                        COMM_STRATEGY_ID ,\
                        COMM_PRO_CLIENT ,\
                        COMM_TRD_TRADE_PRICE ,\
                        COMM_GOOD_TILL_DAYS, \
                        COMM_LEG_NO,\
                        IFNULL(COMM_PAN_NO,\"NA\"),\
                        IFNULL(COMM_PARTICIPANT_TYPE,'N'),\
                        IFNULL(COM_MKT_PROTECT_FLG,'N'),\
                        COMM_MKT_PROTECT_VAL,\
                        COMM_GTC_FLG,\
                        COMM_ENCASH_FLG \
                        FROM COMM_ORDERS\
                        WHERE COMM_ORDER_NO = %lf \
                        ORDER BY COMM_ORDER_NO , COMM_SERIAL_NO desc ;",pViewOrderBookReq->fOrderNo);
        logDebug2(" sCOMMOrdBook :%s: ",sCOMMOrdBook);

        if(mysql_query(DBQury,sCOMMOrdBook) != SUCCESS)
        {
                logSqlFatal("ERROR in COMMOrdBook Query.");
                sql_Error(DBQury);
        }

        Res = mysql_store_result(DBQury);

        iNoOfRec = mysql_num_rows(Res);

        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfRec;
	logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
        pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
        pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
        pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

        pOrderBookHdrResp.cMsgType = 'H';
        pOrderBookHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
        logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
        iRelayID = find_admin_adapter(pViewOrderBookReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ(iTrdRtrToRel , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logDebug2("Write Q id %d",iTrdRtrToRel);
                return FALSE;
        }
        logInfo("I am in Commodity");
        for(i=0;i<iNoOfPkt;i++)
        {
                for(j=0;j<5;j++)
                {
                        if((Row = mysql_fetch_row(Res)))
                        {
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
                                pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
                                pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
                                logDebug2("pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[24]);
                                pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
                                strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
                                pOrderBookResp.IntRespHeader.cSource = Row[6][0];
				if(iTempNoOfRec <= 1)
                                {
                                        pOrderBookResp.cMsgType = 'T';
                                }
                                else
                                {
                                        pOrderBookResp.cMsgType = 'D';
                                }

                                pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
                                pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
                                pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3] ,SECURITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

                                if(atoi(Row[4]) == VALIDITY_DAY)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
                                }
                                else if(atoi(Row[4]) == VALIDITY_IOC)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
                                }

                                pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);				
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
                                pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
                                pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
                                pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
                                pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
                                pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
                                pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

                                pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
                                pOrderBookResp.suborderbookdtls[j].iExchTradeNo   = atoi(Row[16]);

                                pOrderBookResp.suborderbookdtls[j].sProduct = Row[17][0];
                                strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18] ,BSE_EXCH_ORDER_NO_LEN);

                                strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_STRING_LENGTH);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21] ,CLIENT_ID_LEN);
				if(Row[22][0]== 'B')
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
                                }

                                if(strlen(Row[24])!= 0 )
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
                                }

                                strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
                                pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
                                strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
                                pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);

                                if(strlen(Row[31]) == 0)
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
                                }

                                pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
                                pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
                                pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
                                pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
                                pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];


                                logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
                                logDebug2(" pOrderBookResp.IntRespHeader.sExcgId :%s:",pOrderBookResp.IntRespHeader.sExcgId);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
                                logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
                                logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
                                logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
                                logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);
                        }
                        iTempNoOfRec--;
                }

                if(( WriteMsgQ(iTrdRtrToRel , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logDebug2("Write Q id %d", iTrdRtrToRel);
                        return FALSE;
                }

        }
        logTimestamp("Exit :  fCOMMSprdOrderBookDtls");
        return TRUE;

}

BOOL CreateNeatFile()
{
        logTimestamp("Entry : CreateNeatFile");
        SHORT   iOption=0;
        struct INT_CREATE_FILE_REQ pReq;
        memset(&pReq,'\0' ,sizeof(struct INT_CREATE_FILE_REQ));
        logInfo("Select Option");
        logInfo("1. CASH OPEN ORDER FILE");
        logInfo("2. CASH OPEN POSITION FILE");
        logInfo("3. FO OPEN ORDER FILE");
        logInfo("4. FO OPEN POSITION FILE");
        scanf("%d",&iOption);
        if(iOption < 1 && iOption >4)
        {
                logInfo("Invalid Option");
                exit(ERROR);
        }

        if(iOption == 1 || iOption == 2)
        {
                pReq.IntReqHeader.cSegment = EQUITY_SEGMENT;
        }
        else
        {
                pReq.IntReqHeader.cSegment = DERIVATIVE_SEGMENT;
        }


        pReq.IntReqHeader.iSeqNo = iOption;
        logDebug2("pReq.IntReqHeader.iSeqNo = :%d:",pReq.IntReqHeader.iSeqNo);
        logDebug2("pReq.IntReqHeader.iMsgLength = :%d:",pReq.IntReqHeader.iMsgLength);
        logDebug2("pReq.IntReqHeader.iMsgCode = :%d:",pReq.IntReqHeader.iMsgCode);
        logDebug2("pReq.IntReqHeader.sExcgId = :%s:",pReq.IntReqHeader.sExcgId);
        logDebug2("pReq.IntReqHeader.iUserId = :%d:",pReq.IntReqHeader.iUserId);
        logDebug2("pReq.IntReqHeader.cSource = :%c:",pReq.IntReqHeader.cSource);
        logDebug2("pReq.IntReqHeader.cSegment = :%c:",pReq.IntReqHeader.cSegment);
        NeatFileFormat((CHAR *)&pReq);
        logTimestamp("Exit : CreateNeatFile");
}

BOOL NeatFileFormat (CHAR *RcvMsg)
{
        logTimestamp("Entry : NeatFileFormat");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        CHAR             sSeq[30];
        CHAR    sFileName [FILE_NAME_LEN];
        memset (sFileName,'\0',FILE_NAME_LEN);
        CHAR    sFileName1 [FILE_NAME_LEN];
        memset (sFileName1,'\0',FILE_NAME_LEN);
	
	  memset (sSeq,'\0',30);
        CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
        CHAR    sTempFile[FILE_NAME_LEN];
        memset (sTempFile,'\0',FILE_NAME_LEN);

        LONG32 iRow;
        FILE *fpFile;
	
	struct INT_CREATE_FILE_RES      pResp;

        struct INT_CREATE_FILE_REQ *pReq;
        pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
	
	logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
        logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
        logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
        logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
        logDebug2("pReq->IntReqHeader.iUserId = :%d:",pReq->IntReqHeader.iUserId);
        logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
        logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);
	logDebug2("pReq->iFileformat = :%d:",pReq->iFileformat);


        if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
        {
                sql_Error(DBQury);
                logSqlFatal("error in select Time.");
                return FALSE;
        }

        Res = mysql_store_result(DBQury);
        if((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Row[0] = :%s:",Row[0]);

                strncpy(sSeq,Row[0],strlen(Row[0]));
                logDebug2("Time is : %s", sSeq);
        }

        mysql_free_result(Res);
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
        if(pReq->IntReqHeader.iSeqNo == 1 && pReq->IntReqHeader.cSegment == EQUITY_SEGMENT)
        {
                sprintf(sFileName,"%s/%s%s",sRRPath,RR_NEAT_EQ_ORDERS,sSeq);
                sprintf(sTempFile,"%s%s",RR_NEAT_EQ_ORDERS,sSeq);
                sprintf(sSelectQry,"SELECT CONCAT_WS(',',ORDER_NO,ORDER_STATUS,SYMBOL,SERIES,SECURITY_SYMBOL,INSTRUMENT_TYPE,BOOK_TYPE,MARKET_TYPE,USER_ID,BRANCH_ID,BUY_SELL_INDICATOR,DQ,DQ_REMAINING,QTY_REMAINING,ORDER_QTY,MF_QTY,AON_INDICATOR,QUANTITY_TRADED,PRICE,TM_ID,ORDER_TYPE,GTD,ORDER_DURATION,PRO_CLIE,CLIENT_AC,PARTICIPANT_CODE,AUCTION_PART_TYPE,AUCTION_NO,SETT_PERIOD,ORDER_MOD_DT_TIME,CREDIT_RETING,REMARKS,ORDER_ENTRY_DT_TIME,CP_ID)AS PEND_POS FROM PEND_POSITION_EQ ;");
        }
        else if(pReq->IntReqHeader.iSeqNo == 2 && pReq->IntReqHeader.cSegment == EQUITY_SEGMENT)
        {
                sprintf(sFileName,"%s/%s%s",sRRPath,RR_NEAT_EQ_POSTION,sSeq);
                sprintf(sTempFile,"%s%s",RR_NEAT_EQ_POSTION,sSeq);
        	if(pReq->iFileformat == 1)//for csv format.
		{
			/***
                	sprintf(sSelectQry,"SELECT CONCAT_WS(',',0, 1, IF((BUY_QTY < SELL_QTY), '1', '2'), SM_EXCH_SYMBOL, SM_SERIES, 1, '', '', '', 0, '', ABS((BUY_QTY - SELL_QTY)), '', '', (CASE EM.ENTITY_SUB_TYPE WHEN 7 THEN 2 WHEN 1 THEN 1 ELSE 2 END), EM.ENTITY_NSE_CODE, '') AS NEAT_CSV FROM (SELECT CLIENT_ID, SECURITY_ID, EXCH_ID, SUM(BUY_QTY) AS BUY_QTY, SUM(BUY_VAL) AS BUY_VAL, SUM(SELL_QTY) AS SELL_QTY, SUM(SELL_VAL) AS SELL_VAL, EXCH_SEGMENT, PRODUCT, INT_REF_ID, CROSS_CUR_FLAG FROM NET_POSITION_EQ GROUP BY CLIENT_ID , SECURITY_ID , EXCH_ID , PRODUCT) AS NP JOIN ENTITY_MASTER EM JOIN SECURITY_MASTER WHERE SECURITY_ID = SM_SCRIP_CODE AND EXCH_SEGMENT = SM_SEGMENT AND EXCH_ID = SM_EXCHANGE AND EXCH_ID = 'NSE' AND CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0; ");
			***/

			sprintf(sSelectQry,"SELECT CONCAT_WS(',',0, 1, IF((BUY_QTY < SELL_QTY), '1', '2'), SM_EXCH_SYMBOL, SM_SERIES, 1, '', '', '', 'MKT', '', ABS((BUY_QTY - SELL_QTY)), '', '', (CASE EM.ENTITY_SUB_TYPE WHEN 7 THEN 2 WHEN 1 THEN 1 ELSE 2 END), EM.ENTITY_NSE_CODE, '') AS NEAT_CSV FROM (SELECT NPT_CLIENT_ID, NPT_SECURITY_ID, NPT_EXCH_ID, SUM(NPT_TOT_BUY_QTY) AS BUY_QTY, SUM(NPT_TOT_BUY_VAL) AS BUY_VAL, SUM(NPT_TOT_SELL_QTY) AS SELL_QTY, SUM(NPT_TOT_SELL_VAL) AS SELL_VAL, NPT_SEGMENT, NPT_PROD_ID, NPT_REF_ID, NPT_CROSS_CUR_FLAG FROM NET_POSITION_TABLE GROUP BY NPT_CLIENT_ID , NPT_SECURITY_ID , NPT_EXCH_ID , NPT_PROD_ID) AS NP JOIN ENTITY_MASTER EM JOIN SEM_ACTIVE WHERE NPT_SECURITY_ID = SM_SCRIP_CODE AND NPT_SEGMENT = SM_SEGMENT AND NPT_EXCH_ID = SM_EXCHANGE  AND NPT_CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0 AND NP.NPT_PROD_ID IN('I','V','B') AND NPT_SEGMENT ='E';");

		}
		else
		{//for txt format

			/***
                	sprintf(sSelectQry,"SELECT 	CONCAT_WS(',',0, 1, IF((BUY_QTY < SELL_QTY), '1', '2'),   SM_EXCH_SYMBOL, SM_SERIES, 1, '', '', '', 0, '', ABS((BUY_QTY - SELL_QTY)), '', '', (CASE EM.ENTITY_SUB_TYPE WHEN 7 THEN 2 WHEN 1 THEN 1 ELSE 2   END), EM.ENTITY_NSE_CODE, '') AS NEAT_PIPE FROM (select CLIENT_ID,   SECURITY_ID, EXCH_ID, sum(BUY_QTY) as BUY_QTY, sum(BUY_VAL) as BUY_VAL, sum(SELL_QTY) as SELL_QTY, sum(SELL_VAL) as SELL_VAL, EXCH_SEGMENT, PRODUCT, INT_REF_ID, CROSS_CUR_FLAG from NET_POSITION_EQ group by CLIENT_ID,SECURITY_ID,EXCH_ID,PRODUCT) as NP JOIN ENTITY_MASTER EM JOIN SECURITY_MASTER WHERE SECURITY_ID = SM_SCRIP_CODE AND EXCH_SEGMENT = SM_SEGMENT AND EXCH_ID = SM_EXCHANGE AND EXCH_ID = 'NSE' AND CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0;");
			***/
	
			sprintf(sSelectQry,"SELECT CONCAT_WS(',',0, 1, IF((BUY_QTY < SELL_QTY), '1', '2'), SM_EXCH_SYMBOL, SM_SERIES, 1, '', '', '', 'MKT', '', ABS((BUY_QTY - SELL_QTY)), '', '', (CASE EM.ENTITY_SUB_TYPE WHEN 7 THEN 2 WHEN 1 THEN 1 ELSE 2 END), EM.ENTITY_NSE_CODE, '') AS NEAT_CSV FROM (SELECT NPT_CLIENT_ID, NPT_SECURITY_ID, NPT_EXCH_ID, SUM(NPT_TOT_BUY_QTY) AS BUY_QTY, SUM(NPT_TOT_BUY_VAL) AS BUY_VAL, SUM(NPT_TOT_SELL_QTY) AS SELL_QTY, SUM(NPT_TOT_SELL_VAL) AS SELL_VAL, NPT_SEGMENT, NPT_PROD_ID, NPT_REF_ID, NPT_CROSS_CUR_FLAG FROM NET_POSITION_TABLE GROUP BY NPT_CLIENT_ID , NPT_SECURITY_ID , NPT_EXCH_ID , NPT_PROD_ID) AS NP JOIN ENTITY_MASTER EM JOIN SEM_ACTIVE WHERE NPT_SECURITY_ID = SM_SCRIP_CODE AND NPT_SEGMENT = SM_SEGMENT AND NPT_EXCH_ID = SM_EXCHANGE  AND NPT_CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0 AND NP.NPT_PROD_ID IN('I','V','B') AND NPT_SEGMENT ='E';");
	
	
		}
        }
        else if(pReq->IntReqHeader.iSeqNo == 1 && pReq->IntReqHeader.cSegment == DERIVATIVE_SEGMENT)
        {
                sprintf(sFileName,"%s/%s%s",sRRPath,RR_NEAT_FO_ORDERS,sSeq);
                sprintf(sTempFile,"%s%s",RR_NEAT_FO_ORDERS,sSeq);
                sprintf(sSelectQry,"SELECT CONCAT_WS(',',ORDER_NO,ORDER_STATUS,INSTRUMENT_TYPE,SYMBOL,EXPIRY_DATE,STRIKE_PRICE,OPTION_TYPE,SECURITY_SYMBOL,BOOK_TYPE,BOOK_TYPE_NAME,MARKET_TYPE,USER_ID,BRANCH_ID,BUY_SELL_INDICATOR,DQ,DQ_REMAINING,QTY_REMAINING,ORDER_QTY,MF_QTY,AON_INDICATOR,QUANTITY_TRADED,PRICE,TM_ID,ORDER_TYPE,GTD,ORDER_DURATION,PRO_CLIE,CLIENT_AC,PARTICIPANT_CODE,OPEN_CLOSE,COVER_UNCOVER,ORDER_MOD_DT_TIME,REMARKS,ORDER_ENTRY_DT_TIME,CP_ID)AS PEND_POS fROM PEND_POSITION_DRV ;");
        }
        else if(pReq->IntReqHeader.iSeqNo == 2 && pReq->IntReqHeader.cSegment == DERIVATIVE_SEGMENT)
        {
                sprintf(sFileName,"%s/%s%s",sRRPath,RR_NEAT_FO_POSTION,sSeq);
                sprintf(sTempFile,"%s%s",RR_NEAT_FO_POSTION,sSeq);
		
		sprintf(sSelectQry,"SELECT  CONCAT_WS(',',(CASE LENGTH(Reference_No) WHEN 1 THEN CONCAT(Reference_No,' ')  WHEN 2 THEN CONCAT(Reference_No,' ') WHEN 3 THEN CONCAT(Reference_No,' ') WHEN 4 THEN CONCAT(Reference_No,' ') WHEN 5 THEN CONCAT(Reference_No,' ') WHEN 6 THEN CONCAT(Reference_No,' ') WHEN 7 THEN CONCAT(Reference_No,' ') WHEN 8 THEN CONCAT(Reference_No,' ') WHEN 9 THEN CONCAT(Reference_No,' ') WHEN 10 THEN CONCAT(Reference_No,' ') WHEN 11 THEN CONCAT(Reference_No,' ') WHEN 12 THEN CONCAT(Reference_No,' ') WHEN '' THEN CONCAT(Reference_No,' ') ELSE Reference_No END)  , (CASE LENGTH(Open_Close) WHEN 1 THEN CONCAT(Open_Close,'  ')          END )  , (CASE LENGTH(Cover_Uncover) WHEN 1 THEN CONCAT(Cover_Uncover,'  ')          END )  , (CASE LENGTH(Book_Type) WHEN 1 THEN CONCAT(Book_Type,'  ')        WHEN '' THEN CONCAT(Book_Type,'  ') ELSE Book_Type END )  , (CASE LENGTH(MIT_Type) WHEN 1 THEN CONCAT(MIT_Type,'  ') END )  , (CASE LENGTH(BUY_SELL) WHEN 1 THEN CONCAT(BUY_SELL,'  ') WHEN '' THEN CONCAT(BUY_SELL,'  ') ELSE BUY_SELL END ) , (CASE LENGTH(INSTRUMENT) WHEN 1 THEN CONCAT(INSTRUMENT,'  ')  WHEN 2 THEN CONCAT(INSTRUMENT,'  ') WHEN 3 THEN CONCAT(INSTRUMENT,'  ') WHEN 4 THEN CONCAT(INSTRUMENT,'  ') WHEN 5 THEN CONCAT(INSTRUMENT,'  ') WHEN '' THEN CONCAT(INSTRUMENT,'  ') ELSE INSTRUMENT END) , (CASE LENGTH(SYMBOL) WHEN 1 THEN CONCAT(SYMBOL,'  ')  WHEN 2 THEN CONCAT(SYMBOL,'  ') WHEN 3 THEN CONCAT(SYMBOL,'  ') WHEN 4 THEN CONCAT(SYMBOL,'  ') WHEN 5 THEN CONCAT(SYMBOL,'  ') WHEN 6 THEN CONCAT(SYMBOL,'  ') WHEN 7 THEN CONCAT(SYMBOL,'  ') WHEN 8 THEN CONCAT(SYMBOL,'  ') WHEN 9 THEN CONCAT(SYMBOL,'  ') WHEN '' THEN CONCAT(SYMBOL,'  ') ELSE SYMBOL END)  , (CASE LENGTH(Expiry)  WHEN 1 THEN CONCAT(Expiry,'  ')  WHEN 2 THEN CONCAT(Expiry,'  ') WHEN 3 THEN CONCAT(Expiry,'  ') WHEN 4 THEN CONCAT(Expiry,'  ') WHEN 5 THEN CONCAT(Expiry,'  ') WHEN 6 THEN CONCAT(Expiry,'  ') WHEN 7 THEN CONCAT(Expiry,'  ') WHEN 8 THEN CONCAT(Expiry,'  ') WHEN 9 THEN CONCAT(Expiry,'  ') WHEN '' THEN CONCAT(Expiry,'  ') ELSE Expiry END)  , if (INSTRUMENT like 'OPT%%' ,(case LENGTH(ROUND(NPT_STRIKE_PRICE,2))  WHEN 1 THEN CONCAT(NPT_STRIKE_PRICE,'  ')  WHEN 2 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 3 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 4 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 5 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 6 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 7 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 8 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN 9 THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ') WHEN '' THEN CONCAT(ROUND(NPT_STRIKE_PRICE,2),'  ')  ELSE substring(NPT_STRIKE_PRICE,1,10)  END),'  ')  , (CASE LENGTH(NPT_OPTION_TYPE) WHEN 1 THEN CONCAT(NPT_OPTION_TYPE,'  ') WHEN '' THEN CONCAT(NPT_OPTION_TYPE,'  ') ELSE NPT_OPTION_TYPE END ) , (CASE LENGTH(Instruction) WHEN 1 THEN CONCAT(Instruction,'  ')  WHEN '' THEN CONCAT(Instruction,'  ')      ELSE Instruction END ) , (CASE LENGTH(GTD_Days)WHEN 1 THEN CONCAT(GTD_Days,'  ')  WHEN 2 THEN CONCAT(GTD_Days,'  ') WHEN 3 THEN CONCAT(GTD_Days,'  ') WHEN 4 THEN CONCAT(GTD_Days,'  ') WHEN 5 THEN CONCAT(GTD_Days,'  ') WHEN 6 THEN CONCAT(GTD_Days,'  ') WHEN 7 THEN CONCAT(GTD_Days,'  ') WHEN 8 THEN CONCAT(GTD_Days,'  ') WHEN 9 THEN CONCAT(GTD_Days,'  ') WHEN 10 THEN CONCAT(GTD_Days,'  ') WHEN '' THEN CONCAT(GTD_Days,'  ') ELSE GTD_Days  END) , (CASE LENGTH(Special_Term) WHEN 1 THEN CONCAT(Special_Term,'  ')      WHEN '  ' THEN CONCAT(Special_Term,'  ') ELSE Special_Term END)  ,  (CASE LENGTH(MF_Qty) WHEN 1 THEN CONCAT(MF_Qty,'  ')  WHEN 2 THEN CONCAT(MF_Qty,'  ') WHEN 3 THEN CONCAT(MF_Qty,'  ') WHEN 4 THEN CONCAT(MF_Qty,'  ') WHEN 5 THEN CONCAT(MF_Qty,'  ') WHEN 6 THEN CONCAT(MF_Qty,'  ') WHEN 7 THEN CONCAT(MF_Qty,'  ') WHEN 8 THEN CONCAT(MF_Qty,'  ')  WHEN '' THEN CONCAT(MF_Qty,'  ') ELSE MF_Qty  END) , (CASE LENGTH(Price)  WHEN 1 THEN CONCAT(Price,'  ')  WHEN 2 THEN CONCAT(Price,'  ') WHEN 3 THEN CONCAT(Price,'  ') WHEN 4 THEN CONCAT(Price,'  ') WHEN 5 THEN CONCAT(Price,'  ') WHEN 6 THEN CONCAT(Price,'  ') WHEN 7 THEN CONCAT(Price,'  ') WHEN 8 THEN CONCAT(Price,'  ') WHEN 9 THEN CONCAT(Price,'  ') WHEN '' THEN CONCAT(Price,'  ') ELSE Price END) , (CASE LENGTH(Trigger_Price)  WHEN 1 THEN CONCAT(Trigger_Price,'  ')  WHEN 2 THEN CONCAT(Trigger_Price,'  ') WHEN 3 THEN CONCAT(Trigger_Price,'  ') WHEN 4 THEN CONCAT(Trigger_Price,'  ') WHEN 5 THEN CONCAT(Trigger_Price,'  ') WHEN 6 THEN CONCAT(Trigger_Price,'  ') WHEN 7 THEN CONCAT(Trigger_Price,'  ') WHEN 8 THEN CONCAT(Trigger_Price,'  ') WHEN 9 THEN CONCAT(Trigger_Price,'  ') WHEN '' THEN CONCAT(Trigger_Price,'  ') ELSE Trigger_Price END) , (CASE LENGTH(Quantity) WHEN 1 THEN CONCAT(Quantity,'  ')  WHEN 2 THEN CONCAT(Quantity,'  ') WHEN 3 THEN CONCAT(Quantity,'  ') WHEN 4 THEN CONCAT(Quantity,'  ') WHEN 5 THEN CONCAT(Quantity,'  ') WHEN 6 THEN CONCAT(Quantity,'  ') WHEN 7 THEN CONCAT(Quantity,'  ') WHEN 8 THEN CONCAT(Quantity,'  ')  WHEN '' THEN CONCAT(Quantity,'  ') ELSE Quantity  END) , (CASE LENGTH(DQ) WHEN 1 THEN CONCAT(DQ,'  ')  WHEN 2 THEN CONCAT(DQ,'  ') WHEN 3 THEN CONCAT(DQ,'  ') WHEN 4 THEN CONCAT(DQ,'  ') WHEN 5 THEN CONCAT(DQ,'  ') WHEN 6 THEN CONCAT(DQ,'  ') WHEN 7 THEN CONCAT(DQ,'  ') WHEN 8 THEN CONCAT(DQ,'  ')  WHEN '' THEN CONCAT(DQ,'  ') ELSE DQ  END) ,  (CASE LENGTH(Participant)WHEN 1 THEN CONCAT(Participant,'  ')  WHEN 2 THEN CONCAT(Participant,'  ') WHEN 3 THEN CONCAT(Participant,'  ') WHEN 4 THEN CONCAT(Participant,'  ') WHEN 5 THEN CONCAT(Participant,'  ') WHEN 6 THEN CONCAT(Participant,'  ') WHEN 7 THEN CONCAT(Participant,'  ') WHEN 8 THEN CONCAT(Participant,'  ') WHEN 9 THEN CONCAT(Participant,'  ')  WHEN 10 THEN CONCAT(Participant,'  ') WHEN 11 THEN CONCAT(Participant,'  ')  WHEN '' THEN CONCAT(Participant,'  ') ELSE Participant  END) ,  (CASE LENGTH(CLIENT_TYPE) WHEN 1 THEN CONCAT(CLIENT_TYPE,'  ')  WHEN '  ' THEN CONCAT(CLIENT_TYPE,'  ') ELSE CLIENT_TYPE END)   , (CASE LENGTH(NPT_CLIENT_ID)  WHEN 1 THEN CONCAT(NPT_CLIENT_ID,'  ')  WHEN 2 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 3 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 4 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 5 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 6 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 7 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 8 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN 9 THEN CONCAT(NPT_CLIENT_ID,'  ') WHEN '' THEN CONCAT(NPT_CLIENT_ID,'  ') ELSE NPT_CLIENT_ID END) , (CASE LENGTH(Other)  WHEN 1 THEN CONCAT(Other,'  ')  WHEN 2 THEN CONCAT(Other,'  ') WHEN 3 THEN CONCAT(Other,'  ') WHEN 4 THEN CONCAT(Other,'  ') WHEN 5 THEN CONCAT(Other,'  ') WHEN 6 THEN CONCAT(Other,'  ') WHEN 7 THEN CONCAT(Other,'  ') WHEN 8 THEN CONCAT(Other,'  ') WHEN 9 THEN CONCAT(Other,'  ') WHEN 10 THEN CONCAT(Other,'  ') WHEN 11 THEN CONCAT(Other,'  ') WHEN 12 THEN CONCAT(Other,'  ') WHEN 13 THEN CONCAT(Other,'  ') WHEN 14 THEN CONCAT(Other,'  ') WHEN 15 THEN CONCAT(Other,'  ') WHEN 16 THEN CONCAT(Other,'  ') WHEN 17 THEN CONCAT(Other,'  ') WHEN 18 THEN CONCAT(Other,'  ') WHEN 19 THEN CONCAT(Other,'  ') WHEN 20 THEN CONCAT(Other,'  ') WHEN 21 THEN CONCAT(Other,'  ') WHEN 22 THEN CONCAT(Other,'  ') WHEN 23 THEN CONCAT(Other,'  ') WHEN '' THEN CONCAT(Other,'  ') ELSE Other END) , (CASE LENGTH(COL) WHEN 1 THEN CONCAT(COL,'  ')       WHEN '  ' THEN CONCAT(COL,'  ') ELSE COL END)   , (CASE LENGTH(Order_Ref_NO) WHEN 1 THEN CONCAT(Order_Ref_NO,'  ')  WHEN 2 THEN CONCAT(Order_Ref_NO,'  ') WHEN 3 THEN CONCAT(Order_Ref_NO,'  ') WHEN 4 THEN CONCAT(Order_Ref_NO,'  ') WHEN 5 THEN CONCAT(Order_Ref_NO,'  ') WHEN 6 THEN CONCAT(Order_Ref_NO,'  ') WHEN 7 THEN CONCAT(Order_Ref_NO,'  ') WHEN 8 THEN CONCAT(Order_Ref_NO,'  ') WHEN 9 THEN CONCAT(Order_Ref_NO,'  ')  WHEN 10 THEN CONCAT(Order_Ref_NO,'  ') WHEN 11 THEN CONCAT(Order_Ref_NO,'  ') WHEN 12 THEN CONCAT(Order_Ref_NO,'  ') WHEN 13 THEN CONCAT(Order_Ref_NO,'  ') WHEN 14 THEN CONCAT(Order_Ref_NO,'  ') WHEN 15 THEN CONCAT(Order_Ref_NO,'  ') WHEN '' THEN CONCAT(Order_Ref_NO,'  ') ELSE Order_Ref_NO END) , (CASE  WHEN LINE_END='  ' THEN '  '       END) ) FROM (SELECT   1 AS Reference_No, 'O' AS Open_Close, 'U' AS Cover_Uncover,     1 AS Book_Type, 0 AS MIT_Type, (CASE  WHEN NPT_NET_QTY > 0 THEN 2  WHEN NPT_NET_QTY < 0 THEN 1 END) AS BUY_SELL, NPT_INSTRUMENT AS INSTRUMENT,  NPT_EXCH_SYMBOL AS SYMBOL, upper(date_format(date(NPT.NPT_EXPIRY_DATE),'%%d%%b%%Y')) AS Expiry, if (NPT_INSTRUMENT like 'FUT%','',NPT_STRIKE_PRICE) as NPT_STRIKE_PRICE, if (NPT_INSTRUMENT like 'FUT%','',NPT_OPTION_TYPE) as NPT_OPTION_TYPE, 1 AS Instruction, '' AS GTD_Days, '' AS Special_Term, '' AS MF_Qty, 'MKT' AS Price, '' AS Trigger_Price, ABS(NPT_NET_QTY) AS Quantity, '' AS DQ, EAM_BROKER_ID AS Participant, 2 AS CLIENT_TYPE, NPT_CLIENT_ID, '' as Other, '0' as COL, '' as Order_Ref_NO, '  ' as LINE_END FROM NET_POSITION_TABLE NPT,EXCH_ADMINISTRATION_MASTER EAM WHERE NPT_SEGMENT IN ('D','C')  AND NPT_NET_QTY <> 0  AND NPT_REF_ID <> '-1'  AND NPT_PROD_ID IN ('I','V','B')  and EAM_EXM_EXCH_ID = NPT_EXCH_ID  and EAM_SEGMENT = NPT_SEGMENT) A;");
	
	}
	logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
        logDebug2("sFileName1 = %s", sFileName1);
        logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);


        printf("sSelectQry = %s\n",sSelectQry);
        logDebug2("Going for Query");
        if (mysql_query(DBQury, sSelectQry) != SUCCESS)
        {
                sql_Error(DBQury);
                logSqlFatal("Error While Fetching the client details.");
                return FALSE;
        }


        logDebug2("After Query");
        Res = mysql_store_result(DBQury);
        iRow = mysql_num_rows(Res);
        if(iRow == 0)
        {

                mysql_free_result(Res);
                logDebug2("Zero rows selected");
        }
	else
        {
                logDebug2("Rows Selected %d",iRow);
                fpFile = fopen(sFileName1,"a");

                if (fpFile == NULL)
                {
                        logFatal("Not able to Open File in append mode");
                        exit(0);
                }
                else
                {
                        while((Row = mysql_fetch_row(Res)))
                        {
				logDebug2("Row Value From Query %s",Row[0]);
				fprintf(fpFile ,"%s\n",Row[0]);

                        }
                }
                mysql_free_result(Res);
                //fprintf(fpFile,"*");
                fclose(fpFile);
        }
        fConvToPwdPrtect(sFileName,sFileName1);


        logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
        pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
        pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
        pResp.IntRespHeader.iErrorId = 0;
        pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES;
        pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
        pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
        sprintf(pResp.sFilename,"%s.rrs",sTempFile);
        logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
        logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
        logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
        logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
        logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
        logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
        logDebug2("pResp.sFilename = %s", pResp.sFilename);

        iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);
	
	if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                return FALSE;
        }




        logTimestamp("Exit : NeatFileFormat");
}

BOOL BoltFileFormat (CHAR *RcvMsg)
{
        logTimestamp("Entry : BoltFileFormat");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        CHAR             sSeq[30];
        CHAR    sFileName [FILE_NAME_LEN];
        memset (sFileName,'\0',FILE_NAME_LEN);
        CHAR    sFileName1 [FILE_NAME_LEN];
        memset (sFileName1,'\0',FILE_NAME_LEN);
	
	memset (sSeq,'\0',30);
        CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];
        CHAR    sTempFile[FILE_NAME_LEN];
        memset (sTempFile,'\0',FILE_NAME_LEN);

        LONG32 iRow;
        FILE *fpFile;
	
	struct INT_CREATE_FILE_RES      pResp;

        struct INT_CREATE_FILE_REQ *pReq;
        pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
	
	logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
        logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
        logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
        logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
        logDebug2("pReq->IntReqHeader.iUserId = :%d:",pReq->IntReqHeader.iUserId);
        logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
        logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);
	logDebug2("pReq->iFileformat = :%d:",pReq->iFileformat);


        if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
        {
                sql_Error(DBQury);
                logSqlFatal("error in select Time.");
                return FALSE;
        }

        Res = mysql_store_result(DBQury);
        if((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Row[0] = :%s:",Row[0]);

                strncpy(sSeq,Row[0],strlen(Row[0]));
                logDebug2("Time is : %s", sSeq);
        }

        mysql_free_result(Res);
	memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
        if(pReq->IntReqHeader.iSeqNo == 2 && pReq->IntReqHeader.cSegment == EQUITY_SEGMENT)
        {
                sprintf(sFileName,"%s/%s%s",sRRPath,RR_BOLT_EQ_ORDERS,sSeq);
                sprintf(sTempFile,"%s%s",RR_BOLT_EQ_ORDERS,sSeq);
        	if(pReq->iFileformat == 1)//for csv format.
		{
			/****
                	sprintf(sSelectQry,"SELECT CONCAT_WS(',',IF((BUY_QTY < SELL_QTY), 'B', 'S'), ABS((BUY_QTY - SELL_QTY)), ABS((BUY_QTY - SELL_QTY)), SECURITY_ID, 0, EM.ENTITY_NSE_CODE, 'EOSESS', 'CLIENT', 'G', '$') AS BOLT_CSV FROM (SELECT CLIENT_ID, SECURITY_ID, EXCH_ID, SUM(BUY_QTY) AS BUY_QTY, SUM(BUY_VAL) AS BUY_VAL, SUM(SELL_QTY) AS SELL_QTY, SUM(SELL_VAL) AS SELL_VAL, EXCH_SEGMENT, PRODUCT, INT_REF_ID, CROSS_CUR_FLAG FROM NET_POSITION_EQ GROUP BY CLIENT_ID , SECURITY_ID , EXCH_ID , PRODUCT) AS NP JOIN ENTITY_MASTER EM WHERE CLIENT_ID = EM.ENTITY_CODE AND EXCH_ID = 'BSE' AND (BUY_QTY - SELL_QTY) <> 0;");
			***/
	
			sprintf(sSelectQry,"SELECT CONCAT_WS(',', IF((BUY_QTY < SELL_QTY), 'B', 'S'), ABS((BUY_QTY - SELL_QTY)), ABS((BUY_QTY - SELL_QTY)), BSE_SCRIP, 0, EM.ENTITY_NSE_CODE, 'EOSESS', 'CLIENT', 'G', '$') AS BOLT_CSV FROM (SELECT NPT_CLIENT_ID, NPT_SECURITY_ID, NPT_EXCH_ID, SUM(NPT_TOT_BUY_QTY) AS BUY_QTY, SUM(NPT_TOT_BUY_VAL) AS BUY_VAL, SUM(NPT_TOT_SELL_QTY) AS SELL_QTY, SUM(NPT_TOT_SELL_VAL) AS SELL_VAL, NPT_SEGMENT, NPT_PROD_ID, NPT_REF_ID, NPT_CROSS_CUR_FLAG, NPT_BSE_SCRIP AS BSE_SCRIP FROM NET_POSITION_TABLE GROUP BY NPT_CLIENT_ID , NPT_SECURITY_ID , NPT_EXCH_ID , NPT_PROD_ID) AS NP JOIN ENTITY_MASTER EM JOIN SEM_ACTIVE WHERE NPT_SECURITY_ID = SM_SCRIP_CODE AND NPT_SEGMENT = SM_SEGMENT AND NPT_EXCH_ID = SM_EXCHANGE AND NPT_CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0 AND NP.NPT_PROD_ID IN ('I' , 'V', 'B') AND NPT_SEGMENT = 'E';");
	
		}
		else
		{//for txt format
	
			/*****
                	sprintf(sSelectQry,"SELECT CONCAT_WS('|',IF((BUY_QTY < SELL_QTY), 'B', 'S'), ABS((BUY_QTY - SELL_QTY)), ABS((BUY_QTY - SELL_QTY)), SECURITY_ID, 0, EM.ENTITY_NSE_CODE, 'EOSESS', 'CLIENT', 'G','') AS BOLT_PIPE FROM (select CLIENT_ID, SECURITY_ID, EXCH_ID, sum(BUY_QTY) as BUY_QTY, sum(BUY_VAL) as BUY_VAL, sum(SELL_QTY) as SELL_QTY, sum(SELL_VAL) as SELL_VAL, EXCH_SEGMENT, PRODUCT, INT_REF_ID, CROSS_CUR_FLAG from NET_POSITION_EQ group by CLIENT_ID,SECURITY_ID,EXCH_ID,PRODUCT) as NP JOIN ENTITY_MASTER EM WHERE CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0 AND EXCH_ID = 'BSE';");
			***/
	
			sprintf(sSelectQry,"SELECT CONCAT_WS(',', IF((BUY_QTY < SELL_QTY), 'B', 'S'), ABS((BUY_QTY - SELL_QTY)), ABS((BUY_QTY - SELL_QTY)), BSE_SCRIP, 0, EM.ENTITY_NSE_CODE, 'EOSESS', 'CLIENT', 'G', '$') AS BOLT_CSV FROM (SELECT NPT_CLIENT_ID, NPT_SECURITY_ID, NPT_EXCH_ID, SUM(NPT_TOT_BUY_QTY) AS BUY_QTY, SUM(NPT_TOT_BUY_VAL) AS BUY_VAL, SUM(NPT_TOT_SELL_QTY) AS SELL_QTY, SUM(NPT_TOT_SELL_VAL) AS SELL_VAL, NPT_SEGMENT, NPT_PROD_ID, NPT_REF_ID, NPT_CROSS_CUR_FLAG, NPT_BSE_SCRIP AS BSE_SCRIP FROM NET_POSITION_TABLE GROUP BY NPT_CLIENT_ID , NPT_SECURITY_ID , NPT_EXCH_ID , NPT_PROD_ID) AS NP JOIN ENTITY_MASTER EM JOIN SEM_ACTIVE WHERE NPT_SECURITY_ID = SM_SCRIP_CODE AND NPT_SEGMENT = SM_SEGMENT AND NPT_EXCH_ID = SM_EXCHANGE AND NPT_CLIENT_ID = EM.ENTITY_CODE AND (BUY_QTY - SELL_QTY) <> 0 AND NP.NPT_PROD_ID IN ('I' , 'V', 'B') AND NPT_SEGMENT = 'E';");	
		
		}
        }
        
        logDebug2("sFileName = %s", sFileName);
	sprintf(sFileName1,"%s.csv",sFileName);
        logDebug2("sFileName1 = %s", sFileName1);
        logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);


        printf("sSelectQry = %s\n",sSelectQry);
        logDebug2("Going for Query");
        if (mysql_query(DBQury, sSelectQry) != SUCCESS)
        {
                sql_Error(DBQury);
                logSqlFatal("Error While Fetching the client details.");
                return FALSE;
        }


        logDebug2("After Query");
        Res = mysql_store_result(DBQury);
        iRow = mysql_num_rows(Res);
        if(iRow == 0)
        {

                mysql_free_result(Res);
                logDebug2("Zero rows selected");
        }
	else
        {
                logDebug2("Rows Selected %d",iRow);
                fpFile = fopen(sFileName1,"a");

                if (fpFile == NULL)
                {
                        logFatal("Not able to Open File in append mode");
                        exit(0);
                }
                else
                {
                        while((Row = mysql_fetch_row(Res)))
                        {
				fprintf(fpFile ,"%s\n",Row[0]);

                        }
                }
                mysql_free_result(Res);
                //fprintf(fpFile,"*");
                fclose(fpFile);
        }
        fConvToPwdPrtect(sFileName,sFileName1);


        logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
        pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
        pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
        pResp.IntRespHeader.iErrorId = 0;
        pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES;
        pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
        pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
        sprintf(pResp.sFilename,"%s.rrs",sTempFile);
        logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
        logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
        logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
        logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
        logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
        logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
        logDebug2("pResp.sFilename = %s", pResp.sFilename);

        iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);
	
	 if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                return FALSE;
        }




        logTimestamp("Exit : BoltFileFormat");
}

BOOL CreateNowFile()
{
        logTimestamp("Entry : CreateNowFile");
        SHORT   iOption=0;
        struct INT_CREATE_FILE_REQ pReq;
        memset(&pReq,'\0' ,sizeof(struct INT_CREATE_FILE_REQ));
        logInfo("Select Option");
        logInfo("1. CASH OPEN ORDER FILE");
        logInfo("2. CASH OPEN POSITION FILE");
        logInfo("3. FO OPEN ORDER FILE");
        logInfo("4. FO OPEN POSITION FILE");
        scanf("%d",&iOption);
        if(iOption < 1 && iOption >4)
        {
                logInfo("Invalid Option");
                exit(ERROR);
        }

        if(iOption == 1 || iOption == 2)
        {
                pReq.IntReqHeader.cSegment = EQUITY_SEGMENT;
        }
        else
        {
                pReq.IntReqHeader.cSegment = DERIVATIVE_SEGMENT;
        }

	 pReq.IntReqHeader.iSeqNo = iOption;
        logDebug2("pReq.IntReqHeader.iSeqNo = :%d:",pReq.IntReqHeader.iSeqNo);
        logDebug2("pReq.IntReqHeader.iMsgLength = :%d:",pReq.IntReqHeader.iMsgLength);
        logDebug2("pReq.IntReqHeader.iMsgCode = :%d:",pReq.IntReqHeader.iMsgCode);
        logDebug2("pReq.IntReqHeader.sExcgId = :%s:",pReq.IntReqHeader.sExcgId);
        logDebug2("pReq.IntReqHeader.iUserId = :%d:",pReq.IntReqHeader.iUserId);
        logDebug2("pReq.IntReqHeader.cSource = :%c:",pReq.IntReqHeader.cSource);
        logDebug2("pReq.IntReqHeader.cSegment = :%c:",pReq.IntReqHeader.cSegment);
        NowFileFormat((CHAR *)&pReq);
        logTimestamp("Exit : CreateNowFile");
}

BOOL NowFileFormat (CHAR *RcvMsg)
{
        logTimestamp("Entry : NowFileFormat");
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        CHAR             sSeq[30];
        CHAR    sFileName [FILE_NAME_LEN];
        memset (sFileName,'\0',FILE_NAME_LEN);
        CHAR    sFileName1 [FILE_NAME_LEN];
        memset (sFileName1,'\0',FILE_NAME_LEN);
        memset (sSeq,'\0',30);
        CHAR    sSelectQry [DOUBLE_MAX_QUERY_SIZE];

        LONG32 iRow;
        FILE *fpFile;
        struct INT_CREATE_FILE_RES      pResp;

        struct INT_CREATE_FILE_REQ *pReq;
        pReq =(struct INT_CREATE_FILE_REQ *)RcvMsg ;
        logDebug2("pReq->IntReqHeader.iSeqNo = :%d:",pReq->IntReqHeader.iSeqNo);
        logDebug2("pReq->IntReqHeader.iMsgLength = :%d:",pReq->IntReqHeader.iMsgLength);
        logDebug2("pReq->IntReqHeader.iMsgCode = :%d:",pReq->IntReqHeader.iMsgCode);
        logDebug2("pReq->IntReqHeader.sExcgId = :%s:",pReq->IntReqHeader.sExcgId);
        logDebug2("pReq->IntReqHeader.iUserId = :%d:",pReq->IntReqHeader.iUserId);
        logDebug2("pReq->IntReqHeader.cSource = :%c:",pReq->IntReqHeader.cSource);
        logDebug2("pReq->IntReqHeader.cSegment = :%c:",pReq->IntReqHeader.cSegment);


        if (mysql_query(DBQury, "SELECT SUBSTR(CONCAT(Date_format(now(),'%Y%m%d%H%i%S')),3,16);") != SUCCESS)
        {
                sql_Error(DBQury);
                logSqlFatal("error in select Time.");
                return FALSE;
        }

	 Res = mysql_store_result(DBQury);
        if((Row = mysql_fetch_row(Res)))
        {
                logDebug2("Row[0] = :%s:",Row[0]);

                strncpy(sSeq,Row[0],strlen(Row[0]));
                logDebug2("Time is : %s", sSeq);
        }

        mysql_free_result(Res);
        memset(sSelectQry,'\0',DOUBLE_MAX_QUERY_SIZE);
        sprintf(sFileName,"%s/%s%s",sRRPath,RR_NOW_POSITION,sSeq);
        sprintf(sSelectQry,"SELECT CONCAT_WS(',',SEGMENT,INSTRUMENT_NAME,SYMBOL,OPTION_TYPE,STRIKE,EXPIRY,PRICE,QTY,TRIG_PRICE,BUY_SELL,MARKET_TYPE,MARKET_PROT,PRO_CLI,P_TYPE,VILIDITY,ACCOUNT_ID,VALIDITY_TIME,PARTICIPANT_ID,DISC_QTY,VALIDITY_DATE) FROM NOW_OPEN_POSITION ;");
        logDebug2("sFileName = %s", sFileName);
        sprintf(sFileName1,"%s.csv",sFileName);
        logDebug2("sFileName1 = %s", sFileName1);
        logDebug2("pReq->sDateTo = :%s:",pReq->sDateTo);


        printf("sSelectQry = %s\n",sSelectQry);
        logDebug2("Going for Query");
        if (mysql_query(DBQury, sSelectQry) != SUCCESS)
        {
                sql_Error(DBQury);
                logSqlFatal("Error While Fetching the client details.");
                return FALSE;
        }


        logDebug2("After Query");
        Res = mysql_store_result(DBQury);
        iRow = mysql_num_rows(Res);
	if(iRow == 0)
        {

                mysql_free_result(Res);
                logDebug2("Zero rows selected");
        }
        else
        {
                logDebug2("Rows Selected %d",iRow);
                fpFile = fopen(sFileName1,"a");

                if (fpFile == NULL)
                {
                        logFatal("Not able to Open File in append mode");
                        exit(0);
                }
                else
                {
                        while((Row = mysql_fetch_row(Res)))
                        {
                                fprintf(fpFile ,"%s\n",Row[0]);

                        }
                }
                mysql_free_result(Res);
                //fprintf(fpFile,"*");
                fclose(fpFile);
        }
        fConvToPwdPrtect(sFileName,sFileName1);


        logDebug2(" sFileName after fConvToPwdPrtect = %s",sFileName);
        pResp.IntRespHeader.iSeqNo = pReq->IntReqHeader.iSeqNo ;
        pResp.IntRespHeader.iMsgLength = sizeof(struct INT_CREATE_FILE_RES);
        pResp.IntRespHeader.iErrorId = 0;
        pResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_FILE_RES;
        pResp.IntRespHeader.iUserId = pReq->IntReqHeader.iUserId;
        pResp.IntRespHeader.cSource = pReq->IntReqHeader.cSource;
        sprintf(pResp.sFilename,"%s%s.rrs",RR_NOW_POSITION,sSeq);
        logDebug2("pResp.IntRespHeader.iSeqNo = %d", pResp.IntRespHeader.iSeqNo);
        logDebug2("pResp.IntRespHeader.iMsgLength = %d", pResp.IntRespHeader.iMsgLength);
        logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
	logDebug2("pResp.IntRespHeader.iErrorId = %d", pResp.IntRespHeader.iErrorId);
        logDebug2("pResp.IntRespHeader.iMsgCode= %d", pResp.IntRespHeader.iMsgCode);
        logDebug2("pResp.IntRespHeader.iUserId= %llu", pResp.IntRespHeader.iUserId);
        logDebug2("pResp.IntRespHeader.cSource= %c", pResp.IntRespHeader.cSource);
        logDebug2("pResp.sFilename = %s", pResp.sFilename);

        iRelayID = find_admin_adapter(pReq->IntReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }


        if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResp,sizeof(struct INT_CREATE_FILE_RES) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                return FALSE;
        }




        logTimestamp("Exit : NowFileFormat");
}

BOOL    fViewConvToDelDtl(CHAR *RcvMsg)
{
        logTimestamp("Entry : [fViewConvToDelDtl]");
        struct VIEW_CONV_TO_DEL_DTL_REQ         *pReqConvToDelDtl;
        struct VIEW_CONV_TO_DEL_DTL_RES         pResConvToDelDtl;
        struct  VIEW_COMMON_HDR_RESP            pOrderCTDHdrResp;

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;
        CHAR            sSubConvQry     [QUERY_SIZE];
        CHAR            sSelQry         [DOUBLE_MAX_QUERY_SIZE];
        CHAR            sWhere_Clause   [QUERY_SIZE];
        memset(sWhere_Clause,'\0',QUERY_SIZE);

        pReqConvToDelDtl = (struct VIEW_CONV_TO_DEL_DTL_REQ *)RcvMsg;

        BOOL    iChkBrcnh = FALSE;
        CHAR    sBrchId[BRANCH_ID_LEN];
        memset(sBrchId,'\0',BRANCH_ID_LEN);

        CHAR    sBrchClaus[QUERY_SIZE];
        memset(sBrchClaus,'\0',QUERY_SIZE);
        iChkBrcnh = fChckAdminContrlr(pReqConvToDelDtl->sEntityID,&sBrchId);

        if(iChkBrcnh == TRUE)
        {
                sprintf(sBrchClaus ,"AND RCCD_CLIENT_ID in (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) and E.ENTITY_TYPE = \'%c\' )",sBrchId,CLIENT_TYPE);
        }
        else
        {
                sprintf(sBrchClaus ," ");
        }

        logDebug2(" sBrchClaus :%s:",sBrchClaus);

  	if(strcmp(pReqConvToDelDtl->sClientID,SELECT_ALL))
        {
                memset(sSubConvQry,'\0',QUERY_SIZE);
                sprintf(sSubConvQry," AND RCCD_CLIENT_ID LIKE \"%s\"",pReqConvToDelDtl->sClientID);
                logDebug2("sSubConvQry= %s",sSubConvQry);
                strcat(sWhere_Clause,sSubConvQry);
                logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
        }
        if(strcmp(pReqConvToDelDtl->ReqHeader.sExcgId,SELECT_ALL))
        {
                memset(sSubConvQry,'\0',QUERY_SIZE);
                sprintf(sSubConvQry," AND RCCD_EXCHANGE = \"%s\"",pReqConvToDelDtl->ReqHeader.sExcgId);
                logDebug2("sSubConvQry = %s",sSubConvQry);
                strcat(sWhere_Clause,sSubConvQry);
                logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
        }
        if(pReqConvToDelDtl->ReqHeader.cSegment != SEL_ALL)
        {
                memset(sSubConvQry,'\0',QUERY_SIZE);
                sprintf(sSubConvQry," AND RCCD_SEGMENT = \'%c\'",pReqConvToDelDtl->ReqHeader.cSegment);
                logDebug2("sSubConvQry = %s",sSubConvQry);
                strcat(sWhere_Clause,sSubConvQry);
                logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
        }
        logDebug2("pReqConvToDelDtl->sSelDatetime  :%s:",pReqConvToDelDtl->sSelDatetime);
	if(!strcmp(pReqConvToDelDtl->sSelDatetime,""))
        {
                memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
                sprintf(sSelQry,"SELECT CNVT_ID ,RCCD_CLIENT_ID ,RCCD_EXCHANGE ,RCCD_SCRIP_CODE ,RCCD_QTY ,RCCD_PRODUCT_SOURCE ,RCCD_PRODUCT_DESTINATION ,RCCD_SIDE ,\
                        RCCD_CONVT_TIME ,RCCD_CONVT_PRICE ,RCCD_SEGMENT ,RCCD_SYMBOL ,RCCD_INSTRUMENT ,IFNULL(RCCD_EXPIRY_DATE,NOW())  ,SOURCE_TYPE ,\
                        ENTITY_ID ,REMARK FROM RMS_CLIENT_CONVT_TO_DEL_REPORT  WHERE 1=1 %s %s ",sWhere_Clause,sBrchClaus);
        }
        else
        {
                memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
                sprintf(sSelQry,"SELECT CNVT_ID ,RCCD_CLIENT_ID ,RCCD_EXCHANGE ,RCCD_SCRIP_CODE ,RCCD_QTY ,RCCD_PRODUCT_SOURCE ,RCCD_PRODUCT_DESTINATION ,RCCD_SIDE ,\
                        RCCD_CONVT_TIME ,RCCD_CONVT_PRICE ,RCCD_SEGMENT ,RCCD_SYMBOL ,RCCD_INSTRUMENT ,IFNULL(RCCD_EXPIRY_DATE,NOW())  ,SOURCE_TYPE ,\
                        ENTITY_ID ,REMARK FROM RMS_CLIENT_CONVT_TO_DEL_REPORT_ARCHIVE  WHERE 1=1 and date(RCCD_CONVT_TIME)=str_to_date(\"%s\",'%%d/%%m/%%Y') %s %s ",pReqConvToDelDtl->sSelDatetime,sWhere_Clause,sBrchClaus);
        }

        logDebug2("sSelQry      :%s:",sSelQry);

        if(mysql_query(DBQury,sSelQry) != SUCCESS)
        {
                logSqlFatal("Error in sConcToDelDtl.");
                sql_Error(DBQury);
                return FALSE;
        }
        Res = mysql_store_result(DBQury);
        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);
	pOrderCTDHdrResp.IntRespHeader.iSeqNo = 0;
        pOrderCTDHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pOrderCTDHdrResp.IntRespHeader.iErrorId = 0;
        pOrderCTDHdrResp.IntRespHeader.iMsgCode = TC_INT_CONV_TO_DEL_HDR_RES;
        pOrderCTDHdrResp.IntRespHeader.iUserId = pReqConvToDelDtl->ReqHeader.iUserId;
        pOrderCTDHdrResp.IntRespHeader.cSource = pReqConvToDelDtl->ReqHeader.cSource ;
        pOrderCTDHdrResp.cMsgType = 'H';
        pOrderCTDHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pReqConvToDelDtl.IntRespHeader.iMsgLength = %d",pOrderCTDHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pReqConvToDelDtl.IntRespHeader.iMsgCode = %d",pOrderCTDHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pReqConvToDelDtl.IntRespHeader.iUserId = %llu",pOrderCTDHdrResp.IntRespHeader.iUserId);
        logDebug2("pReqConvToDelDtl.IntRespHeader.cSource = %c",pOrderCTDHdrResp.IntRespHeader.cSource);

        iRelayID = find_admin_adapter(pOrderCTDHdrResp.IntRespHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iTrdRtrToRel,(CHAR *)&pOrderCTDHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iTrdRtrToRel);
                return FALSE;
        }
		
	 for(i=0;i<iNoOfPkt;i++)
        {
                logDebug2("No of Pkt (i) = %d",i);
                memset(&pResConvToDelDtl,'\0',sizeof(struct VIEW_CONV_TO_DEL_DTL_RES));
                pResConvToDelDtl.IntRespHeader.iSeqNo = 0;
                pResConvToDelDtl.IntRespHeader.iMsgLength = sizeof(struct VIEW_CONV_TO_DEL_DTL_RES);
                pResConvToDelDtl.IntRespHeader.iMsgCode = TC_INT_CONV_TO_DEL_RES;
                pResConvToDelDtl.IntRespHeader.iErrorId = 0;
                pResConvToDelDtl.IntRespHeader.iUserId = pReqConvToDelDtl->ReqHeader.iUserId;
                pResConvToDelDtl.IntRespHeader.cSource = pReqConvToDelDtl->ReqHeader.cSource ;

                if(iTempNoOfRec <= 1)
                {
                        pResConvToDelDtl.cMsgType = 'T';
                }
                else
                {
                        pResConvToDelDtl.cMsgType = 'D';
                }


                for(j=0;j<5;j++)
                {
                        logDebug2("****** j = %d ******",j);

                        if((Row = mysql_fetch_row(Res)))
                        {
                                 pResConvToDelDtl.subDtlpos[j].iSerialNo     = atoi(Row[0]);
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sClientId,Row[1],CLIENT_ID_LEN) ;
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sExcgId,Row[2],EXCHANGE_LEN)  ;
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sSecurityID,Row[3],SECURITY_ID_LEN) ;
                                 pResConvToDelDtl.subDtlpos[j].fQty          = atof(Row[4]);
                                 pResConvToDelDtl.subDtlpos[j].cProductFrom  = Row[5][0];
                                 pResConvToDelDtl.subDtlpos[j].cProductTo    = Row[6][0];
                                 pResConvToDelDtl.subDtlpos[j].cBuySellInd   = Row[7][0];
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sConvDatetime,Row[8],DATE_TIME_LEN);
                                 pResConvToDelDtl.subDtlpos[j].fConvPrice    = atof(Row[9]);
                                 pResConvToDelDtl.subDtlpos[j].cSegment      = Row[10][0];
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sSymbol,Row[11],DB_SYM_LEN);
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sInstruName,Row[12],INSTRUMENT_LEN);
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sExpiry,Row[13],DATE_TIME_LEN);
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sSourceFlg,Row[14],SOURCE_FLG_LEN);
				 strncpy(pResConvToDelDtl.subDtlpos[j].sEntityId,Row[15],ENTITY_ID_LEN);
                                 strncpy(pResConvToDelDtl.subDtlpos[j].sReasonDesc,Row[16],DB_REASON_DESC_LEN);
                        }
                }
                if(( WriteMsgQ(iTrdRtrToRel,(CHAR *)&pResConvToDelDtl,sizeof(struct VIEW_CONV_TO_DEL_DTL_RES) ,iRelayID ) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iTrdRtrToRel);
                        return FALSE;
                }
                       iTempNoOfRec--;

        }
        logTimestamp("Exit : ");
        return TRUE;

}




BOOL fLoadEnv()
{
        logTimestamp("Entry : fLoadEnv");
        if(getenv("RRFILE_PATH")==NULL)
        {
                logFatal("Error : Environment variables missing : RRFILE_PATH");
                exit(ERROR);
        }
        else
        {
                strcpy ( sRRPath , getenv("RRFILE_PATH"));
                logDebug2("sRRPath :%s:",sRRPath);
        }
        logTimestamp("Exit : fLoadEnv");
        return TRUE;
}

