//#include "STWRelay.h"
#include "IPCS.h"
#include "DWSAdapter.h"
#include <errno.h>

pthread_once_t             OnceInit = PTHREAD_ONCE_INIT;
pthread_attr_t             ThreadAttr;
pthread_t                  OPtid;
pthread_mutex_t            UserSocketTableLock;
pthread_mutex_t			   ProcessTableLock;
pthread_mutex_t            ReadThreadLock;
pthread_mutex_t            WriteThreadLock;
pthread_mutex_t            WriteDloadThreadLock;
pthread_mutex_t            WriteIORThreadLock;
pthread_mutex_t            ActiveSocketLock;
pthread_mutex_t            DummyPipeLock;
pthread_cond_t             MaxWriteThreadCondVar;
pthread_cond_t             MaxReadThreadCondVar;
pthread_cond_t             MaxWriteDloadThreadCondVar;
pthread_cond_t			   MaxWriteIORThreadCondVar;
pthread_mutex_t            SendMutexSeq;


LONG32                        DummyPipe[2];
LONG32                        NoOfReadThreads = 0;
LONG32                        NoOfWriteThreads = 0;
LONG32                        NoOfWriteDloadThreads = 0;
LONG32						  NoOfWriteIORThreads = 0;
LONG32                        MasterSocket ;
/********LONG32						  DloadToSTWRelQ;
  LONG32                        RelDirToSTWRelQ ;
  LONG32                        RelDirToSTWRel_IORQ ;
  LONG32                        DWSRelayToMapperQ ;
  LONG32                        STWRelToDloadQ ;
  LONG32                        STWRelToQueryQ ;
  LONG32                        STWRelToBcastQueryQ ;
 ************/
LONG32                        iRevMapToDWSRel ;
LONG32                        iDWSRelayToMapperQ ;
LONG32                        iRelToOrdRtr ;
LONG32                        iRelToQuery ;


struct                     USER_SOCKET_LOOKUP UserSocketTable[ MAX_NO_OF_USER_SOCKETS ];
struct                     PROCESS_LOOKUP ProcessTable[ MAX_NO_OF_PROCESS ];

fd_set	ActiveSocketSet ;
sigset_t	SignalSet ;

#define MAX_NO_OF_USER_SOCKETS 1000

LONG32		RelayPort;
LONG32		RelayId;
LONG32		dMaxUser;


/*

///////////////////////////////////////////////////////////////////////////
//								Function Declaration's.
//////////////////////////////////////////////////////////////////////////

 */

void InsertProcessTable		(pid_t ProcessId, LONG32 RelayPort, LONG32 RelayId);
void CleanSocketResources	(LONG32 Index);
void Str_Trim(CHAR *String);
void SignalHandlerSigTermParent (int dummy);


LONG32 main(LONG32 argc , char **argv)
{

	pthread_t                  ReadTid;
	pthread_t                  WriteTid;
	pthread_t                  WriteDloadTid;
	pthread_t                  WriteIORTid;



	LONG32			Index , Count ,i;
	LONG32			WriteFlag,WriteIORFlag,WriteDloadFlag;
	LONG32			iRetval=0,Signal=0,Status=0;
	pid_t			ForkInd = 1;
	LONG32			OrderProcessorPort;
	LONG32			TempRelayPort;
	LONG32			RstrtFlg = FALSE;
	CHAR			DummyUser[USER_ID_LEN]="DummyUser";
	CHAR            DummyClientId[CLIENT_ID_LEN]="DummyClientId";/*****  *******/
	pid_t 			ProcessId=0;
	LONG32			iInputRelayId=0;
	CHAR			sMAXUSER[10];

	setvbuf(stdout,NULL,_IONBF,0);

	if(argc < 4)
	{
		printf("\n Usage: STWSRelay OrderProcessorPort RelayPort ");
		exit(1);
	}



	OrderProcessorPort = atoi ( argv[1]);
	if(OrderProcessorPort <= 0)
	{	
		printf("\n Wrong Relay main Port ");
		exit(1);
	}



	RelayPort = atoi (argv[2]);	
	if( RelayPort <=0 )
	{
		printf("\n Wrong Relay Port ");
		exit(1);
	}
	else
	{
		TempRelayPort = RelayPort;
	}


	iInputRelayId = atoi (argv[3]);	
	if( iInputRelayId <0 )
	{
		printf("\n Wrong iInputRelayId ");
		exit(1);
	}
	else
	{
		printf("\n iInputRelayId is :%d:",iInputRelayId);
	}

	signal(SIGHUP,SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	sigemptyset(&SignalSet);
	sigaddset(&SignalSet,SIGTERM);
	sigaddset(&SignalSet,SIGCHLD);
	sigaddset(&SignalSet,SIGSEGV);
	sigprocmask(SIG_BLOCK,&SignalSet,NULL);



	InitProcessTable();
	AccessUsrRlyShm(DummyUser,INIT); /*****  *******/
	pthread_once (&OnceInit,init_routine);

	for (i=0 ; i < MAX_NO_OF_PROCESS && ForkInd != 0 ; i++)
	{
		RelayPort = TempRelayPort + i;
		RelayId = iInputRelayId + 1;


		ForkInd = fork ( );
		if ( ForkInd != 0)
		{
			/*

			 * Since we are in the parents...lets add the details of the child in the ProcessTable.

			 */

			InsertProcessTable (ForkInd ,RelayPort,RelayId);
			usleep(500);
		}
		else
		{
			/* CHILD PROCESS */

			/*	printf("\n RelayId got in fork is %d", RelayId);*/

			break;

		}
		iInputRelayId++;
	}

	if (ForkInd != 0)                               /*** PARENT PROCESS ***/
	{
		sigprocmask(SIG_UNBLOCK,&SignalSet,NULL);
		signal(SIGTERM,SignalHandlerSigTermParent);
		signal(SIGCHLD,SignalHandlerSigChldParent);


		for(;;)
		{
			sleep(3);
			for ( i=0; i < MAX_NO_OF_PROCESS  && ForkInd != 0 ; i++ )
			{
				if ( ProcessTable[i].ProcessId == RESTART )
				{
					sleep (3);
					sigprocmask(SIG_BLOCK,&SignalSet ,NULL);

					ForkInd = fork ();
					if( ForkInd != 0)
					{
						RelayPort = ProcessTable[i].RelayPort;
						RelayId   = ProcessTable[i].RelayId ;
						ProcessTable[i].ProcessId = ForkInd;
					}

					sigprocmask(SIG_UNBLOCK,&SignalSet ,NULL);
					signal(SIGTERM,SignalHandlerSigTermParent);
					signal(SIGCHLD,SignalHandlerSigChldParent);
				}
			}
			if ( ForkInd == 0 )
			{
				printf("\n New Fork Process Started ");
				break;
			}

		}


	}



	printf("\n UNUSED is %d:",UNUSED);	

	strcpy(sMAXUSER,getenv("LICENCE_DWS"));

	printf("\n sMAXUSER :%s:",sMAXUSER)	;

	decryptlicences(sMAXUSER,0xFACA);

	printf("\n sMAXUSER :%s:",sMAXUSER)	;

	dMaxUser = atoi(sMAXUSER);
	printf("\n dMaxUser :%d:",dMaxUser)	;



	if( ( iDWSRelayToMapperQ = OpenMsgQ( (RelToDWSMap))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	printf("\n iDWSRelayToMapperQ created sucesfully wid Qid :%d:",iDWSRelayToMapperQ);

	if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	printf("\n iRelToOrdRtr created sucesfully wid Qid :%d:",iRelToOrdRtr);


	if( ( iRelToQuery = OpenMsgQ( (RelToQuery))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	printf("\n iRelToQuery queue opened sucessfully with queuue id :%d:",iRelToQuery);




	if( (iRevMapToDWSRel= OpenMsgQ(RevMapToDWSRel)) == ERROR) /* */
		//	if( (iRevMapToDWSRel= OpenMsgQ(TrdRtrToRel)) == ERROR)
	{
		perror("Open DirToSTWRelQ :");
		exit( 1 );
	}

	printf("\n iRevMapToDWSRel :%d:",iRevMapToDWSRel);


	/**********
	  if((RelDirToSTWRel_IORQ = OpenMsgQ( DirToSTWRelIORsp ))== ERROR)
	  {
	  printf("\n Error in Opening Queue  RelayDIrToRelayIntOrderRespQ ");
	  exit(1);
	  }



	  if( (DloadToSTWRelQ = OpenMsgQ(DloadToSTWRel)) == ERROR)
	  {
	  perror("Open DloadDirToRelQ :");
	  exit( 1 );
	  }

	 ***********/

	if( pipe(DummyPipe) != 0 )
	{
		perror("Error in pipe creation");
		exit( 1);
	}





	pthread_create(&ReadTid, NULL, ReadThread, NULL);

	WriteFlag = WRITE_THREAD;

	pthread_create(&WriteTid, NULL, WriteThread, &WriteFlag);

	WriteIORFlag = WRITE_IOR_THREAD;

	pthread_create(&WriteIORTid, NULL, WriteThread, &WriteIORFlag);

	WriteDloadFlag = WRITE_DLOAD_THREAD;

	pthread_create(&WriteDloadTid, NULL, WriteThread, &WriteDloadFlag);





	SignalHandler(&RelayId,SignalSet);
	printf("\nRelayId:: %d, Terminating threads now...",RelayId);

	pthread_cancel(ReadTid);
	pthread_cancel(WriteTid);
	pthread_cancel(WriteIORTid);
	pthread_cancel(WriteDloadTid);



	pthread_join(ReadTid,NULL);
	pthread_join(WriteTid,NULL);
	pthread_join(WriteIORTid,NULL);
	pthread_join(WriteDloadTid,NULL);

	printf("\nRelayId:: %d, Successfully joined on all threads\n",RelayId);

	exit(1);
}


/*
//////////////////////////////////////////////////////////////////////////////////////

// This function initializes the process table request.

//////////////////////////////////////////////////////////////////////////////////////
 */

void InitProcessTable()

{

	LONG32 Count;
	for(Count =0; Count< MAX_NO_OF_PROCESS ; Count++)
	{

		ProcessTable [Count].RelayId = UNUSED;
		ProcessTable [Count].ProcessId = UNUSED;
		ProcessTable [Count].RelayPort = UNUSED;
		ProcessTable [Count].NoOfUsers = 0;
	}

}


/*
//////////////////////////////////////////////////////////////////////////////////////

// This function initializes the user socket table request.

//////////////////////////////////////////////////////////////////////////////////////
 */

void InitUserSocketTable()
{

	LONG32 Count;

	for(Count = 0 ;Count < MAX_NO_OF_USER_SOCKETS;Count++)
	{

		memset(UserSocketTable[Count].User,'\0',USER_ID_LEN);
		memset(UserSocketTable[Count].ClientId,'\0',CLIENT_ID_LEN); /*****  *******/
		UserSocketTable[Count].Socket = UNUSED ;
		if((pthread_mutex_init(&UserSocketTable[Count].UserSocketLock,NULL)) !=0)
		{
			printf("\n RelayId %d: Error in initializing UserSocketTable[%d]",RelayId,Count);
			exit(1);
		}
	}

	for(Count = 0 ;Count < MAX_NO_OF_USER_SOCKETS;Count++)
	{
		/*	printf("\n Uid=[%s], Sfd =[%d],Client=[%s],mutex = [%d]",UserSocketTable[Count].User,UserSocketTable[Count].Socket,UserSocketTable[Count].ClientId,UserSocketTable[Count].UserSocketLock);*/
	}
}



/*
///////////////////////////////////////////////////////////////////////////////////////

// This function initializes mutexes to be used. This function will only be called once

// when the program starts.

///////////////////////////////////////////////////////////////////////////////////////
 */

void init_routine()
{

	LONG32 i;


	printf("\nInit_routine: Intializing Resources...");

	if((pthread_mutex_init(&UserSocketTableLock,NULL)) !=0)
	{
		printf("\n Error in initializing UserSocketTableLock");
		exit(1);
	}


	if((pthread_mutex_init(&ProcessTableLock,NULL)) !=0)
	{
		printf("\n Error in initializing ProcessTableLock");
		exit(1);
	}



	if((pthread_mutex_init(&ReadThreadLock,NULL)) !=0)
	{
		printf("\n Error in initializing ReadThreadLock");
		exit(1);
	}



	if((pthread_mutex_init(&WriteThreadLock,NULL)) !=0)
	{
		printf("\n Error in initializing WriteThreadLock");
		exit(1);
	}



	if((pthread_mutex_init(&WriteDloadThreadLock,NULL)) !=0)
	{
		printf("\n Error in initializing WriteDloadThreadLock");
		exit(1);
	}



	if((pthread_mutex_init(&WriteIORThreadLock,NULL)) !=0)
	{
		printf("\n Error in initializing WriteIORThreadLock");
		exit(1);
	}



	if((pthread_mutex_init(&ActiveSocketLock,NULL)) !=0)
	{
		printf("\n Error in initializing ActiveSocketLock");
		exit(1);
	}



	if((pthread_mutex_init(&DummyPipeLock,NULL)) !=0)
	{
		printf("\n Error in initializing DummyPipeLock");
		exit(1);
	}





	if((pthread_attr_init(&ThreadAttr))!= 0 )
	{	
		printf("\n Error in initializing ThreadAttr");
		exit(1);
	}





	if((pthread_attr_setdetachstate(&ThreadAttr,PTHREAD_CREATE_DETACHED))!=0)
	{
		printf("\n Error is setting the detachstate for ThreadAttr");
		exit(1);
	}



	if( pipe(DummyPipe) != 0 )
	{

		perror("Error in pipe creation");
		exit( 1);
	}

	if(  pthread_mutex_init (&SendMutexSeq,NULL ) != 0)

		printf("\n Error in intialising Mutex \n"),exit(1);



}







/*
///////////////////////////////////////////////////////////////////////////////////////

// This function inserts in the process table

///////////////////////////////////////////////////////////////////////////////////////
 */

void InsertProcessTable(pid_t ProcessId, LONG32 RelayPort, LONG32 RelayId)
{

	LONG32 Count;

	for(Count = 0;Count < MAX_NO_OF_PROCESS && ProcessTable[Count].ProcessId != UNUSED ; Count++);

	if(ProcessTable[Count].ProcessId == UNUSED)
	{
		printf("\n Inserting Process Detail at %d position",Count);
		ProcessTable[Count].ProcessId = ProcessId;
		ProcessTable[Count].RelayPort = RelayPort;
		ProcessTable[Count].RelayId = RelayId;
		printf("\n ProcessId = %d \n RelayPort = %d \n RelayId = %d",ProcessTable[Count].ProcessId,ProcessTable[Count].RelayPort,ProcessTable[Count].RelayId);

	}
}


/*
///////////////////////////////////////////////////////////////////////////////////////
// SignalHandler
// This function gets called from the parent as well as the child process.
// Signals being handled are:
// 1. SIGTERM
//	  If this signal is caught then  the first thing that needs to be done is identify
//	  whether the process which caught it was a child process or a parent process.
//	  -> If catching process was parent then it would kill all the child processes
//		spawned
//	  -> If catching process was child then it will close all the open sockets and exit.
//
// 2. SIGCHLD
//	  If this signal is caught it indicates that one of the child process has exited.
//
///////////////////////////////////////////////////////////////////////////////////////
 */
void * SignalHandler(LONG32 *RelayId,sigset_t SignalSet)
{

	LONG32	Signal, iRetVal, Count=0, Status=0;
	pid_t ProcessId;
	int ForkInd=0,i=0;


	while(1)
	{

		printf("\n------ Waiting for signal in RelayId:: %d ------",*RelayId);

		iRetVal = sigwait(&SignalSet,&Signal );
		if (Signal == SIGTERM)
		{

			if (*RelayId ==0)	/* Parent Handling */
			{
				/*
				 * Now we do the following steps:
				 * 1. Kill all the child processes.
				 * 2. Wait and collect return information of all the child process.
				 * 3. Exit.
				 */

				for(Count =0 ;Count<MAX_NO_OF_PROCESS;Count++)
				{
					if(ProcessTable[Count].ProcessId != UNUSED)
					{
						if((iRetVal = kill(ProcessTable[Count].ProcessId,SIGTERM)) == 0)
							printf("\n=> SignalHandler:Parent:: Signal delivered to Process:%d successfully",ProcessTable[Count].ProcessId);
						else
							printf("\nSignalHandler:Parent:: iRetVal =%d, Errno =%d",errno);
					}
				}


				printf("\n Waiting for the Child process to exit..\n\n");
				for(Count = 0;Count<MAX_NO_OF_PROCESS; Count++)
				{
					if((ProcessId = waitpid(-1,&Status, WNOHANG))>0)
					{
						printf("\nSignalHandler:Parent:: Child Id: %d has exited",ProcessId);
						usleep(10);
					}
				}

				/*
				 * Since we are exiting ...cancel the OPThread spawned.
				 */	
				pthread_cancel(OPtid);
				if (pthread_join(OPtid,NULL) == 0)
				{
					printf("\n=> OPThread successfully terminated and joined");
				}
				exit(1);

			}
			else			/* Child Handling */
			{
				/*
				 * Now we do the following steps:
				 * 1. Close all open sockets and call CleanSocketResources.
				 * 2. Exit.
				 */

				printf("\n SignalHandler:Child RelayId %d: Signal caught is %d",*RelayId,Signal);
				for( Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS ; Count++)
				{
					if(UserSocketTable[Count].Socket != UNUSED)
					{
						printf("\nrelayid =%d, Index=%d, Socket=%d, User=%.*s",*RelayId, Count, UserSocketTable[Count].Socket , strlen(UserSocketTable[Count].User), UserSocketTable[Count].User);

						LockThreadMutex(&UserSocketTableLock,"SignalThread");
						CleanSocketResources( Count);
						UnLockThreadMutex(&UserSocketTableLock,"SignalThread");
					}
				}
				break;
				/*				exit(1);*/
			}
		}
		else if ((Signal == SIGCHLD) || (Signal == SIGSEGV)) 
		{
			/*
			 * One of the child process seems to have exited for some reason...
			 * 1. Wait on the process.
			 * 2. Initialise the table. 
			 * 3. Restart the process once again.
			 */
			printf("\n SIG Child generated ");
			if((ProcessId = waitpid(-1,&Status, WNOHANG))>0)
			{
				printf("\nSignalHandler::ParentLoop: Child Id exiting is: %d ",ProcessId);
				LockThreadMutex(&ProcessTableLock,"Main::SIGCHLD");
				for(Count = 0;Count<MAX_NO_OF_PROCESS;Count++)
				{
					if(ProcessId ==  ProcessTable[Count].ProcessId)
					{
						printf("\nOLD:: Count = %d, ProcessTable[Count].ProcessId = %d",Count,ProcessTable[Count].ProcessId);
						ProcessTable[Count].ProcessId = RESTART;
						i = Count;
					}
				}

				UnLockThreadMutex(&ProcessTableLock,"Main::SIGCHLD");

				ForkInd = fork ();
				if(ForkInd != 0)
				{
					/*
					 * We are in the parent part which updates the Process Table and loops back to start
					 * waiting on the sigwait at the begning of this function again.
					 */
					printf("\n Parent:: Count:%d, ForkInd:%d, RelayId:%d",i, ForkInd, *RelayId);
					ProcessTable[i].ProcessId = ForkInd;
				}
				else
				{
					/*
					 * We are in the child part wherein we initialise the required variables and return 
					 * back to main to open the queues and spawn out the threads.
					 */
					usleep(10);
					for(Count = 0;Count<MAX_NO_OF_PROCESS; Count++)
					{
						if (ProcessTable[Count].ProcessId == RESTART)
						{
							*RelayId = ProcessTable[Count].RelayId;
							RelayPort = ProcessTable[Count].RelayPort;
						}
					}
					NoOfReadThreads = 0;
					NoOfWriteThreads = 0;
					NoOfWriteDloadThreads = 0;
					NoOfWriteIORThreads = 0;
					break;
				}
			}
		} /*else SIGCHLD */
	}

	return;
}


/*

///////////////////////////////////////////////////////////////////////////////////////

// ReadThread

// This function is executed as a separate thread. It open a socket on RelayPort and listens for new connections 

// on the port. A socket set is made which comprises of all the sockets established. Select function continuously

// polls on each of the socket in the set and Sets the socket which is ready with data.

//

//	IMPORTANT POINT:

//  The functionality of dummy pipe is used to make the select call NON-BLOCKING. Whenever any packet is read,

//  a dummy byte is written to the pipe to set it for reading. This makes the select to write immediately, 

//  hence making it NON-BLOCKING.

///////////////////////////////////////////////////////////////////////////////////////

 */

void *ReadThread()

{

	pthread_t                  ReadWorkerTid;

	LONG32 flag=1,Count,Index = UNUSED;

	LONG32	NewSocket,MaxSoc;

	LONG32	Dummy;

	LONG32	iRetVal;

	struct sockaddr_in Serv_Addr;

	struct sockaddr_in Cli_Addr;

	fd_set	ReadSocketSet;



	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

	pthread_setcanceltype (PTHREAD_CANCEL_DEFERRED, NULL);




	memset((CHAR *) &Serv_Addr,0,sizeof(Serv_Addr));



	Serv_Addr.sin_family = AF_INET;

	Serv_Addr.sin_addr.s_addr = htonl(INADDR_ANY);

	Serv_Addr.sin_port = htons(RelayPort);




	printf("\n Read Thread for RelayId = %d, RelayPort = %d",RelayId,RelayPort);



	LockThreadMutex ( &UserSocketTableLock, "InitUserSocketTable" );

	InitUserSocketTable( );

	UnLockThreadMutex ( &UserSocketTableLock, "InitUserSocketTable" );



	if((MasterSocket = socket ( AF_INET,SOCK_STREAM ,0 ) ) == ERROR)

	{

		perror("Socket:");

		printf("\n RelayId %d: Unable to make a socket",RelayId);

		exit(1);

	}

	printf("\n----- I am here socket [%d] -----",MasterSocket);



	if((setsockopt(MasterSocket,SOL_SOCKET,SO_REUSEADDR, ( CHAR *) &flag,sizeof(flag)))< 0)

	{

		perror("SetSockOption:");

		printf("\n RelayId %d: Unable to set options for socket",RelayId);

		close(MasterSocket);
		/**	shutdown(MasterSocket,2);***/

		exit(1);

	}



	if((bind(MasterSocket,(struct sockaddr *) &Serv_Addr, sizeof(Serv_Addr))) == ERROR)

	{

		perror("Bind:");

		printf("\n RelayId %d: Unable to bind a socket",RelayId);

		close(MasterSocket);
		/***		shutdown(MasterSocket,2);****/

		exit(1);

	}



	if((listen(MasterSocket,5)) < 0 )

	{

		perror("Listen:");

		printf("\n Unable to listen on socket");

		close(MasterSocket);
		/***	shutdown(MasterSocket,2); ****/

		exit(1);

	}





	LockThreadMutex(&ActiveSocketLock ,"FD_ZERO_ACTIVESOCKETSET");

	FD_ZERO(&ActiveSocketSet);

	FD_SET(DummyPipe[0],&ActiveSocketSet);

	FD_SET(MasterSocket,&ActiveSocketSet);

	UnLockThreadMutex(&ActiveSocketLock,"FD_ZERO_ACTIVESOCKETSET");





	MaxSoc = MasterSocket ;

	/**	while(1)****/
	for(;;)
	{

		LockThreadMutex ( &UserSocketTableLock ,"GetMaxSocket");

		for (Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS ; Count++)

		{

			if((MaxSoc < UserSocketTable[Count].Socket) && (UserSocketTable[Count].Socket != UNUSED))

			{

				MaxSoc = UserSocketTable[Count].Socket;

				printf("\n Count is :%d   MaxSoc  :%d",Count,MaxSoc);

			}

		}

		UnLockThreadMutex ( &UserSocketTableLock,"GetMaxSocket" );



		LockThreadMutex ( &DummyPipeLock,"GetMaxSocket");

		if (MaxSoc < DummyPipe[0])

		{

			MaxSoc =  DummyPipe[0];

			printf("\n MaxSoc in lockthreadmutex :%d...DummyPipe[0] :%d",MaxSoc,DummyPipe[0]);

		}

		UnLockThreadMutex ( &DummyPipeLock,"GetMaxSocket");		



		LockThreadMutex(&ActiveSocketLock,"MakeReadSocketSet");

		FD_ZERO(&ReadSocketSet);

		ReadSocketSet = ActiveSocketSet;

		UnLockThreadMutex(&ActiveSocketLock,"MakeReadSocketSet");



		printf("\nReadThread::RelayId %d:-----Waiting on Select-----",RelayId);

		printf("\nReadThread::RelayId %d:-----Waiting on MaxSoc-----::%d",RelayId,MaxSoc);

		if (( iRetVal = select (MaxSoc +1, &ReadSocketSet , (fd_set *) NULL, NULL, (struct timeval *) NULL)) <= 0)
		{

			printf("\nSELReadThread::RelayId %d: Error While Polling on socket ",RelayId);

			printf("Error in select(): %s\n", strerror(errno));

			continue;

		}

		printf("\n Return Value  :%d",iRetVal);

		LockThreadMutex ( &DummyPipeLock,"ReadFromPipe"); /******  ********/

		if(FD_ISSET(DummyPipe[0],&ReadSocketSet))
		{

			printf("\n Inside the FD_ISSET loop\n");


			read(DummyPipe[0],&Dummy,sizeof(LONG32));

			UnLockThreadMutex(&DummyPipeLock,"ReadFromPipe");

			printf("\nAfter unlocking the mutex\n");

			continue;

		}

		UnLockThreadMutex(&DummyPipeLock,"ReadFromPipe");



		if(FD_ISSET(MasterSocket,&ReadSocketSet))

		{

			printf("\nISSET Inside the master socket FD_ISSET function\n");

			if((NewSocket = accept(MasterSocket, NULL, NULL)) < 0 )

			{

				printf("\nReadThread::RelayId %d: Error while accepting New Socket Errno = %d",RelayId,errno);

				exit(1);

			}

			else if(NewSocket ==0)

			{

				printf("\n accept returning 0 ");

				continue;

			}

			printf("\n  Inside  accept NewSocket= %d ",NewSocket);	



			flag = 1;

			if((setsockopt(NewSocket,SOL_SOCKET,SO_KEEPALIVE, ( CHAR *) &flag,sizeof(flag)))< 0)

			{

				perror("SetSockOption:");

				printf("\nreadThread::RelayId %d: Unable to set options for new socket",RelayId);

				close(NewSocket);
				/**	shutdown(NewSocket,2);	***/

			}

			printf("\n  after  setsockopt NewSocket= %d ",NewSocket);	



			LockThreadMutex(&UserSocketTableLock,"GetSlotInUserSocket");

			if(( Index = GetSlotInUserSocketTable(NewSocket,INSERT)) == NOT_TRUE)

			{

				printf("\nRadThread::RelayId %d: No of Users Limit Reached. Will close the new socket established(INSERT) ",RelayId);

				UnLockThreadMutex(&UserSocketTableLock,"GetSlotInUserSocket");

				continue;

			}

			UnLockThreadMutex(&UserSocketTableLock,"GetSlotInUserSocket");

			printf("\nReadThread::RelayId %d: Received new socket connection :%d",RelayId,NewSocket);



			LockThreadMutex(&ActiveSocketLock,"FDSET");

			FD_SET(NewSocket,&ActiveSocketSet);

			UnLockThreadMutex(&ActiveSocketLock,"FDSET");	



			continue;

		}


		/********************************
		  struct  timeval StartPoint10 ;
		  struct  timezone tzp1;

		  gettimeofday(&StartPoint10, &tzp1);

		  int testing =0;	
		  for(testing = 0;testing < MAX_NO_OF_USER_SOCKETS;testing++)
		  {
		  if(UserSocketTable[testing].Socket != UNUSED)
		  {
		  printf("\n  CHECKTime :%d: UserSocketTable[%d].Socket :%d: , UserSocketTable[%d].User[%s]",StartPoint10.tv_sec,testing,UserSocketTable[testing].Socket,testing,UserSocketTable[testing].User);
		  }
		  }

		 *************************/


		for(Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS; Count++)
		{


			/***			usleep(1); *****/





			if(UserSocketTable[Count].Socket != UNUSED)
			{

				LockThreadMutex(&UserSocketTable[Count].UserSocketLock,"FD_ISSET"); /*****  ******/


				if (FD_ISSET(UserSocketTable[Count].Socket,&ReadSocketSet))

				{


					UnLockThreadMutex(&UserSocketTable[Count].UserSocketLock,"FD_ISSET"); /*****  ******/

					/***

					  If the socket for the user is set then there is data pending at the socket to be recieved.

					  Create a new read worker thread to recieve the data and forward it to the queue.

					  Before creating a new thread check the total number of read threads in the system.

					  If the system has reached the limit of read thread then wait for the threads to get killed

					 ****/	

					printf("\nReadThread:: RelayId %d: UserSocketTable[Count].Socket = %d set at Index = %d ",RelayId,UserSocketTable[Count].Socket,Count);


					WaitForMaxThreadCond(READ_THREAD);

					printf("\n Before thread_create\n");

					pthread_create(&ReadWorkerTid,&ThreadAttr,&ReadWorkerThread,Count);

					LockThreadMutex(&ReadThreadLock,"ReadThreadCreate");

					NoOfReadThreads++;

					UnLockThreadMutex(&ReadThreadLock,"ReadThreadCreate");



					printf("\nReadThread::RelayId %d: No of Read Thread is %d",RelayId,NoOfReadThreads);


					if(NoOfReadThreads <= 0)
					{
						UnLockThreadMutex(&UserSocketTable[Count].UserSocketLock,"FD_ISSET");
						WaitForMaxThreadCond(READ_THREAD);
						pthread_create(&ReadWorkerTid,&ThreadAttr,&ReadWorkerThread,Count);

						LockThreadMutex(&ReadThreadLock,"ReadThreadCreate");
						NoOfReadThreads++;
						UnLockThreadMutex(&ReadThreadLock,"ReadThreadCreate");

						printf("\n IN again create thread ReadThread::RelayId %d: No of Read Thread is %d",RelayId,NoOfReadThreads);

					}


					if(UserSocketTable[Count].Socket != UNUSED)

					{
						LockThreadMutex(&ActiveSocketLock,"FDCLR");
						printf("\n Before FD_CLR 1 %d:",UserSocketTable[Count].Socket);

						FD_CLR(UserSocketTable[Count].Socket,&ActiveSocketSet);

						UnLockThreadMutex(&ActiveSocketLock,"FDCLR");

					}

				}
				UnLockThreadMutex(&UserSocketTable[Count].UserSocketLock,"FD_ISSET"); /******  *****/

			}


		}



	}

}	





void ReadWorkerThread(void *Value)
{

	LONG32 Len, TransCode;
	LONG32	BytesRead;
	LONG32	Dummy;
	LONG32	Index;
	LONG32	Socket;
	LONG32  LocalSoc;
	LONG32	iLogonStatus=0;
	LONG32	Count=ERROR;
	LONG32	iRetVal;
	CHAR 	UserId[USER_ID_LEN];
	CHAR    ClientId[CLIENT_ID_LEN];
	LONG32  ClientIdLen =0;
	LONG32  iRetCurrUser=0;
	LONG32  CurrentUser=0;

	struct  INT_DWS_LOGON_REQ   *Mesg_Pkt1;
	CHAR	Mesg_Buf[MAX_PACKET_SIZE];
	struct 	REQ_HEADER *Mesg_Pkt;	
	struct 	INT_COMMON_RESP_HDR	sMesg_Rsp;
	struct  INT_DWS_LOGON_RESP	pLogonResp;
	struct 	ORDER_PROCESSOR_START_RESP	sOrdProStrt;	


	struct timespec TimeSpec;
	pthread_mutex_t dummy_mutex;
	pthread_cond_t  dummy_cond;
	time_t tsec;

	if(pthread_mutex_init(&dummy_mutex ,NULL) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);



	if(pthread_cond_init(&dummy_cond ,NULL )!= 0)
		printf("\nInit_Routine: Error in intialising Cond Variable"),exit(1);



	/*	Socket = *Value;*/
	Index = (LONG32 *)Value;

	memset(	UserId,'\0',USER_ID_LEN);
	memset(	ClientId,'\0',CLIENT_ID_LEN);
	memset(Mesg_Buf,' ',MAX_PACKET_SIZE);
	printf("\n RWT:: RelayId %d: Going To Recv on Socket=%d Index=%d",RelayId,UserSocketTable[Index].Socket,Index);
	LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"RecvData");


	if(UserSocketTable[Index].Socket != UNUSED)
	{
		if((BytesRead = Recv(UserSocketTable[Index].Socket,Mesg_Buf,&Len)) == ERROR )

		{

			UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"RecvData");
			printf("\n RelayId %d: Error while receiving on the socket:%d ",RelayId,errno);

			usleep(500);
			LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesRecvData")	;
			CleanSocketResources(Index);
			UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesRecvData")	;
			printf("\n Alok before SignalReadThreadKillCond in Recv");
			SignalReadThreadKillCond(READ_THREAD);
			printf("\n Alok After SignalReadThreadKillCond in Recv");
			usleep(500);
			return;
		}



		struct  timeval StartPoint1 , EndPoint1 ;
		struct  timezone tzp;


		StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
		gettimeofday(&StartPoint1, &tzp);

		StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
		printf("\n Time of entry in ReadWorkerThread :%d:",StartPoint1.tv_sec);
		/****
		  tsec = time(NULL);
		  tsec = tsec + 1;
		  TimeSpec.tv_sec = tsec;
		  TimeSpec.tv_nsec = 0;
		 *****/

		tsec = time(NULL);
		TimeSpec.tv_sec = 0;
		TimeSpec.tv_nsec = 250000000;


		pthread_cond_timedwait(&dummy_cond,&dummy_mutex,&TimeSpec);
		/******/

		LockThreadMutex(&ActiveSocketLock, "FD_SETAfterRecv");
		FD_SET(UserSocketTable[Index].Socket,&ActiveSocketSet);
		UnLockThreadMutex(&ActiveSocketLock, "FD_SETAfterRecv");

		UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"RecvData");

	}
	else
	{

		printf("\n UserSocketTable[%d].Socket = [%d] : Invalid Socket ... returning ...\n",Index,UserSocketTable[Index].Socket);

		UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"RecvData");
		SignalReadThreadKillCond(READ_THREAD);

		return;
	}



	Mesg_Pkt = ( struct REQ_HEADER * ) &Mesg_Buf;
	Mesg_Pkt1 = ( struct INT_DWS_LOGON_REQ * ) &Mesg_Buf;

	TransCode = Mesg_Pkt -> iRequestCode;

#ifdef DBG
	printf("\n----------------------DATA received-----------------------");
	printf("\n RWT:: RelayId %d: Transcode 	: %d",RelayId,TransCode);
	printf("\n RWT:: RelayId %d: iUserId 	: %d",RelayId,Mesg_Pkt -> iUserId);
	printf("\n RWT:: RelayId %d: Segment 	: %d",RelayId,Mesg_Pkt ->iSegment);
	printf("\n RWT:: RelayId %d: ExchId 	: %d",RelayId,Mesg_Pkt ->iExchange);
	//rintf("\n RWT:: RelayId %d: UserType	 : %c",RelayId,Mesg_Pkt -> cUserType);
	printf("\n RWT:: RelayId %d: MsgLength : %d",RelayId,Mesg_Pkt -> iRequestLength);
	printf("\n RWT:: RelayId %d: UserSocketTable[%d].Socket: %d",RelayId,Index,UserSocketTable[Index].Socket);
	printf("\n----------------------DATA---------------------");
#endif
	printf("\n USERID :%d: Has connection on socket UserSocketTable[%d].Socket :%d:",Mesg_Pkt -> iUserId,Index,UserSocketTable[Index].Socket);


	sprintf(UserId,"%d",Mesg_Pkt -> iUserId);

	iRetVal = Is_Valid_User(UserId,&Count);

	printf("\n RWT::RelayId %d: Is_Valid_User returns %d and the count is %d and Index = %d",RelayId,iRetVal,Count, Index);

	/****	if((iRetVal == ERROR && TransCode != TC_INT_LOGON_REQ) ||(iRetVal == ERROR && TransCode != TC_INT_RECONNECT_REQ ))
	  {

	  printf("\n ALOKK here in dropping");
	  printf("\n RWT::RelayId %d: Invalid UserId Sent droppping the packet",RelayId);
	  LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")	;
	  CleanSocketResources(Index);
	  UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
	  SignalReadThreadKillCond(READ_THREAD);
	  return;

	  }
	  else**********/ 
	if(iRetVal == SOCKET_EXIST  && TransCode != TC_INT_LOGON_REQ) 
	{

		/*
		 * If the socket for the user already exists, and a TC_INT_LOGON_REQ is received for the user
		 * then close the old socket and process all the comming request on this new socket, and if
		 * the request is not TC_INT_LOGON_REQ then close both the sockets.
		 */

		printf("\n RWT::RelayId %d: Wrong Request recieved on New socket Closing both the socket",RelayId);
		usleep(500);
		LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
		CleanSocketResources(Count);
		if(Count != Index)
			CleanSocketResources(Index);
		UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

		SignalReadThreadKillCond(READ_THREAD);
		return;
	}
	else if((iRetVal == SOCKET_EXIST || iRetVal == TRUE)  && (TransCode == TC_INT_LOGON_REQ || TransCode == TC_INT_RECONNECT_REQ) && UserSocketTable[Count].Socket != UserSocketTable[Index].Socket)
	{
		printf("\n RWT::RelayId %d: Request recieved on New socket Closing old socket",RelayId);
		usleep(500);
		LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
		CleanSocketResources(Count);
		UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
		iRetVal = SOCKET_EXIST;

	}	
	else if(iRetVal == TRUE && TransCode != TC_INT_LOGON_REQ && Count != Index)

	{

		printf("\n RWT::RelayId %d: Wrong Request received on New Socket Closing New Socket");
		usleep(500);
		LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongReq")   ;
		CleanSocketResources(Index);
		UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongReq")   ;
		SignalReadThreadKillCond(READ_THREAD);
		return;
	}

	struct  timeval EndPoint2 ;
	struct  timezone tzp;


	logDebug2("Nishant TransCode received  here :%d:",TransCode);
	switch(TransCode)
	{
		case TC_INT_LOGON_REQ:



			if(iRetVal != TRUE )
			{

				if((iRetVal = ProcessLogOnRequest(&Index,UserId)) == FALSE)
				{
					printf("\n RelayId %d: Unable to process LogOn Request on RelayId ",RelayId);

					usleep(500);
					LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")	;
					CleanSocketResources(Index);
					UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

					break;

				}

			}

			pLogonResp.IntRespHeader.iErrorId = 0;



			iRetCurrUser =Find_Max_User(&CurrentUser);

			printf("\nMaxUser = [%d] CurrentUser = [%d]",dMaxUser,CurrentUser);

			if(CurrentUser >= dMaxUser)
			{
				pLogonResp.IntRespHeader.iErrorId= 4200;
				printf("\n Max user violated :%d:",pLogonResp.IntRespHeader.iErrorId);
			}

			pLogonResp.IntRespHeader.iMsgLength = sizeof(struct  INT_DWS_LOGON_RESP);
			pLogonResp.IntRespHeader.iMsgCode = TC_INT_LOGON_RSP;
			pLogonResp.IntRespHeader.iTimeStamp= 0;
			pLogonResp.IntRespHeader.iUserId= 0;
			//			pLogonResp.IntRespHeader.UserTypeOrLogInfoType=0;

			printf("\n pLogonResp.IntRespHeader.iErrorId:%d:",pLogonResp.IntRespHeader.iErrorId);

			printf("\n pLogonResp.IntRespHeader.iUserId:%d:",pLogonResp.IntRespHeader.iUserId);

			/********** ALOKK HARDCODED NEED TO REMOVE LATER********************/
			strncpy(pLogonResp.sEntityId,"",12);
			strncpy(pLogonResp.AccCode,"",12);
			strncpy(pLogonResp.sName,"",60);
			strncpy(pLogonResp.CurrDate,"20120930",20);

			strncpy(pLogonResp.ExpiryDate,"20120930",20);
			strncpy(pLogonResp.AllowedExch,"1111000",10);
			strncpy(pLogonResp.cfprimaryip,"121.241.245.76",16);
			strncpy(pLogonResp.cffailoverip,"121.241.245.76",16);
			strncpy(pLogonResp.dsprimaryip,"121.241.245.76",16);
			strncpy(pLogonResp.failoverip,"121.241.245.76",16);
			strncpy(pLogonResp.TransPass,"abc123",16);
			pLogonResp.Suscriptionlevel = 7;


			/********** ALOKK HARDCODED NEED TO REMOVE LATER********************/

			Len = pLogonResp.IntRespHeader.iMsgLength;
			printf("\n iUserId%d",pLogonResp.IntRespHeader.iUserId);
			//			printf("\n UserTypeOrLogInfoType %c",pLogonResp.IntRespHeader.UserTypeOrLogInfoType);
			printf("\n iMsgLength %d",pLogonResp.IntRespHeader.iMsgLength);
			printf("\n iMsgCode %d",pLogonResp.IntRespHeader.iMsgCode);
			printf("\n sEntityId %s",pLogonResp.sEntityId);
			printf("\n AccCode %s",pLogonResp.AccCode);
			printf("\n sName %s",pLogonResp.sName);
			printf("\n pLogonResp.CurrDate %s",pLogonResp.CurrDate);
			printf("\n pLogonResp.ExpiryDate %s",pLogonResp.ExpiryDate);
			printf("\n pLogonResp.cfprimaryip %s",pLogonResp.cfprimaryip);
			printf("\n pLogonResp.cffailoverip %s",pLogonResp.cffailoverip);
			printf("\n pLogonResp.dsprimaryip %s",pLogonResp.dsprimaryip);
			printf("\n pLogonResp.failoverip %s",pLogonResp.failoverip);
			printf("\n pLogonResp.AllowedExch %s",pLogonResp.AllowedExch);
			printf("\n pLogonResp.Suscriptionlevel %d",pLogonResp.Suscriptionlevel);
			printf("\n pLogonResp.TransPass :%s:",pLogonResp.TransPass );



			LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
			printf("\n Socket FD = [%d]", LocalSoc);


			if((Send(UserSocketTable[Index].Socket,&pLogonResp,&Len ))== ERROR)
			{
				printf("\n RelayId %d: Error While sending logon response to user TC_INT_LOGON_REQ ",RelayId);	
				LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")	;
				CleanSocketResources(Index);
				UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
			}
			UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

			printf("\n RWT::RelayId %d: LogOn Resp being sent to user:%d, iMsgLength = %d",RelayId,sMesg_Rsp.iUserId,sMesg_Rsp.iMsgLength);


			break;

		case TC_INT_KEEP_ALIVE_REQ:

			sMesg_Rsp.iUserId= Mesg_Pkt -> iUserId;
			sMesg_Rsp.cSegment = Mesg_Pkt -> iSegment;
			//			sMesg_Rsp.UserTypeOrLogInfoType = Mesg_Pkt->cUserType;
			sMesg_Rsp.iMsgLength= sizeof(struct INT_COMMON_RESP_HDR);
			sMesg_Rsp.iErrorId= 0;
			sMesg_Rsp.iTimeStamp= 0;
			sMesg_Rsp.iMsgCode= TC_INT_KEEP_ALIVE_RESP;
			Len = sMesg_Rsp.iMsgLength;

			LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

			if((Send(UserSocketTable[Index].Socket,&sMesg_Rsp,&Len ))== ERROR)
			{
				UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
				printf("\n RelayId %d: Error While sending response to user TC_INT_KEEP_ALIVE_REQ ",RelayId);
				LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;
				CleanSocketResources(Index);
				UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

			}

			UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
			printf("\n RWT::RelayId %d: LogOn Resp being sent to user TC_INT_KEEP_ALIVE_REQ:%d, iMsgLength= %d",RelayId, sMesg_Rsp.iUserId, sMesg_Rsp.iMsgLength);
			break;





		case TC_INT_RECONNECT_REQ :


			printf("\n I am in reconnect");	
			if(iRetVal != TRUE )
			{

				printf("\n iRetVal is [%d] in TC_INT_RECONNECT_REQ going to ProcessLogOnRequest",iRetVal);
				if((iRetVal = ProcessLogOnRequest(&Index,UserId)) == FALSE)
				{
					printf("\n RelayId %d: Unable to process LogOn Request on RelayId ",RelayId);
					usleep(500);
					LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")       ;
					CleanSocketResources(Index);
					UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

					break;

				}
			}

			printf("\n ALOK here after reconnect");

			sMesg_Rsp.iMsgLength= sizeof(struct INT_COMMON_RESP_HDR);
			sMesg_Rsp.iUserId=  Mesg_Pkt ->iUserId;
			//			sMesg_Rsp.UserTypeOrLogInfoType =  Mesg_Pkt ->cUserType;
			sMesg_Rsp.iMsgCode= TC_INT_RECONNECT_RESP ;

			Len = sMesg_Rsp.iMsgLength;

			printf("\n ALOK here after reconnect 2 UserSocketTable[Index].Socket :%d:",UserSocketTable[Index].Socket);

			LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
			printf("\n Socket FD = [%d]", LocalSoc);


			if((Send(UserSocketTable[Index].Socket,&sMesg_Rsp,&Len))== ERROR)

			{
				UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
				printf("\n RelayId %d: Error While sending logon response to user TC_INT_RECONNECT_REQ Index[%d]",RelayId,Index);
				LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")       ;
				CleanSocketResources(Index);
				UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

			}

			UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

			printf("\n ALOK here after reconnect 3");

			break;




			/*
			 * LOGOFF TRANSCODE
			 */
		case	TC_INT_LOGOFF_REQ :

			printf("\n RelayId %d: Handling LogOff Transcode : %d",RelayId,TransCode);
			printf("\n RelayId %d: In TC_INT_LOGOFF_REQ : %d ,sleeping for 500 ms \n",RelayId,TransCode);  

			usleep(500);

			LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")	;
			CleanSocketResources(Index);
			UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongLogOnReq")   ;

			break;


			/*
			 * INQUIRY TRANSCODES 
			 */

			//		case	TC_INT_PASSWD_CHANGE_REQ:
		case	TC_INT_VIEW_CLIENT_LIMIT_REQ:
		case	TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
		case 	TC_INT_NET_POS_REQ:
		case	TC_INT_ORDER_BOOK_REQ:
		case	TC_INT_ORDER_BOOK_DTLS_REQ:
		case	TC_INT_TRADE_BOOK_REQ:
			//		case	TC_INT_ADMIN_TRADE_BOOK_REQ:
		case	TC_INT_CLINET_HOLDING_REQ:
		case	TC_INT_NETPOS_DTL_REQ:
		case	TC_INT_CARRY_FWD_POS_REQ:

			//		case	TC_INT_ADMIN_CONVT_TO_DELV_REQ:
		case	TC_INT_SEND_MSG_TO_CLIENT_REQ:
		case	TC_INT_DNLD_SYSTEM_MSG_REQ:
		case	TC_INT_REJECTED_ORDERS_REQ:



			printf("Before Write Q");

			if((WriteMsgQ(iRelToQuery,Mesg_Buf,Mesg_Pkt -> iRequestLength,1)) < 0)	

			{

				printf("\n RelayId %d: Error While writing to Query Queue ",RelayId);

			}

			printf("\n RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToQuery);

			break;




			/*

			 * INQUIRYBCAST TRANSCODES 

			 */
			/******
			  case	TC_INT_EQU_MBP_REQ			:
			  case	TC_INT_DRV_MBP_REQ			:
			  case	TC_INT_EQU_CLOSING_PRICE_REQ:
			  case	TC_INT_MII_REQ				:
			  case	TC_INT_EQU_MKT_WATCH_REQ	:
			  case	TC_INT_DRV_MKT_WATCH_REQ	:

			  if((WriteMsgQ(STWRelToBcastQueryQ,Mesg_Buf,Mesg_Pkt -> iRequestLength,1)) < 0)	

			  {

			  printf("\n RelayId %d: Error While writing to BcastQuery Queue ",RelayId);

			  }

			  printf("\n RelayId %d: Successfully Written To The Q : %d",RelayId , STWRelToBcastQueryQ);

			  break;
			 *****/




			/*

			 * ORDER TRANSCODES 

			 */

			/*
			   case    TC_INT_ORDER_ENTRY_REQ			:
			   case	TC_INT_ORDER_MODIFY			:
			   case	TC_INT_ORDER_CANCEL			:
			 */
		case    TC_INT_EQU_ORDER_ENTRY                  :
		case    TC_INT_EQU_ORDER_MODIFY                 :
		case    TC_INT_EQU_ORDER_CANCEL                 :
		case    TC_INT_DRV_ORDER_ENTRY                  :
		case    TC_INT_DRV_ORDER_MODIFY                 :
		case    TC_INT_DRV_ORDER_CANCEL    		:

		case	TC_INT_OFF_ORDER_ENTRY			:
		case	TC_INT_OFF_ORDER_MODIFY			:
		case	TC_INT_OFF_ORDER_CANCEL			:
		case    TC_INT_NOTIFICATION_REQ                 :

		case	TC_INT_SQUAREOFF_INTRADAY_REQ		:
		case	TC_INT_PUMPOFFLINE_REQ			:
		case	TC_INT_ADMIN_EXPIRY_REQ			:


			if((WriteMsgQ(iDWSRelayToMapperQ,Mesg_Buf,Mesg_Pkt -> iRequestLength,1)) < 0)	
			{
				printf("\n RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
			}

			gettimeofday(&EndPoint2, &tzp);
			EndPoint2.tv_sec = EndPoint2.tv_sec+19800;
			printf("\n Time of exit is ReadWorkerThread :%d:",EndPoint2.tv_sec);
			printf("\n Cover Order Request MsgCode = %d",TC_INT_EQU_CO_ORDER_REQ);
			printf("\n RelayId %d: Successfully Written To The Q : %d",RelayId,iDWSRelayToMapperQ);

			break;


		case    TC_INT_EQU_CO_ORDER_REQ                 :
		case    TC_INT_EQU_CO_ORDER_MODIFY              :
		case    TC_INT_EQU_CO_ORDER_CANCEL              :
		case    TC_INT_DRV_CO_ORDER_REQ                 :
		case    TC_INT_DRV_CO_ORDER_MODIFY              :
		case    TC_INT_DRV_CO_ORDER_CANCEL              :

			if((WriteMsgQ(iDWSRelayToMapperQ,Mesg_Buf,Mesg_Pkt -> iRequestLength,2)) < 0)
			{
				printf("\n RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
			}

			gettimeofday(&EndPoint2, &tzp);
			EndPoint2.tv_sec = EndPoint2.tv_sec+19800;
			printf("\n Time of exit is ReadWorkerThread :%d:",EndPoint2.tv_sec);
			printf("\n Cover Order Request MsgCode = %d",TC_INT_EQU_CO_ORDER_REQ);
			printf("\n RelayId %d: Successfully Written To The Q : %d",RelayId,iDWSRelayToMapperQ);

			break;

		case	TC_INT_CON_DEL_REQ			:


			logDebug2("Here");
			struct	CON_TO_DELIVERY_REQUEST  pReq;
			BOOL ChkFlag = FALSE;

			memset(&pReq,'\0',sizeof(struct CON_TO_DELIVERY_REQUEST));

			ChkFlag = IntMapper((struct DWS_CON_TO_DELIVERY_REQUEST *) &Mesg_Buf,&pReq);

			if(ChkFlag == FALSE)
			{
				logDebug2("Mapping Failed");
			}
			else 
			{
				if((WriteMsgQ(iRelToOrdRtr,&pReq,sizeof(struct CON_TO_DELIVERY_REQUEST),1)) < 0)	
				{
					printf("\n RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
				}
			}

			gettimeofday(&EndPoint2, &tzp);
			EndPoint2.tv_sec = EndPoint2.tv_sec+19800;
			printf("\n Time of exit is ReadWorkerThread :%d:",EndPoint2.tv_sec);

			printf("\n RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToOrdRtr);

			break;
			/****
			  case    TC_INT_CON_DEL_REQ                      :


			  logDebug2("Here");
			  struct  CON_TO_DELIVERY_REQUEST  pReq;
			  BOOL ChkFlag = FALSE;

			  memset(&pReq,'\0',sizeof(struct CON_TO_DELIVERY_REQUEST));

			  ChkFlag = IntMapper((struct DWS_CON_TO_DELIVERY_REQUEST *) &Mesg_Buf,&pReq);

			  if(ChkFlag == FALSE)
			  {
			  logDebug2("Mapping Failed");
			  }
			  else
			  {
			  if((WriteMsgQ(iRelToOrdRtr,&pReq,sizeof(struct CON_TO_DELIVERY_REQUEST),1)) < 0)
			  {
			  printf("\n RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
			  }
			  }

			  break;	
			 *******/
		default:

			printf("\n RelayId %d: Wrong TransCode recieved::%d ",RelayId,TransCode);

			usleep(500);

			LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongTransCode")	;

			CleanSocketResources(Index);

			UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesWrongTransCode")   ;

			break;

	}


	printf("\n Alok here before SignalReadThreadKillCond 1");

	SignalReadThreadKillCond(READ_THREAD);
	printf("\n Alok here after SignalReadThreadKillCond 1");

	LockThreadMutex(&DummyPipeLock,"WriteToPipe");
	printf("\n Alok here after LockThreadMutex 1");

	write(DummyPipe[1],&Dummy,sizeof(LONG32));
	printf("\n Alok here after write in dummy pipe 1");

	UnLockThreadMutex(&DummyPipeLock,"WriteToPipe");
	printf("\n Alok here after UnLockThreadMutex 1");

}

BOOL IntMapper(struct DWS_CON_TO_DELIVERY_REQUEST *pIn, struct CON_TO_DELIVERY_REQUEST *pOut)
{
	pOut->ReqHeader.iSeqNo= 0;
	pOut->ReqHeader.iMsgLength= sizeof(struct CON_TO_DELIVERY_REQUEST);
	pOut->ReqHeader.iMsgCode= pIn->ReqHeader.iRequestCode;
	logDebug3("pOut->ReqHeader.iMsgCode = %d",pOut->ReqHeader.iMsgCode);
	logDebug2("pIn->ReqHeader.iExchange = %d",pIn->ReqHeader.iExchange);

	if(pIn->ReqHeader.iExchange == 1)
	{
		strncpy(pOut->ReqHeader.sExcgId,NSE_EXCH,EXCHANGE_LEN);
	}
	else if(pIn->ReqHeader.iExchange == 2)
	{
		strncpy(pOut->ReqHeader.sExcgId,BSE_EXCH,EXCHANGE_LEN);
	}
	else if(pIn->ReqHeader.iExchange == 3)
	{
		strncpy(pOut->ReqHeader.sExcgId,MCX_EXCH,EXCHANGE_LEN);
	}
	else
	{
		logFatal("Invalid Exchange :%d:",pIn->ReqHeader.iExchange);
		return FALSE;
	}

	logDebug2("pIn->ReqHeader.cUserType = %c",pIn->ReqHeader.cUserType);
	pOut->cUserType = pIn->ReqHeader.cUserType;
	logDebug3("pOut->cUserType = %c",pOut->cUserType);

	logDebug2("pIn->ReqHeader.iSegment :%d:",pIn->ReqHeader.iSegment);
	if(pIn->ReqHeader.iSegment == 1)
	{
		pOut->ReqHeader.cSegment= EQUITY_SEGMENT;
	}
	else if (pIn->ReqHeader.iSegment == 2)
	{
		pOut->ReqHeader.cSegment= DERIVATIVE_SEGMENT;
	}
	else if (pIn->ReqHeader.iSegment == 3)
	{
		pOut->ReqHeader.cSegment= CURRENCY_SEGMENT;
	}
	else if (pIn->ReqHeader.iSegment == 4)
	{
		pOut->ReqHeader.cSegment= COMMODITY_SEGMENT;
	}
	else
	{
		logFatal("Invalid Segment iSegment:%d:",pIn->ReqHeader.iSegment);
		return FALSE;
	}	
	logDebug2("pOut->ReqHeader.cSegment :%c:",pOut->ReqHeader.cSegment);

	pOut->ReqHeader.iUserId = pIn->ReqHeader.iUserId;
	logDebug3("pOut->ReqHeader.iUserId = %d",pOut->ReqHeader.iUserId);
	strncpy(pOut->sSecurityId,pIn->sSecurityId,SECURITY_ID_LEN);
	logDebug3("pOut->sSecurityId = %s",pOut->sSecurityId);
	strncpy(pOut->sEntityId,pIn->sEntityId,ENTITY_ID_LEN);
	logDebug3("pOut->sEntityId = %s",pOut->sEntityId);
	strncpy(pOut->sClientId,pIn->sClientId,CLIENT_ID_LEN);
	logDebug2("pOut->sClientId = %s",pOut->sClientId);
	pOut->cBuyOrSell = pIn->cBuyOrSell;
	logDebug2("pOut->cBuyOrSell = %c",pOut->cBuyOrSell);
	pOut->cProdIdFrom = pIn->cProdIdFrom;
	logDebug2("pOut->cProdIdFrom = %c",pOut->cProdIdFrom);
	pOut->cProdIdTo = pIn->cProdIdTo;
	logDebug2("pOut->cProdIdTo = %c",pOut->cProdIdTo);
	pOut->iQty = pIn->iQty;
	logDebug3("pOut->iQty = %d",pOut->iQty);
	pOut->iMktType = pIn->iMktType;	
	logDebug3("pOut->iMktType = %d",pOut->iMktType);

	return TRUE;
}

void *WriteThread(LONG32 *Flag)

{

	pthread_t                  WriteWorkerTid;

	pthread_t                  WriteDloadWorkerTid;

	pthread_t                  WriteIORWorkerTid;

	LONG32	QueueId;

	struct  MESG_STRUCT *Mesg_Pkt;



	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

	pthread_setcanceltype (PTHREAD_CANCEL_DEFERRED, NULL);



	switch(*Flag)

	{

		case	WRITE_THREAD:


			QueueId = iRevMapToDWSRel;

			break;

		case	WRITE_IOR_THREAD:

			QueueId = iRelToQuery;//iRevMapToDWSRel;

			break;

		case	WRITE_DLOAD_THREAD:

			QueueId = iRelToQuery; /****** For Queries **************/

			break;

		default:

			printf("\n RelayId %d: Wrong Flag send to Write Thread",RelayId);

			return;

	}



	for(;;)

	{

		Mesg_Pkt = malloc(sizeof(struct  MESG_STRUCT));

		memset(Mesg_Pkt,' ',sizeof(struct  MESG_STRUCT));

		//if((ReadMsgQ(QueueId,&(Mesg_Pkt->Mesg_Buf),MAX_PACKET_SIZE,RelayId)) == ERROR)
		if((ReadMsgQ(iRevMapToDWSRel,&(Mesg_Pkt->Mesg_Buf),MAX_PACKET_SIZE,RelayId)) == ERROR)

		{

			printf("\n WRiteThread::RelayId %d: Error In Reading from Queue Id = %d",RelayId,QueueId);

			exit(1);

		}


		printf("\n After read Q QueueId :%d:",QueueId);




		Mesg_Pkt->Flag = *Flag;

		switch( *Flag )

		{

			case WRITE_THREAD:

				printf ("\n\t Before Send :: %c " , Mesg_Pkt->Mesg_Buf[32]); 


				WaitForMaxThreadCond(WRITE_THREAD);

				printf("\n No.of write thread :%d",NoOfWriteThreads);	

				LockThreadMutex(&WriteThreadLock,"WriteThreadCreate");

				NoOfWriteThreads++;

				UnLockThreadMutex(&WriteThreadLock,"WriteThreadCreate");

				printf("\n WriteThread::RelayId %d: No of Write Thread is %d",RelayId,NoOfWriteThreads);

				printf ("\n\t Called the send func " ) ;

				LockThreadMutex ( &SendMutexSeq,"WriteWorkerThread" ); 

				pthread_create(&WriteWorkerTid,&ThreadAttr,WriteWorkerThread,Mesg_Pkt);

				break;



			case WRITE_IOR_THREAD:

				WaitForMaxThreadCond(WRITE_IOR_THREAD);	

				LockThreadMutex(&WriteIORThreadLock,"WriteIORThreadCreate");

				NoOfWriteIORThreads++;

				UnLockThreadMutex(&WriteIORThreadLock,"WriteIORThreadCreate");

				printf("\n Write_IOR_Thread::RelayId %d: No of Write IOR Thread is %d",RelayId,NoOfWriteIORThreads);

				pthread_create(&WriteIORWorkerTid,&ThreadAttr,WriteWorkerThread,Mesg_Pkt);

				break;



			case WRITE_DLOAD_THREAD:

				WaitForMaxThreadCond(WRITE_DLOAD_THREAD);	

				LockThreadMutex(&WriteDloadThreadLock,"WriteDloadThreadCreate");

				NoOfWriteDloadThreads++;

				UnLockThreadMutex(&WriteDloadThreadLock,"WriteDloadThreadCreate");

				printf("\n Write_Dld_Thread::RelayId %d: No of Write Dload Thread is %d",RelayId,NoOfWriteDloadThreads);

				pthread_create(&WriteDloadWorkerTid,&ThreadAttr,WriteWorkerThread,Mesg_Pkt);

				break;

		}

	}	

}





void WriteWorkerThread(struct  MESG_STRUCT *Mesg_Pkt)

{

	CHAR UserId[CLIENT_ID_LEN];

	LONG32	Index=0 , Len , BytesSend;

	LONG32	TransCode;

	LONG32	iRetVal;

	struct INT_RESP_HEADER	*pIntRespHeader;

	LONG32  Dummy;



	pIntRespHeader = (struct INT_RESP_HEADER *)Mesg_Pkt -> Mesg_Buf;

	memset(UserId,'\0',CLIENT_ID_LEN);

	sprintf ( UserId,"%d",pIntRespHeader->iUserIdOrLogPktId);	


	Len 		= pIntRespHeader->iMsgLength;

	TransCode 	= pIntRespHeader->iMsgCode;

	struct  timeval StartPoint , EndPoint ;
	struct  timezone tzp;

	StartPoint.tv_sec = StartPoint.tv_sec+19800;


	printf("\n WWT::RelayId %d: Sending Packet of Length %d and TransCode %d to User %d UserId:%s",RelayId,Len,TransCode,pIntRespHeader->iUserIdOrLogPktId,UserId);




	iRetVal = Is_Valid_User(UserId,&Index);



	if(iRetVal < 0)

	{

		printf("\n WWT::RelayId %d: Invalid UserId, droppping the packet read from queue",RelayId);

		UnLockThreadMutex ( &SendMutexSeq,"WriteWorkerThread" ); 

	}

	else

	{

		UnLockThreadMutex ( &SendMutexSeq,"WriteWorkerThread" ); 

		LockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

		printf("\nDEBUGMesg_Pkt->Mesg_Buf[32]::%c\n",Mesg_Pkt->Mesg_Buf[32]);

		gettimeofday(&StartPoint, &tzp);
		StartPoint.tv_sec = StartPoint.tv_sec+19800;
		printf("\n Time of entry is WriteWorkerThread :%d:",StartPoint.tv_sec);


		if((BytesSend = Send(UserSocketTable[Index].Socket,&(Mesg_Pkt->Mesg_Buf),&Len)) == ERROR )
		{
			UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
			printf("\n WWT::RelayId %d: Error while sending on the socket ",RelayId);
			LockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesSendData")	;
			CleanSocketResources(Index);
			UnLockThreadMutex(&UserSocketTableLock,"CleanSocketResourcesSendData")	;
		}

		UnLockThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

	}

	printf("\n Hi Alok here where i am suspecting 1");
	printf("\n WWT::RelayId %d: Mesg FLAG is %d",RelayId,Mesg_Pkt->Flag);
	printf("\n Hi Alok here where i am suspecting 2");



	SignalReadThreadKillCond(Mesg_Pkt->Flag);
	printf("\n Hi Alok here where i am suspecting 3");


	printf("\n Hi Alok here where i am suspecting 4");





	LockThreadMutex(&DummyPipeLock,"WriteToPipe");
	printf("\n Hi Alok here where i am suspecting 5");

	write(DummyPipe[1],&Dummy,sizeof(LONG32));
	printf("\n Hi Alok here where i am suspecting 6");

	UnLockThreadMutex(&DummyPipeLock,"WriteToPipe");
	printf("\n Hi Alok here where i am suspecting 7");


	free(Mesg_Pkt);
	printf("\n Hi Alok here where i am suspecting 8");


}



/****

  This function is used to access the user socket table.
  The access is done on the basis of three flag
FLAG:
INSERT : This flag is sent to insert the socket in the table.
SELECT : This flag is sent to get the index of the socket in the table.
RETURN VALUE:
On successful completion of the function the index of the socket is returned.
A value NOT_TRUE is returned is the socket doesn't exists in case of select or 
no space left for new socket.	
 ****/

LONG32 GetSlotInUserSocketTable( LONG32 Socket,LONG32 Flag)

{

	LONG32 Count;



	if(Flag == INSERT)

	{

		printf("\n RelayId %d: New Socket Request Recieved Socket = %d", RelayId,Socket);

		for( Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS ; Count++)

		{

			/*******  **********/



			printf("\n GetSlotInUserSocketTable :: Socket = [%d] ",Socket);



			if(UserSocketTable[Count].Socket != UNUSED)

			{

				printf("\n GetSlotInUserSocketTable ::UserSocketTable[%d].Socket = [%d] \n",Count,UserSocketTable[Count].Socket);

			}

			if(UserSocketTable[Count].Socket == UNUSED)

			{

				printf("\n USER LOGGED IN :%d",Count);

				printf("\n RelayId %d: Index for the new socket is %d",RelayId,Count);

				UserSocketTable[Count].Socket = Socket;

				return Count;

			}

		}

	}

	else if(Flag == SELECT)

	{

		for( Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS ; Count++)

		{

			if(UserSocketTable[Count].Socket == Socket)

				return Count;

		}

	}

	return NOT_TRUE;

}	





void UnLockThreadMutex ( pthread_mutex_t * mutex,CHAR *Position)
{

	LONG32 iRetVal;
	if((iRetVal = pthread_mutex_unlock(mutex)) != 0)
	{
#ifdef     DBG
		printf("\n RelayId %d: UnLocked Position: %s",RelayId,Position);
		printf("\n RelayId %d: UnLockThreadMutex: Error in UnLocking Mutex  Errno = %d\n",RelayId,iRetVal);
#endif
		kill(getpid(),SIGTERM);
	}

}



void LockThreadMutex ( pthread_mutex_t * mutex,CHAR *Position)

{

	LONG32 iRetVal;

	if((iRetVal = pthread_mutex_lock(mutex)) != 0)

	{

#ifdef     DBG

		printf("\n RelayId %d: Locked Position: %s",RelayId,Position);

		printf("\n RelayId %d: LockThreadMutex: Error in Locking Mutex Error no = %d\n",RelayId,iRetVal);

#endif

		kill(getpid(),SIGTERM);

	}

}





void WaitForMaxThreadCond(LONG32 ThreadFlag)

{

	switch(ThreadFlag)

	{

		case READ_THREAD:

			LockThreadMutex(&ReadThreadLock, "WaitForMaxThreadCond");

			if(NoOfReadThreads >= MAX_READ_THREADS)

			{

				printf("\num of active thread :%d",NoOfReadThreads);

				if((pthread_cond_wait(&MaxReadThreadCondVar,&ReadThreadLock) ) < 0)

				{

					printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

					exit(1);

				}

			}

			UnLockThreadMutex(&ReadThreadLock, "WaitForMaxThreadCond");		

			return;



		case WRITE_THREAD:

			printf("\n Check for max write thread :%d",NoOfWriteThreads);

			LockThreadMutex(&WriteThreadLock, "WaitForMaxThreadCond");

			if(NoOfWriteThreads >= MAX_WRITE_THREADS)

			{

				printf ("\n\t Here for exceeding the threads " ) ;

				if((pthread_cond_wait(&MaxWriteThreadCondVar,&WriteThreadLock) ) < 0)

				{

					printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

					exit(1);

				}

			}

			UnLockThreadMutex(&WriteThreadLock, "WaitForMaxThreadCond");		

			return;



		case WRITE_DLOAD_THREAD:

			LockThreadMutex(&WriteDloadThreadLock, "WaitForMaxThreadCond");

			if(NoOfWriteDloadThreads >= MAX_WRITE_DLOAD_THREADS)

			{

				if((pthread_cond_wait(&MaxWriteDloadThreadCondVar,&WriteDloadThreadLock) ) < 0)

				{

					printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

					exit(1);

				}

			}

			UnLockThreadMutex(&WriteDloadThreadLock, "WaitForMaxThreadCond");		

			return;



		case WRITE_IOR_THREAD:

			LockThreadMutex(&WriteIORThreadLock, "WaitForMaxThreadCond");

			if(NoOfWriteIORThreads >= MAX_WRITE_IOR_THREADS)

			{

				if((pthread_cond_wait(&MaxWriteIORThreadCondVar,&WriteIORThreadLock) ) < 0)

				{

					printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

					exit(1);

				}

			}

			UnLockThreadMutex(&WriteIORThreadLock, "WaitForMaxThreadCond");		

			return;



		default:

			printf("\n RelayId %d: Wrong argument passed to the WaitForMaxThreadCond function",RelayId);

			return;

	}

}





void SignalReadThreadKillCond(LONG32 ThreadFlag)

{

	switch(ThreadFlag)

	{

		case READ_THREAD:

			if(RelayId ==0)

				return;

			printf("\n read thread :%d",NoOfReadThreads);

			LockThreadMutex(&ReadThreadLock,"ReleasingReadThread");

			NoOfReadThreads--;

			if((pthread_cond_signal(&MaxReadThreadCondVar) ) < 0)

			{

				printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

				exit(1);

			}

			UnLockThreadMutex(&ReadThreadLock,"ReleasingReadThread");

			printf("\n SRTKillCond::RelayId %d: No of Read Thread After Killing is %d",RelayId,NoOfReadThreads);

			return;



		case WRITE_THREAD:

			LockThreadMutex(&WriteThreadLock,"ReleasingWriteThread");

			NoOfWriteThreads--;

			if((pthread_cond_signal(&MaxWriteThreadCondVar) ) < 0)

			{

				printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

				exit(1);

			}

			UnLockThreadMutex(&WriteThreadLock,"ReleasingWriteThread");

			printf("\n SRTKillCond::RelayId %d: No of Write Thread After Killing is %d",RelayId,NoOfWriteThreads);

			return;



		case WRITE_DLOAD_THREAD:

			LockThreadMutex(&WriteDloadThreadLock,"ReleasingWriteDloadThread");

			NoOfWriteDloadThreads--;

			if((pthread_cond_signal(&MaxWriteDloadThreadCondVar) ) < 0)

			{

				printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

				exit(1);

			}

			UnLockThreadMutex(&WriteDloadThreadLock,"ReleasingWriteDloadThread");

			printf("\n SRTKillCond::RelayId %d: No of Write Dload Thread After Killing is %d",RelayId,NoOfWriteDloadThreads);

			return;



		case WRITE_IOR_THREAD:

			LockThreadMutex(&WriteIORThreadLock,"ReleasingWriteIORThread");

			NoOfWriteIORThreads--;

			if((pthread_cond_signal(&MaxWriteIORThreadCondVar) ) < 0)

			{

				printf("\n RelayId %d: Error While waiting for condition in READ THREAD",RelayId);

				exit(1);

			}

			UnLockThreadMutex(&WriteIORThreadLock,"ReleasingWriteIORThread");

			printf("\n SRTKillCond::RelayId %d: No of Write IOR Thread After Killing is %d",RelayId,NoOfWriteIORThreads);

			return;



		default:

			printf("\n RelayId %d: Wrong argument passed to the SignalReadThreadKillCond function",RelayId);

			return;

	}

}



void CleanSocketResources(  LONG32 lIndex)

{

	LONG32	Len;

	LONG32	lRetval;

	LONG32	lSocket=0;

	LONG32	Dummy;

	CHAR	Mesg_Buf[MAX_PACKET_SIZE];

	LockThreadMutex(&(UserSocketTable[lIndex].UserSocketLock),"CleaningSocket");



	if(UserSocketTable[lIndex].User != SPACE)

	{

		AccessUsrRlyShm(&(UserSocketTable[lIndex].User),DELETE);/* */


	}

	printf("\n CSR::RelayId %d: Index Got : %d", RelayId,lIndex);

	memset(&UserSocketTable[lIndex].User,'\0',USER_ID_LEN);



	if ( UserSocketTable[lIndex].Socket > 2)  /* Other than STDIN, STDOUT and STDERR fd's */
	{

		lSocket		=	UserSocketTable[lIndex].Socket;

	}
	else
	{

		printf("Incorrect UserSocketTable[lIndex].Socket : %d",UserSocketTable[lIndex].Socket);
		UnLockThreadMutex(&(UserSocketTable[lIndex].UserSocketLock),"CleaningSocket");

		return;

	}





	/**** lSocket     =   UserSocketTable[lIndex].Socket; ******/



	printf("\n CSR::RelayId %d: Going To Close The Socket : %d,lSocket: %d , UserSocketTable[lIndex].User:%s:",RelayId,UserSocketTable[lIndex].Socket,lSocket,UserSocketTable[lIndex].User);



	LockThreadMutex(&ActiveSocketLock, "CleaningSocket");

	printf("\n Alok Before FD_CLR in CleanSocket Resour");

	FD_CLR(UserSocketTable[lIndex].Socket,&ActiveSocketSet);
	printf("\n Alok After FD_CLR in CleanSocket Resour");

	UnLockThreadMutex(&ActiveSocketLock, "CleaningSocket");

	printf("\n Alok After UnLockThreadMutex in CleanSocket Resour");



	/*

	 * A dummy byte is written to the pipe to make the select call return and the socket can be closed without 

	 * waiting for the select call to return.

	 */
	printf("\n Alok Before LockThreadMutex in CleanSocket Resour");

	LockThreadMutex(&DummyPipeLock,"WriteToPipe");
	printf("\n Alok After LockThreadMutex in CleanSocket Resour");

	write(DummyPipe[1],&Dummy,sizeof(LONG32));

	printf("\n Alok After write in CleanSocket Resour");

	UnLockThreadMutex(&DummyPipeLock,"WriteToPipe");

	printf("\n Alok After UnLockThreadMutex for DummyPipeLock in CleanSocket Resour");


	LockThreadMutex(&ActiveSocketLock, "CleaningSocket");

	printf("\n After LockThreadMutex before closing socket :");
	if ( lSocket != 0 )
	{
		/***		printf("\n Alok Before   shutdown socket in CleanSocket Resour");
		  lRetval = shutdown(lSocket,2);**********************/
		printf("\n Alok Before   closing socket in CleanSocket Resour");
		lRetval = close(lSocket);		
		printf("\n Alok After   closing socket in CleanSocket Resour lRetval is :%d: ",lRetval);
		/***	lRetval = shutdown(lSocket,2);		***/
		usleep(500);
	}
	else
	{
		printf("\n ERROR:2167: lSocket [%d]",lSocket);
	}
	printf("\n After before making that socket as unused :");

	UserSocketTable[lIndex].Socket = UNUSED;
	printf("\n Alok After   UserSocketTable.Socket = UNUSED  CleanSocket Resour Index %d",lIndex);

	UnLockThreadMutex(&ActiveSocketLock, "CleaningSocket");
	printf("\n After UnLockThreadMutex and  closing socket :");


	UnLockThreadMutex(&(UserSocketTable[lIndex].UserSocketLock),"CleaningSocket");
	printf("\n Alok After   UnLockThreadMutex in the end  CleanSocket Resour");

}







LONG32 Recv(LONG32 Socket,CHAR *Buf, LONG32 *Len)

{



	LONG32 BytesRead =0;
	LONG32	iRetVal;
	LONG32	TotalBytes = sizeof(struct REQ_HEADER );
	LONG32	BytesLeft;	
	char 	Temp_Buf[sizeof(struct REQ_HEADER )];


	memset(Temp_Buf,'\0',sizeof(struct REQ_HEADER));
	BytesLeft = TotalBytes;
	while(BytesRead < TotalBytes)
	{

		if((iRetVal = recv(Socket,Temp_Buf+BytesRead,BytesLeft,MSG_PEEK )) <= 0 )
		{
			return ERROR;
		}

		BytesRead += iRetVal;
		BytesLeft -= iRetVal;
	}


	TotalBytes = BytesLeft = ((struct REQ_HEADER *)Temp_Buf) -> iRequestLength;
	BytesRead = 0;
	printf("\n RelayId %d: going to recv Message of bytes = %d",RelayId,TotalBytes);
	while(BytesRead < TotalBytes)
	{

		if((iRetVal = recv(Socket,Buf+BytesRead,BytesLeft,!MSG_WAITALL)) <= 0)
		{
			printf("Error in RECV ...!!!!!");
			return ERROR;
		}

		BytesRead += iRetVal;
		BytesLeft -= iRetVal;
		printf("\n ALOK  RelayId %d: BytesRead :%d going to recv Message of bytes = %d iRetVal :%d: BytesLeft:%d",RelayId,BytesRead,TotalBytes,iRetVal,BytesLeft);
	}


	*Len = BytesRead;
	return BytesRead;

}



LONG32 Send(LONG32 Socket,CHAR *Buf, LONG32 *Len)

{
	LONG32 BytesSend =0;
	LONG32	iRetVal;
	LONG32	TotalBytes = *Len;
	LONG32	BytesLeft = *Len;	

	printf("\n Socket Send = [%d] BytesSend :%d: TotalBytes :%d:",Socket,BytesSend,TotalBytes);

	while(BytesSend < TotalBytes)
	{
		/***	if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,0)) <= 0)****/
		if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,MSG_NOSIGNAL)) <= 0)
		{
			printf("\n Error in Sending in SEND function need to check the issue");
			perror("in Send function");
			return ERROR;
		}

		BytesSend += iRetVal;
		BytesLeft -= iRetVal;
	}
	printf("\n RelayId %d: Total Bytes written to socket %d is %d",RelayId,Socket,BytesSend);
	return BytesSend;
}



LONG32 ProcessLogOnRequest(LONG32 *Index,CHAR *UserId)
{
	LONG32	Count;

	printf("\n RelayId %d: UserId Recieved is %s length %d",RelayId, UserId, strlen(UserId));

	LockThreadMutex(&UserSocketTableLock,"CheckingUserExistUserSocketTable")	;

	printf("\n after locking CheckingUserExistUserSocketTable");
	for(Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS; Count++)
	{

		if((memcmp(&(UserSocketTable[Count].User), UserId,USER_ID_LEN)== 0 && strlen(UserSocketTable[Count].User) == strlen(UserId)) && *Index != Count)
		{
			CleanSocketResources(Count);
		}
	}
	printf("\n After for loop in ProcessLogOnRequest ");
	UnLockThreadMutex(&UserSocketTableLock,"CheckingUserExistUserSocketTable")	;
	printf("\n Alok in ProcessLogOnRequest after UnLockThreadMutex ");

	LockThreadMutex(&UserSocketTable[*Index].UserSocketLock,"InsertingUser");
	printf("\n Alok in ProcessLogOnRequest after LockThreadMutex ");
	memset(&(UserSocketTable[*Index].User),'\0',USER_ID_LEN);
	printf("\n Alok in ProcessLogOnRequest after memset User ");
	memcpy(&(UserSocketTable[*Index].User), UserId,strlen(UserId));
	printf("\n Alok in ProcessLogOnRequest after memcpy User ");
	/***	memcpy(&(UserSocketTable[*Index].ClientId),ClientId,CLIENT_ID_LEN);***/
	printf("\n RelayId %d: UserId Added is %s--SOCKET =[%d]",RelayId,UserSocketTable[*Index].User,UserSocketTable[*Index].Socket);

	if(UserSocketTable[*Index].User != SPACE)
	{
		printf("\n Alok before AccessUsrRlyShm ");
		AccessUsrRlyShm(&(UserSocketTable[*Index].User),INSERT);/**/
		printf("\n Alok After AccessUsrRlyShm ");
	}

	UnLockThreadMutex(&UserSocketTable[*Index].UserSocketLock,"InsertingUser");
	printf("\n Alok in ProcessLogOnRequest after UnLockThreadMutex InsertingUser ");


	return TRUE;

}



LONG32	AccessUsrRlyShm(CHAR *User, LONG32 Flg)	/*****  *******/

{

	struct 	DWS_ADAPTER_USER_ARRAY *pSTWUsrRlyArryShm;
	struct 	DWS_ADAPTER_USER 	*pSTWUsrRly;

	LONG32	Count;
	LONG32	iRetVal		= FALSE;

	LockShm(DWSAdapterUserShm);

	printf("\n alok in shared memory (INIT=0,INSERT=1,DELETE=2,SELECT=3)  Flg is :%d ",Flg);

	/************/
	if((pSTWUsrRlyArryShm = (struct DWS_ADAPTER_USER_ARRAY *) OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE)) == (struct DWS_ADAPTER_USER_ARRAY *) ERROR)
	{
		printf("\n RelayId %d: Error Opening STW User Relay Shared Memory ",RelayId);
		exit(1);
	}
	/***************/
	/******
	  pSTWUsrRlyArryShm = OpenSharedMemory(DWSAdapterUserShm,DWSAdapterUserShm_SIZE) ;

	  printf("\n ALok here %d: ERROR is :%d:",*( (int *) pSTWUsrRlyArryShm),ERROR);

	  if ( *( (int *) pSTWUsrRlyArryShm) == ERROR )
	  {
	  printf("\n RelayId %d: Error Opening STW User Relay Shared Memory ",RelayId);
	  } 
	 *******/	

	printf("\n alok in shared memory 2 ");
	pSTWUsrRly = pSTWUsrRlyArryShm;

	if ( Flg == INIT)
	{
		for ( Count=0; Count<MAX_DWS_USERS; Count++ )
		{
			pSTWUsrRly->iRelayId =   UNUSED  ;
			pSTWUsrRly->ProcessId    =   UNUSED  ;
			memset(&(pSTWUsrRly->sUser),'\0',USER_ID_LEN);
			pSTWUsrRly++;

		}
		printf("\n RelayId %d : Shared Memory Initialized",RelayId);
		iRetVal	=	TRUE;
	}
	else if ( Flg == INSERT)
	{
		printf("\n RelayId %d: UserId added is %s and length = %d", RelayId,User,strlen(User));
		for(Count = 0;Count < MAX_DWS_USERS; Count++)
		{
			if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId != UNUSED)
			{
				pSTWUsrRly->iRelayId = RelayId;
				pSTWUsrRly->ProcessId = getpid();
				memcpy(&(pSTWUsrRly->sUser),User,strlen(User));

				printf("\n RelayId %d: User Updated, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
				iRetVal	=	TRUE;
				break;
			}
			pSTWUsrRly++;
		}
		if( iRetVal == FALSE)
		{

			printf("\n AccessUsrRlyShm:: UserId: %s==Len %d Record Does Not Exist. Doing Fresh Insertion In Shm",User,strlen(User));
			pSTWUsrRly = pSTWUsrRlyArryShm;
			for(Count = 0;Count < MAX_DWS_USERS; Count++)
			{
				if(pSTWUsrRly->iRelayId == UNUSED) 
				{
					pSTWUsrRly->iRelayId = RelayId;
					pSTWUsrRly->ProcessId = getpid();
					memcpy(&(pSTWUsrRly->sUser),User,strlen(User));
					printf("\n RelayId %d: User Added, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
					iRetVal	=	TRUE;
					break;

				}	
				pSTWUsrRly++;
			}						

		}

	}
	else if ( Flg == DELETE  && User[0]!= NULL)
	{
		for(Count = 0;Count < MAX_DWS_USERS; Count++)
		{
			if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId == RelayId && strlen(pSTWUsrRly->sUser)== strlen(User))
			{
				printf("\n RelayId %d: User Delete, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);

				memset(&(pSTWUsrRly->sUser),'\0',USER_ID_LEN);
				pSTWUsrRly->iRelayId = UNUSED;
				pSTWUsrRly->ProcessId = UNUSED;

				iRetVal	=	TRUE;
			}
			pSTWUsrRly++;
		}
	}
	else if (Flg == SELECT && User[0]!= NULL)
	{

		for(Count = 0;Count < MAX_DWS_USERS; Count++)
		{
			if(memcmp(&(pSTWUsrRly->sUser),User,USER_ID_LEN) == 0 && pSTWUsrRly->iRelayId == RelayId && strlen(pSTWUsrRly->sUser)== strlen(User) )
			{
				printf("\n RelayId %d: User Selected, Details RelayId = %d, ProcessId = %d, User = %.*s",RelayId,pSTWUsrRly->iRelayId,pSTWUsrRly->ProcessId,strlen(User),pSTWUsrRly->sUser);
				iRetVal =       TRUE;
				break;
			}
			pSTWUsrRly++;
		}
	}

	if((CloseSharedMemory((void *) pSTWUsrRlyArryShm)) == ERROR)
	{

		printf("\n RelayId %d: Error in closing STW User Relay Shared Memory Errno = %d",RelayId,errno);
		exit(1);

	}
	printf("\n Before Unlock DWSAdapterUserShm");
	UnLockShm(DWSAdapterUserShm);
	return iRetVal;

}





/****

  This function checks for the entry of the user in the socket table and the shared memory.

  The function checks for following conditions:-

  1.	If User Exists in User Socket Table only then send Index as Count and return value as SOCKET_EXIST.

  2.	If User Exists in both User Socket Table and the shared memory then send Index as Count and return TRUE.

  3.	If User Doesn't Exists then return ERROR.

 *****/

LONG32 Is_Valid_User(CHAR *UserId, LONG32 *Index)

{

	LONG32	Count;
	LONG32	RtrnFlg;	

	printf("\n MAX_NO_OF_USER_SOCKETS	::	%d",MAX_NO_OF_USER_SOCKETS);	

	for(Count = 0 ; Count < MAX_NO_OF_USER_SOCKETS; Count++)

	{
		if(UserSocketTable[Count].Socket != UNUSED)
		{
			if(memcmp(&(UserSocketTable[Count].User), UserId,strlen(UserId))== 0 && strlen(UserSocketTable[Count].User) == strlen(UserId))
			{
				*Index = Count;
				printf("\n Hey I am here ");
				if((AccessUsrRlyShm(&(UserSocketTable[Count].User),SELECT)) == TRUE)
					return TRUE;
				else
					return SOCKET_EXIST;
			}
		}
	}
	return ERROR;
}





void *CleanUPOPThread(void *arg)

{

	LONG32 *OPSocketList = (LONG32 *)arg;

	LONG32 Count=0;



	printf("\nCleanUPOPThread: Cleaning up OrderProcessor Thread resources");

	for(Count=0;Count<MAX_NO_OF_OP && OPSocketList[Count] != UNUSED ;Count++)

	{

		close(OPSocketList[Count]);
		/***	shutdown(OPSocketList[Count],2); ***/

	}



	return;

}



void Str_Trim(CHAR *String)

{

	int block = 0;

	for(block = 0; String[block] != ' ' && String[block] != '\0' ; block++);

	String[block] = '\0';

}

BOOL GetTimeofDay()
{
	struct  timeval StartPoint1 , EndPoint1 ;
	struct  timezone tzp;

	StartPoint1.tv_sec = StartPoint1.tv_sec+19800;
	gettimeofday(&StartPoint1, &tzp);
	printf("\n Time of entry is :%d:",StartPoint1.tv_sec);
}

BOOL Find_Max_User(LONG32 *MaxCurrentUser)
{
	LONG32  Count   =   0   ;
	LONG32  MaxUser =   0   ;
	LONG32  shmid   =   0   ;

	printf("\n Inside [Find_Max_User]");
	struct  user_relay_array    *ptr        ;
	struct  user_relay_array    *tempptr    ;
	LockShm(DirRelShm);
	ptr=( struct user_relay_array *) OpenSharedMemory( DirRelShm , DirRelShm_SIZE ) ;

	if(*(( LONG32 * )ptr )  == ERROR )
	{
		/*        logDebug1("Error in Opening the Shared Memory " )   ;*/
		exit( 1 ) ;
	}

	tempptr =ptr;
	printf("\n Before for loop");
	for( Count = 0 ; Count < MAX_DWS_USERS; Count++ )
	{
		if(UserSocketTable[Count].Socket != UNUSED )
		{
			printf("\n  MaxUser [%d]",MaxUser);
			MaxUser++;
		}
	}
	*MaxCurrentUser = MaxUser;
	CloseSharedMemory( (void *)ptr);
	UnLockShm( DirRelShm);
	printf("\n Leaving [Find_Max_User]");
	printf("\n MaxCurrentUser [%d]",*MaxCurrentUser);
	return( TRUE );
}

void decryptlicences(char password[],int key)
{



	unsigned int i;
	for(i=0;i<strlen(password);++i)
	{
		password[i] = password[i] + key;
	}
}


void SignalHandlerSigChldParent (int dummy)
{
	int     i;
	int     Status;
	pid_t   ProcessId;

	for ( i = 0 ; i <= MAX_NO_OF_PROCESS ; i++ )
	{
		if ( ProcessTable [i].ProcessId != UNUSED )
		{
			if ((ProcessId = waitpid(ProcessTable [i].ProcessId,&Status,WNOHANG))>0)
			{
				if(ProcessId == ProcessTable[i].ProcessId )
				{
					UpdateForkProcessForRestart (ProcessTable[i].ProcessId );
					DeleteUserSHM (ProcessTable[i].RelayId );

				}
			}
		}
	}
}/*************** End of SignalHandlerSigChldParent *******************/

void SignalHandlerSigTermParent (int dummy)
{
	int     i;

	sigprocmask(SIG_BLOCK,&SignalSet ,NULL);


	for ( i = 0 ; i < MAX_NO_OF_PROCESS ; i++ )
	{
		if (ProcessTable [i].ProcessId != UNUSED )
		{
			kill(ProcessTable [i] .ProcessId,SIGTERM);
		}
	}

	exit(1);

}/************* End of SignalHandlerSigTermParent******************/



void UpdateForkProcessForRestart ( int ForkInd )
{
	int     i;

	for ( i =0 ; i<MAX_NO_OF_PROCESS; i++ )
	{
		if ( ProcessTable[i].ProcessId  == ForkInd  )
		{
			ProcessTable[i].ProcessId = RESTART;
			break;
		}
	}
}

void DeleteUserSHM( int ProcessId )
{
	LONG32  Count   =   0   ;
	LONG32  MaxUser =   0   ;
	LONG32  shmid   =   0   ;

	printf("\n Inside [Find_Max_User]");
	struct  user_relay_array    *ptr        ;
	struct  user_relay_array    *tempptr    ;
	LockShm(DirRelShm);
	ptr=( struct user_relay_array *) OpenSharedMemory( DirRelShm , DirRelShm_SIZE ) ;

	if(*(( LONG32 * )ptr )  == ERROR )
	{
		/*        logDebug1("Error in Opening the Shared Memory " )   ;*/
		exit( 1 ) ;
	}

	tempptr =ptr;
	printf("\n Before for loop");
	for( Count = 0 ; Count < MAX_USERS ; Count++ )
	{
		if(ptr->user_relay[Count].iRelayId == ProcessId )
		{
			ptr->user_relay[Count].iUserId = UNUSED;
			ptr->user_relay[Count].iRelayId = UNUSED;
			ptr->user_relay[Count].iCheck = UNUSED;
			ptr->user_relay[Count].iProcessId = UNUSED;
		}
	}
	CloseSharedMemory( (void *)ptr);
	UnLockShm( DirRelShm);
}


