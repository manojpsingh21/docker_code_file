/*
 *  * librdkafka - Apache Kafka C library
 *   *
 *    * Copyright (c) 2019, Magnus Edenhill
 *     * All rights reserved.
 *      *
 *       * Redistribution and use in source and binary forms, with or without
 *        * modification, are permitted provided that the following conditions are met:
 *         *
 *          * 1. Redistributions of source code must retain the above copyright notice,
 *           *    this list of conditions and the following disclaimer.
 *            * 2. Redistributions in binary form must reproduce the above copyright notice,
 *             *    this list of conditions and the following disclaimer in the documentation
 *              *    and/or other materials provided with the distribution.
 *               *
 *                * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *                 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *                  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *                   * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *                    * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *                     * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *                      * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *                       * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *                        * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *                         * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *                          * POSSIBILITY OF SUCH DAMAGE.
 *                           */

/**
 *  * Simple high-level balanced Apache Kafka consumer
 *   * using the Kafka driver from librdkafka
 *    * (https://github.com/edenhill/librdkafka)
 *     */

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include "IPCS.h"
#include "IntStruct.h"
#include "Defination.h"

/* Typical include path would be <librdkafka/rdkafka.h>, but this program
 *  * is builtin from within the librdkafka source tree and thus differs. */

#include "rdkafka.h"


static volatile sig_atomic_t run = 1;

/**
 *  * @brief Signal termination of program
 *   */
static void stop(int sig) {
        run = 0;
}



/**
 *  * @returns 1 if all bytes are printable, else 0.
 *   */
static int is_printable(const char *buf, size_t size) {
        size_t i;

        for (i = 0; i < size; i++)
                if (!isprint((int)buf[i]))
                        return 0;

        return 1;
}


int main(int argc, char **argv) {
        rd_kafka_t *rk;          /* Consumer instance handle */
        rd_kafka_conf_t *conf;   /* Temporary configuration object */
        rd_kafka_resp_err_t err; /* librdkafka API error code */
        char errstr[512];        /* librdkafka API error reporting buffer */
        const char *brokers;     /* Argument: broker list */
        const char *groupid;     /* Argument: Consumer group id */
        char **topics;           /* Argument: list of topics to subscribe to */
        int topic_cnt;           /* Number of topics to subscribe to */
        rd_kafka_topic_partition_list_t *subscription; /* Subscribed topics */
        int i;
	int iCnt = 0;
        CHAR sResponse [ULTRA_DOUBLE_MAX_QUERY_SIZE];
        memset( sResponse,'\0',ULTRA_DOUBLE_MAX_QUERY_SIZE);

        /*
 *          * Argument validation
 *                   */
        if (argc < 4) {
                fprintf(stderr,
                        "%% Usage: "
                        "%s <broker> <group.id> <topic1> <topic2>..\n",
                        argv[0]);
                return 1;
        }

        brokers   = argv[1];
        groupid   = argv[2];
        topics    = &argv[3];
        topic_cnt = argc - 3;

	printf("\n brokers 	:%s:",brokers);
	printf("\n groupid	:%s:",groupid);
	printf("\n topics	:%s:",&topics);
	printf("\n topic_cnt	:%d:",topic_cnt);


        /*
 *          * Create Kafka client configuration place-holder
 *                   */
        conf = rd_kafka_conf_new();

        /* Set bootstrap broker(s) as a comma-separated list of
 *          * host or host:port (default port 9092).
 *                   * librdkafka will use the bootstrap brokers to acquire the full
 *                            * set of brokers from the cluster. */
        if (rd_kafka_conf_set(conf, "bootstrap.servers", brokers, errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

        /* Set the consumer group id.
 *          * All consumers sharing the same group id will join the same
 *                   * group, and the subscribed topic' partitions will be assigned
 *                            * according to the partition.assignment.strategy
 *                                     * (consumer config property) to the consumers in the group. */
        if (rd_kafka_conf_set(conf, "group.id", groupid, errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

        /* If there is no previously committed offset for a partition
 *          * the auto.offset.reset strategy will be used to decide where
 *                   * in the partition to start fetching messages.
 *                            * By setting this to earliest the consumer will read all messages
 *                                     * in the partition if there was no previously committed offset. */
        if (rd_kafka_conf_set(conf, "auto.offset.reset", "earliest", errstr,
                              sizeof(errstr)) != RD_KAFKA_CONF_OK) {
                fprintf(stderr, "%s\n", errstr);
                rd_kafka_conf_destroy(conf);
                return 1;
        }

        /*
 *          * Create consumer instance.
 *                   *
 *                            * NOTE: rd_kafka_new() takes ownership of the conf object
 *                                     *       and the application must not reference it again after
 *                                              *       this call.
 *                                                       */
        rk = rd_kafka_new(RD_KAFKA_CONSUMER, conf, errstr, sizeof(errstr));
        if (!rk) {
                fprintf(stderr, "%% Failed to create new consumer: %s\n",
                        errstr);
                return 1;
        }

        conf = NULL; /* Configuration object is now owned, and freed,
                      * by the rd_kafka_t instance. */
	//struct          ORDER_RESPONSE *Ord_Req;

        /* Redirect all messages from per-partition queues to
 *          * the main queue so that messages can be consumed with one
 *                   * call from all assigned partitions.
 *                            *
 *                                     * The alternative is to poll the main queue (for events)
 *                                              * and each partition queue separately, which requires setting
 *                                                       * up a rebalance callback and keeping track of the assignment:
 *                                                                * but that is more complex and typically not recommended. */
        rd_kafka_poll_set_consumer(rk);


        /* Convert the list of topics to a format suitable for librdkafka */
        subscription = rd_kafka_topic_partition_list_new(topic_cnt);
        for (i = 0; i < topic_cnt; i++)
                rd_kafka_topic_partition_list_add(subscription, topics[i],
                                                  /* the partition is ignored
 *                                                    * by subscribe() */
                                                  RD_KAFKA_PARTITION_UA);
	//rd_kafka_topic_partition_list_add(subscription,topics, 1)->offset = 65400;	
	//rd_kafka_topic_partition_list_set_offset(subscription,topics,1,64000);
	
	rd_kafka_topic_partition_t *part;
	
	if ((part = rd_kafka_topic_partition_list_find(subscription, topics, 0)))
	{
		printf("\n Last  Offset read :%d:",part->offset);
           	//part->offset = 65000;
		//rd_kafka_assign(rk, subscription);
        
		sleep(5);
	}
	else
	{
		printf("\n No  Offset read ::");
		sleep(5);
	}	
	fprintf(stderr,
                "%% Subscribed to %d topic(s), "
                "waiting for rebalance and messages...\n",
                subscription->cnt);

        /* Subscribe to the list of topics */
        err = rd_kafka_subscribe(rk, subscription);
        if (err) {
                fprintf(stderr, "%% Failed to subscribe to %d topics: %s\n",
                        subscription->cnt, rd_kafka_err2str(err));
                rd_kafka_topic_partition_list_destroy(subscription);
                rd_kafka_destroy(rk);
                return 1;
        }
		
	


        rd_kafka_topic_partition_list_destroy(subscription);

        /* Signal handler for clean shutdown */
        signal(SIGINT, stop);

        /* Subscribing to topics will trigger a group rebalance
 *          * which may take some time to finish, but there is no need
 *                   * for the application to handle this idle period in a special way
 *                            * since a rebalance may happen at any time.
 *                                     * Start polling for messages. */

        while (run) {
                rd_kafka_message_t *rkm;

                rkm = rd_kafka_consumer_poll(rk, 10);
                if (!rkm)
                        continue; /* Timeout: no message within 100ms,
                                   *  try again. This short timeout allows
                                   *                                     *  checking for `run` at frequent intervals.
                                   *                                                                        */

                /* consumer_poll() will return either a proper message
 *                  * or a consumer error (rkm->err is set). */
                if (rkm->err) {
                        /* Consumer errors are generally to be considered
 *                          * informational as the consumer will automatically
 *                                                   * try to recover from all types of errors. 
                        fprintf(stderr, "%% Consumer error: %s\n",
                               rd_kafka_message_errstr(rkm));
			***/
			printf("\nCaught Error\n");
                        rd_kafka_message_destroy(rkm);
                        continue;
                }

                /* Proper message. */
                printf("Message on %s [%" PRId32 "] at offset %" PRId64 ":\n",
                       rd_kafka_topic_name(rkm->rkt), rkm->partition,
                       rkm->offset);

                /* Print the message key. */
                if (rkm->key && is_printable(rkm->key, rkm->key_len))
                        printf(" Key: %.*s\n", (int)rkm->key_len,
                               (const char *)rkm->key);
                else if (rkm->key)
                        printf(" Key: (%d bytes)\n", (int)rkm->key_len);

                /* Print the message value/payload. */
                if (rkm->payload && is_printable(rkm->payload, rkm->len))
		{
                        //printf(" Value: %.*s\n", (int)rkm->len, (const char *)rkm->payload);
                        printf("\n iCnt :%d:",iCnt++);
                }
	
		else if (rkm->payload)
		{
			
			LONG32	TransCode;
			LONG32  TransCode2;

			struct ORDER_RESPONSE *Ord_Resp= (struct ORDER_RESPONSE *)(rkm->payload);
			struct C2D_VIEW_NET_POSITION *Ord_Resp2= (struct C2D_VIEW_NET_POSITION *)(rkm->payload);

			logDebug2("---------==================|||||||||||||||||||||||=================---------");
			logDebug2("---------===============WHILE LOOP OF KAFKA-CONSUMER===============---------");
			logDebug2("---------==================|||||||||||||||||||||||=================---------");


                        logDebug2("Reading struct INT_COMMON_RESP_HDR From Kafka....");
			TransCode = (( struct ORDER_RESPONSE * )Ord_Resp)->IntRespHeader.iMsgCode;
			TransCode2 = (( struct C2D_VIEW_NET_POSITION * )Ord_Resp2)->RespHeader.iMsgCode;

			if(TransCode2== TC_INT_CON_DEL_POS_RESP || TransCode2 == TC_INT_CON_DEL_IP_POS_RESP)
			{

				logDebug2("------------MsgCode Received in Transcode2:%d:------------",TransCode2);

				sprintf(sResponse,"iMsgLength-%d|iMsgCode-%d|sExcgId-%s|iErrorId-%d|iUserId-%llu|cSource-%c|iTimeStamp-%d|cSegment-%c|sSecurityId-%s|sExchId-%s|iBuyQty-%d|iBuyQtyCF-%d|iBuyQtyDay-%d|fBuyVal-%f|fBuyValCF-%f|fBuyValDay-%f|fBuyAvg-%f|iSellQty-%d|iSellQtyCF-%d|iSellQtyDay-%d|fSellVal-%f|fSellValCF-%f|fSellValDay-%f|fSellAvg-%f|iNetQty-%d|fNetVal-%f|fNetAvg-%f|fGrossQty-%f|fGrossVal-%f|cMktType-%s|cProductId-%c|fRelaisedProfit-%f|fMTM-%f|sClientId-%s|cSegment-%c|iRef_ID-%d|",Ord_Resp2->RespHeader.iMsgLength,Ord_Resp2->RespHeader.iMsgCode,Ord_Resp2->RespHeader.sExcgId,Ord_Resp2->RespHeader.iErrorId,Ord_Resp2->RespHeader.iUserId,Ord_Resp2->RespHeader.cSource,Ord_Resp2->RespHeader.iTimeStamp,Ord_Resp2->RespHeader.cSegment,Ord_Resp2->sSecurityID,Ord_Resp2->sExchId,Ord_Resp2->iBuyQty,Ord_Resp2->iBuyQtyCF,Ord_Resp2->iBuyQtyDay,Ord_Resp2->fBuyVal,Ord_Resp2->fBuyValCF,Ord_Resp2->fBuyValDay,Ord_Resp2->fBuyAvg,Ord_Resp2->iSellQty,Ord_Resp2->iSellQtyCF,Ord_Resp2->iSellQtyDay,Ord_Resp2->fSellVal,Ord_Resp2->fSellValCF,Ord_Resp2->fSellValDay,Ord_Resp2->fSellAvg,Ord_Resp2->iNetQty,Ord_Resp2->fNetVal,Ord_Resp2->fNetAvg,Ord_Resp2->fGrossQty,Ord_Resp2->fGrossVal,Ord_Resp2->cMktType,Ord_Resp2->cProductId,Ord_Resp2->fRelaisedProfit,Ord_Resp2->fMTM,Ord_Resp2->sClientId,Ord_Resp2->cSegment,Ord_Resp2->iRef_ID);
				printf("\n sResponse :%s: \n",sResponse);
			


			}
			else
			{

				logDebug2("------------MsgCode Received in Transcode:%d:------------",TransCode);

				sprintf(sResponse,"iMsgLength-%d|iMsgCode-%d|sExcgId-%s|iErrorId-%d|iUserId-%llu|cSource-%c|iTimeStamp-%d|cSegment-%c|iLegValue-%d|sSecurityId-%s|sEntityId-%s|sClientId-%s|sExchOrderID-%s|cProductId-%c|cBuyOrSell-%c|iOrderType-%d|iOrderValidity-%d|iDiscQty-%d|iDiscQtyRem-%d|iTotalQtyRem-%d|iTotalQty-%d|iLastTradedQty-%d|iTotalTradedQty-%d|iMinFillQty-%d|fPrice-%f|fTriggerPrice-%f|fOrderNum-%f|iSerialNum-%d|sTradeNo-%s|fTradePrice-%f|fAlgoOrderNo-%f|iStratergyId-%d|cOffMarketFlg-%c|cProCli-%c|cUserType-%c|sOrdEntryTime-%s|sTransacTime-%s|sRemarks-%s|iMktType-%d|sReasDesc-%s|cMarkProFlag-%c|fMarkProVal-%f|cParticipantType-%c|sSettlor-%s|cGTCFlag-%c|cEncashFlag-%c|sPanID-%s|iGrpId-%d",Ord_Resp->IntRespHeader.iMsgLength,Ord_Resp->IntRespHeader.iMsgCode,Ord_Resp->IntRespHeader.sExcgId,Ord_Resp->IntRespHeader.iErrorId,Ord_Resp->IntRespHeader.iUserId,Ord_Resp->IntRespHeader.cSource,Ord_Resp->IntRespHeader.iTimeStamp,Ord_Resp->IntRespHeader.cSegment,Ord_Resp->iLegValue,Ord_Resp->sSecurityId,Ord_Resp->sEntityId,Ord_Resp->sClientId,Ord_Resp->sExchOrderID,Ord_Resp->cProductId,Ord_Resp->cBuyOrSell,Ord_Resp->iOrderType,Ord_Resp->iOrderValidity,Ord_Resp->iDiscQty,Ord_Resp->iDiscQtyRem,Ord_Resp->iTotalQtyRem,Ord_Resp->iTotalQty,Ord_Resp->iLastTradedQty,Ord_Resp->iTotalTradedQty,Ord_Resp->iMinFillQty,Ord_Resp->fPrice,Ord_Resp->fTriggerPrice,Ord_Resp->fOrderNum,Ord_Resp->iSerialNum,Ord_Resp->sTradeNo,Ord_Resp->fTradePrice,Ord_Resp->fAlgoOrderNo,Ord_Resp->iStratergyId,Ord_Resp->cOffMarketFlg,Ord_Resp->cProCli,Ord_Resp->cUserType,Ord_Resp->sOrdEntryTime,Ord_Resp->sTransacTime,Ord_Resp->sRemarks,Ord_Resp->iMktType,Ord_Resp->sReasonDesc,Ord_Resp->cMarkProFlag,Ord_Resp->fMarkProVal,Ord_Resp->cParticipantType,Ord_Resp->sSettlor,Ord_Resp->cGTCFlag,Ord_Resp->cEncashFlag,Ord_Resp->sPanID,Ord_Resp->iGrpId);

				printf("\n sResponse :%s: \n",sResponse);
			}

				printf(" Value: (%d bytes)\n", (int)rkm->len);

/*

        logTimestamp("-------------------Start Printing-------------------");
        logDebug2("Ord_Resp->IntRespHeader.iMsgLength   :%d:",Ord_Resp->IntRespHeader.iMsgLength);
        logDebug2("Ord_Resp->IntRespHeader.iMsgCode     :%d:",Ord_Resp->IntRespHeader.iMsgCode);
        logDebug2("Ord_Resp->IntRespHeader.sExcgId      :%s:",Ord_Resp->IntRespHeader.sExcgId);
        logDebug2("Ord_Resp->IntRespHeader.iErrorId     :%d:",Ord_Resp->IntRespHeader.iErrorId);
        logDebug2("Ord_Resp->IntRespHeader.iUserId      :%llu:",Ord_Resp->IntRespHeader.iUserId);
        logDebug2("Ord_Resp->IntRespHeader.cSource      :%c:",Ord_Resp->IntRespHeader.cSource);
        logDebug2("Ord_Resp->IntRespHeader.iTimeStamp   :%d:",Ord_Resp->IntRespHeader.iTimeStamp);
        logDebug2("Ord_Resp->IntRespHeader.cSegment     :%c:",Ord_Resp->IntRespHeader.cSegment);

        logDebug2("Ord_Resp->iLegValue          :%d:",Ord_Resp->iLegValue);
        logDebug2("Ord_Resp->sSecurityId        :%s:",Ord_Resp->sSecurityId);
        logDebug2("Ord_Resp->sEntityId          :%s:",Ord_Resp->sEntityId);
        logDebug2("Ord_Resp->sClientId          :%s:",Ord_Resp->sClientId);
        logDebug2("Ord_Resp->sExchOrderID       :%s:",Ord_Resp->sExchOrderID);
        logDebug2("Ord_Resp->cProductId         :%c:",Ord_Resp->cProductId);
        logDebug2("Ord_Resp->cBuyOrSell         :%c:",Ord_Resp->cBuyOrSell);
        logDebug2("Ord_Resp->iOrderType         :%d:",Ord_Resp->iOrderType);
        logDebug2("Ord_Resp->iOrderValidity     :%d:",Ord_Resp->iOrderValidity);
        logDebug2("Ord_Resp->iDiscQty           :%d:",Ord_Resp->iDiscQty);
        logDebug2("Ord_Resp->iDiscQtyRem        :%d:",Ord_Resp->iDiscQtyRem);
        logDebug2("Ord_Resp->iTotalQtyRem       :%d:",Ord_Resp->iTotalQtyRem);
        logDebug2("Ord_Resp->iTotalQty          :%d:",Ord_Resp->iTotalQty);
        logDebug2("Ord_Resp->iLastTradedQty     :%d:",Ord_Resp->iLastTradedQty);
        logDebug2("Ord_Resp->iTotalTradedQty    :%d:",Ord_Resp->iTotalTradedQty);
        logDebug2("Ord_Resp->iMinFillQty        :%d:",Ord_Resp->iMinFillQty);
        logDebug2("Ord_Resp->fPrice             :%f:",Ord_Resp->fPrice);
        logDebug2("Ord_Resp->fTriggerPrice      :%f:",Ord_Resp->fTriggerPrice);
        logDebug2("Ord_Resp->fOrderNum          :%f:",Ord_Resp->fOrderNum);
        logDebug2("Ord_Resp->iSerialNum         :%d:",Ord_Resp->iSerialNum);
        logDebug2("Ord_Resp->sTradeNo           :%s:",Ord_Resp->sTradeNo);
        logDebug2("Ord_Resp->fTradePrice        :%f:",Ord_Resp->fTradePrice);
        logDebug2("Ord_Resp->cHandleInst        :%c:",Ord_Resp->cHandleInst);
        logDebug2("Ord_Resp->fAlgoOrderNo       :%f:",Ord_Resp->fAlgoOrderNo);
        logDebug2("Ord_Resp->iStratergyId       :%d:",Ord_Resp->iStratergyId);
        logDebug2("Ord_Resp->cOffMarketFlg      :%c:",Ord_Resp->cOffMarketFlg);
        logDebug2("Ord_Resp->cProCli            :%c:",Ord_Resp->cProCli);
        logDebug2("Ord_Resp->cUserType          :%c:",Ord_Resp->cUserType);
        logDebug2("Ord_Resp->sOrdEntryTime      :%s:",Ord_Resp->sOrdEntryTime);
        logDebug2("Ord_Resp->sTransacTime       :%s:",Ord_Resp->sTransacTime);
        logDebug2("Ord_Resp->sRemarks           :%s:",Ord_Resp->sRemarks);
        logDebug2("Ord_Resp->iMktType           :%d:",Ord_Resp->iMktType);
        logDebug2("Ord_Resp->sReasDesc          :%s:",Ord_Resp->sReasonDesc);
        logDebug2("Ord_Resp->cMarkProFlag       :%c:",Ord_Resp->cMarkProFlag);
        logDebug2("Ord_Resp->fMarkProVal        :%f:",Ord_Resp->fMarkProVal);
        logDebug2("Ord_Resp->cParticipantType   :%c:",Ord_Resp->cParticipantType);
        logDebug2("Ord_Resp->sSettlor           :%s:",Ord_Resp->sSettlor);
        logDebug2("Ord_Resp->cGTCFlag           :%c:",Ord_Resp->cGTCFlag);
        logDebug2("Ord_Resp->cEncashFlag        :%c:",Ord_Resp->cEncashFlag);
        logDebug2("Ord_Resp->sPanID             :%s:",Ord_Resp->sPanID);
        logDebug2("Ord_Resp->iGrpId             :%d:",Ord_Resp->iGrpId);
        logDebug2("--------------------END----------------------------");
*/

	    	}
                rd_kafka_message_destroy(rkm);
        }


        /* Close the consumer: commit final offsets and leave the group. */
        fprintf(stderr, "%% Closing consumer\n");
        rd_kafka_consumer_close(rk);


        /* Destroy the consumer */
        rd_kafka_destroy(rk);

        return 0;
}
