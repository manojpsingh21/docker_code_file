#include "IPCS.h"
#include <errno.h>
#include "DWSAdapter.h"
#include "NseEQNNFStruct.h"


/*
struct VIEW_COMMON_QUERY_REQ
{
        struct  INT_COMMON_REQUEST_HDR ReqHeader;
        CHAR    sClientId[CLIENT_ID_LEN];
        CHAR    sEntityId[ENTITY_ID_LEN];
        //      CHAR    sSymbol [SYMBOL_LEN];
};



struct INT_COMMON_REQUEST_HDR
{
        LONG32          iSeqNo                          ;
        SHORT           iMsgLength                      ;
        SHORT           iMsgCode                        ;
        CHAR            sExcgId[EXCHANGE_LEN]           ;
        LONG32          iUserId                         ;
        CHAR            cSource                         ;
        CHAR            cSegment                        ;
};


*/


struct VIEW_COMMON_QUERY_REQ	pQuery;
LONG32  BytesSend,Len;
LONG32                  SockFlg, flag;
LONG32          NewSocket;
LONG32          MasterSocket;
LONG32          RelayPort;
LONG32          RelayId, TempRelayPort;
LONG32  iRespChild,iTransChild;
int n=0;
int ich,rw;
char statement[200];
double fOrderNum;
int iSerialNum;
int  iMsgcode;
char bs = 'B';
double fPrice;
struct ORDER_REQUEST  pOrdReq;
//struct ORDER_REQUEST pQuery;
int size;
void main (int argc, char *argv[])
{


	if(argc < 3)
	{
		logFatal(" Usage: DWSAdaptor  AdaptorPort AdaptorId");
		exit(1);
	}


	RelayPort = atoi (argv[1]);
	if( RelayPort <=0 )
	{
		logFatal(" Wrong Relay Port ");
		exit(1);
	}
	else
	{
		TempRelayPort = RelayPort;
	}

	RelayId = atoi (argv[2]);

	logTimestamp("Entry [main]");

	if((SockFlg = CreateSocket()) != TRUE)
	{
		logDebug2("failed To Create Socket ");
		exit(1);
	}
	else
	{
		logDebug2("Socket is Created");
	}



	for(; ;)
	{

		for(; ;)
		{
			NewSocket = accept(MasterSocket, NULL, NULL);
			if(NewSocket < 0)
			{
				logDebug2("No connection found");


			}
			else
			{
				flag = 1;
				if((setsockopt(NewSocket,SOL_SOCKET,SO_KEEPALIVE, ( CHAR *) &flag,sizeof(flag)))< 0)
				{
					perror("SetSockOption:");
					logDebug2("readThread::RelayId %d: Unable to set options for new socket",RelayId);
					close(NewSocket);
					/**     shutdown(NewSocket,2);  ***/
				}
				logDebug2("  after  setsockopt NewSocket= %d ",NewSocket);
				if ( (iRespChild = fork()) == 0 )
				{
					iRespChild = getppid();
					logDebug2("ReadfromsocketChild PID :%d:",iRespChild);
					logDebug2("one chiled is created for reading");
					ReadFromSocket();
				}
				break;

			}

		}
	}
}

int CreateSocket()
{
	struct sockaddr_in Serv_Addr;
	struct sockaddr_in Cli_Addr;
	fd_set  ReadSocketSet;
	LONG32 flag=1;



	//        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	//        pthread_setcanceltype (PTHREAD_CANCEL_DEFERRED, NULL);




	memset((CHAR *) &Serv_Addr,0,sizeof(Serv_Addr));

	Serv_Addr.sin_family = AF_INET;
	Serv_Addr.sin_addr.s_addr = htonl(INADDR_ANY);
	Serv_Addr.sin_port = htons(RelayPort);




	logDebug2(" Read Thread for RelayId = %d, RelayPort = %d",RelayId,RelayPort);



	//        LockThreadMutex ( &UserSocketTableLock, "InitUserSocketTable" );
	//        InitUserSocketTable( );
	//        UnLockThreadMutex ( &UserSocketTableLock, "InitUserSocketTable" );



	if((MasterSocket = socket ( AF_INET,SOCK_STREAM ,0 ) ) == ERROR)
	{
		perror("Socket:");
		logFatal(" RelayId %d: Unable to make a socket",RelayId);
		exit(1);
	}

	logDebug1("----- I am here socket [%d] -----",MasterSocket);

	if((setsockopt(MasterSocket,SOL_SOCKET,SO_REUSEADDR, ( CHAR *) &flag,sizeof(flag)))< 0)
	{
		perror("SetSockOption:");
		logDebug2(" RelayId %d: Unable to set options for socket",RelayId);
		close(MasterSocket);
		/**     shutdown(MasterSocket,2);***/
		exit(1);
	}



	if((bind(MasterSocket,(struct sockaddr *) &Serv_Addr, sizeof(Serv_Addr))) == ERROR)
	{
		perror("Bind:");
		logDebug1(" RelayId %d: Unable to bind a socket",RelayId);
		close(MasterSocket);
		/***            shutdown(MasterSocket,2);****/
		exit(1);
	}



	if((listen(MasterSocket,5)) < 0 )
	{
		perror("Listen:");
		logFatal(" Unable to listen on socket");
		close(MasterSocket);
		/***    shutdown(MasterSocket,2); ****/
		exit(1);
	}
	return TRUE;

}

void ReadFromSocket()
{

	while(1)
	{
		printf("\nENTER THE MESSAGE TYPE\n");

		printf("\n 1.New Entery ");
		printf("\n 2.Queries");
		printf("\n 3.\n");
		printf("->");

		scanf("%d",&ich);

		if(ich==1)
			pOrdReq.ReqHeader.iMsgCode=TC_INT_ORDER_ENTRY_REQ;
		else if(ich==2)
			pOrdReq.ReqHeader.iMsgCode=TC_INT_VIEW_CLIENT_LIMIT_REQ;
		else if(ich==3)
			pOrdReq.ReqHeader.iMsgCode=TC_INT_ORDER_CANCEL;
		else
			printf("Invalid Input");

		switch(pOrdReq.ReqHeader.iMsgCode)
		{
			case TC_INT_ORDER_ENTRY_REQ:
				{
					printf("\nEnter Buy or Sell ");
					printf("\n B.Buy ");
					printf("\n S.Sell");
					printf("\n ->");
					scanf(" %c",&bs);

					if(bs == 'B' || bs == 'b')
					{
						bs = 'B';
						printf("\n buy/sell : %c",bs);
						printf("\nPlease enter the Buy Price");
						printf("\n ->");
						scanf(" %lf",&fPrice);
						pOrdReq.fPrice=fPrice;
						pOrdReq.fPrice=fPrice;
					}
					else if(bs == 'S' || bs == 's')
					{
						bs = 'S';
						printf("\n buy/sell : %c",bs);
						printf("\n Please enter the Sell Price");
						printf("\n ->");
						scanf(" %lf",&fPrice);
						pOrdReq.fPrice=fPrice;
					}
					else
					{
						printf("\nInvalid Input");
					}

					pOrdReq.ReqHeader.iSeqNo = 11;
					pOrdReq.ReqHeader.iMsgLength = 300;
					//      pOrdReq.ReqHeader.iMsgCode      =  atoi(argv[3]);
					strncpy(pOrdReq.ReqHeader.sExcgId,"BSE",EXCHANGE_LEN);
					pOrdReq.ReqHeader.iUserId = 1234;
					pOrdReq.ReqHeader.cSource = 'S';
					//      pOrdReq.ReqHeader.cSegment = 'E';
					pOrdReq.ReqHeader.cSegment = 'C';
					//      pOrdReq.fOrderNum = 0;
					//pOrdReq.iSerialNum = 75;
					strncpy(pOrdReq.sSecurityId,"1020211",DB_SECURITY_ID_LEN);
					strncpy(pOrdReq.sEntityId,"CL002",DB_ENTITY_ID_LEN);
					strncpy(pOrdReq.sClientId,"CL002",DB_CLIENT_ID_LEN);
					pOrdReq.iTotalQty = 6;
					pOrdReq.iTotalQtyRem = 6;
					pOrdReq.iDiscQty = 0;
					pOrdReq.iDiscQtyRem = 0;
					pOrdReq.iStratergyId = 5;
					pOrdReq.iTotalTradedQty = 0;
					pOrdReq.cBuyOrSell = bs;
					pOrdReq.iMktType = 1;
					//pOrdReq.cBuyOrSell = 'B';
					//      pOrdReq.fPrice = 50.1;
					pOrdReq.iOrderType      = 1;
					printf("\n BuySell : %c:\n",pOrdReq.cBuyOrSell);
					pOrdReq.fTriggerPrice =0.00 ;           /* 0.00*/
					pOrdReq.iOrderValidity = 0;
					pOrdReq.iMinFillQty = 0;
					pOrdReq.cProCli = 'C';
					pOrdReq.cUserType = 'C';
					pOrdReq.cOffMarketFlg = 'N';
					pOrdReq.cProductId = 'I';
					pOrdReq.cHandleInst = '1';
					pOrdReq.cParticipantType='C';
					pOrdReq.cMarkProFlag='N';
					pOrdReq.cGTCFlag='N';
					pOrdReq.cEncashFlag='N';
					strcpy(pOrdReq.sPanID, "ABCDEFGHIJ");
					Len = pOrdReq.ReqHeader.iMsgLength;
					logDebug2("Market type = %d",pOrdReq.iMktType);
					if((BytesSend = Send(NewSocket,&(pOrdReq),&Len)) == ERROR )
					{
						logDebug2("\n WWT:: Error while sending on the socket ");
						exit(1);
					}

				}

				break;
			case TC_INT_VIEW_CLIENT_LIMIT_REQ:
				{
					sprintf(pQuery.sClientId,"CL0001");
					sprintf(pQuery.sEntityId,"CL0001");
					pQuery.ReqHeader.iSeqNo=1;
					pQuery.ReqHeader.iMsgLength=300;
					pQuery.ReqHeader.iMsgCode=TC_INT_VIEW_CLIENT_LIMIT_REQ;
					sprintf(pQuery.ReqHeader.sExcgId,"NSE");
					pQuery.ReqHeader.iUserId=1234;
					pQuery.ReqHeader.cSource='M';
					pQuery.ReqHeader.cSegment='E';
					Len= pQuery.ReqHeader.iMsgLength;
					if((BytesSend = Send(NewSocket,&(pQuery),&Len)) == ERROR )
					{
						logDebug2("\n WWT:: Error while sending on the socket ");
						exit(1);
					}
				}
				break;
			default:

				printf("\n Invalid input ");
		}
	}
	/*

	   pOrdReq.ReqHeader.iSeqNo = 11;
	   pOrdReq.ReqHeader.iMsgLength = 300;
	//      pOrdReq.ReqHeader.iMsgCode      =  atoi(argv[3]);
	strncpy(pOrdReq.ReqHeader.sExcgId,"BSE",EXCHANGE_LEN);
	pOrdReq.ReqHeader.iUserId = 9223;
	pOrdReq.ReqHeader.cSource = 'S';
	//      pOrdReq.ReqHeader.cSegment = 'E';
	pOrdReq.ReqHeader.cSegment = 'C';
	//      pOrdReq.fOrderNum = 0;
	//pOrdReq.iSerialNum = 75;
	strncpy(pOrdReq.sSecurityId,"1020211",DB_SECURITY_ID_LEN);
	strncpy(pOrdReq.sEntityId,"CL001",DB_ENTITY_ID_LEN);
	strncpy(pOrdReq.sClientId,"CL001",DB_CLIENT_ID_LEN);
	pOrdReq.iTotalQty = 6;
	pOrdReq.iTotalQtyRem = 6;
	pOrdReq.iDiscQty = 0;
	pOrdReq.iDiscQtyRem = 0;
	pOrdReq.iStratergyId = 5;
	pOrdReq.iTotalTradedQty = 0;
	pOrdReq.cBuyOrSell = bs;
	pOrdReq.iMktType = 1;
	//pOrdReq.cBuyOrSell = 'B';
	//      pOrdReq.fPrice = 50.1;
	pOrdReq.iOrderType      = 1;
	printf("\n BuySell : %c:\n",pOrdReq.cBuyOrSell);
	pOrdReq.fTriggerPrice =0.00 ;         
	pOrdReq.iOrderValidity = 0;
	pOrdReq.iMinFillQty = 0;
	pOrdReq.cProCli = 'C';
	pOrdReq.cUserType = 'C';
	pOrdReq.cOffMarketFlg = 'N';
	pOrdReq.cProductId = 'I';
	pOrdReq.cHandleInst = '1';
	pOrdReq.cParticipantType='C';
	pOrdReq.cMarkProFlag='N';
	pOrdReq.cGTCFlag='N';
	pOrdReq.cEncashFlag='N';
	strcpy(pOrdReq.sPanID, "ABCDEFGHIJ");
	Len = pOrdReq.ReqHeader.iMsgLength;
	logDebug2("Market type = %d",pOrdReq.iMktType);
	if((BytesSend = Send(NewSocket,&(pOrdReq),&Len)) == ERROR )
	{
	logDebug2("\n WWT:: Error while sending on the socket ");
	exit(1);
	}
	 */
}



LONG32 Send(LONG32 Socket,CHAR *Buf, LONG32 *Len)

{
	LONG32 BytesSend =0;
	LONG32  iRetVal;
	LONG32  TotalBytes = *Len;
	LONG32  BytesLeft = *Len;

	logDebug2(" Socket Send = [%d] BytesSend :%d: TotalBytes :%d:",Socket,BytesSend,TotalBytes);

	while(BytesSend < TotalBytes)
	{
		/***    if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,0)) <= 0)****/
		if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,MSG_NOSIGNAL)) <= 0)
		{
			logDebug2(" Error in Sending in SEND function need to check the issue");
			perror("in Send function");
			return ERROR;
		}

		BytesSend += iRetVal;
		BytesLeft -= iRetVal;
		logDebug2("SENDING");
	}
	logDebug2("Total Bytes written to socket %d is %d",Socket,BytesSend);
	return BytesSend;
}
