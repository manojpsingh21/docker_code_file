#include <my_global.h>
#include "IPCS.h"
#include "DWSAdapter.h"

LONG32 iAdapToQry;

main()
{
	struct VIEW_DWS_ORDER_BASKET_REQUEST pOrdBasketReq;
	memset(&pOrdBasketReq,'\0',sizeof(struct VIEW_DWS_ORDER_BASKET_REQUEST));

	if((iAdapToQry = OpenMsgQ(RelToQuery)) == ERROR)
	{
		perror("OpenMsgQ ...AdapToQry");
		exit(ERROR);
	}
	printf("\n AdapToQry opened successfully with id = %d", iAdapToQry);
	strncpy(pOrdBasketReq.sClientId,"CL908",CLIENT_ID_LEN);
	strncpy(pOrdBasketReq.sEntityId,"CL008",ENTITY_ID_LEN);
	strncpy(pOrdBasketReq.sBasketName,"Rupeee22",CLIENT_NAME_LEN);
	strncpy(pOrdBasketReq.sExchId,"NSE",EXCHANGE_LEN);
	pOrdBasketReq.ReqHeader.iMsgCode = TC_INT_ORDER_BASKET_REQ;
	pOrdBasketReq.ReqHeader.iUserId = 134; 
	pOrdBasketReq.ReqHeader.cSource = 'S';
	pOrdBasketReq.cFlag = 'A';			
	pOrdBasketReq.cScriptStatus= 'A';			
	pOrdBasketReq.cSegment = 'E';			
	pOrdBasketReq.cProduct= 'A';			
	pOrdBasketReq.cBuySell= 'S';			
	pOrdBasketReq.iBasketId= 0;
	pOrdBasketReq.iQty = 100;
	pOrdBasketReq.iOrdvalidity = 2;
	//pOrdBasketReq.iSequenceId= 2050134;
	pOrdBasketReq.iSequenceId= 0;
	pOrdBasketReq.fPrice= 100.00;
	pOrdBasketReq.iOrderType= 1;
	strncpy(pOrdBasketReq.sCreateTime,"2018,05,23",DATE_TIME_LEN);
	strncpy(pOrdBasketReq.sScripCode,"1345",SCRIP_CODE_LEN);
	strncpy(pOrdBasketReq.sUpdateTime,"2018,03,23",DATE_TIME_LEN);
	strncpy(pOrdBasketReq.sFiller1,";",FILLER_LEN_20);
	strncpy(pOrdBasketReq.sFiller3,";",FILLER_LEN_20);
	strncpy(pOrdBasketReq.sFiller2,";",FILLER_LEN_20);
	pOrdBasketReq.iMktType = 1;
	pOrdBasketReq.fTriggerPrice = 90.00;
	pOrdBasketReq.iDiscQty= 10;


	logDebug2("pOrdBasketReq.sClientId:%s:",pOrdBasketReq.sClientId);
	logDebug2("pOrdBasketReq.cFlag:%c:",pOrdBasketReq.cFlag);
	logDebug2("pOrdBasketReq.cScriptStatus:%c:",pOrdBasketReq.cScriptStatus);
	logDebug2("pOrdBasketReq.cProduct:%c:",pOrdBasketReq.cProduct);
	logDebug2("pOrdBasketReq.cBuySell:%c:",pOrdBasketReq.cBuySell);
	logDebug2("pOrdBasketReq.sBasketName:%s:",pOrdBasketReq.sBasketName);
	logDebug2("pOrdBasketReq.ReqHeader.iMsgCode:%d:",pOrdBasketReq.ReqHeader.iMsgCode);
	logDebug2("pOrdBasketReq.ReqHeader.iUserId:%d:",pOrdBasketReq.ReqHeader.iUserId);
	logDebug2("pOrdBasketReq.ReqHeader.cSource:%c:",pOrdBasketReq.ReqHeader.cSource);
	logDebug2("pOrdBasketReq.iBasketId:%d:",pOrdBasketReq.iBasketId);
	logDebug2("pOrdBasketReq.iQty:%d:",pOrdBasketReq.iQty);
	logDebug2("pOrdBasketReq.iOrdvalidity:%d:",pOrdBasketReq.iOrdvalidity);
	logDebug2("pOrdBasketReq.iOrderType:%d:",pOrdBasketReq.iOrderType);
	logDebug2("pOrdBasketReq.iSequenceId:%d:",pOrdBasketReq.iSequenceId);
	logDebug2("pOrdBasketReq.fPrice:%f:",pOrdBasketReq.fPrice);
	logDebug2("pOrdBasketReq.sCreateTime:%s:",pOrdBasketReq.sCreateTime);
	logDebug2("pOrdBasketReq.sUpdateTime:%s:",pOrdBasketReq.sUpdateTime);
	logDebug2("pOrdBasketReq.sScripCode:%s:",pOrdBasketReq.sScripCode);
	logDebug2("pOrdBasketReq.sFiller1:%s:",pOrdBasketReq.sFiller2);
	logDebug2("pOrdBasketReq.sFiller1:%s:",pOrdBasketReq.sFiller1);
	logDebug2("pOrdBasketReq.sFiller2:%s:",pOrdBasketReq.sFiller3);

	if(WriteMsgQ( iAdapToQry,(CHAR *)&pOrdBasketReq, sizeof(struct VIEW_DWS_ORDER_BASKET_REQUEST), 1 ) != 1)
	{
		perror("write to Q failed : ");
		exit(ERROR);
	}
	printf("\n write successful \n");	
}







