#include <sys/select.h>
#include "IPCS.h"
#include "DWSAdapter.h"
//#include "NNFStruct.h"
#include <errno.h>
#include <malloc.h>


struct MsgSocketStruct
{
	int Socket;
	char *cpMsgBuf;	


};

struct UserDetails
{
	struct  INT_REQUEST_HEADER IntReqHeader;
	int UserId;
	char UserType;
};

struct LOOKUP
{
	struct UserDetails user;
	int Socket;
	struct sockaddr_in  PeerAddr;
	pthread_mutex_t		SendMutex;

};

struct LOGON_REQ
{
	struct  INT_REQUEST_HEADER IntReqHeader;
	int UserId;
	char UserType;


};

#define		ISSET			1		
#define		UNSET			2		
#define		WRITEUNSET		3		
#define		DLDUNSET		4			
#define		SOCKET_ERROR		-1		
#define		MAX_THREADS		5		
#define		MAX_THREADS_WRITE	4		
#define		MAX_DLOAD_THREADS_WRITE	4		
#define 	MAX_RETRY_COUNT		15	
#define 	ERR_RECONNECT_AGAIN	15	
#define 	MAX_NO_OF_USERS 	1000
#define 	BSS_MESSAGE_SIZE	10000
#define 	INVALID_TRANSCODE	1234
#define 	REQUEST_NOT_SENT_TO_EXCH	1235
#define 	INTEACTIVE_USER_ID_TYPE_MISMATCH	1236
#define 	TC_INT_ORDER_CANCEL_REQ 		1237
#define 	TC_INT_ORDER_MODIFY_REQ			1238
#define 	PACKET_SIZE_MISMATCH			1239
#define 	PROBLEM_IN_SYSTEM_RESTART		1240
#define 	USER_ALREADY_LOGGED_IN			1241
#define 	USER_ALREADY_LOGGED_IN_CLOSING_SOCKET	1242
#define 	ERR_VIOLATE_LICENSE			1243
#define 	COMPLETE_PACKET_NOT_RECEIVED		1244
#define 	TC_INT_ERROR_CODE			1245
#define 	DELETE_USER				-2

struct LOOKUP Lookup[MAX_NO_OF_USERS];

struct ForkProcess
{
	int    RelayId;
	int    ProcessId;
	int    RelayPort;
};


pthread_once_t             OnceInit = PTHREAD_ONCE_INIT;


pthread_mutex_t 	LookupMutex;
pthread_mutex_t 	ActiveSocLock;
pthread_mutex_t 	PipeLock;
pthread_mutex_t 	OmsPipeLock;
pthread_mutex_t 	SendMutexSeq;
pthread_mutex_t 	MaxThreadMutex;
pthread_mutex_t 	MaxThreadMutexWrite;
pthread_mutex_t 	MaxDloadThreadMutexWrite;
pthread_mutex_t 	UserSocketTableLock;
pthread_attr_t             ThreadAttr;

LONG32	 	PipeFds[2];
LONG32	 	oms_filedes[2];
LONG32          RelayPort;
LONG32          RelayId;
LONG32		NoOfThreadsWrite = 0;
LONG32		NoOfDloadThreadsWrite= 0;
LONG32		NoOfThreads= 0;
LONG32		MonitorWriteFlag;
LONG32		MonitorDloadFlag;
LONG32		MonitorFlag;
LONG32		WRITEISSET;
LONG32		DLDISSET;
LONG32		MasterSocket;
LONG32		RelayType;
LONG32		MsgRms;
pthread_cond_t	MaxThreadCond;
pthread_cond_t	MaxThreadCondWrite;
pthread_cond_t	MaxDloadThreadCondWrite;

LONG32          dMaxUser;
LONG32                        iDWSTrdRtrToDWSAdp;
LONG32                        iD2C1ToDWSAdap;
LONG32                        iDWSQryToAdap;
LONG32                        iRelToOrdRtr ;
LONG32                        iRelToQuery ;
LONG32                        iAdapToRQuery;


void SignalHandlerSigTermParent (int dummy);
void * WriteDloadThread (void * dummy) ;
void * WriteUserThread (void * MsgStruct);
void * ReadUseridThread(void * Value);
void * WriteUserDloadThread (void * MsgStruct);
struct	ForkProcess ForkProcess[ MAX_NO_OF_PROCESS ];
int AddinShmData (int UserId, struct sockaddr_in *PeerAddr, char UserType);

void sig_segv_handler();

fd_set	MainSignalSet;
fd_set	ChildSignalSet;
fd_set	MainSignalSet;
fd_set	ActiveSocket;

pthread_t               WriteUserTid;
pthread_t               WriteUserDloadTid;
pthread_t               ReadUseridTid;

main( int argc , char ** argv )
{

	LONG32 i;
	pid_t                   ForkInd = 1;
	pthread_t               SignalTid;
	pthread_t               ReadTid;
	pthread_t               WriteTid;
	pthread_t               WriteDloadTid;
	pthread_t               WriteTid_intorderresp;



	OpenMsgQue();


	signal (SIGHUP, SIG_IGN);
	signal (SIGSEGV,sig_segv_handler);
	sigemptyset ( &MainSignalSet );
	sigaddset ( &MainSignalSet , SIGTERM);
	sigaddset ( &MainSignalSet , SIGCHLD);
	sigprocmask (SIG_BLOCK,&MainSignalSet , NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );


	if ( argc < 3 )
	{
		logDebug3( " Usage Prog_name Relaytype RelayPort ");
		exit (1);
	}

	InitForkProcess( );
	/**	ConnectToDB( );***/

	if ( 0 != pthread_once (&OnceInit,init_routine))
	{
		logPError("pthread_once");
	}
	RelayPort = atoi(argv[2]);
	for (i=0 ; i < MAX_NO_OF_PROCESS && ForkInd != 0 ; i++)
	{
		ForkInd = fork ( );
		RelayPort = RelayPort + 1;
		RelayId = i + 1;
		if ( ForkInd != 0)
		{
			UpdateForkProcess (ForkInd ,RelayPort,RelayId);
		}
		
		else
		{
			logDebug2("Child is created with ProcessID %d", getpid());
			break;
		}
	
		
	}

	if ( ForkInd != 0 )
	{
//	***	ConnectToDB ( );**
		sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
	//	signal(SIGTERM,SignalHandlerSigTermParent);
	//	signal(SIGCHLD,SignalHandlerSigChldParent);

		for (;;)
		{
			sleep (3);
			for ( i=0; i < MAX_NO_OF_PROCESS  && ForkInd != 0 ; i++ )
			{
				if ( ForkProcess[i].ProcessId == RESTART )
				{
					sleep(3);
					sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);

					ForkInd = fork ();

					if( ForkInd != 0)               
					{
						RelayPort = ForkProcess[i].RelayPort;
						RelayId   = ForkProcess[i].RelayId ;
						ForkProcess[i].ProcessId = ForkInd;
					}
					sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);
					signal(SIGTERM,SignalHandlerSigTermParent);
					signal(SIGCHLD,SignalHandlerSigChldParent);
				}
			}

			if ( ForkInd == 0 )
			{
				logDebug3 (" New Fork Process Started ");
				break;
			}
		}                                     
	}                                               
	LokThreadMutex ( &LookupMutex );
	InitLookup();
	UnLokThreadMutex ( &LookupMutex );


	/*********************** Open Msg Queus here **************/
	/*********************** END :  Open Msg Queus here **************/

	if( pipe(PipeFds) != 0 )
	{
		perror("Error in pipe creation");
		logDebug3("Error in pipe creation"); 
		exit( 1);
	}

	if( pipe(oms_filedes) != 0 )                    
	{
		perror("Error in pipe creation");
		exit( 1);
	}

	sigprocmask(SIG_UNBLOCK,&MainSignalSet ,NULL);

	sigemptyset ( &ChildSignalSet );
	sigaddset ( &ChildSignalSet , SIGTERM);
	sigaddset ( &ChildSignalSet , SIGUSR1);

	sigaddset ( &ChildSignalSet , SIGUSR2);

	pthread_sigmask ( SIG_BLOCK,&ChildSignalSet,NULL);
	pthread_create(&SignalTid, NULL, SignalThread, NULL);

	/***	ConnectToDB ( );****/


	pthread_create(&ReadTid, NULL, ReadThread, NULL);

//	pthread_create(&WriteTid, NULL, WriteThread, (void *)iDWSTrdRtrToDWSAdp);
//	pthread_create(&WriteTid_intorderresp, NULL, WriteThread, (void *)iDWSQryToAdap);
//	pthread_create(&WriteDloadTid, NULL, WriteDloadThread, NULL);

	pthread_join(ReadTid, NULL);
	pthread_join(WriteTid, NULL);
	pthread_join(WriteTid_intorderresp, NULL);
	pthread_join(WriteDloadTid, NULL);
} /************** End of main*************/



/***********
 *Function Name:
 * Arguments:
 * Return Values:
 * Tables Used:
 * Dependencies:
 * Functions Called By:
 * Comments:
 * **********/

void InitForkProcess ( )
{
	int i;
	for ( i =0 ; i < MAX_NO_OF_PROCESS ; i++ )
	{
		ForkProcess [i].RelayId = UNUSED;
		ForkProcess [i].ProcessId = UNUSED;
		ForkProcess [i].RelayPort = UNUSED;
	}
}


/***********
 *Function Name:
 * Arguments:
 * Return Values:
 * Tables Used:
 * Dependencies:
 * Functions Called By:
 * Comments:
 * **********/

void init_routine()
{
	int i;

	for (i=0; i< MAX_NO_OF_USERS; i++)
	{
		if ( pthread_mutex_init (&Lookup[i].SendMutex,NULL) != 0)
		{
			logPError("pthread_mutex_init:SendMutex");
			exit (1);
		}
	}



	if(  pthread_mutex_init ( &LookupMutex,NULL) != 0)
	{
		logPError("pthread_mutex_init:LookupMutex");
	}

	if(  pthread_mutex_init (&ActiveSocLock,NULL ) != 0)
	{
		logPError("pthread_mutex_init:ActiveSocLock");
	}

	if(  pthread_mutex_init (&PipeLock,NULL ) != 0)
	{
		logPError("pthread_mutex_init:PipeLock");
	}

	if(  pthread_mutex_init (&OmsPipeLock,NULL ) != 0)
	{
		logPError("pthread_mutex_init:OmsPipeLock");
	}


	if(  pthread_mutex_init (&SendMutexSeq,NULL ) != 0)
	{
		logPError("pthread_mutex_init:SendMutexSeq");
	}

	if(  pthread_mutex_init (&MaxThreadMutex,NULL ) != 0)
	{
		logPError("pthread_mutex_init:MaxThreadMutex");
	}

	if(  pthread_mutex_init (&MaxThreadMutexWrite,NULL ) != 0)
	{
		logPError("pthread_mutex_init:MaxThreadMutexWrite");
	}
	if(  pthread_mutex_init (&UserSocketTableLock,NULL ) != 0)
	{
		logPError("pthread_mutex_init:MaxThreadMutexWrite");
	}

	if(  pthread_mutex_init (&MaxDloadThreadMutexWrite,NULL ) != 0)
	{
		logPError("pthread_mutex_init:MaxDloadThreadMutexWrite");
	}

	if(  pthread_attr_init (&ThreadAttr) != 0)
	{
		logPError("pthread_attr_init:ThreadAttr");
	}
	pthread_attr_setdetachstate(&ThreadAttr,PTHREAD_CREATE_DETACHED);
}


/***********
 * * Function Name:
 * * Arguments:
 * * Return Values:
 * * Tables Used:
 * * Dependencies:
 * * Functions Called By:
 * * Comments:
 * * **********/

void AssociateSocketSignal( int Socket )
{
	int flag = 1 ;

	if( setsockopt( Socket , SOL_SOCKET , SO_KEEPALIVE , ( char * )&flag , sizeof( flag ) ) < 0 )
	{
		logPError("setsockopt");
		perror("Error In setsockopt() ErrorMsg");
		exit ( 1 );
	}

	printf("Associating Socket = %d And SIGIO \n" , Socket );
}


/***********
 * Function Name:
 * Arguments:
 * Return Values:
 * Tables Used:
 * Dependencies:
 * Functions Called By:
 * Comments:
 * **********/
void InitLookup( void )
{
	register int i, j;

	for(i=0;i<MAX_NO_OF_USERS;i++)
	{
		Lookup[ i ].Socket        = UNUSED ;
		Lookup[ i ].user.UserId  = UNUSED ;
		Lookup[ i ].user.UserType= UNUSED ;
		memset(&(Lookup[i].PeerAddr),NULL,sizeof(struct sockaddr_in));
	}
}

/***********
 * Function Name:
 * Arguments:
 * Return Values:
 * Tables Used:
 * Dependencies:
 * Functions Called By:
 * Comments:
 * **********/
int GetIndexForPacket( char *cpMsgBuf)
{
	register int i ,k;
	LONG32	 UserId;
	UserId = ((struct INT_RESP_HEADER *)cpMsgBuf)->iUserIdOrLogPktId; 
	for( i = 0 ; i < MAX_NO_OF_USERS ; i++ )
	{
		if( Lookup[i].Socket != UNUSED  && Lookup[i].user.UserId==((struct INT_RESP_HEADER *)cpMsgBuf )->iUserIdOrLogPktId )
		{
			logDebug2("Index:User %d:%d", i, ((struct INT_RESP_HEADER * )cpMsgBuf )->iUserIdOrLogPktId );
			return  i;
		}
	}
	return NOT_TRUE ;
}


/***********
 * Function Name:
 * Arguments:
 * Return Values:
 * Tables Used:
 * Dependencies:
 * Functions Called By:
 * Comments:
 * **********/

int SearchIndex( int Socket )
{
	register int i ;

	printf("In SearchIndex() Socket as a paremeter = %d\n" , Socket );
	for( i = 0 ; i < MAX_NO_OF_USERS ; i ++ )
	{
		if( Lookup[ i ].Socket == Socket )
		{
			printf("\n\t SearchIndex returns %d",i);
			return i ;
		}
	}

	logWarn(" SearchIndex returns -1");
	return NOT_TRUE ;
}


/***********
 * Function Name:
 * Arguments:
 * Return Values:
 * Tables Used:
 * Dependencies:
 * Functions Called By:
 * Comments:
 ***********/

void CleanSocketResour( int Socket )
{
	register int Index ,j;

	printf("\n\t\t INSIDE CleanSocketResour ");

	if( ( Index = SearchIndex( Socket ) ) == NOT_TRUE || Socket == UNUSED )
		return ;
	DltShmRelayData(Lookup[Index].user.UserId);

	Lookup[ Index ].user.UserId     = UNUSED ;
	Lookup[ Index ].user.UserType   = UNUSED ;
	Lookup[ Index ].Socket      = UNUSED ;

	memset(&(Lookup[ Index ].PeerAddr),NULL,sizeof(struct sockaddr_in));
	close( Socket );
	LokThreadMutex ( &ActiveSocLock) ;
	FD_CLR(Socket,&ActiveSocket);
	UnLokThreadMutex ( &ActiveSocLock) ;
	printf("In CleanSocketResour() Socket = %d \n" , Socket );

}


/***********
 *  Function Name:
 *   Arguments:
 *    Return Values:
 *     Tables Used:
 *      Dependencies:
 *       Functions Called By:
 *        Comments:
 *        **********/

int SendPacketToUser( int Socket , char *cpMsgBuf )
{

	logDebug3("In SendPacketToUser");

	struct MsgSocketStruct *MsgStruct;

	MsgStruct = (struct MsgSocketStruct *)malloc(sizeof(struct MsgSocketStruct));
	MsgStruct->Socket = Socket;
	memcpy(MsgStruct->cpMsgBuf,cpMsgBuf,BSS_MESSAGE_SIZE);

	if ( MonitorWriteFlag == WRITEISSET )
	{
		ProcessOutBoundBuff ( MsgStruct );
		LokThreadMutex ( &MaxThreadMutexWrite );
		NoOfThreadsWrite -- ;
		UnLokThreadMutex ( &MaxThreadMutexWrite );
		return;
	}

	WaitForMaxThreadCondWrite ( );
	LokThreadMutex ( &SendMutexSeq );
	pthread_create (&WriteUserTid,&ThreadAttr,WriteUserThread,(void *)(MsgStruct));
	logDebug3("Out SendPacketToUser");
	return TRUE ;
}


int SendDloadPacketToUser( int Socket , char *cpDloadMsgBuf )
{
	struct MsgSocketStruct *MsgStruct;

	MsgStruct = (struct MsgSocketStruct *) malloc ( sizeof (struct MsgSocketStruct));
	MsgStruct->Socket = Socket;
	memcpy(MsgStruct->cpMsgBuf,cpDloadMsgBuf,BSS_MESSAGE_SIZE);

	if ( MonitorDloadFlag == DLDISSET )
	{
		ProcessOutDloadBuff ( MsgStruct );
		LokThreadMutex ( &MaxDloadThreadMutexWrite );
		NoOfDloadThreadsWrite -- ;
		UnLokThreadMutex ( &MaxDloadThreadMutexWrite );
		return;
	}

	WaitForMaxDloadThreadCondWrite ( );
	LokThreadMutex ( &SendMutexSeq );
	pthread_create (&WriteUserDloadTid,&ThreadAttr,WriteUserDloadThread,(void *)(MsgStruct));
	return TRUE ;
}

int SearchuserId(int UserId ,int *OldSocket)
{
	printf("\n\t Inside the function SearchuserId");
	logDebug3(" UserId =%d",UserId);
	int     i,k;
	for ( i = 0; i< MAX_NO_OF_USERS ; i++ )
	{
		if ( Lookup[i].user.UserId == UserId )
		{
			*OldSocket = Lookup[i].Socket;
			logDebug3(" OldSocket =%d",*OldSocket);
			CleanOldSocketResour(Lookup[i].Socket);
			return ( TRUE );
		}
	}
	return ( FALSE );
}


int SearchglobalUserId(int UserId)
{
	int i,k;
	int RetVal = FALSE ;
	struct user_relay_array *Ptr;

	printf("\n In searchGlobaluserid \n");
	printf("\n size of user_relay_array is :%d: :%d: ", sizeof(struct user_relay_array),DirRelShm_SIZE);
	LockShm(DirRelShm);
	Ptr = OpenSharedMemory(DirRelShm,DirRelShm_SIZE);
	if ( *( (int *) Ptr) == ERROR )
	{
		exit(1);
	}

	for ( i=0 ; i < MAX_USERS ; i++ )
	{
		if ( Ptr->user_relay[i].iRelayId != RelayId &&  Ptr->user_relay[i].iUserId == UserId )
		{
			RetVal = TRUE;
		}
		else if (Ptr->user_relay[i].iRelayId == RelayId &&  Ptr->user_relay[i].iUserId == UserId )
		{
			RetVal = TRUE;
		}
	}
	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		exit(1);
	}

	UnLockShm(DirRelShm);
	return(RetVal);
}


void SetUserId( int Socket , char *TempBuf )
{
	register int Index , j;
	LONG32      RecvBuff = 1 ;
	int     OldSocket;
	BOOL ret;
	char Usertype;
	BOOL    iRetVal = FALSE;                        
	struct LOGON_REQ *tempuser;
	tempuser = ( struct LOGON_REQ *)TempBuf;
	Usertype = tempuser->UserType;
	if( ( Index = SearchIndex( Socket ) ) == NOT_TRUE )
	{
		printf("In SetUserId() Can't find index for this socket = %d\n",Socket);
		SenderrorResponce ( Socket,PROBLEM_IN_SYSTEM_RESTART );
		CleanSocketResour( Socket );
		return ;
	}

	CheckpeerAddr((&(Lookup[Index].PeerAddr)),sizeof(struct sockaddr),tempuser->UserType);

	ret    =   find_user_relay ( tempuser->UserId,&(Lookup[ Index ].PeerAddr));
	if(ret == TRUE)
	{
		printf("\nFound request from same peer from same user.Probably lan flip .... accepting user request\n");

		ret = find_user_local(tempuser->UserId,&(Lookup[ Index ].PeerAddr));
		if(ret == TRUE)
		{
			printf("\nUser cleared from local table....can login aging ....\n");
		}

	}


	if (SearchglobalUserId (tempuser -> UserId ) == TRUE )
	{
		SenderrorResponce (Socket,USER_ALREADY_LOGGED_IN );
		CleanSocketResour( Socket );
		return;
	}

	if( SearchuserId (tempuser->UserId, &OldSocket ) == TRUE)
	{

		printf("Already User Logged On \n");
		printf("\n\t Inside SearchuserId...... call ");
		if ( OldSocket == Socket )
		{
			SenderrorResponce ( Socket,USER_ALREADY_LOGGED_IN );
			return ;
		}
		else
		{
			SenderrorResponce (Socket,USER_ALREADY_LOGGED_IN );;
			CleanSocketResour( Socket );
			return;
		}
	}


	if( Lookup[ Index ].user.UserId != UNUSED )
	{
		printf("In SetUserId() Trying To set uset Id Again\n" );
		SenderrorResponce (Socket,USER_ALREADY_LOGGED_IN_CLOSING_SOCKET );
		CleanSocketResour( Socket );
		return ;
	}
	Lookup[ Index ].user.UserId     = tempuser->UserId  ;
	Lookup[ Index ].user.UserType       = tempuser->UserType    ;
	Lookup[ Index ].user.IntReqHeader.cUserTypeOrLogInfoType = tempuser->IntReqHeader.cUserTypeOrLogInfoType ;


	iRetVal=AddinShmData(Lookup[Index].user.UserId , &(Lookup[ Index ].PeerAddr), Usertype);
	if ( iRetVal == FALSE)
	{
		SenderrorResponce ( Socket,ERR_VIOLATE_LICENSE);
		CleanSocketResour( Socket );
		return ;

	}

	/***		SendLogonResponce ( Socket,5018 );******/
}

int SearchForFreeSlot( void )
{
	register int i;

	for( i = 0 ; i < MAX_NO_OF_USERS ; i ++ )
	{
		if( Lookup[ i ].Socket == UNUSED )
		{
			return i ;
		}
	}
	return NOT_TRUE ;
}

int OpenPassiveSocket( void )
{
	int     sock     ;
	int     flag = 1 ;
	struct  sockaddr_in     serv_addr ;
	int i;
	printf("In OpenPassiveSocket");
	memset( ( char * ) &serv_addr, 0, sizeof ( serv_addr ) );
	logDebug2("My Process ID = %d ",getpid());
	for (i=0 ; i < MAX_NO_OF_PROCESS ; i++)
	{
		if (getpid()==ForkProcess[i].ProcessId )
		{
			RelayPort = ForkProcess[i].RelayPort;
		}
	}
	logDebug2("relayPort= %d",RelayPort);

	serv_addr.sin_family        = AF_INET;
	serv_addr.sin_addr.s_addr   = htonl( INADDR_ANY );
	serv_addr.sin_port          = htons( RelayPort ) ;
	logDebug2("ready to create socket");
	if( ( sock = socket( AF_INET , SOCK_STREAM , 0 ) ) == ERROR  )
	{
		logPError("socket");
		logFatal("ERROR CREATING SOCKET FOR PORT %d", RelayPort);

		return NOT_TRUE ;
	}
	if( setsockopt( sock , SOL_SOCKET , SO_REUSEADDR , ( char * )&flag , sizeof( flag ) ) < 0 )
	{
		logPError("setsockopt");
		exit ( 1 );
	}
	if( bind( sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == ERROR )
	{
		logPError("bind");
		logFatal("ERROR BINDING PORT %d", RelayPort);
		return NOT_TRUE ;
	}
	if( listen( sock , 5 ) == ERROR )
	{
		logPError("listen");
		logFatal("ERROR LISTENING PORT %d", RelayPort);
		return NOT_TRUE ;
	}

	LokThreadMutex ( &ActiveSocLock) ;
	FD_ZERO( &ActiveSocket );
	FD_SET(sock,&ActiveSocket );
	UnLokThreadMutex ( &ActiveSocLock) ;
	logDebug2("Socket Created with Process ID = %d ",getpid());	
	return sock ;
}


void GetPacketFromQueue( char *cpMsgBuf , int Queue )
{

	short   UserId ,UserType ;
	short   lTcode = 0;
	sleep(1);
	logDebug2("In GetPacketFromQueue");
	if ( ReadMsgQ( Queue, cpMsgBuf,BSS_MESSAGE_SIZE,RelayId ) != TRUE )
	{
		exit(ERROR);
	}

	UserId   = ( ( struct INT_RESP_HEADER * ) cpMsgBuf )->iUserIdOrLogPktId ;
	UserType = ( ( struct INT_RESP_HEADER * ) cpMsgBuf )->cUserTypeOrLogInfoType ;
	lTcode   = ( ( struct INT_RESP_HEADER * ) cpMsgBuf )->iMsgCode ;

	logDebug1("UserId = [%d]",UserId);
	logDebug1("UserType = [%c]",UserType);
	logDebug1("Tcode = [%d]",lTcode);
}

void GetPacketFromDloadQueue( char *cpMsgBuf , int Downloadq )
{
	short   UserId , UserType ,MsgCode;

	if ( ReadMsgQ( Downloadq, cpMsgBuf,BSS_MESSAGE_SIZE,RelayId ) != TRUE )
	{
		exit(ERROR);
	}

	UserId   = (( struct INT_RESP_HEADER * ) cpMsgBuf )->iUserIdOrLogPktId ;
	UserType = (( struct INT_RESP_HEADER * ) cpMsgBuf )->cUserTypeOrLogInfoType ;
	MsgCode = (( struct INT_RESP_HEADER * ) cpMsgBuf )->iMsgCode ;

	logDebug1("UserId = [%d]",UserId);
	logDebug1("UserType = [%d]",UserType);
	logDebug1("Tcode = [%d]",MsgCode);
}

void * ReadThread(void * dummy)
{
	printf("\nThis is in ReadThread.........\n");

	if( ( MasterSocket = OpenPassiveSocket( ) ) == NOT_TRUE )
	{
		exit( 1 );
	}
	AssociateSocketSignal( MasterSocket );
	logDebug2("Done with creating Socket");
	SignalHandlerSigio(MasterSocket);
}

void * SignalThread ( void * dummy )
{
	int sig ;
	int err;

	printf("thread sigint [tid: %d] awaiting SIGTerm\n", pthread_self());
	for (; ; )
	{
		err = sigwait ( &ChildSignalSet, &sig );

		if (err && (err != SIGTERM && err != SIGUSR1) )
		{
			printf ("signal: %d \n",err);
			perror ("signalthread");
			continue;
		}

		printf("\n signal %d caught by sigint thread [tid: %ld]\n", err, pthread_self());
		if ( err == SIGTERM)
			SignalHandlerSigTermChild ( SIGTERM );
		if ( err == SIGUSR1 )
			CleanUserResour ( );
	}
}


void SignalHandlerSigChldParent (int dummy)
{
	int i;
	int Status;
	pid_t ProcessId;
	printf("\n In SignalHandlerSigChldParent \n");
	for ( i = 0 ; i <= MAX_NO_OF_PROCESS ; i++ )
	{
		if ( ForkProcess [i].ProcessId != UNUSED )
		{
			if ((ProcessId = waitpid(ForkProcess [i].ProcessId,&Status,WNOHANG))>0)
			{
				if(ProcessId == ForkProcess[i].ProcessId )
				{
					printf("\t\n ForkProcess[i].RelayId : %d",ForkProcess[i].RelayId ) ;
					UpdateForkProcessForRestart (ForkProcess[i].ProcessId );
					DeleteRelayUserShm (ForkProcess[i].RelayId );
				}
			}
		}
	}
}

void SignalHandlerSigTermParent (int dummy)
{
	int i;
	printf("\n In SignalHandlerSigTermParent \n");
	sigprocmask(SIG_BLOCK,&MainSignalSet ,NULL);
	for ( i = 0 ; i < MAX_NO_OF_PROCESS ; i++ )
	{
		if (ForkProcess [i].ProcessId != UNUSED )
		{
			kill(ForkProcess [i] .ProcessId,SIGTERM);
		}
	}
	exit (1);
}
/*
   void InitForkProcess ( )
   {
   int i;
   for ( i =0 ; i < MAX_NO_OF_PROCESS ; i++ )
   {
   ForkProcess [i].RelayId = UNUSED;
   ForkProcess [i].ProcessId = UNUSED;
   ForkProcess [i].RelayPort = UNUSED;
   }
   }

 */
void SignalHandlerSigTermChild (int dummy)
{
	int i,j;
	int ProcessId;

	printf("\n In SignalHandlerSigTermChild \n");
	printf("Closing all sockets\n");

	LokThreadMutex ( &LookupMutex );

	for( i = 0 ; i < MAX_NO_OF_USERS; i++ )
	{
		if ( Lookup[i].Socket != UNUSED )
		{
			FD_CLR( Lookup[i].Socket , &ActiveSocket );
			close( Lookup[ i ].Socket );
		}

		Lookup[ i ].Socket = UNUSED ;
		Lookup[ i ].user.UserId = UNUSED ;
		memset(&(Lookup[i].PeerAddr),NULL,sizeof(struct sockaddr_in));
	}

	UnLokThreadMutex ( &LookupMutex );

	DeleteRelayUserShm (RelayId );
	LokThreadMutex ( &MaxThreadMutex );

	while ( NoOfThreads != 0 )
	{
		if ( pthread_cond_wait (&MaxThreadCond,&MaxThreadMutex )  < 0)
		{
			logPError("pthread_cond_wait:MaxThreadCond");
			exit (1);
		}
	}
	UnLokThreadMutex ( &MaxThreadMutex );
	exit( 1 );
}

void SignalHandlerSigio(int dummy)
{
	fd_set           ReadySock;
	fd_set           ErrorSock;
	int              i ;
	int              newSock , Index ;
	struct           sockaddr cli_addr ;
	struct           timeval  timeout = { 20,0 } ;
	int              iRetVal ;
	int              iMaxSoc=3;
	int *            SendVal;
	char             Dummy[1];
	int              TempRet=0 ;
	LONG32		flag;

	printf("\nThis is in SignalHandlerSigio.........\n");
	sleep(1);
	LokThreadMutex ( &ActiveSocLock);
	FD_SET(PipeFds[0],&ActiveSocket);
	UnLokThreadMutex ( &ActiveSocLock);
	logDebug2("Suraj Is before for loop");


	LokThreadMutex ( &ActiveSocLock);
	FD_SET(MasterSocket,&ActiveSocket);
	UnLokThreadMutex ( &ActiveSocLock);

	for (; ;)
	{
		iMaxSoc = GetMaxSocket( );
		LokThreadMutex ( &ActiveSocLock);
		memcpy(  &ReadySock , &ActiveSocket , sizeof( fd_set ) );
		memcpy(  &ErrorSock , &ActiveSocket , sizeof( fd_set ) );
		UnLokThreadMutex ( &ActiveSocLock);
		logDebug2("Max Socket is %d ",iMaxSoc);
		logDebug2("Suraj is inside For LOOP");
		TempRet = select( iMaxSoc + 1 , &ActiveSocket, ( fd_set * )NULL ,NULL ,(struct timeval *) NULL  );
		logDebug2("Suraj is after select");
		if( TempRet > 0 )
		{
			logDebug2("Suraj is inside if  TempRet > 0 ");
			if( FD_ISSET( MasterSocket , &ReadySock ) )
			{
				printf("\n\t INSIDE NEW CONNECTION-PRINTLOOKUP..");

				int cli_len = sizeof( struct sockaddr );

				if( ( newSock = accept( MasterSocket, &cli_addr, &cli_len ) ) == ERROR )
				{
					logPError("accept:MasterSocket");
					exit(1);
				}
				printf("\n\t accept returned=%d",newSock);

				flag = 1;
				if((setsockopt(newSock,SOL_SOCKET,SO_KEEPALIVE, ( CHAR *) &flag,sizeof(flag)))< 0)
				{
					perror("SetSockOption:");
					logDebug2("readThread::RelayId %d: Unable to set options for new socket",RelayId);
					close(newSock);
					/**     shutdown(NewSocket,2);  ***/
				}
				logDebug2("  after  setsockopt NewSocket= %d ",newSock);

				UnLokThreadMutex ( &ActiveSocLock);
				LokThreadMutex ( &LookupMutex );

				FD_SET(newSock,&ActiveSocket);
				Index = SearchForFreeSlot( );

				printf("\n\t Index=returnval of SearchForFreeSlot=%d",Index);
				if ( Index == NOT_TRUE)
				{
					printf("\n Connections Exceeds limit \n");
					close(newSock);
					FD_CLR( newSock , &ActiveSocket );
					UnLokThreadMutex ( &LookupMutex );
					continue;
				}

				UpdatePeerAddr ( &cli_addr,cli_len,Index );
				Lookup[ Index ].Socket = newSock ;
				UnLokThreadMutex ( &LookupMutex );
				AssociateSocketSignal( newSock );
				continue;
			}
			LokThreadMutex ( &PipeLock);
			if( FD_ISSET(PipeFds[0], &ReadySock ) )
			{
				printf("\n Before Reading from PipeFds ");
				read(PipeFds[0],Dummy,sizeof (Dummy));
				UnLokThreadMutex ( &PipeLock);
				continue;
			}
			else
				UnLokThreadMutex ( &PipeLock);
				printf("\niMaxSoc:%d\n",iMaxSoc);
			for( i = 0 ; i <=  iMaxSoc +2 ; i++ )
				if( FD_ISSET( i , &ActiveSocket) )
				{
					SendVal = (int *) malloc(sizeof(int));
					*SendVal = i;
					LokThreadMutex ( &ActiveSocLock);
					logDebug2("I am here");
					//	FD_CLR(i, &ActiveSocket);
					UnLokThreadMutex ( &ActiveSocLock);

					if ( MonitorFlag == ISSET )
					{
						ProcessIncomeBuffer ( SendVal );
						LokThreadMutex ( &MaxThreadMutex );
						NoOfThreads -- ;
						UnLokThreadMutex ( &MaxThreadMutex );
						continue;
					}
					WaitForMaxThreadcond ( );
					pthread_create (&ReadUseridTid,&ThreadAttr,ReadUseridThread,(void *)SendVal);
				}
				else
				{
					logDebug2("No Set");

				}
			for( i = 0 ; i <=  iMaxSoc +2 ; i++ )
				if( FD_ISSET( i , &ErrorSock ) )
				{
					logDebug2("I am here in ");					
					LokThreadMutex ( &LookupMutex );
					CleanSocketResour (i);
					UnLokThreadMutex ( &LookupMutex );
				}
		}
		else
		{
			printf("\n\t select returned value=TempRet=%d",TempRet);
			printf("\n\t Inside ELSE of select..........");
			printf("\n\terrno=%d",errno);
			perror("Select Error");
		}
	}/*** End of for loop ***/
}

void * ReadUseridThread(void * Value)
{
	int        iSelSoc;
	int        Index;
	int        iRetVal;
	int        BreakCounter = 0;
	short        BytesToRead=0;
	char      *TempBuf;
	char       Dummy[1]= "Y"  ;
	struct     LOGON_REQ       tempuser ;
	struct  INT_DWS_LOGON_RESP      pLogonResp;
	struct  INT_COMMON_REQUEST_HDR *pMesg_Pkt;
	struct  INT_COMMON_RESP_HDR     sMesg_Rsp;
	struct  timeval EndPoint2 ;
	struct  timezone tzp;
	LONG32 TransCode ;

	CHAR    Mesg_Buf[RUPEE_MAX_PACKET_SIZE];

	LONG32  iRetCurrUser=0;
	LONG32  CurrentUser=0;
	LONG32	Len;


	printf("\nThis is in ReadUseridThread.........\n");

	TempBuf = (char *) malloc (BYTES_TO_READ + 10);
	iSelSoc = *(int *)(Value);

	iRetVal = recv (iSelSoc , TempBuf , BYTES_TO_READ , MSG_PEEK );
	logDebug3("RETURN VALUE FROM RECEIVE IS: %d",iRetVal );

	printf("\n ReadUseridThread:Bytes Peeked are : %d ",iRetVal);
	if ( iRetVal == -1 )
	{
		logPError("recv");
	}
	if ( iRetVal > 0 )
	{
		BytesToRead = sizeof (struct INT_REQUEST_HEADER);
		logDebug3("BytesToRead: %d",BytesToRead);

		for ( ; ;)
		{
			iRetVal = recv ( iSelSoc , TempBuf , BytesToRead , MSG_PEEK);
			BreakCounter ++ ;

			if ( iRetVal < BytesToRead )
			{
				logDebug3 ( "ReadUseridThread1: Full packet Header  Not arrived :Break Counter %d iRetVal : %d BytesToRead : %d \n",BreakCounter , iRetVal , BytesToRead );
				if ( BreakCounter >= BREAK_COUNTER )
				{
					break;
				}
				Sleep (100);
			}
			else
			{
				BytesToRead = ((struct INT_REQUEST_HEADER * )TempBuf)->iMsgLength;
				printf("\n\t  MsgLength=%d",BytesToRead);
				logDebug3("  Tcode=[%d]",((struct INT_REQUEST_HEADER * )TempBuf)->iInternalTransCode);
				logDebug3(" UserId = %d",((struct INT_REQUEST_HEADER * )TempBuf)->iUserIdOrLogPktId);
				logDebug3("  UserType = %c",((struct INT_REQUEST_HEADER * )TempBuf)->cUserTypeOrLogInfoType);
				if ( BytesToRead > BYTES_TO_READ  || BytesToRead < 0)
				{
					BytesToRead = BYTES_TO_READ;
					break;
				}
				for ( ; ; )
				{
					iRetVal = recv (iSelSoc , TempBuf , BytesToRead , MSG_PEEK );
					BreakCounter ++;
					if (iRetVal < BytesToRead )
					{
						printf ( "\nReadUseridThread2: Full packet Header  Not arrived :Break Counter %d iRetVal : %d BytesToRead : %d \n",BreakCounter , iRetVal , BytesToRead );
						if ( BreakCounter >= BREAK_COUNTER )
						{
							break;
						}
						Sleep (100);
					}
					else
					{
						break;
					}
				}
				break;
			}
		}
	}
	else
	{
		BytesToRead = sizeof (struct INT_REQUEST_HEADER );
	}
	logDebug2("ready to Rec");
	memset ( TempBuf , NULL , BYTES_TO_READ + 10 );
	if(iRetVal = recv( iSelSoc , TempBuf , BytesToRead,0 ) == -1)
	{
		logDebug2(" RelayId %d: Error while receiving on the socket:%d ",RelayId,errno);

		usleep(500);
		LokThreadMutex(&UserSocketTableLock);
		CleanSocketResour(Index);
		UnLokThreadMutex(&UserSocketTableLock)  ;
		logDebug2(" Alok before SignalReadThreadKillCond in Recv");
		//	SignalReadThreadKillCond(READ_THREAD);
		logDebug2(" Alok After SignalReadThreadKillCond in Recv");
		usleep(500);
		return;

	}

	int UserId = ((struct INT_REQUEST_HEADER * )TempBuf)->iUserIdOrLogPktId;	
	TransCode = ((struct INT_REQUEST_HEADER * )TempBuf)->iInternalTransCode;
	switch(((struct INT_REQUEST_HEADER * )TempBuf)->iInternalTransCode)
		//	switch( ( iRetVal = recv( iSelSoc , TempBuf , BytesToRead,0 ) ) )
	{
		case TC_INT_LOGON_REQ:


			/*
			   if(iRetVal != TRUE )
			   {

			   if((iRetVal = ProcessLogOnRequest(&Index,UserId)) == FALSE)
			   {
			   logDebug2(" RelayId %d: Unable to process LogOn Request on RelayId ",RelayId);

			   usleep(500);
			   LokThreadMutex(&UserSocketTableLock)       ;
			   CleanSocketResour(Index);
			   UnLokThreadMutex(&UserSocketTableLock)   ;

			   break;

			   }

			   }

			 */			pLogonResp.IntRespHeader.iErrorId = 0;



			//		iRetCurrUser =Find_Max_User(&CurrentUser);
			logDebug2("MaxUser = [%d] CurrentUser = [%d]",dMaxUser,CurrentUser);

			/*			if(CurrentUser >= dMaxUser)
						{
						pLogonResp.IntRespHeader.iErrorId= 4200;
						logDebug2(" Max user violated :%d:",pLogonResp.IntRespHeader.iErrorId);
						}
			 */
			logDebug2("I am here to send response ");
			pLogonResp.IntRespHeader.iMsgLength = sizeof(struct  INT_DWS_LOGON_RESP);
			logDebug2("I am here to send response again ");
			pLogonResp.IntRespHeader.iMsgCode = TC_INT_LOGON_RSP;
			logDebug2("I am here to send response again 2 ");
			pLogonResp.IntRespHeader.iTimeStamp= 0;
			logDebug2("I am here to send response again 3 ");
			pLogonResp.IntRespHeader.iUserId= UserId;
			//                      pLogonResp.IntRespHeader.UserTypeOrLogInfoType=0;

			logDebug2(" pLogonResp.IntRespHeader.iErrorId:%d:",pLogonResp.IntRespHeader.iErrorId);

			logDebug2(" pLogonResp.IntRespHeader.iUserId:%d:",pLogonResp.IntRespHeader.iUserId);

			/********** ALOKK HARDCODED NEED TO REMOVE LATER********************/
			strncpy(pLogonResp.sEntityId,"",12);
			strncpy(pLogonResp.AccCode,"",12);
			strncpy(pLogonResp.sName,"",60);
			strncpy(pLogonResp.CurrDate,"20120930",20);

			strncpy(pLogonResp.ExpiryDate,"20120930",20);
			strncpy(pLogonResp.AllowedExch,"1111000",10);
			strncpy(pLogonResp.cfprimaryip,"121.241.245.76",16);
			strncpy(pLogonResp.cffailoverip,"121.241.245.76",16);
			strncpy(pLogonResp.dsprimaryip,"121.241.245.76",16);
			strncpy(pLogonResp.failoverip,"121.241.245.76",16);
			strncpy(pLogonResp.TransPass,"abc123",16);
			pLogonResp.Suscriptionlevel = 7;


			/********** ALOKK HARDCODED NEED TO REMOVE LATER********************/

			Len = pLogonResp.IntRespHeader.iMsgLength;
			logDebug2(" iUserId%d",pLogonResp.IntRespHeader.iUserId);
			logDebug2(" iMsgLength %d",pLogonResp.IntRespHeader.iMsgLength);
			logDebug2(" iMsgCode %d",pLogonResp.IntRespHeader.iMsgCode);
			logDebug2(" sEntityId %s",pLogonResp.sEntityId);
			logDebug2(" AccCode %s",pLogonResp.AccCode);
			logDebug2(" sName %s",pLogonResp.sName);
			logDebug2(" pLogonResp.CurrDate %s",pLogonResp.CurrDate);
			logDebug2(" pLogonResp.ExpiryDate %s",pLogonResp.ExpiryDate);
			logDebug2(" pLogonResp.cfprimaryip %s",pLogonResp.cfprimaryip);
			logDebug2(" pLogonResp.cffailoverip %s",pLogonResp.cffailoverip);
			logDebug2(" pLogonResp.dsprimaryip %s",pLogonResp.dsprimaryip);
			logDebug2(" pLogonResp.failoverip %s",pLogonResp.failoverip);
			logDebug2(" pLogonResp.AllowedExch %s",pLogonResp.AllowedExch);
			logDebug2(" pLogonResp.Suscriptionlevel %d",pLogonResp.Suscriptionlevel);
			logDebug2(" pLogonResp.TransPass :%s:",pLogonResp.TransPass );



			//	LokThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
			logDebug2(" Socket FD = [%d]", iSelSoc);


			if((Send(iSelSoc,&pLogonResp,&Len ))== ERROR)
			{
				logDebug2(" RelayId %d: Error While sending logon response to user TC_INT_LOGON_REQ ",RelayId);
				LokThreadMutex(&UserSocketTableLock)       ;
				CleanSocketResour(Index);
				UnLokThreadMutex(&UserSocketTableLock)   ;
			}
			//			UnLokThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

			logDebug2(" RWT::RelayId %d: LogOn Resp being sent to user:%d, iMsgLength = %d",RelayId,sMesg_Rsp.iUserId,sMesg_Rsp.iMsgLength);


			break;

		case TC_INT_KEEP_ALIVE_REQ:

			sMesg_Rsp.iUserId= pMesg_Pkt-> iUserId;
			sMesg_Rsp.cSegment = pMesg_Pkt->cSegment;
			//                      sMesg_Rsp.UserTypeOrLogInfoType = pMesg_Pkt->cUserType;
			sMesg_Rsp.iMsgLength= sizeof(struct INT_COMMON_RESP_HDR);
			sMesg_Rsp.iErrorId= 0;
			sMesg_Rsp.iTimeStamp= 0;
			sMesg_Rsp.iMsgCode= TC_INT_KEEP_ALIVE_RESP;
			Len = sMesg_Rsp.iMsgLength;

			//		LokThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");

			if((Send(iSelSoc,&sMesg_Rsp,&Len ))== ERROR)
			{
				//				UnLokThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
				logDebug2(" RelayId %d: Error While sending response to user TC_INT_KEEP_ALIVE_REQ ",RelayId);
				LokThreadMutex(&UserSocketTableLock)   ;
				CleanSocketResour(Index);
				UnLokThreadMutex(&UserSocketTableLock)   ;

			}

			//		UnLokThreadMutex(&UserSocketTable[Index].UserSocketLock,"SendData");
			logDebug2(" RWT::RelayId %d: LogOn Resp being sent to user TC_INT_KEEP_ALIVE_REQ:%d, iMsgLength= %d",RelayId, sMesg_Rsp.iUserId, sMesg_Rsp.iMsgLength);
			break;





		case TC_INT_RECONNECT_REQ :


			logDebug2(" I am in reconnect");
			/*			if(iRetVal != TRUE )
						{

						logDebug2(" iRetVal is [%d] in TC_INT_RECONNECT_REQ going to ProcessLogOnRequest",iRetVal);
						if((iRetVal = ProcessLogOnRequest(&Index,UserId)) == FALSE)
						{
						logDebug2(" RelayId %d: Unable to process LogOn Request on RelayId ",RelayId);
						usleep(500);
						LokThreadMutex(&UserSocketTableLock)       ;
						CleanSocketResour(Index);
						UnLokThreadMutex(&UserSocketTableLock)   ;
						break;

						}
						}

			 */			logDebug2(" ALOK here after reconnect");

			sMesg_Rsp.iMsgLength= sizeof(struct INT_COMMON_RESP_HDR);
			sMesg_Rsp.iUserId=  pMesg_Pkt->iUserId;
			//                      sMesg_Rsp.UserTypeOrLogInfoType =  pMesg_Pkt->cUserType;
			sMesg_Rsp.iMsgCode= TC_INT_RECONNECT_RESP ;

			Len = sMesg_Rsp.iMsgLength;


			logDebug2(" Socket FD = [%d]", iSelSoc);


			if((Send(iSelSoc,&sMesg_Rsp,&Len))== ERROR)

			{
				logDebug2(" RelayId %d: Error While sending logon response to user TC_INT_RECONNECT_REQ Index[%d]",RelayId,Index);
				LokThreadMutex(&UserSocketTableLock)       ;
				CleanSocketResour(Index);
				UnLokThreadMutex(&UserSocketTableLock)   ;

			}


			logDebug2(" ALOK here after reconnect 3");

			break;
		case    TC_INT_LOGOFF_REQ :


			usleep(500);

			LokThreadMutex(&UserSocketTableLock,"CleanSocketResourWrongLogOnReq")       ;
			CleanSocketResour(Index);
			UnLokThreadMutex(&UserSocketTableLock,"CleanSocketResourWrongLogOnReq")   ;

			break;


			/*
			 * INQUIRY TRANSCODES
			 */

			//              case    TC_INT_PASSWD_CHANGE_REQ:
		case    TC_INT_VIEW_CLIENT_LIMIT_REQ:
		case    TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
		case    TC_INT_NET_POS_REQ:
		case    TC_INT_ORDER_BOOK_REQ:
		case    TC_INT_SPRD_ORD_BOOK_REQ:
		case    TC_INT_ORDER_BOOK_DTLS_REQ:
		case    TC_INT_BO_ORDER_BOOK_DTLS_REQ:
		case    TC_INT_TRADE_BOOK_REQ:
			//              case    TC_INT_ADMIN_TRADE_BOOK_REQ:
		case    TC_INT_CLINET_HOLDING_REQ:
		case    TC_INT_NETPOS_DTL_REQ:
		case    TC_INT_CARRY_FWD_POS_REQ:
		case    TC_INT_DEA_CLIENT_MAPP_REQ:
			//              case    TC_INT_ADMIN_CONVT_TO_DELV_REQ:
		case    TC_INT_SEND_MSG_TO_CLIENT_REQ:
		case    TC_INT_DNLD_SYSTEM_MSG_REQ:
		case    TC_INT_REJECTED_ORDERS_REQ:
		case    TC_INT_BO_ORDER_BOOK_REQ:
		case    TC_INT_SIP_ORDER_BOOK_REQ:
		case    TC_INT_SIP_ORDER_DETS_REQ:
		case    TC_INT_SIP_ORDER_TRALS_REQ:
		case    TC_INT_MKT_STATUS_REQ   :
		case    TC_INT_VIEW_CLIENT_LIMIT_DET_REQ :

			logDebug2("Before Write Q");

			if((WriteMsgQ(iRelToQuery,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)

			{

				logDebug2(" RelayId %d: Error While writing to Query Queue ",RelayId);

			}

			logDebug2(" RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToQuery);

			break;
		case    TC_INT_ORDER_ENTRY_REQ                  :
		case    TC_INT_ORDER_MODIFY                     :
		case    TC_INT_ORDER_CANCEL                     :

		case    TC_INT_SPREAD_OE_REQ                    :
		case    TC_INT_SPREAD_OM_REQ                    :
		case    TC_INT_SPREAD_OC_REQ                    :

		case    TC_INT_OFF_ORDER_ENTRY                  :
		case    TC_INT_OFF_ORDER_MODIFY                 :
		case    TC_INT_OFF_ORDER_CANCEL                 :
		case    TC_INT_NOTIFICATION_REQ                 :

		case    TC_INT_SQUAREOFF_INTRADAY_REQ           :
		case    TC_INT_PUMPOFFLINE_REQ                  :
		case    TC_INT_ADMIN_EXPIRY_REQ                 :
		case    TC_INT_CON_DEL_REQ                      :

		case    TC_INT_SIP_ORD_REQ                      :
		case    TC_INT_SIP_ORD_CANCEL                   :
		case    TC_INT_SIP_ORD_PAUSE_REQ                :
		case    TC_INT_SIP_ORD_CONTINUE_REQ             :

		case    TC_INT_CREATE_ALL_FILE_REQ              :

		case    TC_INT_MTM_AUTO_SQR_OFF                 :

		case    TC_INT_CO_MRG_CAL_REQ           :
		case    TC_INT_BO_MRG_CAL_REQ           :
		case    TC_INT_MRG_CAL_REQ              :

			if((WriteMsgQ(iRelToOrdRtr,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
			{
				logFatal(" RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
			}

			gettimeofday(&EndPoint2, &tzp);
			logDebug2(" RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToOrdRtr);

			break;


		case    TC_INT_CO_ORDER_REQ     :
		case    TC_INT_CO_ORDER_MODIFY  :
		case    TC_INT_CO_ORDER_EXIT    :
		case    TC_INT_BO_ORDER_REQ     :
		case    TC_INT_BO_ORDER_MODIFY  :
		case    TC_INT_BO_ORDER_EXIT    :

			if((WriteMsgQ(iRelToOrdRtr,Mesg_Buf,pMesg_Pkt->iMsgLength,1)) < 0)
			{
				logDebug2(" RelayId %d: Error While writing to BcastQuery Queue ",RelayId);
			}

			gettimeofday(&EndPoint2, &tzp);
			EndPoint2.tv_sec = EndPoint2.tv_sec+19800;
			logDebug2(" Time of exit is ReadWorkerThread :%d:",EndPoint2.tv_sec);
			logDebug2(" Cover Order Request MsgCode = %d",TC_INT_CO_ORDER_REQ);
			logDebug2(" RelayId %d: Successfully Written To The Q : %d",RelayId,iRelToOrdRtr);

			break;

		case SOCKET_CLOSE :
		case SOCKET_ERROR :
		case BYTES_TO_READ :

			printf("\n\t 1.INSIDE SWITCH -- RETURN VALUE FROM RECEIVE IS: %d",iRetVal );
			logPError("recv");
			printf("\nReadUseridThread:Socket = %d Is selected for closing\n",iSelSoc);
			printf("\nReadUseridThread:No of Bytes read from socket = %d %d\n", iRetVal,BytesToRead );
			LokThreadMutex ( &LookupMutex );
			Index=SearchIndex(iSelSoc);
			tempuser.UserId = Lookup[ Index ].user.UserId ;
			tempuser.UserType = Lookup[ Index ].user.UserType ;
			memcpy(TempBuf,&tempuser,sizeof(struct LOGON_REQ ));
			CleanSocketResour( iSelSoc );
			UnLokThreadMutex ( &LookupMutex );

			break ;
		default        :
			printf("\n\t 2.INSIDE SWITCH -- RETURN VALUE FROM RECEIVE IS: %d",iRetVal );
			if ( BreakCounter >= BREAK_COUNTER )
			{
				SenderrorResponce (iSelSoc,COMPLETE_PACKET_NOT_RECEIVED );
				LokThreadMutex ( &LookupMutex );
				CleanSocketResour( iSelSoc );
				UnLokThreadMutex ( &LookupMutex );
				break;
			}
			ProcessIncomePacket ( TempBuf , iRetVal , iSelSoc );
			break ;
	}
	logDebug2("\n Alok here before SignalReadThreadKillCond 1");

	//	SignalReadThreadKillCond(READ_THREAD);
	logDebug2("\n Alok here after SignalReadThreadKillCond 1");

	free(Value);
	free(TempBuf);
	SendMaxThreadCondSig ( );
}


void * WriteDloadThread (void * dummy)
{
	int            Index , count ,socket;
	char           *cpDloadMsgBuf;//[ BSS_MESSAGE_SIZE ];
	struct         LOGON_REQ TempBuf ;
	int         packetcount=1;
	LONG32	Downloadq;

	printf("\nThis is in WriteDloadThread.........\n");

	for(;;)
	{
		GetPacketFromDloadQueue( cpDloadMsgBuf , Downloadq );
		LokThreadMutex ( &LookupMutex );
		if( ( Index = GetIndexForPacket(cpDloadMsgBuf ) ) == NOT_TRUE )
		{

			TempBuf.UserId = ((struct INT_RESP_HEADER * )cpDloadMsgBuf )->iUserIdOrLogPktId ;
			TempBuf.UserType = ((struct INT_RESP_HEADER *)cpDloadMsgBuf)->cUserTypeOrLogInfoType ;
			UnLokThreadMutex ( &LookupMutex );
			continue ;
		}
		socket = Lookup[Index].Socket ;
		UnLokThreadMutex ( &LookupMutex );
		SendDloadPacketToUser( socket,cpDloadMsgBuf ) ;
		TempBuf.UserId = ((struct INT_RESP_HEADER * )cpDloadMsgBuf )->iUserIdOrLogPktId ;
		TempBuf.UserType = ((struct INT_RESP_HEADER *)cpDloadMsgBuf)->cUserTypeOrLogInfoType ;
		printf("Dload packet send to user: %d of Type %c",TempBuf.UserId,TempBuf.UserType);
	}
}

void * WriteThread (int * queueid)
{
	int            queue_to_readfrom,Index , count ,socket;
	char           *cpMsgBuf;//[ BSS_MESSAGE_SIZE ];
	struct         LOGON_REQ TempBuf ;

	queue_to_readfrom = (LONG32 *)queueid;


	printf("\nThis is in WriteThread.........\n");
	printf("The queue_to_readfrom for this thread is %d\n",queue_to_readfrom);

	for(;;)
	{
		logDebug2("Going to read from Queue ");
		GetPacketFromQueue( cpMsgBuf , queue_to_readfrom );
		LokThreadMutex ( &LookupMutex );

		if( ( Index = GetIndexForPacket(cpMsgBuf ) ) == NOT_TRUE )
		{

			TempBuf.UserId = ((struct INT_RESP_HEADER * )cpMsgBuf )->iUserIdOrLogPktId ;
			TempBuf.UserType = ((struct INT_RESP_HEADER *)cpMsgBuf)->cUserTypeOrLogInfoType ;
			UnLokThreadMutex ( &LookupMutex );
			continue ;
		}

		socket = Lookup[Index].Socket ;
		UnLokThreadMutex ( &LookupMutex );

		SendPacketToUser( socket,cpMsgBuf ) ;
		TempBuf.UserId = ((struct INT_RESP_HEADER * )cpMsgBuf )->iUserIdOrLogPktId ;
		TempBuf.UserType = ((struct INT_RESP_HEADER *)cpMsgBuf)->cUserTypeOrLogInfoType ;
	}
}

void * WriteUserThread (void * MsgStruct)
{
	struct        MsgSocketStruct *pMsgStruct;
	int           Index;
	LONG32  dErrno = 0;
	LONG32  flags_old;
	LONG32  errCount = 0;

	printf("\nThis is in WriteUserThread.........\n");
	pMsgStruct = (struct MsgSocketStruct *) MsgStruct;
	printf("\n Write: %d : %d \n",pMsgStruct->Socket,((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength );

	if( ( Index = SearchIndex( pMsgStruct->Socket ) ) == NOT_TRUE )
	{
		UnLokThreadMutex ( &SendMutexSeq );
		return ;
	}

	UnLokThreadMutex ( &SendMutexSeq );
	LokThreadMutex ( &Lookup[Index].SendMutex );

	if ( SendNB( pMsgStruct->Socket, pMsgStruct->cpMsgBuf, ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength ,&dErrno ) < 0 )
	{
		if(dErrno == ENOTCONN)
			printf(" error ENOTCONN encountered while sending  data to socket %d ",pMsgStruct->Socket);
		if(dErrno == ECONNABORTED)
			printf(" error ECONNABORTED encountered while sending  data to socket %d ",pMsgStruct->Socket);
		if(dErrno == ECONNRESET)
			printf(" error ECONNRESET encountered while sending  data to socket %d ",pMsgStruct->Socket);
		if(dErrno == ENETDOWN)
			printf(" error ENETDOWN encountered while sending  data to socket %d ",pMsgStruct->Socket);
		if(dErrno == ETIMEDOUT)
			printf(" error ETIMEOUT encountered while sending  data to socket %d ",pMsgStruct->Socket);

		struct LOGON_REQ TempBuf ;

		UnLokThreadMutex ( &Lookup[Index].SendMutex );
		TempBuf.UserId = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iUserIdOrLogPktId ;
		TempBuf.UserType = ((struct INT_RESP_HEADER *)(pMsgStruct->cpMsgBuf))->cUserTypeOrLogInfoType ;

		LokThreadMutex ( &LookupMutex );
		if ( dErrno == EAGAIN )
		{
			SenderrorResponce (pMsgStruct->Socket,ERR_RECONNECT_AGAIN );
		}

		CleanSocketResour(pMsgStruct->Socket);
		UnLokThreadMutex ( &LookupMutex );
	}

	struct INT_RESP_HEADER TempBuf1 ;
	TempBuf1.iUserIdOrLogPktId = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iUserIdOrLogPktId ;
	TempBuf1.iMsgCode = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iMsgCode ;
	TempBuf1.iSeqNo = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iSeqNo ;
	UnLokThreadMutex ( &Lookup[Index].SendMutex );

	free(pMsgStruct);

	SendMaxThreadCondSigWrite ( );
}



void * WriteUserDloadThread (void * MsgStruct)
{
	struct        MsgSocketStruct *pMsgStruct;
	int           Index;
	LONG32      dErrno ;              
	struct timeval Time2;


	printf("\nThis is in WriteUserDloadThread.........\n");

	pMsgStruct = (struct MsgSocketStruct *) MsgStruct;

	if( ( Index = SearchIndex( pMsgStruct->Socket ) ) == NOT_TRUE )
	{
		UnLokThreadMutex ( &SendMutexSeq );
		return ;
	}
	UnLokThreadMutex ( &SendMutexSeq );
	LokThreadMutex ( &Lookup[Index].SendMutex );


	if ( SendNB( pMsgStruct->Socket, pMsgStruct->cpMsgBuf, ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength ,&dErrno ) < 0 )
	{
		struct LOGON_REQ TempBuf ;
		UnLokThreadMutex ( &Lookup[Index].SendMutex );
		TempBuf.UserId = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iUserIdOrLogPktId ;
		TempBuf.UserType = ((struct INT_RESP_HEADER *)(pMsgStruct->cpMsgBuf))->cUserTypeOrLogInfoType ;

		LokThreadMutex ( &LookupMutex );

		if ( dErrno == EAGAIN )
		{
			SenderrorResponce (pMsgStruct->Socket,ERR_RECONNECT_AGAIN );
		}

		CleanSocketResour(pMsgStruct->Socket);
		UnLokThreadMutex ( &LookupMutex );
	}



	UnLokThreadMutex ( &Lookup[Index].SendMutex );
	free(pMsgStruct);
	SendMaxDloadThreadCondSigWrite ( );
}


int GetMaxSocket()
{
	int Index;
	pid_t   temp;
	int MaxSoc = MasterSocket;

	temp = getpid();

	LokThreadMutex ( &LookupMutex );
	for (Index = 0 ; Index < MAX_NO_OF_USERS ; Index ++)
	{
		if((MaxSoc < Lookup[Index].Socket) && (Lookup[Index].Socket != UNUSED))
		{
			MaxSoc = Lookup[Index].Socket;
		}
	}

	UnLokThreadMutex ( &LookupMutex );
	LokThreadMutex ( &PipeLock);

	if (PipeFds[0] > MaxSoc)
	{
		MaxSoc = PipeFds[0];
	}

	UnLokThreadMutex ( &PipeLock);
	return (MaxSoc);
}

void WriteToRms (int id, char * cpMsgBuf,int Size)
{
	INT16 msg_type=1;
	struct INT_REQUEST_HEADER *BfslHeader;

	BfslHeader=(struct INT_REQUEST_HEADER *)cpMsgBuf;

	if(WriteMsgQ(id,cpMsgBuf,Size,msg_type)==FALSE)
	{
		printf("\n Error in writting to MsgRms\n");
	}

	printf("\n\t Written Tcode : %d QID : %d msg_type = %d ",BfslHeader->iInternalTransCode , id , msg_type )  ;
}

void LokThreadMutex ( pthread_mutex_t * mutex)
{
	if(  pthread_mutex_lock (mutex ) != 0)
	{
		logPError("pthread_mutex_lock");
		exit(1);
	}
}


void UnLokThreadMutex ( pthread_mutex_t * mutex)
{
	if(  pthread_mutex_unlock ( mutex ) != 0)
	{
		logPError("pthread_mutex_unlock");
		exit(1);
	}
}

void ProcessArguments ( char ** argv )
{
	RelayType = atoi ( argv[1]);

	printf("\nRelayType				: %d",  RelayType );
	printf("\nRelayPort				: %d",   atoi ( argv[2]) );

	if ( RelayType <= 0 )
	{
		printf ( " Wrong Relay Type ");
		exit (1);
	}
	RelayPort = atoi ( argv[2]);
	if ( RelayPort <= 0 )
	{
		printf ( " Wrong Relay Port ");
		exit (1);
	}
}

int AddinShmData (int UserId, struct sockaddr_in *PeerAddr, char UserType)
{
	int   i,j,k=0;
	LONG32  CurrentUser=0           ;               
	BOOL iRetVal = FALSE;                          
	struct user_relay_array *Ptr;
	LONG32 		dMaxUser;

	iRetVal=Find_Max_User(&CurrentUser);
	printf("\nMaxUser = [%d]",dMaxUser);
	printf("\nCurrentUser = [%d]",CurrentUser);
	if(CurrentUser >= dMaxUser)
	{
		printf("\n Max user violated");
		return FALSE;
	}
	LockShm(DirRelShm);

	Ptr = OpenSharedMemory(DirRelShm,DirRelShm_SIZE);
	if ( *( (int *) Ptr) == ERROR )
	{
		exit(1);
	}

	for ( i=0 ; i < MAX_USERS ; i++ )
	{
		if ( Ptr->user_relay[i].iUserId == UNUSED )
		{
			Ptr->user_relay[i].iUserId = UserId;
			Ptr->user_relay[i].iRelayId = RelayId;
			Ptr->user_relay[i].iProcessId = getpid();
			Ptr->user_relay[i].iCheck = UNUSED;
			memcpy(&(Ptr->user_relay[i].PeerAddr),PeerAddr,sizeof(struct sockaddr_in));
			memset ( &(Ptr->user_relay[i].sClientId ), ' ' , CLIENT_ID_LEN )  ;
			Ptr->user_relay[i].cUserType = UserType ;

			printf ("\n \tCHK 2 Value of errno is %d", errno);
			break;
		}
	}
	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		exit(1);
	}

	UnLockShm(DirRelShm);
	return TRUE;                                    
}


void DltShmRelayData ( int UserId )
{
	int   i,j, k ;
	struct user_relay_array *Ptr;

	printf("\n I am in DltShmRelayData ");
	LockShm(DirRelShm);

	Ptr = OpenSharedMemory(DirRelShm,DirRelShm_SIZE);

	if ( *( (int *) Ptr) == ERROR )
	{
		exit(1);
	}
	for ( i=0 ; i < MAX_USERS ; i++ )
	{
		if ( Ptr->user_relay[i].iUserId == UserId && Ptr->user_relay[i].iRelayId == RelayId)
		{
			Ptr->user_relay[i].iUserId = UNUSED;
			Ptr->user_relay[i].iRelayId = UNUSED;
			Ptr->user_relay[i].iCheck = UNUSED;
			Ptr->user_relay[i].iProcessId = UNUSED;
			Ptr->user_relay[i].cUserType = ' ' ;
			memset ( &(Ptr->user_relay[i].sClientId ), ' ' , CLIENT_ID_LEN )  ;
			break;
		}
	}
	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		exit(1);
	}
	UnLockShm(DirRelShm);
}


void DeleteRelayUserShm ( int ProcessId )
{
	int   i, j;
	struct user_relay_array *Ptr;
	printf("\n I am in DeleteRelayUserShm :%d", ProcessId );

	LockShm(DirRelShm);

	Ptr = OpenSharedMemory(DirRelShm,DirRelShm_SIZE);
	if ( *( (int *) Ptr) == ERROR )
	{
		exit(1);
	}

	printf("\n Successfully Opened DirRelShm");
	for ( i=0 ; i < MAX_USERS ; i++ )
	{
		if ( Ptr->user_relay[i].iRelayId == ProcessId )
		{
			Ptr->user_relay[i].iUserId = UNUSED;
			Ptr->user_relay[i].iRelayId = UNUSED;
			Ptr->user_relay[i].iCheck = UNUSED;
			Ptr->user_relay[i].iProcessId = UNUSED;
		}
	}

	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		exit(1);
	}
	UnLockShm(DirRelShm);
}

void WaitForMaxThreadcond ( )
{
	LokThreadMutex ( &MaxThreadMutex );
	while ( NoOfThreads >= MAX_THREADS )
	{
		if ( pthread_cond_wait (&MaxThreadCond,&MaxThreadMutex )  < 0)
		{
			logPError("pthread_cond_wait:MaxThreadCond");
			exit (1);
		}
	}
	NoOfThreads ++ ;
	printf ( "\nWaitForMaxThreadCond: Present No of Read Threads : %d out of %d \n",NoOfThreads,MAX_THREADS );

	if ( NoOfThreads >= (MAX_THREADS -1))
	{
		MonitorFlag = ISSET ;
	}
	else
	{
		MonitorFlag = UNSET ;
	}

	UnLokThreadMutex ( &MaxThreadMutex );
}

void WaitForMaxThreadCondWrite ( )
{
	LokThreadMutex ( &MaxThreadMutexWrite );
	while ( NoOfThreadsWrite >= MAX_THREADS_WRITE )
	{
		if ( pthread_cond_wait (&MaxThreadCondWrite,&MaxThreadMutexWrite )  < 0)
		{
			logPError("pthread_cond_wait:MaxThreadCondWrite");
			exit (1);
		}
	}
	NoOfThreadsWrite ++ ;

	printf ( "\n Present No of Write Threads : %d \n",NoOfThreadsWrite );

	if ( NoOfThreadsWrite >= (MAX_THREADS_WRITE -1))
	{
		MonitorWriteFlag = WRITEISSET ;
	}
	else
	{
		MonitorWriteFlag = WRITEUNSET ;
	}

	UnLokThreadMutex ( &MaxThreadMutexWrite );
}


void WaitForMaxDloadThreadCondWrite ( )
{
	LokThreadMutex ( &MaxDloadThreadMutexWrite );
	while ( NoOfDloadThreadsWrite >= MAX_DLOAD_THREADS_WRITE )
	{
		if ( pthread_cond_wait (&MaxDloadThreadCondWrite,&MaxDloadThreadMutexWrite )  < 0)
		{
			logPError("pthread_cond_wait:MaxDloadThreadCondWrite");
			exit (1);
		}
	}
	NoOfDloadThreadsWrite ++ ;

	printf ( "\n Present No of WriteDload Threads : %d \n",NoOfDloadThreadsWrite );


	if ( NoOfDloadThreadsWrite >= (MAX_DLOAD_THREADS_WRITE -1))
	{
		MonitorDloadFlag = DLDISSET ;
	}
	else
	{
		MonitorDloadFlag = DLDUNSET ;
	}

	UnLokThreadMutex ( &MaxDloadThreadMutexWrite );

}

void SendMaxThreadCondSig ( )
{
	LokThreadMutex ( &MaxThreadMutex );
	if ( NoOfThreads <= (MAX_THREADS -2) )
	{
		MonitorFlag = UNSET ;
	}
	else
	{
		MonitorFlag = ISSET ;
	}
	UnLokThreadMutex ( &MaxThreadMutex );

	LokThreadMutex ( &MaxThreadMutex );
	NoOfThreads -- ;

	if ( pthread_cond_signal ( &MaxThreadCond ) < 0)
	{
		logPError("pthread_cond_signal:MaxThreadCond");
		exit (1);
	}
	UnLokThreadMutex ( &MaxThreadMutex );
	printf ( "\n SendMaxThreadCondSig: Present No of Read Threads : %d \n",NoOfThreads );
}

void SendMaxThreadCondSigWrite ( )
{

	LokThreadMutex ( &MaxThreadMutexWrite );
	if ( NoOfThreadsWrite <= (MAX_THREADS_WRITE -2) )
	{
		MonitorWriteFlag = WRITEUNSET ;
	}
	else
	{
		MonitorWriteFlag = WRITEISSET ;
	}
	UnLokThreadMutex ( &MaxThreadMutexWrite );


	LokThreadMutex ( &MaxThreadMutexWrite );
	NoOfThreadsWrite -- ;
	if ( pthread_cond_signal ( &MaxThreadCondWrite ) < 0)
	{
		logPError("pthread_cond_signal:MaxThreadCondWrite");
		exit (1);
	}
	UnLokThreadMutex ( &MaxThreadMutexWrite );
	printf ( "\n Present No of Write Threads : %d \n",NoOfThreadsWrite );
}


void SendMaxDloadThreadCondSigWrite ( )
{

	LokThreadMutex ( &MaxDloadThreadMutexWrite );
	if ( NoOfDloadThreadsWrite <= (MAX_DLOAD_THREADS_WRITE -2) )
	{
		MonitorDloadFlag = DLDUNSET ;
	}
	else
	{
		MonitorDloadFlag = DLDISSET ;
	}
	UnLokThreadMutex ( &MaxDloadThreadMutexWrite );


	LokThreadMutex ( &MaxDloadThreadMutexWrite );
	NoOfDloadThreadsWrite -- ;
	if ( pthread_cond_signal ( &MaxDloadThreadCondWrite ) < 0)
	{
		logPError("pthread_cond_signal:MaxDloadThreadCondWrite");
		exit (1);
	}
	UnLokThreadMutex ( &MaxDloadThreadMutexWrite );
	printf ( "\n Present No of DloadWrite Threads : %d \n",NoOfDloadThreadsWrite );
}

void UpdateForkProcess (int ForkInd ,int ForkPort,int ForkRelay )
{
	int  i;
	for ( i =0 ; i<MAX_NO_OF_PROCESS; i++ )
	{
		if ( ForkProcess[i].ProcessId  == UNUSED  )
		{
			ForkProcess[i].ProcessId = ForkInd;
			ForkProcess[i].RelayId = ForkRelay;
			ForkProcess[i].RelayPort = ForkPort;
			break;
		}
	}
}

void UpdateForkProcessForRestart ( int ForkInd )
{
	int i;
	printf ("\n In UpdateForkProcessRestart \n");
	for ( i =0 ; i<MAX_NO_OF_PROCESS; i++ )
	{
		if ( ForkProcess[i].ProcessId  == ForkInd  )
		{
			ForkProcess[i].ProcessId = RESTART;
			break;
		}
	}
}


void ProcessIncomePacket (char * ReadData, int PacketSize, int Socket )
{
	struct INT_REQUEST_HEADER *BfslHeader;
	struct ORDER_REQUEST	pOe_Request; 


	char       Dummy[1]= "Y"  ;
	int Index ,k ;
	struct timeval Time2;
	memset(&pOe_Request,0,sizeof(struct ORDER_REQUEST));		

	printf ("\n In Process IncomePacket \n");
	BfslHeader = (struct INT_REQUEST_HEADER * ) ReadData ;
	printf("\n BfslHeader = %d",BfslHeader);

	if ( BfslHeader -> iMsgLength != PacketSize )
	{
		SenderrorResponce (Socket,PACKET_SIZE_MISMATCH );
		printf("\n MsgLength : %d" , BfslHeader -> iMsgLength );
		printf("\n\t PacketSize : %d", PacketSize ) ;
		printf("\n\t Transcode :%d:",BfslHeader->iInternalTransCode);
		LokThreadMutex ( &LookupMutex );
		CleanSocketResour( Socket );
		UnLokThreadMutex ( &LookupMutex );
		return;
	}
	gettimeofday(&Time2,NULL);
	printf("\nReceived Transcode is %d, From  UserId : %d MsgLength=%d ",BfslHeader->iInternalTransCode , BfslHeader->iUserIdOrLogPktId,BfslHeader->iMsgLength );

	printf ("\n%ld,%d,%d,%d,RecvTIMECHECK\n",Time2.tv_sec ,BfslHeader->iInternalTransCode ,BfslHeader->iUserIdOrLogPktId,BfslHeader->iSeqNo );

	switch (BfslHeader -> iInternalTransCode)
	{
		case TC_INT_LOGON_REQ:

			printf("Socket = %d Selected for setting UserId \n",Socket);
			printf("No of Bytes read from socket = %d\n", PacketSize );
			printf("Socket = %d \n" , Socket );

			LokThreadMutex ( &ActiveSocLock);
			FD_SET(Socket,&ActiveSocket);
			UnLokThreadMutex ( &ActiveSocLock);
			LokThreadMutex ( &LookupMutex );
			SetUserId( Socket , ReadData );
			UnLokThreadMutex ( &LookupMutex );
			LokThreadMutex ( &PipeLock);
			write(PipeFds[1],Dummy,sizeof(Dummy));
			UnLokThreadMutex ( &PipeLock);
			break ;

		case TC_INT_ORDER_ENTRY_REQ :
		case TC_INT_ORDER_MODIFY_REQ :
		case TC_INT_ORDER_CANCEL_REQ : 
		case  TC_INT_OFF_ORDER_ENTRY:
		case  TC_INT_OFF_ORDER_MODIFY:
		case  TC_INT_OFF_ORDER_CANCEL:

			printf("Socket = %d  with correct trans code \n",Socket);
			printf("No of Bytes read from socket = %d\n", PacketSize );

			LokThreadMutex ( &LookupMutex );
			Index=SearchIndex(Socket);
			printf("\n UserId :%d",BfslHeader->iUserIdOrLogPktId);
			printf("\n UserType:%c",BfslHeader->cUserTypeOrLogInfoType);
			printf("\n Index [%d]",Index);
			if( BfslHeader->iUserIdOrLogPktId != Lookup[ Index ].user.UserId || BfslHeader->cUserTypeOrLogInfoType != Lookup[ Index ].user.UserType || Lookup [Index ].user.UserId == UNUSED )
			{
				printf("\n inside if condition ");
				SenderrorResponce (Socket,INTEACTIVE_USER_ID_TYPE_MISMATCH );
				CleanSocketResour( Socket );
				UnLokThreadMutex ( &LookupMutex );
				break;
			}

			UnLokThreadMutex ( &LookupMutex );
			LokThreadMutex ( &ActiveSocLock);
			FD_SET(Socket,&ActiveSocket);
			UnLokThreadMutex ( &ActiveSocLock);
			LokThreadMutex ( &PipeLock);
			write(PipeFds[1],Dummy,sizeof(Dummy));
			UnLokThreadMutex ( &PipeLock);
			memcpy(&pOe_Request,ReadData,BfslHeader->iMsgLength);
			//	pOe_Request.dReceivedTime = Sysdate(1,1);
			pOe_Request.ReqHeader.iMsgLength= sizeof(struct ORDER_REQUEST);
			if(WriteMsgQ(iRelToOrdRtr,&pOe_Request,sizeof(struct ORDER_REQUEST),1)!=1)
			{
				printf("WRITEQ fata");
			}
			break;



		default:
			SenderrorResponce (Socket,INVALID_TRANSCODE );
			logDebug3("\n INVALID TCODE : %d ", BfslHeader ->iInternalTransCode );
			LokThreadMutex ( &LookupMutex );
			CleanSocketResour( Socket );
			UnLokThreadMutex ( &LookupMutex );
	}
}


void SenderrorResponce ( int Socket,int ErrorId )
{
	struct INT_ERRORRESPONCESEND ErrorResponceSend;
	char temp1[4];
	char temp11[14];
	char temp2[14];
	char temp3[50];
	char temp4[50];
	long Byte_send = 0; 

	memset(&ErrorResponceSend,' ',sizeof(struct INT_ERRORRESPONCESEND));
	ErrorResponceSend.IntRespHeader.iMsgLength = sizeof ( struct INT_ERRORRESPONCESEND );
	ErrorResponceSend.IntRespHeader.iMsgCode = TC_INT_ERROR_CODE ;
	/***	ErrorResponceSend.IntRespHeader.iTimeStamp = GetTimeStamp ( ) ;****/
	ErrorResponceSend.IntRespHeader.iTimeStamp = 0 ;
	ErrorResponceSend.IntRespHeader.iErrorId     = ErrorId;

	memcpy ( temp1 , &ErrorResponceSend , 4 );

	Byte_send= send( Socket, (char *) &ErrorResponceSend,ErrorResponceSend.IntRespHeader.iMsgLength  ,0 ); 
	if ( Byte_send < 0 ) 
	{
		logError("Send: Socket = %d Bytes = %d ", Socket, Byte_send);
		logPError("send");
		logDebug3 ( " Error in sending response [%d]",errno);
	}
	logDebug3 ( " Successfully sent SenderrorResponce  ");
}

void Sleep ( int TimeSleep )
{
	poll((struct pollfd **) NULL, 0,TimeSleep  );
}


void CheckpeerAddr ( struct sockaddr * ClientAddr,int Clien, char UserType)
{
	int i=0;
	struct sockaddr_in  *PeerAddr;

	printf("\n UserTypegot in check peer addr is %c",UserType);
	PeerAddr = (struct sockaddr_in * ) ClientAddr;
	for ( i = 0 ; i < MAX_NO_OF_USERS ; i ++ )
	{
		if ( Lookup[i].PeerAddr.sin_addr.s_addr == PeerAddr->sin_addr.s_addr && Lookup[ i ].user.UserType != UserType && Lookup[ i ].user.UserType != UNUSED )
		{
			printf("\n\t Lookup[i].PeerAddr.sin_addr.s_addr=%s",inet_ntoa(Lookup[i].PeerAddr.sin_addr));
			printf("\n\t PeerAddr->sin_addr.s_addr=%s",inet_ntoa(PeerAddr->sin_addr));
			printf ( "\n PeerAddr found (already set ) \n");
			CleanSocketResour ( Lookup[i].Socket );

			break;
		}
	}
}


void UpdatePeerAddr ( struct sockaddr * ClientAddr, int Clilen,int Index)
{
	memcpy(&(Lookup[Index].PeerAddr),ClientAddr,Clilen);
}


void CleanUserResour ( )
{
	int   i,j;
	struct user_relay_array *Ptr;
	int  UserId = UNUSED;
	int Socket;

	printf("\n In CleanUserResour \n");

	LockShm(DirRelShm);
	Ptr = OpenSharedMemory(DirRelShm,DirRelShm_SIZE);

	if ( *( (int *) Ptr) == ERROR )
	{
		printf("\nCleanUserResour");
		exit(1);
	}
	for ( i=0 ; i < MAX_USERS ; i++ )
	{
		if ( Ptr->user_relay[i].iRelayId == RelayId && Ptr->user_relay[i].iCheck == DELETE_USER )
		{
			UserId = Ptr->user_relay[i].iUserId ;
			printf("\nRequest for CleanUserResour : %d RelayId : %d", UserId , RelayId );
			break;

		}
	}
	if ( CloseSharedMemory( (void * ) Ptr ) == ERROR )
	{
		printf("\n CleanUserResour");
		exit(1);
	}
	UnLockShm(DirRelShm);
	LokThreadMutex ( &LookupMutex );

	if ( UserId != UNUSED )
	{
		if ( SearchuserId ( UserId ,&Socket ) == TRUE )
		{
			CleanSocketResour (Socket);
		}
	}
	UnLokThreadMutex ( &LookupMutex );
}

void ProcessIncomeBuffer ( void * iSelSock )
{
	struct INT_REQUEST_HEADER *BfslHeader;
	char       Dummy[1]= "Y"  ;
	int Index;
	int  Socket ;
	int iRetVal;
	char *ReadData ;
	short        BytesToRead=0;
	int  PacketSize ;
	int  BreakCounter =0 ;


	printf ("\n In Process IncomeBuffer \n");

	ReadData = (char *) malloc (BYTES_TO_READ + 10);
	Socket = *(int *)(iSelSock);
	iRetVal = recv (Socket , ReadData , BYTES_TO_READ , MSG_PEEK );

	if ( iRetVal == -1 )
	{
		logPError("recv");
	}
	if ( iRetVal > 0 )
	{
		BytesToRead = sizeof (struct INT_REQUEST_HEADER);
		for ( ; ;)
		{
			iRetVal = recv ( Socket , ReadData , BytesToRead , MSG_PEEK);
			BreakCounter ++ ;

			if ( iRetVal < BytesToRead )
			{
				printf ( "\nProcessIncomeBuffer:Full packet Header  Not arrived :Break Counter %d iRetVal : %d BytesToRead : %d \n",BreakCounter );
				if ( BreakCounter >= BREAK_COUNTER )
				{
					break;
				}
				Sleep (100);
			}
			else
			{
				BytesToRead = ((struct INT_REQUEST_HEADER * )ReadData)->iMsgLength;
				if ( BytesToRead > BYTES_TO_READ  || BytesToRead < 0)
				{
					BytesToRead = BYTES_TO_READ;
					break;
				}
				for ( ; ; )
				{
					iRetVal = recv (Socket , ReadData , BytesToRead , MSG_PEEK );
					BreakCounter ++;
					if (iRetVal < BytesToRead )
					{
						printf ( "\n Full packet Not arrived :Break Counter %d \n",BreakCounter );
						if ( BreakCounter >= BREAK_COUNTER )
						{
							break;
						}
						Sleep (100);
					}
					else
					{
						break;
					}
				}
				break;
			}
		}
	}
	else
	{
		BytesToRead = sizeof (struct INT_REQUEST_HEADER );
	}

	iRetVal = recv( Socket , ReadData , BytesToRead,0 );

	PacketSize = iRetVal ;

	BfslHeader = (struct INT_REQUEST_HEADER * ) ReadData ;

	if ( BfslHeader ->iMsgLength != PacketSize )
	{
		SenderrorResponce (Socket,PACKET_SIZE_MISMATCH );
		LokThreadMutex ( &LookupMutex );
		CleanSocketResour( Socket );
		UnLokThreadMutex ( &LookupMutex );
		return;
	}
	printf("\nInternalTransCode : %d, UserID :%d", BfslHeader->iInternalTransCode,BfslHeader->iUserIdOrLogPktId  );
	switch (BfslHeader ->iInternalTransCode)
	{
		case TC_INT_LOGON_REQ:

			printf("Socket = %d Selected for setting UserId \n",Socket);
			printf("No of Bytes read from socket = %d\n", PacketSize );
			printf("Socket = %d \n" , Socket );

			LokThreadMutex ( &ActiveSocLock);
			FD_SET(Socket,&ActiveSocket);
			UnLokThreadMutex ( &ActiveSocLock);
			LokThreadMutex ( &LookupMutex );
			SetUserId( Socket , ReadData );
			UnLokThreadMutex ( &LookupMutex );

			LokThreadMutex ( &PipeLock);
			write(PipeFds[1],Dummy,sizeof(Dummy));
			UnLokThreadMutex ( &PipeLock);
			break ;

		case TC_INT_ORDER_ENTRY_REQ:
		case TC_INT_ORDER_MODIFY_REQ:
		case TC_INT_ORDER_CANCEL_REQ:



			printf("Socket = %d  with correct trans code \n",Socket);
			printf("No of Bytes read from socket = %d\n", PacketSize );
			LokThreadMutex ( &LookupMutex );
			Index=SearchIndex(Socket);
			if( BfslHeader->iUserIdOrLogPktId != Lookup[ Index ].user.UserId || BfslHeader->cUserTypeOrLogInfoType!= Lookup[ Index ].user.UserType || Lookup [Index ].user.UserId == UNUSED )

			{
				printf("\n\t BfslHeader->UserIdOrLogPktId : %d  Lookup[ Index ].user.UserId : %d ", BfslHeader->iUserIdOrLogPktId , Lookup[ Index ].user.UserId )  ;
				printf("\n\t BfslHeader->UserTypeOrLogInfoType : %d Lookup[ Index ].user.UserType : %d ", BfslHeader->cUserTypeOrLogInfoType , Lookup[ Index ].user.UserType )  ;
				SenderrorResponce (Socket,INTEACTIVE_USER_ID_TYPE_MISMATCH );
				CleanSocketResour( Socket );
				UnLokThreadMutex ( &LookupMutex );

				break;
			}

			UnLokThreadMutex ( &LookupMutex );
			LokThreadMutex ( &ActiveSocLock);
			FD_SET(Socket,&ActiveSocket);
			UnLokThreadMutex ( &ActiveSocLock);
			LokThreadMutex ( &PipeLock);
			write(PipeFds[1],Dummy,sizeof(Dummy));
			UnLokThreadMutex ( &PipeLock);
			SenderrorResponce (Socket ,REQUEST_NOT_SENT_TO_EXCH);

			break;

		default:

			SenderrorResponce (Socket,INVALID_TRANSCODE );
			LokThreadMutex ( &LookupMutex );
			CleanSocketResour( Socket );
			UnLokThreadMutex ( &LookupMutex );
	}
	LokThreadMutex ( &MaxThreadMutex );
	NoOfThreads ++;
	UnLokThreadMutex ( &MaxThreadMutex );
}

void  ProcessOutDloadBuff (void * MsgStruct)
{
	struct        MsgSocketStruct *pMsgStruct;
	int           Index;
	LONG32        dErrno;                

	printf("\nThis is in ProcessOutDloadBuff.........\n");

	pMsgStruct = (struct MsgSocketStruct *) MsgStruct;

	printf("\n ProcessDload: %d : %d \n",pMsgStruct->Socket,((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength );

	if( ( Index = SearchIndex( pMsgStruct->Socket ) ) == NOT_TRUE )
	{
		printf("\n ProcessDload : SearchIndex for Socket \n");
		UnLokThreadMutex ( &SendMutexSeq );
		return ;
	}
	UnLokThreadMutex ( &SendMutexSeq );
	LokThreadMutex ( &Lookup[Index].SendMutex );


	if ( SendNB( pMsgStruct->Socket, pMsgStruct->cpMsgBuf, ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength ,&dErrno ) < 0 )
	{
		struct LOGON_REQ TempBuf ;
		UnLokThreadMutex ( &Lookup[Index].SendMutex );
		TempBuf.UserId = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iUserIdOrLogPktId ;
		TempBuf.UserType = ((struct INT_RESP_HEADER *)(pMsgStruct->cpMsgBuf))->cUserTypeOrLogInfoType ;
		LokThreadMutex ( &LookupMutex );

		if ( dErrno == EAGAIN )
		{
			SenderrorResponce (pMsgStruct->Socket,ERR_RECONNECT_AGAIN );
		}

		CleanSocketResour(pMsgStruct->Socket);
		UnLokThreadMutex ( &LookupMutex );
	}

	UnLokThreadMutex ( &Lookup[Index].SendMutex );
	free(pMsgStruct);

	LokThreadMutex ( &MaxDloadThreadMutexWrite );
	NoOfDloadThreadsWrite ++;
	UnLokThreadMutex ( &MaxDloadThreadMutexWrite );

}

void  ProcessOutBoundBuff (void * MsgStruct)
{
	struct        MsgSocketStruct *pMsgStruct;
	int           Index;
	LONG32      dErrno;                             

	printf("\nThis is in ProcessOutBoundBuff.........\n");

	pMsgStruct = (struct MsgSocketStruct *) MsgStruct;

	printf("\n ProcessWrite: %d : %d \n",pMsgStruct->Socket,((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength );

	if( ( Index = SearchIndex( pMsgStruct->Socket ) ) == NOT_TRUE )
	{
		printf("\n ProcessWrite : SearchIndex for Socket \n");
		UnLokThreadMutex ( &SendMutexSeq );
		return ;
	}
	UnLokThreadMutex ( &SendMutexSeq );
	LokThreadMutex ( &Lookup[Index].SendMutex );

	if ( SendNB( pMsgStruct->Socket, pMsgStruct->cpMsgBuf, ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf))->iMsgLength ,&dErrno ) < 0 )
	{
		//struct MS_VBTOUNIX_LOGON_REQ TempBuf ;
		struct UserDetails TempBuf;
		UnLokThreadMutex ( &Lookup[Index].SendMutex );
		TempBuf.UserId = ((struct INT_RESP_HEADER * )(pMsgStruct->cpMsgBuf) )->iUserIdOrLogPktId ;
		TempBuf.UserType = ((struct INT_RESP_HEADER *)(pMsgStruct->cpMsgBuf))->cUserTypeOrLogInfoType ;
		LokThreadMutex ( &LookupMutex );

		if ( dErrno == EAGAIN )
		{
			SenderrorResponce (pMsgStruct->Socket,ERR_RECONNECT_AGAIN );
		}

		CleanSocketResour(pMsgStruct->Socket);
		UnLokThreadMutex ( &LookupMutex );
	}

	UnLokThreadMutex ( &Lookup[Index].SendMutex );
	free(pMsgStruct);

	LokThreadMutex ( &MaxThreadMutexWrite );
	NoOfThreadsWrite ++;
	UnLokThreadMutex ( &MaxThreadMutexWrite );

}

BOOL find_user_relay(LONG32 userid, struct sockaddr * ClientAddr)
{
	LONG32  Count       =   0       ;
	LONG32  shmid       =   0       ;
	LONG32  k           =   0       ;
	LONG32  j           =   0       ;
	LONG32  RetVal      =   0       ;
	struct  sockaddr_in     *PeerAddr       ;
	struct  user_relay_array    *ptr        ;
	struct  user_relay_array    *tempptr    ;

	PeerAddr=(struct sockaddr_in * )ClientAddr;
	LockShm ( DirRelShm );
	ptr     =( struct user_relay_array *) OpenSharedMemory( DirRelShm , DirRelShm_SIZE )     ;
	if(*(( LONG32 * )ptr )  == ERROR )
	{
		exit( 1 ) ;
	}
	tempptr     =       ptr     ;
	printf ("\n\t Inside  find_user_relay userid:%d:",userid );

	for( Count = 0 ; Count < MAX_USERS ; Count++ )
	{
		if((tempptr -> user_relay[Count].iUserId) == userid && tempptr -> user_relay[Count].PeerAddr.sin_addr.s_addr==PeerAddr->sin_addr.s_addr)
		{
			printf ("\n\tAs user is already present in shm clearing it...");
			tempptr->user_relay[Count].iUserId=       UNUSED  ;
			tempptr->user_relay[Count].iRelayId=       UNUSED  ;
			tempptr->user_relay[Count].iCheck=       UNUSED  ;
			tempptr->user_relay[Count].iProcessId=       UNUSED  ;
			tempptr->user_relay[Count].cUserType= ' ' ;
			memset(&(tempptr->user_relay[Count].sClientId), ' ' , CLIENT_ID_LEN )  ;
			printf("\n\tUser cleared from shared memory " );
			sleep(1);
			CloseSharedMemory( (void *)ptr);
			UnLockShm( DirRelShm );
			return ( TRUE );
		}
	}
	CloseSharedMemory( (void *)ptr)     ;
	UnLockShm( DirRelShm )                      ;
	return( FALSE )                                     ;
}


BOOL find_user_local (LONG32 UserId, struct sockaddr * ClientAddr )
{
	int     i,j,k;
	for ( i = 0; i< MAX_NO_OF_USERS ; i++ )
	{
		if ( Lookup[i].user.UserId == UserId )
		{
			printf("\n\tINSIDE find_user_local");
			Lookup[i].user.UserId        = UNUSED ;
			Lookup[i].user.UserType      = UNUSED ;
			close( Lookup[i].Socket );
			LokThreadMutex ( &ActiveSocLock) ;
			FD_CLR( Lookup[i].Socket , &ActiveSocket );
			UnLokThreadMutex ( &ActiveSocLock) ;
			Lookup[i].Socket             = UNUSED ;
			memset(&(Lookup[i].PeerAddr),NULL,sizeof(struct sockaddr_in));
			return ( TRUE );
		}
	}
	return ( FALSE );
}


void CleanOldSocketResour( int Socket )
{
	register int Index ,j;
	printf("\n\t Inside CleanOldSocketResour...");
	if( ( Index = SearchIndex( Socket ) ) == NOT_TRUE || Socket == UNUSED )
	{
		return ;
	}
	DltShmRelayData(Lookup[Index].user.UserId);

	Lookup[ Index ].user.UserId    = UNUSED ;
	Lookup[ Index ].user.UserType  = UNUSED ;
	Lookup[ Index ].Socket         = UNUSED ;

	memset(&(Lookup[ Index ].PeerAddr),NULL,sizeof(struct sockaddr_in));
	LokThreadMutex ( &ActiveSocLock) ;
	FD_CLR( Socket , &ActiveSocket );
	UnLokThreadMutex ( &ActiveSocLock) ;
}


void sig_segv_handler()
{
	printf("\n !!!! SIGSEGV encountered !!!! ");
}


BOOL Find_Max_User(LONG32 *MaxCurrentUser)
{
	LONG32  Count   =   0   ;
	LONG32  MaxUser =   0   ;
	LONG32  shmid   =   0   ;

	logTimestamp("Inside [Find_Max_User]");
	struct  user_relay_array    *ptr        ;
	struct  user_relay_array    *tempptr    ;
	LockShm(DirRelShm);
	ptr=( struct user_relay_array *) OpenSharedMemory( DirRelShm , DirRelShm_SIZE ) ;

	if(*(( LONG32 * )ptr )  == ERROR )
	{
		exit( 1 ) ;
	}

	tempptr =ptr;
	logDebug3(" Before for loop");
	for( Count = 0 ; Count < MAX_USERS ; Count++ )
	{
		if((tempptr -> user_relay[Count].cUserType) == 'T'  )
		{
			logDebug3(" MaxUser [%d]",MaxUser);
			MaxUser++;
		}
	}
	*MaxCurrentUser = MaxUser;
	CloseSharedMemory( (void *)ptr);
	UnLockShm( DirRelShm);
	logTimestamp("Leaving [Find_Max_User]");
	logDebug3("MaxCurrentUser [%d]",*MaxCurrentUser);

	return( TRUE );
}


LONG32 SendNB(LONG32 Socket,CHAR *Buf, LONG32 Len,LONG32 *dErrno)
{
	LONG32  BytesSend = 0;
	LONG32  iRetVal;
	LONG32  TotalBytes = Len;
	LONG32  BytesLeft = Len;
	LONG32  flags_old,flags_new;
	LONG32  errCount = 0;

	flags_old  = fcntl(Socket, F_GETFL, 0) ;

	flags_new = flags_old   ;
	flags_new |= O_NONBLOCK  ;
	if (fcntl(Socket, F_SETFL, flags_new) == -1)
	{
		printf ("\n Error in non blockin mode ");
	}

	while(BytesSend < TotalBytes)
	{
		errCount = 0;
		do
		{
			errno = 0 ; /****inititalize it as in sucess case it does not change *****/
			if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,0)) <= 0)
			{
				*dErrno = errno;
			}
			errCount++;
		} while (errno == EAGAIN && errCount <= MAX_RETRY_COUNT);

		if ( errno == EAGAIN && errCount > MAX_RETRY_COUNT )
		{
			*dErrno = errno;
			logDebug3 (" Failed to send after trying %d times on socket %d",errCount,Socket);
			if (fcntl(Socket, F_SETFL, flags_old) == -1)
			{
				logDebug3 ("\n Error in non blockin mode ");
			}
			return ERROR;
		}
		else if ( errno != 0  )
		{
			*dErrno = errno;
			return ERROR ;
		}
		BytesSend += iRetVal;
		BytesLeft -= iRetVal;
	}
	logDebug3("Send: Relay = %d Socket = %d Bytes = %d",RelayId,Socket,BytesSend);

	if (fcntl(Socket, F_SETFL, flags_old) == -1)
	{
		printf ("\n Error in non blockin mode ");
	}

	return BytesSend;
}
int OpenMsgQue()
{

	if( ( iRelToOrdRtr = OpenMsgQ( (RelToOrdRtr))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	logDebug1(" iRelToOrdRtr created sucesfully wid Qid :%d:",iRelToOrdRtr);


	if( ( iRelToQuery = OpenMsgQ( (RelToQuery))) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}
	logDebug1(" iRelToQuery queue opened sucessfully with queuue id :%d:",iRelToQuery);



	if( (iDWSTrdRtrToDWSAdp= OpenMsgQ(DWSTrdRtrToDWSAdp)) == ERROR)
	{
		perror("Open DirToSTWRelQ :");
		exit( 1 );
	}

	logDebug1(" iDWSTrdRtrToDWSAdp :%d:",iDWSTrdRtrToDWSAdp);

	if( (iDWSQryToAdap= OpenMsgQ(DWSQryToAdap)) == ERROR)
	{
		perror("Open DWSQryToAdap:");
		exit( 1 );
	}

	logDebug1(" iDWSQryToAdap :%d:",iDWSQryToAdap);

	if( (iD2C1ToDWSAdap = OpenMsgQ(D2C1ToDWSAdap)) == ERROR)
	{
		perror("Open D2C1ToDWSAdap:");
		exit( 1 );
	}

	logDebug1(" iD2C1ToDWSAdap :%d:",iD2C1ToDWSAdap);


	if( (iAdapToRQuery= OpenMsgQ(AdapToRangeQry)) == ERROR)
	{
		perror("Open iAdapToQuery:");
		exit( 1 );
	}

	logDebug1(" iAdapToQuery:%d:",iAdapToRQuery);
}


LONG32 Send(LONG32 Socket,CHAR *Buf, LONG32 *Len)

{
	LONG32 BytesSend =0;
	LONG32  iRetVal;
	LONG32  TotalBytes = *Len;
	LONG32  BytesLeft = *Len;

	logDebug2(" Socket Send = [%d] BytesSend :%d: TotalBytes :%d:",Socket,BytesSend,TotalBytes);

	while(BytesSend < TotalBytes)
	{
		/***    if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,0)) <= 0)****/
		if((iRetVal = send(Socket,Buf+BytesSend,BytesLeft,MSG_NOSIGNAL)) <= 0)
		{
			logDebug2(" Error in Sending in SEND function need to check the issue");
			perror("in Send function");
			return ERROR;
		}

		BytesSend += iRetVal;
		BytesLeft -= iRetVal;
	}
	logDebug2(" RelayId %d: Total Bytes written to socket %d is %d",RelayId,Socket,BytesSend);
	return BytesSend;
}




