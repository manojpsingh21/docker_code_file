#include <string.h>
#include <mysql.h>
#include <stdlib.h>
#include <alloca.h>
#include <math.h>
#include <float.h>
#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include "IPCS.h"
#include "DWSAdapter.h"

/***#include "Queue.h"
#include "Common.h"
#include "IntTCodes.h"***/

#define LOCAL_MAX_PACKET_SIZE   4096
#define QUERY_SIZE              100

LONG32	iSTWRelToQueryQ;
LONG32	iIntActiveToRelDirQ;
LONG32	iTrdRout2SurvlMapperQ;
MYSQL	*DBQueries;
BOOL    ChkFlag = FALSE;
LONG32  iRelayID;
MYSQL_RES       *Res;
MYSQL_ROW       Row;
int i =0 ,j=0;

main (int argc, char **argv)
{
	setbuf(stdout,NULL);
	setbuf(stdin, NULL );
	DBQueries = DB_Connect();
	if(mysql_set_server_option(DBQueries,CLIENT_MULTI_STATEMENTS) == 0)
        {
                logDebug2(" mysql_set_server_option SUCCESS");
        }
        else
        {
                logDebug2(" mysql_set_server_option FAILed");
                return FALSE;
        }
	OpenMessgQ();
	Mapper();

}/*** End of main***/

BOOL Mapper()
{
	struct	INT_COMMON_REQUEST_HDR *pReqHeader;

	CHAR	RcvMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR    SndMsg[LOCAL_MAX_PACKET_SIZE];
	CHAR    BasicError[ERROR_MSG_LEN];

	LONG32	iMsgCode;
	LONG32	iRetVal;

	while ( 1 )
	{
		memset( &RcvMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &SndMsg,'\0', LOCAL_MAX_PACKET_SIZE );
		memset( &BasicError,'\0', ERROR_MSG_LEN);

		logInfo(" #########Waiting in while loop to get the data ################# %d",iSTWRelToQueryQ);

		if((ReadMsgQ( iSTWRelToQueryQ, &RcvMsg, LOCAL_MAX_PACKET_SIZE, 0)) != 1)
		{
			perror("Error Read Q : ");
			logFatal("(DWSMapper)Error Read Q :Qid %d", iSTWRelToQueryQ);
			return FALSE;
		}


		pReqHeader=(struct INT_COMMON_REQUEST_HDR *) &RcvMsg ;

		logDebug3("pReqHeader->iMsgCode = %d",pReqHeader->iMsgCode);
		iMsgCode = pReqHeader->iMsgCode;

		logDebug2("-----------iMsgCode = :%d:----------------",iMsgCode); 	

		switch ( iMsgCode )

		{
			case	TC_INT_VIEW_CLIENT_LIMIT_REQ:
				/**	iRetVal = fViewClientLimit(&RcvMsg);		****/
				/***/	iRetVal = fViewClientLimit(&RcvMsg);		/****/
				break;


				/**		case	TC_INT_VIEW_CLIENT_DEALER_LIMIT_REQ:
				  iRetVal = fViewClientLimitDealer(&RcvMsg);		
				  break;
				 ****/

			case	TC_INT_NET_POS_REQ:
				iRetVal = fViewNetPosition(&RcvMsg);		
				break;

			case	TC_INT_ORDER_BOOK_REQ:
				iRetVal = fGetOrderBook(&RcvMsg);		
				break;

			case	TC_INT_SPRD_ORD_BOOK_REQ:
				iRetVal = fOrderSprdBook(&RcvMsg);		
				break;

			case	TC_INT_ORDER_BOOK_DTLS_REQ:
				logDebug2(" hey u ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.iSegment :%c:",((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment);
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == EQUITY_SEGMENT)
				{
					iRetVal = fEquOrderBookDtls(&RcvMsg);
				}
				else if (((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == DERIVATIVE_SEGMENT || ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == CURRENCY_SEGMENT)
				{
					iRetVal = fDrvOrderBookDtls(&RcvMsg);
				}
				if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == COMMODITY_SEGMENT)
				{
					iRetVal = fCOMMOrderBookDtls(&RcvMsg);
				}

				break;

			case 	TC_INT_SPRD_ORDER_BOOK_DTLS_REQ :
                                logDebug2("Segment :%c:",((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment);
                                if (((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == DERIVATIVE_SEGMENT ||
                                                ((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == CURRENCY_SEGMENT)
                                {
                                        iRetVal = fDrvSprdOrderBookDtls(&RcvMsg);
                                }
                                else if(((struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg)->ReqHeader.cSegment == COMMODITY_SEGMENT)
                                {
                                        iRetVal = fCOMMSprdOrderBookDtls(&RcvMsg);
                                }
                                break;

			case	TC_INT_TRADE_BOOK_REQ:
				iRetVal = fGetTradeBook(&RcvMsg);		
				break;

			case	TC_INT_ADMIN_TRADE_BOOK_REQ:
				iRetVal = fSurvillenceTradeBook(&RcvMsg);		
				break;

			case	TC_INT_CLINET_HOLDING_REQ:
				iRetVal = fClientHoldings(&RcvMsg);		
				break;

			case	TC_INT_NETPOS_DTL_REQ:
				iRetVal = fNetPositionDetail(&RcvMsg);		
				break;

			case	TC_INT_CARRY_FWD_POS_REQ:
				iRetVal = fClientCarryFwdPosition(&RcvMsg);		
				break;
				/***/
			case	TC_INT_CONVT_TO_DELV_REQ:
				//iRetVal = fClientConvetToDel(&RcvMsg);		
				iRetVal = fGetConvetToDel(&RcvMsg);		
				break;
				/***/

			case	TC_INT_ADMIN_CONVT_TO_DELV_REQ:
				iRetVal = fSurvillenceConvetToDel(&RcvMsg);		
				break;
				/***
				  case	TC_INT_SEND_MSG_TO_CLIENT_REQ:
				  iRetVal = fSendMsgtoClient(&RcvMsg);		
				  break;
				 ********/

			case	TC_INT_DNLD_SYSTEM_MSG_REQ:   
				iRetVal = fDNLDSystemMsg(&RcvMsg);		
				break;

			case    TC_INT_REJECTED_ORDERS_REQ :

				iRetVal = fGetRejectedOrders(&RcvMsg);
				break;

			case    TC_INT_DEA_CLIENT_MAPP_REQ :
				iRetVal = fDeaClientMapp(&RcvMsg);
				break;

			case	TC_INT_MARGIN_SHORTFALL_REQ :
				iRetVal = fMarginShortFall(&RcvMsg);
				break;

			case    TC_INT_PERCENT_MTM_QUERY_REQ :
				iRetVal = fPercentMTM(&RcvMsg);
				break;
				/*			

							case	TC_INT_BO_ORDER_BOOK_REQ:
							iRetVal = fGetBoOrderBook(&RcvMsg);
							break;

				 */		  
			case	TC_INT_EXCH_GEN_MSG_REQ:
				iRetVal = fExchMsgReq (&RcvMsg);
				break;

			case	TC_INT_ORDER_BASKET_REQ:
				iRetVal = fOrderBasket(&RcvMsg);
				break;

			case    TC_INT_ORDER_BASKET_DETAIL_REQ:
				iRetVal = fBasketDetail(&RcvMsg);
				break;

			case    TC_INT_ORDER_BASKET_NAME_REQ:
				iRetVal = fFetchBasketName(&RcvMsg);
				break;

			case    TC_INT_SIP_ORDER_BOOK_REQ:
				iRetVal = fSIPOrdBook(&RcvMsg);
				break;

			case    TC_INT_SIP_ORDER_DETS_REQ :
				iRetVal = fSIPOrdDetails(&RcvMsg);
				break;

			case    TC_INT_SIP_ORDER_TRALS_REQ :
				iRetVal = fSIPOrdTrails(&RcvMsg);
				break;

			case    TC_INT_VIEW_CLIENT_LIMIT_DET_REQ :
				iRetVal = fViewClDetLimit(&RcvMsg);
				break;
			case	TC_INT_MKT_STATUS_REQ :
				iRetVal = fMktStatus(&RcvMsg);
				break;

			case	TC_INT_VIEW_DEALER_ADHOC_LIMIT_REQ:
				iRetVal = fViewDealerLimit(&RcvMsg);
				break;

			case	TC_INT_ADD_DEALER_ADHOC_LIMIT_REQ:
				iRetVal = fAddDealerLimit(&RcvMsg);
				break;

			case    TC_INT_ADDED_VIEW_CLIENT_ADHOC_LIMIT_REQ:
				iRetVal = fAddedViewClientLimit(&RcvMsg);
				break;				

			case 	TC_INT_DL_PAYOUT_REQ:
				iRetVal = fViewPayOut(&RcvMsg); 
				break;
			
			case 	TC_INT_DP_HOLDING_REQ:
				iRetVal = fClientDPHoldings(&RcvMsg); 
				break;
			
			default :
				logFatal(" Invalid Transcode :%d:",iMsgCode);
				iRetVal = FALSE;
				break;



		} /*** END of Switch****/


	}/** End of While**/

}

BOOL OpenMessgQ()
{

	if( ( iSTWRelToQueryQ = OpenMsgQ( (RelToQuery))) == ERROR )
	{
		perror("Open RelToQuery :");
		exit( 1 );
	}
	//	 if( ( iIntActiveToRelDirQ = OpenMsgQ( (OrdSrvToTrdRtr))) == ERROR )
	if( ( iIntActiveToRelDirQ = OpenMsgQ( (DWSQryToAdap))) == ERROR )
	{
		perror("Open DWSQryToAdap:");
		exit( 1 );
	}

	return TRUE;

}/** End of OpenMsgQ**/
/****
  SHORT   fAddSpace( CHAR * Str_In ,SHORT MaxLen )
  {
  OpenMessgQ();


  SHORT Strlen=0;

  it( 1 );
  ( MaxLen <= 0 )
  {
  return FALSE ;
  }

  for( ; Str_In[Strlen] != ' '  && Strlen < MaxLen ; Strlen++ )
  {
  continue;
  }
  Str_In[Strlen]='\0';
  return Strlen  ;
  }
 ****/

BOOL   fBasketDetail(CHAR *RcvMsg)
{
	logTimestamp("Entry : fBasketDetail");

	struct VIEW_USER_DWS_BASKET_REQUEST *pOrdBasketReq;
	struct VIEW_DWS_ORDER_BASKET_RESP pOrdBasketResp;
	struct VIEW_USER_DWS_BASKET_RESPONSE pOrdResp;
	struct VIEW_COMMON_HDR_RESP     pOrdBasketHdrResp;
	struct VIEW_DWS_BASKET_NAME_RESP  pBasketNameResp;

	CHAR    sSelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry1[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry2[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry3[DOUBLE_MAX_QUERY_SIZE];

	CHAR    sDelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sDelQry1[DOUBLE_MAX_QUERY_SIZE];

	CHAR    sInsQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR	cChkFlag;

	memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sSelQry1,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sSelQry2,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sSelQry3,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sDelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sDelQry1,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sInsQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	memset(&pOrdBasketReq,'\0',sizeof (struct VIEW_USER_DWS_BASKET_REQUEST));
	memset(&pOrdBasketResp,'\0',sizeof (struct VIEW_DWS_ORDER_BASKET_RESP));
	memset(&pOrdBasketHdrResp,'\0',sizeof (struct VIEW_COMMON_HDR_RESP));
	memset(&pBasketNameResp,'\0',sizeof (struct VIEW_DWS_BASKET_NAME_RESP));
	memset(&pOrdResp,'\0',sizeof (struct VIEW_USER_DWS_BASKET_RESPONSE));

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	CHAR            sTempBasketId [BASKET_ID];
	LONG32          iTempNoOfRec;

	pOrdBasketReq = (struct VIEW_USER_DWS_BASKET_REQUEST *)RcvMsg;

	cChkFlag = pOrdBasketReq->cFlag;

	if(cChkFlag == ADD_BASKET)
	{
		sprintf(sSelQry,"SELECT NextVal('USER_BASKET_SEQ');");
		logDebug2("sSelQry :%s:",sSelQry);
		if((mysql_query(DBQueries,sSelQry)) != SUCCESS)
		{
			logSqlFatal("ERROR IN Query.");
			sql_Error(DBQueries);
		}
		Res = mysql_store_result(DBQueries);
		if((Row = mysql_fetch_row(Res)))
		{
			logDebug2("Row :%s:",Row[0]);
			sprintf(sTempBasketId,"%d%llu",atoi(Row[0]),pOrdBasketReq->ReqHeader.iUserId);
			logDebug2("iTempBasketId:%s:",sTempBasketId);
			pOrdBasketReq->iBasketId = atoi(sTempBasketId);
		}

		logDebug2("pOrdBasketReqs->sClientId:%s:",pOrdBasketReq->sClientId);
		logDebug2("pOrdBasketReq->sBasketName:%s:",pOrdBasketReq->sBasketName);
		logDebug2("pOrdBasketReq->iBasketId :%d:",pOrdBasketReq->iBasketId);
		logDebug2("pOrdBasketReq->sCreateTime:%s",pOrdBasketReq->sCreateTime);
		logDebug2("pOrdBasketReq->pReqHeader.cSource:%c:",pOrdBasketReq->ReqHeader.cSource);
		logDebug2("pOrdBasketReq->sDescription:%s:",pOrdBasketReq->sDescription);
		logDebug2("pOrdBasketReq->cBasketTyp:%c:",pOrdBasketReq->cBasketTyp);
		logDebug2("pOrdBasketReq->cAssigncat:%c:",pOrdBasketReq->cAssigncat);
		logDebug2("pOrdBasketReq->sRiskId:%s:",pOrdBasketReq->sRiskId);


		sprintf(sInsQry,"INSERT INTO USER_BASKET_DETAILS \
				(UBD_CLIENT_ID,UBD_BASKET_NAME,UBD_BASKET_ID,UBD_DEL_FLAG,UBD_CREATE_DATE,UBD_SOURCE,UBD_DESCRIPTOR,UBD_BASKET_TYPE,\
				 UBD_ASSIGNED_CAT,UBD_RISK_ID)\
				VALUES \ 
				(\"%s\",\"%s\",%d,\'%c\',STR_TO_DATE(\'%s\','%%d/%%m/%%Y'),\'%c\',\"%s\",\'%c\',\'%c\',\"%s\");"\
				,pOrdBasketReq->sClientId,pOrdBasketReq->sBasketName,pOrdBasketReq->iBasketId,pOrdBasketReq->cDelFlag,pOrdBasketReq->sCreateTime,\
				pOrdBasketReq->ReqHeader.cSource,pOrdBasketReq->sDescription,pOrdBasketReq->cBasketTyp,pOrdBasketReq->cAssigncat,\
				pOrdBasketReq->sRiskId);	

		logDebug2("sInsQry :%s:",sInsQry);

		if(mysql_query(DBQueries,sInsQry) != SUCCESS)
		{
			logSqlFatal("Error in sInsQry.");
			sql_Error(DBQueries);
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_ADD_ERR_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			logDebug2("Success In Query :");
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		}


		pOrdResp.IntRespHeader.iSeqNo = 0;
		pOrdResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_USER_DWS_BASKET_RESPONSE);
		pOrdResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pOrdResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);
		if(iRelayID == ERROR)
		{
			logDebug2("Relay ID not found");
			return FALSE;
		}
		strncpy(pOrdResp.sClientId,pOrdBasketReq->sClientId,CLIENT_ID_LEN);
		strncpy(pOrdResp.sBasketName,pOrdBasketReq->sBasketName,CLIENT_NAME_LEN);
		strncpy(pOrdResp.sDescription,pOrdBasketReq->sDescription,BASKET_DESC_LEN);
		strncpy(pOrdResp.sRiskId,pOrdBasketReq->sRiskId,RISK_PROF_LEN);
		pOrdResp.iBasketId = pOrdBasketReq->iBasketId;
		pOrdResp.cBasketTyp = pOrdBasketReq->cBasketTyp;
		pOrdResp.cAssigncat = pOrdBasketReq->cAssigncat;
		pOrdResp.cDelFlag = pOrdBasketReq->cDelFlag;
		logDebug2("pOrdResp.sClientId:%s:",pOrdResp.sClientId);
		logDebug2("pOrdResp.sBasketName:%s:",pOrdResp.sBasketName);
		logDebug2("pOrdResp.iBasketId: %d:",pOrdResp.iBasketId);
		logDebug2("pOrdResp.sCreateTime:%s",pOrdResp.sCreateTime);
		logDebug2("pOrdResp.IntRespHeader.cSource:%c:",pOrdResp.IntRespHeader.cSource);
		logDebug2("pOrdResp.sDescription:%s:",pOrdResp.sDescription);
		logDebug2("pOrdResp.cBasketTyp:%c:",pOrdResp.cBasketTyp);
		logDebug2("pOrdResp.cAssigncat:%c:",pOrdResp.cAssigncat);
		logDebug2("pOrdResp.sRiskId:%s:",pOrdResp.sRiskId);
		logDebug2("pOrdResp.cDelFlag:%c:",pOrdResp.cDelFlag);


		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdResp,sizeof(struct VIEW_USER_DWS_BASKET_RESPONSE) ,iRelayID ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

	}
	if(cChkFlag == DEL_BASKET_NAME)
	{

		logDebug2("Deleting the basket :");	
		sprintf(sDelQry,"DELETE FROM USER_ORDER_BASKET WHERE UOB_CLIENT_ID = \"%s\" AND UOB_BASKET_NAME = \"%s\" and \
				UBD_ASSIGNED_CAT = \'%c\' ;",pOrdBasketReq->sClientId,pOrdBasketReq->sBasketName,pOrdBasketReq->cAssigncat);
		logDebug2("sDelQry :%s:",sDelQry);

		if(mysql_query(DBQueries,sDelQry) != SUCCESS)
		{
			logSqlFatal("Error in sUpdQry.");
			sql_Error(DBQueries);
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_DEL_ERR_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		}

		sprintf(sDelQry,"DELETE FROM USER_ORDER_BASKET WHERE UOB_CLIENT_ID = \"%s\" AND UOB_BASKET_ID = %d ;",pOrdBasketReq->sClientId,\
				pOrdBasketReq->iBasketId);

		if(mysql_query(DBQueries,sDelQry) != SUCCESS)
		{
			logSqlFatal("Error in sUpdQry.");
			sql_Error(DBQueries);
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_EDIT_ERR_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		}


		pOrdBasketHdrResp.IntRespHeader.iSeqNo = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
		pOrdBasketHdrResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pOrdBasketHdrResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		strncpy(pOrdBasketHdrResp.sClientId,pOrdBasketReq->sClientId,CLIENT_ID_LEN);
		pOrdBasketHdrResp.cMsgType = 'H';
		pOrdBasketHdrResp.iNoofRec = 1;
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		logDebug2(" pOrdBasketHdrResp.ResHeader.iSeqNo :%d:" , pOrdBasketHdrResp.IntRespHeader.iSeqNo);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgLength :%d: ", pOrdBasketHdrResp.IntRespHeader.iMsgLength);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iErrorId :%d:" , pOrdBasketHdrResp.IntRespHeader.iErrorId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgCode :%d:" , pOrdBasketHdrResp.IntRespHeader.iMsgCode);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iUserId :%llu:" , pOrdBasketHdrResp.IntRespHeader.iUserId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.cSource:%c:" , pOrdBasketHdrResp.IntRespHeader.cSource);
		logDebug2(" pOrdBasketHdrResp.ResHeader.sClientId :%s:" , pOrdBasketHdrResp.sClientId);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

	}
	if(cChkFlag == BASKET_NAME)
	{
		logDebug2("Basket Name Request :");
		sprintf(sSelQry1,"Select UBD_BASKET_NAME from USER_BASKET_DETAILS where UBD_CLIENT_ID = \"%s\" and UBD_BASKET_TYPE = \'%c\' \
				and UBD_ASSIGNED_CAT = \'%c\';",pOrdBasketReq->sClientId,pOrdBasketReq->cBasketTyp,pOrdBasketReq->cAssigncat);

		logDebug2("sSelQry :%s:",sSelQry1);
		if((mysql_query(DBQueries,sSelQry1)) != SUCCESS)
		{
			logSqlFatal("ERROR IN view Client Limit Query.");
			sql_Error(DBQueries);
		}
		Res = mysql_store_result(DBQueries);
		iNoOfRec = mysql_num_rows(Res);

		fNoOfRec = iNoOfRec;
		iNoOfPkt = ceil(fNoOfRec/5);
		iTempNoOfRec = iNoOfRec;
		pOrdBasketHdrResp.IntRespHeader.iSeqNo = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
		pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgCode =TC_INT_ORDER_BASKET_RESP ;
		pOrdBasketHdrResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pOrdBasketHdrResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		pOrdBasketHdrResp.cMsgType = 'H';
		pOrdBasketHdrResp.iNoofRec = iNoOfRec;

		logDebug2("pOrdBasketReq->ReqHeader.iUserId = %llu",pOrdBasketReq->ReqHeader.iUserId);
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}	
		for(i=0;i<iNoOfPkt;i++)
		{
			for(j=0;j<5;j++)
			{
				if((Row = mysql_fetch_row(Res)))
				{
					pOrdBasketResp.IntRespHeader.iSeqNo = 0;
					pOrdBasketResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_ORDER_BASKET_RESP);
					pOrdBasketResp.IntRespHeader.iErrorId = 0;
					pOrdBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
					pOrdBasketResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
					pOrdBasketResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
					if(iTempNoOfRec <= 1)
					{
						pOrdBasketResp.cMsgType = 'T';
					}
					else
					{
						pOrdBasketResp.cMsgType = 'D';
					}
					pOrdBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
					strncpy(pOrdBasketResp.suborderbasket[j].sBasketName,Row[0],CLIENT_NAME_LEN);
					logDebug2("pOrdBasketResp.subordername[j].sBasketName :%s:",pOrdBasketResp.suborderbasket[j].sBasketName);

				}
				iTempNoOfRec--;
			}
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketResp,sizeof(struct VIEW_DWS_ORDER_BASKET_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
	}
	if(cChkFlag == ALL_BASKET)
	{
		sprintf(sSelQry2,"Select UBD_BASKET_NAME,UBD_CLIENT_ID,UBD_BASKET_ID,UBD_DEL_FLAG,UBD_CREATE_DATE,UBD_SOURCE,\
				UBD_DESCRIPTOR from USER_BASKET_DETAILS where UBD_CLIENT_ID = \"%s\" ;",pOrdBasketReq->sClientId);

		logDebug2("sSelQry2 :%s:",sSelQry2);
		if((mysql_query(DBQueries,sSelQry2)) != SUCCESS)
		{
			logSqlFatal("ERROR IN view Client Limit Query.");
			sql_Error(DBQueries);
		}
		Res = mysql_store_result(DBQueries);
		iNoOfRec = mysql_num_rows(Res);

		fNoOfRec = iNoOfRec;
		iNoOfPkt = ceil(fNoOfRec/5);
		iTempNoOfRec = iNoOfRec;
		pOrdBasketHdrResp.IntRespHeader.iSeqNo = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
		pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgCode =TC_INT_ORDER_BASKET_RESP ;
		pOrdBasketHdrResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pOrdBasketHdrResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		pOrdBasketHdrResp.cMsgType = 'H';
		pOrdBasketHdrResp.iNoofRec = iNoOfRec;

		logDebug2("pOrdBasketReq->ReqHeader.iUserId = %llu",pOrdBasketReq->ReqHeader.iUserId);
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		for(i=0;i<iNoOfPkt;i++)
		{
			for(j=0;j<5;j++)
			{
				if((Row = mysql_fetch_row(Res)))
				{
					pBasketNameResp.IntRespHeader.iSeqNo = 0;
					pBasketNameResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_BASKET_NAME_RESP);
					pBasketNameResp.IntRespHeader.iErrorId = 0;
					pBasketNameResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
					pBasketNameResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
					pBasketNameResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
					if(iTempNoOfRec <= 1)
					{
						pBasketNameResp.cMsgType = 'T';
					}
					else
					{
						pBasketNameResp.cMsgType = 'D';
					}
					pBasketNameResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
					strncpy(pBasketNameResp.subordername[j].sBasketName,Row[0],CLIENT_NAME_LEN);
					strncpy(pBasketNameResp.sClientId,Row[1],CLIENT_ID_LEN);
					pBasketNameResp.subordername[j].iBasketId= atoi(Row[2]);
					pBasketNameResp.subordername[j].cDelFlag = Row[3];
					strncpy(pBasketNameResp.subordername[j].sCreateTime,Row[4],DATE_TIME_LEN);
					pBasketNameResp.subordername[j].cSource = Row[4];
					strncpy(pBasketNameResp.subordername[j].sDescription,Row[5],BASKET_DESC_LEN);

					logDebug2("pBasketNameResp.subordername[j].sBasketName :%s:",pBasketNameResp.subordername[j].sBasketName);
					logDebug2("pBasketNameResp.sClientId:%s:",pBasketNameResp.sClientId);
					logDebug2("pBasketNameResp.subordername[j].iBasketId:%d:",pBasketNameResp.subordername[j].iBasketId);
					logDebug2("pBasketNameResp.subordername[j].cDelFlag:%c:",pBasketNameResp.subordername[j].cDelFlag);
					logDebug2("pBasketNameResp.subordername[j].sCreatetime:%s:",pBasketNameResp.subordername[j].sCreateTime);
					logDebug2("pBasketNameResp.subordername[j].cSource:%c:",pBasketNameResp.subordername[j].cSource);
					logDebug2("pBasketNameResp.subordername[j].sFiller1:%s:",pBasketNameResp.subordername[j].sDescription);

				}
				iTempNoOfRec--;

			}
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pBasketNameResp,sizeof(struct VIEW_DWS_BASKET_NAME_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

	}

}

BOOL   fFetchBasketName(CHAR *RcvMsg)
{
	logTimestamp("Entry : fBasketDetail");

	struct VIEW_DWS_ORDER_BASKET_REQUEST *pOrdBasketReq;

	struct VIEW_DWS_ORDER_BASKET_RESP pOrdBasketResp;

	struct VIEW_COMMON_HDR_RESP     pOrdBasketHdrResp;

	CHAR    sSelQry[DOUBLE_MAX_QUERY_SIZE];
	memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(&pOrdBasketReq,'\0',sizeof (struct VIEW_DWS_ORDER_BASKET_REQUEST));
	memset(&pOrdBasketResp,'\0',sizeof (struct VIEW_DWS_ORDER_BASKET_RESP ));
	memset(&pOrdBasketHdrResp,'\0',sizeof (struct VIEW_COMMON_HDR_RESP));

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempBasketId = 0;
	LONG32          iTempNoOfRec;

	pOrdBasketReq = (struct VIEW_DWS_ORDER_BASKET_REQUEST *)RcvMsg;

	sprintf(sSelQry,"Select UBD_BASKET_NAME from USER_ORDER_BASKET where UBD_CLIENT_ID = \"%s\" ;",pOrdBasketReq->sClientId);

	logDebug2("sSelQry :%s:",sSelQry);
	if((mysql_query(DBQueries,sSelQry)) != SUCCESS)
	{
		logSqlFatal("ERROR IN view Client Limit Query.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	pOrdBasketHdrResp.IntRespHeader.iSeqNo = 0;
	pOrdBasketHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
	pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
	iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}
	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pOrdBasketResp.IntRespHeader.iSeqNo = 0;
				pOrdBasketResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_ORDER_BASKET_RESP );
				pOrdBasketResp.IntRespHeader.iErrorId = 0;
				pOrdBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
				pOrdBasketResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
				pOrdBasketResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;

				if(iTempNoOfRec <= 1)
				{
					pOrdBasketResp.cMsgType = 'T';
				}
				else
				{
					pOrdBasketResp.cMsgType = 'D';
				}
				strncpy(pOrdBasketResp.suborderbasket[j].sBasketName,Row[0],CLIENT_NAME_LEN);
				logDebug2("pOrdBasketResp.subordername[j].sBasketName :%s:",pOrdBasketResp.suborderbasket[j].sBasketName);

			}
			iTempNoOfRec--;
		}
	}
	pOrdBasketResp.IntRespHeader.iSeqNo = 0;
	pOrdBasketResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_ORDER_BASKET_RESP);
	pOrdBasketResp.IntRespHeader.iErrorId = 0;
	pOrdBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;		

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketResp,sizeof(struct VIEW_DWS_ORDER_BASKET_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}


}


BOOL   fOrderBasket(CHAR *RcvMsg)
{
	logTimestamp("Entry : fOrderBasket");
	struct VIEW_DWS_ORDER_BASKET_REQUEST *pOrdBasketReq;
	struct VIEW_DWS_ORDER_BASKET_RESPONSE	pBasketResp;
	struct VIEW_DWS_ORDER_BASKET_RESP    pOrdBasketResp;
	struct VIEW_COMMON_HDR_RESP	pOrdBasketHdrResp;


	CHAR    sDelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sUpdQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sInsQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry1[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry2[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry4[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSelQry3[DOUBLE_MAX_QUERY_SIZE];
	CHAR    cChkFlag;

	memset(sSelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sSelQry1,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sSelQry2,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sDelQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sUpdQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sInsQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(&pOrdBasketReq,'\0',sizeof (struct VIEW_DWS_ORDER_BASKET_REQUEST));
	memset(&pOrdBasketResp,'\0',sizeof (struct VIEW_DWS_ORDER_BASKET_RESP));
	memset(&pOrdBasketHdrResp,'\0',sizeof (struct VIEW_COMMON_HDR_RESP));

	LONG32          iNoOfRec=0,i=0,j=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	CHAR		sTempBasketId[BASKET_ID];
	LONG32          iTempNoOfRec;
	CHAR		sSymbol[SYMBOL_LEN];
	CHAR		sSymbolName[DB_SYM_NAME_LEN];			

	pOrdBasketReq = (struct VIEW_DWS_ORDER_BASKET_REQUEST *)RcvMsg;

	logDebug2("pOrdBasketReq->cFlag :%c:",pOrdBasketReq->cFlag);
	cChkFlag = pOrdBasketReq->cFlag;
	logDebug2("cChkFlag :%c:",pOrdBasketReq->cFlag);
	logDebug2("cChkFlag :%c:",cChkFlag);
	logDebug2("sClientId :%s:",pOrdBasketReq->sClientId);
	logDebug2("sEntityId :%s:",pOrdBasketReq->sEntityId);
	logDebug2("pOrdBasketReq->ReqHeader.iUserId :%llu:",pOrdBasketReq->ReqHeader.iUserId);

	if(cChkFlag == ADD_BASKET)	
	{
		logDebug2("Adding the securities in basket :");

		sprintf(sSelQry,"SELECT NextVal('USER_SEQUENCE_ID');");
		logDebug2("sSelQry :%s:",sSelQry);
		if((mysql_query(DBQueries,sSelQry)) != SUCCESS)
		{
			logSqlFatal("ERROR IN view Client Limit Query.");
			sql_Error(DBQueries);
		}
		Res = mysql_store_result(DBQueries);
		if((Row = mysql_fetch_row(Res)))
		{
			logDebug2("Row :%s:",Row[0]);
			logDebug2("pOrdBasketReq->ReqHeader.iUserId :%llu:",pOrdBasketReq->ReqHeader.iUserId);
			sprintf(sTempBasketId,"%d%d",atoi(Row[0]),pOrdBasketReq->ReqHeader.iUserId);
			logDebug2("iTempBasketId:%s:",sTempBasketId);
			pOrdBasketReq->iSequenceId = atoi(sTempBasketId); 
		}
		mysql_free_result(Res);
		sprintf(sSelQry1,"SELECT SM_SYMBOL,SM_SYMBOL_NAME from SECURITY_MASTER where SM_EXCH_ID = \'%s\' and SM_SEGMENT = \'%c\' AND SM_SCRIP_CODE = \"%s\";",pOrdBasketReq->sExchId,pOrdBasketReq->cSegment,pOrdBasketReq->sScripCode);	
		if((mysql_query(DBQueries,sSelQry1)) != SUCCESS)
		{
			logSqlFatal("ERROR IN view Client Limit Query.");
			sql_Error(DBQueries);
		}
		Res = mysql_store_result(DBQueries);
		if((Row = mysql_fetch_row(Res)))
		{
			logDebug2("Row1 :%s:",Row[0]);
			logDebug2("Row2 :%s:",Row[1]);
			strncpy(sSymbol,Row[0],SYMBOL_LEN);
			strncpy(sSymbolName,Row[1],DB_SYM_NAME_LEN);
		}


		logDebug2("pOrdBasketReqs->sClientId:%s:",pOrdBasketReq->sClientId);
		logDebug2("pOrdBasketReq->sEntityId:%s:",pOrdBasketReq->sEntityId);
		logDebug2("pOrdBasketReq->sBasketName:%s:",pOrdBasketReq->sBasketName);
		logDebug2("pOrdBasketReq->iBasketId :%d:",pOrdBasketReq->iBasketId);
		logDebug2("pOrdBasketReq->cSource:%c:",pOrdBasketReq->cSegment);
		logDebug2("pOrdBasketReq->sScripCode:%s:",pOrdBasketReq->sScripCode);
		logDebug2("pOrdBasketReq->iQty:%d:",pOrdBasketReq->iQty);
		logDebug2("pOrdBasketReq->fPrice:%f:",pOrdBasketReq->fPrice);
		logDebug2("pOrdBasketReq->iOrderType:%d:",pOrdBasketReq->iOrderType);
		logDebug2("pOrdBasketReq->sCreateTime:%s:",pOrdBasketReq->sCreateTime);
		logDebug2("pOrdBasketReq->cScriptStatus:%c:",pOrdBasketReq->cScriptStatus);
		logDebug2("pOrdBasketReq->cProduct:%c:",pOrdBasketReq->cProduct);
		logDebug2("pOrdBasketReq->cBuySell:%c:",pOrdBasketReq->cBuySell);
		logDebug2("pOrdBasketReq->sUpdateTime:%s:",pOrdBasketReq->sUpdateTime);
		logDebug2("pOrdBasketReq->iOrdvalidity:%d:",pOrdBasketReq->iOrdvalidity);
		logDebug2("pOrdBasketReq->sFiller1:%s:",pOrdBasketReq->sFiller1);
		logDebug2("pOrdBasketReq->sFiller2:%s:",pOrdBasketReq->sFiller2);
		logDebug2("pOrdBasketReq->sFiller3:%s:",pOrdBasketReq->sFiller3);
		logDebug2("pOrdBasketReq->iSequenceId:%d:",pOrdBasketReq->iSequenceId);
		logDebug2("pOrdBasketReq->iMktType:%d:",pOrdBasketReq->iMktType);
		logDebug2("pOrdBasketReq->fTriggerPrice:%f:",pOrdBasketReq->fTriggerPrice);
		logDebug2("pOrdBasketReq->iDiscQty:%d:",pOrdBasketReq->iDiscQty);


		sprintf(sInsQry,"INSERT INTO USER_ORDER_BASKET \ 
				(UOB_CLIENT_ID,UOB_ENTITY_ID,UOB_BASKET_NAME,UOB_BASKET_ID,UOB_EXCH_ID,UOB_SEGMENT,UOB_SCRIPT_CODE,UOB_ORD_QTY,\
				 UOB_ORD_PRICE,UOB_ORD_TYPE,UOB_CREATE_TIME,UOB_SCRIPT_STATUS,UOB_PRODUCT,UOB_BUY_SELL_IND,UOB_UPDATE_TIME,\
				 UOB_ORDER_VALIDITY,UOB_FILLER1,UOB_FILLER2,UOB_FILLER3,UOB_SEQUENCE_ID,UOB_MKT_TYP,UOB_TRIGGER_PRICE,UOB_DISC_QTY,\
				 UOB_SYMBOL,UOB_SYMBOL_NAME)\
				VALUES \ 
				( \"%s\",\"%s\",\"%s\",%d,\"%s\",\'%c\',\"%s\",%d,%f,%d,STR_TO_DATE(\"%s\",\'%%Y,%%m,%%d %%H:%%i:%%S\'),\'%c\',\
				  \'%c\',\'%c\',STR_TO_DATE(\"%s\",\'%%Y,%%m,%%d %%H:%%i:%%S\'),%d,\
				  \"%s\" ,\"%s\",\"%s\",%d,%d,%f,%d,\"%s\",\"%s\");",\
				pOrdBasketReq->sClientId,pOrdBasketReq->sEntityId,pOrdBasketReq->sBasketName,pOrdBasketReq->iBasketId,\
				pOrdBasketReq->sExchId,pOrdBasketReq->cSegment,pOrdBasketReq->sScripCode,pOrdBasketReq->iQty,pOrdBasketReq->fPrice,pOrdBasketReq->iOrderType,\
				pOrdBasketReq->sCreateTime,pOrdBasketReq->cScriptStatus,pOrdBasketReq->cProduct,pOrdBasketReq->cBuySell,\
				pOrdBasketReq->sUpdateTime,pOrdBasketReq->iOrdvalidity,pOrdBasketReq->sFiller1,pOrdBasketReq->sFiller2,\
				pOrdBasketReq->sFiller3,pOrdBasketReq->iSequenceId,pOrdBasketReq->iMktType,pOrdBasketReq->fTriggerPrice,\
				pOrdBasketReq->iDiscQty,sSymbol,sSymbolName);

		logDebug2("sInsQry :%s:",sInsQry);		

		if(mysql_query(DBQueries,sInsQry) != SUCCESS)
		{
			logSqlFatal("Error in sInsQry.");
			sql_Error(DBQueries);
			pBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_ADD_ERR_RESP;
			pBasketResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			logDebug2("Success in insert query :");
			pBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
			pBasketResp.IntRespHeader.iErrorId = 0;
		}


		pBasketResp.IntRespHeader.iSeqNo = 0;
		pBasketResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_ORDER_BASKET_RESPONSE);
		pBasketResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pBasketResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		strncpy(pBasketResp.sClientId,pOrdBasketReq->sClientId,CLIENT_ID_LEN);		
		strncpy(pBasketResp.sEntityId,pOrdBasketReq->sEntityId,ENTITY_ID_LEN);
		strncpy(pBasketResp.sBasketName,pOrdBasketReq->sBasketName,CLIENT_NAME_LEN);
		pBasketResp.iBasketId =pOrdBasketReq->iBasketId; 
		strncpy(pBasketResp.sExchId,pOrdBasketReq->sExchId,EXCHANGE_LEN);
		pBasketResp.cSegment = pOrdBasketReq->cSegment;
		strncpy(pBasketResp.sScripCode,pOrdBasketReq->sScripCode,SCRIP_CODE_LEN);
		pBasketResp.iQty = pOrdBasketReq->iQty;
		pBasketResp.fPrice = pOrdBasketReq->fPrice;
		pBasketResp.iOrderType= pOrdBasketReq->iOrderType;
		strncpy(pBasketResp.sCreateTime,pOrdBasketReq->sCreateTime,SCRIP_CODE_LEN);
		pBasketResp.cScriptStatus = pOrdBasketReq->cScriptStatus;
		pBasketResp.cProduct = pOrdBasketReq->cProduct;
		pBasketResp.cBuySell = pOrdBasketReq->cBuySell;
		strncpy(pBasketResp.sUpdateTime,pOrdBasketReq->sUpdateTime,DATE_TIME_LEN);
		pBasketResp.iOrdvalidity = pOrdBasketReq->iOrdvalidity;
		strncpy(pBasketResp.sFiller1,pOrdBasketReq->sFiller1,FILLER_LEN_20);
		strncpy(pBasketResp.sFiller2,pOrdBasketReq->sFiller2,FILLER_LEN_20);
		strncpy(pBasketResp.sFiller3,pOrdBasketReq->sFiller3,FILLER_LEN_20);
		pBasketResp.iSequenceId = pOrdBasketReq->iSequenceId;
		pBasketResp.iMktType = pOrdBasketReq->iMktType;
		pBasketResp.fTriggerPrice = pOrdBasketReq->fTriggerPrice;
		pBasketResp.iDiscQty= pOrdBasketReq->iDiscQty;

		logDebug2(" pOrdBasketHdrResp.ResHeader.iSeqNo :%d:" , pBasketResp.IntRespHeader.iSeqNo);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgLength :%d: ", pBasketResp.IntRespHeader.iMsgLength);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iErrorId :%d:" , pBasketResp.IntRespHeader.iErrorId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgCode :%d:" , pBasketResp.IntRespHeader.iMsgCode);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iUserId :%llu:" , pBasketResp.IntRespHeader.iUserId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.cSource:%c:" , pBasketResp.IntRespHeader.cSource);
		logDebug2(" pOrdBasketHdrResp.ResHeader.sClientId :%s:" , pBasketResp.sClientId);

		logDebug2("pBasketResp.sClientId:%s:",pBasketResp.sClientId);
		logDebug2("pBasketResp.sEntityId:%s:",pBasketResp.sEntityId);
		logDebug2("pBasketResp.sBasketName:%s:",pBasketResp.sBasketName);
		logDebug2("pBasketResp.iBasketId :%d:",pBasketResp.iBasketId);
		logDebug2("pBasketResp.cSource:%c:",pBasketResp.cSegment);
		logDebug2("pBasketResp.sScripCode:%s:",pBasketResp.sScripCode);
		logDebug2("pBasketResp.iQty:%d:",pBasketResp.iQty);
		logDebug2("pBasketResp.fPrice:%f:",pBasketResp.fPrice);
		logDebug2("pBasketResp.iOrderType:%d:",pBasketResp.iOrderType);
		logDebug2("pBasketResp.sCreateTime:%s:",pBasketResp.sCreateTime);
		logDebug2("pBasketResp.cScriptStatus:%c:",pBasketResp.cScriptStatus);
		logDebug2("pBasketResp.cProduct:%c:",pBasketResp.cProduct);
		logDebug2("pBasketResp.cBuySell:%c:",pBasketResp.cBuySell);
		logDebug2("pBasketResp.sUpdateTime:%s:",pBasketResp.sUpdateTime);
		logDebug2("pBasketResp.iOrdvalidity:%d:",pBasketResp.iOrdvalidity);
		logDebug2("pBasketResp.sFiller1:%s:",pBasketResp.sFiller1);
		logDebug2("pBasketResp.sFiller2:%s:",pBasketResp.sFiller2);
		logDebug2("pBasketResp.sFiller3:%s:",pBasketResp.sFiller3);
		logDebug2("pBasketResp.iSequenceId:%d:",pBasketResp.iSequenceId);
		logDebug2("pBasketResp.iMktType:%d:",pBasketResp.iMktType);
		logDebug2("pBasketResp.fTriggerPrice:%f:",pBasketResp.fTriggerPrice);
		logDebug2("pBasketResp.iDiscQty:%d:",pBasketResp.iDiscQty);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pBasketResp ,sizeof(struct VIEW_DWS_ORDER_BASKET_RESPONSE) ,iRelayID ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

	}
	if(cChkFlag == UPDATE_BASKET)
	{
		logDebug2("pOrdBasketReqs->sClientId:%s:",pOrdBasketReq->sClientId);
		logDebug2("pOrdBasketReq->sEntityId:%s:",pOrdBasketReq->sEntityId);
		logDebug2("pOrdBasketReq->sBasketName:%s:",pOrdBasketReq->sBasketName);
		logDebug2("pOrdBasketReq->iBasketId :%d:",pOrdBasketReq->iBasketId);
		logDebug2("pOrdBasketReq->sScripCode:%s:",pOrdBasketReq->sScripCode);
		logDebug2("pOrdBasketReq->iQty:%d:",pOrdBasketReq->iQty);
		logDebug2("pOrdBasketReq->fPrice:%f:",pOrdBasketReq->fPrice);
		logDebug2("pOrdBasketReq->iOrderType:%d",pOrdBasketReq->iOrderType);
		logDebug2("pOrdBasketReq->sCreateTime:%s:",pOrdBasketReq->sCreateTime);
		logDebug2("pOrdBasketReq->cSegment:%c:",pOrdBasketReq->cSegment);
		logDebug2("pOrdBasketReq->cScriptStatus:%c:",pOrdBasketReq->cScriptStatus);
		logDebug2("pOrdBasketReq->cProduct:%c:",pOrdBasketReq->cProduct);
		logDebug2("pOrdBasketReq->cBuySell:%c:",pOrdBasketReq->cBuySell);
		logDebug2("pOrdBasketReq->sUpdateTime:%s:",pOrdBasketReq->sUpdateTime);
		logDebug2("pOrdBasketReq->iOrdvalidity:%d:",pOrdBasketReq->iOrdvalidity);
		logDebug2("pOrdBasketReq->sFiller1:%s:",pOrdBasketReq->sFiller1);
		logDebug2("pOrdBasketReq->sFiller2:%s:",pOrdBasketReq->sFiller2);
		logDebug2("pOrdBasketReq->sFiller3:%s:",pOrdBasketReq->sFiller3);
		logDebug2("pOrdBasketReq->iSequenceId:%d:",pOrdBasketReq->iSequenceId);
		logDebug2("pOrdBasketReq->iMktType:%d:",pOrdBasketReq->iMktType);
		logDebug2("pOrdBasketReq->fTriggerPrice:%f:",pOrdBasketReq->fTriggerPrice);
		logDebug2("pOrdBasketReq->iDiscQty:%d:",pOrdBasketReq->iDiscQty);		


		//		sprintf(sUpdQry,"UPDATE USER_ORDER_BRACKET SET UOB_SCRIPT_STATUS = '\%c\' , UOB_UPDATE_TIME = now(),UOB_ENTITY_ID = \"%s\" \
		WHERE UOB_BASKET_ID = %d and UOB_CLIENT_ID = \"%s\" and UOB_SCRIPT_CODE = \"%s\" ;",pOrdBasketReq->cScriptStatus,pOrdBasketReq->sEntityId,\
			pOrdBasketReq->iBasketId,pOrdBasketReq->sClientId,pOrdBasketReq->sScripCode);

		sprintf(sUpdQry,"INSERT INTO USER_ORDER_BASKET (\
			UOB_CLIENT_ID,\
				UOB_ENTITY_ID,\
				UOB_BASKET_NAME,\
				UOB_BASKET_ID,\
				UOB_EXCH_ID,\
				UOB_SEGMENT,\
				UOB_SCRIPT_CODE,\
				UOB_ORD_QTY,\
				UOB_ORD_PRICE,\
				UOB_ORD_TYPE,\
				UOB_CREATE_TIME,\
				UOB_SCRIPT_STATUS,\
				UOB_PRODUCT,\
				UOB_BUY_SELL_IND,\
				UOB_UPDATE_TIME,\
				UOB_ORDER_VALIDITY,\
				UOB_FILLER1,\
				UOB_FILLER2,\
				UOB_FILLER3,\
				UOB_SEQUENCE_ID,\
				UOB_MKT_TYP,\
				UOB_TRIGGER_PRICE,\
				UOB_DISC_QTY)\
				VALUES( \"%s\",\"%s\",\"%s\",%d,\"%s\",\'%c\',\"%s\",%d,%f,%d,STR_TO_DATE(\"%s\",\'%%Y,%%m,%%d %%H:%%i:%%S\'),\'%c\',\
						\'%c\',\'%c\',STR_TO_DATE(\"%s\",\'%%Y,%%m,%%d %%H:%%i:%%S\'),%d,\
						\"%s\",\"%s\",\"%s\",%d,%d,%f,%d)\ 
				on duplicate key \ 
				UPDATE \
				UOB_CLIENT_ID = VALUES(UOB_CLIENT_ID),\
				UOB_ENTITY_ID = VALUES(UOB_ENTITY_ID),\
				UOB_BASKET_NAME = VALUES(UOB_BASKET_NAME),\
				UOB_BASKET_ID = VALUES(UOB_BASKET_ID),\
				UOB_EXCH_ID = VALUES(UOB_EXCH_ID),\
				UOB_SEGMENT = VALUES(UOB_SEGMENT),\
				UOB_SCRIPT_CODE = VALUES(UOB_SCRIPT_CODE),\
				UOB_ORD_QTY = VALUES(UOB_ORD_QTY),\
				UOB_ORD_PRICE = VALUES(UOB_ORD_PRICE),\
				UOB_ORD_TYPE = VALUES(UOB_ORD_TYPE),\
				UOB_CREATE_TIME = VALUES(UOB_CREATE_TIME),\
				UOB_SCRIPT_STATUS = VALUES(UOB_SCRIPT_STATUS),\
				UOB_PRODUCT = VALUES(UOB_PRODUCT),\
				UOB_BUY_SELL_IND = VALUES(UOB_BUY_SELL_IND),\
				UOB_UPDATE_TIME = VALUES(UOB_UPDATE_TIME),\
				UOB_ORDER_VALIDITY = VALUES(UOB_ORDER_VALIDITY),\
				UOB_FILLER1 = VALUES(UOB_FILLER1),\
				UOB_FILLER2 = VALUES(UOB_FILLER2),\
				UOB_FILLER3 = VALUES(UOB_FILLER3),\
				UOB_SEQUENCE_ID = VALUES(UOB_SEQUENCE_ID),\
				UOB_MKT_TYP = VALUES(UOB_MKT_TYP),\
				UOB_TRIGGER_PRICE = VALUES(UOB_TRIGGER_PRICE),\
				UOB_DISC_QTY = VALUES(UOB_DISC_QTY);" \
				,pOrdBasketReq->sClientId,pOrdBasketReq->sEntityId,pOrdBasketReq->sBasketName,pOrdBasketReq->iBasketId,\
				pOrdBasketReq->sExchId,pOrdBasketReq->cSegment,pOrdBasketReq->sScripCode,pOrdBasketReq->iQty,pOrdBasketReq->fPrice,pOrdBasketReq->iOrderType,\
				pOrdBasketReq->sCreateTime,pOrdBasketReq->cScriptStatus,pOrdBasketReq->cProduct,pOrdBasketReq->cBuySell,\
				pOrdBasketReq->sUpdateTime,pOrdBasketReq->iOrdvalidity,pOrdBasketReq->sFiller1,pOrdBasketReq->sFiller2,\
				pOrdBasketReq->sFiller3,pOrdBasketReq->iSequenceId,pOrdBasketReq->iMktType,pOrdBasketReq->fTriggerPrice,pOrdBasketReq->iDiscQty);

		logDebug2("sUpdQry :%s:",sUpdQry);

		if(mysql_query(DBQueries,sUpdQry) != SUCCESS)
		{
			logSqlFatal("Error in sUpdQry.");
			sql_Error(DBQueries);
			pBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_EDIT_ERR_RESP;
			pBasketResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			logDebug2("Success in Update Qry :");
			pBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
			pBasketResp.IntRespHeader.iErrorId = 0;
		}

		pBasketResp.IntRespHeader.iSeqNo = 0;
		pBasketResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_ORDER_BASKET_RESPONSE);
		pBasketResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pBasketResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		strncpy(pBasketResp.sClientId,pOrdBasketReq->sClientId,CLIENT_ID_LEN);
		strncpy(pBasketResp.sEntityId,pOrdBasketReq->sEntityId,ENTITY_ID_LEN);
		strncpy(pBasketResp.sBasketName,pOrdBasketReq->sBasketName,CLIENT_NAME_LEN);
		pBasketResp.iBasketId =pOrdBasketReq->iBasketId;
		strncpy(pBasketResp.sExchId,pOrdBasketReq->sExchId,EXCHANGE_LEN);
		pBasketResp.cSegment = pOrdBasketReq->cSegment;
		strncpy(pBasketResp.sScripCode,pOrdBasketReq->sScripCode,SCRIP_CODE_LEN);
		pBasketResp.iQty = pOrdBasketReq->iQty;
		pBasketResp.fPrice = pOrdBasketReq->fPrice;
		pBasketResp.iOrderType= pOrdBasketReq->iOrderType;
		strncpy(pBasketResp.sCreateTime,pOrdBasketReq->sCreateTime,SCRIP_CODE_LEN);
		pBasketResp.cScriptStatus = pOrdBasketReq->cScriptStatus;
		pBasketResp.cProduct = pOrdBasketReq->cProduct;
		pBasketResp.cBuySell = pOrdBasketReq->cBuySell;
		strncpy(pBasketResp.sUpdateTime,pOrdBasketReq->sUpdateTime,DATE_TIME_LEN);
		pBasketResp.iOrdvalidity = pOrdBasketReq->iOrdvalidity;
		strncpy(pBasketResp.sFiller1,pOrdBasketReq->sFiller1,FILLER_LEN_20);
		strncpy(pBasketResp.sFiller2,pOrdBasketReq->sFiller2,FILLER_LEN_20);
		strncpy(pBasketResp.sFiller3,pOrdBasketReq->sFiller3,FILLER_LEN_20);
		pBasketResp.iSequenceId = pOrdBasketReq->iSequenceId;
		pBasketResp.iMktType= pOrdBasketReq->iMktType;
		pBasketResp.fTriggerPrice= pOrdBasketReq->fTriggerPrice;
		pBasketResp.iDiscQty= pOrdBasketReq->iDiscQty;

		logDebug2(" pOrdBasketHdrResp.ResHeader.iSeqNo :%d:" , pBasketResp.IntRespHeader.iSeqNo);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgLength :%d: ", pBasketResp.IntRespHeader.iMsgLength);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iErrorId :%d:" , pBasketResp.IntRespHeader.iErrorId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgCode :%d:" , pBasketResp.IntRespHeader.iMsgCode);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iUserId :%llu:" , pBasketResp.IntRespHeader.iUserId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.cSource:%c:" , pBasketResp.IntRespHeader.cSource);
		logDebug2(" pOrdBasketHdrResp.ResHeader.sClientId :%s:" , pBasketResp.sClientId);

		logDebug2("pBasketResp.sClientId:%s:",pBasketResp.sClientId);
		logDebug2("pBasketResp.sEntityId:%s:",pBasketResp.sEntityId);
		logDebug2("pBasketResp.sBasketName:%s:",pBasketResp.sBasketName);
		logDebug2("pBasketResp.iBasketId :%d:",pBasketResp.iBasketId);
		logDebug2("pBasketResp.cSource:%c:",pBasketResp.cSegment);
		logDebug2("pBasketResp.sScripCode:%s:",pBasketResp.sScripCode);
		logDebug2("pBasketResp.iQty:%d:",pBasketResp.iQty);
		logDebug2("pBasketResp.fPrice:%f:",pBasketResp.fPrice);
		logDebug2("pBasketResp.iOrderType:%d:",pBasketResp.iOrderType);
		logDebug2("pBasketResp.sCreateTime:%s:",pBasketResp.sCreateTime);
		logDebug2("pBasketResp.cScriptStatus:%c:",pBasketResp.cScriptStatus);
		logDebug2("pBasketResp.cProduct:%c:",pBasketResp.cProduct);
		logDebug2("pBasketResp.cBuySell:%c:",pBasketResp.cBuySell);
		logDebug2("pBasketResp.sUpdateTime:%s:",pBasketResp.sUpdateTime);
		logDebug2("pBasketResp.iOrdvalidity:%d:",pBasketResp.iOrdvalidity);
		logDebug2("pBasketResp.sFiller1:%s:",pBasketResp.sFiller1);
		logDebug2("pBasketResp.sFiller2:%s:",pBasketResp.sFiller2);
		logDebug2("pBasketResp.sFiller3:%s:",pBasketResp.sFiller3);
		logDebug2("pBasketResp.iSequenceId:%d:",pBasketResp.iSequenceId);
		logDebug2("pBasketResp.iMktType:%d:",pBasketResp.iMktType);
		logDebug2("pBasketResp.fTriggerPrice:%f:",pBasketResp.fTriggerPrice);
		logDebug2("pBasketResp.iDiscQty:%d:",pBasketResp.iDiscQty);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pBasketResp,sizeof(struct VIEW_DWS_ORDER_BASKET_RESPONSE) ,iRelayID ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}


	}
	if(cChkFlag == DEL_BASKET)
	{

		logDebug2("pOrdBasketReqs->sClientId:%s:",pOrdBasketReq->sClientId);
		logDebug2("pOrdBasketReq->iBasketId :%d:",pOrdBasketReq->iBasketId);
		logDebug2("pOrdBasketReq->iSequenceId :%d:",pOrdBasketReq->iSequenceId);

		sprintf(sDelQry,"DELETE FROM USER_ORDER_BASKET WHERE UOB_CLIENT_ID = \"%s\" AND UOB_SEQUENCE_ID= %d ;",pOrdBasketReq->sClientId,\
				pOrdBasketReq->iSequenceId);		

		logDebug2("sDelQry :%s:",sDelQry);

		if(mysql_query(DBQueries,sDelQry) != SUCCESS)
		{
			logSqlFatal("Error in sDelQry.");
			sql_Error(DBQueries);
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_EDIT_ERR_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 1;
		}
		else
		{
			logDebug2("Success to delete query :");
			pOrdBasketHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
			pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		}

		pOrdBasketHdrResp.IntRespHeader.iSeqNo = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
		pOrdBasketHdrResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pOrdBasketHdrResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		strncpy(pOrdBasketHdrResp.sClientId,pOrdBasketReq->sClientId,CLIENT_ID_LEN);
		pOrdBasketHdrResp.cMsgType = 'H';
		pOrdBasketHdrResp.iNoofRec = 1;
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		logDebug2(" pOrdBasketHdrResp.ResHeader.iSeqNo :%d:" , pOrdBasketHdrResp.IntRespHeader.iSeqNo);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgLength :%d: ", pOrdBasketHdrResp.IntRespHeader.iMsgLength);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iErrorId :%d:" , pOrdBasketHdrResp.IntRespHeader.iErrorId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iMsgCode :%d:" , pOrdBasketHdrResp.IntRespHeader.iMsgCode);
		logDebug2(" pOrdBasketHdrResp.ResHeader.iUserId :%llu:" , pOrdBasketHdrResp.IntRespHeader.iUserId);
		logDebug2(" pOrdBasketHdrResp.ResHeader.cSource:%c:" , pOrdBasketHdrResp.IntRespHeader.cSource);
		logDebug2(" pOrdBasketHdrResp.ResHeader.sClientId :%s:" , pOrdBasketHdrResp.sClientId);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
	}
	if(cChkFlag == VIEW_BASKET)
	{
		logDebug2("VIew Basket Query :");

		sprintf(sSelQry,"SELECT UOB_ENTITY_ID,UOB_BASKET_NAME,UOB_BASKET_ID,UOB_EXCH_ID,UOB_SEGMENT,UOB_SCRIPT_CODE,UOB_ORD_QTY,\
				UOB_ORD_PRICE,UOB_ORD_TYPE,UOB_CREATE_TIME,UOB_SCRIPT_STATUS,UOB_PRODUCT,UOB_BUY_SELL_IND,UOB_UPDATE_TIME,\
				UOB_ORDER_VALIDITY,UOB_FILLER1,UOB_FILLER2,UOB_FILLER3,UOB_SEQUENCE_ID,UOB_MKT_TYP,UOB_TRIGGER_PRICE,\
				UOB_DISC_QTY FROM USER_ORDER_BASKET WHERE UOB_CLIENT_ID = \"%s\";",pOrdBasketReq->sClientId);

		logDebug2("sSelQry2 :%s:",sSelQry);
		if((mysql_query(DBQueries,sSelQry)) != SUCCESS)
		{
			logSqlFatal("ERROR IN view Client Limit Query.");
			sql_Error(DBQueries);
		}
		Res = mysql_store_result(DBQueries);
		iNoOfRec = mysql_num_rows(Res);

		fNoOfRec = iNoOfRec;
		iNoOfPkt = ceil(fNoOfRec/5);
		iTempNoOfRec = iNoOfRec;
		pOrdBasketHdrResp.IntRespHeader.iSeqNo = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
		pOrdBasketHdrResp.IntRespHeader.iErrorId = 0;
		pOrdBasketHdrResp.IntRespHeader.iMsgCode =TC_INT_ORDER_BASKET_RESP ;
		pOrdBasketHdrResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
		pOrdBasketHdrResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;
		pOrdBasketHdrResp.cMsgType = 'H';
		pOrdBasketHdrResp.iNoofRec = iNoOfRec;

		logDebug2("pOrdBasketReq->ReqHeader.iUserId = %llu",pOrdBasketReq->ReqHeader.iUserId);
		iRelayID = find_user_adapter(pOrdBasketReq->ReqHeader.iUserId);
		logDebug2("iRelayID = %d",iRelayID);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

		for(i=0;i<iNoOfPkt;i++)
		{
			for(j=0;j<5;j++)
			{
				if((Row = mysql_fetch_row(Res)))
				{
					pOrdBasketResp.IntRespHeader.iSeqNo = 0;
					pOrdBasketResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_ORDER_BASKET_RESP);
					pOrdBasketResp.IntRespHeader.iErrorId = 0;
					pOrdBasketResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BASKET_RESP;
					pOrdBasketResp.IntRespHeader.iUserId = pOrdBasketReq->ReqHeader.iUserId;
					pOrdBasketResp.IntRespHeader.cSource = pOrdBasketReq->ReqHeader.cSource ;

					if(iTempNoOfRec <= 1)
					{
						pOrdBasketResp.cMsgType = 'T';
					}
					else
					{
						pOrdBasketResp.cMsgType = 'D';
					}

					strncpy(pOrdBasketResp.suborderbasket[j].sEntityId,Row[0],ENTITY_ID_LEN);
					strncpy(pOrdBasketResp.suborderbasket[j].sBasketName,Row[1],CLIENT_NAME_LEN);
					pOrdBasketResp.suborderbasket[j].iBasketId = atoi(Row[2]);
					strncpy(pOrdBasketResp.suborderbasket[j].sExchId,Row[3],EXCHANGE_LEN);
					pOrdBasketResp.suborderbasket[j].cSegment = atoi(Row[4]);
					strncpy(pOrdBasketResp.suborderbasket[j].sScripCode,Row[5],SCRIP_CODE_LEN);
					pOrdBasketResp.suborderbasket[j].iQty = atoi(Row[6]);
					pOrdBasketResp.suborderbasket[j].fPrice = atof(Row[7]);
					pOrdBasketResp.suborderbasket[j].iOrderType= atoi(Row[8]);
					strncpy(pOrdBasketResp.suborderbasket[j].sCreateTime,Row[9],DATE_TIME_LEN);
					pOrdBasketResp.suborderbasket[j].cScriptStatus = Row[10][0];
					pOrdBasketResp.suborderbasket[j].cProduct = Row[11][0];
					pOrdBasketResp.suborderbasket[j].cBuySell = Row[12][0];
					strncpy(pOrdBasketResp.suborderbasket[j].sUpdateTime,Row[13],DATE_TIME_LEN);
					pOrdBasketResp.suborderbasket[j].iOrdvalidity = atoi(Row[14]);
					strncpy(pOrdBasketResp.suborderbasket[j].sFiller1,Row[15],FILLER_LEN_20);
					strncpy(pOrdBasketResp.suborderbasket[j].sFiller2,Row[16],FILLER_LEN_20);
					strncpy(pOrdBasketResp.suborderbasket[j].sFiller3,Row[17],FILLER_LEN_20);
					pOrdBasketResp.suborderbasket[j].iSequenceId = atoi(Row[18]);
					pOrdBasketResp.suborderbasket[j].iMktType = atoi(Row[21]);
					pOrdBasketResp.suborderbasket[j].fTriggerPrice= atoi(Row[20]);
					pOrdBasketResp.suborderbasket[j].iDiscQty= atoi(Row[19]);

					logDebug2("pOrdBasketResp.suborderbasket[j].sBasketName :%s:",pOrdBasketResp.suborderbasket[j].sBasketName);
					logDebug2("pOrdBasketResp.suborderbasket[j].sEntityId:%s:",pOrdBasketResp.suborderbasket[j].sEntityId);
					logDebug2("pOrdBasketResp.suborderbasket[j].iBasketId:%d:",pOrdBasketResp.suborderbasket[j].iBasketId);
					logDebug2("pOrdBasketResp.suborderbasket[j].sExchId:%s:",pOrdBasketResp.suborderbasket[j].sExchId);
					logDebug2("pOrdBasketResp.suborderbasket[j].sScripCode:%s:",pOrdBasketResp.suborderbasket[j].sScripCode);
					logDebug2("pOrdBasketResp.suborderbasket[j].iQty:%d:",pOrdBasketResp.suborderbasket[j].iQty);
					logDebug2("pOrdBasketResp.suborderbasket[j].fPrice:%f:",pOrdBasketResp.suborderbasket[j].fPrice);
					logDebug2("pOrdBasketResp.suborderbasket[j].iOrderType:%d:",pOrdBasketResp.suborderbasket[j].iOrderType);
					logDebug2("pOrdBasketResp.suborderbasket[j].sCreateTime:%s:",pOrdBasketResp.suborderbasket[j].sCreateTime);
					logDebug2("pOrdBasketResp.suborderbasket[j].cScriptStatus:%c:",pOrdBasketResp.suborderbasket[j].cScriptStatus);
					logDebug2("pOrdBasketResp.suborderbasket[j].cProduct:%c:",pOrdBasketResp.suborderbasket[j].cProduct);
					logDebug2("pOrdBasketResp.suborderbasket[j].cBuySell:%c:",pOrdBasketResp.suborderbasket[j].cBuySell);
					logDebug2("pOrdBasketResp.suborderbasket[j].sUpdateTime:%s:",pOrdBasketResp.suborderbasket[j].sUpdateTime);
					logDebug2("pOrdBasketResp.suborderbasket[j].iOrdvalidity:%d:",pOrdBasketResp.suborderbasket[j].iOrdvalidity);
					logDebug2("pOrdBasketResp.suborderbasket[j].sFiller1:%s:",pOrdBasketResp.suborderbasket[j].sFiller1);
					logDebug2("pOrdBasketResp.suborderbasket[j].sFiller2:%s:",pOrdBasketResp.suborderbasket[j].sFiller2);
					logDebug2("pOrdBasketResp.suborderbasket[j].sFiller3:%s:",pOrdBasketResp.suborderbasket[j].sFiller3);
					logDebug2("pOrdBasketResp.suborderbasket[j].iSequenceId:%d:",pOrdBasketResp.suborderbasket[j].iSequenceId);
					logDebug2("pOrdBasketResp.suborderbasket[j].iMktType:%d:",pOrdBasketResp.suborderbasket[j].iMktType);
					logDebug2("pOrdBasketResp.suborderbasket[j].fTriggerPrice:%f:",pOrdBasketResp.suborderbasket[j].fTriggerPrice);
					logDebug2("pOrdBasketResp.suborderbasket[j].iDiscQty:%d:",pOrdBasketResp.suborderbasket[j].iDiscQty);

				}
				iTempNoOfRec--;
			}
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrdBasketResp,sizeof(struct VIEW_DWS_ORDER_BASKET_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}


	}
}

BOOL 	fViewClientLimit(CHAR *RcvMsg)
{
	logTimestamp("Entry : fViewClientLimit");

	struct  VIEW_COMMON_QUERY_REQ   	*pViewLimitReq;
	struct	VIEW_CLIENT_LIMIT_RESP_NEW	pViewLimitResp    ;
	struct VIEW_COMMON_HDR_RESP		pLimitHdrResp	;

	LONG32	iErrorId=0,i=0,j=0;
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec = 0.00;
	LONG32          iNoOfPkt = 0;
	LONG32          iTempNoOfRec = 0;

	pViewLimitReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	MYSQL_RES 	*Res;
	MYSQL_ROW	Row;
	//	CHAR *sClntLmt = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);


	CHAR    sClntLmt [DOUBLE_MAX_QUERY_SIZE];
	CHAR    sViewLimit      [QUERY_SIZE];
	CHAR    sWhere_Clause[QUERY_SIZE];

	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sViewLimit,'\0',QUERY_SIZE);
	memset(sClntLmt,'\0',DOUBLE_MAX_QUERY_SIZE);
	printf("Size of struct  VIEW_CLIENT_LIMIT_RESP_NEW:%d: \n", sizeof(struct  VIEW_CLIENT_LIMIT_RESP_NEW));
	logDebug2("pViewLimitReq->sClientId = %s",pViewLimitReq->sClientId);

/***
	 sprintf(sClntLmt,"SELECT       LIMIT_SOD,      ADHOC_LIMIT,      RECEIVABLES,      BANK_HOLDING,      COLLATERALS,      REALISED_PROFITS,      AMOUNT_UTILIZED,      COLLATERALS + SUM_OF_ALL AS SUM_OF_ALL,      COLLATERALS + AVAILABLE_BALANCE AS AVAILABLE_BALANCE,      CLEAR_BALANCE,      LIMIT_TYPE,      CLIENT_ID,      REQUEST_PAYOUT_AMOUNT,      SEGMENT,      CF_OPT_SELL_PREMIUM,      CF_OPT_SELL_PREMIUM_COMM,      CLIENT_NAME,      GROSS_HOLDING_VAL  FROM      (SELECT           X.limit_sod AS LIMIT_SOD,              X.adhoc_limit AS ADHOC_LIMIT,              (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) AS RECEIVABLES,              X.bank_holding AS BANK_HOLDING,              CASE RCSL.COLLATERAL_FLAG                  WHEN 'Y' THEN ROUND(IFNULL(SUM((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 0)) / 100)), 0), 2)                  ELSE 0              END AS COLLATERALS,              (X.realised_profits + X.realised_profits_Comm) AS REALISED_PROFITS,              (X.Amount_Utilized + X.Amount_Utilized_Comm) AS AMOUNT_UTILIZED,              ROUND((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) - X.Request_Payout_Amount), 2) AS SUM_OF_ALL,              ROUND(((X.limit_sod + X.adhoc_limit + X.bank_holding + X.realised_profits + X.realised_profits_Comm + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM) - (X.Amount_Utilized + X.Amount_Utilized_Comm)) - X.Request_Payout_Amount, 2) AS AVAILABLE_BALANCE,              X.CLEAR_BALANCE AS CLEAR_BALANCE,              X.limit_type AS LIMIT_TYPE,              X.CLIENT_ID AS CLIENT_ID,              X.Request_Payout_Amount AS Request_Payout_Amount,              X.SEGMENT AS SEGMENT,              X.CF_OPT_SELL_PREMIUM AS CF_OPT_SELL_PREMIUM,              X.CF_OPT_SELL_PREMIUM_COMM AS CF_OPT_SELL_PREMIUM_COMM,              E.ENTITY_NAME AS CLIENT_NAME,              (CASE  WHEN X.SEGMENT IN ('E','A') THEN ROUND(IFNULL(SUM((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * IFNULL(LWA.L1_LTP, 0)), 0), 2)                  ELSE 0              END) AS GROSS_HOLDING_VAL      FROM          (SELECT           'CAPITAL' AS `limit_type`,              ROUND(IFNULL(`R`.`C_CASH_BALANCE`, 0), 2) AS `limit_sod`,              ROUND(IFNULL(`R`.`C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,              ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,              ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM_COMM`, 0), 2) AS `CF_OPT_SELL_PREMIUM_COMM`,              ROUND(IFNULL(`R`.`NC_NSE_RECEIVABLES`, 0) + IFNULL(`R`.`NC_BSE_RECEIVABLES`, 0), 2) AS `receivables`,              ROUND(IFNULL(`R`.`C_BANK_HOLD`, 0), 2) AS `bank_holding`,              ROUND(IFNULL(`R`.`NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,              ROUND(IFNULL(`R`.`NC_REALISED_PROFIT_COMM`, 0), 2) AS `realised_profits_Comm`,              ROUND((IFNULL(`R`.`TOTAL_CASH_UTILIZED`, 0) + IFNULL(`R`.`TOTAL_NON_CASH_UTILIZED`, 0)), 2) AS `Amount_Utilized`,              ROUND(IFNULL(`R`.`TOTAL_CASH_UTILIZED_COMM`, 0), 2) AS `Amount_Utilized_Comm`,              `R`.`CLIENT_ID` AS `CLIENT_ID`,              `R`.`EXCH_ID` AS `EXCH_ID`,              `R`.`SEGMENT` AS `segment`,              ROUND(`R`.`WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,              ROUND(`R`.`REQUEST_PAYOUT_AMOUNT`, 2) AS `Request_Payout_Amount`      FROM          `RMS_FUND_LIMIT` `R`      WHERE          R.CLIENT_ID LIKE \"%s\" UNION ALL SELECT           'COMMODITY' AS `limit_type`,              ROUND(IFNULL(`R`.`RMLC_C_CASH_BALANCE`, 0), 2) AS `limit_sod`,              ROUND(IFNULL(`R`.`RMLC_C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,              ROUND(IFNULL(`R`.`RMLC_CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,              0 AS `CF_OPT_SELL_PREMIUM_COMM`,              0 AS `receivables`,              ROUND(IFNULL(`R`.`RMLC_C_BANK_HOLD`, 0), 2) AS `bank_holding`,              ROUND(IFNULL(`R`.`RMLC_NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,              0 AS `realised_profits_Comm`,              ROUND(IFNULL(`R`.`RMLC_TOTAL_CASH_UTILIZED`, 0), 2) AS `Amount_Utilized`,              0 AS `Amount_Utilized_Comm`,              `R`.`RMLC_CLIENT_ID` AS `CLIENT_ID`,              `R`.`RMLC_EXCHANGE` AS `EXCH_ID`,              `R`.`RMLC_SEGMENT` AS `SEGMENT`,              ROUND(`R`.`RMLC_WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,              ROUND(`R`.`RMLC_REQUEST_PAYOUT_AMOUNT`, 2) AS `REQUEST_PAYOUT_AMOUNT`      FROM          `RMS_FUND_LIMIT_COM` `R`      WHERE          R.RMLC_CLIENT_ID LIKE \"%s\") X      LEFT JOIN `ENTITY_MASTER` `E` ON ((`E`.`ENTITY_CODE` = `X`.`CLIENT_ID`))      LEFT JOIN `RMS_RISK_PROFILE_MAST` `D` ON ((`E`.`ENTITY_RISK_PROFILE` = `D`.`RPM_CODE`))      LEFT JOIN RMS_CLIENT_SECURITY_LIMIT RCSL ON (RCSL.CLIENT_ID = X.CLIENT_ID              AND RCSL.SECURITY_SOURCE_TYPE IN ('HLD' , 'T1', 'MRG'))      LEFT JOIN EQ_L1_WATCH LWA ON (LWA.L1_SCRIP_CODE = CASE RCSL.EXCH_ID WHEN 'ALL' THEN RCSL.NSE_SCRIP_CODE                                                                                                                                                   WHEN 'NSE' THEN RCSL.NSE_SCRIP_CODE                                                                                                                                                  ELSE RCSL.BSE_SCRIP_CODE end                                       and LWA.L1_SEGMENT='E'                                                                          AND LWA.L1_EXCHANGE = CASE WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE' ELSE RCSL.EXCH_ID END)      LEFT JOIN HAIRCUT_MASTER HM ON (RCSL.ISIN_CODE = HM.HM_ISIN                                                                            AND HM.HM_EXCHANGE = CASE                                                                          WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'                                                                          ELSE RCSL.EXCH_ID END)     GROUP BY X.SEGMENT , X.CLIENT_ID) AS XX  WHERE      1 = 1; ",pViewLimitReq->sClientId,pViewLimitReq->sClientId); 

***/
	sprintf(sClntLmt,"SELECT   IFNULL(LIMIT_SOD, 0),   IFNULL(ADHOC_LIMIT, 0),   IFNULL(RECEIVABLES, 0),   IFNULL(BANK_HOLDING, 0),   CASE     WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(COLLATERALS, 2), 0))     ELSE 0   END COLLATERALS,   IFNULL(REALISED_PROFITS, 0),   IFNULL(AMOUNT_UTILIZED, 0),   IFNULL((CASE         WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(COLLATERALS, 2), 0))         ELSE 0       END) + SUM_OF_ALL,       0) AS SUM_OF_ALL,   IFNULL((CASE         WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(COLLATERALS, 2), 0))         ELSE 0       END) + AVAILABLE_BALANCE + IF(IFNULL(MTM_COMB,0) < 0,IFNULL(MTM_COMB,0),0),       0) AS AVAILABLE_BALANCE,   IFNULL(CLEAR_BALANCE, 0),   IFNULL(LIMIT_TYPE, 0),   IFNULL(CLIENT_ID, 0),   IFNULL(REQUEST_PAYOUT_AMOUNT, 0),   IFNULL(SEGMENT, 0),   IFNULL(CF_OPT_SELL_PREMIUM, 0),   IFNULL(CF_OPT_SELL_PREMIUM_COMM, 0),   IFNULL(CLIENT_NAME, 0),   CASE     WHEN SEGMENT IN ('E' , 'A') THEN SUM(IFNULL(ROUND(GROSS_HOLDING_VAL, 2), 0))     ELSE 0   END GROSS_HOLDING_VAL,   IFNULL(MTM_COMB,\"0.00\") FROM   (SELECT     X.limit_sod AS LIMIT_SOD,       X.adhoc_limit AS ADHOC_LIMIT,       (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) AS RECEIVABLES,       X.bank_holding AS BANK_HOLDING,       CASE         WHEN RCSL.COLLATERAL_FLAG = 'Y' THEN ((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 0)) / 100))         ELSE 0       END COLLATERALS,       (X.realised_profits + X.realised_profits_Comm) AS REALISED_PROFITS,       (X.Amount_Utilized + X.Amount_Utilized_Comm) AS AMOUNT_UTILIZED,       ROUND((X.limit_sod + X.adhoc_limit + X.bank_holding + (case D.RPM_REALIZE_PROFIT when 'Y' then X.realised_profits else (case WHEN (D.RPM_REALIZE_PROFIT_SUBS='Y' AND X.realised_profits<0) THEN X.realised_profits ELSE 0 END) end)        +(case D.RPM_REALIZE_PROFIT when 'Y' then X.realised_profits_Comm else (case WHEN (D.RPM_REALIZE_PROFIT_SUBS='Y' AND X.realised_profits_Comm<0) THEN X.realised_profits_Comm ELSE 0 END) end)+ X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) - X.Request_Payout_Amount), 2) AS SUM_OF_ALL,       ROUND(((X.limit_sod + X.adhoc_limit + X.bank_holding + (case D.RPM_REALIZE_PROFIT when 'Y' then X.realised_profits else (case WHEN (D.RPM_REALIZE_PROFIT_SUBS='Y' AND X.realised_profits<0) THEN X.realised_profits ELSE 0 END) end)        +(case D.RPM_REALIZE_PROFIT when 'Y' then X.realised_profits_Comm else (case WHEN (D.RPM_REALIZE_PROFIT_SUBS='Y' AND X.realised_profits_Comm<0) THEN X.realised_profits_Comm ELSE 0 END) end) + (X.receivables * D.RPM_CNC_SELL_BEN_PER / 100) + X.CF_OPT_SELL_PREMIUM + X.CF_OPT_SELL_PREMIUM_COMM) - (X.Amount_Utilized + X.Amount_Utilized_Comm)) - X.Request_Payout_Amount, 2) AS AVAILABLE_BALANCE,       X.CLEAR_BALANCE AS CLEAR_BALANCE,       X.limit_type AS LIMIT_TYPE,       X.CLIENT_ID AS CLIENT_ID,       X.Request_Payout_Amount AS Request_Payout_Amount,       X.SEGMENT AS SEGMENT,       X.CF_OPT_SELL_PREMIUM AS CF_OPT_SELL_PREMIUM,       X.CF_OPT_SELL_PREMIUM_COMM AS CF_OPT_SELL_PREMIUM_COMM,       E.ENTITY_NAME AS CLIENT_NAME,       (IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) AS GROSS_HOLDING_VAL   FROM     (SELECT     'CAPITAL' AS `limit_type`,       ROUND(IFNULL(`R`.`C_CASH_BALANCE`, 0), 2) AS `limit_sod`,       ROUND(IFNULL(`R`.`C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,       ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,       ROUND(IFNULL(`R`.`CF_OPT_SELL_PREMIUM_COMM`, 0), 2) AS `CF_OPT_SELL_PREMIUM_COMM`,       ROUND(IFNULL(`R`.`NC_NSE_RECEIVABLES`, 0) + IFNULL(`R`.`NC_BSE_RECEIVABLES`, 0), 2) AS `receivables`,       ROUND(IFNULL(`R`.`C_BANK_HOLD`, 0), 2) AS `bank_holding`,       ROUND(IFNULL(`R`.`NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,       ROUND(IFNULL(`R`.`NC_REALISED_PROFIT_COMM`, 0), 2) AS `realised_profits_Comm`,       ROUND((IFNULL(`R`.`TOTAL_CASH_UTILIZED`, 0) + IFNULL(`R`.`TOTAL_NON_CASH_UTILIZED`, 0)), 2) AS `Amount_Utilized`,       ROUND(IFNULL(`R`.`TOTAL_CASH_UTILIZED_COMM`, 0), 2) AS `Amount_Utilized_Comm`,       `R`.`CLIENT_ID` AS `CLIENT_ID`,       `R`.`EXCH_ID` AS `EXCH_ID`,       `R`.`SEGMENT` AS `segment`,       ROUND(`R`.`WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,       ROUND(`R`.`REQUEST_PAYOUT_AMOUNT`, 2) AS `Request_Payout_Amount`   FROM     `RMS_FUND_LIMIT` `R`   WHERE     R.CLIENT_ID LIKE \"%s\" UNION ALL SELECT     'COMMODITY' AS `limit_type`,       ROUND(IFNULL(`R`.`RMLC_C_CASH_BALANCE`, 0), 2) AS `limit_sod`,       ROUND(IFNULL(`R`.`RMLC_C_ADHOC_LIMIT`, 0), 2) AS `adhoc_limit`,       ROUND(IFNULL(`R`.`RMLC_CF_OPT_SELL_PREMIUM`, 0), 2) AS `CF_OPT_SELL_PREMIUM`,       0 AS `CF_OPT_SELL_PREMIUM_COMM`,       0 AS `receivables`,       ROUND(IFNULL(`R`.`RMLC_C_BANK_HOLD`, 0), 2) AS `bank_holding`,       ROUND(IFNULL(`R`.`RMLC_NC_REALISED_PROFIT`, 0), 2) AS `realised_profits`,       0 AS `realised_profits_Comm`,       ROUND(IFNULL(`R`.`RMLC_TOTAL_CASH_UTILIZED`, 0), 2) AS `Amount_Utilized`,       0 AS `Amount_Utilized_Comm`,       `R`.`RMLC_CLIENT_ID` AS `CLIENT_ID`,       `R`.`RMLC_EXCHANGE` AS `EXCH_ID`,       `R`.`RMLC_SEGMENT` AS `SEGMENT`,       ROUND(`R`.`RMLC_WITHDRAWAL_CASH`, 2) AS `CLEAR_BALANCE`,       ROUND(`R`.`RMLC_REQUEST_PAYOUT_AMOUNT`, 2) AS `REQUEST_PAYOUT_AMOUNT`   FROM     `RMS_FUND_LIMIT_COM` `R`   WHERE     R.RMLC_CLIENT_ID LIKE \"%s\") X   LEFT JOIN `ENTITY_MASTER` `E` ON ((`E`.`ENTITY_CODE` = `X`.`CLIENT_ID`))   LEFT JOIN `RMS_RISK_PROFILE_MAST` `D` ON ((`E`.`ENTITY_RISK_PROFILE` = `D`.`RPM_CODE`))   LEFT JOIN RMS_CLIENT_SECURITY_LIMIT RCSL ON (RCSL.CLIENT_ID = X.CLIENT_ID     AND RCSL.SECURITY_SOURCE_TYPE IN ('HLD' , 'T1', 'MRG'))   LEFT JOIN EQ_L1_WATCH LWA ON (LWA.L1_SCRIP_CODE = CASE RCSL.EXCH_ID     WHEN 'ALL' THEN RCSL.NSE_SCRIP_CODE     WHEN 'NSE' THEN RCSL.NSE_SCRIP_CODE     ELSE RCSL.BSE_SCRIP_CODE   END     AND LWA.L1_SEGMENT = 'E'     AND LWA.L1_EXCHANGE = CASE     WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'     ELSE RCSL.EXCH_ID   END)   LEFT JOIN HAIRCUT_MASTER HM ON (RCSL.ISIN_CODE = HM.HM_ISIN     AND HM.HM_EXCHANGE = CASE     WHEN RCSL.EXCH_ID = 'ALL' THEN 'NSE'     ELSE RCSL.EXCH_ID   END)) D   CROSS JOIN (SELECT SUM(MTM) AS MTM_COMB   FROM 	(SELECT (CASE 				WHEN 					(SM.SM_SEGMENT = 'E') 				THEN 					ROUND((CASE 								WHEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0) 								THEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY) 			WHEN 0 THEN 0 			ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY)) 		END), 		2))) 								ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY) 		WHEN 0 THEN 0 		ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY)) 	END), 	2))) 							END), 							2) 				WHEN 					(SM.SM_SEGMENT = 'D') 				THEN 					ROUND((CASE 								WHEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0) 								THEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY) 			WHEN 0 THEN 0 			ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY)) 		END), 		2))) 								ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY) 		WHEN 0 THEN 0 		ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY)) 	END), 	2))) 							END), 							2) 				WHEN 					(SM.SM_SEGMENT = 'C') 				THEN 					(ROUND((CASE 								WHEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0) 								THEN ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY) 			WHEN 0 THEN 0 			ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY)) 		END), 		4))) 								ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY) 		WHEN 0 THEN 0 		ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY)) 	END), 	4))) 							END), 							2) * 1000) 				WHEN 					(SM.SM_SEGMENT = 'M') 				THEN 					(ROUND((CASE           WHEN             ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) > 0)           THEN             ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.BUY_QTY)                   WHEN 0 THEN 0                   ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))                 END),                 2)))           ELSE ((SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) * (MW.L1_LTP - ROUND((CASE SUM(MBNP.SELL_QTY)                 WHEN 0 THEN 0                 ELSE (SUM(MBNP.SELL_VAL) / SUM(MBNP.SELL_QTY))               END),               2))) 					END), 					2) * SM.SM_MCX_MULTIPLIER) 				END) AS MTM 		FROM 			(SELECT 				DT.DRV_CLIENT_ID AS CLIENT_ID, 				DT.DRV_SCRIP_CODE AS SECURITY_ID, 				DT.DRV_EXCH_ID AS EXCH_ID, 			SUM((CASE 				WHEN (DT.DRV_BUY_SELL_IND = 'B') THEN DT.DRV_TRD_TRADE_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN 					(DT.DRV_BUY_SELL_IND = 'B') 				THEN 					(CASE 						WHEN (DT.DRV_CF_FLAG = '-1') THEN (DT.DRV_ORIGINAL_PRICE * DT.DRV_TRD_TRADE_QTY) 						ELSE (DT.DRV_TRD_TRADE_PRICE * DT.DRV_TRD_TRADE_QTY) 					END) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (DT.DRV_BUY_SELL_IND = 'S') THEN DT.DRV_TRD_TRADE_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (DT.DRV_BUY_SELL_IND = 'S') THEN (DT.DRV_TRD_TRADE_PRICE * DT.DRV_TRD_TRADE_QTY) 				ELSE 0 			END)) AS SELL_VAL, 			DT.DRV_SEGMENT AS EXCH_SEGMENT, 			DT.DRV_PRODUCT_ID AS PRODUCT, 			DT.DRV_CF_FLAG AS INT_REF_ID 		FROM 			DRV_ORDERS DT 		WHERE 			(DT.DRV_TRD_STATUS = 'C') 				AND (DT.DRV_MSG_CODE = '2222') 				AND (DT.DRV_CLIENT_ID = \"%s\") 		GROUP BY DT.DRV_CLIENT_ID , DT.DRV_SCRIP_CODE , DT.DRV_EXCH_ID , DT.DRV_PRODUCT_ID , DT.DRV_SEGMENT , DT.DRV_CF_FLAG 		UNION ALL SELECT 			T.EQ_CLIENT_ID AS EQ_CLIENT_ID, 			T.EQ_SCRIP_CODE AS EQ_SCRIP_CODE, 			T.EQ_EXCH_ID AS EQ_EXCH_ID, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'B') THEN T.EQ_LAST_TRADE_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'B') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'S') THEN T.EQ_LAST_TRADE_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (T.EQ_BUY_SELL_IND = 'S') THEN (T.EQ_TRD_TRADE_PRICE * T.EQ_LAST_TRADE_QTY) 				ELSE 0 			END)) AS SELL_VAL, 			'E' AS E, 			T.EQ_PRODUCT_ID AS EQ_PRODUCT_ID, 			0 AS INT_REF_ID 		FROM 			EQ_ORDERS T 		WHERE 			(T.EQ_TRD_STATUS = 'C') 				AND (T.EQ_MSG_CODE = 2222) 				AND (T.EQ_CLIENT_ID = \"%s\") 		GROUP BY T.EQ_CLIENT_ID , T.EQ_SCRIP_CODE , T.EQ_EXCH_ID , T.EQ_PRODUCT_ID 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS BUY_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS BUY_VAL, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS SELL_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS BUY_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS BUY_VAL, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END))) AS SELL_QTY, 			(-(1) * SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END))) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL_DR CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_SOURCE , CD.RCCD_SEGMENT 		UNION ALL SELECT 			CD.RCCD_CLIENT_ID AS RCCD_CLIENT_ID, 			CD.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE, 			CD.RCCD_EXCHANGE AS RCCD_EXCHANGE, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS BUY_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'B') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS BUY_VAL, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN CD.RCCD_QTY 				ELSE 0 			END)) AS SELL_QTY, 			SUM((CASE 				WHEN (CD.RCCD_SIDE = 'S') THEN (CD.RCCD_QTY * CD.RCCD_CONVT_PRICE) 				ELSE 0 			END)) AS SELL_VAL, 			CD.RCCD_SEGMENT AS RCCD_SEGMENT, 			CD.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION, 			0 AS '0' 		FROM 			RMS_CLIENT_CONVT_TO_DEL_DR CD 		WHERE CD.RCCD_CLIENT_ID = \"%s\" 		GROUP BY CD.RCCD_CLIENT_ID , CD.RCCD_SCRIP_CODE , CD.RCCD_EXCHANGE , CD.RCCD_PRODUCT_DESTINATION , CD.RCCD_SEGMENT     UNION ALL     SELECT     CT.COMM_CLIENT_ID AS CLIENT_ID,     CT.COMM_SCRIP_CODE AS SECURITY_ID,     CT.COMM_EXCH_ID AS EXCH_ID,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'B') THEN CT.COMM_TRD_TRADE_QTY       ELSE 0     END)) AS BUY_QTY,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'B') THEN (CT.COMM_TRD_TRADE_PRICE * CT.COMM_TRD_TRADE_QTY)       ELSE 0     END)) AS BUY_VAL,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'S') THEN CT.COMM_TRD_TRADE_QTY       ELSE 0     END)) AS SELL_QTY,     SUM((CASE       WHEN (CT.COMM_BUY_SELL_IND = 'S') THEN (CT.COMM_TRD_TRADE_PRICE * CT.COMM_TRD_TRADE_QTY)       ELSE 0     END)) AS SELL_VAL,     CT.COMM_SEGMENT AS EXCH_SEGMENT,     CT.COMM_PRODUCT_ID AS PRODUCT,     CT.COMM_CF_FLAG AS INT_REF_ID   FROM     COMM_ORDERS CT   WHERE     COMM_CLIENT_ID = \"%s\"   GROUP BY CT.COMM_CLIENT_ID , CT.COMM_SCRIP_CODE , CT.COMM_EXCH_ID , CT.COMM_PRODUCT_ID , CT.COMM_SEGMENT   UNION SELECT     CM.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,     CM.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,     CM.RCCD_EXCHANGE AS RCCD_EXCHANGE,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN CM.RCCD_QTY       ELSE 0     END))) AS BUY_QTY,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END))) AS BUY_VAL,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN CM.RCCD_QTY       ELSE 0     END))) AS SELL_QTY,     (-(1) * SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END))) AS SELL_VAL,     CM.RCCD_SEGMENT AS rccd_segment,     CM.RCCD_PRODUCT_SOURCE AS RCCD_PRODUCT_SOURCE,     0 AS '0'   FROM     RMS_CLIENT_CONVT_TO_DEL_COM CM 	WHERE RCCD_CLIENT_ID = \"%s\"   GROUP BY CM.RCCD_CLIENT_ID , CM.RCCD_SCRIP_CODE , CM.RCCD_EXCHANGE , CM.RCCD_MKT_TYPE , CM.RCCD_PRODUCT_SOURCE , CM.RCCD_SEGMENT   UNION SELECT     CM.RCCD_CLIENT_ID AS RCCD_CLIENT_ID,     CM.RCCD_SCRIP_CODE AS RCCD_SCRIP_CODE,     CM.RCCD_EXCHANGE AS RCCD_EXCHANGE,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN CM.RCCD_QTY       ELSE 0     END)) AS BUY_QTY,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'B') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END)) AS BUY_VAL,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN CM.RCCD_QTY       ELSE 0     END)) AS SELL_QTY,     SUM((CASE       WHEN (CM.RCCD_SIDE = 'S') THEN (CM.RCCD_QTY * CM.RCCD_CONVT_PRICE)       ELSE 0     END)) AS SELL_VAL,     CM.RCCD_SEGMENT AS RCCD_SEGMENT,     CM.RCCD_PRODUCT_DESTINATION AS RCCD_PRODUCT_DESTINATION,     0 AS '0'   FROM     RMS_CLIENT_CONVT_TO_DEL_COM CM 	WHERE RCCD_CLIENT_ID = \"%s\"   GROUP BY CM.RCCD_CLIENT_ID , CM.RCCD_SCRIP_CODE , CM.RCCD_EXCHANGE , CM.RCCD_PRODUCT_DESTINATION , CM.RCCD_SEGMENT) MBNP 			JOIN SEM_ACTIVE SM 			JOIN L1_WATCH_ACTIVE MW 		WHERE 			((MBNP.SECURITY_ID = SM.SM_SCRIP_CODE) 				AND (MBNP.EXCH_ID = SM.SM_EXCHANGE) 				AND (MBNP.EXCH_SEGMENT = SM.SM_SEGMENT) 				AND (MBNP.SECURITY_ID = MW.L1_SCRIP_CODE) 				AND (MBNP.EXCH_SEGMENT = MW.L1_SEGMENT) 				AND (MBNP.EXCH_ID = MW.L1_EXCHANGE)) 		GROUP BY MBNP.CLIENT_ID , MBNP.SECURITY_ID , SM.SM_INSTRUMENT_NAME , SM.SM_SYMBOL , SM.SM_UNDERLAYING_SCRIP_CODE , MBNP.EXCH_ID , SM.SM_EXPIRY_DATE , SM.SM_STRIKE_PRICE , SM.SM_OPTION_TYPE , SM.SM_SEGMENT , MBNP.PRODUCT , MW.L1_LTP , SM.SM_LOT_SIZE) AS POS_MTM) AS MTM WHERE   1 = 1 AND CLIENT_ID LIKE \"%s\" GROUP BY SEGMENT , CLIENT_ID;",pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId,pViewLimitReq->sClientId);
 
	printf(" fViewClientLimit:%s:",sClntLmt);

	if((mysql_query(DBQueries,sClntLmt)) != SUCCESS)
	{
		logSqlFatal("ERROR IN view Client Limit Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iNoOfRec :%d:",iNoOfRec);
	pLimitHdrResp.IntRespHeader.iSeqNo = 0;
	pLimitHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pLimitHdrResp.IntRespHeader.iErrorId = 0;
	pLimitHdrResp.IntRespHeader.iMsgCode = TC_INT_CLT_LMT_HEADER_RESP;
	pLimitHdrResp.IntRespHeader.iUserId = pViewLimitReq->ReqHeader.iUserId;
	pLimitHdrResp.IntRespHeader.cSource = pViewLimitReq->ReqHeader.cSource ;
	pLimitHdrResp.cMsgType = 'H';
	pLimitHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pViewLimitReq->ReqHeader.iUserId = %llu",pViewLimitReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewLimitReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pLimitHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}



	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pViewLimitResp,'\0',sizeof(struct VIEW_CLIENT_LIMIT_RESP_NEW));	

		pViewLimitResp.IntRespHeader.iSeqNo = 0;
		pViewLimitResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_LIMIT_RESP_NEW);
		pViewLimitResp.IntRespHeader.iMsgCode = TC_INT_VIEW_CLIENT_LIMIT_RESP;
		pViewLimitResp.IntRespHeader.iErrorId = iErrorId;
		pViewLimitResp.IntRespHeader.iUserId = pViewLimitReq->ReqHeader.iUserId;
		pViewLimitResp.IntRespHeader.cSource = pViewLimitReq->ReqHeader.cSource ;
		strncpy(pViewLimitResp.sClientId,pViewLimitReq->sClientId,ENTITY_ID_LEN);		
		if(iTempNoOfRec <= 1)
		{
			pViewLimitResp.cMsgType = 'T';
		}
		else
		{
			pViewLimitResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{

				pViewLimitResp.sSubViewClientlimit[j].fLimitSOD = atof(Row[0]);
				pViewLimitResp.sSubViewClientlimit[j].fAdhocLimit = atof(Row[1]);
				pViewLimitResp.sSubViewClientlimit[j].fReceivables = atof(Row[2]);
				pViewLimitResp.sSubViewClientlimit[j].fBankHoldings = atof(Row[3]);
				pViewLimitResp.sSubViewClientlimit[j].fCollaterals = atof(Row[4]);
				pViewLimitResp.sSubViewClientlimit[j].fRelaisedProfit = atof(Row[5]);
				pViewLimitResp.sSubViewClientlimit[j].fAmountUtilised = atof(Row[6]);
				pViewLimitResp.sSubViewClientlimit[j].fSumofAll = atof(Row[7]);
				pViewLimitResp.sSubViewClientlimit[j].fAvailableBal = atof(Row[8]);
				pViewLimitResp.sSubViewClientlimit[j].fClearBalance = atof(Row[9]);
				strncpy(pViewLimitResp.sSubViewClientlimit[j].sLimitType,Row[10],10);
				pViewLimitResp.sSubViewClientlimit[j].sSegment = Row[13][0];
				pViewLimitResp.sSubViewClientlimit[j].fReqPayOutAmt = atof(Row[12]);
				pViewLimitResp.sSubViewClientlimit[j].fCFOptSellPrm= atof(Row[14]);
				pViewLimitResp.sSubViewClientlimit[j].fCFOptSellPrmComm= atof(Row[15]);
				strncpy(pViewLimitResp.sSubViewClientlimit[j].sClientName,Row[16],ENTITY_NAME_LEN);
				pViewLimitResp.sSubViewClientlimit[j].fGrossHoldVal= atof(Row[17]);
				pViewLimitResp.sSubViewClientlimit[j].fMtmValue= atof(Row[18]);
				

				logDebug2("-------------------------Start Print for Record = %d ------------------------------",j);
				logDebug2("pViewLimitResp.IntRespHeader.iMsgCode :%d:",pViewLimitResp.IntRespHeader.iMsgCode);
				logDebug2("pViewLimitResp.IntRespHeader.iMsgLength:%d:",pViewLimitResp.IntRespHeader.iMsgLength);
				logDebug2("pViewLimitResp.IntRespHeader.iErrorId:%d:",pViewLimitResp.IntRespHeader.iErrorId);
				logDebug2("pViewLimitResp.IntRespHeader.iUserId:%llu:",pViewLimitResp.IntRespHeader.iUserId);
				logDebug2("pViewLimitResp.IntRespHeader.cSource:%c",pViewLimitResp.IntRespHeader.cSource);
				logDebug2("pViewLimitResp.sClientId:%s",pViewLimitResp.sClientId);
				logDebug3("pViewLimitResp.fLimitSOD:%lf:",pViewLimitResp.sSubViewClientlimit[j].fLimitSOD);
				logDebug3("pViewLimitResp.fAdhocLimit:%lf:",pViewLimitResp.sSubViewClientlimit[j].fAdhocLimit);
				logDebug3("pViewLimitResp.fReceivables:%lf:",pViewLimitResp.sSubViewClientlimit[j].fReceivables);
				logDebug3("pViewLimitResp.fBankHoldings:%lf:",pViewLimitResp.sSubViewClientlimit[j].fBankHoldings);
				logDebug3("pViewLimitResp.fCollaterals:%lf:",pViewLimitResp.sSubViewClientlimit[j].fCollaterals);
				logDebug3("pViewLimitResp.fRelaisedProfit:%lf:",pViewLimitResp.sSubViewClientlimit[j].fRelaisedProfit);
				logDebug3("pViewLimitResp.fAmountUtilised:%lf:",pViewLimitResp.sSubViewClientlimit[j].fAmountUtilised);
				logDebug3("pViewLimitResp.fSumofAll:%lf:",pViewLimitResp.sSubViewClientlimit[j].fSumofAll);
				logDebug3("pViewLimitResp.fAvailableBal:%lf:",pViewLimitResp.sSubViewClientlimit[j].fAvailableBal);
				logDebug3("pViewLimitResp.fClearBalance:%lf ",pViewLimitResp.sSubViewClientlimit[j].fClearBalance);
				logDebug3("pViewLimitResp.sLimitType:%s:",pViewLimitResp.sSubViewClientlimit[j].sLimitType);
				logDebug3("pViewLimitResp.sSegment:%c ",pViewLimitResp.sSubViewClientlimit[j].sSegment);
				logDebug3("pViewLimitResp.fReqPayOutAmt:%lf ",pViewLimitResp.sSubViewClientlimit[j].fReqPayOutAmt);
				logDebug3("pViewLimitResp.fCFOptSellPrm:%lf ",pViewLimitResp.sSubViewClientlimit[j].fCFOptSellPrm);
				logDebug3("pViewLimitResp.fCFOptSellPrmComm:%lf ",pViewLimitResp.sSubViewClientlimit[j].fCFOptSellPrmComm);
				logDebug3("pViewLimitResp.sClientName:%s:",pViewLimitResp.sSubViewClientlimit[j].sClientName);
				logDebug3("pViewLimitResp.fGrossHoldVal:%lf:",pViewLimitResp.sSubViewClientlimit[j].fGrossHoldVal);
				logDebug3("pViewLimitResp.fMtmValue:%lf:",pViewLimitResp.sSubViewClientlimit[j].fMtmValue);

				logDebug2("-------------------------End Print------------------------------");


			}

		}


		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewLimitResp,sizeof(struct VIEW_CLIENT_LIMIT_RESP_NEW) ,iRelayID ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
	}
	logTimestamp("Exit : fViewClientLimit");

}/**** END Of fViewClientLimit*****/

BOOL	fViewNetPosition(CHAR *RcvMsg)
{
	logTimestamp("ENTRY : fViewNetPosition");
	struct VIEW_COMMON_QUERY_REQ *pViewNetPosReq;
	struct VIEW_NET_POSITION_RESP pViewNetPosResp;
	struct VIEW_COMMON_HDR_RESP pViewNetPosHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR		sUserType[3];
	CHAR		sMrgType[3];
	BOOL		iMrgType=FALSE;
	CHAR    	*sViewNetBk = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pViewNetPosReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;
	memset(sUserType ,'\0',3);
	memset(sMrgType,'\0',3);

	logDebug2("pViewNetPosReq->sClientId = %s",pViewNetPosReq->sClientId);
	logDebug2("pViewNetPosReq->sEntityId = %s",pViewNetPosReq->sEntityId);

	sprintf(sViewNetBk,"SELECT  ENTITY_TYPE,ENTITY_MANAGER_TYPE from  ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));",pViewNetPosReq->sEntityId);
	logDebug2("sViewNetBk = %s",sViewNetBk);

	if(mysql_query(DBQueries,sViewNetBk) != SUCCESS)
	{
		logSqlFatal("Error in sViewNetBk Query.");
		sql_Error(DBQueries); 
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
		//strncpy(sMrgType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
		}
	}
	logDebug2("sUserType = %s",sUserType);

	if(!strcmp(sUserType ,"D")) //&& !strcmp(pViewNetPosReq->sClientId,"-1"))
	{
		logDebug2("call fDeaNetPosition function");
		fDeaNetPosition(RcvMsg,iMrgType);
		return TRUE;

	}
	/***
	  if(!strcmp(sUserType ,"D") && strcmp(pViewNetPosReq->sClientId,"-1"))
	  {
	  logDebug2("call fNetPosition function");
	  fNetPosition(RcvMsg);
	  return TRUE;

	  }
	 ***/
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("call client fNetPosition function");
		fNetPosition(RcvMsg);
		return TRUE;

	}

	logTimestamp("EXIT : fViewNetPosition");
	return TRUE;

}

BOOL	fDeaNetPosition(CHAR *RcvMsg,BOOL iMrgTypeFlg)
{
	logTimestamp("ENTRY : fDeaNetPosition");
	struct VIEW_COMMON_QUERY_REQ *pNetPosReq;
	struct VIEW_NET_POSITION_RESP pNetPosResp;
	struct VIEW_COMMON_HDR_RESP pNetPosHdrResp;

	LONG32 		i=0,j=0;
	MYSQL_RES	*Res;
	MYSQL_ROW       Row;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	CHAR	*sNetPosQry = malloc (sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	CHAR	*sWhereQry = malloc (sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	pNetPosReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	logDebug2("pNetPosReq->sClientId = %s",pNetPosReq->sClientId);
	logDebug2("pNetPosReq->sEntityId = %s",pNetPosReq->sEntityId);



	if(iMrgTypeFlg == TRUE)
	{
		if(strcmp(pNetPosReq->sClientId,"-1") == 0)
		{
			sprintf(sWhereQry," AND NP.CLIENT_ID IN (select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(trim(\"%s\")))",pNetPosReq->sEntityId);
		}
		else
		{
			sprintf(sWhereQry," AND NP.CLIENT_ID IN (select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(trim(\"%s\")) AND C.EDM_CLIENT_ID = ltrim(trim(\"%s\")))",pNetPosReq->sEntityId,pNetPosReq->sClientId);

		}

	}
	else
	{

		if(strcmp(pNetPosReq->sClientId,"-1") == 0)
		{
			sprintf(sWhereQry," ");
		}
		else
		{
			sprintf(sWhereQry," AND NP.CLIENT_ID  = ltrim(trim(\"%s\"))",pNetPosReq->sClientId);

		}
	}
	logDebug2("sWhereQry :%s:",sWhereQry);

	sprintf(sNetPosQry,"SELECT  CLIENT_ID,  SECURITY_ID,  EXCH_ID,  MKT_TYPE,  TOT_BUY_QTY,  TOT_BUY_QTY_CF,  TOT_BUY_QTY_DAY,  TOT_BUY_VAL,  TOT_BUY_VAL_CF,  TOT_BUY_VAL_DAY,  BUY_AVG,  TOT_SELL_QTY,  TOT_SELL_QTY_CF,  TOT_SELL_QTY_DAY,  TOT_SELL_VAL,  TOT_SELL_VAL_CF,  TOT_SELL_VAL_DAY,  SELL_AVG,  NET_QTY,  NET_VAL,  NET_AVG,  GROSS_QTY,  GROSS_VAL,  SEGMENT,  PROD_ID,  REALISED_PROFIT,  REF_ID,  CROSS_CUR_FLAG,  RBI_REFERENCE_RATE FROM  (SELECT  `MBNP`.`CLIENT_ID` AS `CLIENT_ID`,   `MBNP`.`SECURITY_ID` AS `SECURITY_ID`,   `MBNP`.`EXCH_ID` AS `EXCH_ID`,   'NL' AS `MKT_TYPE`,   `MBNP`.`SYMBOL` AS `SYMBOL`,   `MBNP`.`INSTRUMENT` AS `INSTRUMENT`,   `MBNP`.`EXPIRY_DATE` AS `EXPIRY_DATE`,   SUM(`MBNP`.`BUY_QTY`) AS `TOT_BUY_QTY`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN - 1 THEN `MBNP`.`BUY_QTY`    ELSE 0   END) AS `TOT_BUY_QTY_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN 0 THEN `MBNP`.`BUY_QTY`    ELSE 0   END) AS `TOT_BUY_QTY_DAY`,   SUM(CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000    WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER)    ELSE (MBNP.BUY_VAL)   END) AS TOT_BUY_VAL,   SUM(CASE MBNP.INT_REF_ID    WHEN     - 1    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER     ELSE MBNP.BUY_VAL     END)    ELSE 0   END) AS `TOT_BUY_VAL_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN     0    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER)     ELSE (MBNP.BUY_VAL)     END)    ELSE 0   END) AS `TOT_BUY_VAL_DAY`,   (CASE    WHEN     (`MBNP`.`SEGMENT_CODE` = 'C')    THEN     ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))     END), 4)    ELSE ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))    END), 2)   END) AS `BUY_AVG`,   SUM(`MBNP`.`SELL_QTY`) AS `TOT_SELL_QTY`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN - 1 THEN `MBNP`.`SELL_QTY`    ELSE 0   END) AS `TOT_SELL_QTY_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN 0 THEN `MBNP`.`SELL_QTY`    ELSE 0   END) AS `TOT_SELL_QTY_DAY`,   SUM(CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000    WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER)    ELSE (MBNP.SELL_VAL)   END) AS TOT_SELL_VAL,   SUM(CASE MBNP.INT_REF_ID    WHEN     - 1    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER     ELSE MBNP.SELL_VAL     END)    ELSE 0   END) AS `TOT_SELL_VAL_CF`,   SUM(CASE `MBNP`.`INT_REF_ID`    WHEN     0    THEN     (CASE     WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000     WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER     ELSE (MBNP.SELL_VAL)     END)    ELSE 0   END) AS `TOT_SELL_VAL_DAY`,   (CASE    WHEN     (`MBNP`.`SEGMENT_CODE` = 'C')    THEN     ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))     END), 4)    ELSE ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))    END), 2)   END) AS `SELL_AVG`,   (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)) AS `NET_QTY`,   (CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)    WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)    ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))   END) AS NET_VAL,   (CASE    WHEN     (`MBNP`.`SEGMENT_CODE` = 'C')    THEN     ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))     WHEN 0 THEN 0     ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))     END), 2)    ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))     WHEN 0 THEN 0     ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))    END), 2)   END) AS `NET_AVG`,   (SUM(`MBNP`.`BUY_QTY`) + SUM(`MBNP`.`SELL_QTY`)) AS `GROSS_QTY`,   (CASE    WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * 1000)    WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * MBNP.COMM_MULTIPLIER)    ELSE (SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL))   END) AS GROSS_VAL,   MBNP.SEGMENT_CODE AS SEGMENT,   MBNP.PRODUCT AS PROD_ID,   (CASE    WHEN     (MBNP.SEGMENT_CODE = 'C')    THEN     (CASE     WHEN      `MBNP`.`CROSS_CUR_FLAG` = 'Y'     THEN      (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)       WHEN 0 THEN 0       ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))      END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)       WHEN 0 THEN 0       ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))      END), 4))), 4) * 1000 * `MBNP`.`RBI_REFERENCE_RATE`)     ELSE (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)      WHEN 0 THEN 0      ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))     END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)      WHEN 0 THEN 0      ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))     END), 4))), 4) * 1000)     END)    WHEN     (`MBNP`.`SEGMENT_CODE` = 'M')    THEN     (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))     END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))     END), 2))), 2) * 1)    ELSE ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))    END), 2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)     WHEN 0 THEN 0     ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))    END), 2))), 2)   END) AS `REALISED_PROFIT`,   `MBNP`.`INT_REF_ID` AS `REF_ID`,   `MBNP`.`CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   `MBNP`.`RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`  FROM   (SELECT  `DT`.`DRV_CLIENT_ID` AS `CLIENT_ID`,   `DT`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,   `DT`.`DRV_EXCH_ID` AS `EXCH_ID`,   `DT`.`DRV_SEGMENT` AS `SEGMENT_CODE`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN `DT`.`DRV_TRD_TRADE_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN `DT`.`DRV_TRD_TRADE_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)    ELSE 0   END)) AS `SELL_VAL`,   `DT`.`DRV_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,   `DT`.`DRV_SEGMENT` AS `EXCH_SEGMENT`,   `DT`.`DRV_PRODUCT_ID` AS `PRODUCT`,   `DT`.`DRV_CF_FLAG` AS `INT_REF_ID`,   SUBSTR(`DT`.`DRV_SYMBOL`, 1, 6) AS `SYMBOL`,   `DT`.`DRV_INSTRUMENT_NAME` AS `INSTRUMENT`,   `DT`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,   `DT`.`DRV_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `DT`.`DRV_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `DRV_ORDERS` `DT`  WHERE   ((`DT`.`DRV_TRD_STATUS` = 'C')   AND (`DT`.`DRV_MSG_CODE` = '2222'))  GROUP BY `DT`.`DRV_CLIENT_ID` , `DT`.`DRV_SCRIP_CODE` , `DT`.`DRV_EXCH_ID` , `DT`.`DRV_PRODUCT_ID` , `DT`.`DRV_SEGMENT` , `DT`.`DRV_CF_FLAG` UNION ALL SELECT  `T`.`EQ_CLIENT_ID` AS `EQ_CLIENT_ID`,   `T`.`EQ_SCRIP_CODE` AS `EQ_SCRIP_CODE`,   `T`.`EQ_EXCH_ID` AS `EQ_EXCH_ID`,   `T`.`EQ_SEGMENT` AS `SEGMENT_CODE`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN `T`.`EQ_LAST_TRADE_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN `T`.`EQ_LAST_TRADE_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)    ELSE 0   END)) AS `SELL_VAL`,   `T`.`EQ_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,   'E' AS `E`,   `T`.`EQ_PRODUCT_ID` AS `EQ_PRODUCT_ID`,   0 AS `INT_REF_ID`,   `T`.`EQ_SYMBOL` AS `SYMBOL`,   `T`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,   'NA' AS `EXPIRY`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `EQ_ORDERS` `T`  WHERE   ((`T`.`EQ_TRD_STATUS` = 'C')   AND (`T`.`EQ_MSG_CODE` = 2222))  GROUP BY `T`.`EQ_CLIENT_ID` , `T`.`EQ_SCRIP_CODE` , `T`.`EQ_EXCH_ID` , `T`.`EQ_PRODUCT_ID` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `BUY_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `BUY_VAL`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `SELL_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,   'NA' AS `EXPIRY`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,   'NA' AS `EXPIRY`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `BUY_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `BUY_VAL`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `SELL_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,   `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,   1 AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `MT`.`COMM_CLIENT_ID` AS `CLIENT_ID`,   `MT`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,   `MT`.`COMM_EXCH_ID` AS `EXCH_ID`,   `MT`.`COMM_SEGMENT` AS `SEGMENT_CODE`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN `MT`.`COMM_TRD_TRADE_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN `MT`.`COMM_TRD_TRADE_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)    ELSE 0   END)) AS `SELL_VAL`,   `MT`.`COMM_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,   `MT`.`COMM_SEGMENT` AS `EXCH_SEGMENT`,   `MT`.`COMM_PRODUCT_ID` AS `PRODUCT`,   `MT`.`COMM_CF_FLAG` AS `INT_REF_ID`,   SUBSTR(`MT`.`COMM_SYMBOL`, 1, 6) AS `SYMBOL`,   `MT`.`COMM_INSTRUMENT_NAME` AS `INSTRUMENT`,   `MT`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   `MT`.`COMM_MULTIPLIER` AS `COMM_MULTIPLIER`  FROM   `COMM_ORDERS` `MT`  WHERE   ((`MT`.`COMM_TRD_STATUS` = 'C')   AND (`MT`.`COMM_MSG_CODE` = '2222'))  GROUP BY `MT`.`COMM_CLIENT_ID` , `MT`.`COMM_SCRIP_CODE` , `MT`.`COMM_EXCH_ID` , `MT`.`COMM_PRODUCT_ID` , `MT`.`COMM_SEGMENT` , `MT`.`COMM_CF_FLAG` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `BUY_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `BUY_VAL`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END))) AS `SELL_QTY`,   (-(1) * SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END))) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   `CD`.`RCCD_COMM_MULTIPLIER` AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT  `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,   `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,   `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,   `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `BUY_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `BUY_VAL`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`    ELSE 0   END)) AS `SELL_QTY`,   SUM((CASE    WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)    ELSE 0   END)) AS `SELL_VAL`,   '0' AS `SL_TRIGGER_PRICE`,   `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,   `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,   0 AS `0`,   `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,   `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,   `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,   1 AS `RBI_REFERENCE_RATE`,   'N' AS `CROSS_CUR_FLAG`,   `CD`.`RCCD_COMM_MULTIPLIER` AS `COMM_MULTIPLIER`  FROM   `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`  GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT`) AS MBNP  GROUP BY `MBNP`.`CLIENT_ID` , `MBNP`.`SECURITY_ID` , `MBNP`.`EXCH_ID` , `MBNP`.`SEGMENT_CODE` , `MBNP`.`PRODUCT`) AS NP WHERE  1 = 1  %s  AND NOT (NP.GROSS_QTY = 0   AND NP.REALISED_PROFIT = 0);",sWhereQry);   



	printf("sNetPosQry = %s",sNetPosQry);

	if(mysql_query(DBQueries,sNetPosQry) != SUCCESS)
	{
		logSqlFatal("Error in sNetPosQry.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);	

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iNoOfRec :%d:",iNoOfRec);
	pNetPosHdrResp.IntRespHeader.iSeqNo = 0;
	pNetPosHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pNetPosHdrResp.IntRespHeader.iErrorId = 0;
	pNetPosHdrResp.IntRespHeader.iMsgCode = TC_INT_NET_POS_HDR_RESP;
	pNetPosHdrResp.IntRespHeader.iUserId = pNetPosReq->ReqHeader.iUserId;
	pNetPosHdrResp.IntRespHeader.cSource = pNetPosReq->ReqHeader.cSource ;
	pNetPosHdrResp.cMsgType = 'H';
	pNetPosHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pNetPosReq->ReqHeader.iUserId = %llu",pNetPosReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pNetPosReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pNetPosHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pNetPosResp,'\0',sizeof(struct VIEW_NET_POSITION_RESP));
		pNetPosResp.IntRespHeader.iSeqNo = 0;
		pNetPosResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_NET_POSITION_RESP);
		pNetPosResp.IntRespHeader.iErrorId = 0;
		pNetPosResp.IntRespHeader.iMsgCode = TC_INT_NET_POS_RESP;
		pNetPosResp.IntRespHeader.iUserId = pNetPosReq->ReqHeader.iUserId;
		pNetPosResp.IntRespHeader.cSource = pNetPosReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pNetPosResp.cMsgType = 'T';
		}
		else
		{
			pNetPosResp.cMsgType = 'D';
		}
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(pNetPosResp.subnetpos[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pNetPosResp.subnetpos[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				strncpy(pNetPosResp.subnetpos[j].sExchId,Row[2],EXCHANGE_LEN);
				strncpy(pNetPosResp.subnetpos[j].sMktType,Row[3],EXCHANGE_LEN);
				pNetPosResp.subnetpos[j].iBuyQty = atoi(Row[4]);
				pNetPosResp.subnetpos[j].iBuyQtyCF = atoi(Row[5]);
				pNetPosResp.subnetpos[j].iBuyQtyDay = atoi(Row[6]);
				pNetPosResp.subnetpos[j].fBuyVal = atof(Row[7]);
				pNetPosResp.subnetpos[j].fBuyValCF = atof(Row[8]);
				pNetPosResp.subnetpos[j].fBuyValDay = atof(Row[9]);
				pNetPosResp.subnetpos[j].fBuyAvg = atof(Row[10]);
				pNetPosResp.subnetpos[j].iSellQty = atoi(Row[11]);
				pNetPosResp.subnetpos[j].iSellQtyCF = atoi(Row[12]);
				pNetPosResp.subnetpos[j].iSellQtyDay = atoi(Row[13]);
				pNetPosResp.subnetpos[j].fSellVal = atof(Row[14]);
				pNetPosResp.subnetpos[j].fSellValCF = atof(Row[15]);
				pNetPosResp.subnetpos[j].fSellValDay = atof(Row[16]);
				pNetPosResp.subnetpos[j].fSellAvg = atof(Row[17]);
				pNetPosResp.subnetpos[j].iNetQty = atoi(Row[18]);
				pNetPosResp.subnetpos[j].fNetVal = atof(Row[19]);
				pNetPosResp.subnetpos[j].fNetAvg = atof(Row[20]);
				pNetPosResp.subnetpos[j].fGrossQty = atof(Row[21]);
				pNetPosResp.subnetpos[j].fGrossVal = atof(Row[22]);
				pNetPosResp.subnetpos[j].cSegment = Row[23][0];
				pNetPosResp.subnetpos[j].cProductId = Row[24][0];
				pNetPosResp.subnetpos[j].fRelaisedProfit = atof(Row[25]);
				pNetPosResp.subnetpos[j].iRef_ID = atoi(Row[26]);
				pNetPosResp.subnetpos[j].cCross_Cur_Flag = Row[27][0];
				pNetPosResp.subnetpos[j].fRBI_REF_RATE = atof(Row[28]);

				logDebug2("pNetPosResp.cMsgType :%c:",pNetPosResp.cMsgType);
				logDebug3(" pNetPosResp.cMsgType :%c: iTempNoOfRec:%d:",pNetPosResp.cMsgType,iTempNoOfRec);
				logDebug3("pNetPosResp.subnetpos[%d].sClientId:%s:",j,pNetPosResp.subnetpos[j].sClientId);
				logDebug3(" pNetPosResp.subnetpos[%d].sSecurityID :%s:",j,pNetPosResp.subnetpos[j].sSecurityID);
				logDebug3("pNetPosResp.subnetpos[%d].sExchId:%s:",j,pNetPosResp.subnetpos[j].sExchId);
				logDebug3("pNetPosResp.subnetpos[%d].cMktType:%s:",j,pNetPosResp.subnetpos[j].sMktType);
				logDebug3("pNetPosResp.subnetpos[%d].iBuyQty:%d:",j,pNetPosResp.subnetpos[j].iBuyQty);
				logDebug3("pNetPosResp.subnetpos[%d].iBuyQtyCF:%d:",j,pNetPosResp.subnetpos[j].iBuyQtyCF);
				logDebug3("pNetPosResp.subnetpos[%d].iBuyQtyDay:%d:",j,pNetPosResp.subnetpos[j].iBuyQtyDay);
				logDebug3("pNetPosResp.subnetpos[%d].fBuyVal:%lf:",j,pNetPosResp.subnetpos[j].fBuyVal);
				logDebug3("pNetPosResp.subnetpos[%d].fBuyValCF:%lf:",j,pNetPosResp.subnetpos[j].fBuyValCF);
				logDebug3("pNetPosResp.subnetpos[%d].fBuyValDay:%lf:",j,pNetPosResp.subnetpos[j].fBuyValDay);
				logDebug3("pNetPosResp.subnetpos[%d].fBuyAvg :%lf:",j,pNetPosResp.subnetpos[j].fBuyAvg);
				logDebug3("pNetPosResp.subnetpos[%d].iSellQty:%d:",j,pNetPosResp.subnetpos[j].iSellQty);
				logDebug3("pNetPosResp.subnetpos[%d].iSellQtyCF:%d:",j,pNetPosResp.subnetpos[j].iSellQtyCF);
				logDebug3("pNetPosResp.subnetpos[%d].iSellQtyDay:%d:",j,pNetPosResp.subnetpos[j].iSellQtyDay);
				logDebug3("pNetPosResp.subnetpos[%d].fSellVal:%lf:",j,pNetPosResp.subnetpos[j].fSellVal);
				logDebug3("pNetPosResp.subnetpos[%d].fSellValCF:%lf:",j,pNetPosResp.subnetpos[j].fSellValCF);
				logDebug3("pNetPosResp.subnetpos[%d].fSellValDay:%lf:",j,pNetPosResp.subnetpos[j].fSellValDay);
				logDebug3("pNetPosResp.subnetpos[%d].fSellAvg:%lf:",j,pNetPosResp.subnetpos[j].fSellAvg);
				logDebug3("pNetPosResp.subnetpos[%d].iNetQty:%d:",j,pNetPosResp.subnetpos[j].iNetQty);
				logDebug3("pNetPosResp.subnetpos[%d].fNetVal:%lf:",j,pNetPosResp.subnetpos[j].fNetVal);
				logDebug3("pNetPosResp.subnetpos[%d].fNetAvg:%lf:",j,pNetPosResp.subnetpos[j].fNetAvg);
				logDebug3("pNetPosResp.subnetpos[%d].fGrossQty:%lf:",j,pNetPosResp.subnetpos[j].fGrossQty);
				logDebug3("pNetPosResp.subnetpos[%d].fGrossVal:%lf:",j,pNetPosResp.subnetpos[j].fGrossVal);
				logDebug3("pNetPosResp.subnetpos[%d].cSegment:%c:",j,pNetPosResp.subnetpos[j].cSegment);
				logDebug3("pNetPosResp.subnetpos[%d].cProductId:%c:",j,pNetPosResp.subnetpos[j].cProductId);
				logDebug3("pNetPosResp.subnetpos[%d].fRelaisedProfit:%lf:",j,pNetPosResp.subnetpos[j].fRelaisedProfit);
				logDebug3("pNetPosResp.subnetpos[%d].iRef_ID:%d:",j,pNetPosResp.subnetpos[j].iRef_ID);
				logDebug3("pNetPosResp.subnetpos[%d].cCross_Cur_Flag :%c:",j,pNetPosResp.subnetpos[j].cCross_Cur_Flag);
				logDebug3("pNetPosResp.subnetpos[%d].fRBI_REF_RATE :%f:",j,pNetPosResp.subnetpos[j].fRBI_REF_RATE);

			}


		}
		if(iRelayID != FIND_USER_RELAY_ERROR)
		{

			if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pNetPosResp,sizeof(struct VIEW_NET_POSITION_RESP) ,iRelayID) != TRUE ))
			{
				perror("Error WriteMsgQ: ");
				logFatal("Write Q id %d", iIntActiveToRelDirQ);
				return FALSE;
			}
		}
		iTempNoOfRec--;
		usleep(5000);
	}
	free(sNetPosQry);
	free(sWhereQry);
	logTimestamp("Exit : fDeaNetPosition");
}

BOOL 	fNetPosition(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fNetPosition]");
	struct VIEW_COMMON_QUERY_REQ *pViewNetPosReq;
	struct VIEW_NET_POSITION_RESP pViewNetPosResp;
	struct VIEW_COMMON_HDR_RESP pViewNetPosHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR *sNetPstion = malloc (sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	CHAR		sClientId[CLIENT_ID_LEN];
	CHAR		sEntityId[ENTITY_ID_LEN];
	CHAR		sRespClientId[CLIENT_ID_LEN];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchId[EXCHANGE_LEN];
	DOUBLE64        fBuyQty;
	DOUBLE64        fBuyVal;
	DOUBLE64        fSellQty;
	DOUBLE64        fSellVal;
	DOUBLE64        fBuyAvg;
	DOUBLE64        fSellAvg;
	DOUBLE64        fNetQty;
	DOUBLE64        fNetVal;
	DOUBLE64        fNetAvg;
	DOUBLE64        fGrossQty;
	DOUBLE64        fGrossVal;
	CHAR         cMktType[MARKET_LEN];
	CHAR            cProductId;
	DOUBLE64        fLTP;
	DOUBLE64        fRelaisedProfit;
	DOUBLE64        fMTM;
	LONG32		iNoOfRec=0;
	DOUBLE64	fNoOfRec;
	LONG32		iTempNoOfRec;
	LONG32		iNoOfPkt;
	CHAR            cSegment;

	memset(sClientId,'\0',CLIENT_ID_LEN);
	memset(sSecurityID,'\0',SECURITY_ID_LEN);
	memset(sExchId ,'\0',EXCHANGE_LEN);
	memset(cMktType ,'\0',MARKET_LEN);

	pViewNetPosReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;
	strncpy(sClientId ,pViewNetPosReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewNetPosReq->sEntityId,CLIENT_ID_LEN);

	logDebug2(" sClientId  :%s: , pViewNetPosReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewNetPosReq->sClientId,strlen(sClientId));
	logDebug2(" sEntityId  :%s: , pViewNetPosReq->sEntityId :%s: , sEntityId.len:%d:",sEntityId ,pViewNetPosReq->sEntityId,strlen(sEntityId));





	sprintf(sNetPstion,"SELECT        `MBNP`.`CLIENT_ID` AS `CLIENT_ID`,       `MBNP`.`SECURITY_ID` AS `SECURITY_ID`,       `MBNP`.`EXCH_ID` AS `EXC    H_ID`,       'NL' AS `MKT_TYPE`,       `MBNP`.`SYMBOL` AS `SYMBOL`,       `MBNP`.`INSTRUMENT` AS `INSTRUMENT`,       `MBNP`.`EXPIRY_DATE` AS `EXPIRY_DATE`,       SUM(`MBNP`.`BUY_QTY`) AS `TOT_BUY_QTY`,       SUM(CASE `MBNP`.`INT_REF_ID`           WHEN - 1 THEN `MBNP`.`BUY_QTY`           ELSE 0       END) AS `TOT_BUY_QTY_CF`,       SUM(CASE `MBNP`.`INT_REF_ID`           WHEN 0 THEN `MBNP`.`BUY_QTY`           ELSE 0       END) AS `TOT_BUY_QTY_DAY`,       SUM(CASE           WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000           WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER           ELSE MBNP.BUY_VAL       END) AS TOT_BUY_VAL,       SUM(CASE MBNP.INT_REF_ID           WHEN               - 1           THEN               (CASE                   WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000                   WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER                   ELSE MBNP.BUY_VAL               END)           ELSE 0       END) AS `TOT_BUY_VAL_CF`,       SUM(CASE `MBNP`.`INT_REF_ID`           WHEN               0           THEN               (CASE                   WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.BUY_VAL) * 1000                   WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.BUY_VAL) * MBNP.COMM_MULTIPLIER                   ELSE MBNP.BUY_VAL               END)           ELSE 0       END) AS `TOT_BUY_VAL_DAY`,       (CASE           WHEN               (`MBNP`.`SEGMENT_CODE` = 'C')           THEN               ROUND((CASE SUM(`MBNP`.`BUY_QTY`)                           WHEN 0 THEN 0                           ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))                       END),                       4)           ELSE ROUND((CASE SUM(`MBNP`.`BUY_QTY`)                       WHEN 0 THEN 0                       ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))                   END),                   2)       END) AS `BUY_AVG`,       SUM(`MBNP`.`SELL_QTY`) AS `TOT_SELL_QTY`,       SUM(CASE `MBNP`.`INT_REF_ID`           WHEN - 1 THEN `MBNP`.`SELL_QTY`           ELSE 0       END) AS `TOT_SELL_QTY_CF`,       SUM(CASE `MBNP`.`INT_REF_ID`           WHEN 0 THEN `MBNP`.`SELL_QTY`           ELSE 0       END) AS `TOT_SELL_QTY_DAY`,       SUM(CASE           WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000           WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER           ELSE (MBNP.SELL_VAL)       END) AS TOT_SELL_VAL,       SUM(CASE MBNP.INT_REF_ID           WHEN               - 1           THEN               (CASE                   WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000                   WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER                   ELSE MBNP.SELL_VAL               END)           ELSE 0       END) AS `TOT_SELL_VAL_CF`,       SUM(CASE `MBNP`.`INT_REF_ID`           WHEN               0           THEN               (CASE                   WHEN (MBNP.SEGMENT_CODE = 'C') THEN (MBNP.SELL_VAL) * 1000                   WHEN (MBNP.SEGMENT_CODE = 'M') THEN (MBNP.SELL_VAL) * MBNP.COMM_MULTIPLIER                   ELSE (MBNP.SELL_VAL)               END)           ELSE 0       END) AS `TOT_SELL_VAL_DAY`,       (CASE           WHEN               (`MBNP`.`SEGMENT_CODE` = 'C')           THEN               ROUND((CASE SUM(`MBNP`.`SELL_QTY`)                           WHEN 0 THEN 0                           ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))                       END),                       4)           ELSE ROUND((CASE SUM(`MBNP`.`SELL_QTY`)                       WHEN 0 THEN 0                       ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))                   END),                   2)       END) AS SELL_AVG,       (SUM(MBNP.BUY_QTY) - SUM(MBNP.SELL_QTY)) AS NET_QTY,       (CASE           WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * 1000)           WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL)) * MBNP.COMM_MULTIPLIER)           ELSE (SUM(MBNP.SELL_VAL) - SUM(MBNP.BUY_VAL))       END) AS NET_VAL,       (CASE           WHEN               (`MBNP`.`SEGMENT_CODE` = 'C')           THEN               ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))                           WHEN 0 THEN 0                           ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))                       END),                       4)           ELSE ROUND((CASE (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`))                       WHEN 0 THEN 0                       ELSE ((SUM(`MBNP`.`BUY_VAL`) - SUM(`MBNP`.`SELL_VAL`)) / (SUM(`MBNP`.`BUY_QTY`) - SUM(`MBNP`.`SELL_QTY`)))                   END),                   2)       END) AS `NET_AVG`,       (SUM(`MBNP`.`BUY_QTY`) + SUM(`MBNP`.`SELL_QTY`)) AS `GROSS_QTY`,       (CASE           WHEN (MBNP.SEGMENT_CODE = 'C') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * 1000)           WHEN (MBNP.SEGMENT_CODE = 'M') THEN ((SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL)) * MBNP.COMM_MULTIPLIER)           ELSE (SUM(MBNP.BUY_VAL) + SUM(MBNP.SELL_VAL))       END) AS GROSS_VAL,       MBNP.SEGMENT_CODE AS SEGMNT,       MBNP.PRODUCT AS PROD_ID,       (CASE           WHEN               (MBNP.SEGMENT_CODE = 'C')           THEN(CASE WHEN `MBNP`.`CROSS_CUR_FLAG`='Y'                                                              THEN (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)                           WHEN 0 THEN 0                           ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))                       END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)                           WHEN 0 THEN 0                           ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))                       END), 4))), 4) * 1000 * `MBNP`.`RBI_REFERENCE_RATE`)                       ELSE                        (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`), SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)                           WHEN 0 THEN 0                           ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))                       END), 4) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)                           WHEN 0 THEN 0                           ELSE (SUM(MBNP.BUY_VAL) / SUM(MBNP.BUY_QTY))                       END), 4))), 4) * 1000  ) END)           WHEN               (`MBNP`.`SEGMENT_CODE` = 'M')           THEN               (ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`),                               SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)                                   WHEN 0 THEN 0                                   ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))                               END),                               2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)                                   WHEN 0 THEN 0                                   ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))                               END),                               2))),                       2) * MBNP.COMM_MULTIPLIER)           ELSE ROUND((LEAST(SUM(`MBNP`.`BUY_QTY`),                           SUM(`MBNP`.`SELL_QTY`)) * (ROUND((CASE SUM(`MBNP`.`SELL_QTY`)                               WHEN 0 THEN 0                               ELSE (SUM(`MBNP`.`SELL_VAL`) / SUM(`MBNP`.`SELL_QTY`))                           END),                           2) - ROUND((CASE SUM(`MBNP`.`BUY_QTY`)                               WHEN 0 THEN 0                               ELSE (SUM(`MBNP`.`BUY_VAL`) / SUM(`MBNP`.`BUY_QTY`))                           END),                           2))),                   2)       END) AS `REALISED_PROFIT`,       `MBNP`.`INT_REF_ID` AS `REF_ID`,       `MBNP`.`CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,       `MBNP`.`RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`   FROM       (SELECT            `DT`.`DRV_CLIENT_ID` AS `CLIENT_ID`,               `DT`.`DRV_SCRIP_CODE` AS `SECURITY_ID`,               `DT`.`DRV_EXCH_ID` AS `EXCH_ID`,               `DT`.`DRV_SEGMENT` AS `SEGMENT_CODE`,               SUM((CASE                   WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN `DT`.`DRV_TRD_TRADE_QTY`                   ELSE 0               END)) AS `BUY_QTY`,               SUM((CASE                   WHEN (`DT`.`DRV_BUY_SELL_IND` = 'B') THEN (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)                   ELSE 0               END)) AS `BUY_VAL`,               SUM((CASE                   WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN `DT`.`DRV_TRD_TRADE_QTY`                   ELSE 0               END)) AS `SELL_QTY`,               SUM((CASE                   WHEN (`DT`.`DRV_BUY_SELL_IND` = 'S') THEN (`DT`.`DRV_TRD_TRADE_PRICE` * `DT`.`DRV_TRD_TRADE_QTY`)                   ELSE 0               END)) AS `SELL_VAL`,               `DT`.`DRV_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,               `DT`.`DRV_SEGMENT` AS `EXCH_SEGMENT`,               `DT`.`DRV_PRODUCT_ID` AS `PRODUCT`,               `DT`.`DRV_CF_FLAG` AS `INT_REF_ID`,               SUBSTR(`DT`.`DRV_SYMBOL`, 1, 6) AS `SYMBOL`,               `DT`.`DRV_INSTRUMENT_NAME` AS `INSTRUMENT`,               `DT`.`DRV_EXPIRY_DATE` AS `EXPIRY_DATE`,               `DT`.`DRV_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,               `DT`.`DRV_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `DRV_ORDERS` `DT`       WHERE           ((`DT`.`DRV_TRD_STATUS` = 'C')               AND (`DT`.`DRV_MSG_CODE` = '2222'))       GROUP BY `DT`.`DRV_CLIENT_ID` , `DT`.`DRV_SCRIP_CODE` , `DT`.`DRV_EXCH_ID` , `DT`.`DRV_PRODUCT_ID` , `DT`.`DRV_SEGMENT` , `DT`.`DRV_CF_FLAG` UNION ALL SELECT            `T`.`EQ_CLIENT_ID` AS `EQ_CLIENT_ID`,               `T`.`EQ_SCRIP_CODE` AS `EQ_SCRIP_CODE`,               `T`.`EQ_EXCH_ID` AS `EQ_EXCH_ID`,               `T`.`EQ_SEGMENT` AS `SEGMENT_CODE`,               SUM((CASE                   WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN `T`.`EQ_LAST_TRADE_QTY`                   ELSE 0               END)) AS `BUY_QTY`,               SUM((CASE                   WHEN (`T`.`EQ_BUY_SELL_IND` = 'B') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)                   ELSE 0               END)) AS `BUY_VAL`,               SUM((CASE                   WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN `T`.`EQ_LAST_TRADE_QTY`                   ELSE 0               END)) AS `SELL_QTY`,               SUM((CASE                   WHEN (`T`.`EQ_BUY_SELL_IND` = 'S') THEN (`T`.`EQ_TRD_TRADE_PRICE` * `T`.`EQ_LAST_TRADE_QTY`)                   ELSE 0               END)) AS `SELL_VAL`,               `T`.`EQ_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,               'E' AS `E`,               `T`.`EQ_PRODUCT_ID` AS `EQ_PRODUCT_ID`,               0 AS `INT_REF_ID`,               `T`.`EQ_SYMBOL` AS `SYMBOL`,               `T`.`EQ_INSTRUMENT_NAME` AS `INSTRUMENT`,               'NA' AS `EXPIRY`,               1 AS `RBI_REFERENCE_RATE`,               'N' AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `EQ_ORDERS` `T`       WHERE           ((`T`.`EQ_TRD_STATUS` = 'C')               AND (`T`.`EQ_MSG_CODE` = 2222))       GROUP BY `T`.`EQ_CLIENT_ID` , `T`.`EQ_SCRIP_CODE` , `T`.`EQ_EXCH_ID` , `T`.`EQ_PRODUCT_ID` UNION ALL SELECT            `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,               `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,               `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,               `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`                   ELSE 0               END))) AS `BUY_QTY`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END))) AS `BUY_VAL`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`                   ELSE 0               END))) AS `SELL_QTY`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END))) AS `SELL_VAL`,               '0' AS `SL_TRIGGER_PRICE`,               `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,               `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,               0 AS `0`,               `CD`.`RCCD_SYMBOL` AS `SYMBOL`,               `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,               'NA' AS `EXPIRY`,               `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,               `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `RMS_CLIENT_CONVT_TO_DEL` `CD`       GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT            `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,               `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,               `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,               `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`                   ELSE 0               END)) AS `BUY_QTY`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END)) AS `BUY_VAL`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`                   ELSE 0               END)) AS `SELL_QTY`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END)) AS `SELL_VAL`,               '0' AS `SL_TRIGGER_PRICE`,               `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,               `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,               0 AS `0`,               `CD`.`RCCD_SYMBOL` AS `SYMBOL`,               `CD`.`RCCD_INSTRUMENT` AS `INSTRUMENT`,               'NA' AS `EXPIRY`,               `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,               `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `RMS_CLIENT_CONVT_TO_DEL` `CD`       GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT            `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,               `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,               `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,               `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`                   ELSE 0               END))) AS `BUY_QTY`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END))) AS `BUY_VAL`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`                   ELSE 0               END))) AS `SELL_QTY`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END))) AS `SELL_VAL`,               '0' AS `SL_TRIGGER_PRICE`,               `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,               `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,               0 AS `0`,               `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,               `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,               `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,               `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,               `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`       GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_SOURCE` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT            `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,               `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,               `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,               `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`                   ELSE 0               END)) AS `BUY_QTY`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END)) AS `BUY_VAL`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`                   ELSE 0               END)) AS `SELL_QTY`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END)) AS `SELL_VAL`,               '0' AS `SL_TRIGGER_PRICE`,               `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,               `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,               0 AS `0`,               `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,               `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,               `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,               `CD`.`RCCD_RBI_REFERENCE_RATE` AS `RBI_REFERENCE_RATE`,               `CD`.`RCCD_CROSS_CUR_FLAG` AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `RMS_CLIENT_CONVT_TO_DEL_DR` `CD`       GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT            `MT`.`COMM_CLIENT_ID` AS `CLIENT_ID`,               `MT`.`COMM_SCRIP_CODE` AS `SECURITY_ID`,               `MT`.`COMM_EXCH_ID` AS `EXCH_ID`,               `MT`.`COMM_SEGMENT` AS `SEGMENT_CODE`,               SUM((CASE                   WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN `MT`.`COMM_TRD_TRADE_QTY`                   ELSE 0               END)) AS `BUY_QTY`,               SUM((CASE                   WHEN (`MT`.`COMM_BUY_SELL_IND` = 'B') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)                   ELSE 0               END)) AS `BUY_VAL`,               SUM((CASE                   WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN `MT`.`COMM_TRD_TRADE_QTY`                   ELSE 0               END)) AS `SELL_QTY`,               SUM((CASE                   WHEN (`MT`.`COMM_BUY_SELL_IND` = 'S') THEN (`MT`.`COMM_TRD_TRADE_PRICE` * `MT`.`COMM_TRD_TRADE_QTY`)                   ELSE 0               END)) AS `SELL_VAL`,               `MT`.`COMM_TRIGGER_PRICE` AS `SL_TRIGGER_PRICE`,               `MT`.`COMM_SEGMENT` AS `EXCH_SEGMENT`,               `MT`.`COMM_PRODUCT_ID` AS `PRODUCT`,               `MT`.`COMM_CF_FLAG` AS `INT_REF_ID`,               SUBSTR(`MT`.`COMM_SYMBOL`, 1, 6) AS `SYMBOL`,               `MT`.`COMM_INSTRUMENT_NAME` AS `INSTRUMENT`,               `MT`.`COMM_EXPIRY_DATE` AS `EXPIRY_DATE`,               1 AS `RBI_REFERENCE_RATE`,               'N' AS `CROSS_CUR_FLAG`,               `MT`.`COMM_MULTIPLIER` AS `COMM_MULTIPLIER`       FROM           `COMM_ORDERS` `MT`       WHERE           ((`MT`.`COMM_TRD_STATUS` = 'C')               AND (`MT`.`COMM_MSG_CODE` = '2222'))       GROUP BY `MT`.`COMM_CLIENT_ID` , `MT`.`COMM_SCRIP_CODE` , `MT`.`COMM_EXCH_ID` , `MT`.`COMM_PRODUCT_ID` , `MT`.`COMM_SEGMENT` , `MT`.`COMM_CF_FLAG` UNION ALL SELECT            `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,               `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,               `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,               `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`                   ELSE 0               END))) AS `BUY_QTY`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END))) AS `BUY_VAL`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`                   ELSE 0               END))) AS `SELL_QTY`,               (-(1) * SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END))) AS `SELL_VAL`,               '0' AS `SL_TRIGGER_PRICE`,               `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,               `CD`.`RCCD_PRODUCT_SOURCE` AS `RCCD_PRODUCT_SOURCE`,               0 AS `0`,               `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,               `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,               `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,               1 AS `RBI_REFERENCE_RATE`,               'N' AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`       GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT` UNION ALL SELECT            `CD`.`RCCD_CLIENT_ID` AS `RCCD_CLIENT_ID`,               `CD`.`RCCD_SCRIP_CODE` AS `RCCD_SCRIP_CODE`,               `CD`.`RCCD_EXCHANGE` AS `RCCD_EXCHANGE`,               `CD`.`RCCD_SEGMENT` AS ` SEGMENT_CODE`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN `CD`.`RCCD_QTY`                   ELSE 0               END)) AS `BUY_QTY`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'B') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END)) AS `BUY_VAL`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN `CD`.`RCCD_QTY`                   ELSE 0               END)) AS `SELL_QTY`,               SUM((CASE                   WHEN (`CD`.`RCCD_SIDE` = 'S') THEN (`CD`.`RCCD_QTY` * `CD`.`RCCD_CONVT_PRICE`)                   ELSE 0               END)) AS `SELL_VAL`,               '0' AS `SL_TRIGGER_PRICE`,               `CD`.`RCCD_SEGMENT` AS `RCCD_SEGMENT`,               `CD`.`RCCD_PRODUCT_DESTINATION` AS `RCCD_PRODUCT_DESTINATION`,               0 AS `0`,               `CD`.`RCCD_SYMBOL` AS `RCCD_SYMBOL`,               `CD`.`RCCD_INSTRUMENT` AS `RCCD_INSTRUMENT`,               `CD`.`RCCD_EXPIRY_DATE` AS `RCCD_EXPIRY_DATE`,               1 AS `RBI_REFERENCE_RATE`,               'N' AS `CROSS_CUR_FLAG`,               1 AS `COMM_MULTIPLIER`       FROM           `RMS_CLIENT_CONVT_TO_DEL_COM` `CD`       GROUP BY `CD`.`RCCD_CLIENT_ID` , `CD`.`RCCD_SCRIP_CODE` , `CD`.`RCCD_EXCHANGE` , `CD`.`RCCD_PRODUCT_DESTINATION` , `CD`.`RCCD_SEGMENT`) AS MBNP   WHERE       `MBNP`.`CLIENT_ID` = \'%s\'   GROUP BY `MBNP`.`CLIENT_ID` , `MBNP`.`SECURITY_ID` , `MBNP`.`EXCH_ID` , `MBNP`.`SEGMENT_CODE` , `MBNP`.`PRODUCT`",sClientId);

	printf(" fNetPosition :%s: ",sNetPstion);


	if(mysql_query(DBQueries,sNetPstion) != SUCCESS)
	{
		logSqlFatal("ERROR in VIEW net Position Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/

	pViewNetPosHdrResp.IntRespHeader.iSeqNo = 0;
	pViewNetPosHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pViewNetPosHdrResp.IntRespHeader.iErrorId = 0;
	pViewNetPosHdrResp.IntRespHeader.iMsgCode = TC_INT_NET_POS_HDR_RESP;
	pViewNetPosHdrResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
	pViewNetPosHdrResp.IntRespHeader.cSource = pViewNetPosReq->ReqHeader.cSource ;
	//                pViewNetPosHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewNetPosReq->ReqHeader.cUserType;


	pViewNetPosHdrResp.cMsgType = 'H';
	pViewNetPosHdrResp.iNoofRec = iNoOfRec;
	/*	pViewNetPosHdrResp.iNoofPkt = iNoOfPkt;*/

	logDebug2(" pViewNetPosHdrResp.cMsgType:%c:,pViewNetPosHdrResp.iNoofRec:%d:",pViewNetPosHdrResp.cMsgType,pViewNetPosHdrResp.iNoofRec);

	logDebug2("pViewNetPosReq->ReqHeader.iUserId = %llu",pViewNetPosReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewNetPosReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewNetPosHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	logDebug2(" iNoOfPkt :%d:",iNoOfPkt);

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pViewNetPosResp,'\0',sizeof(struct VIEW_NET_POSITION_RESP));
		pViewNetPosResp.IntRespHeader.iSeqNo = 0;
		pViewNetPosResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_NET_POSITION_RESP);
		pViewNetPosResp.IntRespHeader.iErrorId = 0;
		pViewNetPosResp.IntRespHeader.iMsgCode = TC_INT_NET_POS_RESP;
		pViewNetPosResp.IntRespHeader.iUserId = pViewNetPosReq->ReqHeader.iUserId;
		pViewNetPosResp.IntRespHeader.cSource = pViewNetPosReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pViewNetPosResp.cMsgType = 'T';
		}
		else
		{
			pViewNetPosResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{

				strncpy(pViewNetPosResp.subnetpos[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pViewNetPosResp.subnetpos[j].sSecurityID,Row[1],SECURITY_ID_LEN);
				strncpy(pViewNetPosResp.subnetpos[j].sExchId,Row[2],EXCHANGE_LEN);
				strncpy(pViewNetPosResp.subnetpos[j].sMktType,Row[3],MARKET_LEN);
				pViewNetPosResp.subnetpos[j].iBuyQty = atoi(Row[7]);
				pViewNetPosResp.subnetpos[j].iBuyQtyCF = atoi(Row[8]);
				pViewNetPosResp.subnetpos[j].iBuyQtyDay = atoi(Row[9]);
				pViewNetPosResp.subnetpos[j].fBuyVal = atof(Row[10]);
				pViewNetPosResp.subnetpos[j].fBuyValCF = atof(Row[11]);
				pViewNetPosResp.subnetpos[j].fBuyValDay = atof(Row[12]);
				pViewNetPosResp.subnetpos[j].fBuyAvg = atof(Row[13]);
				pViewNetPosResp.subnetpos[j].iSellQty = atoi(Row[14]);
				pViewNetPosResp.subnetpos[j].iSellQtyCF = atoi(Row[15]);
				pViewNetPosResp.subnetpos[j].iSellQtyDay = atoi(Row[16]);
				pViewNetPosResp.subnetpos[j].fSellVal = atof(Row[17]);
				pViewNetPosResp.subnetpos[j].fSellValCF = atof(Row[18]);
				pViewNetPosResp.subnetpos[j].fSellValDay = atof(Row[19]);
				pViewNetPosResp.subnetpos[j].fSellAvg = atof(Row[20]);
				pViewNetPosResp.subnetpos[j].iNetQty = atoi(Row[21]);
				pViewNetPosResp.subnetpos[j].fNetVal = atof(Row[22]);
				pViewNetPosResp.subnetpos[j].fNetAvg = atof(Row[23]);
				pViewNetPosResp.subnetpos[j].fGrossQty = atof(Row[24]);
				pViewNetPosResp.subnetpos[j].fGrossVal = atof(Row[25]);
				pViewNetPosResp.subnetpos[j].cSegment = Row[26][0];
				pViewNetPosResp.subnetpos[j].cProductId = Row[27][0];
				pViewNetPosResp.subnetpos[j].fRelaisedProfit = atof(Row[28]);
				pViewNetPosResp.subnetpos[j].iRef_ID = atoi(Row[29]);
				pViewNetPosResp.subnetpos[j].cCross_Cur_Flag = Row[30][0];
				pViewNetPosResp.subnetpos[j].fRBI_REF_RATE = atof(Row[31]);

				logDebug3(" pViewNetPosResp.cMsgType :%c: iTempNoOfRec:%d:",pViewNetPosResp.cMsgType,iTempNoOfRec);
				logDebug3(" pViewNetPosResp.IntRespHeader.iMsgCode :%d: iTempNoOfRec:%d:",pViewNetPosResp.IntRespHeader.iMsgCode,iTempNoOfRec);
				logDebug3("pViewNetPosResp.subnetpos[%d].sClientId:%s:",j,pViewNetPosResp.subnetpos[j].sClientId);
				logDebug3(" pViewNetPosResp.subnetpos[%d].sSecurityID :%s:",j,pViewNetPosResp.subnetpos[j].sSecurityID);
				logDebug3("pViewNetPosResp.subnetpos[%d].sExchId:%s:",j,pViewNetPosResp.subnetpos[j].sExchId);
				logDebug3("pViewNetPosResp.subnetpos[%d].cMktType:%s:",j,pViewNetPosResp.subnetpos[j].sMktType);
				logDebug3("pViewNetPosResp.subnetpos[%d].iBuyQty:%d:",j,pViewNetPosResp.subnetpos[j].iBuyQty);
				logDebug3("pViewNetPosResp.subnetpos[%d].iBuyQtyCF:%d:",j,pViewNetPosResp.subnetpos[j].iBuyQtyCF);
				logDebug3("pViewNetPosResp.subnetpos[%d].iBuyQtyDay:%d:",j,pViewNetPosResp.subnetpos[j].iBuyQtyDay);
				logDebug3(" pViewNetPosResp.subnetpos[%d].fBuyVal:%lf:",j,pViewNetPosResp.subnetpos[j].fBuyVal);
				logDebug3(" pViewNetPosResp.subnetpos[%d].fBuyValCF:%lf:",j,pViewNetPosResp.subnetpos[j].fBuyValCF);
				logDebug3(" pViewNetPosResp.subnetpos[%d].fBuyValDay:%lf:",j,pViewNetPosResp.subnetpos[j].fBuyValDay);
				logDebug3(" pViewNetPosResp.subnetpos[%d].fBuyAvg :%lf:",j,pViewNetPosResp.subnetpos[j].fBuyAvg);
				logDebug3("pViewNetPosResp.subnetpos[%d].iSellQty:%d:",j,pViewNetPosResp.subnetpos[j].iSellQty);
				logDebug3("pViewNetPosResp.subnetpos[%d].iSellQtyCF:%d:",j,pViewNetPosResp.subnetpos[j].iSellQtyCF);
				logDebug3("pViewNetPosResp.subnetpos[%d].iSellQtyDay:%d:",j,pViewNetPosResp.subnetpos[j].iSellQtyDay);
				logDebug3("pViewNetPosResp.subnetpos[%d].fSellVal:%lf:",j,pViewNetPosResp.subnetpos[j].fSellVal);
				logDebug3("pViewNetPosResp.subnetpos[%d].fSellValCF:%lf:",j,pViewNetPosResp.subnetpos[j].fSellValCF);
				logDebug3("pViewNetPosResp.subnetpos[%d].fSellValDay:%lf:",j,pViewNetPosResp.subnetpos[j].fSellValDay);
				logDebug3(" pViewNetPosResp.subnetpos[%d].fSellAvg:%lf:",j,pViewNetPosResp.subnetpos[j].fSellAvg);
				logDebug3("pViewNetPosResp.subnetpos[%d].iNetQty:%d:",j,pViewNetPosResp.subnetpos[j].iNetQty);
				logDebug3("pViewNetPosResp.subnetpos[%d].fNetVal:%lf:",j,pViewNetPosResp.subnetpos[j].fNetVal);
				logDebug3("pViewNetPosResp.subnetpos[%d].fNetAvg:%lf:",j,pViewNetPosResp.subnetpos[j].fNetAvg);
				logDebug3("pViewNetPosResp.subnetpos[%d].fGrossQty:%lf:",j,pViewNetPosResp.subnetpos[j].fGrossQty);
				logDebug3("pViewNetPosResp.subnetpos[%d].fGrossVal:%lf:",j,pViewNetPosResp.subnetpos[j].fGrossVal);
				logDebug3("pViewNetPosResp.subnetpos[%d].cSegment:%c:",j,pViewNetPosResp.subnetpos[j].cSegment);
				logDebug3("pViewNetPosResp.subnetpos[%d].cProductId:%c:",j,pViewNetPosResp.subnetpos[j].cProductId);
				logDebug3("pViewNetPosResp.subnetpos[%d].fRelaisedProfit:%lf:",j,pViewNetPosResp.subnetpos[j].fRelaisedProfit);
				logDebug3("pViewNetPosResp.subnetpos[%d].iRef_ID:%d:",j,pViewNetPosResp.subnetpos[j].iRef_ID);
				logDebug3("pViewNetPosResp.subnetpos[%d].cCross_Cur_Flag :%c:",j,pViewNetPosResp.subnetpos[j].cCross_Cur_Flag);
				logDebug3("pViewNetPosResp.subnetpos[%d].fRBI_REF_RATE :%f:",j,pViewNetPosResp.subnetpos[j].fRBI_REF_RATE);

			}


		}
		if(iRelayID != FIND_USER_RELAY_ERROR)
		{
			if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewNetPosResp,sizeof(struct VIEW_NET_POSITION_RESP) ,iRelayID) != TRUE ))
			{
				perror("Error WriteMsgQ: ");
				logFatal("Write Q id %d", iIntActiveToRelDirQ);
				return FALSE;
			}
		}
		iTempNoOfRec--;
		usleep(5000);


	}	
	free(sNetPstion);	
	logTimestamp(" EXIT [fNetPosition]");

	return TRUE;

}/********* END of fNetPosition*****/

BOOL 	fOrderBook(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP     pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	//	CHAR    sWhere_Clause[QUERY_SIZE];
	//        memset(sWhere_Clause,'\0',QUERY_SIZE);

	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR         	sBuySellInd[5];
	CHAR         	sSecurityID[SECURITY_ID_LEN];
	CHAR          	sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR         	sProduct[10];
	CHAR         	sValidity[5];
	CHAR         	sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         	sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         	sClientId[CLIENT_ID_LEN];
	CHAR         	sRespClientId[CLIENT_ID_LEN];
	CHAR         	sEntityId[ENTITY_ID_LEN];
	CHAR         	ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32		iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;	
	LONG32		iOrderBookTime;


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);
	logDebug2("  client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);

	//	fOrderBookQuery(sClientId,sWhere_Clause,&Result);

	sprintf(sOrdBook,"SELECT CLIENT_ID,ORDER_DATE_TIME,ORDER_NUMBER,EXCH,BUY_SELL,SEGMENT,LEG_NO,PRODUCT,QUANTITY,REMAINING_QUANTITY,PRICE,\
			TRG_PRICE,ORDER_TYPE,DISCLOSE_QTY,SERIALNO,TRADEDQTY,SEM_SECURITY_ID,ORDER_VALIDITY,DQQTYREM,EXCHORDERNO,REASON_DESCRIPTION,\
			PRO_CLIENT,TRADE_PRICE,GOOD_TILL_DATE,PLACEDBY,STRATEGY_ID,JDATE,TRANSCODE , ALGOORDERNO,IFNULL(PAN_NO,'NA'),\
			IFNULL(PARTICIPANT_TYPE,'B'),IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'), \
			IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),MKT_TYPE, SL_ABSTICK_VALUE,PR_ABSTICK_VALUE,SL_AT_FLAG, PR_ST_FLAG,\
			TRAILING_SL_VALUE FROM (SELECT A.EQ_CLIENT_ID AS CLIENT_ID,\
				DATE_FORMAT(A.EQ_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,A.EQ_ORDER_NO AS ORDER_NUMBER,\
				A.EQ_EXCH_ID AS EXCH,(CASE A.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL,\
				'E' AS SEGMENT,A.EQ_INSTRUMENT_NAME AS INSTRUMENT, A.EQ_SYMBOL AS SYMBOL,A.EQ_LEG_NO AS LEG_NO,\
				(CASE A.EQ_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' \
				 WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' \
				 WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE A.EQ_PRODUCT_ID END) AS PRODUCT,\
				(CASE WHEN ((A.EQ_MSG_CODE = '2073') AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY)) THEN 'Part-Traded' \
				 WHEN ((A.EQ_MSG_CODE = '2074') AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY)) THEN 'Part-Traded' \
				 WHEN ((A.EQ_MSG_CODE = '2212') AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY)) THEN 'Part-Traded' \
				 WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending' WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit' \
				 WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit' WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit' \
				 WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected' \
				 WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen' WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified' \
				 WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled' WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded' \
				 WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired' WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending' \
				 WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified' WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled' \
				 WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered' WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected' \
				 WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected' \
				 WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected' \
				 WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected' END) AS STATUS, \
				A.EQ_TOTAL_QTY AS QUANTITY, A.EQ_REM_QTY AS REMAINING_QUANTITY, \
				(CASE A.EQ_SEGMENT WHEN 'C' THEN REPLACE(FORMAT((CASE A.EQ_ORDER_TYPE \
										 WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(A.EQ_ORDER_PRICE, 0) END), 4), ',', '') \
				 ELSE REPLACE(FORMAT((CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
							 ELSE IFNULL(A.EQ_ORDER_PRICE, 0) END), 2), ',', '') END) AS PRICE, \
				CASE A.EQ_SEGMENT WHEN 'C' THEN ROUND(COALESCE((CASE A.EQ_ORDER_TYPE \
								WHEN '3' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) \
								ELSE 0 END), 0), 2) ELSE ROUND(COALESCE((CASE A.EQ_ORDER_TYPE \
									WHEN '3' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) \
									ELSE 0 END), 0), 2) END AS TRG_PRICE,\
								(CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' \
								 WHEN '4' THEN 'SL' END) AS ORDER_TYPE, \
								CONCAT(A.EQ_REM_QTY, '/', A.EQ_TOTAL_QTY) AS REM_QTY_TOT_QTY, \
								A.EQ_DISC_QTY AS DISCLOSE_QTY, A.EQ_SERIAL_NO AS SERIALNO, \
								A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,A.EQ_SCRIP_CODE AS SEM_SECURITY_ID, \
								(CASE A.EQ_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \
								 WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS ORDER_VALIDITY, \ 
								ifnull(A.EQ_LOT_SIZE,0) AS SEM_NSE_REGULAR_LOT, 0 AS TAKE_PROFIT_TRAIL_GAP, \
								A.EQ_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,A.EQ_DISC_REM_QTY AS DQQTYREM,\
								A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,ifnull(NULLIF(A.EQ_REASON_DESCRIPTION,''),'NULL') AS REASON_DESCRIPTION,\
								A.EQ_PRO_CLIENT as PRO_CLIENT,A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,\
								ifnull(A.EQ_GOOD_TILL_DATE,NOW()) AS GOOD_TILL_DATE,A.EQ_ENTITY_ID AS PLACEDBY,\
								A.EQ_STRATEGY_ID AS STRATEGY_ID,JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,\
								A.EQ_MSG_CODE AS TRANSCODE  ,A.EQ_ALGO_ORDER_NO AS ALGOORDERNO,A.EQ_PAN_NO AS PAN_NO,\
								A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,A.EQ_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,\
								A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,A.EQ_SETTLOR AS SETTLOR,A.EQ_GTC_FLG AS GTC_FLG,\
								A.EQ_ENCASH_FLG AS ENCASH_FLG,A.EQ_MKT_TYPE AS MKT_TYPE,\
								A.EQ_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE, A.EQ_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,\
								A.EQ_SL_AT_FLAG AS SL_AT_FLAG,A.EQ_PR_ST_FLAG 	AS PR_ST_FLAG, \
								A.EQ_TRAILING_SL_VALUE AS TRAILING_SL_VALUE FROM EQ_ORDERS A \
								JOIN (SELECT @rn:=0) r WHERE A.EQ_CLIENT_ID = ltrim(rtrim(\"%s\")) AND (A.EQ_MKT_TYPE <> 'SP') \
								AND A.EQ_SERIAL_NO = (SELECT MAX(C.EQ_SERIAL_NO) FROM EQ_ORDERS C \
										WHERE (C.EQ_ORDER_NO = A.EQ_ORDER_NO) \
										AND (A.EQ_LEG_NO = C.EQ_LEG_NO) AND (A.EQ_ORD_STATUS <> 'B'))   UNION ALL SELECT  \
								DO.DRV_CLIENT_ID AS CLIENT_ID, DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,\
								DO.DRV_ORDER_NO AS ORDER_NUMBER,DO.DRV_EXCH_ID AS EXCH,\
								(CASE DO.DRV_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL,\
								DO.DRV_SEGMENT AS SEGMENT, DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,\
								DO.DRV_SYMBOL AS SYMBOL,DO.DRV_LEG_NO AS LEG_NO,\
								(CASE DO.DRV_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' \
								 WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' \
								 WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE DO.DRV_PRODUCT_ID END) AS PRODUCT, \
								(CASE WHEN ((DO.DRV_MSG_CODE = '2073') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) THEN 'Part-Traded' \
								 WHEN ((DO.DRV_MSG_CODE = '2074') AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY)) THEN 'Part-Traded' \
								 WHEN ((DO.DRV_MSG_CODE = '2212') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) THEN 'Part-Traded' \
								 WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending' WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit' \
								 WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit' WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit' \
								 WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected' \
								 WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen' WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified' \
								 WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled' WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded' \
								 WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired' WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending' \
								 WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified' WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled' \
								 WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered' WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected' \
								 WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected' \
								 WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected' \
								 WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected' END) AS STATUS,\
								DO.DRV_TOTAL_QTY AS QUANTITY,DO.DRV_REM_QTY AS REM_QTY,\
								CASE DO.DRV_SEGMENT WHEN 'C' THEN REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE \
												WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 4), ',', '') \
								ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
												ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 2), ',', '') END AS PRICE,\
								CASE DO.DRV_SEGMENT WHEN 'C' THEN ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE \
												WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) \
												ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE \
													WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) \
													ELSE 0 END), 0), 2) END AS TRG_PRICE,\
												(CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\
												CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,\
												DO.DRV_DISC_QTY AS DISCLOSE_QTY,DO.DRV_SERIAL_NO AS SERIALNO,\
												DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,DO.DRV_SCRIP_CODE AS SECURITY_ID,\
												(CASE DO.DRV_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \
												 WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS ORDER_VALIDITY,\
												DO.DRV_LOT_SIZE AS SM_LOT_SIZE, 0 AS TAKE_PROFIT_TRAIL_GAP,\
												DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,DO.DRV_DISC_REM_QTY AS DQQTYREM,\
												DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO,ifnull(NULLIF(DO.DRV_REASON_DESCRIPTION,''),'NULL') AS REASON_DESCRIPTION,\
												DO.DRV_PRO_CLIENT AS PRO_CLIENT, DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,\
												ifnull(DO.DRV_GOOD_TILL_DATE,NOW()) AS GOOD_TILL_DATE, DO.DRV_ENTITY_ID AS PLACEDBY,\
												DO.DRV_STRATEGY_ID AS STRATEGY_ID,JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
												DO.DRV_MSG_CODE AS TRANSCODE ,DO.DRV_OMS_ALGO_ORD_NO AS ALGOORDERNO,DO.DRV_PAN_NO AS PAN_NO,\
												DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,\
												DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,DO.DRV_SETTLOR AS SETTLOR,DO.DRV_GTC_FLG AS GTC_FLG,\
												DO.DRV_ENCASH_FLG AS ENCASH_FLG,DO.DRV_MKT_TYPE AS MKT_TYPE,DO.DRV_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE,DO.DRV_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,DO.DRV_SL_AT_FLAG     AS SL_AT_FLAG,DO.DRV_PR_ABSTICK_VALUE AS PR_ST_FLAG,DO.DRV_TRAILING_SL_VALUE  AS TRAILING_SL_VALUE FROM DRV_ORDERS DO \
												JOIN (SELECT @rn:=0) r WHERE DO.DRV_CLIENT_ID = ltrim(rtrim(\"%s\")) AND (DO.DRV_MKT_TYPE <> 'SP') \
												AND DO.DRV_SERIAL_NO = (SELECT MAX(DOO.DRV_SERIAL_NO) FROM DRV_ORDERS DOO \
														WHERE (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO) AND (DO.DRV_CF_FLAG <> -(1) \
															AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO)) AND (DO.DRV_STATUS <> 'B')) UNION \
												SELECT  COM.COMM_CLIENT_ID AS CLIENT_ID,DATE_FORMAT(COM.COMM_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,\
												COM.COMM_ORDER_NO AS ORDER_NUMBER,COM.COMM_EXCH_ID AS EXCH,\            
												(CASE COM.COMM_BUY_SELL_IND \
												 WHEN 'B' THEN 'Buy' \
												 WHEN 'S' THEN 'Sell' \
												 END) AS BUY_SELL,COM.COMM_SEGMENT AS SEGMENT,COM.COMM_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,\
												COM.COMM_SYMBOL AS SYMBOL,COM.COMM_LEG_NO AS LEG_NO,\
												(CASE COM.COMM_PRODUCT_ID \
												 WHEN 'B' THEN 'BO' \
												 WHEN 'V' THEN 'CO' \
												 WHEN 'C' THEN 'CNC' \
												 WHEN 'M' THEN 'MARGIN' \
												 WHEN 'L' THEN 'MLB' \
												 WHEN 'S' THEN 'COLLATERAL' \
												 WHEN 'I' THEN 'INTRADAY' \
												 WHEN 'V' THEN 'CO' \
												 WHEN 'B' THEN 'BO' \
												 WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE COM.COMM_PRODUCT_ID \
												 END) AS PRODUCT,\
												(CASE \
												 WHEN \
												 ((COM.COMM_MSG_CODE = '2073') \
												  AND (COM.COMM_REM_QTY <> COM.COMM_TOTAL_QTY)) \
												 THEN \
												 'Part-Traded' \
												 WHEN \
												 ((COM.COMM_MSG_CODE = '2074')\
												  AND (COM.COMM_REM_QTY > COM.COMM_TOTAL_QTY))\
												 THEN\
												 'Part-Traded'\
												 WHEN\
												 ((COM.COMM_MSG_CODE = '2212')\
												  AND (COM.COMM_REM_QTY <> COM.COMM_TOTAL_QTY))\
												 THEN\
												 'Part-Traded'\
												 WHEN (COM.COMM_MSG_CODE = '2073') THEN 'Pending'\
												 WHEN (COM.COMM_MSG_CODE = '2000') THEN 'Transit'\
												 WHEN (COM.COMM_MSG_CODE = '2040') THEN 'Transit'\
												 WHEN (COM.COMM_MSG_CODE = '2070') THEN 'Transit'\
												 WHEN (COM.COMM_MSG_CODE = '2231') THEN 'Rejected'\
												 WHEN (COM.COMM_MSG_CODE = '2042') THEN 'Rejected'\
												 WHEN\
												 (COM.COMM_MSG_CODE = '2170')\
												 THEN\
												 'Frozen'\
												 WHEN (COM.COMM_MSG_CODE = '2074') THEN 'Modified' \
												 WHEN (COM.COMM_MSG_CODE = '2075') THEN 'Cancelled' \
												 WHEN (COM.COMM_MSG_CODE = '2222') THEN 'Traded' \
												 WHEN (COM.COMM_MSG_CODE = '9002') THEN 'Expired' \
												 WHEN (COM.COMM_MSG_CODE = '5112') THEN 'O-Pending' \
												 WHEN (COM.COMM_MSG_CODE = '5113') THEN 'O-Modified' \
												 WHEN (COM.COMM_MSG_CODE = '5114') THEN 'O-Cancelled' \
												 WHEN (COM.COMM_MSG_CODE = '2212') THEN 'Triggered' \
												 WHEN (COM.COMM_MSG_CODE = '1111') THEN 'Rejected' \
												 WHEN (COM.COMM_MSG_CODE = '1113') THEN 'Rejected' \
												 WHEN (COM.COMM_MSG_CODE = '1115') THEN 'Rejected' \
												 WHEN (COM.COMM_MSG_CODE = '4444') THEN 'Rejected' \
												 WHEN (COM.COMM_MSG_CODE = '4445') THEN 'Rejected' \
												 WHEN (COM.COMM_MSG_CODE = '4446') THEN 'Rejected' \
												 END) AS STATUS,\
												 COM.COMM_TOTAL_QTY AS QUANTITY,\
												 COM.COMM_REM_QTY AS REM_QTY,\
												 CASE COM.COMM_SEGMENT\
												 WHEN\
												 'M'\
												 THEN\
												 REPLACE(FORMAT((CASE COM.COMM_ORDER_TYPE\
																 WHEN '1' THEN 'MKT'\
																 WHEN '3' THEN 'MKT'\
																 ELSE IFNULL(COM.COMM_ORDER_PRICE, 0)\
																 END), 4), ',', '')\
												 ELSE REPLACE(FORMAT((CASE COM.COMM_ORDER_TYPE\
																 WHEN '1' THEN 'MKT'\
																 WHEN '3' THEN 'MKT'\
																 ELSE IFNULL(COM.COMM_ORDER_PRICE, 0)\
																 END), 2), ',', '')\
												 END AS PRICE,\
												 CASE COM.COMM_SEGMENT\
												 WHEN\
												 'M'\
												 THEN\
												 ROUND(COALESCE((CASE COM.COMM_ORDER_TYPE\
																 WHEN '3' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)\
																 WHEN '4' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)\
																 ELSE 0 \
																 END), 0), 4)\
												 ELSE ROUND(COALESCE((CASE COM.COMM_ORDER_TYPE\
																 WHEN '3' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)\
																 WHEN '4' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)\
																 ELSE 0\
																 END), 0), 2)\
												 END AS TRG_PRICE,\
												 (CASE COM.COMM_ORDER_TYPE\
												  WHEN '1' THEN 'MARKET'\
												  WHEN '2' THEN 'LIMIT'\
												  WHEN '3' THEN 'SL-M'\
												  WHEN '4' THEN 'SL'\
												  END) AS ORDER_TYPE,\
												 CONCAT(COM.COMM_REM_QTY, '/', COM.COMM_TOTAL_QTY) AS REM_QTY_TOT_QTY,\
												 COM.COMM_DISC_QTY AS DISCLOSE_QTY,\
												 COM.COMM_SERIAL_NO AS SERIALNO,\
												 COM.COMM_TOTAL_TRADED_QTY AS TRADEDQTY,\
												 COM.COMM_SCRIP_CODE AS SECURITY_ID,\
												 (CASE COM.COMM_VALIDITY\
												  WHEN '0' THEN 'DAY'\
												  WHEN '1' THEN 'GTC'\
												  WHEN '2' THEN 'ATO'\
												  WHEN '3' THEN 'IOC'\
												  WHEN '6' THEN 'GTD'\
												  ELSE 'EOS'\
												  END) AS ORDER_VALIDITY,\
												 COM.COMM_LOT_SIZE AS SM_LOT_SIZE,\
												 0 AS TAKE_PROFIT_TRAIL_GAP,\
												 COM.COMM_OMS_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,\
												 COM.COMM_DISC_REM_QTY AS DQQTYREM,\
												 COM.COMM_EXCH_ORDER_NO AS EXCHORDERNO,\
												 IFNULL(NULLIF(COM.COMM_REASON_DESCRIPTION, ''), 'NULL') AS REASON_DESCRIPTION,\
												 COM.COMM_PRO_CLIENT AS PRO_CLIENT,\
												 COM.COMM_TRD_TRADE_PRICE AS TRADE_PRICE,\
												 IFNULL(COM.COMM_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,\
												 COM.COMM_ENTITY_ID AS PLACEDBY,\
												 COM.COMM_STRATEGY_ID AS STRATEGY_ID,\
												 JULIDATE(COM.COMM_INTERNAL_ENTRY_DATE) AS JDATE,\
												 COM.COMM_MSG_CODE AS TRANSCODE,\
												 COM.COMM_OMS_ALGO_ORDER_NO AS ALGOORDERNO,COM.COMM_PAN_NO AS PAN_NO,COM.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,\
												 COM.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,COM.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,COM.COMM_SETTLOR AS SETTLOR,\
												 COM.COMM_GTC_FLG AS GTC_FLG,COM.COMM_ENCASH_FLG AS ENCASH_FLG,COM.COMM_MKT_TYPE AS MKT_TYPE,COM.COMM_SL_ABSTICK_VALUE	AS SL_ABSTICK_VALUE,COM.COMM_PR_ABSTICK_VALUE	AS PR_ABSTICK_VALUE,COM.COMM_SL_AT_FLAG	AS SL_AT_FLAG,COM.COMM_PR_ABSTICK_VALUE	AS PR_ST_FLAG,COM.COMM_TRAILING_SL_VALUE  AS TRAILING_SL_VALUE FROM\
												 COMM_ORDERS COM\
												 JOIN (SELECT @rn:=0) r\
												 WHERE\
												 COM.COMM_CLIENT_ID = LTRIM(RTRIM(\'%s\'))\
												 AND (COM.COMM_MKT_TYPE <> 'SP')\
												 AND COM.COMM_SERIAL_NO = (SELECT \
														 MAX(DOO.COMM_SERIAL_NO)\
														 FROM\
														 COMM_ORDERS DOO\
														 WHERE\
														 (DOO.COMM_ORDER_NO = COM.COMM_ORDER_NO)\
													AND (DOO.COMM_CF_FLAG <> -(1)\
														 AND (COM.COMM_OMS_ALGO_ORDER_NO <> -(1)\
															 AND (COM.COMM_LEG_NO = DOO.COMM_LEG_NO))\
														 AND (COM.COMM_STATUS <> 'B')))) orderbook\
														 WHERE 1 = 1 ORDER BY ORDER_DATE_TIME DESC; ",sClientId,sClientId,sClientId);


	printf(" fOrderBook :%s:",sOrdBook);

	if(mysql_query(DBQueries,sOrdBook ) != SUCCESS)
	{
		logSqlFatal("ERROR in Order BOOK Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);	
	iNoOfRec= mysql_num_rows(Res); 

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	//	pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug1(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);

	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}
	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("----------i count  = :%d:-----------",i);
		memset(&pOrderBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_RESP));
		pOrderBookResp.IntRespHeader.iSeqNo = 0;
		pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_RESP);
		pOrderBookResp.IntRespHeader.iErrorId = 0;
		pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_RESP;
		pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
		pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
		if(iTempNoOfRec <= 1)
		{
			pOrderBookResp.cMsgType = 'T';
		}
		else
		{
			pOrderBookResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{	
				strncpy(pOrderBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sDatetime,Row[1],DATE_LENGTH);
				pOrderBookResp.suborderbook[j].fOrderNo =atof(Row[2]);
				strncpy(pOrderBookResp.suborderbook[j].sExcgId,Row[3],EXCHANGE_LEN);
				memset(pOrderBookResp.suborderbook[j].sBuySellInd,'\0',5);
				strncpy(pOrderBookResp.suborderbook[j].sBuySellInd,Row[4],5);
				pOrderBookResp.suborderbook[j].cSegment = Row[5][0];
				pOrderBookResp.suborderbook[j].iLegValue = atoi(Row[6]);
				strncpy(pOrderBookResp.suborderbook[j].sProduct,Row[7],10);
				pOrderBookResp.suborderbook[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbook[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbook[j].fPrice = atof(Row[10]);
				pOrderBookResp.suborderbook[j].fTrgPrice = atof(Row[11]);
				strncpy(pOrderBookResp.suborderbook[j].sOrderType,Row[12],8);
				pOrderBookResp.suborderbook[j].fDQQty = atof(Row[13]);
				pOrderBookResp.suborderbook[j].iSerialNo =atoi(Row[14]);
				pOrderBookResp.suborderbook[j].fTradeQty = atof(Row[15]);
				strncpy(pOrderBookResp.suborderbook[j].sSecurityID,Row[16] ,SECURITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sValidity,Row[17],5);
				pOrderBookResp.suborderbook[j].fDQQtyRem = atof(Row[18]);
				strncpy(pOrderBookResp.suborderbook[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sReasonDesc, Row[20],DB_REASON_DESC_LEN);
				pOrderBookResp.suborderbook[j].cProClient =  Row[21][0];
				pOrderBookResp.suborderbook[j].fTrdPrice  = atof(Row[22]);
				strncpy(pOrderBookResp.suborderbook[j].sGoodTillDaysDate, Row[23],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sEntityId , Row[24],ENTITY_ID_LEN);
				pOrderBookResp.suborderbook[j].iStrategyId = atoi(Row[25]);
				pOrderBookResp.suborderbook[j].iDateTime = atoi(Row[26]);
				pOrderBookResp.suborderbook[j].iTranscode = atoi(Row[27]);
				pOrderBookResp.suborderbook[j].fAlgoOrderNo  = atof(Row[28]);
				if(strlen(Row[29]) == 0)
				{	
					strncpy(pOrderBookResp.suborderbook[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbook[j].sPanID,Row[29],INT_PAN_LEN);
				}

				pOrderBookResp.suborderbook[j].cParticipantType =  Row[30][0];
				pOrderBookResp.suborderbook[j].cMarkProFlag =  Row[31][0];
				pOrderBookResp.suborderbook[j].fMarkProVal = atof(Row[32]);
				if(strlen(Row[33]) == 0)
				{
					strncpy(pOrderBookResp.suborderbook[j].sSettlor,"NA",SETTLOR_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbook[j].sSettlor,Row[33],SETTLOR_LEN);
				}
				pOrderBookResp.suborderbook[j].cGTCFlag =  Row[34][0];
				pOrderBookResp.suborderbook[j].cEncashFlag =  Row[35][0];
				strncpy(pOrderBookResp.suborderbook[j].sMktType,Row[36],MKT_TYPE_LEN);
				/**
				  pOrderBookResp.suborderbook[j].fSLAbsTick= atof(Row[37]);
				  pOrderBookResp.suborderbook[j].fPRAbsTick= atof(Row[38]);
				  pOrderBookResp.suborderbook[j].cSLAtFlag=  Row[39][0];
				  pOrderBookResp.suborderbook[j].cPRStFlag=  Row[40][0];
				  pOrderBookResp.suborderbook[j].fTrailingVal= atof(Row[41]);
				 **/
				logDebug2("Printing fAlgoOrderNo");

				logInfo(" ----------------- Printing Header ------------------------------------");

				logDebug2("pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2("pOrderBookResp.suborderbook[%d].sClientId = %s",j,pOrderBookResp.suborderbook[j].sClientId);
				logDebug2("pOrderBookResp.suborderbook[%d].sDatetime = %s",j,pOrderBookResp.suborderbook[j].sDatetime);
				logDebug2("pOrderBookResp.suborderbook[%d].fOrderNo =%lf ",j,pOrderBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrderBookResp.suborderbook[%d].sExcgId = %s",j,pOrderBookResp.suborderbook[j].sExcgId);	
				logDebug2("pOrderBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrderBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrderBookResp.suborderbook[%d].cSegment = %c",j,pOrderBookResp.suborderbook[j].cSegment);
				logDebug2("pOrderBookResp.suborderbook[%d].iLegValue = %d",j,pOrderBookResp.suborderbook[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbook[%d].sProduct = %s",j,pOrderBookResp.suborderbook[j].sProduct);
				logDebug2("pOrderBookResp.suborderbook[%d].fQty = %lf",j,pOrderBookResp.suborderbook[j].fQty);
				logDebug2("pOrderBookResp.suborderbook[%d].fRemQty = %lf",j,pOrderBookResp.suborderbook[j].fRemQty);
				logDebug2("pOrderBookResp.suborderbook[%d].fPrice = %lf",j,pOrderBookResp.suborderbook[j].fPrice);
				logDebug2("pOrderBookResp.suborderbook[%d].fTrgPrice = %lf",j,pOrderBookResp.suborderbook[j].fTrgPrice);
				logDebug2("pOrderBookResp.suborderbook[%d].sOrderType= %s",j,pOrderBookResp.suborderbook[j].sOrderType);
				logDebug2("pOrderBookResp.suborderbook[%d].fDQQty = %lf",j,pOrderBookResp.suborderbook[j].fDQQty);
				logDebug2("pOrderBookResp.suborderbook[%d].iSerialNo = %d",j,pOrderBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrderBookResp.suborderbook[%d].fTradeQty= %lf",j,pOrderBookResp.suborderbook[j].fTradeQty);
				logDebug2("pOrderBookResp.suborderbook[%d].iStrategyId = %d",j,pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[%d].sValidity = %s",j,pOrderBookResp.suborderbook[j].sValidity);
				logDebug2("pOrderBookResp.suborderbook[%d].fDQQtyRem = %lf",j,pOrderBookResp.suborderbook[j].fDQQtyRem);
				logDebug2("pOrderBookResp.suborderbook[%d].sExchOrderNumber= %s",j,pOrderBookResp.suborderbook[j].sExchOrderNumber);
				logDebug2("pOrderBookResp.suborderbook[%d].sReasonDesc = %s",j,pOrderBookResp.suborderbook[j].sReasonDesc);		
				logDebug2("pOrderBookResp.suborderbook[%d].cProClient = %c",j,pOrderBookResp.suborderbook[j].cProClient);
				logDebug2("pOrderBookResp.suborderbook[%d].fTrdPrice = %lf",j,pOrderBookResp.suborderbook[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbook[%d].sGoodTillDaysDate = %s",j,pOrderBookResp.suborderbook[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbook[%d].sEntityId = %s",j,pOrderBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbook[%d].iStrategyId = %d",j,pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[%d].iDateTime = %d",j,pOrderBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrderBookResp.suborderbook[%d].iTranscode = %d",j,pOrderBookResp.suborderbook[j].iTranscode);	
				logDebug2("pOrderBookResp.suborderbook[%d].fAlgoOrderNo = %f",j,pOrderBookResp.suborderbook[j].fAlgoOrderNo);
				logDebug2("pOrderBookResp.suborderbook[%d].sPanID = %s",j,pOrderBookResp.suborderbook[j].sPanID);
				logDebug2("pOrderBookResp.suborderbook[%d].cParticipantType = %c",j,pOrderBookResp.suborderbook[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbook[%d].cMarkProFlag = %c",j,pOrderBookResp.suborderbook[j].cMarkProFlag);	
				logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbook[j].fMarkProVal);	
				logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbook[j].sSettlor);	
				logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbook[j].cGTCFlag);	
				logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbook[j].cEncashFlag);	
				logDebug2("pOrderBookResp.suborderbook[%d].sMktType = %s",j,pOrderBookResp.suborderbook[j].sMktType);
				/**
				  logDebug2("pOrderBookResp.suborderbook[%d].cPRStFlag= %c",j,pOrderBookResp.suborderbook[j].cPRStFlag);
				  logDebug2("pOrderBookResp.suborderbook[%d].cSLAtFlag= %c",j,pOrderBookResp.suborderbook[j].cSLAtFlag);
				  logDebug2("pOrderBookResp.suborderbook[%d].fSLAbsTick= %lf",j,pOrderBookResp.suborderbook[j].fSLAbsTick);
				  logDebug2("pOrderBookResp.suborderbook[%d].fPRAbsTick= %lf",j,pOrderBookResp.suborderbook[j].fPRAbsTick);
				  logDebug2("pOrderBookResp.suborderbook[%d].fTrailingVal= %lf",j,pOrderBookResp.suborderbook[j].fTrailingVal);
				 **/
			}

		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/
	}

	logTimestamp("EXIT [fOrderBook]");
	return TRUE;

}/************** END of fOrderBook ****/
/************************************************/
BOOL fEquOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fEquOrderBookDtls]");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sEqOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 i=0,j=0;

	DOUBLE64        fReqOrderNo;
	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR          sFlags[10];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR		sProduct;
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_TIME_LEN];
	LONG32          iEquNoOfRec;
	LONG32          iDrvNoOfRec;
	LONG32		iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTotalTradeQty;
	LONG32          iExchTradeNo;
	DOUBLE64        fTradePrice;
	LONG32          iTranscode;
	CHAR		cDayFlg;
	CHAR		cIOCFlg;
	CHAR		cMKTFlg;
	CHAR		cSTOPLOSSFlg;
	CHAR		cAONFlg;
	CHAR		cDQFlg;
	CHAR		cProCliFlg;
	CHAR		cSource;
	LONG32		iErrorId;
	CHAR         sBuySellInd[5];
	CHAR		sBuySellIndTemp;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	CHAR         sOrdReasonDesc[200];
	CHAR	cProdId ;
	INT16 iLegVal = 0;


	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	fReqOrderNo = pViewOrderBookReq->fOrderNo;	
	iLegVal     = pViewOrderBookReq->iLegNo;	

	logDebug2("pViewOrderBookReq->ReqHeader.cSegment:%c:",pViewOrderBookReq->ReqHeader.cSegment);
	logDebug2("ReqOrderNo :%lf:",pViewOrderBookReq->fOrderNo);
	logDebug2("ReqOrderNo :%lf:",fReqOrderNo);
	logDebug2("iLegVal    :%d:",pViewOrderBookReq->iLegNo);
	logDebug2("iLegVal    :%d:",iLegVal);

	sprintf(sEqOrdBook,"SELECT  EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_MSG_CODE,\
			EQ_SCRIP_CODE,\
			EQ_VALIDITY,\
			EQ_PRO_CLIENT,\
			EQ_SOURCE_FLG,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_LAST_TRADE_QTY,\
			EQ_TRD_TRADE_PRICE,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_TRD_EXCH_TRADE_NO,\
			EQ_PRODUCT_ID,\
			EQ_EXCH_ORDER_NO,\
			date_format(EQ_INTERNAL_ENTRY_DATE,\'%%d-%%m-%%Y %%r\'),\
			EQ_ERROR_CODE,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_EXCH_ID,\
			EQ_REASON_DESCRIPTION ,\
			EQ_ENTITY_ID ,\
			EQ_STRATEGY_ID ,\
			EQ_PRO_CLIENT ,\
			EQ_TRD_TRADE_PRICE ,\
			EQ_GOOD_TILL_DAYS ,\
			EQ_LEG_NO, \
			IFNULL(EQ_PAN_NO,\"NA\"),\
			IFNULL(EQ_PARTICIPANT_TYPE,'N'),\
			IFNULL(EQ_MKT_PROTECT_FLG,'N') \
			FROM EQ_ORDERS \
			WHERE EQ_ORDER_NO = \"%lf\" \
			AND EQ_LEG_NO = %d \
			ORDER BY EQ_ORDER_NO , EQ_SERIAL_NO desc ;",fReqOrderNo,iLegVal);

	logDebug3(" fEquOrderBookDtls :%s:",sEqOrdBook);

	if(mysql_query(DBQueries,sEqOrdBook) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;
	//		pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	logInfo(" I am in Equity");	


	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pOrderBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP));

		pOrderBookResp.IntRespHeader.iSeqNo = 0;
		pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);


		pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
		pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;

		pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pOrderBookResp.cMsgType = 'T';
		}
		else
		{
			pOrderBookResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				iErrorId = atoi(Row[24]);
				logDebug2("atoi(Row[24]) :%d: iErrorId :%d:",atoi(Row[24]),iErrorId);
				pOrderBookResp.IntRespHeader.iErrorId = iErrorId;
				logDebug2("pOrderBookResp.IntRespHeader.iErrorId :%d: iErrorId :%d:",pOrderBookResp.IntRespHeader.iErrorId,iErrorId);
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo	  =atoi(Row[16]);

				cProdId =  Row[17][0];
				pOrderBookResp.suborderbookdtls[j].sProduct =  Row[17][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18],BSE_EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_TIME_LEN);
				//pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[20]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21],CLIENT_ID_LEN);
				if(Row[22][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				if(strlen(Row[24]) != 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[24],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]); 
				pOrderBookResp.suborderbookdtls[j].cProClient	= Row[27][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice	= atof(Row[28]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
				pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
					
				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" pOrderBookResp.suborderbookdtls[%d].iTranscode :%d:",j,pOrderBookResp.suborderbookdtls[j].iTranscode);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s: ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);

			}


		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		usleep(1000);
		iTempNoOfRec--;

	}

	logTimestamp("EXIT [fEquOrderBookDtls]");
	return TRUE;

}/************** END of fEquOrderBookDtls ****/



BOOL fBoEquOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("ENTRY fBoEquOrderBookDtls");
	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP      pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	//        CHAR    *sEqOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	CHAR sEqOrdBook [MAX_QUERY_SIZE];
	memset(sEqOrdBook,'\0',MAX_QUERY_SIZE);

	LONG32 i=0,j=0;
	DOUBLE64        fReqOrderNo = 0.00 ;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec = 0; 
	DOUBLE64        fNoOfRec = 0.00 ;
	LONG32          iNoOfPkt = 0 ;
	LONG32          iErrorId = 0 ;


	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	fReqOrderNo = pViewOrderBookReq->fOrderNo;

	logDebug2("pViewOrderBookReq->ReqHeader.cSegment:%c:",pViewOrderBookReq->ReqHeader.cSegment);
	logDebug2("ReqOrderNo :%lf:",fReqOrderNo);
	logDebug2("iLegVal    :%d:",pViewOrderBookReq->iLegNo);

	sprintf(sEqOrdBook,"SELECT  ord.EQ_ORDER_NO,\
			EQ_SERIAL_NO,\
			EQ_MSG_CODE,\
			EQ_SCRIP_CODE,\
			EQ_VALIDITY,\
			EQ_PRO_CLIENT,\
			EQ_SOURCE_FLG,\
			EQ_TOTAL_QTY,\
			EQ_REM_QTY,\
			EQ_DISC_QTY,\
			EQ_DISC_REM_QTY,\
			EQ_ORDER_PRICE,\
			EQ_TRIGGER_PRICE,\
			EQ_LAST_TRADE_QTY,\
			EQ_TRD_TRADE_PRICE,\
			EQ_TOTAL_TRADED_QTY,\
			EQ_TRD_EXCH_TRADE_NO,\
			EQ_PRODUCT_ID,\
			EQ_EXCH_ORDER_NO,\
			date_format(EQ_INTERNAL_ENTRY_DATE,\'%%d-%%m-%%Y %%r\'),\
			EQ_ERROR_CODE,\
			EQ_CLIENT_ID,\
			EQ_BUY_SELL_IND,\
			EQ_EXCH_ID,\
			EQ_REASON_DESCRIPTION ,\
			EQ_ENTITY_ID ,\
			EQ_STRATEGY_ID ,\
			EQ_PRO_CLIENT ,\
			EQ_TRD_TRADE_PRICE ,\
			EQ_GOOD_TILL_DAYS ,\
			EQ_LEG_NO ,\
			EQ_ALGO_ORDER_NO ,\
			EQ_ORDER_TYPE \
			FROM EQ_ORDERS ord,( \
					select eq_order_no ,max(eq_serial_no) srno from EQ_ORDERS where EQ_ALGO_ORDER_NO = %lf group by eq_order_no) ord1 \
			WHERE ord.EQ_ORDER_NO=ord1.eq_order_no and ord.EQ_SERIAL_NO=ord1.srno AND EQ_PRODUCT_ID = \'%c\'",fReqOrderNo,PROD_BRACKET);

	logDebug3(" fBoEquOrderBookDtls :%s:",sEqOrdBook);

	if(mysql_query(DBQueries,sEqOrdBook) != SUCCESS)
	{
		logSqlFatal("Error in EQ Ord BOOK Details Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;


	//              pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				//                              memset(cProdId,'\0',2);

				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP);
				iErrorId = atoi(Row[24]);
				logDebug2("atoi(Row[24]) :%d: iErrorId :%d:",atoi(Row[24]),iErrorId);
				pOrderBookResp.IntRespHeader.iErrorId = iErrorId;
				logDebug2("pOrderBookResp.IntRespHeader.iErrorId :%d: iErrorId :%d:",pOrderBookResp.IntRespHeader.iErrorId,iErrorId);

				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_DTLS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
				pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;
				pOrderBookResp.IntRespHeader.cSegment = EQUITY_SEGMENT;
				logDebug2("pOrderBookResp.IntRespHeader.cSegment	:%c:",pOrderBookResp.IntRespHeader.cSegment);

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iOrderValidity = atoi(Row[4]);


				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[16]);

				pOrderBookResp.suborderbookdtls[j].cProduct =  Row[17][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18],EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_TIME_LEN);
				//pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[20]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21],CLIENT_ID_LEN);
				if(Row[22][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",BUY_SELL_LEN);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",BUY_SELL_LEN);
				}
				if(strlen(Row[24]) != 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[24],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice  = atof(Row[28]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);
				logDebug2("fAlgoOrderNo atof(Row[31]):%lf:",atof(Row[31]));
				pOrderBookResp.suborderbookdtls[j].fAlgoOrderNo = atof(Row[31]);
				pOrderBookResp.suborderbookdtls[j].iOrderType	 = atoi(Row[32]);;

				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);


				logDebug2("---------------------------Start Record = %d---------------------------",j);
				logDebug2("iLegValue[%d]	:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
				logDebug2(" fOrderNo[%d]	:%lf:",j,pOrderBookResp.suborderbookdtls[j].fOrderNo);
				logDebug2("fAlgoOrderNo[%d]	:%lf:",j,pOrderBookResp.suborderbookdtls[j].fAlgoOrderNo);
				logDebug2("sBuySellInd[%d]	:%s:",j,pOrderBookResp.suborderbookdtls[j].sBuySellInd);
				logDebug2("sExchOrderNumber[%d]:%s:",j,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber);
				logDebug2("fQty[%d]		:%lf:",j,pOrderBookResp.suborderbookdtls[j].fQty);
				logDebug2("fRemQty[%d]		:%lf:",j,pOrderBookResp.suborderbookdtls[j].fRemQty);
				logDebug2("sSecurityID[%d]	:%s:",j,pOrderBookResp.suborderbookdtls[j].sSecurityID);
				logDebug2("iSerialNo[%d]	:%d:",j,pOrderBookResp.suborderbookdtls[j].iSerialNo);
				logDebug2("fDQQty[%d]		:%lf:",j,pOrderBookResp.suborderbookdtls[j].fDQQty);
				logDebug2("fDQQtyRem[%d]	:%lf:",j,pOrderBookResp.suborderbookdtls[j].fDQQtyRem);
				logDebug2("fPrice[%d]		:%lf:",j,pOrderBookResp.suborderbookdtls[j].fPrice);
				logDebug2("fTrgPrice[%d]	:%lf:",j,pOrderBookResp.suborderbookdtls[j].fTrgPrice);
				logDebug2("fTradeQty[%d]	:%lf:",j,pOrderBookResp.suborderbookdtls[j].fTradeQty);
				logDebug2("cProduct[%d]		:%c:",j,pOrderBookResp.suborderbookdtls[j].cProduct);
				logDebug2("iOrderType[%d]       :%d:",j,pOrderBookResp.suborderbookdtls[j].iOrderType);
				logDebug2("iOrderValidity[%d]  	:%d:",j,pOrderBookResp.suborderbookdtls[j].iOrderValidity);
				logDebug2("sDatetime[%d]	:%s:",j,pOrderBookResp.suborderbookdtls[j].sDatetime);
				logDebug2("sClientId[%d]	:%s:",j,pOrderBookResp.suborderbookdtls[j].sClientId);
				logDebug2("ReasonDesc[%d]	:%s:",j,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc);
				logDebug2(" ErrorId[%d] 	:%d: ",j,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("sEntityId[%d] 	:%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("iStrategyId[%d] 	:%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("cProClient[%d] 	:%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("sGoodTillDaysDate[%d] :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("-------------------------------END-----------------------------------------");


			}

			iTempNoOfRec--;
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}


	}

	logTimestamp("EXIT [fBoEquOrderBookDtls]");
	return TRUE;
}

BOOL fBoDrvOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("Entry : fBoDrvOrderBookDtls");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	LONG32 i=0,j=0;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	//        CHAR    *sDrvOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR 	sDrvOrdBook [MAX_QUERY_SIZE];
	memset(sDrvOrdBook,'\0',MAX_QUERY_SIZE);
	DOUBLE64        fReqOrderNo;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            cOrdValidity;

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	fReqOrderNo = pViewOrderBookReq->fOrderNo;

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,fReqOrderNo);

	sprintf(sDrvOrdBook,"SELECT  DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_MSG_CODE,\
			DRV_SCRIP_CODE,\
			DRV_VALIDITY,\
			DRV_PRO_CLIENT,\
			DRV_SOURCE_FLG,\
			DRV_ORIG_CLORDID,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_TRD_TRADE_QTY,\
			DRV_TRD_TRADE_PRICE,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_TRD_EXCH_TRADE_NO,\
			DRV_PRODUCT_ID,\
			DRV_EXCH_ORDER_NO,\
			IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
			DRV_ERROR_CODE,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_EXCH_ID,\
			DRV_REASON_DESCRIPTION ,\
			DRV_ENTITY_ID ,\
			DRV_STRATEGY_ID ,\
			DRV_PRO_CLIENT ,\
			DRV_TRD_TRADE_PRICE ,\
			DRV_GOOD_TILL_DAYS ,\
			DRV_LEG_NO	,\
			DRV_OMS_ALGO_ORD_NO ,\	
			DRV_ORDER_TYPE	\
			FROM DRV_ORDERS A \
			WHERE DRV_OMS_ALGO_ORD_NO = %lf \
			AND DRV_LEG_NO IN (2,3) \
			AND DRV_PRODUCT_ID = \'%c\' \
			AND DRV_SERIAL_NO = (SELECT MAX(DRV_SERIAL_NO) FROM DRV_ORDERS B  WHERE DRV_OMS_ALGO_ORD_NO = %lf AND A.DRV_LEG_NO = B.DRV_LEG_NO) ORDER BY DRV_ORDER_NO , DRV_INTERNAL_ENTRY_DATE desc ",fReqOrderNo,PROD_BRACKET,fReqOrderNo);			


			logDebug2(" fBoDrvOrderBookDtls :%s: ",sDrvOrdBook);

	if(mysql_query(DBQueries,sDrvOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in DrvOrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	logInfo(" I am in Derivative");

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_DTLS_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
				pOrderBookResp.IntRespHeader.cSegment = DERIVATIVE_SEGMENT;
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iOrderValidity = atoi(Row[4]);

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[17]);
				pOrderBookResp.suborderbookdtls[j].cProduct = Row[18][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

				if(strlen(Row[25])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				if(Row[23][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",BUY_SELL_LEN);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",BUY_SELL_LEN);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice    = atof(Row[29]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[31]);
				pOrderBookResp.suborderbookdtls[j].fAlgoOrderNo = atof(Row[32]);
				pOrderBookResp.suborderbookdtls[j].iOrderType =  atoi(Row[33]);

				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);

				logDebug2("iLegValue[%d]        :%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
				logDebug2(" fOrderNo[%d]        :%lf:",j,pOrderBookResp.suborderbookdtls[j].fOrderNo);
				logDebug2("fAlgoOrderNo[%d]     :%d:",j,pOrderBookResp.suborderbookdtls[j].fAlgoOrderNo);
				logDebug2("sBuySellInd[%d]      :%s:",j,pOrderBookResp.suborderbookdtls[j].sBuySellInd);
				logDebug2("sExchOrderNumber[%d]:%s:",j,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber);
				logDebug2("fQty[%d]             :%lf:",j,pOrderBookResp.suborderbookdtls[j].fQty);
				logDebug2("fRemQty[%d]          :%lf:",j,pOrderBookResp.suborderbookdtls[j].fRemQty);
				logDebug2("sSecurityID[%d]      :%s:",j,pOrderBookResp.suborderbookdtls[j].sSecurityID);
				logDebug2("iSerialNo[%d]        :%d:",j,pOrderBookResp.suborderbookdtls[j].iSerialNo);
				logDebug2("fDQQty[%d]           :%lf:",j,pOrderBookResp.suborderbookdtls[j].fDQQty);
				logDebug2("fDQQtyRem[%d]        :%lf:",j,pOrderBookResp.suborderbookdtls[j].fDQQtyRem);
				logDebug2("fPrice[%d]           :%lf:",j,pOrderBookResp.suborderbookdtls[j].fPrice);
				logDebug2("fTrgPrice[%d]        :%lf:",j,pOrderBookResp.suborderbookdtls[j].fTrgPrice);
				logDebug2("fTradeQty[%d]        :%lf:",j,pOrderBookResp.suborderbookdtls[j].fTradeQty);
				logDebug2("cProduct[%d] 	:%c:",j,pOrderBookResp.suborderbookdtls[j].cProduct);
				logDebug2("iOrderType[%d]        :%d:",j,pOrderBookResp.suborderbookdtls[j].iOrderType);
				logDebug2("iOrderValidity [%d]        :%d:",j,pOrderBookResp.suborderbookdtls[j].iOrderValidity);
				logDebug2("sDatetime[%d]        :%s:",j,pOrderBookResp.suborderbookdtls[j].sDatetime);
				logDebug2("sClientId[%d]        :%s:",j,pOrderBookResp.suborderbookdtls[j].sClientId);
				logDebug2("ReasonDesc[%d]       :%s:",j,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc);
				logDebug2(" ErrorId[%d]         :%d: ",j,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("sEntityId[%d]        :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("iStrategyId[%d]      :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("cProClient[%d]       :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("sGoodTillDaysDate[%d] :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);

			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_BRACKET_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}


	}

	logTimestamp("Exit : fBoDrvOrderBookDtls ");
	return TRUE;


}




BOOL 	fTradeBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fTradeBook");

	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR *sTrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;




	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);


	sprintf(sTrdBook,"SELECT CLIENT_ID,SEM_SMST_SECURITY_ID,ORDER_DATE_TIME,ORDER_NUMBER,EXCH_ORDER_NUMBER,TRADE_NUMBER,EXCH,BUY_SELL,SEGMENT,ORDER_TYPE,\
			PRODUCT,QUANTITY,PRICE,TRADE_VALUE,JDATE,PLACEDBY,STRATEGY_ID,LEGVALUE,IFNULL(PAN_NO,'NA'),IFNULL(PARTICIPANT_TYPE,'B'),\
			IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'),IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),MKT_TYPE \
			FROM(SELECT A.EQ_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r,\
				A.EQ_SCRIP_CODE AS SEM_SMST_SECURITY_ID, DATE_FORMAT(A.EQ_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME,\
				A.EQ_ORDER_NO AS ORDER_NUMBER, A.EQ_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, A.EQ_TRD_EXCH_TRADE_NO AS TRADE_NUMBER,\
				A.EQ_EXCH_ID AS EXCH, (CASE A.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, 'E' AS SEGMENT,\
				(CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE, \
				A.EQ_SYMBOL AS SYMBOL, \
				(CASE A.EQ_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'\
				 WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE A.EQ_PRODUCT_ID END) AS PRODUCT, A.EQ_LAST_TRADE_QTY AS QUANTITY, \
				IFNULL(A.EQ_TRD_TRADE_PRICE, 0) AS PRICE, ROUND((A.EQ_TRD_TRADE_PRICE * A.EQ_LAST_TRADE_QTY), 4) AS TRADE_VALUE, \
				A.EQ_SCRIP_CODE AS SECURITY_ID, A.EQ_PRODUCT_ID AS TRD_PRODUCT,\
				JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,\
				A.EQ_ENTITY_ID AS PLACEDBY,A.EQ_STRATEGY_ID AS STRATEGY_ID,A.EQ_LEG_NO AS LEGVALUE,A.EQ_PAN_NO AS PAN_NO,\
				A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,A.EQ_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
				A.EQ_SETTLOR AS SETTLOR,A.EQ_GTC_FLG AS GTC_FLG,A.EQ_ENCASH_FLG AS ENCASH_FLG,A.EQ_MKT_TYPE AS MKT_TYPE FROM EQ_ORDERS A \
				CROSS JOIN (SELECT @rn:=0) r WHERE A.EQ_CLIENT_ID = ltrim(rtrim(\"%s\")) AND ((A.EQ_MSG_CODE = '2222') AND (A.EQ_TRD_STATUS = 'C')\
			) UNION ALL SELECT B.DRV_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r, \
				B.DRV_SCRIP_CODE AS SEM_SMST_SECURITY_ID, DATE_FORMAT(B.DRV_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME, \
				B.DRV_ORDER_NO AS ORDER_NUMBER, B.DRV_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, B.DRV_TRD_EXCH_TRADE_NO AS TRADE_NUMBER, \
				B.DRV_EXCH_ID AS EXCH, (CASE B.DRV_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, \
				B.DRV_SEGMENT AS SEGMENT, \
				(CASE B.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\
				B.DRV_SYMBOL AS SYMBOL, \
				(CASE B.DRV_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'\
				 WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE B.DRV_PRODUCT_ID END) AS PRODUCT, B.DRV_TRD_TRADE_QTY AS QTY, \
				IFNULL(B.DRV_TRD_TRADE_PRICE, 0) AS PRICE, (CASE WHEN (B.DRV_SEGMENT = 'C') \
						THEN ROUND(((B.DRV_TRD_TRADE_PRICE * B.DRV_TRD_TRADE_QTY) * 1000), 4) \
						ELSE ROUND((B.DRV_TRD_TRADE_PRICE * B.DRV_TRD_TRADE_QTY), 2) END) AS TRADE_VALUE, B.DRV_SCRIP_CODE AS SECURITY_ID, \
				B.DRV_PRODUCT_ID AS TRD_PRODUCT,JULIDATE(B.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
				B.DRV_ENTITY_ID AS PLACEDBY,B.DRV_STRATEGY_ID AS STRATEGY_ID,B.DRV_LEG_NO AS LEGVALUE,B.DRV_PAN_NO AS PAN_NO,\
				B.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,B.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,B.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
				B.DRV_SETTLOR AS SETTLOR,B.DRV_GTC_FLG AS GTC_FLG,B.DRV_ENCASH_FLG AS ENCASH_FLG,B.DRV_MKT_TYPE  AS MKT_TYPE FROM DRV_ORDERS B \
				CROSS JOIN (SELECT @rn:=0) r \
				WHERE B.DRV_CLIENT_ID = ltrim(rtrim(\"%s\")) AND ((B.DRV_MSG_CODE = '2222') AND (B.DRV_TRD_STATUS = 'C') AND B.DRV_CF_FLAG <> -1)\
				UNION ALL SELECT C.COMM_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r, C.COMM_SCRIP_CODE AS SEM_SMST_SECURITY_ID, \
				DATE_FORMAT(C.COMM_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME, C.COMM_ORDER_NO AS ORDER_NUMBER, \
				C.COMM_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, C.COMM_TRD_EXCH_TRADE_NO AS TRADE_NUMBER, C.COMM_EXCH_ID AS EXCH, \
				(CASE C.COMM_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, 'M' AS SEGMENT, \
				(CASE C.COMM_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE, \
				C.COMM_SYMBOL AS SYMBOL, \
				(CASE C.COMM_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'\
				 WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE C.COMM_PRODUCT_ID END) AS PRODUCT, C.COMM_TRD_TRADE_QTY AS QTY, \
				IFNULL(C.COMM_TRD_TRADE_PRICE, 0) AS PRICE, \
				ROUND(((C.COMM_TRD_TRADE_PRICE * C.COMM_TRD_TRADE_QTY) * C.COMM_MULTIPLIER), 2) AS TRADE_VALUE,\
				C.COMM_SCRIP_CODE AS SECURITY_ID,C.COMM_PRODUCT_ID AS TRD_PRODUCT,\
				JULIDATE(C.COMM_INTERNAL_ENTRY_DATE) AS JDATE,\
				C.COMM_ENTITY_ID AS PLACEDBY, C.COMM_STRATEGY_ID AS STRATEGY_ID,C.COMM_LEG_NO AS LEGVALUE,\
				C.COMM_PAN_NO AS PAN_NO,C.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,C.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG, \
				C.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,C.COMM_SETTLOR AS SETTLOR,C.COMM_GTC_FLG AS GTC_FLG,\
				C.COMM_ENCASH_FLG AS ENCASH_FLG,C.COMM_MKT_TYPE AS MKT_TYPE FROM COMM_ORDERS C \
				CROSS JOIN (SELECT @rn:=0) r WHERE C.COMM_CLIENT_ID = ltrim(rtrim(\"%s\")) AND ((C.COMM_MSG_CODE = '2222')\
				AND (C.COMM_TRD_STATUS = 'C') AND C.COMM_CF_FLAG <> -1)) tradebook ORDER BY ORDER_DATE_TIME DESC; ",\
				sClientId,sClientId,sClientId);

	printf("sTrdBook :%s:",sTrdBook);

	if(mysql_query(DBQueries,sTrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in Trade BOOK Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/

	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	pTradeBookHdrResp.IntRespHeader.cSource = pViewTradeBookReq->ReqHeader.cSource ;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);

	logDebug2(" pTradeBookHdrResp.IntRespHeader.iMsgLength :%d:",pTradeBookHdrResp.IntRespHeader.iMsgLength);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.iMsgLength :%d:",pTradeBookHdrResp.IntRespHeader.iMsgLength);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.iMsgCode	:%d:",pTradeBookHdrResp.IntRespHeader.iMsgCode);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.iUserId :%llu:",pTradeBookHdrResp.IntRespHeader.iUserId);
	logDebug2(" pTradeBookHdrResp.IntRespHeader.cSource :%c:",pTradeBookHdrResp.IntRespHeader.cSource);

	logDebug2("pViewTradeBookReq->ReqHeader.iUserId = %llu",pViewTradeBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewTradeBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}



	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pTradeBookResp,'\0',sizeof(struct VIEW_TRADE_BOOK_RESP) );
		pTradeBookResp.IntRespHeader.iSeqNo = 0;
		pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
		pTradeBookResp.IntRespHeader.iErrorId = 0;
		pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_RESP;
		pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
		pTradeBookResp.IntRespHeader.cSource = pViewTradeBookReq->ReqHeader.cSource ;
		//                              pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;
		//                              logDebug2(" Is this core :%c: :%s:",Row[12][0],Row[11]);
		//pTradeBookResp.IntRespHeader.cSegment = Row[12][0];
		//strncpy(pTradeBookResp.IntRespHeader.sExcgId,Row[11],EXCHANGE_LEN);


		if(iTempNoOfRec <= 1)
		{
			pTradeBookResp.cMsgType = 'T';
		}
		else
		{
			pTradeBookResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			logInfo(" Here is j :%d:",j);

			if((Row = mysql_fetch_row(Res)))
			{

				strncpy(pTradeBookResp.subTradeBook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,Row[1] ,SECURITY_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sDatetime,Row[2],DATE_LENGTH);	
				pTradeBookResp.subTradeBook[j].fOrderNo = atof(Row[3]);
				strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,Row[4],BSE_EXCH_ORDER_NO_LEN);
				pTradeBookResp.subTradeBook[j].fTradeNo = atof(Row[5]);
				strncpy(pTradeBookResp.subTradeBook[j].sExcgId,Row[6],EXCHANGE_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,Row[7],5);
				pTradeBookResp.subTradeBook[j].cSegment = Row[8][0];
				strncpy(pTradeBookResp.subTradeBook[j].sOrderType,Row[9],8);
				strncpy(pTradeBookResp.subTradeBook[j].sProduct,Row[10],10);
				pTradeBookResp.subTradeBook[j].fTradeQty = atof(Row[11]);
				pTradeBookResp.subTradeBook[j].fTradePrice = atof(Row[12]);
				pTradeBookResp.subTradeBook[j].fTradeVal = atof(Row[13]);
				pTradeBookResp.subTradeBook[j].iDateTime = atol(Row[14]);
				strncpy(pTradeBookResp.subTradeBook[j].sEntityId,Row[15],ENTITY_ID_LEN);
				pTradeBookResp.subTradeBook[j].iStrategyId = atoi (Row[16]);
				pTradeBookResp.subTradeBook[j].iLegValue = atoi(Row[17]);
				strncpy(pTradeBookResp.subTradeBook[j].sPanID,Row[18],INT_PAN_LEN);
				pTradeBookResp.subTradeBook[j].cParticipantType = Row[19][0];
				pTradeBookResp.subTradeBook[j].cMarkProFlag = Row[20][0];
				pTradeBookResp.subTradeBook[j].fMarkProVal = atof(Row[21]);
				strncpy(pTradeBookResp.subTradeBook[j].sSettlor,Row[22],SETTLOR_LEN);
				pTradeBookResp.subTradeBook[j].cGTCFlag =  Row[23][0];
				pTradeBookResp.subTradeBook[j].cEncashFlag =  Row[24][0];

				strncpy(pTradeBookResp.subTradeBook[j].sMktType,Row[25],MKT_TYPE_LEN);				

				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%llu:",pTradeBookResp.IntRespHeader.iUserId);
				logDebug2(" pTradeBookResp.IntRespHeader.cSource:%c:",pTradeBookResp.IntRespHeader.cSource);
				logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
				logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
				logDebug2("pTradeBookResp.subTradeBook[j].sClientId = %s",pTradeBookResp.subTradeBook[j].sClientId);
				logDebug2("pTradeBookResp.subTradeBook[j].sSecurityID = %s",pTradeBookResp.subTradeBook[j].sSecurityID);
				logDebug2("pTradeBookResp.subTradeBook[j].sDatetime = %s",pTradeBookResp.subTradeBook[j].sDatetime);
				logDebug2("pTradeBookResp.subTradeBook[j].fOrderNo = %lf",pTradeBookResp.subTradeBook[j].fOrderNo);
				logDebug2("pTradeBookResp.subTradeBook[j].sExchOrderNumber = %s",pTradeBookResp.subTradeBook[j].sExchOrderNumber);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradeNo = %lf",pTradeBookResp.subTradeBook[j].fTradeNo);
				logDebug2("pTradeBookResp.subTradeBook[j].sExcgId = %s",pTradeBookResp.subTradeBook[j].sExcgId);
				logDebug2("pTradeBookResp.subTradeBook[j].sBuySellInd = %s",pTradeBookResp.subTradeBook[j].sBuySellInd);
				logDebug2("pTradeBookResp.subTradeBook[j].cSegment = %c",pTradeBookResp.subTradeBook[j].cSegment);
				logDebug2("pTradeBookResp.subTradeBook[j].sOrderType = %s",pTradeBookResp.subTradeBook[j].sOrderType);
				logDebug2("pTradeBookResp.subTradeBook[j].sProduct = %s",pTradeBookResp.subTradeBook[j].sProduct);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradeQty = %d",pTradeBookResp.subTradeBook[j].fTradeQty);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradePrice = %lf",pTradeBookResp.subTradeBook[j].fTradePrice);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradeVal = %lf",pTradeBookResp.subTradeBook[j].fTradeVal);
				logDebug2("pTradeBookResp.subTradeBook[j].iDateTime = %d",pTradeBookResp.subTradeBook[j].iDateTime);
				logDebug2("pTradeBookResp.subTradeBook[j].sEntityId = %s",pTradeBookResp.subTradeBook[j].sEntityId);
				logDebug2("pTradeBookResp.subTradeBook[j].iStrategyId = %d",pTradeBookResp.subTradeBook[j].iStrategyId);
				logDebug2("pTradeBookResp.subTradeBook[j].iLegValue = %d",pTradeBookResp.subTradeBook[j].iLegValue);
				logDebug2("pTradeBookResp.subTradeBook[%d].sPanID = %s",j,pTradeBookResp.subTradeBook[j].sPanID);
				logDebug2("pTradeBookResp.subTradeBook[%d].cParticipantType = %c",j,pTradeBookResp.subTradeBook[j].cParticipantType);
				logDebug2("pTradeBookResp.subTradeBook[%d].cMarkProFlag = %c",j,pTradeBookResp.subTradeBook[j].cMarkProFlag);
				logDebug2("pTradeBookResp.subTradeBook[%d].fMarkProVal = %lf",j,pTradeBookResp.subTradeBook[j].fMarkProVal);
				logDebug2("pTradeBookResp.subTradeBook[%d].sSettlor = %s",j,pTradeBookResp.subTradeBook[j].sSettlor);
				logDebug2("pTradeBookResp.subTradeBook[%d].cGTCFlag = %c",j,pTradeBookResp.subTradeBook[j].cGTCFlag);
				logDebug2("pTradeBookResp.subTradeBook[%d].cEncashFlag = %c",j,pTradeBookResp.subTradeBook[j].cEncashFlag);
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/

	}
	free(sTrdBook);	
	logTimestamp("Exit : fTradeBook");
	return TRUE;

}/************** END of fTradeBook ****/
BOOL 	fClientHoldings(CHAR *RcvMsg)
{
	logTimestamp("Entry : fClientHoldings");

	struct VIEW_HOLDING_QUERY_REQ	*pViewClientHoldingReq;
	struct VIEW_CLIENT_HOLDINGS_RESP     pClientHoldingResp;
	struct VIEW_COMMON_HDR_RESP     pClientHoldingHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	//        CHAR *sCliHlding = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR sCliHlding [DOUBLE_MAX_QUERY_SIZE];


	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR    sWhere_Clause[QUERY_SIZE];
	CHAR    sViewHld      [QUERY_SIZE];
	CHAR	sSymbol	[DB_SYM_LEN];

	memset(sWhere_Clause,'\0',QUERY_SIZE);
	memset(sViewHld,'\0',QUERY_SIZE);
	memset(sClientId,'\0',CLIENT_ID_LEN);
	memset(sEntityId,'\0',ENTITY_ID_LEN);
	memset(sCliHlding,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sSymbol,'\0',DB_SYM_LEN);	
	LONG32		iNoOfRec=0;
	LONG32		iTempNoOfRec = 0;
	DOUBLE64        fNoOfRec = 0.00;
	LONG32          iNoOfPkt = 0;

	pViewClientHoldingReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	logDebug2("pViewClientHoldingReq->sClientId = %s",pViewClientHoldingReq->sClientId);

	sprintf(sCliHlding,"SELECT    CAST(@rn:=@rn + 1 AS UNSIGNED) ROW_NUM, hld.*   FROM   (SELECT    XX.*,   IFNULL(ROUND(ELW.L1_LTP, 2), 0) AS ltp,   TRIM(ROUND(((IFNULL(XX.QTY, 0) - IFNULL(XX.QTY_UTILIZED, 0)) * IFNULL(ELW.L1_LTP, 0)), 2)) AS market_value   FROM   (SELECT    RCSL.CLIENT_ID AS client_id,   RCSL.EXCH_ID AS exch_id,   RCSL.ISIN_CODE AS isin_code,   RCSL.SECURITY_SOURCE_TYPE AS security_source_type,   RCSL.QTY AS qty,   IFNULL(RCSL.QTY_UTILIZED, 0) AS qty_utilized,   (IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED, 0)) AS rem_qty,   (IFNULL(RCSL.NSE_SCRIP_CODE, 'NA')) AS nse_scrip_code,   (IFNULL(RCSL.BSE_SCRIP_CODE, 'NA')) AS bse_scrip_code,   (IFNULL(RCSL.NSE_SYMBOL, 'NA')) AS nse_symbol,   (IFNULL(RCSL.BSE_SYMBOL, 'NA')) AS bse_symbol,   IFNULL(RCSL.COST_PRICE, 0) AS cost_price,   (CASE RCSL.COLLATERAL_FLAG   WHEN 'Y' THEN IFNULL(ROUND((IFNULL(RCSL.QTY, 0) - IFNULL(RCSL.QTY_UTILIZED_TRADED, 0)) * (IFNULL(LWA.L1_LTP, 0)) * ((100 - IFNULL(HM.HM_HAIRCUT_PERC, 100)) / 100), 2), 0)   ELSE 0   END) AS COLLATERAL   FROM   RMS_CLIENT_SECURITY_LIMIT RCSL   LEFT JOIN HAIRCUT_MASTER HM ON RCSL.ISIN_CODE = HM.HM_ISIN    LEFT JOIN SECURITY_MASTER SM ON RCSL.ISIN_CODE = SM.SM_ISIN_CODE   LEFT JOIN EQ_L1_WATCH LWA ON SM.SM_SCRIP_CODE = LWA.L1_SCRIP_CODE   WHERE   1 = 1 AND client_id LIKE LTRIM(RTRIM('%s'))   AND (CASE RCSL.EXCH_ID   WHEN 'ALL' THEN 'NSE'   ELSE RCSL.EXCH_ID   END) = SM.SM_EXCHANGE   AND SM.SM_STATUS = 'A'   AND SM.SM_EXCH_STATUS = 'A') AS XX   LEFT OUTER JOIN EQ_L1_WATCH ELW ON (CASE   WHEN XX.EXCH_ID = 'NSE' THEN XX.NSE_SCRIP_CODE   WHEN XX.EXCH_ID = 'BSE' THEN XX.BSE_SCRIP_CODE   WHEN XX.EXCH_ID = 'ALL' THEN XX.NSE_SCRIP_CODE   END = ELW.L1_SCRIP_CODE)   ORDER BY XX.CLIENT_ID) AS hld   CROSS JOIN   (SELECT @rn:=0) R;",pViewClientHoldingReq->sClientId);

	logDebug2(" fClientHoldings :%s:",sCliHlding);

	if(mysql_query(DBQueries,sCliHlding) != SUCCESS)
	{
		logSqlFatal("ERROR in client Holding Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);


	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/


	pClientHoldingHdrResp.IntRespHeader.iSeqNo = 0;
	pClientHoldingHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pClientHoldingHdrResp.IntRespHeader.iErrorId = 0;
	pClientHoldingHdrResp.IntRespHeader.iMsgCode = TC_INT_CLINET_HOLDING_HEADER_RESP;
	pClientHoldingHdrResp.IntRespHeader.iUserId = pViewClientHoldingReq->ReqHeader.iUserId;
	pClientHoldingHdrResp.IntRespHeader.cSource = pViewClientHoldingReq->ReqHeader.cSource ;

	pClientHoldingHdrResp.cMsgType = 'H';
	pClientHoldingHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pClientHoldingHdrResp.cMsgType:%c:,pClientHoldingHdrResp.iNoofRec:%d:",pClientHoldingHdrResp.cMsgType,pClientHoldingHdrResp.iNoofRec);
	logDebug2("pViewClientHoldingReq->ReqHeader.iUserId = %llu",pViewClientHoldingReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewClientHoldingReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pClientHoldingHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pClientHoldingResp,'\0',sizeof(struct VIEW_CLIENT_HOLDINGS_RESP));			
		pClientHoldingResp.IntRespHeader.iSeqNo = 0;
		pClientHoldingResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_HOLDINGS_RESP);
		pClientHoldingResp.IntRespHeader.iErrorId = 0;
		pClientHoldingResp.IntRespHeader.iMsgCode = TC_INT_CLINET_HOLDING_RESP;
		pClientHoldingResp.IntRespHeader.iUserId = pViewClientHoldingReq->ReqHeader.iUserId;
		pClientHoldingResp.IntRespHeader.cSource = pViewClientHoldingReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pClientHoldingResp.cMsgType = 'T';
		}
		else
		{
			pClientHoldingResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(pClientHoldingResp.subClientHoldings[j].sClientId,Row[1],CLIENT_ID_LEN);	
				strncpy(pClientHoldingResp.subClientHoldings[j].sExcgId,Row[2],EXCHANGE_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sISINCode,Row[3],ISINCODE_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sSecuritySource,Row[4],SEC_SOURCE_LEN);

				pClientHoldingResp.subClientHoldings[j].iQty 		= atoi(Row[5]);
				pClientHoldingResp.subClientHoldings[j].iQtyUtilized 	= atoi(Row[6]);
				pClientHoldingResp.subClientHoldings[j].iRemQty 	= atoi(Row[7]);

				strncpy(pClientHoldingResp.subClientHoldings[j].sNseSecurityID,Row[8],SECURITY_ID_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sBseSecurityID,Row[9],SECURITY_ID_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sNseSymbol,Row[10],SECURITY_SYM_LEN);
				strncpy(pClientHoldingResp.subClientHoldings[j].sBseSymbol,Row[11],SECURITY_SYM_LEN);			

				pClientHoldingResp.subClientHoldings[j].fCostPrice 	= atof(Row[12]);

				pClientHoldingResp.subClientHoldings[j].fCollateral 	= atof(Row[13]);

				pClientHoldingResp.subClientHoldings[j].fLtp 		= atof(Row[14]);
				pClientHoldingResp.subClientHoldings[j].fMarketValue 	= atof(Row[15]);
				//	strncpy(pClientHoldingResp.subClientHoldings[j].sNseSeries ,Row[14],HLD_SERIES_LEN);
				//      strncpy(pClientHoldingResp.subClientHoldings[j].sBseSeries,Row[15],HLD_SERIES_LEN);

				logDebug2("-------------------Start Printing Record no = %d ------------------",j);	
				logDebug2("pClientHoldingResp.IntRespHeader.iMsgLength 	= %d",pClientHoldingResp.IntRespHeader.iMsgLength);
				logDebug2("pClientHoldingResp.IntRespHeader.iMsgCode 	= %d",pClientHoldingResp.IntRespHeader.iMsgCode);
				logDebug2("pClientHoldingResp.IntRespHeader.iUserId 	= %llu",pClientHoldingResp.IntRespHeader.iUserId);
				logDebug2("pClientHoldingResp.IntRespHeader.cSource 	= %c",pClientHoldingResp.IntRespHeader.cSource);
				logDebug2("pClientHoldingResp.cMsgType 			= %c",pClientHoldingResp.cMsgType);

				logDebug2("pClientHoldingResp.subClientHoldings[%d].sClientId 	= %s",j,pClientHoldingResp.subClientHoldings[j].sClientId);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sExcgId 	= %s",j,pClientHoldingResp.subClientHoldings[j].sExcgId);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sISINCode 	= %s",j,pClientHoldingResp.subClientHoldings[j].sISINCode);
				logDebug2("pClientHolResp.subClientHold[%d].sSecuritySource	= %s",j,pClientHoldingResp.subClientHoldings[j].sSecuritySource);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].iQty 	= %d",j,pClientHoldingResp.subClientHoldings[j].iQty);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].iQtyUtilized= %d",j,pClientHoldingResp.subClientHoldings[j].iQtyUtilized);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].iRemQty 	= %d",j,pClientHoldingResp.subClientHoldings[j].iRemQty);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].fCostPrice 	= %lf",j,pClientHoldingResp.subClientHoldings[j].fCostPrice);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].fLtp 	= %lf",j,pClientHoldingResp.subClientHoldings[j].fLtp);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].fMarketValue= %lf",j,pClientHoldingResp.subClientHoldings[j].fMarketValue);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sNseSecurityID = %s",j,pClientHoldingResp.subClientHoldings[j].sNseSecurityID);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sBseSecurityID = %s",j,pClientHoldingResp.subClientHoldings[j].sBseSecurityID);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sNseSymbol 	= %s",j,pClientHoldingResp.subClientHoldings[j].sNseSymbol);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sBseSymbol 	= %s",j,pClientHoldingResp.subClientHoldings[j].sBseSymbol);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].fCollateral	= %lf",j,pClientHoldingResp.subClientHoldings[j].fCollateral);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sNseSeries  = %s",j,pClientHoldingResp.subClientHoldings[j].sNseSeries);
				logDebug2("pClientHoldingResp.subClientHoldings[%d].sBseSeries  = %s",j,pClientHoldingResp.subClientHoldings[j].sBseSeries);

				logDebug2("-------------------END------------------",j);	

			}


		}


		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pClientHoldingResp,sizeof(struct VIEW_CLIENT_HOLDINGS_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
		usleep(5000);
	}
	return TRUE;

}/** End of View Client Holdings***/
/**/
BOOL 	fNetPositionDetail(CHAR *RcvMsg)
{
	logTimestamp("Entry : fNetPositionDetail");
	struct VIEW_NET_POSITION_DATA_DETAIL *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP     pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP     pTradeBookHdrResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sNetPostion = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sReqSecurityID[SECURITY_ID_LEN];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR         sReqExcgId[EXCHANGE_LEN];
	SHORT         	iReqExcgId;
	CHAR            Segment;
	CHAR            cReqSegment;
	CHAR            cProductID;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;

	pViewTradeBookReq = (struct VIEW_NET_POSITION_DATA_DETAIL *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->commonquery.sClientId,CLIENT_ID_LEN);
	//	iReqExcgId = pViewTradeBookReq->commonquery.ReqHeader.iExchange;
	strncpy(sReqExcgId ,pViewTradeBookReq->commonquery.ReqHeader.sExcgId,EXCHANGE_LEN);
	strncpy(sReqSecurityID ,pViewTradeBookReq->sSecurityID,SECURITY_ID_LEN);
	cProductID = pViewTradeBookReq->cProductID;

	/***
	  if(iReqExcgId == 1)
	  {
	  strncpy(sReqExcgId ,"NSE",EXCHANGE_LEN);
	  }
	  else if(iReqExcgId == 2)
	  {
	  strncpy(sReqExcgId ,"BSE",EXCHANGE_LEN);
	  }
	  else if(iReqExcgId == 3)
	  {
	  strncpy(sReqExcgId ,"MCX",EXCHANGE_LEN);
	  }
	 ***/	

	logDebug2(" pViewTradeBookReq->sSecurityID :%s:pViewTradeBookReq->cProductID:%c: sClientId:%s: sReqExcgId :%s: sReqSecurityID.len ", pViewTradeBookReq->sSecurityID,pViewTradeBookReq->cProductID,sClientId ,sReqExcgId );

	/****
	  SELECT  count(1)
INTO :iNoOfRec
from TRADEBOOK
WHERE CLIENT_ID = ltrim(rtrim(:sClientId))
AND EXCHANGE = ltrim(rtrim(:sReqExcgId))
AND SEM_SMST_SECURITY_ID = ltrim(rtrim(:sReqSecurityID))
AND TRD_PRODUCT = :cProductID;
	 *********/

	logDebug2(" sClientId :%s: sReqExcgId :%s: sReqSecurityID:%s: cProductID:%c:",sClientId ,sReqExcgId,sReqSecurityID ,cProductID);

	sprintf(sNetPostion, "SELECT * FROM(SELECT A.EQ_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r,\
		A.EQ_SCRIP_CODE AS SEM_SMST_SECURITY_ID, DATE_FORMAT(A.EQ_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME,\
			A.EQ_ORDER_NO AS ORDER_NUMBER, A.EQ_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, A.EQ_TRD_EXCH_TRADE_NO AS TRADE_NUMBER,\
			A.EQ_EXCH_ID AS EXCH, (CASE A.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, 'E' AS SEGMENT,\
			(CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE, \
			A.EQ_SYMBOL AS SYMBOL, \
			(CASE A.EQ_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'\
			 WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' ELSE A.EQ_PRODUCT_ID END) AS PRODUCT, A.EQ_LAST_TRADE_QTY AS QUANTITY, \
			IFNULL(A.EQ_TRD_TRADE_PRICE, 0) AS PRICE, ROUND((A.EQ_TRD_TRADE_PRICE * A.EQ_LAST_TRADE_QTY), 4) AS TRADE_VALUE, \
			A.EQ_SCRIP_CODE AS SECURITY_ID, A.EQ_PRODUCT_ID AS TRD_PRODUCT,\
			JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JULIDATE(ORDER_DATE_TIME),\
			A.EQ_ENTITY_ID AS PLACEDBY,A.EQ_STRATEGY_ID AS STRATEGY_ID,A.EQ_LEG_NO AS LEGVALUE\
			FROM EQ_ORDERS A \
			CROSS JOIN (SELECT @rn:=0) r WHERE A.EQ_CLIENT_ID = ltrim(rtrim(\"%s\")) AND ((A.EQ_MSG_CODE = '2222') AND (A.EQ_TRD_STATUS = 'C')\
		AND (A.EQ_ALGO_ORDER_NO <> -(1))) UNION ALL SELECT B.DRV_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r, \
			B.DRV_SCRIP_CODE AS SEM_SMST_SECURITY_ID, DATE_FORMAT(B.DRV_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME, \
			B.DRV_ORDER_NO AS ORDER_NUMBER, B.DRV_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, B.DRV_TRD_EXCH_TRADE_NO AS TRADE_NUMBER, \
			B.DRV_EXCH_ID AS EXCH, (CASE B.DRV_BUY_SELL_IND WHEN 'B' THEN 'BUY' WHEN 'S' THEN 'SELL' END) AS BUY/SELL, \
			B.DRV_SEGMENT AS SEGMENT, \
			(CASE B.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\
			B.DRV_SYMBOL AS SYMBOL, \
			(CASE B.DRV_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'\
			 WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' ELSE B.DRV_PRODUCT_ID END) AS PRODUCT, B.DRV_TRD_TRADE_QTY AS QTY, \
			IFNULL(B.DRV_TRD_TRADE_PRICE, 0) AS PRICE, (CASE WHEN (B.DRV_SEGMENT = 'C') \
					THEN ROUND(((B.DRV_TRD_TRADE_PRICE * B.DRV_TRD_TRADE_QTY) * 1000), 4) \
					ELSE ROUND((B.DRV_TRD_TRADE_PRICE * B.DRV_TRD_TRADE_QTY), 2) END) AS TRADE_VALUE, B.DRV_SCRIP_CODE AS SECURITY_ID, \
			B.DRV_PRODUCT_ID AS TRD_PRODUCT,JULIDATE(B.DRV_INTERNAL_ENTRY_DATE) AS JULIDATE(ORDER_DATE_TIME),\
			B.DRV_ENTITY_ID AS PLACEDBY,B.DRV_STRATEGY_ID AS STRATEGY_ID,B.DRV_LEG_NO AS LEGVALUE\
			FROM DRV_ORDERS B \
			CROSS JOIN (SELECT @rn:=0) r \
			WHERE B.DRV_CLIENT_ID = ltrim(rtrim(\"%s\")) AND ((B.DRV_MSG_CODE = '2222') AND (B.DRV_TRD_STATUS = 'C') \
			AND (B.DRV_OMS_ALGO_ORD_NO <> -(1)))\
			UNION ALL SELECT C.COMM_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r, C.COMM_SCRIP_CODE AS SEM_SMST_SECURITY_ID, \
			DATE_FORMAT(C.COMM_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME, C.COMM_ORDER_NO AS ORDER_NUMBER, \
			C.COMM_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, C.COMM_TRD_EXCH_TRADE_NO AS TRADE_NUMBER, C.COMM_EXCH_ID AS EXCH, \
			(CASE C.COMM_BUY_SELL_IND WHEN 'B' THEN 'BUY' WHEN 'S' THEN 'SELL' END) AS BUY/SELL, 'C' AS SEGMENT, \
			(CASE C.COMM_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE, \
			C.COMM_SYMBOL AS SYMBOL, \
			(CASE C.COMM_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'\
			 WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' ELSE C.COMM_PRODUCT_ID END) AS PRODUCT, C.COMM_TRD_TRADE_QTY AS QTY, \
			IFNULL(C.COMM_TRD_TRADE_PRICE, 0) AS PRICE, \
			ROUND(((C.COMM_TRD_TRADE_PRICE * C.COMM_TRD_TRADE_QTY) * C.COMM_LOT_SIZE), 2) AS TRADE_VALUE,\
			C.COMM_SCRIP_CODE AS SECURITY_ID,C.COMM_PRODUCT_ID AS TRD_PRODUCT,\
			JULIDATE(C.COMM_INTERNAL_ENTRY_DATE) AS JULIDATE(ORDER_DATE_TIME),\
			C.COMM_ENTITY_ID AS PLACEDBY, C.COMM_STRATEGY_ID AS STRATEGY_ID,C.COMM_LEG_NO AS LEGVALUE\
			FROM COMM_ORDERS C \
			CROSS JOIN (SELECT @rn:=0) r WHERE C.COMM_CLIENT_ID = ltrim(rtrim(\"%s\")) AND ((C.COMM_MSG_CODE = '2222')\
			AND (C.COMM_TRD_STATUS = 'C') AND (C.COMM_OMS_ALGO_ORDER_NO <> -(1)))) tradebook \
			WHERE EXCH = ltrim(rtrim(\"%s\")) AND SEM_SMST_SECURITY_ID = ltrim(rtrim(\"%s\")) AND TRD_PRODUCT= \'%c\' \
			ORDER BY ORDER_DATE_TIME DESC;",sClientId,sClientId,sClientId,sReqExcgId,sReqSecurityID,cProductID);

	logDebug2(" sNetPostion :%s:",sNetPostion);

	if(mysql_query(DBQueries,sNetPostion) != SUCCESS)
	{
		logSqlFatal("ERROR IN Net Position Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_NETPOS_DTL_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->commonquery.ReqHeader.iUserId;
	pTradeBookHdrResp.IntRespHeader.cSource = pViewTradeBookReq->commonquery.ReqHeader.cSource ;
	//                pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->commonquery.ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);

	logDebug2("pViewTradeBookReq->commonquery.ReqHeader.iUserId = %llu",pViewTradeBookReq->commonquery.ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewTradeBookReq->commonquery.ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				memset(&pTradeBookResp,'\0',sizeof(struct VIEW_TRADE_BOOK_RESP));
				pTradeBookResp.IntRespHeader.iSeqNo = 0;
				pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
				pTradeBookResp.IntRespHeader.iErrorId = 0;
				pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_NETPOS_DTL_RESP;
				pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->commonquery.ReqHeader.iUserId;
				pTradeBookResp.IntRespHeader.cSource = pViewTradeBookReq->commonquery.ReqHeader.cSource;


				if(iTempNoOfRec <= 1)
				{
					pTradeBookResp.cMsgType = 'T';
				}
				else
				{
					pTradeBookResp.cMsgType = 'D';
				}	


				pTradeBookResp.IntRespHeader.cSegment = Row[12][0];
				strncpy(pTradeBookResp.IntRespHeader.sExcgId,Row[11],EXCHANGE_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,Row[2] ,SECURITY_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sDatetime,Row[3],DATE_LENGTH);
				pTradeBookResp.subTradeBook[j].fOrderNo = atof(Row[4]);
				strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,Row[5],BSE_EXCH_ORDER_NO_LEN);
				pTradeBookResp.subTradeBook[j].fTradeNo = atof(Row[6]);
				strncpy(pTradeBookResp.subTradeBook[j].sExcgId,Row[7],EXCHANGE_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,Row[8],5);
				pTradeBookResp.subTradeBook[j].cSegment = Row[9][0];
				strncpy(pTradeBookResp.subTradeBook[j].sOrderType,Row[10],8);
				strncpy(pTradeBookResp.subTradeBook[j].sProduct,Row[12],10);
				pTradeBookResp.subTradeBook[j].fTradeQty = atof(Row[13]);
				pTradeBookResp.subTradeBook[j].fTradePrice = atof(Row[14]);
				pTradeBookResp.subTradeBook[j].fTradeVal = atof(Row[15]);
				pTradeBookResp.subTradeBook[j].iDateTime = atol(Row[18]);
				strncpy(pTradeBookResp.subTradeBook[j].sEntityId,Row[19],ENTITY_ID_LEN);
				pTradeBookResp.subTradeBook[j].iStrategyId = atoi (Row[20]);
				pTradeBookResp.subTradeBook[j].iLegValue = atoi(Row[21]);

				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%llu:",pTradeBookResp.IntRespHeader.iUserId);
				//                		logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
				logDebug2(" pTradeBookResp.IntRespHeader.cSource:%c:",pTradeBookResp.IntRespHeader.cSource);
				logDebug2(" pTradeBookResp.IntRespHeader.sExcgId :%s: strlen(pTradeBookResp.IntRespHeader.sExcgId):%d:",pTradeBookResp.IntRespHeader.sExcgId,strlen(pTradeBookResp.IntRespHeader.sExcgId));
				logInfo(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);

				logDebug2("pTradeBookResp.subTradeBook[j].sClientId = %s",pTradeBookResp.subTradeBook[j].sClientId);
				logDebug2("pTradeBookResp.subTradeBook[j].sSecurityID = %s",pTradeBookResp.subTradeBook[j].sSecurityID);
				logDebug2("pTradeBookResp.subTradeBook[j].sDatetime = %s",pTradeBookResp.subTradeBook[j].sDatetime);
				logDebug2("pTradeBookResp.subTradeBook[j].fOrderNo = %lf",pTradeBookResp.subTradeBook[j].fOrderNo);
				logDebug2("pTradeBookResp.subTradeBook[j].sExchOrderNumber = %s",pTradeBookResp.subTradeBook[j].sExchOrderNumber);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradeNo = %lf",pTradeBookResp.subTradeBook[j].fTradeNo);
				logDebug2("pTradeBookResp.subTradeBook[j].sExcgId = %s",pTradeBookResp.subTradeBook[j].sExcgId);
				logDebug2("pTradeBookResp.subTradeBook[j].sBuySellInd = %s",pTradeBookResp.subTradeBook[j].sBuySellInd);
				logDebug2("pTradeBookResp.subTradeBook[j].cSegment = %c",pTradeBookResp.subTradeBook[j].cSegment);
				logDebug2("pTradeBookResp.subTradeBook[j].sOrderType = %s",pTradeBookResp.subTradeBook[j].sOrderType);
				logDebug2("pTradeBookResp.subTradeBook[j].sProduct = %s",pTradeBookResp.subTradeBook[j].sProduct);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradeQty = %d",pTradeBookResp.subTradeBook[j].fTradeQty);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradePrice = %lf",pTradeBookResp.subTradeBook[j].fTradePrice);
				logDebug2("pTradeBookResp.subTradeBook[j].fTradeVal = %lf",pTradeBookResp.subTradeBook[j].fTradeVal);
				logDebug2("pTradeBookResp.subTradeBook[j].iDateTime = %d",pTradeBookResp.subTradeBook[j].iDateTime);
				logDebug2("pTradeBookResp.subTradeBook[j].sEntityId = %s",pTradeBookResp.subTradeBook[j].sEntityId);
				logDebug2("pTradeBookResp.subTradeBook[j].iStrategyId = %d",pTradeBookResp.subTradeBook[j].iStrategyId);
				logDebug2("pTradeBookResp.subTradeBook[j].iLegValue = %d",pTradeBookResp.subTradeBook[j].iLegValue);
				/*
				   logDebug2(" pTradeBookResp.subTradeBook.fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
				   logDebug2(" pTradeBookResp.subTradeBook.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook.sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
				   logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
				   logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
				   logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
				   logDebug2(" pTradeBookResp.subTradeBook[j].fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);
				   logDebug2(" pTradeBookResp.subTradeBook[j].iDateTime :%d:",pTradeBookResp.subTradeBook[j].iDateTime);
				   logDebug2(" pTradeBookResp.subTradeBook[j].iLegValue:%d:",pTradeBookResp.subTradeBook[j].iLegValue);
				 */

			}
			iTempNoOfRec--;

		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		usleep(1000);

	}

	free(sNetPostion);
	logTimestamp("Exit : fNetPositionDetail");
	return TRUE;

}/** End of fNetPositionDetail **/

BOOL fDrvOrderBookDtls(CHAR *RcvMsg)
{
	logTimestamp("Entry : fDrvOrderBookDtls");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;

	LONG32 i=0,j=0;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR		*sDrvOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	DOUBLE64        fReqOrderNo;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR		cOrdValidity;	

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	fReqOrderNo = pViewOrderBookReq->fOrderNo;	

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,fReqOrderNo);

	sprintf(sDrvOrdBook,"SELECT  DRV_ORDER_NO,\
			DRV_SERIAL_NO,\
			DRV_MSG_CODE,\
			DRV_SCRIP_CODE,\
			DRV_VALIDITY,\
			DRV_PRO_CLIENT,\
			DRV_SOURCE_FLG,\
			DRV_ORIG_CLORDID,\
			DRV_TOTAL_QTY,\
			DRV_REM_QTY,\
			DRV_DISC_QTY,\
			DRV_DISC_REM_QTY,\
			DRV_ORDER_PRICE,\
			DRV_TRIGGER_PRICE,\
			DRV_TRD_TRADE_QTY,\
			DRV_TRD_TRADE_PRICE,\
			DRV_TOTAL_TRADED_QTY,\
			DRV_TRD_EXCH_TRADE_NO,\
			DRV_PRODUCT_ID,\
			DRV_EXCH_ORDER_NO,\
			IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
			DRV_ERROR_CODE,\
			DRV_CLIENT_ID,\
			DRV_BUY_SELL_IND,\
			DRV_EXCH_ID,\
			DRV_REASON_DESCRIPTION ,\
			DRV_ENTITY_ID ,\
			DRV_STRATEGY_ID ,\
			DRV_PRO_CLIENT ,\
			DRV_TRD_TRADE_PRICE ,\
			DRV_GOOD_TILL_DAYS, \
			IFNULL(DRV_PAN_NO,\"NA\"),\
			IFNULL(DRV_PARTICIPANT_TYPE,'N'),\
			IFNULL(DRV_MKT_PROTECT_FLG,'N')\
			FROM DRV_ORDERS\
			WHERE DRV_ORDER_NO = %lf\
			AND  DRV_LEG_NO = %d\
			ORDER BY DRV_ORDER_NO , DRV_SERIAL_NO desc ;",fReqOrderNo,pViewOrderBookReq->iLegNo);

	logDebug2(" sDrvOrdBook :%s: ",sDrvOrdBook);

	if(mysql_query(DBQueries,sDrvOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in DrvOrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	//	pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	logInfo(" I am in Derivative");	

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pOrderBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP));
		pOrderBookResp.IntRespHeader.iSeqNo = 0;
		pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);

		pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
		pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
		pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pOrderBookResp.cMsgType = 'T';
		}
		else
		{
			pOrderBookResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);


				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);
				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo	  =atoi(Row[17]);
				pOrderBookResp.suborderbookdtls[j].sProduct = Row[18][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

				if(strlen(Row[25])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				if(Row[23][0]== 'B')
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{

					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				//pOrderBookResp.suborderbookdtls[j].fTrdPrice    = atof(Row[29]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
				pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s:,ErrorID:%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);

				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				//logDebug2("pOrderBookResp.suborderbookdtls[j].fTrdPrice  :%f:",pOrderBookResp.suborderbookdtls[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
			}

		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		usleep(1000);
		iTempNoOfRec--;


	}

	logTimestamp("Exit : fDrvOrderBookDtls");
	return TRUE;


}/************** END of fDrvOrderBookDtls ****/
BOOL    fCOMMOrderBookDtls(CHAR *RcvMsg)
{
	logDebug2("Entry : fCOMMOrderBookDtls");

	struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ    *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_DETAIL_RESP              pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP                     pOrderBookHdrResp;

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;
	CHAR            *sCOMMOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

	logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,pViewOrderBookReq->fOrderNo);

	logDebug2("pViewOrderBookReq->iLegNo = %d",pViewOrderBookReq->iLegNo);

	sprintf(sCOMMOrdBook,"SELECT    COMM_ORDER_NO,\
			COMM_SERIAL_NO,\
			COMM_MSG_CODE,\
			COMM_SCRIP_CODE,\
			COMM_VALIDITY,\
			COMM_PRO_CLIENT,\
			COMM_SOURCE_FLG,\
			COMM_TOTAL_QTY,\
			COMM_REM_QTY,\
			COMM_DISC_QTY,\
			COMM_DISC_REM_QTY,\
			COMM_ORDER_PRICE,\
			COMM_TRIGGER_PRICE,\
			COMM_TRD_TRADE_QTY,\
			COMM_TRD_TRADE_PRICE,\
			COMM_TOTAL_TRADED_QTY,\
			COMM_TRD_EXCH_TRADE_NO,\
			COMM_PRODUCT_ID,\
			COMM_EXCH_ORDER_NO,\
			COMM_INTERNAL_ENTRY_DATE,\
			COMM_ERROR_CODE,\
			COMM_CLIENT_ID,\
			COMM_BUY_SELL_IND,\
			COMM_EXCH_ID,\
			COMM_REASON_DESCRIPTION ,\
			COMM_ENTITY_ID ,\
			COMM_STRATEGY_ID ,\
			COMM_PRO_CLIENT ,\
			COMM_TRD_TRADE_PRICE ,\
			COMM_GOOD_TILL_DAYS, \
			COMM_LEG_NO,\
			IFNULL(COMM_PAN_NO,\"NA\"),\
			IFNULL(COMM_PARTICIPANT_TYPE,'N'),\
			IFNULL(COM_MKT_PROTECT_FLG,'N'),\
			COMM_MKT_PROTECT_VAL,\
			COMM_GTC_FLG,\
			COMM_ENCASH_FLG \
			FROM COMM_ORDERS\
			WHERE COMM_ORDER_NO = %lf \
			AND COMM_LEG_NO = %d\
			ORDER BY COMM_ORDER_NO , COMM_SERIAL_NO desc ;",pViewOrderBookReq->fOrderNo,pViewOrderBookReq->iLegNo);
	logDebug2(" sCOMMOrdBook :%s: ",sCOMMOrdBook);

	if(mysql_query(DBQueries,sCOMMOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in COMMOrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ(iIntActiveToRelDirQ, (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d",iIntActiveToRelDirQ);
		return FALSE;
	}
	logInfo("I am in Commodity");
	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
				logDebug2("pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				//                      strncpy(pOrderBookResp.IntRespHeader.sExcgId,ExcgId ,EXCHANGE_LEN);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[24]);
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
				pOrderBookResp.IntRespHeader.cSource = Row[6][0];

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
				pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
				pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3] ,SECURITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
				pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

				if(atoi(Row[4]) == VALIDITY_DAY)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
				}
				else if(atoi(Row[4]) == VALIDITY_IOC)
				{
					pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
				}

				pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
				pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
				pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
				pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
				pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
				pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
				pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

				pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
				pOrderBookResp.suborderbookdtls[j].iExchTradeNo   = atoi(Row[16]);

				pOrderBookResp.suborderbookdtls[j].sProduct = atof(Row[17]);
				strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18] ,BSE_EXCH_ORDER_NO_LEN);

				strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_STRING_LENGTH);
				strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21] ,CLIENT_ID_LEN);

				if(Row[22][0]== 'B')
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
				}

				if(strlen(Row[24])!= 0 )
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
				}

				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
				pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
				pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
				pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);

				if(strlen(Row[31]) == 0)
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
				}

				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
				pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
				pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
				pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
				pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];


				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" pOrderBookResp.IntRespHeader.sExcgId :%s:",pOrderBookResp.IntRespHeader.sExcgId);
				logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
				logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
				logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);
			}
			iTempNoOfRec--;
		}

		if(( WriteMsgQ(iIntActiveToRelDirQ, (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

	}
	logTimestamp("Exit :  fCOMMOrderBookDtls");
	return TRUE;



}/************** END of fCOMMOrderBookDtls ****/
BOOL fGetOrderBook(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fGetOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP     pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR		sUserType[3];
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR	*sGetOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	BOOL	iMrgType = FALSE;

	memset(sEntityId ,'\0',ENTITY_ID_LEN);
	memset(sUserType ,'\0',3);

	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);
	sprintf(sGetOrdBook,"SELECT  ENTITY_TYPE,ENTITY_MANAGER_TYPE from  ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);

	logDebug2("Query[%s]",sGetOrdBook);

	/*** SELECT  em_entity_type
INTO :sUserType
from  entity_master em
WHERE em.em_entity_id = ltrim(rtrim(:sEntityId));
	 ******/

	if(mysql_query(DBQueries,sGetOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR IN fGetOrderBook QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
		}
	}

	logDebug2("USER TYPE is :%s:",sUserType );

	if(!strcmp(sUserType ,"D") )//&& !strcmp(sClientId ,"-1"))
	{
		logDebug2("Going to call fDealerALLOrderBook");
		fDealerOrderBook(RcvMsg,iMrgType);
		return TRUE;

	}
	/** // Commented bcoz of branch dealer search for unmapped client data goes to the frontend
	  if(!strcmp(sUserType ,"D" ) && strcmp(sClientId ,"-1"))
	  {
	  logDebug2("---- Going to call fOrderBook");
	  fOrderBook(RcvMsg);
	  return TRUE;

	  }
	 **/	
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("Going to call fClientOrderBook-----");
		fOrderBook(RcvMsg);
		return TRUE;

	}

	logTimestamp("EXIT [fGetOrderBook]");
	return TRUE;

}/*** End of fGetOrderBook *****/
BOOL 	fDealerOrderBook(CHAR *RcvMsg,BOOL iMrgType)
{
	logTimestamp("Entry : fDealerOrderBook");

	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP	pOrderBookHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetDealrOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64     	fOrderNo;
	LONG32       	iSerialNo;
	CHAR         	sBuySellInd[5];
	CHAR         	sSecurityID[SECURITY_ID_LEN];
	CHAR         	sOrderType[8];
	DOUBLE64     	fQty;
	DOUBLE64	fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR         	sProduct[10];
	CHAR         	sValidity[5];
	CHAR         	sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         	sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         	sClientId[CLIENT_ID_LEN];
	CHAR         	sRespClientId[CLIENT_ID_LEN];
	CHAR         	sEntityId[ENTITY_ID_LEN];
	CHAR         	ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32		iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;	
	LONG32		iDateTime;
	CHAR		sWhereClause [MAX_QUERY_SIZE];


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);
	memset(sWhereClause,'\0',MAX_QUERY_SIZE);

	logDebug2("fDealerOrderBook  client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);

	if(iMrgType == TRUE)
	{
		if(strcmp(sClientId,"-1") == 0)
		{
			sprintf(sWhereClause," AND CLIENT_ID IN (select E.ENTITY_CODE \
				FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
					union select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(rtrim(\"%s\"))) \
				ORDER BY ORDER_DATE_TIME DESC;",sEntityId,sEntityId);
		}
		else
		{
			sprintf(sWhereClause," AND CLIENT_ID IN (select E.ENTITY_CODE \
				FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
					union select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(rtrim(\"%s\")) \
					AND C.EDM_CLIENT_ID = ltrim(rtrim(\"%s\"))) \
				ORDER BY ORDER_DATE_TIME DESC;",sEntityId,sEntityId,sClientId);
		}		

	}
	else
	{
		if(strcmp(sClientId,"-1") == 0)
		{
			sprintf(sWhereClause," ORDER BY ORDER_DATE_TIME DESC ");
		}
		else
		{
			sprintf(sWhereClause," AND CLIENT_ID = ltrim(rtrim(\"%s\")) ORDER BY ORDER_DATE_TIME DESC ",sClientId);

		}

	}	

	/*	sprintf(sGetDealrOrdBook,"SELECT CLIENT_ID,ORDER_DATE_TIME,ORDER_NUMBER,EXCH,BUY_SELL,SEGMENT,LEG_NO,PRODUCT,QUANTITY,REMAINING_QUANTITY,PRICE,\
		TRG_PRICE,ORDER_TYPE,DISCLOSE_QTY,SERIALNO,TRADEDQTY,SEM_SECURITY_ID,ORDER_VALIDITY,DQQTYREM,EXCHORDERNO,REASON_DESCRIPTION,\
		PRO_CLIENT,TRADE_PRICE,GOOD_TILL_DATE,PLACEDBY,STRATEGY_ID,JDATE,TRANSCODE,ALGOORDERNO,IFNULL(PAN_NO,'NA'),\
		IFNULL(PARTICIPANT_TYPE,'B'),IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'), \
		IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),MKT_TYPE FROM (SELECT A.EQ_CLIENT_ID AS CLIENT_ID,\
		DATE_FORMAT(A.EQ_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,A.EQ_ORDER_NO AS ORDER_NUMBER,\
		A.EQ_EXCH_ID AS EXCH,(CASE A.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL,\
		'E' AS SEGMENT,A.EQ_INSTRUMENT_NAME AS INSTRUMENT, A.EQ_SYMBOL AS SYMBOL,A.EQ_LEG_NO AS LEG_NO,\
		(CASE A.EQ_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN'\
		WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' \
		ELSE A.EQ_PRODUCT_ID END) AS PRODUCT,\
		(CASE WHEN ((A.EQ_MSG_CODE = '2073') AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY)) THEN 'Part-Traded' \
		WHEN ((A.EQ_MSG_CODE = '2074') AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY)) THEN 'Part-Traded' \
		WHEN ((A.EQ_MSG_CODE = '2212') AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY)) THEN 'Part-Traded' \
		WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending' WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit' \
		WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit' WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit' \
		WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected' \
		WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen' WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified' \
		WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled' WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded' \
		WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired' WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending' \
		WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified' WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled' \
		WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered' WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected' \
		WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected' \
		WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected' \
		WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected' END) AS STATUS,\
		A.EQ_TOTAL_QTY AS QUANTITY, A.EQ_REM_QTY AS REMAINING_QUANTITY,\
		(CASE A.EQ_SEGMENT WHEN 'C' THEN REPLACE(FORMAT((CASE A.EQ_ORDER_TYPE \
		WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(A.EQ_ORDER_PRICE, 0) END), 4), ',', '') \
		ELSE REPLACE(FORMAT((CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
		ELSE IFNULL(A.EQ_ORDER_PRICE, 0) END), 2), ',', '') END) AS PRICE,\
		CASE A.EQ_SEGMENT WHEN 'C' THEN ROUND(COALESCE((CASE A.EQ_ORDER_TYPE \
		WHEN '3' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) \
		ELSE 0 END), 0), 2) ELSE ROUND(COALESCE((CASE A.EQ_ORDER_TYPE \
		WHEN '3' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) \
		ELSE 0 END), 0), 2) END AS TRG_PRICE,\
		(CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' \
		WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\
		CONCAT(A.EQ_REM_QTY, '/', A.EQ_TOTAL_QTY) AS REM_QTY_TOT_QTY,\
		A.EQ_DISC_QTY AS DISCLOSE_QTY, A.EQ_SERIAL_NO AS SERIALNO,\
		A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,A.EQ_SCRIP_CODE AS SEM_SECURITY_ID,\
		(CASE A.EQ_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \
		WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS ORDER_VALIDITY,\
		ifnull(A.EQ_LOT_SIZE,0) AS SEM_NSE_REGULAR_LOT, 0 AS TAKE_PROFIT_TRAIL_GAP,\
		A.EQ_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,A.EQ_DISC_REM_QTY AS DQQTYREM,\
		A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,ifnull(A.EQ_REASON_DESCRIPTION,'NULL') AS REASON_DESCRIPTION,\
		A.EQ_PRO_CLIENT as PRO_CLIENT,A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,\
		ifnull(A.EQ_GOOD_TILL_DATE,NOW()) AS GOOD_TILL_DATE,A.EQ_ENTITY_ID AS PLACEDBY,\
		A.EQ_STRATEGY_ID AS STRATEGY_ID,JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,\
		A.EQ_MSG_CODE AS TRANSCODE , A.EQ_ALGO_ORDER_NO AS  ALGOORDERNO,A.EQ_PAN_NO AS PAN_NO,\
		A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,A.EQ_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
		A.EQ_SETTLOR AS SETTLOR,A.EQ_GTC_FLG AS GTC_FLG,A.EQ_ENCASH_FLG AS ENCASH_FLG,EQ_MKT_TYPE AS MKT_TYPE FROM EQ_ORDERS A \
		JOIN (SELECT @rn:=0) r WHERE A.EQ_SERIAL_NO = (SELECT MAX(C.EQ_SERIAL_NO)  FROM EQ_ORDERS C \
		WHERE (C.EQ_ORDER_NO = A.EQ_ORDER_NO) \
		AND (A.EQ_LEG_NO = C.EQ_LEG_NO) AND (A.EQ_ORD_STATUS <> 'B')) AND (A.EQ_MKT_TYPE <> 'SP') UNION ALL SELECT \
		DO.DRV_CLIENT_ID AS CLIENT_ID, DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,\
		DO.DRV_ORDER_NO AS ORDER_NUMBER,DO.DRV_EXCH_ID AS EXCH,\
		(CASE DO.DRV_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL,\
		DO.DRV_SEGMENT AS SEGMENT, DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,\
		DO.DRV_SYMBOL AS SYMBOL,DO.DRV_LEG_NO AS LEG_NO,\
		(CASE DO.DRV_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' \
		WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' \
		WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' ELSE DO.DRV_PRODUCT_ID END) AS PRODUCT,\
		(CASE WHEN ((DO.DRV_MSG_CODE = '2073') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) THEN 'Part-Traded' \
		WHEN ((DO.DRV_MSG_CODE = '2074') AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY)) THEN 'Part-Traded' \
		WHEN ((DO.DRV_MSG_CODE = '2212') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) THEN 'Part-Traded' \
		WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending' WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit' \
		WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit' WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit' \
		WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected' \
		WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen' WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified' \
		WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled' WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded' \
		WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired' WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending' \
	WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified' WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled' \
		WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered' WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected' \
		WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected' \
		WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected' \
		WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected' END) AS STATUS,\
		DO.DRV_TOTAL_QTY AS QUANTITY,DO.DRV_REM_QTY AS REM_QTY,\
		CASE DO.DRV_SEGMENT WHEN 'C' THEN REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE \
						WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 4), ',', '') \
		ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT'     \
						ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 2), ',', '') END AS PRICE,\
		CASE DO.DRV_SEGMENT WHEN 'C' THEN ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE \
						WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) \
						ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE \
							WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) \
							ELSE 0 END), 0), 2) END AS TRG_PRICE,\
						(CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' \
						 WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\
						CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,\
						DO.DRV_DISC_QTY AS DISCLOSE_QTY,DO.DRV_SERIAL_NO AS SERIALNO,\
						DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,DO.DRV_SCRIP_CODE AS SECURITY_ID,\
						(CASE DO.DRV_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \
						 WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS ORDER_VALIDITY,\
						DO.DRV_LOT_SIZE AS SM_LOT_SIZE, 0 AS TAKE_PROFIT_TRAIL_GAP,\
						DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,DO.DRV_DISC_REM_QTY AS DQQTYREM,\
						DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO, ifnull(DO.DRV_REASON_DESCRIPTION,'NULL') AS REASON_DESCRIPTION,\
						DO.DRV_PRO_CLIENT AS PRO_CLIENT, DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,\
						ifnull(DO.DRV_GOOD_TILL_DATE,NOW()) AS GOOD_TILL_DATE, DO.DRV_ENTITY_ID AS PLACEDBY,\
						DO.DRV_STRATEGY_ID AS STRATEGY_ID,JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
						DO.DRV_MSG_CODE AS TRANSCODE ,DO.DRV_OMS_ALGO_ORD_NO AS ALGOORDERNO,DO.DRV_PAN_NO AS PAN_NO,\
						DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
						DO.DRV_SETTLOR AS SETTLOR,DO.DRV_GTC_FLG AS GTC_FLG,DO.DRV_ENCASH_FLG AS ENCASH_FLG,DO.DRV_MKT_TYPE AS MKT_TYPE FROM DRV_ORDERS DO \
						JOIN (SELECT @rn:=0) r WHERE DO.DRV_SERIAL_NO = (SELECT MAX(DOO.DRV_SERIAL_NO) \
								FROM DRV_ORDERS DOO WHERE (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO) AND (DO.DRV_CF_FLAG <> -(1) \
									AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO)) AND (DO.DRV_STATUS <> 'B')) AND (DO.DRV_MKT_TYPE <> 'SP') \
						UNION ALL SELECT  COM.COMM_CLIENT_ID AS CLIENT_ID,DATE_FORMAT(COM.COMM_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME, \
						COM.COMM_ORDER_NO AS ORDER_NUMBER,COM.COMM_EXCH_ID AS EXCH,\
						(CASE COM.COMM_BUY_SELL_IND \
						 WHEN 'B' THEN 'Buy' \
						 WHEN 'S' THEN 'Sell' \
						 END) AS BUY_SELL,COM.COMM_SEGMENT AS SEGMENT,COM.COMM_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,\
						COM.COMM_SYMBOL AS SYMBOL,COM.COMM_LEG_NO AS LEG_NO,\
						(CASE COM.COMM_PRODUCT_ID \
						 WHEN 'B' THEN 'BO' \
						 WHEN 'V' THEN 'CO' \
						 WHEN 'C' THEN 'CNC' \
						 WHEN 'M' THEN 'MARGIN' \
						 WHEN 'L' THEN 'MLB' \
						 WHEN 'S' THEN 'COLLATERAL' \
						 WHEN 'I' THEN 'INTRADAY' \
						 WHEN 'V' THEN 'CO' \
						 WHEN 'B' THEN 'BO' \
						 ELSE COM.COMM_PRODUCT_ID \
						 END) AS PRODUCT,\
						(CASE \
						 WHEN \
						 ((COM.COMM_MSG_CODE = '2073') \
						  AND (COM.COMM_REM_QTY <> COM.COMM_TOTAL_QTY)) \
						 THEN \
						 'Part-Traded' \
						 WHEN \
						 ((COM.COMM_MSG_CODE = '2074') \
						  AND (COM.COMM_REM_QTY > COM.COMM_TOTAL_QTY)) \
						 THEN \
						 'Part-Traded' \
						 WHEN \
						 ((COM.COMM_MSG_CODE = '2212') \
						  AND (COM.COMM_REM_QTY <> COM.COMM_TOTAL_QTY)) \
						 THEN \
						 'Part-Traded' \
						 WHEN (COM.COMM_MSG_CODE = '2073') THEN 'Pending' \
						 WHEN (COM.COMM_MSG_CODE = '2000') THEN 'Transit' \
						 WHEN (COM.COMM_MSG_CODE = '2040') THEN 'Transit' \
						 WHEN (COM.COMM_MSG_CODE = '2070') THEN 'Transit' \
						 WHEN (COM.COMM_MSG_CODE = '2231') THEN 'Rejected' \
						 WHEN (COM.COMM_MSG_CODE = '2042') THEN 'Rejected' \
						 WHEN \
						 (COM.COMM_MSG_CODE = '2170') \
						 THEN \
						 'Frozen' \
						 WHEN (COM.COMM_MSG_CODE = '2074') THEN 'Modified' \
						 WHEN (COM.COMM_MSG_CODE = '2075') THEN 'Cancelled' \
						 WHEN (COM.COMM_MSG_CODE = '2222') THEN 'Traded' \
						 WHEN (COM.COMM_MSG_CODE = '9002') THEN 'Expired' \
						 WHEN (COM.COMM_MSG_CODE = '5112') THEN 'O-Pending' \
						 WHEN (COM.COMM_MSG_CODE = '5113') THEN 'O-Modified' \
						 WHEN (COM.COMM_MSG_CODE = '5114') THEN 'O-Cancelled' \
						 WHEN (COM.COMM_MSG_CODE = '2212') THEN 'Triggered' \
						 WHEN (COM.COMM_MSG_CODE = '1111') THEN 'Rejected' \
						 WHEN (COM.COMM_MSG_CODE = '1113') THEN 'Rejected' \
						 WHEN (COM.COMM_MSG_CODE = '1115') THEN 'Rejected' \
						 WHEN (COM.COMM_MSG_CODE = '4444') THEN 'Rejected' \
						 WHEN (COM.COMM_MSG_CODE = '4445') THEN 'Rejected' \
						 WHEN (COM.COMM_MSG_CODE = '4446') THEN 'Rejected' \
						 END) AS STATUS,\
						 COM.COMM_TOTAL_QTY AS QUANTITY,\
						 COM.COMM_REM_QTY AS REM_QTY,\
						 CASE COM.COMM_SEGMENT \
						 WHEN \
						 'M' \
						 THEN \
						 REPLACE(FORMAT((CASE COM.COMM_ORDER_TYPE \
										 WHEN '1' THEN 'MKT' \
										 WHEN '3' THEN 'MKT' \
										 ELSE IFNULL(COM.COMM_ORDER_PRICE, 0) \
										 END), 4), ',', '') \
						 ELSE REPLACE(FORMAT((CASE COM.COMM_ORDER_TYPE \
										 WHEN '1' THEN 'MKT' \
										 WHEN '3' THEN 'MKT' \
										 ELSE IFNULL(COM.COMM_ORDER_PRICE, 0) \
										 END), 2), ',', '') \
						 END AS PRICE,\
						 CASE COM.COMM_SEGMENT \
						 WHEN \
						 'M' \
						 THEN \
						 ROUND(COALESCE((CASE COM.COMM_ORDER_TYPE \
										 WHEN '3' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0) \
										 WHEN '4' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0) \
										 ELSE 0 \
										 END), 0), 4) \
						 ELSE ROUND(COALESCE((CASE COM.COMM_ORDER_TYPE \
										 WHEN '3' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0) \
										 WHEN '4' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0) \
										 ELSE 0 \
										 END), 0), 2) \
						 END AS TRG_PRICE,\
						 (CASE COM.COMM_ORDER_TYPE \
						  WHEN '1' THEN 'MARKET' \
						  WHEN '2' THEN 'LIMIT' \
						  WHEN '3' THEN 'SL-M' \
						  WHEN '4' THEN 'SL' \
						  END) AS ORDER_TYPE,\
						 CONCAT(COM.COMM_REM_QTY, '/', COM.COMM_TOTAL_QTY) AS REM_QTY_TOT_QTY,\
						 COM.COMM_DISC_QTY AS DISCLOSE_QTY,\
						 COM.COMM_SERIAL_NO AS SERIALNO,\
						 COM.COMM_TOTAL_TRADED_QTY AS TRADEDQTY,\
						 COM.COMM_SCRIP_CODE AS SECURITY_ID,\
						 (CASE COM.COMM_VALIDITY \
						  WHEN '0' THEN 'DAY' \
						  WHEN '1' THEN 'GTC' \
						  WHEN '2' THEN 'ATO' \
						  WHEN '3' THEN 'IOC' \
						  ELSE 'EOS' \
						  END) AS ORDER_VALIDITY,\
						 COM.COMM_LOT_SIZE AS SM_LOT_SIZE,\
						 0 AS TAKE_PROFIT_TRAIL_GAP,\
						 COM.COMM_OMS_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,\
						 COM.COMM_DISC_REM_QTY AS DQQTYREM,\
						 COM.COMM_EXCH_ORDER_NO AS EXCHORDERNO,\
						 IFNULL(NULLIF(COM.COMM_REASON_DESCRIPTION, ''), 'NULL') AS REASON_DESCRIPTION,\
						 COM.COMM_PRO_CLIENT AS PRO_CLIENT,\
						 COM.COMM_TRD_TRADE_PRICE AS TRADE_PRICE,\
						 IFNULL(COM.COMM_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,\
						 COM.COMM_ENTITY_ID AS PLACEDBY,\
						 COM.COMM_STRATEGY_ID AS STRATEGY_ID,\
						 JULIDATE(COM.COMM_INTERNAL_ENTRY_DATE) AS JDATE,\
						 COM.COMM_MSG_CODE AS TRANSCODE,\
						 COM.COMM_OMS_ALGO_ORDER_NO AS ALGOORDERNO,COM.COMM_PAN_NO AS PAN_NO,COM.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE, \
						 COM.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,COM.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
						 COM.COMM_SETTLOR AS SETTLOR,COM.COMM_GTC_FLG AS GTC_FLG,COM.COMM_ENCASH_FLG AS ENCASH_FLG,COM.COMM_MKT_TYPE AS MKT_TYPE FROM \
						 COMM_ORDERS COM \
						 JOIN (SELECT @rn:=0) r \
						 WHERE \
						 (COM.COMM_MKT_TYPE <> 'SP') \
						 AND COM.COMM_SERIAL_NO = (SELECT \
								 MAX(DOO.COMM_SERIAL_NO) \
								 FROM \
								 COMM_ORDERS DOO \
								 WHERE \
								 (DOO.COMM_ORDER_NO = COM.COMM_ORDER_NO) \
								 AND (COM.COMM_OMS_ALGO_ORDER_NO <> -(1) \
									 AND (COM.COMM_LEG_NO = DOO.COMM_LEG_NO)) \
								 AND (COM.COMM_STATUS <> 'B'))) orderbook \
								 WHERE 1=1 %s ; ",sWhereClause);
	printf("sGetDealrOrdBook :%s:",sGetDealrOrdBook);*/


	sprintf(sGetDealrOrdBook,"SELECT CLIENT_ID,ORDER_DATE_TIME,ORDER_NUMBER,EXCH,BUY_SELL,SEGMENT,LEG_NO,PRODUCT,QUANTITY,REMAINING_QUANTITY,PRICE,                   TRG_PRICE,ORDER_TYPE,DISCLOSE_QTY,SERIALNO,TRADEDQTY,SEM_SECURITY_ID,ORDER_VALIDITY,DQQTYREM,EXCHORDERNO,REASON_DESCRIPTION,                   PRO_CLIENT,TRADE_PRICE,GOOD_TILL_DATE,PLACEDBY,IFNULL(STRATEGY_ID,0),JDATE,TRANSCODE,IFNULL(ALGOORDERNO,0),IFNULL(PAN_NO,'NA'),                   IFNULL(PARTICIPANT_TYPE,'B'),IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'),                    IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),MKT_TYPE,  SL_ABSTICK_VALUE,    PR_ABSTICK_VALUE,    SL_AT_FLAG,    PR_ST_FLAG,    TRAILING_SL_VALUE FROM (SELECT A.EQ_CLIENT_ID AS CLIENT_ID,                   DATE_FORMAT(A.EQ_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,A.EQ_ORDER_NO AS ORDER_NUMBER,                   A.EQ_EXCH_ID AS EXCH,(CASE A.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL,                   'E' AS SEGMENT,A.EQ_INSTRUMENT_NAME AS INSTRUMENT, A.EQ_SYMBOL AS SYMBOL,A.EQ_LEG_NO AS LEG_NO,                   (CASE A.EQ_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN'                    WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF'                    ELSE A.EQ_PRODUCT_ID END) AS PRODUCT,                   (CASE WHEN ((A.EQ_MSG_CODE = '2073') AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY)) THEN 'Part-Traded'                     WHEN ((A.EQ_MSG_CODE = '2074') AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY)) THEN 'Part-Traded'                     WHEN ((A.EQ_MSG_CODE = '2212') AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY)) THEN 'Part-Traded'                     WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending' WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'                     WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit' WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'                     WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'                     WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen' WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'                     WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled' WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'                     WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired' WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'                     WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified' WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'                     WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered' WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'                     WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'                     WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected' WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'                     WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected' END) AS STATUS,                   A.EQ_TOTAL_QTY AS QUANTITY, A.EQ_REM_QTY AS REMAINING_QUANTITY,                   (CASE A.EQ_SEGMENT WHEN 'C' THEN REPLACE(FORMAT((CASE A.EQ_ORDER_TYPE                     WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(A.EQ_ORDER_PRICE, 0) END), 4), ',', '')                     ELSE REPLACE(FORMAT((CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT'                     ELSE IFNULL(A.EQ_ORDER_PRICE, 0) END), 2), ',', '') END) AS PRICE,                   CASE A.EQ_SEGMENT WHEN 'C' THEN ROUND(COALESCE((CASE A.EQ_ORDER_TYPE                    WHEN '3' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0)                    ELSE 0 END), 0), 2) ELSE ROUND(COALESCE((CASE A.EQ_ORDER_TYPE                    WHEN '3' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(A.EQ_TRIGGER_PRICE, 0)                    ELSE 0 END), 0), 2) END AS TRG_PRICE,                   (CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M'                     WHEN '4' THEN 'SL' END) AS ORDER_TYPE,                   CONCAT(A.EQ_REM_QTY, '/', A.EQ_TOTAL_QTY) AS REM_QTY_TOT_QTY,                   A.EQ_DISC_QTY AS DISCLOSE_QTY, A.EQ_SERIAL_NO AS SERIALNO,                   A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,A.EQ_SCRIP_CODE AS SEM_SECURITY_ID,                   (CASE A.EQ_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO'                     WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS ORDER_VALIDITY,                   ifnull(A.EQ_LOT_SIZE,0) AS SEM_NSE_REGULAR_LOT, 0 AS TAKE_PROFIT_TRAIL_GAP,                   A.EQ_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,A.EQ_DISC_REM_QTY AS DQQTYREM,                   A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,ifnull(A.EQ_REASON_DESCRIPTION,'NULL') AS REASON_DESCRIPTION,                   A.EQ_PRO_CLIENT as PRO_CLIENT,A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,                   ifnull(A.EQ_GOOD_TILL_DATE,NOW()) AS GOOD_TILL_DATE,A.EQ_ENTITY_ID AS PLACEDBY,                   A.EQ_STRATEGY_ID AS STRATEGY_ID,JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,                   A.EQ_MSG_CODE AS TRANSCODE , A.EQ_ALGO_ORDER_NO AS  ALGOORDERNO,A.EQ_PAN_NO AS PAN_NO,                   A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,A.EQ_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,                   A.EQ_SETTLOR AS SETTLOR,A.EQ_GTC_FLG AS GTC_FLG,A.EQ_ENCASH_FLG AS ENCASH_FLG,EQ_MKT_TYPE AS MKT_TYPE, A.EQ_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE, A.EQ_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE, A.EQ_SL_AT_FLAG AS SL_AT_FLAG,A.EQ_PR_ST_FLAG    AS PR_ST_FLAG, A.EQ_TRAILING_SL_VALUE AS TRAILING_SL_VALUE FROM EQ_ORDERS A                    JOIN (SELECT @rn:=0) r WHERE A.EQ_SERIAL_NO = (SELECT MAX(C.EQ_SERIAL_NO)  FROM EQ_ORDERS C                    WHERE (C.EQ_ORDER_NO = A.EQ_ORDER_NO)                    AND (A.EQ_LEG_NO = C.EQ_LEG_NO) AND (A.EQ_ORD_STATUS <> 'B')) AND (A.EQ_MKT_TYPE <> 'SP') UNION ALL SELECT                    DO.DRV_CLIENT_ID AS CLIENT_ID, DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,                   DO.DRV_ORDER_NO AS ORDER_NUMBER,DO.DRV_EXCH_ID AS EXCH,                   (CASE DO.DRV_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL,                   DO.DRV_SEGMENT AS SEGMENT, DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,                   DO.DRV_SYMBOL AS SYMBOL,DO.DRV_LEG_NO AS LEG_NO,                   (CASE DO.DRV_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'C' THEN 'CNC'                     WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY'                     WHEN 'V' THEN 'CO' WHEN 'B' THEN 'BO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE DO.DRV_PRODUCT_ID END) AS PRODUCT,                   (CASE WHEN ((DO.DRV_MSG_CODE = '2073') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) THEN 'Part-Traded'                     WHEN ((DO.DRV_MSG_CODE = '2074') AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY)) THEN 'Part-Traded'                     WHEN ((DO.DRV_MSG_CODE = '2212') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) THEN 'Part-Traded'                     WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending' WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit'                     WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit' WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit'                     WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected'                     WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen' WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified'                     WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled' WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded'                     WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired' WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending'                     WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified' WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'                     WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered' WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected'                     WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected'                     WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected'                     WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected' END) AS STATUS,                   DO.DRV_TOTAL_QTY AS QUANTITY,DO.DRV_REM_QTY AS REM_QTY,                   CASE DO.DRV_SEGMENT WHEN 'C' THEN REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE                    WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 4), ',', '')                    ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT'                        ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 2), ',', '') END AS PRICE,                   CASE DO.DRV_SEGMENT WHEN 'C' THEN ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE                    WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)                    ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE                    WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)                    ELSE 0 END), 0), 2) END AS TRG_PRICE,                   (CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M'                    WHEN '4' THEN 'SL' END) AS ORDER_TYPE,                   CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,                   DO.DRV_DISC_QTY AS DISCLOSE_QTY,DO.DRV_SERIAL_NO AS SERIALNO,                   DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,DO.DRV_SCRIP_CODE AS SECURITY_ID,                   (CASE DO.DRV_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO'                     WHEN '3' THEN 'IOC' WHEN '6' THEN 'GTD' ELSE 'EOS' END) AS ORDER_VALIDITY,                   DO.DRV_LOT_SIZE AS SM_LOT_SIZE, 0 AS TAKE_PROFIT_TRAIL_GAP,                   DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,DO.DRV_DISC_REM_QTY AS DQQTYREM,                   DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO, ifnull(DO.DRV_REASON_DESCRIPTION,'NULL') AS REASON_DESCRIPTION,                   DO.DRV_PRO_CLIENT AS PRO_CLIENT, DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,                   ifnull(DO.DRV_GOOD_TILL_DATE,NOW()) AS GOOD_TILL_DATE, DO.DRV_ENTITY_ID AS PLACEDBY,                   DO.DRV_STRATEGY_ID AS STRATEGY_ID,JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,                   DO.DRV_MSG_CODE AS TRANSCODE ,DO.DRV_OMS_ALGO_ORD_NO AS ALGOORDERNO,DO.DRV_PAN_NO AS PAN_NO,                   DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,                   DO.DRV_SETTLOR AS SETTLOR,DO.DRV_GTC_FLG AS GTC_FLG,DO.DRV_ENCASH_FLG AS ENCASH_FLG,DO.DRV_MKT_TYPE AS MKT_TYPE,DO.DRV_SL_ABSTICK_VALUE AS SL_ABSTICK_VALUE,DO.DRV_PR_ABSTICK_VALUE AS PR_ABSTICK_VALUE,DO.DRV_SL_AT_FLAG     AS SL_AT_FLAG,DO.DRV_PR_ABSTICK_VALUE AS PR_ST_FLAG,DO.DRV_TRAILING_SL_VALUE  AS TRAILING_SL_VALUE FROM DRV_ORDERS DO                    JOIN (SELECT @rn:=0) r WHERE DO.DRV_SERIAL_NO = (SELECT MAX(DOO.DRV_SERIAL_NO)                    FROM DRV_ORDERS DOO WHERE (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO) AND (DO.DRV_CF_FLAG <> -(1)                    AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO)) AND (DO.DRV_STATUS <> 'B')) AND (DO.DRV_MKT_TYPE <> 'SP')                    UNION ALL SELECT  COM.COMM_CLIENT_ID AS CLIENT_ID,DATE_FORMAT(COM.COMM_INTERNAL_ENTRY_DATE, '%%d-%%b-%%Y %%T') AS ORDER_DATE_TIME,                    COM.COMM_ORDER_NO AS ORDER_NUMBER,COM.COMM_EXCH_ID AS EXCH,                   (CASE COM.COMM_BUY_SELL_IND                    WHEN 'B' THEN 'Buy'                    WHEN 'S' THEN 'Sell'                    END) AS BUY_SELL,COM.COMM_SEGMENT AS SEGMENT,COM.COMM_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,                   COM.COMM_SYMBOL AS SYMBOL,COM.COMM_LEG_NO AS LEG_NO,                   (CASE COM.COMM_PRODUCT_ID                     WHEN 'B' THEN 'BO'                     WHEN 'V' THEN 'CO'                     WHEN 'C' THEN 'CNC'                     WHEN 'M' THEN 'MARGIN'                     WHEN 'L' THEN 'MLB'                     WHEN 'S' THEN 'COLLATERAL'                     WHEN 'I' THEN 'INTRADAY'                     WHEN 'V' THEN 'CO'                     WHEN 'B' THEN 'BO'          WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF'           ELSE COM.COMM_PRODUCT_ID                     END) AS PRODUCT,                   (CASE                     WHEN                     ((COM.COMM_MSG_CODE = '2073')                      AND (COM.COMM_REM_QTY <> COM.COMM_TOTAL_QTY))                     THEN                     'Part-Traded'                     WHEN                     ((COM.COMM_MSG_CODE = '2074')                      AND (COM.COMM_REM_QTY > COM.COMM_TOTAL_QTY))                     THEN                     'Part-Traded'                     WHEN                     ((COM.COMM_MSG_CODE = '2212')                      AND (COM.COMM_REM_QTY <> COM.COMM_TOTAL_QTY))                     THEN                     'Part-Traded'                     WHEN (COM.COMM_MSG_CODE = '2073') THEN 'Pending'                     WHEN (COM.COMM_MSG_CODE = '2000') THEN 'Transit'                     WHEN (COM.COMM_MSG_CODE = '2040') THEN 'Transit'                     WHEN (COM.COMM_MSG_CODE = '2070') THEN 'Transit'                     WHEN (COM.COMM_MSG_CODE = '2231') THEN 'Rejected'                     WHEN (COM.COMM_MSG_CODE = '2042') THEN 'Rejected'                     WHEN                     (COM.COMM_MSG_CODE = '2170')                     THEN                     'Frozen'                     WHEN (COM.COMM_MSG_CODE = '2074') THEN 'Modified'                     WHEN (COM.COMM_MSG_CODE = '2075') THEN 'Cancelled'                     WHEN (COM.COMM_MSG_CODE = '2222') THEN 'Traded'                     WHEN (COM.COMM_MSG_CODE = '9002') THEN 'Expired'                     WHEN (COM.COMM_MSG_CODE = '5112') THEN 'O-Pending'                     WHEN (COM.COMM_MSG_CODE = '5113') THEN 'O-Modified'                     WHEN (COM.COMM_MSG_CODE = '5114') THEN 'O-Cancelled'                     WHEN (COM.COMM_MSG_CODE = '2212') THEN 'Triggered'                     WHEN (COM.COMM_MSG_CODE = '1111') THEN 'Rejected'                     WHEN (COM.COMM_MSG_CODE = '1113') THEN 'Rejected'                     WHEN (COM.COMM_MSG_CODE = '1115') THEN 'Rejected'                     WHEN (COM.COMM_MSG_CODE = '4444') THEN 'Rejected'                     WHEN (COM.COMM_MSG_CODE = '4445') THEN 'Rejected'                     WHEN (COM.COMM_MSG_CODE = '4446') THEN 'Rejected'                     END) AS STATUS,                    COM.COMM_TOTAL_QTY AS QUANTITY,                    COM.COMM_REM_QTY AS REM_QTY,                    CASE COM.COMM_SEGMENT                     WHEN                     'M'                     THEN                     REPLACE(FORMAT((CASE COM.COMM_ORDER_TYPE                    WHEN '1' THEN 'MKT'                    WHEN '3' THEN 'MKT'                    ELSE IFNULL(COM.COMM_ORDER_PRICE, 0)                    END), 4), ',', '')                    ELSE REPLACE(FORMAT((CASE COM.COMM_ORDER_TYPE                    WHEN '1' THEN 'MKT'                    WHEN '3' THEN 'MKT'                    ELSE IFNULL(COM.COMM_ORDER_PRICE, 0)                    END), 2), ',', '')                    END AS PRICE,                   CASE COM.COMM_SEGMENT                    WHEN                    'M'                    THEN                    ROUND(COALESCE((CASE COM.COMM_ORDER_TYPE                    WHEN '3' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)                    WHEN '4' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)                    ELSE 0                    END), 0), 4)                     ELSE ROUND(COALESCE((CASE COM.COMM_ORDER_TYPE                     WHEN '3' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)                     WHEN '4' THEN IFNULL(COM.COMM_TRIGGER_PRICE, 0)                    ELSE 0                     END), 0), 2)                     END AS TRG_PRICE,                   (CASE COM.COMM_ORDER_TYPE                     WHEN '1' THEN 'MARKET'                     WHEN '2' THEN 'LIMIT'                     WHEN '3' THEN 'SL-M'                     WHEN '4' THEN 'SL'                     END) AS ORDER_TYPE,                   CONCAT(COM.COMM_REM_QTY, '/', COM.COMM_TOTAL_QTY) AS REM_QTY_TOT_QTY,                   COM.COMM_DISC_QTY AS DISCLOSE_QTY,                   COM.COMM_SERIAL_NO AS SERIALNO,                   COM.COMM_TOTAL_TRADED_QTY AS TRADEDQTY,                   COM.COMM_SCRIP_CODE AS SECURITY_ID,                   (CASE COM.COMM_VALIDITY                     WHEN '0' THEN 'DAY'                     WHEN '1' THEN 'GTC'                     WHEN '2' THEN 'ATO'                     WHEN '3' THEN 'IOC'           WHEN '6' THEN 'GTD'          ELSE 'EOS'                     END) AS ORDER_VALIDITY,                   COM.COMM_LOT_SIZE AS SM_LOT_SIZE,                   0 AS TAKE_PROFIT_TRAIL_GAP,                   COM.COMM_OMS_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,                   COM.COMM_DISC_REM_QTY AS DQQTYREM,                   COM.COMM_EXCH_ORDER_NO AS EXCHORDERNO,                   IFNULL(NULLIF(COM.COMM_REASON_DESCRIPTION, ''), 'NULL') AS REASON_DESCRIPTION,                   COM.COMM_PRO_CLIENT AS PRO_CLIENT,                   COM.COMM_TRD_TRADE_PRICE AS TRADE_PRICE,                   IFNULL(COM.COMM_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,                   COM.COMM_ENTITY_ID AS PLACEDBY,                   COM.COMM_STRATEGY_ID AS STRATEGY_ID,                   JULIDATE(COM.COMM_INTERNAL_ENTRY_DATE) AS JDATE,                   COM.COMM_MSG_CODE AS TRANSCODE,                   COM.COMM_OMS_ALGO_ORDER_NO AS ALGOORDERNO,COM.COMM_PAN_NO AS PAN_NO,COM.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,                    COM.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,COM.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,                   COM.COMM_SETTLOR AS SETTLOR,COM.COMM_GTC_FLG AS GTC_FLG,COM.COMM_ENCASH_FLG AS ENCASH_FLG,COM.COMM_MKT_TYPE AS MKT_TYPE,COM.COMM_SL_ABSTICK_VALUE   AS SL_ABSTICK_VALUE,COM.COMM_PR_ABSTICK_VALUE   AS PR_ABSTICK_VALUE,COM.COMM_SL_AT_FLAG AS SL_AT_FLAG,COM.COMM_PR_ABSTICK_VALUE AS PR_ST_FLAG,COM.COMM_TRAILING_SL_VALUE  AS TRAILING_SL_VALUE FROM                    COMM_ORDERS COM                    JOIN (SELECT @rn:=0) r                    WHERE                    (COM.COMM_MKT_TYPE <> 'SP')                    AND COM.COMM_SERIAL_NO = (SELECT                    MAX(DOO.COMM_SERIAL_NO)                    FROM                    COMM_ORDERS DOO                    WHERE                    (DOO.COMM_ORDER_NO = COM.COMM_ORDER_NO) AND (DOO.COMM_CF_FLAG <> -1)   AND (COM.COMM_LEG_NO = DOO.COMM_LEG_NO)                    AND (COM.COMM_STATUS <> 'B'))) orderbook                    WHERE 1=1 %s ;",sWhereClause);
	printf("sGetDealrOrdBook :%s:",sGetDealrOrdBook); 

	if(mysql_query(DBQueries,sGetDealrOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR In GetDealrOrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
//	iNoOfPkt = ceil(fNoOfRec);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/


	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_HEADER_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource  = pViewOrderBookReq->ReqHeader.cSource ;
	//		pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pOrderBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_RESP));
		pOrderBookResp.IntRespHeader.iSeqNo = 0;
		pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_RESP);
		pOrderBookResp.IntRespHeader.iErrorId = 0;
		pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_RESP;
		pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
		pOrderBookResp.IntRespHeader.cSource  = pViewOrderBookReq->ReqHeader.cSource ;

		logDebug2(" iTempNoOfRec :%d: Segment:%c:,ExcgId :%s:",iTempNoOfRec,Segment,ExcgId );

		if(iTempNoOfRec <= 1)
		{
			pOrderBookResp.cMsgType = 'T';
		}
		else
		{
			pOrderBookResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrderBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sDatetime,Row[1],DATE_LENGTH);
				pOrderBookResp.suborderbook[j].fOrderNo =atof(Row[2]);
				strncpy(pOrderBookResp.suborderbook[j].sExcgId,Row[3],EXCHANGE_LEN);
				memset(pOrderBookResp.suborderbook[j].sBuySellInd,'\0',5);
				strncpy(pOrderBookResp.suborderbook[j].sBuySellInd,Row[4],5);
				pOrderBookResp.suborderbook[j].cSegment = Row[5][0];
				pOrderBookResp.suborderbook[j].iLegValue = atoi(Row[6]);
				strncpy(pOrderBookResp.suborderbook[j].sProduct,Row[7],10);
				pOrderBookResp.suborderbook[j].fQty = atof(Row[8]);
				pOrderBookResp.suborderbook[j].fRemQty = atof(Row[9]);
				pOrderBookResp.suborderbook[j].fPrice = atof(Row[10]);
				pOrderBookResp.suborderbook[j].fTrgPrice = atof(Row[11]);
				strncpy(pOrderBookResp.suborderbook[j].sOrderType,Row[12],8);
				pOrderBookResp.suborderbook[j].fDQQty = atof(Row[13]);
				pOrderBookResp.suborderbook[j].iSerialNo =atoi(Row[14]);
				pOrderBookResp.suborderbook[j].fTradeQty = atof(Row[15]);
				strncpy(pOrderBookResp.suborderbook[j].sSecurityID,Row[16] ,SECURITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sValidity,Row[17],5);
				pOrderBookResp.suborderbook[j].fDQQtyRem = atof(Row[18]);
				strncpy(pOrderBookResp.suborderbook[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sReasonDesc, Row[20],DB_REASON_DESC_LEN);
				pOrderBookResp.suborderbook[j].cProClient =  Row[21][0];
				pOrderBookResp.suborderbook[j].fTrdPrice  = atof(Row[22]);
				strncpy(pOrderBookResp.suborderbook[j].sGoodTillDaysDate, Row[23],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sEntityId , Row[24],ENTITY_ID_LEN);
				pOrderBookResp.suborderbook[j].iStrategyId = atoi(Row[25]);
				pOrderBookResp.suborderbook[j].iDateTime = atoi(Row[26]);
				pOrderBookResp.suborderbook[j].iTranscode = atoi(Row[27]);
				pOrderBookResp.suborderbook[j].fAlgoOrderNo  = atof(Row[28]);
				if(strlen(Row[29]) == 0)
				{
					strncpy(pOrderBookResp.suborderbook[j].sPanID,"NA",INT_PAN_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbook[j].sPanID,Row[29],INT_PAN_LEN);
				}
				pOrderBookResp.suborderbook[j].cParticipantType =  Row[30][0];
				pOrderBookResp.suborderbook[j].cMarkProFlag =  Row[31][0];
				pOrderBookResp.suborderbook[j].fMarkProVal = atof(Row[32]);
				if(strlen(Row[33]) == 0)
				{
					strncpy(pOrderBookResp.suborderbook[j].sSettlor,"NA",SETTLOR_LEN);
				}
				else
				{
					strncpy(pOrderBookResp.suborderbook[j].sSettlor,Row[33],SETTLOR_LEN);
				}	
				pOrderBookResp.suborderbook[j].cGTCFlag =  Row[34][0];
				pOrderBookResp.suborderbook[j].cEncashFlag =  Row[35][0];
				strncpy(pOrderBookResp.suborderbook[j].sMktType,Row[36],MKT_TYPE_LEN);
				/**
				  pOrderBookResp.suborderbook[j].fSLAbsTick= atof(Row[37]);
				  pOrderBookResp.suborderbook[j].fPRAbsTick= atof(Row[38]);
				  pOrderBookResp.suborderbook[j].cSLAtFlag=  Row[39][0];
				  pOrderBookResp.suborderbook[j].cPRStFlag=  Row[40][0];
				  pOrderBookResp.suborderbook[j].fTrailingVal= atof(Row[41]);
				 **/
				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pOrderBookResp.IntRespHeader.iMsgLength :%d:",pOrderBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pOrderBookResp.IntRespHeader.iUserId:%llu:",pOrderBookResp.IntRespHeader.iUserId);
				logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
				logDebug2(" ----------------- Printing Header ------------------------------------");

				logDebug2("pOrderBookResp.suborderbook[%d].sClientId = %s",j,pOrderBookResp.suborderbook[j].sClientId);
				logDebug2("pOrderBookResp.suborderbook[%d].sDatetime = %s",j,pOrderBookResp.suborderbook[j].sDatetime);
				logDebug2("pOrderBookResp.suborderbook[%d].fOrderNo =%lf ",j,pOrderBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrderBookResp.suborderbook[%d].sExcgId = %s",j,pOrderBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrderBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrderBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrderBookResp.suborderbook[%d].cSegment = %c",j,pOrderBookResp.suborderbook[j].cSegment);
				logDebug2("pOrderBookResp.suborderbook[%d].iLegValue = %d",j,pOrderBookResp.suborderbook[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbook[%d].sProduct = %s",j,pOrderBookResp.suborderbook[j].sProduct);
				logDebug2("pOrderBookResp.suborderbook[%d].fQty = %lf",j,pOrderBookResp.suborderbook[j].fQty);
				logDebug2("pOrderBookResp.suborderbook[%d].fRemQty = %lf",j,pOrderBookResp.suborderbook[j].fRemQty);
				logDebug2("pOrderBookResp.suborderbook[%d].fPrice = %lf",j,pOrderBookResp.suborderbook[j].fPrice);
				logDebug2("pOrderBookResp.suborderbook[%d].fTrgPrice = %lf",j,pOrderBookResp.suborderbook[j].fTrgPrice);
				logDebug2("pOrderBookResp.suborderbook[%d].sOrderType= %s",j,pOrderBookResp.suborderbook[j].sOrderType);
				logDebug2("pOrderBookResp.suborderbook[%d].fDQQty = %lf",j,pOrderBookResp.suborderbook[j].fDQQty);
				logDebug2("pOrderBookResp.suborderbook[%d].iSerialNo = %d",j,pOrderBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrderBookResp.suborderbook[%d].fTradeQty= %lf",j,pOrderBookResp.suborderbook[j].fTradeQty);
				logDebug2("pOrderBookResp.suborderbook[%d].iStrategyId = %d",j,pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[%d].sValidity = %s",j,pOrderBookResp.suborderbook[j].sValidity);
				logDebug2("pOrderBookResp.suborderbook[%d].fDQQtyRem = %lf",j,pOrderBookResp.suborderbook[j].fDQQtyRem);
				logDebug2("pOrderBookResp.suborderbook[%d].sExchOrderNumber= %s",j,pOrderBookResp.suborderbook[j].sExchOrderNumber);
				logDebug2("pOrderBookResp.suborderbook[%d].sReasonDesc = %s",j,pOrderBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrderBookResp.suborderbook[%d].cProClient = %c",j,pOrderBookResp.suborderbook[j].cProClient);
				logDebug2("pOrderBookResp.suborderbook[%d].fTrdPrice = %lf",j,pOrderBookResp.suborderbook[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbook[%d].sGoodTillDaysDate = %s",j,pOrderBookResp.suborderbook[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbook[%d].sEntityId = %s",j,pOrderBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbook[%d].iStrategyId = %d",j,pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[%d].iDateTime = %d",j,pOrderBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrderBookResp.suborderbook[%d].iTranscode = %d",j,pOrderBookResp.suborderbook[j].iTranscode);
				logDebug2("pOrderBookResp.suborderbook[%d].fAlgoOrderNo = %f",j,pOrderBookResp.suborderbook[j].fAlgoOrderNo);
				logDebug2("pOrderBookResp.suborderbook[%d].sPanID = %s",j,pOrderBookResp.suborderbook[j].sPanID);
				logDebug2("pOrderBookResp.suborderbook[%d].cParticipantType = %c",j,pOrderBookResp.suborderbook[j].cParticipantType);
				logDebug2("pOrderBookResp.suborderbook[%d].cMarkProFlag = %c",j,pOrderBookResp.suborderbook[j].cMarkProFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbook[j].fMarkProVal);
				logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbook[j].sSettlor);
				logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbook[j].cGTCFlag);
				logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbook[j].cEncashFlag);
				/**
				  logDebug2("pOrderBookResp.suborderbook[%d].cPRStFlag= %c",j,pOrderBookResp.suborderbook[j].cPRStFlag);
				  logDebug2("pOrderBookResp.suborderbook[%d].cSLAtFlag= %c",j,pOrderBookResp.suborderbook[j].cSLAtFlag);
				  logDebug2("pOrderBookResp.suborderbook[%d].fSLAbsTick= %lf",j,pOrderBookResp.suborderbook[j].fSLAbsTick);
				  logDebug2("pOrderBookResp.suborderbook[%d].fPRAbsTick= %lf",j,pOrderBookResp.suborderbook[j].fPRAbsTick);
				  logDebug2("pOrderBookResp.suborderbook[%d].fTrailingVal= %lf",j,pOrderBookResp.suborderbook[j].fTrailingVal);
				 **/
				logDebug2("-------------------END------------------");
			}
		}

		usleep(5000);
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/

	}

	logTimestamp("Exit : fDealerOrderBook");
	return TRUE;

}/************** END of fDealerOrderBook ****/


BOOL 	fGetTradeBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fGetTradeBook");
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP     pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP     pTradeBookHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sUserType[3];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetTrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	BOOL		iMrgType = FALSE;

	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);
	logDebug2("sClientId :%s: sEntityId :%s:",sClientId,sEntityId);

	sprintf(sGetTrdBook,"SELECT  ENTITY_TYPE,ENTITY_MANAGER_TYPE FROM  ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);
	logDebug2("sGetTrdBook :%s:",sGetTrdBook);

	if(mysql_query(DBQueries,sGetTrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in GetTrdBook Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
		}
	}		

	logDebug2("USER TYPE is :%s:",sUserType );

	if(!strcmp(sUserType ,"D") )//&& !strcmp(sClientId ,"-1"))
	{
		logDebug2(" Going to call fDealerALLTRadebook");
		fDealerTradeBook(RcvMsg,iMrgType);
		return TRUE;

	}
	/**
	  if(!strcmp(sUserType ,"D" ) && strcmp(sClientId ,"-1"))
	  {
	  logDebug2("-----Going to call fTradeBook");
	  fTradeBook(RcvMsg);
	  return TRUE;

	  }
	 ***/
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2(" Going to call fTradeBook---------");
		fTradeBook(RcvMsg);
		return TRUE;

	}

	logTimestamp("Exit : fGetTradeBook");
	return TRUE;

}/** End of fGetTradeBook ***/


BOOL fGetConvetToDel(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sUserType[3];
	LONG32 iMrgType = 0;
	MYSQL_RES	*Res;
	MYSQL_ROW	Row;
	CHAR *sGetCon2Del= malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewCTODReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewCTODReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" pViewCTODReq->sClientId [%s]",pViewCTODReq->sClientId);
	logDebug2(" pViewCTODReq->sEntityId [%s]",pViewCTODReq->sEntityId);

	sprintf(sGetCon2Del,"SELECT  ENTITY_TYPE  ,ENTITY_MANAGER_TYPE \
			from  ENTITY_MASTER \
			WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);


	if(mysql_query(DBQueries,sGetCon2Del) != SUCCESS)
	{
		logSqlFatal("ERROR select Entity Type in fGetConvetToDel QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
		}

	}

	logDebug2(" USER TYPE is :%s:",sUserType );		

	if(!strcmp(sUserType ,"D") && !strcmp(sClientId ,"-1"))
	{
		logDebug2(" Going to call fDealerConvetToDel");
		fDealerConvetToDel(RcvMsg,iMrgType);
		return TRUE;

	}

	if(!strcmp(sUserType ,"C"))
	{
		logDebug2(" Going to call fClientConvetToDel ");
		fClientConvetToDel(RcvMsg);
		return TRUE;

	}	

	logDebug2(" I m here too");


	return TRUE;


}

BOOL fDealerConvetToDel(CHAR *RcvMsg,BOOL iMrgTypeFlg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sDealrCnvtToDel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sWhereQry[MAX_QUERY_SIZE];
	memset(sWhereQry,'\0',MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;	

	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR            cProductSource;
	CHAR            cProductDest;
	CHAR            cSide;
	LONG32          iQty;
	CHAR         sExcgId[EXCHANGE_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            cSegment;
	CHAR         sRespClientId[CLIENT_ID_LEN];


	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;	

	strncpy(sEntityId ,pViewCTODReq->sEntityId,ENTITY_ID_LEN);

	if(iMrgTypeFlg == TRUE)
	{
		sprintf(sWhereQry," AND RCCD_CLIENT_ID IN (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
			UNION SELECT D.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING D WHERE D.EDM_DEALER_ID = ltrim(rtrim(\"%s\")))\
			ORDER BY ORDER_DATE_TIME DESC ;",sEntityId,sEntityId);


	}
	else
	{
		sprintf(sWhereQry," ");
	}


	logDebug2(" fDealerConvetToDel sEntityId [%s] pViewCTODReq->sEntityId[%s]",sEntityId ,pViewCTODReq->sEntityId);


	sprintf(sDealrCnvtToDel,"SELECT  RCCD_SCRIP_CODE,\
			RCCD_EXCHANGE,\
			RCCD_PRODUCT_SOURCE,\
			RCCD_PRODUCT_DESTINATION,\
			RCCD_SIDE,\
			RCCD_QTY,\
			RCCD_CONVT_PRICE,\
			RCCD_SEGMENT,\
			RCCD_CLIENT_ID\
			FROM RMS_CLIENT_CONVT_TO_DEL tb\
			WHERE 1=1 %s ",sWhereQry);


	logDebug2(" sDealrCnvtToDel :%s:",sDealrCnvtToDel);

	if(mysql_query(DBQueries,sDealrCnvtToDel) != SUCCESS)
	{
		logSqlFatal("ERROR in DealrCnvToDel Query.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;


	pCTODHdrResp.IntRespHeader.iSeqNo = 0;
	pCTODHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCTODHdrResp.IntRespHeader.iErrorId = 0;
	pCTODHdrResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_HEADER_RESP;
	pCTODHdrResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
	pCTODHdrResp.IntRespHeader.cSource = pViewCTODReq->ReqHeader.cSource ;

	//                pCTODHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;

	pCTODHdrResp.cMsgType = 'H';
	pCTODHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pCTODHdrResp.cMsgType:%c:,pCTODHdrResp.iNoofRec:%d:",pCTODHdrResp.cMsgType,pCTODHdrResp.iNoofRec);

	logDebug2("pViewCTODReq->ReqHeader.iUserId = %llu",pViewCTODReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewCTODReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}



	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{

				pCTODResp.IntRespHeader.iSeqNo = 0;
				pCTODResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY);
				pCTODResp.IntRespHeader.iErrorId = 0;
				pCTODResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_RESP;
				pCTODResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
				pCTODResp.IntRespHeader.cSource  = pViewCTODReq->ReqHeader.cSource ;
				//                		pCTODResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;	

				if(iTempNoOfRec <= 1)
				{
					pCTODResp.cMsgType = 'T';
				}
				else
				{
					pCTODResp.cMsgType = 'D';
				}

				strncpy(pCTODResp.subCTOD[j].sClientId,Row[8],CLIENT_ID_LEN);
				strncpy(pCTODResp.subCTOD[j].sSecurityID,Row[0],SECURITY_ID_LEN);
				pCTODResp.subCTOD[j].cProductSource = Row[2][0];
				pCTODResp.subCTOD[j].cProductDest = Row[3][0];
				pCTODResp.subCTOD[j].cSide = Row[4][0];
				pCTODResp.subCTOD[j].iQty = atoi(Row[5]);
				pCTODResp.subCTOD[j].fConvertPrice = atof(Row[6]);
				pCTODResp.subCTOD[j].cSegment = Row[7][0];
				strncpy(pCTODResp.subCTOD[j].sExcgId,Row[1],EXCHANGE_LEN);

				logDebug2(" pCTODResp.IntRespHeader.iSeqNo [%d]",pCTODResp.IntRespHeader.iSeqNo);
				logDebug2(" pCTODResp.IntRespHeader.iMsgLength [%d]",pCTODResp.IntRespHeader.iMsgLength);
				logDebug2(" pCTODResp.IntRespHeader.iErrorId [%d]",pCTODResp.IntRespHeader.iErrorId);
				logDebug2(" pCTODResp.IntRespHeader.iMsgCode [%d]",pCTODResp.IntRespHeader.iMsgCode);
				logDebug2(" pCTODResp.IntRespHeader.iUserId [%llu]",pCTODResp.IntRespHeader.iUserId);
				//				logDebug2(" pCTODResp.IntRespHeader.cUserTypeOrLogInfoType [%d]",pCTODResp.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug2(" pCTODResp.cMsgType [%c]",pCTODResp.cMsgType);
				logDebug2(" pCTODResp.subCTOD[%d].sClientId [%s]",j,pCTODResp.subCTOD[j].sClientId);
				logDebug2(" pCTODResp.subCTOD[%d].sSecurityID [%s]",j,pCTODResp.subCTOD[j].sSecurityID);
				logDebug2(" pCTODResp.subCTOD[%d].cProductSource [%c]",j,pCTODResp.subCTOD[j].cProductSource);
				logDebug2(" pCTODResp.subCTOD[%d].cProductDest [%c]",j,pCTODResp.subCTOD[j].cProductDest);
				logDebug2(" pCTODResp.subCTOD[%d].cSide [%c]",j,pCTODResp.subCTOD[j].cSide);
				logDebug2(" pCTODResp.subCTOD[%d].iQty [%d]",j,pCTODResp.subCTOD[j].iQty);
				logDebug2(" pCTODResp.subCTOD[%d].fConvertPrice [%d]",j,pCTODResp.subCTOD[j].fConvertPrice);
				logDebug2(" pCTODResp.subCTOD[%d].cSegment [%c]",j,pCTODResp.subCTOD[j].cSegment);
				logDebug2(" pCTODResp.subCTOD[%d].sExcgId [%s]",j,pCTODResp.subCTOD[j].sExcgId);


				iTempNoOfRec--;
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODResp,sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}


	}



	return TRUE;	

}




BOOL 	fDealerTradeBook(CHAR *RcvMsg,BOOL iMrgTypeFlg)
{
	logTimestamp("Entry : fDealerTradeBook");

	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetDealrTrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;

	CHAR		sWhereQry[MAX_QUERY_SIZE];

	memset(sWhereQry,'\0',MAX_QUERY_SIZE);	

	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);

	if(iMrgTypeFlg == TRUE)
	{
		if(strcmp(sClientId,"-1") == 0)
		{
			sprintf(sWhereQry," AND CLIENT_ID IN (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
				UNION SELECT D.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING D WHERE D.EDM_DEALER_ID = ltrim(rtrim(\"%s\")))\
				ORDER BY ORDER_DATE_TIME DESC ",sEntityId,sEntityId);
		}
		else
		{
			sprintf(sWhereQry," AND CLIENT_ID IN (select E.ENTITY_CODE FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
				UNION SELECT D.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING D WHERE D.EDM_DEALER_ID = ltrim(rtrim(\"%s\")) AND D.EDM_CLIENT_ID = ltrim(rtrim(\"%s\")))\
				ORDER BY ORDER_DATE_TIME DESC ",sEntityId,sEntityId,sClientId);
		}

	}
	else
	{
		if(strcmp(sClientId,"-1") == 0)
		{
			sprintf(sWhereQry," ORDER BY ORDER_DATE_TIME DESC ");
		}
		else
		{
			sprintf(sWhereQry," AND CLIENT_ID  = ltrim(rtrim(\"%s\")) ORDER BY ORDER_DATE_TIME DESC ",sClientId);
		}
	}


	sprintf(sGetDealrTrdBook,"SELECT CLIENT_ID,SEM_SMST_SECURITY_ID,ORDER_DATE_TIME,ORDER_NUMBER,EXCH_ORDER_NUMBER,TRADE_NUMBER,EXCH,BUY_SELL,SEGMENT,ORDER_TYPE,\
			PRODUCT,QUANTITY,PRICE,TRADE_VALUE,JDATE,PLACEDBY,STRATEGY_ID,\
			LEGVALUE,IFNULL(PAN_NO,'NA'),IFNULL(PARTICIPANT_TYPE,'B'),IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1),IFNULL(SETTLOR,'NA'), \
			IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),MKT_TYPE FROM(SELECT A.EQ_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r,\
				A.EQ_SCRIP_CODE AS SEM_SMST_SECURITY_ID, DATE_FORMAT(A.EQ_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME,\
				A.EQ_ORDER_NO AS ORDER_NUMBER, A.EQ_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, A.EQ_TRD_EXCH_TRADE_NO AS TRADE_NUMBER,\
				A.EQ_EXCH_ID AS EXCH, (CASE A.EQ_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, 'E' AS SEGMENT,\
				(CASE A.EQ_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE, \
				A.EQ_SYMBOL AS SYMBOL, \
				(CASE A.EQ_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' WHEN 'S' THEN 'COLLATERAL' \
				 WHEN 'I' THEN 'INTRADAY' WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE A.EQ_PRODUCT_ID END) AS PRODUCT,\
				A.EQ_LAST_TRADE_QTY AS QUANTITY,IFNULL(A.EQ_TRD_TRADE_PRICE, 0) AS PRICE,\
				ROUND((A.EQ_TRD_TRADE_PRICE * A.EQ_LAST_TRADE_QTY), 4) AS TRADE_VALUE,A.EQ_SCRIP_CODE AS SECURITY_ID,\
				A.EQ_PRODUCT_ID AS TRD_PRODUCT,JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,\
				A.EQ_ENTITY_ID AS PLACEDBY,IFNULL(A.EQ_STRATEGY_ID,0) AS STRATEGY_ID,A.EQ_LEG_NO AS LEGVALUE,\
				A.EQ_PAN_NO AS PAN_NO,A.EQ_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,A.EQ_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,A.EQ_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
				A.EQ_SETTLOR AS SETTLOR,A.EQ_GTC_FLG AS GTC_FLG,A.EQ_ENCASH_FLG AS ENCASH_FLG ,A.EQ_MKT_TYPE AS MKT_TYPE FROM EQ_ORDERS A \
				CROSS JOIN (SELECT @rn:=0) r WHERE ((A.EQ_MSG_CODE = '2222') AND (A.EQ_TRD_STATUS = 'C')\ 
					) UNION ALL SELECT B.DRV_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r, \
				B.DRV_SCRIP_CODE AS SEM_SMST_SECURITY_ID, DATE_FORMAT(B.DRV_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME, \
				B.DRV_ORDER_NO AS ORDER_NUMBER, B.DRV_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, B.DRV_TRD_EXCH_TRADE_NO AS TRADE_NUMBER, \
				B.DRV_EXCH_ID AS EXCH, (CASE B.DRV_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, \
				B.DRV_SEGMENT AS SEGMENT, \
				(CASE B.DRV_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\
				B.DRV_SYMBOL AS SYMBOL,(CASE B.DRV_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' \
						WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF' ELSE B.DRV_PRODUCT_ID END) AS PRODUCT,\
				B.DRV_TRD_TRADE_QTY AS QTY,IFNULL(B.DRV_TRD_TRADE_PRICE, 0) AS PRICE, (CASE WHEN (B.DRV_SEGMENT = 'C') \
						THEN ROUND(((B.DRV_TRD_TRADE_PRICE * B.DRV_TRD_TRADE_QTY) * 1000), 4) \
						ELSE ROUND((B.DRV_TRD_TRADE_PRICE * B.DRV_TRD_TRADE_QTY), 2) END) AS TRADE_VALUE, B.DRV_SCRIP_CODE AS SECURITY_ID, \
				B.DRV_PRODUCT_ID AS TRD_PRODUCT,JULIDATE(B.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
				B.DRV_ENTITY_ID AS PLACEDBY,IFNULL(B.DRV_STRATEGY_ID,0) AS STRATEGY_ID,B.DRV_LEG_NO AS LEGVALUE,\
				B.DRV_PAN_NO AS PAN_NO,\
				B.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,B.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,B.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
				B.DRV_SETTLOR AS SETTLOR,B.DRV_GTC_FLG AS GTC_FLG,B.DRV_ENCASH_FLG AS ENCASH_FLG,B.DRV_MKT_TYPE AS MKT_TYPE\
				FROM DRV_ORDERS B CROSS JOIN (SELECT @rn:=0) r WHERE ((B.DRV_MSG_CODE = '2222') AND (B.DRV_TRD_STATUS = 'C') \
						AND B.DRV_CF_FLAG <> -1 )\
				UNION ALL SELECT C.COMM_CLIENT_ID AS CLIENT_ID, @rn:=@rn + 1 AS r, C.COMM_SCRIP_CODE AS SEM_SMST_SECURITY_ID, \
				DATE_FORMAT(C.COMM_TRD_TRADE_TIME, '%%d-%%m-%%Y %%T') AS ORDER_DATE_TIME, C.COMM_ORDER_NO AS ORDER_NUMBER, \
				C.COMM_EXCH_ORDER_NO AS EXCH_ORDER_NUMBER, C.COMM_TRD_EXCH_TRADE_NO AS TRADE_NUMBER, C.COMM_EXCH_ID AS EXCH, \
				(CASE C.COMM_BUY_SELL_IND WHEN 'B' THEN 'Buy' WHEN 'S' THEN 'Sell' END) AS BUY_SELL, 'M' AS SEGMENT, \
				(CASE C.COMM_ORDER_TYPE WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT' WHEN '3' THEN 'SL-M' WHEN '4' THEN 'SL' END) AS ORDER_TYPE,\ 
				C.COMM_SYMBOL AS SYMBOL,(CASE C.COMM_PRODUCT_ID WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN' WHEN 'L' THEN 'MLB' \
						WHEN 'S' THEN 'COLLATERAL' WHEN 'I' THEN 'INTRADAY' WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO' WHEN 'H' THEN 'NORMAL' WHEN 'F' THEN 'MTF'\
						ELSE C.COMM_PRODUCT_ID END) AS PRODUCT, C.COMM_TRD_TRADE_QTY AS QTY,IFNULL(C.COMM_TRD_TRADE_PRICE, 0) AS PRICE, \
				ROUND(((C.COMM_TRD_TRADE_PRICE * C.COMM_TRD_TRADE_QTY) * C.COMM_MULTIPLIER), 2) AS TRADE_VALUE,\
				C.COMM_SCRIP_CODE AS SECURITY_ID,C.COMM_PRODUCT_ID AS TRD_PRODUCT,\
				JULIDATE(C.COMM_INTERNAL_ENTRY_DATE) AS JDATE,C.COMM_ENTITY_ID AS PLACEDBY,\
				IFNULL(C.COMM_STRATEGY_ID,0) AS STRATEGY_ID,C.COMM_LEG_NO AS LEGVALUE,C.COMM_PAN_NO AS PAN_NO,C.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE, \
				C.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,C.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,\
				C.COMM_SETTLOR AS SETTLOR,C.COMM_GTC_FLG AS GTC_FLG,C.COMM_ENCASH_FLG AS ENCASH_FLG,C.COMM_MKT_TYPE AS MKT_TYPE FROM COMM_ORDERS C \
				CROSS JOIN (SELECT @rn:=0) r WHERE ((C.COMM_MSG_CODE = '2222')\
						AND (C.COMM_TRD_STATUS = 'C') AND C.COMM_CF_FLAG <> -1 )) tradebook\
						WHERE 1=1 %s ;",sWhereQry);
	printf("sGetDealrTrdBook :%s:",sGetDealrTrdBook);

	if(mysql_query(DBQueries,sGetDealrTrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR in GetDealrTrdBook Query.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/

	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	pTradeBookHdrResp.IntRespHeader.cSource = pViewTradeBookReq->ReqHeader.cSource;
	//	pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);
	logDebug2("pViewTradeBookReq->ReqHeader.iUserId = %llu",pViewTradeBookReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pViewTradeBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pTradeBookResp,'\0',sizeof(struct VIEW_TRADE_BOOK_RESP));
		pTradeBookResp.IntRespHeader.iSeqNo = 0;
		pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
		pTradeBookResp.IntRespHeader.iErrorId = 0;
		pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_TRADE_BOOK_RESP;
		pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
		pTradeBookResp.IntRespHeader.cSource  = pViewTradeBookReq->ReqHeader.cSource ;
		//                              pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

		if(iTempNoOfRec <= 1)
		{
			pTradeBookResp.cMsgType = 'T';
		}
		else
		{
			pTradeBookResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{
				strncpy(pTradeBookResp.subTradeBook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,Row[1] ,SECURITY_ID_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sDatetime,Row[2],DATE_LENGTH);
				pTradeBookResp.subTradeBook[j].fOrderNo = atof(Row[3]);
				strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,Row[4],BSE_EXCH_ORDER_NO_LEN);
				pTradeBookResp.subTradeBook[j].fTradeNo = atof(Row[5]);
				strncpy(pTradeBookResp.subTradeBook[j].sExcgId,Row[6],EXCHANGE_LEN);
				strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,Row[7],5);
				pTradeBookResp.subTradeBook[j].cSegment = Row[8][0];
				strncpy(pTradeBookResp.subTradeBook[j].sOrderType,Row[9],8);
				strncpy(pTradeBookResp.subTradeBook[j].sProduct,Row[10],10);
				pTradeBookResp.subTradeBook[j].fTradeQty = atof(Row[11]);
				pTradeBookResp.subTradeBook[j].fTradePrice = atof(Row[12]);
				pTradeBookResp.subTradeBook[j].fTradeVal = atof(Row[13]);
				pTradeBookResp.subTradeBook[j].iDateTime = atol(Row[14]);
				strncpy(pTradeBookResp.subTradeBook[j].sEntityId,Row[15],ENTITY_ID_LEN);
				pTradeBookResp.subTradeBook[j].iStrategyId = atoi (Row[16]);
				pTradeBookResp.subTradeBook[j].iLegValue = atoi(Row[17]);
				strncpy(pTradeBookResp.subTradeBook[j].sPanID,Row[18],INT_PAN_LEN);
				pTradeBookResp.subTradeBook[j].cParticipantType = Row[19][0];
				pTradeBookResp.subTradeBook[j].cMarkProFlag = Row[20][0];
				pTradeBookResp.subTradeBook[j].fMarkProVal = atof(Row[21]);
				strncpy(pTradeBookResp.subTradeBook[j].sSettlor,Row[22],SETTLOR_LEN);
				pTradeBookResp.subTradeBook[j].cGTCFlag =  Row[23][0];
				pTradeBookResp.subTradeBook[j].cEncashFlag =  Row[24][0];

				strncpy(pTradeBookResp.subTradeBook[j].sMktType,Row[25],MKT_TYPE_LEN);

				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
				logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
				logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%llu:",pTradeBookResp.IntRespHeader.iUserId);
				logDebug2(" pTradeBookResp.IntRespHeader.cSource:%c:",pTradeBookResp.IntRespHeader.cSource);
				logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
				logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
				logDebug2(" ----------------- Printing Header ------------------------------------");
				logDebug2("pTradeBookResp.subTradeBook[%d].sClientId = %s",j,pTradeBookResp.subTradeBook[j].sClientId);
				logDebug2("pTradeBookResp.subTradeBook[%d].sSecurityID = %s",j,pTradeBookResp.subTradeBook[j].sSecurityID);
				logDebug2("pTradeBookResp.subTradeBook[%d].sDatetime = %s",j,pTradeBookResp.subTradeBook[j].sDatetime);
				logDebug2("pTradeBookResp.subTradeBook[%d].fOrderNo = %lf",j,pTradeBookResp.subTradeBook[j].fOrderNo);
				logDebug2("pTradeBookResp.subTradeBook[%d].sExchOrderNumber = %s",j,pTradeBookResp.subTradeBook[j].sExchOrderNumber);
				logDebug2("pTradeBookResp.subTradeBook[%d].fTradeNo = %lf",j,pTradeBookResp.subTradeBook[j].fTradeNo);
				logDebug2("pTradeBookResp.subTradeBook[%d].sExcgId = %s",j,pTradeBookResp.subTradeBook[j].sExcgId);
				logDebug2("pTradeBookResp.subTradeBook[%d].sBuySellInd = %s",j,pTradeBookResp.subTradeBook[j].sBuySellInd);
				logDebug2("pTradeBookResp.subTradeBook[%d].cSegment = %c",j,pTradeBookResp.subTradeBook[j].cSegment);
				logDebug2("pTradeBookResp.subTradeBook[%d].sOrderType = %s",j,pTradeBookResp.subTradeBook[j].sOrderType);
				logDebug2("pTradeBookResp.subTradeBook[%d].sProduct = %s",j,pTradeBookResp.subTradeBook[j].sProduct);
				logDebug2("pTradeBookResp.subTradeBook[%d].fTradeQty = %d",j,pTradeBookResp.subTradeBook[j].fTradeQty);
				logDebug2("pTradeBookResp.subTradeBook[%d].fTradePrice = %lf",j,pTradeBookResp.subTradeBook[j].fTradePrice);
				logDebug2("pTradeBookResp.subTradeBook[%d].fTradeVal = %lf",j,pTradeBookResp.subTradeBook[j].fTradeVal);
				logDebug2("pTradeBookResp.subTradeBook[%d].iDateTime = %d",j,pTradeBookResp.subTradeBook[j].iDateTime);
				logDebug2("pTradeBookResp.subTradeBook[%d].sEntityId = %s",j,pTradeBookResp.subTradeBook[j].sEntityId);
				logDebug2("pTradeBookResp.subTradeBook[%d].iStrategyId = %d",j,pTradeBookResp.subTradeBook[j].iStrategyId);
				logDebug2("pTradeBookResp.subTradeBook[%d].iLegValue = %d",j,pTradeBookResp.subTradeBook[j].iLegValue);
				logDebug2("pTradeBookResp.subTradeBook[%d].sPanID = %s",j,pTradeBookResp.subTradeBook[j].sPanID);
				logDebug2("pTradeBookResp.subTradeBook[%d].cParticipantType = %c",j,pTradeBookResp.subTradeBook[j].cParticipantType);
				logDebug2("pTradeBookResp.subTradeBook[%d].cMarkProFlag = %c",j,pTradeBookResp.subTradeBook[j].cMarkProFlag);
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
		usleep(500); /** This is done to give a slow response to the Rapid Rupee **/

	}

	logTimestamp("Exit : fDealerTradeBook");
	return TRUE;

}/************** END of fDealerTradeBook ****/
BOOL fClientCarryFwdPosition(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_STRING_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;


	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);


	/********
	  SELECT  count(1)
INTO :iNoOfRec
from VIEW_CARRY_FWD_POSITION , entity_master em
WHERE CLIENT_ID = em.em_entity_id
AND CLIENT_ID like decode(ltrim(rtrim(:sClientId)),'-1','%',ltrim(rtrim(:sClientId)));
	 ********/

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_CARRY_FWD_POS_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	pTradeBookHdrResp.IntRespHeader.cSource  = pViewTradeBookReq->ReqHeader.cSource ;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);
	logDebug2("pViewTradeBookReq->ReqHeader.iUserId = %llu",pViewTradeBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewTradeBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}
	/****
	  SELECT	ORDER_NUMBER,
	  SEM_SMST_SECURITY_ID,
	  BUY_SELL,
	  ORDER_TYPE,
	  EXCH_ORDER_NUMBER,
	  TRADE_NUMBER,
	  PRODUCT,
	  QUANTITY,
	  PRICE,
	  TRADE_VALUE,
	  ORDER_DATE_TIME,
	  EXCHANGE,
	  SEGMENT,
	  CLIENT_ID
	  FROM VIEW_CARRY_FWD_POSITION , entity_master em
	  WHERE CLIENT_ID = em.em_entity_id
	  AND CLIENT_ID like decode(ltrim(rtrim(:sClientId)),'-1','%',ltrim(rtrim(:sClientId)))
	  ORDER BY ORDER_DATE_TIME DESC;********/




	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			fOrderNo=0;
			fTradeQty=0;


			memset(sBuySellInd ,'\0',5);

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);

			memset(sOrderType ,'\0',8);

			memset(sExchOrderNumber ,'\0',BSE_EXCH_ORDER_NO_LEN);

			memset(sDatetime ,'\0',DATE_STRING_LENGTH);

			memset(ExcgId ,'\0',EXCHANGE_LEN);

			memset(sRespClientId ,'\0',CLIENT_ID_LEN);

			memset(sProduct ,'\0',10);


			Segment = '\0';	

			/*********

			  :fOrderNo,
			  :sSecurityID,
			  :sBuySellInd,
			  :sOrderType,
			  :sExchOrderNumber,
			  :fTradeNo,
			  :sProduct,
			  :fTradeQty,
			  :fTradePrice,
			  :fTradeVal,
			  :sDatetime,
			  :ExcgId,
			  :Segment,
			  :sRespClientId;
			 ********/



			pTradeBookResp.IntRespHeader.iSeqNo = 0;
			pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
			pTradeBookResp.IntRespHeader.iErrorId = 0;
			pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_CARRY_FWD_POS_RESP;
			pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
			pTradeBookResp.IntRespHeader.cSource  = pViewTradeBookReq->ReqHeader.cSource ;
			//                pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pTradeBookResp.cMsgType = 'T';
			}
			else
			{
				pTradeBookResp.cMsgType = 'D';
			}

			pTradeBookResp.subTradeBook[j].fOrderNo = fOrderNo;
			strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sOrderType,sOrderType ,8);
			pTradeBookResp.subTradeBook[j].fTradeQty = fTradeQty;
			pTradeBookResp.subTradeBook[j].fTradePrice = fTradePrice;
			pTradeBookResp.subTradeBook[j].fTradeVal = fTradeVal;
			pTradeBookResp.subTradeBook[j].fTradeNo = fTradeNo;
			pTradeBookResp.subTradeBook[j].cSegment = Segment;
			memset(pTradeBookResp.subTradeBook[j].sBuySellInd,'\0',5);
			strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,sBuySellInd ,5);

			strncpy(pTradeBookResp.subTradeBook[j].sProduct,sProduct ,10);
			strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,sExchOrderNumber ,BSE_EXCH_ORDER_NO_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sDatetime,sDatetime ,DATE_STRING_LENGTH);
			strncpy(pTradeBookResp.subTradeBook[j].sClientId,sRespClientId ,CLIENT_ID_LEN);

			strncpy(pTradeBookResp.subTradeBook[j].sExcgId,ExcgId ,EXCHANGE_LEN);

			logDebug2(" ----------------- Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
			logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%llu:",pTradeBookResp.IntRespHeader.iUserId);
			//		logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
			logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
			logDebug2(" pTradeBookResp.subTradeBook[j].sExcgId :%s: strlen(pTradeBookResp.subTradeBook[j].sExcgId):%d:",pTradeBookResp.subTradeBook[j].sExcgId,strlen(pTradeBookResp.subTradeBook[j].sExcgId));
			logDebug2(" ----------------- Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
			logDebug2(" pTradeBookResp.subTradeBook[j].fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
			logDebug2(" pTradeBookResp.subTradeBoo[j]k.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook[j].sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
			logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
			logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
			logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
			logDebug2(" pTradeBookResp.subTradeBook.fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ );
			return FALSE;
		}
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/



	}


	return TRUE;

}/************** END of fClientCarryFwdPosition ****/
/***************************************************/
BOOL fClientConvetToDel(CHAR *RcvMsg)
{

	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sCltCnvtToDel = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);


	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR		sSecurityID[SECURITY_ID_LEN];
	CHAR		cProductSource;
	CHAR		cProductDest;
	CHAR		cSide;
	LONG32		iQty;
	CHAR		sExcgId[EXCHANGE_LEN];
	CHAR		sClientId[CLIENT_ID_LEN];
	LONG32		iNoOfRec=0;
	LONG32		iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR		cSegment;	

	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewCTODReq->sClientId,CLIENT_ID_LEN);
	logDebug2(" sClientId  is n fClientConvetToDel :%s: ",sClientId );



	/*****
	  SELECT  count(1)
INTO :iNoOfRec
from RMS_CLIENT_CONVT_TO_DEL
WHERE RCCD_CLIENT_ID = ltrim(rtrim(:sClientId));
	 ********/
	sprintf(sCltCnvtToDel,"SELECT  RCCD_SCRIP_CODE,\
			RCCD_EXCHANGE,\
			RCCD_PRODUCT_SOURCE,\
			RCCD_PRODUCT_DESTINATION,\
			RCCD_SIDE,\
			RCCD_QTY,\
			RCCD_CONVT_PRICE,\
			RCCD_SEGMENT\
			FROM RMS_CLIENT_CONVT_TO_DEL\
			WHERE RCCD_CLIENT_ID = ltrim(rtrim(\"%s\")); ",sClientId);

	logDebug2("\n sCltCnvtToDel :%s:",sCltCnvtToDel);	
	if(mysql_query(DBQueries,sCltCnvtToDel) != SUCCESS)
	{
		logSqlFatal("ERROR in CltCnvtToDel Query.");			
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);


	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;


	pCTODHdrResp.IntRespHeader.iSeqNo = 0;
	pCTODHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCTODHdrResp.IntRespHeader.iErrorId = 0;
	pCTODHdrResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_HEADER_RESP;
	pCTODHdrResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
	pCTODHdrResp.IntRespHeader.cSource  = pViewCTODReq->ReqHeader.cSource ;
	//		pCTODHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;

	pCTODHdrResp.cMsgType = 'H';
	pCTODHdrResp.iNoofRec = iNoOfRec;

	logDebug2("\n pCTODHdrResp.cMsgType:%c:,pCTODHdrResp.iNoofRec:%d:",pCTODHdrResp.cMsgType,pCTODHdrResp.iNoofRec);
	logDebug2("pViewCTODReq->ReqHeader.iUserId = %llu",pViewCTODReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewCTODReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{

				pCTODResp.IntRespHeader.iSeqNo = 0;
				pCTODResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY);
				pCTODResp.IntRespHeader.iErrorId = 0;
				pCTODResp.IntRespHeader.iMsgCode = TC_INT_CONVT_TO_DELV_RESP;
				pCTODResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
				pCTODResp.IntRespHeader.cSource = pViewCTODReq->ReqHeader.cSource ;
				//				pCTODResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pCTODResp.cMsgType = 'T';
				}
				else
				{
					pCTODResp.cMsgType = 'D';
				}

				strncpy(pCTODResp.subCTOD[j].sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pCTODResp.subCTOD[j].sSecurityID,Row[0],SECURITY_ID_LEN);
				pCTODResp.subCTOD[j].cProductSource = Row[2][0];
				pCTODResp.subCTOD[j].cProductDest = Row[3][0];
				pCTODResp.subCTOD[j].cSide = Row[4][0];
				pCTODResp.subCTOD[j].iQty = atoi(Row[5]);
				pCTODResp.subCTOD[j].fConvertPrice = atof(Row[6]);
				pCTODResp.subCTOD[j].cSegment = Row[7][0];
				strncpy(pCTODResp.subCTOD[j].sExcgId,Row[1],EXCHANGE_LEN);

				iTempNoOfRec--;
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pCTODResp,sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}


	}



	return TRUE;
}

BOOL fSendMsgtoClient(CHAR *RcvMsg)
{
	struct SEND_MSG_TO_CLIENT_REQ *pSendMsgtoClientReq;
	struct SEND_MSG_TO_CLIENT_RESP     pSendMsgtoClientResp;

	LONG32 iNoOfRec=0;
	LONG32 i=0;

	pSendMsgtoClientReq = (struct SEND_MSG_TO_CLIENT *)RcvMsg;

	iNoOfRec = pSendMsgtoClientReq->iNoOfRec;

	logDebug2("\n pSendMsgtoClientReq->iNoOfRec :%d:",pSendMsgtoClientReq->iNoOfRec);
	logDebug2("\n pSendMsgtoClientReq->sMsg :%s",pSendMsgtoClientReq->sMsg);

	for(i=0;i<iNoOfRec;i++)
	{
		logDebug2("\n pSendMsgtoClientReq->iReceiverUserId[%d] :%d",i,pSendMsgtoClientReq->iReceiverUserId[i]);
		pSendMsgtoClientResp.IntRespHeader.iSeqNo = 0;
		pSendMsgtoClientResp.IntRespHeader.iMsgLength = sizeof(struct SEND_MSG_TO_CLIENT_RESP);
		pSendMsgtoClientResp.IntRespHeader.iErrorId = 0;
		pSendMsgtoClientResp.IntRespHeader.iMsgCode = TC_INT_SEND_MSG_TO_CLIENT_RESP;
		pSendMsgtoClientResp.IntRespHeader.iUserId = pSendMsgtoClientReq->iReceiverUserId[i];
		//		pSendMsgtoClientResp.IntRespHeader.cUserTypeOrLogInfoType = 'C';

		strncpy(pSendMsgtoClientResp.sSender,pSendMsgtoClientReq->sSender,CLIENT_ID_LEN);
		strncpy(pSendMsgtoClientResp.sMsg,pSendMsgtoClientReq->sMsg,SEND_MSG_LEN);

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pSendMsgtoClientResp,sizeof(struct SEND_MSG_TO_CLIENT_RESP) ,1 ) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

	}


	pSendMsgtoClientResp.IntRespHeader.iUserId = pSendMsgtoClientReq->ReqHeader.iUserId;	
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pSendMsgtoClientResp,sizeof(struct SEND_MSG_TO_CLIENT_RESP) ,1 ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}


	return TRUE;


}/** End fSendMsgtoClient ***/
BOOL fDNLDSystemMsg(CHAR *RcvMsg)
{

	logDebug2("\n [In fDNLDSystemMsg]");
	struct VIEW_COMMON_QUERY_REQ *pDNLDSystemMsgReq;
	struct DWS_DNLD_SYS_MESGS_RESP     pDNLDSystemMsgResp;
	struct VIEW_COMMON_HDR_RESP     pDNLDSystemMsgHdrResp;
	CHAR	*sSelQury = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	MYSQL_RES	*Res;
	MYSQL_ROW	Row;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sGenralMsg[SYSTEM_MSG_LEN];
	CHAR         sExcgId[EXCHANGE_LEN];
	LONG32          iNoOfRec;
	CHAR            cSegment;
	ULONG64		iUserId;
	LONG32		iMsgCode;
	LONG32		iTempNoOfRec;

	pDNLDSystemMsgReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	iUserId = pDNLDSystemMsgReq->ReqHeader.iUserId;

	sprintf(sSelQury,"SELECT  SM_TRANS_CODE,\
			SM_EXCH_ID,\
			SM_SEGMENT,\
			DATE_FORMAT(SM_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\
			SM_GENERAL_MESG\
			FROM SYSTEM_MESGS\
			WHERE SM_USER_ID = %llu;",iUserId);

	logDebug2("sSelQury :%s:",sSelQury);	

	if(mysql_query(DBQueries,sSelQury) != SUCCESS)
	{
		logSqlFatal("ERROR in fDNLDSystemMsg QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec = mysql_num_rows(Res);
	logDebug2("iNoOfRec = %d",iNoOfRec);
	iTempNoOfRec = iNoOfRec;

	pDNLDSystemMsgHdrResp.IntRespHeader.iSeqNo = 0;
	pDNLDSystemMsgHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pDNLDSystemMsgHdrResp.IntRespHeader.iErrorId = 0;
	pDNLDSystemMsgHdrResp.IntRespHeader.iMsgCode = TC_INT_DNLD_SYSTEM_MSG_HDR_RESP;
	pDNLDSystemMsgHdrResp.IntRespHeader.iUserId = pDNLDSystemMsgReq->ReqHeader.iUserId;
	pDNLDSystemMsgHdrResp.IntRespHeader.cSource = pDNLDSystemMsgReq->ReqHeader.cSource ;
	//	pDNLDSystemMsgHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pDNLDSystemMsgReq->ReqHeader.cUserType;

	pDNLDSystemMsgHdrResp.cMsgType = 'H';
	pDNLDSystemMsgHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pDNLDSystemMsgHdrResp.cMsgType:%c:,pDNLDSystemMsgHdrResp.iNoofRec:%d:",pDNLDSystemMsgHdrResp.cMsgType,pDNLDSystemMsgHdrResp.iNoofRec);
	logDebug2("pDNLDSystemMsgReq->ReqHeader.iUserId = %llu",pDNLDSystemMsgReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pDNLDSystemMsgReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pDNLDSystemMsgHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}

	//for(i=0;i<iNoOfRec;i++)	
	while((Row=mysql_fetch_row(Res)))
	{


		pDNLDSystemMsgResp.IntRespHeader.iSeqNo = 0;
		pDNLDSystemMsgResp.IntRespHeader.iMsgLength = sizeof(struct DWS_DNLD_SYS_MESGS_RESP);
		pDNLDSystemMsgResp.IntRespHeader.iErrorId = 0;
		pDNLDSystemMsgResp.IntRespHeader.iMsgCode = TC_INT_DNLD_SYSTEM_MSG_RESP;
		strncpy(pDNLDSystemMsgResp.IntRespHeader.sExcgId,Row[1],EXCHANGE_LEN);
		pDNLDSystemMsgResp.IntRespHeader.iUserId = pDNLDSystemMsgReq->ReqHeader.iUserId;
		pDNLDSystemMsgResp.IntRespHeader.cSource  = pDNLDSystemMsgReq->ReqHeader.cSource;
		//			pDNLDSystemMsgResp.IntRespHeader.cUserTypeOrLogInfoType = pDNLDSystemMsgReq->ReqHeader.cUserType;
		pDNLDSystemMsgResp.IntRespHeader.cSegment = Row[2][0];


		if(iTempNoOfRec <= 1)
		{
			pDNLDSystemMsgResp.cMsgType = 'T';
		}
		else
		{
			pDNLDSystemMsgResp.cMsgType = 'D';
		}

		strncpy(pDNLDSystemMsgResp.sDatetime,Row[3],DATE_LENGTH);
		strncpy(pDNLDSystemMsgResp.sGenralMsg,Row[4],SYSTEM_MSG_LEN);
		pDNLDSystemMsgResp.iMsgCode = atoi(Row[0]);

		iTempNoOfRec--;

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pDNLDSystemMsgResp,sizeof(struct DWS_DNLD_SYS_MESGS_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}

		usleep(100);



	}

	return TRUE;

}

BOOL fSurvillenceTradeBook(CHAR *RcvMsg)
{
	struct VIEW_COMMON_QUERY_REQ *pViewTradeBookReq;
	struct VIEW_TRADE_BOOK_RESP	pTradeBookResp;
	struct VIEW_COMMON_HDR_RESP	pTradeBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	DOUBLE64        fOrderNo;
	CHAR         sBuySellInd[5];
	CHAR         sSecurityID[SECURITY_ID_LEN];
	CHAR         sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR         sDatetime[DATE_LENGTH];
	CHAR         sOrderType[8];
	CHAR         sProduct[10];
	DOUBLE64        fTradePrice;
	DOUBLE64        fTradeQty;
	DOUBLE64        fTradeVal;
	DOUBLE64        fTradeNo;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sRespClientId[CLIENT_ID_LEN];
	CHAR         ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iDateTime;	


	pViewTradeBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewTradeBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewTradeBookReq->sEntityId,ENTITY_ID_LEN);


	/*****
	  SELECT  count(1)
INTO :iNoOfRec
from TRADEBOOK tb;
	 ****/

	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pTradeBookHdrResp.IntRespHeader.iSeqNo = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pTradeBookHdrResp.IntRespHeader.iErrorId = 0;
	pTradeBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_TRADE_BOOK_HEADER_RESP;
	pTradeBookHdrResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
	pTradeBookHdrResp.IntRespHeader.cSource  = pViewTradeBookReq->ReqHeader.cSource ;
	//		pTradeBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;

	pTradeBookHdrResp.cMsgType = 'H';
	pTradeBookHdrResp.iNoofRec = iNoOfRec;

	logDebug2("\n Survillenece Admin pTradeBookHdrResp.cMsgType:%c:,pTradeBookHdrResp.iNoofRec:%d:",pTradeBookHdrResp.cMsgType,pTradeBookHdrResp.iNoofRec);
	logDebug2("pViewTradeBookReq->ReqHeader.iUserId = %llu",pViewTradeBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewTradeBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pTradeBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
	/*******
	  SELECT	ORDER_NUMBER,
	  SEM_SMST_SECURITY_ID,
	  BUY_SELL,
	  ORDER_TYPE,
	  EXCH_ORDER_NUMBER,
	  TRADE_NUMBER,
	  PRODUCT,
	  QUANTITY,
	  PRICE,
	  TRADE_VALUE,
	  to_char(to_date(ORDER_DATE_TIME,'DD-MM-YYYY HH:MI:SS AM'),'DD-MM-YYYY HH:MI:SS AM'),
	  EXCHANGE,
	  SEGMENT,
	  CLIENT_ID,
	  julidate(to_date(ORDER_DATE_TIME,'DD-MM-YYYY HH:MI:SS AM'))
	  FROM TRADEBOOK tb
	  ORDER BY ORDER_DATE_TIME DESC;*******/


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			fOrderNo=0;
			fTradeQty=0;


			memset(sBuySellInd ,'\0',5);

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);

			memset(sOrderType ,'\0',8);

			memset(sExchOrderNumber ,'\0',BSE_EXCH_ORDER_NO_LEN);

			memset(sDatetime ,'\0',DATE_LENGTH);

			memset(ExcgId ,'\0',EXCHANGE_LEN);

			memset(sRespClientId ,'\0',CLIENT_ID_LEN);

			memset(sProduct ,'\0',10);


			Segment = '\0';	
			iDateTime=0;


			/***********
			  :fOrderNo,
			  :sSecurityID,
			  :sBuySellInd,
			  :sOrderType,
			  :sExchOrderNumber,
			  :fTradeNo,
			  :sProduct,
			  :fTradeQty,
			  :fTradePrice,
			  :fTradeVal,
			  :sDatetime,
			  :ExcgId,
			  :Segment,
			  :sRespClientId,
			  :iDateTime;
			 ******/	



			pTradeBookResp.IntRespHeader.iSeqNo = 0;
			pTradeBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_TRADE_BOOK_RESP);
			pTradeBookResp.IntRespHeader.iErrorId = 0;
			pTradeBookResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_TRADE_BOOK_RESP;
			pTradeBookResp.IntRespHeader.iUserId = pViewTradeBookReq->ReqHeader.iUserId;
			pTradeBookResp.IntRespHeader.cSource = pViewTradeBookReq->ReqHeader.cSource ;
			//                pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewTradeBookReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pTradeBookResp.cMsgType = 'T';
			}
			else
			{
				pTradeBookResp.cMsgType = 'D';
			}

			pTradeBookResp.subTradeBook[j].fOrderNo = fOrderNo;
			strncpy(pTradeBookResp.subTradeBook[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sOrderType,sOrderType ,8);
			pTradeBookResp.subTradeBook[j].fTradeQty = fTradeQty;
			pTradeBookResp.subTradeBook[j].fTradePrice = fTradePrice;
			pTradeBookResp.subTradeBook[j].fTradeVal = fTradeVal;
			pTradeBookResp.subTradeBook[j].fTradeNo = fTradeNo;
			pTradeBookResp.subTradeBook[j].cSegment = Segment;
			memset(pTradeBookResp.subTradeBook[j].sBuySellInd,'\0',5);
			strncpy(pTradeBookResp.subTradeBook[j].sBuySellInd,sBuySellInd ,5);

			strncpy(pTradeBookResp.subTradeBook[j].sProduct,sProduct ,10);
			strncpy(pTradeBookResp.subTradeBook[j].sExchOrderNumber,sExchOrderNumber ,BSE_EXCH_ORDER_NO_LEN);
			strncpy(pTradeBookResp.subTradeBook[j].sDatetime,sDatetime ,DATE_LENGTH);
			strncpy(pTradeBookResp.subTradeBook[j].sClientId,sRespClientId ,CLIENT_ID_LEN);

			strncpy(pTradeBookResp.subTradeBook[j].sExcgId,ExcgId ,EXCHANGE_LEN);
			pTradeBookResp.subTradeBook[j].iDateTime = iDateTime;

			logDebug2(" ----------------- Survillenece Admin  Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgLength :%d:",pTradeBookResp.IntRespHeader.iMsgLength);
			logDebug2(" pTradeBookResp.IntRespHeader.iMsgCode :%d:",pTradeBookResp.IntRespHeader.iMsgCode);
			logDebug2(" pTradeBookResp.IntRespHeader.iUserId:%llu:",pTradeBookResp.IntRespHeader.iUserId);
			//		logDebug2(" pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pTradeBookResp.IntRespHeader.cUserTypeOrLogInfoType);
			logDebug2(" pTradeBookResp.IntRespHeader.cSegment:%c:",pTradeBookResp.IntRespHeader.cSegment);
			logDebug2(" pTradeBookResp.subTradeBook[j].sExcgId :%s: strlen(pTradeBookResp.subTradeBook[j].sExcgId):%d:",pTradeBookResp.subTradeBook[j].sExcgId,strlen(pTradeBookResp.subTradeBook[j].sExcgId));
			logDebug2(" pTradeBookResp.subTradeBook[j]..sExchOrderNumber :%s: strlen(pTradeBookResp.subTradeBook[j]..sExchOrderNumber):%d:",pTradeBookResp.subTradeBook[j].sExchOrderNumber,strlen(pTradeBookResp.subTradeBook[j].sExchOrderNumber));
			logDebug2(" ----------------- Survillenece Admin Printing Header ------------------------------------");
			logDebug2(" pTradeBookResp.cMsgType :%c:",pTradeBookResp.cMsgType);
			logDebug2(" pTradeBookResp.subTradeBook[j].fOrderNo :%lf:",pTradeBookResp.subTradeBook[j].fOrderNo);
			logDebug2(" pTradeBookResp.subTradeBoo[j]k.sBuySellInd:%s: strlen(pTradeBookResp.subTradeBook[j].sBuySellInd):%d:",pTradeBookResp.subTradeBook[j].sBuySellInd,strlen(pTradeBookResp.subTradeBook[j].sBuySellInd));
			logDebug2(" pTradeBookResp.subTradeBook.sSecurityID:%s: strlen(pTradeBookResp.subTradeBook.sSecurityID):%d:",pTradeBookResp.subTradeBook[j].sSecurityID,strlen(pTradeBookResp.subTradeBook[j].sSecurityID));
			logDebug2(" pTradeBookResp.subTradeBook.sOrderType :%s: strlen(pTradeBookResp.subTradeBook.sOrderType):%d:",pTradeBookResp.subTradeBook[j].sOrderType,strlen(pTradeBookResp.subTradeBook[j].sOrderType));
			logDebug2(" pTradeBookResp.subTradeBook.sProduct:%s: strlen(pTradeBookResp.subTradeBook.sProduct):%d:",pTradeBookResp.subTradeBook[j].sProduct,strlen(pTradeBookResp.subTradeBook[j].sProduct));
			logDebug2(" pTradeBookResp.subTradeBook.fTradeVal :%lf:",pTradeBookResp.subTradeBook[j].fTradeVal);
			logDebug2(" pTradeBookResp.subTradeBook.iDateTime :%d:",pTradeBookResp.subTradeBook[j].iDateTime);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pTradeBookResp,sizeof(struct VIEW_TRADE_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRout2SurvlMapperQ);
			return FALSE;
		}
		usleep(500); /** This is done to give a slow response to the Rapid Rupee **/


	}


	return TRUE;
}


/************** END of fSurvillenceTradeBook ****/


/*BOOL fRejectedOrders(CHAR *RcvMsg)
  {
  struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
  struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
  struct 	VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp; 

  MYSQL_RES    *Res;
  MYSQL_ROW     Row;

  CHAR *sRejectedOrders = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

  LONG32 iErrorId=0;
  LONG32 i=0,j=0;

  LONG32          fNoOfRec=0.0;
  LONG32          iTempNoOfRec;
  DOUBLE64        fConvertPrice;
  LONG32          iNoOfPkt;
  CHAR            sClientId[CLIENT_ID_LEN];
  CHAR            sEntityId[ENTITY_ID_LEN];


  pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


/*	strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
logdebug2(" sClientId :%s:", sClientId); /

memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));


/***

logDebug2(sRejectedOrders,"SELECT ORDNO,\
SCRIP_CODE,\
ORDBUYSELL,\
TRADE_DATE,\
ORDERTYPE,\
PRODUCTCODE,\
ORDQTY,\
ORDERRATE,\
INSUFFICIENT_QTY,\
INSUFFICIENT_AMT,\
AMOUNT_BLOCKED,\
RMS_STATUS,\
MKT_ORDER,\
SEGMENT,\
EXCH_ID\
FROM   RMS_REJECTED_ORDERS\
WHERE CLIENT_ID = LTRIM(RTRIM(\'%s\'))",sClientId);

 *

 sprintf(sRejectedOrders,"SELECT ORDNO,\
 SCRIP_CODE,\
 ORDBUYSELL,\
 TRADE_DATE,\
 ORDERTYPE,\
 PRODUCTCODE,\
 ORDQTY,\
 ORDERRATE,\
 INSUFFICIENT_QTY,\
 INSUFFICIENT_AMT,\
 IFNULL(AMOUNT_BLOCKED,0),\
 RMS_STATUS,\
 MKT_ORDER,\
 ltrim(rtrim(CLIENT_ID)),\
 SEGMENT,\
 EXCH_ID\
 FROM   RMS_REJECTED_ORDERS") ;
 WHERE	CLIENT_ID IN (select e.ENTITY_CODE\
 FROM ENTITY_MASTER e\
 WHERE e.ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))\
 union\
 select c.EDM_CLIENT_ID\
 FROM ENTITY_DEALER_MAPPING c\
 WHERE c.EDM_DEALER_ID = ltrim(rtrim(\"%s\"))\
 )\
 order by TRADE_DATE DESC;",sEntityId,sEntityId);	


 logDebug2("fRejectedOrders :%s:",sRejectedOrders);

 if(mysql_query(DBQueries, sRejectedOrders) != SUCCESS)
 {
 logSqlFatal("ERROR in RejectOrd Query.");
 sql_Error(DBQueries);
 }

 Res = mysql_store_result(DBQueries);
 fNoOfRec = mysql_num_rows(Res);

 iNoOfPkt = ceil(fNoOfRec/5);
 iTempNoOfRec = fNoOfRec;

 pRejectedOrdersHdrResp.IntRespHeader.iSeqNo = 0;
 pRejectedOrdersHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);

 pRejectedOrdersHdrResp.IntRespHeader.iErrorId = 0;
 pRejectedOrdersHdrResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_HEADER_RESP;
 pRejectedOrdersHdrResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
 pRejectedOrdersHdrResp.IntRespHeader.cSource  = pViewRejectedOrdersReq->ReqHeader.cSource ;
//       	pRejectedOrdersHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;

pRejectedOrdersHdrResp.cMsgType = 'H';
pRejectedOrdersHdrResp.iNoofRec = fNoOfRec;


logDebug2("pRejectedOrdersHdrResp.cMsgType:%c:, pRejectedOrdersHdrResp.iNoofRec:%d:", pRejectedOrdersHdrResp.cMsgType, pRejectedOrdersHdrResp.iNoofRec);
if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,1 ) != TRUE ))
{
	perror("Error WriteMsgQ: ");
	logDebug2("Write Q id %d", iSTWRelToQueryQ);
	return FALSE;
}
logDebug2("iNoOfPkt :%d:",iNoOfPkt);

for(i=0;i<iNoOfPkt;i++)
{
	memset(&pRejectedOrdersResp,'\0',sizeof( struct VIEW_REJECTED_ORDERS_RESP));
	for(j=0;j<5;j++)
	{

		if((Row = mysql_fetch_row(Res)))
		{
			pRejectedOrdersResp.IntRespHeader.iSeqNo = 0;
			pRejectedOrdersResp.IntRespHeader.iMsgLength = sizeof(struct  VIEW_REJECTED_ORDERS_RESP);
			pRejectedOrdersResp.IntRespHeader.iErrorId = 0;
			pRejectedOrdersResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_RESP;
			pRejectedOrdersResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
			pRejectedOrdersResp.IntRespHeader.cSource = pViewRejectedOrdersReq->ReqHeader.cSource ;
			//                                 pRejectedOrdersResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pRejectedOrdersResp.cMsgType = 'T';
			}
			else
			{
				pRejectedOrdersResp.cMsgType = 'D';
			}


			pRejectedOrdersResp.subRejOrdBook[j].fOrderNo = atof(Row[0]);
			//  strncpy(pRejectedOrdersResp.sClientId,sClientId ,CLIENT_ID_LEN);
			strncpy(pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,Row[1],strlen(Row[1]));
			if(Row[2][0] == INT_BUY)
			{
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Buy",5);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_BUY,strlen(FE_BUY));
			}
			else if(Row[2][0] == INT_SELL)
			{
				/**					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Sell",5);/
				  strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_SELL,strlen(FE_SELL));
				  }
			/*	strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],DATE_LENGTH);	
			strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],strlen(Row[3]));	
			logDebug2("\n pRejectedOrdersResp.subRejOrdBook[j].sDatetime :%s: %d:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime,strlen(pRejectedOrdersResp.subRejOrdBook[j].sDatetime));
			if(Row[4][0] == 'N')
			{
				/** strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",8);/
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",3);
				}
				else if(Row[4][0] == 'M')
				{
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"Modified",8);
				}

				if(Row[5][0] == PROD_INTRADAY)
				{
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_INTRADAY,strlen(FE_PROD_INTRADAY));
				}
				else if(Row[5][0] == PROD_MARGIN)
				{
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_MARGIN,strlen(FE_PROD_MARGIN));
				}
				else if(Row[5][0] == PROD_CNC)
				{
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_CNC,strlen(FE_PROD_CNC));
				}
				pRejectedOrdersResp.subRejOrdBook[j].iQty = atoi(Row[6]);
				pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice = atoi(Row[7]);
				pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty = atoi(Row[8]);
				pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt = atof(Row[9]);
				pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked = atof(Row[10]);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus,Row[11],10);
				pRejectedOrdersResp.subRejOrdBook[j].cMktOrder = Row[12][0];


				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sClientId,Row[13],strlen(Row[13]));

				logDebug2("\n -------------------------- Printing Data *********************");
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sClientId :%s: len :%d:",pRejectedOrdersResp.subRejOrdBook[j].sClientId,strlen(pRejectedOrdersResp.subRejOrdBook[j].sClientId));
				logDebug2("pRejectedOrdersHdrResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersHdrResp.IntRespHeader.iMsgCode);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrderNo:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrderNo);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sSecurityID:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd:%s:",pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime:%s:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sOrderType);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sProduct:%s:",pRejectedOrdersResp.subRejOrdBook[j].sProduct);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt:%f:",pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked:%f:",pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus:%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].cMktOrder:%c:",pRejectedOrdersResp.subRejOrdBook[j].cMktOrder);

				logDebug2("\n -------------------------- Printing Data *********************");

				pRejectedOrdersResp.subRejOrdBook[j].cSegment = Row[14][0];



				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sExcgId,Row[15],EXCHANGE_LEN);


				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sExcgId :%s:",pRejectedOrdersResp.subRejOrdBook[j].sExcgId);
				logDebug2(" pRejectedOrdersResp.cMsgType :%c:",pRejectedOrdersResp.cMsgType);
				logDebug2(" pRejectedOrdersResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersResp.IntRespHeader.iMsgCode);
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus :%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);

				logDebug2("pRejectedOrdersResp.subRejOrdBook.sSecurityID:%s: pRejectedOrdersResp.subRejOrdBook.sBuySellInd:%s: pRejectedOrdersResp.subRejOrdBook.sProduct:%s: pRejectedOrdersResp.subRejOrdBook.iQty:%d: pRejectedOrdersResp.subRejOrdBook.fOrdPrice:%f: pRejectedOrdersResp.subRejOrdBook.iInSuffQty:%d: pRejectedOrdersResp.subRejOrdBook.fInSuffAmt:%f: pRejectedOrdersResp.subRejOrdBook.fAmtBlocked:%f: pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,pRejectedOrdersResp.subRejOrdBook[j].sProduct,pRejectedOrdersResp.subRejOrdBook[j].iQty,pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice,pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty,pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt,pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked,pRejectedOrdersResp.subRejOrdBook[j].sOrderType);

				}

				iTempNoOfRec--;
				}

				if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersResp,sizeof(struct VIEW_REJECTED_ORDERS_RESP) ,1 ) != TRUE ))
				{
				perror("Error WriteMsgQ: ");
				logDebug2("Write Q id %d", iSTWRelToQueryQ);
				return FALSE;
			}
}


}
	*/
BOOL fSurvillenceConvetToDel(CHAR *RcvMsg)
{

	struct VIEW_COMMON_QUERY_REQ *pViewCTODReq;
	struct VIEW_CLIENT_CONVERT_TO_DELIVERY     pCTODResp;
	struct VIEW_COMMON_HDR_RESP     pCTODHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	CHAR		sSecurityID[SECURITY_ID_LEN];
	CHAR		cProductSource;
	CHAR		cProductDest;
	CHAR		cSide;
	LONG32		iQty;
	CHAR		sExcgId[EXCHANGE_LEN];
	CHAR		sClientId[CLIENT_ID_LEN];
	LONG32		iNoOfRec=0;
	LONG32		iTempNoOfRec;
	DOUBLE64        fNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR		cSegment;	

	pViewCTODReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewCTODReq->sClientId,CLIENT_ID_LEN);
	logDebug2("\n sClientId  is n fSurvillenceConvetToDel :%s: ",sClientId );



	/****
	  SELECT  count(1)
INTO :iNoOfRec
from RMS_CLIENT_CONVT_TO_DEL;
	 ******/

	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;


	pCTODHdrResp.IntRespHeader.iSeqNo = 0;
	pCTODHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCTODHdrResp.IntRespHeader.iErrorId = 0;
	pCTODHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CONVT_TO_DELV_HEADER_RESP;
	pCTODHdrResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
	pCTODHdrResp.IntRespHeader.cSource  = pViewCTODReq->ReqHeader.cSource ;
	//		pCTODHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;

	pCTODHdrResp.cMsgType = 'H';
	pCTODHdrResp.iNoofRec = iNoOfRec;

	logDebug2(" pCTODHdrResp.cMsgType:%c:,pCTODHdrResp.iNoofRec:%d:",pCTODHdrResp.cMsgType,pCTODHdrResp.iNoofRec);
	logDebug2("pViewCTODReq->ReqHeader.iUserId = %llu",pViewCTODReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewCTODReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pCTODHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}

	/******
	  SELECT	RCCD_SCRIP_CODE,
	  RCCD_EXCHANGE,
	  RCCD_PRODUCT_SOURCE,
	  RCCD_PRODUCT_DESTINATION,
	  RCCD_SIDE,
	  RCCD_QTY,
	  RCCD_CONVT_PRICE,
	  RCCD_SEGMENT
	  FROM RMS_CLIENT_CONVT_TO_DEL;*******/



	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{



			iQty=0;

			memset(sSecurityID ,'\0',SECURITY_ID_LEN);
			/*************
			  :sSecurityID,
			  :sExcgId,
			  :cProductSource,
			  :cProductDest,
			  :cSide,	
			  :iQty,
			  :fConvertPrice,
			  :cSegment;
			 *********/


			pCTODResp.IntRespHeader.iSeqNo = 0;
			pCTODResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY);
			pCTODResp.IntRespHeader.iErrorId = 0;
			pCTODResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_CONVT_TO_DELV_RESP;
			pCTODResp.IntRespHeader.iUserId = pViewCTODReq->ReqHeader.iUserId;
			pCTODResp.IntRespHeader.cSource  = pViewCTODReq->ReqHeader.cSource ;
			//		pCTODResp.IntRespHeader.cUserTypeOrLogInfoType = pViewCTODReq->ReqHeader.cUserType;


			if(iTempNoOfRec <= 1)
			{
				pCTODResp.cMsgType = 'T';
			}
			else
			{
				pCTODResp.cMsgType = 'D';
			}

			strncpy(pCTODResp.subCTOD[j].sClientId,sClientId ,CLIENT_ID_LEN);
			strncpy(pCTODResp.subCTOD[j].sSecurityID,sSecurityID ,SECURITY_ID_LEN);
			pCTODResp.subCTOD[j].cProductSource = cProductSource;
			pCTODResp.subCTOD[j].cProductDest = cProductDest;
			pCTODResp.subCTOD[j].cSide = cSide;
			pCTODResp.subCTOD[j].iQty = iQty;
			pCTODResp.subCTOD[j].fConvertPrice = fConvertPrice;
			pCTODResp.subCTOD[j].cSegment = cSegment;
			strncpy(pCTODResp.subCTOD[j].sExcgId,sExcgId ,EXCHANGE_LEN);

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iTrdRout2SurvlMapperQ , (CHAR *)&pCTODResp,sizeof(struct VIEW_CLIENT_CONVERT_TO_DELIVERY) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iTrdRout2SurvlMapperQ);
			return FALSE;
		}
	}
	return TRUE;
}/*** END Survillence Convet to del ******/

BOOL    fDeaClientMapp(CHAR *RcvMsg)
{
	logTimestamp("Entry : fDeaClientMapp");        

	struct VIEW_COMMON_QUERY_REQ    *pCliMappReq;
	struct VIEW_COMMON_HDR_RESP     pCliMappHdrRes;
	struct DEALER_MAPP_RESP         pCliMappRes;

	MYSQL_RES       *Res,*Res1;
	MYSQL_ROW       Row,Row1;
	LONG32          iTotalRow;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	CHAR    sEntityId[ENTITY_ID_LEN];
	CHAR    sClientId[CLIENT_ID_LEN];
	LONG32  i=0,j=0;

	CHAR    *sCliMap = malloc(sizeof(CHAR) *MAX_QUERY_SIZE );
	CHAR    *sQuery = malloc(sizeof(CHAR) *MAX_QUERY_SIZE );

	pCliMappReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;
	strncpy(sEntityId,pCliMappReq->sEntityId,ENTITY_ID_LEN);

	sprintf(sCliMap,"SELECT EDM_CLIENT_ID from ENTITY_DEALER_MAPPING_TEMP WHERE EDM_DEALER_ID = ltrim(rtrim(\"%s\"));",sEntityId);
	logDebug2("[%s]",sCliMap);

	if((mysql_query(DBQueries,sCliMap)) != SUCCESS)
	{
		logSqlFatal("ERROR IN Select Client Id QRY.");
		sql_Error(DBQueries);
	}
	Res = mysql_store_result(DBQueries);

	iTotalRow = mysql_num_rows(Res);
	logDebug2("Total no of Client = %d",iTotalRow);
	fNoOfRec = iTotalRow;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iTotalRow;

	pCliMappHdrRes.IntRespHeader.iSeqNo = 0;
	pCliMappHdrRes.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pCliMappHdrRes.IntRespHeader.iErrorId = 0;
	pCliMappHdrRes.IntRespHeader.iMsgCode = TC_INT_DEA_CLIENT_MAPP_HEADER_RESP;
	pCliMappHdrRes.IntRespHeader.iUserId = pCliMappReq->ReqHeader.iUserId;
	pCliMappHdrRes.IntRespHeader.cSource  = pCliMappReq->ReqHeader.cSource;
	//        pCliMappHdrRes.IntRespHeader.cUserTypeOrLogInfoType = pCliMappReq->ReqHeader.cUserType;
	pCliMappHdrRes.cMsgType = 'H';
	pCliMappHdrRes.iNoofRec = iTotalRow;

	logDebug2("pCliMappReq->ReqHeader.iUserId = %llu",pCliMappReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pCliMappReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ ,(CHAR *)&pCliMappHdrRes,sizeof(struct VIEW_COMMON_HDR_RESP),iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if(Row = mysql_fetch_row(Res))
			{
				pCliMappRes.IntRespHeader.iSeqNo = 0;
				pCliMappRes.IntRespHeader.iMsgLength = sizeof(struct DEALER_MAPP_RESP);
				pCliMappRes.IntRespHeader.iErrorId = 0;
				pCliMappRes.IntRespHeader.iMsgCode = TC_INT_DEA_CLIENT_MAPP_RESP;
				pCliMappRes.IntRespHeader.iUserId = pCliMappReq->ReqHeader.iUserId;
				pCliMappRes.IntRespHeader.cSource  = pCliMappReq->ReqHeader.cSource ;
				//                                pCliMappRes.IntRespHeader.cUserTypeOrLogInfoType = pCliMappReq->ReqHeader.cUserType;

				if(iTempNoOfRec <= 1)
				{
					pCliMappRes.cMsgType = 'T';
				}
				else
				{
					pCliMappRes.cMsgType = 'D';
				}

				strncpy(sClientId,Row[0],12);
				sprintf(sQuery,"SELECT CONCAT(ENTITY_CODE,'|',ENTITY_NAME,'|',ENTITY_ADD_1,'|',ENTITY_ADD_2,'|',ENTITY_ADD_3,'|',\
					ENTITY_PHONE,'|',ENTITY_MOBILE,'|',ENTITY_DOB,'|',ENTITY_PAN,'|',ENTITY_NSE_CODE)AS v_string\
					FROM ENTITY_MASTER where ENTITY_CODE = \"%s\" ",sClientId);	
				logDebug2("sQuery = %s",sQuery);

				if((mysql_query(DBQueries,sQuery)) != SUCCESS)
				{
					logSqlFatal("ERR In fDeaClientMapp QRY.");
					sql_Error(DBQueries);
				}
				Res1 = mysql_store_result(DBQueries);

				if(Row1 = mysql_fetch_row(Res1))
				{
					strncpy(pCliMappRes.subdeamapp[j].sClientString,Row[0],CLI_STRING_LEN);
				}

				logDebug2(".................Printing value..................");
				logDebug3("pCliMappRes.IntRespHeader.iMsgLength = %d ",pCliMappRes.IntRespHeader.iMsgLength);
				logDebug3("pCliMappRes.IntRespHeader.iMsgCode = %d ",pCliMappRes.IntRespHeader.iMsgCode);
				logDebug3("pCliMappRes.IntRespHeader.iUserId = %llu",pCliMappRes.IntRespHeader.iUserId);
				//                                logDebug3("pCliMappRes.IntRespHeader.cUserTypeOrLogInfoType = %c ",pCliMappRes.IntRespHeader.cUserTypeOrLogInfoType);
				logDebug3("pCliMappRes.cMsgType = %c ",pCliMappRes.cMsgType);
				logDebug3("pCliMappRes.subdeamapp[j].sClientString = %s ",pCliMappRes.subdeamapp[j].sClientString);

				free(Res1);
				iTempNoOfRec--;
			}

		}

		if(WriteMsgQ(iIntActiveToRelDirQ, (CHAR *)&pCliMappRes,sizeof(struct DEALER_MAPP_RESP),iRelayID) != TRUE)
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id = %d", iSTWRelToQueryQ);
			return FALSE;
		}

		usleep(100);

	}
	logTimestamp("Exit : fDeaClientMapp");
	return TRUE;

}

BOOL fOrderSprdBook(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fOrderSprdBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewSprdOrdBookReq;
	struct VIEW_SPRD_ORD_BOOK_RESP pSprdOrdBookResp;
	struct VIEW_COMMON_HDR_RESP     pSprdOrdBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	//CHAR *sOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	CHAR sOrdBook  [DOUBLE_MAX_QUERY_SIZE];
	memset(sOrdBook,'\0',DOUBLE_MAX_QUERY_SIZE);

	DOUBLE64        fOrderNo = 0.00;
	LONG32          iSerialNo;
	LONG32          iLegValue = 0;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;


	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR            sProduct[10];
	CHAR            sValidity[5];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sRespClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];
	CHAR            ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32          iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iOrderBookTime;
	CHAR            sWhere_Clause[QUERY_SIZE];	

	memset(sWhere_Clause,'\0',QUERY_SIZE);
	pViewSprdOrdBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewSprdOrdBookReq->sClientId,CLIENT_ID_LEN);

	strncpy(sEntityId ,pViewSprdOrdBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("  client:%s: sEntityId :%s: ",sClientId ,pViewSprdOrdBookReq->sEntityId);

	if(strcmp(sClientId,ALL_SELECT))
	{
		sprintf(sWhere_Clause,"AND DO.DRV_CLIENT_ID = LTRIM(RTRIM(\'%s\'))",sClientId);
		logDebug2("sWhere_Clause = %s",sWhere_Clause);
	}
	/**
	  sprintf(sOrdBook,"SELECT  ORDER_NUMBER,\
	  SERIALNO,\
	  SEM_SECURITY_ID,\
	  ORDER_TYPE,\
	  QUANTITY,\
	  REMAINING_QUANTITY,\
	  DISCLOSE_QTY,\
	  DQQTYREM,\
	  ORDER_PRICE,\
	  TRG_PRICE,\
	  TRADEDQTY,\
	  PRODUCT,\
	  ORDER_VALIDITY,\
	  EXCHORDERNO,\
	  date_format(ORDER_DATE_TIME,\'%%d-%%m-%%Y  %%r'),\
	  EXCH,\
	  BUY_SELL,\
	  SEGMENT,\
	  TRANSCODE,\
	  CLIENT_ID,\
	  JULIDATE(ORDER_DATE_TIME),\
	  STRATEGY_ID,\
	  PLACEDBY,\
	  REASON_DESCRIPTION,\
	  PRO_CLIENT,\
	  TRADE_PRICE,\
	  IFNULL(GOOD_TILL_DATE,NOW()) ,\
	  LEGVALUE \
	  FROM  ORDERBOOK  WHERE  CLIENT_ID  = ltrim(rtrim(\"%s\")) AND MKT_TYPE = 'SP' ORDER BY ORDER_DATE_TIME DESC,LEGVALUE ASC;",sClientId );
	 ***/
/*
	sprintf(sOrdBook,"	SELECT 	ORDER_NUMBER,SERIALNO, SECURITY_ID, ORDER_TYPE,QUANTITY,REM_QTY,DISCLOSE_QTY,DQQTYREM,PRICE, TRG_PRICE,TRADEDQTY,\
			PRODUCT,ORDER_VALIDITY,EXCHORDERNO,ORDER_DATE_TIME, EXCH,BUY_SELL, SEGMENT, TRANSCODE, CLIENT_ID,JDATE, STRATEGY_ID,\
			PLACEDBY, REASON_DESCRIPTION,PRO_CLIENT,TRADE_PRICE,IFNULL(GOOD_TILL_DATE,NOW()) ,LEGVALUE,IFNULL(PAN_NO,'NA'),IFNULL(PARTICIPANT_TYPE,'B'),\
			IFNULL(SETTLOR,'NA'), \
			IFNULL(MKT_PROTECT_FLG,'N'),IFNULL(MKT_PROTECT_VAL,1), IFNULL(GTC_FLG,'N'),IFNULL(ENCASH_FLG,'N'),ALGO_ORD_NO,MKT_TYPE FROM\
			( SELECT  DO.DRV_CLIENT_ID AS CLIENT_ID, DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE,NOW() ) AS ORDER_DATE_TIME,\
			  DO.DRV_ORDER_NO AS ORDER_NUMBER, DO.DRV_EXCH_ID AS EXCH,(CASE DO.DRV_BUY_SELL_IND  \
				  WHEN 'B' THEN 'Buy'  WHEN 'S' THEN 'Sell' END) AS BUY_SELL,\
			  DO.DRV_SEGMENT AS SEGMENT,DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,DO.DRV_SYMBOL AS SYMBOL,DO.DRV_LEG_NO AS LEG_NO,\
			  (CASE DO.DRV_PRODUCT_ID WHEN 'B' THEN 'BO' WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC' WHEN 'M' THEN 'MARGIN'  WHEN 'L' THEN 'MLB'\
			   WHEN 'S' THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY' WHEN 'H' THEN 'NORMAL' ELSE DO.DRV_PRODUCT_ID END) AS PRODUCT,\
			  (CASE WHEN ((DO.DRV_MSG_CODE = '2073') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY)) \
			   THEN 'Part-Traded'  WHEN  ((DO.DRV_MSG_CODE = '2074') AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY)) THEN  'Part-Traded'\
			   WHEN ((DO.DRV_MSG_CODE = '2212') AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))  THEN 'Part-Traded'\
			   WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending'  WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit' \
			   WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit'\
			   WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit'  WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected' \
			   WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected'\
			   WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen' WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified'  \
			   WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
			   WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded' WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired' \
			   WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
			   WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified' WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled' \
			   WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered'\
			   WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected' \
			   WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected'\
			   WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected' WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected'\
			   WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected'\
			   END) AS STATUS, DO.DRV_TOTAL_QTY AS QUANTITY, DO.DRV_REM_QTY AS REM_QTY,CASE DO.DRV_SEGMENT  WHEN  'C'\
			  THEN\
			  REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE WHEN '1' THEN 'MKT' WHEN '3' THEN 'MKT' \
							  ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)  END), 4), ',', '')  ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE WHEN '1' \
							  THEN 'MKT' WHEN '3' THEN 'MKT'  ELSE IFNULL(DO.DRV_ORDER_PRICE, 0) END), 2), ',', '')  END AS PRICE,  CASE DO.DRV_SEGMENT   WHEN\
							  'C' THEN  ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)  WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)\
											  ELSE 0 END), 0), 4) ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE WHEN '3'\
												  THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)	WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0) ELSE 0  END), 0), 2)  END AS TRG_PRICE,\
											  (CASE DO.DRV_ORDER_TYPE  WHEN '1' THEN 'MARKET' WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'   WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,\
											  CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,\
											  DO.DRV_DISC_QTY AS DISCLOSE_QTY, DO.DRV_SERIAL_NO AS SERIALNO, DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,DO.DRV_SCRIP_CODE AS SECURITY_ID,\
											  (CASE DO.DRV_VALIDITY WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' \ 
											   WHEN '3' THEN 'IOC'  ELSE 'EOS' END) AS ORDER_VALIDITY,\
											  DO.DRV_LOT_SIZE AS SM_LOT_SIZE, 0 AS TAKE_PROFIT_TRAIL_GAP, DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,\
											  DO.DRV_DISC_REM_QTY AS DQQTYREM,\
											  DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO, IFNULL(DO.DRV_REASON_DESCRIPTION, 'NULL') AS REASON_DESCRIPTION,\
											  DO.DRV_PRO_CLIENT AS PRO_CLIENT,\
											  DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE, IFNULL(DO.DRV_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,\
											  DO.DRV_ENTITY_ID AS PLACEDBY,\
											  DO.DRV_STRATEGY_ID AS STRATEGY_ID, JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
											  DO.DRV_MSG_CODE AS TRANSCODE,DO.DRV_LEG_NO AS LEGVALUE,\
											  DO.DRV_PAN_NO AS PAN_NO,DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,DO.DRV_SETTLOR AS SETTLOR,\
											  DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,DO.DRV_GTC_FLG AS GTC_FLG,\
											  DO.DRV_ENCASH_FLG AS ENCASH_FLG,DO.DRV_OMS_ALGO_ORD_NO AS ALGO_ORD_NO,DO.DRV_MKT_TYPE AS MKT_TYPE  FROM  DRV_ORDERS DO JOIN (SELECT @rn:=0) r\
											  WHERE\
											  1=1 %s AND DO.DRV_SERIAL_NO = (SELECT  MAX(DOO.DRV_SERIAL_NO) FROM DRV_ORDERS DOO  WHERE\
													  (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO) AND (DO.DRV_OMS_ALGO_ORD_NO <> -(1) \
														  AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO)) AND (DO.DRV_STATUS <> 'B'))) orderbook\
														  WHERE 1 = 1 AND MKT_TYPE = 'SP'  ORDER BY ORDER_DATE_TIME DESC, LEGVALUE ASC;",sWhere_Clause);
*/
	 sprintf(sOrdBook,"SELECT   ORDER_NUMBER,   SERIALNO,   SECURITY_ID,   ORDER_TYPE,   QUANTITY,   REM_QTY,   DISCLOSE_QTY,   DQQTYREM,   PRICE,   TRG_PRICE,   TRADEDQTY,   PRODUCT,   ORDER_VALIDITY,   EXCHORDERNO,   ORDER_DATE_TIME,   EXCH,   BUY_SELL,   SEGMENT,   TRANSCODE,   CLIENT_ID,   JDATE,   STRATEGY_ID,   PLACEDBY,   REASON_DESCRIPTION,   PRO_CLIENT,   TRADE_PRICE,   IFNULL(GOOD_TILL_DATE, NOW()),   LEGVALUE,   IFNULL(PAN_NO, 'NA'),   IFNULL(PARTICIPANT_TYPE, 'B'),   IFNULL(SETTLOR, 'NA'),   IFNULL(MKT_PROTECT_FLG, 'N'),   IFNULL(MKT_PROTECT_VAL, 1),   IFNULL(GTC_FLG, 'N'),   IFNULL(ENCASH_FLG, 'N'),   ALGO_ORD_NO,   MKT_TYPE FROM   (SELECT     DO.DRV_CLIENT_ID AS CLIENT_ID,       DATE_FORMAT(DO.DRV_INTERNAL_ENTRY_DATE, NOW()) AS ORDER_DATE_TIME,       DO.DRV_ORDER_NO AS ORDER_NUMBER,       DO.DRV_EXCH_ID AS EXCH,       (CASE DO.DRV_BUY_SELL_IND         WHEN 'B' THEN 'Buy'         WHEN 'S' THEN 'Sell'       END) AS BUY_SELL,       DO.DRV_SEGMENT AS SEGMENT,       DO.DRV_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,       DO.DRV_SYMBOL AS SYMBOL,       DO.DRV_LEG_NO AS LEG_NO,       (CASE DO.DRV_PRODUCT_ID         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'H' THEN 'NORMAL'         ELSE DO.DRV_PRODUCT_ID       END) AS PRODUCT,       (CASE         WHEN           ((DO.DRV_MSG_CODE = '2073')             AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))         THEN           'Part-Traded'         WHEN           ((DO.DRV_MSG_CODE = '2074')             AND (DO.DRV_REM_QTY > DO.DRV_TOTAL_QTY))         THEN           'Part-Traded'         WHEN           ((DO.DRV_MSG_CODE = '2212')             AND (DO.DRV_REM_QTY <> DO.DRV_TOTAL_QTY))         THEN           'Part-Traded'         WHEN (DO.DRV_MSG_CODE = '2073') THEN 'Pending'         WHEN (DO.DRV_MSG_CODE = '2000') THEN 'Transit'         WHEN (DO.DRV_MSG_CODE = '2040') THEN 'Transit'         WHEN (DO.DRV_MSG_CODE = '2070') THEN 'Transit'         WHEN (DO.DRV_MSG_CODE = '2231') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '2042') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '2170') THEN 'Frozen'         WHEN (DO.DRV_MSG_CODE = '2074') THEN 'Modified'         WHEN (DO.DRV_MSG_CODE = '2075') THEN 'Cancelled'         WHEN (DO.DRV_MSG_CODE = '2222') THEN 'Traded'         WHEN (DO.DRV_MSG_CODE = '9002') THEN 'Expired'         WHEN (DO.DRV_MSG_CODE = '5112') THEN 'O-Pending'         WHEN (DO.DRV_MSG_CODE = '5113') THEN 'O-Modified'         WHEN (DO.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'         WHEN (DO.DRV_MSG_CODE = '2212') THEN 'Triggered'         WHEN (DO.DRV_MSG_CODE = '1111') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '1113') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '1115') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '4444') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '4445') THEN 'Rejected'         WHEN (DO.DRV_MSG_CODE = '4446') THEN 'Rejected'       END) AS STATUS,       DO.DRV_TOTAL_QTY AS QUANTITY,       DO.DRV_REM_QTY AS REM_QTY,       CASE DO.DRV_SEGMENT         WHEN           'C'         THEN           REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE             WHEN '1' THEN 'MKT'             WHEN '3' THEN 'MKT'             ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)           END), 4), ',', '')         ELSE REPLACE(FORMAT((CASE DO.DRV_ORDER_TYPE           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(DO.DRV_ORDER_PRICE, 0)         END), 2), ',', '')       END AS PRICE,       CASE DO.DRV_SEGMENT         WHEN           'C'         THEN           ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE             WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)             WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)             ELSE 0           END), 0), 4)         ELSE ROUND(COALESCE((CASE DO.DRV_ORDER_TYPE           WHEN '3' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)           WHEN '4' THEN IFNULL(DO.DRV_TRIGGER_PRICE, 0)           ELSE 0         END), 0), 2)       END AS TRG_PRICE,       (CASE DO.DRV_ORDER_TYPE         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS ORDER_TYPE,       CONCAT(DO.DRV_REM_QTY, '/', DO.DRV_TOTAL_QTY) AS REM_QTY_TOT_QTY,       DO.DRV_DISC_QTY AS DISCLOSE_QTY,       DO.DRV_SERIAL_NO AS SERIALNO,       DO.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,       DO.DRV_SCRIP_CODE AS SECURITY_ID,       (CASE DO.DRV_VALIDITY         WHEN '0' THEN 'DAY'         WHEN '1' THEN 'GTC'         WHEN '2' THEN 'ATO'         WHEN '3' THEN 'IOC'         ELSE 'EOS'       END) AS ORDER_VALIDITY,       DO.DRV_LOT_SIZE AS SM_LOT_SIZE,       0 AS TAKE_PROFIT_TRAIL_GAP,       DO.DRV_OMS_ALGO_ORD_NO AS ADV_GROUP_REF_NO,       DO.DRV_DISC_REM_QTY AS DQQTYREM,       DO.DRV_EXCH_ORDER_NO AS EXCHORDERNO,       IFNULL(DO.DRV_REASON_DESCRIPTION, 'NULL') AS REASON_DESCRIPTION,       DO.DRV_PRO_CLIENT AS PRO_CLIENT,       DO.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,       IFNULL(DO.DRV_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,       DO.DRV_ENTITY_ID AS PLACEDBY,       DO.DRV_STRATEGY_ID AS STRATEGY_ID,       JULIDATE(DO.DRV_INTERNAL_ENTRY_DATE) AS JDATE,       DO.DRV_MSG_CODE AS TRANSCODE,       DO.DRV_LEG_NO AS LEGVALUE,       DO.DRV_PAN_NO AS PAN_NO,       DO.DRV_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,       DO.DRV_SETTLOR AS SETTLOR,       DO.DRV_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,       DO.DRV_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,       DO.DRV_GTC_FLG AS GTC_FLG,       DO.DRV_ENCASH_FLG AS ENCASH_FLG,       DO.DRV_OMS_ALGO_ORD_NO AS ALGO_ORD_NO,       DO.DRV_MKT_TYPE AS MKT_TYPE   FROM     DRV_ORDERS DO   JOIN (SELECT @rn:=0) r   WHERE     1 = 1       AND DO.DRV_SERIAL_NO = (SELECT         MAX(DOO.DRV_SERIAL_NO)       FROM         DRV_ORDERS DOO       WHERE         (DOO.DRV_ORDER_NO = DO.DRV_ORDER_NO)           AND (DO.DRV_OMS_ALGO_ORD_NO <> -(1)           AND (DO.DRV_LEG_NO = DOO.DRV_LEG_NO))           AND (DO.DRV_STATUS <> 'B')) UNION ALL SELECT     DO.COMM_CLIENT_ID AS CLIENT_ID,       DATE_FORMAT(DO.COMM_INTERNAL_ENTRY_DATE, NOW()) AS ORDER_DATE_TIME,       DO.COMM_ORDER_NO AS ORDER_NUMBER,       DO.COMM_EXCH_ID AS EXCH,       (CASE DO.COMM_BUY_SELL_IND         WHEN 'B' THEN 'Buy'         WHEN 'S' THEN 'Sell'       END) AS BUY_SELL,       DO.COMM_SEGMENT AS SEGMENT,       DO.COMM_INSTRUMENT_NAME AS SM_INSTRUMENT_NAME,       DO.COMM_SYMBOL AS SYMBOL,       DO.COMM_LEG_NO AS LEG_NO,       (CASE DO.COMM_PRODUCT_ID         WHEN 'B' THEN 'BO'         WHEN 'V' THEN 'CO'         WHEN 'C' THEN 'CNC'         WHEN 'M' THEN 'MARGIN'         WHEN 'L' THEN 'MLB'         WHEN 'S' THEN 'COLLATERAL'         WHEN 'I' THEN 'INTRADAY'         WHEN 'H' THEN 'NORMAL'         ELSE DO.COMM_PRODUCT_ID       END) AS PRODUCT,       (CASE         WHEN           ((DO.COMM_MSG_CODE = '2073')             AND (DO.COMM_REM_QTY <> DO.COMM_TOTAL_QTY))         THEN           'Part-Traded'         WHEN           ((DO.COMM_MSG_CODE = '2074')             AND (DO.COMM_REM_QTY > DO.COMM_TOTAL_QTY))         THEN           'Part-Traded'         WHEN           ((DO.COMM_MSG_CODE = '2212')             AND (DO.COMM_REM_QTY <> DO.COMM_TOTAL_QTY))         THEN           'Part-Traded'         WHEN (DO.COMM_MSG_CODE = '2073') THEN 'Pending'         WHEN (DO.COMM_MSG_CODE = '2000') THEN 'Transit'         WHEN (DO.COMM_MSG_CODE = '2040') THEN 'Transit'         WHEN (DO.COMM_MSG_CODE = '2070') THEN 'Transit'         WHEN (DO.COMM_MSG_CODE = '2231') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '2042') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '2170') THEN 'Frozen'         WHEN (DO.COMM_MSG_CODE = '2074') THEN 'Modified'         WHEN (DO.COMM_MSG_CODE = '2075') THEN 'Cancelled'         WHEN (DO.COMM_MSG_CODE = '2222') THEN 'Traded'         WHEN (DO.COMM_MSG_CODE = '9002') THEN 'Expired'         WHEN (DO.COMM_MSG_CODE = '5112') THEN 'O-Pending'         WHEN (DO.COMM_MSG_CODE = '5113') THEN 'O-Modified'         WHEN (DO.COMM_MSG_CODE = '5114') THEN 'O-Cancelled'         WHEN (DO.COMM_MSG_CODE = '2212') THEN 'Triggered'         WHEN (DO.COMM_MSG_CODE = '1111') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '1113') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '1115') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '4444') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '4445') THEN 'Rejected'         WHEN (DO.COMM_MSG_CODE = '4446') THEN 'Rejected'       END) AS STATUS,       DO.COMM_TOTAL_QTY AS QUANTITY,       DO.COMM_REM_QTY AS REM_QTY,       CASE DO.COMM_SEGMENT         WHEN           'C'         THEN           REPLACE(FORMAT((CASE DO.COMM_ORDER_TYPE             WHEN '1' THEN 'MKT'             WHEN '3' THEN 'MKT'             ELSE IFNULL(DO.COMM_ORDER_PRICE, 0)           END), 4), ',', '')         ELSE REPLACE(FORMAT((CASE DO.COMM_ORDER_TYPE           WHEN '1' THEN 'MKT'           WHEN '3' THEN 'MKT'           ELSE IFNULL(DO.COMM_ORDER_PRICE, 0)         END), 2), ',', '')       END AS PRICE,       CASE DO.COMM_SEGMENT         WHEN           'C'         THEN           ROUND(COALESCE((CASE DO.COMM_ORDER_TYPE             WHEN '3' THEN IFNULL(DO.COMM_TRIGGER_PRICE, 0)             WHEN '4' THEN IFNULL(DO.COMM_TRIGGER_PRICE, 0)             ELSE 0           END), 0), 4)         ELSE ROUND(COALESCE((CASE DO.COMM_ORDER_TYPE           WHEN '3' THEN IFNULL(DO.COMM_TRIGGER_PRICE, 0)           WHEN '4' THEN IFNULL(DO.COMM_TRIGGER_PRICE, 0)           ELSE 0         END), 0), 2)       END AS TRG_PRICE,       (CASE DO.COMM_ORDER_TYPE         WHEN '1' THEN 'MARKET'         WHEN '2' THEN 'LIMIT'         WHEN '3' THEN 'SL-M'         WHEN '4' THEN 'SL'       END) AS ORDER_TYPE,       CONCAT(DO.COMM_REM_QTY, '/', DO.COMM_TOTAL_QTY) AS REM_QTY_TOT_QTY,       DO.COMM_DISC_QTY AS DISCLOSE_QTY,       DO.COMM_SERIAL_NO AS SERIALNO,       DO.COMM_TOTAL_TRADED_QTY AS TRADEDQTY,       DO.COMM_SCRIP_CODE AS SECURITY_ID,       (CASE DO.COMM_VALIDITY         WHEN '0' THEN 'DAY'         WHEN '1' THEN 'GTC'         WHEN '2' THEN 'ATO'         WHEN '3' THEN 'IOC'         ELSE 'EOS'       END) AS ORDER_VALIDITY,       DO.COMM_LOT_SIZE AS SM_LOT_SIZE,       0 AS TAKE_PROFIT_TRAIL_GAP,       DO.COMM_OMS_ALGO_ORDER_NO AS ADV_GROUP_REF_NO,       DO.COMM_DISC_REM_QTY AS DQQTYREM,       DO.COMM_EXCH_ORDER_NO AS EXCHORDERNO,       IFNULL(DO.COMM_REASON_DESCRIPTION, 'NULL') AS REASON_DESCRIPTION,       DO.COMM_PRO_CLIENT AS PRO_CLIENT,       DO.COMM_TRD_TRADE_PRICE AS TRADE_PRICE,       IFNULL(DO.COMM_GOOD_TILL_DATE, NOW()) AS GOOD_TILL_DATE,       DO.COMM_ENTITY_ID AS PLACEDBY,       DO.COMM_STRATEGY_ID AS STRATEGY_ID,       JULIDATE(DO.COMM_INTERNAL_ENTRY_DATE) AS JDATE,       DO.COMM_MSG_CODE AS TRANSCODE,       DO.COMM_LEG_NO AS LEGVALUE,       DO.COMM_PAN_NO AS PAN_NO,       DO.COMM_PARTICIPANT_TYPE AS PARTICIPANT_TYPE,       DO.COMM_SETTLOR AS SETTLOR,       DO.COM_MKT_PROTECT_FLG AS MKT_PROTECT_FLG,       DO.COMM_MKT_PROTECT_VAL AS MKT_PROTECT_VAL,       DO.COMM_GTC_FLG AS GTC_FLG,       DO.COMM_ENCASH_FLG AS ENCASH_FLG,       DO.COMM_OMS_ALGO_ORDER_NO AS ALGO_ORD_NO,       DO.COMM_MKT_TYPE AS MKT_TYPE   FROM     COMM_ORDERS DO   JOIN (SELECT @rn:=0) r   WHERE     1 = 1       AND DO.COMM_SERIAL_NO = (SELECT         MAX(DOO.COMM_SERIAL_NO)       FROM         COMM_ORDERS DOO       WHERE         (DOO.COMM_ORDER_NO = DO.COMM_ORDER_NO)           AND (DO.COMM_OMS_ALGO_ORDER_NO <> -(1)           AND (DO.COMM_LEG_NO = DOO.COMM_LEG_NO))           AND (DO.COMM_STATUS <> 'B'))) orderbook WHERE   1 = 1 AND MKT_TYPE = 'SP' ORDER BY ORDER_DATE_TIME , ORDER_NUMBER , LEGVALUE;",sWhere_Clause);
	printf(" fOrderSprdBook :%s: \n",sOrdBook);

	if(mysql_query(DBQueries,sOrdBook ) != SUCCESS)
	{
		logFatal("ERROR in Order BOOK Query.");
		sql_Error(DBQueries);
	}


	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec/2;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/


	pSprdOrdBookHdrResp.IntRespHeader.iSeqNo = 0;
	pSprdOrdBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pSprdOrdBookHdrResp.IntRespHeader.iErrorId = 0;
	pSprdOrdBookHdrResp.IntRespHeader.iMsgCode = TC_INT_SPRD_ORD_BOOK_HDR_RESP;
	pSprdOrdBookHdrResp.IntRespHeader.iUserId = pViewSprdOrdBookReq->ReqHeader.iUserId;
	pSprdOrdBookHdrResp.IntRespHeader.cSource = pViewSprdOrdBookReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewSprdOrdBookReq->ReqHeader.cUserType;

	pSprdOrdBookHdrResp.cMsgType = 'H';
	pSprdOrdBookHdrResp.iNoofRec = iNoOfRec/2;

	logDebug1(" pSprdOrdBookHdrResp.cMsgType:%c:,pSprdOrdBookHdrResp.iNoofRec:%d:",pSprdOrdBookHdrResp.cMsgType,pSprdOrdBookHdrResp.iNoofRec);

	logDebug1("pViewSprdOrdBookReq->ReqHeader.iUserId = %llu",pViewSprdOrdBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewSprdOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pSprdOrdBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
	logDebug2("Here 1");
	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			//if(Row=mysql_fetch_row(Res))
			while(Row=mysql_fetch_row(Res))
			{
				logDebug2("THisi is before If :%f: :%d:",fOrderNo,iLegValue);
				//if(fOrderNo == atof(Row[0]) && iLegValue ==1)
				if(fOrderNo == 0.00 && iLegValue == 0)
				{
					logDebug2("THisi is inside If");

					fOrderNo = atof(Row[0]);
					iLegValue = atoi(Row[27]);


					pSprdOrdBookResp.IntRespHeader.iSeqNo = 0;
					pSprdOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SPRD_ORD_BOOK_RESP);
					pSprdOrdBookResp.IntRespHeader.iErrorId = 0;
					pSprdOrdBookResp.IntRespHeader.iMsgCode = TC_INT_SPRD_ORD_BOOK_RESP;
					pSprdOrdBookResp.IntRespHeader.iUserId = pViewSprdOrdBookReq->ReqHeader.iUserId;
					pSprdOrdBookResp.IntRespHeader.cSource  = pViewSprdOrdBookReq->ReqHeader.cSource ;
					//                              	pSprdOrdBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewSprdOrdBookReq->ReqHeader.cUserType;

					logDebug2(" iTempNoOfRec :%d: ",iTempNoOfRec);


					if(iTempNoOfRec <= 2)
					{
						pSprdOrdBookResp.cMsgType = 'T';
					}
					else
					{
						pSprdOrdBookResp.cMsgType = 'D';
					}
					pSprdOrdBookResp.suborderbook[j].fOrderNo = atof(Row[0]);
					pSprdOrdBookResp.suborderbook[j].iSerialNo = atoi(Row[1]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sSecurityID,Row[2] ,SECURITY_ID_LEN);
					strncpy(pSprdOrdBookResp.suborderbook[j].sOrderType,Row[3] ,8);
					pSprdOrdBookResp.suborderbook[j].fQty = atof(Row[4]);
					pSprdOrdBookResp.suborderbook[j].fRemQty =atof(Row[5]) ;
					pSprdOrdBookResp.suborderbook[j].fDQQty = atof(Row[6]);
					//pSprdOrdBookResp.suborderbook[j].fDQQtyRem = atof(Row[7]);
					pSprdOrdBookResp.suborderbook[j].fPrice = atof(Row[8]);
					pSprdOrdBookResp.suborderbook[j].fTrgPrice = atof(Row[9]);
					pSprdOrdBookResp.suborderbook[j].fTradeQty = atof(Row[10]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sProduct,Row[11] ,10);
					strncpy(pSprdOrdBookResp.suborderbook[j].sValidity,Row[12] ,5);
					strncpy(pSprdOrdBookResp.suborderbook[j].sExchOrderNumber,Row[13] ,BSE_EXCH_ORDER_NO_LEN);
					strncpy(pSprdOrdBookResp.suborderbook[j].sDatetime,Row[14] ,DATE_LENGTH);
					strncpy(pSprdOrdBookResp.suborderbook[j].sExcgId,Row[15] ,EXCHANGE_LEN);
					memset(pSprdOrdBookResp.suborderbook[j].sBuySellInd,'\0',5);
					strncpy(pSprdOrdBookResp.suborderbook[j].sBuySellInd,Row[16],5);
					pSprdOrdBookResp.suborderbook[j].cSegment = Row[17][0];
					pSprdOrdBookResp.suborderbook[j].iTranscode = atoi(Row[18]);

					strncpy(pSprdOrdBookResp.suborderbook[j].sClientId,Row[19],CLIENT_ID_LEN);

					pSprdOrdBookResp.suborderbook[j].iDateTime = atoi(Row[20]);


					pSprdOrdBookResp.suborderbook[j].iStrategyId = atoi(Row[21]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sEntityId , Row[22],ENTITY_ID_LEN);
					strncpy(pSprdOrdBookResp.suborderbook[j].sReasonDesc, Row[23],DB_REASON_DESC_LEN);
					pSprdOrdBookResp.suborderbook[j].cProClient =  Row[24][0];
					pSprdOrdBookResp.suborderbook[j].fTrdPrice  = atof(Row[25]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sGoodTillDaysDate, Row[26],DB_DATETIME_LEN);
					pSprdOrdBookResp.suborderbook[j].iLegValue = atoi(Row[27]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sPanID, Row[28],INT_PAN_LEN);
					pSprdOrdBookResp.suborderbook[j].cParticipantType= Row[29][0];
					strncpy(pSprdOrdBookResp.suborderbook[j].sSettlor, Row[30],SETTLOR_LEN);
					pSprdOrdBookResp.suborderbook[j].cMarkProFlag = Row[31][0];
					pSprdOrdBookResp.suborderbook[j].fMarkProVal = atof(Row[32]);
					pSprdOrdBookResp.suborderbook[j].cGTCFlag = Row[33][0];
					pSprdOrdBookResp.suborderbook[j].cEncashFlag = Row[34][0];
					pSprdOrdBookResp.suborderbook[j].fAlgoOrderNo = atof(Row[35]);
					strncpy(pSprdOrdBookResp.suborderbook[j].sMktType,Row[36],MKT_TYPE_LEN);	

					//                              	pOrderBookHdrResp.IntRespHeader.iErrorId = atoi (Row[27]);


					logInfo(" ----------------- Printing Header ------------------------------------");
					logDebug2(" pSprdOrdBookResp.IntRespHeader.iMsgLength :%d:",pSprdOrdBookResp.IntRespHeader.iMsgLength);
					logDebug2(" pSprdOrdBookResp.IntRespHeader.iMsgCode :%d:",pSprdOrdBookResp.IntRespHeader.iMsgCode);
					logDebug2(" pSprdOrdBookResp.IntRespHeader.iUserId:%llu:",pSprdOrdBookResp.IntRespHeader.iUserId);
					logDebug2(" pSprdOrdBookResp.IntRespHeader.cSource :%c:",pSprdOrdBookResp.IntRespHeader.cSource);
					//                              	logDebug2(" pSprdOrdBookResp.IntRespHeader.cUserTypeOrLogInfoType:%c:",pSprdOrdBookResp.IntRespHeader.cUserTypeOrLogInfoType);

					logInfo(" -----------------Printing VALUES ------------------------------------");
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].sExcgId :%s: strlen(pSprdOrdBookResp.suborderbook[j].sExcgId):%d:",j,pSprdOrdBookResp.suborderbook[j].sExcgId,strlen(pSprdOrdBookResp.suborderbook[j].sExcgId));
					logDebug2(" pSprdOrdBookResp.cMsgType :%c:",pSprdOrdBookResp.cMsgType);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].fOrderNo :%lf:",j,pSprdOrdBookResp.suborderbook[j].fOrderNo);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].fPrice :%lf:",j,pSprdOrdBookResp.suborderbook[j].fPrice);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].iSerialNo:%d:",j,pSprdOrdBookResp.suborderbook[j].iSerialNo);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].iTranscode:%d:",j,pSprdOrdBookResp.suborderbook[j].iTranscode);
					logDebug2(" pSprdOrdBookResp.suborderbook[%i].sBuySellInd:%s: strlen(pSprdOrdBookResp.suborderbook.sBuySellInd):%d:",j,pSprdOrdBookResp.suborderbook[j].sBuySellInd,strlen(pSprdOrdBookResp.suborderbook[j].sBuySellInd));
					logDebug2(" pSprdOrdBookResp.suborderbook.sSecurityID:%s: strlen(pSprdOrdBookResp.suborderbook.sSecurityID):%d:",pSprdOrdBookResp.suborderbook[j].sSecurityID,strlen(pSprdOrdBookResp.suborderbook[j].sSecurityID));
					logDebug2(" pSprdOrdBookResp.suborderbook.sOrderType :%s: strlen(pSprdOrdBookResp.suborderbook.sOrderType):%d:",pSprdOrdBookResp.suborderbook[j].sOrderType,strlen(pSprdOrdBookResp.suborderbook[j].sOrderType));
					logDebug2(" pSprdOrdBookResp.suborderbook.sProduct:%s: strlen(pSprdOrdBookResp.suborderbook.sProduct):%d:",pSprdOrdBookResp.suborderbook[j].sProduct,strlen(pSprdOrdBookResp.suborderbook[j].sProduct));
					logDebug2(" pSprdOrdBookResp.cMsgType :%c:",pSprdOrdBookResp.cMsgType);
					logDebug2(" pSprdOrdBookResp.iLegValue :%d:",pSprdOrdBookResp.suborderbook[j].iLegValue);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].PanID :%s:",j,pSprdOrdBookResp.suborderbook[j].sPanID);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cParticipantType :%c:",j,pSprdOrdBookResp.suborderbook[j].cParticipantType);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].sSettlor:%s:",j,pSprdOrdBookResp.suborderbook[j].sSettlor);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cMarkProFlag:%c:",j,pSprdOrdBookResp.suborderbook[j].cMarkProFlag);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].fMarkProVal:%f:",j,pSprdOrdBookResp.suborderbook[j].fMarkProVal);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cGTCFlag:%c:",j,pSprdOrdBookResp.suborderbook[j].cGTCFlag);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].cEncashFlag:%c:",j,pSprdOrdBookResp.suborderbook[j].cEncashFlag);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].fAlgoOrderNo:%f:",j,pSprdOrdBookResp.suborderbook[j].fAlgoOrderNo);
					logDebug2(" pSprdOrdBookResp.suborderbook[%d].sMktType:%f:",j,pSprdOrdBookResp.suborderbook[j].sMktType);
				}
				else
				{
					memset(pSprdOrdBookResp.suborderbook[j].sBuySellInd,'\0',5);
					strncpy(pSprdOrdBookResp.suborderbook[j].sBuySellInd,Row[16],5);
					logDebug2("THisi is inside else Leg:%d:",atoi(Row[27]));
					logDebug2("pSprdOrdBookResp.suborderbook[j].sSecurityID :%s: Row[2] :%s:",pSprdOrdBookResp.suborderbook[j].sSecurityID,Row[2]);
					sprintf(pSprdOrdBookResp.suborderbook[j].sSecurityID,"%s-%s",pSprdOrdBookResp.suborderbook[j].sSecurityID,Row[2] );

					logDebug2("pSprdOrdBookResp.suborderbook[j].sSecurityID :%s:",pSprdOrdBookResp.suborderbook[j].sSecurityID);
					fOrderNo = 0.00;
					iLegValue = 0;
					break;
				}
			}
			//iTempNoOfRec--;
			iTempNoOfRec = iTempNoOfRec - 2;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pSprdOrdBookResp,sizeof(struct VIEW_SPRD_ORD_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}


	}


	return TRUE;


}/************** END of fOrderSprdBook ****/

BOOL fGetRejectedOrders(CHAR *RcvMsg)
{
	logTimestamp("Entry : fGetRejectedOrders");	

	struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
	struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
	struct  VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR *sGetRejectedOrders = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR            sUserType[3];
	CHAR		sManagerType[4];
	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	LONG32          fNoOfRec=0.0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];

	pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


	/*      strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
		logdebug2(" sClientId :%s:", sClientId); */

	memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



	strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));

	sprintf(sGetRejectedOrders,"SELECT  ENTITY_TYPE, ENTITY_MANAGER_TYPE \
			from  ENTITY_MASTER \
			WHERE ENTITY_CODE = ltrim(rtrim(\"%s\")); ",sEntityId);

	logDebug2("Query[%s]",sGetRejectedOrders);

	/*** SELECT  em_entity_type
INTO :sUserType
from  entity_master em
WHERE em.em_entity_id = ltrim(rtrim(:sEntityId));
	 ******/

	if(mysql_query(DBQueries,sGetRejectedOrders) != SUCCESS)
	{
		logSqlFatal("ERROR IN fGetRejectedOrders QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sManagerType,Row[1],4);
		strncpy(sUserType,Row[0],3);
	}


	logDebug2("USER TYPE is :%s:",sUserType );

	if(!strcmp(sUserType ,"D") && !strcmp(sClientId ,"-1"))
	{
		if(sManagerType == "B")
		{
			logDebug2("Going to call fDealermapOrderBook");
			fDealersRejectedOrder(RcvMsg);
			return TRUE;
		}
		if(sManagerType == "BR")
		{
			logDebug2("Going to call fDealerALLOrderBook");
			fAdminRejectedOrder(RcvMsg);
			return TRUE;
		}
	}
	if(!strcmp(sUserType ,"D" ) && strcmp(sClientId ,"-1"))
	{
		logDebug2("---- Going to call fRejectedOrder");
		fRejectedOrder(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("Going to call fClientOrderBook-----");
		fRejectedOrder(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"S") && !strcmp(sClientId ,"-1"))
	{
		logDebug2("Going to call fAdminALLRejectedOrders");
		fAdminRejectedOrder(RcvMsg);
		return TRUE;
	}
	if(!strcmp(sUserType ,"S" ) && strcmp(sClientId ,"-1"))
	{
		logDebug2("---- Going to call fAdminRejectedOrders");
		fAdminRejectedOrderBook(RcvMsg);
		return TRUE;
	}


	logTimestamp("EXIT : fGetRejectedOrders");
	return TRUE;
}
BOOL 	fDealersRejectedOrder(CHAR *RcvMsg)
{
	logTimestamp("Entry : fDealersRejectedOrder");        

	struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
	struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
	struct  VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR *sDlrRjctOrds = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	LONG32          fNoOfRec=0.0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];


	pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


	/*      strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
		logdebug2(" sClientId :%s:", sClientId); */

	memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



	strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));

	sprintf(sDlrRjctOrds,"SELECT ORDNO,\
			SCRIP_CODE,\
			ORDBUYSELL,\
			TRADE_DATE,\
			ORDERTYPE,\
			PRODUCTCODE,\
			ORDQTY,\
			ORDERRATE,\
			INSUFFICIENT_QTY,\
			INSUFFICIENT_AMT,\
			IFNULL(AMOUNT_BLOCKED,0),\
			RMS_STATUS,\
			MKT_ORDER,\
			ltrim(rtrim(CLIENT_ID)),\
			SEGMENT,\
			EXCH_ID\
			FROM   RMS_REJECTED_ORDERS WHERE  CLIENT_ID IN (select e.ENTITY_CODE FROM ENTITY_MASTER e WHERE e.ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))union\
				select c.EDM_CLIENT_ID\
				FROM ENTITY_DEALER_MAPPING c\
				WHERE c.EDM_DEALER_ID = ltrim(rtrim(\"%s\"))\
				order by TRADE_DATE DESC;",sEntityId,sEntityId);        


			logDebug2("DlrRjctOrds:%s:",sDlrRjctOrds);

	if(mysql_query(DBQueries, sDlrRjctOrds) != SUCCESS)
	{
		logSqlFatal("ERROR in RejectOrd Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	fNoOfRec = mysql_num_rows(Res);

	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = fNoOfRec;

	pRejectedOrdersHdrResp.IntRespHeader.iSeqNo = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);

	pRejectedOrdersHdrResp.IntRespHeader.iErrorId = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_HEADER_RESP;
	pRejectedOrdersHdrResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
	pRejectedOrdersHdrResp.IntRespHeader.cSource  = pViewRejectedOrdersReq->ReqHeader.cSource ;
	//              pRejectedOrdersHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;

	pRejectedOrdersHdrResp.cMsgType = 'H';
	pRejectedOrdersHdrResp.iNoofRec = fNoOfRec;

	logDebug2("pViewRejectedOrdersReq->ReqHeader.iUserId = %llu",pViewRejectedOrdersReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewRejectedOrdersReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	logDebug2("pRejectedOrdersHdrResp.cMsgType:%c:, pRejectedOrdersHdrResp.iNoofRec:%d:", pRejectedOrdersHdrResp.cMsgType, pRejectedOrdersHdrResp.iNoofRec);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
	logDebug2("iNoOfPkt :%d:",iNoOfPkt);

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pRejectedOrdersResp,'\0',sizeof( struct VIEW_REJECTED_ORDERS_RESP));
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				pRejectedOrdersResp.IntRespHeader.iSeqNo = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgLength = sizeof(struct  VIEW_REJECTED_ORDERS_RESP);
				pRejectedOrdersResp.IntRespHeader.iErrorId = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_RESP;
				pRejectedOrdersResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
				pRejectedOrdersResp.IntRespHeader.cSource = pViewRejectedOrdersReq->ReqHeader.cSource ;
				//                                 pRejectedOrdersResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pRejectedOrdersResp.cMsgType = 'T';
				}
				else
				{
					pRejectedOrdersResp.cMsgType = 'D';
				}


				pRejectedOrdersResp.subRejOrdBook[j].fOrderNo = atof(Row[0]);
				//  strncpy(pRejectedOrdersResp.sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,Row[1],strlen(Row[1]));
				if(Row[2][0] == INT_BUY)
				{
					/**     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Buy",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_BUY,strlen(FE_BUY));
				}
				else if(Row[2][0] == INT_SELL)
				{
					/**                                     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Sell",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_SELL,strlen(FE_SELL));
				}
				/*      strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],DATE_LENGTH);     **/
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],strlen(Row[3]));
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime :%s: %d:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime,strlen(pRejectedOrdersResp.subRejOrdBook[j].sDatetime));
				if(Row[4][0] == 'N')
				{
					/** strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",8);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",3);
				}
				else if(Row[4][0] == 'M')
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"Modified",8);
				}

				if(Row[5][0] == PROD_INTRADAY)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_INTRADAY,strlen(FE_PROD_INTRADAY));
				}
				else if(Row[5][0] == PROD_MARGIN)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_MARGIN,strlen(FE_PROD_MARGIN));
				}
				else if(Row[5][0] == PROD_CNC)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_CNC,strlen(FE_PROD_CNC));
				}
				pRejectedOrdersResp.subRejOrdBook[j].iQty = atoi(Row[6]);
				pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice = atoi(Row[7]);
				pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty = atoi(Row[8]);
				pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt = atof(Row[9]);
				pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked = atof(Row[10]);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus,Row[11],10);
				pRejectedOrdersResp.subRejOrdBook[j].cMktOrder = Row[12][0];


				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sClientId,Row[13],strlen(Row[13]));

				logDebug2("-------------------------- Printing Data *********************");
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sClientId :%s: len :%d:",pRejectedOrdersResp.subRejOrdBook[j].sClientId,strlen(pRejectedOrdersResp.subRejOrdBook[j].sClientId));
				logDebug2("pRejectedOrdersHdrResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersHdrResp.IntRespHeader.iMsgCode);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrderNo:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrderNo);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sSecurityID:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd:%s:",pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime:%s:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sOrderType);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sProduct:%s:",pRejectedOrdersResp.subRejOrdBook[j].sProduct);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt:%f:",pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked:%f:",pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus:%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].cMktOrder:%c:",pRejectedOrdersResp.subRejOrdBook[j].cMktOrder);

				logDebug2("-------------------------- Printing Data *********************");

				pRejectedOrdersResp.subRejOrdBook[j].cSegment = Row[14][0];



				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sExcgId,Row[15],EXCHANGE_LEN);


				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sExcgId :%s:",pRejectedOrdersResp.subRejOrdBook[j].sExcgId);
				logDebug2(" pRejectedOrdersResp.cMsgType :%c:",pRejectedOrdersResp.cMsgType);
				logDebug2(" pRejectedOrdersResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersResp.IntRespHeader.iMsgCode);
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus :%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);

				logDebug2("pRejectedOrdersResp.subRejOrdBook.sSecurityID:%s: pRejectedOrdersResp.subRejOrdBook.sBuySellInd:%s: pRejectedOrdersResp.subRejOrdBook.sProduct:%s: pRejectedOrdersResp.subRejOrdBook.iQty:%d: pRejectedOrdersResp.subRejOrdBook.fOrdPrice:%f: pRejectedOrdersResp.subRejOrdBook.iInSuffQty:%d: pRejectedOrdersResp.subRejOrdBook.fInSuffAmt:%f: pRejectedOrdersResp.subRejOrdBook.fAmtBlocked:%f: pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,pRejectedOrdersResp.subRejOrdBook[j].sProduct,pRejectedOrdersResp.subRejOrdBook[j].iQty,pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice,pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty,pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt,pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked,pRejectedOrdersResp.subRejOrdBook[j].sOrderType);

			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersResp,sizeof(struct VIEW_REJECTED_ORDERS_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}
	}
	logTimestamp("Exit : fDealersRejectedOrder");
	return TRUE;

}

BOOL fRejectedOrder(CHAR *RcvMsg)
{
	logTimestamp("Entry : fRejectedOrder");     

	struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
	struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
	struct  VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR *sRejectedOrders = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	LONG32          fNoOfRec=0.0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];


	pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


	/*      strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
		logdebug2(" sClientId :%s:", sClientId); */

	memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



	strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));

	sprintf(sRejectedOrders,"SELECT ORDNO,\
			SCRIP_CODE,\
			ORDBUYSELL,\
			TRADE_DATE,\
			ORDERTYPE,\
			PRODUCTCODE,\
			ORDQTY,\
			ORDERRATE,\
			INSUFFICIENT_QTY,\
			INSUFFICIENT_AMT,\
			IFNULL(AMOUNT_BLOCKED,0),\
			RMS_STATUS,\
			MKT_ORDER,\
			ltrim(rtrim(CLIENT_ID)),\
			SEGMENT,\
			EXCH_ID\
			FROM   RMS_REJECTED_ORDERS \
			WHERE CLIENT_ID = ltrim(rtrim(\"%s\")) AND MKT_TYPE <> 'SP' ORDER BY TRADE_DATE DESC;",sClientId) ;
	/***       WHERE       CLIENT_ID IN (select e.ENTITY_CODE\
	  FROM ENTITY_MASTER e\
	  WHERE e.ENTITY_MANAGER_CODE =ltrim(rtrim(\"%s\"))\
	  union\
	  select c.EDM_CLIENT_ID\
	  FROM ENTITY_DEALER_MAPPING c\
	  WHERE c.EDM_DEALER_ID = ltrim(rtrim(\"%s\"))\
	  )\
	  order by TRADE_DATE DESC;",sEntityId,sEntityId);        *******/


	logDebug2("fRejectedOrders :%s:",sRejectedOrders);

	if(mysql_query(DBQueries, sRejectedOrders) != SUCCESS)
	{
		logSqlFatal("ERROR in RejectOrd Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	fNoOfRec = mysql_num_rows(Res);

	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = fNoOfRec;
	pRejectedOrdersHdrResp.IntRespHeader.iSeqNo = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);

	pRejectedOrdersHdrResp.IntRespHeader.iErrorId = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_HEADER_RESP;
	pRejectedOrdersHdrResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
	pRejectedOrdersHdrResp.IntRespHeader.cSource  = pViewRejectedOrdersReq->ReqHeader.cSource ;
	//              pRejectedOrdersHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;

	pRejectedOrdersHdrResp.cMsgType = 'H';
	pRejectedOrdersHdrResp.iNoofRec = fNoOfRec;

	logDebug2("pViewRejectedOrdersReq->ReqHeader.iUserId = %llu",pViewRejectedOrdersReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewRejectedOrdersReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}	

	logDebug2("pRejectedOrdersHdrResp.cMsgType:%c:, pRejectedOrdersHdrResp.iNoofRec:%d:", pRejectedOrdersHdrResp.cMsgType, pRejectedOrdersHdrResp.iNoofRec);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
	logDebug2("iNoOfPkt :%d:",iNoOfPkt);

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pRejectedOrdersResp,'\0',sizeof( struct VIEW_REJECTED_ORDERS_RESP));
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				pRejectedOrdersResp.IntRespHeader.iSeqNo = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgLength = sizeof(struct  VIEW_REJECTED_ORDERS_RESP);
				pRejectedOrdersResp.IntRespHeader.iErrorId = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_RESP;
				pRejectedOrdersResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
				pRejectedOrdersResp.IntRespHeader.cSource = pViewRejectedOrdersReq->ReqHeader.cSource ;
				//                                 pRejectedOrdersResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pRejectedOrdersResp.cMsgType = 'T';
				}
				else
				{
					pRejectedOrdersResp.cMsgType = 'D';
				}


				pRejectedOrdersResp.subRejOrdBook[j].fOrderNo = atof(Row[0]);
				//  strncpy(pRejectedOrdersResp.sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,Row[1],strlen(Row[1]));
				if(Row[2][0] == INT_BUY)
				{
					/**     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Buy",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_BUY,strlen(FE_BUY));
				}
				else if(Row[2][0] == INT_SELL)
				{
					/**                                     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Sell",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_SELL,strlen(FE_SELL));
				}
				/*      strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],DATE_LENGTH);     **/
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],strlen(Row[3]));
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime :%s: %d:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime,strlen(pRejectedOrdersResp.subRejOrdBook[j].sDatetime));
				if(Row[4][0] == 'N')
				{
					/** strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",8);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",3);
				}
				else if(Row[4][0] == 'M')
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"Modified",8);
				}

				if(Row[5][0] == PROD_INTRADAY)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_INTRADAY,strlen(FE_PROD_INTRADAY));
				}
				else if(Row[5][0] == PROD_MARGIN)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_MARGIN,strlen(FE_PROD_MARGIN));
				}
				else if(Row[5][0] == PROD_CNC)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_CNC,strlen(FE_PROD_CNC));
				}
				pRejectedOrdersResp.subRejOrdBook[j].iQty = atoi(Row[6]);
				pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice = atoi(Row[7]);
				pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty = atoi(Row[8]);
				pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt = atof(Row[9]);
				pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked = atof(Row[10]);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus,Row[11],10);
				pRejectedOrdersResp.subRejOrdBook[j].cMktOrder = Row[12][0];


				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sClientId,Row[13],strlen(Row[13]));

				logDebug2("-------------------------- Printing Data *********************");
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sClientId :%s: len :%d:",pRejectedOrdersResp.subRejOrdBook[j].sClientId,strlen(pRejectedOrdersResp.subRejOrdBook[j].sClientId));
				logDebug2("pRejectedOrdersHdrResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersHdrResp.IntRespHeader.iMsgCode);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrderNo:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrderNo);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sSecurityID:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd:%s:",pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime:%s:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sOrderType);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sProduct:%s:",pRejectedOrdersResp.subRejOrdBook[j].sProduct);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt:%f:",pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked:%f:",pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus:%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].cMktOrder:%c:",pRejectedOrdersResp.subRejOrdBook[j].cMktOrder);

				logDebug2("-------------------------- Printing Data *********************");

				pRejectedOrdersResp.subRejOrdBook[j].cSegment = Row[14][0];



				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sExcgId,Row[15],EXCHANGE_LEN);

				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sExcgId :%s:",pRejectedOrdersResp.subRejOrdBook[j].sExcgId);
				logDebug2(" pRejectedOrdersResp.cMsgType :%c:",pRejectedOrdersResp.cMsgType);
				logDebug2(" pRejectedOrdersResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersResp.IntRespHeader.iMsgCode);
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus :%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);

				logDebug2("pRejectedOrdersResp.subRejOrdBook.sSecurityID:%s: pRejectedOrdersResp.subRejOrdBook.sBuySellInd:%s: pRejectedOrdersResp.subRejOrdBook.sProduct:%s: pRejectedOrdersResp.subRejOrdBook.iQty:%d: pRejectedOrdersResp.subRejOrdBook.fOrdPrice:%f: pRejectedOrdersResp.subRejOrdBook.iInSuffQty:%d: pRejectedOrdersResp.subRejOrdBook.fInSuffAmt:%f: pRejectedOrdersResp.subRejOrdBook.fAmtBlocked:%f: pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,pRejectedOrdersResp.subRejOrdBook[j].sProduct,pRejectedOrdersResp.subRejOrdBook[j].iQty,pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice,pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty,pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt,pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked,pRejectedOrdersResp.subRejOrdBook[j].sOrderType);

			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersResp,sizeof(struct VIEW_REJECTED_ORDERS_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}
	}
	logTimestamp("Exit : fRejectedOrder");

}

BOOL fAdminRejectedOrder(CHAR *RcvMsg)
{
	logTimestamp("Entry : fAdminRejectedOrder");

	struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
	struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
	struct  VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR *sAdmnRejectedOrders1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	LONG32          fNoOfRec=0.0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];


	pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


	/*      strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
		logdebug2(" sClientId :%s:", sClientId); */

	memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



	strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));

	sprintf(sAdmnRejectedOrders1,"SELECT ORDNO,\
			SCRIP_CODE,\
			ORDBUYSELL,\
			TRADE_DATE,\
			ORDERTYPE,\
			PRODUCTCODE,\
			ORDQTY,\
			ORDERRATE,\
			INSUFFICIENT_QTY,\
			INSUFFICIENT_AMT,\
			IFNULL(AMOUNT_BLOCKED,0),\
			RMS_STATUS,\
			MKT_ORDER,\
			ltrim(rtrim(CLIENT_ID)),\
			SEGMENT,\
			EXCH_ID\
			FROM   RMS_REJECTED_ORDERS") ;

	logDebug2("fRejectedOrders :%s:",sAdmnRejectedOrders1);

	if(mysql_query(DBQueries, sAdmnRejectedOrders1) != SUCCESS)
	{
		logSqlFatal("ERROR in RejectOrd Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	fNoOfRec = mysql_num_rows(Res);

	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = fNoOfRec;

	pRejectedOrdersHdrResp.IntRespHeader.iSeqNo = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);

	pRejectedOrdersHdrResp.IntRespHeader.iErrorId = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_HEADER_RESP;
	pRejectedOrdersHdrResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
	pRejectedOrdersHdrResp.IntRespHeader.cSource  = pViewRejectedOrdersReq->ReqHeader.cSource ;
	//              pRejectedOrdersHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;

	pRejectedOrdersHdrResp.cMsgType = 'H';
	pRejectedOrdersHdrResp.iNoofRec = fNoOfRec;

	logDebug2("pViewRejectedOrdersReq->ReqHeader.iUserId = %llu",pViewRejectedOrdersReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewRejectedOrdersReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}	

	logDebug2("pRejectedOrdersHdrResp.cMsgType:%c:, pRejectedOrdersHdrResp.iNoofRec:%d:", pRejectedOrdersHdrResp.cMsgType, pRejectedOrdersHdrResp.iNoofRec);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
	logDebug2("iNoOfPkt :%d:",iNoOfPkt);

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pRejectedOrdersResp,'\0',sizeof( struct VIEW_REJECTED_ORDERS_RESP));
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				pRejectedOrdersResp.IntRespHeader.iSeqNo = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgLength = sizeof(struct  VIEW_REJECTED_ORDERS_RESP);
				pRejectedOrdersResp.IntRespHeader.iErrorId = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_RESP;
				pRejectedOrdersResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
				pRejectedOrdersResp.IntRespHeader.cSource = pViewRejectedOrdersReq->ReqHeader.cSource ;
				//                                 pRejectedOrdersResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pRejectedOrdersResp.cMsgType = 'T';
				}
				else
				{
					pRejectedOrdersResp.cMsgType = 'D';
				}


				pRejectedOrdersResp.subRejOrdBook[j].fOrderNo = atof(Row[0]);
				//  strncpy(pRejectedOrdersResp.sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,Row[1],strlen(Row[1]));
				if(Row[2][0] == INT_BUY)
				{
					/**     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Buy",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_BUY,strlen(FE_BUY));
				}
				else if(Row[2][0] == INT_SELL)
				{
					/**                                     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Sell",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_SELL,strlen(FE_SELL));
				}
				/*      strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],DATE_LENGTH);     **/
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],strlen(Row[3]));
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime :%s: %d:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime,strlen(pRejectedOrdersResp.subRejOrdBook[j].sDatetime));
				if(Row[4][0] == 'N')
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",3);
				}
				else if(Row[4][0] == 'M')
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"Modified",8);
				}

				if(Row[5][0] == PROD_INTRADAY)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_INTRADAY,strlen(FE_PROD_INTRADAY));
				}
				else if(Row[5][0] == PROD_MARGIN)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_MARGIN,strlen(FE_PROD_MARGIN));
				}
				else if(Row[5][0] == PROD_CNC)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_CNC,strlen(FE_PROD_CNC));
				}
				pRejectedOrdersResp.subRejOrdBook[j].iQty = atoi(Row[6]);
				pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice = atoi(Row[7]);
				pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty = atoi(Row[8]);
				pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt = atof(Row[9]);
				pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked = atof(Row[10]);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus,Row[11],10);
				pRejectedOrdersResp.subRejOrdBook[j].cMktOrder = Row[12][0];


				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sClientId,Row[13],strlen(Row[13]));

				logDebug2("-------------------------- Printing Data *********************");
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sClientId :%s: len :%d:",pRejectedOrdersResp.subRejOrdBook[j].sClientId,strlen(pRejectedOrdersResp.subRejOrdBook[j].sClientId));
				logDebug2("pRejectedOrdersHdrResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersHdrResp.IntRespHeader.iMsgCode);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrderNo:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrderNo);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sSecurityID:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd:%s:",pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime:%s:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sOrderType);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sProduct:%s:",pRejectedOrdersResp.subRejOrdBook[j].sProduct);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt:%f:",pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked:%f:",pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus:%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].cMktOrder:%c:",pRejectedOrdersResp.subRejOrdBook[j].cMktOrder);

				logDebug2("-------------------------- Printing Data *********************");

				pRejectedOrdersResp.subRejOrdBook[j].cSegment = Row[14][0];



				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sExcgId,Row[15],EXCHANGE_LEN);


				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sExcgId :%s:",pRejectedOrdersResp.subRejOrdBook[j].sExcgId);
				logDebug2(" pRejectedOrdersResp.cMsgType :%c:",pRejectedOrdersResp.cMsgType);
				logDebug2(" pRejectedOrdersResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersResp.IntRespHeader.iMsgCode);
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus :%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);

				logDebug2("pRejectedOrdersResp.subRejOrdBook.sSecurityID:%s: pRejectedOrdersResp.subRejOrdBook.sBuySellInd:%s: pRejectedOrdersResp.subRejOrdBook.sProduct:%s: pRejectedOrdersResp.subRejOrdBook.iQty:%d: pRejectedOrdersResp.subRejOrdBook.fOrdPrice:%f: pRejectedOrdersResp.subRejOrdBook.iInSuffQty:%d: pRejectedOrdersResp.subRejOrdBook.fInSuffAmt:%f: pRejectedOrdersResp.subRejOrdBook.fAmtBlocked:%f: pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,pRejectedOrdersResp.subRejOrdBook[j].sProduct,pRejectedOrdersResp.subRejOrdBook[j].iQty,pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice,pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty,pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt,pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked,pRejectedOrdersResp.subRejOrdBook[j].sOrderType);

			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersResp,sizeof(struct VIEW_REJECTED_ORDERS_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}
	}
	logTimestamp("Exit : fAdminRejectedOrder");

}

BOOL 	fAdminRejectedOrderBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fAdminRejectedOrderBook");

	struct VIEW_COMMON_QUERY_REQ *pViewRejectedOrdersReq;
	struct  VIEW_REJECTED_ORDERS_RESP pRejectedOrdersResp;
	struct  VIEW_COMMON_HDR_RESP  pRejectedOrdersHdrResp;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR *sAdmnRjctOrds = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	LONG32          fNoOfRec=0.0;
	LONG32          iTempNoOfRec;
	DOUBLE64        fConvertPrice;
	LONG32          iNoOfPkt;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];


	pViewRejectedOrdersReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;


	/*      strncpy(sClientId ,pViewRejectedOrdersReq->ClientId,CLIENT_ID_LEN);
		logdebug2(" sClientId :%s:", sClientId); */

	memset(&pRejectedOrdersResp,'\0',sizeof(struct  VIEW_REJECTED_ORDERS_RESP));



	strncpy(sClientId ,pViewRejectedOrdersReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId,pViewRejectedOrdersReq->sEntityId,ENTITY_ID_LEN);

	logDebug2(" sEntityId  :%s: , pViewRejectedOrdersReq->sClientId :%s: , sClientId.len:%d:",sClientId ,pViewRejectedOrdersReq->sClientId,strlen(sClientId));

	sprintf(sAdmnRjctOrds,"SELECT ORDNO,\
			SCRIP_CODE,\
			ORDBUYSELL,\
			TRADE_DATE,\
			ORDERTYPE,\
			PRODUCTCODE,\
			ORDQTY,\
			ORDERRATE,\
			INSUFFICIENT_QTY,\
			INSUFFICIENT_AMT,\
			IFNULL(AMOUNT_BLOCKED,0),\
			RMS_STATUS,\
			MKT_ORDER,\
			ltrim(rtrim(CLIENT_ID)),\
			SEGMENT,\
			EXCH_ID\
			FROM   RMS_REJECTED_ORDERS \
			WHERE CLIENT_ID = ltrim(rtrim(\"%s\"))",sClientId);

	logDebug2("sAdmnRjctOrds :%s:",sAdmnRjctOrds);

	if(mysql_query(DBQueries, sAdmnRjctOrds) != SUCCESS)
	{
		logSqlFatal("ERROR in RejectOrd Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	fNoOfRec = mysql_num_rows(Res);

	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = fNoOfRec;

	pRejectedOrdersHdrResp.IntRespHeader.iSeqNo = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);

	pRejectedOrdersHdrResp.IntRespHeader.iErrorId = 0;
	pRejectedOrdersHdrResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_HEADER_RESP;
	pRejectedOrdersHdrResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
	pRejectedOrdersHdrResp.IntRespHeader.cSource  = pViewRejectedOrdersReq->ReqHeader.cSource ;
	//              pRejectedOrdersHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;

	pRejectedOrdersHdrResp.cMsgType = 'H';
	pRejectedOrdersHdrResp.iNoofRec = fNoOfRec;

	logDebug2("pViewRejectedOrdersReq->ReqHeader.iUserId = %llu",pViewRejectedOrdersReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewRejectedOrdersReq->ReqHeader.iUserId);	
	logDebug2("iRelayID = %d",iRelayID);

	logDebug2("pRejectedOrdersHdrResp.cMsgType:%c:, pRejectedOrdersHdrResp.iNoofRec:%d:", pRejectedOrdersHdrResp.cMsgType, pRejectedOrdersHdrResp.iNoofRec);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
	logDebug2("iNoOfPkt :%d:",iNoOfPkt);

	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pRejectedOrdersResp,'\0',sizeof( struct VIEW_REJECTED_ORDERS_RESP));
		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				pRejectedOrdersResp.IntRespHeader.iSeqNo = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgLength = sizeof(struct  VIEW_REJECTED_ORDERS_RESP);
				pRejectedOrdersResp.IntRespHeader.iErrorId = 0;
				pRejectedOrdersResp.IntRespHeader.iMsgCode = TC_INT_REJECTED_ORDERS_RESP;
				pRejectedOrdersResp.IntRespHeader.iUserId = pViewRejectedOrdersReq->ReqHeader.iUserId;
				pRejectedOrdersResp.IntRespHeader.cSource = pViewRejectedOrdersReq->ReqHeader.cSource ;
				//                                 pRejectedOrdersResp.IntRespHeader.cUserTypeOrLogInfoType = pViewRejectedOrdersReq->ReqHeader.cUserType;


				if(iTempNoOfRec <= 1)
				{
					pRejectedOrdersResp.cMsgType = 'T';
				}
				else
				{
					pRejectedOrdersResp.cMsgType = 'D';
				}


				pRejectedOrdersResp.subRejOrdBook[j].fOrderNo = atof(Row[0]);
				//  strncpy(pRejectedOrdersResp.sClientId,sClientId ,CLIENT_ID_LEN);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,Row[1],strlen(Row[1]));
				if(Row[2][0] == INT_BUY)
				{
					/**     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Buy",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_BUY,strlen(FE_BUY));
				}
				else if(Row[2][0] == INT_SELL)
				{
					/**                                     strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,"Sell",5);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,FE_SELL,strlen(FE_SELL));
				}
				/*      strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],DATE_LENGTH);     **/
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sDatetime,Row[3],strlen(Row[3]));
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime :%s: %d:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime,strlen(pRejectedOrdersResp.subRejOrdBook[j].sDatetime));
				if(Row[4][0] == 'N')
				{
					/** strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",8);***/
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"New",3);
				}
				else if(Row[4][0] == 'M')
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sOrderType,"Modified",8);
				}

				if(Row[5][0] == PROD_INTRADAY)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_INTRADAY,strlen(FE_PROD_INTRADAY));
				}
				else if(Row[5][0] == PROD_MARGIN)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_MARGIN,strlen(FE_PROD_MARGIN));
				}
				else if(Row[5][0] == PROD_CNC)
				{
					strncpy(pRejectedOrdersResp.subRejOrdBook[j].sProduct,FE_PROD_CNC,strlen(FE_PROD_CNC));
				}
				pRejectedOrdersResp.subRejOrdBook[j].iQty = atoi(Row[6]);
				pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice = atoi(Row[7]);
				pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty = atoi(Row[8]);
				pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt = atof(Row[9]);
				pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked = atof(Row[10]);
				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus,Row[11],10);
				pRejectedOrdersResp.subRejOrdBook[j].cMktOrder = Row[12][0];


				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sClientId,Row[13],strlen(Row[13]));

				logDebug2("-------------------------- Printing Data *********************");
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sClientId :%s: len :%d:",pRejectedOrdersResp.subRejOrdBook[j].sClientId,strlen(pRejectedOrdersResp.subRejOrdBook[j].sClientId));
				logDebug2("pRejectedOrdersHdrResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersHdrResp.IntRespHeader.iMsgCode);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrderNo:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrderNo);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sSecurityID:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd:%s:",pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sDatetime:%s:",pRejectedOrdersResp.subRejOrdBook[j].sDatetime);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sOrderType);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sProduct:%s:",pRejectedOrdersResp.subRejOrdBook[j].sProduct);

				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice:%f:",pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty:%d:",pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt:%f:",pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked:%f:",pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus:%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);
				logDebug2("pRejectedOrdersResp.subRejOrdBook[j].cMktOrder:%c:",pRejectedOrdersResp.subRejOrdBook[j].cMktOrder);

				logDebug2("\n -------------------------- Printing Data *********************");

				pRejectedOrdersResp.subRejOrdBook[j].cSegment = Row[14][0];



				strncpy(pRejectedOrdersResp.subRejOrdBook[j].sExcgId,Row[15],EXCHANGE_LEN);


				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sExcgId :%s:",pRejectedOrdersResp.subRejOrdBook[j].sExcgId);
				logDebug2(" pRejectedOrdersResp.cMsgType :%c:",pRejectedOrdersResp.cMsgType);
				logDebug2(" pRejectedOrdersResp.IntRespHeader.iMsgCode :%d:",pRejectedOrdersResp.IntRespHeader.iMsgCode);
				logDebug2(" pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus :%s:",pRejectedOrdersResp.subRejOrdBook[j].sRmsStatus);

				logDebug2("pRejectedOrdersResp.subRejOrdBook.sSecurityID:%s: pRejectedOrdersResp.subRejOrdBook.sBuySellInd:%s: pRejectedOrdersResp.subRejOrdBook.sProduct:%s: pRejectedOrdersResp.subRejOrdBook.iQty:%d: pRejectedOrdersResp.subRejOrdBook.fOrdPrice:%f: pRejectedOrdersResp.subRejOrdBook.iInSuffQty:%d: pRejectedOrdersResp.subRejOrdBook.fInSuffAmt:%f: pRejectedOrdersResp.subRejOrdBook.fAmtBlocked:%f: pRejectedOrdersResp.subRejOrdBook[j].sOrderType:%s:",pRejectedOrdersResp.subRejOrdBook[j].sSecurityID,pRejectedOrdersResp.subRejOrdBook[j].sBuySellInd,pRejectedOrdersResp.subRejOrdBook[j].sProduct,pRejectedOrdersResp.subRejOrdBook[j].iQty,pRejectedOrdersResp.subRejOrdBook[j].fOrdPrice,pRejectedOrdersResp.subRejOrdBook[j].iInSuffQty,pRejectedOrdersResp.subRejOrdBook[j].fInSuffAmt,pRejectedOrdersResp.subRejOrdBook[j].fAmtBlocked,pRejectedOrdersResp.subRejOrdBook[j].sOrderType);

			}

			iTempNoOfRec--;
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pRejectedOrdersResp,sizeof(struct VIEW_REJECTED_ORDERS_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}
	}

	logTimestamp("Exit : fAdminRejectedOrderBook");
}

/*
   BOOL	fMarginShortFall(CHAR *RcvMsg)
   {
   logTimestamp("Entry : fMarginShortFall");

//	struct 	VIEW_COMMON_QUERY_REQ	*pMargShtfallReq;
struct	VIEW_MARGIN_MTM_COMMON_QUERY_REQ	*pMargShtfallReq;

pMargShtfallReq = (struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

MYSQL_RES    *Res;
MYSQL_ROW     Row;

//	CHAR	cUserType;
CHAR    *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
logDebug2("pMargShtfallReq->iMode = %d",pMargShtfallReq->iMode);
logDebug2("pMargShtfallReq->sClientId = %s",pMargShtfallReq->sClientId);
logDebug2("pMargShtfallReq->cUserType = %c",pMargShtfallReq->cUserType);

if(pMargShtfallReq->cUserType == SUPER_ADMIN)
{
logDebug2("call fMarginShortFallAll");
fMarginShortFallAll(RcvMsg);
return TRUE;
}
if(pMargShtfallReq->cUserType == ADMIN_TYPE)
{
logDebug2("call fMarginSrtFall");
fMarginSrtFall(RcvMsg);	
return TRUE;
}

logTimestamp("Exit : fMarginShortFall");
return TRUE;

}
 */


BOOL    fMarginShortFall_PR_COM(CHAR *RcvMsg)
{
        logTimestamp("Entry :fMarginShortFall_PR_COM");

        struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ	*pMarginShortFallReq;

        pMarginShortFallReq = (struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ	*)RcvMsg;

        CHAR    sQry[MAX_QUERY_SIZE];
        memset(sQry,'\0',MAX_QUERY_SIZE);
        sprintf(sQry,"CALL PR_MARGIN_SHORTFALL_COM(%d,\'%c\')",pMarginShortFallReq->iMode,pMarginShortFallReq->ReqHeader.cSegment);

        logDebug2("sQry = %s",sQry);

        if(mysql_query(DBQueries,sQry) != SUCCESS)
        {
                logSqlFatal("ERROR IN PR_MARGIN_SHORTFALL_COM sQRY.");
                sql_Error(DBQueries);
                return  FALSE;
        }



        logTimestamp("Exit : fMarginShortFall_PR_COM");
        return TRUE;
}

BOOL	fMarginShortFall_PR(CHAR *RcvMsg)
{
	logTimestamp("Entry :fMarginShortFall_PR");

	struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ *pMarginShortFallReq;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	pMarginShortFallReq = (struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

	logDebug2("pMarginShortFallReq->iMode = %d",pMarginShortFallReq->iMode);
	logDebug2("pMarginShortFallReq->sClientId = %s",pMarginShortFallReq->sClientId);
	//logDebug2("pMarginShortFallReq->sClientName = %s",pMarginShortFallReq->sClientName);

	CHAR    *sQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	//	sprintf(sQry,"CALL PR_MARGIN_SHORTFALL_CAPITAL(%d,\"%s\",\"%s\")",pMarginShortFallReq->iMode,pMarginShortFallReq->sClientId,pMarginShortFallReq->sClientName);
		
	//sprintf(sQry,"CALL PR_MTM_FTCH_CONFIG(%d)",pMarginShortFallReq->iMode);
	sprintf(sQry,"CALL PR_MARGIN_SHORTFALL(%d,\'%c\')",pMarginShortFallReq->iMode,pMarginShortFallReq->ReqHeader.cSegment);

	logDebug2("sQry = %s",sQry);

	if(mysql_query(DBQueries,sQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN PR_MARGIN_SHORTFALL_CAPITAL sQRY.");
		sql_Error(DBQueries);
		return	FALSE;
	}

	return TRUE;	
	logTimestamp("Exit : fMarginShortFall_PR");
}



BOOL	fMarginShortFall(CHAR *RcvMsg)
{
	logTimestamp("Entry : fMarginShortFallAll");

	struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ	*pViewMarginShrtfallReq;
	struct  VIEW_MARGIN_MTM_COMMON_QUERY_RESP       pMarginShrtfallResp;
	struct  VIEW_COMMON_HDR_RESP                    pMarShrtfallHdrResp;	

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	pViewMarginShrtfallReq = (struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

	CHAR	sMarginQry[MAX_QUERY_SIZE];	
	CHAR	sWhere_Clause[QUERY_SIZE];
	CHAR	sMarg_Qry[QUERY_SIZE];

	LONG32 		i=0,j=0;
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	ChkFlag = FALSE;

	memset(sMarginQry,'\0',MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	logDebug2("pViewMarginShrtfallReq->iMode = %d",pViewMarginShrtfallReq->iMode);
	logDebug2("pViewMarginShrtfallReq->sClientId = %s",pViewMarginShrtfallReq->sClientId);
	//logDebug2("pViewMarginShrtfallReq->sClientName = %s",pViewMarginShrtfallReq->sClientName);
	logDebug2("pViewMarginShrtfallReq->sManager_Code = %s",pViewMarginShrtfallReq->sManager_Code);
	
	if (pViewMarginShrtfallReq->ReqHeader.cSegment != 'M')
        {

		ChkFlag = fMarginShortFall_PR(RcvMsg);
	}
        else
        {
                ChkFlag = fMarginShortFall_PR_COM(RcvMsg);
        }

	if(ChkFlag == FALSE)
	{
		logDebug3(" Error in fMarginShortFall_PR ");
		return	FALSE;
	}

	if(strcmp(pViewMarginShrtfallReq->sClientId,SELECT_ALL))
	{
		memset(sMarg_Qry,'\0',QUERY_SIZE);
		sprintf(sMarg_Qry,"AND CLIENT_ID = \"%s\"",pViewMarginShrtfallReq->sClientId);
		logDebug2("sMarg_Qry = %s",sMarg_Qry);
		strcat(sWhere_Clause,sMarg_Qry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(pViewMarginShrtfallReq->iShortFallFlag == MARGIN_SHORTFALL_FLAG)
	{
		memset(sMarg_Qry,'\0',QUERY_SIZE);
		sprintf(sMarg_Qry,"AND SHORTFALLVALUE < 0");
		logDebug2("sMarg_Qry = %s",sMarg_Qry);
		strcat(sWhere_Clause,sMarg_Qry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}

	logDebug2("final sWhere_Clause = %s",sWhere_Clause);	

	sprintf(sMarginQry,"	SELECT CLIENT_ID,TOTAL_BAL,BANK_HOLDING,ADHOC,LIMIT_SOD,MTMKT_EQ,MTMKT_DR,TOTALMTM,MTMPER,EXPOSURE_EQ,EXPOSURE_EQ_GROSS,\
			EXPOSURE_DR,EXPOSURE_DR_GROSS,REALISED_PROFIT,SPAN,TREALISEDMTM,SHORTFALLVALUE\
			FROM MARGIN_SHORTFALL a, ENTITY_MASTER s where a.CLIENT_ID = s.ENTITY_CODE and s.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\"))\
			WHERE 1=1 %s ;",pViewMarginShrtfallReq->sManager_Code,sWhere_Clause);

	logDebug2("sMarginQry = %s",sMarginQry);

	if(mysql_query(DBQueries,sMarginQry ) != SUCCESS)
	{
		logSqlFatal("ERROR in sMarginQry.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;

	pMarShrtfallHdrResp.IntRespHeader.iSeqNo = 0;
	pMarShrtfallHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pMarShrtfallHdrResp.IntRespHeader.iErrorId = 0;
	pMarShrtfallHdrResp.IntRespHeader.iMsgCode = TC_INT_MARGIN_SHORTFALL_HEADER_RESP;
	pMarShrtfallHdrResp.IntRespHeader.iUserId = pViewMarginShrtfallReq->ReqHeader.iUserId;
	pMarShrtfallHdrResp.IntRespHeader.cSource = pViewMarginShrtfallReq->ReqHeader.cSource ;
	pMarShrtfallHdrResp.cMsgType = 'H';
	pMarShrtfallHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pMarShrtfallHdrResp.IntRespHeader.iMsgLength = %d",pMarShrtfallHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pMarShrtfallHdrResp.IntRespHeader.iMsgCode = %d",pMarShrtfallHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pMarShrtfallHdrResp.IntRespHeader.iUserId = %llu",pMarShrtfallHdrResp.IntRespHeader.iUserId);
	logDebug2("pMarShrtfallHdrResp.IntRespHeader.cSource = %c",pMarShrtfallHdrResp.IntRespHeader.cSource);
	logDebug2("pMarShrtfallHdrResp.iNoofRec = %d",pMarShrtfallHdrResp.iNoofRec);

	logDebug2("pViewMarginShrtfallReq->ReqHeader.iUserId = %llu",pViewMarginShrtfallReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pViewMarginShrtfallReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pMarShrtfallHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pMarginShrtfallResp.IntRespHeader.iSeqNo = 0;
				pMarginShrtfallResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_MARGIN_MTM_COMMON_QUERY_RESP);
				pMarginShrtfallResp.IntRespHeader.iMsgCode = TC_INT_MARGIN_SHORTFALL_RESP;
				pMarginShrtfallResp.IntRespHeader.iErrorId = 0;
				pMarginShrtfallResp.IntRespHeader.iUserId = pViewMarginShrtfallReq->ReqHeader.iUserId;
				pMarginShrtfallResp.IntRespHeader.cSource = pViewMarginShrtfallReq->ReqHeader.cSource ;

				if(iTempNoOfRec <= 1)
				{
					pMarginShrtfallResp.cMsgType = 'T';
				}
				else
				{
					pMarginShrtfallResp.cMsgType = 'D';
				}

				strncpy(pMarginShrtfallResp.subViewMargin[j].sClientId,Row[0],CLIENT_ID_LEN);
				pMarginShrtfallResp.subViewMargin[j].fTotalBal = atof(Row[1]);
				pMarginShrtfallResp.subViewMargin[j].fBankHodl = atof(Row[2]);
				pMarginShrtfallResp.subViewMargin[j].fAdhoc = atof(Row[3]);
				pMarginShrtfallResp.subViewMargin[j].fLimit_SOD = atof(Row[4]);
				pMarginShrtfallResp.subViewMargin[j].fMTMKT_EQ = atof(Row[5]);
				pMarginShrtfallResp.subViewMargin[j].fMTMKT_DR = atof(Row[6]);
				pMarginShrtfallResp.subViewMargin[j].fTotalMTM = atof(Row[7]);
				pMarginShrtfallResp.subViewMargin[j].fMTM_PER = atof(Row[8]);
				pMarginShrtfallResp.subViewMargin[j].fEXPO_EQ = atof(Row[9]);
				pMarginShrtfallResp.subViewMargin[j].fEXPO_EQ_GROSS = atof(Row[10]);
				pMarginShrtfallResp.subViewMargin[j].fEXPO_DR = atof(Row[11]);
				pMarginShrtfallResp.subViewMargin[j].fEXPO_DR_GROSS = atof(Row[12]);
				pMarginShrtfallResp.subViewMargin[j].fRealised_Profit = atof(Row[13]);
				pMarginShrtfallResp.subViewMargin[j].fSpan = atof(Row[14]);
				pMarginShrtfallResp.subViewMargin[j].fRealised_MTM = atof(Row[15]);
				pMarginShrtfallResp.subViewMargin[j].fShortfall_VAL = atof(Row[16]);

				logDebug2("pMarginShrtfallResp.subViewMargin[j].sClientId = %s",pMarginShrtfallResp.subViewMargin[j].sClientId);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fTotalBal = %lf",pMarginShrtfallResp.subViewMargin[j].fTotalBal);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fBankHodl = %lf",pMarginShrtfallResp.subViewMargin[j].fBankHodl);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fAdhoc = %lf",pMarginShrtfallResp.subViewMargin[j].fAdhoc);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fLimit_SOD = %lf",pMarginShrtfallResp.subViewMargin[j].fLimit_SOD);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fMTMKT_EQ = %lf",pMarginShrtfallResp.subViewMargin[j].fMTMKT_EQ);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fMTMKT_DR = %lf",pMarginShrtfallResp.subViewMargin[j].fMTMKT_DR);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fTotalMTM = %lf",pMarginShrtfallResp.subViewMargin[j].fTotalMTM);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fMTM_PER = %lf",pMarginShrtfallResp.subViewMargin[j].fMTM_PER);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fEXPO_EQ = %lf",pMarginShrtfallResp.subViewMargin[j].fEXPO_EQ);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fEXPO_EQ_GROSS = %lf",pMarginShrtfallResp.subViewMargin[j].fEXPO_EQ_GROSS);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fEXPO_DR = %lf",pMarginShrtfallResp.subViewMargin[j].fEXPO_DR);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fEXPO_DR_GROSS = %lf",pMarginShrtfallResp.subViewMargin[j].fEXPO_DR_GROSS);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fRealised_Profit = %lf",pMarginShrtfallResp.subViewMargin[j].fRealised_Profit);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fSpan = %lf",pMarginShrtfallResp.subViewMargin[j].fSpan);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fRealised_MTM = %lf",pMarginShrtfallResp.subViewMargin[j].fRealised_MTM);
				logDebug2("pMarginShrtfallResp.subViewMargin[j].fShortfall_VAL = %lf",pMarginShrtfallResp.subViewMargin[j].fShortfall_VAL);

			}
			iTempNoOfRec--;

		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pMarginShrtfallResp,sizeof(struct VIEW_MARGIN_MTM_COMMON_QUERY_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iSTWRelToQueryQ);
			return FALSE;
		}
	}

	logTimestamp("Exit : fMarginShortFallAll");
	return TRUE;
}

/*
   BOOL	fMarginSrtFall(CHAR *RcvMsg)
   {
   logTimestamp("Entry : fMarginSrtFall");

   struct	VIEW_MARGIN_MTM_COMMON_QUERY_REQ	*pViewMarShrtfallReq;
   struct	VIEW_MARGIN_MTM_COMMON_QUERY_RESP	pMarShrtfallResp;
   struct 	VIEW_COMMON_HDR_RESP			pMarShtfallHdrResp;

   MYSQL_RES    *Res;
   MYSQL_ROW     Row;

   CHAR    *sMarginQry1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

   LONG32          i=0,j=0;
   LONG32          iNoOfRec=0;
   DOUBLE64        fNoOfRec;
   LONG32          iNoOfPkt;
   LONG32          iTempNoOfRec;

   pViewMarShrtfallReq = (struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

   ChkFlag = FALSE;

   logDebug2("pViewMarShrtfallReq->iMode = %d",pViewMarShrtfallReq->iMode);
   logDebug2("pViewMarShrtfallReq->sClientId = %s",pViewMarShrtfallReq->sClientId);
   logDebug2("pViewMarShrtfallReq->sClientName = %s",pViewMarShrtfallReq->sClientName);
   logDebug2("pViewMarShrtfallReq->sManager_Code = %s",pViewMarShrtfallReq->sManager_Code);

   ChkFlag = fMarginShortFall_PR(RcvMsg);

   if(ChkFlag == FALSE)
   {
   logDebug3(" Error in fMarginShortFall_PR ");
   return	FALSE;	
   }

   sprintf(sMarginQry1,"   SELECT CLIENT_ID,TOTAL_BAL,BANK_HOLDING,ADHOC,LIMIT_SOD,MTMKT_EQ,MTMKT_DR,TOTALMTM,MTMPER,EXPOSURE_EQ,EXPOSURE_EQ_GROSS,\
   EXPOSURE_DR,EXPOSURE_DR_GROSS,REALISED_PROFIT,SPAN,TREALISEDMTM,SHORTFALLVALUE\
   FROM MARGIN_SHORTFALL a, ENTITY_MASTER s where a.CLIENT_ID = s.ENTITY_CODE and s.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\"))",\
   pViewMarShrtfallReq->sManager_Code);

   logDebug2("sMarginQry1 = %s",sMarginQry1);

   if(mysql_query(DBQueries,sMarginQry1) != SUCCESS)
   {
   logSqlFatal("ERROR in sMarginQry1.......");
   sql_Error(DBQueries);
   }

   Res = mysql_store_result(DBQueries);

   iNoOfRec= mysql_num_rows(Res);
   fNoOfRec = iNoOfRec;
   iNoOfPkt = ceil(fNoOfRec/5);
   iTempNoOfRec = iNoOfRec;

   pMarShtfallHdrResp.IntRespHeader.iSeqNo = 0;
   pMarShtfallHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
   pMarShtfallHdrResp.IntRespHeader.iErrorId = 0;
   pMarShtfallHdrResp.IntRespHeader.iMsgCode = TC_INT_MARGIN_SHORTFALL_HEADER_RESP ;
   pMarShtfallHdrResp.IntRespHeader.iUserId = pViewMarShrtfallReq->ReqHeader.iUserId;
   pMarShtfallHdrResp.IntRespHeader.cSource = pViewMarShrtfallReq->ReqHeader.cSource ;
   pMarShtfallHdrResp.cMsgType = 'H';
   pMarShtfallHdrResp.iNoofRec = iNoOfRec;

   logDebug2("pMarShtfallHdrResp.IntRespHeader.iMsgLength = %d",pMarShtfallHdrResp.IntRespHeader.iMsgLength);
   logDebug2("pMarShtfallHdrResp.IntRespHeader.iMsgCode = %d",pMarShtfallHdrResp.IntRespHeader.iMsgCode);
   logDebug2("pMarShtfallHdrResp.IntRespHeader.iUserId = %d",pMarShtfallHdrResp.IntRespHeader.iUserId);
   logDebug2("pMarShtfallHdrResp.IntRespHeader.cSource = %c",pMarShtfallHdrResp.IntRespHeader.cSource);
   logDebug2("pMarShtfallHdrResp.iNoofRec = %d",pMarShtfallHdrResp.iNoofRec);

logDebug2("pViewMarShrtfallReq->ReqHeader.iUserId = %d",pViewMarShrtfallReq->ReqHeader.iUserId);
iRelayID = find_user_adapter(pViewMarShrtfallReq->ReqHeader.iUserId);
logDebug2("iRelayID = %d",iRelayID);

if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pMarShtfallHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
{
	perror("Error WriteMsgQ: ");
	logFatal("Write Q id %d", iSTWRelToQueryQ);
	return FALSE;
}

for(i=0;i<iNoOfPkt;i++)
{
	for(j=0;j<5;j++)
	{
		if((Row = mysql_fetch_row(Res)))
		{
			pMarShrtfallResp.IntRespHeader.iSeqNo = 0;
			pMarShrtfallResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_MARGIN_MTM_COMMON_QUERY_RESP);
			pMarShrtfallResp.IntRespHeader.iMsgCode = TC_INT_MARGIN_SHORTFALL_RESP;
			pMarShrtfallResp.IntRespHeader.iErrorId = 0;
			pMarShrtfallResp.IntRespHeader.iUserId = pViewMarShrtfallReq->ReqHeader.iUserId;
			pMarShrtfallResp.IntRespHeader.cSource = pViewMarShrtfallReq->ReqHeader.cSource ;

			if(iTempNoOfRec <= 1)
			{
				pMarShrtfallResp.cMsgType = 'T';
			}
			else
			{
				pMarShrtfallResp.cMsgType = 'D';
			}

			strncpy(pMarShrtfallResp.subViewMargin[j].sClientId,Row[0],CLIENT_ID_LEN);
			pMarShrtfallResp.subViewMargin[j].fTotalBal = atof(Row[1]);
			pMarShrtfallResp.subViewMargin[j].fBankHodl = atof(Row[2]);
			pMarShrtfallResp.subViewMargin[j].fAdhoc = atof(Row[3]);
			pMarShrtfallResp.subViewMargin[j].fLimit_SOD = atof(Row[4]);
			pMarShrtfallResp.subViewMargin[j].fMTMKT_EQ = atof(Row[5]);
			pMarShrtfallResp.subViewMargin[j].fMTMKT_DR = atof(Row[6]);
			pMarShrtfallResp.subViewMargin[j].fTotalMTM = atof(Row[7]);
			pMarShrtfallResp.subViewMargin[j].fMTM_PER = atof(Row[8]);
			pMarShrtfallResp.subViewMargin[j].fEXPO_EQ = atof(Row[9]);
			pMarShrtfallResp.subViewMargin[j].fEXPO_EQ_GROSS = atof(Row[10]);
			pMarShrtfallResp.subViewMargin[j].fEXPO_DR = atof(Row[11]);
			pMarShrtfallResp.subViewMargin[j].fEXPO_DR_GROSS = atof(Row[12]);
			pMarShrtfallResp.subViewMargin[j].fRealised_Profit = atof(Row[13]);
			pMarShrtfallResp.subViewMargin[j].fSpan = atof(Row[14]);
			pMarShrtfallResp.subViewMargin[j].fRealised_MTM = atof(Row[15]);
			pMarShrtfallResp.subViewMargin[j].fShortfall_VAL = atof(Row[16]);

			logDebug2("pMarShrtfallResp.subViewMargin[j].sClientId = %s",pMarShrtfallResp.subViewMargin[j].sClientId);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fTotalBal = %lf",pMarShrtfallResp.subViewMargin[j].fTotalBal);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fBankHodl = %lf",pMarShrtfallResp.subViewMargin[j].fBankHodl);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fAdhoc = %lf",pMarShrtfallResp.subViewMargin[j].fAdhoc);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fLimit_SOD = %lf",pMarShrtfallResp.subViewMargin[j].fLimit_SOD);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fMTMKT_EQ = %lf",pMarShrtfallResp.subViewMargin[j].fMTMKT_EQ);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fMTMKT_DR = %lf",pMarShrtfallResp.subViewMargin[j].fMTMKT_DR);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fTotalMTM = %lf",pMarShrtfallResp.subViewMargin[j].fTotalMTM);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fMTM_PER = %lf",pMarShrtfallResp.subViewMargin[j].fMTM_PER);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fEXPO_EQ = %lf",pMarShrtfallResp.subViewMargin[j].fEXPO_EQ);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fEXPO_EQ_GROSS = %lf",pMarShrtfallResp.subViewMargin[j].fEXPO_EQ_GROSS);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fEXPO_DR = %lf",pMarShrtfallResp.subViewMargin[j].fEXPO_DR);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fEXPO_DR_GROSS = %lf",pMarShrtfallResp.subViewMargin[j].fEXPO_DR_GROSS);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fRealised_Profit = %lf",pMarShrtfallResp.subViewMargin[j].fRealised_Profit);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fSpan = %lf",pMarShrtfallResp.subViewMargin[j].fSpan);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fRealised_MTM = %lf",pMarShrtfallResp.subViewMargin[j].fRealised_MTM);
			logDebug2("pMarShrtfallResp.subViewMargin[j].fShortfall_VAL = %lf",pMarShrtfallResp.subViewMargin[j].fShortfall_VAL);

		}
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pMarShrtfallResp,sizeof(struct VIEW_MARGIN_MTM_COMMON_QUERY_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logDebug2("Write Q id %d", iSTWRelToQueryQ);
		return FALSE;
	}
}

logTimestamp("Exit : fMarginSrtFall");
}
*/

/*BOOL    fPercentMTM(CHAR *RcvMsg)
{
	logTimestamp("Entry : fPercentMTM");

	struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ        *pPercentMTMReq;

	pPercentMTMReq = (struct VIEW_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;
	BOOL	ChkFlag = FALSE;

	//      CHAR    cUserType;
	CHAR    *sQuery = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	logDebug2("pPercentMTMReq->iPercent = %d",pPercentMTMReq->iPercent);
	logDebug2("pPercentMTMReq->iMode = %d",pPercentMTMReq->iMode);
	logDebug2("pPercentMTMReq->cUserType = %c",pPercentMTMReq->cUserType);

	ChkFlag = fPercentMTM_PR(RcvMsg);

	logDebug2("call fPercentMTMALL");
	fPercentMTM_SA(RcvMsg);

	logTimestamp("Exit : fPercentMTM");
	return TRUE;

}*/

BOOL    fPercentMTM_PR(CHAR *RcvMsg)
{
	logTimestamp("Entry :fPercentMTM_PR");

	struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ *pReq;
	CHAR    sQry[MAX_QUERY_SIZE];
	
	pReq = (struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ *)RcvMsg; 
//	MYSQL_RES    *Res;
//	MYSQL_ROW     Row;

	logDebug2("pReq->iMode = %d",pReq->iMode);
	logDebug2("pReq->iPercent = %d",pReq->iPercent);
	logDebug2("pReq->ReqHeader.cSegment = %c",pReq->ReqHeader.cSegment);

//	CHAR    *sQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	sprintf(sQry,"CALL PR_MTM_WATCH(%d,%d,\'%c\')",pReq->iMode,pReq->iPercent,pReq->ReqHeader.cSegment);

	logDebug2("sQry = %s",sQry);

	if(mysql_query(DBQueries,sQry) != SUCCESS)
	{
		logSqlFatal("ERROR IN CALL PR_MTM_WATCH sQry.");
		sql_Error(DBQueries);
		return  FALSE;
	}

	logTimestamp("Exit : fPercentMTM_PR");
	return TRUE;
}



BOOL    fPercentMTM(CHAR *RcvMsg)
{
	logTimestamp("Entry : fPercentMTM");

	struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ        *pPercentMTMReq;
	struct  VIEW_PERCENT_MTM_COMMON_QUERY_RESP       pPerMTMResp;
	struct  VIEW_COMMON_HDR_RESP                    pPerMTMHdrResp;

	//MYSQL_RES    *Res;
	//MYSQL_ROW     Row;

	CHAR    sPercentQry[DOUBLE_MAX_QUERY_SIZE];
	//CHAR    *sPercentQry = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	CHAR    sWhere_Clause[QUERY_SIZE];
	CHAR    sMTM_Qry[QUERY_SIZE];

	LONG32          i=0,j=0;
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	BOOL 	ChkFlag = FALSE;
	memset(sPercentQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);
	
	pPercentMTMReq= (struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ*)RcvMsg;
	logDebug2("pPercentMTMReq->iMode = %d",pPercentMTMReq->iMode);
	logDebug2("pPercentMTMReq->iPercent = %d",pPercentMTMReq->iPercent);
	logDebug2("pPercentMTMReq->ReqHeader.cSegment = %c",pPercentMTMReq->ReqHeader.cSegment);			
	logDebug2("pPercentMTMReq->sClientId = %s",pPercentMTMReq->sClientId);			

	ChkFlag = fPercentMTM_PR(RcvMsg);

	if(ChkFlag == FALSE)
	{
		logDebug3(" Error in fPercentMTM_PR ");
		return  FALSE;
	}

	  if(strcmp(pPercentMTMReq->sClientId,SELECT_ALL))
	  {
	  	memset(sMTM_Qry,'\0',QUERY_SIZE);
		sprintf(sMTM_Qry," AND CLIENT_ID = \"%s\"",pPercentMTMReq->sClientId);
		logDebug2("sMTM_Qry = %s",sMTM_Qry);
	  	strcat(sWhere_Clause,sMTM_Qry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	  }

	  logDebug2("final sWhere_Clause = %s",sWhere_Clause);

	sprintf(sPercentQry,"SELECT CLIENT_ID,TOTAL_BAL,BANK_HOLDING,ADHOC,LIMIT_SOD,MTMKT_EQ,MTMKT_DR,TOTALMTM,MTMPER,EXPOSURE_EQ,EXPOSURE_EQ_GROSS,\
			EXPOSURE_DR,EXPOSURE_DR_GROSS,REALISED_PROFIT,TREALISEDMTM,MTMKT_CDS,EXPOSURE_CDS,EXPOSURE_CDS_GROSS,\
			RECEIVABLES,OPT_SELL_PREMIUM,COLLATERALS,GROSS_HOLDING_VAL,MTMKT_COM,EXPOSURE_COM,EXPOSURE_COM_GROSS \
			FROM MTM_FETCH_CAP WHERE 1=1 %s;",sWhere_Clause);

	logDebug2("sMarginQry = %s",sPercentQry);
		logDebug3(" Ashish s here 2 fPercentMTM_PR ");

	if(mysql_query(DBQueries,sPercentQry ) != SUCCESS)
	{
		logSqlFatal("ERROR in sPercentQry.");
		sql_Error(DBQueries);
		return FALSE;
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec =iNoOfPkt;
	pPerMTMHdrResp.IntRespHeader.iSeqNo = 0;
	pPerMTMHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pPerMTMHdrResp.IntRespHeader.iErrorId = 0;
	pPerMTMHdrResp.IntRespHeader.iMsgCode = TC_INT_PERCENT_MTM_HEADER_RESP;
	pPerMTMHdrResp.IntRespHeader.iUserId = pPercentMTMReq->ReqHeader.iUserId;
	pPerMTMHdrResp.IntRespHeader.cSource = pPercentMTMReq->ReqHeader.cSource ;
	pPerMTMHdrResp.cMsgType = 'H';
	pPerMTMHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pPerMTMHdrResp.IntRespHeader.iMsgLength = %d",pPerMTMHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pPerMTMHdrResp.IntRespHeader.iMsgCode = %d",pPerMTMHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pPerMTMHdrResp.IntRespHeader.iUserId = %llu",pPerMTMHdrResp.IntRespHeader.iUserId);
	logDebug2("pPerMTMHdrResp.IntRespHeader.cSource = %c",pPerMTMHdrResp.IntRespHeader.cSource);
	logDebug2("pPerMTMHdrResp.iNoofRec = %d",pPerMTMHdrResp.iNoofRec);

	logDebug2("pPercentMTMReq->ReqHeader.iUserId = %llu",pPercentMTMReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pPercentMTMReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	 if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pPerMTMHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;	
	}

	logDebug2("iNoOfPkt :%d:",iNoOfPkt);
	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pPerMTMResp,'\0',sizeof(struct VIEW_PERCENT_MTM_COMMON_QUERY_RESP));
		pPerMTMResp.IntRespHeader.iSeqNo = 0;
		pPerMTMResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_PERCENT_MTM_COMMON_QUERY_RESP);
		pPerMTMResp.IntRespHeader.iMsgCode = TC_INT_PERCENT_MTM_QUERY_RESP;
		pPerMTMResp.IntRespHeader.iErrorId = 0;
		pPerMTMResp.IntRespHeader.iUserId = pPercentMTMReq->ReqHeader.iUserId;
		pPerMTMResp.IntRespHeader.cSource = pPercentMTMReq->ReqHeader.cSource ;
		pPerMTMResp.IntRespHeader.cSegment = pPercentMTMReq->ReqHeader.cSegment;
		logDebug2("pPerMTMResp.IntRespHeader.cSegment = %c",pPerMTMResp.IntRespHeader.cSegment);
		if(iTempNoOfRec <= 1)
		{
			pPerMTMResp.cMsgType = 'T';
		}
		else
		{
			pPerMTMHdrResp.cMsgType = 'D';
		}
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{	
				strncpy( pPerMTMResp.subViewPercent[j].sClientId,Row[0],CLIENT_ID_LEN);
				pPerMTMResp.subViewPercent[j].fTotalBal = atof(Row[1]);
				pPerMTMResp.subViewPercent[j].fBankHodl = atof(Row[2]);
				pPerMTMResp.subViewPercent[j].fAdhoc = atof(Row[3]);
				pPerMTMResp.subViewPercent[j].fLimit_SOD = atof(Row[4]);
				pPerMTMResp.subViewPercent[j].fMTMKT_EQ = atof(Row[5]);
				pPerMTMResp.subViewPercent[j].fMTMKT_DR = atof(Row[6]);
				pPerMTMResp.subViewPercent[j].fTotalMTM = atof(Row[7]);
				pPerMTMResp.subViewPercent[j].fMTM_PER = atof(Row[8]);
				pPerMTMResp.subViewPercent[j].fEXPO_EQ = atof(Row[9]);
				pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS = atof(Row[10]);
				pPerMTMResp.subViewPercent[j].fEXPO_DR = atof(Row[11]);
				pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS = atof(Row[12]);
				pPerMTMResp.subViewPercent[j].fRealised_Profit = atof(Row[13]);
				pPerMTMResp.subViewPercent[j].fRealised_MTM = atof(Row[14]);
				pPerMTMResp.subViewPercent[j].fMTM_cds = atof(Row[15]);	
				pPerMTMResp.subViewPercent[j].fExposure_cds = atof(Row[16]);
				pPerMTMResp.subViewPercent[j].fExposure_cds_gross = atof(Row[17]);
				pPerMTMResp.subViewPercent[j].fReceivables = atof(Row[18]);
				pPerMTMResp.subViewPercent[j].fOpt_sell_prm = atof(Row[19]);
				pPerMTMResp.subViewPercent[j].fCollaterals = atof(Row[20]);		
				pPerMTMResp.subViewPercent[j].fGrossHoldVal = atof(Row[21]);
				pPerMTMResp.subViewPercent[j].fMTMKT_COM = atof(Row[22]);
				pPerMTMResp.subViewPercent[j].fExpo_COMM = atof(Row[23]);
				pPerMTMResp.subViewPercent[j].fExpo_COMM_gross = atof(Row[24]);
	

				logDebug2(" pPerMTMResp.subViewPercent[j].sClientId = %s",pPerMTMResp.subViewPercent[j].sClientId);
				logDebug2(" pPerMTMResp.subViewPercent[j].fTotalBal = %lf",pPerMTMResp.subViewPercent[j].fTotalBal);
				logDebug2(" pPerMTMResp.subViewPercent[j].fBankHodl = %lf",pPerMTMResp.subViewPercent[j].fBankHodl);
				logDebug2(" pPerMTMResp.subViewPercent[j].fAdhoc = %lf",pPerMTMResp.subViewPercent[j].fAdhoc);
				logDebug2(" pPerMTMResp.subViewPercent[j].fLimit_SOD = %lf",pPerMTMResp.subViewPercent[j].fLimit_SOD);
				logDebug2(" pPerMTMResp.subViewPercent[j].fMTMKT_EQ = %lf",pPerMTMResp.subViewPercent[j].fMTMKT_EQ);
				logDebug2(" pPerMTMResp.subViewPercent[j].fMTMKT_DR = %lf",pPerMTMResp.subViewPercent[j].fMTMKT_DR);
				logDebug2(" pPerMTMResp.subViewPercent[j].fTotalMTM = %lf",pPerMTMResp.subViewPercent[j].fTotalMTM);
				logDebug2(" pPerMTMResp.subViewPercent[j].fMTM_PER = %lf",pPerMTMResp.subViewPercent[j].fMTM_PER);
				logDebug2(" pPerMTMResp.subViewPercent[j].fEXPO_EQ = %lf",pPerMTMResp.subViewPercent[j].fEXPO_EQ);
				logDebug2(" pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS = %lf",pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS);
				logDebug2(" pPerMTMResp.subViewPercent[j].fEXPO_DR = %lf",pPerMTMResp.subViewPercent[j].fEXPO_DR);
				logDebug2(" pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS = %lf",pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS);
				logDebug2(" pPerMTMResp.subViewPercent[j].fRealised_Profit = %lf",pPerMTMResp.subViewPercent[j].fRealised_Profit);
				logDebug2(" pPerMTMResp.subViewPercent[j].fRealised_MTM= %lf", pPerMTMResp.subViewPercent[j].fRealised_MTM);
				logDebug2(" pPerMTMResp.subViewPercent[j].fMTM_cds= %lf", pPerMTMResp.subViewPercent[j].fMTM_cds);
				logDebug2(" pPerMTMResp.subViewPercent[j].fExposure_cds= %lf", pPerMTMResp.subViewPercent[j].fExposure_cds);
				logDebug2(" pPerMTMResp.subViewPercent[j].fExposure_cds_gross= %lf", pPerMTMResp.subViewPercent[j].fExposure_cds_gross);
				logDebug2(" pPerMTMResp.subViewPercent[j].fReceivables = %lf", pPerMTMResp.subViewPercent[j].fReceivables);
				logDebug2(" pPerMTMResp.subViewPercent[j].fOpt_sell_prm = %lf", pPerMTMResp.subViewPercent[j].fOpt_sell_prm);
				logDebug2(" pPerMTMResp.subViewPercent[j].fCollaterals = %lf", pPerMTMResp.subViewPercent[j].fCollaterals);
				logDebug2(" pPerMTMResp.subViewPercent[j].fGrossHoldVal = %lf", pPerMTMResp.subViewPercent[j].fGrossHoldVal);
				logDebug2(" pPerMTMResp.subViewPercent[j].fMTMKT_COM = %lf", pPerMTMResp.subViewPercent[j].fMTMKT_COM);
				logDebug2(" pPerMTMResp.subViewPercent[j].fExpo_COMM = %lf", pPerMTMResp.subViewPercent[j].fExpo_COMM);
				logDebug2(" pPerMTMResp.subViewPercent[j].fExpo_COMM_gross = %lf", pPerMTMResp.subViewPercent[j].fExpo_COMM_gross);
			}
		
		}
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)& pPerMTMResp,sizeof(struct VIEW_PERCENT_MTM_COMMON_QUERY_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
	}	

	logTimestamp("Exit : fPercentMTM");
	return TRUE;
}

BOOL    fPercentMTMall(CHAR *RcvMsg)
{
	logTimestamp("Entry : fPercentMTMall");

	struct  VIEW_MARGIN_MTM_COMMON_QUERY_REQ        *pPercentMTMReq;
	struct  VIEW_PERCENT_MTM_COMMON_QUERY_RESP       pPerMTMResp;
	struct  VIEW_COMMON_HDR_RESP                    pMTMHdrResp;

	MYSQL_RES    *Res;
	MYSQL_ROW     Row;

	CHAR    *sPercentQry1 = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	LONG32          i=0,j=0;
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	ChkFlag = FALSE;

	logDebug2("pPercentMTMReq->iMode = %d",pPercentMTMReq->iMode);
	logDebug2("pPercentMTMReq->iPercent = %d",pPercentMTMReq->iPercent);

	ChkFlag = fPercentMTM_PR(RcvMsg);

	if(ChkFlag == FALSE)
	{
		logDebug3(" Error in fPercentMTM_PR");
		return  FALSE;
	}

	sprintf(sPercentQry1,"   SELECT CLIENT_ID,TOTAL_BAL,BANK_HOLDING,ADHOC,LIMIT_SOD,MTMKT_EQ,MTMKT_DR,TOTALMTM,MTMPER,EXPOSURE_EQ,EXPOSURE_EQ_GROSS,\
			EXPOSURE_DR,EXPOSURE_DR_GROSS,REALISED_PROFIT,SPAN,TREALISEDMTM,SHORTFALLVALUE\
			FROM MTM_FETCH_CAP a, ENTITY_MASTER s where a.CLIENT_ID = s.ENTITY_CODE and s.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\"))",\
			pPercentMTMReq->sManager_Code);

	logDebug2("sPercentQry1 = %s",sPercentQry1);

	if(mysql_query(DBQueries,sPercentQry1) != SUCCESS)
	{
		logSqlFatal("ERROR in sPercentQry1.......");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	iNoOfRec= mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;

	pMTMHdrResp.IntRespHeader.iSeqNo = 0;
	pMTMHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pMTMHdrResp.IntRespHeader.iErrorId = 0;
	pMTMHdrResp.IntRespHeader.iMsgCode = TC_INT_PERCENT_MTM_HEADER_RESP;
	pMTMHdrResp.IntRespHeader.iUserId = pPercentMTMReq->ReqHeader.iUserId;
	pMTMHdrResp.IntRespHeader.cSource = pPercentMTMReq->ReqHeader.cSource ;
	pMTMHdrResp.cMsgType = 'H';
	pMTMHdrResp.iNoofRec = iNoOfRec;

	logDebug2("pMTMHdrResp.IntRespHeader.iMsgLength = %d",pMTMHdrResp.IntRespHeader.iMsgLength);
	logDebug2("pMTMHdrResp.IntRespHeader.iMsgCode = %d",pMTMHdrResp.IntRespHeader.iMsgCode);
	logDebug2("pMTMHdrResp.IntRespHeader.iUserId = %llu",pMTMHdrResp.IntRespHeader.iUserId);
	logDebug2("pMTMHdrResp.IntRespHeader.cSource = %c",pMTMHdrResp.IntRespHeader.cSource);
	logDebug2("pMTMHdrResp.iNoofRec = %d",pMTMHdrResp.iNoofRec);

	logDebug2("pPercentMTMReq->ReqHeader.iUserId = %llu",pPercentMTMReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pPercentMTMReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pMTMHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pPerMTMResp.IntRespHeader.iSeqNo = 0;
				pPerMTMResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_PERCENT_MTM_COMMON_QUERY_RESP);
				pPerMTMResp.IntRespHeader.iMsgCode =  TC_INT_PERCENT_MTM_QUERY_RESP;
				pPerMTMResp.IntRespHeader.iErrorId = 0;
				pPerMTMResp.IntRespHeader.iUserId = pPercentMTMReq->ReqHeader.iUserId;
				pPerMTMResp.IntRespHeader.cSource = pPercentMTMReq->ReqHeader.cSource ;

				if(iTempNoOfRec <= 1)
				{
					pPerMTMResp.cMsgType = 'T';
				}
				else
				{
					pPerMTMResp.cMsgType = 'D';
				}

				strncpy(pPerMTMResp.subViewPercent[j].sClientId,Row[0],CLIENT_ID_LEN);
				pPerMTMResp.subViewPercent[j].fTotalBal = atof(Row[1]);
				pPerMTMResp.subViewPercent[j].fBankHodl = atof(Row[2]);
				pPerMTMResp.subViewPercent[j].fAdhoc = atof(Row[3]);
				pPerMTMResp.subViewPercent[j].fLimit_SOD = atof(Row[4]);
				pPerMTMResp.subViewPercent[j].fMTMKT_EQ = atof(Row[5]);
				pPerMTMResp.subViewPercent[j].fMTMKT_DR = atof(Row[6]);
				pPerMTMResp.subViewPercent[j].fTotalMTM = atof(Row[7]);
				pPerMTMResp.subViewPercent[j].fMTM_PER = atof(Row[8]);
				pPerMTMResp.subViewPercent[j].fEXPO_EQ = atof(Row[9]);
				pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS = atof(Row[10]);
				pPerMTMResp.subViewPercent[j].fEXPO_DR = atof(Row[11]);
				pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS = atof(Row[12]);
				pPerMTMResp.subViewPercent[j].fRealised_Profit = atof(Row[13]);
			//	pPerMTMResp.subViewPercent[j].fSpan = atof(Row[14]);
				pPerMTMResp.subViewPercent[j].fRealised_MTM = atof(Row[14]);
			//	pPerMTMResp.subViewPercent[j].fShortfall_VAL = atof(Row[16]);
				logDebug2("pPerMTMResp.cMsgType = %c",pPerMTMResp.cMsgType);
				logDebug2("pPerMTMResp.subViewPercent[j].sClientId = %s",pPerMTMResp.subViewPercent[j].sClientId);
				logDebug2("pPerMTMResp.subViewPercent[j].fTotalBal = %lf",pPerMTMResp.subViewPercent[j].fTotalBal);
				logDebug2("pPerMTMResp.subViewPercent[j].fBankHodl = %lf",pPerMTMResp.subViewPercent[j].fBankHodl);
				logDebug2("pPerMTMResp.subViewPercent[j].fAdhoc = %lf",pPerMTMResp.subViewPercent[j].fAdhoc);
				logDebug2("pPerMTMResp.subViewPercent[j].fLimit_SOD = %lf",pPerMTMResp.subViewPercent[j].fLimit_SOD);
				logDebug2("pPerMTMResp.subViewPercent[j].fMTMKT_EQ = %lf",pPerMTMResp.subViewPercent[j].fMTMKT_EQ);
				logDebug2("pPerMTMResp.subViewPercent[j].fMTMKT_DR = %lf",pPerMTMResp.subViewPercent[j].fMTMKT_DR);
				logDebug2("pPerMTMResp.subViewPercent[j].fTotalMTM = %lf",pPerMTMResp.subViewPercent[j].fTotalMTM);
				logDebug2("pPerMTMResp.subViewPercent[j].fMTM_PER = %lf",pPerMTMResp.subViewPercent[j].fMTM_PER);
				logDebug2("pPerMTMResp.subViewPercent[j].fEXPO_EQ = %lf",pPerMTMResp.subViewPercent[j].fEXPO_EQ);
				logDebug2("pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS = %lf",pPerMTMResp.subViewPercent[j].fEXPO_EQ_GROSS);
				logDebug2("pPerMTMResp.subViewPercent[j].fEXPO_DR = %lf",pPerMTMResp.subViewPercent[j].fEXPO_DR);
				logDebug2("pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS = %lf",pPerMTMResp.subViewPercent[j].fEXPO_DR_GROSS);
				logDebug2("pPerMTMResp.subViewPercent[j].fRealised_Profit = %lf",pPerMTMResp.subViewPercent[j].fRealised_Profit);
			//	logDebug2("pPerMTMResp.subViewPercent[j].fSpan = %lf",pPerMTMResp.subViewPercent[j].fSpan);
				logDebug2("pPerMTMResp.subViewPercent[j].fRealised_MTM = %lf",pPerMTMResp.subViewPercent[j].fRealised_MTM);
			//	logDebug2("pPerMTMResp.subViewPercent[j].fShortfall_VAL = %lf",pPerMTMResp.subViewPercent[j].fShortfall_VAL);

			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pPerMTMResp,sizeof(struct VIEW_PERCENT_MTM_COMMON_QUERY_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logDebug2("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
	}

	logTimestamp("Exit : fPercentMTMall");
}
BOOL fGetBoOrderBook(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fGetBoOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_ORDER_BOOK_RESP     pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	CHAR         sEntityId[ENTITY_ID_LEN];
	CHAR         sClientId[CLIENT_ID_LEN];
	CHAR            sUserType[3];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR    *sGetOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
	BOOL	iMrgType = FALSE;	

	memset(sEntityId ,'\0',ENTITY_ID_LEN);
	memset(sUserType ,'\0',3);

	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);

	logDebug2("client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);
	sprintf(sGetOrdBook,"SELECT  ENTITY_TYPE,ENTITY_MANAGER_TYPE from  ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));  ",sEntityId);

	logDebug2("Query[%s]",sGetOrdBook);

	/*** SELECT  em_entity_type
INTO :sUserType
from  entity_master em
WHERE em.em_entity_id = ltrim(rtrim(:sEntityId));
	 ******/

	if(mysql_query(DBQueries,sGetOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR IN fGetBoOrderBook QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
		}
	}

	logDebug2("USER TYPE is :%s:",sUserType );

	/**/     if(!strcmp(sUserType ,"D") && !strcmp(sClientId ,"-1"))
	{
		logDebug2("Going to call fDealerALLOrderBook");
		fDealerBoOrderBook(RcvMsg,iMrgType);
		return TRUE;

	}
	/**/
	if(!strcmp(sUserType ,"D" ) && strcmp(sClientId ,"-1"))
	{
		logDebug2("---- Going to call fOrderBook");
		fBoOrderBook(RcvMsg);
		return TRUE;

	}
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("Going to call fClientOrderBook-----");
		fBoOrderBook(RcvMsg);
		return TRUE;

	}

	logTimestamp("EXIT [fGetBoOrderBook]");
	return TRUE;

}/*** End of fGetBoOrderBook*****/


BOOL    fBoOrderBook(CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fBoOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_BO_ORDER_BOOK_RESP	pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	//      CHAR    sWhere_Clause[QUERY_SIZE];
	//        memset(sWhere_Clause,'\0',QUERY_SIZE);

	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR            sProduct[10];
	CHAR            sValidity[5];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sRespClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];
	CHAR            ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32          iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;

	LONG32          iOrderBookTime;


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);
	logDebug2("  client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);

	//      fOrderBookQuery(sClientId,sWhere_Clause,&Result);
	/***
	  sprintf(sOrdBook,"SELECT\ 
	  A.EQ_CLIENT_ID AS CLIENT_ID,\
	  A.EQ_INTERNAL_ENTRY_DATE AS ORDER_DATE_TIME,\
	  A.EQ_ORDER_NO AS ORDER_NUMBER,\
	  A.EQ_EXCH_ID AS EXCH,\
	  (CASE A.EQ_BUY_SELL_IND\
	  WHEN 'B' THEN 'Buy'\
	  WHEN 'S' THEN 'Sell'\
	  END) AS BUY_SELL,\
	  'E' AS SEGMENT,\
	  A.EQ_INSTRUMENT_NAME AS INSTRUMENT,\
	  A.EQ_SYMBOL AS SYMBOL,\
	  (CASE A.EQ_PRODUCT_ID\
	  WHEN 'B' THEN 'BO'\
	  WHEN 'V' THEN 'CO'\
	  WHEN 'C' THEN 'CNC'\
	  WHEN 'M' THEN 'MARGIN'\
	  WHEN 'L' THEN 'MLB'\
	  WHEN 'S' THEN 'COLLATERAL'\
	  WHEN 'I' THEN 'INTRADAY'\
	  ELSE A.EQ_PRODUCT_ID\
	  END) AS PRODUCT,\
	  GROUP_CONCAT(CASE  A.EQ_LEG_NO \
	  WHEN 1 THEN (CASE\
	  WHEN\
	  ((A.EQ_MSG_CODE = '2073')\
	  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
	  THEN\
	  'Part-Traded'\
	  WHEN\
	  ((A.EQ_MSG_CODE = '2074')\
	  AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
	  THEN\
	  'Part-Traded'\
	  WHEN\
	  ((A.EQ_MSG_CODE = '2212')\
	  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
	  THEN\
	  'Part-Traded'\
	  WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
	  WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
	  WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
	  WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
	  WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
	  WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
	  WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
	  WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
	  WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
	  WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
	  WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
	  WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
	  WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
	  WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
	  END) END )AS ORD_STATUS_MAIN,\
	  sum(CASE  A.EQ_LEG_NO WHEN 1 THEN A.EQ_TOTAL_QTY end )AS QUANTITY,\
	  sum(CASE  A.EQ_LEG_NO WHEN 1 THEN A.EQ_REM_QTY end )AS REMAINING_QUANTITY,\
	  sum(CASE  A.EQ_LEG_NO WHEN 1 THEN \
	  (CASE A.EQ_ORDER_TYPE\
	  WHEN '1' THEN 'MKT'\
	  WHEN '3' THEN 'MKT'\
	  ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
	  END) end )AS PRICE,\
	CASE  A.EQ_LEG_NO WHEN 1 THEN \
		(CASE A.EQ_ORDER_TYPE\
		 WHEN '1' THEN 'MARKET'\
		 WHEN '2' THEN 'LIMIT'\
		 WHEN '3' THEN 'SL-M'\
		 WHEN '4' THEN 'SL'\
		 END) end AS ORDER_TYPE,\
		GROUP_CONCAT( case  A.EQ_LEG_NO \
				WHEN 2 THEN A.EQ_MSG_CODE END  )as SL_CODE ,\
		GROUP_CONCAT( case  A.EQ_LEG_NO\ 
				WHEN 2 THEN (CASE\
					WHEN\
					((A.EQ_MSG_CODE = '2073')\
					 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
					THEN\
					'Part-Traded'\
					WHEN\
					((A.EQ_MSG_CODE = '2074')\
					 AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
					THEN\
					'Part-Traded'\
					WHEN\
					((A.EQ_MSG_CODE = '2212')\
					 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
					THEN\
					'Part-Traded'\
					WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
					WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
					WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
					WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
					WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
					WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
					WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
					WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
					WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
					WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
					WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
					WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
					WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
					WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
					WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
					WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
					WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
					WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
					END) END) AS ORD_STATUS_SL,\
					sum(CASE  A.EQ_LEG_NO WHEN 2 THEN A.EQ_TOTAL_QTY end )AS QUANTITY_SL,\
					sum(CASE  A.EQ_LEG_NO WHEN 2 THEN A.EQ_REM_QTY end )AS REMAINING_QUANTITY_SL,\
					sum(CASE  A.EQ_LEG_NO WHEN 2 THEN \
							IFNULL(A.EQ_TRIGGER_PRICE, 0)\
							END) AS PRICE_SL,\
					GROUP_CONCAT( case  A.EQ_LEG_NO \
							WHEN 3 THEN A.EQ_MSG_CODE END  )as PROF_CODE ,\
					GROUP_CONCAT(CASE  A.EQ_LEG_NO \
							WHEN 3 THEN (CASE\
								WHEN\
								((A.EQ_MSG_CODE = '2073')\
								 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
								THEN\
								'Part-Traded'\
								WHEN\
								((A.EQ_MSG_CODE = '2074')\
								 AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
								THEN\
								'Part-Traded'\
								WHEN\
								((A.EQ_MSG_CODE = '2212')\
								 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
								THEN\
								'Part-Traded'\
								WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
								WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
								WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
								WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
								WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
								WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
								WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
								WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
								WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
								WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
								WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
								WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
								WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
								WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
								WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
								WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
								WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
								END) END )AS ORD_STATUS_PROFIT,\
								A.EQ_MSG_CODE as PROF_MSG_CODE,\
								sum( CASE  A.EQ_LEG_NO WHEN 3 THEN A.EQ_TOTAL_QTY end )AS QUANTITY_PROFIT,\
								sum(CASE  A.EQ_LEG_NO WHEN 3 THEN A.EQ_REM_QTY end )AS REMAINING_QUANTITY_PROFIT,\
								sum(CASE  A.EQ_LEG_NO WHEN 3 THEN (CASE A.EQ_ORDER_TYPE\
											WHEN '1' THEN 'MKT'\
											WHEN '3' THEN 'MKT'\
											ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
											END) end )AS PRICE_PROFIT,\
								A.EQ_DISC_QTY AS DISCLOSE_QTY,\
								A.EQ_SERIAL_NO AS SERIALNO,\
								A.EQ_ACC_CODE AS ACCCOUNTCODE,\
								A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,\
								A.EQ_SCRIP_CODE AS SEM_SECURITY_ID,\
								A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,\
								A.EQ_STRATEGY_ID AS STRATEGY_ID,\
								A.EQ_REASON_DESCRIPTION AS REASON_DESCRIPTION,\
								A.EQ_PRO_CLIENT AS PRO_CLIENT,\
								A.EQ_GOOD_TILL_DATE AS GOOD_TILL_DATE,\
								A.EQ_ERROR_CODE AS ERROR_CODE,\
								(CASE A.EQ_VALIDITY\
								 WHEN '0' THEN 'DAY'\
								 WHEN '1' THEN 'GTC'\
								 WHEN '2' THEN 'ATO'\
								 WHEN '3' THEN 'IOC'\
								 ELSE 'EOS'\
								 END) AS ORDER_VALIDITY,\
								A.EQ_LOT_SIZE AS SEM_NSE_REGULAR_LOT,\
								0 AS TAKE_PROFIT_TRAIL_GAP,\
								0 AS ADV_GROUP_REF_NO,\
								'NA' AS OPTION_TYPE,\
								0 AS STRIKE_PRICE,\
								'NA' AS EXPIRY_DATE,\
								A.EQ_DISC_REM_QTY AS DQQTYREM,\
								A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,\
								A.EQ_MSG_CODE AS TRANSCODE,\
								A.EQ_ORDER_PRICE AS ORDER_PRICE,\
								A.EQ_ENTITY_ID AS PLACEDBY,\
								A.EQ_LEG_NO AS LEGVALUE,\
								julidate(A.EQ_INTERNAL_ENTRY_DATE) as JDATE,\
								A.EQ_MKT_TYPE AS MKT_TYPE\
								FROM\
								EQ_ORDERS A\
								WHERE A.EQ_PRODUCT_ID='B' and A.EQ_ALGO_ORDER_NO=-1 AND A.EQ_CLIENT_ID = \'%s\' \
								AND \
								((A.EQ_SERIAL_NO = (SELECT \
										    MAX(C.EQ_SERIAL_NO)\
										    FROM\
										    EQ_ORDERS C\
										    WHERE\
										    ((C.EQ_ORDER_NO = A.EQ_ORDER_NO)\
										     AND (A.EQ_LEG_NO = C.EQ_LEG_NO))))) \
								GROUP BY A.EQ_ORDER_NO;\
								",sClientId);	
								****/
								sprintf(sOrdBook,"SELECT * FROM (SELECT \
								A.EQ_CLIENT_ID AS CLIENT_ID,\
										A.EQ_INTERNAL_ENTRY_DATE AS ORDER_DATE_TIME,\
										A.EQ_ORDER_NO AS ORDER_NUMBER,\
										A.EQ_EXCH_ID AS EXCH,\
										(CASE A.EQ_BUY_SELL_IND\
										 WHEN 'B' THEN 'Buy'\
										 WHEN 'S' THEN 'Sell'\
										 END) AS BUY_SELL,\
										'E' AS SEGMENT,\
										A.EQ_INSTRUMENT_NAME AS INSTRUMENT,\
										A.EQ_SYMBOL AS SYMBOL,\
										(CASE A.EQ_PRODUCT_ID\
										 WHEN 'B' THEN 'BO'\
										 WHEN 'V' THEN 'CO'\
										 WHEN 'C' THEN 'CNC'\
										 WHEN 'M' THEN 'MARGIN'\
										 WHEN 'L' THEN 'MLB'\
										 WHEN 'S' THEN 'COLLATERAL'\
										 WHEN 'I' THEN 'INTRADAY'\
										 ELSE A.EQ_PRODUCT_ID\
										 END) AS PRODUCT,\
										GROUP_CONCAT(CASE A.EQ_LEG_NO\
												WHEN\
												1\
												THEN\
												(CASE\
												 WHEN\
												 ((A.EQ_MSG_CODE = '2073')\
												  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
												 THEN\
												 'Part-Traded'\
												 WHEN\
												 ((A.EQ_MSG_CODE = '2074')\
												  AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
												 THEN\
												 'Part-Traded'\
												 WHEN\
												 ((A.EQ_MSG_CODE = '2212')\
												  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
												 THEN\
												 'Part-Traded'\
												 WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
												 WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
												 WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
												 WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
												 WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
												 WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
												 WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
												 WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
												 WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
												 WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
												 WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
												 WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
												 WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
												 WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
												 WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
												 END)\
												 END) AS ORD_STATUS_MAIN,\
												 SUM(CASE A.EQ_LEG_NO\
														 WHEN 1 THEN A.EQ_TOTAL_QTY\
														 END) AS QUANTITY,\
												 SUM(CASE A.EQ_LEG_NO\
														 WHEN 1 THEN A.EQ_REM_QTY\
														 END) AS REMAINING_QUANTITY,\
												 SUM(CASE A.EQ_LEG_NO\
														 WHEN\
														 1\
														 THEN\
														 (CASE A.EQ_ORDER_TYPE\
														  WHEN '1' THEN 'MKT'\
														  WHEN '3' THEN 'MKT'\
														  ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
														  END)\
														 END) AS PRICE,\
												 GROUP_CONCAT(CASE A.EQ_LEG_NO\
														 WHEN\
														 1\
														 THEN\
														 (CASE A.EQ_ORDER_TYPE\
														  WHEN '1' THEN 'MARKET'\
														  WHEN '2' THEN 'LIMIT'\
														  WHEN '3' THEN 'SL-M'\
														  WHEN '4' THEN 'SL'\
														  END)\
														 END) AS ORDER_TYPE,\
												 GROUP_CONCAT(CASE A.EQ_LEG_NO\
														 WHEN 2 THEN A.EQ_MSG_CODE\
														 END) AS SL_CODE,\
												 GROUP_CONCAT(CASE A.EQ_LEG_NO\
														 WHEN\
														 2\
														 THEN\
														 (CASE\
														  WHEN\
														  ((A.EQ_MSG_CODE = '2073')\
														   AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
														  THEN\
														  'Part-Traded'\
														  WHEN\
														  ((A.EQ_MSG_CODE = '2074')\
														   AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
														  THEN\
														  'Part-Traded'\
														  WHEN\
														  ((A.EQ_MSG_CODE = '2212')\
														   AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
														  THEN\
														  'Part-Traded'\
														  WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
														  WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
														  WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
														  WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
														  WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
														  WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
														  WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
														  WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
														  WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
														  WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
														  WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
														  WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
														  WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
														  WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
														  WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
														  WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
														  WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
														  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
														  WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
														  END)\
														  END) AS ORD_STATUS_SL,\
														  SUM(CASE A.EQ_LEG_NO\
																  WHEN 2 THEN A.EQ_TOTAL_QTY\
																  END) AS QUANTITY_SL,\
														  SUM(CASE A.EQ_LEG_NO\
																  WHEN 2 THEN A.EQ_REM_QTY\
																  END) AS REMAINING_QUANTITY_SL,\
														  SUM(CASE A.EQ_LEG_NO\
																  WHEN 2 THEN IFNULL(A.EQ_TRIGGER_PRICE, 0)\
																  END) AS PRICE_SL,\
														  GROUP_CONCAT(CASE A.EQ_LEG_NO\
																  WHEN 3 THEN A.EQ_MSG_CODE\
																  END) AS PROF_CODE,\
														  GROUP_CONCAT(CASE A.EQ_LEG_NO\
																  WHEN\
																  3\
																  THEN\
																  (CASE\
																   WHEN\
																   ((A.EQ_MSG_CODE = '2073')\
																    AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
																   THEN\
																   'Part-Traded'\
																   WHEN\
																   ((A.EQ_MSG_CODE = '2074')\
																    AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
																   THEN\
																   'Part-Traded'\
																   WHEN\
																   ((A.EQ_MSG_CODE = '2212')\
																    AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
																   THEN\
																   'Part-Traded'\
																   WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
																   WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
																   WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
																   WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
																   WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
																   WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
																   WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
																   WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
																   WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
																   WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
																   WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
																   WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
																   WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
																   WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
																   WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
																   WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
																   WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
																   WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
																   END)\
																   END) AS ORD_STATUS_PROFIT,\
																   A.EQ_MSG_CODE AS PROF_MSG_CODE,\
																   SUM(CASE A.EQ_LEG_NO\
																		   WHEN 3 THEN A.EQ_TOTAL_QTY\
																		   END) AS QUANTITY_PROFIT,\
																   SUM(CASE A.EQ_LEG_NO\
																		   WHEN 3 THEN A.EQ_REM_QTY\
																		   END) AS REMAINING_QUANTITY_PROFIT,\
																   SUM(CASE A.EQ_LEG_NO\
																		   WHEN\
																		   3\
																		   THEN\
																		   (CASE A.EQ_ORDER_TYPE\
																		    WHEN '1' THEN 'MKT'\
																		    WHEN '3' THEN 'MKT'\
																		    ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
																		    END)\
																		   END) AS PRICE_PROFIT,\
																   A.EQ_DISC_QTY AS DISCLOSE_QTY,\
																   A.EQ_SERIAL_NO AS SERIALNO,\
																   A.EQ_ACC_CODE AS ACCCOUNTCODE,\
																   A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,\
																   A.EQ_SCRIP_CODE AS SEM_SECURITY_ID,\
																   A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,\
																   A.EQ_STRATEGY_ID AS STRATEGY_ID,\
																   A.EQ_REASON_DESCRIPTION AS REASON_DESCRIPTION,\
																   A.EQ_PRO_CLIENT AS PRO_CLIENT,\
																   A.EQ_GOOD_TILL_DATE AS GOOD_TILL_DATE,\
																   A.EQ_ERROR_CODE AS ERROR_CODE,\
																   (CASE A.EQ_VALIDITY\
																    WHEN '0' THEN 'DAY'\
																    WHEN '1' THEN 'GTC'\
																    WHEN '2' THEN 'ATO'\
																    WHEN '3' THEN 'IOC'\
																    ELSE 'EOS'\
																    END) AS ORDER_VALIDITY,\
																   A.EQ_LOT_SIZE AS SEM_NSE_REGULAR_LOT,\
																   0 AS TAKE_PROFIT_TRAIL_GAP,\
																   0 AS ADV_GROUP_REF_NO,\
																   'NA' AS OPTION_TYPE,\
																   0 AS STRIKE_PRICE,\
																   'NA' AS EXPIRY_DATE,\
																   A.EQ_DISC_REM_QTY AS DQQTYREM,\
																   A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,\
																   A.EQ_MSG_CODE AS TRANSCODE,\
																   A.EQ_ORDER_PRICE AS ORDER_PRICE,\
																   A.EQ_ENTITY_ID AS PLACEDBY,\
																   A.EQ_LEG_NO AS LEGVALUE,\
																   JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,\
																   A.EQ_MKT_TYPE AS MKT_TYPE\
																   FROM\
																   EQ_ORDERS A\
																   WHERE\
																   A.EQ_PRODUCT_ID = 'B'\
																   AND A.EQ_ALGO_ORDER_NO = - 1\
																   AND ((A.EQ_SERIAL_NO = (SELECT \
																				   MAX(C.EQ_SERIAL_NO)\
																				   FROM\
																				   EQ_ORDERS C\
																				   WHERE\
																				   ((C.EQ_ORDER_NO = A.EQ_ORDER_NO)\
																				    AND (A.EQ_LEG_NO = C.EQ_LEG_NO)))))\
																   GROUP BY A.EQ_ORDER_NO \
																   union all SELECT \
																   A.DRV_CLIENT_ID AS CLIENT_ID,\
																   A.DRV_INTERNAL_ENTRY_DATE AS ORDER_DATE_TIME,\
																   A.DRV_ORDER_NO AS ORDER_NUMBER,\
																   A.DRV_EXCH_ID AS EXCH,\
																   (CASE A.DRV_BUY_SELL_IND\
																    WHEN 'B' THEN 'Buy'\
																    WHEN 'S' THEN 'Sell'\
																    END) AS BUY_SELL,\
																   A.DRV_SEGMENT AS SEGMENT,\
																   A.DRV_INSTRUMENT_NAME AS INSTRUMENT,\
																   A.DRV_SYMBOL AS SYMBOL,\
																   (CASE A.DRV_PRODUCT_ID\
																    WHEN 'B' THEN 'BO'\
																    WHEN 'V' THEN 'CO'\
																    WHEN 'C' THEN 'CNC'\
																    WHEN 'M' THEN 'MARGIN'\
																    WHEN 'L' THEN 'MLB'\
																    WHEN 'S' THEN 'COLLATERAL'\
																    WHEN 'I' THEN 'INTRADAY'\
																    ELSE A.DRV_PRODUCT_ID\
																    END) AS PRODUCT,\
																   GROUP_CONCAT(CASE A.DRV_LEG_NO\
																		   WHEN\
																		   1\
																		   THEN\
																		   (CASE\
																		    WHEN\
																		    ((A.DRV_MSG_CODE = '2073')\
																		     AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																		    THEN\
																		    'Part-Traded'\
																		    WHEN\
																		    ((A.DRV_MSG_CODE = '2074')\
																		     AND (A.DRV_REM_QTY > A.DRV_TOTAL_QTY))\
																		    THEN\
																		    'Part-Traded'\
																		    WHEN\
																		    ((A.DRV_MSG_CODE = '2212')\
																		     AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																		    THEN\
																		    'Part-Traded'\
																		    WHEN (A.DRV_MSG_CODE = '2073') THEN 'Pending'\
																		    WHEN (A.DRV_MSG_CODE = '2000') THEN 'Transit'\
																		    WHEN (A.DRV_MSG_CODE = '2040') THEN 'Transit'\
																		    WHEN (A.DRV_MSG_CODE = '2070') THEN 'Transit'\
																		    WHEN (A.DRV_MSG_CODE = '2231') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '2042') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '2170') THEN 'Frozen'\
																		    WHEN (A.DRV_MSG_CODE = '2074') THEN 'Modified'\
																		    WHEN (A.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
																		    WHEN (A.DRV_MSG_CODE = '2222') THEN 'Traded'\
																		    WHEN (A.DRV_MSG_CODE = '9002') THEN 'Expired'\
																		    WHEN (A.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
																		    WHEN (A.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
																		    WHEN (A.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
																		    WHEN (A.DRV_MSG_CODE = '2212') THEN 'Triggered'\
																		    WHEN (A.DRV_MSG_CODE = '1111') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '1113') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '1115') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '4444') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '4445') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
																		    WHEN (A.DRV_MSG_CODE = '4450') THEN 'Rejected'\
																		    END)\
																		    END) AS ORD_STATUS_MAIN,\
																		    SUM(CASE A.DRV_LEG_NO\
																				    WHEN 1 THEN A.DRV_TOTAL_QTY\
																				    END) AS QUANTITY,\
																		    SUM(CASE A.DRV_LEG_NO\
																				    WHEN 1 THEN A.DRV_REM_QTY\
																				    END) AS REMAINING_QUANTITY,\
																		    SUM(CASE A.DRV_LEG_NO\
																				    WHEN\
																				    1\
																				    THEN\
																				    (CASE A.DRV_ORDER_TYPE\
																				     WHEN '1' THEN 'MKT'\
																				     WHEN '3' THEN 'MKT'\
																				     ELSE IFNULL(A.DRV_ORDER_PRICE, 0)\
																				     END)\
																				    END) AS PRICE,\
																		    GROUP_CONCAT(CASE A.DRV_LEG_NO\
																				    WHEN\
																				    1\
																				    THEN\
																				    (CASE A.DRV_ORDER_TYPE\
																				     WHEN '1' THEN 'MARKET'\
																				     WHEN '2' THEN 'LIMIT'\
																				     WHEN '3' THEN 'SL-M'\
																				     WHEN '4' THEN 'SL'\
																				     END)\
																				    END) AS ORDER_TYPE,\
																		    GROUP_CONCAT(CASE A.DRV_LEG_NO\
																				    WHEN 2 THEN A.DRV_MSG_CODE\
																				    END) AS SL_CODE,\
																		    GROUP_CONCAT(CASE A.DRV_LEG_NO\
																				    WHEN\
																				    2\
																				    THEN\
																				    (CASE\
																				     WHEN\
																				     ((A.DRV_MSG_CODE = '2073')\
																				      AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																				     THEN\
																				     'Part-Traded'\
																				     WHEN\
																				     ((A.DRV_MSG_CODE = '2074')\
																				      AND (A.DRV_REM_QTY > A.DRV_TOTAL_QTY))\
																				     THEN\
																				     'Part-Traded'\
																				     WHEN\
																				     ((A.DRV_MSG_CODE = '2212')\
																				      AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																				     THEN\
																				     'Part-Traded'\
																				     WHEN (A.DRV_MSG_CODE = '2073') THEN 'Pending'\
																				     WHEN (A.DRV_MSG_CODE = '2000') THEN 'Transit'\
																				     WHEN (A.DRV_MSG_CODE = '2040') THEN 'Transit'\
																				     WHEN (A.DRV_MSG_CODE = '2070') THEN 'Transit'\
																				     WHEN (A.DRV_MSG_CODE = '2231') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '2042') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '2170') THEN 'Frozen'\
																				     WHEN (A.DRV_MSG_CODE = '2074') THEN 'Modified'\
																				     WHEN (A.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
																				     WHEN (A.DRV_MSG_CODE = '2222') THEN 'Traded'\
																				     WHEN (A.DRV_MSG_CODE = '9002') THEN 'Expired'\
																				     WHEN (A.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
																				     WHEN (A.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
																				     WHEN (A.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
																				     WHEN (A.DRV_MSG_CODE = '2212') THEN 'Triggered'\
																				     WHEN (A.DRV_MSG_CODE = '1111') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '1113') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '1115') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '4444') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '4445') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '8107') THEN 'Open'\
																				     WHEN (A.DRV_MSG_CODE = '8108') THEN 'Pending'\
																				     WHEN (A.DRV_MSG_CODE = '8109') THEN 'Traded'\
																				     WHEN (A.DRV_MSG_CODE = '8110') THEN 'Exited'\
																				     WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
																				     WHEN (A.DRV_MSG_CODE = '4450') THEN 'Rejected'\
																				     END)\
																				     END) AS ORD_STATUS_SL,\
																				     SUM(CASE A.DRV_LEG_NO\
																						     WHEN 2 THEN A.DRV_TOTAL_QTY\
																						     END) AS QUANTITY_SL,\
																				     SUM(CASE A.DRV_LEG_NO\
																						     WHEN 2 THEN A.DRV_REM_QTY\
																						     END) AS REMAINING_QUANTITY_SL,\
																				     SUM(CASE A.DRV_LEG_NO\
																						     WHEN 2 THEN IFNULL(A.DRV_TRIGGER_PRICE, 0)\
																						     END) AS PRICE_SL,\
																				     GROUP_CONCAT(CASE A.DRV_LEG_NO\
																						     WHEN 3 THEN A.DRV_MSG_CODE\
																						     END) AS PROF_CODE,\
																				     GROUP_CONCAT(CASE A.DRV_LEG_NO\
																						     WHEN\
																						     3\
																						     THEN\
																						     (CASE\
																						      WHEN\
																						      ((A.DRV_MSG_CODE = '2073')\
																						       AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																						      THEN\
																						      'Part-Traded'\
																						      WHEN\
																						      ((A.DRV_MSG_CODE = '2074')\
																						       AND (A.DRV_REM_QTY > A.DRV_TOTAL_QTY))\
																						      THEN\
																						      'Part-Traded'\
																						      WHEN\
																						      ((A.DRV_MSG_CODE = '2212')\
																						       AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																						      THEN\
																						      'Part-Traded'\
																						      WHEN (A.DRV_MSG_CODE = '2073') THEN 'Pending'\
																						      WHEN (A.DRV_MSG_CODE = '2000') THEN 'Transit'\
																						      WHEN (A.DRV_MSG_CODE = '2040') THEN 'Transit'\
																						      WHEN (A.DRV_MSG_CODE = '2070') THEN 'Transit'\
																						      WHEN (A.DRV_MSG_CODE = '2231') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '2042') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '2170') THEN 'Frozen'\
																						      WHEN (A.DRV_MSG_CODE = '2074') THEN 'Modified'\
																						      WHEN (A.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
																						      WHEN (A.DRV_MSG_CODE = '2222') THEN 'Traded'\
																						      WHEN (A.DRV_MSG_CODE = '9002') THEN 'Expired'\
																						      WHEN (A.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
																						      WHEN (A.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
																						      WHEN (A.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
																						      WHEN (A.DRV_MSG_CODE = '2212') THEN 'Triggered'\
																						      WHEN (A.DRV_MSG_CODE = '1111') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '1113') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '1115') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '4444') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '4445') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '4450') THEN 'Rejected'\
																						      WHEN (A.DRV_MSG_CODE = '8107') THEN 'Open'\
																						      WHEN (A.DRV_MSG_CODE = '8108') THEN 'Pending'\
																						      WHEN (A.DRV_MSG_CODE = '8109') THEN 'Traded'\
																						      WHEN (A.DRV_MSG_CODE = '8110') THEN 'Exited'\
																						      END)\
																						      END) AS ORD_STATUS_PROFIT,\
																						      A.DRV_MSG_CODE AS PROF_MSG_CODE,\
																						      SUM(CASE A.DRV_LEG_NO\
																								      WHEN 3 THEN A.DRV_TOTAL_QTY\
																								      END) AS QUANTITY_PROFIT,\
																						      SUM(CASE A.DRV_LEG_NO\
																								      WHEN 3 THEN A.DRV_REM_QTY\
																								      END) AS REMAINING_QUANTITY_PROFIT,\
																						      SUM(CASE A.DRV_LEG_NO\
																								      WHEN\
																								      3\
																								      THEN\
																								      (CASE A.DRV_ORDER_TYPE\
																								       WHEN '1' THEN 'MKT'\
																								       WHEN '3' THEN 'MKT'\
																								       ELSE IFNULL(A.DRV_ORDER_PRICE, 0)\
																								       END)\
																								      END) AS PRICE_PROFIT,\
																						      A.DRV_DISC_QTY AS DISCLOSE_QTY,\
																						      A.DRV_SERIAL_NO AS SERIALNO,\
																						      A.DRV_ACC_CODE AS ACCCOUNTCODE,\
																						      A.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,\
																						      A.DRV_SCRIP_CODE AS SEM_SECURITY_ID,\
																						      A.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,\
																						      A.DRV_STRATEGY_ID AS STRATEGY_ID,\
																						      A.DRV_REASON_DESCRIPTION AS REASON_DESCRIPTION,\
																						      A.DRV_PRO_CLIENT AS PRO_CLIENT,\
																						      A.DRV_GOOD_TILL_DATE AS GOOD_TILL_DATE,\
																						      A.DRV_ERROR_CODE AS ERROR_CODE,\
																						      (CASE A.DRV_VALIDITY\
																						       WHEN '0' THEN 'DAY'\
																						       WHEN '1' THEN 'GTC'\
																						       WHEN '2' THEN 'ATO'\
																						       WHEN '3' THEN 'IOC'\
																						       ELSE 'EOS'\
																						       END) AS ORDER_VALIDITY,\
																						      A.DRV_LOT_SIZE AS SEM_NSE_REGULAR_LOT,\
																						      0 AS TAKE_PROFIT_TRAIL_GAP,\
																						      0 AS ADV_GROUP_REF_NO,\
																						      'NA' AS OPTION_TYPE,\
																						      0 AS STRIKE_PRICE,\
																						      'NA' AS EXPIRY_DATE,\
																						      A.DRV_DISC_REM_QTY AS DQQTYREM,\
																						      A.DRV_EXCH_ORDER_NO AS EXCHORDERNO,\
																						      A.DRV_MSG_CODE AS TRANSCODE,\
																						      A.DRV_ORDER_PRICE AS ORDER_PRICE,\
																						      A.DRV_ENTITY_ID AS PLACEDBY,\
																						      A.DRV_LEG_NO AS LEGVALUE,\
																						      JULIDATE(A.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
																						      A.DRV_MKT_TYPE AS MKT_TYPE\
																						      FROM\
																						      DRV_ORDERS A\
																						      WHERE\
																						      A.DRV_PRODUCT_ID = 'B'\
																						      AND A.DRV_OMS_ALGO_ORD_NO = - 1\
																						      AND ((A.DRV_SERIAL_NO = (SELECT \
																										      MAX(C.DRV_SERIAL_NO)\
																										      FROM\
																										      DRV_ORDERS C\
																										      WHERE\
																										      ((C.DRV_ORDER_NO = A.DRV_ORDER_NO)\
																										       AND (A.DRV_LEG_NO = C.DRV_LEG_NO)))))\
																						      GROUP BY A.DRV_ORDER_NO) BO_ORDERBOOK WHERE CLIENT_ID = \"%s\";",sClientId);

	printf(" fBoOrderBook :%s:",sOrdBook);

	if(mysql_query(DBQueries,sOrdBook ) != SUCCESS)
	{
		logSqlFatal("ERROR in Order BOOK Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_HDR_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug1(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);

	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BO_ORDER_BOOK_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = 0;
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
				//                      logDebug2("pOrderBookResp.IntRespHeader.cSource :%c:",pOrderBookResp.IntRespHeader.cSource);
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				strncpy(pOrderBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sDatetime,Row[1],DATE_LENGTH);
				pOrderBookResp.suborderbook[j].fOrderNo =atof(Row[2]);
				strncpy(pOrderBookResp.suborderbook[j].sExcgId,Row[3],EXCHANGE_LEN);
				memset(pOrderBookResp.suborderbook[j].sBuySellInd,'\0',5);
				strncpy(pOrderBookResp.suborderbook[j].sBuySellInd,Row[4],5);
				pOrderBookResp.suborderbook[j].cSegment = Row[5][0];
				pOrderBookResp.suborderbook[j].iLegValue = atoi(Row[48]);
				strncpy(pOrderBookResp.suborderbook[j].sProduct,Row[8],10);

				pOrderBookResp.suborderbook[j].iMainTranscode= atoi(Row[45]);
				pOrderBookResp.suborderbook[j].iQty = atoi(Row[10]);
				pOrderBookResp.suborderbook[j].iRemQty= atoi(Row[11]);
				pOrderBookResp.suborderbook[j].fPrice = atof(Row[12]);



				pOrderBookResp.suborderbook[j].iSLTranscode= atoi(Row[14]);
				pOrderBookResp.suborderbook[j].iSLOrdQty= atoi(Row[16]);
				pOrderBookResp.suborderbook[j].iSLRemQty= atoi(Row[17]);
				pOrderBookResp.suborderbook[j].fSLPrice = atof(Row[18]);


				pOrderBookResp.suborderbook[j].iProfTranscode= atoi(Row[19]);
				pOrderBookResp.suborderbook[j].iProfQty= atoi(Row[22]);
				pOrderBookResp.suborderbook[j].iProfRemQty= atoi(Row[23]);
				pOrderBookResp.suborderbook[j].fProfPrice= atof(Row[24]);


				strncpy(pOrderBookResp.suborderbook[j].sOrderType,Row[13],8);
				pOrderBookResp.suborderbook[j].fDQQty = atof(Row[43]);
				pOrderBookResp.suborderbook[j].iSerialNo =atoi(Row[26]);
				pOrderBookResp.suborderbook[j].fTradeQty = atof(Row[28]);
				strncpy(pOrderBookResp.suborderbook[j].sSecurityID,Row[29] ,SECURITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sValidity,Row[36],5);
				pOrderBookResp.suborderbook[j].fDQQtyRem = atof(Row[43]);
				strncpy(pOrderBookResp.suborderbook[j].sExchOrderNumber,Row[44],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sReasonDesc, Row[32],DB_REASON_DESC_LEN);
				pOrderBookResp.suborderbook[j].cProClient =  Row[33][0];
				pOrderBookResp.suborderbook[j].fTrdPrice  = atof(Row[30]);
				strncpy(pOrderBookResp.suborderbook[j].sGoodTillDaysDate, Row[34],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sEntityId , Row[47],ENTITY_ID_LEN);
				pOrderBookResp.suborderbook[j].iStrategyId = atoi(Row[31]);
				pOrderBookResp.suborderbook[j].iDateTime = atoi(Row[49]);
				strncpy(pOrderBookResp.suborderbook[j].sMktType, Row[50],MKT_TYPE_LEN);


				logInfo(" ----------------- Printing Header ------------------------------------");

				logDebug2("pOrderBookResp.suborderbook[j].sClientId = %s",pOrderBookResp.suborderbook[j].sClientId);
				logDebug2("pOrderBookResp.suborderbook[j].sDatetime = %s",pOrderBookResp.suborderbook[j].sDatetime);
				logDebug2("pOrderBookResp.suborderbook[j].fOrderNo =%lf ",pOrderBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrderBookResp.suborderbook[j].sExcgId = %s",pOrderBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrderBookResp.suborderbook[j].sBuySellInd = %s",pOrderBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrderBookResp.suborderbook[j].cSegment = %c",pOrderBookResp.suborderbook[j].cSegment);
				logDebug2("pOrderBookResp.suborderbook[j].iLegValue = %d",pOrderBookResp.suborderbook[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbook[j].sProduct = %s",pOrderBookResp.suborderbook[j].sProduct);

				logDebug2("pOrderBookResp.suborderbook[j].iMainTranscode = %d",pOrderBookResp.suborderbook[j].iMainTranscode);
				logDebug2("pOrderBookResp.suborderbook[j].iQty= %d",pOrderBookResp.suborderbook[j].iQty);
				logDebug2("pOrderBookResp.suborderbook[j].iRemQty = %d",pOrderBookResp.suborderbook[j].iRemQty);
				logDebug2("pOrderBookResp.suborderbook[j].fPrice = %lf",pOrderBookResp.suborderbook[j].fPrice);

				logDebug2("pOrderBookResp.suborderbook[j].iSLTranscode= %d",pOrderBookResp.suborderbook[j].iSLTranscode);
				logDebug2("pOrderBookResp.suborderbook[j].iSLOrdQty = %d",pOrderBookResp.suborderbook[j].iSLOrdQty);
				logDebug2("pOrderBookResp.suborderbook[j].iSLRemQty = %d",pOrderBookResp.suborderbook[j].iSLRemQty);
				logDebug2("pOrderBookResp.suborderbook[j].fSLPrice= %lf",pOrderBookResp.suborderbook[j].fSLPrice);

				logDebug2("pOrderBookResp.suborderbook[j].iProfTranscode = %d",pOrderBookResp.suborderbook[j].iProfTranscode);
				logDebug2("pOrderBookResp.suborderbook[j].iProfQty= %d",pOrderBookResp.suborderbook[j].iProfQty);
				logDebug2("pOrderBookResp.suborderbook[j].iProfRemQty= %d",pOrderBookResp.suborderbook[j].iProfRemQty);
				logDebug2("pOrderBookResp.suborderbook[j].fProfPrice= %lf",pOrderBookResp.suborderbook[j].fProfPrice);

				logDebug2("pOrderBookResp.suborderbook[j].sOrderType= %s",pOrderBookResp.suborderbook[j].sOrderType);
				logDebug2("pOrderBookResp.suborderbook[j].fDQQty = %lf",pOrderBookResp.suborderbook[j].fDQQty);
				logDebug2("pOrderBookResp.suborderbook[j].iSerialNo = %d",pOrderBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrderBookResp.suborderbook[j].fTradeQty= %lf",pOrderBookResp.suborderbook[j].fTradeQty);
				logDebug2("pOrderBookResp.suborderbook[j].iStrategyId = %d",pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[j].sValidity = %s",pOrderBookResp.suborderbook[j].sValidity);
				logDebug2("pOrderBookResp.suborderbook[j].fDQQtyRem = %lf",pOrderBookResp.suborderbook[j].fDQQtyRem);
				logDebug2("pOrderBookResp.suborderbook[j].sExchOrderNumber= %s",pOrderBookResp.suborderbook[j].sExchOrderNumber);
				logDebug2("pOrderBookResp.suborderbook[j].sReasonDesc = %s",pOrderBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrderBookResp.suborderbook[j].cProClient = %c",pOrderBookResp.suborderbook[j].cProClient);
				logDebug2("pOrderBookResp.suborderbook[j].fTrdPrice = %lf",pOrderBookResp.suborderbook[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbook[j].sGoodTillDaysDate = %s",pOrderBookResp.suborderbook[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbook[j].sEntityId = %s",pOrderBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbook[j].iStrategyId = %d",pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[j].iDateTime = %d",pOrderBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrderBookResp.suborderbook[j].sMktType = %s",pOrderBookResp.suborderbook[j].sMktType);		
			}
			iTempNoOfRec--;
		}

		usleep(100);
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_BO_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/
	}

	logTimestamp("EXIT [fBoOrderBook]");
	return TRUE;

}/************** END of fBoOrderBook****/


BOOL fExchMsgReq (CHAR *RcvMsg)
{
	logTimestamp(" ENTRY [fExchMsgReq]");
	struct VIEW_COMMON_QUERY_REQ 	*pReq;
	struct VIEW_COMMON_HDR_RESP    	pMsgResp ;
	struct VIEW_DWS_GEN_MSG_BCAST 	pGenMsg ;

	LONG32 iErrorId=0;
	LONG32 iNoOfRec =0;
	LONG32 iNoOfPkt =0;
	LONG32 iTempNoOfRec =0;
	LONG32 i=0,j=0;
	DOUBLE64 fNoOfRec = 0.00 ;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR sSelQuery [MAX_QUERY_SIZE];
	memset(sSelQuery,'\0',sSelQuery);

	pReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;
	logDebug2("  client:%s: sEntityId :%s: ",pReq->sClientId,pReq->sEntityId);
	sprintf(sSelQuery,"SELECT EXMS_GENERAL_MESG ,EXMS_ACTION_CODE,EXMS_EXM_EXCH_ID FROM EXCH_MESGS");

	logDebug2("sSelQuery :%s:",sSelQuery);
	if(mysql_query(DBQueries,sSelQuery) != SUCCESS)
	{
		logSqlFatal("ERROR in Selecting EXCH_MESGS");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/2);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pMsgResp.IntRespHeader.iSeqNo = 0;
	pMsgResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pMsgResp.IntRespHeader.iErrorId = 0;
	pMsgResp.IntRespHeader.iMsgCode = TC_INT_EXCH_GEN_MSG_RESP;
	pMsgResp.IntRespHeader.iUserId = pReq->ReqHeader.iUserId;
	pMsgResp.IntRespHeader.cSource = pReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pMsgResp.cMsgType = 'H';
	pMsgResp.iNoofRec = iNoOfRec;

	logDebug1(" pMsgResp.cMsgType:%c:,pMsgResp.iNoofRec:%d:",pMsgResp.cMsgType,pMsgResp.iNoofRec);
	logDebug2("pReq->ReqHeader.iUserId = %llu",pReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pReq->ReqHeader.iUserId);

	logDebug2("iRelayID = %d",iRelayID);

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pMsgResp ,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<2;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pGenMsg.IntRespHeader.iSeqNo = 0;
				pGenMsg.IntRespHeader.iMsgLength = sizeof(struct VIEW_DWS_GEN_MSG_BCAST);
				pGenMsg.IntRespHeader.iErrorId = 0;
				pGenMsg.IntRespHeader.iMsgCode = TC_INT_EXCH_GEN_MSG_RESP ;
				pGenMsg.IntRespHeader.iUserId = pReq->ReqHeader.iUserId;
				pGenMsg.IntRespHeader.cSource = pReq->ReqHeader.cSource;

				strncpy(pGenMsg.sExchmsg[j].sBcastMsg,Row[0],BCAST_MSG_LEN);	
				strncpy(pGenMsg.sExchmsg[j].sActionCode,Row[1],ACTION_CODE_LEN);	

				if(iTempNoOfRec <= 1)
				{
					pGenMsg.cMsgType = 'T';
				}
				else
				{
					pGenMsg.cMsgType = 'D';
				}
				logDebug2("------------------Start Print General Messages for Packet %d-------------------",j);
				logDebug2("pGenMsg.IntRespHeader.iMsgLength	:%d:",pGenMsg.IntRespHeader.iMsgLength);
				logDebug2("pGenMsg.IntRespHeader.iMsgCode	:%d:",pGenMsg.IntRespHeader.iMsgCode);
				logDebug2("pGenMsg.IntRespHeader.iUserId	:%llu:",pGenMsg.IntRespHeader.iUserId);
				logDebug2("pGenMsg.IntRespHeader.cSource	:%c:",pGenMsg.IntRespHeader.cSource);

				logDebug2("pGenMsg.sExchmsg[j].sBcastMsg   	:%s:",pGenMsg.sExchmsg[j].sBcastMsg);
				logDebug2("pGenMsg.sExchmsg[j].sActionCode	:%s:",pGenMsg.sExchmsg[j].sActionCode);

			}
			iTempNoOfRec--;
		}

		usleep(100);
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pGenMsg,sizeof(struct VIEW_DWS_GEN_MSG_BCAST) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/
	}

	logTimestamp("EXIT [fExchMsgReq]");
	return TRUE;

}	

BOOL    fDealerBoOrderBook(CHAR *RcvMsg,BOOL iMrgFlag)
{
	logTimestamp(" ENTRY [fDealerBoOrderBook]");
	struct VIEW_COMMON_QUERY_REQ *pViewOrderBookReq;
	struct VIEW_BO_ORDER_BOOK_RESP  pOrderBookResp;
	struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

	LONG32 iErrorId=0;
	LONG32 i=0,j=0;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR *sOrdBook = malloc(sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);

	//      CHAR    sWhere_Clause[QUERY_SIZE];
	//        memset(sWhere_Clause,'\0',QUERY_SIZE);

	DOUBLE64        fOrderNo;
	LONG32          iSerialNo;
	CHAR            sBuySellInd[5];
	CHAR            sSecurityID[SECURITY_ID_LEN];
	CHAR            sOrderType[8];
	DOUBLE64        fQty;
	DOUBLE64        fRemQty;
	DOUBLE64        fDQQty;
	DOUBLE64        fDQQtyRem;
	DOUBLE64        fPrice;
	DOUBLE64        fTrgPrice;
	CHAR            sProduct[10];
	CHAR            sValidity[5];
	CHAR            sExchOrderNumber[BSE_EXCH_ORDER_NO_LEN];
	CHAR            sDatetime[DATE_LENGTH];
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec;
	CHAR            sClientId[CLIENT_ID_LEN];
	CHAR            sRespClientId[CLIENT_ID_LEN];
	CHAR            sEntityId[ENTITY_ID_LEN];
	CHAR            ExcgId[EXCHANGE_LEN];
	CHAR            Segment;
	DOUBLE64        fTradeQty;
	LONG32          iTranscode;
	LONG32          iNoOfPkt;
	DOUBLE64        fNoOfRec;
	LONG32          iOrderBookTime;

	CHAR    *sWhereQry = malloc (sizeof(CHAR) * DOUBLE_MAX_QUERY_SIZE);
	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	logDebug2("pViewOrderBookReq->sClientId = %s",pViewOrderBookReq->sClientId);
	logDebug2("pViewOrderBookReq->sEntityId = %s",pViewOrderBookReq->sEntityId);

	if(iMrgFlag == TRUE)
	{
		sprintf(sWhereQry," AND CLIENT_ID IN (select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(trim(\"%s\")))",pViewOrderBookReq->sEntityId);

	}
	else
	{
		sprintf(sWhereQry," ");
	}


	pViewOrderBookReq = (struct VIEW_COMMON_QUERY_REQ *)RcvMsg;

	strncpy(sClientId ,pViewOrderBookReq->sClientId,CLIENT_ID_LEN);
	strncpy(sEntityId ,pViewOrderBookReq->sEntityId,ENTITY_ID_LEN);
	logDebug2("  client:%s: sEntityId :%s: ",sClientId ,pViewOrderBookReq->sEntityId);

	//      fOrderBookQuery(sClientId,sWhere_Clause,&Result);
	/**
	  sprintf(sOrdBook,"SELECT\
	  A.EQ_CLIENT_ID AS CLIENT_ID,\
	  A.EQ_INTERNAL_ENTRY_DATE AS ORDER_DATE_TIME,\
	  A.EQ_ORDER_NO AS ORDER_NUMBER,\
	  A.EQ_EXCH_ID AS EXCH,\
	  (CASE A.EQ_BUY_SELL_IND\
	  WHEN 'B' THEN 'Buy'\
	  WHEN 'S' THEN 'Sell'\
	  END) AS BUY_SELL,\
	  'E' AS SEGMENT,\
	  A.EQ_INSTRUMENT_NAME AS INSTRUMENT,\
	  A.EQ_SYMBOL AS SYMBOL,\
	  (CASE A.EQ_PRODUCT_ID\
	  WHEN 'B' THEN 'BO'\
	  WHEN 'V' THEN 'CO'\
	  WHEN 'C' THEN 'CNC'\
	  WHEN 'M' THEN 'MARGIN'\
	  WHEN 'L' THEN 'MLB'\
	  WHEN 'S' THEN 'COLLATERAL'\
	  WHEN 'I' THEN 'INTRADAY'\
	  ELSE A.EQ_PRODUCT_ID\
	  END) AS PRODUCT,\
	  GROUP_CONCAT(CASE  A.EQ_LEG_NO \
	  WHEN 1 THEN (CASE\
	  WHEN\
	  ((A.EQ_MSG_CODE = '2073')\
	  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
	  THEN\
	  'Part-Traded'\
	  WHEN\
	  ((A.EQ_MSG_CODE = '2074')\
	  AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
	  THEN\
	  'Part-Traded'\
	  WHEN\
	  ((A.EQ_MSG_CODE = '2212')\
	  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
	  THEN\
	  'Part-Traded'\
	  WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
	  WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
	  WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
	  WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
	  WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
	  WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
	  WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
	  WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
	  WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
	  WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
	  WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
	  WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
	  WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
	  WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
	  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
	  END) END )AS ORD_STATUS_MAIN,\
	  sum(CASE  A.EQ_LEG_NO WHEN 1 THEN A.EQ_TOTAL_QTY end )AS QUANTITY,\
	  sum(CASE  A.EQ_LEG_NO WHEN 1 THEN A.EQ_REM_QTY end )AS REMAINING_QUANTITY,\
	  sum(CASE  A.EQ_LEG_NO WHEN 1 THEN \
	  (CASE A.EQ_ORDER_TYPE\
	  WHEN '1' THEN 'MKT'\
	  WHEN '3' THEN 'MKT'\
	  ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
	  END) end )AS PRICE,\
	  CASE  A.EQ_LEG_NO WHEN 1 THEN \
	(CASE A.EQ_ORDER_TYPE\
	 WHEN '1' THEN 'MARKET'\
	 WHEN '2' THEN 'LIMIT'\
	 WHEN '3' THEN 'SL-M'\
	 WHEN '4' THEN 'SL'\
	 END) end AS ORDER_TYPE,\
		GROUP_CONCAT( case  A.EQ_LEG_NO \
				WHEN 2 THEN A.EQ_MSG_CODE END  )as SL_CODE ,\
		GROUP_CONCAT( case  A.EQ_LEG_NO\
				WHEN 2 THEN (CASE\
					WHEN\
					((A.EQ_MSG_CODE = '2073')\
					 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
					THEN\
					'Part-Traded'\
					WHEN\
					((A.EQ_MSG_CODE = '2074')\
					 AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
					THEN\
					'Part-Traded'\
					WHEN\
					((A.EQ_MSG_CODE = '2212')\
					 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
					THEN\
					'Part-Traded'\
					WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
					WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
					WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
					WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
					WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
					WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
					WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
					WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
					WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
					WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
					WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
					WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
					WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
					WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
					WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
					WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\	
					WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
					WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
					END) END) AS ORD_STATUS_SL,\
					sum(CASE  A.EQ_LEG_NO WHEN 2 THEN A.EQ_TOTAL_QTY end )AS QUANTITY_SL,\
					sum(CASE  A.EQ_LEG_NO WHEN 2 THEN A.EQ_REM_QTY end )AS REMAINING_QUANTITY_SL,\
					sum(CASE  A.EQ_LEG_NO WHEN 2 THEN \
							IFNULL(A.EQ_TRIGGER_PRICE, 0)\
							END) AS PRICE_SL,\
					GROUP_CONCAT( case  A.EQ_LEG_NO \
							WHEN 3 THEN A.EQ_MSG_CODE END  )as PROF_CODE ,\
					GROUP_CONCAT(CASE  A.EQ_LEG_NO \
							WHEN 3 THEN (CASE\
								WHEN\
								((A.EQ_MSG_CODE = '2073')\
								 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
								THEN\
								'Part-Traded'\
								WHEN\
								((A.EQ_MSG_CODE = '2074')\
								 AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
								THEN\
								'Part-Traded'\
								WHEN\
								((A.EQ_MSG_CODE = '2212')\
								 AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
								THEN\
								'Part-Traded'\
								WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
								WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
								WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
								WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
								WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
								WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
								WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
								WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
								WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
								WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
								WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
								WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\	
								WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
								WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
								WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
								WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
								WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
								WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
								END) END )AS ORD_STATUS_PROFIT,\
								A.EQ_MSG_CODE as PROF_MSG_CODE,\
								sum( CASE  A.EQ_LEG_NO WHEN 3 THEN A.EQ_TOTAL_QTY end )AS QUANTITY_PROFIT,\
								sum(CASE  A.EQ_LEG_NO WHEN 3 THEN A.EQ_REM_QTY end )AS REMAINING_QUANTITY_PROFIT,\
								sum(CASE  A.EQ_LEG_NO WHEN 3 THEN (CASE A.EQ_ORDER_TYPE\
											WHEN '1' THEN 'MKT'\
											WHEN '3' THEN 'MKT'\
											ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
											END) end )AS PRICE_PROFIT,\
								A.EQ_DISC_QTY AS DISCLOSE_QTY,\
								A.EQ_SERIAL_NO AS SERIALNO,\
								A.EQ_ACC_CODE AS ACCCOUNTCODE,\
								A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,\
								A.EQ_SCRIP_CODE AS SEM_SECURITY_ID,\
								A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,\
								A.EQ_STRATEGY_ID AS STRATEGY_ID,\
								A.EQ_REASON_DESCRIPTION AS REASON_DESCRIPTION,\
								A.EQ_PRO_CLIENT AS PRO_CLIENT,\
								A.EQ_GOOD_TILL_DATE AS GOOD_TILL_DATE,\
								A.EQ_ERROR_CODE AS ERROR_CODE,\
								(CASE A.EQ_VALIDITY\
								 WHEN '0' THEN 'DAY'\
								 WHEN '1' THEN 'GTC'\
								 WHEN '2' THEN 'ATO'\
								 WHEN '3' THEN 'IOC'\
								 ELSE 'EOS'\
								 END) AS ORDER_VALIDITY,\
								A.EQ_LOT_SIZE AS SEM_NSE_REGULAR_LOT,\
								0 AS TAKE_PROFIT_TRAIL_GAP,\
								0 AS ADV_GROUP_REF_NO,\
								'NA' AS OPTION_TYPE,\
								0 AS STRIKE_PRICE,\ 	
								'NA' AS EXPIRY_DATE,\
								A.EQ_DISC_REM_QTY AS DQQTYREM,\
								A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,\
								A.EQ_MSG_CODE AS TRANSCODE,\
								A.EQ_ORDER_PRICE AS ORDER_PRICE,\
								A.EQ_ENTITY_ID AS PLACEDBY,\
								A.EQ_LEG_NO AS LEGVALUE,\
								julidate(A.EQ_INTERNAL_ENTRY_DATE) as JDATE,\
								A.EQ_MKT_TYPE AS MKT_TYPE\
								FROM\
								EQ_ORDERS A\
								WHERE A.EQ_PRODUCT_ID='B' and A.EQ_ALGO_ORDER_NO=-1  \
								AND \
								((A.EQ_SERIAL_NO = (SELECT \
										    MAX(C.EQ_SERIAL_NO)\
										    FROM\
										    EQ_ORDERS C\
										    WHERE\
										    ((C.EQ_ORDER_NO = A.EQ_ORDER_NO)\
										     AND (A.EQ_LEG_NO = C.EQ_LEG_NO))))) \
								%s \  		
								GROUP BY A.EQ_ORDER_NO;\
								",sWhereQry);
	***/
		sprintf(sOrdBook,"SELECT * FROM (SELECT \
		A.EQ_CLIENT_ID AS CLIENT_ID,\
				A.EQ_INTERNAL_ENTRY_DATE AS ORDER_DATE_TIME,\
				A.EQ_ORDER_NO AS ORDER_NUMBER,\
				A.EQ_EXCH_ID AS EXCH,\
				(CASE A.EQ_BUY_SELL_IND\
				 WHEN 'B' THEN 'Buy'\
				 WHEN 'S' THEN 'Sell'\
				 END) AS BUY_SELL,\
				'E' AS SEGMENT,\
				A.EQ_INSTRUMENT_NAME AS INSTRUMENT,\
				A.EQ_SYMBOL AS SYMBOL,\
				(CASE A.EQ_PRODUCT_ID\
				 WHEN 'B' THEN 'BO'\
				 WHEN 'V' THEN 'CO'\
				 WHEN 'C' THEN 'CNC'\
				 WHEN 'M' THEN 'MARGIN'\
				 WHEN 'L' THEN 'MLB'\
				 WHEN 'S' THEN 'COLLATERAL'\
				 WHEN 'I' THEN 'INTRADAY'\
				 ELSE A.EQ_PRODUCT_ID\
				 END) AS PRODUCT,\
				GROUP_CONCAT(CASE A.EQ_LEG_NO\
						WHEN\
						1\
						THEN\
						(CASE\
						 WHEN\
						 ((A.EQ_MSG_CODE = '2073')\
						  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
						 THEN\
						 'Part-Traded'\
						 WHEN\
						 ((A.EQ_MSG_CODE = '2074')\
						  AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
						 THEN\
						 'Part-Traded'\
						 WHEN\
						 ((A.EQ_MSG_CODE = '2212')\
						  AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
						 THEN\
						 'Part-Traded'\
						 WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
						 WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
						 WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
						 WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
						 WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
						 WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
						 WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
						 WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
						 WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
						 WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
						 WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
						 WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
						 WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
						 WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
						 WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
						 END)\
						 END) AS ORD_STATUS_MAIN,\
						 SUM(CASE A.EQ_LEG_NO\
								 WHEN 1 THEN A.EQ_TOTAL_QTY\
								 END) AS QUANTITY,\
						 SUM(CASE A.EQ_LEG_NO\
								 WHEN 1 THEN A.EQ_REM_QTY\
								 END) AS REMAINING_QUANTITY,\
						 SUM(CASE A.EQ_LEG_NO\
								 WHEN\
								 1\
								 THEN\
								 (CASE A.EQ_ORDER_TYPE\
								  WHEN '1' THEN 'MKT'\
								  WHEN '3' THEN 'MKT'\
								  ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
								  END)\
								 END) AS PRICE,\
						 CASE A.EQ_LEG_NO\
						 WHEN\	
						 1\
						 THEN\
						 (CASE A.EQ_ORDER_TYPE\
						  WHEN '1' THEN 'MARKET'\
						  WHEN '2' THEN 'LIMIT'\
						  WHEN '3' THEN 'SL-M'\
						  WHEN '4' THEN 'SL'\
						  END)\
						 END AS ORDER_TYPE,\
						 GROUP_CONCAT(CASE A.EQ_LEG_NO\
								 WHEN 2 THEN A.EQ_MSG_CODE\
								 END) AS SL_CODE,\
						 GROUP_CONCAT(CASE A.EQ_LEG_NO\
								 WHEN\
								 2\
								 THEN\
								 (CASE\
								  WHEN\
								  ((A.EQ_MSG_CODE = '2073')\
								   AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
								  THEN\
								  'Part-Traded'\
								  WHEN\
								  ((A.EQ_MSG_CODE = '2074')\
								   AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
								  THEN\
								  'Part-Traded'\
								  WHEN\
								  ((A.EQ_MSG_CODE = '2212')\
								   AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
								  THEN\
								  'Part-Traded'\
								  WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
								  WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
								  WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
								  WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
								  WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
								  WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
								  WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
								  WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
								  WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
								  WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
								  WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
								  WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
								  WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
								  WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
								  WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
								  WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
								  WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
								  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
								  WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
								  END)\
								  END) AS ORD_STATUS_SL,\
								  SUM(CASE A.EQ_LEG_NO\
										  WHEN 2 THEN A.EQ_TOTAL_QTY\
										  END) AS QUANTITY_SL,\
								  SUM(CASE A.EQ_LEG_NO\
										  WHEN 2 THEN A.EQ_REM_QTY\
										  END) AS REMAINING_QUANTITY_SL,\
								  SUM(CASE A.EQ_LEG_NO\
										  WHEN 2 THEN IFNULL(A.EQ_TRIGGER_PRICE, 0)\
										  END) AS PRICE_SL,\
								  GROUP_CONCAT(CASE A.EQ_LEG_NO\
										  WHEN 3 THEN A.EQ_MSG_CODE\
										  END) AS PROF_CODE,\
								  GROUP_CONCAT(CASE A.EQ_LEG_NO\
										  WHEN\
										  3\
										  THEN\
										  (CASE\
										   WHEN\
										   ((A.EQ_MSG_CODE = '2073')\
										    AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
										   THEN\
										   'Part-Traded'\
										   WHEN\
										   ((A.EQ_MSG_CODE = '2074')\
										    AND (A.EQ_REM_QTY > A.EQ_TOTAL_QTY))\
										   THEN\
										   'Part-Traded'\
										   WHEN\
										   ((A.EQ_MSG_CODE = '2212')\
										    AND (A.EQ_REM_QTY <> A.EQ_TOTAL_QTY))\
										   THEN\
										   'Part-Traded'\
										   WHEN (A.EQ_MSG_CODE = '2073') THEN 'Pending'\
										   WHEN (A.EQ_MSG_CODE = '2000') THEN 'Transit'\
										   WHEN (A.EQ_MSG_CODE = '2040') THEN 'Transit'\
										   WHEN (A.EQ_MSG_CODE = '2070') THEN 'Transit'\
										   WHEN (A.EQ_MSG_CODE = '2231') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '2042') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '2170') THEN 'Frozen'\
										   WHEN (A.EQ_MSG_CODE = '2074') THEN 'Modified'\
										   WHEN (A.EQ_MSG_CODE = '2075') THEN 'Cancelled'\
										   WHEN (A.EQ_MSG_CODE = '2222') THEN 'Traded'\
										   WHEN (A.EQ_MSG_CODE = '9002') THEN 'Expired'\
										   WHEN (A.EQ_MSG_CODE = '5112') THEN 'O-Pending'\
										   WHEN (A.EQ_MSG_CODE = '5113') THEN 'O-Modified'\
										   WHEN (A.EQ_MSG_CODE = '5114') THEN 'O-Cancelled'\
										   WHEN (A.EQ_MSG_CODE = '2212') THEN 'Triggered'\
										   WHEN (A.EQ_MSG_CODE = '1111') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '1113') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '1115') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '4444') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '4445') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '4446') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '4450') THEN 'Rejected'\
										   WHEN (A.EQ_MSG_CODE = '8107') THEN 'Open'\
										   WHEN (A.EQ_MSG_CODE = '8108') THEN 'Pending'\
										   WHEN (A.EQ_MSG_CODE = '8109') THEN 'Traded'\
										   WHEN (A.EQ_MSG_CODE = '8110') THEN 'Exited'\
										   END)\
										   END) AS ORD_STATUS_PROFIT,\
										   A.EQ_MSG_CODE AS PROF_MSG_CODE,\
										   SUM(CASE A.EQ_LEG_NO\
												   WHEN 3 THEN A.EQ_TOTAL_QTY\
												   END) AS QUANTITY_PROFIT,\
										   SUM(CASE A.EQ_LEG_NO\
												   WHEN 3 THEN A.EQ_REM_QTY\
												   END) AS REMAINING_QUANTITY_PROFIT,\
										   SUM(CASE A.EQ_LEG_NO\
												   WHEN\
												   3\
												   THEN\
												   (CASE A.EQ_ORDER_TYPE\
												    WHEN '1' THEN 'MKT'\
												    WHEN '3' THEN 'MKT'\
												    ELSE IFNULL(A.EQ_ORDER_PRICE, 0)\
												    END)\
												   END) AS PRICE_PROFIT,\
										   A.EQ_DISC_QTY AS DISCLOSE_QTY,\
										   A.EQ_SERIAL_NO AS SERIALNO,\
										   A.EQ_ACC_CODE AS ACCCOUNTCODE,\
										   A.EQ_TOTAL_TRADED_QTY AS TRADEDQTY,\
										   A.EQ_SCRIP_CODE AS SEM_SECURITY_ID,\
										   A.EQ_TRD_TRADE_PRICE AS TRADE_PRICE,\
										   A.EQ_STRATEGY_ID AS STRATEGY_ID,\
										   A.EQ_REASON_DESCRIPTION AS REASON_DESCRIPTION,\
										   A.EQ_PRO_CLIENT AS PRO_CLIENT,\
										   A.EQ_GOOD_TILL_DATE AS GOOD_TILL_DATE,\
										   A.EQ_ERROR_CODE AS ERROR_CODE,\
										   (CASE A.EQ_VALIDITY\
										    WHEN '0' THEN 'DAY'\
										    WHEN '1' THEN 'GTC'\
										    WHEN '2' THEN 'ATO'\
										    WHEN '3' THEN 'IOC'\
										    ELSE 'EOS'\
										    END) AS ORDER_VALIDITY,\
										   A.EQ_LOT_SIZE AS SEM_NSE_REGULAR_LOT,\
										   0 AS TAKE_PROFIT_TRAIL_GAP,\
										   0 AS ADV_GROUP_REF_NO,\
										   'NA' AS OPTION_TYPE,\
										   0 AS STRIKE_PRICE,\
										   'NA' AS EXPIRY_DATE,\
										   A.EQ_DISC_REM_QTY AS DQQTYREM,\
										   A.EQ_EXCH_ORDER_NO AS EXCHORDERNO,\
										   A.EQ_MSG_CODE AS TRANSCODE,\
										   A.EQ_ORDER_PRICE AS ORDER_PRICE,\
										   A.EQ_ENTITY_ID AS PLACEDBY,\
										   A.EQ_LEG_NO AS LEGVALUE,\
										   JULIDATE(A.EQ_INTERNAL_ENTRY_DATE) AS JDATE,\		
										   A.EQ_MKT_TYPE AS MKT_TYPE\
										   FROM\
										   EQ_ORDERS A\
										   WHERE\
										   A.EQ_PRODUCT_ID = 'B'\
										   AND A.EQ_ALGO_ORDER_NO = - 1\
										   AND ((A.EQ_SERIAL_NO = (SELECT \
														   MAX(C.EQ_SERIAL_NO)\
														   FROM\
														   EQ_ORDERS C\
														   WHERE\
														   ((C.EQ_ORDER_NO = A.EQ_ORDER_NO)\
														    AND (A.EQ_LEG_NO = C.EQ_LEG_NO)))))\
										   GROUP BY A.EQ_ORDER_NO \
										   union all SELECT \
										   A.DRV_CLIENT_ID AS CLIENT_ID,\
										   A.DRV_INTERNAL_ENTRY_DATE AS ORDER_DATE_TIME,\
										   A.DRV_ORDER_NO AS ORDER_NUMBER,\
										   A.DRV_EXCH_ID AS EXCH,\
										   (CASE A.DRV_BUY_SELL_IND\
										    WHEN 'B' THEN 'Buy'\
										    WHEN 'S' THEN 'Sell'\
										    END) AS BUY_SELL,\
										   A.DRV_SEGMENT AS SEGMENT,\
										   A.DRV_INSTRUMENT_NAME AS INSTRUMENT,\
										   A.DRV_SYMBOL AS SYMBOL,\
										   (CASE A.DRV_PRODUCT_ID\
										    WHEN 'B' THEN 'BO'\
										    WHEN 'V' THEN 'CO'\
										    WHEN 'C' THEN 'CNC'\
										    WHEN 'M' THEN 'MARGIN'\
										    WHEN 'L' THEN 'MLB'\
										    WHEN 'S' THEN 'COLLATERAL'\
										    WHEN 'I' THEN 'INTRADAY'\
										    ELSE A.DRV_PRODUCT_ID\
										    END) AS PRODUCT,\
										   GROUP_CONCAT(CASE A.DRV_LEG_NO\
												   WHEN\
												   1\
												   THEN\
												   (CASE\
												    WHEN\
												    ((A.DRV_MSG_CODE = '2073')\
												     AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
												    THEN\
												    'Part-Traded'\
												    WHEN\
												    ((A.DRV_MSG_CODE = '2074')\
												     AND (A.DRV_REM_QTY > A.DRV_TOTAL_QTY))\
												    THEN\
												    'Part-Traded'\
												    WHEN\
												    ((A.DRV_MSG_CODE = '2212')\
												     AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
												    THEN\
												    'Part-Traded'\
												    WHEN (A.DRV_MSG_CODE = '2073') THEN 'Pending'\
												    WHEN (A.DRV_MSG_CODE = '2000') THEN 'Transit'\
												    WHEN (A.DRV_MSG_CODE = '2040') THEN 'Transit'\
												    WHEN (A.DRV_MSG_CODE = '2070') THEN 'Transit'\
												    WHEN (A.DRV_MSG_CODE = '2231') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '2042') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '2170') THEN 'Frozen'\
												    WHEN (A.DRV_MSG_CODE = '2074') THEN 'Modified'\
												    WHEN (A.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
												    WHEN (A.DRV_MSG_CODE = '2222') THEN 'Traded'\
												    WHEN (A.DRV_MSG_CODE = '9002') THEN 'Expired'\
												    WHEN (A.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
												    WHEN (A.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
												    WHEN (A.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
												    WHEN (A.DRV_MSG_CODE = '2212') THEN 'Triggered'\
												    WHEN (A.DRV_MSG_CODE = '1111') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '1113') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '1115') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '4444') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '4445') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
												    WHEN (A.DRV_MSG_CODE = '4450') THEN 'Rejected'\
												    END)\
												    END) AS ORD_STATUS_MAIN,\
												    SUM(CASE A.DRV_LEG_NO\
														    WHEN 1 THEN A.DRV_TOTAL_QTY\
														    END) AS QUANTITY,\
												    SUM(CASE A.DRV_LEG_NO\
														    WHEN 1 THEN A.DRV_REM_QTY\
														    END) AS REMAINING_QUANTITY,\
												    SUM(CASE A.DRV_LEG_NO\
														    WHEN\
														    1\
														    THEN\
														    (CASE A.DRV_ORDER_TYPE\
														     WHEN '1' THEN 'MKT'\
														     WHEN '3' THEN 'MKT'\
														     ELSE IFNULL(A.DRV_ORDER_PRICE, 0)\
														     END)\
														    END) AS PRICE,\
												    CASE A.DRV_LEG_NO\
												    WHEN\
												    1\
												    THEN\
												    (CASE A.DRV_ORDER_TYPE\
												     WHEN '1' THEN 'MARKET'\
												     WHEN '2' THEN 'LIMIT'\
												     WHEN '3' THEN 'SL-M'\
												     WHEN '4' THEN 'SL'\
												     END)\
												    END AS ORDER_TYPE,\
												    GROUP_CONCAT(CASE A.DRV_LEG_NO\
														    WHEN 2 THEN A.DRV_MSG_CODE\
														    END) AS SL_CODE,\
												    GROUP_CONCAT(CASE A.DRV_LEG_NO\
														    WHEN\
														    2\
														    THEN\
														    (CASE\
														     WHEN\
														     ((A.DRV_MSG_CODE = '2073')\
														      AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
														     THEN\
														     'Part-Traded'\
														     WHEN\
														     ((A.DRV_MSG_CODE = '2074')\
														      AND (A.DRV_REM_QTY > A.DRV_TOTAL_QTY))\
														     THEN\
														     'Part-Traded'\
														     WHEN\
														     ((A.DRV_MSG_CODE = '2212')\
														      AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
														     THEN\
														     'Part-Traded'\
														     WHEN (A.DRV_MSG_CODE = '2073') THEN 'Pending'\
														     WHEN (A.DRV_MSG_CODE = '2000') THEN 'Transit'\
														     WHEN (A.DRV_MSG_CODE = '2040') THEN 'Transit'\
														     WHEN (A.DRV_MSG_CODE = '2070') THEN 'Transit'\
														     WHEN (A.DRV_MSG_CODE = '2231') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '2042') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '2170') THEN 'Frozen'\
														     WHEN (A.DRV_MSG_CODE = '2074') THEN 'Modified'\
														     WHEN (A.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
														     WHEN (A.DRV_MSG_CODE = '2222') THEN 'Traded'\
														     WHEN (A.DRV_MSG_CODE = '9002') THEN 'Expired'\
														     WHEN (A.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
														     WHEN (A.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
														     WHEN (A.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
														     WHEN (A.DRV_MSG_CODE = '2212') THEN 'Triggered'\
														     WHEN (A.DRV_MSG_CODE = '1111') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '1113') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '1115') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '4444') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '4445') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '8107') THEN 'Open'\
														     WHEN (A.DRV_MSG_CODE = '8108') THEN 'Pending'\
														     WHEN (A.DRV_MSG_CODE = '8109') THEN 'Traded'\
														     WHEN (A.DRV_MSG_CODE = '8110') THEN 'Exited'\
														     WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
														     WHEN (A.DRV_MSG_CODE = '4450') THEN 'Rejected'\
														     END)\
														     END) AS ORD_STATUS_SL,\
														     SUM(CASE A.DRV_LEG_NO\
																     WHEN 2 THEN A.DRV_TOTAL_QTY\
																     END) AS QUANTITY_SL,\
														     SUM(CASE A.DRV_LEG_NO\
																     WHEN 2 THEN A.DRV_REM_QTY\
																     END) AS REMAINING_QUANTITY_SL,\
														     SUM(CASE A.DRV_LEG_NO\
																     WHEN 2 THEN IFNULL(A.DRV_TRIGGER_PRICE, 0)\
																     END) AS PRICE_SL,\
														     GROUP_CONCAT(CASE A.DRV_LEG_NO\
																     WHEN 3 THEN A.DRV_MSG_CODE\
																     END) AS PROF_CODE,\ 
														     GROUP_CONCAT(CASE A.DRV_LEG_NO\
																     WHEN\
																     3\
																     THEN\
																     (CASE\
																      WHEN\
																      ((A.DRV_MSG_CODE = '2073')\
																       AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																      THEN\
																      'Part-Traded'\
																      WHEN\
																      ((A.DRV_MSG_CODE = '2074')\
																       AND (A.DRV_REM_QTY > A.DRV_TOTAL_QTY))\
																      THEN\
																      'Part-Traded'\
																      WHEN\
																      ((A.DRV_MSG_CODE = '2212')\
																       AND (A.DRV_REM_QTY <> A.DRV_TOTAL_QTY))\
																      THEN\
																      'Part-Traded'\
																      WHEN (A.DRV_MSG_CODE = '2073') THEN 'Pending'\
																      WHEN (A.DRV_MSG_CODE = '2000') THEN 'Transit'\
																      WHEN (A.DRV_MSG_CODE = '2040') THEN 'Transit'\
																      WHEN (A.DRV_MSG_CODE = '2070') THEN 'Transit'\
																      WHEN (A.DRV_MSG_CODE = '2231') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '2042') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '2170') THEN 'Frozen'\
																      WHEN (A.DRV_MSG_CODE = '2074') THEN 'Modified'\
																      WHEN (A.DRV_MSG_CODE = '2075') THEN 'Cancelled'\
																      WHEN (A.DRV_MSG_CODE = '2222') THEN 'Traded'\
																      WHEN (A.DRV_MSG_CODE = '9002') THEN 'Expired'\
																      WHEN (A.DRV_MSG_CODE = '5112') THEN 'O-Pending'\
																      WHEN (A.DRV_MSG_CODE = '5113') THEN 'O-Modified'\
																      WHEN (A.DRV_MSG_CODE = '5114') THEN 'O-Cancelled'\
																      WHEN (A.DRV_MSG_CODE = '2212') THEN 'Triggered'\
																      WHEN (A.DRV_MSG_CODE = '1111') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '1113') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '1115') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '4444') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '4445') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '4446') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '4450') THEN 'Rejected'\
																      WHEN (A.DRV_MSG_CODE = '8107') THEN 'Open'\
																      WHEN (A.DRV_MSG_CODE = '8108') THEN 'Pending'\
																      WHEN (A.DRV_MSG_CODE = '8109') THEN 'Traded'\
																      WHEN (A.DRV_MSG_CODE = '8110') THEN 'Exited'\
																      END)\
																      END) AS ORD_STATUS_PROFIT,\
																      A.DRV_MSG_CODE AS PROF_MSG_CODE,\
																      SUM(CASE A.DRV_LEG_NO\
																		      WHEN 3 THEN A.DRV_TOTAL_QTY\
																		      END) AS QUANTITY_PROFIT,\
																      SUM(CASE A.DRV_LEG_NO\
																		      WHEN 3 THEN A.DRV_REM_QTY\
																		      END) AS REMAINING_QUANTITY_PROFIT,\
																      SUM(CASE A.DRV_LEG_NO\
																		      WHEN\
																		      3\
																		      THEN\
																		      (CASE A.DRV_ORDER_TYPE\
																		       WHEN '1' THEN 'MKT'\
																		       WHEN '3' THEN 'MKT'\
																		       ELSE IFNULL(A.DRV_ORDER_PRICE, 0)\
																		       END)\
																		      END) AS PRICE_PROFIT,\
																      A.DRV_DISC_QTY AS DISCLOSE_QTY,\
																      A.DRV_SERIAL_NO AS SERIALNO,\
																      A.DRV_ACC_CODE AS ACCCOUNTCODE,\
																      A.DRV_TOTAL_TRADED_QTY AS TRADEDQTY,\
																      A.DRV_SCRIP_CODE AS SEM_SECURITY_ID,\
																      A.DRV_TRD_TRADE_PRICE AS TRADE_PRICE,\
																      A.DRV_STRATEGY_ID AS STRATEGY_ID,\
																      A.DRV_REASON_DESCRIPTION AS REASON_DESCRIPTION,\
																      A.DRV_PRO_CLIENT AS PRO_CLIENT,\
																      A.DRV_GOOD_TILL_DATE AS GOOD_TILL_DATE,\
																      A.DRV_ERROR_CODE AS ERROR_CODE,\
																      (CASE A.DRV_VALIDITY\
																       WHEN '0' THEN 'DAY'\
																       WHEN '1' THEN 'GTC'\
																       WHEN '2' THEN 'ATO'\
																       WHEN '3' THEN 'IOC'\
																       ELSE 'EOS'\
																       END) AS ORDER_VALIDITY,\
																      A.DRV_LOT_SIZE AS SEM_NSE_REGULAR_LOT,\
																      0 AS TAKE_PROFIT_TRAIL_GAP,\
																      0 AS ADV_GROUP_REF_NO,\
																      'NA' AS OPTION_TYPE,\
																      0 AS STRIKE_PRICE,\
																      'NA' AS EXPIRY_DATE,\
																      A.DRV_DISC_REM_QTY AS DQQTYREM,\
																      A.DRV_EXCH_ORDER_NO AS EXCHORDERNO,\
																      A.DRV_MSG_CODE AS TRANSCODE,\
																      A.DRV_ORDER_PRICE AS ORDER_PRICE,\
																      A.DRV_ENTITY_ID AS PLACEDBY,\
																      A.DRV_LEG_NO AS LEGVALUE,\
																      JULIDATE(A.DRV_INTERNAL_ENTRY_DATE) AS JDATE,\
																      A.DRV_MKT_TYPE AS MKT_TYPE\
																      FROM\
																      DRV_ORDERS A\
																      WHERE\
																      A.DRV_PRODUCT_ID = 'B'\
																      AND A.DRV_OMS_ALGO_ORD_NO = - 1\
																      AND ((A.DRV_SERIAL_NO = (SELECT \
																				      MAX(C.DRV_SERIAL_NO)\
																				      FROM\
																				      DRV_ORDERS C\
																				      WHERE\
																				      ((C.DRV_ORDER_NO = A.DRV_ORDER_NO)\
																				       AND (A.DRV_LEG_NO = C.DRV_LEG_NO)))))\
																      GROUP BY A.DRV_ORDER_NO) BO_ORDERBOOK WHERE 1 = 1 %s ;",sWhereQry);

	printf(" fDealerBoOrderBook :%s:",sOrdBook);

	if(mysql_query(DBQueries,sOrdBook ) != SUCCESS)
	{
		logSqlFatal("ERROR in Order BOOK Query.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec= mysql_num_rows(Res);

	logDebug2("Rows returned from Database = :%d:",iNoOfRec);
	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfRec;
	/********END: Calculating no of packets****/

	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
	pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_HDR_RESP;
	pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
	pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	//      pOrderBookHdrResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

	pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

	logDebug1(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
	logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);

	iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);

	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		for(j=0;j<5;j++)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				pOrderBookResp.IntRespHeader.iSeqNo = 0;
				pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BO_ORDER_BOOK_RESP);
				pOrderBookResp.IntRespHeader.iErrorId = 0;
				pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_BO_ORDER_BOOK_RESP;
				pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
				pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
				//                      logDebug2("pOrderBookResp.IntRespHeader.cSource :%c:",pOrderBookResp.IntRespHeader.cSource);
				//                              pOrderBookResp.IntRespHeader.cUserTypeOrLogInfoType = pViewOrderBookReq->ReqHeader.cUserType;

				if(iTempNoOfRec <= 1)
				{
					pOrderBookResp.cMsgType = 'T';
				}
				else
				{
					pOrderBookResp.cMsgType = 'D';
				}

				strncpy(pOrderBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sDatetime,Row[1],DATE_LENGTH);
				pOrderBookResp.suborderbook[j].fOrderNo =atof(Row[2]);
				strncpy(pOrderBookResp.suborderbook[j].sExcgId,Row[3],EXCHANGE_LEN);
				memset(pOrderBookResp.suborderbook[j].sBuySellInd,'\0',5);
				strncpy(pOrderBookResp.suborderbook[j].sBuySellInd,Row[4],5);
				pOrderBookResp.suborderbook[j].cSegment = Row[5][0];
				pOrderBookResp.suborderbook[j].iLegValue = atoi(Row[48]);
				strncpy(pOrderBookResp.suborderbook[j].sProduct,Row[8],10);

				pOrderBookResp.suborderbook[j].iMainTranscode= atoi(Row[45]);
				pOrderBookResp.suborderbook[j].iQty = atoi(Row[10]);
				pOrderBookResp.suborderbook[j].iRemQty= atoi(Row[11]);
				pOrderBookResp.suborderbook[j].fPrice = atof(Row[12]);



				pOrderBookResp.suborderbook[j].iSLTranscode= atoi(Row[14]);
				pOrderBookResp.suborderbook[j].iSLOrdQty= atoi(Row[16]);
				pOrderBookResp.suborderbook[j].iSLRemQty= atoi(Row[17]);
				pOrderBookResp.suborderbook[j].fSLPrice = atof(Row[18]);


				pOrderBookResp.suborderbook[j].iProfTranscode= atoi(Row[19]);
				pOrderBookResp.suborderbook[j].iProfQty= atoi(Row[22]);
				pOrderBookResp.suborderbook[j].iProfRemQty= atoi(Row[23]);
				pOrderBookResp.suborderbook[j].fProfPrice= atof(Row[24]);


				strncpy(pOrderBookResp.suborderbook[j].sOrderType,Row[13],8);
				pOrderBookResp.suborderbook[j].fDQQty = atof(Row[43]);
				pOrderBookResp.suborderbook[j].iSerialNo =atoi(Row[26]);
				pOrderBookResp.suborderbook[j].fTradeQty = atof(Row[28]);
				strncpy(pOrderBookResp.suborderbook[j].sSecurityID,Row[29] ,SECURITY_ID_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sValidity,Row[36],5);
				pOrderBookResp.suborderbook[j].fDQQtyRem = atof(Row[43]);
				strncpy(pOrderBookResp.suborderbook[j].sExchOrderNumber,Row[44],BSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sReasonDesc, Row[32],DB_REASON_DESC_LEN);
				pOrderBookResp.suborderbook[j].cProClient =  Row[33][0];
				pOrderBookResp.suborderbook[j].fTrdPrice  = atof(Row[30]);
				strncpy(pOrderBookResp.suborderbook[j].sGoodTillDaysDate, Row[34],DB_DATETIME_LEN);
				strncpy(pOrderBookResp.suborderbook[j].sEntityId , Row[47],ENTITY_ID_LEN);
				pOrderBookResp.suborderbook[j].iStrategyId = atoi(Row[31]);
				pOrderBookResp.suborderbook[j].iDateTime = atoi(Row[49]);
				strncpy(pOrderBookResp.suborderbook[j].sMktType, Row[50],MKT_TYPE_LEN);


				logInfo(" ----------------- Printing Header ------------------------------------");

				logDebug2("pOrderBookResp.suborderbook[j].sClientId = %s",pOrderBookResp.suborderbook[j].sClientId);
				logDebug2("pOrderBookResp.suborderbook[j].sDatetime = %s",pOrderBookResp.suborderbook[j].sDatetime);
				logDebug2("pOrderBookResp.suborderbook[j].fOrderNo =%lf ",pOrderBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrderBookResp.suborderbook[j].sExcgId = %s",pOrderBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrderBookResp.suborderbook[j].sBuySellInd = %s",pOrderBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrderBookResp.suborderbook[j].cSegment = %c",pOrderBookResp.suborderbook[j].cSegment);
				logDebug2("pOrderBookResp.suborderbook[j].iLegValue = %d",pOrderBookResp.suborderbook[j].iLegValue);
				logDebug2("pOrderBookResp.suborderbook[j].sProduct = %s",pOrderBookResp.suborderbook[j].sProduct);
				logDebug2("pOrderBookResp.suborderbook[j].iQty= %d",pOrderBookResp.suborderbook[j].iQty);
				logDebug2("pOrderBookResp.suborderbook[j].iRemQty = %d",pOrderBookResp.suborderbook[j].iRemQty);
				logDebug2("pOrderBookResp.suborderbook[j].fPrice = %lf",pOrderBookResp.suborderbook[j].fPrice);
				logDebug2("pOrderBookResp.suborderbook[j].fSLPrice= %lf",pOrderBookResp.suborderbook[j].fSLPrice);
				logDebug2("pOrderBookResp.suborderbook[j].sOrderType= %s",pOrderBookResp.suborderbook[j].sOrderType);
				logDebug2("pOrderBookResp.suborderbook[j].fDQQty = %lf",pOrderBookResp.suborderbook[j].fDQQty);
				logDebug2("pOrderBookResp.suborderbook[j].iSerialNo = %d",pOrderBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrderBookResp.suborderbook[j].fTradeQty= %lf",pOrderBookResp.suborderbook[j].fTradeQty);
				logDebug2("pOrderBookResp.suborderbook[j].iStrategyId = %d",pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[j].sValidity = %s",pOrderBookResp.suborderbook[j].sValidity);
				logDebug2("pOrderBookResp.suborderbook[j].fDQQtyRem = %lf",pOrderBookResp.suborderbook[j].fDQQtyRem);
				logDebug2("pOrderBookResp.suborderbook[j].sExchOrderNumber= %s",pOrderBookResp.suborderbook[j].sExchOrderNumber);
				logDebug2("pOrderBookResp.suborderbook[j].sReasonDesc = %s",pOrderBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrderBookResp.suborderbook[j].cProClient = %c",pOrderBookResp.suborderbook[j].cProClient);
				logDebug2("pOrderBookResp.suborderbook[j].fTrdPrice = %lf",pOrderBookResp.suborderbook[j].fTrdPrice);
				logDebug2("pOrderBookResp.suborderbook[j].sGoodTillDaysDate = %s",pOrderBookResp.suborderbook[j].sGoodTillDaysDate);
				logDebug2("pOrderBookResp.suborderbook[j].sEntityId = %s",pOrderBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrderBookResp.suborderbook[j].iStrategyId = %d",pOrderBookResp.suborderbook[j].iStrategyId);
				logDebug2("pOrderBookResp.suborderbook[j].iDateTime = %d",pOrderBookResp.suborderbook[j].iDateTime);
				logDebug2("pOrderBookResp.suborderbook[j].iMainTranscode = %d",pOrderBookResp.suborderbook[j].iMainTranscode);
				logDebug2("pOrderBookResp.suborderbook[j].sMktType = %s",pOrderBookResp.suborderbook[j].sMktType);
			}
			iTempNoOfRec--;
		}
		usleep(100);
		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_BO_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		usleep(100); /** This is done to give a slow response to the Rapid Rupee **/
	}

	logTimestamp("EXIT [fDealerBoOrderBook]");
	return TRUE;

}


BOOL	fSIPOrdBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrdBook");

	struct	VIEW_SIP_ORDER_BOOK_REQ		*pSIPOrderBookReq;

	pSIPOrderBookReq = (struct VIEW_SIP_ORDER_BOOK_REQ *)RcvMsg;

	CHAR	sEntityId[ENTITY_ID_LEN];
	CHAR	sGetSIPOrdBook[MAX_QUERY_SIZE];
	BOOL    iMrgType = FALSE;
	CHAR    sUserType[3];

	strncpy(sEntityId ,pSIPOrderBookReq->sEntityId,ENTITY_ID_LEN);
	logDebug2("sEntityId %s",pSIPOrderBookReq->sEntityId);

	memset(sGetSIPOrdBook,'\0',MAX_QUERY_SIZE);
	sprintf(sGetSIPOrdBook,"SELECT ENTITY_TYPE,ENTITY_MANAGER_TYPE from ENTITY_MASTER WHERE ENTITY_CODE = ltrim(rtrim(\"%s\"));",sEntityId);

	logDebug2("Query[%s]",sGetSIPOrdBook);

	if(mysql_query(DBQueries,sGetSIPOrdBook) != SUCCESS)
	{
		logSqlFatal("ERROR IN fGetSIPOrderBook QUERY.");
		sql_Error(DBQueries);
	}

	Res = mysql_store_result(DBQueries);

	if(Row = mysql_fetch_row(Res))
	{
		strncpy(sUserType,Row[0],3);
		if(!strncmp(Row[1],"BR",2))
		{
			iMrgType = TRUE;
		}
	}

	logDebug2("USER TYPE is :%s:",sUserType );

	if(!strcmp(sUserType ,"D") )
	{
		logDebug2("Going to call fDealerSIPOrderBook");
		fDealerSIPOrderBook(RcvMsg,iMrgType);
		return TRUE;

	}
	if(!strcmp(sUserType ,"C"))
	{
		logDebug2("Going to call fClientSIPOrderBook-----");
		fSIPOrderBook(RcvMsg);
		return TRUE;

	}
	logTimestamp("Exit : fSIPOrdBook");
	return TRUE;
}

BOOL	fDealerSIPOrderBook(CHAR *RcvMsg,BOOL iMrgType)
{
	logTimestamp("Entry : fDealerSIPOrderBook");

	struct  VIEW_SIP_ORDER_BOOK_REQ           	*pOrdBookReq;
	struct  VIEW_SIP_ORDER_BOOK_RESP          	pOrdBookResp;
	struct  VIEW_COMMON_HDR_RESP                    pOrdBookHedResp;

	CHAR    sSIPOrdBkQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSIPSubOrdBKQry[QUERY_SIZE];

	pOrdBookReq = (struct VIEW_SIP_ORDER_BOOK_REQ *)RcvMsg;

	CHAR            sWhere_Clause[QUERY_SIZE];
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdBkQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	logDebug2("pOrdBookReq->ReqHeader.sExcgId = :%s:",pOrdBookReq->ReqHeader.sExcgId);
	logDebug2("pOrdBookReq->ReqHeader.cSegment = :%c:",pOrdBookReq->ReqHeader.cSegment);
	logDebug2("pOrdBookReq->ReqHeader.iUserId = :%llu:",pOrdBookReq->ReqHeader.iUserId);
	logDebug2("pOrdBookReq->sSymbol = :%s:",pOrdBookReq->sSymbol);
	logDebug2("pOrdBookReq->sStatus = :%s:",pOrdBookReq->sStatus);
	logDebug2("pOrdBookReq->sStartDate = :%s:",pOrdBookReq->sStartDate);
	logDebug2("pOrdBookReq->sExpiry = :%s:",pOrdBookReq->sExpiryDate);
	logDebug2("pOrdBookReq->cProduct = :%c:",pOrdBookReq->cProduct);
	logDebug2("pOrdBookReq->sClientId = :%s:",pOrdBookReq->sClientId);
	logDebug2("pOrdBookReq->sPlacedBy = :%s:",pOrdBookReq->sPlacedBy);
	logDebug2("pOrdBookReq->sEntityId = :%s:",pOrdBookReq->sEntityId);
	logDebug2("pOrdBookReq->sSource = :%s:",pOrdBookReq->sSource);

	if(strcmp(pOrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND EXCH = \"%s\"",pOrdBookReq->ReqHeader.sExcgId);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pOrdBookReq->sSymbol);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStatus,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND STATUS = \"%s\"",pOrdBookReq->sStatus);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStartDate,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sStartDate = %s",pOrdBookReq->sStartDate);
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND DATE (START_DATE_TIME) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sStartDate);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sExpiryDate,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sExpiryDate = %s",pOrdBookReq->sExpiryDate);
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND DATE (END_DATE_TIME) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sExpiryDate);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(pOrdBookReq->cProduct != SEL_ALL)
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		if(pOrdBookReq->cProduct == PROD_INTRADAY )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_INTRADAY);
		if(pOrdBookReq->cProduct == PROD_MARGIN )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_MARGIN);
		if(pOrdBookReq->cProduct == PROD_CNC )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_CNC);

		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);

	}
	if(strcmp(pOrdBookReq->sPlacedBy,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND ENTITY_ID LIKE \"%s\"",pOrdBookReq->sPlacedBy);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSource,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND SOURCE_FLG = \"%s\"",pOrdBookReq->sSource);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause8 = %s",sWhere_Clause);
	}

	if(iMrgType == TRUE)
	{
		if(strcmp(pOrdBookReq->sClientId,SELECT_ALL) == 0)
		{
			sprintf(sWhere_Clause," AND CLIENT_ID IN (select E.ENTITY_CODE\
				FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
					union select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(rtrim(\"%s\")))\
				ORDER BY ORDER_DATE_TIME DESC;",pOrdBookReq->sEntityId,pOrdBookReq->sEntityId);
		}
		else
		{
			sprintf(sWhere_Clause," AND CLIENT_ID IN (select E.ENTITY_CODE\
				FROM ENTITY_MASTER E WHERE E.ENTITY_MANAGER_CODE = ltrim(rtrim(\"%s\")) \
					union select C.EDM_CLIENT_ID FROM ENTITY_DEALER_MAPPING C WHERE C.EDM_DEALER_ID = ltrim(rtrim(\"%s\")) \
					AND C.EDM_CLIENT_ID = ltrim(rtrim(\"%s\")))\
				ORDER BY ORDER_DATE_TIME DESC;",pOrdBookReq->sEntityId,pOrdBookReq->sEntityId,pOrdBookReq->sClientId);
		}

	}
	else
	{
		if(strcmp(pOrdBookReq->sClientId,SELECT_ALL) == 0)
		{
			sprintf(sWhere_Clause," ORDER BY ORDER_DATE_TIME DESC;");
		}
		else
		{
			sprintf(sWhere_Clause," AND CLIENT_ID = ltrim(rtrim(\"%s\")) ORDER BY ORDER_DATE_TIME DESC; ",pOrdBookReq->sClientId);

		}

	}
	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	sprintf(sSIPOrdBkQry,"SELECT CLIENT_ID, ORDER_NUMBER, EXCH, ORDER_DATE_TIME, START_DATE_TIME, END_DATE_TIME, FREQUENCY, \
			BUY_SELL, PRODUCT, SEGMENT, SCRIP_CODE, SYMBOL, PERIOD, TOTAL_QTY, ENTITY_ID, SOURCE_FLG, STATUS, ORDER_VALIDITY, \
			REASON_DESCRIPTION, USER_TYPE,SERIAL_NO,LAST_TRIGGER_DATE,NEXT_TRIGGER_DATE, \
			PAN_NO,PARTICIPANT_TYPE,SETTLOR,MKT_PROTECT_FLG,MKT_PROTECT_VAL,GTC_FLG,ENCASH_FLG,AMOUNT \
			FROM (SELECT `SIP_CLIENT_ID` AS `CLIENT_ID`,`SIP_ORDER_NO` AS `ORDER_NUMBER`,`SIP_EXCH_ID` AS `EXCH`,\
				DATE_FORMAT(`SIP_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`,\
				DATE_FORMAT(`SIP_START_DATE`, '%%Y-%%m-%%d %%T') AS `START_DATE_TIME`,\
				DATE_FORMAT(`SIP_EXPIRE_DATE`, '%%Y-%%m-%%d %%T') AS `END_DATE_TIME`, (CASE `SIP_FREQUENCY` WHEN 'D' THEN 'Daily' WHEN 'W' THEN 'Weekly'\
					WHEN 'M' THEN 'Monthly' END) AS `FREQUENCY`,(CASE `SIP_BUY_SELL_IND` WHEN 'B' THEN 'SIP' WHEN 'S' THEN 'SWP' END) AS `BUY_SELL`,\
				(CASE `SIP_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'I' THEN 'INTRADAY' WHEN 'M' THEN 'MARGIN' END) AS `PRODUCT`,\
				`SIP_SEGMENT` AS `SEGMENT`,`SIP_SCRIP_CODE` AS `SCRIP_CODE`,`SIP_SYMBOL` AS `SYMBOL`,`SIP_PERIOD` AS `PERIOD`,\
				`SIP_TOTAL_QTY` AS `TOTAL_QTY`,`SIP_ENTITY_ID` AS `ENTITY_ID`,(CASE `SIP_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' \
					WHEN 'W' THEN 'WEB' WHEN 'A' THEN 'ADMIN' WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' \
					WHEN 'H' THEN 'HELPDESK' WHEN 'E' THEN 'EXCHANGE' WHEN 'I' THEN 'ITS' END) AS `SOURCE_FLG`,\
				(CASE WHEN (`SIP_MSG_CODE` IN ('3000' , '3040')) THEN 'CONFIRM' WHEN (`SIP_MSG_CODE` = '3050') THEN 'CANCELLED'\
				 WHEN (`SIP_MSG_CODE` = '3030') THEN 'PAUSED' END) AS `STATUS`,(CASE `SIP_VALIDITY` WHEN '0' THEN 'DAY' \
				 WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO'	WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS `ORDER_VALIDITY`,\
				ifnull(nullif(`SIP_REASON_DESCRIPTION`,''),'NA') AS `REASON_DESCRIPTION`,\
				(CASE `SIP_USER_TYPE` WHEN 'C' THEN 'Client' WHEN 'D' THEN 'Dealer' WHEN 'A' THEN 'Admin' WHEN 'S' THEN 'Super Admin' END )AS `USER_TYPE`, \
				`SIP_SERIAL_NO` AS `SERIAL_NO`,ifnull(nullif(`SIP_LTD`,''),'NA') AS `LAST_TRIGGER_DATE`,\
				(CASE WHEN (`SIP_MSG_CODE` = '3030') THEN 'NA' WHEN (`SIP_MSG_CODE` = '3050') THEN 'NA' \
				 ELSE IFNULL(NULLIF(`SIP_NTD`, ''), 'NA') END) AS `NEXT_TRIGGER_DATE`, \
				`SIP_PAN_NO` AS `PAN_NO` ,`SIP_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`SIP_SETTLOR` AS `SETTLOR`, \
				`SIP_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,`SIP_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,\
				`SIP_GTC_FLG` AS `GTC_FLG`, `SIP_ENCASH_FLG` AS `ENCASH_FLG`,`SIP_AMOUNT` AS `AMOUNT` FROM SIP_ORDERS AS `A` \
				WHERE A.SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO) FROM SIP_ORDERS B WHERE B.SIP_ORDER_NO = A.SIP_ORDER_NO)) AS SipOrderBook\
				WHERE 1=1 %s ",sWhere_Clause);

	printf("sSIPOrdBkQry = %s",sSIPOrdBkQry);

	if(mysql_query(DBQueries,sSIPOrdBkQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdBkQry.");
		sql_Error(DBQueries);
		return FALSE;
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdBookHedResp.IntRespHeader.iSeqNo = 0;
	pOrdBookHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdBookHedResp.IntRespHeader.iErrorId = 0;
	pOrdBookHedResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORDER_BOOK_HED_RESP;
	pOrdBookHedResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
	pOrdBookHedResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;
	pOrdBookHedResp.cMsgType = 'H';
	pOrdBookHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgLength = %d",pOrdBookHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgCode = %d",pOrdBookHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdBookHedResp.IntRespHeader.iUserId = %llu",pOrdBookHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdBookHedResp.IntRespHeader.cSource = %c",pOrdBookHedResp.IntRespHeader.cSource);
	logDebug2("pOrdBookHedResp.iNoofRec = %d",pOrdBookHedResp.iNoofRec);

	logDebug2("pOrdBookReq->ReqHeader.iUserId = %llu",pOrdBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iIntActiveToRelDirQ,(CHAR *)&pOrdBookHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdBookResp,'\0',sizeof(struct VIEW_SIP_ORDER_BOOK_RESP));
		pOrdBookResp.IntRespHeader.iSeqNo = 0;
		pOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ORDER_BOOK_RESP);
		pOrdBookResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORD_BOOK_RESP;
		pOrdBookResp.IntRespHeader.iErrorId = 0;
		pOrdBookResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
		pOrdBookResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;

		logDebug2("pOrdBookResp.IntRespHeader.cSource = %c",pOrdBookResp.IntRespHeader.cSource);

		if(iTempNoOfRec <= 1)
		{
			pOrdBookResp.cMsgType = 'T';
		}
		else
		{
			pOrdBookResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrdBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				pOrdBookResp.suborderbook[j].fOrderNo = atof(Row[1]);
				strncpy(pOrdBookResp.suborderbook[j].sExcgId,Row[2] ,EXCHANGE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sInternalDate,Row[3] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sStartDate,Row[4] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sStartEnd,Row[5] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sfrequency,Row[6] ,FREQUENCY_LEN);
				memset(pOrdBookResp.suborderbook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sBuySellInd,Row[7],BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sProduct,Row[8] ,PRODUCT_LEN);
				pOrdBookResp.suborderbook[j].cSegment = Row[9][0];
				strncpy(pOrdBookResp.suborderbook[j].sSecurityID,Row[10] ,SECURITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sSymbol,Row[11] ,SECURITY_ID_LEN);
				pOrdBookResp.suborderbook[j].iForPeriod = atoi(Row[12]);
				pOrdBookResp.suborderbook[j].fQty = atof(Row[13]);
				strncpy(pOrdBookResp.suborderbook[j].sEntityId , Row[14],ENTITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sSourceFlg, Row[15],SOURCE_FLG_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sStatus,Row[16],ORDER_STATUS);
				strncpy(pOrdBookResp.suborderbook[j].sValidity,Row[17] ,VALIDITY_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sReasonDesc, Row[18],DB_REASON_DESC_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sUserType,Row[19],USER_TYPE_LEN);
				pOrdBookResp.suborderbook[j].iSerialNo = atoi(Row[20]);
				strncpy(pOrdBookResp.suborderbook[j].sLastTriggerDate,Row[21],USER_TYPE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sNextTriggerDate,Row[22],USER_TYPE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sPanID,Row[23],INT_PAN_LEN);
				pOrdBookResp.suborderbook[j].cParticipantType = Row[24][0];
				strncpy(pOrdBookResp.suborderbook[j].sSettlor,Row[25],SETTLOR_LEN);
				pOrdBookResp.suborderbook[j].cMarkProFlag = Row[26][0];
				pOrdBookResp.suborderbook[j].fMarkProVal = atof(Row[27]);
				pOrdBookResp.suborderbook[j].cGTCFlag = Row[28][0];
				pOrdBookResp.suborderbook[j].cEncashFlag = Row[29][0];
				pOrdBookResp.suborderbook[j].fPrice = atof(Row[30]);

				logDebug2("pOrdBookResp.suborderbook[%d].sClientId = %s",j,pOrdBookResp.suborderbook[j].sClientId);
				logDebug2("pOrdBookResp.suborderbook[%d].fOrderNo = %lf",j,pOrdBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sExcgId = %s",j,pOrdBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrdBookResp.suborderbook[%d].sInternalDate = %s",j,pOrdBookResp.suborderbook[j].sInternalDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sStartDate = %s",j,pOrdBookResp.suborderbook[j].sStartDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sStartEnd = %s",j,pOrdBookResp.suborderbook[j].sStartEnd);
				logDebug2("pOrdBookResp.suborderbook[%d].sfrequency = %s",j,pOrdBookResp.suborderbook[j].sfrequency);
				logDebug2("pOrdBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrdBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdBookResp.suborderbook[%d].sProduct = %s",j,pOrdBookResp.suborderbook[j].sProduct);
				logDebug2("pOrdBookResp.suborderbook[%d].cSegment = %c",j,pOrdBookResp.suborderbook[j].cSegment);
				logDebug2("pOrdBookResp.suborderbook[%d].sSecurityID = %s",j,pOrdBookResp.suborderbook[j].sSecurityID);
				logDebug2("pOrdBookResp.suborderbook[%d].sSymbol = %s",j,pOrdBookResp.suborderbook[j].sSymbol);
				logDebug2("pOrdBookResp.suborderbook[%d].iForPeriod = %d",j,pOrdBookResp.suborderbook[j].iForPeriod);
				logDebug2("pOrdBookResp.suborderbook[%d].fQty = %d",j,pOrdBookResp.suborderbook[j].fQty);
				logDebug2("pOrdBookResp.suborderbook[%d].sEntityId = %s",j,pOrdBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrdBookResp.suborderbook[%d].sSourceFlg = %s",j,pOrdBookResp.suborderbook[j].sSourceFlg);
				logDebug2("pOrdBookResp.suborderbook[%d].sStatus = %s",j,pOrdBookResp.suborderbook[j].sStatus);
				logDebug2("pOrdBookResp.suborderbook[%d].sValidity = %s",j,pOrdBookResp.suborderbook[j].sValidity);
				logDebug2("pOrdBookResp.suborderbook[%d].sReasonDesc = %s",j,pOrdBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrdBookResp.suborderbook[%d].sUserType = %s",j,pOrdBookResp.suborderbook[j].sUserType);
				logDebug2("pOrdBookResp.suborderbook[%d].iSerialNo = %d",j,pOrdBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sLastTriggerDate = %s",j,pOrdBookResp.suborderbook[j].sLastTriggerDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sNextTriggerDate = %s",j,pOrdBookResp.suborderbook[j].sNextTriggerDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sPanID = %s",j,pOrdBookResp.suborderbook[j].sPanID);
				logDebug2("pOrdBookResp.suborderbook[%d].cParticipantType = %c",j,pOrdBookResp.suborderbook[j].cParticipantType);
				logDebug2("pOrdBookResp.suborderbook[%d].sSettlor = %s",j,pOrdBookResp.suborderbook[j].sSettlor);
				logDebug2("pOrdBookResp.suborderbook[%d].cMarkProFlag = %c",j,pOrdBookResp.suborderbook[j].cMarkProFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrdBookResp.suborderbook[j].fMarkProVal);
				logDebug2("pOrdBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrdBookResp.suborderbook[j].cGTCFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrdBookResp.suborderbook[j].cEncashFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fPrice = %lf",j,pOrdBookResp.suborderbook[j].fPrice);

			}

		}

		if(( WriteMsgQ(iIntActiveToRelDirQ,(CHAR *)&pOrdBookResp,sizeof(struct VIEW_SIP_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iIntActiveToRelDirQ);
			return FALSE;
		}

		iTempNoOfRec--;
		usleep(5000);
	}

	logTimestamp("Exit : fDealerSIPOrderBook");
	return TRUE;
}	

BOOL	fSIPOrderBook(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrderBook");

	struct  VIEW_SIP_ORDER_BOOK_REQ           	*pOrdBookReq;
	struct  VIEW_SIP_ORDER_BOOK_RESP          	pOrdBookResp;
	struct  VIEW_COMMON_HDR_RESP                    pOrdBookHedResp;

	CHAR    sSIPOrdBkQry[DOUBLE_MAX_QUERY_SIZE];
	CHAR    sSIPSubOrdBKQry[QUERY_SIZE];

	pOrdBookReq = (struct VIEW_SIP_ORDER_BOOK_REQ *)RcvMsg;

	CHAR            sWhere_Clause[QUERY_SIZE];
	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdBkQry,'\0',DOUBLE_MAX_QUERY_SIZE);
	memset(sWhere_Clause,'\0',QUERY_SIZE);

	logDebug2("pOrdBookReq->ReqHeader.sExcgId = :%s:",pOrdBookReq->ReqHeader.sExcgId);
	logDebug2("pOrdBookReq->ReqHeader.cSegment = :%c:",pOrdBookReq->ReqHeader.cSegment);
	logDebug2("pOrdBookReq->ReqHeader.iUserId = :%llu:",pOrdBookReq->ReqHeader.iUserId);
	logDebug2("pOrdBookReq->sSymbol = :%s:",pOrdBookReq->sSymbol);
	logDebug2("pOrdBookReq->sStatus = :%s:",pOrdBookReq->sStatus);
	logDebug2("pOrdBookReq->sStartDate = :%s:",pOrdBookReq->sStartDate);
	logDebug2("pOrdBookReq->sExpiry = :%s:",pOrdBookReq->sExpiryDate);
	logDebug2("pOrdBookReq->cProduct = :%c:",pOrdBookReq->cProduct);
	logDebug2("pOrdBookReq->sClientId = :%s:",pOrdBookReq->sClientId);
	logDebug2("pOrdBookReq->sPlacedBy = :%s:",pOrdBookReq->sPlacedBy);
	logDebug2("pOrdBookReq->sEntityId = :%s:",pOrdBookReq->sEntityId);
	logDebug2("pOrdBookReq->sSource = :%s:",pOrdBookReq->sSource);


	if(strcmp(pOrdBookReq->ReqHeader.sExcgId,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND EXCH = \"%s\"",pOrdBookReq->ReqHeader.sExcgId);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause1 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSymbol,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry, " AND SUBSTRING_INDEX(SYMBOL,'-',1) LIKE \"%s\"",pOrdBookReq->sSymbol);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause2 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStatus,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND STATUS = \"%s\"",pOrdBookReq->sStatus);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause3 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sStartDate,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sStartDate = %s",pOrdBookReq->sStartDate);
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND DATE (START_DATE_TIME) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sStartDate);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause4 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sExpiryDate,SELECT_ALL))
	{
		logDebug2("pOrdBookReq->sExpiryDate = %s",pOrdBookReq->sExpiryDate);
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND DATE (END_DATE_TIME) = date_format(date(STR_TO_DATE(\"%s\",\'%%d-%%M-%%Y %%r\')),\'%%Y-%%m-%%d %%H:%%i:%%S\')",\
				pOrdBookReq->sExpiryDate);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause5 = %s",sWhere_Clause);
	}
	if(pOrdBookReq->cProduct != SEL_ALL)
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		if(pOrdBookReq->cProduct == PROD_INTRADAY )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_INTRADAY);
		if(pOrdBookReq->cProduct == PROD_MARGIN )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_MARGIN);
		if(pOrdBookReq->cProduct == PROD_CNC )
			sprintf(sSIPSubOrdBKQry," AND PRODUCT = \"%s\"",FE_PROD_CNC);

		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause6 = %s",sWhere_Clause);

	}
	if(strcmp(pOrdBookReq->sPlacedBy,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND ENTITY_ID LIKE \"%s\"",pOrdBookReq->sPlacedBy);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause7 = %s",sWhere_Clause);
	}
	if(strcmp(pOrdBookReq->sSource,SELECT_ALL))
	{
		memset(sSIPSubOrdBKQry,'\0',QUERY_SIZE);
		sprintf(sSIPSubOrdBKQry," AND SOURCE_FLG = \"%s\"",pOrdBookReq->sSource);
		logDebug2("sSIPSubOrdBKQry = %s",sSIPSubOrdBKQry);
		strcat(sWhere_Clause,sSIPSubOrdBKQry);
		logDebug2("sWhere_Clause8 = %s",sWhere_Clause);
	}
	logDebug2("Final Where_Clause = %s",sWhere_Clause);

	sprintf(sSIPOrdBkQry,"SELECT CLIENT_ID, ORDER_NUMBER, EXCH, ORDER_DATE_TIME, START_DATE_TIME, END_DATE_TIME, FREQUENCY, \
			BUY_SELL, PRODUCT, SEGMENT, SCRIP_CODE, SYMBOL, PERIOD, TOTAL_QTY, ENTITY_ID, SOURCE_FLG, STATUS, ORDER_VALIDITY, \
			REASON_DESCRIPTION, USER_TYPE,SERIAL_NO,LAST_TRIGGER_DATE,NEXT_TRIGGER_DATE, \
			PAN_NO,PARTICIPANT_TYPE,SETTLOR,MKT_PROTECT_FLG,MKT_PROTECT_VAL,GTC_FLG,ENCASH_FLG,AMOUNT \
			FROM (SELECT `SIP_CLIENT_ID` AS `CLIENT_ID`,`SIP_ORDER_NO` AS `ORDER_NUMBER`,`SIP_EXCH_ID` AS `EXCH`,\
				DATE_FORMAT(`SIP_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`,\
				DATE_FORMAT(`SIP_START_DATE`, '%%Y-%%m-%%d %%T') AS `START_DATE_TIME`,\
				DATE_FORMAT(`SIP_EXPIRE_DATE`, '%%Y-%%m-%%d %%T') AS `END_DATE_TIME`,(CASE `SIP_FREQUENCY` WHEN 'D' THEN 'Daily' WHEN 'W' THEN 'Weekly'\
					WHEN 'M' THEN 'Monthly' END) AS `FREQUENCY`,(CASE `SIP_BUY_SELL_IND` WHEN 'B' THEN 'SIP' WHEN 'S' THEN 'SWP' END) AS `BUY_SELL`,\
				(CASE `SIP_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'I' THEN 'INTRADAY' WHEN 'M' THEN 'MARGIN' END) AS `PRODUCT`,\
				`SIP_SEGMENT` AS `SEGMENT`,`SIP_SCRIP_CODE` AS `SCRIP_CODE`,`SIP_SYMBOL` AS `SYMBOL`,`SIP_PERIOD` AS `PERIOD`,\
				`SIP_TOTAL_QTY` AS `TOTAL_QTY`,`SIP_ENTITY_ID` AS `ENTITY_ID`,(CASE `SIP_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' WHEN 'W' \
					THEN 'WEB' WHEN 'A' THEN 'ADMIN' WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' \
					WHEN 'H' THEN 'HELPDESK' WHEN 'E' THEN 'EXCHANGE' WHEN 'I' THEN 'ITS' END) AS `SOURCE_FLG`,\
				(CASE WHEN (`SIP_MSG_CODE` IN ('3000' , '3040')) THEN 'CONFIRM' WHEN (`SIP_MSG_CODE` = '3050') THEN 'CANCELLED'\
				 WHEN (`SIP_MSG_CODE` = '3030') THEN 'PAUSED' END) AS `STATUS`,(CASE `SIP_VALIDITY` WHEN '0' THEN 'DAY' \
				 WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO'	WHEN '3' THEN 'IOC' ELSE 'EOS' END) AS `ORDER_VALIDITY`,\
				ifnull(nullif(`SIP_REASON_DESCRIPTION`,''),'NA') AS `REASON_DESCRIPTION`,\
				(CASE `SIP_USER_TYPE` WHEN 'C' THEN 'Client' WHEN 'D' THEN 'Dealer' WHEN 'A' THEN 'Admin' WHEN 'S' THEN 'Super Admin' END )AS `USER_TYPE`, \
				`SIP_SERIAL_NO` AS `SERIAL_NO`,ifnull(nullif(`SIP_LTD`,''),'NA') AS `LAST_TRIGGER_DATE`,\
				(CASE WHEN (`SIP_MSG_CODE` = '3030') THEN 'NA' WHEN (`SIP_MSG_CODE` = '3050') THEN 'NA' \
				 ELSE IFNULL(NULLIF(`SIP_NTD`, ''), 'NA') END) AS `NEXT_TRIGGER_DATE`, \
				`SIP_PAN_NO` AS `PAN_NO` ,`SIP_PARTICIPANT_TYPE` AS `PARTICIPANT_TYPE`,`SIP_SETTLOR` AS `SETTLOR`, \
				`SIP_MKT_PROTECT_FLG` AS `MKT_PROTECT_FLG`,`SIP_MKT_PROTECT_VAL` AS `MKT_PROTECT_VAL`,\
				`SIP_GTC_FLG` AS `GTC_FLG`, `SIP_ENCASH_FLG` AS `ENCASH_FLG`,`SIP_AMOUNT` AS `AMOUNT` FROM SIP_ORDERS AS `A` \
				WHERE A.SIP_SERIAL_NO = (SELECT MAX(SIP_SERIAL_NO) FROM SIP_ORDERS B WHERE B.SIP_ORDER_NO = A.SIP_ORDER_NO)) AS SipOrderBook\
				WHERE 1=1 AND CLIENT_ID = \"%s\" %s ORDER BY ORDER_DATE_TIME DESC; ",pOrdBookReq->sClientId,sWhere_Clause);

	printf("sSIPOrdBkQry = %s",sSIPOrdBkQry);

	if(mysql_query(DBQueries,sSIPOrdBkQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdBkQry.");
		sql_Error(DBQueries);
		return FALSE;
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdBookHedResp.IntRespHeader.iSeqNo = 0;
	pOrdBookHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdBookHedResp.IntRespHeader.iErrorId = 0;
	pOrdBookHedResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORDER_BOOK_HED_RESP;
	pOrdBookHedResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
	pOrdBookHedResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;
	pOrdBookHedResp.cMsgType = 'H';
	pOrdBookHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgLength = %d",pOrdBookHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdBookHedResp.IntRespHeader.iMsgCode = %d",pOrdBookHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdBookHedResp.IntRespHeader.iUserId = %llu",pOrdBookHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdBookHedResp.IntRespHeader.cSource = %c",pOrdBookHedResp.IntRespHeader.cSource);
	logDebug2("pOrdBookHedResp.iNoofRec = %d",pOrdBookHedResp.iNoofRec);

	logDebug2("pOrdBookReq->ReqHeader.iUserId = %llu",pOrdBookReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pOrdBookReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iIntActiveToRelDirQ ,(CHAR *)&pOrdBookHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdBookResp,'\0',sizeof(struct VIEW_SIP_ORDER_BOOK_RESP));
		pOrdBookResp.IntRespHeader.iSeqNo = 0;
		pOrdBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ORDER_BOOK_RESP);
		pOrdBookResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORD_BOOK_RESP;
		pOrdBookResp.IntRespHeader.iErrorId = 0;
		pOrdBookResp.IntRespHeader.iUserId = pOrdBookReq->ReqHeader.iUserId;
		pOrdBookResp.IntRespHeader.cSource = pOrdBookReq->ReqHeader.cSource;

		logDebug2("pOrdBookResp.IntRespHeader.cSource = %c",pOrdBookResp.IntRespHeader.cSource);

		if(iTempNoOfRec <= 1)
		{
			pOrdBookResp.cMsgType = 'T';
		}
		else
		{
			pOrdBookResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrdBookResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				pOrdBookResp.suborderbook[j].fOrderNo = atof(Row[1]);
				strncpy(pOrdBookResp.suborderbook[j].sExcgId,Row[2] ,EXCHANGE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sInternalDate,Row[3] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sStartDate,Row[4] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sStartEnd,Row[5] ,DATE_LENGTH);
				strncpy(pOrdBookResp.suborderbook[j].sfrequency,Row[6] ,FREQUENCY_LEN);
				memset(pOrdBookResp.suborderbook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sBuySellInd,Row[7],BUY_SELL_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sProduct,Row[8] ,PRODUCT_LEN);
				pOrdBookResp.suborderbook[j].cSegment = Row[9][0];
				strncpy(pOrdBookResp.suborderbook[j].sSecurityID,Row[10] ,SECURITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sSymbol,Row[11] ,SECURITY_ID_LEN);
				pOrdBookResp.suborderbook[j].iForPeriod = atoi(Row[12]);
				pOrdBookResp.suborderbook[j].fQty = atof(Row[13]);
				strncpy(pOrdBookResp.suborderbook[j].sEntityId , Row[14],ENTITY_ID_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sSourceFlg, Row[15],SOURCE_FLG_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sStatus,Row[16],ORDER_STATUS);
				strncpy(pOrdBookResp.suborderbook[j].sValidity,Row[17] ,VALIDITY_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sReasonDesc, Row[18],DB_REASON_DESC_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sUserType,Row[19],USER_TYPE_LEN);
				pOrdBookResp.suborderbook[j].iSerialNo = atoi(Row[20]);
				strncpy(pOrdBookResp.suborderbook[j].sLastTriggerDate,Row[21],USER_TYPE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sNextTriggerDate,Row[22],USER_TYPE_LEN);
				strncpy(pOrdBookResp.suborderbook[j].sPanID,Row[23],INT_PAN_LEN);
				pOrdBookResp.suborderbook[j].cParticipantType = Row[24][0];
				strncpy(pOrdBookResp.suborderbook[j].sSettlor,Row[25],SETTLOR_LEN);
				pOrdBookResp.suborderbook[j].cMarkProFlag = Row[26][0];
				pOrdBookResp.suborderbook[j].fMarkProVal = atof(Row[27]);
				pOrdBookResp.suborderbook[j].cGTCFlag = Row[28][0];
				pOrdBookResp.suborderbook[j].cEncashFlag = Row[29][0];
				pOrdBookResp.suborderbook[j].fPrice = atof(Row[30]);

				logDebug2("pOrdBookResp.suborderbook[%d].sClientId = %s",j,pOrdBookResp.suborderbook[j].sClientId);
				logDebug2("pOrdBookResp.suborderbook[%d].fOrderNo = %lf",j,pOrdBookResp.suborderbook[j].fOrderNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sExcgId = %s",j,pOrdBookResp.suborderbook[j].sExcgId);
				logDebug2("pOrdBookResp.suborderbook[%d].sInternalDate = %s",j,pOrdBookResp.suborderbook[j].sInternalDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sStartDate = %s",j,pOrdBookResp.suborderbook[j].sStartDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sStartEnd = %s",j,pOrdBookResp.suborderbook[j].sStartEnd);
				logDebug2("pOrdBookResp.suborderbook[%d].sfrequency = %s",j,pOrdBookResp.suborderbook[j].sfrequency);
				logDebug2("pOrdBookResp.suborderbook[%d].sBuySellInd = %s",j,pOrdBookResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdBookResp.suborderbook[%d].sProduct = %s",j,pOrdBookResp.suborderbook[j].sProduct);
				logDebug2("pOrdBookResp.suborderbook[%d].cSegment = %c",j,pOrdBookResp.suborderbook[j].cSegment);
				logDebug2("pOrdBookResp.suborderbook[%d].sSecurityID = %s",j,pOrdBookResp.suborderbook[j].sSecurityID);
				logDebug2("pOrdBookResp.suborderbook[%d].sSymbol = %s",j,pOrdBookResp.suborderbook[j].sSymbol);
				logDebug2("pOrdBookResp.suborderbook[%d].iForPeriod = %d",j,pOrdBookResp.suborderbook[j].iForPeriod);
				logDebug2("pOrdBookResp.suborderbook[%d].fQty = %d",j,pOrdBookResp.suborderbook[j].fQty);
				logDebug2("pOrdBookResp.suborderbook[%d].sEntityId = %s",j,pOrdBookResp.suborderbook[j].sEntityId);
				logDebug2("pOrdBookResp.suborderbook[%d].sSourceFlg = %s",j,pOrdBookResp.suborderbook[j].sSourceFlg);
				logDebug2("pOrdBookResp.suborderbook[%d].sStatus = %s",j,pOrdBookResp.suborderbook[j].sStatus);
				logDebug2("pOrdBookResp.suborderbook[%d].sValidity = %s",j,pOrdBookResp.suborderbook[j].sValidity);
				logDebug2("pOrdBookResp.suborderbook[%d].sReasonDesc = %s",j,pOrdBookResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrdBookResp.suborderbook[%d].sUserType = %s",j,pOrdBookResp.suborderbook[j].sUserType);
				logDebug2("pOrdBookResp.suborderbook[%d].iSerialNo = %d",j,pOrdBookResp.suborderbook[j].iSerialNo);
				logDebug2("pOrdBookResp.suborderbook[%d].sLastTriggerDate = %s",j,pOrdBookResp.suborderbook[j].sLastTriggerDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sNextTriggerDate = %s",j,pOrdBookResp.suborderbook[j].sNextTriggerDate);
				logDebug2("pOrdBookResp.suborderbook[%d].sPanID = %s",j,pOrdBookResp.suborderbook[j].sPanID);
				logDebug2("pOrdBookResp.suborderbook[%d].cParticipantType = %c",j,pOrdBookResp.suborderbook[j].cParticipantType);
				logDebug2("pOrdBookResp.suborderbook[%d].sSettlor = %s",j,pOrdBookResp.suborderbook[j].sSettlor);
				logDebug2("pOrdBookResp.suborderbook[%d].cMarkProFlag = %c",j,pOrdBookResp.suborderbook[j].cMarkProFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrdBookResp.suborderbook[j].fMarkProVal);
				logDebug2("pOrdBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrdBookResp.suborderbook[j].cGTCFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrdBookResp.suborderbook[j].cEncashFlag);
				logDebug2("pOrdBookResp.suborderbook[%d].fPrice = %lf",j,pOrdBookResp.suborderbook[j].fPrice);
			}

		}

		if(( WriteMsgQ(iIntActiveToRelDirQ,(CHAR *)&pOrdBookResp,sizeof(struct VIEW_SIP_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iIntActiveToRelDirQ);
			return FALSE;
		}

		iTempNoOfRec--;
		usleep(5000);
	}

	logTimestamp("Exit : fSIPOrderBook");
	return TRUE;
}

BOOL    fSIPOrdDetails(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrdDetails");

	struct  VIEW_SIP_ORDER_DETAILS_REQ		*pOrdDetlsReq;
	struct  VIEW_SIP_ORDER_BOOK_RESP          	pOrdDetlsResp;
	struct  VIEW_COMMON_HDR_RESP                    pOrdDetlsHedResp;

	CHAR    sSIPOrdDetlsQry[DOUBLE_MAX_QUERY_SIZE];

	pOrdDetlsReq = (struct VIEW_SIP_ORDER_DETAILS_REQ *)RcvMsg;

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdDetlsQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	logDebug2("pOrdDetlsReq->fOrderNo = %lf",pOrdDetlsReq->fOrderNo);
	logDebug2("pOrdDetlsReq->sClientId = %s",pOrdDetlsReq->sClientId);

	sprintf(sSIPOrdDetlsQry,"SELECT `SIP_CLIENT_ID` AS `CLIENT_ID`,`SIP_ORDER_NO` AS `ORDER_NUMBER`,`SIP_EXCH_ID` AS `EXCH`,\
			DATE_FORMAT(`SIP_INTERNAL_ENTRY_DATE`, '%%Y-%%m-%%d %%T') AS `ORDER_DATE_TIME`,\
			DATE_FORMAT(`SIP_START_DATE`, '%%Y-%%m-%%d %%T') AS `START_DATE_TIME`,\
			DATE_FORMAT(`SIP_EXPIRE_DATE`, '%%Y-%%m-%%d %%T') AS `END_DATE_TIME`,(CASE `SIP_FREQUENCY` WHEN 'D' THEN 'Daily' \
				WHEN 'W' THEN 'Weekly' WHEN 'M' THEN 'Monthly' END) AS `FREQUENCY`,(CASE `SIP_BUY_SELL_IND` WHEN 'B' THEN 'SIP'\
					WHEN 'S' THEN 'SWP' END) AS `BUY_SELL`,(CASE `SIP_PRODUCT_ID` WHEN 'C' THEN 'CNC' WHEN 'I' THEN 'INTRADAY'\
						WHEN 'M' THEN 'MARGIN' END) AS `PRODUCT`,`SIP_SEGMENT` AS `SEGMENT`,\
			`SIP_SCRIP_CODE` AS `SCRIP_CODE`,`SIP_SYMBOL` AS `SYMBOL`,`SIP_PERIOD` AS `PERIOD`,`SIP_TOTAL_QTY` AS `TOTAL_QTY`,\
			`SIP_ENTITY_ID` AS `ENTITY_ID`,(CASE `SIP_SOURCE_FLG` WHEN 'M' THEN 'MOBILE' WHEN 'W' THEN 'WEB' WHEN 'A' THEN 'ADMIN'\
				WHEN 'R' THEN 'RAPIDRUPEE' WHEN 'S' THEN 'RUPEESMART' WHEN 'F' THEN 'FALCON' WHEN 'H' THEN 'HELPDESK' WHEN 'E' THEN 'EXCHANGE'\
				WHEN 'I' THEN 'ITS' END) AS `SOURCE_FLG`,(CASE WHEN (`SIP_MSG_CODE` IN ('3000' , '3040')) THEN 'CONFIRM'\
					WHEN (`SIP_MSG_CODE` = '3050') THEN 'CANCELLED' WHEN (`SIP_MSG_CODE` = '3030') THEN 'PAUSED' END) AS `STATUS`,\
			(CASE `SIP_VALIDITY` WHEN '0' THEN 'DAY' WHEN '1' THEN 'GTC' WHEN '2' THEN 'ATO' WHEN '3' THEN 'IOC' \
			 ELSE 'EOS' END) AS `ORDER_VALIDITY`,IFNULL(NULLIF(`SIP_REASON_DESCRIPTION`, ''), 'NA') AS `REASON_DESCRIPTION`,\
			(CASE `SIP_USER_TYPE` WHEN 'C' THEN 'Client' WHEN 'D' THEN 'Dealer' WHEN 'A' THEN 'Admin' WHEN 'S' THEN 'Super Admin' \
			 END) AS `USER_TYPE`,`SIP_SERIAL_NO` AS `SERIAL_NO` FROM SIP_ORDERS AS `A` WHERE SIP_CLIENT_ID = \"%s\" AND SIP_ORDER_NO = %lf \
			ORDER BY ORDER_DATE_TIME ASC;",pOrdDetlsReq->sClientId,pOrdDetlsReq->fOrderNo);

//	logDebug2("sSIPOrdDetlsQry = %s",sSIPOrdDetlsQry);
	printf("\n sSIPOrdDetlsQry :%s: \n",sSIPOrdDetlsQry);

	if(mysql_query(DBQueries,sSIPOrdDetlsQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdDetlsQry.");
		sql_Error(DBQueries);
		return FALSE;
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

	pOrdDetlsHedResp.IntRespHeader.iSeqNo = 0;
	pOrdDetlsHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdDetlsHedResp.IntRespHeader.iErrorId = 0;
	pOrdDetlsHedResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORDER_DETS_HED_RESP;
	pOrdDetlsHedResp.IntRespHeader.iUserId = pOrdDetlsReq->ReqHeader.iUserId;
	pOrdDetlsHedResp.IntRespHeader.cSource = pOrdDetlsReq->ReqHeader.cSource;
	pOrdDetlsHedResp.cMsgType = 'H';
	pOrdDetlsHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdDetlsHedResp.IntRespHeader.iMsgLength = %d",pOrdDetlsHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdDetlsHedResp.IntRespHeader.iMsgCode = %d",pOrdDetlsHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdDetlsHedResp.IntRespHeader.iUserId = %llu",pOrdDetlsHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdDetlsHedResp.IntRespHeader.cSource = %c",pOrdDetlsHedResp.IntRespHeader.cSource);
	logDebug2("pOrdDetlsHedResp.iNoofRec = %d",pOrdDetlsHedResp.iNoofRec);

	logDebug2("pOrdDetlsReq->ReqHeader.iUserId = %llu",pOrdDetlsReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pOrdDetlsReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iIntActiveToRelDirQ,(CHAR *)&pOrdDetlsHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdDetlsResp,'\0',sizeof(struct VIEW_SIP_ORDER_BOOK_RESP));
		pOrdDetlsResp.IntRespHeader.iSeqNo = 0;
		pOrdDetlsResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ORDER_BOOK_RESP);
		pOrdDetlsResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORDER_DETS_RESP;
		pOrdDetlsResp.IntRespHeader.iErrorId = 0;
		pOrdDetlsResp.IntRespHeader.iUserId = pOrdDetlsReq->ReqHeader.iUserId;
		pOrdDetlsResp.IntRespHeader.cSource = pOrdDetlsReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pOrdDetlsResp.cMsgType = 'T';
		}
		else
		{
			pOrdDetlsResp.cMsgType = 'D';
		}


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pOrdDetlsResp.suborderbook[j].sClientId,Row[0],CLIENT_ID_LEN);
				pOrdDetlsResp.suborderbook[j].fOrderNo = atof(Row[1]);
				strncpy(pOrdDetlsResp.suborderbook[j].sExcgId,Row[2] ,EXCHANGE_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sInternalDate,Row[3] ,DATE_LENGTH);
				strncpy(pOrdDetlsResp.suborderbook[j].sStartDate,Row[4] ,DATE_LENGTH);
				strncpy(pOrdDetlsResp.suborderbook[j].sStartEnd,Row[5] ,DATE_LENGTH);
				strncpy(pOrdDetlsResp.suborderbook[j].sfrequency,Row[6] ,FREQUENCY_LEN);
				memset(pOrdDetlsResp.suborderbook[j].sBuySellInd,'\0',BUY_SELL_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sBuySellInd,Row[7],BUY_SELL_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sProduct,Row[8] ,PRODUCT_LEN);
				pOrdDetlsResp.suborderbook[j].cSegment = Row[9][0];
				strncpy(pOrdDetlsResp.suborderbook[j].sSecurityID,Row[10] ,SECURITY_ID_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sSymbol,Row[11] ,SECURITY_ID_LEN);
				pOrdDetlsResp.suborderbook[j].iForPeriod = atoi(Row[12]);
				pOrdDetlsResp.suborderbook[j].fQty = atof(Row[13]);
				strncpy(pOrdDetlsResp.suborderbook[j].sEntityId , Row[14],ENTITY_ID_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sSourceFlg, Row[15],SOURCE_FLG_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sStatus,Row[16],ORDER_STATUS);
				strncpy(pOrdDetlsResp.suborderbook[j].sValidity,Row[17] ,VALIDITY_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sReasonDesc, Row[18],DB_REASON_DESC_LEN);
				strncpy(pOrdDetlsResp.suborderbook[j].sUserType,Row[19],USER_TYPE_LEN);
				pOrdDetlsResp.suborderbook[j].iSerialNo = atoi(Row[20]);

				logDebug2("pOrdDetlsResp.suborderbook[%d].sClientId = %s",j,pOrdDetlsResp.suborderbook[j].sClientId);
				logDebug2("pOrdDetlsResp.suborderbook[%d].fOrderNo = %lf",j,pOrdDetlsResp.suborderbook[j].fOrderNo);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sExcgId = %s",j,pOrdDetlsResp.suborderbook[j].sExcgId);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sInternalDate = %s",j,pOrdDetlsResp.suborderbook[j].sInternalDate);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sStartDate = %s",j,pOrdDetlsResp.suborderbook[j].sStartDate);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sStartEnd = %s",j,pOrdDetlsResp.suborderbook[j].sStartEnd);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sfrequency = %s",j,pOrdDetlsResp.suborderbook[j].sfrequency);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sBuySellInd = %s",j,pOrdDetlsResp.suborderbook[j].sBuySellInd);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sProduct = %s",j,pOrdDetlsResp.suborderbook[j].sProduct);
				logDebug2("pOrdDetlsResp.suborderbook[%d].cSegment = %c",j,pOrdDetlsResp.suborderbook[j].cSegment);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sSecurityID = %s",j,pOrdDetlsResp.suborderbook[j].sSecurityID);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sSymbol = %s",j,pOrdDetlsResp.suborderbook[j].sSymbol);
				logDebug2("pOrdDetlsResp.suborderbook[%d].iForPeriod = %d",j,pOrdDetlsResp.suborderbook[j].iForPeriod);
				logDebug2("pOrdDetlsResp.suborderbook[%d].fQty = %d",j,pOrdDetlsResp.suborderbook[j].fQty);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sEntityId = %s",j,pOrdDetlsResp.suborderbook[j].sEntityId);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sSourceFlg = %s",j,pOrdDetlsResp.suborderbook[j].sSourceFlg);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sStatus = %s",j,pOrdDetlsResp.suborderbook[j].sStatus);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sValidity = %s",j,pOrdDetlsResp.suborderbook[j].sValidity);
				logDebug2("pOrdDetlsResp.suborderbook[%d].sReasonDesc = %s",j,pOrdDetlsResp.suborderbook[j].sReasonDesc);
				logDebug2("pOrdDetlsResp.suborderbook[%d].scUserType = %s",j,pOrdDetlsResp.suborderbook[j].sUserType);
				logDebug2("pOrdDetlsResp.suborderbook[%d].iSerialNo = %d",j,pOrdDetlsResp.suborderbook[j].iSerialNo);
			}

		}

		if(( WriteMsgQ(iIntActiveToRelDirQ,(CHAR *)&pOrdDetlsResp,sizeof(struct VIEW_SIP_ORDER_BOOK_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iIntActiveToRelDirQ);
			return FALSE;
		}

		iTempNoOfRec--;
		usleep(5000);
	}
	logTimestamp("Exit : fSIPOrdDetails");
	return TRUE;
}

BOOL    fSIPOrdTrails(CHAR *RcvMsg)
{
	logTimestamp("Entry : fSIPOrdTrails");

	struct  VIEW_SIP_ORDER_TRAILS_REQ         	*pOrdTrlsReq;
	struct  VIEW_SIP_ORDER_TRAILS_RESP        	pOrdTrlsResp;
	struct  VIEW_COMMON_HDR_RESP                    pOrdTrlsHedResp;

	CHAR    sSIPOrdTrlsQry[DOUBLE_MAX_QUERY_SIZE];

	pOrdTrlsReq = (struct VIEW_SIP_ORDER_TRAILS_REQ *)RcvMsg;

	LONG32          iNoOfRec=0;
	DOUBLE64        fNoOfRec;
	LONG32          iNoOfPkt;
	LONG32          iTempNoOfRec;

	memset(sSIPOrdTrlsQry,'\0',DOUBLE_MAX_QUERY_SIZE);

	logDebug2("pOrdTrlsReq->fOrderNo = %lf",pOrdTrlsReq->fOrderNo);

	sprintf(sSIPOrdTrlsQry,"SELECT ORDER_NO,ORD_SERIAL_NO,MSG_CODE,SCRIP_CODE,ORDER_VALIDITY,PRO_CLIENT,SOURCE,\
				QTY_ORIGINAL,QTY_REMAINING,PRICE,LAST_TRADE_QTY,TRD_TRADE_PRICE,QTY_TRADED,EXCH_TRADE_NO,PRODUCT,EXCH_ORDER_NO,\
				ORD_TRD_TRADE_TIME,CLIENT_ID,ENTITY_ID,BUY_SELL,EXCH_ID,ERROR_MESSAGE,STATUS,SEM_SYMBOL,ORDER_TYPE,\
				ALGO_ORDER_NO FROM (SELECT  EQ_ORDER_NO AS ORDER_NO,  EQ_SERIAL_NO AS ORD_SERIAL_NO,  EQ_MSG_CODE AS MSG_CODE,\
				EQ_SCRIP_CODE AS SCRIP_CODE,  (CASE EQ_VALIDITY  WHEN 0 THEN 'DAY'  WHEN 3 THEN 'IOC'  END) AS ORDER_VALIDITY,\
				EQ_PRO_CLIENT AS PRO_CLIENT,  EQ_SOURCE_FLG AS SOURCE,  EQ_TOTAL_QTY AS QTY_ORIGINAL,  EQ_REM_QTY AS QTY_REMAINING,\
				EQ_ORDER_PRICE AS PRICE,  EQ_LAST_TRADE_QTY AS LAST_TRADE_QTY,  EQ_TRD_TRADE_PRICE AS TRD_TRADE_PRICE,\
				EQ_TOTAL_TRADED_QTY AS QTY_TRADED,  EQ_TRD_EXCH_TRADE_NO AS EXCH_TRADE_NO, (CASE EQ_PRODUCT_ID  WHEN 'B' \
				THEN 'BO'  WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC'  WHEN 'M' THEN 'MARGIN'  WHEN 'L' THEN 'MLB'  WHEN 'S' \
				THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY'  WHEN 'V' THEN 'CO'  WHEN 'B' THEN 'BO'  ELSE EQ_PRODUCT_ID  END) AS PRODUCT,\
				EQ_EXCH_ORDER_NO AS EXCH_ORDER_NO,  DATE_FORMAT(EQ_INTERNAL_ENTRY_DATE, '%%d-%%m-%%Y %%r') AS ORD_TRD_TRADE_TIME,\
				EQ_CLIENT_ID AS CLIENT_ID,  EQ_ENTITY_ID AS ENTITY_ID,  (CASE EQ_BUY_SELL_IND  WHEN 'B' THEN 'SIP'  \
				WHEN 'S' THEN 'SWP'  END) AS BUY_SELL,  EQ_EXCH_ID AS EXCH_ID,  EQ_REASON_DESCRIPTION AS ERROR_MESSAGE,\
				CASE EQ_MSG_CODE  WHEN '2073' THEN 'Pending'  WHEN '2000' THEN 'Transit'  WHEN '2231' THEN 'Rejected'  \
				WHEN '2042' THEN 'Rejected'  WHEN '2170' THEN 'Frozen'  WHEN '2074' THEN 'Modified'  WHEN '2075' THEN 'Cancelled'  \
				WHEN '2222' THEN 'Traded'  WHEN '2072' THEN 'Rejected'  WHEN '2040' THEN 'Transit'  WHEN '2070' \
				THEN 'Transit'  WHEN '9002' THEN 'Expired'  WHEN '5112' THEN 'O-Pending'  WHEN '5113' THEN 'O-Modified'  \
				WHEN '5114' THEN 'O-Cancelled'  WHEN '2212' THEN 'Triggered'  WHEN '1111' THEN 'Rejected'  WHEN '1113' \
				THEN 'Rejected'  WHEN '1115' THEN 'Rejected'  WHEN '4444' THEN 'Rejected'  WHEN '4445' THEN 'Rejected'  \
				WHEN '4446' THEN 'Rejected'  WHEN '3073' THEN 'Pending' WHEN '3331' THEN 'Rejected' END AS STATUS,\
				EQ_SYMBOL AS SEM_SYMBOL,  (CASE EQ_ORDER_TYPE  WHEN '1' THEN 'MARKET'  \
				WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'  WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,  EQ_ALGO_ORDER_NO AS \
				ALGO_ORDER_NO  FROM EQ_ORDERS_ARCHIVE UNION ALL SELECT  EQ_ORDER_NO AS ORDER_NO,  EQ_SERIAL_NO AS ORD_SERIAL_NO,\
				EQ_MSG_CODE AS MSG_CODE,  EQ_SCRIP_CODE AS SCRIP_CODE,  (CASE EQ_VALIDITY  WHEN 0 THEN 'DAY'  WHEN 3 THEN 'IOC'  END) \
				AS ORDER_VALIDITY,  EQ_PRO_CLIENT AS PRO_CLIENT,  EQ_SOURCE_FLG AS SOURCE,  EQ_TOTAL_QTY AS QTY_ORIGINAL,\
				EQ_REM_QTY AS QTY_REMAINING,  EQ_ORDER_PRICE AS PRICE,  EQ_LAST_TRADE_QTY AS LAST_TRADE_QTY,  \
				EQ_TRD_TRADE_PRICE AS TRD_TRADE_PRICE,  EQ_TOTAL_TRADED_QTY AS QTY_TRADED,  EQ_TRD_EXCH_TRADE_NO AS EXCH_TRADE_NO,\
				(CASE EQ_PRODUCT_ID  WHEN 'B' THEN 'BO'  WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC'  WHEN 'M' THEN 'MARGIN' \ 
				WHEN 'L' THEN 'MLB'  WHEN 'S' THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY'  WHEN 'V' THEN 'CO'  WHEN 'B' \
				THEN 'BO'  ELSE EQ_PRODUCT_ID  END) AS PRODUCT,  EQ_EXCH_ORDER_NO AS EXCH_ORDER_NO,  \
				DATE_FORMAT(EQ_INTERNAL_ENTRY_DATE, '%%d-%%m-%%Y %%r') AS ORD_TRD_TRADE_TIME,  EQ_CLIENT_ID AS CLIENT_ID,\
				EQ_ENTITY_ID AS ENTITY_ID,  (CASE EQ_BUY_SELL_IND  WHEN 'B' THEN 'SIP'  WHEN 'S' THEN 'SWP'  END) AS BUY_SELL,\
				EQ_EXCH_ID AS EXCH_ID,  EQ_REASON_DESCRIPTION AS ERROR_MESSAGE,  CASE EQ_MSG_CODE  WHEN '2073' THEN 'Pending'  \
				WHEN '2000' THEN 'Transit'  WHEN '2231' THEN 'Rejected'  WHEN '2042' THEN 'Rejected'  WHEN '2170' THEN 'Frozen'  \
				WHEN '2074' THEN 'Modified'  WHEN '2075' THEN 'Cancelled'  WHEN '2222' THEN 'Traded'  WHEN '2072' THEN 'Rejected'  \
				WHEN '2040' THEN 'Transit'  WHEN '2070' THEN 'Transit'  WHEN '9002' THEN 'Expired'  WHEN '5112' THEN 'O-Pending'  \
				WHEN '5113' THEN 'O-Modified'  WHEN '5114' THEN 'O-Cancelled'  WHEN '2212' THEN 'Triggered'  WHEN '1111' \
				THEN 'Rejected'  WHEN '1113' THEN 'Rejected'  WHEN '1115' THEN 'Rejected'  WHEN '4444' THEN 'Rejected'  \
				WHEN '4445' THEN 'Rejected'  WHEN '4446' THEN 'Rejected'  WHEN '3073' THEN 'Pending' WHEN '3331' THEN 'Rejected' \
				END AS STATUS,  EQ_SYMBOL AS SEM_SYMBOL, \
				(CASE EQ_ORDER_TYPE  WHEN '1' THEN 'MARKET'  WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'  WHEN '4' THEN 'SL'  END)\
				AS ORDER_TYPE,  EQ_ALGO_ORDER_NO AS ALGO_ORDER_NO  FROM EQ_ORDERS UNION ALL SELECT  SIP_ORDER_NO AS ORDER_NO,\
				SIP_SERIAL_NO AS ORD_SERIAL_NO,  SIP_MSG_CODE AS MSG_CODE,  SIP_SCRIP_CODE AS SCRIP_CODE, \
				(CASE SIP_VALIDITY  WHEN 0 THEN 'DAY'  WHEN 3 THEN 'IOC'  END) AS ORDER_VALIDITY,  SIP_PRO_CLIENT AS PRO_CLIENT, \
				SIP_SOURCE_FLG AS SOURCE,  SIP_TOTAL_QTY AS QTY_ORIGINAL,  0 AS QTY_REMAINING,  SIP_AMOUNT AS PRICE,\
				0 AS LAST_TRADE_QTY,  0 AS TRD_TRADE_PRICE,  0 AS QTY_TRADED,  0 AS EXCH_TRADE_NO,  (CASE SIP_PRODUCT_ID  WHEN 'B'\
				THEN 'BO'  WHEN 'V' THEN 'CO'  WHEN 'C' THEN 'CNC'  WHEN 'M' THEN 'MARGIN'  WHEN 'L' THEN 'MLB'  WHEN 'S'\
				THEN 'COLLATERAL'  WHEN 'I' THEN 'INTRADAY'  WHEN 'V' THEN 'CO'  WHEN 'B' THEN 'BO'  ELSE SIP_PRODUCT_ID  END) AS PRODUCT,\
				0 AS EXCH_ORDER_NO,  DATE_FORMAT(SIP_INTERNAL_ENTRY_DATE, '%%d-%%m-%%Y %%r') AS ORD_TRD_TRADE_TIME,\
				SIP_CLIENT_ID AS CLIENT_ID,  SIP_ENTITY_ID AS ENTITY_ID,  (CASE SIP_BUY_SELL_IND  WHEN 'B' THEN 'SIP' \
				WHEN 'S' THEN 'SWP'  END) AS BUY_SELL,  SIP_EXCH_ID AS EXCH_ID,  SIP_REMARKS AS ERROR_MESSAGE,  CASE SIP_MSG_CODE \
				WHEN '2073' THEN 'Pending'  WHEN '2000' THEN 'Transit'  WHEN '2231' THEN 'Rejected'  WHEN '2042' THEN 'Rejected' \
				WHEN '2170' THEN 'Frozen'  WHEN '2074' THEN 'Modified'  WHEN '2075' THEN 'Cancelled'  WHEN '2222' THEN 'Traded'\
				WHEN '2072' THEN 'Rejected'  WHEN '2040' THEN 'Transit'  WHEN '2070' THEN 'Transit'  WHEN '9002' THEN 'Expired'\
				WHEN '5112' THEN 'O-Pending'  WHEN '5113' THEN 'O-Modified'  WHEN '5114' THEN 'O-Cancelled'  WHEN '2212' THEN 'Triggered'\
				WHEN '1111' THEN 'Rejected'  WHEN '1113' THEN 'Rejected'  WHEN '1115' THEN 'Rejected'  WHEN '4444' THEN 'Rejected' \
				WHEN '4445' THEN 'Rejected'  WHEN '4446' THEN 'Rejected'  WHEN '3073' THEN 'Pending' WHEN '3331' THEN 'Rejected' \
				END AS STATUS,  SIP_SYMBOL AS SEM_SYMBOL,\
				(CASE SIP_ORDER_TYPE  WHEN '1' THEN 'MARKET'  WHEN '2' THEN 'LIMIT'  WHEN '3' THEN 'SL-M'  WHEN '4' THEN 'SL'  END) AS ORDER_TYPE,\
				SIP_ORDER_NO AS ALGO_ORDER_NO  FROM SIP_ORDERS_ARCHIVE  WHERE SIP_TOTAL_QTY = 0)\
				AS EQ WHERE  ALGO_ORDER_NO = %lf ORDER BY ORD_TRD_TRADE_TIME DESC , ORDER_NO DESC , ORD_SERIAL_NO DESC;",pOrdTrlsReq->fOrderNo);

//	logDebug2("sSIPOrdTrlsQry = %s",sSIPOrdTrlsQry);
	printf("\n sSIPOrdTrlsQry :%s: \n",sSIPOrdTrlsQry);

	if(mysql_query(DBQueries,sSIPOrdTrlsQry) != SUCCESS)
	{
		logSqlFatal("Error in sSIPOrdTrlsQry.");
		sql_Error(DBQueries);
		return FALSE;
	}
	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;

	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);
	pOrdTrlsHedResp.IntRespHeader.iSeqNo = 0;
	pOrdTrlsHedResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pOrdTrlsHedResp.IntRespHeader.iErrorId = 0;
	pOrdTrlsHedResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORDER_TRALS_HED_RESP;
	pOrdTrlsHedResp.IntRespHeader.iUserId = pOrdTrlsReq->ReqHeader.iUserId;
	pOrdTrlsHedResp.IntRespHeader.cSource = pOrdTrlsReq->ReqHeader.cSource;
	pOrdTrlsHedResp.cMsgType = 'H';
	pOrdTrlsHedResp.iNoofRec = iNoOfRec;

	logDebug2("pOrdTrlsHedResp.IntRespHeader.iMsgLength = %d",pOrdTrlsHedResp.IntRespHeader.iMsgLength);
	logDebug2("pOrdTrlsHedResp.IntRespHeader.iMsgCode = %d",pOrdTrlsHedResp.IntRespHeader.iMsgCode);
	logDebug2("pOrdTrlsHedResp.IntRespHeader.iUserId = %llu",pOrdTrlsHedResp.IntRespHeader.iUserId);
	logDebug2("pOrdTrlsHedResp.IntRespHeader.cSource = %c",pOrdTrlsHedResp.IntRespHeader.cSource);
	logDebug2("pOrdTrlsHedResp.iNoofRec = %d",pOrdTrlsHedResp.iNoofRec);

	logDebug2("pOrdTrlsReq->ReqHeader.iUserId = %llu",pOrdTrlsReq->ReqHeader.iUserId);
	iRelayID = find_user_adapter(pOrdTrlsReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}
	if(( WriteMsgQ( iIntActiveToRelDirQ,(CHAR *)&pOrdTrlsHedResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		logFatal("Error : WriteMsgQ = %d",iIntActiveToRelDirQ);
		return FALSE;
	}

	for(i=0;i<iNoOfPkt;i++)
	{
		logDebug2("No 0f Pkt(i) = %d",i);
		memset(&pOrdTrlsResp,'\0',sizeof(struct VIEW_SIP_ORDER_TRAILS_RESP));
		pOrdTrlsResp.IntRespHeader.iSeqNo = 0;
		pOrdTrlsResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_SIP_ORDER_TRAILS_RESP);
		pOrdTrlsResp.IntRespHeader.iMsgCode = TC_INT_SIP_ORDER_TRALS_RESP;
		pOrdTrlsResp.IntRespHeader.iErrorId = 0;
		pOrdTrlsResp.IntRespHeader.iUserId = pOrdTrlsReq->ReqHeader.iUserId;
		pOrdTrlsResp.IntRespHeader.cSource = pOrdTrlsReq->ReqHeader.cSource;

		if(iTempNoOfRec <= 1)
		{
			pOrdTrlsResp.cMsgType = 'T';
		}
		else
		{
			pOrdTrlsResp.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				pOrdTrlsResp.subordertrails[j].fOrderNo = atof(Row[0]);
				pOrdTrlsResp.subordertrails[j].iSerialNo = atoi(Row[1]);
				pOrdTrlsResp.subordertrails[j].iTranscode = atoi(Row[2]);
				strncpy(pOrdTrlsResp.subordertrails[j].sSecurityID,Row[3],SECURITY_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sValidity,Row[4],VALIDITY_LEN);
				pOrdTrlsResp.subordertrails[j].cProClient = Row[5][0];
				strncpy(pOrdTrlsResp.subordertrails[j].sSourceFlg,Row[6],SOURCE_FLG_LEN);
				pOrdTrlsResp.subordertrails[j].fQty = atof(Row[7]);
				pOrdTrlsResp.subordertrails[j].fRemQty = atof(Row[8]);
				pOrdTrlsResp.subordertrails[j].fPrice = atof(Row[9]);
				pOrdTrlsResp.subordertrails[j].fTradeQty = atof(Row[10]);
				pOrdTrlsResp.subordertrails[j].fTradePrice = atof(Row[11]);
				pOrdTrlsResp.subordertrails[j].fTotalTradeQty = atof(Row[12]);
				pOrdTrlsResp.subordertrails[j].iExchTradeNo = atoi(Row[13]);
				strncpy(pOrdTrlsResp.subordertrails[j].sProduct,Row[14],PRODUCT_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sExchOrderNumber,Row[15],NSE_EXCH_ORDER_NO_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sDatetime,Row[16],DATE_STRING_LENGTH);
				strncpy(pOrdTrlsResp.subordertrails[j].sClientId,Row[17],CLIENT_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sEntityId,Row[18],ENTITY_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sBuySellInd,Row[19],BUY_SELL_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sExcgId,Row[20],EXCHANGE_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sOrdReasonDesc,Row[21],ORDER_REASON_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sStatus,Row[22],ORDER_STATUS);
				strncpy(pOrdTrlsResp.subordertrails[j].sSymbol,Row[23],SECURITY_ID_LEN);
				strncpy(pOrdTrlsResp.subordertrails[j].sOrderType,Row[24],ORD_TYP_LEN);
				pOrdTrlsResp.subordertrails[j].fAlgoOrderNo = atof(Row[25]);

				logDebug2("pOrdTrlsResp.subordertrails[%d].fOrderNo = %lf",j,pOrdTrlsResp.subordertrails[j].fOrderNo);
				logDebug2("pOrdTrlsResp.subordertrails[%d].iSerialNo = %d",j,pOrdTrlsResp.subordertrails[j].iSerialNo);
				logDebug2("pOrdTrlsResp.subordertrails[%d].iTranscode = %d",j,pOrdTrlsResp.subordertrails[j].iTranscode);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sSecurityID = %s",j,pOrdTrlsResp.subordertrails[j].sSecurityID);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sValidity = %s",j,pOrdTrlsResp.subordertrails[j].sValidity);
				logDebug2("pOrdTrlsResp.subordertrails[%d].cProClient = %c",j,pOrdTrlsResp.subordertrails[j].cProClient);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sSourceFlg = %s",j,pOrdTrlsResp.subordertrails[j].sSourceFlg);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fQty = %lf",j,pOrdTrlsResp.subordertrails[j].fQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fRemQty = %lf",j,pOrdTrlsResp.subordertrails[j].fRemQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fPrice = %lf",j,pOrdTrlsResp.subordertrails[j].fPrice);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fTradeQty = %lf",j,pOrdTrlsResp.subordertrails[j].fTradeQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fTradePrice = %lf",j,pOrdTrlsResp.subordertrails[j].fTradePrice);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fTotalTradeQty = %lf",j,pOrdTrlsResp.subordertrails[j].fTotalTradeQty);
				logDebug2("pOrdTrlsResp.subordertrails[%d].iExchTradeNo = %d",j,pOrdTrlsResp.subordertrails[j].iExchTradeNo);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sProduct = %s",j,pOrdTrlsResp.subordertrails[j].sProduct);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sExchOrderNumber = %s",j,pOrdTrlsResp.subordertrails[j].sExchOrderNumber);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sDatetime = %s",j,pOrdTrlsResp.subordertrails[j].sDatetime);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sClientId = %s",j,pOrdTrlsResp.subordertrails[j].sClientId);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sEntityId = %s",j,pOrdTrlsResp.subordertrails[j].sEntityId);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sBuySellInd = %s",j,pOrdTrlsResp.subordertrails[j].sBuySellInd);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sExcgId = %s",j,pOrdTrlsResp.subordertrails[j].sExcgId);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sOrdReasonDesc = %s",j,pOrdTrlsResp.subordertrails[j].sOrdReasonDesc);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sStatus = %s",j,pOrdTrlsResp.subordertrails[j].sStatus);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sSymbol = %s",j,pOrdTrlsResp.subordertrails[j].sSymbol);
				logDebug2("pOrdTrlsResp.subordertrails[%d].sOrderType = %s",j,pOrdTrlsResp.subordertrails[j].sOrderType);
				logDebug2("pOrdTrlsResp.subordertrails[%d].fAlgoOrderNo = %lf",j,pOrdTrlsResp.subordertrails[j].fAlgoOrderNo);

			}

		}

		if(( WriteMsgQ(iIntActiveToRelDirQ,(CHAR *)&pOrdTrlsResp,sizeof(struct VIEW_SIP_ORDER_TRAILS_RESP) ,iRelayID) != TRUE ))
		{
			logFatal("Error : WriteMsgQ = %d ",iIntActiveToRelDirQ);
			return FALSE;
		}

		iTempNoOfRec--;
		usleep(5000);
	}
	logTimestamp("Exit : fSIPOrdTrails");
	return TRUE;
}


BOOL    fViewClDetLimit(CHAR *RcvMsg)
{
	logTimestamp("Entry : fViewClDetLimit");
	struct  VIEW_COMMON_QUERY_REQ           *pViewDetLmtReq;
	struct  VIEW_CLIENT_LIMIT_DTLS          pDetLmtRes;

	pViewDetLmtReq = (struct  VIEW_COMMON_QUERY_REQ *)RcvMsg;

	INT16 iStatus,iError ;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	CHAR    sViewDetLimit      [DOUBLE_MAX_QUERY_SIZE];
	memset(sViewDetLimit,'\0',DOUBLE_MAX_QUERY_SIZE);

	if(mysql_set_server_option(DBQueries,CLIENT_MULTI_STATEMENTS) == 0)
	{
		logDebug2(" mysql_set_server_option SUCCESS");
	}
	else
	{
		logDebug2(" mysql_set_server_option FAILed");
		return FALSE;
	}
	logDebug2("pViewDetLmtReq->sClientId = %s",pViewDetLmtReq->sClientId);

	sprintf(sViewDetLimit,"CALL PR_DETAILED_LIMIT(\"%s\",@V_EQ_CNC_PEND ,@V_EQ_MRG_PEND,@V_EQ_INT_PEND,  @V_MRG_PEND ,@V_INT_PEND,@V_CURR_MRG_PEND ,\
		@V_CURR_INT_PEND ,@V_EQ_HYB_PEND ,@V_EQ_MTF_PEND ,@V_EQ_CNC ,@V_NSE_CNC_RECEIVABLE ,@V_BSE_CNC_RECEIVABLE ,@V_EQ_MRG_VAR ,@V_EQ_INT_VAR ,\
			@V_EQ_HYB_VAR ,@V_EQ_MTF_VAR , @V_INTRADAY , @V_MARGIN ,@V_CURR_INTRADAY ,@V_CURR_MARGIN ,@V_SPANB1 ,@V_SPANB2 ,@V_SPANB3 ,@V_SPANB4 ,\
			@V_OPTION_SELL_PREMIUM ,      @V_EXPO_INT , @V_EXPO_MARGIN ,@V_CURR_EXPO_INT ,@V_CURR_EXPO_MARGIN ,@V_EQ_CO,  @V_CO ,@V_CURR_CO ,@V_EQ_BO ,\
			@V_BO ,@V_CURR_BO ,@V_EQ_INT_RPNL ,@V_EQ_MRG_RPNL ,@V_EQ_CNC_RPNL , @V_INT_RPNL , @V_MRG_RPNL ,@V_CURR_INT_RPNL ,@V_CURR_MRG_RPNL ,\
			@V_EQ_HYB_RPNL ,@V_EQ_MTF_RPNL ,@V_EQ_TOTAL_UTLZ , @V_TOTAL_UTLZ ,@V_CURR_TOTAL_UTLZ ,@V_COMM_MRG_PEND ,@V_COMM_INT_PEND ,@V_COMM_INTRADAY ,\
			@V_COMM_MARGIN ,@V_SPANB5 ,@V_SPANB6 ,@V_COMM_EXPO_INT ,@V_COMM_EXPO_MARGIN ,@V_COMM_CO ,@V_COMM_BO  ,@V_COMM_INT_RPNL ,@V_COMM_MRG_RPNL  ,\
			@V_COMM_TOTAL_UTLZ ,@V_OPTION_SELL_PREMIUM_COM,@V_EQ_CO_RPNL, @V_DRV_CO_RPNL, @V_CURR_CO_RPNL, @V_EQ_BO_RPNL, @V_DRV_BO_RPNL,\
			@V_CURR_BO_RPNL, @V_COMM_CO_RPNL ,@V_COMM_BO_RPNL ,@V_OPTION_SELL_PREMIUM_CURR );\
		SELECT  IFNULL(@V_EQ_CNC_PEND , 0), IFNULL(@V_EQ_MRG_PEND, 0), IFNULL(@V_EQ_INT_PEND  ,  0), IFNULL(@V_MRG_PEND , 0), \
		IFNULL(@V_INT_PEND, 0), IFNULL(@V_CURR_MRG_PEND , 0), IFNULL(@V_CURR_INT_PEND , 0), IFNULL(@V_EQ_HYB_PEND , 0), \
		IFNULL(@V_EQ_MTF_PEND , 0), IFNULL(@V_EQ_CNC , 0), IFNULL(@V_NSE_CNC_RECEIVABLE , 0), IFNULL(@V_BSE_CNC_RECEIVABLE , 0), \
		IFNULL(@V_EQ_MRG_VAR , 0), IFNULL(@V_EQ_INT_VAR , 0),            IFNULL(@V_EQ_HYB_VAR , 0), IFNULL(@V_EQ_MTF_VAR ,  0),\
		IFNULL(@V_INTRADAY,   0), IFNULL(@V_MARGIN , 0), IFNULL(@V_CURR_INTRADAY , 0), IFNULL(@V_CURR_MARGIN , 0), \
		IFNULL(@V_SPANB1 , 0), IFNULL(@V_SPANB2 , 0), IFNULL(@V_SPANB3 , 0), IFNULL(@V_SPANB4 , 0), IFNULL(@V_OPTION_SELL_PREMIUM     ,   0), \
		IFNULL(@V_EXPO_INT ,  0), IFNULL(@V_EXPO_MARGIN , 0), IFNULL(@V_CURR_EXPO_INT , 0), IFNULL(@V_CURR_EXPO_MARGIN , 0), IFNULL(@V_EQ_CO ,0),\
		IFNULL( @V_CO,  0), \
		IFNULL(@V_CURR_CO , 0), IFNULL(@V_EQ_BO , 0), IFNULL(@V_BO , 0), IFNULL(@V_CURR_BO , 0), IFNULL(@V_EQ_INT_RPNL , 0), IFNULL(@V_EQ_MRG_RPNL , 0),\
		IFNULL(@V_EQ_CNC_RPNL,   0), IFNULL(@V_INT_RPNL ,  0), IFNULL(@V_MRG_RPNL , 0), IFNULL(@V_CURR_INT_RPNL , 0), IFNULL(@V_CURR_MRG_RPNL , 0),\
		IFNULL(@V_EQ_HYB_RPNL , 0), IFNULL(@V_EQ_MTF_RPNL , 0), IFNULL(@V_EQ_TOTAL_UTLZ ,  0), IFNULL(@V_TOTAL_UTLZ , 0), IFNULL(@V_CURR_TOTAL_UTLZ , 0), \
		IFNULL(@V_COMM_MRG_PEND  , 0), IFNULL(@V_COMM_INT_PEND , 0), IFNULL(@V_COMM_INTRADAY , 0), IFNULL(@V_COMM_MARGIN , 0), IFNULL(@V_SPANB5 , 0), \
		IFNULL(@V_SPANB6 , 0), IFNULL(@V_COMM_EXPO_INT , 0), IFNULL(@V_COMM_EXPO_MARGIN , 0), IFNULL(@V_COMM_CO , 0), IFNULL(@V_COMM_BO  , 0),\
		IFNULL(@V_COMM_INT_RPNL , 0), IFNULL(@V_COMM_MRG_RPNL  , 0), IFNULL(@V_COMM_TOTAL_UTLZ , 0), IFNULL(@V_OPTION_SELL_PREMIUM_COMi, 0), \
		IFNULL(@V_EQ_CO_RPNL,  0), IFNULL(@V_DRV_CO_RPNL, 0), IFNULL(@V_CURR_CO_RPNL,  0), IFNULL(@V_EQ_BO_RPNL,  0), IFNULL(@V_DRV_BO_RPNL,  0), \
		IFNULL(@V_CURR_BO_RPNL,  0), IFNULL(@V_COMM_CO_RPNL , 0), IFNULL(@V_COMM_BO_RPNL , 0), IFNULL(@V_OPTION_SELL_PREMIUM_CURRi, 0);",pViewDetLmtReq->sClientId);	

		printf("\n sViewDetLimit :%s: \n",sViewDetLimit);

	if(mysql_query(DBQueries,sViewDetLimit) != SUCCESS)
	{
		sql_Error(DBQueries);
		iError  = mysql_errno(DBQueries);
		logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
		return ERROR;
	}


	do{

		Res = mysql_store_result(DBQueries);
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{

				pDetLmtRes.IntRespHeader.iSeqNo = 0;
				pDetLmtRes.IntRespHeader.iMsgLength = sizeof(struct VIEW_CLIENT_LIMIT_DTLS);
				logDebug2("pDetLmtRes.IntRespHeader.iMsgLength = %d",pDetLmtRes.IntRespHeader.iMsgLength);
				pDetLmtRes.IntRespHeader.iMsgCode = TC_INT_VIEW_CLIENT_LIMIT_DET_RES;
				pDetLmtRes.IntRespHeader.iErrorId = 0;
				pDetLmtRes.IntRespHeader.iUserId = pViewDetLmtReq->ReqHeader.iUserId;
				pDetLmtRes.IntRespHeader.cSource = pViewDetLmtReq->ReqHeader.cSource ;

				strncpy(pDetLmtRes.sClientId,pViewDetLmtReq->sClientId,CLIENT_ID_LEN);
				pDetLmtRes.fEqCNCPending=atof(Row[0]);
				pDetLmtRes.fEqMRGPending  =atof(Row[1]);
				pDetLmtRes.fEqINTPending  =atof(Row[2]);
				pDetLmtRes.fDrvMRGPending =atof(Row[3]);
				pDetLmtRes.fDrvINTPending =atof(Row[4]);
				pDetLmtRes.fCurrMRGPending=atof(Row[5]);
				pDetLmtRes.fCurrINTPending=atof(Row[6]);
				pDetLmtRes.fEqHYBPending  =atof(Row[7]);
				pDetLmtRes.fEqMTFPending  =atof(Row[8]);
				logDebug2("pDetLmtRes.fEqMTFPending = %f",pDetLmtRes.fEqMTFPending);				
				pDetLmtRes.fEqCNC   =atof(Row[9]);
				logDebug2("pDetLmtRes.fEqCNC = %f",pDetLmtRes.fEqCNC);				
				pDetLmtRes.fNseCNCRecvable=atof(Row[10]);
				pDetLmtRes.fBseCNCRecvable=atof(Row[11]);
				pDetLmtRes.fEqMRGVar=atof(Row[12]);
				pDetLmtRes.fEqINTVar=atof(Row[13]);
				pDetLmtRes.fEqHYBVar=atof(Row[14]);
				pDetLmtRes.fEqMTFVar=atof(Row[15]);
				pDetLmtRes.fDrvInt  =atof(Row[16]);
				pDetLmtRes.fDrvMRG  =atof(Row[17]);
				pDetLmtRes.fCurrINT =atof(Row[18]);
				pDetLmtRes.fCurrMRG =atof(Row[19]);
				pDetLmtRes.fSPAN1   =atof(Row[20]);
				pDetLmtRes.fSPAN2   =atof(Row[21]);
				pDetLmtRes.fSPAN3   =atof(Row[22]);
				pDetLmtRes.fSPAN4   =atof(Row[23]);
				pDetLmtRes.fOptSellPremiDrv  =atof(Row[24]);
				pDetLmtRes.fDrvExpoINT    =atof(Row[25]);
				pDetLmtRes.fDrvExpoMRG    =atof(Row[26]);
				pDetLmtRes.fCurrExpoINT   =atof(Row[27]);
				pDetLmtRes.fCurrExpoMRG   =atof(Row[28]);
				pDetLmtRes.fEquCO   =atof(Row[29]);
				pDetLmtRes.fDrvCO   =atof(Row[30]);
				pDetLmtRes.fCurrCO  =atof(Row[31]);
				pDetLmtRes.fEquBO   =atof(Row[32]);
				pDetLmtRes.fDrvBO   =atof(Row[33]);
				pDetLmtRes.fCurrBO  =atof(Row[34]);
				pDetLmtRes.fEquINTRPNL    =atof(Row[35]);
				pDetLmtRes.fEquMRGRPNL    =atof(Row[36]);
				pDetLmtRes.fEquCNCRPNL    =atof(Row[37]);
				pDetLmtRes.fDrvINTRPNL    =atof(Row[38]);
				pDetLmtRes.fDrvMRGRPNL    =atof(Row[39]);
				pDetLmtRes.fCurrINTRPNL   =atof(Row[40]);
				pDetLmtRes.fCurrMRGRPNL   =atof(Row[41]);
				pDetLmtRes.fEqHYBRPNL     =atof(Row[42]);
				pDetLmtRes.fEqMTFRPNL     =atof(Row[43]);
				pDetLmtRes.fEqTotUtilized =atof(Row[44]);
				pDetLmtRes.fDrvTotUtilized=atof(Row[45]);
				pDetLmtRes.fCurrTotUtilized     =atof(Row[46]);
				pDetLmtRes.fCommMRGPend   =atof(Row[47]);
				pDetLmtRes.fCommINTPend   =atof(Row[48]);
				pDetLmtRes.fCommINTR=atof(Row[49]);
				pDetLmtRes.fCommMRG =atof(Row[50]);
				pDetLmtRes.fSPAN5   =atof(Row[51]);
				pDetLmtRes.fSPAN6   =atof(Row[52]);
				pDetLmtRes.fCommExpoINT   =atof(Row[53]);
				pDetLmtRes.fCommExpoMRG   =atof(Row[54]);
				pDetLmtRes.fCommExpoCO    =atof(Row[55]);
				pDetLmtRes.fCommExpoBO    =atof(Row[56]);
				pDetLmtRes.fCommINTRPNL   =atof(Row[57]);
				pDetLmtRes.fCommMRGRPNL   =atof(Row[58]);
				pDetLmtRes.fCommTotUtiliz =atof(Row[59]);
				pDetLmtRes.fCommSellOptPremi=atof(Row[60]);
				pDetLmtRes.fEquCORPNL =atof(Row[61]);
				pDetLmtRes.fDrvCORPNL =atof(Row[62]);
				pDetLmtRes.fCurrCORPNL =atof(Row[63]);
				pDetLmtRes.fEquBORPNL=atof(Row[64]);
				pDetLmtRes.fDrvBORPNL=atof(Row[65]);
				pDetLmtRes.fCurrBORPNL=atof(Row[66]);
				pDetLmtRes.fCommCORPNL=atof(Row[67]);
				pDetLmtRes.fCommBORPNL=atof(Row[68]);
				pDetLmtRes.fOptSellPremiCurr=atof(Row[69]);

				mysql_free_result(Res);

			}
		}
		else
		{
			logDebug2("No Result Set ");
		}

		if((iStatus =mysql_next_result(DBQueries)) > 0)
		{
			logDebug3("Could not execute statement :%d:",iStatus);
		}

		logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBQueries));

	}while(iStatus == 0);

	iRelayID = find_user_adapter(pViewDetLmtReq->ReqHeader.iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logInfo("Invalid Relayid");
		return FALSE;
	}

	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pDetLmtRes,sizeof(struct VIEW_CLIENT_LIMIT_DTLS) ,iRelayID ) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}


	logTimestamp("Exit : fViewClDetLimit");

}







BOOL	fMktStatus(CHAR *RcvMsg)
{
	logTimestamp("Entry : MktStatus");	

	struct INT_COMMON_REQUEST_HDR	*MktStatReq;	
	struct	VIEW_MKT_STATUS 	Mkstatus;
	struct	VIEW_COMMON_HDR_RESP     MarketStat;


	INT16 iError ;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;

	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec = 0;
	DOUBLE64        fNoOfRec = 0.00;
	LONG32          iNoOfPkt = 0;


	CHAR    sMktStat      [DOUBLE_MAX_QUERY_SIZE];
	memset(sMktStat,'\0',DOUBLE_MAX_QUERY_SIZE);

	MktStatReq = (struct INT_COMMON_REQUEST_HDR *)RcvMsg;



	sprintf(sMktStat,"SELECT EMM_EXM_EXCH_ID,EMM_EXCH_SEG,case when EMM_EXM_EXCH_ID <> 'MCX' then CASE EMM_MKT_TYPE_NO WHEN 1 THEN 'NL' WHEN 2 THEN 'OL'  WHEN 3 \            THEN 'SP' WHEN 4 THEN 'AU' WHEN 5 THEN 'A1' WHEN 6 THEN 'A2' END  else case EMM_MKT_TYPE_NO WHEN 1 THEN 'MS' WHEN 2 THEN 'ES' WHEN 3 THEN 'SS' END  END,\               EMM_MKT_DESCRIPTION,CASE EMM_STATUS WHEN 1 THEN 'OPEN' WHEN 2 THEN 'CLOSE' WHEN 0 THEN 'PRE-OPEN' END  FROM EXCH_MKT_MASTER order by EMM_EXM_EXCH_ID;");

	printf("\n sMktStat :%s: \n",sMktStat);

	if(mysql_query(DBQueries,sMktStat) != SUCCESS)
	{
		sql_Error(DBQueries);
		iError  = mysql_errno(DBQueries);
		logDebug2("ERROR Received While Calling RMS_VALIDATE :%d:",iError);
		return ERROR;
	}


	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);


	/******** Calculating no of packets****/
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	//iTempNoOfRec = iNoOfRec;
	iTempNoOfRec = iNoOfPkt;
	/********END: Calculating no of packets****/
	MarketStat.IntRespHeader.iSeqNo = 0;
	MarketStat.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	MarketStat.IntRespHeader.iErrorId = 0;
	MarketStat.IntRespHeader.iMsgCode = TC_INT_MKT_STATUS_HDR_RES;
	MarketStat.IntRespHeader.iUserId = MktStatReq->iUserId;
	MarketStat.IntRespHeader.cSource = MktStatReq->cSource ;

	MarketStat.cMsgType = 'H';
	MarketStat.iNoofRec = iNoOfRec;

	logDebug2("MarketStat.cMsgType:%c:,.iNoofRec:%d:",MarketStat.cMsgType,MarketStat.iNoofRec);
	logDebug2("MktStatReq->ReqHeader.iUserId = %llu",MktStatReq->iUserId);
	iRelayID = find_user_adapter(MktStatReq->iUserId);
	logDebug2("iRelayID = %d",iRelayID);

	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&MarketStat,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}


	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&Mkstatus,'\0',sizeof(struct VIEW_MKT_STATUS));			
		Mkstatus.pResHeader.iSeqNo = 0;
		Mkstatus.pResHeader.iMsgLength = sizeof(struct VIEW_MKT_STATUS);
		logDebug2("Mkstatus.pResHeader.iMsgLength = %d",Mkstatus.pResHeader.iMsgLength);
		Mkstatus.pResHeader.iErrorId = 0;
		Mkstatus.pResHeader.iMsgCode =  TC_INT_MKT_STATUS_RES ;
		Mkstatus.pResHeader.iUserId = MktStatReq->iUserId;
		Mkstatus.pResHeader.cSource = MktStatReq->cSource ;

		if(iTempNoOfRec <= 1)
		{
			Mkstatus.cMsgType = 'T';
		}
		else
		{
			Mkstatus.cMsgType = 'D';
		}

		for(j=0;j<5;j++)
		{

			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(Mkstatus.subMktType[j].sExchId,Row[0],EXCHANGE_LEN);
				Mkstatus.subMktType[j].cSegment = Row[1][0];
				strncpy(Mkstatus.subMktType[j].sMktType,Row[2],MKT_TYPE_LEN);
				strncpy(Mkstatus.subMktType[j].sMktDesc,Row[3],MKT_DESC_LEN);
				strncpy(Mkstatus.subMktType[j].sMktStat,Row[4],STATUS_LEN);

				logDebug2("-------------------Start Printing Record no = %d ------------------",j);	
				logDebug2("Mkstatus.subMktType[%d].cSegment 	= %c",j,Mkstatus.subMktType[j].cSegment);

				logDebug2("Mkstatus.subMktType[%d].sExcgId 	= %s",j,Mkstatus.subMktType[j].sExchId);
				logDebug2("Mkstatus.subMktType[%d].sMktType	= %s",j,Mkstatus.subMktType[j].sMktType);
				logDebug2("Mkstatus.subMktType[%d].sMktDesc	= %s",j,Mkstatus.subMktType[j].sMktDesc);
				logDebug2("Mkstatus.subMktType[%d].sMktStat 	= %s",j,Mkstatus.subMktType[j].sMktStat);

				logDebug2("-------------------END------------------",j);	

			}


		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&Mkstatus,sizeof(struct VIEW_MKT_STATUS) ,iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;
		usleep(5000);
	}
	return TRUE;

}

BOOL fViewDealerLimit(CHAR *RcvMsg)
{
	logTimestamp("ENTRY [fViewDealerLimit]");
	struct VIEW_BRANCH_ADHOC_LIMIT_REQ *pViewBranchLmtiReq;
	struct INT_COMMON_REQUEST_HDR   *BrnchLmtReq;
	struct VIEW_BRANCH_ADHOC_LIMIT_RESP pViewBranchLmtiResp;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	CHAR            *sViewBrnchLmt = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	pViewBranchLmtiReq = (struct VIEW_BRANCH_ADHOC_LIMIT_REQ *)RcvMsg;
	logDebug2("pViewBranchLmtiReq->sBranchID :%s:",pViewBranchLmtiReq->sBranchID);
/*	sprintf(sViewBrnchLmt,"SELECT A.MAX_CLIENT_ALLOWED,A.MAX_LIMIT_PER_CLIENT,A.MAX_TOTAL_LIMIT AS MAX_LIMIT,IFNULL( SUM(BAC_ADHOC_AMOUNT),0) AS UTILIZED_AMT,\
			IFNULL(( A.MAX_TOTAL_LIMIT-SUM(BAC_ADHOC_AMOUNT)),0) AS REMENING_AMT FROM TERMINAL_LIMIT_FOR_BRANCH A ,\
			TERMINAL_LIMIT_FOR_CLIENT B WHERE A.BRANCH_ID= B.BAC_BRANCH_ID AND A.BRANCH_ID=\"%s\";",pViewBranchLmtiReq->sBranchID);*/

/*	sprintf(sViewBrnchLmt,"SELECT A.MAX_CLIENT_ALLOWED,A.MAX_LIMIT_PER_CLIENT,A.MAX_TOTAL_LIMIT AS MAX_LIMIT,IFNULL(SUM(B.BAC_ADHOC_AMOUNT),0) AS UTILIZED_AMT,\
			IFNULL((A.MAX_TOTAL_LIMIT - IFNULL(SUM(B.BAC_ADHOC_AMOUNT),0)),0) AS REMENING_AMT FROM TERMINAL_LIMIT_FOR_BRANCH A,\
			TERMINAL_LIMIT_FOR_CLIENT B WHERE A.BRANCH_ID = B.BAC_BRANCH_ID AND A.BRANCH_ID = \"%s\";",pViewBranchLmtiReq->sBranchID);
*/
	sprintf(sViewBrnchLmt,"SELECT IFNULL(A.MAX_CLIENT_ALLOWED,0) AS MAX_ALLOW,IFNULL(A.MAX_LIMIT_PER_CLIENT,0)AS MAX_LIMIT_PER_CLIENT,\
			IFNULL(A.MAX_TOTAL_LIMIT,0) AS MAX_TOTAL_LIMIT,IFNULL(SUM(B.BAC_ADHOC_AMOUNT),0) AS UTILIZED_AMT,\
                        IFNULL((A.MAX_TOTAL_LIMIT - IFNULL(SUM(B.BAC_ADHOC_AMOUNT),0)),0) AS REMENING_AMT FROM TERMINAL_LIMIT_FOR_BRANCH A,\
                        TERMINAL_LIMIT_FOR_CLIENT B WHERE A.BRANCH_ID = B.BAC_BRANCH_ID AND A.BRANCH_ID = \"%s\";",pViewBranchLmtiReq->sBranchID);

	logDebug2("sViewBrnchLmt = %s",sViewBrnchLmt);
	if(mysql_query(DBQueries,sViewBrnchLmt) != SUCCESS)
	{
		sql_Error(DBQueries);
		//iError  = mysql_errno(DBQueries);
		logDebug2("ERROR Received While Calling sViewBrnchLmt ");
		return ERROR;
	}
	logDebug2("hii");
	Res = mysql_store_result(DBQueries);
	logDebug2("hii2");
	if(Row = mysql_fetch_row(Res))
	{
		logDebug2("hii3");
		pViewBranchLmtiResp.IntRespHeader.iSeqNo = 0;
		pViewBranchLmtiResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_BRANCH_ADHOC_LIMIT_RESP);
		pViewBranchLmtiResp.IntRespHeader.iErrorId = 0;
		pViewBranchLmtiResp.IntRespHeader.iMsgCode = TC_INT_VIEW_DEALER_ADHOC_LIMIT_RESP;
		pViewBranchLmtiResp.IntRespHeader.iUserId = pViewBranchLmtiReq->ReqHeader.iUserId;
		pViewBranchLmtiResp.IntRespHeader.cSource = pViewBranchLmtiReq->ReqHeader.cSource ;

		pViewBranchLmtiResp.fMaxClnt = atof(Row[0]);
		pViewBranchLmtiResp.fMaxLmtPrClnt = atof(Row[1]);
		pViewBranchLmtiResp.fMaxTtlLmt = atof(Row[2]);
		pViewBranchLmtiResp.fAmt = atof(Row[3]);
		pViewBranchLmtiResp.fRemAmt = atof(Row[4]);
		logDebug2("pViewBranchLmtiResp.fMaxClnt = %lf",pViewBranchLmtiResp.fMaxClnt);
		logDebug2("pViewBranchLmtiResp.fMaxLmtPrClntt = %lf",pViewBranchLmtiResp.fMaxLmtPrClnt);
		logDebug2("pViewBranchLmtiResp.fMaxTtlmt = %lf",pViewBranchLmtiResp.fMaxTtlLmt);
		logDebug2("pViewBranchLmtiResp.fAmt = %lf",pViewBranchLmtiResp.fAmt);
		logDebug2("pViewBranchLmtiResp.fRemAmt = %lf",pViewBranchLmtiResp.fRemAmt);
		logDebug2("END");
	}
	else
	{
		logDebug3("ERRor.....");
	}
	free(sViewBrnchLmt);
	logDebug2("pViewBranchLmtiResp.IntRespHeader.iUserId :%llu:",pViewBranchLmtiResp.IntRespHeader.iUserId);
	iRelayID = find_user_adapter(pViewBranchLmtiResp.IntRespHeader.iUserId);
	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pViewBranchLmtiResp,sizeof(struct VIEW_BRANCH_ADHOC_LIMIT_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}



	logTimestamp("Exit : fViewDealerLimit");
}

BOOL    fClientDPHoldings(CHAR *RcvMsg)
{
        logTimestamp("Entry : fClientDPHoldings");

        struct VIEW_DP_HOLDING_QUERY_REQ  *pViewClientHoldingReq;
        struct VIEW_DP_HOLDING_RESP	pClientHoldingResp;
        struct VIEW_COMMON_HDR_RESP     pClientHoldingHdrResp;

        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        
        CHAR sCliHlding [DOUBLE_MAX_QUERY_SIZE];


        LONG32 iErrorId=0;
        LONG32 i=0,j=0;

        CHAR         sClientId[CLIENT_ID_LEN];
        CHAR         sEntityId[ENTITY_ID_LEN];
        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sViewHld      [QUERY_SIZE];
        CHAR    sSymbol [DB_SYM_LEN];

        memset(sWhere_Clause,'\0',QUERY_SIZE);
        memset(sViewHld,'\0',QUERY_SIZE);
        memset(sClientId,'\0',CLIENT_ID_LEN);
        memset(sEntityId,'\0',ENTITY_ID_LEN);
        memset(sCliHlding,'\0',DOUBLE_MAX_QUERY_SIZE);
        memset(sSymbol,'\0',DB_SYM_LEN);
        LONG32          iNoOfRec=0;
        LONG32          iTempNoOfRec = 0;
        DOUBLE64        fNoOfRec = 0.00;
        LONG32          iNoOfPkt = 0;

        pViewClientHoldingReq = (struct VIEW_DP_HOLDING_QUERY_REQ*)RcvMsg;

        logDebug2("pViewClientHoldingReq->sClientId = %s",pViewClientHoldingReq->sClientId);

	sprintf(sCliHlding,"SELECT  RECORD_TYPE,  LINE_NUMBER,  BRANCH_CODE, BEN_ACC_NUM,  BEN_CATEGORY,  ISIN,  (CASE BEN_ACC_TYPE  WHEN 01 THEN 'Beneficiary Freeze'    WHEN 11 THEN 'Beneficiary'   WHEN 12 THEN 'Pending Demat'   WHEN 13 THEN 'Pending Remat/Repurchase'   WHEN 14 THEN 'Pledge'   WHEN 16 THEN 'Pledge'   END) BEN_ACC_TYPE,  BEN_ACC_POSITION,  (CASE ISIN_STATUS WHEN 01 THEN 'Active'    WHEN 02 THEN 'Suspended'    WHEN 03 THEN 'Blocked due to ACA'    WHEN 04 THEN 'To be Closed'    WHEN 05 THEN 'Closed'   END) ISIN_STATUS,  (CASE ISIN_TYPE WHEN 01 THEN 'Equity'   WHEN 02 THEN 'Postal Savings Scheme'   WHEN 03 THEN 'Preferential Shares'   WHEN 04 THEN 'Bond'   WHEN 05 THEN 'Deep Discount Bond'   WHEN 06 THEN 'Floating Rate Bond'   WHEN 07 THEN 'Commercial Paper'   WHEN 08 THEN 'Step Discount Bond'   WHEN 09 THEN 'Regular Return Bond'   WHEN 10 THEN 'Certificate of Deposit'   WHEN 11 THEN 'Securitised Instruments'   WHEN 12 THEN 'Debenture'   WHEN 13 THEN 'Units'   WHEN 14 THEN 'Government Securities'   WHEN 15 THEN 'Warrants'   WHEN 16 THEN 'Commodity'   WHEN 17 THEN 'RBI Bonds'   WHEN 19 THEN 'Indian Depository Receipt'   WHEN 20 THEN 'Mutual Fund'   WHEN 21 THEN 'Alternative Investment Fund (AIF)'   WHEN 22 THEN 'Treasury Bills'   WHEN 24 THEN 'Municipal Bond'   WHEN 25 THEN 'Real Estate Investment Trusts (REIT)'   END) ISIN_TYPE,  BLOCK_LOCK_FLAG,  BLOCK_LOCK_CODE,  LOCK_IN_RELEASE_DATE,  HOLD_QUANTITY,  UNDER_PROCESS_QTY,  CLIENT_ID,  SM.SM_EXCH_SYMBOL   FROM  RMS_DP_ALL_HOLDING RDAH   LEFT JOIN  SECURITY_MASTER SM ON (RDAH.ISIN = SM.SM_ISIN_CODE)   WHERE  SM.SM_SEGMENT = 'E'   AND SM.SM_EXCH_STATUS = 'A'   AND SM.SM_STATUS = 'A'   AND SM.SM_EXCHANGE = (CASE   WHEN    SM.SM_EXCHANGE = 'NSE' AND SM.SM_EXCH_STATUS = 'A'   THEN    'NSE'   WHEN    SM.SM_EXCHANGE = 'NSE' AND SM.SM_EXCH_STATUS <> 'A'   THEN    'BSE'  END) AND CLIENT_ID = \"%s\"; ",pViewClientHoldingReq->sClientId);

        logDebug2(" fClientHoldings :%s:",sCliHlding);

        if(mysql_query(DBQueries,sCliHlding) != SUCCESS)
        {
                logSqlFatal("ERROR in client Holding Query.");
                sql_Error(DBQueries);
        }

        Res = mysql_store_result(DBQueries);
        iNoOfRec = mysql_num_rows(Res);
		
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        
        iTempNoOfRec = iNoOfPkt;
		
 	pClientHoldingHdrResp.IntRespHeader.iSeqNo = 0;
        pClientHoldingHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pClientHoldingHdrResp.IntRespHeader.iErrorId = 0;
        pClientHoldingHdrResp.IntRespHeader.iMsgCode = TC_INT_HDR_DP_HOLDING_RESP;
        pClientHoldingHdrResp.IntRespHeader.iUserId = pViewClientHoldingReq->ReqHeader.iUserId;
        pClientHoldingHdrResp.IntRespHeader.cSource = pViewClientHoldingReq->ReqHeader.cSource ;

        pClientHoldingHdrResp.cMsgType = 'H';
        pClientHoldingHdrResp.iNoofRec = iNoOfRec;

        logDebug2(" pClientHoldingHdrResp.cMsgType:%c:,pClientHoldingHdrResp.iNoofRec:%d:",pClientHoldingHdrResp.cMsgType,pClientHoldingHdrResp.iNoofRec);
        logDebug2("pViewClientHoldingReq->ReqHeader.iUserId = %llu",pViewClientHoldingReq->ReqHeader.iUserId);
        iRelayID = find_user_adapter(pViewClientHoldingReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == FIND_USER_RELAY_ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }


        if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pClientHoldingHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logFatal("Write Q id %d", iIntActiveToRelDirQ);
                exit(ERROR);
        }

		 for(i=0;i<iNoOfPkt;i++)
        {
                memset(&pClientHoldingResp,'\0',sizeof(struct VIEW_DP_HOLDING_RESP));
                pClientHoldingResp.IntRespHeader.iSeqNo = 0;
                pClientHoldingResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DP_HOLDING_RESP);
                pClientHoldingResp.IntRespHeader.iErrorId = 0;
                pClientHoldingResp.IntRespHeader.iMsgCode = TC_INT_DP_HOLDING_RESP;
                pClientHoldingResp.IntRespHeader.iUserId = pViewClientHoldingReq->ReqHeader.iUserId;
                pClientHoldingResp.IntRespHeader.cSource = pViewClientHoldingReq->ReqHeader.cSource ;

                if(iTempNoOfRec <= 1)
                {
                        pClientHoldingResp.cMsgType = 'T';
                }
                else
                {
                        pClientHoldingResp.cMsgType = 'D';
                }

                for(j=0;j<5;j++)
                {

                        if((Row = mysql_fetch_row(Res)))
                        {
				strncpy(pClientHoldingResp.subdpHolding[j].sRecordType,Row[0],RECORD_TYPE);
                                strncpy(pClientHoldingResp.subdpHolding[j].sLineNumber,Row[1],LINE_NUMBER);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBranchCode,Row[2],BRANCH_CODE_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sDPId,Row[3],DP_ID_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBenCategory,Row[4],BEN_CATEGORY);
                                strncpy(pClientHoldingResp.subdpHolding[j].sIsin,Row[5],DB_ISIN_CODE_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBenAccType,Row[6],BEN_ACC_TYP_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBenAccPosition,Row[7],BEN_ACC_POSITION_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sIsinStatus,Row[8],ISIN_STATUS_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sIsinType,Row[9],ISIN_TYPE_LEN);
                                pClientHoldingResp.subdpHolding[j].cBlock_Lock_Flag = Row[10][0];
				strncpy(pClientHoldingResp.subdpHolding[j].sLockIn_Release_Date,Row[11],DATE_TIME_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sBlock_Lock_code,Row[12],BLOCK_LOCK_CODE);
				pClientHoldingResp.subdpHolding[j].iHoldQty = atoi(Row[13]);
                                pClientHoldingResp.subdpHolding[j].iUnderHoldQty = atoi(Row[14]);
                                strncpy(pClientHoldingResp.subdpHolding[j].sClientId,Row[15],CLIENT_ID_LEN);
                                strncpy(pClientHoldingResp.subdpHolding[j].sSymbol,Row[16],DB_SYMBOL_LEN);

                               
                                logDebug2("-------------------Start Printing Record no = %d ------------------",j);
                                logDebug2("pClientHoldingResp.IntRespHeader.iMsgLength  = %d",pClientHoldingResp.IntRespHeader.iMsgLength);
                                logDebug2("pClientHoldingResp.IntRespHeader.iMsgCode    = %d",pClientHoldingResp.IntRespHeader.iMsgCode);
                                logDebug2("pClientHoldingResp.IntRespHeader.iUserId     = %llu",pClientHoldingResp.IntRespHeader.iUserId);
                                logDebug2("pClientHoldingResp.IntRespHeader.cSource     = %c",pClientHoldingResp.IntRespHeader.cSource);
                                logDebug2("pClientHoldingResp.cMsgType                  = %c",pClientHoldingResp.cMsgType);

                                logDebug2("pClientHoldingResp.subdpHolding[%d].sRecordType = %s",j,pClientHoldingResp.subdpHolding[j].sRecordType);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sExcgId     = %s",j,pClientHoldingResp.subdpHolding[j].sLineNumber);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBranchCode = %s",j,pClientHoldingResp.subdpHolding[j].sBranchCode);
                                logDebug2("pClientHolResp.subdpHolding[%d].sDPId = %s",j,pClientHoldingResp.subdpHolding[j].sDPId);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBenCategory = %s",j,pClientHoldingResp.subdpHolding[j].sBenCategory);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sIsin = %s",j,pClientHoldingResp.subdpHolding[j].sIsin);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBenAccType = %s",j,pClientHoldingResp.subdpHolding[j].sBenAccType);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBenAccPosition = %s",j,pClientHoldingResp.subdpHolding[j].sBenAccPosition);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sIsinStatus = %s",j,pClientHoldingResp.subdpHolding[j].sIsinStatus);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sIsinType = %s",j,pClientHoldingResp.subdpHolding[j].sIsinType);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sLockIn_Release_Date = %s",j,pClientHoldingResp.subdpHolding[j].sLockIn_Release_Date);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].cBlock_Lock_Flag = %c",j,pClientHoldingResp.subdpHolding[j].cBlock_Lock_Flag);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sBlock_Lock_code = %s",j,pClientHoldingResp.subdpHolding[j].sBlock_Lock_code);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].iHoldQty = %d",j,pClientHoldingResp.subdpHolding[j].iHoldQty);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].iUnderHoldQty = %d",j,pClientHoldingResp.subdpHolding[j].iUnderHoldQty);
                                logDebug2("pClientHoldingResp.subdpHolding[%d].sSymbol = %s",j,pClientHoldingResp.subdpHolding[j].sSymbol);

                                logDebug2("-------------------END------------------",j);

                        }


                }

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pClientHoldingResp,sizeof(struct VIEW_DP_HOLDING_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logFatal("Write Q id %d", iIntActiveToRelDirQ);
                        exit(ERROR);
                }
                iTempNoOfRec--;
                usleep(5000);
        }
        return TRUE;

}
BOOL fAddDealerLimit(CHAR *RcvMsg)
{
	logTimestamp("ENTRY :fAddDealerLimit:");	
	struct ADD_BRANCH_ADHOC_LIMIT_REQ *pAddBrnchLimitReq;	
	struct ADD_BRANCH_ADHOC_LIMIT_RESP pAddBrnchLimitResp; 
	//	struct INT_COMMON_RESP_HDR  pAddBrnchLimitResp;
	pAddBrnchLimitReq  = (struct  ADD_BRANCH_ADHOC_LIMIT_REQ *)RcvMsg;
	CHAR            sRMSStatus[15];
	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32	iStatus = 0;

	CHAR                                    sErrorID[10];
	CHAR    sErrString[DB_REASON_DESC_LEN];
        memset ( sErrString,     '\0' ,DB_REASON_DESC_LEN);

	CHAR    sAddBrnchLimit      [DOUBLE_MAX_QUERY_SIZE];
	memset(sAddBrnchLimit,'\0',DOUBLE_MAX_QUERY_SIZE);

	logDebug2("pAddBrnchLimitReq->sClientID = %s",pAddBrnchLimitReq->sClientID);
	logDebug2("pAddBrnchLimitReq->sBranchID = %s",pAddBrnchLimitReq->sBranchID);
	logDebug2("pAddBrnchLimitReq->fAmt = %lf",pAddBrnchLimitReq->fAmt);
	logDebug2("pAddBrnchLimitReq->cTransactType = %c",pAddBrnchLimitReq->cTransactType);
	logDebug2("pAddBrnchLimitReq.ReqHeader->cSegment = %c",pAddBrnchLimitReq->ReqHeader.cSegment);

	sprintf(sAddBrnchLimit,"CALL PR_BRANCH_ADHOC_TO_CLIENT(\"%s\",\"%s\",\'%c\',%lf,\'%c\',@ZSTATUS);\
			SELECT @ZSTATUS;",pAddBrnchLimitReq->sClientID,pAddBrnchLimitReq->sBranchID,pAddBrnchLimitReq->ReqHeader.cSegment,\
			pAddBrnchLimitReq->fAmt,pAddBrnchLimitReq->cTransactType);

	logDebug2("sAddBrnchLimit :%s:",sAddBrnchLimit);
	if(mysql_query(DBQueries,sAddBrnchLimit) != SUCCESS)
	{
		logSqlFatal(" ---------ERROR IN CALLING PR_BRANCH_ADHOC_TO_CLIENT----------");
		sql_Error (DBQueries);
	}
	else
	{
		logDebug2("------SUCCESS IN QUERY-----");
	}
	/**
	  Res = mysql_store_result(DBQueries);
	  if((Row = mysql_fetch_row(Res)))
	  {
	  strncpy(sRMSStatus,Row[0],15);
	  }
	  else
	  {
	  logDebug2("There is some error while fetching the data :");
	  }
	  if(sRMSStatus == 'S')
	  {	
	  logDebug3("---------SUCESS----------");
	  pAddBrnchLimitResp.iSeqNo = 0;
	  pAddBrnchLimitResp.iMsgLength = sizeof(struct INT_COMMON_RESP_HDR);
	  pAddBrnchLimitResp.iErrorId = 0;
	  pAddBrnchLimitResp.iMsgCode = TC_INT_ADD_DEALER_ADHOC_LIMIT_RESP;
	  pAddBrnchLimitResp.iUserId = pAddBrnchLimitReq->ReqHeader.iUserId;
	  pAddBrnchLimitResp.cSource = pAddBrnchLimitReq->ReqHeader.cSource ;
	  strncpy(pAddLimitResp.sStatus,"ADHOC LIMIT ADDED SUCESSFULLY",BRANCH_ID_LEN);

	  }
	  else
	  {
	  logDebug3("--------ERROR-----------");
	  strncpy(pAddLimitResp.sStatus,"ERROR OCCURED !!!",BRANCH_ID_LEN);
	  }
	 **/
	do{

		Res = mysql_store_result(DBQueries);
		if(Res)
		{
			if((Row = mysql_fetch_row(Res)))
			{
				strncpy(sRMSStatus,Row[0],15);

			}
			else
			{
				logDebug2("There is some error while fetching the data :");
			}
			logDebug2("sRMSStatus :%s:",sRMSStatus);
			pAddBrnchLimitResp.IntRespHeader.iSeqNo = 0;
			pAddBrnchLimitResp.IntRespHeader.iMsgLength = sizeof(struct ADD_BRANCH_ADHOC_LIMIT_RESP);
			pAddBrnchLimitResp.IntRespHeader.iErrorId = 0;
			pAddBrnchLimitResp.IntRespHeader.iMsgCode = TC_INT_ADD_DEALER_ADHOC_LIMIT_RESP;
			pAddBrnchLimitResp.IntRespHeader.iUserId = pAddBrnchLimitReq->ReqHeader.iUserId;
			pAddBrnchLimitResp.IntRespHeader.cSource = pAddBrnchLimitReq->ReqHeader.cSource ;
			if(sRMSStatus[0] == 'S')
			{
				logDebug3("---------SUCESS----------");

				strncpy(pAddBrnchLimitResp.sStatus,"ADHOC ADDED SUCESSFULLY",DB_REASON_DESC_LEN);

			}
			else
			{
				logDebug3("--------ERROR-----------");
				strncpy(sErrorID,sRMSStatus,15);
				//strncpy(pAddBrnchLimitResp.sStatus,"ERROR OCCURED !!!",DB_REASON_DESC_LEN);
				if(fFetchErrStr(sErrorID, &sErrString) == TRUE )
			        {
		                	logDebug2("Reason is :%s:",sErrString);
		                	strncpy(pAddBrnchLimitResp.sStatus,sErrString,DB_REASON_DESC_LEN);	
	       			}	
			        else
			       	{
		        	        strncpy(sErrString,"Not Specified ",DB_REASON_DESC_LEN);	
					strncpy(pAddBrnchLimitResp.sStatus,sErrString,DB_REASON_DESC_LEN);
				}

			
			}
		}
		else
		{
			logDebug2("No Result Set ");
		}

		if((iStatus =mysql_next_result(DBQueries)) > 0)
		{
			logDebug3("Could not execute statement :%d:",iStatus);
		}

		logDebug2("After print 1 :%d: :%d:",iStatus,mysql_next_result(DBQueries));

	}while(iStatus == 0);
	logDebug2("pAddLimitResp.sStatus :%s:",pAddBrnchLimitResp.sStatus);	
	iRelayID = find_user_adapter(pAddBrnchLimitResp.IntRespHeader.iUserId);
	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}

	logDebug2("pAddLimitResp.sStatus :%s:",pAddBrnchLimitResp.sStatus);
	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pAddBrnchLimitResp,sizeof(struct ADD_BRANCH_ADHOC_LIMIT_RESP) ,iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}

	logTimestamp("Exit : fAddDealerLimit");


}

BOOL fAddedViewClientLimit(CHAR *RcvMsg)
{
	logTimestamp("ENTRY :fAddedViewClientLimit:");
	struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_REQ *pAddBrnchLimitReq;
	struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_RESP pAddLimitResp;
	struct VIEW_COMMON_HDR_RESP pAddBrnchLimitResp;

	pAddBrnchLimitReq  = (struct  VIEW_ADDED_BRANCH_ADHOC_LIMIT_REQ *)RcvMsg;

	MYSQL_RES       *Res;
	MYSQL_ROW       Row;
	LONG32          iNoOfRec=0;
	LONG32          iTempNoOfRec = 0;
	DOUBLE64        fNoOfRec = 0.00;
	LONG32          iNoOfPkt = 0;

	CHAR    sAddBrnchLimit      [DOUBLE_MAX_QUERY_SIZE];
	memset(sAddBrnchLimit,'\0',DOUBLE_MAX_QUERY_SIZE);

	logDebug2("pAddBrnchLimitReq->sBranchID = %s",pAddBrnchLimitReq->sBranchID);

	sprintf(sAddBrnchLimit,"SELECT BAC_CLIENT_ID,BAC_BRANCH_ID,BAC_ADHOC_AMOUNT,BAC_SEGMENT FROM TERMINAL_LIMIT_FOR_CLIENT WHERE BAC_BRANCH_ID=\"%s\";",pAddBrnchLimitReq->sBranchID);

	logDebug2("sAddBrnchLimit :%s:",sAddBrnchLimit);

	if(mysql_query(DBQueries,sAddBrnchLimit) != SUCCESS)
	{
		logSqlFatal(" ---------ERROR IN VIEWING ADDED ADHOC_TO_CLIENT----------");
		sql_Error (DBQueries);
	}

	Res = mysql_store_result(DBQueries);
	iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
	iNoOfPkt = ceil(fNoOfRec/5);
	iTempNoOfRec = iNoOfPkt;
	logDebug2("iTempNoOfRec = %d",iTempNoOfRec);
	pAddBrnchLimitResp.IntRespHeader.iSeqNo = 0;
	pAddBrnchLimitResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
	pAddBrnchLimitResp.IntRespHeader.iErrorId = 0;
	pAddBrnchLimitResp.IntRespHeader.iMsgCode = TC_INT_ADDED_VIEW_BRANCH_ADHOC_LIMIT_HDR_RESP;
	pAddBrnchLimitResp.IntRespHeader.iUserId = pAddBrnchLimitReq->ReqHeader.iUserId;
	pAddBrnchLimitResp.IntRespHeader.cSource = pAddBrnchLimitReq->ReqHeader.cSource ;
	pAddBrnchLimitResp.cMsgType = 'H';
	pAddBrnchLimitResp.iNoofRec = iNoOfRec;


	logDebug2("pAddBrnchLimitResp.IntRespHeader.iSeqNo :%d: ",pAddBrnchLimitResp.IntRespHeader.iSeqNo);
	logDebug2("pAddBrnchLimitResp.IntRespHeader.iMsgLength :%d: ",pAddBrnchLimitResp.IntRespHeader.iMsgLength);
	logDebug2("pAddBrnchLimitResp.IntRespHeader.iErrorId :%d: ",pAddBrnchLimitResp.IntRespHeader.iErrorId);
	logDebug2("pAddBrnchLimitResp.IntRespHeader.iMsgCode :%d: ",pAddBrnchLimitResp.IntRespHeader.iMsgCode);
	logDebug2("pAddBrnchLimitResp.IntRespHeader.iUserId :%llu: ",pAddBrnchLimitResp.IntRespHeader.iUserId);		
	logDebug2("pAddBrnchLimitResp.IntRespHeader.cSource :%c: ",pAddBrnchLimitResp.IntRespHeader.cSource);		
	logDebug2("pAddBrnchLimitResp.cMsgType :%c: ",pAddBrnchLimitResp.cMsgType );		
	logDebug2("pAddBrnchLimitResp.iNoofRec :%d: ",pAddBrnchLimitResp.iNoofRec);	

	
	iRelayID = find_user_adapter(pAddBrnchLimitReq->ReqHeader.iUserId);
	if(iRelayID == FIND_USER_RELAY_ERROR)
	{
		logDebug2("Relay ID not found");
		return FALSE;
	}


	if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pAddBrnchLimitResp,sizeof(struct VIEW_COMMON_HDR_RESP),iRelayID) != TRUE ))
	{
		perror("Error WriteMsgQ: ");
		logFatal("Write Q id %d", iIntActiveToRelDirQ);
		return FALSE;
	}
	for(i=0;i<iNoOfPkt;i++)
	{
		memset(&pAddLimitResp,'\0',sizeof(struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_RESP));			
		pAddLimitResp.IntRespHeader.iSeqNo = 0;
		pAddLimitResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_RESP);
		pAddLimitResp.IntRespHeader.iErrorId = 0;
		pAddLimitResp.IntRespHeader.iMsgCode = TC_INT_ADDED_VIEW_CLIENT_ADHOC_LIMIT_RESP;
		pAddLimitResp.IntRespHeader.iUserId = pAddBrnchLimitReq->ReqHeader.iUserId;
		pAddLimitResp.IntRespHeader.cSource = pAddBrnchLimitReq->ReqHeader.cSource ;

		if(iTempNoOfRec <= 1)
		{
			pAddLimitResp.cMsgType = 'T';
		}
		else
		{
			pAddLimitResp.cMsgType = 'D';
		}
		logDebug2("pAddLimitResp.IntRespHeader.iSeqNo :%d: ",pAddLimitResp.IntRespHeader.iSeqNo );
		logDebug2("pAddLimitResp.IntRespHeader.iMsgLength :%d: ",pAddLimitResp.IntRespHeader.iMsgLength);
		logDebug2("pAddLimitResp.IntRespHeader.iErrorId:%d: ",pAddLimitResp.IntRespHeader.iErrorId);
		logDebug2("pAddLimitResp.IntRespHeader.iMsgCode:%d: ",pAddLimitResp.IntRespHeader.iMsgCode);
		logDebug2("pAddLimitResp.IntRespHeader.iUserId:%llu: ",pAddLimitResp.IntRespHeader.iUserId);
		logDebug2("pAddLimitResp.IntRespHeader.cSource:%c: ",pAddLimitResp.IntRespHeader.cSource );
		logDebug2("pAddLimitResp.cMsgType :%c: ",pAddLimitResp.cMsgType );


		for(j=0;j<5;j++)
		{
			if(Row=mysql_fetch_row(Res))
			{
				strncpy(pAddLimitResp.subviewBranchLimit[j].sClientID,Row[0],BRANCH_ID_LEN);
				strncpy(pAddLimitResp.subviewBranchLimit[j].sBranchID,Row[1],BRANCH_ID_LEN);
				pAddLimitResp.subviewBranchLimit[j].fAmt = atof(Row[2]);
				pAddLimitResp.subviewBranchLimit[j].cSegment = Row[3][0];

				logDebug2("-------------------Start Printing Record no = %d ------------------",j);				
				logDebug2("pAddLimitResp.subviewBranchLimit[%d].sClientID :%s:",j,pAddLimitResp.subviewBranchLimit[j].sClientID);
				logDebug2("pAddLimitResp.subviewBranchLimit[%d].sBranchID :%s:",j,pAddLimitResp.subviewBranchLimit[j].sBranchID);
				logDebug2("pAddLimitResp.subviewBranchLimit[%d].fAmt :%lf:",j,pAddLimitResp.subviewBranchLimit[j].fAmt);
				logDebug2("pAddLimitResp.subviewBranchLimit[%d].cSegment :%c:",j,pAddLimitResp.subviewBranchLimit[j].cSegment);
				logDebug2("-------------------END------------------",j);
			}
		}

		if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pAddLimitResp,sizeof(struct VIEW_ADDED_BRANCH_ADHOC_LIMIT_RESP),iRelayID) != TRUE ))
		{
			perror("Error WriteMsgQ: ");
			logFatal("Write Q id %d", iIntActiveToRelDirQ);
			return FALSE;
		}
		iTempNoOfRec--;	
	}

	logTimestamp("Exit : fAddedViewClientLimit");
}

BOOL    fFetchErrStr(CHAR *sErrorID,CHAR *sErrString)
{

        logTimestamp("Entry : fFetchErrStr");
        MYSQL_RES               *Res;
        MYSQL_ROW               Row;
        INT16   iNumRow;


        CHAR SelQuery [MAX_QUERY_SIZE];
        memset(SelQuery,'\0',MAX_QUERY_SIZE);

        //        logDebug2(" fFetchErrStr sErrorID :%s:",sErrorID);


        sprintf(SelQuery,"SELECT   RM_REASON_DESC FROM REASON_MASTER WHERE RM_EXCH_ID = 'INT' AND RM_ERR_CODE = \"%s\" ;",sErrorID);

        logDebug2("%s",SelQuery);
        if (mysql_query(DBQueries, SelQuery) != SUCCESS)
        {
                logSqlFatal("Error in Query");
                sql_Error(DBQueries);
                return FALSE;
        }

        Res = mysql_store_result(DBQueries);
        logDebug2("Rows : %i",mysql_num_rows(Res));

        iNumRow = mysql_num_rows(Res);


        if(iNumRow != 0)
        {

                if((Row = mysql_fetch_row(Res)))
                {
                        logDebug2("reason is  :%s: ",Row[0]);
                        strncpy(sErrString,Row[0],DB_REASON_DESC_LEN);

                }
        }
        else
 	{
                logDebug2("Error ID not Found in DB :%s:",sErrorID);
                return FALSE;
        }

        logTimestamp("Exit : fFetchErrStr");
        return TRUE;
}

BOOL    fViewPayOut(CHAR *RcvMsg)
{
        logTimestamp("Entry : fViewPayOut");
        struct  VIEW_DL_PAYOUT_REPORT_REQ          *PViewPayoutReq;
        struct  VIEW_COMMON_HDR_RESP            pPayOutHdrResp;
        struct  VIEW_DL_PAYOUT_REPORT_RESP         pViewPayOutResp;

        PViewPayoutReq = (struct  VIEW_PAYOUT_REPORT_REQ *)RcvMsg;

        CHAR    sWhere_Clause[QUERY_SIZE];
        CHAR    sSubPayOutQry[QUERY_SIZE];
        CHAR    sPayOutQry[MAX_QUERY_SIZE];
        memset(sPayOutQry,'\0',MAX_QUERY_SIZE);

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;

        logDebug2("PViewPayoutReq->sClientId = %s",PViewPayoutReq->sClientId);
        logDebug2("PViewPayoutReq->cPayStatus = %c",PViewPayoutReq->cPayStatus);
        logDebug2("PViewPayoutReq->sDateFrom = %s",PViewPayoutReq->sDateFrom);
        logDebug2("PViewPayoutReq->sDateTo = %s",PViewPayoutReq->sDateTo);
        logDebug2("PViewPayoutReq->sAccType = %s",PViewPayoutReq->sAccType);

        if(strcmp(PViewPayoutReq->sClientId,SELECT_ALL))
        {
                memset(sSubPayOutQry,'\0',QUERY_SIZE);
                sprintf(sSubPayOutQry," AND RPD_CLIENT_ID LIKE \"%s\"",PViewPayoutReq->sClientId);
                logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
                strcat(sWhere_Clause,sSubPayOutQry);
                logDebug2("sWhere_Clause 1 = %s",sWhere_Clause);
        }
        if(PViewPayoutReq->cPayStatus != SEL_ALL)
        {
                memset(sSubPayOutQry,'\0',QUERY_SIZE);
                sprintf(sSubPayOutQry," AND RPD_PAY_STATUS = \'%c\'",PViewPayoutReq->cPayStatus);
                logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
                strcat(sWhere_Clause,sSubPayOutQry);
                logDebug2("sWhere_Clause 2 = %s",sWhere_Clause);
        }
	if((strcmp(PViewPayoutReq->sDateFrom,SELECT_ALL)) && (strcmp(PViewPayoutReq->sDateTo,SELECT_ALL)))
        {
                memset(sSubPayOutQry,'\0',QUERY_SIZE);
                sprintf(sSubPayOutQry,"AND DATE(RPD_REQUEST_DATE) BETWEEN STR_TO_DATE(\"%s\", '%%d/%%m/%%Y') AND STR_TO_DATE(\"%s\", '%%d/%%m/%%Y')",
                                PViewPayoutReq->sDateFrom,PViewPayoutReq->sDateTo);
                logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
                strcat(sWhere_Clause,sSubPayOutQry);
                logDebug2("sWhere_Clause 3 = %s",sWhere_Clause);
        }
        if(strcmp(PViewPayoutReq->sAccType,SELECT_ALL))
        {
                memset(sSubPayOutQry,'\0',QUERY_SIZE);
                sprintf(sSubPayOutQry," AND RPD_ACC_TYPE = \"%s\"",PViewPayoutReq->sAccType);
                logDebug2("sSubPayOutQry = %s",sSubPayOutQry);
                strcat(sWhere_Clause,sSubPayOutQry);
                logDebug2("sWhere_Clause 4 = %s",sWhere_Clause);
        }

        sprintf(sPayOutQry,"    select RPD_PAYMENT_ID,RPD_CLIENT_ID,RPD_PAY_AMOUNT,RPD_ACC_NO,RPD_IFSC_CODE,\
                        case RPD_PAY_STATUS WHEN 'S' THEN 'Submitted' WHEN 'R' THEN 'Rejected' WHEN 'A' THEN 'Approved' END AS RPD_PAY_STATUS,\
                        ifnull(RPD_PAY_STATUS_MSG,'NA') AS RPD_PAY_STATUS_MSG,\
                        RPD_REQUEST_DATE,RPD_ACC_TYPE,RPD_BANK_NAME,RPD_REMARK from REQUEST_PAYOUT_DETAILS \
                        where 1=1 %s order by RPD_PAYMENT_ID;",sWhere_Clause );

        logDebug2("sPayOutQry = %s",sPayOutQry);

        if(mysql_query(DBQueries,sPayOutQry) != SUCCESS)
        {
                logSqlFatal("Error in sPayOutQry.");
                sql_Error(DBQueries);
                return FALSE;
        }
        Res = mysql_store_result(DBQueries);
        iNoOfRec= mysql_num_rows(Res);
        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;

        logDebug2("iTempNoOfRec = %d",iTempNoOfRec);

        pPayOutHdrResp.IntRespHeader.iSeqNo = 0;
        pPayOutHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pPayOutHdrResp.IntRespHeader.iErrorId = 0;
	pPayOutHdrResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_PAYOUT_REPORT_HEADER_RESP;
        pPayOutHdrResp.IntRespHeader.iUserId = PViewPayoutReq->ReqHeader.iUserId;
        pPayOutHdrResp.IntRespHeader.cSource = PViewPayoutReq->ReqHeader.cSource;
        pPayOutHdrResp.cMsgType = 'H';
        pPayOutHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pPayOutHdrResp.IntRespHeader.iMsgLength = %d",pPayOutHdrResp.IntRespHeader.iMsgLength);
        logDebug2("pPayOutHdrResp.IntRespHeader.iMsgCode = %d",pPayOutHdrResp.IntRespHeader.iMsgCode);
        logDebug2("pPayOutHdrResp.IntRespHeader.iUserId = %llu",pPayOutHdrResp.IntRespHeader.iUserId);
        logDebug2("pPayOutHdrResp.IntRespHeader.cSource = %c",pPayOutHdrResp.IntRespHeader.cSource);
        logDebug2("pPayOutHdrResp.iNoofRec = %d",pPayOutHdrResp.iNoofRec);

        logDebug2("PViewPayoutReq->ReqHeader.iUserId = %llu",PViewPayoutReq->ReqHeader.iUserId);
        iRelayID = find_user_adapter(PViewPayoutReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iIntActiveToRelDirQ,(CHAR *)&pPayOutHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                logFatal("Error : WriteMsgQ = %d",iIntActiveToRelDirQ);
                return FALSE;
        }

        for(i=0;i<iNoOfPkt;i++)
        {
                memset(&pViewPayOutResp,'\0',sizeof(struct VIEW_DL_PAYOUT_REPORT_RESP));
                pViewPayOutResp.IntRespHeader.iSeqNo = 0;
                pViewPayOutResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_DL_PAYOUT_REPORT_RESP);
                pViewPayOutResp.IntRespHeader.iErrorId = 0;
                pViewPayOutResp.IntRespHeader.iMsgCode = TC_INT_ADMIN_VIEW_PAYOUT_REPORT_RESP;
                pViewPayOutResp.IntRespHeader.iUserId = PViewPayoutReq->ReqHeader.iUserId;
                pViewPayOutResp.IntRespHeader.cSource = PViewPayoutReq->ReqHeader.cSource;

                logDebug2("pViewPayOutResp.IntRespHeader.iMsgCode = %d",pViewPayOutResp.IntRespHeader.iMsgCode);

		if(iTempNoOfRec <= 1)
                {
                        pViewPayOutResp.cMsgType = 'T';
                }
                else
                {
                        pViewPayOutResp.cMsgType = 'D';
                }
                for(j=0;j<5;j++)
                {
                        if(Row = mysql_fetch_row(Res))
                        {
                                pViewPayOutResp.subPayoutReport[j].iPaymentID = atoi(Row[0]);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sClientId,Row[1],CLIENT_ID_LEN);
                                pViewPayOutResp.subPayoutReport[j].fPayAmount = atof(Row[2]);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sAccountNo,Row[3],BANK_ACC_NUM_LEN);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sIFSC_Code,Row[4],IFSC_CODE_LEN);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sPayStatus,Row[5],ORDER_STATUS);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sPayStatusMsg,Row[6],PAY_MODE_MSG_LEN);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sRequestDate,Row[7],DATE_TIME_LEN);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sLmtType,Row[8],LIMIT_TYPE_LEN);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sBankName,Row[9],BANK_NAME_LEN);
                                strncpy(pViewPayOutResp.subPayoutReport[j].sRemark,Row[10],REMARKS_LEN);

                                logDebug2("************<<<<<<<<<<<<< start >>>>>>>>>>>>>************");
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].iPaymentID = %d",j,pViewPayOutResp.subPayoutReport[j].iPaymentID);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sClientId = %s",j,pViewPayOutResp.subPayoutReport[j].sClientId);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].iPayAmount = %lf",j,pViewPayOutResp.subPayoutReport[j].fPayAmount);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sAccountNo = %s",j,pViewPayOutResp.subPayoutReport[j].sAccountNo);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sIFSC_Code = %s",j,pViewPayOutResp.subPayoutReport[j].sIFSC_Code);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sPayStatus = %s",j,pViewPayOutResp.subPayoutReport[j].sPayStatus);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sPayStatusMsg = %s",j,pViewPayOutResp.subPayoutReport[j].sPayStatusMsg);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sRequestDate = %s",j,pViewPayOutResp.subPayoutReport[j].sRequestDate);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sLmtType = %s",j,pViewPayOutResp.subPayoutReport[j].sLmtType);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sBankName = %s",j,pViewPayOutResp.subPayoutReport[j].sBankName);
                                logDebug2("pViewPayOutResp.subPayoutReport[%d].sRemark = %s",j,pViewPayOutResp.subPayoutReport[j].sRemark);
                        }
                }
                if(( WriteMsgQ(iIntActiveToRelDirQ,(CHAR *)&pViewPayOutResp,sizeof(struct VIEW_DL_PAYOUT_REPORT_RESP) ,iRelayID) != TRUE ))
                {
                        logFatal("Error : WriteMsgQ = %d ",iIntActiveToRelDirQ);
                        return FALSE;
		}

                iTempNoOfRec--;
	}

        logTimestamp("Exit : fViewPayOut");
        return TRUE;
}

BOOL fDrvSprdOrderBookDtls(CHAR *RcvMsg)
{
        logTimestamp("Entry : fDrvSprdOrderBookDtls");

        struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *pViewOrderBookReq;
        struct VIEW_ORDER_BOOK_DETAIL_RESP      pOrderBookResp;
        struct VIEW_COMMON_HDR_RESP     pOrderBookHdrResp;

        LONG32 i=0,j=0;
        MYSQL_RES       *Res;
        MYSQL_ROW       Row;
        CHAR            *sDrvOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);
        DOUBLE64        fReqOrderNo;
        LONG32          iNoOfPkt;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfRec=0;
        LONG32          iTempNoOfRec;
        CHAR            cOrdValidity;

        pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

        fReqOrderNo = pViewOrderBookReq->fOrderNo;

        logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,fReqOrderNo);

        sprintf(sDrvOrdBook,"SELECT  DRV_ORDER_NO,\
                        DRV_SERIAL_NO,\
                        DRV_MSG_CODE,\
                        DRV_SCRIP_CODE,\
                        DRV_VALIDITY,\
                        DRV_PRO_CLIENT,\
                        DRV_SOURCE_FLG,\
                        DRV_ORIG_CLORDID,\
                        DRV_TOTAL_QTY,\
                        DRV_REM_QTY,\
                        DRV_DISC_QTY,\
                        DRV_DISC_REM_QTY,\
                        DRV_ORDER_PRICE,\
                        DRV_TRIGGER_PRICE,\
                        DRV_TRD_TRADE_QTY,\
                        DRV_TRD_TRADE_PRICE,\
                        DRV_TOTAL_TRADED_QTY,\
                        DRV_TRD_EXCH_TRADE_NO,\
                 	DRV_PRODUCT_ID,\
                        DRV_EXCH_ORDER_NO,\
                        IFNULL(date_format(str_to_date(DRV_EXCH_ORDER_TIME,\'%%Y-%%m-%%d %%H:%%i:%%S\'),\'%%Y-%%m-%%d %%H:%%i:%%S\'),NOW()),\
                        DRV_ERROR_CODE,\
                        DRV_CLIENT_ID,\
                        DRV_BUY_SELL_IND,\
                        DRV_EXCH_ID,\
                        DRV_REASON_DESCRIPTION ,\
                        DRV_ENTITY_ID ,\
                        DRV_STRATEGY_ID ,\
                        DRV_PRO_CLIENT ,\
                        DRV_TRD_TRADE_PRICE ,\
                        DRV_GOOD_TILL_DAYS, \
                        IFNULL(DRV_PAN_NO,\"NA\"),\
                        IFNULL(DRV_PARTICIPANT_TYPE,'N'),\
                        IFNULL(DRV_MKT_PROTECT_FLG,'N')\
                        FROM DRV_ORDERS\
                        WHERE DRV_ORDER_NO = %lf\
                        ORDER BY DRV_ORDER_NO , DRV_SERIAL_NO desc ;",fReqOrderNo);

        logDebug2(" sDrvOrdBook :%s: ",sDrvOrdBook);

        if(mysql_query(DBQueries,sDrvOrdBook) != SUCCESS)
        {
                logSqlFatal("ERROR in DrvOrdBook Query.");
                sql_Error(DBQueries);
        }

        Res = mysql_store_result(DBQueries);

        iNoOfRec = mysql_num_rows(Res);
	fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfPkt;
	pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
        pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
        pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;
	pOrderBookHdrResp.cMsgType = 'H';
        pOrderBookHdrResp.iNoofRec = iNoOfRec;

        logDebug2(" pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);

        logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
        iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == FIND_USER_RELAY_ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logFatal("Write Q id %d", iIntActiveToRelDirQ);
                return FALSE;
        }

        logInfo(" I am in Derivative");

        for(i=0;i<iNoOfPkt;i++)
	{
                memset(&pOrderBookResp,'\0',sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP));
                pOrderBookResp.IntRespHeader.iSeqNo = 0;
                pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);

                pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
                pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
                pOrderBookResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource;

                if(iTempNoOfRec <= 1)
                {
                        pOrderBookResp.cMsgType = 'T';
                }
                else
                {
                        pOrderBookResp.cMsgType = 'D';
                }


                for(j=0;j<5;j++)
                {
                        if(Row=mysql_fetch_row(Res))
                        {
                                strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);


                                pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[25]);
                                strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[24],EXCHANGE_LEN);
                                pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
                                pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
                                pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3],SECURITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

                                if(atoi(Row[4]) == VALIDITY_DAY)
				{
                                        pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
                                }
                                else if(atoi(Row[4]) == VALIDITY_IOC)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
                                }

                                pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[8]);
                                pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[9]);
                                pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[10]);
                                pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[11]);
                                pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[12]);
                                pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[15]);
                                pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[13]);
                                pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[14]);
                                pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[16]);
                                pOrderBookResp.suborderbookdtls[j].iExchTradeNo   =atoi(Row[17]);
                                pOrderBookResp.suborderbookdtls[j].sProduct = Row[18][0];
                                strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[19],BSE_EXCH_ORDER_NO_LEN);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[20],DATE_STRING_LENGTH);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[22],CLIENT_ID_LEN);

                                if(strlen(Row[25])!= 0 )
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
                                }

                                if(Row[23][0]== 'B')
                                {

                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
                                }
                                else
                                {

                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
                                }
				strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[26],ENTITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[27]);
                                pOrderBookResp.suborderbookdtls[j].cProClient   = Row[28][0];
				strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[30],DB_DATETIME_LEN);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
                                pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
                                pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
                                logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
                                logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s:,ErrorID:%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);

                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
				logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
                        }

                }

                if(( WriteMsgQ( iIntActiveToRelDirQ , (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logDebug2("Write Q id %d", iIntActiveToRelDirQ);
                        return FALSE;
                }
                usleep(1000);
                iTempNoOfRec--;


        }
	logTimestamp("Exit : fDrvSprdOrderBookDtls");
        return TRUE;


}



BOOL    fCOMMSprdOrderBookDtls(CHAR *RcvMsg)
{
        logDebug2("Entry : fCOMMSprdOrderBookDtls");

        struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ    *pViewOrderBookReq;
        struct VIEW_ORDER_BOOK_DETAIL_RESP              pOrderBookResp;
        struct VIEW_COMMON_HDR_RESP                     pOrderBookHdrResp;

        LONG32          iNoOfRec=0;
        DOUBLE64        fNoOfRec;
        LONG32          iNoOfPkt;
        LONG32          iTempNoOfRec;
        CHAR            *sCOMMOrdBook = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

        pViewOrderBookReq = (struct VIEW_VIEW_ORDER_BOOK_DETAIL_QUERY_REQ *)RcvMsg;

        logDebug2(" pViewOrderBookReq->ReqHeader.cSegment:%c: fReqOrderNo :%lf:",pViewOrderBookReq->ReqHeader.cSegment,pViewOrderBookReq->fOrderNo);


        sprintf(sCOMMOrdBook,"SELECT    COMM_ORDER_NO,\
                        COMM_SERIAL_NO,\
                        COMM_MSG_CODE,\
                        COMM_SCRIP_CODE,\
                        COMM_VALIDITY,\
                        COMM_PRO_CLIENT,\
                        COMM_SOURCE_FLG,\
                        COMM_TOTAL_QTY,\
                        COMM_REM_QTY,\
                        COMM_DISC_QTY,\
                        COMM_DISC_REM_QTY,\
                        COMM_ORDER_PRICE,\
                        COMM_TRIGGER_PRICE,\
                        COMM_TRD_TRADE_QTY,\
                        COMM_TRD_TRADE_PRICE,\
                        COMM_TOTAL_TRADED_QTY,\
                        COMM_TRD_EXCH_TRADE_NO,\
                        COMM_PRODUCT_ID,\
                        COMM_EXCH_ORDER_NO,\
                        COMM_INTERNAL_ENTRY_DATE,\
                        COMM_ERROR_CODE,\
                        COMM_CLIENT_ID,\
                        COMM_BUY_SELL_IND,\
			COMM_EXCH_ID,\
                        COMM_REASON_DESCRIPTION ,\
                        COMM_ENTITY_ID ,\
                        COMM_STRATEGY_ID ,\
                        COMM_PRO_CLIENT ,\
                        COMM_TRD_TRADE_PRICE ,\
                        COMM_GOOD_TILL_DAYS, \
                        COMM_LEG_NO,\
                        IFNULL(COMM_PAN_NO,\"NA\"),\
                        IFNULL(COMM_PARTICIPANT_TYPE,'N'),\
                        IFNULL(COM_MKT_PROTECT_FLG,'N'),\
                        COMM_MKT_PROTECT_VAL,\
                        COMM_GTC_FLG,\
                        COMM_ENCASH_FLG \
                        FROM COMM_ORDERS\
                        WHERE COMM_ORDER_NO = %lf \
                        AND COMM_LEG_NO = %d\
                        ORDER BY COMM_ORDER_NO , COMM_SERIAL_NO desc ;",pViewOrderBookReq->fOrderNo);
        logDebug2(" sCOMMOrdBook :%s: ",sCOMMOrdBook);

        if(mysql_query(DBQueries,sCOMMOrdBook) != SUCCESS)
        {
                logSqlFatal("ERROR in COMMOrdBook Query.");
                sql_Error(DBQueries);
        }

        Res = mysql_store_result(DBQueries);

        iNoOfRec = mysql_num_rows(Res);

        fNoOfRec = iNoOfRec;
        iNoOfPkt = ceil(fNoOfRec/5);
        iTempNoOfRec = iNoOfRec;
        logDebug2("pViewOrderBookReq->ReqHeader.cSource = %c",pViewOrderBookReq->ReqHeader.cSource);
        pOrderBookHdrResp.IntRespHeader.iSeqNo = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_COMMON_HDR_RESP);
        pOrderBookHdrResp.IntRespHeader.iErrorId = 0;
        pOrderBookHdrResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_HEADER_RESP;
        pOrderBookHdrResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
        pOrderBookHdrResp.IntRespHeader.cSource = pViewOrderBookReq->ReqHeader.cSource ;

        pOrderBookHdrResp.cMsgType = 'H';
	pOrderBookHdrResp.iNoofRec = iNoOfRec;

        logDebug2("pOrderBookHdrResp.cMsgType:%c:,pOrderBookHdrResp.iNoofRec:%d:",pOrderBookHdrResp.cMsgType,pOrderBookHdrResp.iNoofRec);
        logDebug2("pViewOrderBookReq->ReqHeader.iUserId = %llu",pViewOrderBookReq->ReqHeader.iUserId);
        iRelayID = find_user_adapter(pViewOrderBookReq->ReqHeader.iUserId);
        logDebug2("iRelayID = %d",iRelayID);

        if(iRelayID == ERROR)
        {
                logDebug2("Relay ID not found");
                return FALSE;
        }

        if(( WriteMsgQ(iIntActiveToRelDirQ, (CHAR *)&pOrderBookHdrResp,sizeof(struct VIEW_COMMON_HDR_RESP) ,iRelayID) != TRUE ))
        {
                perror("Error WriteMsgQ: ");
                logDebug2("Write Q id %d",iIntActiveToRelDirQ);
                return FALSE;
        }
        logInfo("I am in Commodity");
        for(i=0;i<iNoOfPkt;i++)
        {
                for(j=0;j<5;j++)
                {
                        if((Row = mysql_fetch_row(Res)))
                        {
                                pOrderBookResp.IntRespHeader.iSeqNo = 0;
                                pOrderBookResp.IntRespHeader.iMsgLength = sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP);
                                pOrderBookResp.IntRespHeader.iMsgCode = TC_INT_ORDER_BOOK_DTLS_RESP;
                                logDebug2("pOrderBookResp.IntRespHeader.iMsgCode :%d:",pOrderBookResp.IntRespHeader.iMsgCode);
				pOrderBookResp.IntRespHeader.iErrorId = atoi(Row[24]);
                                pOrderBookResp.IntRespHeader.iUserId = pViewOrderBookReq->ReqHeader.iUserId;
                                strncpy(pOrderBookResp.IntRespHeader.sExcgId,Row[23],EXCHANGE_LEN);
                                pOrderBookResp.IntRespHeader.cSource = Row[6][0];

                                if(iTempNoOfRec <= 1)
                                {
                                        pOrderBookResp.cMsgType = 'T';
                                }
                                else
                                {
                                        pOrderBookResp.cMsgType = 'D';
                                }

                                pOrderBookResp.suborderbookdtls[j].fOrderNo = atof(Row[0]);
                                pOrderBookResp.suborderbookdtls[j].iSerialNo = atoi(Row[1]);
                                pOrderBookResp.suborderbookdtls[j].iTranscode = atoi(Row[2]);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sSecurityID,Row[3] ,SECURITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].sFlags[0] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[1] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[2] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[3] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[4] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[5] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[6] = '0';
                                pOrderBookResp.suborderbookdtls[j].sFlags[7] = '0';

                                if(atoi(Row[4]) == VALIDITY_DAY)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[0] = '1';
                                }
                                else if(atoi(Row[4]) == VALIDITY_IOC)
                                {
                                        pOrderBookResp.suborderbookdtls[j].sFlags[1] = '1';
                                }

                                pOrderBookResp.suborderbookdtls[j].fQty = atof(Row[7]);
                                pOrderBookResp.suborderbookdtls[j].fRemQty = atof(Row[8]);
                                pOrderBookResp.suborderbookdtls[j].fDQQty = atof(Row[9]);
                                pOrderBookResp.suborderbookdtls[j].fDQQtyRem = atof(Row[10]);
                                pOrderBookResp.suborderbookdtls[j].fPrice = atof(Row[11]);
                                pOrderBookResp.suborderbookdtls[j].fTrgPrice = atof(Row[12]);
                                pOrderBookResp.suborderbookdtls[j].fTradeQty = atof(Row[13]);
				pOrderBookResp.suborderbookdtls[j].fTradePrice = atof(Row[14]);

                                pOrderBookResp.suborderbookdtls[j].fTotalTradeQty = atof(Row[15]);
                                pOrderBookResp.suborderbookdtls[j].iExchTradeNo   = atoi(Row[16]);

                                pOrderBookResp.suborderbookdtls[j].sProduct = atof(Row[17]);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,Row[18] ,BSE_EXCH_ORDER_NO_LEN);

                                strncpy(pOrderBookResp.suborderbookdtls[j].sDatetime,Row[19] ,DATE_STRING_LENGTH);
                                strncpy(pOrderBookResp.suborderbookdtls[j].sClientId,Row[21] ,CLIENT_ID_LEN);

                                if(Row[22][0]== 'B')
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Buy",3);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sBuySellInd,"Sell",3);
                                }

                                if(strlen(Row[24])!= 0 )
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,Row[25],200);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,"S",200);
                                }

                                strncpy(pOrderBookResp.suborderbookdtls[j].sEntityId, Row[25],ENTITY_ID_LEN);
                                pOrderBookResp.suborderbookdtls[j].iStrategyId  = atoi(Row[26]);
                                pOrderBookResp.suborderbookdtls[j].cProClient   = Row[27][0];
                                strncpy(pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate,Row[29],DB_DATETIME_LEN);
                                pOrderBookResp.suborderbookdtls[j].iLegValue = atoi(Row[30]);

                                if(strlen(Row[31]) == 0)
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,"NA",INT_PAN_LEN);
                                }
                                else
                                {
                                        strncpy(pOrderBookResp.suborderbookdtls[j].sPanID,Row[31],INT_PAN_LEN);
                                }
				pOrderBookResp.suborderbookdtls[j].cParticipantType = Row[32][0];
                                pOrderBookResp.suborderbookdtls[j].cMarkProFlag = Row[33][0];
                                pOrderBookResp.suborderbookdtls[j].fMarkProVal = atof(Row[34]);
                                pOrderBookResp.suborderbookdtls[j].cGTCFlag =  Row[35][0];
                                pOrderBookResp.suborderbookdtls[j].cEncashFlag =  Row[36][0];


                                logDebug2(" pOrderBookResp.cMsgType :%c:",pOrderBookResp.cMsgType);
                                logDebug2(" pOrderBookResp.IntRespHeader.sExcgId :%s:",pOrderBookResp.IntRespHeader.sExcgId);
                                logDebug2(" fOrderNo:%lf:,iSerialNo:%d:,sBuySellInd:%s:,sSecurityID:%s:,sFlags:%s:,fQty:%lf:,fRemQty:%lf:,fDQQty:%lf:,fDQQtyRem:%lf:,fPrice:%lf:,fTrgPrice:%lf:,fTradeQty:%lf:,sProduct:%c:,sExchOrderNumber:%s:,sDatetime:%s:,sClientId:%s:,ReasonDesc:%s: ErrorId :%d:",pOrderBookResp.suborderbookdtls[j].fOrderNo,pOrderBookResp.suborderbookdtls[j].iSerialNo,pOrderBookResp.suborderbookdtls[j].sBuySellInd,pOrderBookResp.suborderbookdtls[j].sSecurityID,pOrderBookResp.suborderbookdtls[j].sFlags,pOrderBookResp.suborderbookdtls[j].fQty,pOrderBookResp.suborderbookdtls[j].fRemQty,pOrderBookResp.suborderbookdtls[j].fDQQty,pOrderBookResp.suborderbookdtls[j].fDQQtyRem,pOrderBookResp.suborderbookdtls[j].fPrice,pOrderBookResp.suborderbookdtls[j].fTrgPrice,pOrderBookResp.suborderbookdtls[j].fTradeQty,pOrderBookResp.suborderbookdtls[j].sProduct,pOrderBookResp.suborderbookdtls[j].sExchOrderNumber,pOrderBookResp.suborderbookdtls[j].sDatetime,pOrderBookResp.suborderbookdtls[j].sClientId,pOrderBookResp.suborderbookdtls[j].sOrdReasonDesc,pOrderBookResp.IntRespHeader.iErrorId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sEntityId :%s:",j,pOrderBookResp.suborderbookdtls[j].sEntityId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].iStrategyId :%d:",j,pOrderBookResp.suborderbookdtls[j].iStrategyId);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cProClient :%c:",j,pOrderBookResp.suborderbookdtls[j].cProClient );
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sGoodTillDaysDate :%s:",j,pOrderBookResp.suborderbookdtls[j].sGoodTillDaysDate);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].iLegValue:%d:",j,pOrderBookResp.suborderbookdtls[j].iLegValue);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].sPanID :%s:",j,pOrderBookResp.suborderbookdtls[j].sPanID);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cParticipantType :%c:",j,pOrderBookResp.suborderbookdtls[j].cParticipantType);
                                logDebug2("pOrderBookResp.suborderbookdtls[%d].cMarkProFlag :%c:",j,pOrderBookResp.suborderbookdtls[j].cMarkProFlag);
                                logDebug2("pOrderBookResp.suborderbook[%d].fMarkProVal = %lf",j,pOrderBookResp.suborderbookdtls[j].fMarkProVal);
                                logDebug2("pOrderBookResp.suborderbook[%d].sSettlor = %s",j,pOrderBookResp.suborderbookdtls[j].sSettlor);
                                logDebug2("pOrderBookResp.suborderbook[%d].cGTCFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cGTCFlag);
                                logDebug2("pOrderBookResp.suborderbook[%d].cEncashFlag = %c",j,pOrderBookResp.suborderbookdtls[j].cEncashFlag);
                        }
                        iTempNoOfRec--;
                }

                if(( WriteMsgQ(iIntActiveToRelDirQ, (CHAR *)&pOrderBookResp,sizeof(struct VIEW_ORDER_BOOK_DETAIL_RESP) ,iRelayID) != TRUE ))
                {
                        perror("Error WriteMsgQ: ");
                        logDebug2("Write Q id %d", iIntActiveToRelDirQ);
                        return FALSE;
                }

        }
        logTimestamp("Exit :  fCOMMSprdOrderBookDtls");
        return TRUE;

}
