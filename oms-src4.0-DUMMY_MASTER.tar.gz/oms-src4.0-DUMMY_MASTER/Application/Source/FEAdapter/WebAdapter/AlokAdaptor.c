#include "IPCS.h"
#include "WebAdapter.h"

void        LockThreadMutex                 (pthread_mutex_t *,CHAR *,int );
void        UnLockThreadMutex               (pthread_mutex_t *,CHAR *,int );
main(int argc,char *argv[])
{
	LONG32		Signal;
	LONG32		Retval;
	LONG32		i;
	sigset_t	SignalSet;
	pthread_t	MainThreadId;
	UserId_Lookup_Table *tmpnode;

	setbuf ( stdout,NULL);
	setbuf ( stdin ,NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );

	signal		(SIGHUP,SIG_IGN);
	sigemptyset	(&SignalSet);
	sigaddset	(&SignalSet,SIGTERM);
	sigaddset	(&SignalSet,SIGINT);
	sigaddset	(&SignalSet,SIGUSR2);
	sigaddset	(&SignalSet,SIGUSR2);
	sigaddset	(&SignalSet,SIGTRAP);
	sigprocmask (SIG_BLOCK,&SignalSet,NULL);

	if (argc <2)
	{
		printf("\n Usage <ItsRelay1> <PortNo> ");
		exit(1);
	}

	MasterPort	=	atoi(argv[1]);

	printf("\n Main Port : %d",MasterPort);

	if((ItsToRmsDir = OpenMsgQ(RelToOrdRtr)) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	printf("\n Sucessfully opened RelToOrdRtr Q with Id :%d:",ItsToRmsDir);

	if( (RelDirToIts = OpenMsgQ(TrdRtrToWebAdap)) == ERROR)
	{
		perror("Open DirToRelQ :");
		exit( 1 );
	}

	printf("\n Sucessfully opened TrdRtrToWebAdap Q with Id :%d:",RelDirToIts);

	if (pipe(SocketCommunicationPipe) != 0)
	{
		printf("\nError in creation of the SocketCommunicationPipe");
		exit(1);
	}

	if (pipe(DummyPipe) != 0)
	{
		printf("\nError in creation of the DummyPipe");
		exit(1);
	}

	pthread_once (&once_control,Init_Routine);

	pthread_sigmask(SIG_BLOCK,&SignalSet,NULL);

	printf("\n Creating MainThread ...");
	pthread_create(&MainThreadId,NULL,ReadWriteMainThread,NULL);

	printf("\n MAX_NO_OF_SOCKETS:%d:",MAX_NO_OF_SOCKETS);

	while(1)
	{
		/*		if ((Retval = sigwait(&SignalSet,&Signal)) < 0)*/
		if ((Retval = sigwait(&SignalSet,&Signal)) < 0)
		{
			perror("\n\n FATAL ERROR in sigwait::");
			break;
		}

		if (Retval == SIGTRAP)
		{
			/***
			  This part is just for debugging purpose. This signal can be raised from outside
			  to display all the nodes existing in the linked list.
			 ***/
			LONG32 	localNodes=0;

			if (IndexNode == NULL)
			{
				printf("\n No nodes in List");
				continue;
			}

			printf("\n Existing nodes in List");
			tmpnode = IndexNode;
			while(IndexNode != NULL)
			{
				printf("\n Node::%d UserId::%d SocketId::%d",++localNodes,tmpnode->UserId,tmpnode->SocketId);
				if (tmpnode->Next == NULL)
					break;

				tmpnode = tmpnode->Next;
			}
		}
		else if(Retval== SIGUSR2)
		{
			for(i=0;i<MAX_NO_OF_SOCKETS;i++)
			{
				printf( "\n in SIGUSR2 case Socket id = %d , UserStatus =  %d ,pthread_mutex_t = %d ",SocketTable[i].SocketId,SocketTable[i].UserStatus,SocketTable[i].Mutex);
			}

			continue ;
		}
		else if ((Retval == SIGTERM) || (Retval == SIGINT))
		{
			pthread_cancel(MainThreadId);
			for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS;i++)
				pthread_cancel(ThreadTable[i].ThreadId);

			LockThreadMutex(&UserIdTableLock,"DeleteUser");
			while (IndexNode != NULL)
			{
				tmpnode = IndexNode;
				IndexNode = IndexNode->Next;
				printf("\n Freed Node for User::%d on SocketId::%d",tmpnode->UserId,tmpnode->SocketId);
				free(tmpnode);
			}
			UnLockThreadMutex(&UserIdTableLock,"DeleteUser");
			break;
		}
	}

	pthread_join(MainThreadId,NULL);
	printf("\n\n ReadWriteMain Thread terminated");

	for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS;i++)
		pthread_join(ThreadTable[i].ThreadId,NULL);

	fflush(stdout);
	exit(0);
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Intialises all the mutex and the gobal variables to the default values.
////////////////////////////////////////////////////////////////////////////////*/
void Init_Routine ()
{
	LONG32	i;

	printf("\n Initialising Resources ...");



	if(pthread_mutex_init (&ActiveSocketLock,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&SocketTableLock,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&SocketCommunicationPipeLock,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&UserIdTableLock,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&OracleAccess,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&TotalThreadsInProgressLock,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&DynamicThreadsInProgressCondLock,NULL ) != 0)
		printf("\nInit_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_attr_init(&ThreadAttr) != 0)
		printf("\nInit_Routine: Error in initialising the Attributes"),exit(1);

	/***
	  This attribute will be applied for the threads which will be dynamically spawned
	  coz we cant wait for them to terminate and free up resources.
	 ***/

	pthread_attr_setdetachstate(&ThreadAttr,PTHREAD_CREATE_DETACHED);


	for(i=0;i<MAX_NO_OF_SOCKETS;i++)
	{
		SocketTable[i].SocketId = UNUSED;	
		SocketTable[i].UserStatus = UNUSED;	
		if (pthread_mutex_init (&SocketTable[i].Mutex,NULL) != 0)
			exit (1);
	}

	for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS;i++)
	{
		ThreadTable[i].Status = UNUSED;	
	}

}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Creates the Master Socket for accepting the new connections.The socketid
//			on which the data arrives is written to the pipe, and the Worker thread
//			which accquires a lock to the pipe processes the data. If the value of
//			StaticThreadsInProgress becomes equal to MAX_NO_STATIC_READ_THREADS, then ReadMain...
//			spawns off a new thread dynamically which will process the packet and die.
//			It also creates the Read and wrtie worker  threads.
////////////////////////////////////////////////////////////////////////////////*/
void	*ReadWriteMainThread(void *arg)
{
	pthread_t	ThreadId[MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS];
	struct		sockaddr_in	servadd,cliadd,bc_servadd;
	struct		sockaddr_in	ev_servadd;		
	LONG32		Retval=1,i,MaxSocketId=0;
	LONG32		MasterSocket,SM_MasterSocket=0,NewSocket,Len,DynamicThreads=0;
	LONG32 		EV_MasterSocket=0;		
	CHAR		recvString[MAX_PACKET_SIZE];
	fd_set		ReadSocketSet;
	CHAR		DummyChar;
	int t;
	int len;
	struct sockaddr_in sin;
	struct hostent *host;


	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);

	//memset((CHAR *)&servadd,' ',sizeof(struct sockaddr_in));
	memset((CHAR *)&servadd,'\0',sizeof(struct sockaddr_in));
	servadd.sin_family			= AF_INET;
	servadd.sin_port			= htons(MasterPort);
	servadd.sin_addr.s_addr		= htonl(INADDR_ANY);

	printf("\n Creating Worker Threads ...");
	for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS;i++)
	{
		if (i < MAX_NO_STATIC_READ_THREADS)
		{
			if ((pthread_create(&ThreadId[i],NULL,ReadWorkerThread,NULL)!= 0))
			{
				printf("\nReadWriteMainThread: Error in creation of the Read Worker Threads");
				kill(getpid(),SIGTERM);
			}
		}
		else if(MAX_NO_STATIC_READ_THREADS <= i <MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS )
		{
			if ((pthread_create(&ThreadId[i],NULL,WriteWorkerThread,NULL)!= 0))
			{
				printf("\nReadWriteMainThread: Error in creation of the Write Worker Threads");
				kill(getpid(),SIGTERM);
			}
		}
		ThreadTable[i].ThreadId = ThreadId[i];
		ThreadTable[i].Status 	= USED;

	}

	if ((MasterSocket=socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		perror("\nReadWriteMainThread: Error in creating the MasterSocket");
		kill(getpid(),SIGTERM);
	}

	if (setsockopt(MasterSocket,SOL_SOCKET,SO_REUSEADDR,(char *)&Retval,sizeof(Retval))<0)
	{
		perror("\nReadWriteMainThread: Error in setsockopt on the MasterSocket");
		kill(getpid(),SIGTERM);
	}

	if( bind(MasterSocket,(struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("\nReadWriteMainThread: Error in binding to the MasterSocket");
		kill(getpid(),SIGTERM);
	}

	listen(MasterSocket,5);


	/***
NOTE: As the name suggests the job of this pipe itself is dumb. We just write to the pipe
to make the select call unblocking.
	 ***/
	FD_SET (DummyPipe[0],&ActiveSocketSet);
	FD_SET (MasterSocket,&ActiveSocketSet);


	MaxSocketId=MasterSocket;

	while(1)
	{
		LockThreadMutex(&ActiveSocketLock,"ActiveSocketLock",0);
		ReadSocketSet = ActiveSocketSet;
		UnLockThreadMutex(&ActiveSocketLock,"ActiveSocketLock",0);


		printf("\n\n ============================ Waiting for Req/Data ============================");
		Retval = select(MaxSocketId + 1,&ReadSocketSet,(fd_set *)NULL,(fd_set *)NULL,(struct timeval *) NULL);
		if (Retval <= 0)
		{
			perror("\nReadWriteMainThread: Error in the select call");
			continue;
		}

		if (FD_ISSET(DummyPipe[0],&ReadSocketSet))
		{
			read(DummyPipe[0],&DummyChar,sizeof(CHAR));
			continue;
		}

		pthread_testcancel();	
		if (FD_ISSET(MasterSocket,&ReadSocketSet))
		{
			/**
			  Someone is trying to make a connection.Accept the call and add it to the Socket_Lookup_Table
			  if the count of sockets hasnt excedded the maximum.
			 **/
			//memset((CHAR *)&cliadd,' ',sizeof(struct sockaddr_in));
			memset((CHAR *)&cliadd,'\0',sizeof(struct sockaddr_in));
			Retval = sizeof(struct sockaddr);
			if ((NewSocket = accept(MasterSocket,(struct sockaddr *)&cliadd,&Retval)) < 0)
			{
				perror("\nReadWriteMainThread: Error in accepting the connection");
				kill(getpid(),SIGTERM);
			}
			printf("\nNew Socket Connection Established on:%d",NewSocket);
			/****************************************
			  len = sizeof cliadd;
			  if (getpeername(NewSocket, (struct sockaddr *) &sin, &len) < 0)
			  perror("getpeername");
			  else 
			  {
			  if ((host = gethostbyaddr((char *) &sin.sin_addr, sizeof sin.sin_addr, AF_INET)) == NULL)
			  perror("gethostbyaddr");
			  else 
			  printf("remote host is '%s'\n", host->h_name);
			  }
			 *******************************************/

			LockThreadMutex(&SocketTableLock,"GetSlotInSocketTable.NewSocket",NewSocket);
			if ((Retval = GetSlot_In_Socket_Table()) == ERROR)
			{
				UnLockThreadMutex(&SocketTableLock,"GetSlotInSocketTable.NewSocket",NewSocket);
				printf("\nReadWriteMainThread: SocketTable pool full... new connection will be dropped");
				close(NewSocket);
				continue;
			}
			UnLockThreadMutex(&SocketTableLock,"GetSlotInSocketTable.NewSocket",NewSocket);

			LockThreadMutex(&ActiveSocketLock,"FDSET.NewSocket",NewSocket);
			FD_SET(NewSocket,&ActiveSocketSet);
			UnLockThreadMutex(&ActiveSocketLock,"FDSET.NewSocket",NewSocket);

			LockThreadMutex(&SocketTableLock,"SocketTable[].SocketId.NewSocket",NewSocket);
			SocketTable[Retval].SocketId = NewSocket;
			UnLockThreadMutex(&SocketTableLock,"SocketTable[].SocketId.NewSocket",NewSocket);
			MaxSocketId=NewSocket;
			printf("\n NewSocket: %d",NewSocket);
		}

		pthread_testcancel();	
		for(i=0;i<=MAX_NO_OF_SOCKETS;i++)
		{
			if (FD_ISSET(SocketTable[i].SocketId,&ReadSocketSet))
			{
				/***
				  Write the Index of the Socketid from which the data packet has arrived on to the pipe
				  and whichever thread is waiting on a read on the pipe will read the index of the socket
				  in the SocketTable.
				 ***/

				LockThreadMutex(&ActiveSocketLock,"FDSET.SocketTable[i].SocketId",SocketTable[i].SocketId);
				FD_CLR(SocketTable[i].SocketId,&ActiveSocketSet);
				UnLockThreadMutex(&ActiveSocketLock,"FDSET.SocketTable[i].SocketId",SocketTable[i].SocketId);

				if (write(SocketCommunicationPipe[1],(void *)&i,sizeof(LONG32)) < 0)
				{
					perror("\nReadWriteMainThread: Error in writing to pipe");
					printf("\n error is :%d",errno);
				}
				printf("\nReadWriteMainThread: Data pending on socket :%d",SocketTable[i].SocketId);
				/*************************************

				  if (TotalThreadsInProgress >= MAX_NO_STATIC_READ_THREADS)
				  {
				 ***
				 If we are here it indicates that all the worker threads are busy processing, hence
				 spawn out a new thread which will process this new packet and die.

NOTE: If the Queues are FULL then the Worker threads will block on the Queue for
writing the data. In such a case all the arriving data packets will result in the
spawning of a dynamic thread. If the Queues never become empty and we go on spawning
threads then....... we may exceed the system limit. Hence if the no of dynamic
thread reaches the threshold of MAX_NO_DYNAMIC_READ_THREADS then we wait for the
a Conditional Variable till the count of dynamic threads doesnt come down.
				 ***

				 if (TotalThreadsInProgress == MAX_NO_DYNAMIC_READ_THREADS + MAX_NO_STATIC_READ_THREADS)
				 {
				 printf("\n System is going to be suspended For crossing the Thread Limit");
				 _SYSTEM_SUSPENDED_ = TRUE;
				 LockThreadMutex(&DynamicThreadsInProgressCondLock,"DynamicThreads",0);
				 pthread_cond_wait(&DynamicThreadsInProgressCondVar,&DynamicThreadsInProgressCondLock);
				 UnLockThreadMutex(&DynamicThreadsInProgressCondLock,"DynamicThreads",0);
				 }
				 printf("\nReadWriteMainThread: All the Read Workers Busy... Spawning a new Thread now");
				 pthread_create(&ThreadId,&ThreadAttr,ProcessIncomingPacket,(void *)i);

				 LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.SocketTable[i].SocketId",SocketTable[i].SocketId);
				 ++TotalThreadsInProgress;
				 printf("\nDynamic Thread Created: STATIC-TotalThreadsinProgress: %d",TotalThreadsInProgress-MAX_NO_STATIC_READ_THREADS);
				 UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.SocketTable[i].SocketId",SocketTable[i].SocketId);


				 if (TotalThreadsInProgress >= MAX_NO_DYNAMIC_READ_THREADS + MAX_NO_STATIC_READ_THREADS -3)
				 printf("\nReadWriteMainThread: !!! WARNING,approaching MAX_NO_DYNAMIC_READ_THREADS limit");

				 printf("\nReadWriteMainThread: DYNAMIC-TotalThreadsinProgress: %d",TotalThreadsInProgress);
				 }
				 *************************************/


			}
		}
	}
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Statically Spawned Worker Thread, waits on the pipe for receiving the 
//			socketid from which the data will be read. When a lock is aqquired
//			the global var StaticThreadsInProgress is incremented to indicate the no of
//			threads which are currently busy and decremented when the processing 
//			is done.	
////////////////////////////////////////////////////////////////////////////////*/
void	*ReadWorkerThread(void *arg)
{
	LONG32	Index=0;

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);

	while(1)
	{

		if (read(SocketCommunicationPipe[0],&Index,sizeof(LONG32)) < 0)
		{
			perror("\nStaticReadWorkerThread: Error in reading from pipe");
			continue;
		}
		printf("\nStaticReadWorkerThread: SocketIndex read from pipe is :%d",Index);

		LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.Index",Index);
		++TotalThreadsInProgress;
		printf("\nReadWorkerThread: STATIC-TotalThreadsinProgress: %d",TotalThreadsInProgress);
		UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.Index",Index);

		ProcessIncomingPacket((void *)Index);
		pthread_testcancel();
	}
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Takes the socketid as the argument and reads the data from the socket.
//			Adds it in the Offline Table if the OFF_STAT_FLG flag in the table is
//			set else it writes it to the Q, to be processed by the Parent Process.
//Var Usage:SocketId - To read from. 
////////////////////////////////////////////////////////////////////////////////*/
void*	ProcessIncomingPacket(void *Index)
{
	LONG32			Retval		=	0			;
	LONG32			Len			=	0			;
	LONG32			SocketIndex =	0			;
	LONG32			Qid			=	0			; 
	LONG32			iTransCode	=	0			;
	LONG32			TempLen		=	0			;
	SHORT			MsgType		=	0			;
	CHAR			DummyChar	=	'D'			;
	CHAR			recvString[MAX_PACKET_SIZE]	;
	CHAR			*arr[6]					; 
	CHAR			*ReqDet						;
	CHAR			Ord_Str[MAX_PACKET_SIZE]	;
	int				iSocket	=	0;
	int				iRetStatus	=	0;
	//struct ORDER_REQUEST           ord_req     ;
	CHAR    ord_req[MAX_PACKET_SIZE];
	struct INT_COMMON_REQUEST_HDR   ReqHeader   ;
	struct timeval TimeStampRead;
	struct timeval TimeStampRead1;
	struct timeval TimeStamp3;
	struct timeval TimeStamp4;
	int iSeqNo=0;
	int USER_IDE	= 0;
	char *buf ;
	char temp_store[100];


	SocketIndex = (LONG32 ) Index					; 
	Len 		= sizeof(struct INT_COMMON_REQUEST_HDR) + 26	;
	gettimeofday(&TimeStampRead1,NULL);
	/***	memset( recvString,NULL,MAX_PACKET_SIZE );****/
	memset( recvString,'\0',MAX_PACKET_SIZE );
	memset( ord_req,' ',MAX_PACKET_SIZE);

	LockThreadMutex( &SocketTable[SocketIndex].Mutex ,"SocketTable[].Mutex",SocketTable[SocketIndex].SocketId);
	iSocket = SocketTable[SocketIndex].SocketId	 ;
	Retval = Recv( SocketTable[SocketIndex].SocketId, recvString ,&Len,MSG_PEEK				);
	if (Retval <= 0)
	{
		UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].Mutex",SocketTable[SocketIndex].SocketId);
		close(SocketTable[SocketIndex].SocketId);
		CleanResources(	SocketIndex												);
		LockThreadMutex(	&TotalThreadsInProgressLock,"ThreadsInLock",SocketTable[SocketIndex].SocketId);

		--TotalThreadsInProgress;

		printf("\n Recv failed with Retval	: %d ,iSocket :: %d ",Retval,iSocket);
		printf("\n\t ERRNO	: %d 	iSocket :: %d ", errno,iSocket 				);
		perror("Recv Error	: " 						);

		UnLockThreadMutex(	&TotalThreadsInProgressLock,"ThreadsInLock",SocketTable[SocketIndex].SocketId);
		return;
	}
	printf("\n iSocket :: %d ,Recv The String From Its: %s",iSocket,recvString	);
	printf("\n iSocket :: %d ,Recv success with Retval: %d",iSocket,Retval		);

	ReqDet = (struct INT_COMMON_REQUEST_HDR *)malloc(sizeof(struct  INT_COMMON_REQUEST_HDR));

	memset( ReqDet,'\0'		,sizeof(struct INT_COMMON_REQUEST_HDR));
	memcpy( ReqDet,recvString	,sizeof(struct INT_COMMON_REQUEST_HDR));
	printf("\n recvString[0] :%c: , recvString[0] :%d:",recvString[0],recvString[0]);

	if(recvString[0]!=13)
	{
		printf("\n GETTING JUNK ");

		printf("iSocket :: %d , req Details :%s\n",iSocket,recvString);


		arr[0]=strtok_r(recvString,"|",&buf);
		ReqHeader.iSeqNo 			= atoi(arr[0]);

		arr[1]=strtok_r(NULL,"|",&buf);
		ReqHeader.iMsgLength 		= atoi(arr[1]		);

		arr[2]=strtok_r(NULL,"|",&buf);
		ReqHeader.iMsgCode = atoi(arr[2]		);

		arr[3]=strtok_r(NULL,"|",&buf);
		printf("\nExcgId			::	%s   Len   :: %d" ,arr[3],strlen(arr[3]));

		arr[4]=strtok_r(NULL,"|",&buf);
		printf("\narr[4]			::	%s   Len   :: %d",arr[4],strlen(arr[4]));

		arr[5]=strtok_r(NULL,"|",&buf);
		USER_IDE					= atoi(arr[4]		);


		printf("\n USER_IDE		::	%d	",USER_IDE);

		/* Added Upto Here*/
		iSeqNo=ReqHeader.iSeqNo;


		/** Added To Recv Successfully From ITS The Bytes Paded With ^M **/

		Len=ReqHeader.iMsgLength;
		printf("\n iSocket :: %d | Len : %d | USER_IDE : %d | SeqNo  : %d ",iSocket,Len,USER_IDE,ReqHeader.iSeqNo);


		printf("\n iSocket :: %d | Transcode: %d | USER_IDE : %d | SeqNo  : %d ",iSocket, ReqHeader.iMsgCode,USER_IDE,ReqHeader.iSeqNo);

		fflush(stdin);
		fflush(stdout);

		iTransCode=ReqHeader.iMsgCode			;
		printf("\n iSocket :: %d | Transcode :: %d | USER_IDE : %d | SeqNo  : %d ",iSocket,iTransCode,USER_IDE,ReqHeader.iSeqNo)	;

		Retval = Recv( SocketTable[SocketIndex].SocketId,recvString,&Len,0	);
		if (Retval <= 0)
		{
			UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].USER_IDE",USER_IDE);
			close(SocketTable[SocketIndex].SocketId);
			CleanResources(SocketIndex												);
			LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);

			--TotalThreadsInProgress;

			printf("\nProcessIncomingPacket: TotalThreadsinProgress	: %d | USER_IDE : %d | SeqNo  : %d ",TotalThreadsInProgress,USER_IDE,ReqHeader.iSeqNo);
			printf("\n Recv failed with Retval: %d | USER_IDE : %d | SeqNo  : %d ",Retval,USER_IDE,ReqHeader.iSeqNo);

			UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);

			return;
		}
		UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"Recv.USER_IDE",USER_IDE);


		LockThreadMutex(&ActiveSocketLock,"FDSET.USER_IDE",USER_IDE);
		FD_SET(SocketTable[SocketIndex].SocketId,&ActiveSocketSet);
		UnLockThreadMutex(&ActiveSocketLock,"FDSET.USER_IDE",USER_IDE);

		if (write(DummyPipe[1],(void *)&DummyChar,sizeof(CHAR)) < 0)
		{
			perror("\nProcessIncomingPacket: Error in writing to pipe");
			printf("\n error is :%d",errno);
		}
	}

	printf("iTransCode is [%d]",iTransCode);

	switch(iTransCode)
	{
		case TC_INT_ORDER_ENTRY_REQ:
		case TC_INT_ORDER_MODIFY:
		case TC_INT_ORDER_CANCEL:
		case TC_INT_OFF_ORDER_ENTRY:
		case TC_INT_OFF_ORDER_MODIFY:
		case TC_INT_OFF_ORDER_CANCEL:
			iRetStatus=Map_Ord_Req(recvString,&ord_req);
			printf("\n Returned successfully from Map_Ord_Req.USER_IDE : %d | iSocket:: %d | SeqNo  : %d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct ORDER_REQUEST));
			break;

		case TC_INT_CON_DEL_REQ:		
			iRetStatus=Map_C2D_Req(recvString,&ord_req);
			printf("\n Returned successfully from Map_C2D_Req.USER_IDE : %d | iSocket:: %d | SeqNo  : %d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct CON_TO_DELIVERY_RESPONSE));
			break;

		case TC_INT_SIP_ORD_REQ		:
		case TC_INT_SIP_ORD_CANCEL	:

			iRetStatus = Map_SIP_Ord_Req(recvString,&ord_req);
			logDebug2("Returned successfully from Map_SIP_Ord_Req.. USER_IDE = %d | iSocket = %d | SeqNo =%d ",ReqHeader.iSeqNo);	
			memcpy(&Ord_Str,&ord_req,sizeof(struct SIP_ORD_REQUEST));
			break;

		case TC_INT_CO_ORDER_REQ	:
		case TC_INT_CO_ORDER_MODIFY	:
		case TC_INT_CO_ORDER_EXIT	:
		case TC_INT_BO_ORDER_REQ	:
		case TC_INT_BO_ORDER_MODIFY	:
		case TC_INT_BO_ORDER_EXIT	:
		case TC_INT_BO_LEG_MODIFY	:

			iRetStatus = Map_COBO_Ord_Req(recvString,&ord_req);
			logDebug2("Returned successfully from Map_COBO_Ord_Req.. USER_IDE = %d | iSocket = %d | SeqNo =%d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct CO_BO_ORDERS_REQUEST));
			break;

		default:

			printf("\n There is no Transcode in the list ");

			UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].default",0 );

			close(SocketTable[SocketIndex].SocketId);
			CleanResources(SocketIndex );
			LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.default",0);

			--TotalThreadsInProgress;
			UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.default",0);
			printf("\n ProcessIncomingPacket:default::USER_IDE : %d | iSocket:: %d | SeqNo  : %d | TotalThreadsinProgress : %d",ReqHeader.iSeqNo,TotalThreadsInProgress);

			return;
	}
	Len = ((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->iMsgLength;

	printf("\n iSocket :: %d  | USER_IDE :: %d | SocketTable[SocketIndex].SocketId Befor AddUser: %d",iSocket,USER_IDE,SocketTable[SocketIndex].SocketId);

	LockThreadMutex(&UserIdTableLock,"AddUser.USER_IDE",USER_IDE);
	AddUser(IndexNode,
			((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->iUserId,
			SocketTable[SocketIndex].SocketId,
			((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->sExcgId,
			((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->cSegment);
	++NoOfNodes;
	UnLockThreadMutex(&UserIdTableLock,"AddUser.USER_IDE",USER_IDE);


	MsgType = 1;
	Qid = ItsToRmsDir;
	if ((WriteMsgQ( Qid, &Ord_Str,Len,MsgType)!= TRUE))
	{
		perror("\nProcessIncomingPacket: Error in Writing to the Q ItsToRmsDir");
		kill(getpid(),SIGTERM);
	}


	LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);
	--TotalThreadsInProgress;
	printf("\nProcessIncomingPacket: TotalThreadsinProgress: %d",TotalThreadsInProgress);
	UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);

	/***
NOTE: If all the MAX_NO_DYNAMIC_READ_THREADS have been created then the no more packets
will be read from the socket, and this program will go in a suspended mode. Hence if
the total no of busy threads comes down by a certain value then raise a signal.
	 ***/

	return;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Waits on the Queue for the MsgType 222, and using the UserId, indexes
//			into the UserId table to get the socket on which the resp is to be 
//			sent.
////////////////////////////////////////////////////////////////////////////////*/
void	*WriteWorkerThread(void *arg)
{
	LONG32	Retval,SocketId,Index,Len,Transcode,ErrorCode=0;
	CHAR	OrderResp[MAX_PACKET_SIZE], localStr[MAX_PACKET_SIZE];
	CHAR	*ModOrderResp;
	SHORT   WriteSM=0;
	struct timeval TimeStampSend;
	struct timeval TimeStampRead;
	int iSeqNo=0;
	LONG32 USER_IDE = 0;
	struct INT_ERROR_FE_RESP *INT_ERROR_FE_RESP;
	/*************************************
	  int iRecvCounter=0;
	  int iSendCounter=0;
	 *************************************/

	while(1)
	{
		memset(OrderResp,' ',MAX_PACKET_SIZE); 
		if ((Retval = ReadMsgQ(RelDirToIts,OrderResp,MAX_PACKET_SIZE,222)) != TRUE)
		{
			perror("\nWriteWorkerThread: Error in reading from the Q");
			kill(getpid(),SIGTERM);
		}


		Transcode 	= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgCode ;
		Len		= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgLength;
		iSeqNo		= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iSeqNo;
		USER_IDE	= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId;
		printf("\n  Transcode = %d ",((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgCode);
#ifdef	DBG
		printf("\nWriteWorkerThread: Received User: %d |  Tcode:%d | ",USER_IDE,Transcode);
#endif
		switch(Transcode)
		{
			case TC_INT_OE_ERROR_RESP:
			case TC_INT_OM_ERROR_RESP:
			case TC_INT_OC_ERROR_RESP:
			case TC_INT_OE_FREEZE_RESP:
			case TC_INT_ORDER_REJECTION:	
			case TC_INT_RMS_ORD_REJECTION:	
				ErrorCode = 1;
				printf("\n Transcode Received: %d | USER_IDE : %d | ErrorCode: %d | SeqNo : %d | ErrorMessage :%s: ",Transcode,USER_IDE,ErrorCode,iSeqNo,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
				printf("\n trancode and error msg are suppose to get printed ");
				break;

			case TC_INT_LOGON_RSP				:
			case TC_INT_ORDER_ENTRY_RSP			:
			case TC_INT_ORDER_MODIFY_RSP			:
			case TC_INT_ORDER_CANCEL_RSP			:
			case TC_INT_CON_DEL_RESP			:	 
			case TC_INT_OFF_ORDER_ENTRY_RSP			:
			case TC_INT_OFF_ORDER_MODIFY_RSP		:
			case TC_INT_OFF_ORDER_CANCEL_RSP		:
			case TC_INT_SIP_ORD_RES				:
			case TC_INT_SIP_ORD_CANCEL_RES			:

				ErrorCode = 0;
				printf("\n Transcode Received: %d | USER_IDE : %d | ErrorCode: %d | SeqNo : %d",Transcode,USER_IDE,ErrorCode,iSeqNo);
				break;


			case TC_INT_OE_CONF_RESP				:
			case TC_INT_TRADE_RESP					:
			case TC_INT_OM_CONF_RESP 				:
			case TC_INT_OC_CONF_RESP				:
			case TC_INT_SL_ORDER_TRIG_RESP			:

				printf("\n Dropping Pkt For Exchange Confirmation/Rejection Resp :: USER_IDE :: %d | SeqNo ::%d ",USER_IDE,iSeqNo);
				continue;

			default:

				printf("\n Invalid Transcode: %d",Transcode);
				continue;
		}
		/***
		  Now that we have the response delete the node corresponding to this user from the
		  list. Note the last argument is passed by reference to get the Socket on which the
		  response is to be sent.
		 ***/
		SocketId = ERROR;
		LockThreadMutex(&UserIdTableLock,"DeleteUser.USER_IDE",USER_IDE);
		DeleteUser( IndexNode,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.sExcgId,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.cSegment,USER_IDE,&SocketId);
		printf("\n SocketId Got After Deleting The User: %d | USER_IDE : %d | SeqNo :%d",SocketId,USER_IDE,iSeqNo);
		if (SocketId == ERROR)
		{
			/***
			  FATAL ERROR... If we are here that means the socket has either been closed or it
			  encountered some error because of which the entry corresponding to all users whose
			  request had come on this socket was cleared.
			 ***/
			UnLockThreadMutex(&UserIdTableLock,"DeleteUser.USER_IDE",USER_IDE);
			printf("\nWriteWorkerThread: FATAL ERROR UserId not found.USER_IDE :: %d |  SeqNo :%d",USER_IDE,iSeqNo);
			continue;
		}
		--NoOfNodes;
		UnLockThreadMutex(&UserIdTableLock,"DeleteUser.USER_IDE",USER_IDE);

#ifdef	DBG
		printf("\nWriteWorkerThread: Deleted the Node Successfully| USER_IDE : %d | SocketId :%d | SeqNo :%d",USER_IDE,SocketId,iSeqNo);
#endif
		/***
		  Though we have got the socket we still need the mutex corresponding to this socket to for 
		  locking. So loop in the socket table and get the index corresponding to this socket.
		 ***/
		LockThreadMutex(&SocketTableLock,"GetIndexInSocketTable.USER_IDE",USER_IDE);
		printf("\n SocketId For Getting The Index: %d | USER_IDE : %d | SeqNo :%d",SocketId,USER_IDE,iSeqNo);
		if ((Index = GetIndex_In_Socket_Table(SocketId)) == ERROR)
		{
			/***
			  FATAL ERROR... If we are here that means the socket has either been closed or it
			  encountered some error because of which the  socket entry was cleared.
			 ***/
			UnLockThreadMutex(&SocketTableLock,"GetIndexInSocketTable.USER_IDE",USER_IDE);
			printf("\nWriteWorkerThread: FATAL ERROR SocketId not found");
			printf("\nWriteWorkerThread: FATAL ERROR in sending the resp to USERID:%d | SeqNo :%d",USER_IDE,iSeqNo);
			continue;
		}
		UnLockThreadMutex(&SocketTableLock,"GetIndexInSocketTable.USER_IDE",USER_IDE);
		printf("\n Index : %d | USER_IDE : %d | SocketId : %d | SeqNo :%d",Index,USER_IDE,SocketId,iSeqNo);

		/***
		  We have the socket and its mutex.... so lock the socket and send the data.
		 ***/
		Len = ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgLength;

		switch(Transcode)
		{
			case TC_INT_CON_DEL_RESP                        :
				sprintf(localStr,"%d|%d|%.0lf\n",ErrorCode,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,0);
				printf("\n Sending The Response: %s",localStr); 
				break;
			default:
				if (ErrorCode == 1 )
				{
					printf("\n Error Message: %s",((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
					sprintf(localStr,"%d|%d|%s\n",ErrorCode,((struct  INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
					printf("\n Sending The Response: %s",localStr);
				}
				else
				{
					printf("\n Error Message: %.0lf",((struct ORDER_RESPONSE *)OrderResp)->fOrderNum);
					sprintf(localStr,"%d|%d|%.0lf\n",ErrorCode,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,((struct ORDER_RESPONSE *)OrderResp)->fOrderNum);
					printf("\n Sending The Response: %s",localStr);
				}
				printf("\n Sending The Response: %s",localStr);
				break;
		}

		/* Added Upto Here */
		LockThreadMutex(&SocketTable[Index].Mutex,"SocketTable[].USER_IDE",USER_IDE);
		printf ("\n\t Lockd the Mutex" ) ;
		printf("\n SocketId: %d |  USER_IDE : %d | SeqNo : %d ",SocketTable[Index].SocketId,USER_IDE,iSeqNo);
		Retval = Send(SocketTable[Index].SocketId,localStr,&Len,0);
		if (Retval 	< 0)
		{
			/**
			  Some FATAL ERROR again, due to which the user will not get the Error Resp packet ...
			  most probably timeout and die.
			 **/
			printf("\n Failed To Send The Data %s",localStr);
			UnLockThreadMutex(&SocketTable[Index].Mutex,"SocketTable[].,USER_IDE",USER_IDE);
			CleanResources(Index);
			/*			return;*/
			printf("\n  Continue...");
			continue;
		}

		UnLockThreadMutex(&SocketTable[Index].Mutex,"SocketTable[].USER_IDE",USER_IDE);
		gettimeofday(&TimeStampSend,NULL);
		printf("\nWriteWorkeThread:Socket | %d | USER_IDE | %d |iSeqNo | %d | sec |  %ld | usec |  %ld | ",SocketId,USER_IDE,iSeqNo,TimeStampSend.tv_sec,TimeStampSend.tv_usec);
#ifdef	DBG
		printf("\nWriteWorkerThread: Sent the data to the User successfully");	
#endif
		CleanResources(Index);  /************* Alok Added for testing ************/

	}
	return;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments: Indexes into the SocketTable and returns the Index where we get a match.
//NOTE:: FOR ALLOWING THE LOGON OF THE SAME USERID FROM 2 DIFF PLACES, SIMILAR TO 
//RELAY THIS FUNCTION NEEDS TO BE CHANGED.
////////////////////////////////////////////////////////////////////////////////*/
BOOL    GetIndex_In_Socket_Table(LONG32 Id)
{
	SHORT  i;

	for(i=0;i<MAX_NO_OF_SOCKETS;i++)
	{
		if (SocketTable[i].SocketId == Id)
			return i;
	}
	return ERROR;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Returns back the Index of the Slot which is empty.
////////////////////////////////////////////////////////////////////////////////*/
BOOL	GetSlot_In_Socket_Table()
{
	SHORT	i;

	for(i=0;i<MAX_NO_OF_SOCKETS;i++)
	{
		if (SocketTable[i].SocketId == UNUSED || SocketTable[i].SocketId == -1)
			return i;
	}
	return ERROR;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Whenver the user connects the first message expected from him is the
//			logon message. On receiving this message the user will be validated
//			for a valid userid & passwd.
//				Failure in sending a correct UserId/Passwd will result in termination
//			of the connectivity.
//VarUsage: Index is the subscript of the socket to be clearedin the Socket_Table.
////////////////////////////////////////////////////////////////////////////////*/
BOOL	ValidateUser()
{
	/***
	  Read the UserId/Passwd from the ini file and authenticate the user. If its a valid
	  user then mark it as a _VALID_USER_ (default is _INVALID_USER).
	  If a packet is received from the other end without a proper login (i.e. one
	  whose status is still in the _INVALID_USER state) then the packet will be dropped
	  along with the connectivity since its a malicious user trying trying to connect.
	 ***/
	return TRUE;
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Clears the entry from UserIdLookUpTable, SocketLookUpTable and the 
//			ActiveSocketSet.
//				This function will be called only when something has gone wrong 
//			with the socket, due to which all the users who have received the
//			requests on this socket will be deleted too.
//VarUsage: Index is the subscript of the socket to be clearedin the Socket_Table.
////////////////////////////////////////////////////////////////////////////////*/
void	CleanResources(LONG32 Index)
{
	LockThreadMutex(&UserIdTableLock,"DeleteUser.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
	DeleteUser( IndexNode,
			SocketTable[Index].SocketId,
			NULL,
			NULL,
			SOCKET_ID,
			NULL);
	UnLockThreadMutex(&UserIdTableLock,"DeleteUser.SocketTable[Index].SocketId",SocketTable[Index].SocketId);

	LockThreadMutex(&ActiveSocketLock,"FDCLR.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
	FD_CLR(SocketTable[Index].SocketId,&ActiveSocketSet);
	UnLockThreadMutex(&ActiveSocketLock,"FDCLR.SocketTable[Index].SocketId",SocketTable[Index].SocketId);

	LockThreadMutex(&SocketTableLock,"pthread_mutex_init.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
	SocketTable[Index].SocketId = UNUSED;
	SocketTable[Index].UserStatus = UNUSED;
	if (pthread_mutex_init (&SocketTable[Index].Mutex,NULL) != 0)
		kill(getpid(),SIGTERM);

	UnLockThreadMutex(&SocketTableLock,"pthread_mutex_init.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
}


/*////////////////////////////////////////////////////////////////////////////
//Comments:	UnLocks the mutex which has been locked.
//
//Var Usage:mutex - The mutex to be unlocked.
////////////////////////////////////////////////////////////////////////////*/
void UnLockThreadMutex ( pthread_mutex_t * mutex,CHAR *Position , int Identifier)
{
	struct timeval TimeStampRead1;
	struct timeval TimeStampRead2;
	if(pthread_mutex_unlock(mutex) != 0)
	{
#ifdef     DBG
		printf("\nLockThreadMutex: Error in UnLocking Mutex \n");
#endif
		kill(getpid(),SIGTERM);
	}
}


/*////////////////////////////////////////////////////////////////////////////
//Comments:	Locks the mutex and restricts the access to the resource being 
//			locked till it is not unlocked by the calling function itself.
//
//Var Usage:mutex - The mutex to be locked.
////////////////////////////////////////////////////////////////////////////*/
void LockThreadMutex ( pthread_mutex_t * mutex,CHAR *Position,int Identifier)
{
	struct timeval TimeStampRead1;
	struct timeval TimeStampRead2;
	if(pthread_mutex_lock(mutex) != 0)
	{
#ifdef     DBG
		printf("\nLockThreadMutex: Error in Locking Mutex \n");
#endif
		kill(getpid(),SIGTERM);
	}
}

/*////////////////////////////////////////////////////////////////////////////
//Comments:	Send doesnt guarantee that all the data in the buffer will
//			be sent in a single call to send, loop around checking the return 
//			value till all the bytes are sent.
//
//Var Usage:Socketfd- Socket Descriptor to which data will be sent.
//			SendData- Data to be sent.
//			SendLen - Len of the data to be sent.
//			Flags	- If any.
////////////////////////////////////////////////////////////////////////////*/
BOOL    Send(LONG32 Socketfd,CHAR *SendData,LONG32 *SendLen,SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{
		printf("\n SocketId: %d",Socketfd);
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("\nSend: Error is");
			return Bytes;
		}
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;          /* return -1 on failure, 0 on success*/
}

/*////////////////////////////////////////////////////////////////////////////
//Comments:	Recv doesnt guarantee that all the data received in the buffer in
//			a single go will be of the len specified. Hence loop aroung till
//			the specified no of bytes are not received.
//
//Var Usage:Socketfd- Socket Descriptor from which data is read.
//			RecvData- Data to be read.
//			RecvLen - Len of the data to be read.
//			Flags	- If any.
////////////////////////////////////////////////////////////////////////////*/
BOOL    Recv(LONG32 Socketfd,CHAR *RecvData,LONG32 *RecvLen,SHORT Flags)
{
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;

	while(TotalLen < *RecvLen)
	{
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("\nRecv: Error is");
			return Bytes;
		}
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	*RecvLen = TotalLen;
	printf("\n total no of bytes recieved are :%d",TotalLen);
	return TRUE;          /* return -1 on failure, 0 on success*/
}


/*/////////////////////////////////////////////////////////////////////////////////
//Comments:	Adds a node to the list of the Internet users who have placed orders 
//			and are existing in the loop.
/////////////////////////////////////////////////////////////////////////////////*/
void AddUser (UserId_Lookup_Table *Curr,LONG32 UserId,LONG32 SocketId,CHAR *ExchId,CHAR Segment)
{
	if (Curr == NULL)
	{
		IndexNode = (struct UserId_Lookup_Table *)malloc (sizeof(UserId_Lookup_Table));
		IndexNode->UserId	= UserId;
		IndexNode->SocketId	= SocketId;
		printf("\n IndexNode->SocketId: %d",IndexNode->SocketId);
		IndexNode->Segment	= Segment;
		memset(&(IndexNode->Exch),' ',EXCHANGE_LEN);
		memset(&(IndexNode->Exch),ExchId,EXCHANGE_LEN);
		IndexNode->Next		= NULL;
		return;
	}

	while(Curr->Next != NULL)
		Curr = Curr->Next;

	Curr->Next = (struct UserId_Lookup_Table *)malloc (sizeof(UserId_Lookup_Table));
	Curr->Next->UserId	= UserId;
	Curr->Next->SocketId= SocketId;
	Curr->Next->Segment	= Segment;
	memset(&(Curr->Next->Exch),' ',EXCHANGE_LEN);
	memset(&(Curr->Next->Exch),ExchId,EXCHANGE_LEN);
	Curr->Next->Next	= NULL;

}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Deletes the user entry from the list when, the response is sent back
//			or when something goes haywire.
//NOTE: ONLY THE USERID IS BEING USED CURRENTLY FOR DELETING AN ENTRY FROM THE 
//LIST OF USERS WHO HAVE PLACED ORDERS. BUT IN FUTURE THE EXCHID AND THE SEGMENT
//MAY NEED TO BE COMPARED IF ITS STARTS SUPPORTING MULTIPLE LOGON FACILITY.
////////////////////////////////////////////////////////////////////////////////*/
void DeleteUser (UserId_Lookup_Table *Curr,LONG32 Id,CHAR *ExchId, CHAR Segment,SHORT MODE,LONG32 *SocketId)
{
	UserId_Lookup_Table *tmpnode;
	int counter=0,count=0;

	/***
NOTE: This is a very imp check. Do not delete this.
The program may stop/crash at some point of time without delivering response packets
which may have been there in the reverse Q. If this happens then when the program
starts again the WriteWorkerThread will attempt to read from the Q, which will 
result a call to this function which will try to loop and find the userid in the
link list and will again *CRASH*.
	 ***/
	if (Curr == NULL)
		return;


	printf("\n DeleteUser:NoOfNodes :%d",NoOfNodes);
	if (MODE == SOCKET_ID)
	{
		printf("\nDeleteUser: Deleting node with socketid:%d",Id);
		printf("\n Curr->SocketId %d User %d Id %d",Curr->SocketId,Curr->UserId,Id);
		if (Curr->SocketId == Id)
		{
			IndexNode = Curr->Next;
			printf("\nDeleteUser: NODE deleted...");
			free(Curr);
			return;
		}

		if (Curr->Next == NULL)
			return;

		while(Curr->Next->Next != NULL)
		{
			printf("\n Curr->Next->SocketId %d User %d",Curr->Next->SocketId,Curr->Next->UserId);
			if (Curr->Next->SocketId == Id)
			{
				tmpnode	= Curr->Next;
				Curr->Next = Curr->Next->Next;
				free(tmpnode);
				printf("\n In If Counter1:%d",counter++);
			}
			else
			{
				Curr = Curr->Next;
				printf("\n In Else Counter2:%d",count++);
			}
		}

		if (Curr->Next->SocketId == Id)
		{		
			free(Curr->Next);
			Curr->Next = NULL;
		}
	}
	else
	{
		printf("\n Deleting node with userid:%d",Id);
		if (Curr->UserId == Id)
		{
			*SocketId = Curr->SocketId;
			printf("\n SocketId : %d,Curr->SocketId : %d",*SocketId,Curr->SocketId);
			IndexNode = Curr->Next;
			free(Curr);
			return;
		}

		if (Curr->Next == NULL)
			return;

		while(Curr->Next->Next != NULL)
		{
			if (Curr->Next->UserId == Id)
			{
				*SocketId = Curr->Next->SocketId;
				printf("\n SocketId: %d,Curr->Next->SocketId : %d",*SocketId,Curr->Next->SocketId );
				tmpnode	= Curr->Next;
				Curr->Next = Curr->Next->Next;
				free(tmpnode);
				return;
			}
			Curr = Curr->Next;
		}

		if (Curr->Next->UserId == Id)
		{		
			*SocketId = Curr->Next->SocketId;
			printf("\n SocketId: %d,Curr->Next->SocketId : %d",*SocketId,Curr->Next->SocketId );
			free(Curr->Next);
			Curr->Next = NULL;
		}
	}
}

