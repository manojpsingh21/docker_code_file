#include "IPCS.h"
#include "WebAdapter.h"

void        LockThreadMutex                 (pthread_mutex_t *,CHAR *,int );
void        UnLockThreadMutex               (pthread_mutex_t *,CHAR *,int );


LONG32	    iMsgType;
LONG32	    iUDPport;	
CHAR	    sIpAddr[IP_ADDR_LEN];	

fd_set		ActiveSocketSet;
main(int argc,char *argv[])
{
	logTimestamp("Entry :main:");
	LONG32		Signal;
	LONG32		Retval;
	LONG32		i;
	sigset_t	SignalSet;
	pthread_t	MainThreadId;
	UserId_Lookup_Table *tmpnode;

	setbuf ( stdout,NULL);
	setbuf ( stdin ,NULL);
	setvbuf( stdout , NULL , _IONBF , 0 );

	signal		(SIGHUP,SIG_IGN);
	sigemptyset	(&SignalSet);
	sigaddset	(&SignalSet,SIGTERM);
	sigaddset	(&SignalSet,SIGINT);
	sigaddset	(&SignalSet,SIGUSR2);
	sigaddset	(&SignalSet,SIGUSR2);
	sigaddset	(&SignalSet,SIGTRAP);
	sigprocmask (SIG_BLOCK,&SignalSet,NULL);

	//if (argc <2)
	logInfo("Number of Argc param :%d:",argc);
	memset(sIpAddr,'\0',IP_ADDR_LEN);
	logInfo("2nd param :%s:",argv[2]);
	if (argc <5)
	{
		logInfo(" Usage <WebAdaptor> <PortNo> <MsgType>");
		exit(1);
	}

	MasterPort	=	atoi(argv[1]);
	iMsgType = atoi(argv[2]);
	iUDPport = atoi(argv[3]);
	strncpy(sIpAddr,argv[4],IP_ADDR_LEN);

	logDebug1(" Main Port : %d",MasterPort);
	logDebug1(" MsgType : %d",iMsgType);
	logDebug1(" iUDPport : %d",iUDPport);
	logDebug1(" sIpAddr : %s",sIpAddr);

	if((ItsToRmsDir = OpenMsgQ(RelToOrdRtr)) == ERROR )
	{
		perror("Open RelToDirQ :");
		exit( 1 );
	}

	logDebug2(" Sucessfully opened RelToOrdRtr Q with Id :%d:",ItsToRmsDir);

	if( (RelDirToIts = OpenMsgQ(TrdRtrToWebAdap)) == ERROR)
	{
		perror("Open DirToRelQ :");
		exit( 1 );
	}

	logDebug2(" Sucessfully opened TrdRtrToWebAdap Q with Id :%d:",RelDirToIts);

	if (pipe(SocketCommunicationPipe) != 0)
	{
		logFatal("Error in creation of the SocketCommunicationPipe");
		exit(1);
	}

	if (pipe(DummyPipe) != 0)
	{
		logFatal("Error in creation of the DummyPipe");
		exit(1);
	}

	pthread_once (&once_control,Init_Routine);

	pthread_sigmask(SIG_BLOCK,&SignalSet,NULL);

	logDebug1(" Creating MainThread ...");
	pthread_create(&MainThreadId,NULL,ReadWriteMainThread,NULL);

	logDebug1(" MAX_NO_OF_SOCKETS:%d:",MAX_NO_OF_SOCKETS);

	//	fSendUDPMsg();


	while(1)
	{
		/*		if ((Retval = sigwait(&SignalSet,&Signal)) < 0)*/
		logInfo("Waiting for Signal");	
		if ((Retval = sigwait(&SignalSet,&Signal)) < 0)
		{
			perror("\n\n FATAL ERROR in sigwait::");
			break;
		}

		logDebug2("Signal :%d:",Signal);

		if (Signal == SIGTRAP)
		{
			/***
			  This part is just for debugging purpose. This signal can be raised from outside
			  to display all the nodes existing in the linked list.
			 ***/
			LONG32 	localNodes=0;

			if (IndexNode == NULL)
			{
				logDebug2(" No nodes in List");
				continue;
			}

			logDebug2(" Existing nodes in List");
			tmpnode = IndexNode;
			while(IndexNode != NULL)
			{
				logDebug2(" Node::%d UserId::%d SocketId::%d",++localNodes,tmpnode->UserId,tmpnode->SocketId);
				if (tmpnode->Next == NULL)
					break;

				tmpnode = tmpnode->Next;
			}
		}
		else if(Signal == SIGUSR2)
		{
			for(i=0;i<MAX_NO_OF_SOCKETS;i++)
			{
				logDebug2( "in SIGUSR2 case Socket id = %d , UserStatus =  %d ,pthread_mutex_t = %d ",SocketTable[i].SocketId,SocketTable[i].UserStatus,SocketTable[i].Mutex);
			}

			continue ;
		}
		else if ((Signal == SIGTERM) || (Signal == SIGINT))
		{
			logInfo("caught SIGTERM");
			pthread_cancel(MainThreadId);
			for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS;i++)
				pthread_cancel(ThreadTable[i].ThreadId);

			LockThreadMutex(&UserIdTableLock,"DeleteUser",0);
			while (IndexNode != NULL)
			{
				tmpnode = IndexNode;
				IndexNode = IndexNode->Next;
				logDebug1(" Freed Node for User::%d on SocketId::%d",tmpnode->UserId,tmpnode->SocketId);
				free(tmpnode);
			}
			UnLockThreadMutex(&UserIdTableLock,"DeleteUser",0);



			break;
		}

		for(i=0;i<MAX_NO_OF_SOCKETS;i++)
		{
			SocketTable[i].SocketId = UNUSED;
			SocketTable[i].UserStatus = UNUSED;
		}


	}

	pthread_join(MainThreadId,NULL);
	logDebug1(" ReadWriteMain Thread terminated");

	for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS;i++)
		pthread_join(ThreadTable[i].ThreadId,NULL);

	fflush(stdout);
	logTimestamp("Exit :main:");
	exit(0);
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Intialises all the mutex and the gobal variables to the default values.
////////////////////////////////////////////////////////////////////////////////*/
void Init_Routine ()
{
	logTimestamp("Entry :Init_Routine:");
	LONG32	i;

	logDebug1(" Initialising Resources ...");



	if(pthread_mutex_init (&ActiveSocketLock,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&SocketTableLock,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&SocketCommunicationPipeLock,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&UserIdTableLock,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&OracleAccess,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&TotalThreadsInProgressLock,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_mutex_init (&DynamicThreadsInProgressCondLock,NULL ) != 0)
		logDebug1("Init_Routine: Error in intialising Mutex"),exit(1);

	if(pthread_attr_init(&ThreadAttr) != 0)
		logDebug1("Init_Routine: Error in initialising the Attributes"),exit(1);

	/***
	  This attribute will be applied for the threads which will be dynamically spawned
	  coz we cant wait for them to terminate and free up resources.
	 ***/

	pthread_attr_setdetachstate(&ThreadAttr,PTHREAD_CREATE_DETACHED);


	for(i=0;i<MAX_NO_OF_SOCKETS;i++)
	{
		SocketTable[i].SocketId = UNUSED;	
		SocketTable[i].UserStatus = UNUSED;	
		if (pthread_mutex_init (&SocketTable[i].Mutex,NULL) != 0)
			exit (1);
	}

	for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS+MAX_NO_STATIC_WRITE_EXCH_RESP_THREADS;i++)
	{
		ThreadTable[i].Status = UNUSED;	
	}

	logTimestamp("Exit :Init_Routine:");
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Creates the Master Socket for accepting the new connections.The socketid
//			on which the data arrives is written to the pipe, and the Worker thread
//			which accquires a lock to the pipe processes the data. If the value of
//			StaticThreadsInProgress becomes equal to MAX_NO_STATIC_READ_THREADS, then ReadMain...
//			spawns off a new thread dynamically which will process the packet and die.
//			It also creates the Read and wrtie worker  threads.
////////////////////////////////////////////////////////////////////////////////*/
void	*ReadWriteMainThread(void *arg)
{
	logTimestamp("Entry :ReadWriteMainThread:");
	pthread_t	ThreadId[MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS];
	struct		sockaddr_in	servadd,cliadd,bc_servadd;
	struct		sockaddr_in	ev_servadd;		
	LONG32		Retval=1,i,MaxSocketId=0;
	LONG32		MasterSocket,SM_MasterSocket=0,NewSocket,Len,DynamicThreads=0;
	LONG32 		EV_MasterSocket=0;		
	CHAR		recvString[MAX_PACKET_SIZE];
	fd_set		ReadSocketSet;
	CHAR		DummyChar;
	CHAR		sCommStr[COMMAND_LEN];
	int t;
	int len;
	struct sockaddr_in sin;
	struct hostent *host;

	memset(sCommStr,'\0',COMMAND_LEN);
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);

	//memset((CHAR *)&servadd,' ',sizeof(struct sockaddr_in));
	memset((CHAR *)&servadd,'\0',sizeof(struct sockaddr_in));
	servadd.sin_family			= AF_INET;
	servadd.sin_port			= htons(MasterPort);
	servadd.sin_addr.s_addr		= htonl(INADDR_ANY);

	logDebug1(" Creating Worker Threads ...");
	for(i=0;i<MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS;i++)
	{
		if (i < MAX_NO_STATIC_READ_THREADS)
		{
			if ((pthread_create(&ThreadId[i],NULL,ReadWorkerThread,NULL)!= 0))
			{
				logFatal("ReadWriteMainThread: Error in creation of the Read Worker Threads");
				kill(getpid(),SIGTERM);
			}
		}
		else if(MAX_NO_STATIC_READ_THREADS <= i <MAX_NO_STATIC_READ_THREADS+MAX_NO_STATIC_WRITE_THREADS )
		{
			if ((pthread_create(&ThreadId[i],NULL,WriteWorkerThread,NULL)!= 0))
			{
				logFatal("ReadWriteMainThread: Error in creation of the Write Worker Threads");
				kill(getpid(),SIGTERM);
			}
		}
		ThreadTable[i].ThreadId = ThreadId[i];
		ThreadTable[i].Status 	= USED;

	}

	if ((MasterSocket=socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		perror("\nReadWriteMainThread: Error in creating the MasterSocket");
		kill(getpid(),SIGTERM);
	}

	if (setsockopt(MasterSocket,SOL_SOCKET,SO_REUSEADDR,(char *)&Retval,sizeof(Retval))<0)
	{
		perror("\nReadWriteMainThread: Error in setsockopt on the MasterSocket");
		kill(getpid(),SIGTERM);
	}

	if( bind(MasterSocket,(struct sockaddr *)&servadd, sizeof(servadd)) == ERROR )
	{
		perror("\nReadWriteMainThread: Error in binding to the MasterSocket");
		kill(getpid(),SIGTERM);
	}

	listen(MasterSocket,5);


	/***
NOTE: As the name suggests the job of this pipe itself is dumb. We just write to the pipe
to make the select call unblocking.
	 ***/
//	FD_ZERO(&ActiveSocketLock);
	//FD_ZERO(&ActiveSocketLock);
	
	FD_ZERO(&ActiveSocketSet);
	FD_ZERO(&ReadSocketSet);
	FD_SET (DummyPipe[0],&ActiveSocketSet);
	FD_SET (MasterSocket,&ActiveSocketSet);


	MaxSocketId=MasterSocket;

	while(1)
	{
		//		MaxSocketId = GetMaxSocket ( MasterSocket,DummyPipe[0] );
		logDebug1(" DP here MaxSocketId :%d:",MaxSocketId);
		LockThreadMutex(&ActiveSocketLock,"ActiveSocketLock",0);
		ReadSocketSet = ActiveSocketSet;
		UnLockThreadMutex(&ActiveSocketLock,"ActiveSocketLock",0);


		logDebug1(" ============================ Waiting for Req/Data ============================");
		Retval = select(MaxSocketId +1,&ReadSocketSet,(fd_set *)NULL,(fd_set *)NULL,(struct timeval *) NULL);
		if (Retval <= 0)
		{
			perror("\nReadWriteMainThread: Error in the select call");
			continue;
		}

		if (FD_ISSET(DummyPipe[0],&ReadSocketSet))
		{
			read(DummyPipe[0],&DummyChar,sizeof(CHAR));
			continue;
		}

		pthread_testcancel();	
		if (FD_ISSET(MasterSocket,&ReadSocketSet))
		{
			/**
			  Someone is trying to make a connection.Accept the call and add it to the Socket_Lookup_Table
			  if the count of sockets hasnt excedded the maximum.
			 **/
			//memset((CHAR *)&cliadd,' ',sizeof(struct sockaddr_in));
			memset((CHAR *)&cliadd,'\0',sizeof(struct sockaddr_in));
			Retval = sizeof(struct sockaddr);
			if ((NewSocket = accept(MasterSocket,(struct sockaddr *)&cliadd,&Retval)) < 0)
			{
				perror("\nReadWriteMainThread: Error in accepting the connection");
				kill(getpid(),SIGTERM);
			}
			logTimestamp("IP captured  :%s:", inet_ntoa(cliadd.sin_addr));
			logDebug1("New Socket Connection Established on:%d",NewSocket);
				
			/***
			  sprintf(sCommStr,"http://localhost:8080/RupeeSeedWS/Utility/reconnectWS?rsPwd=%s",getenv("WS_PASSWORD"));
			  logDebug2("sCommStr :%s:",sCommStr);
			  system(sCommStr);
			 **/				

			/****************************************
			  len = sizeof cliadd;
			  if (getpeername(NewSocket, (struct sockaddr *) &sin, &len) < 0)
			  perror("getpeername");
			  else 
			  {
			  if ((host = gethostbyaddr((char *) &sin.sin_addr, sizeof sin.sin_addr, AF_INET)) == NULL)
			  perror("gethostbyaddr");
			  else 
			  logDebug("remote host is '%s'\n", host->h_name);
			  }
			 *******************************************/


			LockThreadMutex(&SocketTableLock,"GetSlotInSocketTable.NewSocket",NewSocket);
			if ((Retval = GetSlot_In_Socket_Table()) == ERROR)
			{
				UnLockThreadMutex(&SocketTableLock,"GetSlotInSocketTable.NewSocket",NewSocket);
				logDebug2("ReadWriteMainThread: SocketTable pool full... new connection will be dropped");
				if (NewSocket != 0)
				{
					logDebug2("Shutdown socket :%d:",NewSocket);
					close(NewSocket);
					//	shutdown(NewSocket,2 );
					//	perror("Shutdown Socket 3 : ");
				}

				continue;
			}

			logDebug2(" ALOK HERE IN GetSlot_In_Socket_Table Retval is :%d:",Retval);
			UnLockThreadMutex(&SocketTableLock,"GetSlotInSocketTable.NewSocket",NewSocket);

			LockThreadMutex(&ActiveSocketLock,"FDSET.NewSocket",NewSocket);
			FD_SET(NewSocket,&ActiveSocketSet);
			UnLockThreadMutex(&ActiveSocketLock,"FDSET.NewSocket",NewSocket);

			LockThreadMutex(&SocketTableLock,"SocketTable[].SocketId.NewSocket",NewSocket);
			SocketTable[Retval].SocketId = NewSocket;
			UnLockThreadMutex(&SocketTableLock,"SocketTable[].SocketId.NewSocket",NewSocket);
			MaxSocketId=NewSocket;
			logDebug2(" NewSocket: %d",NewSocket);
		}

		pthread_testcancel();	
		for(i=0;i<=MAX_NO_OF_SOCKETS;i++)
		{
			if (FD_ISSET(SocketTable[i].SocketId,&ReadSocketSet))
			{
				/***
				  Write the Index of the Socketid from which the data packet has arrived on to the pipe
				  and whichever thread is waiting on a read on the pipe will read the index of the socket
				  in the SocketTable.
				 ***/

				LockThreadMutex(&ActiveSocketLock,"FDSET.SocketTable[i].SocketId",SocketTable[i].SocketId);
				FD_CLR(SocketTable[i].SocketId,&ActiveSocketSet);
				UnLockThreadMutex(&ActiveSocketLock,"FDSET.SocketTable[i].SocketId",SocketTable[i].SocketId);

				if (write(SocketCommunicationPipe[1],(void *)&i,sizeof(LONG32)) < 0)
				{
					perror("\nReadWriteMainThread: Error in writing to pipe");
					logFatal(" error is :%d",errno);
				}
				logDebug3("ReadWriteMainThread: Data pending on socket :%d",SocketTable[i].SocketId);
				/*************************************

				  if (TotalThreadsInProgress >= MAX_NO_STATIC_READ_THREADS)
				  {
				 ***
				 If we are here it indicates that all the worker threads are busy processing, hence
				 spawn out a new thread which will process this new packet and die.

NOTE: If the Queues are FULL then the Worker threads will block on the Queue for
writing the data. In such a case all the arriving data packets will result in the
spawning of a dynamic thread. If the Queues never become empty and we go on spawning
threads then....... we may exceed the system limit. Hence if the no of dynamic
thread reaches the threshold of MAX_NO_DYNAMIC_READ_THREADS then we wait for the
a Conditional Variable till the count of dynamic threads doesnt come down.
				 ***

				 if (TotalThreadsInProgress == MAX_NO_DYNAMIC_READ_THREADS + MAX_NO_STATIC_READ_THREADS)
				 {
				 logDebug("\n System is going to be suspended For crossing the Thread Limit");
				 _SYSTEM_SUSPENDED_ = TRUE;
				 LockThreadMutex(&DynamicThreadsInProgressCondLock,"DynamicThreads",0);
				 pthread_cond_wait(&DynamicThreadsInProgressCondVar,&DynamicThreadsInProgressCondLock);
				 UnLockThreadMutex(&DynamicThreadsInProgressCondLock,"DynamicThreads",0);
				 }
				 logDebug("\nReadWriteMainThread: All the Read Workers Busy... Spawning a new Thread now");
				 pthread_create(&ThreadId,&ThreadAttr,ProcessIncomingPacket,(void *)i);

				 LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.SocketTable[i].SocketId",SocketTable[i].SocketId);
				 ++TotalThreadsInProgress;
				 logDebug("\nDynamic Thread Created: STATIC-TotalThreadsinProgress: %d",TotalThreadsInProgress-MAX_NO_STATIC_READ_THREADS);
				 UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.SocketTable[i].SocketId",SocketTable[i].SocketId);


				 if (TotalThreadsInProgress >= MAX_NO_DYNAMIC_READ_THREADS + MAX_NO_STATIC_READ_THREADS -3)
				 logDebug("\nReadWriteMainThread: !!! WARNING,approaching MAX_NO_DYNAMIC_READ_THREADS limit");

				 logDebug("\nReadWriteMainThread: DYNAMIC-TotalThreadsinProgress: %d",TotalThreadsInProgress);
				 }
				 *************************************/


			}
		}
	}
	logTimestamp("Exit :ReadWriteMainThread:");
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Statically Spawned Worker Thread, waits on the pipe for receiving the 
//			socketid from which the data will be read. When a lock is aqquired
//			the global var StaticThreadsInProgress is incremented to indicate the no of
//			threads which are currently busy and decremented when the processing 
//			is done.	
////////////////////////////////////////////////////////////////////////////////*/
void	*ReadWorkerThread(void *arg)
{
	logTimestamp("Entry :ReadWorkerThread:");
	LONG32	Index=0;

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);

	while(1)
	{

		if (read(SocketCommunicationPipe[0],&Index,sizeof(LONG32)) < 0)
		{
			perror("\nStaticReadWorkerThread: Error in reading from pipe");
			continue;
		}
		logDebug3("StaticReadWorkerThread: SocketIndex read from pipe is :%d",Index);

		LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.Index",Index);
		++TotalThreadsInProgress;
		logDebug3("ReadWorkerThread: STATIC-TotalThreadsinProgress: %d",TotalThreadsInProgress);
		UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.Index",Index);

		ProcessIncomingPacket((void *)Index);
		pthread_testcancel();
	}
	logTimestamp("Exit  :ReadWorkerThread:");
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Takes the socketid as the argument and reads the data from the socket.
//			Adds it in the Offline Table if the OFF_STAT_FLG flag in the table is
//			set else it writes it to the Q, to be processed by the Parent Process.
//Var Usage:SocketId - To read from. 
////////////////////////////////////////////////////////////////////////////////*/
void*	ProcessIncomingPacket(void *Index)
{
	logTimestamp("Entry :ProcessIncomingPacket:");
	LONG32			Retval		=	0			;
	LONG32			Len			=	0			;
	LONG32			SocketIndex =	0			;
	LONG32			Qid			=	0			; 
	LONG32			iTransCode	=	0			;
	LONG32			TempLen		=	0			;
	SHORT			MsgType		=	0			;
	CHAR			DummyChar	=	'D'			;
	CHAR			recvString[MAX_PACKET_SIZE]	;
	CHAR			*arr[6]					; 
	CHAR			*ReqDet						;
	CHAR			Ord_Str[MAX_PACKET_SIZE]	;
	int				iSocket	=	0;
	int				iRetStatus	=	0;
	//struct ORDER_REQUEST           ord_req     ;
	CHAR    ord_req[MAX_PACKET_SIZE];
	struct INT_COMMON_REQUEST_HDR   ReqHeader   ;
	struct timeval TimeStampRead;
	struct timeval TimeStampRead1;
	struct timeval TimeStamp3;
	struct timeval TimeStamp4;
	int iSeqNo=0;
	unsigned long long int USER_IDE	= 0;
	char *buf ;
	char temp_store[100];


	SocketIndex = (LONG32 ) Index					; 
	Len 		= sizeof(struct INT_COMMON_REQUEST_HDR) + 26	;
	gettimeofday(&TimeStampRead1,NULL);
	/***	memset( recvString,NULL,MAX_PACKET_SIZE );****/
	memset( recvString,'\0',MAX_PACKET_SIZE );
	memset( ord_req,' ',MAX_PACKET_SIZE);

	LockThreadMutex( &SocketTable[SocketIndex].Mutex ,"SocketTable[].Mutex",SocketTable[SocketIndex].SocketId);
	iSocket = SocketTable[SocketIndex].SocketId	 ;
	Retval = Recv( SocketTable[SocketIndex].SocketId, recvString ,&Len,MSG_PEEK,0				);
	if (Retval <= 0)
	{
		UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].Mutex",SocketTable[SocketIndex].SocketId);
		if (SocketTable[SocketIndex].SocketId != 0)
		{
			logInfo("Printing Shutdown :%d: SocketIndex %d:",SocketTable[SocketIndex].SocketId,SocketIndex);
			close(SocketTable[SocketIndex].SocketId);
			// shutdown(SocketTable[SocketIndex].SocketId,2);
		}

		CleanResources(	SocketIndex,'A');
		LockThreadMutex(	&TotalThreadsInProgressLock,"ThreadsInLock",SocketTable[SocketIndex].SocketId);

		--TotalThreadsInProgress;

		logDebug2(" Recv failed with Retval	: %d ,iSocket :: %d ",Retval,iSocket);
		logDebug2(" ERRNO	: %d 	iSocket :: %d ", errno,iSocket 				);
		perror("Recv Error	: " 						);

		UnLockThreadMutex(	&TotalThreadsInProgressLock,"ThreadsInLock",SocketTable[SocketIndex].SocketId);
		return;
	}
	logDebug2(" iSocket :: %d ,Recv The String From Its: %s",iSocket,recvString	);
	logDebug2(" iSocket :: %d ,Recv success with Retval: %d",iSocket,Retval		);


	ReqDet = (struct INT_COMMON_REQUEST_HDR *)malloc(sizeof(struct  INT_COMMON_REQUEST_HDR));

	memset( ReqDet,'\0'		,sizeof(struct INT_COMMON_REQUEST_HDR));
	memcpy( ReqDet,recvString	,sizeof(struct INT_COMMON_REQUEST_HDR));
	logDebug2(" recvString[0] :%c: , recvString[0] :%d:",recvString[0],recvString[0]);

	logDebug2("iSocket :: %d , req Details :%s: hex recvString :%04x:\n",iSocket,recvString,recvString);
	logDebug2("strlen(recvString) :%d: Len :%d:",strlen(recvString),Len);
	if((strlen(recvString) < Len) || (strchr(recvString,'|') == NULL ) )
	{
		logTimestamp("Recvd less than 54 byets. Dropping Packet ");
		Retval = Recv( SocketTable[SocketIndex].SocketId, recvString ,&Len,0,0				);
		if (Retval <= 0)
	        {
	                UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].Mutex",SocketTable[SocketIndex].SocketId);
	                if (SocketTable[SocketIndex].SocketId != 0)
	                {
	                        logInfo("Printing Shutdown :%d: SocketIndex %d:",SocketTable[SocketIndex].SocketId,SocketIndex);
	                        close(SocketTable[SocketIndex].SocketId);
			}

	                CleanResources( SocketIndex,'A');
	                LockThreadMutex(        &TotalThreadsInProgressLock,"ThreadsInLock",SocketTable[SocketIndex].SocketId);

	                --TotalThreadsInProgress;

	                logDebug2(" Recv failed with Retval     : %d ,iSocket :: %d ",Retval,iSocket);
	                logDebug2(" ERRNO       : %d    iSocket :: %d ", errno,iSocket                          );
	                perror("Recv Error      : "                                             );

	                UnLockThreadMutex(      &TotalThreadsInProgressLock,"ThreadsInLock",SocketTable[SocketIndex].SocketId);
	                return;
	        }

		return;	
	}

	arr[0]=strtok_r(recvString,"|",&buf);
	ReqHeader.iSeqNo 			= atoi(arr[0]);

	arr[1]=strtok_r(NULL,"|",&buf);
	ReqHeader.iMsgLength 		= atoi(arr[1]		);

	arr[2]=strtok_r(NULL,"|",&buf);
	ReqHeader.iMsgCode = atoi(arr[2]		);

	arr[3]=strtok_r(NULL,"|",&buf);
	logDebug2("ExcgId			::	%s   Len   :: %d" ,arr[3],strlen(arr[3]));

	arr[4]=strtok_r(NULL,"|",&buf);
	logDebug2("arr[4]			::	%s   Len   :: %d",arr[4],strlen(arr[4]));

	arr[5]=strtok_r(NULL,"|",&buf);
	//USER_IDE					= atoi(arr[4]		);
	USER_IDE					= strtoull(arr[4],NULL,10);//@Ashish Changing for User id mapping for unsgined long long int.


	logDebug2(" USER_IDE		::	%llu	",USER_IDE);

	/* Added Upto Here*/
	iSeqNo=ReqHeader.iSeqNo;


	/** Added To Recv Successfully From ITS The Bytes Paded With ^M **/

	Len=ReqHeader.iMsgLength;
	logDebug1(" iSocket :: %d | Len : %d | USER_IDE : %llu | SeqNo  : %d ",iSocket,Len,USER_IDE,ReqHeader.iSeqNo);


	logDebug1(" iSocket :: %d | Transcode: %d | USER_IDE : %llu | SeqNo  : %d ",iSocket, ReqHeader.iMsgCode,USER_IDE,ReqHeader.iSeqNo);

	fflush(stdin);
	fflush(stdout);

	iTransCode=ReqHeader.iMsgCode			;
	logDebug1(" iSocket :: %d | Transcode :: %d | USER_IDE : %llu | SeqNo  : %d ",iSocket,iTransCode,USER_IDE,ReqHeader.iSeqNo)	;

	Retval = Recv( SocketTable[SocketIndex].SocketId,recvString,&Len,0	,USER_IDE);
	if (Retval <= 0)
	{
		UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].USER_IDE",USER_IDE);
		if (SocketTable[SocketIndex].SocketId != 0)
		{
			logInfo("Printing Shutdown 1  :%d: SocketIndex :%d:",SocketTable[SocketIndex].SocketId,SocketIndex);
			close(SocketTable[SocketIndex].SocketId);
			// shutdown(SocketTable[SocketIndex].SocketId,2);
			//	perror("Shutdown Socket 1 : ");
		}

		CleanResources(SocketIndex,'B');
		LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);

		--TotalThreadsInProgress;

		logDebug3("ProcessIncomingPacket: TotalThreadsinProgress	: %d | USER_IDE : %llu | SeqNo  : %d ",TotalThreadsInProgress,USER_IDE,ReqHeader.iSeqNo);
		logDebug3(" Recv failed with Retval: %d | USER_IDE : %llu | SeqNo  : %d ",Retval,USER_IDE,ReqHeader.iSeqNo);

		UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);

		return;
	}
	UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"Recv.USER_IDE",USER_IDE);
	logTimestamp("WebServOrder Recv Sock :%d: :%s:",SocketTable[SocketIndex].SocketId,recvString);
	LockThreadMutex(&ActiveSocketLock,"FDSET.USER_IDE",USER_IDE);
	FD_SET(SocketTable[SocketIndex].SocketId,&ActiveSocketSet);
	UnLockThreadMutex(&ActiveSocketLock,"FDSET.USER_IDE",USER_IDE);
	/**/
	if (write(DummyPipe[1],(void *)&DummyChar,sizeof(CHAR)) < 0)
	{
		perror("\nProcessIncomingPacket: Error in writing to pipe");
		logFatal(" error is :%d",errno);
	}
	/***/

	logDebug1("iTransCode is [%d]",iTransCode);

	switch(iTransCode)
	{
		case TC_INT_ORDER_ENTRY_REQ:
		case TC_INT_ORDER_MODIFY:
		case TC_INT_ORDER_CANCEL:
		case TC_INT_OFF_ORDER_ENTRY:
		case TC_INT_OFF_ORDER_MODIFY:
		case TC_INT_OFF_ORDER_CANCEL:
			logDebug1("Inside switch with new order");
			iRetStatus=Map_Ord_Req(recvString,&ord_req);
			logDebug1(" Returned successfully from Map_Ord_Req.USER_IDE : %llu | iSocket:: %d | SeqNo  : %d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct ORDER_REQUEST));
			break;

		case TC_INT_CON_DEL_REQ:		
			iRetStatus=Map_C2D_Req(recvString,&ord_req);
			logDebug1(" Returned successfully from Map_C2D_Req.USER_IDE : %llu | iSocket:: %d | SeqNo  : %d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct CON_TO_DELIVERY_RESPONSE));
			break;

		case TC_INT_SIP_ORD_REQ			:
		case TC_INT_SIP_ORD_CANCEL		:
		case TC_INT_SIP_ORD_PAUSE_REQ   	:
		case TC_INT_SIP_ORD_CONTINUE_REQ	:
                case TC_INT_SIP_ORD_MODIFY_REQ          :
			iRetStatus = Map_SIP_Ord_Req(recvString,&ord_req);
			logDebug2("Returned successfully from Map_SIP_Ord_Req.. USER_IDE = %llu | iSocket = %d | SeqNo =%d ",ReqHeader.iSeqNo);	
			memcpy(&Ord_Str,&ord_req,sizeof(struct SIP_ORD_REQUEST));
			break;

		case TC_INT_CO_ORDER_REQ	:
		case TC_INT_CO_ORDER_MODIFY	:
		case TC_INT_CO_ORDER_EXIT	:

			iRetStatus = Map_CO_Ord_Req(recvString,&ord_req);
			logDebug2("Returned successfully from Map_CO_Ord_Req... USER_IDE = %llu | iSocket = %d | SeqNo =%d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct CO_ORDER_REQUEST));
			break;

		case TC_INT_BO_ORDER_REQ        :
		case TC_INT_BO_ORDER_MODIFY     :
		case TC_INT_BO_ORDER_EXIT       :

			iRetStatus = Map_BO_Ord_Req(recvString,&ord_req);
			logDebug2("Returned successfully from Map_BO_Ord_Req .. USER_IDE = %llu | iSocket = %d | SeqNo =%d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct BO_ORDER_REQUEST));
			logDebug2("sizeof( struct BO_ORDER_REQUEST 3) :%d:",sizeof( struct BO_ORDER_REQUEST ));
			break;

		case TC_INT_SPREAD_OE_REQ	:
		case TC_INT_SPREAD_OM_REQ	:
		case TC_INT_SPREAD_OC_REQ	:

			iRetStatus = Map_SPRD_Req(recvString,&ord_req);
			logDebug2("Returned successfully from Map_SPRD_Req.. USER_IDE = %llu | iSocket = %d | SeqNo =%d ",ReqHeader.iSeqNo);
			memcpy(&Ord_Str,&ord_req,sizeof(struct ORDER_SPREAD_REQUEST));
			break;
		
		case TC_INT_GTT_ORDER_ENTRY     :
                case TC_INT_GTT_ORDER_MODIFY    :
                case TC_INT_GTT_ORDER_CANCEL    :

                        logDebug1("Inside switch with new order");
                        iRetStatus=Map_GTT_Ord_Req(recvString,&ord_req);
                        logDebug1(" Returned successfully from Map_Ord_Req.USER_IDE : %d | iSocket:: %d | SeqNo  : %d ",ReqHeader.iSeqNo);
                        memcpy(&Ord_Str,&ord_req,sizeof(struct FOREVER_ORDER_REQUEST));
                        break;			

		default:

			logDebug2(" There is no Transcode in the list ");

			UnLockThreadMutex(&SocketTable[SocketIndex].Mutex,"SocketTable[].default",0 );
			if (SocketTable[SocketIndex].SocketId != 0)
			{
				close(SocketTable[SocketIndex].SocketId);
				logInfo("Printing Shutdown 5  :%d: SocketIndex :%d:",SocketTable[SocketIndex].SocketId,SocketIndex);
				// shutdown(SocketTable[SocketIndex].SocketId,2);
				//	perror("Shutdown Socket 2 : ");
			}

			CleanResources(SocketIndex,'C' );
			LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.default",0);

			--TotalThreadsInProgress;
			UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.default",0);
			logDebug1(" ProcessIncomingPacket:default::USER_IDE : %llu | iSocket:: %d | SeqNo  : %d | TotalThreadsinProgress : %d",ReqHeader.iSeqNo,TotalThreadsInProgress);

			return;
	}
	Len = ((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->iMsgLength;

	logDebug1("iSocket :: %d  | USER_IDE :: %llu | SocketTable[SocketIndex].SocketId Befor AddUser: %d",iSocket,USER_IDE,SocketTable[SocketIndex].SocketId);

	LockThreadMutex(&UserIdTableLock,"AddUser.USER_IDE",USER_IDE);
	logDebug1("We aree deleting first in case of any sequence is already there....");
	DeleteUser( IndexNode, ReqHeader.iSeqNo, USER_IDE, &iSocket);
	//DeleteUser(IndexNode, ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iSeqNo, USER_IDE, &SocketId);
	AddUser(IndexNode,
			((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->iSeqNo,
			SocketTable[SocketIndex].SocketId,
			((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->sExcgId,
			((struct INT_COMMON_REQUEST_HDR *)Ord_Str)->cSegment);
	++NoOfNodes;
	UnLockThreadMutex(&UserIdTableLock,"AddUser.USER_IDE",USER_IDE);


	MsgType = 1;
	Qid = ItsToRmsDir;
	if ((WriteMsgQ( Qid, &Ord_Str,Len,MsgType)!= TRUE))
	{
		perror("\nProcessIncomingPacket: Error in Writing to the Q ItsToRmsDir");
		kill(getpid(),SIGTERM);
	}

	logInfo("WRITEQ REQ TO OMS");

	LockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);
	--TotalThreadsInProgress;
	logDebug1("ProcessIncomingPacket: TotalThreadsinProgress: %d",TotalThreadsInProgress);
	UnLockThreadMutex(&TotalThreadsInProgressLock,"ThreadsInLock.USER_IDE",USER_IDE);

	/***
NOTE: If all the MAX_NO_DYNAMIC_READ_THREADS have been created then the no more packets
will be read from the socket, and this program will go in a suspended mode. Hence if
the total no of busy threads comes down by a certain value then raise a signal.
	 ***/

	logTimestamp("Exit :ProcessIncomingPacket:");
	return;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Waits on the Queue for the MsgType 222, and using the UserId, indexes
//			into the UserId table to get the socket on which the resp is to be 
//			sent.
////////////////////////////////////////////////////////////////////////////////*/
void	*WriteWorkerThread(void *arg)
{
	logTimestamp("Entry :WriteWorkerThread:");
	LONG32	Retval,SocketId,Index,Len,Transcode,ErrorCode=0;
	CHAR	OrderResp[MAX_PACKET_SIZE], localStr[MAX_PACKET_SIZE];
	CHAR	*ModOrderResp;
	SHORT   WriteSM=0;
	struct timeval TimeStampSend;
	struct timeval TimeStampRead;
	int iSeqNo=0;
	ULONG64 USER_IDE = 0;
	struct INT_ERROR_FE_RESP *INT_ERROR_FE_RESP;
	/*************************************
	  int iRecvCounter=0;
	  int iSendCounter=0;
	 *************************************/

	while(1)
	{
		memset(OrderResp,' ',MAX_PACKET_SIZE); 
		//memset(OrderResp,'\0',MAX_PACKET_SIZE); 
		//if ((Retval = ReadMsgQ(RelDirToIts,OrderResp,MAX_PACKET_SIZE,222)) != TRUE)

		logInfo("---------==================WHILE LOOP -> MsgType : %d==============---------",iMsgType);

		if ((Retval = ReadMsgQ(RelDirToIts,OrderResp,MAX_PACKET_SIZE,iMsgType)) != TRUE)
		{
			perror("\nWriteWorkerThread: Error in reading from the Q");
			kill(getpid(),SIGTERM);
		}

		logInfo("READQ RESP FROM OMS");
		Transcode 	= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgCode ;
		Len		= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgLength;
		iSeqNo		= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iSeqNo;
		USER_IDE	= ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId;
		logDebug1("Transcode = %d ",((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgCode);
#ifdef	DBG
		logDebug1("WriteWorkerThread: Received User: %llu |  Tcode:%d | ",USER_IDE,Transcode);
#endif
		switch(Transcode)
		{
			case TC_INT_OE_ERROR_RESP:
			case TC_INT_OM_ERROR_RESP:
			case TC_INT_OC_ERROR_RESP:
			case TC_INT_OE_FREEZE_RESP:
			case TC_INT_ORDER_REJECTION:	
			case TC_INT_CON_DEL_ERR_RESP:	 
			//case TC_INT_RMS_ORD_REJECTION:	//Ashish_blank_resp 
			case TC_BO_OE_ERROR_RESP:
			case TC_BO_OM_ERROR_RESP:
			case TC_BO_OC_ERROR_RESP:
			case TC_BO_OE_FREEZE_RESP:

				ErrorCode = 1;
				logDebug1(" Transcode Received: %d | USER_IDE : %llu | ErrorCode: %d | SeqNo : %d | ErrorMessage :%s: ",Transcode,USER_IDE,ErrorCode,iSeqNo,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
				logDebug1(" trancode and error msg are suppose to get printed ");
				break;

			case TC_INT_LOGON_RSP				:
			case TC_INT_ORDER_ENTRY_RSP			:
			case TC_INT_ORDER_MODIFY_RSP			:
			case TC_INT_ORDER_CANCEL_RSP			:
			case TC_INT_OFF_ORDER_ENTRY_RSP			:
			case TC_INT_OFF_ORDER_MODIFY_RSP		:
			case TC_INT_OFF_ORDER_CANCEL_RSP		:
			case TC_INT_CON_DEL_RESP			:	 
			case TC_INT_SIP_ORD_RES				:
			case TC_INT_SIP_ORD_CANCEL_RES			:
			case TC_INT_SIP_ORD_PAUSE_RES			:
			case TC_INT_SIP_ORD_CONTINUE_RES		:
                        case TC_INT_SIP_ORD_MODIFY_RES                  :
			case TC_INT_SPRD_ORD_ENT_RSP			:
			case TC_INT_SPRD_ORD_MOD_RSP                    :
			case TC_INT_SPRD_ORD_CAN_RSP                    :
			case TC_INT_BO_ORDER_ENTRY_RSP			:
			case TC_INT_GTT_ORDER_ENTRY_RSP                 :
                        case TC_INT_GTT_ORDER_MODIFY_RSP                :
                        case TC_INT_GTT_ORDER_CANCEL_RSP                :

				ErrorCode = 0;
				logDebug1(" Transcode Received: %d | USER_IDE : %llu | ErrorCode: %d | SeqNo : %d",Transcode,USER_IDE,ErrorCode,iSeqNo);
				break;

			case TC_INT_OE_CONF_RESP			:
			case TC_INT_TRADE_RESP				:
			case TC_INT_OM_CONF_RESP 			:
			case TC_INT_OC_CONF_RESP			:
			case TC_INT_SL_ORDER_TRIG_RESP			:
			case TC_INT_SPREAD_OE_CONF_RESP                 :
			case TC_INT_SPREAD_OM_CONF_RESP                 :
			case TC_INT_SPREAD_OC_CONF_RESP                 :
			case TC_BO_OE_CONF_RESP				:
			case TC_BO_OM_CONF_RESP				:
			case TC_BO_OC_CONF_RESP				:	
			case TC_BO_MKT_LMT_CONVT_RESP			:

				logDebug1(" Dropping Pkt For Exchange Confirmation/Rejection Resp :: USER_IDE :: %llu | SeqNo ::%d ",USER_IDE,iSeqNo);
				continue;

			case TC_INT_OE_REJECTION 			:
			case TC_INT_OM_REJECTION			:
			case TC_INT_OC_REJECTION			:
			case TC_INT_RMS_OE_REJECTION			:
			case TC_INT_RMS_OM_REJECTION			:
			case TC_INT_RMS_OC_REJECTION			:
			case TC_INT_SPRD_OE_REJ				:
			case TC_INT_SPRD_OM_REJ				:
			case TC_INT_SPRD_OC_REJ				:
			case TC_INT_RMS_SPRD_OE_REJ			:
			case TC_INT_RMS_SPRD_OM_REJ			: 		
			case TC_INT_RMS_SPRD_OC_REJ			:
			case TC_INT_BO_RMS_OE_REJECTION			:
			case TC_INT_BO_RMS_OM_REJECTION			:
			case TC_INT_BO_RMS_OC_REJECTION			:	
			case TC_INT_BO_OE_REJECTION			:
			case TC_INT_BO_OM_REJECTION			:
			case TC_INT_BO_OC_REJECTION			:
				logDebug2(" This new Internal Order Rejection Message ");
				ErrorCode = 1;
				break;

			default:

				logDebug1(" Invalid Transcode: %d",Transcode);
				continue;
		}
		/***
		  Now that we have the response delete the node corresponding to this user from the
		  list. Note the last argument is passed by reference to get the Socket on which the
		  response is to be sent.
		 ***/
		SocketId = ERROR;
		LockThreadMutex(&UserIdTableLock,"DeleteUser.USER_IDE",USER_IDE);
		//		DeleteUser( IndexNode,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.sExcgId,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.cSegment,USER_IDE,&SocketId);
		DeleteUser(IndexNode, ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iSeqNo, USER_IDE, &SocketId);
		logDebug1(" SocketId Got After Deleting The User: %d | USER_IDE : %llu | SeqNo :%d",SocketId,USER_IDE,iSeqNo);
		if (SocketId == ERROR)
		{
			/***
			  FATAL ERROR... If we are here that means the socket has either been closed or it
			  encountered some error because of which the entry corresponding to all users whose
			  request had come on this socket was cleared.
			 ***/
			UnLockThreadMutex(&UserIdTableLock,"DeleteUser.USER_IDE",USER_IDE);
			logDebug1("WriteWorkerThread: FATAL ERROR UserId not found.USER_IDE :: %llu |  SeqNo :%d",USER_IDE,iSeqNo);
			continue;
		}
		--NoOfNodes;
		UnLockThreadMutex(&UserIdTableLock,"DeleteUser.USER_IDE",USER_IDE);

#ifdef	DBG
		logDebug1("WriteWorkerThread: Deleted the Node Successfully| USER_IDE : %llu | SocketId :%d | SeqNo :%d",USER_IDE,SocketId,iSeqNo);
#endif
		/***
		  Though we have got the socket we still need the mutex corresponding to this socket to for 
		  locking. So loop in the socket table and get the index corresponding to this socket.
		 ***/
		LockThreadMutex(&SocketTableLock,"GetIndexInSocketTable.USER_IDE",USER_IDE);
		logDebug1(" SocketId For Getting The Index: %d | USER_IDE : %llu | SeqNo :%d",SocketId,USER_IDE,iSeqNo);
		if ((Index = GetIndex_In_Socket_Table(SocketId)) == ERROR)
		{
			/***
			  FATAL ERROR... If we are here that means the socket has either been closed or it
			  encountered some error because of which the  socket entry was cleared.
			 ***/
			UnLockThreadMutex(&SocketTableLock,"GetIndexInSocketTable.USER_IDE",USER_IDE);
			logDebug2("WriteWorkerThread: FATAL ERROR SocketId not found");
			logDebug2("WriteWorkerThread: FATAL ERROR in sending the resp to USERID:%llu | SeqNo :%d",USER_IDE,iSeqNo);
			continue;
		}
		UnLockThreadMutex(&SocketTableLock,"GetIndexInSocketTable.USER_IDE",USER_IDE);
		logDebug1(" Index : %d | USER_IDE : %llu | SocketId : %d | SeqNo :%d",Index,USER_IDE,SocketId,iSeqNo);

		/***
		  We have the socket and its mutex.... so lock the socket and send the data.
		 ***/
		Len = ((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iMsgLength;

		switch(Transcode)
		{
			case TC_INT_CON_DEL_RESP                        :
				//sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct CON_TO_DELIVERY_RESPONSE *)OrderResp)->RespHeader.iUserId,0);
				sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct CON_TO_DELIVERY_RESPONSE *)OrderResp)->RespHeader.iSeqNo,0);
				logDebug1(" Sending The Response: %s",localStr); 
				break;
			case TC_INT_CON_DEL_ERR_RESP	:
			case TC_INT_ORDER_REJECTION:	
				//sprintf(localStr,"%d|%d|%s#\n",ErrorCode,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
				sprintf(localStr,"%d|%d|%s|%s#\n",ErrorCode,((struct INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iSeqNo,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorCode);
				logDebug1(" Sending The Response: %s",localStr); 
				break;

			case TC_INT_SPRD_ORD_ENT_RSP		:
			case TC_INT_SPRD_ORD_MOD_RSP		:
			case TC_INT_SPRD_ORD_CAN_RSP		:
				//sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->IntRespHeader.iUserId,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->fOrderNum);
				sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->IntRespHeader.iSeqNo,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->fOrderNum);
				logDebug2(" Sending The Response: %s",localStr);
				logDebug2(" ((struct ORDER_SPREAD_RESPONSE *)OrderResp)->fOrderNum: :%.0lf:",((struct ORDER_SPREAD_RESPONSE *)OrderResp)->fOrderNum);

				break;

			case TC_INT_RMS_SPRD_OE_REJ                     :
			case TC_INT_RMS_SPRD_OM_REJ                     :
			case TC_INT_RMS_SPRD_OC_REJ                     :
			case TC_INT_SPRD_OE_REJ				:
			case TC_INT_SPRD_OM_REJ				:
			case TC_INT_SPRD_OC_REJ				:
				logDebug2("((struct INT_ERROR_FE_RESP *)OrderResp)->sReasonDesc :%s:",((struct ORDER_SPREAD_RESPONSE *)OrderResp)->sReasonDesc);
				//sprintf(localStr,"%d|%d|%s#\n",ErrorCode,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->IntRespHeader.iUserId,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->sReasonDesc);
				sprintf(localStr,"%d|%d|%s#\n",ErrorCode,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->IntRespHeader.iSeqNo,((struct ORDER_SPREAD_RESPONSE *)OrderResp)->sReasonDesc);
				logDebug1("Sending The Response: %s ",localStr);
				break;

				/***			case TC_BO_OE_ERROR_RESP			:
				  case TC_BO_OM_ERROR_RESP			:
				  case TC_BO_OC_ERROR_RESP			:
				  case TC_BO_OE_FREEZE_RESP			:
				  case TC_INT_BO_RMS_OE_REJECTION                 :
				  case TC_INT_BO_RMS_OM_REJECTION                 :
				  case TC_INT_BO_RMS_OC_REJECTION                 :
				  sprintf(localStr,"%d|%d|%s#\n",ErrorCode,((struct BO_ORDER_RESPONSE *)OrderResp)->IntRespHeader.iUserId,((struct BO_ORDER_RESPONSE *)OrderResp)->sReasonDesc);
				  logDebug2("Sending The Response: %s ",localStr);

				  case TC_BO_OE_CONF_RESP                         :
				  case TC_BO_OM_CONF_RESP                         :
				  case TC_BO_OC_CONF_RESP                         :
				  case TC_BO_MKT_LMT_CONVT_RESP			: 
				  sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct BO_ORDER_RESPONSE *)OrderResp)->IntRespHeader.iUserId,((struct BO_ORDER_RESPONSE *)OrderResp)->fOrderNum);
				  logDebug2("Sending The Response: %s ",localStr);
				  logDebug2("fOrderNum :%.0lf",((struct BO_ORDER_RESPONSE *)OrderResp)->fOrderNum);
				 ******/			
			case	TC_INT_SIP_ORD_RES		:
			case	TC_INT_SIP_ORD_CANCEL_RES	:
			case	TC_INT_SIP_ORD_PAUSE_RES	:
			case    TC_INT_SIP_ORD_CONTINUE_RES	:
                        case    TC_INT_SIP_ORD_MODIFY_RES       :

				sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct SIP_ORD_RESPONSE *)OrderResp)->IntRespHeader.iSeqNo,((struct SIP_ORD_RESPONSE *)OrderResp)->fOrderNum);
				logDebug1("Sending The Response(SIP): %s ",localStr);
				break;

			default:
				/***
				  if (ErrorCode == 1 )
				  {
				  logDebug("\n Error Message: %s",((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
				  sprintf(localStr,"%d|%d|%s#\n",ErrorCode,((struct  INT_ERROR_FE_RESP *)OrderResp)->IntRespHeader.iUserId,((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
				  logDebug("\n Sending The Response: %s",localStr);
				  }
				  else 
				 **/
				if (ErrorCode == 1 )
				{
//					logDebug2("Error Message: %s",((struct ORDER_RESPONSE *)OrderResp)->sReasonDesc);
					logDebug2("Error Message: %s",((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorMsg);
					logDebug2("Error Message: %s",((struct INT_ERROR_FE_RESP *)OrderResp)->sErrorCode);
					//sprintf(localStr,"%d|%d|%s#\n",ErrorCode,((struct  ORDER_RESPONSE *)OrderResp)->IntRespHeader.iUserId,((struct ORDER_RESPONSE *)OrderResp)->sReasonDesc);
					sprintf(localStr,"%d|%d|%s|%s|%.0lf#\n",ErrorCode,((struct  ORDER_RESPONSE *)OrderResp)->IntRespHeader.iSeqNo,((struct ORDER_RESPONSE *)OrderResp)->sReasonDesc,((struct ORDER_RESPONSE *)OrderResp)->sErrorCode,((struct ORDER_RESPONSE *)OrderResp)->fOrderNum);
					logDebug1(" Sending The Response: %s",localStr);
				}
				else
				{
					logDebug2(" Error Message: %.0lf",((struct ORDER_RESPONSE *)OrderResp)->fOrderNum);
					//sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct ORDER_RESPONSE *)OrderResp)->IntRespHeader.iUserId,((struct ORDER_RESPONSE *)OrderResp)->fOrderNum);
					sprintf(localStr,"%d|%d|%.0lf#\n",ErrorCode,((struct ORDER_RESPONSE *)OrderResp)->IntRespHeader.iSeqNo,((struct ORDER_RESPONSE *)OrderResp)->fOrderNum);
					logDebug2(" Sending The Response: %s",localStr);
				}
				logDebug1(" Sending The Response: %s",localStr);
				break;
		}

		/* Added Upto Here */
		LockThreadMutex(&SocketTable[Index].Mutex,"SocketTable[].USER_IDE",USER_IDE);
		logDebug3 (" Lockd the Mutex" ) ;
		logDebug3(" SocketId: %d |  USER_IDE : %d | SeqNo : %d ",SocketTable[Index].SocketId,USER_IDE,iSeqNo);
		Retval = Send(SocketTable[Index].SocketId,localStr,&Len,0,USER_IDE);
		if (Retval < 0)
		{
			/**
			  Some FATAL ERROR again, due to which the user will not get the Error Resp packet ...
			  most probably timeout and die.
			 **/
			logFatal("Failed To Send The Data  %s to socket id %d",localStr ,SocketTable[Index].SocketId);
			UnLockThreadMutex(&SocketTable[Index].Mutex,"SocketTable[].,USER_IDE",USER_IDE);
			CleanResources(Index,'D');
			/*			return;*/
			logInfo("  Continue...");
			continue;
		}
		logTimestamp("WebServOrder Send :%d: :%s:",SocketTable[Index].SocketId,localStr);
		UnLockThreadMutex(&SocketTable[Index].Mutex,"SocketTable[].USER_IDE",USER_IDE);
		gettimeofday(&TimeStampSend,NULL);
		logDebug2("WriteWorkeThread:Socket | %d | USER_IDE | %llu |iSeqNo | %d | sec |  %ld | usec |  %ld | ",SocketId,USER_IDE,iSeqNo,TimeStampSend.tv_sec,TimeStampSend.tv_usec);
#ifdef	DBG
		logDebug2("WriteWorkerThread: Sent the data to the User successfully");	
#endif
		/**		CleanResources(Index,'E');  ************* Alok Added for testing ************/

	}
	return;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments: Indexes into the SocketTable and returns the Index where we get a match.
//NOTE:: FOR ALLOWING THE LOGON OF THE SAME USERID FROM 2 DIFF PLACES, SIMILAR TO 
//RELAY THIS FUNCTION NEEDS TO BE CHANGED.
////////////////////////////////////////////////////////////////////////////////*/
BOOL    GetIndex_In_Socket_Table(LONG32 Id)
{
	logTimestamp("Entry :GetIndex_In_Socket_Table:");
	SHORT  i;

	for(i=0;i<MAX_NO_OF_SOCKETS;i++)
	{
		if (SocketTable[i].SocketId == Id)
			return i;
	}
	return ERROR;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Returns back the Index of the Slot which is empty.
////////////////////////////////////////////////////////////////////////////////*/
BOOL	GetSlot_In_Socket_Table()
{
	logTimestamp("Entry :GetSlot_In_Socket_Table:");
	SHORT	i;

	for(i=0;i<MAX_NO_OF_SOCKETS;i++)
	{
		if (SocketTable[i].SocketId == UNUSED || SocketTable[i].SocketId == -1)
			return i;
	}
	return ERROR;
}

/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Whenver the user connects the first message expected from him is the
//			logon message. On receiving this message the user will be validated
//			for a valid userid & passwd.
//				Failure in sending a correct UserId/Passwd will result in termination
//			of the connectivity.
//VarUsage: Index is the subscript of the socket to be clearedin the Socket_Table.
////////////////////////////////////////////////////////////////////////////////*/
BOOL	ValidateUser()
{
	logTimestamp("Entry :ValidateUser:");
	/***
	  Read the UserId/Passwd from the ini file and authenticate the user. If its a valid
	  user then mark it as a _VALID_USER_ (default is _INVALID_USER).
	  If a packet is received from the other end without a proper login (i.e. one
	  whose status is still in the _INVALID_USER state) then the packet will be dropped
	  along with the connectivity since its a malicious user trying trying to connect.
	 ***/
	return TRUE;
}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Clears the entry from UserIdLookUpTable, SocketLookUpTable and the 
//			ActiveSocketSet.
//				This function will be called only when something has gone wrong 
//			with the socket, due to which all the users who have received the
//			requests on this socket will be deleted too.
//VarUsage: Index is the subscript of the socket to be clearedin the Socket_Table.
////////////////////////////////////////////////////////////////////////////////*/
void	CleanResources(LONG32 Index, CHAR Point)
{
	logTimestamp("Entry :CleanResources:");
	LockThreadMutex(&UserIdTableLock,"DeleteUser.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
	/***
	  DeleteUser( IndexNode,
	  SocketTable[Index].SocketId,
	  NULL,
	  NULL,
	  SOCKET_ID,
	  NULL);*****/
	DeleteUser( IndexNode, SocketTable[Index].SocketId, SOCKET_ID, NULL);


	UnLockThreadMutex(&UserIdTableLock,"DeleteUser.SocketTable[Index].SocketId",SocketTable[Index].SocketId);



	logDebug1(" HEY NITISH in CleanResources Index is :%d: SocketTable[Index].SocketId:%d ,Point:%c:",Index,SocketTable[Index].SocketId,Point);
	/****
	  if (SocketTable[Index].SocketId != 0)
	  {
	  close(SocketTable[Index].SocketId);
	  shutdown(SocketTable[Index].SocketId,2);
	  perror("Shutdown Socket 2 : ");
	  usleep(100000);
	  }***/

	LockThreadMutex(&ActiveSocketLock,"FDCLR.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
	FD_CLR(SocketTable[Index].SocketId,&ActiveSocketSet);
	UnLockThreadMutex(&ActiveSocketLock,"FDCLR.SocketTable[Index].SocketId",SocketTable[Index].SocketId);


	LockThreadMutex(&SocketTableLock,"pthread_mutex_init.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
	SocketTable[Index].SocketId = UNUSED;
	SocketTable[Index].UserStatus = UNUSED;

	logDebug1(" in CLEANRESOURCE SocketTable[%d].SocketId :%d:",Index,SocketTable[Index].SocketId);
	if (pthread_mutex_init (&SocketTable[Index].Mutex,NULL) != 0)
		kill(getpid(),SIGTERM);

	UnLockThreadMutex(&SocketTableLock,"pthread_mutex_init.SocketTable[Index].SocketId",SocketTable[Index].SocketId);
}


/*////////////////////////////////////////////////////////////////////////////
//Comments:	UnLocks the mutex which has been locked.
//
//Var Usage:mutex - The mutex to be unlocked.
////////////////////////////////////////////////////////////////////////////*/
void UnLockThreadMutex ( pthread_mutex_t * mutex,CHAR *Position , int Identifier)
{
	logTimestamp("Entry :UnLockThreadMutex:");
	struct timeval TimeStampRead1;
	struct timeval TimeStampRead2;
	if(pthread_mutex_unlock(mutex) != 0)
	{
#ifdef     DBG
		logDebug1("LockThreadMutex: Error in UnLocking Mutex ");
#endif
		kill(getpid(),SIGTERM);
	}
}


/*////////////////////////////////////////////////////////////////////////////
//Comments:	Locks the mutex and restricts the access to the resource being 
//			locked till it is not unlocked by the calling function itself.
//
//Var Usage:mutex - The mutex to be locked.
////////////////////////////////////////////////////////////////////////////*/
void LockThreadMutex ( pthread_mutex_t * mutex,CHAR *Position,int Identifier)
{
	logTimestamp("Entry :LockThreadMutex:");
	struct timeval TimeStampRead1;
	struct timeval TimeStampRead2;
	if(pthread_mutex_lock(mutex) != 0)
	{
#ifdef     DBG
		logDebug1("LockThreadMutex: Error in Locking Mutex ");
#endif
		kill(getpid(),SIGTERM);
	}
}

/*////////////////////////////////////////////////////////////////////////////
//Comments:	Send doesnt guarantee that all the data in the buffer will
//			be sent in a single call to send, loop around checking the return 
//			value till all the bytes are sent.
//
//Var Usage:Socketfd- Socket Descriptor to which data will be sent.
//			SendData- Data to be sent.
//			SendLen - Len of the data to be sent.
//			Flags	- If any.
////////////////////////////////////////////////////////////////////////////*/
BOOL    Send(LONG32 Socketfd,CHAR *SendData,LONG32 *SendLen,SHORT Flags,LONG32	iUserID)
{
	logTimestamp("Entry :Send:");
	int TotalLen=0;
	int BytesLeft = *SendLen;
	int Bytes;

	while(TotalLen < *SendLen)
	{
		logDebug1(" SocketId: %d",Socketfd);
		if ((Bytes = send(Socketfd, SendData+TotalLen, BytesLeft, Flags)) <=0)
		{
			perror("\nSend: Error is");
			return Bytes;
		}
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	logTimestamp("SERVICE SEND ORD %d %d ",Socketfd,iUserID);
	/**
	  Return TotalLen actually sent here which will be same as SendLen unless theres and error in
	  which partial data was sent.
	 **/
	*SendLen = TotalLen;
	return TRUE;          /* return -1 on failure, 0 on success*/
}

/*////////////////////////////////////////////////////////////////////////////
//Comments:	Recv doesnt guarantee that all the data received in the buffer in
//			a single go will be of the len specified. Hence loop aroung till
//			the specified no of bytes are not received.
//
//Var Usage:Socketfd- Socket Descriptor from which data is read.
//			RecvData- Data to be read.
//			RecvLen - Len of the data to be read.
//			Flags	- If any.
////////////////////////////////////////////////////////////////////////////*/
BOOL    Recv(LONG32 Socketfd,CHAR *RecvData,LONG32 *RecvLen,SHORT Flags,LONG32	iUserID)
{
	logTimestamp("Entry :Recv:");
	int TotalLen=0;
	int BytesLeft = *RecvLen;
	int Bytes;
	int iCnt= 0 ;
	while(TotalLen < *RecvLen)
	{
		if ((Bytes = recv(Socketfd, RecvData+TotalLen, BytesLeft, Flags)) <= 0)
		{
			perror("\nRecv: Error is");
			logFatal("Number of Byets Rec Error :%d:",Bytes);	
			return Bytes;
		}
		logInfo("Number of Byets Rec Success :%d: ",Bytes);	
		TotalLen += Bytes;
		BytesLeft -= Bytes;
	}
	logTimestamp("SERVICE RECV ORD %d %d",Socketfd,iUserID);

	/**
	  Return TotalLen actually sent here which will be same as RecvLen unless theres and error in
	  which partial data was sent.
	 **/
	printf("\n ");	
	for(iCnt = 0;iCnt< TotalLen ; iCnt++)
	{
		printf("%02X ",RecvData[iCnt]);	
	}
	

	*RecvLen = TotalLen;
	logDebug1(" total no of bytes recieved are :%d",TotalLen);
	return TRUE;          /* return -1 on failure, 0 on success*/
}


/*/////////////////////////////////////////////////////////////////////////////////
//Comments:	Adds a node to the list of the Internet users who have placed orders 
//			and are existing in the loop.
/////////////////////////////////////////////////////////////////////////////////*/
void AddUser (UserId_Lookup_Table *Curr,LONG32 UserId,LONG32 SocketId,CHAR *ExchId,CHAR Segment)
{
	logTimestamp("Entry :AddUser:");
	if (Curr == NULL)
	{
		IndexNode = (struct UserId_Lookup_Table *)malloc (sizeof(UserId_Lookup_Table));
		IndexNode->UserId	= UserId;
		IndexNode->SocketId	= SocketId;
		logDebug1(" IndexNode->SocketId: %d",IndexNode->SocketId);
		IndexNode->Segment	= Segment;
		memset(&(IndexNode->Exch),' ',EXCHANGE_LEN);
		memset(&(IndexNode->Exch),ExchId,EXCHANGE_LEN);
		IndexNode->Next		= NULL;
		return;
	}

	while(Curr->Next != NULL)
		Curr = Curr->Next;

	Curr->Next = (struct UserId_Lookup_Table *)malloc (sizeof(UserId_Lookup_Table));
	Curr->Next->UserId	= UserId;
	Curr->Next->SocketId= SocketId;
	Curr->Next->Segment	= Segment;
	memset(&(Curr->Next->Exch),' ',EXCHANGE_LEN);
	memset(&(Curr->Next->Exch),ExchId,EXCHANGE_LEN);
	Curr->Next->Next	= NULL;

}


/*////////////////////////////////////////////////////////////////////////////////
//Comments:	Deletes the user entry from the list when, the response is sent back
//			or when something goes haywire.
//NOTE: ONLY THE USERID IS BEING USED CURRENTLY FOR DELETING AN ENTRY FROM THE 
//LIST OF USERS WHO HAVE PLACED ORDERS. BUT IN FUTURE THE EXCHID AND THE SEGMENT
//MAY NEED TO BE COMPARED IF ITS STARTS SUPPORTING MULTIPLE LOGON FACILITY.
////////////////////////////////////////////////////////////////////////////////*/

/*****
  void DeleteUser (UserId_Lookup_Table *Curr,LONG32 Id,CHAR *ExchId, CHAR Segment,SHORT MODE,LONG32 *SocketId)
  {
  logTimestamp("Entry :fSendUDPMsg:");
  UserId_Lookup_Table *tmpnode;
  int counter=0,count=0;

 ***
NOTE: This is a very imp check. Do not delete this.
The program may stop/crash at some point of time without delivering response packets
which may have been there in the reverse Q. If this happens then when the program
starts again the WriteWorkerThread will attempt to read from the Q, which will 
result a call to this function which will try to loop and find the userid in the
link list and will again *CRASH*.
 ***
 if (Curr == NULL)
 return;


 logDebug("\n DeleteUser:NoOfNodes :%d",NoOfNodes);
 if (MODE == SOCKET_ID)
 {
 logDebug("\nDeleteUser: Deleting node with socketid:%d",Id);
 logDebug("\n Curr->SocketId %d User %d Id %d",Curr->SocketId,Curr->UserId,Id);
 if (Curr->SocketId == Id)
 {
 IndexNode = Curr->Next;
 logDebug("\nDeleteUser: NODE deleted...");
 free(Curr);
 return;
 }

 if (Curr->Next == NULL)
 return;

 while(Curr->Next->Next != NULL)
 {
 logDebug("\n Curr->Next->SocketId %d User %d",Curr->Next->SocketId,Curr->Next->UserId);
 if (Curr->Next->SocketId == Id)
 {
 tmpnode	= Curr->Next;
 Curr->Next = Curr->Next->Next;
 free(tmpnode);
 logDebug("\n In If Counter1:%d",counter++);
 }
 else
 {
 Curr = Curr->Next;
 logDebug("\n In Else Counter2:%d",count++);
 }
 }

 if (Curr->Next->SocketId == Id)
 {		
 free(Curr->Next);
 Curr->Next = NULL;
 }
 }
 else
 {
 logDebug("\n Deleting node with userid:%d",Id);
 if (Curr->UserId == Id)
 {
 *SocketId = Curr->SocketId;
 logDebug("\n SocketId : %d,Curr->SocketId : %d",*SocketId,Curr->SocketId);
 IndexNode = Curr->Next;
 free(Curr);
 return;
 }

 if (Curr->Next == NULL)
return;

while(Curr->Next->Next != NULL)
{
	if (Curr->Next->UserId == Id)
	{
		*SocketId = Curr->Next->SocketId;
		logDebug("\n SocketId: %d,Curr->Next->SocketId : %d",*SocketId,Curr->Next->SocketId );
		tmpnode	= Curr->Next;
		Curr->Next = Curr->Next->Next;
		free(tmpnode);
		return;
	}
	Curr = Curr->Next;
}

if (Curr->Next->UserId == Id)
{		
	*SocketId = Curr->Next->SocketId;
	logDebug("\n SocketId: %d,Curr->Next->SocketId : %d",*SocketId,Curr->Next->SocketId );
	free(Curr->Next);
	Curr->Next = NULL;
}
}
}*****/
//void DeleteUser (UserId_Lookup_Table *Curr,LONG32 Id,SHORT MODE,LONG32 *SocketId)
void DeleteUser (UserId_Lookup_Table *Curr,LONG32 Id,ULONG64 MODE,LONG32 *SocketId)
{
	logTimestamp("Entry :DeleteUser:");
	UserId_Lookup_Table *tmpnode;
	int counter=0,count=0;

	/***
NOTE: This is a very imp check. Do not delete this.
The program may stop/crash at some point of time without delivering response packets
which may have been there in the reverse Q. If this happens then when the program
starts again the WriteWorkerThread will attempt to read from the Q, which will
result a call to this function which will try to loop and find the userid in the
link list and will again *CRASH*.
	 ***/
	if (Curr == NULL)
		return;

	logDebug1("DU: NoOfNodes :%d",NoOfNodes);
	logDebug1("DU: MODE :%llu",MODE);
	logDebug1("DU: SOCKET_ID :%d",SOCKET_ID);
	if (MODE == SOCKET_ID)
	{
		logDebug1("DU: User: %d Socket: %d Id: %d", Curr->UserId, Curr->SocketId, Id);
		//logTID(" Curr->SocketId %d User %d Id %d",Curr->SocketId,Curr->UserId,Id);
		if (Curr->SocketId == Id)
		{
			IndexNode = Curr->Next;
			logDebug1(" DU: NODE deleted...");
			free(Curr);
			return;
			/***
			  Do not return from here after deleting the first node since some more
			  userids may have sent on the same socket, so all the nodes on this
			  socket have to be deleted.
			 ***/
		}

		if (Curr->Next == NULL)
			return;

		while(Curr->Next->Next != NULL)
		{
			logDebug2(" DU: Socket: %d User: %d", Curr->Next->SocketId, Curr->Next->UserId);
			if (Curr->Next->SocketId == Id)
			{
				tmpnode = Curr->Next;
				Curr->Next = Curr->Next->Next;
				free(tmpnode);
				logDebug2(" In If Counter1:%d",counter++);
			}
			else
			{
				Curr = Curr->Next;
				logDebug2(" In Else Counter2:%d",count++);
			}
		}

		if (Curr->Next->SocketId == Id)
		{
			free(Curr->Next);
			Curr->Next = NULL;
		}
	}
	else
	{
		logDebug2("DU: Deleting node with userid: %d",Id);
		if (Curr->UserId == Id)
		{
			logDebug2("SOCKETID: %d",Curr->SocketId);
			*SocketId = Curr->SocketId;
			logDebug2(" DU: Deleting1 SocketId: %d Curr->SocketId: %d", *SocketId, Curr->SocketId);
			IndexNode = Curr->Next;
			free(Curr);
			return;
		}

		if (Curr->Next == NULL)
			return;

		while(Curr->Next->Next != NULL)
		{
			if (Curr->Next->UserId == Id)
			{
				*SocketId = Curr->Next->SocketId;
				logDebug2(" DU: Deleting2 SocketId: %d Curr->Next->SocketId: %d", *SocketId, Curr->Next->SocketId );
				tmpnode = Curr->Next;
				Curr->Next = Curr->Next->Next;
				free(tmpnode);
				return;
			}
			Curr = Curr->Next;
		}

		if (Curr->Next->UserId == Id)
		{
			*SocketId = Curr->Next->SocketId;
			logDebug2("DU: Deleting3 SocketId: %d Curr->Next->SocketId: %d", *SocketId, Curr->Next->SocketId );
			free(Curr->Next);
			Curr->Next = NULL;
		}
	}
	logTimestamp("Exit :DeleteUser:");
}

LONG32 GetMaxSocket(LONG32 MasterSocket,LONG32 DummyPipe)
{
	logTimestamp("Entry :GetMaxSocket:");
	LONG32 Index;
	LONG32 MaxSoc = MasterSocket;

	LockThreadMutex(&SocketTableLock,"GetMaxSocket",0);
	for (Index = 0 ; Index < MAX_NO_OF_SOCKETS ; Index ++)
	{
		if((MaxSoc < SocketTable[Index].SocketId) && (SocketTable[Index].SocketId != UNUSED))
		{
			MaxSoc = SocketTable[Index].SocketId;
			logDebug2("ALOK PRINTING GetMaxSocket: SocketTable[%d].SocketId :%d:",Index,SocketTable[Index].SocketId);
			logDebug2("GetMaxSocket: SocketTable[%d].SocketId :%d:",Index,SocketTable[Index].SocketId);
			break;
		}
	}
	UnLockThreadMutex(&SocketTableLock,"GetMaxSocket",0);
	if (DummyPipe > MaxSoc)
	{
		MaxSoc = DummyPipe;
	}
	logDebug1(" Hey MAX SOCK is : %d",MaxSoc);
	return (MaxSoc);
}



BOOL fSendUDPMsg()
{
	logTimestamp("Entry :fSendUDPMsg:");

	LONG32  iOptval = 1;
	LONG32  iVal,iSockfdUdp;
	CHAR	cMsgBuf[SEND_MSG_LEN];
	struct  sockaddr_in     pCli_addr;
	memset(&cMsgBuf,'\0',SEND_MSG_LEN);	
	logDebug2("sIpAddr :%s:",sIpAddr);
	logDebug2("iUDPport :%d:",iUDPport);

	if((iSockfdUdp = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		perror("Server can't open udp socket");
		return FALSE;
	}
	pCli_addr.sin_family         = AF_INET;
	pCli_addr.sin_addr.s_addr    = inet_addr(sIpAddr);
	pCli_addr.sin_port           = htons(iUDPport);

	strcpy(cMsgBuf,"init#");

	logDebug2("iUDPport core  123");
	logDebug2("cMsgBuf :%s:",cMsgBuf);
	logDebug2("len cMsgBuf :%d:",strlen(cMsgBuf));


	if(sendto(iSockfdUdp,cMsgBuf,strlen(cMsgBuf),0,(struct sockaddr *) &pCli_addr,sizeof( struct sockaddr))< 0)
	{
		perror("Server : Error in Sending");
		return FALSE;
	}
	close(iSockfdUdp);

	logTimestamp("Exit :fSendUDPMsg:");

}	
