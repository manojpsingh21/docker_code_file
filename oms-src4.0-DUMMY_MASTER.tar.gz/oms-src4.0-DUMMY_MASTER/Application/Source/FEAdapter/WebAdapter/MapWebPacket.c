#include "IPCS.h"
#include<stdio.h>
#include <memory.h>
#include <string.h>
#include<stdlib.h>

#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/msg.h>
#include <sys/errno.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <ctype.h>
#include <errno.h>

#include <netinet/in.h>		
//#include <Common.h>
//#include <Inquiry.h>
//#include "MrgPlsOrderStructs.h"
//#define ITS_TIME_OUT 20000
//#define PORT 4342
//#define PACKET_SIZE 200
//#define     TWIDDLE(A)      Twiddle ((char *) &A, sizeof(A));

//BOOL Map_MrgPlsOrd_Req(char *,struct MRGPLS_ORDER_REQUEST  *);
BOOL 	Map_Ord_Req(char * ,struct ORDER_REQUEST *);
BOOL 	Map_C2D_Req(char * ,struct CON_TO_DELIVERY_REQUEST *);
BOOL	Map_SIP_Ord_Req(char *,struct SIP_ORD_REQUEST *);
BOOL    Map_CO_Ord_Req(char *,struct CO_ORDER_REQUEST *);
BOOL    Map_BO_Ord_Req(char *,struct BO_ORDER_REQUEST *);
BOOL    Map_SPRD_Req(char *,struct ORDER_SPREAD_REQUEST *);
BOOL    Map_GTT_Ord_Req(char * ,struct FOREVER_ORDER_REQUEST *);
//int 	createSocket	();
//int 	SendPacket	(int ,char *);
//char* 	ReceivePacket	(int );




BOOL  Map_Ord_Req(char *requestDetails ,struct ORDER_REQUEST  *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct ORDER_REQUEST ));

	logDebug2("Packet recieved:%s",requestDetails);

	while(1)
	{
		/**	logDebug2 ("\n\t Value of i is : %d " , i) ;***/
		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);
		/*****
		  logDebug2("\n Counter In Map_1LOrd_Req :: %d ",i);
		  logDebug2("\n temp_store :: %s ",temp_store);
		 ******/

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" iSeqNo	::	%d ",ord_req->ReqHeader.iSeqNo);

				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST );
				logDebug2(" iSeqNo :: %d ,The MsgLength is %d",ord_req->ReqHeader.iSeqNo, ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2(" temp_store :%s: ord_req->ReqHeader.iMsgCode :%d:",temp_store,ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.ExcgId :%s",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%llu",&ord_req->ReqHeader.iUserId);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.UserId :%llu",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("SeqNo :: %d , ord_req->SourceFlag : %c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSource);
				break;			
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("SeqNo :: %d ,ord_req->ReqHeader.Segment :%c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSegment);
				break;
			case 8:
				memset( ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is SecId :%.12s:",ord_req->ReqHeader.iSeqNo, ord_req->sSecurityId);
				break;
			case 9:
				logDebug2("this is entityId ");
				memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is EntityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sEntityId);
				break;
			case 10:
				logDebug2("this is ClientId ");
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is ClientId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sClientId);
				break;
			case 11:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cProductId);
				logDebug2("SeqNo :: %d , Product Id is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProductId);
				break;
			case 12:
				//memcpy(ord_req->cBuyOrSell,temp_store,strlen(temp_store));
				sscanf(temp_store,"%c",&ord_req->cBuyOrSell);
				logDebug2("SeqNo :: %d , ord_req->BuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->cBuyOrSell);
				break;
			case 13:
				ord_req->iOrderType = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iOrderType :%d:",temp_store,ord_req->iOrderType);
				break;
			case 14:
				ord_req->iOrderValidity = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iOrderValidity:%d:",temp_store,ord_req->iOrderValidity);
				break;

			case 15:
				sscanf(temp_store,"%d",&ord_req->iDiscQty);
				logDebug2("SeqNo :: %d , ord_req->DiscQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iDiscQty);
				break;
			case 16:
				sscanf(temp_store,"%d",&ord_req->iDiscQtyRem);
				logDebug2("SeqNo :: %d , ord_req->DiscQtyRemaining : %d",ord_req->ReqHeader.iSeqNo,ord_req->iDiscQtyRem);
				break;
			case 17:
				sscanf(temp_store,"%d",&ord_req->iTotalQtyRem);
				logDebug2("SeqNo :: %d , ord_req->TotalQtyRemaining : %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalQtyRem);
				break;
			case 18:
				sscanf(temp_store,"%d",&ord_req->iTotalQty);
				logDebug2("SeqNo :: %d , ord_req->TotalQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalQty);
				break;

			case 19:
				sscanf(temp_store,"%d",&ord_req->iTotalTradedQty);
				logDebug2("SeqNo :: %d , ord_req->iTotalTradedQty: %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalTradedQty);
				break;	

			case 20:
				sscanf(temp_store,"%d",&ord_req->iMinFillQty);
				logDebug2("SeqNo :: %d , ord_req->MinFillQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iMinFillQty);
				break;

			case 21:
				sscanf(temp_store,"%lf",&ord_req->fPrice);
				logDebug2("SeqNo :: %d , ord_req->Price : %lf",ord_req->ReqHeader.iSeqNo,ord_req->fPrice);
				break;

			case 22:
				sscanf(temp_store,"%lf",&ord_req->fTriggerPrice);
				logDebug2("SeqNo :: %d , ord_req->TriggerPrice : %lf",ord_req->ReqHeader.iSeqNo,ord_req->fTriggerPrice);
				break;

			case 23:
				sscanf(temp_store,"%lf",&ord_req->fOrderNum);
				logDebug2("SeqNo :: %d , ord_req->OrderNum %lf",ord_req->ReqHeader.iSeqNo,ord_req->fOrderNum);
				break;

			case 24:
				logDebug2("this is SerialNum ");
				sscanf(temp_store,"%d",&ord_req->iSerialNum);
				ord_req->iSerialNum = atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->SerialNum : %d",ord_req->ReqHeader.iSeqNo,ord_req->iSerialNum);
				break;
			case 25:

				sscanf(temp_store,"%c",&ord_req->cHandleInst );
				//                        	sscanf(temp_store,"0" );
				logDebug2(" CTD HandlInst = [%c]",ord_req->cHandleInst );
				break;

			case 26:
				ord_req->fAlgoOrderNo = atof(temp_store);	
				logDebug2(" SeqNo :: %d , ord_req->fAlgoOrderNo :%lf:",ord_req->ReqHeader.iSeqNo,ord_req->fAlgoOrderNo);
				break;
			case 27:
				ord_req->iStratergyId= atoi(temp_store);	
				logDebug2(" SeqNo :: %d , ord_req->iStratergyId:%d",ord_req->ReqHeader.iSeqNo,ord_req->iStratergyId);
				break;

			case 28:
				sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
				logDebug2("SeqNo :: %d , ord_req->cOffMarketFlg : %c",ord_req->ReqHeader.iSeqNo,ord_req->cOffMarketFlg);
				break;

			case 29:
				//memcpy(ord_req->cProCli,temp_store,strlen(temp_store));
				sscanf(temp_store,"%c",&ord_req->cProCli);
				logDebug2("SeqNo :: %d ,ord_req->cProCli  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProCli );
				break;

			case 30:
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("SeqNo :: %d ,ord_req->cUserType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cUserType);
				break;

			case 31:
				memset(ord_req->sRemarks,'\0',REMARKS_LEN);
				memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
				logDebug2("SeqNo :: %d , ord_req->Remarks : %s",ord_req->ReqHeader.iSeqNo,ord_req->sRemarks);
				break;

			case 32:
				ord_req->iMktType = atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->iMktType :%d:",ord_req->ReqHeader.iSeqNo,ord_req->iMktType);
				break;

			case 33:
				ord_req->iAuctionNum= atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->iAuctionNum:%d:",ord_req->ReqHeader.iSeqNo,ord_req->iAuctionNum);
				break;
			
			case 34:
                                sscanf(temp_store,"%s",&ord_req->sGoodTillDaysDate);
                                logDebug2("SeqNo :: %d ,ord_req->sGoodTillDaysDate :%s",ord_req->ReqHeader.iSeqNo,ord_req->sGoodTillDaysDate);
                                break;

			case 35:
                                sscanf(temp_store,"%c",&ord_req->cMarkProFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cMarkProFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cMarkProFlag);
                                break;
					
			case 36:
				sscanf(temp_store,"%lf",&ord_req->fMarkProVal);
                                logDebug2("SeqNo :: %d , ord_req->fMarkProVal %lf",ord_req->ReqHeader.iSeqNo,ord_req->fMarkProVal);
                                break;
			
			case 37:
				sscanf(temp_store,"%c",&ord_req->cParticipantType);
                                logDebug2("SeqNo :: %d ,ord_req->cParticipantType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cParticipantType);
                                break;
				
			case 38:
				memset(ord_req->sSettlor, '\0', SETTLOR_LEN);
                                if(!strcmp(temp_store,"X"))
        			{
			                strncpy(ord_req->sSettlor,"",SETTLOR_LEN);
			        }
			        else
			        {
					memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
			        }
                                logDebug2("SeqNo :: %d ,ord_req->sSettlor = %s",ord_req->ReqHeader.iSeqNo, ord_req->sSettlor);
                                break;
			
			case 39:
				sscanf(temp_store,"%c",&ord_req->cGTCFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cGTCFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cGTCFlag);
                                break;	
			
			case 40:
                                sscanf(temp_store,"%c",&ord_req->cEncashFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cEncashFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cEncashFlag);
                                break;
									
			case 41:
                                sscanf(temp_store,"%d",&ord_req->iGrpId);
                                logDebug2("SeqNo :: %d ,ord_req->iGrpId :%d",ord_req->ReqHeader.iSeqNo,ord_req->iGrpId);
                                break;
			case 42:
				memset(ord_req->sPlatform, '\0',PLATFORM_LEN);
				memcpy(ord_req->sPlatform,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->sPlatform :%s",ord_req->ReqHeader.iSeqNo,ord_req->sPlatform);
                                break;
			case 43:
				memset(ord_req->sChannel, '\0', CHANNEL_LEN);
				memcpy(ord_req->sChannel,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->Channel:%s",ord_req->ReqHeader.iSeqNo,ord_req->sChannel);
                                break;
			default	:
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;
		}
		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);
	}   
	/**free(arr);***/
/*
	logDebug2("^^^^^^^^^^^^^");
	ord_req->cMarkProFlag = NO;
	logDebug2("ord_req->cMarkProFlag = %c",ord_req->cMarkProFlag);
	ord_req->fMarkProVal = 0.0;
	logDebug2("ord_req->fMarkProVal = %f",ord_req->fMarkProVal);
	ord_req->cParticipantType = PARTICI_BROKER;
	logDebug2("ord_req->cParticipantType = %c",ord_req->cParticipantType);
	strncpy(ord_req->sSettlor,NOT_AVAILABLE,SETTLOR_LEN);
	logDebug2("ord_req->sSettlor = %s",ord_req->sSettlor);
	ord_req->cGTCFlag = NO;
	logDebug2("ord_req->cGTCFlag = %c",ord_req->cGTCFlag);
	ord_req->cEncashFlag = NO;
	logDebug2("ord_req->cEncashFlag = %c",ord_req->cEncashFlag);
	strncpy(ord_req->sPanID,"ABCDE1234F",INT_PAN_LEN);
	logDebug2("ord_req->sPanID = %s",ord_req->sPanID); */

	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	//ord_req->AuctionNum  = 0 ;
	return TRUE;

}



BOOL  Map_C2D_Req(char *requestDetails ,struct CON_TO_DELIVERY_REQUEST *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct CON_TO_DELIVERY_REQUEST));

	logDebug2("Packet recieved:%s",requestDetails);

	while(1)
	{
		/**	logDebug2 ("\n\t Value of i is : %d " , i) ;***/
		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);
		/*****
		  logDebug2("\n Counter In Map_1LOrd_Req :: %d ",i);
		  logDebug2("\n temp_store :: %s ",temp_store);
		 ******/

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" iSeqNo	::	%d ",ord_req->ReqHeader.iSeqNo);

				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct CON_TO_DELIVERY_REQUEST );
				logDebug2(" iSeqNo :: %d ,The MsgLength is %d",ord_req->ReqHeader.iSeqNo, ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2(" temp_store :%s: ord_req->ReqHeader.iMsgCode :%d:",temp_store,ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.ExcgId :%s",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%llu",&ord_req->ReqHeader.iUserId);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.UserId :%llu",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("SeqNo :: %d , ord_req->SourceFlag : %c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSource);
				break;			
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("SeqNo :: %d ,ord_req->ReqHeader.Segment :%c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSegment);
				break;
			case 8:
				memset( ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is SecId :%.12s:",ord_req->ReqHeader.iSeqNo, ord_req->sSecurityId);
				break;
			case 9:
				logDebug2("this is entityId ");
				memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is EntityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sEntityId);
				break;
			case 10:
				logDebug2("this is ClientId ");
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is ClientId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sClientId);
				break;
			case 11:
				//memcpy(ord_req->cBuyOrSell,temp_store,strlen(temp_store));
				sscanf(temp_store,"%c",&ord_req->cBuyOrSell);
				logDebug2("SeqNo :: %d , ord_req->BuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->cBuyOrSell);
				break;
			case 12:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cProdIdFrom);
				logDebug2("SeqNo :: %d , Product From is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProdIdFrom);
				break;
			case 13:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cProdIdTo);
				logDebug2("SeqNo :: %d , Product To is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProdIdTo);
				break;
			case 14:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("SeqNo :: %d , UserType is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cUserType);
				break;
			case 15:
				ord_req->iQty = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iQty :%d:",temp_store,ord_req->iQty);
				break;
			case 16:
				ord_req->iMktType = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iMktType:%d:",temp_store,ord_req->iMktType);
				break;
			default	:
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;
		}
		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);
	}   
	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	return TRUE;
}

BOOL  Map_SIP_Ord_Req(char *requestDetails ,struct SIP_ORD_REQUEST *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct SIP_ORD_REQUEST));

	logDebug2("Packet recieved... = %s",requestDetails);

	while(1)
	{
		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The String Is Completely tokenised");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" SeqNo =  %d ",ord_req->ReqHeader.iSeqNo);

				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST );
				logDebug2(" MsgLength = %d",ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2("ord_req->ReqHeader.iMsgCode  = %d",ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2("ord_req->ReqHeader.ExcgId = %s",ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%llu",&ord_req->ReqHeader.iUserId);
				logDebug2(" ord_req->ReqHeader.UserId = %llu",ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("ord_req->SourceFlag = %c",ord_req->ReqHeader.cSource);
				break;
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("ord_req->ReqHeader.Segment = %c",ord_req->ReqHeader.cSegment);
				break;
			case 8:
				memset(ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sSecurityId = %.12s",ord_req->sSecurityId);
				break;
			case 9:
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sClientId = %s ",ord_req->sClientId);
				break;
			case 10:
				sscanf(temp_store,"%c",&ord_req->cProductId);
				logDebug2("ord_req->cProductId = %c",ord_req->cProductId);
				break;
			case 11:
				sscanf(temp_store,"%c",&ord_req->cBuyOrSell);
				logDebug2("ord_req->BuyOrSell = %c",ord_req->cBuyOrSell);
				break;
			case 12:
				ord_req->iOrderType = atoi(temp_store);
				logDebug2(" ord_req->iOrderType = %d ",ord_req->iOrderType);
				break;
			case 13:
				ord_req->iOrderValidity = atoi(temp_store);
				logDebug2(" ord_req->iOrderValidity = %d",ord_req->iOrderValidity);
				break;
			case 14:
				sscanf(temp_store,"%d",&ord_req->iTotalQtyRem);
				logDebug2("ord_req->TotalQtyRemaining = %d",ord_req->iTotalQtyRem);
				break;
			case 15:
				sscanf(temp_store,"%d",&ord_req->iTotalQty);
				logDebug2("ord_req->TotalQty = %d",ord_req->iTotalQty);
				break;
			case 16:
				sscanf(temp_store,"%lf",&ord_req->fPrice);
				logDebug2("ord_req->Price = %lf",ord_req->fPrice);
				break;
			case 17:
				sscanf(temp_store,"%lf",&ord_req->fOrderNum);
				logDebug2("ord_req->OrderNum = %lf",ord_req->fOrderNum);
				break;
			case 18:
				sscanf(temp_store,"%d",&ord_req->iSerialNum);
				ord_req->iSerialNum = atoi(temp_store);
				logDebug2("ord_req->SerialNum = %d",ord_req->iSerialNum);
				break;
			case 19:
				sscanf(temp_store,"%d",&ord_req->iForPeriod);
				logDebug2("ord_req->iForPeriod = %d",ord_req->iForPeriod);
				break;
			case 20:
				sscanf(temp_store,"%c",&ord_req->cHandleInst );
				logDebug2("ord_req->cHandleInst = %c",ord_req->cHandleInst );
				break;
			case 21:
				sscanf(temp_store,"%c",&ord_req->cFrequency);
				logDebug2("ord_req->cFrequency = %c",ord_req->cFrequency);
				break;
			case 22:
				memset(ord_req->sStartDate , '\0', DATE_LENGTH);
				memcpy(ord_req->sStartDate,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sStartDate = %s",ord_req->sStartDate);
				break;
			case 23:
				sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
				logDebug2("ord_req->cOffMarketFlg = %c",ord_req->cOffMarketFlg);
				break;				
			case 24:
				sscanf(temp_store,"%c",&ord_req->cProCli);
				logDebug2("ord_req->cProCli = %c",ord_req->cProCli );
				break;
			case 25:
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("ord_req->cUserType = %c",ord_req->cUserType);
				break;
			case 26:
				sscanf(temp_store,"%c",&ord_req->cSIPFlag);
				logDebug2("ord_req->cSIPFlag = %c",ord_req->cSIPFlag);
				break;
			case 27:
				memset(ord_req->sRemarks,'\0',REMARKS_LEN);
				memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
				logDebug2("ord_req->Remarks = %s",ord_req->sRemarks);
				break;
			case 28:
				ord_req->iMktType = atoi(temp_store);
				logDebug2("ord_req->iMktType = %d",ord_req->iMktType);
				break;
			case 29:
                                memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
                                memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
                                logDebug2("ord_req->sEntityId = %s ",ord_req->sEntityId);
                                break;
			case 30:
                                sscanf(temp_store,"%c",&ord_req->cMarkProFlag);
                                logDebug2("ord_req->cMarkProFlag :%c",ord_req->cMarkProFlag);
                                break;

                        case 31:
                                sscanf(temp_store,"%lf",&ord_req->fMarkProVal);
                                logDebug2("ord_req->fMarkProVal %lf",ord_req->fMarkProVal);
                                break;

                        case 32:
                                sscanf(temp_store,"%c",&ord_req->cParticipantType);
                                logDebug2("ord_req->cParticipantType :%c",ord_req->cParticipantType);
                                break;

                        case 33:
                                memset(ord_req->sSettlor, '\0', SETTLOR_LEN);
                                //memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                if(!strcmp(temp_store,"X"))
                                {
                                        strncpy(ord_req->sSettlor,"",SETTLOR_LEN);
                                }
                                else
                                {
                                        memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                }
                                logDebug2("SeqNo :: %d ,ord_req->sSettlor = %s",ord_req->ReqHeader.iSeqNo, ord_req->sSettlor);

                                logDebug2("ord_req->sSettlor = %s",ord_req->sSettlor);
                                break;

                        case 34:
                                sscanf(temp_store,"%c",&ord_req->cGTCFlag);
                                logDebug2("ord_req->cGTCFlag :%c",ord_req->cGTCFlag);
                                break;

                        case 35:
                                sscanf(temp_store,"%c",&ord_req->cEncashFlag);
                                logDebug2("ord_req->cEncashFlag :%c",ord_req->cEncashFlag);
                                break;

                        case 36:
				sscanf(temp_store,"%d",&ord_req->iGrpId);
                                logDebug2("SeqNo :: %d ,ord_req->iGrpId :%d",ord_req->ReqHeader.iSeqNo,ord_req->iGrpId);
                                break;
                        case 37:
                                memset(ord_req->sPlatform, '\0',PLATFORM_LEN);
                                memcpy(ord_req->sPlatform,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->sPlatform :%s",ord_req->ReqHeader.iSeqNo,ord_req->sPlatform);
                                break;
                        case 38:
                                memset(ord_req->sChannel, '\0', CHANNEL_LEN);
                                memcpy(ord_req->sChannel,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->Channel:%s",ord_req->ReqHeader.iSeqNo,ord_req->sChannel);
                                break;
			
			default :
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;

		}
		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);

	}
	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	return TRUE;
}


BOOL  Map_CO_Ord_Req(char *requestDetails ,struct CO_ORDER_REQUEST *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct CO_ORDER_REQUEST ));

	logDebug2("Packet recieved.. = %s",requestDetails);

	while(1)
	{

		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised..");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" SeqNo =  %d ",ord_req->ReqHeader.iSeqNo);
				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct CO_ORDER_REQUEST);
				logDebug2(" MsgLength = %d",ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2("ord_req->ReqHeader.iMsgCode  = %d",ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2("ord_req->ReqHeader.ExcgId = %s",ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%llu",&ord_req->ReqHeader.iUserId);
				logDebug2(" ord_req->ReqHeader.UserId = %llu",ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("ord_req->SourceFlag = %c",ord_req->ReqHeader.cSource);
				break;
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("ord_req->ReqHeader.Segment = %c",ord_req->ReqHeader.cSegment);	
				break;
			case 8:
				sscanf(temp_store,"%lf",&ord_req->CoArray[0].fTriggerPrice);
				logDebug2(" 8 ord_req->CoArray[MAX_COBO_LEN].fTriggerPrice 1 = %lf",ord_req->CoArray[0].fTriggerPrice);
				break;
			case 9:
				sscanf(temp_store,"%c",&ord_req->CoArray[0].cBuySellInd);
				logDebug2("9 ord_req->CoArray[MAX_COBO_LEN].cBuySellInd 1 = %c",ord_req->CoArray[0].cBuySellInd);
				break;
			case 10:
				sscanf(temp_store,"%d",&ord_req->CoArray[0].iLegValue);
				logDebug2("10 ord_req->CoArray[MAX_COBO_LEN].iLegValue 1 = %d",ord_req->CoArray[0].iLegValue);
				break;			
			case 11:
				sscanf(temp_store,"%lf",&ord_req->CoArray[1].fTriggerPrice);
				logDebug2("11 ord_req->CoArray[MAX_COBO_LEN].fTriggerPrice 2 = %lf",ord_req->CoArray[1].fTriggerPrice);
				break;
			case 12:
				sscanf(temp_store,"%c",&ord_req->CoArray[1].cBuySellInd);
				logDebug2("12 ord_req->CoArray[MAX_COBO_LEN].cBuySellInd 2 = %c",ord_req->CoArray[1].cBuySellInd);
				break;
			case 13:
				sscanf(temp_store,"%d",&ord_req->CoArray[1].iLegValue);
				logDebug2("13 ord_req->CoArray[MAX_COBO_LEN].iLegValue 2 = %d",ord_req->CoArray[1].iLegValue);
				break;
				/*
				   case 14:
				   sscanf(temp_store,"%lf",&ord_req->CoArray[2].fTriggerPrice);
				   logDebug2("ord_req->CoArray[MAX_COBO_LEN].fTriggerPrice 3 = %lf",ord_req->CoArray[1].fTriggerPrice);
				   break;
				   case 15:
				   sscanf(temp_store,"%c",&ord_req->CoArray[2].cBuySellInd);
				   logDebug2("ord_req->CoArray[MAX_COBO_LEN].cBuySellInd 3 = %c",ord_req->CoArray[1].cBuySellInd);
				   break;
				   case 16:
				   sscanf(temp_store,"%d",&ord_req->CoArray[2].iLegValue);
				   logDebug2("ord_req->CoArray[MAX_COBO_LEN].iLegValue 3 = %d",ord_req->CoArray[1].iLegValue);
				   break;
				 */
			case 14:
				memset(ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("14 ord_req->sSecurityId = %.12s",ord_req->sSecurityId);
				break;
			case 15:
				memset(ord_req->sEntityId, '\0', ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sEntityId= %.12s",ord_req->sEntityId);
				break;	
			case 16:
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sClientId = %s ",ord_req->sClientId);
				break;
			case 17:
				sscanf(temp_store,"%c",&ord_req->cProductId);
				logDebug2("ord_req->cProductId = %c",ord_req->cProductId);
				break;
			case 18:
				sscanf(temp_store,"%c",&ord_req->cHandleInst );
				logDebug2("ord_req->cHandleInst = %c",ord_req->cHandleInst );
				break;
			case 19:
				sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
				logDebug2("ord_req->cOffMarketFlg = %c",ord_req->cOffMarketFlg);
				break;
			case 20:
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("ord_req->cUserType = %c",ord_req->cUserType);
				break;
			case 21:
				ord_req->iMktType = atoi(temp_store);
				logDebug2("ord_req->iMktType = %d",ord_req->iMktType);
				break;
			case 22:
				sscanf(temp_store,"%d",&ord_req->iDiscQty);
				logDebug2("ord_req->iDiscQty = %d",ord_req->iDiscQty);
				break;
			case 23:
				sscanf(temp_store,"%d",&ord_req->iDiscQtyRem);
				logDebug2("ord_req->iDiscQtyRem = %d",ord_req->iDiscQtyRem);
				break;
			case 24:
				sscanf(temp_store,"%d",&ord_req->iTotalQtyRem);
				logDebug2("ord_req->iTotalQtyRem = %d",ord_req->iTotalQtyRem);
				break;
			case 25:
				sscanf(temp_store,"%d",&ord_req->iTotalQty);
				logDebug2("ord_req->iTotalQty : %d",ord_req->iTotalQty);
				break;
			case 26:
				sscanf(temp_store,"%d",&ord_req->iTotalTradedQty);
				logDebug2("ord_req->iTotalTradedQty: %d",ord_req->iTotalTradedQty);
				break;
			case 27:
				sscanf(temp_store,"%lf",&ord_req->fPrice);
				logDebug2("ord_req->Price = %lf",ord_req->fPrice);
				break;
			case 28:
				sscanf(temp_store,"%lf",&ord_req->fOrderNum);
				logDebug2("ord_req->OrderNum = %lf",ord_req->fOrderNum);
				break;
			case 29:
				sscanf(temp_store,"%d",&ord_req->iSerialNum);
				ord_req->iSerialNum = atoi(temp_store);
				logDebug2("ord_req->SerialNum = %d",ord_req->iSerialNum);
				break;
			case 30:
				ord_req->fAlgoOrderNo = atof(temp_store);
				logDebug2("ord_req->fAlgoOrderNo = %lf",ord_req->fAlgoOrderNo);
				break;
			case 31:
				sscanf(temp_store,"%lf",&ord_req->fTrailingSLValue);
				logDebug2("ord_req->fTrailingSLValue= %lf",ord_req->fTrailingSLValue);
				break;
			case 32:
				sscanf(temp_store,"%c",&ord_req->cProCli);
				logDebug2("ord_req->cProCli = %c",ord_req->cProCli );
				break;
			case 33:
				memset(ord_req->sRemarks,'\0',REMARKS_LEN);
				memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
				logDebug2("ord_req->Remarks = %s",ord_req->sRemarks);
				break;
			case 34:
				ord_req->iStratergyId= atoi(temp_store);
				logDebug2("ord_req->iStratergyId = %d",ord_req->iStratergyId);
				break;
			case 35:
				sscanf(temp_store,"%d",&ord_req->iNoOfLeg);
				logDebug2("ord_req->iNoOfLeg = %d",ord_req->iNoOfLeg);
				break;
			case 36:
				ord_req->iOrderType = atoi(temp_store);
				logDebug2(" ord_req->iOrderType = %d ",ord_req->iOrderType);
				break;
			case 37:
				ord_req->iOrderValidity = atoi(temp_store);
				logDebug2(" ord_req->iOrderValidity = %d",ord_req->iOrderValidity);
				break;
			case 38:
				sscanf(temp_store,"%d",&ord_req->iMinFillQty);
				logDebug2("ord_req->iMinFillQty = %d",ord_req->iMinFillQty);
				break;
			case 39:
				sscanf(temp_store,"%c",&ord_req->cSLFlag);
				logDebug2("ord_req->cSLFlag= %c",ord_req->cSLFlag);
				break;
			case 40:
				sscanf(temp_store,"%c",&ord_req->cPBFlag);
				logDebug2("ord_req->cPBFlag= %c",ord_req->cPBFlag);
				break;
			case 41:
                                sscanf(temp_store,"%c",&ord_req->cAvgLtpFlg);
                                logDebug2("ord_req->cAvgLtpFlg = %c",ord_req->cAvgLtpFlg);
                                break;
			case 42:
				sscanf(temp_store,"%lf",&ord_req->fPBTikAbsValue);
				logDebug2("ord_req->fPBTikAbsValue = %lf",ord_req->fPBTikAbsValue);
				break;
			case 43:
				sscanf(temp_store,"%lf",&ord_req->fSLTikAbsValue);
				logDebug2("ord_req->fSLTikAbsValue = %lf",ord_req->fSLTikAbsValue);
				break;
			
			case 44:
                                sscanf(temp_store,"%c",&ord_req->cMarkProFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cMarkProFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cMarkProFlag);
                                break;

                        case 45:
                                sscanf(temp_store,"%lf",&ord_req->fMarkProVal);
                                logDebug2("SeqNo :: %d , ord_req->fMarkProVal %lf",ord_req->ReqHeader.iSeqNo,ord_req->fMarkProVal);
                                break;

                        case 46:
                                sscanf(temp_store,"%c",&ord_req->cParticipantType);
                                logDebug2("SeqNo :: %d ,ord_req->cParticipantType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cParticipantType);
                                break;

                        case 47:
                                memset(ord_req->sSettlor, '\0', SETTLOR_LEN);
                                //memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                if(!strcmp(temp_store,"X"))
                                {
                                        strncpy(ord_req->sSettlor,"",SETTLOR_LEN);
                                }
                                else
                                {
                                        memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                }
                                logDebug2("SeqNo :: %d ,ord_req->sSettlor = %s",ord_req->ReqHeader.iSeqNo, ord_req->sSettlor);
                                break;

                        case 48:
                                sscanf(temp_store,"%c",&ord_req->cGTCFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cGTCFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cGTCFlag);
                                break;

                        case 49:
                                sscanf(temp_store,"%c",&ord_req->cEncashFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cEncashFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cEncashFlag);
                                break;

                        case 50:
                                sscanf(temp_store,"%d",&ord_req->iGrpId);
                                logDebug2("SeqNo :: %d ,ord_req->iGrpId= %d",ord_req->ReqHeader.iSeqNo, ord_req->iGrpId);
                                break;
			case 51:
				memset(ord_req->sPlatform, '\0',PLATFORM_LEN);
				memcpy(ord_req->sPlatform,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->sPlatform :%s",ord_req->ReqHeader.iSeqNo,ord_req->sPlatform);
                                break;
			case 52:
				memset(ord_req->sChannel, '\0', CHANNEL_LEN);
				memcpy(ord_req->sChannel,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->Channel:%s",ord_req->ReqHeader.iSeqNo,ord_req->sChannel);
                                break;
			
			default :
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;

		}

		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);
	}	
	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	return TRUE;
}



BOOL  Map_SPRD_Req(char *requestDetails ,struct ORDER_SPREAD_REQUEST *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct ORDER_SPREAD_REQUEST));

	logDebug2("Packet recieved:%s",requestDetails);

	while(1)
	{
		/**     logDebug2 ("\n\t Value of i is : %d " , i) ;***/
		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);
		
		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" iSeqNo      ::      %d ",ord_req->ReqHeader.iSeqNo);

				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct  ORDER_SPREAD_REQUEST );
				logDebug2(" iSeqNo :: %d ,The MsgLength is %d",ord_req->ReqHeader.iSeqNo, ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2(" temp_store :%s: ord_req->ReqHeader.iMsgCode :%d:",temp_store,ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.ExcgId :%s",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%d",&ord_req->ReqHeader.iUserId);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.UserId :%d",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("SeqNo :: %d , ord_req->SourceFlag : %c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSource);
				break;
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("SeqNo :: %d ,ord_req->ReqHeader.Segment :%c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSegment);
				break;
			case 8:
				logDebug2("this is entityId ");
				memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is EntityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sEntityId);
				break;
			case 9:
				logDebug2("this is ClientId ");
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is ClientId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sClientId);
				break;
			case 10:
				logDebug2(" temp_store :%s: ",temp_store);
				sscanf(temp_store,"%c",&ord_req->cProductId);
				logDebug2("SeqNo :: %d , Product To is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProductId);
				break;
			case 11:
				ord_req->iOrderType = atoi(temp_store);
				logDebug2(" temp_store :%s: ord_req->iOrderType :%d:",temp_store,ord_req->iOrderType);
				break;
			case 12:
				sscanf(temp_store,"%c",&ord_req->cProCli);
				logDebug2("SeqNo :: %d ,ord_req->cProCli  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProCli );
				break;
			case 13:
				sscanf(temp_store,"%lf",&ord_req->fOrderNum);
				logDebug2("ord_req->OrderNum = %lf",ord_req->fOrderNum);
				break;
			case 14:
				sscanf(temp_store,"%lf",&ord_req->fPriceDiff);
				logDebug2("SeqNo :: %d , ord_req->fPriceDiff : %lf",ord_req->ReqHeader.iSeqNo,ord_req->fPriceDiff);
				break;
			case 15:
				ord_req->iOrderValidity = atoi(temp_store);
				logDebug2(" ord_req->iOrderValidity = %d",ord_req->iOrderValidity);
				break;
			case 16:
				sscanf(temp_store,"%d",&ord_req->iSerialNum);
				ord_req->iSerialNum = atoi(temp_store);
				logDebug2("ord_req->SerialNum = %d",ord_req->iSerialNum);
				break;	
			case 17:
				memset(ord_req->sRemarks,'\0',REMARKS_LEN);
				memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
				logDebug2("ord_req->Remarks = %s",ord_req->sRemarks);
				break;	
			case 18:
				memset(ord_req->sSettlor,'\0',SETTLOR_LEN);
				if(!strcmp(temp_store,"X"))
                                {
                                        strncpy(ord_req->sSettlor,"",SETTLOR_LEN);
                                }
                                else
                                {
                                        memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                }
				logDebug2("ord_req->sSettlor = %s",ord_req->sSettlor);
				break;
			case 19:
				sscanf(temp_store,"%c",&ord_req->cHandleInst );
				logDebug2("ord_req->cHandleInst = %c",ord_req->cHandleInst );
				break;
			case 20:
				sscanf(temp_store,"%d",&ord_req->iNoOfLeg);
				logDebug2("ord_req->iNoOfLeg = %d",ord_req->iNoOfLeg);
				break;
			case 21:
				memset(ord_req->sSpreadLeg[0].sSecurityId,'\0',SECURITY_ID_LEN);
				memcpy(ord_req->sSpreadLeg[0].sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is sSpreadLeg[0].sSecurityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sSpreadLeg[0].sSecurityId);
				break;
			case 22:
				sscanf(temp_store,"%c",&ord_req->sSpreadLeg[0].cBuyOrSell);
				logDebug2("SeqNo :: %d , ord_req->BuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->sSpreadLeg[0].cBuyOrSell);
				break;
			case 23:
                                sscanf(temp_store,"%lf",&ord_req->sSpreadLeg[0].fPrice);
                                logDebug2("SeqNo :: %d , ord_req->fPrice : %lf",ord_req->ReqHeader.iSeqNo,ord_req->sSpreadLeg[0].fPrice);
                                break;
			
			case 24:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[0].iTotalQtyRem);
                                logDebug2("ord_req->iTotalQtyRem = %d",ord_req->sSpreadLeg[0].iTotalQtyRem);
                                break;
                        case 25:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[0].iTotalQty);
                                logDebug2("ord_req->iTotalQty : %d",ord_req->sSpreadLeg[0].iTotalQty);
                                break;
                        case 26:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[0].iTotalTradedQty);
                                logDebug2("ord_req->iTotalTradedQty: %d",ord_req->sSpreadLeg[0].iTotalTradedQty);
                                break;
                        case 27:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[0].iMinFillQty);
                                logDebug2("ord_req->iMinFillQty = %d",ord_req->sSpreadLeg[0].iMinFillQty);
                                break;	
		
			case 28:
				memset(ord_req->sSpreadLeg[1].sSecurityId,'\0',SECURITY_ID_LEN);
				memcpy(ord_req->sSpreadLeg[1].sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is sSpreadLeg[1].sSecurityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sSpreadLeg[1].sSecurityId);	
				break;
			case 29:
				sscanf(temp_store,"%c",&ord_req->sSpreadLeg[1].cBuyOrSell);
				logDebug2("SeqNo :: %d , ord_req->sSpreadLeg[1].cBuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->sSpreadLeg[1].cBuyOrSell);
				break;
			case 30:
                                sscanf(temp_store,"%lf",&ord_req->sSpreadLeg[1].fPrice);
                                logDebug2("SeqNo :: %d , ord_req->fPrice : %lf",ord_req->ReqHeader.iSeqNo,ord_req->sSpreadLeg[1].fPrice);
                                break;
		
			case 31:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[1].iTotalQtyRem);
                                logDebug2("ord_req->iTotalQtyRem = %d",ord_req->sSpreadLeg[1].iTotalQtyRem);
                                break;
                        case 32:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[1].iTotalQty);
                                logDebug2("ord_req->iTotalQty : %d",ord_req->sSpreadLeg[1].iTotalQty);
                                break;
                        case 33:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[1].iTotalTradedQty);
                                logDebug2("ord_req->iTotalTradedQty: %d",ord_req->sSpreadLeg[1].iTotalTradedQty);
                                break;
                        case 34:
                                sscanf(temp_store,"%d",&ord_req->sSpreadLeg[1].iMinFillQty);
                                logDebug2("ord_req->iMinFillQty = %d",ord_req->sSpreadLeg[1].iMinFillQty);
                                break;
			case 35:
				memset(ord_req->sCBrokerCode,'\0',BROKER_CODE_LEN);
				memcpy(ord_req->sCBrokerCode,temp_store,strlen(temp_store));
				logDebug2("ord_req->sCBrokerCode = %s",ord_req->sCBrokerCode);
				break;
			case 36:
				ord_req->fAlgoOrderNo = atof(temp_store);
				logDebug2(" SeqNo :: %d , ord_req->fAlgoOrderNo :%lf:",ord_req->ReqHeader.iSeqNo,ord_req->fAlgoOrderNo);
				break;	
			case 37:
				ord_req->iStratergyId= atoi(temp_store);
				logDebug2(" SeqNo :: %d , ord_req->iStratergyId:%d",ord_req->ReqHeader.iSeqNo,ord_req->iStratergyId);
				break;
			case 38:
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("SeqNo :: %d ,ord_req->cUserType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cUserType);
				break;
			case 39:
				ord_req->iMktType = atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->iMktType :%d:",ord_req->ReqHeader.iSeqNo,ord_req->iMktType);
				break;
			case 40:
				sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
				logDebug2("ord_req->cOffMarketFlg = %c",ord_req->cOffMarketFlg);
				break;
			case 41:
                                sscanf(temp_store,"%c",&ord_req->cMarkProFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cMarkProFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cMarkProFlag);
                                break;

                        case 42:
                                sscanf(temp_store,"%lf",&ord_req->fMarkProVal);
                                logDebug2("SeqNo :: %d , ord_req->fMarkProVal %lf",ord_req->ReqHeader.iSeqNo,ord_req->fMarkProVal);
                                break;

                        case 43:
                                sscanf(temp_store,"%c",&ord_req->cParticipantType);
                                logDebug2("SeqNo :: %d ,ord_req->cParticipantType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cParticipantType);
                                break;

                      

                        case 44:
                                sscanf(temp_store,"%c",&ord_req->cGTCFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cGTCFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cGTCFlag);
                                break;

                        case 45:
                                sscanf(temp_store,"%c",&ord_req->cEncashFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cEncashFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cEncashFlag);
                                break;
		
			case 46:
                                sscanf(temp_store,"%d",&ord_req->iGrpId);
                                logDebug2("SeqNo :: %d ,ord_req->iGrpId= %d",ord_req->ReqHeader.iSeqNo, ord_req->iGrpId);
                                break;
			
			 case 47:
                                memset(ord_req->sPlatform, '\0',PLATFORM_LEN);
                                memcpy(ord_req->sPlatform,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->sPlatform :%s",ord_req->ReqHeader.iSeqNo,ord_req->sPlatform);
                                break;
                        case 48:
                                memset(ord_req->sChannel, '\0', CHANNEL_LEN);
                                memcpy(ord_req->sChannel,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->Channel:%s",ord_req->ReqHeader.iSeqNo,ord_req->sChannel);
                                break;	


			default :
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;
		}
		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);

	}
	/**free(arr);***/
	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	//ord_req->AuctionNum  = 0 ;
	return TRUE;


}

BOOL  Map_BO_Ord_Req(char *requestDetails ,struct BO_ORDER_REQUEST *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset(ord_req ,'\0', sizeof( struct BO_ORDER_REQUEST ));

	logDebug2("Packet recieved.. = %s",requestDetails);
	logDebug2("sizeof( struct BO_ORDER_REQUEST 1) :%d:",sizeof( struct BO_ORDER_REQUEST ));
	while(1)
	{

		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised..");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" SeqNo =  %d ",ord_req->ReqHeader.iSeqNo);
				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct BO_ORDER_REQUEST);
				logDebug2(" MsgLength = %d",ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2("ord_req->ReqHeader.iMsgCode  = %d",ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2("ord_req->ReqHeader.sExcgId = %s",ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%llu",&ord_req->ReqHeader.iUserId);
				logDebug2(" ord_req->ReqHeader.iUserId = %llu",ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("ord_req->SourceFlag = %c",ord_req->ReqHeader.cSource);
				break;
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("ord_req->ReqHeader.iSegment = %c",ord_req->ReqHeader.cSegment);
				break;
			case 8:
				sscanf(temp_store,"%lf",&ord_req->BoArray[0].fTriggerPrice);
				logDebug2(" 8 ord_req->BoArray[MAX_COBO_LEN].fTriggerPrice 1 = %lf",ord_req->BoArray[0].fTriggerPrice);
				break;
			case 9:
				sscanf(temp_store,"%c",&ord_req->BoArray[0].cBuySellInd);
				logDebug2("9 ord_req->BoArray[MAX_COBO_LEN].cBuySellInd 1 = %c",ord_req->BoArray[0].cBuySellInd);
				break;
			case 10:
				sscanf(temp_store,"%d",&ord_req->BoArray[0].iLegValue);
				logDebug2("10 ord_req->BoArray[MAX_COBO_LEN].iLegValue 1 = %d",ord_req->BoArray[0].iLegValue);
				break;
			case 11:
				sscanf(temp_store,"%lf",&ord_req->BoArray[1].fTriggerPrice);
				logDebug2("11 ord_req->BoArray[MAX_COBO_LEN].fTriggerPrice 2 = %lf",ord_req->BoArray[1].fTriggerPrice);
				break;
			case 12:
				sscanf(temp_store,"%c",&ord_req->BoArray[1].cBuySellInd);
				logDebug2("12 ord_req->BoArray[MAX_COBO_LEN].cBuySellInd 2 = %c",ord_req->BoArray[1].cBuySellInd);
				break;
			case 13:
				sscanf(temp_store,"%d",&ord_req->BoArray[1].iLegValue);
				logDebug2("13 ord_req->BoArray[MAX_COBO_LEN].iLegValue 2 = %d",ord_req->BoArray[1].iLegValue);
				break;
			case 14:
				sscanf(temp_store,"%lf",&ord_req->BoArray[2].fTriggerPrice);
				logDebug2("14 ord_req->BoArray[MAX_COBO_LEN].fTriggerPrice 3 = %lf",ord_req->BoArray[2].fTriggerPrice);
				break;
			case 15:
				sscanf(temp_store,"%c",&ord_req->BoArray[2].cBuySellInd);
				logDebug2("15 ord_req->BoArray[MAX_COBO_LEN].cBuySellInd 3 = %c",ord_req->BoArray[2].cBuySellInd);
				break;
			case 16:
				sscanf(temp_store,"%d",&ord_req->BoArray[2].iLegValue);
				logDebug2("16 ord_req->BoArray[MAX_COBO_LEN].iLegValue 3 = %d",ord_req->BoArray[2].iLegValue);
				break;
			case 17:
				memset(ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("14 ord_req->sSecurityId = %.12s",ord_req->sSecurityId);
				break;
			case 18:
				memset(ord_req->sEntityId, '\0', ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sEntityId= %.12s",ord_req->sEntityId);
				break;
			case 19:
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("ord_req->sClientId = %s ",ord_req->sClientId);
				break;
			case 20:
				sscanf(temp_store,"%c",&ord_req->cProductId);
				logDebug2("ord_req->cProductId = %c",ord_req->cProductId);
				break;
			case 21:
				sscanf(temp_store,"%c",&ord_req->cHandleInst );
				logDebug2("ord_req->cHandleInst = %c",ord_req->cHandleInst );
				break;
			case 22:
				sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
				logDebug2("ord_req->cOffMarketFlg = %c",ord_req->cOffMarketFlg);
				break;
			case 23:
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("ord_req->cUserType = %c",ord_req->cUserType);
				break;
			case 24:
				ord_req->iMktType = atoi(temp_store);
				logDebug2("ord_req->iMktType = %d",ord_req->iMktType);
				break;
			case 25:
				sscanf(temp_store,"%d",&ord_req->iDiscQty);
				logDebug2("ord_req->iDiscQty = %d",ord_req->iDiscQty);
				break;
			case 26:
				sscanf(temp_store,"%d",&ord_req->iDiscQtyRem);
				logDebug2("ord_req->iDiscQtyRem = %d",ord_req->iDiscQtyRem);
				break;
			case 27:
				sscanf(temp_store,"%d",&ord_req->iTotalQtyRem);
				logDebug2("ord_req->iTotalQtyRem = %d",ord_req->iTotalQtyRem);
				break;
			case 28:
				sscanf(temp_store,"%d",&ord_req->iTotalQty);
				logDebug2("ord_req->iTotalQty : %d",ord_req->iTotalQty);
				break;
			case 29:
				sscanf(temp_store,"%d",&ord_req->iTotalTradedQty);
				logDebug2("ord_req->iTotalTradedQty: %d",ord_req->iTotalTradedQty);
				break;
			case 30:
				sscanf(temp_store,"%lf",&ord_req->fPrice);
				logDebug2("ord_req->Price = %lf",ord_req->fPrice);
				break;
			case 31:
				sscanf(temp_store,"%lf",&ord_req->fOrderNum);
				logDebug2("ord_req->OrderNum = %lf",ord_req->fOrderNum);
				break;
			case 32:
				sscanf(temp_store,"%d",&ord_req->iSerialNum);
				ord_req->iSerialNum = atoi(temp_store);
				logDebug2("ord_req->SerialNum = %d",ord_req->iSerialNum);
				break;
			case 33:
				ord_req->fAlgoOrderNo = atof(temp_store);
				logDebug2("ord_req->fAlgoOrderNo = %lf",ord_req->fAlgoOrderNo);
				break;
			case 34:
				sscanf(temp_store,"%lf",&ord_req->fTrailingSLValue);
				logDebug2("ord_req->fTrailingSLValue= %lf",ord_req->fTrailingSLValue);
				break;
			case 35:
				sscanf(temp_store,"%c",&ord_req->cProCli);
				logDebug2("ord_req->cProCli = %c",ord_req->cProCli );
				break;
			case 36:
				memset(ord_req->sRemarks,'\0',REMARKS_LEN);
				memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
				logDebug2("ord_req->Remarks = %s",ord_req->sRemarks);
				break;
			case 37:
				ord_req->iStratergyId= atoi(temp_store);
				logDebug2("ord_req->iStratergyId = %d",ord_req->iStratergyId);
				break;
			case 38:
				sscanf(temp_store,"%d",&ord_req->iNoOfLeg);
				logDebug2("ord_req->iNoOfLeg = %d",ord_req->iNoOfLeg);
				break;
			case 39:
				ord_req->iOrderType = atoi(temp_store);
				logDebug2(" ord_req->iOrderType = %d ",ord_req->iOrderType);
				break;
			case 40:
				ord_req->iOrderValidity = atoi(temp_store);
				logDebug2(" ord_req->iOrderValidity = %d",ord_req->iOrderValidity);
				break;
			case 41:
				sscanf(temp_store,"%d",&ord_req->iMinFillQty);
				logDebug2("ord_req->iMinFillQty = %d",ord_req->iMinFillQty);
				break;
			case 42:
				sscanf(temp_store,"%c",&ord_req->cSLFlag);
				logDebug2("ord_req->cSLFlag= %c",ord_req->cSLFlag);
				break;
			case 43:
				sscanf(temp_store,"%c",&ord_req->cPBFlag);
				logDebug2("ord_req->cPBFlag= %c",ord_req->cPBFlag);
				break;
			case 44:
				sscanf(temp_store,"%lf",&ord_req->fPBTikAbsValue);
				logDebug2("ord_req->fPBTikAbsValue = %lf",ord_req->fPBTikAbsValue);
				break;
			case 45:
				sscanf(temp_store,"%lf",&ord_req->fSLTikAbsValue);
				logDebug2("ord_req->fSLTikAbsValue = %lf",ord_req->fSLTikAbsValue);
				break;
			case 46:
				sscanf(temp_store,"%d",&ord_req->iChildLegsUniqId);
				logDebug2("ord_req->iChildLegsUniqId = %d",ord_req->iChildLegsUniqId);
				break;
			case 47:
				sscanf(temp_store,"%d",&ord_req->iParentId);
				logDebug2("ord_req->iParentId = %d",ord_req->iParentId);
				break;
			case 48:
				sscanf(temp_store,"%c",&ord_req->cFlag);
				logDebug2("ord_req->cFlag = %c",ord_req->cFlag);
				break;
			case 49:
                                sscanf(temp_store,"%c",&ord_req->cMarkProFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cMarkProFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cMarkProFlag);
                                break;
                        case 50:
                                sscanf(temp_store,"%lf",&ord_req->fMarkProVal);
                                logDebug2("SeqNo :: %d , ord_req->fMarkProVal %lf",ord_req->ReqHeader.iSeqNo,ord_req->fMarkProVal);
                                break;
                        case 51:
                                sscanf(temp_store,"%c",&ord_req->cParticipantType);
                                logDebug2("SeqNo :: %d ,ord_req->cParticipantType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cParticipantType);
                                break;
                        case 52:
                                memset(ord_req->sSettlor, '\0', SETTLOR_LEN);
                                //memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                if(!strcmp(temp_store,"X"))
                                {
                                        strncpy(ord_req->sSettlor,"",SETTLOR_LEN);
                                }
                                else
                                {
                                        memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                }
                                logDebug2("SeqNo :: %d ,ord_req->sSettlor = %s",ord_req->ReqHeader.iSeqNo, ord_req->sSettlor);
                                break;
                        case 53:
                                sscanf(temp_store,"%c",&ord_req->cGTCFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cGTCFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cGTCFlag);
                                break;
                        case 54:
                                sscanf(temp_store,"%c",&ord_req->cEncashFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cEncashFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cEncashFlag);
                                break;
                        case 55:
                                //sscanf(temp_store,"%d",&ord_req->iGrpId);
				ord_req->iGrpId = atoi(temp_store);
                                logDebug2("SeqNo :: %d ,ord_req->iGrpId= %d",ord_req->ReqHeader.iSeqNo, ord_req->iGrpId);
                                break;
			case 56:
				memset(ord_req->sPlatform, '\0',PLATFORM_LEN);
				memcpy(ord_req->sPlatform,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->sPlatform :%s",ord_req->ReqHeader.iSeqNo,ord_req->sPlatform);
                                break;
			case 57:
				memset(ord_req->sChannel, '\0', CHANNEL_LEN);
				memcpy(ord_req->sChannel,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->Channel:%s",ord_req->ReqHeader.iSeqNo,ord_req->sChannel);
                                break;
			default :
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;

		}

		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);

	}

	logDebug2("sizeof( struct BO_ORDER_REQUEST 2) :%d:",sizeof( struct BO_ORDER_REQUEST ));
	logDebug2(" Returning for Sequence Number(BO) :: %d ",ord_req->ReqHeader.iSeqNo);
	return TRUE;
}





BOOL  Map_GTT_Ord_Req(char *requestDetails ,struct FOREVER_ORDER_REQUEST *ord_req)
{
        int i=0;
        char *arr[100];
        char temp_store[100];
        char *buf ;
        memset ( ord_req , '\0', sizeof( struct FOREVER_ORDER_REQUEST ));

        logDebug2("Packet recieved:%s",requestDetails);

        while(1)
        {
                if( i == 0)
                {
                        arr[i]=strtok_r(requestDetails,"|",&buf);
                }
                else
                {
                        arr[i]=strtok_r(NULL,"|",&buf);
                        if(arr[i]==NULL)
                        {
                                logDebug2(" The string is completely tokenised");
                                break;
                        }
                }

                memset(temp_store , '\0', 100 );
                strcpy(temp_store,arr[i]);
		
		switch(i+1)
                {
                        case 1:
                                ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
                                logDebug2(" iSeqNo      ::      %d ",ord_req->ReqHeader.iSeqNo);

                                break;
                        case 2:
                                ord_req->ReqHeader.iMsgLength = sizeof(struct FOREVER_ORDER_REQUEST);
                                logDebug2(" iSeqNo :: %d ,The MsgLength is %d",ord_req->ReqHeader.iSeqNo, ord_req->ReqHeader.iMsgLength);
                                break;
                        case 3:
                                ord_req->ReqHeader.iMsgCode = atoi(temp_store);
                                logDebug2(" temp_store :%s: ord_req->ReqHeader.iMsgCode :%d:",temp_store,ord_req->ReqHeader.iMsgCode);
                                break;
                        case 4:
                                memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
                                memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
                                logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.ExcgId :%s",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.sExcgId);
                                break;
                        case 5:
                                sscanf(temp_store,"%d",&ord_req->ReqHeader.iUserId);
                                logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.UserId :%d",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.iUserId);
                                break;
                        case 6:
                                sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
                                logDebug2("SeqNo :: %d , ord_req->SourceFlag : %c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSource);
                                break;
                        case 7:
                                sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
                                logDebug2("SeqNo :: %d ,ord_req->ReqHeader.Segment :%c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSegment);
                                break;
                        case 8:
                                ord_req->CoArray[0].fTriggerPrice= atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fTriggerPrice :%lf",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[0].fTriggerPrice);
                                break;
                        case 9:
                                ord_req->CoArray[0].iLegValue= atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->iLegValue :%d",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[0].iLegValue);
                                break;
                        case 10:
                                ord_req->CoArray[0].fPrice= atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fPrice :%lf:",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[0].fPrice);
                                break;
                        case 11:
                                ord_req->CoArray[0].iTotalQtyRem = atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->.iTotalQtyRem :%d",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[0].iTotalQtyRem);
                                break;
                        case 12:
                                ord_req->CoArray[0].iTotalQty = atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->.iTotalQty :%d",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[0].iTotalQty);
                                break;
                        case 13:
                                ord_req->CoArray[1].fTriggerPrice= atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fTriggerPrice :%lf",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[1].fTriggerPrice);
                                break;
                        case 14:
                                ord_req->CoArray[1].iLegValue= atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->iLegValue :%d",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[1].iLegValue);
                                break;
                        case 15:
                                ord_req->CoArray[1].fPrice= atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fPrice :%lf:",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[1].fPrice);
                                break;
                        case 16:
                                ord_req->CoArray[1].iTotalQtyRem = atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->.iTotalQtyRem :%d",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[1].iTotalQtyRem);
                                break;

                        case 17:
                                ord_req->CoArray[1].iTotalQty = atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->.iTotalQty :%d",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[1].iTotalQty);
                                break;

                        case 18:
                                memset( ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
                                memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
                                logDebug2("SeqNo :: %d ,this is SecId :%.12s:",ord_req->ReqHeader.iSeqNo, ord_req->sSecurityId);
                                break;
                        case 19:
                                logDebug2("this is entityId ");
                                memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
                                memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
                                logDebug2("SeqNo :: %d ,this is EntityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sEntityId);
                                break;
                        case 20:
                                logDebug2("this is ClientId ");
                                memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
                                memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
                                logDebug2("SeqNo :: %d ,this is ClientId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sClientId);
                                break;
                        case 21:
                                logDebug2(" temp_store :%s: ",temp_store);
                                sscanf(temp_store,"%c",&ord_req->cProductId);
                                logDebug2("SeqNo :: %d , Product Id is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProductId);
                                break;
                        case 22:
                                sscanf(temp_store,"%c",&ord_req->cHandleInst );
                                logDebug2("ord_req->cHandleInst = %c",ord_req->cHandleInst );
                                break;
                        case 23:
                                sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
                                logDebug2("ord_req->cOffMarketFlg = %c",ord_req->cOffMarketFlg);
                                break;
                        case 24:
                                sscanf(temp_store,"%c",&ord_req->cUserType);
                                logDebug2("ord_req->cUserType = %c",ord_req->cUserType);
                                break;
                        case 25:
                                sscanf(temp_store,"%c",&ord_req->cBuySellInd);
                                logDebug2("SeqNo :: %d , ord_req->BuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->cBuySellInd);
                                break;

                        case 26:
                                ord_req->iMktType = atoi(temp_store);
                                logDebug2("ord_req->iMktType = %d",ord_req->iMktType);
                                break;
                        case 27:
                                sscanf(temp_store,"%d",&ord_req->iDiscQty);
                                logDebug2("SeqNo :: %d , ord_req->DiscQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iDiscQty);
                                break;
			case 28:
                                sscanf(temp_store,"%d",&ord_req->iDiscQtyRem);
                                logDebug2("ord_req->iDiscQtyRem = %d",ord_req->iDiscQtyRem);
                                break;
                        case 29:
                                sscanf(temp_store,"%d",&ord_req->iTotalTradedQty);
                                logDebug2("SeqNo :: %d , ord_req->iTotalTradedQty: %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalTradedQty);
                                break;
                        case 30:
                                sscanf(temp_store,"%lf",&ord_req->fOrderNum);
                                logDebug2("SeqNo :: %d , ord_req->OrderNum %lf",ord_req->ReqHeader.iSeqNo,ord_req->fOrderNum);
                                break;

                        case 31:
                                logDebug2("this is SerialNum ");
                                sscanf(temp_store,"%d",&ord_req->iSerialNum);
                                ord_req->iSerialNum = atoi(temp_store);
                                logDebug2("SeqNo :: %d , ord_req->SerialNum : %d",ord_req->ReqHeader.iSeqNo,ord_req->iSerialNum);
                                break;

                        case 32:
                                ord_req->fAlgoOrderNo = atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fAlgoOrderNo :%lf:",ord_req->ReqHeader.iSeqNo,ord_req->fAlgoOrderNo);
                                break;
                        case 33:
                                sscanf(temp_store,"%lf",&ord_req->fTrailingSLValue);
                                logDebug2("ord_req->fTrailingSLValue= %lf",ord_req->fTrailingSLValue);
                                break;
                        case 34:
                                sscanf(temp_store,"%c",&ord_req->cProCli);
                                logDebug2("SeqNo :: %d ,ord_req->cProCli  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProCli );
                                break;
                        case 35:
                                memset(ord_req->sRemarks,'\0',REMARKS_LEN);
                                memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d , ord_req->Remarks : %s",ord_req->ReqHeader.iSeqNo,ord_req->sRemarks);
                                break;

                        case 36:
                                ord_req->iStratergyId= atoi(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->iStratergyId:%d",ord_req->ReqHeader.iSeqNo,ord_req->iStratergyId);
                                break;
                        case 37:
                                sscanf(temp_store,"%d",&ord_req->iNoOfLeg);
                                logDebug2("ord_req->iNoOfLeg = %d",ord_req->iNoOfLeg);
                                break;
                        case 38:
                                ord_req->iOrderType = atoi(temp_store);
                                logDebug2(" ord_req->iOrderType = %d ",ord_req->iOrderType);
                                break;
                        case 39:
                                ord_req->iOrderValidity = atoi(temp_store);
                                logDebug2(" ord_req->iOrderValidity = %d",ord_req->iOrderValidity);
                                break;
                        case 40:
                                sscanf(temp_store,"%d",&ord_req->iMinFillQty);
                                logDebug2("ord_req->iMinFillQty = %d",ord_req->iMinFillQty);
                                break;
                        case 41:
                                sscanf(temp_store,"%c",&ord_req->cSLFlag);
                                logDebug2("ord_req->cSLFlag= %c",ord_req->cSLFlag);
                                break;
                        case 42:
                                sscanf(temp_store,"%c",&ord_req->cPBFlag);
                                logDebug2("ord_req->cPBFlag= %c",ord_req->cPBFlag);
                                break;
                        case 43:
                                sscanf(temp_store,"%c",&ord_req->cAvgLtpFlg);
                                logDebug2("ord_req->cAvgLtpFlg = %c",ord_req->cAvgLtpFlg);
                                break;
                        case 44:
                                sscanf(temp_store,"%lf",&ord_req->fPBTikAbsValue);
                                logDebug2("ord_req->fPBTikAbsValue = %lf",ord_req->fPBTikAbsValue);
                                break;
                        case 45:
                                sscanf(temp_store,"%lf",&ord_req->fSLTikAbsValue);
                                logDebug2("ord_req->fSLTikAbsValue = %lf",ord_req->fSLTikAbsValue);
                                break;
                        case 46:
                                sscanf(temp_store,"%c",&ord_req->cMarkProFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cMarkProFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cMarkProFlag);
                                break;

                        case 47:
                                sscanf(temp_store,"%lf",&ord_req->fMarkProVal);
                                logDebug2("SeqNo :: %d , ord_req->fMarkProVal %lf",ord_req->ReqHeader.iSeqNo,ord_req->fMarkProVal);
                                break;
                        case 48:
                                sscanf(temp_store,"%c",&ord_req->cParticipantType);
                                logDebug2("SeqNo :: %d ,ord_req->cParticipantType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cParticipantType);
                                break;

                        case 49:
                                memset(ord_req->sSettlor, '\0', SETTLOR_LEN);
                                memcpy(ord_req->sSettlor,temp_store,strlen( temp_store ));
                                logDebug2("SeqNo :: %d ,ord_req->sSettlor = %s",ord_req->ReqHeader.iSeqNo, ord_req->sSettlor);
                                break;

                        case 50:
                                sscanf(temp_store,"%c",&ord_req->cGTCFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cGTCFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cGTCFlag);
                                break;

                        case 51:
                                sscanf(temp_store,"%c",&ord_req->cEncashFlag);
                                logDebug2("SeqNo :: %d ,ord_req->cEncashFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cEncashFlag);
                                break;

                        case 52:
				ord_req->iGrpId = atoi(temp_store);
                                logDebug2("SeqNo :: %d ,ord_req->iGrpId= %d",ord_req->ReqHeader.iSeqNo, ord_req->iGrpId);
                                break;

                        case 53:
                                sscanf(temp_store,"%c",&ord_req->cGttType);
                                logDebug2("SeqNo :: %d ,ord_req->GTTFlag :%c",ord_req->ReqHeader.iSeqNo,ord_req->cGttType);
                                break;
			case 54:
				memset(ord_req->sPlatform, '\0',PLATFORM_LEN);
				memcpy(ord_req->sPlatform,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->sPlatform :%s",ord_req->ReqHeader.iSeqNo,ord_req->sPlatform);
                                break;
			case 55:
				memset(ord_req->sChannel, '\0', CHANNEL_LEN);
				memcpy(ord_req->sChannel,temp_store,strlen(temp_store));
                                logDebug2("SeqNo :: %d ,ord_req->Channel:%s",ord_req->ReqHeader.iSeqNo,ord_req->sChannel);
                                break;
			case 56:
                                ord_req->CoArray[0].fOrdTriggerPrice= atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fOrdTriggerPrice :%lf",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[0].fOrdTriggerPrice);
                                break;
			case 57:
                                ord_req->CoArray[1].fOrdTriggerPrice= atof(temp_store);
                                logDebug2(" SeqNo :: %d , ord_req->fOrdTriggerPrice :%lf",ord_req->ReqHeader.iSeqNo,ord_req->CoArray[1].fOrdTriggerPrice);
                                break;


                        default :
                                logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
                                return FALSE;
                }
                i++;
                logDebug2(" TOKEN NUMBER : [%d]",i);
        }
        logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
        return TRUE;
}
