#include "IPCS.h"
#include<stdio.h>
#include <memory.h>
#include <string.h>
#include<stdlib.h>

#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/msg.h>
#include <sys/errno.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <ctype.h>
#include <errno.h>

#include <netinet/in.h>		
//#include <Common.h>
//#include <Inquiry.h>
//#include "MrgPlsOrderStructs.h"
//#define ITS_TIME_OUT 20000
//#define PORT 4342
//#define PACKET_SIZE 200
//#define     TWIDDLE(A)      Twiddle ((char *) &A, sizeof(A));

//BOOL Map_MrgPlsOrd_Req(char *,struct MRGPLS_ORDER_REQUEST  *);
BOOL 	Map_Ord_Req(char * ,struct ORDER_REQUEST *);
BOOL 	Map_C2D_Req(char * ,struct CON_TO_DELIVERY_REQUEST *);
//int 	createSocket	();
//int 	SendPacket	(int ,char *);
//char* 	ReceivePacket	(int );




BOOL  Map_Ord_Req(char *requestDetails ,struct ORDER_REQUEST  *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct ORDER_REQUEST ));

	logDebug2("Packet recieved:%s",requestDetails);

	while(1)
	{
		/**	logDebug2 ("\n\t Value of i is : %d " , i) ;***/
		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);
		/*****
		  logDebug2("\n Counter In Map_1LOrd_Req :: %d ",i);
		  logDebug2("\n temp_store :: %s ",temp_store);
		 ******/

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" iSeqNo	::	%d ",ord_req->ReqHeader.iSeqNo);

				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct ORDER_REQUEST );
				logDebug2(" iSeqNo :: %d ,The MsgLength is %d",ord_req->ReqHeader.iSeqNo, ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2(" temp_store :%s: ord_req->ReqHeader.iMsgCode :%d:",temp_store,ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.ExcgId :%s",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%d",&ord_req->ReqHeader.iUserId);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.UserId :%d",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("SeqNo :: %d , ord_req->SourceFlag : %c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSource);
				break;			
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("SeqNo :: %d ,ord_req->ReqHeader.Segment :%c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSegment);
				break;
			case 8:
				memset( ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is SecId :%.12s:",ord_req->ReqHeader.iSeqNo, ord_req->sSecurityId);
				break;
			case 9:
				logDebug2("this is entityId ");
				memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is EntityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sEntityId);
				break;
			case 10:
				logDebug2("this is ClientId ");
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is ClientId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sClientId);
				break;
			case 11:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cProductId);
				logDebug2("SeqNo :: %d , Product Id is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProductId);
				break;
			case 12:
				//memcpy(ord_req->cBuyOrSell,temp_store,strlen(temp_store));
				sscanf(temp_store,"%c",&ord_req->cBuyOrSell);
				logDebug2("SeqNo :: %d , ord_req->BuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->cBuyOrSell);
				break;
			case 13:
				ord_req->iOrderType = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iOrderType :%d:",temp_store,ord_req->iOrderType);
				break;
			case 14:
				ord_req->iOrderValidity = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iOrderValidity:%d:",temp_store,ord_req->iOrderValidity);
				break;

			case 15:
				sscanf(temp_store,"%d",&ord_req->iDiscQty);
				logDebug2("SeqNo :: %d , ord_req->DiscQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iDiscQty);
				break;
			case 16:
				sscanf(temp_store,"%d",&ord_req->iDiscQtyRem);
				logDebug2("SeqNo :: %d , ord_req->DiscQtyRemaining : %d",ord_req->ReqHeader.iSeqNo,ord_req->iDiscQtyRem);
				break;
			case 17:
				sscanf(temp_store,"%d",&ord_req->iTotalQtyRem);
				logDebug2("SeqNo :: %d , ord_req->TotalQtyRemaining : %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalQtyRem);
				break;
			case 18:
				sscanf(temp_store,"%d",&ord_req->iTotalQty);
				logDebug2("SeqNo :: %d , ord_req->TotalQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalQty);
				break;

			case 19:
				sscanf(temp_store,"%d",&ord_req->iTotalTradedQty);
				logDebug2("SeqNo :: %d , ord_req->iTotalTradedQty: %d",ord_req->ReqHeader.iSeqNo,ord_req->iTotalTradedQty);
				break;	

			case 20:
				sscanf(temp_store,"%d",&ord_req->iMinFillQty);
				logDebug2("SeqNo :: %d , ord_req->MinFillQty : %d",ord_req->ReqHeader.iSeqNo,ord_req->iMinFillQty);
				break;

			case 21:
				sscanf(temp_store,"%lf",&ord_req->fPrice);
				logDebug2("SeqNo :: %d , ord_req->Price : %lf",ord_req->ReqHeader.iSeqNo,ord_req->fPrice);
				break;

			case 22:
				sscanf(temp_store,"%lf",&ord_req->fTriggerPrice);
				logDebug2("SeqNo :: %d , ord_req->TriggerPrice : %lf",ord_req->ReqHeader.iSeqNo,ord_req->fTriggerPrice);
				break;

			case 23:
				sscanf(temp_store,"%lf",&ord_req->fOrderNum);
				logDebug2("SeqNo :: %d , ord_req->OrderNum %lf",ord_req->ReqHeader.iSeqNo,ord_req->fOrderNum);
				break;

			case 24:
				logDebug2("this is SerialNum ");
				sscanf(temp_store,"%d",&ord_req->iSerialNum);
				ord_req->iSerialNum = atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->SerialNum : %d",ord_req->ReqHeader.iSeqNo,ord_req->iSerialNum);
				break;
			case 25:

				sscanf(temp_store,"%c",&ord_req->cHandleInst );
				//                        	sscanf(temp_store,"0" );
				logDebug2(" CTD HandlInst = [%c]",ord_req->cHandleInst );
				break;

			case 26:
				ord_req->fAlgoOrderNo = atof(temp_store);	
				logDebug2(" SeqNo :: %d , ord_req->fAlgoOrderNo :%lf:",ord_req->ReqHeader.iSeqNo,ord_req->fAlgoOrderNo);
				break;
			case 27:
				ord_req->iStratergyId= atoi(temp_store);	
				logDebug2(" SeqNo :: %d , ord_req->iStratergyId:%d",ord_req->ReqHeader.iSeqNo,ord_req->iStratergyId);
				break;


			case 28:
				sscanf(temp_store,"%c",&ord_req->cOffMarketFlg);
				logDebug2("SeqNo :: %d , ord_req->cOffMarketFlg : %c",ord_req->ReqHeader.iSeqNo,ord_req->cOffMarketFlg);
				break;


			case 29:
				//memcpy(ord_req->cProCli,temp_store,strlen(temp_store));
				sscanf(temp_store,"%c",&ord_req->cProCli);
				logDebug2("SeqNo :: %d ,ord_req->cProCli  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProCli );
				break;

			case 30:
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("SeqNo :: %d ,ord_req->cUserType :%c",ord_req->ReqHeader.iSeqNo,ord_req->cUserType);
				break;

			case 31:
				memset(ord_req->sRemarks,'\0',REMARKS_LEN);
				memcpy(ord_req->sRemarks,temp_store,strlen(temp_store));
				logDebug2("SeqNo :: %d , ord_req->Remarks : %s",ord_req->ReqHeader.iSeqNo,ord_req->sRemarks);
				break;

			case 32:
				ord_req->iMktType = atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->iMktType :%d:",ord_req->ReqHeader.iSeqNo,ord_req->iMktType);
				break;
			case 33:
				ord_req->iAuctionNum= atoi(temp_store);
				logDebug2("SeqNo :: %d , ord_req->iAuctionNum:%d:",ord_req->ReqHeader.iSeqNo,ord_req->iAuctionNum);
				break;
			case 35:
				ord_req->fSqrOffPrice = atof(temp_store);
				logDebug2("SeqNo :: %d , ord_req->fSqrOffPrice :%f:",ord_req->ReqHeader.iSeqNo,ord_req->fSqrOffPrice);
				break;
			case 36:
				ord_req->fTrailingSLValue = atof(temp_store);
				logDebug2("SeqNo :: %d , ord_req->fTrailingSLValue:%f:",ord_req->ReqHeader.iSeqNo,ord_req->fTrailingSLValue);
				break;
			case 37:
				sscanf(temp_store,"%c",&ord_req->cBuySellInd2);
				logDebug2("SeqNo :: %d , ord_req->cBuySellInd2 :%c",ord_req->ReqHeader.iSeqNo,ord_req->cBuySellInd2);

			default	:
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;
		}
		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);

	}   
	/**free(arr);***/
	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	//ord_req->AuctionNum  = 0 ;
	return TRUE;

}



BOOL  Map_C2D_Req(char *requestDetails ,struct CON_TO_DELIVERY_REQUEST *ord_req)
{
	int i=0;
	char *arr[100];
	char temp_store[100];
	char *buf ;
	memset ( ord_req , '\0', sizeof( struct CON_TO_DELIVERY_REQUEST));

	logDebug2("Packet recieved:%s",requestDetails);

	while(1)
	{
		/**	logDebug2 ("\n\t Value of i is : %d " , i) ;***/
		if( i == 0)
		{
			arr[i]=strtok_r(requestDetails,"|",&buf);
		}
		else
		{
			arr[i]=strtok_r(NULL,"|",&buf);
			if(arr[i]==NULL)
			{
				logDebug2(" The string is completely tokenised");
				break;
			}
		}

		memset(temp_store , '\0', 100 );
		strcpy(temp_store,arr[i]);
		/*****
		  logDebug2("\n Counter In Map_1LOrd_Req :: %d ",i);
		  logDebug2("\n temp_store :: %s ",temp_store);
		 ******/

		switch(i+1)
		{
			case 1:
				ord_req->ReqHeader.iSeqNo = atoi(arr[0]);
				logDebug2(" iSeqNo	::	%d ",ord_req->ReqHeader.iSeqNo);

				break;
			case 2:
				ord_req->ReqHeader.iMsgLength = sizeof(struct CON_TO_DELIVERY_REQUEST );
				logDebug2(" iSeqNo :: %d ,The MsgLength is %d",ord_req->ReqHeader.iSeqNo, ord_req->ReqHeader.iMsgLength);
				break;
			case 3:
				ord_req->ReqHeader.iMsgCode = atoi(temp_store);
				logDebug2(" temp_store :%s: ord_req->ReqHeader.iMsgCode :%d:",temp_store,ord_req->ReqHeader.iMsgCode);
				break;
			case 4:
				memset(ord_req->ReqHeader.sExcgId,'\0',EXCHANGE_LEN);
				memcpy(ord_req->ReqHeader.sExcgId,temp_store,EXCHANGE_LEN);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.ExcgId :%s",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.sExcgId);
				break;
			case 5:
				sscanf(temp_store,"%d",&ord_req->ReqHeader.iUserId);
				logDebug2(" iSeqNo :: %d ,ord_req->ReqHeader.UserId :%d",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.iUserId);
				break;
			case 6:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSource);
				logDebug2("SeqNo :: %d , ord_req->SourceFlag : %c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSource);
				break;			
			case 7:
				sscanf(temp_store,"%c",&ord_req->ReqHeader.cSegment);
				logDebug2("SeqNo :: %d ,ord_req->ReqHeader.Segment :%c",ord_req->ReqHeader.iSeqNo,ord_req->ReqHeader.cSegment);
				break;
			case 8:
				memset( ord_req->sSecurityId , '\0', SECURITY_ID_LEN);
				memcpy(ord_req->sSecurityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is SecId :%.12s:",ord_req->ReqHeader.iSeqNo, ord_req->sSecurityId);
				break;
			case 9:
				logDebug2("this is entityId ");
				memset(ord_req->sEntityId,'\0',ENTITY_ID_LEN);
				memcpy(ord_req->sEntityId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is EntityId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sEntityId);
				break;
			case 10:
				logDebug2("this is ClientId ");
				memset(ord_req->sClientId,'\0',CLIENT_ID_LEN);
				memcpy(ord_req->sClientId,temp_store,strlen( temp_store ));
				logDebug2("SeqNo :: %d ,this is ClientId :%s:",ord_req->ReqHeader.iSeqNo, ord_req->sClientId);
				break;
			case 11:
				//memcpy(ord_req->cBuyOrSell,temp_store,strlen(temp_store));
				sscanf(temp_store,"%c",&ord_req->cBuyOrSell);
				logDebug2("SeqNo :: %d , ord_req->BuyOrSell : %c",ord_req->ReqHeader.iSeqNo,ord_req->cBuyOrSell);
				break;
			case 12:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cProdIdFrom);
				logDebug2("SeqNo :: %d , Product From is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProdIdFrom);
				break;
			case 13:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cProdIdTo);
				logDebug2("SeqNo :: %d , Product To is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cProdIdTo);
				break;
			case 14:
				logDebug2(" temp_store :%s: ",temp_store);	
				sscanf(temp_store,"%c",&ord_req->cUserType);
				logDebug2("SeqNo :: %d , UserType is  %c",ord_req->ReqHeader.iSeqNo,ord_req->cUserType);
				break;
			case 15:
				ord_req->iQty = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iQty :%d:",temp_store,ord_req->iQty);
				break;
			case 16:
				ord_req->iMktType = atoi(temp_store);	
				logDebug2(" temp_store :%s: ord_req->iMktType:%d:",temp_store,ord_req->iMktType);
				break;
			default	:
				logDebug2(" Error for  SeqNo :: %d ",ord_req->ReqHeader.iSeqNo);
				return FALSE;
		}
		i++;
		logDebug2(" TOKEN NUMBER : [%d]",i);
	}   
	logDebug2(" Returning for Sequence Number :: %d ",ord_req->ReqHeader.iSeqNo);
	return TRUE;
}
