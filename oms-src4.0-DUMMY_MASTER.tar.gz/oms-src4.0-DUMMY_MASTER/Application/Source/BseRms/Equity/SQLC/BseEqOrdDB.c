#include "IPCS.h"
#include <mysql.h>
#include <stdlib.h>
#include <my_global.h>

extern struct USER_DETAIL_ARRAY  pUser;
extern iMsgType;
extern DBConBEQ;

BOOL LoadUserDetail()
{
	logTimestamp("Entry [UserDetail]");

	MYSQL_RES	*Res;
	MYSQL_ROW 	Row;
	LONG32		iCount,iRow;

	memset(&pUser, '\0', sizeof(struct USER_DETAIL_ARRAY));
	CHAR *FetchDealer = malloc(sizeof(CHAR) * MAX_QUERY_SIZE);

	sprintf(FetchDealer,"select u.USER_CODE,ifnull (u.USER_CTCL_GROUP,1),u.USER_EQU_BSE_LOC_CODE from ENTITY_MASTER em left outer join USER_MASTER u \
			on em.ENTITY_CODE=u.USER_ENTITY_CODE \
			where em.ENTITY_TYPE IN('D','A') \
			and USER_EQU_BSE_LOC_CODE	<> 0 ");

	logDebug2("%s",FetchDealer);

	if(mysql_query(DBConBEQ,FetchDealer)!= SUCESS)
	{
		sql_Error(DBConBEQ);
		free(FetchDealer);
		logFatal("error Fetching Dealer location code");
		exit(ERROR);	
	}
	Res = mysql_store_result(DBConBEQ);
	iRow = mysql_num_row(Res);

	if(iRow == 0)
	{
		mysql_free_result(Res);
		free(FetchDealer);
		logFatal("No Dealer location found for BSE equity");
	}
	else
	{
		iCount = 0;
		while(Row = mysql_fetch_row(Res))
		{
			pUser.User_Dtl[iCnt].iUserId = atoi(Row[0]);
			pUser.User_Dtl[iCnt].iUserGrpId = atoi(Row[1]);
			strncpy(pUser.User_Dtl[iCnt].sLocationCode,Row[2],LOC_CODE_LEN);
			iCnt++;
		}
		pUser.iNoOfUsers = iCnt;
		mysql_free_result(Res);
		free(FetchDealer);
		logDebug2("Dealer Location Code Loaded -> %d.",iRow);
	}


}
