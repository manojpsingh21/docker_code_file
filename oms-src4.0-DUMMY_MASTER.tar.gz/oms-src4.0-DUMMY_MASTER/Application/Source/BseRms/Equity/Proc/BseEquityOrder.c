#include <stdio.h>
#include <my_global.h>
#include <stdio.h>
#include <mysql.h>
#include <unistd.h>
#include "IPCS.h"

LONG32		iCatalystToOrdSrvBseEQ;
LONG32		iOrdSrvToConAdpBseEQ;
LONG32		iOrdSrvToTrdRtr;
MYSQL		*DBConBEQ;
//CHAR		sGeneratedOrdNo[]
BOOL 		ChekFlag = TRUE;
LONG32		iBcmBranchId
LONG32		iBExchUserId
CHAR		cMsgType;

main(int arge ,char argv[])
{
	logTimeStamp("Entry in main..");
	DBConBEQ = DB_Connect();
	setbuff(stdout, NULL);
	setbuff(stderr, NULL);
	LoadBseEnv();
	cMsgType = argv[1][0];
	OpenMsgQueue();
	LoadUserDetail();


}

BOOL	OpenMsgQueue()
{
	logTimeStamp("Entry in OpenMsgQueue");

	if((iCatalystToOrdSrvBseEQ = OpenMsgQ(CatalystToOrdSrvBseEQ)) == ERROR)
	{
		logFatal("Error.. OpenMsgQ(CatalystToOrdSrvBseEQ)");
		exit(ERROR);
	}
	logInfo("Queue Open Successfully(CatalystToOrdSrvBseEQ) with id = %d", iCatalystToOrdSrvBseEQ);

	if((iOrdSrvToConAdpBseEQ = OpenMsgQ(OrdSrvToConAdpBseEQ)) == ERROR)
	{
		logFatal("Error in OpenMsgQ(OrdSrvToConAdpBseEQ)");
		exit(ERROR);
	}
	logInfo("Queue Open Successfully(OrdSrvToConAdpBseEQ) with id = %d", iOrdSrvToConAdpBseEQ);

	if((iOrdSrvToTrdRtr = OpenMsgQ(OrdSrvToTrdRtr)) == ERROR)
	{
		logFatal("Error in OpenMsgQ(OrdSrvToTrdRtr)");
		exit(ERROR);
	}
	logInfo("Queue Open Successfully(OrdSrvToTrdRtr) with id = %d", iOrdSrvToTrdRtr);	

	logTimeStamp("Exit [OpenMsgQueue]");
}

BOOL LoadBseEnv()
{
	logTimeStamp("Entry in Environment Varible");

	if(getenv("BSE_CM_BRANCH_ID") == NULL)
	{
		logFatal("Error ... Environment varible Missing (BSE_CM_BRANCH_ID)");
		exit(ERROR);
	}
	else
	{
		iBcmBranchId = atoi(getenv("BSE_CM_BRANCH_ID"));
	}
	if(getenv("BSE_CM_BROKER_ID") == NULL)
	{
		logFatal("Error.. Environment varible Missing ()");
		exit(ERROR);
	}
	else
	{
		strncpy(sBBeginStr,getenv("BSE_CM_BROKER_ID"),ENV_VARIABLE_LEN);
	}
	if(getenv("BSE_CM_EXCH_USER_ID") == NULL)
	{
		logFatal("Error... Environment Varible Missing ()");
		exit(ERROR);
	}
	else
	{
		strncpy(sBSenderCompId,getenv("BSE_CM_EXCH_USER_ID"),ENV_VARIABLE_LEN);
		iBExchUserId = atoi(getenv("BSE_CM_EXCH_USER_ID"));
	}

	logTimeStamp("Exit [LoadBseEnv]");
}
